#!/bin/sh
#
# script file to start WLAN for WPS 2.0 SPEC
#
#set -o xtrace
nvram=/usr/sbin/nvram
WLAN_IF="ath0"
WAN_IF=`nvram get wan_ifname`
BR="br0"
BR_PRI="br0"
BR_SLV="br0"
LAN_HWADDR=`nvram get lan_hwaddr`
sys_uptime=$([ -f /proc/uptime ] && cat /proc/uptime | awk '{print $1}' | awk -F. '{print $1}')
DATETIME=`date +"%A,%B %C,%Y %T"`
MSSID_num=1
SSID_ACT=0
MSSID_disable=1
RUN_GUEST_ACCESS_FILE=0
KVER=`uname -r | cut -f 1 -d '-'`
MODULE_PATH=/lib/modules/$KVER/net
hostapd=/sbin/hostapd
conf_hostapd=/tmp/hostapd/hostapd.conf
dir_hostapd=/tmp/hostapd
topo=/tmp/topology.conf
guest_access_file=/tmp/guest_access
TMP_HOSTAPD=$hostapd #/tmp/hostapd_$1
HOSTAPD_CLI=/sbin/hostapd_cli
TMP_CONF_HOSTAPD=
RUN_HOSTAPD=0
################################################################################################

## Initialize lan group ##
if [ "$(nvram get wan_phy_mode)" = "adsl" ]; then
	interface_group_map=$(nvram get interface_group_map)
	for i in 1 2 3 4; do 
		ath_group=`echo $interface_group_map | cut -d":" -f $i | grep "ath0"`
		if [ "x$ath_group" != "x" ]; then
			ath_group=lan${i}_ifname
			BR_PRI=$(nvram get lan${i}_ifname)
			break
		fi
	done
	for i in 1 2 3 4; do 
		ath_group=`echo $interface_group_map | cut -d":" -f $i | grep "ath2"`
		if [ "x$ath_group" != "x" ]; then
			BR_SLV=$(nvram get lan${i}_ifname)
			break
		fi
	done
else
	BR="br0"
	BR_PRI="br0"
	BR_SLV="br0"
fi

##MODE##
MODE="ap"
if [ "$(nvram get wds_endis_fun)" = "1" -a "$(nvram get wds_repeater_basic)" = "0" -a "$(nvram get wds_endis_mac_client)" = "1" ]; then        
    MODE="repeater"
fi
##

## Initial varible ##
WL_ACL_NUM=`nvram get wl_acl_num`
WL_ACCESS_CTRL_ON=`nvram get wl_access_ctrl_on`
##

config_open_hostapd()
{
cat <<EOF
#
# Open (NO) Security
#
wpa=0

interface=$1
ssid=$3
auth_algs=3

logger_syslog_level=3
logger_stdout_level=3
debug=1
ctrl_interface=/var/run/hostapd
ctrl_interface_group=0
macaddr_acl=0
bridge=$2
wme_enabled=0

# hw_mode=a
# driver=atheros
logger_syslog=-1
logger_stdout=-1
dump_file=/tmp/hostapd.dump
ignore_broadcast_ssid=0
ieee8021x=0
eapol_key_index_workaround=0

#
# WSC configuration section
#
config_methods=label display push_button keypad
EOF
}

config_wep_hostapd()
{
cat <<EOF
#
# WEP Selected
#
#using expr the index should be reduced by 1
wep_default_key=$4
auth_algs=1
wep_key0=$5
wep_key1=$6
wep_key2=$7
wep_key3=$8

interface=$1
ssid=$3
auth_algs=1
logger_syslog_level=2
logger_stdout_level=2
debug=1
ctrl_interface=/var/run/hostapd
ctrl_interface_group=0
macaddr_acl=0
bridge=$2
wme_enabled=0

# hw_mode=a
logger_syslog=-1
logger_stdout=-1
dump_file=/tmp/hostapd.dump
ignore_broadcast_ssid=0
ieee8021x=0
eapol_key_index_workaround=0
dtim_period=2
max_num_sta=255
wep_rekey_period=300
wep_key_len_broadcast=5
wep_key_len_unicast=5

#
# WSC configuration section
#
config_methods=label display push_button keypad
EOF
}

config_psk_hostapd()
{
cat <<EOF
#
# WPA-PSK Selected
#
wpa=$6
$4
wpa_key_mgmt=WPA-PSK
wpa_pairwise=$5
wpa_group_rekey=3600
wpa_gmk_rekey=3600

interface=$1
ssid=$3
auth_algs=3

logger_syslog_level=3
logger_stdout_level=3
debug=1
ctrl_interface=/var/run/hostapd
ctrl_interface_group=0
macaddr_acl=0
bridge=$2
wme_enabled=0

# hw_mode=a
logger_syslog=-1
logger_stdout=-1
dump_file=/tmp/hostapd.dump
ignore_broadcast_ssid=0
ieee8021x=0
eapol_key_index_workaround=0

#
# WSC configuration section
#
config_methods=label display push_button keypad
EOF
}

config_psk_none_wps_hostapd()
{
cat <<EOF
#
# WPA-PSK Selected
#
wpa=$6
wpa_passphrase=$4
wpa_key_mgmt=WPA-PSK
wpa_pairwise=$5
wpa_group_rekey=3600
wpa_gmk_rekey=3600
wpa_strict_rekey=1

interface=$1
ssid=$3
bridge=$2
logger_syslog=-1
logger_syslog_level=2
logger_stdout=-1
logger_stdout_level=2
ctrl_interface=/var/run/hostapd
ctrl_interface_group=0
dtim_period=2
max_num_sta=255
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wme_enabled=0
ieee8021x=0
eapol_version=2
eapol_key_index_workaround=0
eap_server=1
EOF
}

#$1: Interface(eth0)    $2: bridge $3: ssid(DNI_WIFI)    $4:own_ip_addr(192.168.1.1)
#$5: auth_server_addr(192.168.1.10)    $6: auth_server_port(1812)    $7: auth_server_shared_secret(securite)
#$8: wpa(1 | 2 | 3)    $9: wpa_pairwise(TKIP | CCMP | TKIP CCMP)
config_psk_radius_hostapd()
{
cat <<EOF
#
# RADIUS Selected
#
# The own IP address of the access point (used as NAS-IP-Address)
own_ip_addr=$4
#nas_identifier=test.5gwireless.com

# RADIUS authentication server
auth_server_addr=$5
auth_server_port=$6
auth_server_shared_secret=$7
# RADIUS accounting server
#acct_server_addr=$5
#acct_server_port=1813
#acct_server_shared_secret=$7

### WPA
wpa=$8
wpa_key_mgmt=WPA-EAP
wpa_pairwise=$9
wpa_group_rekey=300
wpa_gmk_rekey=640

logger_syslog=-1
logger_syslog_level=3
logger_stdout=-1
logger_stdout_level=3

bridge=$2
interface=$1
ssid=$3
dump_file=/tmp/hostapd.dump
ctrl_interface=/var/run/hostapd
ctrl_interface_group=0
dtim_period=2
max_num_sta=255
macaddr_acl=0
ignore_broadcast_ssid=0
wme_enabled=0
ieee8021x=1
auth_algs=1

eap_server=0
eap_reauth_period=0
eapol_version=2
eapol_key_index_workaround=1

#===== Disable WPS =====
# wps_state=0
EOF
}

run_wps()
{
	## Aim at WPS 2.0 ##
	if [ "$RUN_HOSTAPD" = "1" ]; then
		echo "Running hostapd!"
		echo "@@$TMP_HOSTAPD -d $TMP_CONF_HOSTAPD@@"
		$TMP_HOSTAPD -d $TMP_CONF_HOSTAPD &
    fi	
}

wps_recovery_led() #no arguments
{
	local WL_WPSLED="off"
	local WL_SECTYPE=`nvram get wl_sectype`
	if [ "`nvram get endis_wl_radio`" = "1" ]; then
		if [ "$WL_SECTYPE" != "1" ]; then
			WL_WPSLED="on"
		fi
	fi
	set_wps_led wifi0 $WL_WPSLED
}

set_wifi_led() #$1: wlan0
{
    echo "$1: wifi_led "

    echo none > /sys/class/leds/wlan_onoff_led/trigger
    echo 0 > /sys/class/leds/wlan_onoff_led/brightness

    if [ "$2" = "up" ]; then
        echo wifi_data > /sys/class/leds/wlan_onoff_led/trigger
        echo 1 > /sys/class/leds/wlan_onoff_led/brightness
        echo 250 > /sys/class/leds/wlan_onoff_led/timeout
    elif [ "$2" = "down" ]; then
        echo none > /sys/class/leds/wlan_onoff_led/trigger
        echo 0 > /sys/class/leds/wlan_onoff_led/brightness
    fi
}

set_wps_led() # $1: wifi0 $2: on|off
{
	## none must be set in order to initialize led behavior ##
	echo "$1: Init wps_led"
	if [ "x$2" = "xoff" ]; then
		echo none > /sys/class/leds/wps_on_led/trigger
		echo 0 > /sys/class/leds/wps_on_led/brightness
	elif [ "x$2" = "xon" ]; then
		echo none > /sys/class/leds/wps_on_led/trigger
		echo 1 > /sys/class/leds/wps_on_led/brightness
	else
		echo "$1: incorrect wps_on_led set, must run with [on|off]."
		echo none > /sys/class/leds/wps_on_led/trigger
		echo 0 > /sys/class/leds/wps_on_led/brightness
	fi
}

blink_wps_led() #$1: wifi0
{
	echo "$1: Blinking wps_on_led"

	## Turn off wps_on_led ##
	echo "$1: Init wps_led"
	echo none > /sys/class/leds/wps_on_led/trigger
	echo 0 > /sys/class/leds/wps_on_led/brightness

	echo timer > /sys/class/leds/wps_on_led/trigger
	echo 1 > /sys/class/leds/wps_on_led/brightness
	if [ "x$2" = "x" ]; then
		## Blinking wps_on_led ##
		echo 500 > /sys/class/leds/wps_on_led/delay_on
		echo 500 > /sys/class/leds/wps_on_led/delay_off
	else
		## Blinking wps_on_led with adjusted speed ##
		echo $2 > /sys/class/leds/wps_on_led/delay_on
		echo $2 > /sys/class/leds/wps_on_led/delay_off
	fi
}

config_wpa_psk() #$1: interface $2: bridge $3: ssid $4: wpa_passphrase $5: wpa_pairwise $6: wpa
{
    CONF_HOSTAPD=/tmp/hostapd/hostapd_$1.conf
    config_psk_hostapd "$1" "$2" "$3" "$4" "$5" "$6" > $CONF_HOSTAPD
    if [ "$1" = "ath0" -o "$1" = "ath1" ]; then 
        #if [ "$($nvram get endis_wl_wps)" != "1" ]; then
	if [ "$6" != "1" ]; then
		## WPS 2.0: disable wps state in "TKIP" ##
                set_wps $1 $CONF_HOSTAPD
        fi
    fi
    if [ "$(nvram get wds_endis_fun)" = "0" ]; then
        if [ "$(nvram get wl_sectype)" != "2" -o "$(nvram get wl_auth)" != "1" -o "$SSID_ACT" != "1" ]; then
            #echo "Running hostapd!"
            RUN_HOSTAPD=1
			TMP_CONF_HOSTAPD="$TMP_CONF_HOSTAPD $CONF_HOSTAPD"
            #$TMP_HOSTAPD -d $CONF_HOSTAPD &
        fi
    fi
}

config_wpa_psk_none_wps() #$1: interface $2: bridge $3: ssid $4: wpa_passphrase $5: wpa_pairwise $6: wpa
{
    CONF_HOSTAPD=/tmp/hostapd/hostapd_$1.conf
    config_psk_none_wps_hostapd "$1" "$2" "$3" "$4" "$5" "$6"> $CONF_HOSTAPD
    if [ "$(nvram get wds_endis_fun)" = "0" ]; then
        if [ "$(nvram get wl_sectype)" != 2 -o "$(nvram get wl_auth)" != "1" -o "$SSID_ACT" != "1" ]; then
            echo "*** Running HOSTAPD in WPA-PSK mode without WPS ability! ***"
			RUN_HOSTAPD=1
			TMP_CONF_HOSTAPD="$TMP_CONF_HOSTAPD $CONF_HOSTAPD"
            #$TMP_HOSTAPD -d $CONF_HOSTAPD &
        fi
    fi
}

set_wps()
{    
	#$1: ath0
    #common settings
    echo "$1: Start WPS Configuration"		   

    AP_SETUP_LOCK="$($nvram get endis_pin)"
    #if [ "$(cat /tmp/wps_client)" = "1" -o "$(nvram get wps_status)" = "5" ]; then
    if [ "$(nvram get wps_status)" = "5" ]; then
        WPS_STATE=2
    else
        WPS_STATE=1
    fi
    if [ "$(nvram get wds_endis_fun)" = "0" ]; then
        #if [ "$(nvram get wl_sectype)" = "2"  -a "$(nvram get wl_auth)" = "1" ]; then
        if [ "$(nvram get wl_sectype)" = "2" ]; then
            WPS_STATE=0
            AP_SETUP_LOCK=1
        fi
    fi
	## Disable WPS if ACL turns on & zero acl list ##
	if [ "$WL_ACL_NUM" = "0" -a "$WL_ACCESS_CTRL_ON" = "1" ]; then
		WPS_STATE=0
	fi

    DEVICE_PIN="$($nvram get wps_pin)"
    bridge=$BR_PRI #br0 #"$($nvram get lan_ifname)"
    DEV_NAME=$(nvram get netbiosname) #deriver from LAN Setup
	PRODUCT_NAME=$(nvram get product_id)

	echo "pbc_in_m1=1" >> $2
    echo "wps_state=$WPS_STATE" >> $2
    echo "eap_server=1" >>$2
    echo "ap_pin=$DEVICE_PIN" >> $2
    echo "upnp_iface=$bridge" >> $2

    echo "friendly_name=$DEV_NAME (Wireless AP)" >> $2
    echo "manufacturer=NETGEAR, Inc " >> $2
    echo "manufacturer_url=http://www.netgear.com" >> $2
    echo "model_name=$PRODUCT_NAME (Wireless AP)" >> $2
    echo "model_url=http://www.netgear.com" >> $2
    echo "model_number=$PRODUCT_NAME" >>  $2
    echo "model_description=$PRODUCT_NAME Wireless AP" >>  $2
    echo "device_type=6-0050F204-1" >>  $2
    if [ "$AP_SETUP_LOCK" = "1" ]; then
        echo "ap_setup_locked=$AP_SETUP_LOCK" >> $2
    fi

}

Ins_module()
{
    echo "*** Inserting Modules ***"
    insmod $MODULE_PATH/adf.ko
    insmod $MODULE_PATH/asf.ko
    insmod $MODULE_PATH/ath_hal.ko
    insmod $MODULE_PATH/ath_rate_atheros.ko
    insmod $MODULE_PATH/ath_spectral.ko maxholdintvl=5000 nfrssi=1 nobeacons=0

    #load DFS if A band is supported,default is supported and set AP_NO_A_BAND=1 if not supported
    insmod $MODULE_PATH/ath_dfs.ko
	insmod $MODULE_PATH/hst_tx99.ko
    insmod $MODULE_PATH/ath_dev.ko
    insmod $MODULE_PATH/umac.ko flowmac_on=0
    insmod $MODULE_PATH/wlan_me.ko
    insmod $MODULE_PATH/ath_pktlog.ko

    Set_region
    #wlanlog

}
##end of Ins_module##

Rm_module()
{   
    echo "*** Removing Modules ***"
    rmmod wlan_scan_ap
    rmmod wlan_scan_sta
    rmmod ath_pktlog
    sleep 2
    rmmod wlan_me
    sleep 2
    rmmod umac
    sleep 2
    rmmod ath_dev
	rmmod hst_tx99
    rmmod ath_dfs
    rmmod ath_spectral
    rmmod ath_rate_atheros
    rmmod ath_hal
    rmmod asf
    rmmod adf
    
    #killall wlanlog
}
##end of Rm_module##

Set_region()
{
    local COUN=`nvram get wl_country`
    #country_code_0=710              # Africa (ZA)
    #country_code_1=156              # Asia china (CN)
    #country_code_2=36               # Australi (AU)
    #country_code_3=124              # Canada (CA)
    #country_code_4=276              # Europe Germany (DE)
    #country_code_5=376              # Israel (IL)
    #country_code_6=392              # Japan (JP)
    #country_code_7=410              # Korea (KR)
    #country_code_8=484              # Mexica (MX)
    ##country_code_9=76               # South America Brazil (BR)
    #country_code_11=364             # Middle East (IR)
    #country_code_10=840             # United States (US)
    #country_code_12=156             # China (CN)
    #country_code_13=643             # Russia (RU)
    #COUN=$((country_code_`nvram get wl_country`))
    #echo "iwpriv wifi0 setCountryID $COUN"

	case "$COUN" in
	0)
		COUN="ZA"
		;;
	1)
		COUN="CN"
		;;
	2)
		COUN="AU"
		;;
	3)
		COUN="CA"
		;;
	4)
		COUN="DE"
		;;
	5)
		COUN="IL"
		;;
	6)
		COUN="JP"
		;;
	7)
		COUN="KR"
		;;
	8)
		COUN="MX"
		;;
	9)
		COUN="BR"
		;;
	10)
		COUN="US"
		;;
	11) #Middle East
		COUN="IR"
		;;
	12)
		COUN="CN"
		;;
	13)
		COUN="RU"
	esac

    #iwpriv wifi0 setCountryID $COUN
	iwpriv wifi0 setCountry $COUN
}
##end of Set_region##

Basic_setting()
{
    echo "$1: basic settings"

    num=$2 #`cut -d 'ath' -f 1`
    AP_INDEX=$num
    if [ "$num" = "0" ]; then
        # 2.4G 
        WL_SSID=$(nvram get wl_ssid)
        WL_ISO=$(nvram get endis_wl_iso)
        WL_BCAST=$(nvram get endis_ssid_broadcast)
        ifconfig wifi0 txqueuelen 1000
        #VOW related configurations
        #iwpriv wifi0 setVowExt 0
        #ifconfig $1 -allmulti
        #iwpriv wifi0 setKeySrchAlways 0
        #iwpriv $1 mcastenhance 0
        #iwpriv $1 acparams 1 0 0 0
        #iwpriv wifi0 set_vsp_enable 0
        #iwpriv wifi0 setPhyRestartWar 0
        #iwpriv wifi0 setVowExtStats 0
    elif [ "$num" = "1" ]; then
        # 5G 
        WL_SSID=$(nvram get wla_ssid)
        WL_ISO=`nvram get endis_wla_iso`
        #WL_ISO=$(nvram get endis_wla_wireless_isolation)
        WL_BCAST=$(nvram get wla_endis_ssid_broadcast)
        ifconfig wifi1 txqueuelen 1000
    else
        #WL_SSID=`nvram get wl_ssid_$num`
        WL_ISO=`nvram get endis_wlg1_iso`
        #WL_BCAST=`nvram get endis_ssid_broadcast_$num`
		WL_BCAST=`nvram get wlg1_endis_guestSSIDbro`
        WL_SSID=`nvram get wlg1_ssid`
        #WL_ISO=$((1 - $(nvram get wlg1_endis_allow_guest) ))
        #WL_BCAST=`nvram get wlg1_endis_guestNet`
        ifconfig wifi0 txqueuelen 1000

        #VOW related configurations
        #ifconfig $1 -allmulti
        #iwpriv $1 mcastenhance 0
        #iwpriv $1 acparams 1 0 0 0
    fi
    ifconfig ath$num txqueuelen 1000
	iwpriv ath$num no_wradar 0

    case "$(nvram get wl_simple_mode)" in
    1)
        echo "$1: up to 54M"
        iwpriv $1 mode 11G
        iwpriv $1 pureg 0
        ;;
    2)
        echo "$1: up to 65M"
        iwpriv $1 mode 11NGHT20
        iwpriv $1 shortgi 0
        iwpriv $1 puren 0
        ;;
    3)
        echo "$1: up to 150M"
        iwpriv $1 mode 11NGHT40PLUS
        iwpriv $1 shortgi 1
        iwpriv $1 puren 0
        iwpriv $1 extoffset 1
        ;;
    5)
        echo "$1: up to 150M"
        iwpriv $1 mode 11NGHT40MINUS
        iwpriv $1 shortgi 1
        iwpriv $1 puren 0
        iwpriv $1 extoffset -1
        ;;
    6)    
        echo "$1: up to 150M"
        iwpriv $1 mode 11NGHT40
        iwpriv $1 shortgi 1
        iwpriv $1 puren 0
        ;;
    esac

    iwpriv $1 vap_doth 0
    
    iwpriv $1 protmode 1   # 802.11g protection mode
    #iwpriv $1 htweptkip 0
    
		iwpriv wifi0 ForBiasAuto 1
    iwpriv $1 bgscan 0
    iwconfig $1 frag "$(nvram get wl_frag)"

    iwpriv wifi0 AMPDU 1
    iwpriv wifi0 AMPDUFrames 32
    iwpriv wifi0 AMPDULim 50000

    WL_RTS=`nvram get wl_rts`
    if [ "$WL_RTS" = "2347" ];then
        iwconfig $1 rts off
    else
        iwconfig $1 rts "$WL_RTS"
    fi

    #iwconfig $1 rate "$(nvram get wl_rate)"
    iwpriv $1 wmm "$(nvram get endis_wl_wmm)"
    iwpriv $1 hide_ssid $((1-$WL_BCAST))
    [ "$(nvram get wl_plcphdr)" = "2" ] && iwpriv $1 shpreamble 0 || iwpriv $1 shpreamble 1
    #iwpriv $1 xr "$(nvram get endis_xr)"

    if [ "$WL_ISO" = "1" ]; then
        iwpriv $1 ap_bridge 0
    else
        iwpriv $1 ap_bridge 1
    fi

    iwconfig $1 essid "$WL_SSID"
    #iwconfig $1 freq mode master "$(nvram get wl_hidden_channel)"
    iwconfig $1 freq "$(nvram get wl_hidden_channel)"
}
##end of Basic_setting##


Security()
{
    echo "$1: Security, num=$2."
    #$1: ath0 | ath1 | ath[2-X]
    mkdir -p $dir_hostapd

    #num=`cut -d 'ath' -f 1`
    num=$2
    AP_INDEX=$num
    if [ "$num" = "0" ]; then
        WL_SSID=`nvram get wl_ssid`
        WL_SECTYPE=`nvram get wl_sectype`
        WL_AUTH=`nvram get wl_auth`
        WL_KEY=$(nvram get wl_key)

        # 'WPA Key
        WL_WPA1_KEY="$(nvram get wl_wpa1_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPA2_KEY="$(nvram get wl_wpa2_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        # 'WPASPSK Key
        WL_WPASPSK_KEY="$(nvram get wl_wpas_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        # 'WPAX Key Length
        WL_WPAX_KEYLEN="$(nvram get wl_sec_wpaphrase_len)"        

        # 'WPA/WPA2 Enterprise 
        #WL_RADIUS_MODE="$(nvram get wl_radius_mode)"
        WL_RAD_MODE="$(nvram get wl_wpae_mode)"
        WL_RAD_SERIP=$($nvram get wl_radiusSerIp)
        WL_RAD_SECTYPE=$($nvram get wl_radiusSecret)
        WL_RAD_PORT=$($nvram get wl_radiusPort)
		BR=$BR_PRI

    elif [ "$num" = "1" ]; then
        WL_SSID=`nvram get wla_ssid`
        WL_SECTYPE=`nvram get wla_sectype`
        WL_AUTH=`nvram get wla_auth`
        WL_KEY=$(nvram get wla_key)

        # 'WPA Key
        WL_WPA1_KEY="$(nvram get wla_wpa1_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPA2_KEY="$(nvram get wla_wpa2_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        # 'WPASPSK Key
        WL_WPASPSK_KEY="$(nvram get wla_wpas_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        # 'WPAX Key Length
        WL_WPAX_KEYLEN="$(nvram get wla_sec_wpaphrase_len)"

        # 'WPA/WPA2 Enterprise 
        #WL_RADIUS_MODE="$(nvram get wla_radius_mode)"
        WL_RAD_MODE="$(nvram get wla_wpae_mode)"
        WL_RAD_SERIP=$($nvram get wla_radiusSerIp)
        WL_RAD_SECTYPE=$($nvram get wla_radiusSecret)
        WL_RAD_PORT=$($nvram get wla_radiusPort)
		BR=$BR_PRI
    else
        AP_IFACE=$1
        #WL_SSID=$(nvram get wl_ssid_$AP_INDEX)
        #WL_SECTYPE=$(nvram get wl_sectype_$AP_INDEX)
        #WL_AUTH=$(nvram get wl_auth_$AP_INDEX)
        #WL_KEY=$(nvram get wl_key_$AP_INDEX)
        WL_SSID=$(nvram get wlg1_ssid)
        WL_SECTYPE=$(nvram get wlg1_sectype)
        WL_AUTH=$(nvram get wlg1_auth)
        WL_KEY=$(nvram get wlg1_key)

        # 'WPA Key
        #WL_WPA1_KEY="$(nvram get wl_wpa1_psk_$AP_INDEX | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        #WL_WPA2_KEY="$(nvram get wl_wpa2_psk_$AP_INDEX | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPA1_KEY="$(nvram get wlg1_wpa1_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPA2_KEY="$(nvram get wlg1_wpa2_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"

        # 'WPASPSK Key
        #WL_WPASPSK_KEY="$(nvram get wl_wpas_psk_$AP_INDEX | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPASPSK_KEY="$(nvram get wlg1_wpas_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        # 'WPAX Key Length
        #WL_WPAX_KEYLEN="$(nvram get wl_sec_wpaphrase_len)"
        WL_WPAX_KEYLEN="$(nvram get wlg1_sec_wpaphrase_len)"

        # 'WPA/WPA2 Enterprise 
        #WL_RADIUS_MODE="$(nvram get wl_radius_mode)"
        WL_RAD_MODE="$(nvram get wlg1_wpae_mode)"
        WL_RAD_SERIP=$($nvram get wlg1_radiusSerIp)
        WL_RAD_SECTYPE=$($nvram get wlg1_radiusSecret)
        WL_RAD_PORT=$($nvram get wlg1_radiusPort)
		BR=$BR_SLV
    fi
    #SSID="$(nvram get wl_ssid_$1 | sed -e 's/\\\\\\\\/\\/g' -e 's/\\\\\\`/`/g' -e 's/\\\"/"/g')"

    WPS_STAT="$(nvram get wps_status)"
    if [ "$WPS_STAT" = "1" ]; then
        WPS_CONF=0
    else
        WPS_CONF=1
    fi
    WPSPIN=`cat /tmp/wpspin`
    
    #if [ ! -e  $TMP_HOSTAPD ]; then ln -s $hostapd  $TMP_HOSTAPD; fi

    echo "WL_SSID=$WL_SSID, WL_SECTYPE=$WL_SECTYPE, WL_AUTH=$WL_AUTH, WL_KEY=$WL_KEY"
    CONF_HOSTAPD=/tmp/hostapd/hostapd_$1.conf
    case $WL_SECTYPE in
    1) #none
        echo "$1: Security none"
        #cat /etc/ath/open.ap_bss > $dir_hostapd/$1.ap_bss
        config_open_hostapd "$1" "$BR" "$WL_SSID" > $CONF_HOSTAPD
        #if [ "$AP_INDEX" -le "1" -a "$($nvram get endis_wl_wps)" = "1" ]; then
        if [ "$AP_INDEX" -le "1" ]; then
            set_wps $1 $CONF_HOSTAPD
        fi

        if [ "$(nvram get wds_endis_fun)" = "0" ]; then
            if [ "$(nvram get wl_sectype)" != 2 -o "$(nvram get wl_auth)" != "1" -o "$SSID_ACT" != "1" ]; then
                #echo "Running hostapd!"
                RUN_HOSTAPD=1
                TMP_CONF_HOSTAPD="$TMP_CONF_HOSTAPD $CONF_HOSTAPD"
                #$TMP_HOSTAPD -d $CONF_HOSTAPD &
            fi
        fi
        ;;
    2) #wep
        echo "$1: Security wep"
        auth=$WL_AUTH    #1 Shared Key  #2 Auto Key  --- algs  1 shared else open @@
        if [ "$AP_INDEX" = "0" ]; then
            # 2.4G
            WEP_KEY0=$(nvram get wl_key1)
            WEP_KEY1=$(nvram get wl_key2)
            WEP_KEY2=$(nvram get wl_key3)
            WEP_KEY3=$(nvram get wl_key4)
        elif [ "$AP_INDEX" = "1" ]; then
            # 5G 
            WEP_KEY0=$(nvram get wla_key1)
            WEP_KEY1=$(nvram get wla_key2)
            WEP_KEY2=$(nvram get wla_key3)
            WEP_KEY3=$(nvram get wla_key4)
        else
            #Guest
            #WEP_KEY0=$(nvram get wl_key1_$AP_INDEX)
            #WEP_KEY1=$(nvram get wl_key2_$AP_INDEX)
            #WEP_KEY2=$(nvram get wl_key3_$AP_INDEX)
            #WEP_KEY3=$(nvram get wl_key4_$AP_INDEX)
            
            WEP_KEY0=$(nvram get wlg1_key1)
            WEP_KEY1=$(nvram get wlg1_key2)
            WEP_KEY2=$(nvram get wlg1_key3)
            WEP_KEY3=$(nvram get wlg1_key4)
        fi

        iwpriv $1 wpa 0

        echo "$1: WEP_KEY0=$WEP_KEY0, WEP_KEY1=$WEP_KEY1, WEP_KEY2=$WEP_KEY2, WEP_KEY3=$WEP_KEY3"
        case "$WL_AUTH" in
        0) #open
	    echo "$1: Security wep open"
            iwpriv $1 authmode 1
            iwconfig $1 key ["$WL_KEY"] open
            ;;
        1) #shared
            echo "$1: Security wep share"
            iwpriv $1 authmode 2
            iwconfig $1 key ["$WL_KEY"] restricted
            ;;
        2) #auto
            echo "$1: Security wep auto"
            iwpriv $1 authmode 4
            iwconfig $1 key ["$WL_KEY"]
            ;;
        esac

        if [ "$WEP_KEY0" != "" ]; then
            iwconfig $1 key [1] "$WEP_KEY0"
        fi
        if [ "$WEP_KEY1" != "" ]; then
            iwconfig $1 key [2] "$WEP_KEY1"
        fi
        if [ "$WEP_KEY2" != "" ]; then
            iwconfig $1 key [3] "$WEP_KEY2"
        fi
        if [ "$WEP_KEY3" != "" ]; then
            iwconfig $1 key [4] "$WEP_KEY3"
        fi


        #WPS Startup    
        #config_wep_hostapd "$1" "$BR" "$WL_SSID" "$(($WL_KEY-1))" "$WEP_KEY0" "$WEP_KEY1" "$WEP_KEY2" "$WEP_KEY3" > $conf_hostapd
        #if [ "$($nvram get endis_wl_wps)" = "1" ]; then
        #    set_wps $1
        #    if [ "${HOSTAPD_VER}" != "v0.5.9" ]; then
                #WPS 2.0 Spec.
                echo "*** WARNING: WPS is enabled in WEP mode!! ***"
                echo "*** WARNING: WPS is disabled  ***"
                echo "*** WARNING: HOSTAPD isn't start-up!! ***"
        #        if [ "$(nvram get wds_endis_fun)" = "0" ]; then
        #            if [ "$WL_SECTYPE" != 2 -o  "$SSID_ACT" != "1" ] && [ "$WL_AUTH" != "1" ]; then
        #                echo "Running hostapd!"
        #                $TMP_HOSTAPD -d $conf_hostapd &
        #           fi
        #       fi
        #fi
        ;;
    3) #wpa-psk
        echo "$1: Security wpa-psk(TKIP)"
        #cat /etc/ath/wpapsk.ap_bss > $dir_hostapd/$1.ap_bss
        sec_algo="TKIP"    
        echo "*** WARNING: WPS is enabled in TKIP only mode!! ***"
        echo "*** WARNING: WPS is disabled  ***"
		if [ ${#WL_WPA1_KEY} -ge 64 ]; then
			WL_WPA1_KEY="wpa_psk=$WL_WPA1_KEY"
		else
			WL_WPA1_KEY="wpa_passphrase=$WL_WPA1_KEY"
		fi
        config_wpa_psk $1 "$BR" "$WL_SSID" "$WL_WPA1_KEY" "$sec_algo" 1
        ;;
    4) #wpa2-psk
        echo "$1: Security wpa2-psk(AES)"
        #cat /etc/ath/wpa2psk.ap_bss > $dir_hostapd/$1.ap_bss
        sec_algo="CCMP"
		if [ ${#WL_WPA2_KEY} -ge 64 ]; then
			WL_WPA2_KEY="wpa_psk=$WL_WPA2_KEY"
		else
			WL_WPA2_KEY="wpa_passphrase=$WL_WPA2_KEY"
		fi
        config_wpa_psk $1 "$BR" "$WL_SSID" "$WL_WPA2_KEY" "$sec_algo" 2
        ;;
    5) #wpa-psk/wpa2-psk
        # Limited key_length=64, using wpa_passphrase!
        echo "$1: Security wpa-psk(TKIP)+wpa2-psk(AES)"
        #if [ "$WL_WPAX_KEYLEN" != "64" ]; then
        #    echo "wpa_passphrase=$WL_WPASPSK_KEY" >> $dir_hostapd/$1.ap_bss
        #else
        #    echo "wpa_psk=$WL_WPASPSK_KEY" >> $dir_hostapd/$1.ap_bss
        #fi
		if [ ${#WL_WPASPSK_KEY} -ge 64 ]; then
			WL_WPASPSK_KEY="wpa_psk=$WL_WPASPSK_KEY"
		else
			WL_WPASPSK_KEY="wpa_passphrase=$WL_WPASPSK_KEY"
		fi
        sec_algo="TKIP CCMP"
        config_wpa_psk $1 "$BR" "$WL_SSID" "$WL_WPASPSK_KEY" "$sec_algo" 3
        ;;
    6) #wpa/wpa2-enterprise
        echo "$1: Security wpa/wpa2 enterprise"
        case "$WL_RAD_MODE" in
        "WPAE-TKIP") #wpa (tkip)
            echo "$1: wpa(tkip) encryption mode"
            sec_algo="TKIP"
            config_psk_radius_hostapd $1 $BR $WL_SSID `nvram get lan_ipaddr` $WL_RAD_SERIP $WL_RAD_PORT $WL_RAD_SECTYPE 1 "$sec_algo" > $CONF_HOSTAPD
            ;;
        "WPAE-AES") #wpa2 (aes)
            echo "$1: wpa2(aes) encryption mode"
            sec_algo="CCMP"
            config_psk_radius_hostapd $1 $BR $WL_SSID `nvram get lan_ipaddr` $WL_RAD_SERIP $WL_RAD_PORT $WL_RAD_SECTYPE 2 "$sec_algo" > $CONF_HOSTAPD
            ;;
        "WPAE-TKIPAES") #wpa (tkip) + wpa2 (aes)
            echo "$1: wpa(tkip) + wpa2(aes) encryption mode"
            sec_algo="CCMP TKIP"
            config_psk_radius_hostapd $1 $BR $WL_SSID `nvram get lan_ipaddr` $WL_RAD_SERIP $WL_RAD_PORT $WL_RAD_SECTYPE 3 "$sec_algo" > $CONF_HOSTAPD
            ;;
        esac

        if [ "$(nvram get wds_endis_fun)" = "0" ]; then
            #echo "Running hostapd!"
            RUN_HOSTAPD=1
            TMP_CONF_HOSTAPD="$TMP_CONF_HOSTAPD $CONF_HOSTAPD"
            #$TMP_HOSTAPD -d $CONF_HOSTAPD &
        fi
        ;;
    esac
}
##end of Security##

ACL()
{
    echo "$1: ACL[$2] Start...."
    MACAC_ENABLED=`nvram get wl_access_ctrl_on`
    #iwpriv $1 maccmd $MACAC_ENABLED
    if [ "$MACAC_ENABLED" != "0" ]; then
        iwpriv $1 maccmd $MACAC_ENABLED
        MACAC_NUM=`nvram get wl_acl_num`
        if [ "$MACAC_NUM" != "0" ]; then
            num=1
            while [ $num -le $MACAC_NUM ]
            do
                AC_MAC=`nvram get wlacl$num | awk '{print $2}'`
                iwpriv $1 addmac $AC_MAC
                num=$(($num+1))
            done
        fi
    fi
}
##end of ACL##

Wds()
{
    if [ "$1" = "start" ]; then
        echo "Wds start:"
        if [ "$(nvram get wds_endis_fun)" = "1" ]; then
            brctl stp $BR_PRI on
            if [ "$(nvram get wds_repeater_basic)" = "1" ]; then  ##root-ap##
                echo "root ap"
                iwpriv ath0 wds 1
                if [ "$(nvram get wds_endis_mac_client)" = "1" ]; then
                    iwpriv ath0 maccmd 1 
                fi
                wlanconfig ath0 nawds mode 1
                for rep in 1 2 3 4; do
                    repeater_mac=$(nvram get repeater_mac$rep)
                    if [ "$repeater_mac" != "" ]; then
                        wlanconfig ath0 nawds add-repeater $repeater_mac 0x6
                    fi
                done
            else  ##repeater##
                echo "repeater"
                #wlanconfig wds5 create wlandev wifi0 wlanmode sta nosbeacon
                if [ "$(nvram get wl_sectype)" = "2" ]; then
                    AP_WEPKEY1=`nvram get wl_key1`
                    AP_WEPKEY2=`nvram get wl_key2`
                    AP_WEPKEY3=`nvram get wl_key3`
                    AP_WEPKEY4=`nvram get wl_key4`

                    iwpriv wds5 wpa 0

                    case "$(nvram get wl_auth)" in
                    0) #open
                        iwpriv wds5 authmode 1
                        iwconfig wds5 key ["$(nvram get wl_key)"] open
                        ;;
                    1) #shared
                        iwpriv wds5 authmode 2
                        iwconfig wds5 key ["$(nvram get wl_key)"] restricted
                        ;;
                    2) #auto
                        iwpriv wds5 authmode 4
                        iwconfig wds5 key ["$(nvram get wl_key)"]
                        ;;
                    esac

                    [ "$AP_WEPKEY1" = "" ] || iwconfig wds5 key [1] "$AP_WEPKEY1"
                    [ "$AP_WEPKEY2" = "" ] || iwconfig wds5 key [2] "$AP_WEPKEY2"
                    [ "$AP_WEPKEY3" = "" ] || iwconfig wds5 key [3] "$AP_WEPKEY3"
                    [ "$AP_WEPKEY4" = "" ] || iwconfig wds5 key [4] "$AP_WEPKEY4"

                fi

                iwpriv wds5 wds 1
                iwpriv wds5 vap_ind 1
                iwpriv wds5 bgscan 0
                iwconfig wds5 mode managed freq $(nvram get wl_hidden_channel)
                iwconfig wds5 ap $(nvram get basic_station_mac)

                if [ "$(nvram get wds_endis_ip_client)" = "1" ]; then
                    iwpriv ath0 maccmd 1 
                fi
                ifconfig wds5 up
                brctl addif $BR_PRI wds5
				ifconfig $BR_PRI hw ether $LAN_HWADDR
            fi
        fi
    else
        echo "Wds stop:" 
        wds_if=`ifconfig -a | grep wds`
        if [ "x$wds_if" != "x" ]; then
            ifconfig wds5 down
            brctl delif $BR_PRI wds5
            #echo "wlanconfig wds5 destroy"
            wlanconfig wds5 destroy
        fi
        iwpriv ath0 wds 0
        brctl stp $BR_PRI off
    fi      
}
##end of Wds##

Guest_access()
{
    ETH_P_ARP=0x0806
    ETH_P_RARP=0x8035
    ETH_P_IP=0x0800
    IPPROTO_ICMP=1
    IPPROTO_UDP=17
    DHCPS_DHCPC=67:68
    PORT_DNS=53

    cat<<EOF > $guest_access_file

#!/bin/sh

ebtables -F FORWARD
ebtables -F INPUT
ebtables -P FORWARD ACCEPT
ebtables -A FORWARD -p $ETH_P_ARP -j ACCEPT
ebtables -A FORWARD -p $ETH_P_RARP -j ACCEPT
ebtables -A FORWARD -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $DHCPS_DHCPC -j ACCEPT
ebtables -P INPUT ACCEPT
ebtables -A INPUT -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $DHCPS_DHCPC -j ACCEPT
ebtables -A INPUT -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $PORT_DNS -j ACCEPT
EOF

    #primary 
    if [ "$(nvram get endis_wl_iso)" = "1" -a "$(nvram get endis_wl_radio)" = "1" ]; then
        RUN_GUEST_ACCESS_FILE=1
        echo "ebtables -A FORWARD -i ath0 -j DROP" >> $guest_access_file
        echo "ebtables -A INPUT -i ath0 -p $ETH_P_IP --ip-dst $(nvram get lan_ipaddr) -j DROP" >> $guest_access_file
    fi
     
    #guest
    index=0
    while [ "$index" -lt "$MSSID_num" ]
    do
        #AP_GUEST_ENIFACE=`nvram get endis_allow_guest_ath$(($index))`
        #AP_GUEST_ENIFACE=`nvram get wl_guest_access_local_endis_$(($index+2))`
        AP_ENABLE_ALLOW_GUEST=$(nvram get wlg1_endis_allow_guest)
        #AP_ENIFACE=`nvram get endis_wl_radio_$(($index+2))`
        AP_ENIFACE=`nvram get wlg1_endis_guestNet`
        
        AP_IFACE=ath$(($index+2))
        if [ "$AP_ENABLE_ALLOW_GUEST" = "0" -a "$AP_ENIFACE" = "1" ]; then
            RUN_GUEST_ACCESS_FILE=1
            echo "ebtables -A FORWARD -i $AP_IFACE -j DROP" >> $guest_access_file
            echo "ebtables -A INPUT -i $AP_IFACE -p $ETH_P_IP --ip-dst $(nvram get lan_ipaddr) -j DROP" >> $guest_access_file
        fi
        index=$(($index+1))
    done 

    if [ "$RUN_GUEST_ACCESS_FILE" = "1" ]; then
        chmod +x $guest_access_file         
        $guest_access_file 
    else
        ebtables -F FORWARD
        ebtables -F INPUT
    fi
}
##end of Guest_access##

Create_vap()
{
	HWADDR=`nvram get wl_hwaddr`
	iwpriv wifi0 setHwaddr $HWADDR
	
	if [ "$(nvram get wds_endis_fun)" = "1" -a "$(nvram get wds_repeater_basic)" != "1" ]; then
		## repeater ##
		wlanconfig wds5 create wlandev wifi0 wlanmode sta nosbeacon
	fi

    # Create 2.4G Interface from eth0
    wlanconfig ath0 create wlandev wifi0 wlanmode ap
    
    # Create Guest interface for 2.4G from eth0
    index=0
    guest_enable=0
    while [ "$index" -lt "$MSSID_num" ]
    do
        #if [ "$(nvram get endis_wl_radio_$(($index+2)))" = "1" ]; then
        if [ "$(nvram get wlg1_endis_guestNet)" = "1" ]; then
            guest_enable=1
        fi
        index=$(($index+1))
    done
    
    index=0
    if [ "$guest_enable" = "1" ]; then
        while [ "$index" -lt "$MSSID_num" ]
        do
            wlanconfig ath$(($index+2)) create wlandev wifi0 wlanmode ap
            index=$(($index+1))
        done
    fi
}
##end of Create_vap##

Kill_vap()
{
    # Destroy interface athx for 2.4G.
    VAP=`ifconfig -a | grep ath2`
    index=0
    if [ "$VAP" != "" ]; then
        while [ "$index" -lt "$MSSID_num" ]
        do
            #echo "wlanconfig ath$(($index+2)) destroy"
            wlanconfig ath$(($index+2)) destroy

            index=$(($index+1))
        done
    fi

    # Destroy Interface ath0 for 2.4G.
    wlanconfig ath0 destroy
}
##end of Kill_vap##

IF_Handle()
{
    echo "$1: IF_Handle."
    AP_IPADDR=$(nvram get lan_ipaddr)
    AP_NETMASK=$(nvram get lan_netmask)
      
    index=0
    while [ "$index" -le "$MSSID_num" ]     
    do
        if [ "$index" = "0" ]; then
            # ath0: 2.4G
            AP_IFACE=ath0
            AP_ENIFACE=`nvram get endis_wl_radio`
        else
            # athx: Guest for 2.4G
            AP_IFACE=ath$(($index+1))
            #AP_ENIFACE=`nvram get endis_wl_radio_$(($index+1))`
            AP_ENIFACE=`nvram get wlg1_endis_guestNet`
        fi 
        if [ "$AP_ENIFACE" = "1" ]; then
            case "$SSID_ACT" in
            1)      
                iwpriv $AP_IFACE bintval 100
                iwpriv $AP_IFACE dtim_period 2
                ;;
            2)      
                iwpriv $AP_IFACE bintval 200
                iwpriv $AP_IFACE dtim_period 2
                ;;
            3)      
                iwpriv $AP_IFACE bintval 300
                iwpriv $AP_IFACE dtim_period 2
                ;;
            4)      
                iwpriv $AP_IFACE bintval 400
                iwpriv $AP_IFACE dtim_period 2
                ;;
            5)      
                iwpriv $AP_IFACE bintval 500
                iwpriv $AP_IFACE dtim_period 2
                ;;                  
            esac    
        fi      
        index=$(($index+1)) 
    done

    if [ "$1" = "start" ]; then
        echo "IF start:"
        index=0
        while [ "$index" -le "$MSSID_num" ]
        do
            if [ "$index" = "0" -a "$MODE" != "repeater" ]; then
                # ath0: 2.4G

                AP_ENIFACE=`nvram get endis_wl_radio`
                AP_IFACE=ath$index
                if [ "$AP_ENIFACE" = "1" ]; then
                    #ifconfig $AP_IFACE up
                    brctl addif $BR_PRI $AP_IFACE
					#ifconfig $BR_PRI hw ether $LAN_HWADDR
                    sleep 1    
                fi
            elif [ "$MODE" != "repeater" ]; then
                #Guest for 2.4G

                #AP_ENIFACE=`nvram get endis_wl_radio_$(($index+2))`
                AP_ENIFACE=`nvram get wlg1_endis_guestNet`
                AP_IFACE=ath$(($index+1))
                if [ "$AP_ENIFACE" = "1" ]; then
                    #ifconfig $AP_IFACE up
                    brctl addif $BR_SLV $AP_IFACE
					#ifconfig $BR_PRI hw ether $LAN_HWADDR
                    sleep 1    
                fi
            fi      

            if [ "$AP_ENIFACE" = "1" ]; then
            #    ifconfig $AP_IFACE down
            #    iwpriv $AP_IFACE disablecoext 1
                ifconfig $AP_IFACE up
            fi

            index=$(($index+1))
        done              
    else
        echo "IF stop:"
        # ath0: 2.4G
        IF=$( iwconfig | grep ath0 )
        if [ "x$IF" != "x" ]; then
            ifconfig ath0 down 
            brctl delif $BR_PRI ath0
        fi

        index=0
        # athx: Guest for 2.4G
        while [ "$index" -lt "$MSSID_num" ]
        do
            AP_IFACE=ath$(($index+2))
            IF=$( iwconfig | grep $AP_IFACE )
            if [ "x$IF" != "x" ]; then
                ifconfig $AP_IFACE down 
                brctl delif $BR_SLV $AP_IFACE
            fi
            index=$(($index+1))
        done 

        Kill_vap
    fi
}
##end of IF_Handle##

main()
{
    echo "$1: wlan_ath.sh..."
   if [ "$1" = "start" ]; then
        
        RADIO=`nvram get endis_wl_radio`
        if [ "$RADIO" = "1" ]; then 
			switch_utility RegisterSet 0x4a 0x518	#Lantiq provide below method/ commend to balance the buffer
			/sbin/ledcontrol -n wlan -s on

            Ins_module
            #nvram set wps_client=""
            #rm -f /tmp/wps_client
            nvram set wlan_busy=1

            if [ "$(nvram get wds_endis_fun)" = "1" -a "$(nvram get wds_repeater_basic)" = "0" ]; then
                Create_vap
                sleep 1

                index=0
                while [ "$index" -le "$MSSID_num" ]
                do
                    if [ "$index" = "0" ]; then
                        # ath0: 2.4G
                        AP_ENIFACE=`nvram get endis_wl_radio`
                        AP_IFACE=ath0
                        AP_INDEX=0
                    else
                        # athx: Guest for 2.4G
                        #AP_ENIFACE=`nvram get endis_wl_radio_$(($index+1))`
                        AP_ENIFACE=`nvram get wlg1_endis_guestNet`
                        AP_IFACE=ath$(($index+1))
                        AP_INDEX=$(($index+1))
                    fi
                    if [ "$MODE" != "repeater" -a "$AP_ENIFACE" = "1" ]; then
                        iwpriv $AP_IFACE wds 1
                        iwpriv $AP_IFACE vap_ind 1
                        Basic_setting $AP_IFACE $AP_INDEX
                        Security $AP_IFACE  $AP_INDEX
                        ACL $AP_IFACE $AP_INDEX
                        SSID_ACT=$(($SSID_ACT+1))                                    
                    fi
                    index=$(($index+1))
                done 

                Guest_access
                IF_Handle start
                sleep 5
                Wds start
            else
                Create_vap
                index=0
                while [ "$index" -le "$MSSID_num" ]
                do
                    if [ "$index" = "0" ]; then
                        # ath0: 2.4G
                        AP_ENIFACE=`nvram get endis_wl_radio`
                        AP_IFACE=ath0
                        AP_INDEX=0
                    else
                        # athx: Guest
                        #AP_ENIFACE=`nvram get endis_wl_radio_$(($index+1))`
                        AP_ENIFACE=`nvram get wlg1_endis_guestNet`
                        AP_IFACE=ath$(($index+1))
                        AP_INDEX=$(($index+1))
                    fi
                    if [ "$MODE" != "repeater" -a "$AP_ENIFACE" = "1" ]; then
                        Basic_setting $AP_IFACE $AP_INDEX
                        Security $AP_IFACE $AP_INDEX
                        ACL $AP_IFACE $AP_INDEX
                        SSID_ACT=$(($SSID_ACT+1))                                     
                    fi
                    index=$(($index+1))
                done 
                #Wds start
                Guest_access
                IF_Handle start
                sleep 5
                Wds start
            fi

            #if [ "$(nvram get wds_endis_fun)" = "0" ]; then
            #    if [ "$(nvram get wl_sectype)" != 2 -o "$(nvram get wl_auth)" != "1" -o "$SSID_ACT" != "1" ]; then
            #        echo "Running hostapd!"
            #        $hostapd $topo &
            #    fi
            #fi

            echo $sys_uptime > /tmp/WLAN_uptime
            DECAYPOWER=$(nvram get wl_txctrl_web)
            [ "$DECAYPOWER" = "0" ] || iwpriv wifi0 tpscale $DECAYPOWER
             nvram set wlan_busy=0
			
			run_wps
			wps_recovery_led
        else
			echo "Wireless disabled"
			/sbin/ledcontrol -n wlan -s off
        fi
    else
        MODLIST=`lsmod | grep ath_hal`
##
## If the modules are already unloaded, we do not need to do anything
##
        if [ "$MODLIST" = "" ]; then
            echo "Modules already unloaded"
            return 
        fi

        #pktlogconf -d          

        #killall hostapd_$1      
        killall -9 hostapd
        #rm -rf $conf_hostapd
        #killall -9 wpa_supplicant
        sleep 4
        Wds stop
        IF_Handle stop 
        rm -rf $dir_hostapd


        #rm -rf /tmp/br*
        #rm -rf /tmp/ap*
        #rm -rf /tmp/sta*
        #rm -rf /tmp/top*
        #rm -rf /tmp/conf*
        #rm -rf /tmp/sta_conf*

        Rm_module

				#WLAN & WPS LED off
				/sbin/ledcontrol -n wlan -s off
				/sbin/ledcontrol -n wps -s off
   fi
}
##end of main##


case "$1" in 
"start")
	SCHEDULE=$2
	if [ "x$SCHEDULE" = "xon" ]; then
		nvram set endis_wl_radio=1
		if [ "x`nvram get log_wire_signal_sched`" = "x1" ]; then
			logger -- "[type4][wireless signal schedule] The wireless signal is ON, " #$DATETIME"
		fi
	fi
    main start
	wl_2G_on=`ifconfig | grep -c wifi0`
	if [ "$wl_2G_on" != "1" ]; then
		main stop
	fi
    ;;  
"stop")
	SCHEDULE=$2
	if [ "x$SCHEDULE" = "xoff" ]; then
		nvram set endis_wl_radio=1
		if [ "x`nvram get log_wire_signal_sched`" = "x1" ]; then
			logger -- "[type4][wireless signal schedule] The wireless signal is OFF, " #$DATETIME"
		fi
	fi
    main stop       
    ;;
"load_module")
    echo "wireless module test" > /dev/console
    Ins_module
    ;;
"restart")
    main stop
    main start    
		wl_2G_on=`ifconfig | grep -c wifi0`
		if [ "$wl_2G_on" != "1" ]; then
			main stop
		fi
    ;;
"wps_pbc")
    	echo "*** WPS: WPS-PBC (Push Button)  ***" > /dev/console
		wifi_pid="$($nvram get wifi_pid)"
		if [ "$wifi_pid" != "" ]; then
			echo "kill pid => $wifi_pid"   
			kill -9 $wifi_pid
		fi
		#if [ "$($nvram get endis_wl_wps)" = "1" ] && [ "$($nvram get endis_wl_radio)" = "1" ]; then
		if [ "$($nvram get endis_wl_radio)" = "1" ]; then
			#WLAN & WPS LED power on
			/sbin/ledcontrol -n wlan -s on
			rm -f /tmp/wps_client
			$HOSTAPD_CLI -i ath0 wps_pbc
			blink_wps_led wifi0
		else
			## WPS is disabled & WPS button is pushed ##
			if [ "$2" = "HW" ]; then
				## The LED MUST keep blinking for 5 more seconds after the WPS button is released ##
				wifi_pid=$$  # get now wifi pid
				$nvram set wifi_pid=$wifi_pid                          
				num=6
				blink_wps_led wifi0 100
				while [ $num -gt 0 ]
				do
					sleep 1
					num=$(($num-1))
				done
				set_wps_led wifi0 off
				$nvram unset wifi_pid
			fi
		fi
    echo "*** RUN WPS-PBC Done!! ***" > /dev/console
    ;;
"wps_pin")
    echo "*** WPS: WPS-PIN (Enter PIN Number)  ***"  > /dev/console
	#WLAN & WPS LED power on
	/sbin/ledcontrol -n wlan -s on
	blink_wps_led wifi0

    rm -f /tmp/wps_client
    enrollee_pin=`cat /tmp/wps_client_pin`
    echo "*** WPS: wps_pin $enrollee_pin ***" > /dev/console
    $HOSTAPD_CLI -i ath0 wps_pin any $enrollee_pin 240
    echo "*** RUN WPS-PIN Done!! ***" > /dev/console
    ;; 
"wps_quit")
    echo "*** WPS: WPS-Restart!! ***" > /dev/console
    WPS_QUIT=$( ps > /tmp/wps_quit; cat /tmp/wps_quit | grep hostapd | awk '{print $1}' )
    if [ $WPS_QUIT != "" ] ; then 
		#WPS LED power off
		/sbin/ledcontrol -n wps -s off
        echo "*** KILL PID: $WPS_QUIT ***" > /dev/console
        kill -HUP $WPS_QUIT
        rm -f /tmp/wps_quit
    fi
	wps_recovery_led
    ;;
"wps_recovery_led")
	echo "*** WPS: Recovery WPS LED ***" > /dev/console
	wps_recovery_led
	;;
"hfreq_blink") #100 msec
	if [ "x$2" != "x" ]; then
		#cur_time=`date +%s`
		#last_time=`cat /tmp/last_blink_time`
		#if [ "x$last_time" != "x" ]; then
		#	delta_time=$(( $cur_time - $last_time ))
		#	if [ $delta_time -le 5 ]; then
		#		echo "*** WPS reentry, go back ***"
		#		return
		#	fi
		#fi
		wifi_pid="$($nvram get wifi_pid)"
		if [ "$wifi_pid" != "" ]; then
			echo "kill pid => $wifi_pid"
			kill -9 $wifi_pid
		fi
		wifi_pid=$$
		$nvram set wifi_pid=$wifi_pid
		#echo $cur_time > /tmp/last_blink_time
		wait_n_sec=$2
		blink_wps_led wifi0 100
		while [ $wait_n_sec -gt 0 ]
		do
			sleep 1
			wait_n_sec=$(( $wait_n_sec-1 ))
		done
		$nvram unset wifi_pid
		wps_recovery_led
	else
		blink_wps_led wifi0 100
	fi
	;;
"lfreq_blink") #500 msec
	blink_wps_led wifi0 500
	;;
*)
    echo "Warning! You must input ./wlan_ath.sh [start|stop|restart|hfreq_blink|lfreq_blink]."
esac
