#!/bin/sh

[ -f /usr/sbin/pppd ] || exit 0

RETVAL=0
prog="pppd"
CAT="/bin/cat"
CUT="/usr/bin/cut"

ETH_WAN_INDEX=`nvram get eth_wan_iface`
wan_phy_auto=`nvram get wan_phy_auto`
wan_phy_mode=`nvram get wan_phy_mode`
if [ "$wan_phy_mode" = "adsl" ]; then
    MULTI_WAN=1    
fi

if [ "$MULTI_WAN" = "1" ]; then
    iface=$2
    manual=$3
    if [ "$iface" = "`nvram get wan_default_iface`" ] || [ "$iface" = "$ETH_WAN_INDEX" ]; then
        DEFAULT_GW=1
    fi
else
    iface=""  
    manual=$2       
    DEFAULT_GW=1
fi

WAN_INFO=/tmp/wan/wan${iface}
if [ "$MULTI_WAN" = "1" ]; then
    PID_FILE="/var/run/ppp${iface}.pid"    
else
    PID_FILE="/var/run/pppd.pid"
fi

CALL_FILE="provider_pptp"
PLUG_IN="plugin dni-pptp.so"
RESOLV_CONF="/var/resolv.conf"

wan_ifname=`nvram get wan${iface}_hwifname`
user=`nvram get wan${iface}_pptp_username`
password=`nvram get wan${iface}_pptp_password`
pptp_conn_id=`nvram get wan${iface}_pptp_connection_id`
mtu=$(nvram get wan${iface}_pptp_mtu)
mru=$(nvram get wan_pptp_mru)
if [ "$mru" = "" ]; then
	mru=$mtu
fi
idle_time=$(nvram get wan${iface}_pptp_idle_time)
demand=`nvram get wan${iface}_pptp_demand`
dy_dns=`nvram get wan${iface}_pptp_dns_assign`
dy_pptp=`nvram get dy${iface}_pptp`

if [ "$dy_pptp" = "1" ]; then
        if [ -n "$(nvram get dns${iface}_pptp_server_addr)" ]; then    
            PPTP_SERVER_IP=`nvram get dns${iface}_pptp_server_addr`
            nvram unset dns${iface}_pptp_server_addr
            server_ip_based=0
        else
            server_ip_based=1
            PPTP_SERVER_IP=`nvram get wan${iface}_pptp_server_ip`
        fi
else
        PPTP_SERVER_IP=`nvram get wan${iface}_pptp_server_ip`
fi

PPTP_MY_IP=`nvram get wan${iface}_pptp_local_ip`
PPTP_NETMASK=`nvram get wan${iface}_pptp_netmask`
wan_hostname=`nvram get wan_hostname`
nat_endis=`nvram get wan${iface}_nat_enable`

if [ "${demand}" = "0" ]; then
	persist_demand="persist"
	idle_time="0"
elif [ "${demand}" = "1" ]; then
	if [ "$idle_time" = "0" ]; then
		persist_demand="persist"
	else
		persist_demand="demand"
		echo 1 > /proc/sys/net/ipv4/ip_forward
	fi
else
	persist_demand="persist"	# for maual trigger 
	idle_time="0"
fi


if [ "$dy_dns" = "0" ]; then
	usepeerdns="usepeerdns"
else
	usepeerdns=""
fi

if [ "$pptp_conn_id" = "" ]; then
	conn_id=""
else
	conn_id="pptp_connection_id $pptp_conn_id"
fi

if [ "$wan_hostname" = "" ]; then
	hostname=""
else
	hostname="pptp_hostname"
fi

if [ "$MULTI_WAN" = "1" ]; then
       iface_num="iface_num ${iface} unit ${iface}"
else
       iface_num="unit 0"
fi
if [ "$DEFAULT_GW" = "1" ];  then
       defaultroute="defaultroute"
       route del default 
else
       defaultroute=""
fi

pptp_based_static_ip() {
        ifconfig ${wan_ifname} ${PPTP_MY_IP} netmask ${PPTP_NETMASK} up
	gw_ip=`nvram get pptp${iface}_gw_static_route`
	stat_dns1=`nvram get wan${iface}_ether_dns1`
	stat_dns2=`nvram get wan${iface}_ether_dns2`
	stat_dns="$stat_dns1 $stat_dns2"

        if [ "$DEFAULT_GW" = "1" ]; then                             
                 /usr/sbin/nvram set wan0_ipaddr=$PPTP_MY_IP
              	 /usr/sbin/nvram set wan0_netmask=$PPTP_NETMASK
               	 /usr/sbin/nvram set wan0_gateway=$gw_ip
                 /usr/sbin/nvram set wan0_dns="$stat_dns"                        
                
                 #route add default gw $gw_ip
        fi

        /usr/sbin/nvram set wan${iface}_dns="$stat_dns"             
        /usr/sbin/nvram set wan${iface}_pptp_dns="$stat_dns"       
        /usr/sbin/nvram set wan${iface}_pptp_server="$PPTP_SERVER_IP"
        /usr/sbin/nvram set wan${iface}_pptp_my_ip="$PPTP_MY_IP"
        /usr/sbin/nvram set wan${iface}_pptp_my_mask="$PPTP_NETMASK"
        /usr/sbin/nvram set wan${iface}_pptp_gw="$gw_ip"
        /usr/sbin/nvram set wan${iface}_pptp_dy_dns="$dy_dns"
         
	fqdn="0" 
        area-ck $PPTP_SERVER_IP
        if [ "$?" = "1" ]; then     #pptp server format is domain based
                  usepeerdns="usepeerdns"
                  server_ip_based=0

                  if [ "$MULTI_WAN" = "1" ] && [ "$DEFAULT_GW" = "1" ]; then                        
                      	echo search $wan_domain > $RESOLV_CONF
                       	for i in $stat_dns; 
                        do
                      		echo adding dns $i
                       		echo nameserver	$i >> $RESOLV_CONF
                       	done
                  fi     
        else                                #pptp server format is ip based                      
                  if [ "$dy_dns" = "0" ]; then
                      	usepeerdns="usepeerdns"
                  else
                       	usepeerdns=""
                  fi
                  server_ip_based=1
        fi

	if [ "$server_ip_based" = "0" -a "x$gw_ip" != "x" ]; then
		fqdn="1" 
                for i in $stat_dns
                do
                     area-ck $PPTP_MY_IP $i $PPTP_NETMASK
                     if [ "$?" != "1" ]; then
                          route add -net ${i} netmask 255.255.255.255 gw $gw_ip
                     fi
                done

                 if [ "$MULTI_WAN" != "1" ]; then		               
                        /etc/rc.d/dnsmasq.sh restart
                 fi
	fi

        #if [ "$server_ip_based" = "1" ]; then
           #     if [ "$DEFAULT_GW" != "1" ]; then
              #         for i in $stat_dns
                 #      do
                    #            area-ck $PPTP_MY_IP $i $PPTP_NETMASK           
                       #         if [ "$?" != "1" ]; then                  #pptp dns server and pptp my ip address are not at same subset
                          #            route add -net ${i} netmask 255.255.255.255 gw $gw_ip
                             #   fi
                        #done
                #fi
        #fi

	if [ "x$gw_ip" != "x" ]; then
                if [ "$MULTI_WAN" != "1" ]; then	
		    forward_flag="`cat /proc/sys/net/ipv4/ip_forward`"
		    echo 0 > /proc/sys/net/ipv4/ip_forward
                fi

		if [ "$server_ip_based" = "1" ]; then 
			area-ck $PPTP_MY_IP $PPTP_SERVER_IP $PPTP_NETMASK
		else
                        find_server_ip=0
                        if [ "$MULTI_WAN" != "1" ]; then
        			PPTP_SERVER_IP_TEMP="`area-ck $PPTP_MY_IP $PPTP_SERVER_IP $PPTP_NETMASK`"
                       		area-ck $PPTP_SERVER_IP_TEMP	# 0 -> IP, 1 -> name 
        			if [ "$?" = "0" ]; then
        				PPTP_SERVER_IP=$PPTP_SERVER_IP_TEMP
                                        find_server_ip=1
        			fi
                        else
                                for i in $stat_dns
                                do                                       
                                        PPTP_SERVER_IP_TEMP=`dns_query $i $PPTP_SERVER_IP`
                                        if [ "$PPTP_SERVER_IP_TEMP" != "0" ] && [ "$PPTP_SERVER_IP_TEMP" != "1" ]; then
                                            PPTP_SERVER_IP=$PPTP_SERVER_IP_TEMP
                                            find_server_ip=1
                                            break;
                                        fi
                                done
                        fi
                         if [ "$find_server_ip" = "1" ]; then
			        area-ck $PPTP_MY_IP $PPTP_SERVER_IP $PPTP_NETMASK
                         else
                                echo "Can't find pptp server IP address!"
                                exit
                         fi
		fi
		if [ "$?" != "1" ]; then
			route add -net ${PPTP_SERVER_IP} netmask 255.255.255.255 gw $gw_ip
		fi

		nvram set pptp${iface}_have_gateway=1                

		sleep 2
                if [ "$MULTI_WAN" != "1" ]; then
		    echo $forward_flag > /proc/sys/net/ipv4/ip_forward
                fi
	fi               

        echo 1 > /proc/sys/net/ipv4/ip_forward

         if [ "$MULTI_WAN" = "1" ]; then
                if [ "$DEFAULT_GW" = "1" ]; then
                        if [ "$wan_phy_auto" = "1" ] && [ "$iface" != "$ETH_WAN_INDEX" ]; then
                                WAN_INFO="/tmp/wan/wan${ETH_WAN_INDEX}"
				wan_proto=`$CAT ${WAN_INFO} | ${CUT} -d ":" -f1`
				if [ "$wan_proto" = "pptp" ] || [ "$wan_proto" = "l2tp" ]; then
				            is_dyn=`$CAT ${WAN_INFO} | ${CUT} -d ":" -f2`
					    if [ "$is_dyn" = "1" ]; then
						    /etc/rc.d/do_nat.sh stop $ETH_WAN_INDEX dhcpc
                                                    T_PID_FILE="/var/run/udhcpc${ETH_WAN_INDEX}.pid"  
                                                    T_PID=`$CAT ${T_PID_FILE}`
                                                    /bin/kill -9 ${T_PID} 
					    else    
						    /etc/rc.d/do_nat.sh stop $ETH_WAN_INDEX static
					    fi
                                            T_PID_FILE="/var/run/ppp${ETH_WAN_INDEX}.pid"   
					    sleep 1
				 elif [ "$wan_proto" = "pppoe" ]; then
                                        T_PID_FILE="/var/run/ppp${ETH_WAN_INDEX}.pid"                                            
                                 elif [ "$wan_proto" = "dhcp" ]; then
                                        T_PID_FILE="/var/run/udhcpc${ETH_WAN_INDEX}.pid"    
                                 fi      
                                 T_PID=`$CAT ${T_PID_FILE}`            
                                 /bin/kill -9 ${T_PID}  
				 /etc/rc.d/do_nat.sh stop $ETH_WAN_INDEX
				 sleep 1
                                 /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_default_ipaddr
                                 /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_default_netmask
                                 /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_default_gateway
                                 /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_dns
                                 /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_dhcp_ipaddr
            		         /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_dhcp_netmask
            		         /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_dhcp_gateway
                                 name=`/usr/sbin/nvram get wan${ETH_WAN_INDEX}_hwifname`
			         /sbin/ifconfig $name 0.0.0.0 down
                        fi
                fi	    
              	/etc/rc.d/do_nat.sh restart $iface static
        else
	       iptables -t nat -D POSTROUTING -o $wan_ifname -j SNATP2P --to-source ${PPTP_MY_IP} > /dev/null 2>&1
	       iptables -t nat -A POSTROUTING -o $wan_ifname -j SNATP2P --to-source ${PPTP_MY_IP}
                /etc/rc.d/dnsmasq.sh restart       
        fi
       
        #if [ "$DEFAULT_GW" = "1" ]; then                   
                #/usr/sbin/nvram set action=3
        #fi        
}


start() {
	# Start daemons.
	echo $"Starting pptp${iface}:"
        
        echo "pptp:$dy_pptp" > ${WAN_INFO}

	pptp_ko=`lsmod | grep ^pptp`
	if [ "$pptp_ko" = "" ]; then
		/usr/sbin/insmod /lib/modules/2.6.30/pptp.ko
	fi

        if [ "$MULTI_WAN" = "1" ];  then
                if [ "$DEFAULT_GW" = "1" ];  then
                    nvram set wan_hwifname=$wan_ifname
                fi
        fi        

	nvram set pptp${iface}_have_gateway=0

        if [ "$dy_pptp" = "0" ]; then
                pptp_based_static_ip
        fi	

	if [ "$manual" != "manual" ] && [ "$manual" != "manually" ]; then
		if [ "${demand}" = "2" ]; then
			echo "Run Manual Connect..."
			RETVAL=$?
			return $RETVAL
		fi
	fi

	#do dial-on-demand and bring link up when starting
	if [ "`nvram get demandex`" = "1" ]; then
		nvram unset demandex	
		demandex="demandex"
	fi
         
	echo "${prog} maxfail -1 ${PLUG_IN} ${PPTP_SERVER_IP} ${hostname} \"${wan_hostname}\" ${conn_id} user ${user} password \"${password}\" mru ${mru} mtu ${mtu} ${persist_demand} ${demandex} idle ${idle_time} ${usepeerdns} ${defaultroute} lcp-echo-failure 3 lcp-echo-interval 10 noipdefault ${iface_num}"
	${prog} maxfail -1 ${PLUG_IN} ${PPTP_SERVER_IP} ${hostname} "${wan_hostname}" ${conn_id} user ${user} password "${password}" mru ${mru} mtu ${mtu} ${persist_demand} ${demandex} idle ${idle_time} ${usepeerdns} ${defaultroute} lcp-echo-failure 3 lcp-echo-interval 10 noipdefault ${iface_num}

	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
        # Stop daemons.
        echo $"Shutting down pptp${iface}:"

        pptp_type=`cat ${WAN_INFO} | cut -d ":" -f2`
          
        if [ -e ${PID_FILE} ]; then
    	    PID=`cat ${PID_FILE}`
        else
            exit;
        fi

        if [ "$MULTI_WAN" = "1" ]; then
            ppp_item=0
            for item in `ls /var/run/ | grep ppp | grep -v pppd | grep -v ppp${iface}`
            do
    		    ppp_item=$(($ppp_item+1))
            done        
        fi
    
        if [ "$PID" != "" ]; then                        

            if [ -e ${PID_FILE} ]; then
                rm -f ${PID_FILE}
            fi
           
             if [ "$MULTI_WAN" = "1" ]; then
                if  [ "$pptp_type" = "0" ]; then                                   

                    /etc/rc.d/do_nat.sh stop $iface static
                    ifconfig $wan_ifname 0.0.0.0

                    /usr/sbin/nvram unset wan${iface}_dns
                    /usr/sbin/nvram unset wan${iface}_pptp_dns 
                    /usr/sbin/nvram unset wan${iface}_pptp_server
                    /usr/sbin/nvram unset wan${iface}_pptp_my_ip
                    /usr/sbin/nvram unset wan${iface}_pptp_my_mask
                    /usr/sbin/nvram unset wan${iface}_pptp_gw
                    /usr/sbin/nvram unset wan${iface}_pptp_dy_dns  
                elif  [ "$pptp_type" = "1" ]; then
                    #/etc/rc.d/do_nat.sh stop $iface dhcpc
                    DHCPC_PID_FILE="/var/run/udhcpc${iface}.pid"
                    DHCPC_PID=`cat $DHCPC_PID_FILE`
                    if [ "$DHCPC_PID" != "" ]; then
                        kill -17 ${DHCPC_PID}
		        kill -9 ${DHCPC_PID}
                        rm -rf ${DHCPC_PID_FILE}
                    fi
                fi
             fi       

             kill -1 ${PID}   # call ip-dowm script            
             sleep 5
             kill -9 ${PID}
             sleep 5
        fi        
    
        if [ -f /var/run/pppd.pid ] && [ "$ppp_item" = "0" ]; then
            rm /var/run/pppd.pid
        fi	       

	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

