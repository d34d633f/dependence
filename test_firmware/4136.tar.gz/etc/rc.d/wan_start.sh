#!/bin/sh

RETVAL=0
UDHCPC_INIT_PROG="/etc/rc.d/udhcpc.sh"
PPPOE_INIT_PROG="/etc/rc.d/pppoe.sh"
MULTI_PPPOE_INIT_PROG="/etc/rc.d/multi-pppoe.sh"
PPTP_INIT_PROG="/etc/rc.d/pptp.sh"
FIXED_INIT_PROG="/etc/rc.d/static.sh"
L2TP_INIT_PROG="/etc/rc.d/l2tp.sh"

NVRAM="/usr/sbin/nvram"
wan_proto=`nvram get wan_proto`
manual=$2

check_mac_assign() 
{
       local proto=`nvram get wan_proto`
       local macassign=0
       case "$proto" in	                                       
       		static|dhcp|bigpond)  
                    macassign=`nvram get wan_ether_mac_assign`      
		    ;;
       		pppoe)
                    macassign=`nvram get wan_pppoe_mac_assign`
 		    ;;                                       
                pptp)
                    macassign=`nvram get wan_pptp_mac_assign`                        			
                    ;;
                l2tp)
                     macassign=`nvram get wan_l2tp_mac_assign`                                           
                     ;;                        		
        esac                

        echo $macassign
}

start() {
	# Start daemons.
	echo $"Starting WAN: "
	#${UDHCPC_INIT_PROG} stop
	#${PPPOE_INIT_PROG} stop
	#${PPTP_INIT_PROG} stop

	wanif=`nvram get wan_hwifname`
	wanhwaddr=`nvram get wan_hwaddr`
	lan_ifname=`nvram get lan_hwifname`
	if [ -z "$wanhwaddr" ]; then
		wanhwaddr=`nvram get wan_factory_mac`
		nvram set wan_hwaddr=$wanhwaddr
		nvram set wan0_hwaddr=$wanhwaddr
		#nvram commit
	fi

	nvram set wan0_hwaddr=$wanhwaddr
	ifconfig $wanif down hw ether $wanhwaddr

        mac_assign=`check_mac_assign`
        if [ "$mac_assign" = "0" ]; then
                echo -n "0" > /proc/net/spoof_mac
        elif [ "$mac_assign" = "1" ]; then
                echo -n "1" > /proc/net/spoof_mac
        else 
                echo -n "1" > /proc/net/spoof_mac
        fi

	ifconfig $wanif up
   /usr/sbin/sigto_infoHdl 38  # send signal to infoHdl wan ip is down
	nvram unset wan0_ipaddr
	nvram unset wan0_netmask
	nvram unset wan0_gateway
	nvram unset wan0_dns
	nvram unset wan_default_ipaddr
	nvram unset wan_default_netmask
	nvram unset wan_default_gateway
   nvram unset wan1_ipaddr
	nvram unset wan1_netmask
	nvram unset wan1_gateway
	nvram unset wan1_dns
  

	route add -host 255.255.255.255 metric 0 dev $wanif

	case "$wan_proto" in	
		static)
#			nvram set DHCPRelayEnabled=0
                
			${FIXED_INIT_PROG} start
         /usr/sbin/sigto_infoHdl 39  # send signal to infoHdl wan ip is up
			;;
		dhcp)		
			#hostname `nvram get wan_hostname`
#			nvram set DHCPRelayEnabled=1	# scenario DUT(WAN)->Relay->Server 
			${UDHCPC_INIT_PROG} start $manual
			;;
		pppoe)
			pppoe_total_numbered=`$NVRAM get count_mulpppoe`
			if [ "`cat /module_name`" = "DEGN1000v3" ] && [ "`cat /firmware_region`" = "RU" ]; then
				if [ "`nvram get wan_pppoe_intranet_wan_assign`" = "0" ]; then
					${UDHCPC_INIT_PROG} intra-start $manual
				else
		                        local pppoe_intra_ip=`$NVRAM get wan_pppoe_intranet_ip`
	                        	$NVRAM set wan_dhcp_ipaddr=$pppoe_intra_ip
				fi
			fi
			if [ $pppoe_total_numbered -eq 2 ];then
				for i in 1 2
				do
					${MULTI_PPPOE_INIT_PROG} start $i $manual
				done
			else
#			   nvram set DHCPRelayEnabled=0
            ${PPPOE_INIT_PROG} start $manual
			fi
			;;
		pptp)
#			nvram set DHCPRelayEnabled=0
			if [ `$NVRAM get dy_pptp` = "1" ];then
				${UDHCPC_INIT_PROG} start $manual
			else
				local PPTP_MY_IP=`$NVRAM get wan_pptp_local_ip`
		                local pptp_hwifname=`$NVRAM get wan_hwifname`
	                        $NVRAM set wan_dhcp_ipaddr=$PPTP_MY_IP
	                        $NVRAM set wan_dhcp_ifname=$pptp_hwifname
				${PPTP_INIT_PROG} start $manual
			fi
			;;
       l2tp)
            if [ "$manual" = "manual" ]; then
                    touch /tmp/ppp/trying
            fi
#                       nvram set DHCPRelayEnabled=0
            if [ "`nvram get dy_l2tp`" = "1" ];then
                    ${UDHCPC_INIT_PROG} start $manual
            else
			local L2TP_MY_IP=`$NVRAM get wan_l2tp_local_ip`
			local l2tp_hwifname=`$NVRAM get wan_hwifname`
			$NVRAM set wan_dhcp_ipaddr=$L2TP_MY_IP
			$NVRAM set wan_dhcp_ifname=$l2tp_hwifname
                    ${L2TP_INIT_PROG} start $manual
            fi
            ;;
		*)

			echo $"Usage: $0 {start|stop|restart}"
	esac

	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting WAN: "
	pppoe_total_numbered=`$NVRAM get count_mulpppoe`
	
	# Delete default route
	#/sbin/ip route delete default
	#ip route delete default
	route del default
	/etc/rc.d/igmpproxy.sh stop
	#${UDHCPC_INIT_PROG} stop
	if [ $pppoe_total_numbered -eq 2 ];then
		for i in 1 2
		do
			${MULTI_PPPOE_INIT_PROG} stop $i
		done
	else
	${PPPOE_INIT_PROG} stop
	fi
	${PPTP_INIT_PROG} stop
	${L2TP_INIT_PROG} stop
	${UDHCPC_INIT_PROG} stop
	${FIXED_INIT_PROG} stop
	if [ "`cat /module_name`" = "DEGN1000v3" ] && [ "`cat /firmware_region`" = "RU" ]; then
		${UDHCPC_INIT_PROG} intra-stop
	fi
	iptables -F -t nat
	#echo 2 > /proc/fast_nat
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

