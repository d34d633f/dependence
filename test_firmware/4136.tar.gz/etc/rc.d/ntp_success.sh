#!/bin/sh

# This script is called when DUT synchronizes with NTP server

/bin/echo "connected" > /tmp/NTP_connect
sleep 2

#nvram set ntp_bootup="`date +%s`"
#nvram set dut_uptime="`cat /proc/uptime  | awk '{print $1}' | awk -F'.' '{print $1}'`"
/etc/rc.d/cmdsched.sh restart both
/usr/sbin/cmd_pot settime
#/etc/rc.d/update_log_timestamp.sh
#/etc/rc.d/cmdsched.sh restart both

NTP_sync_flag=`nvram get NTP_sync_flag`
NTP_sync_OK=`nvram get NTP_sync_OK`
if [ "$NTP_sync_flag" = "1" -a "$NTP_sync_OK" != "1" ]; then
	/etc/rc.d/update_log_timestamp.sh sync
fi
/etc/rc.d/update_log_timestamp.sh update
/sbin/cmd_traffic_meter restart

#ticket 64 connection status-obtain time and lease time
if [ "`nvram get dhcpc_lease_obtain_update`" = 1 ]; then
	#nvram set dhcpc_lease_obtain="`date +%f`"
	nvram unset dhcpc_lease_obtain_update
fi

