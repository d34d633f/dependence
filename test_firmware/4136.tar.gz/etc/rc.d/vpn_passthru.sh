#!/bin/sh

MODULE_PATH=/lib/modules/2.6.30

wan_default_iface=`nvram get wan_default_iface`
ETH_WAN_INDEX=`nvram get eth_wan_iface`
wan_phy_mode=`nvram get wan_phy_mode`
wan_phy_auto=`nvram get wan_phy_auto`

LAN_INTFS="1 2 3 4"
find_lan()  #$1: lan group
{
     slect_wan=wan$1

    for i in $LAN_INTFS
    do 
            group=`nvram get interface_group_map | cut -d":" -f$i`
             if [ "x$group" != "x" ]; then
                    find=`echo $group | grep $slect_wan`
                    if [ "x$find" != "x" ]; then
                            lan_intf=$i
                            break
                    fi
            fi
    done
      
     echo $lan_intf
}


if [ "$wan_phy_mode" = "adsl" ]; then
        MULTI_WAN=1
fi

if [ "$MULTI_WAN" = "1" ]; then
        wan_iface=$2
        index=$wan_iface
	if [ "$2" = "" ]; then
            wan_iface=`nvram get wan_default_iface`
	fi

        wan_ip=`nvram get wan${wan_iface}_default_ipaddr`
        if [ "$wan_phy_auto" = "1" ] && [ "$wan_iface" = "$wan_default_iface" ]; then
                if [ "x$wan_ip" = "x" ]; then
                        wan_iface=$ETH_WAN_INDEX
                        wan_ip=`nvram get wan${wan_iface}_default_ipaddr`
                fi
        fi
        if [ "$wan_iface" = "$ETH_WAN_INDEX" ]; then        
                index=$wan_default_iface
        fi
        lan_iface=`find_lan ${index}`
        if [ "$lan_iface" = "" ]; then
            exit
        fi
fi

pptp_passthru=`nvram get wan${index}_enable_pptp`
l2tp_passthru=`nvram get wan${index}_enable_l2tp`
ipsec_passthru=`nvram get wan${index}_enable_ipsec`

lan_ifname=`nvram get lan${lan_iface}_ifname`

RETVAL=0

init() {
    rmmod nf_nat_pptp 2> /dev/null
    rmmod nf_nat_proto_gre 2> /dev/null
    rmmod nf_conntrack_pptp 2> /dev/null
    rmmod nf_conntrack_proto_gre 2> /dev/null
    rmmod ip_nat_proto_esp 2> /dev/null
    rmmod ip_conntrack_proto_esp 2> /dev/null

    # for pptp passthrough
    /usr/sbin/insmod ${MODULE_PATH}/nf_conntrack_proto_gre.ko
    /usr/sbin/insmod ${MODULE_PATH}/nf_conntrack_pptp.ko
    /usr/sbin/insmod ${MODULE_PATH}/nf_nat_proto_gre.ko
    /usr/sbin/insmod ${MODULE_PATH}/nf_nat_pptp.ko

    # for ipsec passthrough
    #/usr/sbin/insmod ${MODULE_PATH}/ip_conntrack_proto_esp.ko
    #/usr/sbin/insmod ${MODULE_PATH}/ip_nat_proto_esp.ko
    /usr/sbin/insmod ${MODULE_PATH}/nf_conntrack_proto_esp.ko
    /usr/sbin/insmod ${MODULE_PATH}/nf_nat_proto_esp.ko
}


start() {
         if [ "$MULTI_WAN" = "1" ]; then
                local wan_ip=`nvram get wan${wan_iface}_default_ipaddr`
                echo "wan_ip = $wan_ip"
                
                if [ "$pptp_passthru" = "1" ]; then	
                        iptables -D fwd_vpn_passthru -i $lan_ifname -p tcp --dport 1723 -j DROP 
                      	iptables -A fwd_vpn_passthru -i $lan_ifname -p 0x2f -j ACCEPT 
                       	iptables -A fwd_vpn_passthru -d $wan_ip -p 0x2f -j ACCEPT 
        	fi
                if [ "$l2tp_passthru" = "1" ]; then
        		iptables -D fwd_vpn_passthru -i $lan_ifname -p udp --dport 1701 -j DROP 2> /dev/null
        	fi
                if [ "$ipsec_passthru" = "1" ]; then	        
        		iptables -D fwd_vpn_passthru -i $lan_ifname -p esp -j DROP 2> /dev/null
        		iptables -A fwd_vpn_passthru -i $lan_ifname -p esp -j ACCEPT 2> /dev/null
                        iptables -A fwd_vpn_passthru -d $wan_ip -p esp -j ACCEPT 2> /dev/null
        	fi	

                if [ "x$wan_iface" != "x" ]; then
	              nvram set wan${index}_ipaddr_vpn=$wan_ip
	        fi
        else
        	if [ "$pptp_passthru" = "1" ]; then	        	
                        /usr/sbin/insmod ${MODULE_PATH}/nf_conntrack_proto_gre.ko
                        /usr/sbin/insmod ${MODULE_PATH}/nf_conntrack_pptp.ko
                        /usr/sbin/insmod ${MODULE_PATH}/nf_nat_proto_gre.ko
                        /usr/sbin/insmod ${MODULE_PATH}/nf_nat_pptp.ko
        
        		iptables -D fwd_vpn_passthru -i $lan_ifname -p tcp --dport 1723 -j DROP 2> /dev/null
                      	iptables -A fwd_vpn_passthru -p 0x2f -j ACCEPT 2> /dev/null
        	fi

        	if [ "$l2tp_passthru" = "1" ]; then
        		iptables -D fwd_vpn_passthru -i $lan_ifname -p udp --dport 1701 -j DROP 2> /dev/null
        	fi
        
        	if [ "$ipsec_passthru" = "1" ]; then	
                        #/usr/sbin/insmod ${MODULE_PATH}/ip_conntrack_proto_esp.ko
                        #/usr/sbin/insmod ${MODULE_PATH}/ip_nat_proto_esp.ko	
                        /usr/sbin/insmod ${MODULE_PATH}/nf_conntrack_proto_esp.ko
                        /usr/sbin/insmod ${MODULE_PATH}/nf_nat_proto_esp.ko	
        
        		iptables -D fwd_vpn_passthru -i $lan_ifname -p esp -j DROP 2> /dev/null
        		iptables -A fwd_vpn_passthru -p esp -j ACCEPT 2> /dev/null
        	fi	
        fi
}

stop() {

        if [ "$MULTI_WAN" = "1" ]; then
                local wan_ip=`nvram get wan${index}_ipaddr_vpn`
                
                iptables -D fwd_vpn_passthru -i $lan_ifname -p tcp --dport 1723 -j DROP 2> /dev/null
        	iptables -D fwd_vpn_passthru -i $lan_ifname -p udp --dport 1701 -j DROP 2> /dev/null
        	iptables -D fwd_vpn_passthru -i $lan_ifname -p esp -j DROP 2> /dev/null

                iptables -A fwd_vpn_passthru -i $lan_ifname -p tcp --dport 1723 -j DROP 2> /dev/null
        	iptables -A fwd_vpn_passthru -i $lan_ifname -p udp --dport 1701 -j DROP 2> /dev/null
        	iptables -A fwd_vpn_passthru -i $lan_ifname -p esp -j DROP 2> /dev/null

                iptables -D fwd_vpn_passthru -i $lan_ifname -p 0x2f -j ACCEPT 2> /dev/null
                iptables -D fwd_vpn_passthru -d $wan_ip -p 0x2f -j ACCEPT 2> /dev/null

                iptables -D fwd_vpn_passthru -i $lan_ifname -p esp -j ACCEPT 2> /dev/null
                iptables -D fwd_vpn_passthru -d $wan_ip -p esp -j ACCEPT 2> /dev/null
        else
               	rmmod nf_nat_pptp 2> /dev/null
               	rmmod nf_nat_proto_gre 2> /dev/null
               	rmmod nf_conntrack_pptp 2> /dev/null
               	rmmod nf_conntrack_proto_gre 2> /dev/null
               	#rmmod ip_nat_proto_esp 2> /dev/null
               	#rmmod ip_conntrack_proto_esp 2> /dev/null
               	rmmod nf_nat_proto_esp 2> /dev/null
               	rmmod nf_conntrack_proto_esp 2> /dev/null
               	iptables -F fwd_vpn_passthru
                
        	iptables -A fwd_vpn_passthru -i $lan_ifname -p tcp --dport 1723 -j DROP 2> /dev/null
        	iptables -A fwd_vpn_passthru -i $lan_ifname -p udp --dport 1701 -j DROP 2> /dev/null
        	iptables -A fwd_vpn_passthru -i $lan_ifname -p esp -j DROP 2> /dev/null
        fi
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  init)
	init
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

