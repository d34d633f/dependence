#!/bin/sh
# this script is used to control management control list function

#[ -f /bin/iptables ] || exit 0

. /etc/rc.d/tools.sh
RETVAL=0
iptables="iptables"

start() {

	local enable=`nvram get ParentalControl`
	local lan_ipaddr=`nvram get lan_ipaddr`
	if [ "$enable" = "1" ]; then
#		$iptables -t nat -I PREROUTING -p udp --dport 53 -j DNAT --to-destination $lan_ipaddr
		$iptables -t nat -I PREROUTING -p udp --dport 53 -j REDIRECT
	fi
}


stop() {

	local enable=`nvram get ParentalControl`
	local lan_ipaddr=`nvram get lan_ipaddr`
	if [ "$enable" = "1" ]; then
#		$iptables -t nat -D PREROUTING -p udp --dport 53 -j DNAT --to-destination $lan_ipaddr
		$iptables -t nat -D PREROUTING -p udp --dport 53 -j REDIRECT
	fi
}


case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
