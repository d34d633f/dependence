#!/bin/sh

if [ ! "$CONFIGLOADED" ]; then
  if [ -r /etc/rc.d/config.sh ]; then
	  . /etc/rc.d/config.sh 2>/dev/null
	  . /etc/rc.d/model_config.sh 2>/dev/null
	  CONFIGLOADED="1"
	fi
fi

qos_endis_on=`nvram get qos_endis_on`

# start IPQoS
#if [ "$CONFIG_FEATURE_IFX_IPQOS" = "1" ]; then
	. /etc/rc.d/ipqos_preinit
	if [ $qos_endis_on -eq 1 ]; then
		/etc/rc.d/ipqos_init &
	fi
#fi

