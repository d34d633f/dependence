#!/bin/sh

PROG="mini_upnpd"

IFACE=$2
if [ "$IFACE" = "" ]; then
    BR_IFNAME="br0"
else
    index=$(($IFACE-1))
    BR_IFNAME="br$index"
fi

PID_FILE="/var/run/${PROG}${IFACE}.pid"

start() {
	local UPNP_ENABLED=`nvram get upnp_enable`
	local WSC_ENABLE=`nvram get WPSEnable`
	local WSC_EXTERNAL_REGISTRAR=`nvram get WIFIWscExternalRegistrar`

	_CMD=

	if [ $UPNP_ENABLED != 0 ]; then
		_CMD="$_CMD -interface ${BR_IFNAME} -igd /tmp/igd_config${IFACE}"
	fi
	
	if [ "$_CMD" != "" ]; then
		echo $"Starting $PROG: "
		mini_upnpd $_CMD &
		#echo $! > /var/run/${PROG}${IFACE}.pid
		echo $! > "${PID_FILE}"
	fi
	
	RETVAL=$?
	#echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting down $PROG: "
	if [ "$(nvram get wan_phy_mode)" = "adsl" ]; then
		if [ -e "${PID_FILE}" ]; then
			kill `cat ${PID_FILE}`
			rm -f ${PID_FILE}
		fi
		if [ -e "/var/run/${PROG}.pid" ]; then
			kill `cat /var/run/${PROG}.pid`
			rm -f /var/run/${PROG}.pid
			rm -f /tmp/igd_config.old
		fi
	else
		killall -9 ${PROG}
		rm -f /var/run/${PROG}*.pid
		rm -f /tmp/igd_config*.old
	fi
	
	RETVAL=$?
	#echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start 
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
