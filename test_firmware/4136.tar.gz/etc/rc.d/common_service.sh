#!/bin/sh

RETVAL=0

SYSLOGD_INIT_PROG="/etc/rc.d/syslogd.sh"

LLTD_PROG="/etc/rc.d/lltd.sh"
DNS_HIJACK="/etc/rc.d/dns_hijack.sh"
TRAFFIC_INIT_PROG="/sbin/cmd_traffic_meter"
SCHE_PROG="/etc/rc.d/cmdsched.sh"
MAC_FILTER="/etc/rc.d/mac_filter.sh"
WEB_INIT_PROG="/etc/rc.d/web.sh"
ROUTING_PROG="/etc/rc.d/routing.sh"

start() {
	# Start daemons.
	echo $"Starting Services: "
	${WEB_INIT_PROG} start
	${SYSLOGD_INIT_PROG} start
	if [ "`nvram get TimerSettingAuto`" != "1" ]; then
        	setstr=`nvram get TimerSetManualstr`
        	if [ -n $setstr ]; then
        		date -u $setstr
			echo -n "manual_connected" > /tmp/NTP_connect
        	fi
        fi

	if [ "`nvram get router_disable`" = "0" ]; then # NOT APmode
		
		${ROUTING_PROG} start
		${SCHE_PROG} start both		# site_svc/email/both 
                if [ "`nvram get telnet_endis`" = "1" ]; then
                        lan_ifname=`nvram get lan1_ifname`
                        /usr/sbin/utelnetd -d -i $lan_ifname -l /bin/sh
                else
			/usr/sbin/telnetenable
		fi
		/usr/sbin/getdeviceinfo&

		lan_ifname=`nvram get lan_ifname`
		lan_ipaddr=`nvram get lan_ipaddr`	
		${DNS_HIJACK} restart
		echo 0 > /proc/custom_Passthru
		if [ "`nvram get ipv6_pass`" = "1" ];then
			echo 1 > /proc/custom_Passthru
		fi
		if [ "`nvram get PPPoEPassThrough_enable`" = "1" ];then
			if [ "`nvram get ipv6_pass`" = "1" ];then
				echo 3 > /proc/custom_Passthru
			else
				echo 2 > /proc/custom_Passthru
			fi
		fi
	fi
	${TRAFFIC_INIT_PROG} start
	${LLTD_PROG} start
	/sbin/lan_port_resv&
	${MAC_FILTER} prepare
	${MAC_FILTER} restart
	/etc/rc.d/S70usb_host_device.sh start
        #/etc/rc.d/utelnetd.sh restart
	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting Services: "
	${WEB_INIT_PROG} stop
	${SYSLOGD_INIT_PROG} stop
	${SCHE_PROG} stop		# site_svc/email/both  
	${TRAFFIC_INIT_PROG} stop
	${LLTD_PROG} stop
	killall telnetenable
	killall utelnetd
	if [ "`nvram get ipv6_pass`" = "1" ];then
		echo 0 > /proc/custom_Passthru
	fi
	if [ "`nvram get PPPoEPassThrough_enable`" = "1" ];then
		echo 0 > /proc/custom_Passthru
	fi
	RETVAL=$?
	echo
	return $RETVAL
}

ui_start() {
	# Start daemons.
	echo $"Starting Service: "
	if [ "`nvram get router_disable`" = "0" ]; then # NOT APmode
		${ROUTING_PROG} start
                if [ "`nvram get telnet_endis`" = "1" ]; then
                        lan_ifname=`nvram get lan1_ifname`
                        /usr/sbin/utelnetd -d -i $lan_ifname -l /bin/sh
                else
			/usr/sbin/telnetenable
		fi
		echo 0 > /proc/custom_Passthru
		if [ "`nvram get ipv6_pass`" = "1" ];then
			echo 1 > /proc/custom_Passthru
		fi
		if [ "`nvram get PPPoEPassThrough_enable`" = "1" ];then
			if [ "`nvram get ipv6_pass`" = "1" ];then
				echo 3 > /proc/custom_Passthru
			else
				echo 2 > /proc/custom_Passthru
			fi
		fi
	fi
	${LLTD_PROG} start
	${TRAFFIC_INIT_PROG} start
        #/etc/rc.d/utelnetd.sh restart
	RETVAL=$?
	echo
	return $RETVAL
}

ui_stop() {
	# Stop daemons.
	echo $"Shutting Service: "

	${ROUTING_PROG} stop
	${LLTD_PROG} stop
	killall telnetenable
	killall utelnetd
	if [ "`nvram get ipv6_pass`" = "1" ];then
		echo 0 > /proc/custom_Passthru
	fi
	if [ "`nvram get PPPoEPassThrough_enable`" = "1" ];then
		echo 0 > /proc/custom_Passthru
	fi
	${TRAFFIC_INIT_PROG} stop
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  start_ui)
	ui_start
	;;
  stop_ui)
	ui_stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

