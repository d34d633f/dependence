#!/bin/sh

RETVAL=0

NVRAM="/usr/sbin/nvram"
MPOAD="/usr/sbin/mpoad"
MPOACTL="/usr/sbin/mpoactl"
SARCTL="/usr/sbin/sarctl"
IPTV="/etc/rc.d/iptv.sh"

index=$2

ALL_VPI="0 8 1 0 0 0 8 0 0 0 0 1 1 8 8 8 0 2 8 8 1 8 0 8 0"
ALL_VCI="35 35 32 33 40 66 75 32 34 38 100 33 50 32 48 67 50 32 34 36 47 64 101 81 103"
DF_VPI=0
DF_VCI=35
lan_ifname=`$NVRAM get lan_ifname`
wan_hwifname=`$NVRAM get wan_hwifname`
wan_hwaddr=`$NVRAM get wan_hwaddr`
router_disable=`$NVRAM get router_disable`
multi_pvc=`$NVRAM get multi_pvc`
vconfig_enable=`$NVRAM get vconfig_enable`
fw_region=`cat /firmware_region`

if [ "$fw_region" = "GR" ] && [ "$vconfig_enable" = "1" ]; then
        echo 10002 > /proc/gpio         #no vlan check in dev.c
else
        echo 10001 > /proc/gpio         #vlan check in dev.c
fi


start() {
   echo $"Starting PVCs: "

    gr_pvc_set=0
    gr_nas_index=0
    gr_wan_vpi=0
    gr_wan_vci=0

    j=1
    nas_index=0
    while true
    do
               pvc_item=$($NVRAM get "atmPVC$j")
               if [ "x$pvc_item" = "x" ]; then
                        break;
               fi               
            
               ENABLE=`echo "$pvc_item" | awk -F* '{print $1}'` 
               vpi=`echo "$pvc_item" | awk -F* '{print $2}'` 
               vci=`echo "$pvc_item" | awk -F* '{print $3}'` 
               multiplexing=`echo "$pvc_item" | awk -F* '{print $4}'` 
               atmqos=`echo "$pvc_item" | awk -F* '{print $5}'` 
               VLAN=`echo "$pvc_item" | awk -F* '{print $6}'` 
               vid=`echo "$pvc_item" | awk -F* '{print $7}'` 
               #atmqos="ubr:pcr=0"

               if [ "$vci" = "0" ] || [ "$ENABLE" = "0" ];then
                    let j=$j+1  
                    let nas_index=$nas_index+1
                    continue;
               fi            

		skip_set_wan_hwifname=0		
                echo "PVC-${j} is starting"
                wan_proto=$($NVRAM get "wan${j}_proto")
                wan_router=$($NVRAM get "wan${j}_router_mode")
                if [ "$wan_router" = "eoa" ]; then
                        wan_proto="eoa"
                fi
               if [ "$wan_proto" != "pppoa" ]; then

                    if [ "$multiplexing" = "0" ]; then    # LLC mode
                           e_mode=1
                    elif [ "$multiplexing" = "1" ]; then    # VC mode
                           e_mode=0
                    fi 

                    if [ "$wan_proto" = "ipoa" ]; then              # 1483 route                        
                             if [ "$multiplexing" = "0" ]; then       # LLC mode
                                   e_mode=4
                            elif [ "$multiplexing" = "1" ]; then     # VC mode
                                   e_mode=3
                            fi
                            echo "mpoactl add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos"
                            $MPOACTL add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos 
                    elif [ "$wan_proto" = "eoa" ]; then
                            echo "mpoactl add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos"
                            $MPOACTL add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos 
                    else  # 1483 bridge dhcp, fix, pppoe     
                            #echo "mpoactl add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos"
                            #$MPOACTL add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos
                            
                            #if [ "$VLAN" = "1" ]; then      # vlan enabled
		            if [ "$VLAN" = "1" ] && [ "`cat /firmware_region`" = "GR" ] && [ "$vconfig_enable" = "1" ]; then
			     if [ "$gr_pvc_set" = "1" ] && [ "$gr_wan_vpi" = "$vpi" ] && [ "$gr_wan_vci" = "$vci" ]; then
				# same VPI/VCI
				nas_index=$gr_nas_index
			     else
                            	echo "mpoactl add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos"
	                        $MPOACTL add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos
                               	echo "mpoactl set vc${nas_index} vlan 0 vid 0 vprio 0"
                               	$MPOACTL set vc${nas_index} vlan 0 vid 0 vprio 0
			     fi	
				$NVRAM set wan${j}_hwifname="vc${nas_index}.${vid}"
				sleep 2
				ifconfig vc${nas_index} up
				sleep 2
				vconfig add vc${nas_index} ${vid}
				#vconfig set_flag vc${nas_index}.${vid} 1
				wan_hwifname=`$NVRAM get wan${j}_hwifname`
				ifconfig $wan_hwifname up
				skip_set_wan_hwifname=1	
			    else
			     if [ "$gr_pvc_set" = "1" ] && [ "$gr_wan_vpi" = "$vpi" ] && [ "$gr_wan_vci" = "$vci" ]; then
					# same VPI/VCI
					nas_index=$gr_nas_index
			     else
                            	echo "mpoactl add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos"
	                        $MPOACTL add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos
				if [ "$VLAN" = "1" ]; then
	                        	echo "mpoactl set vc${nas_index} vlan 1 vid ${vid} vprio 0"
	                                $MPOACTL set vc${nas_index} vlan 1 vid ${vid} vprio 0
				else
                                   	echo "mpoactl set vc${nas_index} vlan 0 vid 0 vprio 0"
	                                $MPOACTL set vc${nas_index} vlan 0 vid 0 vprio 0
				fi	
			     fi
			        $NVRAM set wan${j}_hwifname="vc${nas_index}"
                            fi
	      		   #if [ "`cat /firmware_region`" = "GR" ] && [ "$wan_proto" != "iptv" ] && [ "$vconfig_enable" = "1" ]; then
	      		   if [ "`cat /firmware_region`" = "GR" ] && [ "$j" = "1" ] && [ "$vconfig_enable" = "1" ]; then
				gr_pvc_set=1
				gr_wan_vpi=$vpi
				gr_wan_vci=$vci
				gr_nas_index=${nas_index}
	 		   fi
                            if [ "$wan_proto" = "iptv" ]; then
                                $IPTV 
                            fi
                    fi

	 	    if [ "$skip_set_wan_hwifname" != "1" ]; then
	 	         $NVRAM set wan${j}_hwifname="vc${nas_index}"
	            fi
	 	    if [ "$j" = "1" ]; then
			wan_hwifname=`$NVRAM get $wan${j}_hwifname`
	         	$NVRAM set wan_hwifname=$wan_hwifname
	            fi
                
                    echo $! > /var/run/vc${nas_index}.pid
                      
                    if [ "$router_disable" -ne "0" ]; then         
                         wan_mtu=`$NVRAM get wan_dhcp_mtu`
                         if [ "$wan_mtu" = "0" ]; then
                            ifconfig vc${nas_index} mtu 1500
                         else
                            ifconfig vc${nas_index} mtu $wan_mtu
                         fi       
                         brctl addif $lan_ifname vc${nas_index}
                     fi
    
                     /sbin/ifconfig vc${nas_index} 0.0.0.0     
                     if [ "$wan_proto" = "iptv" ]; then
                            $IPTV 
                     fi                               
                else
                     $NVRAM set wan${j}_hwifname="vc${nas_index}"	 	     
                fi

                if [ "$multi_pvc" = "$j" ]; then
                     break;
                fi

                let j=$j+1  
                let nas_index=${nas_index}+1
     done      

     RETVAL=$?
     echo
     return $RETVAL
}

pvc_start() {
    echo $"Starting PVC $1: " 

    index=0;
    gr_pvc_set=0
    gr_nas_index=0
    gr_wan_vpi=0
    gr_wan_vci=0
    
    iface=$1
    let nas_index=$iface-1    
    
    pvc_item=$($NVRAM get "atmPVC${iface}")
    if [ "x$pvc_item" = "x" ];then
           return;
    fi
	
     ENABLE=`echo "$pvc_item" | awk -F* '{print $1}'` 
     vpi=`echo "$pvc_item" | awk -F* '{print $2}'` 
     vci=`echo "$pvc_item" | awk -F* '{print $3}'` 
     multiplexing=`echo "$pvc_item" | awk -F* '{print $4}'` 
     atmqos=`echo "$pvc_item" | awk -F* '{print $5}'` 
     #atmqos="UBR,aal5:max_pcr=0,min_pcr=0"
     VLAN=`echo "$pvc_item" | awk -F* '{print $6}'` 
     vid=`echo "$pvc_item" | awk -F* '{print $7}'` 

    if [ "$ENABLE" = "0" ]; then    
          #echo "PVC-${iface} is not enable"
          return;
    fi
    	
     skip_set_wan_hwifname=0
     echo "PVC-${iface} is starting"
     wan_proto=$($NVRAM get "wan${iface}_proto")                 
                wan_router=$($NVRAM get "wan${iface}_router_mode")
                if [ "$wan_router" = "eoa" ]; then
                        wan_proto="eoa"
                fi
     echo "multiplexing=$multiplexing"
                     
    if [ "$wan_proto" != "pppoa" ]; then

          if [ "$multiplexing" = "0" ]; then       # LLC mode
                e_mode=1
          elif [ "$multiplexing" = "1" ]; then    # VC mode
                e_mode=0
          fi 

          if [ "$wan_proto" = "ipoa" ]; then             # 1483 route                        
               if [ "$multiplexing" = "0" ]; then          # LLC mode
                     e_mode=4
               elif [ "$multiplexing" = "1" ]; then       # VC mode
                     e_mode=3
               fi 
               echo "mpoactl add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos"
               $MPOACTL add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos 
          elif [ "$wan_proto" = "eoa" ]; then
              echo "mpoactl add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos"
              $MPOACTL add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos
          else  # 1483 bridge dhcp, fix, pppoe     
              #echo "mpoactl add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos"
              #$MPOACTL add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos
              #if [ "$VLAN" = "1" ]; then   # vlan enabled
	      if [ "$VLAN" = "1" ] && [ "`cat /firmware_region`" = "GR" ] && [ "$vconfig_enable" = "1" ]; then
			if [ "$gr_pvc_set" = "1" ] && [ "$gr_wan_vpi" = "$vpi" ] && [ "$gr_wan_vci" = "$vci" ]; then
				# same VPI/VCI
				nas_index=$gr_nas_index
			else
              			echo "mpoactl add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos"
		                $MPOACTL add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos
                               	echo "mpoactl set vc${nas_index} vlan 0 vid 0 vprio 0"
                               	$MPOACTL set vc${nas_index} vlan 0 vid 0 vprio 0
			fi
				$NVRAM set wan${iface}_hwifname="vc${nas_index}.${vid}"
				sleep 2
				ifconfig vc${nas_index} up
				sleep 2
				vconfig add vc${nas_index} ${vid}
				#vconfig set_flag vc${nas_index}.${vid} 1
				wan_hwifname=`$NVRAM get wan${iface}_hwifname`
				ifconfig $wan_hwifname up
				skip_set_wan_hwifname=1	
	      else
			if [ "$gr_pvc_set" = "1" ] && [ "$gr_wan_vpi" = "$vpi" ] && [ "$gr_wan_vci" = "$vci" ]; then
				# same VPI/VCI
				nas_index=$gr_nas_index
			else
              			echo "mpoactl add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos"
		                $MPOACTL add vc${nas_index} pvc $vpi.$vci encaps $e_mode qos $atmqos
				if [ "$VLAN" = "1" ]; then
	                        	echo "mpoactl set vc${nas_index} vlan 1 vid ${vid} vprio 0"
	                                $MPOACTL set vc${nas_index} vlan 1 vid ${vid} vprio 0
				else
                                   	echo "mpoactl set vc${nas_index} vlan 0 vid 0 vprio 0"
	                                $MPOACTL set vc${nas_index} vlan 0 vid 0 vprio 0
				fi
			fi
			        $NVRAM set wan${iface}_hwifname="vc${nas_index}"
              fi	 
              #if [ "`cat /firmware_region`" = "GR" ] && [ "$wan_proto" != "iptv" ] && [ "$vconfig_enable" = "1" ]; then
              if [ "`cat /firmware_region`" = "GR" ] && [ "$iface" = "1" ] && [ "$vconfig_enable" = "1" ]; then
			gr_pvc_set=1
			gr_wan_vpi=$vpi
			gr_wan_vci=$vci
			gr_nas_index=${nas_index}
	      fi
		
          fi    
         sleep 1
	 
	 if [ "$skip_set_wan_hwifname" != "1" ]; then
	         $NVRAM set wan${iface}_hwifname="vc${nas_index}"
	 fi
	 if [ "$iface" = "1" ]; then
		wan_hwifname=`$NVRAM get $wan${iface}_hwifname`
         	$NVRAM set wan_hwifname=$wan_hwifname
	 fi
                    
         echo $! > /var/run/vc${nas_index}.pid
                          
          if [ "$router_disable" -ne "0" ]; then         
                 wan_mtu=`$NVRAM get wan_dhcp_mtu`
                 if [ "$wan_mtu" = "0" ]; then
                      ifconfig vc${nas_index} mtu 1500
                 else
                      ifconfig vc${nas_index} mtu $wan_mtu
                 fi       
                 brctl addif $lan_ifname vc${nas_index}
           fi
    
           /sbin/ifconfig vc${nas_index} 0.0.0.0                

           if [ "$wan_proto" = "iptv" ]; then
                 $IPTV 
           fi
     fi
}

stop() {

   echo $"Stoping PVCs: "

    j=1
    nas_index=0
    while true
    do
               pvc_item=$($NVRAM get "atmPVC$j")
               if [ "x$pvc_item" = "x" ];then                     
                        break;
               fi

               vci=`echo "$pvc_item" | awk -F* '{print $3}'` 
               if [ "$vci" = "0" ]; then
                    let j=$j+1     
                    let nas_index=$nas_index+1                        
                    continue;
               fi
                
     	       vid=`echo "$pvc_item" | awk -F* '{print $7}'` 
               rm -rf /var/run/vc${nas_index}.pid
               #/sbin/ifconfig nas${nas_index} down
               echo "PVC-${iface} is stopping"
               $MPOACTL del vc${nas_index}
	       ifconfig vc${nas_index}.${vid} down	
	       vconfig rem vc${nas_index}.${vid}
		

               wan_proto=$($NVRAM get "wan${j}_proto")   
               if [ "$wan_proto" = "iptv" ]; then
                    $IPTV 
               fi

               let j=$j+1     
               let nas_index=${nas_index}+1
    done
     
    killall oamd

   RETVAL=$?
   echo
   return $RETVAL
}

pvc_stop() {
    echo $"Stoping PVC $1: " 
    
    let nas_index=$1-1    
    
    pvc_item=$($NVRAM get "atmPVC$1")
    vid=`echo "$pvc_item" | awk -F* '{print $7}'` 

    rm -rf /var/run/vc${nas_index}.pid
    #/sbin/ifconfig vc${nas_index} down
    $MPOACTL del vc${nas_index}    
    ifconfig vc${nas_index}.${vid} down	
    vconfig rem vc${nas_index}.${vid}

    wan_proto=$($NVRAM get "wan${1}_proto")
    if [ "$wan_proto" = "iptv" ]; then
          $IPTV 
    fi

    RETVAL=$?
    echo
    return $RETVAL
}

init_mpoad() {
    $SARCTL pvcnumber 8
    $MPOAD &
}


detauto() {

   index=0
   try_num=3
   VPI=$1 
   VCI=$2

   country=$($NVRAM get "wizard_select_country")
    
   DSLLINK_STATUS=/tmp/dsl_status
   if [ -f $DSLLINK_STATUS ]; then
         dsl_status=`cat $DSLLINK_STATUS`
         if [ $dsl_status != "UP" ]; then
            echo "dsl not link"
            return $RETVAL
         fi
   else
          echo "dsl not link"
          return $RETVAL
   fi

    $OAMD &
    
   if [ "$VPI" != "" ] && [ "$VCI" != "" ]; then 
            atmqos="UBR,aal5:max_pcr=0,min_pcr=0"
            echo $"Starting detect=($VPI/$VCI)"
            echo "br2684ctl -b -p 1 -c 0 -e 0 -q $atmqos -a $VPI.$VCI -s 65536"
            br2684ctl -b -p 1 -c 0 -e 0 -q $atmqos -a $VPI.$VCI -s 65536
            echo $! > /var/run/nas0.pid
             /sbin/ifconfig nas0 0.0.0.0
             oamctl --f5 --vpi $VPI --vci $VCI --scope 0 --continuity-check 2 --loopback 200 --num-of-pings $try_num > /tmp/oam_ping
             sleep 2

             result=`cat /tmp/oam_ping | grep "num_cells_rx" | awk -F":" '{printf $2}' | awk -F" " '{printf $1}'`
             if [ "$result" = "$try_num" ]; then      
                    echo "oam test $VPI/$VCI success"
                    /usr/sbin/nvram set atmPVC1="1*$VPI*$VCI*0"
             else 
                    echo "oam test $VPI/$VCI failed"
                    br2684ctl -k 0
             fi
   else 
           for TESTVCI in $ALL_VCI
           do            
              index=$(($index+1))
              TESTVPI=`echo $ALL_VPI | cut -d " " -f $index`
              atmqos="UBR,aal5:max_pcr=0,min_pcr=0"
              echo $"Starting detect index=$index ($TESTVPI/$TESTVCI)"
              echo "br2684ctl -b -p 1 -c 0 -e 0 -q $atmqos -a $TESTVPI.$TESTVCI -s 65536"
              br2684ctl -b -p 1 -c 0 -e 0 -q $atmqos -a $TESTVPI.$TESTVCI -s 65536

              echo $! > /var/run/nas0.pid
              /sbin/ifconfig nas0 0.0.0.0
        
              oamctl --f5 --vpi $TESTVPI --vci $TESTVCI --scope 0 --continuity-check 2 --loopback 200 --num-of-pings $try_num > /tmp/oam_ping
              sleep 2

              result=`cat /tmp/oam_ping | grep "num_cells_rx" | awk -F"=" '{printf $2}'`
              if [ "$result" = "$try_num" ]; then      
                 echo "oam test $VPI/$VCI success"
                  /usr/sbin/nvram set atmPVC1="1*$VPI*$VCI*0"
                 break;
              else
                 echo "oam test $VPI/$VCI failed"
                 br2684ctl -k 0
                 #stop
              fi              
           done
    fi    

    killall oamd
   #/usr/sbin/nvram set AdslVci=$DF_VCI
   #/usr/sbin/nvram set AdslVpi=$DF_VPI
   #nvram commit
   #start
}


# See how we were called.
echo "$1"
case "$1" in
  init)
	init_mpoad
	;;
  start)
	start
	;;
  stop)
	stop
	;;
  pvc_start)
	if [ "$fw_region" = "GR" ]; then
		start
	else	
        	pvc_start $2
	fi
        ;;
  pvc_stop)
	if [ "$fw_region" = "GR" ]; then
		stop
	else
	        pvc_stop $2
	fi
        ;;  
  pvc_restart)
	if [ "$fw_region" = "GR" ]; then
		stop
		start
	else
	        pvc_stop $2
	        pvc_start $2
	fi
        RETVAL=$?
        ;;                             
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  detauto)
   stop
   detauto $2 $3
   ;;
  *)
	echo $"Usage: $0 {start|stop|restart} "
	exit 1
esac

exit $RETVAL
