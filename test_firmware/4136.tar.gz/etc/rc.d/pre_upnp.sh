#!/bin/sh
#echo "run pre_upnp.sh ..."

WSC_DISABLE=`nvram get wsc_disable`
LAN_MAC=$(nvram get lan_hwaddr | sed -n 's/://gp')
#device_name=`nvram get netbiosname`
#sed devcie name
#xml file can not display '&', '<', '/', '[', '\'
#'\' = '\##92;' need to first sed and '\##92;' = '\&#92;' need to ather '&' 
device_name=$(nvram get netbiosname | sed -e 's/\\/\\\#\#92;/g' -e 's/\&/\\\&amp;/g' -e 's/</\\\&lt;/g' -e 's/\//\\\&\#47;/g' -e 's/\[/\\\&\#91;/g' -e 's/\\\#\#92;/\\\&\#92;/g')
product_name=`nvram get product_id`
#echo "device_name: $device_name"


WAN_NUM=$1 ## current wan interface ##
PICS_FILE_PATH="/var/linuxigd"
## Initialize lan group ##
## igmpproxy only support 1 upstream interface. ##
if [ "$(nvram get wan_phy_mode)" = "adsl" ]; then
	WAN_PROTO=`nvram get wan${WAN_NUM}_proto`
	SKL_FILE="${PICS_FILE_PATH}/picsdesc${WAN_NUM}.skl"
	XML_FILE="${PICS_FILE_PATH}/picsdesc${WAN_NUM}.xml"
else
	WAN_PROTO=`nvram get wan_proto`
	SKL_FILE="${PICS_FILE_PATH}/picsdesc.skl"
	XML_FILE="${PICS_FILE_PATH}/picsdesc.xml"
fi


#for IGD device
mkdir -p $PICS_FILE_PATH
cp /etc/tmp/picsdesc.skl "${SKL_FILE}.1"
cp /etc/tmp/picsdesc.xml "${XML_FILE}.1"


#/bin/sed -e 's/ee1234cc5678/'${LAN_MAC}'/g' -e 's/VEGN2200/'"${device_name}"'/g' ${SKL_FILE}.1 > ${SKL_FILE}
#/bin/sed -e 's/ee1234cc5678/'${LAN_MAC}'/g' -e 's/VEGN2200/'"${device_name}"'/g' ${XML_FILE}.1 > ${XML_FILE}
#/bin/sed -e 's/ee1234cc5678/'${LAN_MAC}'/g' -e 's/<friendlyName>VEGN2200/'"<friendlyName>${device_name}"'/g' ${SKL_FILE}.1 > ${SKL_FILE}
#/bin/sed -e 's/ee1234cc5678/'${LAN_MAC}'/g' -e 's/<friendlyName>VEGN2200/'"<friendlyName>${device_name}"'/g' ${XML_FILE}.1 > ${XML_FILE}
/bin/sed -e 's/ee1234cc5678/'${LAN_MAC}'/g' -e 's/DEVICE_NAME/'"${device_name}"'/g' -e 's/PRODUCT_NAME/'"${product_name}"'/g' ${SKL_FILE}.1 > ${SKL_FILE}
/bin/sed -e 's/ee1234cc5678/'${LAN_MAC}'/g' -e 's/DEVICE_NAME/'"${device_name}"'/g' -e 's/PRODUCT_NAME/'"${product_name}"'/g' ${XML_FILE}.1 > ${XML_FILE}

HW_VER=`cat /hardware_version`
cp "${SKL_FILE}" "${SKL_FILE}.2"
cp "${XML_FILE}" "${XML_FILE}.2"

if [ "$HW_VER" = "DEGN1000v3" ]; then
	/bin/sed -e 's/DEV_1001&amp;REV_01/'DEV_300a\\\&amp\;REV_03'/g' ${SKL_FILE}.2 > ${SKL_FILE}
	/bin/sed -e 's/DEV_1001&amp;REV_01/'DEV_300a\\\&amp\;REV_03'/g' ${XML_FILE}.2 > ${XML_FILE}
fi
#NETGEAR DGN1000v3
#Specific HW ID - VEN_01f2&DEV_300a&REV_03
#Generic  HW ID - VEN_01f2&DEV_8000&REV_01
if [ "$HW_VER" = "DGN1000v3" ]; then
	/bin/sed -e 's/DEV_1001&amp;REV_01/'DEV_300a\\\&amp\;REV_03'/g' ${SKL_FILE}.2 > ${SKL_FILE}
	/bin/sed -e 's/DEV_1001&amp;REV_01/'DEV_300a\\\&amp\;REV_03'/g' ${XML_FILE}.2 > ${XML_FILE}
fi
if [ "$HW_VER" = "DGN1000v3-3DDAUS" ]; then
	/bin/sed -e 's/DEV_1001&amp;REV_01/'DEV_300a\\\&amp\;REV_03'/g' ${SKL_FILE}.2 > ${SKL_FILE}
	/bin/sed -e 's/DEV_1001&amp;REV_01/'DEV_300a\\\&amp\;REV_03'/g' ${XML_FILE}.2 > ${XML_FILE}
fi

if [ "$WAN_PROTO" = "pptp" -o "$WAN_PROTO" = "pppoe" -o "$WAN_PROTO" = "l2tp" ]; then
	/bin/sed -e 's/WANIPConnection/WANPPPConnection/g' "${SKL_FILE}" > "${SKL_FILE}.2"
	/bin/sed -e 's/WANIPConn1/WANPPPConn1/g' "${SKL_FILE}.2" > "${SKL_FILE}.1"
	/bin/sed -e 's/wanipcn.xml/wanpppcn.xml/g' "${SKL_FILE}.1" > "${SKL_FILE}"
	/bin/sed -e 's/WANIPConnection/WANPPPConnection/g' "${XML_FILE}" > "${XML_FILE}.2"
	/bin/sed -e 's/WANIPConn1/WANPPPConn1/g' "${XML_FILE}.2" > "${XML_FILE}.1"
	/bin/sed -e 's/wanipcn.xml/wanpppcn.xml/g' "${XML_FILE}.1" > "${XML_FILE}"
else
	/bin/sed -e 's/WANPPPConnection/WANIPConnection/g' "${SKL_FILE}" > "${SKL_FILE}.2"
	/bin/sed -e 's/WANPPPConn1/WANIPConn1/g' "${SKL_FILE}.2" > "${SKL_FILE}.1"
	/bin/sed -e 's/wanpppcn.xml/wanipcn.xml/g' "${SKL_FILE}.1" > "${SKL_FILE}"
	/bin/sed -e 's/WANPPPConnection/WANIPConnection/g' "${XML_FILE}" > "${XML_FILE}.2"
	/bin/sed -e 's/WANPPPConn1/WANIPConn1/g' "${XML_FILE}.2" > "${XML_FILE}.1"
	/bin/sed -e 's/wanpppcn.xml/wanipcn.xml/g' "${XML_FILE}.1" > "${XML_FILE}" 
fi
rm "${SKL_FILE}.1"
rm "${XML_FILE}.1"
rm "${SKL_FILE}.2"
rm "${XML_FILE}.2"

#for WFA device
mkdir -p /var/wps
cp /etc/rc.d/simplecfg* /var/wps

cp /etc/rc.d/wscd.conf /var/wps/wscd.conf.1
cp /etc/rc.d/wscd_config /tmp/wscd_config.1

/bin/sed -e 's/aabbccddeeff/'${LAN_MAC}'/g' /var/wps/wscd.conf.1 > /var/wps/wscd.conf
rm /var/wps/wscd.conf.1

#/bin/sed -e 's/aabbccddeeff/'${LAN_MAC}'/g' /tmp/wscd_config.1 > /tmp/wscd_config
/bin/sed -e 's/aabbccddeeff/'${LAN_MAC}'/g' /tmp/wscd_config.1 > /tmp/wscd_config.2
rm /tmp/wscd_config.1

#generate random port
rnd_seed=`cat /proc/stat | grep intr | awk '{print $2}'`
echo "$rnd_seed" > /dev/urandom
tmp_rnd_num=`dd if=/dev/urandom bs=1 count=1 2>/dev/null | hexdump -d | head -1 | awk '{print 0+$NF}'`
rnd_num=$((${tmp_rnd_num}%10000))
rnd_port=$((${rnd_num} + 50000))

/bin/sed -e 's/57788/'${rnd_port}'/g' /tmp/wscd_config.2 > /tmp/wscd_config
rm /tmp/wscd_config.2

# UPNP advertise time, delete first then insert the item.
upnp_AdverTime=`nvram get upnp_AdverTime`
old_pattern="`grep max_age /tmp/wscd_config`"
new_pattern="max_age $upnp_AdverTime"
/bin/sed -i s/"$old_pattern"/"$new_pattern"/g /tmp/wscd_config

