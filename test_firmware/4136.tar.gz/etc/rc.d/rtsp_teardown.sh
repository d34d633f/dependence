#!/bin/sh

# Usage: del_conntrack.sh service_type entry_num
# Format: "Service_Type Src_IP Min_Port Max_Port"

proc_fs_name=conntrack_killer

rtsp_ports=`cat /proc/net/rtsp_ports`
Min_Port=`echo $rtsp_ports | awk -F, '{print $1}'`
Max_Port=`echo $rtsp_ports | awk -F, '{print $2}'`
echo "port_range 255.255.255.255 $Min_Port $Max_Port" > /proc/$proc_fs_name


