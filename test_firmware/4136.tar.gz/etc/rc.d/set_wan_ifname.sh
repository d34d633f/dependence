#!/bin/sh

RETVAL=0


wan_proto=`nvram get wan_proto`
wan_hwifname=`nvram get wan_hwifname`
case "$wan_proto" in	
	static)
		nvram set wan_ifname=$wan_hwifname
		;;
	dhcp|bigpond)		
		nvram set wan_ifname=$wan_hwifname
		;;
	pppoe)
		nvram set wan_ifname=ppp0
		;;
	pptp)
		nvram set wan_ifname=ppp0
		;;
	*)
esac

if [ "`cat /module_name`" = "DEGN1000v3" ]; then
	ETH_WAN_INDEX=`nvram get eth_wan_iface`
	ETH_IFNAME=nas0
	nvram set wan${ETH_WAN_INDEX}_hwifname="$ETH_IFNAME"
	wan_proto=`nvram get wan${ETH_WAN_INDEX}_proto`
	wan_hwifname=`nvram get wan${ETH_WAN_INDEX}_hwifname`
fi

case "$wan_proto" in	
	static)
		nvram set wan_ifname=$wan_hwifname
		;;
	dhcp|bigpond)		
		nvram set wan_ifname=$wan_hwifname
		;;
	pppoe)
		nvram set wan_ifname=ppp${wan_hwifname}
		;;
	pptp)
		nvram set wan_ifname=ppp${wan_hwifname}
		;;
	*)
esac

RETVAL=$?
echo
exit $RETVAL
