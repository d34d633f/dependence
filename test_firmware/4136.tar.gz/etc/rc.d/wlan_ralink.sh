#!/bin/sh
#
# script file to setting WLAN and run
#
#set -o xtrace
NVRAM=/usr/sbin/nvram
WLAN_IF="`${NVRAM} get wl_ifname`"
WAN_IF="`${NVRAM} get wan_ifnames`"
BR="`${NVRAM} get lan_ifname`"

#fw_region=`cat /firmware_region`

AOSS_LED=/usr/sbin/aoss-led
CAT=/bin/cat
sys_uptime=$([ -f /proc/uptime ] && ${CAT} /proc/uptime | awk '{print $1}' | awk -F. '{print $1}')
MSSID_num=4
MSSID_disable=1

model=`${CAT} /vendor_model_name`
AP_CFG=/tmp/RT2860AP.dat
WLAN_SET=/usr/bin/wlancmd
IWPRIV=/sbin/iwpriv
CP=/bin/cp
#INSMOD=/sbin/insmod
INSMOD=/usr/sbin/insmod
IFCONFIG=/sbin/ifconfig
RMMOD=/sbin/rmmod
ECHO=/bin/echo
BRCTL=/usr/sbin/brctl
DEBUG_LOG=/tmp/aaron_debug_log
EBTABLE_BIN="/usr/sbin/ebtables"
IPTABLES_BIN="/usr/sbin/iptables"
RM=/bin/rm

SSID_PREFIX="BUFFALO-"

BOARD_INOF_REGION=`${NVRAM} get region_boardinfo`
LED_CHECK=0
AOSS_TOOL_RUN=0

calc_wireless_client()
{
	client_num="`/usr/bin/wc -l /proc/DNI_wireless_info`"
	modify="`${ECHO} -n ${client_num}|sed s/"\/proc\/DNI_wireless_info"//g`"
	client_num=$((${modify}-1))
	${NVRAM} set CURRENT_WL_CLIENT=${client_num}
}
Kill_proc()
{
    if [ -f $1 ] ; then
       	  PID=`${CAT} $1`
	  if [ $PID != 0 ]; then
	       kill -9 $PID
	  fi
          rm -f $1
    fi
}

AosscList()
{
	${WLAN_SET} assoclist display -i 0 |grep -v No|cut -d " " -f2|grep -v no >/tmp/assoclist.txt
	${WLAN_SET} assoclist display -i 1 |grep -v No|cut -d " " -f2|grep -v no >>/tmp/assoclist.txt
	${WLAN_SET} assoclist display -i 2 |grep -v No|cut -d " " -f2|grep -v no >>/tmp/assoclist.txt
	${WLAN_SET} assoclist display -i 3 |grep -v No|cut -d " " -f2|grep -v no >>/tmp/assoclist.txt
	
}
LED_ERROR()
{
	if [ "`ps -ef|grep '${AOSS_LED} error'|grep -v grep|head -1|awk '{print $1}'`" = "" ];then
		${AOSS_LED} error
	fi
}
#return 1: error
#		0: not error
led_by_aoss_check()
{
#	if [ "`${NVRAM} get WIFIAOSSAction`" = "1" ];then
#		return 0
#	fi
#	if [ "`${NVRAM} get WIFIAOSSButtonEnable`" = "0" ];then
#		return 0
#	fi
	i=0
	cat /proc/DNI_wireless_security | while read line
	do
		key="`echo $line | cut -d "," -f 6`"
		ssid="`echo $line |cut -d "," -f 3`"
		s3="`echo $line |grep WEP`"
		if [ "${i}" = "3" ];then
			break
		fi
		if [ "`ifconfig|grep ra${i}`" != "" ];then
			if [ "${s3}" = "" ];then
				if [ "${#key}" -gt "63" -o "x`${ECHO} -n ${ssid}| grep ' '`" != "x" ];then
					${ECHO} 1 > /tmp/aoss_check_ttmp
					break
				elif [ "x`${ECHO} -n ${key}| grep ' '`" != "x" ];then
					${ECHO} 1 > /tmp/aoss_check_ttmp
					break
				fi
			else
				if [ "x`${ECHO} -n ${ssid}| grep ' '`" != "x" ];then
					${ECHO} 1 > /tmp/aoss_check_ttmp
					break
				fi
			fi
		fi
		i=$((${i}+1))
	done

	if [ -e /tmp/aoss_check_ttmp ];then
		return "1"
	else
		return "0"
	fi
}
led_security()
{
	##aaaa
	if [ ! -e /tmp/hw_button_ttmp -a "`${CAT} /proc/tc3162/wps_button`" = "0" ];then
##################################################################
		check_WPS_function
		Current_WPS_ENABLE="`${NVRAM} get Current_WPS_ENABLE`"
##################################################################
		if [ "${Current_WPS_ENABLE}" = "1" -o "`${NVRAM} get WIFIAOSSButtonEnable`" = "1" ];then
			${NVRAM} set AOSS_ERROR_STATUS=0
			${ECHO} 1 >> /tmp/hw_button_ttmp
			if [ "`${CAT} /proc/tc3162/led_sec_lock`" != "2" ];then
				#LED error check
				led_by_aoss_check
				#if [ "$?" = "1" -o  "`${NVRAM} get AOSS_INPUT_ERROR`" != "0" ];then
				if [ -e /tmp/aoss_check_ttmp ];then
					${RM} /tmp/aoss_check_ttmp
					killall ${AOSS_LED}
					${AOSS_LED} error
				else
					${AOSS_LED} Connect
				fi
			fi
		else
			${RM} /tmp/hw_button_ttmp 2>/dev/null
		fi
	fi
}
led_security_web_bt()
{
	if [ "`${NVRAM} get WPSEnable`" = "1" -o "`${NVRAM} get WIFIAOSSAction`" = "1" ];then
		${AOSS_LED} Connect
	fi
}

Attachdev()
{
   echo "Ssid_index_0" > /tmp/wirelessclist
	${WLAN_SET} assoclist display -i 0 |grep -v No|cut -d " " -f2 >>/tmp/wirelessclist
   echo "Ssid_index_1" >> /tmp/wirelessclist
	${WLAN_SET} assoclist display -i 1 |grep -v No|cut -d " " -f2 >>/tmp/wirelessclist
   echo "Ssid_index_2" >> /tmp/wirelessclist
	${WLAN_SET} assoclist display -i 2 |grep -v No|cut -d " " -f2 >>/tmp/wirelessclist
   echo "Ssid_index_3" >> /tmp/wirelessclist
	${WLAN_SET} assoclist display -i 3 |grep -v No|cut -d " " -f2 >>/tmp/wirelessclist	
}

Applications()
{
	echo "Application setting.."
}
update_AOSS_Client_tables()
{
	while [ -e /tmp/lock_nvram ]
	do
		${ECHO} 0 >/dev/null
	done
	client="`${NVRAM} get WIFIAOSS_CLIENT_LIST`"
	del_item=" 1,Aaron,${1},----"
	del_item1="1,Aaron,${1},---- "
	del_item2="1,Aaron,${1},----"
	echo -n ${client} >/tmp/aoaa_tables
	modify="`sed s/"${del_item}"//g < /tmp/aoaa_tables`"
	echo -n ${modify} > /tmp/aoaa_tables 
	modify="`sed s/"${del_item1}"//g < /tmp/aoaa_tables`"
	echo -n ${modify} > /tmp/aoaa_tables 
	modify="`sed s/"${del_item2}"//g < /tmp/aoaa_tables`"
	${ECHO} 0 > /tmp/lock_nvram
	${NVRAM} set WIFIAOSS_CLIENT_LIST="${modify}"
	${RM} /tmp/aoaa_tables
	${RM} /tmp/lock_nvram
}

BRIDGE()
{
	${BRCTL} ${1} ${BR} ${2}
}
WMM_FILE()
{
	${CP} /etc/Wireless/RT2860AP/RT2860AP_default.dat ${AP_CFG}

	# Workaround for BasicRateSet, due to imprive not work.
	${ECHO} "BasicRate=`${NVRAM} get WIFIBasicRate`" >> ${AP_CFG}	
	${ECHO} "WirelessMode=`${NVRAM} get WIFI54gMode`" >> ${AP_CFG}	
	${ECHO} "CountryCode=`${NVRAM} get WIFIRegion`" >> ${AP_CFG}

	${ECHO} "HT_BSSCoexistence=`${NVRAM} get HT_BSSCoexistence`" >> ${AP_CFG}

	RekeyInterval=`${NVRAM} get WIFIRekeyIntervalSingle`	
	${ECHO} "RekeyInterval=$((${RekeyInterval}*60))" >> ${AP_CFG}

	if [ "`${NVRAM} get WIFIChannel`" = 0 ];then
		${ECHO} "AutoChannelSelect=1" >> ${AP_CFG}
	else
		${ECHO} "AutoChannelSelect=0" >> ${AP_CFG}
	fi
	${ECHO} "APAifsn=`${NVRAM} get GUIAPAifsn`" >> ${AP_CFG}
	${ECHO} "APCwmin=`${NVRAM} get GUIAPCwmin`" >> ${AP_CFG}
	${ECHO} "APCwmax=`${NVRAM} get GUIAPCwmax`" >> ${AP_CFG}
	${ECHO} "APTxop=`${NVRAM} get GUIAPTxop`" >> ${AP_CFG}
	${ECHO} "APACM=0;0;0;0" >> ${AP_CFG}
	${ECHO} "BSSAifsn=`${NVRAM} get GUIBSSAifsn`" >> ${AP_CFG}
	${ECHO} "BSSCwmin=`${NVRAM} get GUIBSSCwmin`" >> ${AP_CFG}
	${ECHO} "BSSCwmax=`${NVRAM} get GUIBSSCwmax`" >> ${AP_CFG}
	${ECHO} "BSSTxop=`${NVRAM} get GUIBSSTxop`" >> ${AP_CFG}
	${ECHO} "BSSACM=0;0;0;0" >> ${AP_CFG}
	${ECHO} "WscConfMethods=86;86;86;86" >> ${AP_CFG}
	${ECHO} "WscConfMode=7" >> ${AP_CFG}
	# RT3390 only support 1T1R
	${ECHO} "HT_TxStream=1" >> ${AP_CFG}
	${ECHO} "HT_RxStream=1" >> ${AP_CFG}
	${ECHO} "WmmCapable=`${NVRAM} get WIFIWmmCapable`" >> ${AP_CFG}
        #if [ "`${NVRAM} get WIFI_TEST`" = "1" ];then
        #        ${ECHO} "WmmCapable=`${NVRAM} get WIFIWmmCapable`" >> ${AP_CFG}
        #fi
	${ECHO} "HT_RDG=`${NVRAM} get WIFIHTRDG`" >> ${AP_CFG}
}
WMM()
{
	wmm_enable=`${NVRAM} get WIFIWmmCapable`
	if [ "${1}" = "STOP" ];then
		${IWPRIV} ra0 set WmmCapable=0
		${IWPRIV} ra1 set WmmCapable=0
		${IWPRIV} ra2 set WmmCapable=0
		${IWPRIV} ra3 set WmmCapable=0
	else
		if [ "${wmm_enable}" = "1" ];then
			#${NVRAM} set WIFITxBurst=0
			${IWPRIV} ra${1} set WmmCapable=`${NVRAM} get WIFIWmmCapable` # 0 disable
		fi
	fi
}
start_wps()
{
	ifname=${1}

	PinCode=`${NVRAM} get WIFIWscVendorPinCode`
	${IWPRIV} ${ifname} set WscConfMode=0			
	${IWPRIV} ${ifname} set WscMode=1
	echo 1 > /proc/tc3162/DNI_WscMode
	if [ "`${NVRAM} get WIFIWPS_CONFIG_STATUS`" = "0" ];then
		${IWPRIV} ${ifname} set WscConfMode=7			
		${IWPRIV} ${ifname} set WscVendorPinCode=${PinCode}
		${IWPRIV} ${ifname} set WscConfStatus=1		# un-configured mode 
		${IWPRIV} ${ifname} set WscStatus=0 
	else
		${IWPRIV} ${ifname} set WscConfMode=7
		${IWPRIV} ${ifname} set WscVendorPinCode=${PinCode}
		${IWPRIV} ${ifname} set WscConfStatus=2		# configured mode 
		#${IWPRIV} ${ifname} set WscGetConf=1		# Trigger WPS AP to do simple config with WPS Client
		${IWPRIV} ${ifname} set WscStatus=0 
	fi
}
Wps()
{
	
	ifname="`${NVRAM} get WPS_IFNAME`"
##################################################	
	check_WPS_function
	Current_WPS_ENABLE="`${NVRAM} get Current_WPS_ENABLE`"
##################################################
	case "$1" in 
		start)
		if [ "`${NVRAM} get WPSEnable`" = "1" -a "`${NVRAM} get WIFIAOSSAction`" = "1" ];then
			PinCode=`${NVRAM} get WIFIWscVendorPinCode`
			${IWPRIV} ${ifname} set WscConfMode=0			
			${IWPRIV} ${ifname} set WscMode=1
			echo 1 > /proc/tc3162/DNI_WscMode
			${IWPRIV} ${ifname} set WscConfMode=7
			${IWPRIV} ${ifname} set WscVendorPinCode=${PinCode}
			${IWPRIV} ${ifname} set WscConfStatus=2		# configured mode
			${IWPRIV} ${ifname} set WscStatus=0 
		elif [ "${Current_WPS_ENABLE}" = "1" ];then
			start_wps ${ifname}
		else
			${IWPRIV} ra0 set WscConfMode=0
		fi

		if [ "${ifname}" = "ra0" ]; then
			/etc/rc.d/wscd.sh restart
			/etc/rc.d/mini_upnp.sh restart
		fi
		;;  
		stop)
		${IWPRIV} ra0 set WscConfMode=0
		${IWPRIV} ra1 set WscConfMode=0
		${IWPRIV} ra2 set WscConfMode=0
		${IWPRIV} ra3 set WscConfMode=0
		/etc/rc.d/mini_upnp.sh restart igd_only
		/etc/rc.d/wscd.sh stop
		;;
	esac
}
# Security note:
# $1 = $AuthType
# $2 = $num
# $3 = $WPAPSK_KEY
# $4 = $EncrypType
# $5 = $KeyIndex
# $6 = $K1
# $7 = $K2
# $8 = $K3
# $9 = $K4
Security()
{
        if [ "`${NVRAM} get WIFI_SET_SIGNAL`"  = "1" ]; then
                SSID=`${NVRAM} get WIFISsid1Single`
		elif [ "`${NVRAM} get WIFI_SET_SIGNAL`"  = "2" ]; then
                SSID=`nvram get AOSS_WIFISsid1Single`
		else
                config_num=`${NVRAM} get WIFI_config_num_tmp`
                SSID=`${NVRAM} get WIFISsid${config_num}Multi`
        fi

#	if [ "`${NVRAM} get WIFISecMode`" = 2 ];then
#		config_num=`${NVRAM} get WIFI_config_num_tmp`
#		SSID=`nvram get WIFISsid${config_num}Multi`
#	else
#		SSID=`nvram get WIFISsid1Single`
#	fi
  echo "Security..."
	case "${1}" in
			OPEN)
			${WLAN_SET} secmode set -i ${2} open
			if [ "${4}" = "WEP" ];then
				${IWPRIV} ra${2} set AuthMode=SHARED
				${WLAN_SET} secmode set -i ${2} wep
				if [ "${6}" != "" ];then
					${WLAN_SET} wepkey set -i ${2} -k 1 "${6}"
				fi
				if [ "${7}" != "" ];then
					${WLAN_SET} wepkey set -i ${2} -k 2 "${7}"
				fi
				if [ "${8}" != "" ];then
					${WLAN_SET} wepkey set -i ${2} -k 3 "${8}"
				fi
				if [ "${9}" != "" ];then
					${WLAN_SET} wepkey set -i ${2} -k 4 "${9}"
				fi
				${WLAN_SET} wepkeyindex set -i ${2} ${5}
			else
				${IWPRIV} ra${2} set AuthMode=OPEN
				${IWPRIV} ra${2} set EncrypType=NONE
			fi
			${IWPRIV} ra${2} set IEEE8021X=0
			;;
			WPAPSKWPA2PSK)
                        ${WLAN_SET} secmode set -i ${2} wpapskwpa2psk
                        ${IWPRIV} ra${2} set AuthMode=WPAPSKWPA2PSK
                        ${WLAN_SET} wpaencryption set -i ${2} tkipaes
                        ${IWPRIV} ra${2} set EncrypType=TKIPAES
                        ${IWPRIV} ra${2} set IEEE8021X=0
                        ${IWPRIV} ra${2} set DefaultKeyID=2
                        ${IWPRIV} ra${2} set SSID="$SSID"
                        ${WLAN_SET} pskkey set -i ${2} "${3}"
                        ${IWPRIV} ra${2} set WPAPSK="${3}"
                        ${IWPRIV} ra${2} set DefaultKeyID=2
                        ${IWPRIV} ra${2} set SSID="$SSID"
			;;  
			WPAPSK|WPA2PSK)
			if [ "${1}" = "WPAPSK" ];then
	    		${WLAN_SET} secmode set -i ${2} wpapsk
	    		${IWPRIV} ra${2} set AuthMode=WPAPSK
	    	else
	    		${WLAN_SET} secmode set -i ${2} wpa2psk
	    		${IWPRIV} ra${2} set AuthMode=WPA2PSK
	    	fi
	    	if [ "${4}" = "TKIP" ];then
				${WLAN_SET} wpaencryption set -i ${2} tkip
				${IWPRIV} ra${2} set EncrypType=TKIP
	    	else
	    		${WLAN_SET} wpaencryption set -i ${2} aes
	    		${IWPRIV} ra${2} set EncrypType=AES
	    	fi
	    	${IWPRIV} ra${2} set IEEE8021X=0
	    	${IWPRIV} ra${2} set DefaultKeyID=2
	    	${IWPRIV} ra${2} set SSID="$SSID"
			${WLAN_SET} pskkey set -i ${2} "${3}"
			${IWPRIV} ra${2} set WPAPSK="${3}"
	    	${IWPRIV} ra${2} set DefaultKeyID=2
	    	${IWPRIV} ra${2} set SSID="$SSID"
			;;
			WPAPS)
			Wps start
			;;
		esac
}
AOSS_Basic_setting_single_SSID()
{
	SSID=`${NVRAM} get AOSS_WIFISsid1Single`
	CH=`${NVRAM} get WIFIChannel`
	BW=`${NVRAM} get WIFIHTBW`

	if [ "${SSID}" = "" ];then
		#MSSID=`${NVRAM} get lan_hwaddr|cut -c1-2,4-5,7-8,10-11,13-14,16-17`
		MSSID=`${NVRAM} get lan_hwaddr|cut -c10-11,13-14,16-17`
		${NVRAM} set AOSS_WIFISsid1Single=${SSID_PREFIX}${MSSID}
		SSID=`${NVRAM} get AOSS_WIFISsid1Single`
		if [ "${BOARD_INOF_REGION}" = "EU" ]; then
			${NVRAM} set AOSS_WIFISsid1Multi=${SSID_PREFIX}${MSSID}
		fi
	fi
	${ECHO} "Start AOSS static SSID1 setting..." >> ${DEBUG_LOG}
	EncrypType=`${NVRAM} get AOSS_WIFIEncrypType1Single`
	AuthType=`${NVRAM} get AOSS_WIFIAuthType1Single`
	KeyType=`${NVRAM} get AOSS_WIFIWEPKey1TypeSingle`
	KeyIndex=`${NVRAM} get AOSS_WIFIWEPKeyIndex1Single`
	TYPE_WEP="`${NVRAM} get AOSS_WIFIWEPKey1TypeSingle`"
	if [ "${TYPE_WEP}" = "A5" -o "${TYPE_WEP}" = "A13" ];then
		tmp_key="`${NVRAM} get AOSS_WIFIWEPKey1_S1Single`"
		K1=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		tmp_key="`${NVRAM} get AOSS_WIFIWEPKey2_S1Single`"
		K2=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		tmp_key="`${NVRAM} get AOSS_WIFIWEPKey3_S1Single`"
		K3=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		tmp_key="`${NVRAM} get AOSS_WIFIWEPKey4_S1Single`"
		K4=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		${ECHO} "Signal wep key" >>/tmp/aaron_wep_key
		${ECHO} ${K1} >>/tmp/aaron_wep_key
		${ECHO} ${K2} >>/tmp/aaron_wep_key
		${ECHO} ${K3} >>/tmp/aaron_wep_key
		${ECHO} ${K4} >>/tmp/aaron_wep_key
	else
		K1="`${NVRAM} get AOSS_WIFIWEPKey1_S1Single`"
		K2="`${NVRAM} get AOSS_WIFIWEPKey2_S1Single`"
		K3="`${NVRAM} get AOSS_WIFIWEPKey3_S1Single`"
		K4="`${NVRAM} get AOSS_WIFIWEPKey4_S1Single`"
	fi
	if [ "x${K1}" = "x" ];then
		K1="X"
	fi
	if [ "x${K2}" = "x" ];then
		K2="X"
	fi
	if [ "x${K3}" = "x" ];then
		K3="X"
	fi
	if [ "x${K4}" = "x" ];then
		K4="X"
	fi
	WPAPSK_KEY=`${NVRAM} get AOSS_WIFIWPAPSK1Single`
	if [ "`${NVRAM} get WIFIAOSSAction`" = "1" ];then
		Hide=0
	else
		Hide=`${NVRAM} get WIFIHideSSID1`
	fi
		
	RekeyInterval=`${NVRAM} get AOSS_WIFIRekeyIntervalSingle`
	SeparateFeature=`${NVRAM} get AOSS_WIFIGuestPort1Single`
			
	if [ "$WPAPSK_KEY" = "" ];then
		WPAPSK_KEY="NULL"
	fi
	Security ${AuthType} $1 "${WPAPSK_KEY}" ${EncrypType} ${KeyIndex} ${K1} ${K2} ${K3} ${K4}
	${IWPRIV}  ra$1 set SSID="$SSID"

	${IWPRIV} ${WLAN_IF} set RekeyMethod=TIME
	${IWPRIV} ${WLAN_IF} set RekeyInterval=$((${RekeyInterval}*60))
		
	if [ "$Hide" = "1" ];then
		${WLAN_SET} hide set -i $1 enable
	else
		${WLAN_SET} hide set -i $1 disable
	fi

	${IWPRIV} ra$1 set CountryRegion=0	
   if [ "$CH" != "0" -a "x`${NVRAM} get RESET_CHNNEL`" = "x" ];then
      ${IWPRIV} ra$1 set Channel=${CH}
   fi
	${IWPRIV} ra$1 set HtHtc=1 #Enable

	if [ "$BW" = "1" ];then # HT20/HT40
		${IWPRIV} ra$1 set HtBw=1
		if [ "${CH}" -le "4" ]; then
			${IWPRIV} ra$1 set HtExtcha=1
		elif [ "${CH}" -ge "5" ] && [ "${CH}" -le "7" ]; then
			${IWPRIV} ra$1 set HtExtcha=${ExCH}
		elif [ "${CH}" -ge "8" ];then
			${IWPRIV} ra$1 set HtExtcha=0
		fi
		${IWPRIV} ra$1 set HtGi=1 #400ns
	else # HT20
		${IWPRIV} ra$1 set HtBw=0
		${IWPRIV} ra$1 set HtGi=0 #800ns
	fi
	${IWPRIV}  ra$1 set SSID="$SSID"


	if [ "`${NVRAM} get AOSS_ERROR_STATUS`" != "1" ];then
	if [ "$AuthType" = "OPEN" ] && [ "$EncrypType" = "NONE" ];then
		if [ "${LED_CHECK}" != "1" ];then
		ledcontrol -n security -s off
		fi
	else
		LED_CHECK=1
		ledcontrol -n security -s on
	fi
	fi
	${WLAN_SET} up -i ${1}
	WMM $1
	BRIDGE addif ra$1
}

Basic_setting_single_SSID()
{
	SSID=`${NVRAM} get WIFISsid1Single`
   CH=`${NVRAM} get WIFIChannel`
   BW=`${NVRAM} get WIFIHTBW`

	if [ "${SSID}" = "" ];then
		#MSSID=`${NVRAM} get lan_hwaddr|cut -c1-2,4-5,7-8,10-11,13-14,16-17`
		MSSID=`${NVRAM} get lan_hwaddr|cut -c10-11,13-14,16-17`
		${NVRAM} set WIFISsid1Single=${SSID_PREFIX}${MSSID}
		SSID=`${NVRAM} get WIFISsid1Single`
		if [ "${BOARD_INOF_REGION}" = "EU" ]; then
			${NVRAM} set WIFISsid1Multi=${SSID_PREFIX}${MSSID}
		fi
	fi
	${ECHO} "Start static SSID1 setting..." >> ${DEBUG_LOG}
	EncrypType=`${NVRAM} get WIFIEncrypType1Single`
	AuthType=`${NVRAM} get WIFIAuthType1Single`
	KeyType=`${NVRAM} get WIFIWEPKey1TypeSingle`
	KeyIndex=`${NVRAM} get WIFIWEPKeyIndex1Single`
	TYPE_WEP="`${NVRAM} get WIFIWEPKey1TypeSingle`"
	if [ "${TYPE_WEP}" = "A5" -o "${TYPE_WEP}" = "A13" ];then
		tmp_key="`${NVRAM} get WIFIWEPKey1_S1Single`"
		K1=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		tmp_key="`${NVRAM} get WIFIWEPKey2_S1Single`"
		K2=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		tmp_key="`${NVRAM} get WIFIWEPKey3_S1Single`"
		K3=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		tmp_key="`${NVRAM} get WIFIWEPKey4_S1Single`"
		K4=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		${ECHO} "Signal wep key" >>/tmp/aaron_wep_key
		${ECHO} ${K1} >>/tmp/aaron_wep_key
		${ECHO} ${K2} >>/tmp/aaron_wep_key
		${ECHO} ${K3} >>/tmp/aaron_wep_key
		${ECHO} ${K4} >>/tmp/aaron_wep_key
	else
		K1="`${NVRAM} get WIFIWEPKey1_S1Single`"
		K2="`${NVRAM} get WIFIWEPKey2_S1Single`"
		K3="`${NVRAM} get WIFIWEPKey3_S1Single`"
		K4="`${NVRAM} get WIFIWEPKey4_S1Single`"
	fi
	if [ "x${K1}" = "x" ];then
		K1="X"
	fi
	if [ "x${K2}" = "x" ];then
		K2="X"
	fi
	if [ "x${K3}" = "x" ];then
		K3="X"
	fi
	if [ "x${K4}" = "x" ];then
		K4="X"
	fi
	WPAPSK_KEY=`${NVRAM} get WIFIWPAPSK1Single`
	if [ "`${NVRAM} get WIFIAOSSAction`" = "1" ];then
		Hide=0
	else
		Hide=`${NVRAM} get WIFIHideSSID1`
	fi
		
	RekeyInterval=`${NVRAM} get WIFIRekeyIntervalSingle`
	SeparateFeature=`${NVRAM} get WIFIGuestPort1Single`
			
	if [ "$WPAPSK_KEY" = "" ];then
		WPAPSK_KEY="NULL"
	fi
	#${WLAN_SET} up -i $1
	#${IWPRIV} ra${1} set AccessPolicy=1
	#${WLAN_SET} ssid set -i 0 "${SSID}"
	Security ${AuthType} $1 "${WPAPSK_KEY}" ${EncrypType} ${KeyIndex} ${K1} ${K2} ${K3} ${K4}
	#${WLAN_SET} up -i 0
	#${WLAN_SET} ssid set -i $1 "${SSID}"
	${IWPRIV}  ra$1 set SSID="$SSID"

	${IWPRIV} ${WLAN_IF} set RekeyMethod=TIME
	${IWPRIV} ${WLAN_IF} set RekeyInterval=$((${RekeyInterval}*60))
		
	if [ "$Hide" = "1" ];then
		${WLAN_SET} hide set -i $1 enable
	else
		${WLAN_SET} hide set -i $1 disable
	fi

	${IWPRIV} ra$1 set CountryRegion=0	
   if [ "$CH" != "0" -a "x`${NVRAM} get RESET_CHNNEL`" = "x" ];then
      ${IWPRIV} ra$1 set Channel=${CH}
   #else
   #${IWPRIV} ra$1 set Channel="`cat /proc/DNI_wireless_autochannel |grep 1|cut -d " " -f 2`"
   fi
	${IWPRIV} ra$1 set HtHtc=1 #Enable

	if [ "$BW" = "1" ];then # HT20/HT40
		${IWPRIV} ra$1 set HtBw=1
		if [ "${CH}" -le "4" ]; then
			${IWPRIV} ra$1 set HtExtcha=1
		elif [ "${CH}" -ge "5" ] && [ "${CH}" -le "7" ]; then
			${IWPRIV} ra$1 set HtExtcha=${ExCH}
		elif [ "${CH}" -ge "8" ];then
			${IWPRIV} ra$1 set HtExtcha=0
		fi
		${IWPRIV} ra$1 set HtGi=1 #400ns
	else # HT20
		${IWPRIV} ra$1 set HtBw=0
		${IWPRIV} ra$1 set HtGi=0 #800ns
	fi
	${IWPRIV}  ra$1 set SSID="$SSID"


	if [ "`${NVRAM} get AOSS_ERROR_STATUS`" != "1" ];then
	if [ "$AuthType" = "OPEN" ] && [ "$EncrypType" = "NONE" ];then
		if [ "${LED_CHECK}" != "1" ];then
		ledcontrol -n security -s off
		fi
	else
		LED_CHECK=1
		ledcontrol -n security -s on
	fi
	fi
	${WLAN_SET} up -i ${1}
	WMM $1
	BRIDGE addif ra$1
}

byInterfaceBasicSetting()
{
	#interface numbered
	if_num=${1}
	#config numbered
	num=${2}
	
	SSID=`${NVRAM} get WIFISsid${num}Multi`
	EncrypType=`${NVRAM} get WIFIEncrypType${num}Multi`
	AuthType=`${NVRAM} get WIFIAuthType${num}Multi`
	KeyIndex=`${NVRAM} get WIFIWEPKeyIndex${num}Multi`
	TYPE_WEP="`${NVRAM} get WIFIWEPKey1Type_S${num}Multi`"
	if [ "${TYPE_WEP}" = "A5" -o "${TYPE_WEP}" = "A13" ];then
		tmp_key="`${NVRAM} get WIFIWEPKey1_S${num}Multi`"
		K1=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		tmp_key="`${NVRAM} get WIFIWEPKey2_S${num}Multi`"
		K2=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		tmp_key="`${NVRAM} get WIFIWEPKey3_S${num}Multi`"
		K3=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		tmp_key="`${NVRAM} get WIFIWEPKey4_S${num}Multi`"
		K4=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
		${ECHO} "multi-if ${num} wep key" >>/tmp/aaron_wep_key
		${ECHO} ${K1} >>/tmp/aaron_wep_key
		${ECHO} ${K2} >>/tmp/aaron_wep_key
		${ECHO} ${K3} >>/tmp/aaron_wep_key
		${ECHO} ${K4} >>/tmp/aaron_wep_key
	else
		K1="`${NVRAM} get WIFIWEPKey1_S${num}Multi`"
		K2="`${NVRAM} get WIFIWEPKey2_S${num}Multi`"
		K3="`${NVRAM} get WIFIWEPKey3_S${num}Multi`"
		K4="`${NVRAM} get WIFIWEPKey4_S${num}Multi`"
	fi
	if [ "x${K1}" = "x" ];then
		K1="X"
	fi
	if [ "x${K2}" = "x" ];then
		K2="X"
	fi
	if [ "x${K3}" = "x" ];then
		K3="X"
	fi
	if [ "x${K4}" = "x" ];then
		K4="X"
	fi
	WPAPSK_KEY=`${NVRAM} get WIFIWPAPSK${num}Multi`

	if [ "`${NVRAM} get WIFIAOSSAction`" = "1" ];then
		Hide=0
	else
		Hide=`${NVRAM} get WIFIHideSSID1`
	fi

	RekeyInterval=`${NVRAM} get WIFIRekeyIntervalSingle`
	

	${ECHO} "INIT down & up :ra${if_num}" >> ${DEBUG_LOG}
	if [ "${SSID}" = "" ];then
		MSSID=`${NVRAM} get lan_hwaddr|cut -c10-11,13-14,16-17`-${num}
		${NVRAM} set WIFISsid${num}Multi=${SSID_PREFIX}${MSSID}
		SSID=`nvram get WIFISsid${num}Multi`
	fi

	if [ "$WPAPSK_KEY" = "" ];then
		WPAPSK_KEY="NULL"
	fi
				
	${NVRAM} set WIFI_config_num_tmp=${num}
	Security ${AuthType} ${if_num} "${WPAPSK_KEY}" ${EncrypType} ${KeyIndex} ${K1} ${K2} ${K3} ${K4}
	${NVRAM} unset WIFI_config_num_tmp
	${WLAN_SET} ssid set -i ${if_num} "$SSID"
		
	${IWPRIV} ra${if_num} set RekeyMethod=TIME
	${IWPRIV} ra${if_num} set RekeyInterval=$((${RekeyInterval}*60))
	
	if [ "$Hide" = "1" ];then
		${WLAN_SET} hide set -i ${if_num} enable
	else
		${WLAN_SET} hide set -i ${if_num} disable
	fi

	WMM ${if_num}
	${BRCTL} addif br0 ra${if_num}
	${IWPRIV} ra${if_num} set CountryRegion=0
	if [ "${CH}" != "0" -a "x`${NVRAM} get RESET_CHNNEL`" = "x" ];then
		${ECHO} "Setting wireless chnnel to ${CH}" >> ${DEBUG_LOG}
		${IWPRIV} ra${if_num} set Channel=${CH}
	#else
	#	${IWPRIV} ra${if_num} set Channel="`cat /proc/DNI_wireless_autochannel |grep 1|cut -d " " -f 2`"
	fi
	${IWPRIV} ra${if_num} set HtHtc=1 #Enable

	if [ "$BW" = "1" ];then # HT20/HT40
		${IWPRIV} ra${if_num} set HtBw=1
		if [ "${CH}" -le "4" ]; then
			${IWPRIV} ra${if_num} set HtExtcha=1
		elif [ "${CH}" -ge "5" ] && [ "${CH}" -le "7" ]; then
			${IWPRIV} ra${if_num} set HtExtcha=${ExCH}
		elif [ "${CH}" -ge "8" ];then
			${IWPRIV} ra${if_num} set HtExtcha=0
		fi
		${IWPRIV} ra${if_num} set HtGi=1 #400ns
	else # HT20
		${IWPRIV} ra${if_num} set HtBw=0
		${IWPRIV} ra${if_num} set HtGi=0 #800ns
	fi
	${IWPRIV} ra${if_num} set SSID="$SSID"
	#if [ "`${NVRAM} get AOSS_ERROR_STATUS`" != "1" ];then
	#	if [ "$AuthType" = "OPEN" ] && [ "$EncrypType" = "NONE" ];then
	#		if [ "${LED_CHECK}" != "1" ];then
	#			ledcontrol -n security -s off
	#		fi
	#	else
	#		ledcontrol -n security -s on
	#		LED_CHECK=1
	#	fi
	#fi
	${IFCONFIG} ra${if_num} up
}
Single_interface_down()
{
	echo "Only enabled ra0 ,disabled other wireless interface."
	${IFCONFIG} ra1 down
	${IFCONFIG} ra2 down
	${IFCONFIG} ra3 down
}
Basic_settings()
{
	
	#echo "Basic...."
	${ECHO} "Start New Wireless Basic setting" > ${DEBUG_LOG}

	# AP/EU WPS profile used only. AP->0, EU->1
	if [ "`${NVRAM} get WIFIRegion`" = "US" ];then
	        echo 0 > /proc/DNI_SKU_TYPE
	else
	        echo 1 > /proc/DNI_SKU_TYPE
	fi

	CH=`${NVRAM} get WIFIChannel`
	BW=`${NVRAM} get WIFIHTBW`
	ExCH=`${NVRAM} get WIFIHTEXTCHA`
		
	Wps stop
	RESTART_AES="`${NVRAM} get RESTART_AES`"
	RESTART_TKIP="`${NVRAM} get RESTART_TKIP`"
	RESTART_WEP="`${NVRAM} get RESTART_WEP`"
	RESTART_FIXED="`${NVRAM} get RESTART_AES`"
	${ECHO} "*****************************" >> ${DEBUG_LOG}
	${ECHO} "RESTART_AES=${RESTART_AES}" >> ${DEBUG_LOG}
	${ECHO} "RESTART_TKIP=${RESTART_TKIP}" >> ${DEBUG_LOG}
	${ECHO} "RESTART_WEP=${RESTART_WEP}" >> ${DEBUG_LOG}
	${ECHO} "RESTART_FIXED=${RESTART_FIXED}" >> ${DEBUG_LOG}

	if [ "`${NVRAM} get WIFISecMode`" = "1" ];then
		#Single-ssid
		${NVRAM} set WIFI_SET_SIGNAL=1
		Basic_setting_single_SSID 0
		${NVRAM} unset WIFI_SET_SIGNAL
		Single_interface_down
	else	
		#Multi-ssid
		num=1
		if_num=0	
		
		#get ra0 type
		while [ ${num} -lt ${MSSID_num} ]
		do
			if [ "`${NVRAM} get WIFISsid${num}EnableMulti`" = "1" ];then
				break
			fi
			num=$((${num}+1))
		done
		manual_if_nb=3
		#setting type
		case ${num} in
		1)
		MAIN_IF_TYPE="TKIP"
		${ECHO} "Get main type : ${MAIN_IF_TYPE}" >> ${DEBUG_LOG}
		# if_number config_numbered
		main_if="`${NVRAM} get MAIN_IF`"
		if [ "${main_if}" != "TKIP" ];then
			${NVRAM} unset RESTART_${main_if}
			${NVRAM} unset RESTART_${MAIN_IF_TYPE}
		fi
		if [ "x`${NVRAM} get RESTART_TKIP`" = "x" ];then
			# parmiter : if_number config_number

			byInterfaceBasicSetting 0 1
			${NVRAM} set MAIN_IF="TKIP"
			#${IFCONFIG} ra0 up
		fi
		if [ "`${NVRAM} get WIFISsid2EnableMulti`" = "1" -a "x`${NVRAM} get RESTART_AES`" = "x" ];then
			byInterfaceBasicSetting 1 2
			#${IFCONFIG} ra1 up
		elif [ "x`${NVRAM} get RESTART_AES`" = "x" ];then
			${IFCONFIG} ra1 down>/dev/null
		fi
		
		if [ "`${NVRAM} get WIFISsid3EnableMulti`" = "1" -a "x`${NVRAM} get RESTART_WEP`" = "x" ];then
			byInterfaceBasicSetting 2 3
		#	${IFCONFIG} ra2 up
		elif [ "x`${NVRAM} get RESTART_WEP`" = "x" ];then
			${IFCONFIG} ra2 down>/dev/null
		fi
		;;
		2)
		MAIN_IF_TYPE="AES"
		${ECHO} "Get main type : ${MAIN_IF_TYPE}" >> ${DEBUG_LOG}
		# if_number config_numbered
		main_if="`${NVRAM} get MAIN_IF`"
		if [ "${main_if}" != "AES" ];then
			${NVRAM} unset RESTART_${main_if}
			${NVRAM} unset RESTART_${MAIN_IF_TYPE}
		fi
		if [ "x`${NVRAM} get RESTART_AES`" = "x" ];then
			${NVRAM} set MAIN_IF="AES"
			byInterfaceBasicSetting 0 2
			#${IFCONFIG} ra0 up
		fi
		if [ "`${NVRAM} get WIFISsid1EnableMulti`" = "1" -a "x`${NVRAM} get RESTART_TKIP`" = "x" ];then
			byInterfaceBasicSetting 1 1
			#${IFCONFIG} ra1 up
		elif [ "x`${NVRAM} get RESTART_TKIP`" = "x" ];then
			${IFCONFIG} ra1 down>/dev/null
		fi
		if [ "`${NVRAM} get WIFISsid3EnableMulti`" = "1" -a "x`${NVRAM} get RESTART_WEP`" = "x" ];then
			byInterfaceBasicSetting 2 3
			#${IFCONFIG} ra2 up
		elif [ "x`${NVRAM} get RESTART_WEP`" = "x" ];then
			${IFCONFIG} ra2 down>/dev/null
		fi
		;;
		3)
		MAIN_IF_TYPE="WEP"
		
		${ECHO} "Get main type : ${MAIN_IF_TYPE}" >> ${DEBUG_LOG}
		# if_number config_numbered
		main_if="`${NVRAM} get MAIN_IF`"
		if [ "${main_if}" != "WEP" ];then
			if [ "${main_if}" = "AES" ];then
				aes_num=0
			fi
			${NVRAM} unset RESTART_${main_if}
			${NVRAM} unset RESTART_${MAIN_IF_TYPE}

		fi
		if [ "x`${NVRAM} get RESTART_WEP`" = "x" ];then
			${NVRAM} set MAIN_IF="WEP"
			byInterfaceBasicSetting 0 3
			#${IFCONFIG} ra0 up
		fi
		if [ "`${NVRAM} get WIFISsid2EnableMulti`" = "1" -a "x`${NVRAM} get RESTART_AES`" = "x" ];then
			byInterfaceBasicSetting 1 2
			#${IFCONFIG} ra1 up
		elif [ "x`${NVRAM} get RESTART_AES`" = "x" ];then
			if [ "${aes_num}" = "0" ];then
				${IFCONFIG} ra2 down>/dev/null
			else
				${IFCONFIG} ra1 down>/dev/null
			fi
		fi
		if [ "`${NVRAM} get WIFISsid1EnableMulti`" = "1" -a "x`${NVRAM} get RESTART_TKIP`" = "x" ];then
			byInterfaceBasicSetting 2 1
			#${IFCONFIG} ra2 up
		elif [ "x`${NVRAM} get RESTART_TKIP`" = "x" ];then
			${IFCONFIG} ra2 down>/dev/null
		fi
		;;
  		*)
			MAIN_IF_TYPE="NONE"
			${ECHO} "Get main type : ${MAIN_IF_TYPE}" >> ${DEBUG_LOG}
			manual_if_nb=0
			${NVRAM} unset RESTART_FIXED
			${IFCONFIG} ra1 down>/dev/null
			${IFCONFIG} ra2 down>/dev/null
			${IFCONFIG} ra3 down>/dev/null
			;;
		esac
		
		
		if [ "`${NVRAM} get WIFISsid1Enable`" = "1" -a "x`${NVRAM} get RESTART_FIXED`" = "x" ];then
			${ECHO} "INIT manual ${manual_if_nb}" >> ${DEBUG_LOG}
			#${WLAN_SET} down -i ${manual_if_nb} >/dev/null
			${NVRAM} set WIFI_SET_SIGNAL=1
			main_if="`${NVRAM} get MAIN_IF`"
			
			if [ "${main_if}" != "FIXED" -a "${manual_if_nb}" = "0" ];then
				${NVRAM} unset RESTART_${main_if}
				${WLAN_SET} down -i 3 >/dev/null
			fi
			if [ "${manual_if_nb}" = "0" ];then
				${NVRAM} set MAIN_IF="FIXED"
			fi
			Basic_setting_single_SSID ${manual_if_nb}
			${IFCONFIG} ra${manual_if_nb} up
			${NVRAM} unset WIFI_SET_SIGNAL
		elif [ "x`${NVRAM} get RESTART_FIXED`" = "x" ];then
			${WLAN_SET} down -i ${manual_if_nb} >/dev/null
		fi
	fi
	if [ "`${NVRAM} get AOSS_ERROR_STATUS`" != "1" ];then
		security_led_check
	fi
	Wps start
}

#	else
#		SSID=`${NVRAM} get WIFISsid1Single`
#		if [ "${SSID}" = "" ];then
#			MSSID=`${NVRAM} get lan_hwaddr|cut -c1-2,4-5,7-8,10-11,13-14,16-17`
#			${NVRAM} set WIFISsid1Single=${SSID_PREFIX}${MSSID}
#			SSID=`${NVRAM} get WIFISsid1Single`
#		fi
#		EncrypType=`${NVRAM} get WIFIEncrypType1Single`
#		AuthType=`${NVRAM} get WIFIAuthType1Single`
#		KeyType=`${NVRAM} get WIFIWEPKey1TypeSingle`
#		KeyIndex=`${NVRAM} get WIFIWEPKeyIndex1Single`
#		K1=`${NVRAM} get WIFIWEPKey1_S1Single`
#		K2=`${NVRAM} get WIFIWEPKey2_S1Single`
#		K3=`${NVRAM} get WIFIWEPKey3_S1Single`
#		K4=`${NVRAM} get WIFIWEPKey4_S1Single`
#			
#		WPAPSK_KEY=`${NVRAM} get WIFIWPAPSK1Single`
#		
#		Hide=`${NVRAM} get WIFIHideSSID1`
#			
#		RekeyInterval=`${NVRAM} get WIFIRekeyIntervalSingle`
#		SeparateFeature=`${NVRAM} get WIFIGuestPort1Single`
#			
#		if [ "$WPAPSK_KEY" = "" ];then
#			WPAPSK_KEY="NULL"
#		fi
#		${WLAN_SET} up -i 0
#		#${WLAN_SET} ssid set -i 0 "$SSID"
#		Security ${AuthType} 0 ${WPAPSK_KEY} ${EncrypType} ${KeyIndex} ${K1} ${K2} ${K3} ${K4}
#		#${WLAN_SET} up -i 0
#		${WLAN_SET} ssid set -i 0 "$SSID"
#
#		${IWPRIV} ${WLAN_IF} set RekeyMethod=TIME
#		${IWPRIV} ${WLAN_IF} set RekeyInterval=$((${RekeyInterval}*60))
#			
#		if [ "$Hide" = "1" ];then
#			${WLAN_SET} hide set -i 0 enable
#		else
#			${WLAN_SET} hide set -i 0 disable
#		fi
#
#		${IWPRIV} ra0 set CountryRegion=0	
#		${IWPRIV} ra0 set Channel=${CH}
#		${IWPRIV} ra0 set HtHtc=1 #Enable
#
#		if [ "$BW" = "1" ];then # HT20/HT40
#			${IWPRIV} ra0 set HtBw=1
#			if [ "${CH}" -le "4" ]; then
#				${IWPRIV} ra0 set HtExtcha=1
#			elif [ "${CH}" -ge "5" ] && [ "${CH}" -le "7" ]; then
#				${IWPRIV} ra0 set HtExtcha=${ExCH}
#			elif [ "${CH}" -ge "8" ];then
#				${IWPRIV} ra0 set HtExtcha=0
#			fi
#			${IWPRIV} ra0 set HtGi=1 #400ns
#		else # HT20
#			${IWPRIV} ra0 set HtBw=0
#			${IWPRIV} ra0 set HtGi=0 #800ns
#		fi
#		${IWPRIV}  ra0 set SSID="$SSID"
#
#		if [ "$AuthType" = "OPEN" ] && [ "$EncrypType" = "NONE" ];then
#			ledcontrol -n security -s off
#		else
#			ledcontrol -n security -s on
#		fi
#		WMM 0
#		BRIDGE addif ra0

Adv_settings()
{
	TX_BUEST=`${NVRAM} get WIFITxBurst`
	TX_POWER=`${NVRAM} get WIFITxPower`
	DTIM=`${NVRAM} get WIFIDtimPeriod`
	BASE_RATE=`${NVRAM} get WIFIBasicRate`
	HTRDG=`${NVRAM} get WIFIHTRDG`
	NoForwardingBTNBSSID=`${NVRAM} get WIFINoForwardingBTNBSSID`
	MultiRate=`${NVRAM} get WIFIMultiRate`

	case "${MultiRate}" in
		1)
			MPhyMode=1
			MMcs=0
			;;
		2)
			MPhyMode=1
			MMcs=1
			;;
		5.5)
			MPhyMode=1
			MMcs=2
			;;
		6)
			MPhyMode=2
			MMcs=0
			;;
		9)
			MPhyMode=2
			MMcs=1
			;;
		11)
			MPhyMode=1
			MMcs=3
			;;
		12)
			MPhyMode=2
			MMcs=2
			;;
		18)
			MPhyMode=2
			MMcs=3
			;;
		24)
			MPhyMode=2
			MMcs=4
			;;
		36)
			MPhyMode=2
			MMcs=5
			;;
		48)
			MPhyMode=2
			MMcs=6
			;;
		54)
			MPhyMode=2
			MMcs=7
			;;
	esac

	${IWPRIV} ra0 set McastPhyMode=${MPhyMode}
	${IWPRIV} ra1 set McastPhyMode=${MPhyMode}
	${IWPRIV} ra2 set McastPhyMode=${MPhyMode}
	${IWPRIV} ra3 set McastPhyMode=${MPhyMode}

	${IWPRIV} ra0 set McastMcs=${MMcs}
	${IWPRIV} ra1 set McastMcs=${MMcs}
	${IWPRIV} ra2 set McastMcs=${MMcs}
	${IWPRIV} ra3 set McastMcs=${MMcs}
	
	# RT3390 only support 1T1R
	#${IWPRIV} ra0 set HtTxStream=1
	#${IWPRIV} ra1 set HtTxStream=1
	#${IWPRIV} ra2 set HtTxStream=1
	#${IWPRIV} ra3 set HtTxStream=1
	#${IWPRIV} ra0 set HtRxStream=1 
	#${IWPRIV} ra1 set HtRxStream=1 
	#${IWPRIV} ra2 set HtRxStream=1 
	#${IWPRIV} ra3 set HtRxStream=1 

	# Buffalo not define rates, so hardcode auto mode here
	# deleted by lucas for HT20/40 Coexistence, move to profile
	#${IWPRIV} ra0 set HtMcs=33
	#${IWPRIV} ra1 set HtMcs=33
	#${IWPRIV} ra2 set HtMcs=33
	#${IWPRIV} ra3 set HtMcs=33

	${IWPRIV} ra0 set BasicRate=${BASE_RATE}
	${IWPRIV} ra1 set BasicRate=${BASE_RATE}
	${IWPRIV} ra2 set BasicRate=${BASE_RATE}
	${IWPRIV} ra3 set BasicRate=${BASE_RATE}

	${WLAN_SET} txburst set ${TX_BUEST}
	${IWPRIV} ra0 set TxBurst=${TX_BUEST}
	${IWPRIV} ra1 set TxBurst=${TX_BUEST}
	${IWPRIV} ra2 set TxBurst=${TX_BUEST}
	${IWPRIV} ra3 set TxBurst=${TX_BUEST}
	
	${WLAN_SET} txpwr set -p ${TX_POWER}
	${IWPRIV} ra0 set TxPower=${TX_POWER}
	${IWPRIV} ra1 set TxPower=${TX_POWER}
	${IWPRIV} ra2 set TxPower=${TX_POWER}
	${IWPRIV} ra3 set TxPower=${TX_POWER}
	
	${WLAN_SET} dtim set ${DTIM}
	${IWPRIV} ra0 set DtimPeriod=${DTIM}
	${IWPRIV} ra1 set DtimPeriod=${DTIM}
	${IWPRIV} ra2 set DtimPeriod=${DTIM}
	${IWPRIV} ra3 set DtimPeriod=${DTIM}
	
	# deleted by lucas for HT20/40 Coexistence, move to profile
	#${IWPRIV} ra0 set HtRdg=${HTRDG}
	#${IWPRIV} ra1 set HtRdg=${HTRDG}
	#${IWPRIV} ra2 set HtRdg=${HTRDG}
	#${IWPRIV} ra3 set HtRdg=${HTRDG}
	
	${IWPRIV} ra0 set NoForwarding=${NoForwardingBTNBSSID}
	${IWPRIV} ra1 set NoForwarding=${NoForwardingBTNBSSID}
	
	${IWPRIV} ra3 set NoForwarding=${NoForwardingBTNBSSID}
	${IWPRIV} ra0 set NoForwardingBTNBSSID=${NoForwardingBTNBSSID}
	${IWPRIV} ra1 set NoForwardingBTNBSSID=${NoForwardingBTNBSSID}
	${IWPRIV} ra3 set NoForwardingBTNBSSID=${NoForwardingBTNBSSID}
	if [ "`${NVRAM} get WIFIAOSSAction`" != "1" ];then
		${IWPRIV} ra2 set NoForwarding=${NoForwardingBTNBSSID}
		${IWPRIV} ra2 set NoForwardingBTNBSSID=${NoForwardingBTNBSSID}
	fi
	
}

macFilter()
{
	${IWPRIV} ra0 set ACLClearAll=1
	${IWPRIV} ra1 set ACLClearAll=1
	${IWPRIV} ra2 set ACLClearAll=1
	${IWPRIV} ra3 set ACLClearAll=1
	${IWPRIV} ra0 set AccessPolicy=0
	${IWPRIV} ra1 set AccessPolicy=0
	${IWPRIV} ra2 set AccessPolicy=0
	${IWPRIV} ra3 set AccessPolicy=0
	if [ "`${NVRAM} get WIFIMACFilterEnable`" = "1" ]; then
		MAC_LIST=`${NVRAM} get WIFI_FILTER_MACTAB`
		${IWPRIV} ra0 set AccessPolicy=1
		${IWPRIV} ra1 set AccessPolicy=1
		${IWPRIV} ra2 set AccessPolicy=1
		${IWPRIV} ra3 set AccessPolicy=1
		${IWPRIV} ra0 set ACLAddEntry=${MAC_LIST}
		${IWPRIV} ra1 set ACLAddEntry=${MAC_LIST}
		${IWPRIV} ra2 set ACLAddEntry=${MAC_LIST}
		${IWPRIV} ra3 set ACLAddEntry=${MAC_LIST}
	fi
}


# aoss Security note:
# $1 = $AuthType
# $2 = $num
# $3 = $WPAPSK_KEY
# $4 = $EncrypType
# $5 = $KeyIndex
# $6 = $K1
# $7 = $K2
# $8 = $K3
# $9 = $K4
aoss_Security()
{
	config_num=`${NVRAM} get WIFI_config_num_tmp`
	SSID="`nvram get WIFI_config_ssid_tmp`"

  echo "AOSS Security Start !!!!"

	case "${1}" in
		OPEN)
			if [ "${4}" = "WEP" ];then
				${IWPRIV} ra${2} set AuthMode=SHARED
				${WLAN_SET} secmode set -i ${2} wep
				#${IWPRIV}  ra${2} set AuthMode=WEPAUTO 
				#${IWPRIV} ra${2} set EncrypType=WEP 
				if [ "${6}" != "" ];then
					${WLAN_SET} wepkey set -i ${2} -k 1 ${6}
				fi
				if [ "${7}" != "" ];then
					${WLAN_SET} wepkey set -i ${2} -k 2 ${7}
				fi
				if [ "${8}" != "" ];then
					${WLAN_SET} wepkey set -i ${2} -k 3 ${8}
				fi
				if [ "${9}" != "" ];then
					${WLAN_SET} wepkey set -i ${2} -k 4 ${9}
				fi
				${WLAN_SET} wepkeyindex set -i ${2} $((${5}+1))
			else
				${WLAN_SET} secmode set -i ${2} open
			fi
			${IWPRIV} ra${2} set IEEE8021X=0
			;;
		WPAPSKWPA2PSK)
                        ${WLAN_SET} secmode set -i ${2} wpapskwpa2psk
                        ${IWPRIV} ra${2} set AuthMode=WPAPSKWPA2PSK
                        ${WLAN_SET} wpaencryption set -i ${2} tkipaes
                        ${IWPRIV} ra${2} set EncrypType=TKIPAES
                        ${IWPRIV} ra${2} set IEEE8021X=0
                        ${IWPRIV} ra${2} set DefaultKeyID=2
                        ${IWPRIV} ra${2} set SSID="$SSID"
                        ${WLAN_SET} pskkey set -i ${2} "${3}"
                        ${IWPRIV} ra${2} set WPAPSK="${3}"
                        ${IWPRIV} ra${2} set DefaultKeyID=2
                        ${IWPRIV} ra${2} set SSID="$SSID"
			;;  
		WPAPSK|WPA2PSK)
		if [ "${1}" = "WPAPSK" ];then
	    	${WLAN_SET} secmode set -i ${2} wpapsk
	    	${IWPRIV} ra${2} set AuthMode=WPAPSK
	    	else
	    		${WLAN_SET} secmode set -i ${2} wpa2psk
	    		${IWPRIV} ra${2} set AuthMode=WPA2PSK
	    	fi
	    	if [ "${4}" = "TKIP" ];then
				${WLAN_SET} wpaencryption set -i ${2} tkip
				${IWPRIV} ra${2} set EncrypType=TKIP
	    	else
	    		${WLAN_SET} wpaencryption set -i ${2} aes
	    		${IWPRIV} ra${2} set EncrypType=AES
	    	fi
	    	${IWPRIV} ra${2} set IEEE8021X=0
	    	${IWPRIV} ra${2} set DefaultKeyID=2
	    	${IWPRIV} ra${2} set SSID="$SSID"
			${WLAN_SET} pskkey set -i ${2} ${3}
			${IWPRIV} ra${2} set WPAPSK=${3}
			;;
		esac
}

aoss_basic_settings()
{
#RESTART_TKIP
#RESTART_AES
#RESTART_WEP
#RESTART_FIXED
    #echo " Aoss Basic...."
	CH=`nvram get WIFIChannel`
	BW=`${NVRAM} get WIFIHTBW`
	ExCH=`${NVRAM} get WIFIHTEXTCHA`
	num=0;
	MSSID_num=4
	
	if [ "`${NVRAM} get WIFIAOSSAction`" != "1" ];then
		exit 0
	fi
	
	Wps stop
	num=1;
	if_num=0
	${ECHO} "Start AOSS basic setting" > ${DEBUG_LOG}
	#TKIP_IF="`${NVRAM} get AOSS_TKIP_IF`"
  	#AES_IF="`${NVRAM} get AOSS_AES_IF`"
  	#WEP_IF="`${NVRAM} get AOSS_WEP_IF`"
	TKIP_IF=1
  	AES_IF=2
  	WEP_IF=3
  	${NVRAM} set AOSS_TKIP_IF=2
  	${NVRAM} set AOSS_AES_IF=1
  	${NVRAM} set AOSS_WEP_IF=3
  	
  	${NVRAM} set WPS_IFNAME=ra0
	while [ ${num} -lt ${MSSID_num} ]
	do
		SSID="NULL"
		EncrypType="NULL"
		AuthType="NULL"
		KeyIndex="1"
		K1="NULL"
		K2="NULL"
		K3="NULL"
		K4="NULL"
		WPAPSK_KEY="NULL"
		ExclusiveSSID="0"
		#WPA-PSK-TKEP
		
		if [ "${num}" = "${TKIP_IF}" -a "x`${NVRAM} get RESTART_TKIP`" = "x" ];then 
			${ECHO} "AOSS ra${if_num} init" >> ${DEBUG_LOG}
			#${WLAN_SET} down -i ${if_num} >/dev/null
			SSID="`${NVRAM} get WIFIAOSSTKIP_11bg_manssid`"
			if [ "`${NVRAM} get WIFIAOSSAdvEncryptionEnable`" = "1" ];then
				AuthType="WPAPSKWPA2PSK"
				EncrypType="TKIP"
			else
				AuthType="WPAPSK"
				EncrypType="TKIP"
			fi
			#${NVRAM} unset RESTART_AES
			WPAPSK_KEY="`${NVRAM} get WIFIAOSSTKIP_11bg_wpapsk`"
		elif [ "${num}" = "${TKIP_IF}" ];then
			${ECHO} "AOSS skip ra${if_num} init" >> ${DEBUG_LOG}
			if_num=$((${if_num}+1))
			num=$((${num}+1))
			continue
		fi
		
		#WPA-PSK-AES
		if [ "${num}" = "${AES_IF}" -a "x`${NVRAM} get RESTART_AES`" = "x" ];then
			#${WLAN_SET} down -i ${if_num} >/dev/null
			${ECHO} "AOSS ra${if_num} init" >> ${DEBUG_LOG}
			SSID="`${NVRAM} get WIFIAOSSAES_11bg_manssid`"
			EncrypType="AES"
			AuthType="WPAPSK"
			WPAPSK_KEY="`${NVRAM} get WIFIAOSSAES_11bg_wpapsk`"
		elif [ "${num}" = "${AES_IF}" ];then
			${ECHO} "AOSS skip ra${if_num} init" >> ${DEBUG_LOG}
			if_num=$((${if_num}+1))
			num=$((${num}+1))
			continue
		fi
		#WEP
		if [ "${num}" = "${WEP_IF}" -a "x`${NVRAM} get RESTART_WEP`" = "x" ];then 
			#${WLAN_SET} down -i ${if_num} >/dev/null
			case "`${NVRAM} get WIFIAOSSEncryptionType`" in 
				"1")
				${ECHO} "AOSS ra${if_num} wep 64 init" >> ${DEBUG_LOG}
				SSID=`${NVRAM} get WIFIAOSSWEP40_11bg_manssid`
				EncrypType="WEP"
				AuthType="OPEN"
				
				K1="`${NVRAM} get WIFIAOSSWEP40_11bg_key0`"
				K2="`${NVRAM} get WIFIAOSSWEP40_11bg_key1`"
				K3="`${NVRAM} get WIFIAOSSWEP40_11bg_key2`"
				K4="`${NVRAM} get WIFIAOSSWEP40_11bg_key3`"
				
				if [ "${#K1}" = "5" ];then
					tmp_key="${K1}"
					K1=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
				fi
				if [ "${#K2}" = "5" ];then
					tmp_key="${K2}"
					K2=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
				fi
				if [ "${#K3}" = "5" ];then
					tmp_key="${K3}"
					K3=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
				fi
				if [ "${#K4}" = "5" ];then
					tmp_key="${K4}"
					K4=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
				fi
				if [ "x${K1}" = "x" ];then
					K1="X"
				fi
				if [ "x${K2}" = "x" ];then
					K2="X"
				fi
				if [ "x${K3}" = "x" ];then
					K3="X"
				fi
				if [ "x${K4}" = "x" ];then
					K4="X"
				fi
				${ECHO} "aoss-if 64 ${num} wep key" >>/tmp/aaron_wep_key
				${ECHO} ${K1} >>/tmp/aaron_wep_key
				${ECHO} ${K2} >>/tmp/aaron_wep_key
				${ECHO} ${K3} >>/tmp/aaron_wep_key
				${ECHO} ${K4} >>/tmp/aaron_wep_key
				
				KeyIndex="`${NVRAM} get WIFIAOSSWEP40_11bg_key_index`"
				echo "WEP 64 mode"
				;; 
				"2")
				${ECHO} "AOSS ra${if_num} wep 128 init" >> ${DEBUG_LOG}
				SSID="`${NVRAM} get WIFIAOSSWEP104_11bg_manssid`"
				EncrypType="WEP"
				AuthType="OPEN"
				K1="`${NVRAM} get WIFIAOSSWEP104_11bg_key0`"
				K2="`${NVRAM} get WIFIAOSSWEP104_11bg_key1`"
				K3="`${NVRAM} get WIFIAOSSWEP104_11bg_key2`"
				K4="`${NVRAM} get WIFIAOSSWEP104_11bg_key3`"
				if [ "${#K1}" = "13" ];then
					tmp_key="${K1}"
					K1=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
				fi
				if [ "${#K2}" = "13" ];then
					tmp_key="${K2}"
					K2=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
				fi
				if [ "${#K3}" = "13" ];then
					tmp_key="${K3}"
					K3=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
				fi
				if [ "${#K4}" = "13" ];then
					tmp_key="${K4}"
					K4=`echo -n "${tmp_key}"|hexdump|head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
				fi
				if [ "x${K1}" = "x" ];then
					K1="X"
				fi
				if [ "x${K2}" = "x" ];then
					K2="X"
				fi
				if [ "x${K3}" = "x" ];then
					K3="X"
				fi
				if [ "x${K4}" = "x" ];then
					K4="X"
				fi
				${ECHO} "aoss-if 128 ${num} wep key" >>/tmp/aaron_wep_key
				${ECHO} ${K1} >>/tmp/aaron_wep_key
				${ECHO} ${K2} >>/tmp/aaron_wep_key
				${ECHO} ${K3} >>/tmp/aaron_wep_key
				${ECHO} ${K4} >>/tmp/aaron_wep_key
				KeyIndex="`${NVRAM} get WIFIAOSSWEP104_11bg_key_index`"
				echo "WEP 128 mode"
				;;
				*)
					${ECHO} "AOSS down ra${if_num}" >> ${DEBUG_LOG}
					${WLAN_SET} down -i ${if_num} >/dev/null
					if_num=$((${if_num}+1))
					num=$((${num}+1))
					continue
					break;
				;;
			esac
		elif [ "${num}" = "${WEP_IF}" ];then
			${ECHO} "AOSS skip ra${if_num} init WEP" >> ${DEBUG_LOG}
			#${WLAN_SET} down -i ${if_num} >/dev/null
			if_num=$((${if_num}+1))
			num=$((${num}+1))
			continue
		fi

		if [ "`${NVRAM} get WIFIAOSSExclusiveSSID`" = "1" ];then
			ExclusiveSSID="1"
		fi
		if [ "`${NVRAM} get WIFIAOSSAction`" = "1" ];then
			Hide=0
		else
			Hide=`${NVRAM} get WIFIHideSSID1`
		fi
		RekeyInterval=`${NVRAM} get WIFIRekeyIntervalSingle`

		
		${NVRAM} set WIFI_config_num_tmp=${num}
		${NVRAM} set WIFI_config_ssid_tmp=${SSID}
		aoss_Security ${AuthType} ${if_num} ${WPAPSK_KEY} ${EncrypType} ${KeyIndex} ${K1} ${K2} ${K3} ${K4}
		${NVRAM} unset WIFI_config_num_tmp
		${NVRAM} unset WIFI_config_ssid_tmp
		${WLAN_SET} ssid set -i ${if_num} "$SSID"

		${IWPRIV} ra${if_num} set RekeyInterval=$((${RekeyInterval}*60))
		if [ "$Hide" = "1" ];then
			${WLAN_SET} hide set -i ${if_num} enable
		else
			${WLAN_SET} hide set -i ${if_num} disable
		fi

		WMM ${if_num}
		${IFCONFIG} ra${if_num} 0.0.0.0
		${BRCTL} addif br0 ra${if_num}
		${EBTABLE_BIN} -F
		if [ "${ExclusiveSSID}" = "1" ];then
			${IWPRIV} ra2 set NoForwarding=1
			${IWPRIV} ra2 set NoForwardingBTNBSSID=1
			
			${EBTABLE_BIN} -A FORWARD -i ra2 -o eth0 -j DROP
			${EBTABLE_BIN} -A FORWARD -i eth0 -o ra2 -j DROP
			${EBTABLE_BIN} -A FORWARD -i ra2 -o ra0 -j DROP
			${EBTABLE_BIN} -A FORWARD -i ra0 -o ra2 -j DROP
			${EBTABLE_BIN} -A FORWARD -i ra2 -o ra1 -j DROP
			${EBTABLE_BIN} -A FORWARD -i ra1 -o ra2 -j DROP
		else
			${IWPRIV} ra2 set NoForwarding=0
			${IWPRIV} ra2 set NoForwardingBTNBSSID=0
		fi
		${IWPRIV} ra${if_num} set CountryRegion=0	
      		if [ "$CH" != "0" -a "x`${NVRAM} get RESET_CHNNEL`" = "x" ];then
      			${ECHO} "Setting wireless chnnel to ${CH}" >> ${DEBUG_LOG}
			${IWPRIV} ra${if_num} set Channel=${CH}
      		#else
      			#${IWPRIV} ra${if_num} set Channel="`cat /proc/DNI_wireless_autochannel |grep 1|cut -d " " -f 2`"
      		fi
		${IWPRIV} ra${if_num} set HtHtc=1 #Enable

		if [ "$BW" = "1" ];then # HT20/HT40
			${IWPRIV} ra${if_num} set HtBw=1
			if [ "${CH}" -le "4" ]; then
				${IWPRIV} ra${if_num} set HtExtcha=1
			elif [ "${CH}" -ge "5" ] && [ "${CH}" -le "7" ]; then
				${IWPRIV} ra${if_num} set HtExtcha=${ExCH}
			elif [ "${CH}" -ge "8" ];then
				${IWPRIV} ra${if_num} set HtExtcha=0
			fi
			${IWPRIV} ra${if_num} set HtGi=1 #400ns
		else # HT20
			${IWPRIV} ra${if_num} set HtBw=0
			${IWPRIV} ra${if_num} set HtGi=0 #800ns
		fi
		${IWPRIV} ra${if_num} set SSID="$SSID"
		${WLAN_SET} up -i ${if_num}
		if_num=$((${if_num}+1))
		num=$((${num}+1))
	done

	if [ "${BOARD_INOF_REGION}" = "AP" ];then
	if [ "`${NVRAM} get AOSS_WIFISsid1Enable`" = "1" -a "x`${NVRAM} get RESTART_FIXED`" = "x" ];then
		${ECHO} "@i@AOSS ra3 init" >> ${DEBUG_LOG}
		${NVRAM} set WIFI_SET_SIGNAL=2
		AOSS_Basic_setting_single_SSID 3
		${NVRAM} unset WIFI_SET_SIGNAL
	elif [ "`${NVRAM} get WIFISsid1Enable`" = "0" ];then
		${ECHO} "AOSS ra3 down" >> ${DEBUG_LOG}
		${WLAN_SET} down -i 3 >/dev/null
	else
		${ECHO} "AOSS sikp ra3 init" >> ${DEBUG_LOG}
	fi
	else
		${ECHO} "EU region : ra3 down" >> ${DEBUG_LOG}
		${WLAN_SET} down -i 3 >/dev/null
	fi
	if [ "`${NVRAM} get AOSS_ERROR_STATUS`" != "1" ];then
		ledcontrol -n security -s on
	fi
	Wps start
}
addFilterAossTables()
{
	if [ "${1}" = "" ];then
		exit
	fi
	while [ -e /tmp/lock_nvram ]
	do
		${ECHO} 0 >/dev/null
	done
	preTables="`${NVRAM} get WIFIAOSS_CLIENT_LIST`"
	${ECHO} 0 > /tmp/lock_nvram
	${NVRAM} set WIFIAOSS_CLIENT_LIST="${preTables} ${2},Aaron,${1},----"
	${RM} /tmp/lock_nvram
}
aoss_macFilter()
{
	${IWPRIV} ra0 set ACLClearAll=1
	${IWPRIV} ra1 set ACLClearAll=1
	${IWPRIV} ra2 set ACLClearAll=1
	${IWPRIV} ra3 set ACLClearAll=1
	${IWPRIV} ra0 set AccessPolicy=0
	${IWPRIV} ra1 set AccessPolicy=0
	${IWPRIV} ra2 set AccessPolicy=0
	${IWPRIV} ra3 set AccessPolicy=0
	CLIENT_LIST=`${NVRAM} get WIFIAOSS_CLIENT_LIST_FILTER`
	${IWPRIV} ra0 set AccessPolicy=2
	${IWPRIV} ra1 set AccessPolicy=2
	${IWPRIV} ra2 set AccessPolicy=2
	${IWPRIV} ra3 set AccessPolicy=2
	MAC_LIST=""
	deny_counter=0
	flg="0"
	if [ "x${CLIENT_LIST}" = "x" ];then
		return
	fi
	for i in ${CLIENT_LIST}
	do

		if [ "`${ECHO} ${i}|cut -d, -f 1`" != "0" ];then
			continue;
		fi
		if [ "${flg}" = "1" ];then
			MAC_LIST="${MAC_LIST};"
		fi
		MAC_LIST="${MAC_LIST}`${ECHO} ${i}|cut -d, -f 2`"
		flg="1"
		deny_counter=$((${deny_counter}+1))
	done
	MAC_LIST="${MAC_LIST};"
	${NVRAM} set AOSS_DENY_COUNT=${deny_counter}
	${NVRAM} commit
	if [ "${MAC_LIST}" != "" ];then
		${IWPRIV} ra0 set ACLAddEntry=${MAC_LIST}
		${IWPRIV} ra1 set ACLAddEntry=${MAC_LIST}
		${IWPRIV} ra2 set ACLAddEntry=${MAC_LIST}
		${IWPRIV} ra3 set ACLAddEntry=${MAC_LIST}
	fi
}
aoss_start()
{
	aoss_basic_settings ${1}
	Adv_settings
	aoss_macFilter
}
ReleaseButton()
{
	${ECHO} 0 > /proc/tc3162/wps_button
	Wps stop
	Wps start
}
SetTimer()
{
	DEF_TOUT=${1:-10};
	if [ "${DEF_TOUT}" -ne "0" ];then
		sleep "${DEF_TOUT}" && kill -s 14 $$ &
		CHPROCIDS="${CHPROCIDS} $!"
		TIMEORIC=$!
	fi
}
WpsTime=0
WSC_WAIT_TIME=120 #sec
AlarmHandler()
{
	#echo "Got SIGALARM"
	if [ "`${CAT} /proc/DNI_wsc_status`" != "34" ]; then
		if [ "${WpsTime}" -ge "${WSC_WAIT_TIME}" ];then
				ReleaseButton
				#${ECHO} 00 > /proc/tc3162/wps_button
				#${ECHO} 33 > /proc/tc3162/led_security
				#${AOSS_LED} error	
				#LED_ERROR
				${NVRAM} set AOSS_ERROR_STATUS=1
				#killall aoss_counter.sh
				#pid="`ps -ef|grep 'aoss_counter.sh'|grep -v grep|head -1|awk '{print $1}`"
				#kill -1 ${pid}
				#/etc/rc.d/aoss_counter.sh&
				LED_ERROR

				rm /tmp/run_security_bt
				${NVRAM} unset aoss_running
			${NVRAM} unset wps_running
			${NVRAM} unset apply_running
			if [ "`ps -ef|grep 'aoss -i'|grep -v grep|head -1|awk '{print $1}'`" != "" ]; then
				killall aoss
				/usr/bin/logger "[AOSS AOSS TimeOut Exit]"
				${NVRAM} unset RESTART_WEP                        
				${NVRAM} set RESTART_AES=1
				${NVRAM} set RESTART_TKIP=1
				${NVRAM} set RESTART_FIXED=1
				if [ "`${NVRAM} get WIFIAOSSAction_tmp`" = "0" ];then
					${NVRAM} set WIFIAOSSAction=0
					Basic_settings
				else
					aoss_basic_settings
				fi
			fi			
			${NVRAM} unset WIFIAOSSAction_tmp
			${NVRAM} unset RESTART_WEP
			${NVRAM} unset RESTART_AES
			${NVRAM} unset RESTART_TKIP
			${NVRAM} unset RESTART_FIXED
			${NVRAM} commit
			exit 14
		fi
	else
		if [ "`${NVRAM} get WIFIWPS_CONFIG_STATUS`" = "0" ];then
			if [ "`cat /proc/DNI_wireless_security |grep ra0|cut -d',' -f 2`" = "Yes" ];then
				${NVRAM} set WIFIWPS_CONFIG_STATUS=1
				KEY="`cat /proc/DNI_wireless_security |grep ra0|cut -d"," -f 6`"
				AUTH="`cat /proc/DNI_wireless_security |grep ra0|cut -d"," -f 4`"
				TYPE="`cat /proc/DNI_wireless_security |grep ra0|cut -d"," -f 5`"
				if [ "`${NVRAM} get WIFIAOSSAction_tmp`" = "1" ];then
					${NVRAM} set WIFIAOSSTKIP_11bg_wpapsk="${KEY}"
				else
					if [ "`${NVRAM} get WIFISecMode`" = "2" ];then
						${NVRAM} set WIFIAuthType1Multi="${AUTH}"
						${NVRAM} set WIFIWPAPSK1Multi="${KEY}"
						${NVRAM} set WIFIEncrypType1Multi="${TYPE}"
					else
						${NVRAM} set WIFIWPAPSK1Single="${KEY}"
						${NVRAM} set WIFIAuthType1Single="${AUTH}"
						${NVRAM} set WIFIEncrypType1Single="${TYPE}"
					fi
				fi
			fi
		fi
		ReleaseButton
		#${ECHO} 00 > /proc/tc3162/wps_button
		#${ECHO} 01 > /proc/tc3162/led_security
		${AOSS_LED} enabled
		rm /tmp/run_security_bt
		#only restart ra2
		if [ "`ps -ef|grep 'aoss -i'|grep -v grep|head -1|awk '{print $1}'`" != "" ]; then
			killall aoss
			/usr/bin/logger "[AOSS AOSS STOP]"
			${NVRAM} unset RESTART_WEP                        
			${NVRAM} set RESTART_AES=1
			${NVRAM} set RESTART_TKIP=1
			${NVRAM} set RESTART_FIXED=1
			if [ "`${NVRAM} get WIFIAOSSAction_tmp`" = "0" ];then
				${NVRAM} set WIFIAOSSAction=0
				Basic_settings
			else
				aoss_basic_settings
			fi
		fi			
		sleep 2
		${NVRAM} unset WIFIAOSSAction_tmp
		${NVRAM} unset RESTART_WEP
		${NVRAM} unset RESTART_AES
		${NVRAM} unset RESTART_TKIP
		${NVRAM} unset RESTART_FIXED
		#ERROR Aaron check this
		#ifconfig ra2 down
		${NVRAM} unset aoss_running
		${NVRAM} unset wps_running
		${NVRAM} unset apply_running
		${NVRAM} commit
		exit 14
	fi
}
unsetTimer()
{
	kill $TIMERPROC
}

PCB_function()
{
	
	ifname="`${NVRAM} get WPS_IFNAME`"
	Wps stop
	CHPROCIDS=$$
	trap AlarmHandler 14
	$PROG &
	${IWPRIV} ${ifname} set WscConfMode=7
	${IWPRIV} ${ifname} set WscMode=2
	echo 2 > /proc/tc3162/DNI_WscMode
	if [ "`${NVRAM} get WIFIWPS_CONFIG_STATUS`" = "0" ];then
		${IWPRIV} ${ifname} set WscConfStatus=1
		${IWPRIV} ${ifname} set WscGetConf=1
	else
		${IWPRIV} ${ifname} set WscConfStatus=2
		${IWPRIV} ${ifname} set WscGetConf=1
	fi
	${IWPRIV} ${ifname} set WscStatus=0
	WpsTime=$((${WpsTime}+2))
	while [ "${WpsTime}" -lt "${WSC_WAIT_TIME}" ]
	do
		SetTimer 2
		wait $!
		WpsTime=$((${WpsTime}+2))
	done
	if [ "`${CAT} /proc/tc3162/wps_button`" = 1 ]; then
		${NVRAM} set AOSS_ERROR_STATUS=1
		LED_ERROR
		ReleaseButton
		rm /tmp/run_security_bt
		${NVRAM} unset apply_running
		${NVRAM} unset aoss_running
		${NVRAM} unset wps_running
		if [ "`ps -ef|grep 'aoss -i'|grep -v grep|head -1|awk '{print $1}'`" != "" ]; then
			killall aoss
			/usr/bin/logger "[AOSS AOSS TimeOut Exit]"
			${NVRAM} unset RESTART_WEP                        
			${NVRAM} set RESTART_AES=1
			${NVRAM} set RESTART_TKIP=1
			${NVRAM} set RESTART_FIXED=1
			if [ "`${NVRAM} get WIFIAOSSAction_tmp`" = "0" ];then
				${NVRAM} set WIFIAOSSAction=0
				Basic_settings
			else
				aoss_basic_settings
			fi
			${NVRAM} unset WIFIAOSSAction_tmp
			${NVRAM} unset RESTART_WEP
			${NVRAM} unset RESTART_AES
			${NVRAM} unset RESTART_TKIP
			${NVRAM} unset RESTART_FIXED
		fi
	fi
}
restart_wps()
{
	if [ "`${CAT} /proc/DNI_wsc_status`" != "34" ]; then
		if [ "${WpsTime}" -ge "${WSC_WAIT_TIME}" ];then
			rm /tmp/run_security_bt
			Wps stop
			Wps start
			${NVRAM} unset nosave_ClientPin
			${NVRAM} unset enrollee_running
			${NVRAM} commit
			security_led_check
			exit 0
		fi
	else
		if [ "`${NVRAM} get WIFIWPS_CONFIG_STATUS`" = "0" ];then
			if [ "`cat /proc/DNI_wireless_security |grep ra0|cut -d',' -f 2`" = "Yes" ];then
				${NVRAM} set WIFIWPS_CONFIG_STATUS=1
				KEY="`cat /proc/DNI_wireless_security |grep ra0|cut -d"," -f 6`"
				AUTH="`cat /proc/DNI_wireless_security |grep ra0|cut -d"," -f 4`"
				TYPE="`cat /proc/DNI_wireless_security |grep ra0|cut -d"," -f 5`"
				if [ "`${NVRAM} get WIFIAOSSAction_tmp`" = "1" ];then
					${NVRAM} set WIFIAOSSTKIP_11bg_wpapsk="${KEY}"
				else
					if [ "`${NVRAM} get WIFISecMode`" = "2" ];then
						${NVRAM} set WIFIAuthType1Multi="${AUTH}"
						${NVRAM} set WIFIWPAPSK1Multi="${KEY}"
						${NVRAM} set WIFIEncrypType1Multi="${TYPE}"
					else
						${NVRAM} set WIFIWPAPSK1Single="${KEY}"
						${NVRAM} set WIFIAuthType1Single="${AUTH}"
						${NVRAM} set WIFIEncrypType1Single="${TYPE}"
					fi
				fi
			fi
		fi
		rm /tmp/run_security_bt
		Wps stop
		Wps start
		${NVRAM} unset nosave_ClientPin
		${NVRAM} unset enrollee_running
		${NVRAM} commit
		security_led_check
		exit 0
	fi
}

check_ssid()
{
	if [ "`${ECHO} -n ${1} | grep " "`" != "" ];then
		${NVRAM} unset RESTART_WEP
		${NVRAM} unset RESTART_AES
		${NVRAM} unset RESTART_TKIP
		${NVRAM} unset RESTART_FIXED
		${NVRAM} set WIFIAOSSAction=0
		${NVRAM} unset aoss_running
		${NVRAM} unset wps_running
		${NVRAM} commit
		/usr/bin/logger "[AOSS AOSS Invalid ESSID Error: White space in ESSID]"
		LED_ERROR
		${NVRAM} set AOSS_INPUT_ERROR=1
		${RM} /tmp/run_security_bt&
		${ECHO} 0 > /proc/tc3162/wps_button
		if [ "`${NVRAM} get WIFIAOSSAction_tmp`" = "0" ];then
			${NVRAM} set WIFIAOSSAction=0
		fi
		exit 1
	fi
}
check_wpa_key()
{
	if [ "`${NVRAM} get WIFI_TEST`" = "1" ];then
		return
	fi
	key=${1}
	if [ "`${ECHO} -n ${1} | grep ' '`" != "" ];then
		${NVRAM} unset RESTART_WEP
		${NVRAM} unset RESTART_AES
		${NVRAM} unset RESTART_TKIP
		${NVRAM} unset RESTART_FIXED
		${NVRAM} set WIFIAOSSAction=0
		${NVRAM} unset aoss_running
		${NVRAM} unset wps_running
		${NVRAM} commit
		/usr/bin/logger "[AOSS AOSS Invalid PSK Error: White space in PSK]"
		LED_ERROR
		${NVRAM} set AOSS_INPUT_ERROR=2
		${ECHO} 0 > /proc/tc3162/wps_button
		${RM} /tmp/run_security_bt&
		if [ "`${NVRAM} get WIFIAOSSAction_tmp`" = "0" ];then
				${NVRAM} set WIFIAOSSAction=0
		fi
		exit 2
	elif [ "${#key}" -gt "63" ];then
		${NVRAM} unset RESTART_WEP
		${NVRAM} unset RESTART_AES
		${NVRAM} unset RESTART_TKIP
		${NVRAM} unset RESTART_FIXED
		${NVRAM} set WIFIAOSSAction=0
		${NVRAM} unset aoss_running
		${NVRAM} unset wps_running
		${NVRAM} commit
		/usr/bin/logger "[AOSS AOSS Invalid PSK Error: PSK exceeded 63 characters]"
		LED_ERROR
		${NVRAM} set AOSS_INPUT_ERROR=3
		${RM} /tmp/run_security_bt&
		${ECHO} 0 > /proc/tc3162/wps_button
		if [ "`${NVRAM} get WIFIAOSSAction_tmp`" = "0" ];then
				${NVRAM} set WIFIAOSSAction=0
		fi
		exit 2
	fi	
}

check_auth_mod()
{
	if [ "`cat /proc/DNI_wireless_security |grep ra0|cut -d "," -f 4`" != "WPAPSKWPA2PSK" ];then
		${NVRAM} unset RESTART_TKIP
	fi
	if [ "`cat /proc/DNI_wireless_security |grep ra1|cut -d "," -f 4`" != "WPAPSK" ];then
		${NVRAM} unset RESTART_AES
	fi
	
}
save_manual_cfg()
{
	${NVRAM} set AOSS_WIFISsid1Enable="`${NVRAM} get WIFISsid1Enable`"
	${NVRAM} set AOSS_WIFIWEPKey1TypeSingle="`${NVRAM} get WIFIWEPKey1TypeSingle`"
	${NVRAM} set AOSS_WIFIWPAPSK1Single="`${NVRAM} get WIFIWPAPSK1Single`"
	${NVRAM} set AOSS_WIFIWEPKey1_S1Single="`${NVRAM} get WIFIWEPKey1_S1Single`"
	${NVRAM} set AOSS_WIFIWEPKey2_S1Single="`${NVRAM} get WIFIWEPKey2_S1Single`"
	${NVRAM} set AOSS_WIFIWEPKey3_S1Single="`${NVRAM} get WIFIWEPKey3_S1Single`"
	${NVRAM} set AOSS_WIFIWEPKey4_S1Single="`${NVRAM} get WIFIWEPKey4_S1Single`"
	${NVRAM} set AOSS_WIFIWEPKeyIndex1Single="`${NVRAM} get WIFIWEPKeyIndex1Single`"
	${NVRAM} set AOSS_WIFISsid1Single="`${NVRAM} get WIFISsid1Single`"
	${NVRAM} set AOSS_WIFIEncrypType1Single="`${NVRAM} get WIFIEncrypType1Single`"
	${NVRAM} set AOSS_WIFIRekeyIntervalSingle="`${NVRAM} get WIFIRekeyIntervalSingle`"
	${NVRAM} set AOSS_WIFIGuestPort1Single="`${NVRAM} get WIFIGuestPort1Single`"
	${NVRAM} set AOSS_WIFIAuthType1Single="`${NVRAM} get WIFIAuthType1Single`"
}
aossKeySync()
{
	if [ "x${BOARD_INOF_REGION}" = "xEU" -a "`${NVRAM} get WIFISecMode`" != "2" ];then
		EU_S_aossKeySync
		return
	fi
	#setting not init aoss item
	${NVRAM} set RESTART_WEP=1
	${NVRAM} set RESTART_AES=1
	${NVRAM} set RESTART_TKIP=1
	${NVRAM} set RESTART_FIXED=1
	
	${NVRAM} set WIFIAOSSEncryptionType=0
	VAR_KEY=0
	for i in 1 2 3
	do
		if [ "`${NVRAM} get WIFISsid${i}EnableMulti`" = "1" ];then
			MAIN_SSID="`${NVRAM} get WIFISsid${i}Multi`"
			AUTH_TYPE="`${NVRAM} get WIFIAuthType${i}Multi`"
			TYPE="`${NVRAM} get WIFIEncrypType${i}Multi`"
			if [ "${MAIN_SSID}" = "" ];then
				MSSID=`${NVRAM} get lan_hwaddr|cut -c10-11,13-14,16-17`
				MAIN_SSID="${SSID_PREFIX}${MSSID}-1"
			fi
			IF_NUMBER=${i}
			case "${IF_NUMBER}" in
  			#"AES")
  			"2")
  				${NVRAM} set AOSS_TKIP_IF=2
  				${NVRAM} set AOSS_AES_IF=1
  				${NVRAM} set AOSS_WEP_IF=3
				${NVRAM} unset RESTART_AES
  				ADD1_END=""
				ADD2_END="-2"
				ADD3_END="-3"
				ADD4_END="-4"
				MAIN_ITEM="${TYPE}"
				if [ "${MAIN_ITEM}" = "AES" ];then
					MAIN_ITEM="TKIP"
					break;
				fi
				if [ "${MAIN_ITEM}" = "WEP" -a "${AUTH_TYPE}" = "OPEN" ];then 
					U_WEP_TYPE="`${NVRAM} get WIFIWEPKey1Type_S${i}Multi`"
					if [ "x${U_WEP_TYPE}" = "xA5" -o "x${U_WEP_TYPE}" = "xH10" ];then
						MAIN_ITEM="WEP64"
						ADD4_END=""
						${NVRAM} set WIFIAOSSEncryptionType=1
					else
						MAIN_ITEM="WEP128"
						ADD3_END=""
						if [ "`${NVRAM} get WIFIAOSSEncryptionType`" != "1" ];then
						${NVRAM} set WIFIAOSSEncryptionType=2
						fi
					fi
					for i in 1 2 3 4
					do
						SMALLEST_KEY="`${NVRAM} get WIFIWEPKey${i}_S1Multi`"
						if [ "${SMALLEST_KEY}" != "" ];then
							break;
						fi
					done
				else
					VAR_KEY=1
					MAIN_ITEM="AES"
				fi
				;;
  			#"TKIP")
  			"1")
  				${NVRAM} set AOSS_TKIP_IF=1
  				${NVRAM} set AOSS_AES_IF=2
  				${NVRAM} set AOSS_WEP_IF=3
  				ADD1_END="-1"
				ADD2_END="-2"
				ADD3_END="-3"
				ADD4_END="-4"
				MAIN_ITEM="${TYPE}"
				if [ "${MAIN_ITEM}" = "AES" ];then
					MAIN_ITEM="TKIP"
					ADD2_END=""
					break
				fi
				if [ "${MAIN_ITEM}" = "TKIP" ];then
					ADD2_END=""
					break
				fi
				if [ "${MAIN_ITEM}" = "TKIPAES" ];then
					ADD2_END=""
					break
				fi
				
				if [ "${MAIN_ITEM}" = "WEP" -a "${AUTH_TYPE}" = "OPEN" ];then 
					U_WEP_TYPE="`${NVRAM} get WIFIWEPKey1Type_S${i}Multi`"
					if [ "${U_WEP_TYPE}" = "A5" -o "${U_WEP_TYPE}" = "H10" ];then
						MAIN_ITEM="WEP64"
						ADD4_END=""
						${NVRAM} set WIFIAOSSEncryptionType=1
					else
						MAIN_ITEM="WEP128"
						ADD3_END=""
						if [ "`${NVRAM} get WIFIAOSSEncryptionType`" != "1" ];then
						${NVRAM} set WIFIAOSSEncryptionType=2
						fi
					fi
					for i in 1 2 3 4
					do
						SMALLEST_KEY="`${NVRAM} get WIFIWEPKey${i}_S1Multi`"
						if [ "${SMALLEST_KEY}" != "" ];then
							break;
						fi
					done
					SESSION_MAIN="WEP"	
				else
					VAR_KEY=1
					MAIN_ITEM="TKIP"
				fi
				;;
  			#"WEP")
  			"3")
  				${NVRAM} set AOSS_TKIP_IF=2
  				${NVRAM} set AOSS_AES_IF=1
  				${NVRAM} set AOSS_WEP_IF=3
  				ADD1_END="-1"
				ADD2_END="-2"
				ADD3_END="-3"
				ADD4_END="-4"
 				U_WEP_TYPE="`${NVRAM} get WIFIWEPKey1Type_S${i}Multi`"
				if [ "${U_WEP_TYPE}" = "A5" -o "${U_WEP_TYPE}" = "H10" ];then
					MAIN_ITEM="WEP64"
					ADD4_END=""
					${NVRAM} set WIFIAOSSEncryptionType=1
				else
					MAIN_ITEM="WEP128"
					ADD3_END=""
					if [ "`${NVRAM} get WIFIAOSSEncryptionType`" != "1" ];then
					${NVRAM} set WIFIAOSSEncryptionType=2
					fi
				fi
				for i in 1 2 3 4
				do
					SMALLEST_KEY="`${NVRAM} get WIFIWEPKey${i}_S1Multi`"
					if [ "${SMALLEST_KEY}" != "" ];then
						break;
					fi
				done
				
				;;
  			*)
  				MAIN_ITEM="NONE"
				ADD1_END="-1"
				ADD2_END="-2"
				ADD3_END="-3"
				ADD4_END="-4"
				;;
			esac
			break;
		fi
	done
	if [ "${MAIN_SSID}" = "" ];then
		MSSID=`${NVRAM} get lan_hwaddr|cut -c10-11,13-14,16-17`
		MAIN_SSID="${SSID_PREFIX}${MSSID}"
  		MAIN_ITEM="NONE"
		ADD1_END="-1"
		ADD2_END="-2"
		ADD3_END="-3"
		ADD4_END="-4"
	fi
	#set security and SSID
	PUBLE_WAP_KEY="`${NVRAM} get aeskey_default`"
	PUBLE_WEP_64KEY=`dd if=/dev/urandom bs=5 count=1 2>/dev/null |hexdump |head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
	PUBLE_WEP_128KEY=`dd if=/dev/urandom bs=13 count=1 2>/dev/null |hexdump |head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
	
	if [ "${SESSION_MAIN}" = "WEP" ];then
		cfg_item=1
	else
		cfg_item=3
	fi
	S3_WEP_TYPE="`${NVRAM} get WIFIWEPKey1Type_S${cfg_item}Multi`"
	if [ "${S3_WEP_TYPE}" = "A5" -o "${S3_WEP_TYPE}" = "H10" ];then
		S3_WEP_TYPE=WEP_64
	else
		S3_WEP_TYPE=WEP_128
	fi
#AES Setting
	if [ "${MAIN_ITEM}" = "AES" ];then
		${NVRAM} set WIFIAOSSAES_11bg_manssid="${MAIN_SSID}"
		if [ "${VAR_KEY}" = "0" ];then
		${NVRAM} set WIFIAOSSAES_11bg_wpapsk="`${NVRAM} get WIFIWPAPSK${IF_NUMBER}Multi`"
		else
		${NVRAM} unset RESTART_AES
		${NVRAM} set WIFIAOSSAES_11bg_wpapsk="${PUBLE_WAP_KEY}"
		fi
	else
		if [ "`${NVRAM} get WIFISsid2EnableMulti`" = "1" ];then
		${NVRAM} set WIFIAOSSAES_11bg_manssid="`${NVRAM} get WIFISsid2Multi`"
		${NVRAM} set WIFIAOSSAES_11bg_wpapsk="`${NVRAM} get WIFIWPAPSK2Multi`"
		else
		${NVRAM} unset RESTART_AES
		if [ "`${ECHO} ${MAIN_SSID}|wc -L`" -ge "31" ];then
			NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-30`"
			if [ "${NEW_SSID}${ADD1_END}" = "${MAIN_SSID}" ];then
				#OFFSET="`${ECHO} -n ${NEW_SSID}|cut -c 29-30`"
				#NEW1_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-28`"
				#NEW_SSID=${NEW1_SSID}$((${OFFSET}-1))
				NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-29`"
			fi
			${NVRAM} set WIFIAOSSAES_11bg_manssid="${NEW_SSID}${ADD1_END}"
		else
			${NVRAM} set WIFIAOSSAES_11bg_manssid="${MAIN_SSID}${ADD1_END}"
		fi
		${NVRAM} set WIFIAOSSAES_11bg_wpapsk="${PUBLE_WAP_KEY}"
		fi
	fi
#TKIP setting
	if [ "${MAIN_ITEM}" = "TKIP" -o "${MAIN_ITEM}" = "TKIPAES" ];then
		if [ "`${NVRAM} get WIFISsid1EnableMulti`" = "1" ];then
			${NVRAM} set WIFIAOSSTKIP_11bg_manssid="${MAIN_SSID}${ADD2_END}"
			if [ "${VAR_KEY}" = "0" ];then
				${NVRAM} set WIFIAOSSTKIP_11bg_wpapsk="`${NVRAM} get WIFIWPAPSK${IF_NUMBER}Multi`"
			else
				${NVRAM} unset RESTART_TKIP
				${NVRAM} set WIFIAOSSTKIP_11bg_wpapsk="${PUBLE_WAP_KEY}"
			fi
		else
			${NVRAM} unset RESTART_TKIP
			if [ "`${ECHO} ${MAIN_SSID}|wc -L`" -ge "31" ];then
				NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-30`"
				if [ "${NEW_SSID}${ADD2_END}" = "${MAIN_SSID}" ];then
					NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-29`"
				fi
				${NVRAM} set WIFIAOSSTKIP_11bg_manssid="${NEW_SSID}${ADD2_END}"
			else
				${NVRAM} set WIFIAOSSTKIP_11bg_manssid="${MAIN_SSID}${ADD2_END}"
			fi
			${NVRAM} set WIFIAOSSTKIP_11bg_wpapsk="${PUBLE_WAP_KEY}"
		fi
	else
		if [ "`${NVRAM} get WIFISsid1EnableMulti`" = "1" -a "${MAIN_ITEM}" = "TKIP" ];then
			${NVRAM} set WIFIAOSSTKIP_11bg_manssid="`${NVRAM} get WIFISsid1Multi`"
			${NVRAM} set WIFIAOSSTKIP_11bg_wpapsk="`${NVRAM} get WIFIWPAPSK1Multi`"
		else
			${NVRAM} unset RESTART_TKIP
			if [ "`${ECHO} ${MAIN_SSID}|wc -L`" -ge "31" ];then
				NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-30`"
				if [ "${NEW_SSID}${ADD2_END}" = "${MAIN_SSID}" ];then
					NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-29`"
				fi
				${NVRAM} set WIFIAOSSTKIP_11bg_manssid="${NEW_SSID}${ADD2_END}"
			else
				${NVRAM} set WIFIAOSSTKIP_11bg_manssid="${MAIN_SSID}${ADD2_END}"
			fi
			${NVRAM} set WIFIAOSSTKIP_11bg_wpapsk="${PUBLE_WAP_KEY}"
		fi
	fi
	if [ "${IF_NUMBER}" = "3" ];then
	for i in 1 2 3 4
	do
		SMALLEST_KEY="`${NVRAM} get WIFIWEPKey${i}_S${cfg_item}Multi`"
		if [ "${SMALLEST_KEY}" != "" ];then
			break;
		fi
	done
	fi
	if [ "${SMALLEST_KEY}" = "" ];then
		SMALLEST_KEY="${PUBLE_WEP_64KEY}"
	fi
	if [ "${MAIN_ITEM}" = "WEP64" ];then
		${NVRAM} set WIFIAOSSWEP40_11bg_manssid="${MAIN_SSID}"
		bs_index="`${NVRAM} get WIFIWEPKeyIndex${IF_NUMBER}Multi`"
		${NVRAM} set WIFIAOSSWEP40_11bg_key_index=$((${bs_index}-1))
		if [ "${SMALLEST_KEY}" = "" ];then
			SMALLEST_KEY="${PUBLE_WEP_64KEY}"
		fi
		for i in 1 2 3 4
		do
			KEY_CFG="`${NVRAM} get WIFIWEPKey${i}_S${IF_NUMBER}Multi`"
			if [ "${KEY_CFG}" != "" ];then
				${NVRAM} unset RESTART_WEP
				${NVRAM} set WIFIAOSSEncryptionType=1
				${NVRAM} set WIFIAOSSWEP40_11bg_key$((${i}-1))="${KEY_CFG}"
			else
				${NVRAM} set WIFIAOSSWEP40_11bg_key$((${i}-1))="${SMALLEST_KEY}"
			fi
		done
	else		
		if [ "`${NVRAM} get WIFISsid3EnableMulti`" = "1" -a "${S3_WEP_TYPE}" = "WEP_64" ];then
			${NVRAM} set WIFIAOSSWEP40_11bg_manssid="`${NVRAM} get WIFISsid3Multi`"
			bs_index="`${NVRAM} get WIFIWEPKeyIndex3Multi`"
			${NVRAM} set WIFIAOSSWEP40_11bg_key_index=$((${bs_index}-1))
			
			for i in 1 2 3 4
			do
				LEST_KEY="`${NVRAM} get WIFIWEPKey${i}_S${cfg_item}Multi`"
				if [ "${LEST_KEY}" != "" ];then
					break;
				fi
			done
			if [ "${LEST_KEY}" = "" ];then
				LEST_KEY="${PUBLE_WEP_64KEY}"
			fi
			for i in 1 2 3 4
			do
				if [ "`${NVRAM} get WIFIWEPKey${i}_S${cfg_item}Multi`" = "" ];then
					${NVRAM} set WIFIAOSSWEP40_11bg_key$((${i}-1))="${LEST_KEY}"
				else
					${NVRAM} set WIFIAOSSEncryptionType=1
					${NVRAM} set WIFIAOSSWEP40_11bg_key$((${i}-1))="`${NVRAM} get WIFIWEPKey${i}_S${cfg_item}Multi`"
				fi
			done
		else
			${NVRAM} unset RESTART_WEP
			if [ "`${ECHO} ${MAIN_SSID}|wc -L`" -ge "31" ];then
				NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-30`"
				if [ "${NEW_SSID}${ADD4_END}" = "${MAIN_SSID}" ];then
					NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-29`"
				fi
				${NVRAM} set WIFIAOSSWEP40_11bg_manssid="${NEW_SSID}${ADD4_END}"
			else
				${NVRAM} set WIFIAOSSWEP40_11bg_manssid="${MAIN_SSID}${ADD4_END}"
			fi
			${NVRAM} set WIFIAOSSWEP40_11bg_key_index="0"
			${NVRAM} set WIFIAOSSWEP40_11bg_key0="${PUBLE_WEP_64KEY}"
			${NVRAM} set WIFIAOSSWEP40_11bg_key1="${PUBLE_WEP_64KEY}"
			${NVRAM} set WIFIAOSSWEP40_11bg_key2="${PUBLE_WEP_64KEY}"
			${NVRAM} set WIFIAOSSWEP40_11bg_key3="${PUBLE_WEP_64KEY}"
		fi
	fi
	
	if [ "${MAIN_ITEM}" = "WEP128" ];then
		${NVRAM} set WIFIAOSSWEP104_11bg_manssid="${MAIN_SSID}"
		bs_index="`${NVRAM} get WIFIWEPKeyIndex${IF_NUMBER}Multi`"
		${NVRAM} set WIFIAOSSWEP104_11bg_key_index=$((${bs_index}-1))
		if [ "${SMALLEST_KEY}" = "" ];then
			SMALLEST_KEY="${PUBLE_WEP_128KEY}"
		fi
		for i in 1 2 3 4
		do
			KEY_CFG="`${NVRAM} get WIFIWEPKey${i}_S${cfg_item}Multi`"
			if [ "${KEY_CFG}" != "" ];then
				${NVRAM} unset RESTART_WEP
				${NVRAM} set WIFIAOSSWEP104_11bg_key$((${i}-1))="${KEY_CFG}"
				if [ "`${NVRAM} get WIFIAOSSEncryptionType`" != "1" ];then
				${NVRAM} set WIFIAOSSEncryptionType=2
				fi
			else
				${NVRAM} set WIFIAOSSWEP104_11bg_key$((${i}-1))="${SMALLEST_KEY}"
			fi
		done
	else
		if [ "`${NVRAM} get WIFISsid3EnableMulti`" = "1"  -a "${S3_WEP_TYPE}" = "WEP_128" ];then
		${NVRAM} set WIFIAOSSWEP104_11bg_manssid="`${NVRAM} get WIFISsid3Multi`"
		bs_index="`${NVRAM} get WIFIWEPKeyIndex3Multi`"
		${NVRAM} set WIFIAOSSWEP104_11bg_key_index=$((${bs_index}-1))
		for i in 1 2 3 4
		do
			LEST_KEY="`${NVRAM} get WIFIWEPKey${i}_S${cfg_item}Multi`"
			if [ "${LEST_KEY}" != "" ];then
				break;
			fi
		done
		if [ "${LEST_KEY}" = "" ];then
			LEST_KEY="${PUBLE_WEP_128KEY}"
		fi
		for i in 1 2 3 4
		do
			if [ "`${NVRAM} get WIFIWEPKey${i}_S${cfg_item}Multi`" = "" ];then
				${NVRAM} set WIFIAOSSWEP104_11bg_key$((${i}-1))="${LEST_KEY}"
			else
				${NVRAM} set WIFIAOSSWEP104_11bg_key$((${i}-1))="`${NVRAM} get WIFIWEPKey${i}_S${cfg_item}Multi`"
				if [ "`${NVRAM} get WIFIAOSSEncryptionType`" != "1" ];then
				${NVRAM} set WIFIAOSSEncryptionType=2
				fi
			fi
		done
		else
		${NVRAM} unset RESTART_WEP
		if [ "`${ECHO} ${MAIN_SSID}|wc -L`" -ge "31" ];then
			NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-30`"
			if [ "${NEW_SSID}${ADD3_END}" = "${MAIN_SSID}" ];then
				NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-29`"
			fi
			${NVRAM} set WIFIAOSSWEP104_11bg_manssid="${NEW_SSID}${ADD3_END}"
		else
			${NVRAM} set WIFIAOSSWEP104_11bg_manssid="${MAIN_SSID}${ADD3_END}"
		fi
		${NVRAM} set WIFIAOSSWEP104_11bg_key_index=0
		${NVRAM} set WIFIAOSSWEP104_11bg_key0="${PUBLE_WEP_128KEY}"
		${NVRAM} set WIFIAOSSWEP104_11bg_key1="${PUBLE_WEP_128KEY}"
		${NVRAM} set WIFIAOSSWEP104_11bg_key2="${PUBLE_WEP_128KEY}"
		${NVRAM} set WIFIAOSSWEP104_11bg_key3="${PUBLE_WEP_128KEY}"
		fi
	fi
	
	#error confirmation
	check_ssid "`${NVRAM} get WIFIAOSSTKIP_11bg_manssid`"
	check_ssid "`${NVRAM} get WIFIAOSSWEP40_11bg_manssid`"
	check_ssid "`${NVRAM} get WIFIAOSSAES_11bg_manssid`"
	check_ssid "`${NVRAM} get WIFIAOSSWEP104_11bg_manssid`"

	check_wpa_key  "`${NVRAM} get WIFIAOSSTKIP_11bg_wpapsk`"
	check_wpa_key  "`${NVRAM} get WIFIAOSSAES_11bg_wpapsk`"

	KeyLen=`${NVRAM} get WIFIAOSSWEP104_11bg_key0`
	if [ "${#KeyLen}" = "10" -o "${#KeyLen}" = "26" ];then
		${NVRAM} set WIFIAOSSWEP104_11bg_key0="`${NVRAM} get WIFIAOSSWEP104_11bg_key0|tr [a-z] [A-Z]`"
		${NVRAM} set WIFIAOSSWEP104_11bg_key1="`${NVRAM} get WIFIAOSSWEP104_11bg_key1|tr [a-z] [A-Z]`"
		${NVRAM} set WIFIAOSSWEP104_11bg_key2="`${NVRAM} get WIFIAOSSWEP104_11bg_key2|tr [a-z] [A-Z]`"
		${NVRAM} set WIFIAOSSWEP104_11bg_key3="`${NVRAM} get WIFIAOSSWEP104_11bg_key3|tr [a-z] [A-Z]`"
	fi

	KeyLen=`${NVRAM} get WIFIAOSSWEP40_11bg_key0`
	if [ "${#KeyLen}" = "10" -o "${#KeyLen}" = "26" ];then
			${NVRAM} set WIFIAOSSWEP40_11bg_key0="`${NVRAM} get WIFIAOSSWEP40_11bg_key0|tr [a-z] [A-Z]`"
			${NVRAM} set WIFIAOSSWEP40_11bg_key1="`${NVRAM} get WIFIAOSSWEP40_11bg_key1|tr [a-z] [A-Z]`"
			${NVRAM} set WIFIAOSSWEP40_11bg_key2="`${NVRAM} get WIFIAOSSWEP40_11bg_key2|tr [a-z] [A-Z]`"
			${NVRAM} set WIFIAOSSWEP40_11bg_key3="`${NVRAM} get WIFIAOSSWEP40_11bg_key3|tr [a-z] [A-Z]`"
	fi
	check_auth_mod
	if [ "x${BOARD_INOF_REGION}" = "xEU" ];then
		save_manual_cfg
	fi
	${NVRAM} commit
}

EU_S_aossKeySync()
{
	#setting not init aoss item
	${NVRAM} unset RESTART_WEP
	${NVRAM} unset RESTART_AES=1
	${NVRAM} unset RESTART_TKIP
	${NVRAM} unset RESTART_FIXED
	
	${NVRAM} set WIFIAOSSEncryptionType=0
	TYPE="`${NVRAM} get WIFIEncrypType1Single`"
	MAIN_SSID="`${NVRAM} get WIFISsid1Single`"
	AUTH_TYPE="`${NVRAM} get WIFIAuthType1Single`"

	if [ "${AUTH_TYPE}" = "OPEN" -a "${TYPE}" = "NONE" ];then
		MAIN_ITEM="NONE"
		ADD1_END="-1"
		ADD2_END="-2"
		ADD3_END="-3"
		ADD4_END="-4"
	elif [ "${AUTH_TYPE}" = "WPAPSK" -a "${TYPE}" = "AES" ];then
		MAIN_ITEM="AES"
		ADD1_END=""
		ADD2_END="-2"
		ADD3_END="-3"
		ADD4_END="-4"
	elif [ "${AUTH_TYPE}" = "OPEN" -a "${TYPE}" = "WEP" ];then
		U_WEP_TYPE="`${NVRAM} get WIFIWEPKey1TypeSingle`"
		if [ "x${U_WEP_TYPE}" = "xA5" -o "x${U_WEP_TYPE}" = "xH10" ];then
			MAIN_ITEM="WEP64"
  			ADD1_END="-1"
			ADD2_END="-2"
			ADD3_END="-3"
			ADD4_END=""
			${NVRAM} set WIFIAOSSEncryptionType=1
		else
			MAIN_ITEM="WEP128"
  			ADD1_END="-1"
			ADD2_END="-2"
			ADD3_END=""
			ADD4_END="-4"
			${NVRAM} set WIFIAOSSEncryptionType=0
		fi
		for i in 1 2 3 4
		do
			SMALLEST_KEY="`${NVRAM} get WIFIWEPKey${i}_S1Single`"
			if [ "${SMALLEST_KEY}" != "" ];then
				break;
			fi
		done
	else
		MAIN_ITEM="TKIPAES"
		ADD1_END="-1"
		ADD2_END=""
		ADD3_END="-3"
		ADD4_END="-4"
	fi

	#set security and SSID
	PUBLE_WAP_KEY="`${NVRAM} get aeskey_default`"
	PUBLE_WEP_64KEY=`dd if=/dev/urandom bs=5 count=1 2>/dev/null |hexdump |head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`
	PUBLE_WEP_128KEY=`dd if=/dev/urandom bs=13 count=1 2>/dev/null |hexdump |head -1|sed -e 's/[^ ]* //' -e 's/ //g'|sed 's/..$//'`

		
#AES Setting
	if [ "${MAIN_ITEM}" = "AES" ];then
		${NVRAM} set WIFIAOSSAES_11bg_manssid="${MAIN_SSID}"
		${NVRAM} set WIFIAOSSAES_11bg_wpapsk="`${NVRAM} get WIFIWPAPSK1Single`"
	else
		${NVRAM} unset RESTART_AES
		if [ "`${ECHO} ${MAIN_SSID}|wc -L`" -ge "31" ];then
			NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-30`"
			if [ "${NEW_SSID}${ADD1_END}" = "${MAIN_SSID}" ];then
				NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-29`"
			fi
			${NVRAM} set WIFIAOSSAES_11bg_manssid="${NEW_SSID}${ADD1_END}"
		else
			${NVRAM} set WIFIAOSSAES_11bg_manssid="${MAIN_SSID}${ADD1_END}"
		fi
		${NVRAM} set WIFIAOSSAES_11bg_wpapsk="${PUBLE_WAP_KEY}"
	fi
#TKIP setting
	if [ "${MAIN_ITEM}" = "TKIP" -o "${MAIN_ITEM}" = "TKIPAES" ];then
		${NVRAM} set WIFIAOSSTKIP_11bg_manssid="${MAIN_SSID}${ADD2_END}"
		${NVRAM} set WIFIAOSSTKIP_11bg_wpapsk="`${NVRAM} get WIFIWPAPSK1Single`"
		${NVRAM} unset RESTART_AES
	else
		if [ "`${ECHO} ${MAIN_SSID}|wc -L`" -ge "31" ];then
			NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-30`"
			if [ "${NEW_SSID}${ADD2_END}" = "${MAIN_SSID}" ];then
				NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-29`"
			fi
			${NVRAM} set WIFIAOSSTKIP_11bg_manssid="${NEW_SSID}${ADD2_END}"
		else
			${NVRAM} set WIFIAOSSTKIP_11bg_manssid="${MAIN_SSID}${ADD2_END}"
		fi
		${NVRAM} set WIFIAOSSTKIP_11bg_wpapsk="${PUBLE_WAP_KEY}"
	fi

#WEP 64
	if [ "${MAIN_ITEM}" = "WEP64" ];then
		${NVRAM} unset RESTART_AES
		${NVRAM} set WIFIAOSSWEP40_11bg_manssid="${MAIN_SSID}"
		bs_index="`${NVRAM} get WIFIWEPKeyIndex1Single`"
		${NVRAM} set WIFIAOSSEncryptionType=1
		${NVRAM} set WIFIAOSSWEP40_11bg_key_index=$((${bs_index}-1))
		if [ "x${SMALLEST_KEY}" = "x" ];then
			SMALLEST_KEY="${PUBLE_WEP_64KEY}"
		fi
		for i in 1 2 3 4
		do
			KEY_CFG="`${NVRAM} get WIFIWEPKey${i}_S1Single`"
			if [ "${KEY_CFG}" != "" ];then
				${NVRAM} set WIFIAOSSWEP40_11bg_key$((${i}-1))="${KEY_CFG}"
			else
				${NVRAM} set WIFIAOSSWEP40_11bg_key$((${i}-1))="${SMALLEST_KEY}"
			fi
		done
	else		
		if [ "`${ECHO} ${MAIN_SSID}|wc -L`" -ge "31" ];then
			NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-30`"
			if [ "${NEW_SSID}${ADD4_END}" = "${MAIN_SSID}" ];then
				NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-29`"
			fi
			${NVRAM} set WIFIAOSSWEP40_11bg_manssid="${NEW_SSID}${ADD4_END}"
		else
			${NVRAM} set WIFIAOSSWEP40_11bg_manssid="${MAIN_SSID}${ADD4_END}"
		fi
		${NVRAM} set WIFIAOSSWEP40_11bg_key_index="0"
		${NVRAM} set WIFIAOSSWEP40_11bg_key0="${PUBLE_WEP_64KEY}"
		${NVRAM} set WIFIAOSSWEP40_11bg_key1="${PUBLE_WEP_64KEY}"
		${NVRAM} set WIFIAOSSWEP40_11bg_key2="${PUBLE_WEP_64KEY}"
		${NVRAM} set WIFIAOSSWEP40_11bg_key3="${PUBLE_WEP_64KEY}"
	fi
#WEP 128	
	if [ "${MAIN_ITEM}" = "WEP128" ];then
		${NVRAM} unset RESTART_AES
		${NVRAM} set WIFIAOSSWEP104_11bg_manssid="${MAIN_SSID}"
		bs_index="`${NVRAM} get WIFIWEPKeyIndex1Single`"
		${NVRAM} set WIFIAOSSEncryptionType=2
		${NVRAM} set WIFIAOSSWEP104_11bg_key_index=$((${bs_index}-1))
		if [ "x${SMALLEST_KEY}" = "x" ];then
			SMALLEST_KEY="${PUBLE_WEP_128KEY}"
		fi
		for i in 1 2 3 4
		do
			KEY_CFG="`${NVRAM} get WIFIWEPKey${i}_S1Single`"
			if [ "${KEY_CFG}" != "" ];then
				${NVRAM} set WIFIAOSSWEP104_11bg_key$((${i}-1))="${KEY_CFG}"
			else
				${NVRAM} set WIFIAOSSWEP104_11bg_key$((${i}-1))="${SMALLEST_KEY}"
			fi
		done
	else
		if [ "`${ECHO} ${MAIN_SSID}|wc -L`" -ge "31" ];then
			NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-30`"
			if [ "${NEW_SSID}${ADD3_END}" = "${MAIN_SSID}" ];then
				NEW_SSID="`${ECHO} -n ${MAIN_SSID}|cut -c 0-29`"
			fi
			${NVRAM} set WIFIAOSSWEP104_11bg_manssid="${NEW_SSID}${ADD3_END}"
		else
			${NVRAM} set WIFIAOSSWEP104_11bg_manssid="${MAIN_SSID}${ADD3_END}"
		fi
		${NVRAM} set WIFIAOSSWEP104_11bg_key_index=0
		${NVRAM} set WIFIAOSSWEP104_11bg_key0="${PUBLE_WEP_128KEY}"
		${NVRAM} set WIFIAOSSWEP104_11bg_key1="${PUBLE_WEP_128KEY}"
		${NVRAM} set WIFIAOSSWEP104_11bg_key2="${PUBLE_WEP_128KEY}"
		${NVRAM} set WIFIAOSSWEP104_11bg_key3="${PUBLE_WEP_128KEY}"
	fi
	
	#error confirmation
	check_ssid "`${NVRAM} get WIFIAOSSTKIP_11bg_manssid`"
	check_ssid "`${NVRAM} get WIFIAOSSWEP40_11bg_manssid`"
	check_ssid "`${NVRAM} get WIFIAOSSAES_11bg_manssid`"
	check_ssid "`${NVRAM} get WIFIAOSSWEP104_11bg_manssid`"

	check_wpa_key  "`${NVRAM} get WIFIAOSSTKIP_11bg_wpapsk`"
	check_wpa_key  "`${NVRAM} get WIFIAOSSAES_11bg_wpapsk`"

	KeyLen=`${NVRAM} get WIFIAOSSWEP104_11bg_key0`
	if [ "${#KeyLen}" = "10" -o "${#KeyLen}" = "26" ];then
		${NVRAM} set WIFIAOSSWEP104_11bg_key0="`${NVRAM} get WIFIAOSSWEP104_11bg_key0|tr [a-z] [A-Z]`"
		${NVRAM} set WIFIAOSSWEP104_11bg_key1="`${NVRAM} get WIFIAOSSWEP104_11bg_key1|tr [a-z] [A-Z]`"
		${NVRAM} set WIFIAOSSWEP104_11bg_key2="`${NVRAM} get WIFIAOSSWEP104_11bg_key2|tr [a-z] [A-Z]`"
		${NVRAM} set WIFIAOSSWEP104_11bg_key3="`${NVRAM} get WIFIAOSSWEP104_11bg_key3|tr [a-z] [A-Z]`"
	fi

	KeyLen=`${NVRAM} get WIFIAOSSWEP40_11bg_key0`
	if [ "${#KeyLen}" = "10" -o "${#KeyLen}" = "26" ];then
			${NVRAM} set WIFIAOSSWEP40_11bg_key0="`${NVRAM} get WIFIAOSSWEP40_11bg_key0|tr [a-z] [A-Z]`"
			${NVRAM} set WIFIAOSSWEP40_11bg_key1="`${NVRAM} get WIFIAOSSWEP40_11bg_key1|tr [a-z] [A-Z]`"
			${NVRAM} set WIFIAOSSWEP40_11bg_key2="`${NVRAM} get WIFIAOSSWEP40_11bg_key2|tr [a-z] [A-Z]`"
			${NVRAM} set WIFIAOSSWEP40_11bg_key3="`${NVRAM} get WIFIAOSSWEP40_11bg_key3|tr [a-z] [A-Z]`"
	fi
	check_auth_mod
	${NVRAM} commit
}

wps_enrollee()
{
	ifname="`${NVRAM} get WPS_IFNAME`"
##################################################	
	check_WPS_function
	Current_WPS_ENABLE="`${NVRAM} get Current_WPS_ENABLE`"
##################################################
	if [ "${Current_WPS_ENABLE}" = "0" ];then
		return
	fi
	ENROLLEE_PIN=`${NVRAM} get nosave_ClientPin`
	if [ "${ENROLLEE_PIN}" = "" ];then
		exit 1;
	fi
	${AOSS_LED} Connect
	$PROG &
	${NVRAM} set enrollee_running=1
	trap restart_wps 14
	#SetTimer 120
	${IWPRIV} ${ifname} set WscConfMode=0
	${IWPRIV} ${ifname} set WscConfMode=7
	${IWPRIV} ${ifname} set WscMode=1
	echo 2 > /proc/tc3162/DNI_WscMode
	${IWPRIV} ${ifname} set WscPinCode=${ENROLLEE_PIN}
	if [ "`${NVRAM} get WIFIWPS_CONFIG_STATUS`" = 0 ];then
		${IWPRIV} ${ifname} set WscConfStatus=1
	else
		${IWPRIV} ${ifname} set WscConfStatus=2
	fi
	${IWPRIV} ${ifname} set WscGetConf=1
	${IWPRIV} ${ifname} set WscStatus=0
	WpsTime=$((${WpsTime}+2))
	while [ "${WpsTime}" -lt "${WSC_WAIT_TIME}" ]
	do
		SetTimer 2
		wait $!
		WpsTime=$((${WpsTime}+2))
	done
	rm /tmp/run_security_bt
	Wps stop
	Wps start
	${NVRAM} unset nosave_ClientPin
	${NVRAM} unset enrollee_running
	security_led_check
	exit 0
}

aoss_button()
{
	#RADIO=`${NVRAM} get WIFIModuleEnable`
	#if [ "$RADIO" = "0" ]; then
	#	exit 0
	#fi
	if [ "`${NVRAM} get WIFIAOSSAction`" != "1" -o "`${NVRAM} get UI_PRE_AOSS_STATUS`" = "0" ];then
		${NVRAM} set UI_PRE_AOSS_STATUS=1
		aossKeySync
	else

		if [ "x${BOARD_INOF_REGION}" = "xEU" ];then
			${NVRAM} set RESTART_WEP=1
		else
		#only restart WEP interface
			${NVRAM} unset RESTART_WEP
		fi
		${NVRAM} set RESTART_AES=1
		${NVRAM} set RESTART_TKIP=1
	fi
	${NVRAM} set RESTART_FIXED=1
	IF_NAME="`${NVRAM} get WIFIAOSS_ifname`"
	killall aoss
	/usr/bin/logger "[AOSS AOSS Start]"
	/usr/sbin/aoss -i ${IF_NAME} -m ap&
	#/usr/sbin/aoss -i eth0 -m ap&	
}
check_WPS_function()
{
	#check WPS enabled
	${NVRAM} set Current_WPS_ENABLE=1	
	Current_WPS_ENABLE=1
	if [ "`${NVRAM} get WIFISecMode`" = "2" -a "`${NVRAM} get WIFISsid1EnableMulti`" = "0" ];then
		${NVRAM} set Current_WPS_ENABLE=0	
		Current_WPS_ENABLE=0
	fi
	if [ "${aoss_tmp}" = "1" -a "${Current_WPS_ENABLE}" = "0" ];then
		${NVRAM} set Current_WPS_ENABLE=1	
		Current_WPS_ENABLE=1
	fi
	if [ "`${NVRAM} get WPSEnable`" = "0" -a "${Current_WPS_ENABLE}" = "1" ];then
		${NVRAM} set Current_WPS_ENABLE=0	
	fi
}
SecurityButton()
{
	flag=0
	aoss_tmp="`${NVRAM} get WIFIAOSSAction`"

##################################################################
	check_WPS_function
	Current_WPS_ENABLE="`${NVRAM} get Current_WPS_ENABLE`"
##################################################################
	if [ -e "/tmp/run_security_bt" ]; then
		echo "Button running ....."
		exit 0
	fi
	button_status=`${CAT} /proc/tc3162/wps_button`
	if [ "${button_status}" = "0" ];then
		return
	fi
	${ECHO} 1 > "/tmp/run_security_bt"

	#button start AOSS
	${NVRAM} set WIFIAOSSAction_tmp=${aoss_tmp}
	if [ "`${NVRAM} get WIFIAOSSButtonEnable`" = "1" ];then
		${NVRAM} set UI_PRE_AOSS_STATUS=${aoss_tmp}
		aoss_button
		${NVRAM} set apply_running=1
		if [ "${Current_WPS_ENABLE}" = "0" ];then
	   		${AOSS_LED} Connect
			${NVRAM} unset apply_running
			${NVRAM} set aoss_running=1
		fi
		flag=1
	else
		/usr/bin/logger "[AOSS AOSS disable Exit]"
	fi

	#button star WPS
	if [ "${Current_WPS_ENABLE}" = "1" ];then
		${NVRAM} set apply_running=1
		if [ "${flag}" = "0" ];then
			${AOSS_LED} Connect
			${NVRAM} unset apply_running
			${NVRAM} set wps_running=1
		else
			${AOSS_LED} Connect
		fi
		PCB_function
	elif [ "${flag}" = "0" ];then 
		${ECHO} 0 > /proc/tc3162/wps_button
		${RM} /tmp/run_security_bt 2>/dev/null
	fi
	${RM} /tmp/run_security_bt 2>/dev/null
}

reConnction()
{
	sleep ${2}
	${ECHO} "============================================"  >> ${DEBUG_LOG}
	${ECHO} "send reconnect to ra${1} Wireless interface" >> ${DEBUG_LOG}
	${WLAN_SET} assoclist display -i ${1} |grep -v No|cut -d " " -f2|grep -v no >/tmp/reConnect.txt
	cat /tmp/reConnect.txt | while read line
	do
		MAC="`echo $line | grep -v MAC|cut -d" " -f 1`"
		if [ "${MAC}" != "" -a "x`${ECHO} ${MAC}|grep :`" != "x" ];then
			iwpriv ra${1} set DisConnectSta=${MAC}
			${ECHO} "send reconnect to ra${1} :${MAC}" >> ${DEBUG_LOG}
		fi
	done
}
reActive()
{
	sleep ${1}
	if [!  -e "/tmp/DNI_wireless_info" ];then
		cp /proc/DNI_wireless_info /tmp/DNI_wireless_info
	fi
	if [ ! -s "/tmp/DNI_wireless_info" ];then
		cp /proc/DNI_wireless_info /tmp/DNI_wireless_info
	fi
	if [ "`cat /proc/DNI_wireless_info|grep HTMIX`" != "" ];then
		cp /proc/DNI_wireless_info /tmp/DNI_wireless_info
	fi
	
	
	cat /tmp/DNI_wireless_info | while read line
	do
		MAC="`echo $line | grep -v MAC|cut -d" " -f 1`"
		if [ "${MAC}" != "" ];then
			for ii in 1 2 3 ...
			do
				iwpriv ra0 set DisConnectSta=${MAC}
				iwpriv ra1 set DisConnectSta=${MAC}
				iwpriv ra2 set DisConnectSta=${MAC}
				iwpriv ra3 set DisConnectSta=${MAC}
			done
		fi
	done
	
}

main()
{
	${ECHO} "Wireless Configing...."
	if [ "$1" = "start" ]; then
		RADIO=`${NVRAM} get WIFIModuleEnable`
		if [ "$RADIO" = "1" ]; then
			if [ "x`cat /proc/modules|/bin/grep rt3390ap|/bin/grep -v tccicmd|/bin/grep -v tcledctrl|/bin/grep -v grep|/usr/bin/cut -d" " -f1`" = "x" ];then
				${ECHO} "@@Insmod wireless module..."
				${NVRAM} unset RESTART_WEP
				${NVRAM} unset RESTART_AES
				${NVRAM} unset RESTART_TKIP
				${NVRAM} unset RESTART_FIXED
				${NVRAM} unset RESET_CHNNEL
				${INSMOD} /lib/modules/2.6.22/rt3390ap.ko
				${IFCONFIG} ra0 up
				brctl setbridgeprio br0 0
				brctl sethello br0 1
				brctl setmaxage br0 3
				brctl setfd br0 3
				#${IFCONFIG} ra0 down
			else
				if [ "x`${NVRAM} get RESTART_TKIP`" = "x" ];then
					reConnction 0 1
				fi
				if [ "x`${NVRAM} get RESTART_AES`" = "x" ];then
					reConnction 1 1
				fi
				if [ "x`${NVRAM} get RESTART_WEP`" = "x" ];then
					reConnction 2 1
				fi
				if [ "x`${NVRAM} get RESTART_FIXED`" = "x" ];then
					reConnction 3 1
				fi
			fi
			${ECHO} 0 >/proc/DNI_AOSS_status
			if [ "${2}" = "all" ];then
				${NVRAM} unset RESTART_WEP
				${NVRAM} unset RESTART_AES
				${NVRAM} unset RESTART_TKIP
				${NVRAM} unset RESTART_FIXED
				${NVRAM} unset RESET_CHNNEL
			fi
			if [ "`${NVRAM} get WIFI_TEST`" = "1" ];then
				${IWPRIV} ra0 set BasicRate=`${NVRAM} get WIFIBasicRate` #n/b/g mode
				${IWPRIV} ra0 set WirelessMode=`${NVRAM} get WIFI54gMode` #n/b/g mode
			fi
			
#for test_A
#nvram unset RESTART_WEP
#nvram set RESTART_WEP=1
#nvram set RESTART_AES=1
#nvram set RESTART_TKIP=1
#nvram set RESTART_FIXED=1
			if [ "${BOARD_INOF_REGION}" = "EU" ];then
				${IFCONFIG} "`${NVRAM} get WIFIAOSS_ifname`" down
			fi
			if [ "`${NVRAM} get WIFIAOSSAction`" = "1" ];then
				/etc/rc.d/wifi_separate.sh stop
				${ECHO} 1 >/proc/DNI_AOSS_status
				aoss_start ${2}
			else
				Basic_settings
				Adv_settings
				macFilter
				#Applications start
				/etc/rc.d/wifi_separate.sh restart
			fi
			
			${NVRAM} unset RESTART_WEP
			${NVRAM} unset RESTART_AES
			${NVRAM} unset RESTART_TKIP
			${NVRAM} unset RESTART_FIXED
			${NVRAM} commit
			${ECHO} ${sys_uptime} > /tmp/WLAN_uptime
		else
			cp /proc/DNI_wireless_info /tmp/DNI_wireless_info
			${NVRAM} unset RESTART_WEP
			${NVRAM} unset RESTART_AES
			${NVRAM} unset RESTART_TKIP
			${NVRAM} unset RESTART_FIXED
			WMM STOP
			Wps stop
			#if [ "`${NVRAM} get AOSS_ERROR_STATUS`" != "1" ];then
				ledcontrol -n security -s off
			#fi
			${NVRAM} unset AOSS_ERROR_STATUS
			if [ -e /tmp/aossCounter ];then
				kill -9 $(cat /tmp/aossCounter)
			fi
			${ECHO} 0 >/proc/DNI_AOSS_status
			
			
			${IFCONFIG} ra0 down
			${IFCONFIG} ra1 down
			${IFCONFIG} ra2 down
			${IFCONFIG} ra3 down
			BRIDGE delif ra0
			BRIDGE delif ra1
			BRIDGE delif ra2
			BRIDGE delif ra3
			if [ "x`cat /proc/modules|grep rt3390ap|grep -v tccicmd|grep -v tcledctrl|cut -d" " -f1`" != "x" ];then
			${RMMOD} rt3390ap
			fi
		fi
	else
		${ECHO} 0 >/proc/DNI_AOSS_status
		cp /proc/DNI_wireless_info /tmp/DNI_wireless_info
		${NVRAM} unset RESTART_WEP
		${NVRAM} unset RESTART_AES
		${NVRAM} unset RESTART_TKIP
		${NVRAM} unset RESTART_FIXED
		WMM STOP
		Wps stop
		if [ "`${NVRAM} get AOSS_ERROR_STATUS`" != "1" ];then
			ledcontrol -n security -s off
		fi
		${IFCONFIG} ra0 down
		${IFCONFIG} ra1 down
		${IFCONFIG} ra2 down
		${IFCONFIG} ra3 down
		#${IFCONFIG} br0 down
		BRIDGE delif ra0
		BRIDGE delif ra1
		BRIDGE delif ra2
		BRIDGE delif ra3		
		
		${RMMOD} rt3390ap
	fi
}
security_led_check()
{
	
	cp /proc/DNI_wireless_security /tmp/wlan_security
	i=0
	sleep 1
	cat /tmp/wlan_security | while read line
	do
		s1="`echo $line | grep TKIP`"
		s2="`echo $line |grep AES`"
		s3="`echo $line |grep WEP`"
		if [ "`ifconfig|grep ra${i}`" != "" ];then
			if [ "${s1}" != "" -o "${s2}" != "" -o "${s3}" != "" ];then
				led_flag="1"
				${AOSS_LED} enabled
				echo "1" >/tmp/tmp_led_security
				break
			fi
		fi
		i=$((${i}+1))
	done
	
	if [ ! -e /tmp/tmp_led_security ];then
		${AOSS_LED} disabled
	fi
	rm /tmp/tmp_led_security 2>/dev/null
}
multi_interface_test()
{
	${NVRAM} unset RESTART_WEP
	${NVRAM} unset RESTART_AES
	${NVRAM} unset RESTART_TKIP
	${NVRAM} unset RESTART_FIXED
	#${NVRAM} set RESTART_FIXED=1
	if [ "`${NVRAM} get WIFIAOSSAction`" = "1" ];then
		#/etc/rc.d/wifi_separate.sh stop
		aoss_start ${2}
	else
		Basic_settings
		#Adv_settings
		#macFilter
		#Applications start                
		#/etc/rc.d/wifi_separate.sh restart
	fi
	${NVRAM} unset RESTART_WEP
	${NVRAM} unset RESTART_AES
	${NVRAM} unset RESTART_TKIP
	${NVRAM} unset RESTART_FIXED
}
case "$1" in 
	start)
		main start ${2}
		;;  
	stop)
		main stop
		;;
	restart)
		main stop
		WMM_FILE
		main start
		;;
	wps)
		Wps stop
		Wps start
		;;
	filter)
		macFilter
		;;
	wmm_restart)
		main stop
		WMM_FILE
		main start
		;;
	wmm_file)
		WMM_FILE
		;;
	aossclist)
		AosscList
		;;
	attachdev)
		Attachdev
		;;
	enrollee)
		wps_enrollee
		;;
	security_button)
	echo "security_button"

	${RM} /tmp/hw_button_ttmp 2>/dev/null
	if [ "`${NVRAM} get ECO_state`" != "normal" ]; then
		/usr/sbin/get_ctime
		${NVRAM} set ECO_resuming=1
		/etc/rc.d/blk_eco.sh normal
		${ECHO} 0 > /proc/tc3162/wps_button
		rm /tmp/run_security_bt
		return
	fi
	if [ "`ps -ef|grep 'aoss -i'|grep -v grep|head -1|awk '{print $1}'`" != "" -a ! -e /tmp/run_security_bt ]; then
		${ECHO} 0 > /proc/tc3162/wps_button
		return
	fi

	AOSS_ERROR="`${NVRAM} get AOSS_INPUT_ERROR`"
	enWireless="`${NVRAM} get WIFIModuleEnable`"
	if [ "${enWireless}" = "0" ];then
		${AOSS_LED} disabled
		${ECHO} 0 > /proc/tc3162/wps_button
		/usr/bin/logger "[AOSS AOSS cannot be executed(Wireless disabled)]"
		rm /tmp/run_security_bt
	elif [ "${enWireless}" = "1" -a "${AOSS_ERROR}" = "0" ]; then
		SecurityButton
	elif [ "`${NVRAM} get WIFIAOSSButtonEnable`" = "0" -a "${enWireless}" = "1" ];then
		SecurityButton
	elif [ "${AOSS_ERROR}" != "0" ];then
		if [ "${AOSS_ERROR}" = "1" ];then
			/usr/bin/logger "[AOSS AOSS Invalid ESSID Error: White space in ESSID]"
		elif [ "${AOSS_ERROR}" = "2" ];then
			/usr/bin/logger "[AOSS AOSS Invalid PSK Error: White space in PSK]"
		elif [ "${AOSS_ERROR}" = "3" ];then
			/usr/bin/logger "[AOSS AOSS Invalid PSK Error: PSK exceeded 63 characters]"
		fi
		#/usr/bin/logger "[AOSS AOSS End, restart AccessPoint]"
		#${AOSS_LED} error
		LED_ERROR
		${ECHO} 0 > /proc/tc3162/wps_button
		rm /tmp/run_security_bt
	fi
	;;
	aoss_web)
	if [ "`${NVRAM} get WIFIModuleEnable`" = "1" ]; then
		#${ECHO} 99 > /proc/tc3162/led_security
		#pid="`ps -ef|grep 'aoss_counter.sh'|grep -v grep|head -1|awk '{print $1}`"
		#kill -1 ${pid}
		${NVRAM} unset AOSS_ERROR_STATUS
		led_security_web_bt
		${NVRAM} set aoss_running=1

		aoss_button
	else
		${NVRAM} set WIFIAOSSAction=0
		${NVRAM} unset aoss_running
	fi
	;;
	aoss)
		aoss_start
      		;;
	aoss_filter)
		aoss_macFilter	
		;;
	calc_WC)
		calc_wireless_client	
		;;
	update_ACT)
		update_AOSS_Client_tables ${2}	
		;;
	security_led)
		#button trigger
		led_security
     		;;
     	send_reconnect)
     		 reConnction ${2} 1
     		;;
     	advSettings)
     		main stop
     		WMM_FILE
     		Adv_settings
     		main start
     		;;
     	check)
		aossKeySync
		;;
	error_led)		
		LED_ERROR
		;;
	led_security)
		security_led_check
		;;
	addFilter)
		addFilterAossTables ${2} ${3}
		;;
	test)
		#security_led_check
		aossKeySync
		#EU_S_aossKeySync
		#reActive 10
		#reConnction 0 1
		#multi_interface_test
		;;
esac
