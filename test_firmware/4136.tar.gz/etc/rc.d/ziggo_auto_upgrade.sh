#!/bin/sh
#For JWNB2100-1ZGNLS(Ziggo) auto check firmware upgrade randomly between 2 a.m. - 2.30 a.m. GMT +1
. /www/cgi-bin/functions.sh
. /www/cgi-bin/webupgrade.sh

CRON_CONF_DIR_TMP=/tmp/crontabs
CRON_CONF_FILE_JWNB2100_TMP="$CRON_CONF_DIR_TMP"/JWNB2100_auto_upgrade
upgrade_date=0
adjust_time_zone() {
	time_zone=`nvram get ntp_hidden_select`
	case "$time_zone" in 
		0)
			upgrade_date="13"
			;;
		1)
			upgrade_date="14"
			;;
		2)
			upgrade_date="15"
			;;
		3)
			upgrade_date="16"
			;;
		4)
			upgrade_date="17"
			;;
		5)
			upgrade_date="18"
			;;
		6)
			upgrade_date="18"
			;;
		7)
			upgrade_date="19"
			;;
		8)
			upgrade_date="19"
			;;
		9)
			upgrade_date="20"
			;;
		10)
			upgrade_date="20"
			;;
		11)
			upgrade_date="21"
			;;
		12)
			upgrade_date="22"
			;;
		13)
			upgrade_date="23"
			;;
		14)
			upgrade_date="0"
			;;
		15)
			upgrade_date="1"
			;;
		16)
			upgrade_date="1"
			;;
		17)
			upgrade_date="2"
			;;
		18)
			upgrade_date="2"
			;;
		19)
			upgrade_date="2"
			;;
		20)
			upgrade_date="2"
			;;
		21)
			upgrade_date="3"
			;;
		22)
			upgrade_date="3"
			;;
		23)
			upgrade_date="3"
			;;
		24)
			upgrade_date="4"
			;;
		25)
			upgrade_date="4"
			;;
		26)
			upgrade_date="5"
			;;
		27)
			upgrade_date="6"
			;;
		28)
			upgrade_date="6.5"
			;;
		29)
			upgrade_date="7"
			;;
		30)
			upgrade_date="8"
			;;
		31)
			upgrade_date="9"
			;;
		32)
			upgrade_date="9"
			;;
		33)
			upgrade_date="10"
			;;
		34)
			upgrade_date="11"
			;;
		35)
			upgrade_date="11"
			;;
		36)
			upgrade_date="12"
			;;
		37)
			upgrade_date="13"
			;;
	esac
	
	/sbin/flash random jwnb2100_rand
	sleep 1
	rand=`[ -f /tmp/jwnb2100_rand ] && cat /tmp/jwnb2100_rand || echo "0"`
	if [ "$time_zone" = "28" ]; then
		rand=$(($rand+30))
	fi
	
	echo "$rand" "$upgrade_date" "* *" "0,1,2,3,4,5,6," "/etc/rc.d/ziggo_auto_upgrade.sh" "upgrade" > "$CRON_CONF_FILE_JWNB2100_TMP"
	rm -rf /tmp/jwnb2100_rand
}

do_upgrade()
{
	/www/cgi-bin/test_wan_status.sh firmware &> /dev/null &
	sleep 1
	[ -e /tmp/determine_wan_fail ] && exit 0
	sleep 1
	is_new=0
	while [ "$is_new" != "9999" ]
	do
		WEBUPGRADE_STAGE_1=`cat /tmp/webupgrade_status | awk -F ":" '{print $1}'`
		if [ "$WEBUPGRADE_STAGE_1" = "download_control_file" ]; then
			is_new=`cat /tmp/webupgrade_status | awk -F ":" '{print $2}'`
			if [ "$is_new" -gt "9999" ]; then
				exit 0
			fi
		fi
	done
	/www/cgi-bin/webupgrade_get_image.sh &> /dev/null &
	status=0
	while [ "$status" -lt "9999" ]
	do
		WEBUPGRADE_STAGE_2=`cat /tmp/webupgrade_status | awk -F ":" '{print $1}'`
		if [ "$WEBUPGRADE_STAGE_2" = "download_image_file" ]; then
			status=`cat /tmp/webupgrade_status | awk -F ":" '{print $2}'`
		fi
	done
	#imginstall &
	imginstall /tmp/netgear-jwnb2100-1zgnls-image 0 &
	sleep 3
	y=0
	while [ "$y" -le "30" ]
	do
		success=`[ -f /tmp/fw_success ] && cat /tmp/fw_success || echo "0"`
		y=$(($y+1))
		if [ "$success" != "1" ]; then
			sleep 2
		else
			[ -f /tmp/reboot ] && /tmp/reboot || /sbin/reboot
			break;
		fi
	done 
}

start() {
	echo "Starting ziggo auto upgrade schedule ..."
	adjust_time_zone
	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	rm -rf "$CRON_CONF_FILE_JWNB2100_TMP"
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  upgrade)
	do_upgrade
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|upgrade}"
	exit 1
esac

exit $RETVAL

