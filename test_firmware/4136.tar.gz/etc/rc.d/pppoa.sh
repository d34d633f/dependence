#!/bin/sh

#[ -f /usr/local/sbin/pppd ] || exit 0

RETVAL=0

prog="pppd"
NVRAM="/usr/sbin/nvram"
CALL_FILE="provider_pppoe_1492"
IP_UP="/etc/ppp/ip-up"
IP_DOWN="/etc/ppp/ip-down"
PLUG_IN="plugin pppoatm.so"

if [ "$2" = "manual" ] || [ "$2" = "manually" ]; then
      iface=""  
      manual=$2        
else
      iface=$2
      manual=$3
fi

WAN_INFO=/tmp/wan/wan${iface}
if [ "$iface" = "" ];  then
    PID_FILE="/var/run/ppp0.pid"
else 
    PID_FILE="/var/run/ppp${iface}.pid"
fi

wan_ifname=`nvram get wan${iface}_hwifname`
user=`nvram get wan${iface}_pppoe_username`
password=`nvram get wan${iface}_pppoe_passwd`
#mru=`nvram get wan${iface}_pppoe_mtu`
#mtu=`nvram get wan${iface}_pppoe_mtu`
mru=`nvram get wan${iface}_pppoa_mtu`
mtu=`nvram get wan${iface}_pppoa_mtu`
idle=`nvram get wan${iface}_pppoe_idletime`
demand=`nvram get wan${iface}_pppoe_demand`
dns_assign=`nvram get wan${iface}_pppoe_dns_assign`
keepalive_time=`nvram get wan_pppoe_keepalive_time`
pppoe_netmask=`nvram get wan${iface}_pppoe_netmask`
wan_default_iface=`nvram get wan_default_iface`
wan_phy_auto=`nvram get wan_phy_auto`

if [ "$iface" != "" ]; then
        iface_num="iface_num ${iface} unit ${iface}"
fi

if [ "$iface" = "$wan_default_iface" ]; then
        defaultroute="defaultroute"
        if [ "$wan_phy_auto" = "1" ] && [ "$iface" = "$wan_default_iface" ]; then
                    if [ "$demand" = "1" ]; then                             
                            ip route del default table 20${iface}
                    fi
        fi
else
        defaultroute=""
fi

if [ "$pppoe_netmask" = "" ]; then
	pppoe_netmask="0.0.0.0"
fi

if [ "$demand" = "0" ]; then ## Always ON ##
	persist_demand="persist"
	keep_alive=$keepalive_time
	lcp_echo_fails="3";
	idle="0"
elif [ "$demand" = "1" ]; then ## Dial on Demand ##
	if [ "$idle" = "0" ]; then
		persist_demand="persist"
		keep_alive="0";
		lcp_echo_fails="0";
	else
		persist_demand="demand"
		keep_alive=$keepalive_time
		lcp_echo_fails="3";
		echo 1 > /proc/sys/net/ipv4/ip_forward
	fi
else
	persist_demand="persist"	# for maual trigger 
	idle="0"
        keep_alive="0";
   	lcp_echo_fails="0";
fi

if [ "$dns_assign" = "0" ]; then
	usepeerdns="usepeerdns"
else
	usepeerdns=""
fi

if [ "$mtu" = "0" ]; then
	mru="1492";
        mtu="1492";
fi

start() {
	# Start daemons.
	echo $"Starting pppoa${iface}:"

        echo "pppoa" > ${WAN_INFO}

        pvc_item=$($NVRAM get "atmPVC${iface}")
        echo "pvc_item=$pvc_item"

        vpi=`echo "$pvc_item" | awk -F* '{print $2}'` 
        vci=`echo "$pvc_item" | awk -F* '{print $3}'` 
        multiplexing=`echo "$pvc_item" | awk -F* '{print $4}'` 
        atmqos="UBR,aal5:max_pcr=0,min_pcr=0"
 
        if [ "$multiplexing" = "0" ]; then
            ENCAP_T=llc-encaps
        else
            ENCAP_T=vc-encaps
        fi

	if [ "$manual" != "manual" ] && [ "$manual" != "manually" ]; then
		if [ "$demand" = "2" ]; then
			echo "Run Manual Connect...."
			RETVAL=$?
			return $RETVAL
		fi
	fi 

        if [ "$manual" = "manual" ] || [ "$manual" = "manually" ]; then
              demandex="demandex"
	fi		
	
	#do dial-on-demand and bring link up when starting
	if [ "`nvram get demandex`" = "1" ]; then
		nvram unset demandex	
		demandex="demandex"
	fi
  
        echo "${prog} user ${user} password ${password} holdoff 4 maxfail -1 ${PLUG_IN} $ENCAP_T $vpi.$vci mru ${mru} mtu ${mtu} ${persist_demand} ${demandex} idle ${idle} $usepeerdns ${defaultroute} lcp-echo-failure ${lcp_echo_fails} lcp-echo-interval ${keep_alive} qos ${atmqos} ${iface_num} noipdefault"
        ${prog} user "${user}" password "${password}" holdoff 4 maxfail -1 ${PLUG_IN} $ENCAP_T $vpi.$vci mru ${mru} mtu ${mtu} ${persist_demand} ${demandex} idle ${idle} $usepeerdns ${defaultroute} lcp-echo-failure ${lcp_echo_fails} lcp-echo-interval ${keep_alive} qos ${atmqos} ${iface_num} noipdefault
         
	RETVAL=$?
	echo
 
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting down pppoa${iface}: ${PID_FILE}"
   
	if [ -e ${PID_FILE} ]; then
              PID=`cat ${PID_FILE}`
        fi
	#echo $"Shutting down pppoa${iface}, PID: ${PID}"
        
        ppp_item=0
        for item in `ls /var/run/ | grep ppp | grep -v pppd | grep -v ppp${iface}`
        do
                ppp_item=$(($ppp_item+1))
        done       	    

	if [ "$PID" != "" ]; then
		kill -1 ${PID}
		sleep 3
		kill -9 ${PID}
		#sleep 7
		#while true
		#do
		#	sleep 2
		#	ABC=`ps | grep ${PID}`
		#	if [ "x${ABC}" != "x${PID}" ]; then
		#		break;
		#	else
		#		echo "@@ ${PID_FILE}: pppd ${PID} not kill, ${ABC}"
   		#    	kill -9 ${PID}
		#	fi
		#done
	fi

        if [ -e ${PID_FILE} ]; then
		rm -f ${PID_FILE}
	fi

        if [ -f /var/run/pppd.pid ] && [ "$ppp_item" = "0" ]; then
                rm /var/run/pppd.pid
        fi

	ETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

