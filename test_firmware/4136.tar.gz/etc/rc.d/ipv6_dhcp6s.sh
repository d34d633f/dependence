#!/bin/sh
IFACE=$2
RETVAL=0
prog="/usr/sbin/dhcp6s"
nvram="/usr/sbin/nvram"
IPv6_FILE="/proc/net/if_inet6"
CONFIG_FILE="/tmp/dhcp6s${IFACE}.config"
LAN_IF_NAME=`$nvram get lan${IFACE}_ifname`
IPV6_WAN_TYPE=`$nvram get ipv6_type`
DHCP_SERVER_MODE=`$nvram get dhcp_server_mode`
LAN_IPV6=`ifconfig ${LAN_IF_NAME} | grep Scope:Link | awk '{printf $3}' | awk -F/ '{printf $1}'`

start() {

	# get lan ip that Global Scope:"00"
	TMP_LAN_IPV6=`cat $IPv6_FILE | grep ${LAN_IF_NAME} | awk '{print $1":"$4}' | awk -F: '/:00/{print $1}'`
	HEX_PRELEN=`cat $IPv6_FILE | grep ${LAN_IF_NAME} | awk '{print $1":"$4"/"$3}' | awk -F/ '/:00/{print $2}'`
	if [ -n "$TMP_LAN_IPV6" ];then
		if [ "$HEX_PRELEN" != "80" ];then
		# get lan prefix that Global Scope:"00"
		TMP_PRELEN=`printf "%d" 0x$HEX_PRELEN`
		REMAINDER=`expr $TMP_PRELEN % 4`
		HEX_LEN=`expr $TMP_PRELEN / 4`
		I=0

		# get normal prefix
		while [ "$I" -lt "$HEX_LEN" ]
		do
			I=`expr $I + 1`
			EACH_CHAR=`expr substr "$TMP_LAN_IPV6" $I 1`
			PRE_LAN_IPV6="${PRE_LAN_IPV6}${EACH_CHAR}"
			BIT_16=`expr $I % 4`
			if [ "$BIT_16" = "0" ];then
				PRE_LAN_IPV6=`printf "%s:" $PRE_LAN_IPV6`
			fi
		done

		#get last char prefix if ((prefix%4) != 0)
		#REMAINDER=`expr $REMAINDER + 1`
		if [ "$REMAINDER" != "0" ];then
			I=`expr $I + 1`
			LAST_CHAR=`expr substr "$TMP_LAN_IPV6" $I 1`
			case $REMAINDER in
				"1")
					LAST_CHAR=$((LAST_CHAR & 8))
				;;
				"2")
					LAST_CHAR=$((LAST_CHAR & 12))
				;;
				"3")
					LAST_CHAR=$((LAST_CHAR & 14))
				;;
			esac
			LAST_CHAR=`printf "%x" $LAST_CHAR`
			PRE_LAN_IPV6="$PRE_LAN_IPV6$LAST_CHAR"
			BIT_16=`expr $I % 4`
			if [ "$BIT_16" = "0" ];then
				PRE_LAN_IPV6=`printf "%s:" $PRE_LAN_IPV6`
			fi
			#BIT_16=`expr $BIT_16 + 1`
			#if [ "$BIT_16" = "0" ];then
			#	PRE_LAN_IPV6=`printf "%s000:" $PRE_LAN_IPV6`
			#fi
		fi

		#To let prefix be set of 16 bit
		#BIT_16=`expr $BIT_16 + 1`
		if [ "$BIT_16" != "0" ];then
			case $BIT_16 in
				"1")
					PRE_LAN_IPV6=`printf "%s000:" $PRE_LAN_IPV6`
				;;
				"2")
					PRE_LAN_IPV6=`printf "%s00:" $PRE_LAN_IPV6`
				;;
				"3")
					PRE_LAN_IPV6=`printf "%s0:" $PRE_LAN_IPV6`
				;;
			esac
		#echo $PRE_LAN_IPV6
		fi
		fi
	fi
	IPV6_LAN_DHCP=`$nvram get ipv6_dhcps_enable`
	echo "Start DHCPv6 Server ..."
#	echo 0 > /proc/sys/net/ipv6/conf/all/autoconf
   	echo 'option domain-name-servers '$LAN_IPV6';' > $CONFIG_FILE
#	echo 'option domain-name "testing.net";' >> $CONFIG_FILE
	if [ -n "$PRE_LAN_IPV6" ] && [ "$IPV6_LAN_DHCP" = "1" ];then
		echo 'interface '$LAN_IF_NAME' {' >> $CONFIG_FILE
		echo '	  allow rapid-commit;' >> $CONFIG_FILE
		echo '    address-pool mynetwork 3600;' >> $CONFIG_FILE
		echo '};' >> $CONFIG_FILE
	   	echo 'pool mynetwork {' >> $CONFIG_FILE
		echo '	range '$PRE_LAN_IPV6':2 to '$PRE_LAN_IPV6':500;' >> $CONFIG_FILE
  	 	echo '};' >> $CONFIG_FILE
		#if [ "$DHCP_SERVER_MODE" = "have_host" ];then
   		#	echo 'host myhost {' >> $CONFIG_FILE
   		#	echo '   duid 00:11:22:33:44:55;' >> $CONFIG_FILE
   		#	echo '   prefix '$PREFIX48':e472::/64 infinity;' >> $CONFIG_FILE
   		#	echo '};' >> $CONFIG_FILE
		#fi
	fi

	$prog -c $CONFIG_FILE $LAN_IF_NAME

	RETVAL=$?
	return $RETVAL
}

stop() {

	echo "Stop DHCPv6 Server ..."
	killall dhcp6s
	if [ -e "$CONFIG_FILE" ];then
		rm $CONFIG_FILE
	fi
#	echo 0 > /proc/sys/net/ipv6/conf/all/forwarding
#	echo 1 > /proc/sys/net/ipv6/conf/all/autoconf
	RETVAL=$?
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart|reload)
    stop
    start
    RETVAL=$?
    ;;
  *)
    echo $"Usage: $0 {start|stop|restart}"
    exit 1
esac

exit $RETVAL

