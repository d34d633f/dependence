
#!/bin/sh
# this script is used to control management control list function

#[ -f /bin/iptables ] || exit 0

RETVAL=0

#iptables="iptables"
wan_phy_mode=`nvram get wan_phy_mode`
if [ "$wan_phy_mode" != "adsl" ]; then
    lan_ifname=`nvram get lan_ifname`
else
    lan_ifname="br+"
fi
blk_svc_enable=`nvram get blockserv_ctrl`
BLOCK_SVC=fwd_block_svc

LOG_PREFIX=[type2]

# filter_client0=ip-ip:dp-dp,tcp[udp][both],0-6-0-23,on/off,block(0->always)
#---------------------------------------------------------------------------
#block_services1=FTP TCP 20 21 FTP 2 all
#block_services2=HTTP TCP 80 80 HTTP 1 192.168.1.10-192.168.1.20
#block_services3=Telnet TCP 23 23 Telnet 0 192.168.1.100
#---------------------------------------------------------------------------
TARGET=""
ACT=""

svc_proto=""
svc_dport_s=""
svc_dport_e=""
svc_desc=""
svc_desc=""
svc_filter=""
src_ip=""
dst_filter=""
dst_ip=""
action=""
is_log=""
endis=""

add_firewall()
{
        # protocal handler
	if [ "$svc_proto" = "TCP/UDP" ]; then
		proto="tcp"
		proto_other="udp"
	else
		proto=$svc_proto
		proto_other=""
	fi

        # destination port handler
	if [ "$svc_dport_s" != "$svc_dport_e" ]; then
		dport="$svc_dport_s:$svc_dport_e"
	else
		dport="$svc_dport_s"
	fi        

            if [ "$svc_filter" -eq "0" ]; then      # lan site any
                      if [ "$dst_filter" -eq "0" ]; then    # wan site any 
                                echo "is log = $is_log"
                                if [ "$proto" != "" ]; then
                                    if [ "$is_log" = "1" ]; then                                        
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -p $proto --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                    else
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -p $proto --dport $dport  -j $TARGET
                                    fi
        		        fi
                                if [ "$proto_other" != "" ]; then   # use for UDP
                                    if [ "$is_log" = "1" ]; then                                       
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -p $proto_other --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                    else
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -p $proto_other --dport $dport  -j $TARGET                                    
                                    fi
        		        fi
                        elif [ "$dst_filter" -eq "1" ]; then    # wan site single ip  
                                if [ "$proto" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -d $dst_ip -p $proto --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -d $dst_ip -p $proto --dport $dport  -j $TARGET
                                        fi
                		fi
                		if [ "$proto_other" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -d $dst_ip -p $proto_other --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -d $dst_ip -p $proto_other --dport $dport  -j $TARGET
                                        fi
                		fi              
                         elif [ "$dst_filter" -eq "2" ]; then   # wan site ip range 
                                if [ "$proto" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --dst-range $dst_ip -p $proto --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --dst-range $dst_ip -p $proto --dport $dport  -j $TARGET
                                        fi
                		fi
                		if [ "$proto_other" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --dst-range $dst_ip -p $proto_other --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --dst-range $dst_ip -p $proto_other --dport $dport  -j $TARGET
                                        fi
                		fi
                         fi
                elif [ "$svc_filter" -eq "1" ]; then  # lan single ip
                         if [ "$dst_filter" -eq "0" ]; then     # wan site any 
                                if [ "$proto" != "" ]; then
                                    if [ "$is_log" = "1" ]; then
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -p $proto --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                    else
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -p $proto --dport $dport  -j $TARGET
                                    fi
        		        fi
                                if [ "$proto_other" != "" ]; then
                                    if [ "$is_log" = "1" ]; then
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -p $proto_other --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                    else
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -p $proto_other --dport $dport  -j $TARGET
                                    fi
        		        fi
                        elif [ "$dst_filter" -eq "1" ]; then    # wan site single ip  
                                 if [ "$proto" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -d $dst_ip -p $proto --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -d $dst_ip -p $proto --dport $dport  -j $TARGET
                                        fi
                		fi
                		if [ "$proto_other" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -d $dst_ip -p $proto_other --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -d $dst_ip -p $proto_other --dport $dport  -j $TARGET
                                        fi
                		fi              
                         elif [ "$dst_filter" -eq "2" ]; then   # wan site ip range 
                                 if [ "$proto" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -m iprange --dst-range $dst_ip -p $proto --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                    			    iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -m iprange --dst-range $dst_ip -p $proto --dport $dport  -j $TARGET
                                        fi
                		fi
                		if [ "$proto_other" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -m iprange --dst-range $dst_ip -p $proto_other --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -s $src_ip -m iprange --dst-range $dst_ip -p $proto_other --dport $dport  -j $TARGET
                                        fi
                		fi
                         fi
                elif [ "$svc_filter" -eq "2" ]; then   # lan ip range
                          if [ "$dst_filter" -eq "0" ]; then    # wan site any 
                                if [ "$proto" != "" ]; then
                                    if [ "$is_log" = "1" ]; then
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -p $proto --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                    else
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -p $proto --dport $dport  -j $TARGET
                                    fi
        		        fi
                                if [ "$proto_other" != "" ]; then
                                    if [ "$is_log" = "1" ]; then
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -p $proto_other --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                    else
        			        iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -p $proto_other --dport $dport  -j $TARGET
                                    fi
        		        fi
                        elif [ "$dst_filter" -eq "1" ]; then    # wan site single ip  
                                if [ "$proto" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -d $dst_ip -p $proto --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -d $dst_ip -p $proto --dport $dport  -j $TARGET
                                        fi
                		fi
                		if [ "$proto_other" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -d $dst_ip -p $proto_other --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -d $dst_ip -p $proto_other --dport $dport  -j $TARGET
                                        fi
                		fi              
                         elif [ "$dst_filter" -eq "2" ]; then   # wan site ip range 
                            if [ "$proto" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -m iprange --dst-range $dst_ip -p $proto --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -m iprange --dst-range $dst_ip -p $proto --dport $dport  -j $TARGET
                                        fi
                		fi
                		if [ "$proto_other" != "" ]; then
                                        if [ "$is_log" = "1" ]; then
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -m iprange --dst-range $dst_ip -p $proto_other --dport $dport  -m log --log-prefix "$LOG_PREFIX[service blocked: $svc_desc]" -j $TARGET
                                        else
                			    iptables $ACT $BLOCK_SVC -i $lan_ifname -m iprange --src-range $src_ip -m iprange --dst-range $dst_ip -p $proto_other --dport $dport  -j $TARGET
                                        fi
                		fi
                         fi
                fi
}


check_is_subset_of_rules()
{
         cur_rule_num=$1
         k=1
         while true
         do               
                check_svc_entry=`nvram get block_services$k`
                 if [ "x$check_svc_entry" = "x" ];then
                                break;
                 fi                
                	
              	check_svc_proto=`echo $check_svc_entry | awk -F" " '{print $2}'`
               	check_svc_dport_s=`echo $check_svc_entry | awk -F" " '{print $3}'`
               	check_svc_dport_e=`echo $check_svc_entry | awk -F" " '{print $4}'`
               	check_svc_desc=`echo $check_svc_entry | awk -F" " '{print $5}'`
               	check_svc_desc=`echo $check_svc_desc | sed 's/\&harr\;/ /g'`
               	check_svc_filter=`echo $check_svc_entry | awk -F" " '{print $6}'`
               	check_src_ip=`echo $check_svc_entry | awk -F" " '{print $7}'`
                check_dst_filter=`echo $check_svc_entry | awk -F" " '{print $8}'`
                check_dst_ip=`echo $check_svc_entry | awk -F" " '{print $9}'`
                check_action=`echo $check_svc_entry | awk -F" " '{print $10}'`
                check_is_log=`echo $check_svc_entry | awk -F" " '{print $11}'`
                check_endis=`echo $check_svc_entry | awk -F" " '{print $12}'`

                if [ "$k" != "$cur_rule_num" ] && [ "$check_action" -le "1" ] && [ "$check_endis" = "1" ]; then
                        sub_port=0
                        if [ "$svc_dport_s" -ge "$check_svc_dport_s" ] && [ "$svc_dport_e" -le "$check_svc_dport_e" ];  then
                              sub_port=1
                        fi

                        sub_src_ip=0
                        if [ "$check_svc_filter" = "0" ]; then
                                    sub_src_ip=1
                        elif [ "$check_svc_filter" = "1" ]; then
                                     if [ "$svc_filter" = "1" ] && [ "$check_src_ip" = "$src_ip" ]; then
                                        sub_src_ip=1
                                     fi
                        elif [ "$check_svc_filter" = "2" ]; then
                                     check_src_start=`echo $check_src_ip | awk -F"-" '{print $1}'`
                                     check_src_end=`echo $check_src_ip | awk -F"-" '{print $2}'`
                                     s_check_pos1=`echo $check_src_start | awk -F"." '{print $1}'`
                                     s_check_pos2=`echo $check_src_start | awk -F"." '{print $2}'`
                                     s_check_pos3=`echo $check_src_start | awk -F"." '{print $3}'`
                                     s_check_pos4=`echo $check_src_start | awk -F"." '{print $4}'`
                        
                                     e_check_pos1=`echo $check_src_end | awk -F"." '{print $1}'`
                                     e_check_pos2=`echo $check_src_end | awk -F"." '{print $2}'`
                                     e_check_pos3=`echo $check_src_end | awk -F"." '{print $3}'`
                                     e_check_pos4=`echo $check_src_end | awk -F"." '{print $4}'`
                                     if [ "$svc_filter" = "1" ]; then
                                           pos1=`echo $src_ip | awk -F"." '{print $1}'`
                                           pos2=`echo $src_ip | awk -F"." '{print $2}'`
                                           pos3=`echo $src_ip | awk -F"." '{print $3}'`
                                           pos4=`echo $src_ip | awk -F"." '{print $4}'`
                                           if [ "$pos1" -ge "$s_check_pos1" ] && [ "$pos2" -ge "$s_check_pos2" ] && [ "$pos3" -ge "$s_check_pos3" ] && [ "$pos4" -ge "$s_check_pos4" ]; then
                                                if [ "$pos1" -le "$e_check_pos1" ] && [ "$pos2" -le "$e_check_pos2" ] && [ "$pos3" -le "$e_check_pos3" ] && [ "$pos4" -le "$e_check_pos4" ]; then
                                                    sub_src_ip=1                                                
                                                fi
                                           fi
                                     elif [ "$svc_filter" = "2" ]; then
                                            src_start=`echo $src_ip | awk -F"-" '{print $1}'`
                                            src_end=`echo $src_ip | awk -F"-" '{print $2}'`
                                            s_pos1=`echo $src_start | awk -F"." '{print $1}'`
                                            s_pos2=`echo $src_start | awk -F"." '{print $2}'`
                                            s_pos3=`echo $src_start | awk -F"." '{print $3}'`
                                            s_pos4=`echo $src_start | awk -F"." '{print $4}'`
                                            e_pos1=`echo $src_end | awk -F"." '{print $1}'`
                                            e_pos2=`echo $src_end | awk -F"." '{print $2}'`
                                            e_pos3=`echo $src_end | awk -F"." '{print $3}'`
                                            e_pos4=`echo $src_end | awk -F"." '{print $4}'`
                                            if [ "$s_pos1" -ge "$s_check_pos1" ] && [ "$s_pos2" -ge "$s_check_pos2" ] && [ "$s_pos3" -ge "$s_check_pos3" ] && [ "$s_pos4" -ge "$s_check_pos4" ]; then
                                                    if [ "$e_pos1" -le "$e_check_pos1" ] && [ "$e_pos2" -le "$e_check_pos2" ] && [ "$e_pos3" -le "$e_check_pos3" ] && [ "$e_pos4" -le "$e_check_pos4" ]; then
                                                            sub_src_ip=1      
                                                    fi
                                            fi
                                     fi                                                                      
                             fi

                             sub_dst_ip=0
                             if [ "$check_dst_filter" = "0" ]; then
                                    sub_dst_ip=1
                             elif [ "$check_dst_filter" = "1" ]; then
                                     if [ "$dst_filter" = "1" ] && [ "$check_dst_ip" = "$dst_ip" ]; then
                                        sub_dst_ip=1
                                     fi
                             elif [ "$check_dst_filter" = "2" ]; then
                                    check_dst_start=`echo $check_dst_ip | awk -F"-" '{print $1}'`
                                    check_dst_end=`echo $check_dst_ip | awk -F"-" '{print $2}'`
                                     s_check_pos1=`echo $check_dst_start | awk -F"." '{print $1}'`
                                     s_check_pos2=`echo $check_dst_start | awk -F"." '{print $2}'`
                                     s_check_pos3=`echo $check_dst_start | awk -F"." '{print $3}'`
                                     s_check_pos4=`echo $check_dst_start | awk -F"." '{print $4}'`
                        
                                     e_check_pos1=`echo $check_dst_end | awk -F"." '{print $1}'`
                                     e_check_pos2=`echo $check_dst_end | awk -F"." '{print $2}'`
                                     e_check_pos3=`echo $check_dst_end | awk -F"." '{print $3}'`
                                     e_check_pos4=`echo $check_dst_end | awk -F"." '{print $4}'`
                                     if [ "$dst_filter" = "1" ]; then
                                           pos1=`echo $dst_ip | awk -F"." '{print $1}'`
                                           pos2=`echo $dst_ip | awk -F"." '{print $2}'`
                                           pos3=`echo $dst_ip | awk -F"." '{print $3}'`
                                           pos4=`echo $dst_ip | awk -F"." '{print $4}'`
                                           if [ "$pos1" -ge "$s_check_pos1" ] && [ "$pos2" -ge "$s_check_pos2" ] && [ "$pos3" -ge "$s_check_pos3" ] && [ "$pos4" -ge "$s_check_pos4" ]; then
                                                if [ "$pos1" -le "$e_check_pos1" ] && [ "$pos2" -le "$e_check_pos2" ] && [ "$pos3" -le "$e_check_pos3" ] && [ "$pos4" -le "$e_check_pos4" ]; then
                                                    sub_dst_ip=1                                                
                                                fi
                                           fi
                                     elif [ "$dst_filter" = "2" ]; then
                                            src_start=`echo $dst_ip | awk -F"-" '{print $1}'`
                                            src_end=`echo $dst_ip | awk -F"-" '{print $2}'`
                                            s_pos1=`echo $src_start | awk -F"." '{print $1}'`
                                            s_pos2=`echo $src_start | awk -F"." '{print $2}'`
                                            s_pos3=`echo $src_start | awk -F"." '{print $3}'`
                                            s_pos4=`echo $src_start | awk -F"." '{print $4}'`
                                            e_pos1=`echo $src_end | awk -F"." '{print $1}'`
                                            e_pos2=`echo $src_end | awk -F"." '{print $2}'`
                                            e_pos3=`echo $src_end | awk -F"." '{print $3}'`
                                            e_pos4=`echo $src_end | awk -F"." '{print $4}'`
                                            if [ "$s_pos1" -ge "$s_check_pos1" ] && [ "$s_pos2" -ge "$s_check_pos2" ] && [ "$s_pos3" -ge "$s_check_pos3" ] && [ "$s_pos4" -ge "$s_check_pos4" ]; then
                                                    if [ "$e_pos1" -le "$e_check_pos1" ] && [ "$e_pos2" -le "$e_check_pos2" ] && [ "$e_pos3" -le "$e_check_pos3" ] && [ "$e_pos4" -le "$e_check_pos4" ]; then
                                                            sub_dst_ip=1      
                                                    fi
                                            fi
                                     fi                                                   
                                fi

                                if [ "$sub_port" = "1" ] && [ "$sub_src_ip" = "1" ] && [ "$sub_dst_ip" = "1" ]; then
                                        echo "1"
                                        return                               
                                fi
                fi

                 let k=$k+1  
         done

         echo "0"
}


start() 
{
	[ "`nvram get block_services1`" = "" ] && exit 0
        echo  $"Starting block services:"
	nvram set blk_svc_on=1				#used by blk_site.sh
        nvram set blockserv_ctrl=0
        set_blockserv_ctrl=0
	#echo 0 > /proc/sys/net/ipv4/ct_fast_forward	#4:Block Services doesn't work
	echo 0 > /proc/sys/net/ipv4/netfilter/ip_conntrack_tcp_forward_accept	#4:Block Services doesn't work

        SET_TYPE=$1
        SCHEDULE=$2

         j=1
        while true
        do
                svc_entry=`nvram get block_services$j`
                if [ "x$svc_entry" = "x" ];then
                        break;
                fi         

               	svc_proto=`echo $svc_entry | awk -F" " '{print $2}'`
        	svc_dport_s=`echo $svc_entry | awk -F" " '{print $3}'`
        	svc_dport_e=`echo $svc_entry | awk -F" " '{print $4}'`
        	svc_desc=`echo $svc_entry | awk -F" " '{print $5}'`
        	svc_desc=`echo $svc_desc | sed 's/\&harr\;/ /g'`
        	svc_filter=`echo $svc_entry | awk -F" " '{print $6}'`
        	src_ip=`echo $svc_entry | awk -F" " '{print $7}'`
                dst_filter=`echo $svc_entry | awk -F" " '{print $8}'`
                dst_ip=`echo $svc_entry | awk -F" " '{print $9}'`
                action=`echo $svc_entry | awk -F" " '{print $10}'`
                is_log=`echo $svc_entry | awk -F" " '{print $11}'`
                endis=`echo $svc_entry | awk -F" " '{print $12}'`
                  	                      
                if [ "$endis" = "1" ]; then
                        if [ "$action" = "1" ] || [ "$action" = "3" ] ; then   
                                if [ "$set_blockserv_ctrl" = "0" ]; then
                                    nvram set blockserv_ctrl=1
                                    set_blockserv_ctrl=1                                    
                                fi
                        fi

                        if [ "$action" = "0" ]; then
                                TARGET=DROP
                                ACT="-A"
                                echo "add block services, rule $j"
                                add_firewall 
                        elif [ "$action" = "2" ]; then
                                TARGET=ACCEPT
                                ACT="-A"
            
                                #ret=`check_is_subset_of_rules $j`
            
                                #if [ "$ret" = "1" ] || [ "$is_log" = "1" ]; then
                                #        echo "add allow block services, rule $j"
                                        add_firewall
                                #else
                                #        echo "can't set allow block services, rule $j"
                                #fi
                        elif [ "$action" = "1" ] && [ "$SET_TYPE" = "schedule" ]; then
                                if [ "$SCHEDULE" = "ontime" ]; then
                                        TARGET=DROP
                                else
                                        TARGET=ACCEPT
                                fi
                                ACT="-A"
                                echo "add schedule block services, rule $j"
                                add_firewall 
                        elif [ "$action" = "3" ] && [ "$SET_TYPE" = "schedule" ]; then
                                if [ "$SCHEDULE" = "ontime" ]; then
                                        TARGET=ACCEPT
                                else
                                        TARGET=DROP
                                fi
                                ACT="-A"
            
                                #ret=`check_is_subset_of_rules $j`
            
                                #if [ "$ret" = "1" ]; then
                                   #     echo "add schedule allow block services, rule $j"
                                        add_firewall
                                #else
                                   #     echo "can't set schedule allow block services, rule $j"
                                #fi
                        fi
                fi               

                let j=$j+1  
        done
}


stop() {

        echo  $"Shutting block services: Flush fwd_block_svc chain"
	nvram set blk_svc_on=0				#used by blk_site.sh
	#[ "`nvram get blk_site_on`" = "0" ] && echo 1 > /proc/sys/net/ipv4/ct_fast_forward #4:Block Services doesn't work
	[ "`nvram get blk_site_on`" = "0" ] && echo 1 > /proc/sys/net/ipv4/netfilter/ip_conntrack_tcp_forward_accept #4:Block Services doesn't work

	#[ "$blk_svc_enable" = "0" ] && exit 0
	iptables -F $BLOCK_SVC
}


start_by_sched() 
{
     j=1
     while true
     do
              svc_entry=`nvram get block_services$j`
              if [ "x$svc_entry" = "x" ];then
                    break;
             fi
             let j=$j+1  

            svc_proto=`echo $svc_entry | awk -F" " '{print $2}'`
    	    svc_dport_s=`echo $svc_entry | awk -F" " '{print $3}'`
    	    svc_dport_e=`echo $svc_entry | awk -F" " '{print $4}'`
    	    svc_desc=`echo $svc_entry | awk -F" " '{print $5}'`
    	    svc_desc=`echo $svc_desc | sed 's/\&harr\;/ /g'`
    	    svc_filter=`echo $svc_entry | awk -F" " '{print $6}'`
    	    src_ip=`echo $svc_entry | awk -F" " '{print $7}'`
            dst_filter=`echo $svc_entry | awk -F" " '{print $8}'`
            dst_ip=`echo $svc_entry | awk -F" " '{print $9}'`
            action=`echo $svc_entry | awk -F" " '{print $10}'`
            is_log=`echo $svc_entry | awk -F" " '{print $11}'`
            endis=`echo $svc_entry | awk -F" " '{print $12}'`

            # block by schedule
            if [ "$endis" = "1" ] && [ "$action" = "1" ]; then
                TARGET=DROP
                ACT="-A"
                add_firewall 
            fi          
    done
}

case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  start_by_sched)
	start schedule $2
	;;
  stop_by_sched)
	stop 
	;;
     test)
	convert_to_integer 192.0.0.0
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
   restart_by_sched)
	stop 
	start schedule $2
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

