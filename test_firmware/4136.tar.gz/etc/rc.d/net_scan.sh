#!/bin/sh

RETVAL=0

wan_phy_mode=`nvram get wan_phy_mode`

iface=$2

if [ "$iface" = "" ]; then
    br_ifname="br0"
else
    index=$(($iface-1))
    br_ifname="br$index"
fi

prog="net-scan"
PID_FILE="/var/run/net-scan${iface}.pid"

start() {
	[ -e ${PID_FILE} ] && exit 0
	# Start daemons.
        echo $"Starting $prog $br_ifname:"

        if [ "x$iface" = "x" ]; then
	    ${prog} -i ${br_ifname}
        else
            ${prog} -p ${iface} -i ${br_ifname}
        fi
	RETVAL=$?	
	return $RETVAL
}

stop() {
	# Stop daemons.
        echo $"Shutting down $prog $br_ifname:"

	if [ -e ${PID_FILE} ]; then
		kill -9 `cat ${PID_FILE}`
	fi
	rm -f ${PID_FILE}

	RETVAL=$?
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

