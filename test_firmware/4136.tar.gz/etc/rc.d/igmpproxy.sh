#!/bin/sh

#[ -f /usr/local/sbin/igmpproxy ] || exit 0

RETVAL=0
prog="igmpproxy"
PID_FILE="/var/run/igmpproxy.pid" #if the path/file changes, remember to modify snmp checking function
CONFIG_FILE="/var/igmpproxy.conf"
lan_ifname=`nvram get lan_ifname`
wan_ifname=`nvram get wan_ifname`
wan_hwifname=`nvram get wan_hwifname`
wan_proto=`nvram get wan_proto`

def_iface=`nvram get wan_default_iface`

lan_group=""	#multi lan group such as bridge, br[0-3].
wan_group=""	#multi wan such as wan[1-8].
wan_num=""
IS_MULTI_WAN=""

igmp_ver=`nvram get igmp_ver`
if [ "x$igmp_ver" = "x" ]; then
	igmp_ver="auto"
fi

## Initialize lan group ##
## igmpproxy only support 1 upstream interface. ##
if [ "$(nvram get wan_phy_mode)" = "adsl" ]; then
	lan_group_map=""
	wifi_group_map=""
    interface_group_map="`nvram get interface_group_map`"
	if [ "$interface_group_map" = ":::" ]; then
		## default wan interface ##
		return
		#IS_MULTI_WAN=""
	else
		## wan1 interface ##
		lan_group_map=`echo $interface_group_map | grep "eth"`
		wifi_group_map=`echo $interface_group_map | grep "ath"`
		wan_group_map=`echo $interface_group_map | grep "wan${def_iface}"`
		
		## igmpproxy in multi interfaces ##
		#if [ "y$lan_group_map" != "y" -o "z$wifi_group_map" != "z" ]; then
		## igmpproxy in single interface ##
		if [ "x$wan_group_map" != "x" ] && [ "y$lan_group_map" != "y" -o "z$wifi_group_map" != "z" ]; then
			IS_MULTI_WAN="1"
		else
			#IS_MULTI_WAN=""
			return
		fi
	fi
else
	IS_MULTI_WAN=""
fi

echo "xxx"

if [ "x$IS_MULTI_WAN" = "x" ]; then
	lan_ifname=`nvram get lan_ifname`
	wan_ifname=`nvram get wan_ifname`
	wan_hwifname=`nvram get wan_hwifname`
	wan_proto=`nvram get wan_proto`
fi

## igmpproxy in single-upstream interface ##
igmp_defalt_queue() {
	local i=$1
    local interface_group_map="`nvram get interface_group_map`"

	# Parsing Multi-WAN from Multi-LAN Group br[0-3] #
	wan_group=`echo $interface_group_map | cut -d":" -f $i | grep "wan${def_iface}"`
	if [ "x$wan_group" != "x" ]; then 
       	lan_group=`echo $interface_group_map | cut -d":" -f $i | grep "eth"`
       	wifi_group=`echo $interface_group_map | cut -d":" -f $i | grep "ath"`
		if [ "x$lan_group" != "x" -o "y$wifi_group" != "y" ]; then
			wan_num=`echo $wan_group | sed 's/^.*wan//g' | sed 's/|.*$//g'`
       		if [ "x$wan_num" != "x" ]; then
                        iptv_bridge=`nvram get iptv_bridge`
              		if [ "`cat /firmware_region`" = "GR" ] && [ "$iptv_bridge" != "1" ] && [ "$wan_num" = "1" ]; then
    				pvc_item=`nvram get atmPVC2`
				if [ "x$pvc_item" != "x" ];then
					ENABLE=`echo "$pvc_item" | awk -F* '{print $1}'`
					if [ "$ENABLE" = "1" ]; then
						wan_num="2"
					fi
			        fi
			fi
           		lan_ifname=`nvram get lan${i}_ifname`
				wan_ifname=`nvram get wan${wan_num}_ifname`
				wan_hwifname=`nvram get wan${wan_num}_hwifname`
				wan_proto=`nvram get wan${wan_num}_proto`
				wan_pppoe_netmask= `nvram get wan${wan_num}_pppoe_netmask`
				wan_pppoe_wan_assign=`nvram get wan${wan_num}_pppoe_wan_assign`
			else # Incorrect WAN Number #
        		wan_group=""
				wan_num=""			
       		fi
		else # Empty LAN #
        	wan_group=""
			wan_num=""			
		fi
	else # Empty WAN #
        wan_group=""
		wan_num=""
	fi
}

## igmp in multi-upstream interfaces ##
igmp_multi_queue() {
	local i=$1
    local interface_group_map="`nvram get interface_group_map`"

	# Parsing Multi-WAN from Multi-LAN Group br[0-3] #
	wan_group=`echo $interface_group_map | cut -d":" -f $i | grep "wan"`
	if [ "x$wan_group" != "x" ]; then 
       	lan_group=`echo $interface_group_map | cut -d":" -f $i | grep "eth"`
       	wifi_group=`echo $interface_group_map | cut -d":" -f $i | grep "ath"`
		if [ "x$lan_group" != "x" -o "y$wifi_group" != "y" ]; then
			wan_num=`echo $wan_group | sed 's/^.*wan//g' | sed 's/|.*$//g'`
       		if [ "x$wan_num" != "x" ]; then
           		lan_ifname=`nvram get lan${i}_ifname`
				wan_ifname=`nvram get wan${wan_num}_ifname`
				wan_hwifname=`nvram get wan${wan_num}_hwifname`
				wan_proto=`nvram get wan${wan_num}_proto`
				wan_pppoe_netmask= `nvram get wan${wan_num}_pppoe_netmask`
				wan_pppoe_wan_assign=`nvram get wan${wan_num}_pppoe_wan_assign`
			else # Incorrect WAN Number #
        		wan_group=""
				wan_num=""			
       		fi
		else # Empty LAN #
        	wan_group=""
			wan_num=""			
		fi
	else # Empty WAN #
        wan_group=""
		wan_num=""
	fi
}

start() {
	# Start daemons.
	#local igmp_enable=`nvram get igmp_enable`
	local igmp_enable=`nvram get wan_endis_igmp`
	local i="0"

	if [ "$igmp_enable" != "1" ]; then	
		return $RETVAL
	fi

	if [ "x$IS_MULTI_WAN" != "x" ]; then
	# Running Multi-WAN #
		for i in 1 2 3 4; do
			# igmp_multi_queue $i
			## igmpproxy in single-upstream interface ##
			igmp_defalt_queue $i

			if [ "x$wan_group" = "x" ]; then
				continue
			fi

			PID_FILE="/var/run/igmpproxy${i}.pid" #if the path/file changes, remember to modify snmp checking function
			CONFIG_FILE="/var/igmpproxy${i}.conf"
			echo "Starting $wan_group $prog: "
			echo "quickleave" > $CONFIG_FILE
			echo "" >> $CONFIG_FILE

    	    case "$wan_proto" in
			static|dhcp)
				wan_ifname_upstream=$wan_ifname
				;;
			pppoe)
				if [ "$wan_pppoe_wan_assign" = "1" ] && [ "$wan_pppoe_netmask" != "0.0.0.0" ]; then
					wan_ifname_upstream=$wan_hwifname
				else
					wan_ifname_upstream=$wan_ifname
				fi

        			if [ "`cat /module_name`" = "DEGN1000v3" ]; then
					wan_ifname_upstream=$wan_hwifname
				fi
				;;
			pptp)
				wan_ifname_upstream=$wan_hwifname
				;;
			l2tp)
				wan_ifname_upstream=$wan_hwifname
				;;
			*)
				wan_ifname_upstream=$wan_ifname
			esac
	
			echo "phyint $wan_ifname_upstream upstream  ratelimit 0  threshold 1" >> $CONFIG_FILE
			echo "" >> $CONFIG_FILE

			echo "phyint $lan_ifname downstream  ratelimit 0  threshold 1" >> $CONFIG_FILE
			echo "" >> $CONFIG_FILE

			if [ "$wan_ifname_upstream" = "$wan_hwifname" ]; then
				echo "phyint ppp0 disabled" >> $CONFIG_FILE
				echo "" >> $CONFIG_FILE
			fi

			for i in 1 2 3 4 5 6 7 8; do 
				if [ "$def_iface" != "$i" ]; then
					echo "phyint ppp$i disabled" >> $CONFIG_FILE
				fi
			done
			echo "" >> $CONFIG_FILE
			touch $PID_FILE
			iptables -D INPUT -i $wan_ifname_upstream -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1
			iptables -D FORWARD -i $wan_ifname_upstream -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1

			iptables -I INPUT -i $wan_ifname_upstream -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT
			iptables -I FORWARD -i $wan_ifname_upstream -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT

			#local port_based_vlan=`cat /proc/port_based_vlan_support`
	        	#local vlan_type=`echo $port_based_vlan | awk -F':' '{print $2}'`
			#if [ "$vlan_type" != "1" ]; then
			#	echo "1" > /proc/br_igmpsnoop
			#else
			#	echo "0" > /proc/br_igmpsnoop
			#fi
			echo "1" > /proc/br_igmpsnoop
			echo "0" > /proc/br_igmpProxy

			#switch_utility RegisterSet 0x480 0x2007			
			#switch_utility RegisterSet 0x4ee 0x2807			

			if [ "$igmp_ver" != "auto" ]; then	
				echo $igmp_ver > /proc/sys/net/ipv4/conf/all/force_igmp_version  #igmpv2
			fi
			${prog} -c $CONFIG_FILE
			RETVAL=$?
			echo
			return $RETVAL
		done
	else	
		echo "Starting $prog: "
		echo "quickleave" > $CONFIG_FILE
		echo "" >> $CONFIG_FILE

        case "$wan_proto" in
		static|dhcp)
			wan_ifname_upstream=$wan_ifname
			;;
		pppoe)
			if [ "$(nvram get wan_pppoe_wan_assign)" = "1" ] && [ "$(nvram get wan_pppoe_netmask)" != "0.0.0.0" ]; then                
				wan_ifname_upstream=$wan_hwifname
			else
				wan_ifname_upstream=$wan_ifname
			fi
        		if [ "`cat /module_name`" = "DEGN1000v3" ] && [ "`cat /firmware_region`" = "RU" ]; then
               			wan_dhcphwifname=`nvram get wan${wan_num}_dhcphwifname`
				wan_ifname_upstream=$wan_dhcphwifname
			fi
			;;
		pptp)
			wan_ifname_upstream=$wan_hwifname
			;;
		l2tp)
			wan_ifname_upstream=$wan_hwifname
			;;
		*)
			wan_ifname_upstream=$wan_ifname
		esac
	
		echo "phyint $wan_ifname_upstream upstream  ratelimit 0  threshold 1" >> $CONFIG_FILE
		echo "" >> $CONFIG_FILE

		echo "phyint $lan_ifname downstream  ratelimit 0  threshold 1" >> $CONFIG_FILE
		echo "" >> $CONFIG_FILE

		if [ "$wan_ifname_upstream" = "$wan_hwifname" ]; then
			echo "phyint ppp0 disabled" >> $CONFIG_FILE
			echo "" >> $CONFIG_FILE
		fi

		if [ "$wan_proto" = "pppoe" ]; then
			echo "phyint ppp1 disabled" >> $CONFIG_FILE
			echo "" >> $CONFIG_FILE
		fi
		touch $PID_FILE
		iptables -D INPUT -i $wan_ifname_upstream -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1
		iptables -D FORWARD -i $wan_ifname_upstream -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1

		iptables -I INPUT -i $wan_ifname_upstream -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT
		iptables -I FORWARD -i $wan_ifname_upstream -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT

		#local port_based_vlan=`cat /proc/port_based_vlan_support`
        	#local vlan_type=`echo $port_based_vlan | awk -F':' '{print $2}'`
		#if [ "$vlan_type" != "1" ]; then
		#	echo "1" > /proc/br_igmpsnoop
		#else
		#	echo "0" > /proc/br_igmpsnoop
		#fi
		echo "1" > /proc/br_igmpsnoop
		echo "0" > /proc/br_igmpProxy

			#switch_utility RegisterSet 0x480 0x2007			
			#switch_utility RegisterSet 0x4ee 0x2807			

		if [ "$igmp_ver" != "auto" ]; then	
			echo $igmp_ver > /proc/sys/net/ipv4/conf/all/force_igmp_version  #igmpv2
		fi
		${prog} -c $CONFIG_FILE
		RETVAL=$?
		echo
	fi
	return $RETVAL
}

stop() {

	if [ "`ls /var/run | grep igmp`" != "" ]; then
	    killall -9 igmpproxy
	fi

	#if [ "x$IS_MULTI_WAN" != "x" ]; then
	#    # Running Multi-WAN #
    #    for i in 1 2 3 4; do
    #        igmp_multi_queue $i
    #        if [ "x$wan_group" = "x" ]; then
    #            continue
    #        fi

    #        PID_FILE="/var/run/igmpproxy${i}.pid" #if the path/file changes, remember to modify snmp checking function
    #        CONFIG_FILE="/var/igmpproxy${i}.conf"

			wan_ifname=`nvram get wan${def_iface}_ifname`
			wan_hwifname=`nvram get wan${def_iface}_hwifname`
            PID_FILE="/var/run/igmpproxy*.pid" #if the path/file changes, remember to modify snmp checking function
            CONFIG_FILE="/var/igmpproxy*.conf"
	
			# Stop daemons.
			echo $"Shutting down $prog: "
			local port_based_vlan=`cat /proc/port_based_vlan_support`
	        	local vlan_type=`echo $port_based_vlan | awk -F':' '{print $2}'`
			if [ "$vlan_type" = "1" ]; then
				echo "1" > /proc/br_igmpsnoop
			else
				echo "0" > /proc/br_igmpsnoop
			fi
			#echo "0" > /proc/br_igmpsnoop
			echo "0" > /proc/br_igmpProxy
	
			rm -f ${PID_FILE}
			rm -f ${CONFIG_FILE}
			iptables -D INPUT -i $wan_ifname -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1
			iptables -D FORWARD -i $wan_ifname -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1
			iptables -D INPUT -i $wan_hwifname -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1
			iptables -D FORWARD -i $wan_hwifname -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1
	#	done
	#fi

	PID_FILE="/var/run/igmpproxy.pid" 
	CONFIG_FILE="/var/igmpproxy.conf"
	wan_ifname=`nvram get wan_ifname`
	wan_hwifname=`nvram get wan_hwifname`

	# Stop daemons.
	echo $"Shutting down $prog: "
			local port_based_vlan=`cat /proc/port_based_vlan_support`
	        	local vlan_type=`echo $port_based_vlan | awk -F':' '{print $2}'`
			if [ "$vlan_type" = "1" ]; then
				echo "1" > /proc/br_igmpsnoop
			else
				echo "0" > /proc/br_igmpsnoop
			fi
			#echo "0" > /proc/br_igmpsnoop
			echo "0" > /proc/br_igmpProxy

	if [ "`ls /var/run | grep igmp`" != "" ]; then
	    killall -2 igmpproxy
	fi    
	rm -f ${PID_FILE}
	iptables -D INPUT -i $wan_ifname -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1
	iptables -D FORWARD -i $wan_ifname -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1
	iptables -D INPUT -i $wan_hwifname -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1
	iptables -D FORWARD -i $wan_hwifname -m iprange --dst-range 224.0.0.0-239.255.255.255 -j ACCEPT > /dev/null 2>&1

	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

