#!/bin/sh
# this script is used to control mac filter function

#[ -f /bin/iptables ] || exit 0

RETVAL=0

#iptables="iptables"
lan_ifname=`nvram get lan_ifname`
mac_filter_enable=`nvram get filter_macmode`
INPUT_MAC_FILTER=input_mac_filter
FWD_MAC_FILTER=fwd_mac_filter


start() 
{
if [ "$mac_filter_enable" = "enabled" ]; then
   i=1;
   while [ "$i" -le "$(nvram get macfilter_num)" ]
   do
       
       block_checked=`nvram get macfilter$i | awk -F" " '{print $1}`
       mac_entry=`nvram get macfilter$i | awk -F" " '{print $2}`
       if [ "$block_checked" = "1" ]; then
           #echo "$iptables -A input_mac_filter -m mac --mac-source $mac_entry -j DROP"
           iptables -A $INPUT_MAC_FILTER -m mac --mac-source $mac_entry -j DROP
           #echo "$iptables -A fwd_mac_filter -m mac --mac-source $mac_entry -j DROP"
           iptables -A $FWD_MAC_FILTER -m mac --mac-source $mac_entry -j DROP
       fi    
       i=$((i+1))
   done
fi
}

stop() {
	iptables -F $INPUT_MAC_FILTER
   iptables -F $FWD_MAC_FILTER
}

prepare() {
	iptables -A INPUT -j $INPUT_MAC_FILTER
   iptables -A FORWARD -j $FWD_MAC_FILTER
}

case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  prepare)
	prepare
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

