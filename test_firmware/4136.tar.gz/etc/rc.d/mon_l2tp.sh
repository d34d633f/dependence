#!/bin/sh
#set -o xtrace

L2TP_PID_FILE="var/run/xl2tpd.pid"
PPP_PID_FILE="/var/run/ppp0.pid"
count=0
pppd_down=0

echo "##Enter mon_l2tp.sh" > /dev/console

while [ 1 ]
do
	sleep 30
	
	if [ "`nvram get wan_proto`" = "l2tp" ]; then  #in case user change wan_proto in the middle of polling
		if [ "`nvram get wan_l2tp_demand`" = "0" ]; then  #persist mode
			while [ 1 ]
			do
				if [ ! -e ${PPP_PID_FILE} ]; then
					count=$(($count+1))
					sleep 5
				else
					PPP_PID=`cat $PPP_PID_FILE`
					if [ ! -d "/proc/${PPP_PID}"  ]; then
						count=$(($count+1))
						sleep 5
					else
						count=0
						pppd_down=0
						break;			
					fi				
				fi
				
				if [ $count -ge 3 ]; then
					count=0
					pppd_down=1
					break
				fi 
			done
			
			if [ "$pppd_down" = "1" ]; then
				if [ -e ${L2TP_PID_FILE} ]; then
					L2TP_PID=`cat $L2TP_PID_FILE`
					if [ -d "/proc/${L2TP_PID}"  ]; then  #do redial only if the l2tpd is running
						echo "##mon_l2tp.sh:: pppd is down, trying to connect l2tp" > /dev/console
						echo "d client" > /var/run/xl2tpd/l2tp-control &
						sleep 3
						echo "c client" > /var/run/xl2tpd/l2tp-control &
					fi
				fi
			fi
		fi
	fi
done
