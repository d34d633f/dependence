#!/bin/sh 

prog="proftpd"
NVRAM="/usr/sbin/nvram"
NETBIOS_NAME=`nvram get usb_deviceName`
WORKGROUP=`nvram get usb_workGroup`
BR_IFNMAE=`nvram get lan_ifname`
LAN_IPADDR=`nvram get lan_ipaddr`
LAN_MASK=`nvram get lan_netmask`
PRODUCT_ID=`nvram get product_id`
CFG_FILE="/tmp/proftpd.conf"

shared_folder_num=0
USB_ATTACHED_DEV=/tmp/attach_usb

append_read_allowuser()
{
        case "$1" in
                0) echo "                       AllowUser admin"
                   echo "                       AllowUser guest";;
                1) echo "                       AllowUser guest";;
                2) echo "                       AllowUser admin";;
                *);;
        esac
}

append_write_allowuser()
{
        case "$1" in
                0) echo "                       AllowUser admin"
                   echo "                       AllowUser guest";;
                1) echo "                       AllowUser guest";;
                2) echo "                       AllowUser admin";;
                *);;
        esac
}

print_onesharefolder_config()
{
        cat <<EOF >>$CFG_FILE
        <Directory /tmp/ftpguest/shares/$1>
        AllowOverwrite    on
                <Limit Read>
EOF
        append_read_allowuser $2>> $CFG_FILE
        cat <<EOF >> $CFG_FILE
                        DenyAll
                </Limit>
                <Limit Write>
EOF
        append_write_allowuser $2>> $CFG_FILE
        cat <<EOF >> $CFG_FILE
                        DenyAll
                </Limit>
        </Directory>
EOF
}

# param: devnam=sda1, relative_path="/lost+found", ftppath="network", rootdir="ftpadmin" access="0-All, 1-guest, 2-admin "
mount1()
{
        mkdir -p /tmp/$4/shares/$3
        mount -o bind utf8=yes,fmask=0000,dmask=0000 /mnt/$1"$2" /tmp/$4/shares/"$3"
        if [ $? -ne 0 ];then
                # UTF8 can't be added to mounting ext2/3
                mount -o bind /mnt/$1"$2" /tmp/$4/shares/"$3"
        
                if [ $? -ne 0 ];then
                        rmdir /tmp/$4/shares/"$3"
                #else
                        #case "$5" in
                               # 0)chmod -R 777 /tmp/$4/shares/"$3";;
                                #1)[ "$4" = "ftpadmin" ] && chmod -R 777 /tmp/$4/shares/"$3";;
                                #2)chmod -R 777 /tmp/$4/shares/"$3";;
                                #*);;
                        #esac
                fi
        fi
}

# parameter: $1:sda1, $2:relative_path, $3:sharename, $4:access
map_usb_to_ftp()
{
        case "$4" in
                0 | 1)mount1 "$1" "$2" "$3" "ftpadmin" "$4"
                      mount1 "$1" "$2" "$3" "ftpguest" "$4";;
                2)    mount1 "$1" "$2" "$3" "ftpadmin" "$4";;
                *);;
        esac

}

get_devnam_fromlabel()
{               
        while read LINE
        do
                if [ "x$LINE" = "x" ];then
                        break
                fi

                dev_nam=`echo $LINE | awk -F* '{print $1}'`
                vendor=`echo $LINE | awk -F* '{print $2}'`
                volume=`echo $LINE | awk -F* '{print $3}'`
                if [ "$vendor" = "$1" ] && [ "$volume" = "$2" ]; then
                        echo $dev_nam
                        break
                fi
                 
        done < $USB_ATTACHED_DEV
}


Itoa()
{
        array="U T S R Q P O N M L K J I H G F E D C B A"
        i=0
        for ch in $array;do
                if [ "$i" = "$1" ];then
                        echo "$ch"
                        break
                fi
                let i=$i+1
        done
}


init_proftpd_conf() 
{
	echo "ServerName              NETGEAR-$PRODUCT_ID" > $CFG_FILE 
	echo "ServerType              standalone" >> $CFG_FILE
	echo "UseReverseDNS           off" >> $CFG_FILE
	echo "Port                    21" >> $CFG_FILE
	echo "Umask                   022" >> $CFG_FILE
	echo "MaxInstances            30" >> $CFG_FILE
	echo "AllowOverwrite          on" >> $CFG_FILE
	echo "ScoreboardFile          /tmp/proftpd.scoreboard" >> $CFG_FILE
	echo "PidFile                 /tmp/proftpd.pid" >> $CFG_FILE
	echo "DefaultServer           on" >> $CFG_FILE
	echo "UseEncoding	      UTF-8 UTF-8" >> $CFG_FILE
	echo "UseIPv6                 off" >> $CFG_FILE
	echo "<Global>" >> $CFG_FILE
        echo "	      AllowOverwrite          on" >> $CFG_FILE
	echo "        User                    root" >> $CFG_FILE
	echo "        Group                   root" >> $CFG_FILE
	echo "        DefaultRoot             ~" >> $CFG_FILE
	#echo "        <Anonymous /tmp/ftpadmin/>" >> $CFG_FILE
	#echo "        	User admin" >> $CFG_FILE
	#echo "        	UserAlias anonymous admin" >> $CFG_FILE
	#echo "        	RequireValidShell off" >> $CFG_FILE
	#echo "        </Anonymous>" >> $CFG_FILE
	#echo "        <Anonymous /tmp/ftpadmin/>" >> $CFG_FILE
	#echo "        	User guest" >> $CFG_FILE
	#echo "        	UserAlias anonymous guest" >> $CFG_FILE
	#echo "        	RequireValidShell off" >> $CFG_FILE
	#echo "        </Anonymous>" >> $CFG_FILE
                
        shared_folder=""           
        dev_order=0

        while read LINE
        do
                if [ "x$LINE" = "x" ];then
                        break
                fi
       
                dev_nam=`echo $LINE | awk -F* '{print $1}'`
                dev_vendor=`echo $LINE | awk -F* '{print $2}'`
                dev_volume=`echo $LINE | awk -F* '{print $3}'`
                
                j=0                

                while true
                do
                       
                       dev_exist=0
                       dulplicat=0            
                       dev=""

                       sharefolder_item=$($NVRAM get "shared_usb_folder$j")
                       if [ "x$sharefolder_item" = "x" ];then
                                break;
                       fi
        
                       sharename=`echo "$sharefolder_item" | awk -F* '{print $1}'` 
                       relative_path=`echo "$sharefolder_item" | awk -F* '{print $2}'`
                       readable=`echo $sharefolder_item | awk -F* '{print $3}'`
                       writable=`echo $sharefolder_item | awk -F* '{print $4}'`
                       volume=`echo $sharefolder_item | awk -F* '{print $5}'`
                       vendor=`echo $sharefolder_item | awk -F* '{print $6}' | awk -F- '{print $1}'`
                       model=`echo $sharefolder_item | awk -F* '{print $6}' | awk -F- '{print $2}'`              
        
                       vendor=`echo $vendor | sed 's/[[:space:]]*$//')`
                       model=`echo $model | sed 's/[[:space:]]*$//')`
                       vendor_model="$vendor $model"
        
                        let access=$readable+$writable

                        if [ "$dev_vendor" = "$vendor_model" ] && [ "$dev_volume" = "$volume" ]; then
                                dev=$dev_nam                                
                        fi      

                       #dev=`get_devnam_fromlabel "$vendor_model" "$volume"`
        
                       if [ "x$dev" != "x" ];then          # the shared folder has it's relative usb device      
                                  
                                    shared_folder_num=$(($shared_folder_num+1))    
        
                                    for item in $shared_folder
                                    do 
                                            if [ "$item" = "$sharename" ];then    
                                                    dulplicat=1                                                 
                                            fi
                                    done
        
                                    if [ "x$shared_folder" = "x" ];then    
                                        shared_folder=$sharename
                                    else 
                                        shared_folder="$shared_folder $sharename"
                                    fi
                
                                     if [ "$dulplicat" = "0" ];then    
                                            print_onesharefolder_config "$sharename" "$access"                 	       
                                            map_usb_to_ftp "$dev" "$relative_path" "$sharename" "$access"
                                    else 
                                            label=`Itoa "$dev_order"`
                                            print_onesharefolder_config "$sharename($label)" "$access"                 	       
                                            map_usb_to_ftp "$dev" "$relative_path" "$sharename($label)" "$access"
                                    fi
                       fi

                       let j=$j+1
            done       

            let dev_order=$dev_order+1

        done < $USB_ATTACHED_DEV

	echo "</Global>" >> $CFG_FILE
}

start() {
	usb_enableFTP=`nvram get usb_enableFTP`
	usb_enableFvia=`nvram get usb_enableFvia`
			
	if [ "$usb_enableFTP" != "0" ] && [ "$usb_enableFvia" != "0" ]; then
		return 1
	fi
	
        [ ! -f $USB_ATTACHED_DEV ] && exit

	pid_num=`ps | grep $prog | grep -v grep | head -n 1 | awk '{print $1}'`
	if [ "$pid_num" != "" ]; then
		echo "$prog had been runnig already"
		return 1
	fi
	
        [ -f $CFG_FILE ] && rm -f $CFG_FILE                
	init_proftpd_conf

        if [ $shared_folder_num != "0" ]; then
	        echo "Starting $prog: "
        	$prog -c $CFG_FILE	
        fi
}


stop() {
	echo "Shutting down $prog: "
        
        killall proftpd
	rm -f /tmp/proftpd.conf    

        for item in `mount | grep "/tmp/ftp" | cut -d " " -f 3`
	do			
		umount $item
		if [ "$?" = "0" ]; then
			rmdir $item
		fi
	done	
}


# See how we were called.
case "$1" in
  start)        
	start 
	;;
  stop)
	stop
	;;
  restart)
	stop
	sleep 1
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
