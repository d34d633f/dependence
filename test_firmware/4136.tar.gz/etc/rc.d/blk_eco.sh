#!/bin/sh

eco_mode=`nvram get ECO_setup_mode`
eco_lamp=`nvram get ECO_lamp_mode`
eco_lan=`nvram get ECO_lan_mode`

blk_svc_ctl=`nvram get blockserv_ctrl`
product_id=`nvram get product_id`

start() 
{
	echo "ECO START!!!"

	if [ "$eco_lan" = "1" ] || [ "$eco_mode" = "1" ];  then	#10/100M only, 1G disabled
		echo bb804104=003F003F > /proc/mem_write
		echo bb804108=043F003F > /proc/mem_write
		echo bb80410c=083F003F > /proc/mem_write
		echo bb804110=0c3F003F > /proc/mem_write
		echo bb804114=103F003F > /proc/mem_write
		echo 202 > /proc/gpio   #off LEDs of switch
	else
		echo bb804104=007F003F > /proc/mem_write
		echo bb804108=047F003F > /proc/mem_write
		echo bb80410c=087F003F > /proc/mem_write
		echo bb804110=0c7F003F > /proc/mem_write
		echo bb804114=107F003F > /proc/mem_write
		echo 201 > /proc/gpio	#restore LEDs of switch
	fi
	
	if [ "$eco_lamp" = "0" ] || [ "$eco_mode" = "1" ];  then
		ledcontrol -n power -s off
		ledcontrol -n eco -s on
		#ledcontrol -n service -s off

		#might be changed to follow IO-DATA ECO spec.
      		#/usr/sbin/sigto_infoHdl 45   # send signal to infoHdl to handle site is not expired 
	else
		ledcontrol -n power -s on
		ledcontrol -n eco -s off
		#ledcontrol -n service -s on
		
		#might be changed to follow IO-DATA ECO spec.
      		#/usr/sbin/sigto_infoHdl 44   # send signal to infoHdl to handle site is expired 
	fi
	
	nvram set ECO_running=1
	nvram set ECO_switch_changed=1
}

stop()
{
	echo "ECO STOP!!!"
	
	echo bb804104=007F003F > /proc/mem_write
	echo bb804108=047F003F > /proc/mem_write
	echo bb80410c=087F003F > /proc/mem_write
	echo bb804110=0c7F003F > /proc/mem_write
	echo bb804114=107F003F > /proc/mem_write
	echo 201 > /proc/gpio	#restore LEDs of switch
	
	ledcontrol -n power -s on
	ledcontrol -n eco -s off
	#ledcontrol -n service -s on
		
	#might be changed to follow IO-DATA ECO spec.
   	#/usr/sbin/sigto_infoHdl 44   # send signal to infoHdl to handle site is expired
   
   	nvram set ECO_running=0
	nvram set ECO_switch_changed=1
}

down_lanip()
{
	lan_stop
}

up_lanip()
{
	if [ "`nvram get ECO_state`" = "normal" ]; then	
		lan_normal	
	fi
	if [ "`nvram get ECO_state`" = "user" ]; then		
		if [ "`nvram get eco_user_lan`" = "2" ]; then		#Stop wired LAN
			# Stop wired LAN
			lan_stop
		else
			if [ "`nvram get eco_user_lan`" = "1" ]; then		#10M wired LAN
				# 10M wired LAN
				lan_low_speed
			else
				lan_normal	
			fi
		
		fi
	fi
	if [ "`nvram get ECO_state`" = "sleep" ]; then		
		lan_stop
	fi
}

lan_stop()
{
	echo "ECO Stop Wired LAN..." > /dev/console
	#/userfs/bin/ethcmd miiw 0 0 0800		#shutdown phy port 0
	#/userfs/bin/ethcmd miiw 1 0 0800		#shutdown phy port 1
	#/userfs/bin/ethcmd miiw 2 0 0800		#shutdown phy port 2
	#/userfs/bin/ethcmd miiw 3 0 0800		#shutdown phy port 3
        if [ "$product_id" = "VEGN2200" ]; then
                switch_utility MDIO_DataWrite 18 0 0x1800             # phy down
                switch_utility MDIO_DataWrite 17 0 0x1800
                switch_utility MDIO_DataWrite 20 0 0x1800
                switch_utility MDIO_DataWrite 19 0 0x1800
        else
                switch_utility MDIO_DataWrite 0 0 0x1800             # phy down
                switch_utility MDIO_DataWrite 1 0 0x1800
                switch_utility MDIO_DataWrite 17 0 0x1800
                switch_utility MDIO_DataWrite 19 0 0x1800
        fi

}

lan_low_speed()
{
	echo "ECO 10M Wired LAN..." > /dev/console
	/userfs/bin/ethcmd miiw 0 4 0461		#10M phy port 0
	/userfs/bin/ethcmd miiw 1 4 0461		#10M phy port 1
	/userfs/bin/ethcmd miiw 2 4 0461		#10M phy port 2
	/userfs/bin/ethcmd miiw 3 4 0461		#10M phy port 3
	/userfs/bin/ethcmd miiw 0 0 1200		#restart Auto-negotiation phy port 0
	/userfs/bin/ethcmd miiw 1 0 1200		#restart Auto-negotiation phy port 1
	/userfs/bin/ethcmd miiw 2 0 1200		#restart Auto-negotiation phy port 2
	/userfs/bin/ethcmd miiw 3 0 1200		#restart Auto-negotiation phy port 3
}

lan_normal()
{
	echo "ECO Start Wired LAN..." > /dev/console
	#/userfs/bin/ethcmd miiw 0 4 05e1		#10/100M phy port 0
	#/userfs/bin/ethcmd miiw 1 4 05e1		#10/100M phy port 1
	#/userfs/bin/ethcmd miiw 2 4 05e1		#10/100M phy port 2
	#/userfs/bin/ethcmd miiw 3 4 05e1		#10/100M phy port 3
	#/userfs/bin/ethcmd miiw 0 0 1200		#restart Auto-negotiation phy port 0
	#/userfs/bin/ethcmd miiw 1 0 1200		#restart Auto-negotiation phy port 1
	#/userfs/bin/ethcmd miiw 2 0 1200		#restart Auto-negotiation phy port 2
	#/userfs/bin/ethcmd miiw 3 0 1200		#restart Auto-negotiation phy port 3
        if [ "$product_id" = "VEGN2200" ]; then
                switch_utility MDIO_DataWrite 18  0 0x1040        # phy up
                switch_utility MDIO_DataWrite 17  0 0x1040
                switch_utility MDIO_DataWrite 20 0 0x1040
                switch_utility MDIO_DataWrite 19 0 0x1040

        else
                switch_utility MDIO_DataWrite 0  0 0x1040        # phy up
                switch_utility MDIO_DataWrite 1  0 0x1040
                switch_utility MDIO_DataWrite 17 0 0x1040
                switch_utility MDIO_DataWrite 19 0 0x1040
        fi

}

wlan_stop()
{
	echo "ECO Stop Wireless LAN..." > /dev/console
	#/etc/rc.d/wlan_ralink.sh stop
	/etc/rc.d/wlan_rtl.sh stop
}

wlan_normal()
{
	echo "ECO Start Wireless LAN..." > /dev/console
	#/etc/rc.d/wlan_ralink.sh restart
	/etc/rc.d/wlan_rtl.sh restart
}

user()
{
	
	if [ "`nvram get ECO_resuming`" = "1" ]; then		
		return
	fi

	echo "ECO running user..." > /dev/console
	nvram set ECO_state="user"
	
	if [ "`nvram get eco_user_led`" = "1" ]; then		#Turn off LED
		# Turn off LED
		#ledcontrol -n system_ok -s off
		#ledcontrol -n system_ng -s off
		#ledcontrol -n xdsl -s off
		#ledcontrol -n internet_ok -s off
		#ledcontrol -n internet_ng -s off
		#ledcontrol -n security -s off
		echo 1 > /proc/tc3162/led_lock
		echo 2 > /proc/tc3162/wifiled		# LED_RADIO_OFF
	else
		dslLink=`cat /tmp/dslStatus/dslLink_status`
		if [ "$dslLink" = "1" ]; then
			ledcontrol -n xdsl -s on
		else
			ledcontrol -n xdsl -s off
		fi	
		echo 0 > /proc/tc3162/led_lock		# Restore LED
		echo 1 > /proc/tc3162/wifiled		# LED_LINK_UP
	fi

	if [ "`nvram get eco_user_lan`" = "2" ]; then		#Stop wired LAN
		# Stop wired LAN
		lan_stop
	elif [ "`nvram get eco_user_lan`" = "1" ]; then		#10M wired LAN
			# 10M wired LAN
			lan_low_speed
	else							#LAN normal
			# 10M wired LAN
			lan_normal
	fi

	if [ "`nvram get eco_user_wlan`" = "1" ]; then		#Stop wireless LAN
		# Stop wireless LAN
		wlan_stop
	else
		# start wireless LAN
		ra0_up=`ifconfig | grep ra0`
		if [ "x$ra0_up" = "x" ]; then
			wlan_normal
			if [ "`nvram get eco_user_led`" = "1" ]; then		#Turn off LED
				echo 2 > /proc/tc3162/wifiled		# LED_RADIO_OFF
			fi
		fi 
	fi

}

sleep()
{
	if [ "`nvram get ECO_resuming`" = "1" ]; then		
		return
	fi

	echo "ECO running sleep..." > /dev/console
	nvram set ECO_state="sleep"

	# Turn off LED
	#ledcontrol -n system_ok -s off
	#ledcontrol -n system_ng -s off
	#ledcontrol -n xdsl -s off
	#ledcontrol -n internet_ok -s off
	#ledcontrol -n internet_ng -s off
	#ledcontrol -n security -s off
	echo 1 > /proc/tc3162/led_lock
	echo 2 > /proc/tc3162/wifiled		# LED_RADIO_OFF

	#Stop wired LAN
	lan_stop

	#stop wireless LAN
	wlan_stop
}

normal()
{
	if [ "`nvram get ECO_state`" != "normal" ]; then		
		echo "ECO running normal..." > /dev/console	
		
		#Turn on wirled LAN
		lan_normal
		#Turn on wireless LAN 
		wlan_normal

		dslLink=`cat /tmp/dslStatus/dslLink_status`
		if [ "$dslLink" = "1" ]; then
			ledcontrol -n xdsl -s on
		else
			ledcontrol -n xdsl -s off
		fi	
		echo 0 > /proc/tc3162/led_lock		# Restore LED
		echo 1 > /proc/tc3162/wifiled		# LED_LINK_UP
	fi

	nvram set ECO_state="normal"
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	;;
  user)
	user
	;;
  sleep)
	sleep
	;;
  normal)
	normal
	;;				   	
  down_lanip)
	down_lanip
	;;				   	
  up_lanip)
	#up_lanip
	lan_normal
	;;				   	
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit 1

