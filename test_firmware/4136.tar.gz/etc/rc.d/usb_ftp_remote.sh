#!/bin/sh
# this script is used to control management control list function

#[ -f /bin/iptables ] || exit 0

. /etc/rc.d/tools.sh

accept="ACCEPT"
log="LOG"
drop="DROP"
reject="REJECT"

RETVAL=0
wan_phy_mode=`nvram get wan_phy_mode`
if [ "$wan_phy_mode" = "adsl" ]; then
        MULTI_LAN=1
fi

iptables="iptables"
NVRAM="/usr/sbin/nvram"
LAN_IPADDR=`nvram get lan_ipaddr`
LAN_SUBNET=`nvram get lan_netmask`
masklen=`print_masklen $LAN_SUBNET`
subnet=`print_subnet $LAN_IPADDR $LAN_SUBNET`
mark_flag=6

start() {
        local wan_ip=`nvram get wan0_ipaddr`
	local usb_enableFvia=`nvram get usb_enableFvia`
	local usb_FTP_via_port=`nvram get usb_FTP_via_port`

	if [ "$usb_enableFvia" = "0" ]; then
		$iptables -t mangle -A PREROUTING -p tcp --dport $usb_FTP_via_port -j MARK --set-mark $mark_flag 
		$iptables -t nat -A nat_local_server -p tcp --dport $usb_FTP_via_port -j REDIRECT --to-ports 21
		$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -p tcp --dport 21 -j ACCEPT
	fi
        	
        if [ "$MULTI_LAN" = "1" ]; then
                nvram set wan_ipaddr_usb_ftp=$wan_ip
        fi
}

stop() {
        local wan_ip=`nvram get wan0_ipaddr`
	local usb_enableFvia=`nvram get usb_enableFvia`
	local usb_FTP_via_port=`nvram get usb_FTP_via_port`

        if [ "$MULTI_LAN" = "1" ]; then
                wan_ip=`nvram get wan_ipaddr_usb_http`
        fi
	$iptables -t mangle -D PREROUTING -p tcp --dport $usb_FTP_via_port -j MARK --set-mark $mark_flag 2> /dev/null
	$iptables -t nat -D nat_local_server -p tcp --dport $usb_FTP_via_port -j REDIRECT --to-ports 21 2> /dev/null
	$iptables -D local_server -m mark --mark $mark_flag -d $wan_ip -p tcp --dport 21 -j ACCEPT 2> /dev/null
}


case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
