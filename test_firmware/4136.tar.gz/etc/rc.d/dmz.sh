#!/bin/sh
# this script is used to control management control list function


. /etc/rc.d/tools.sh
RETVAL=0
iptables="iptables"

wan_default_iface=`nvram get wan_default_iface`
ETH_WAN_INDEX=`nvram get eth_wan_iface`
wan_phy_mode=`nvram get wan_phy_mode`
wan_phy_auto=`nvram get wan_phy_auto`
if [ "$wan_phy_mode" = "adsl" ]; then
        MULTI_WAN=1
fi

if [ "$MULTI_WAN" = "1" ]; then
        iface=$2
        index=$iface
        wan_ip=`nvram get wan${iface}_default_ipaddr`
        if [ "$wan_phy_auto" = "1" ] && [ "$iface" = "$wan_default_iface" ]; then
                if [ "x$wan_ip" = "x" ]; then
                        iface=$ETH_WAN_INDEX
                        wan_ip=`nvram get wan${iface}_default_ipaddr`
                fi
        fi
        if [ "$iface" = "$ETH_WAN_INDEX" ]; then        
                index=$wan_default_iface
        fi
fi

start() {
	local lan_ipaddr=`nvram get dmz${index}_ipaddr`
	local enable=`nvram get wan${index}_endis_dmz`
        local wan_ip=`nvram get wan${iface}_default_ipaddr`

	if [ "$enable" = "1" ]; then
                if [ "x$iface" != "x" ]; then
                      $iptables -t nat -A nat_dmz -p icmp -j RETURN
                      $iptables -t nat -A nat_dmz -j DNAT --to-destination $lan_ipaddr
                      nvram set lan${index}_ipaddr_dmz=$lan_ipaddr
                else
                      $iptables -t nat -A nat_dmz -p icmp -j RETURN
    	              $iptables -t nat -A nat_dmz -j DNAT --to-destination $lan_ipaddr
                fi
		$iptables -A fwd_dmz -d $lan_ipaddr -j LOG --log-level 7 --log-prefix "NAT LAN access from remote" 
		$iptables -A fwd_dmz -d $lan_ipaddr -j ACCEPT
	fi
}


stop() {

        if [ "x$iface" != "x" ]; then
                local lan_ipaddr=`nvram get lan${index}_ipaddr_dmz`
                $iptables -t nat -D nat_dmz -p icmp -j RETURN
                $iptables -t nat -D nat_dmz  -j DNAT --to-destination $lan_ipaddr 2> /dev/null
                $iptables -D fwd_dmz -d $lan_ipaddr -j LOG --log-level 7 --log-prefix "NAT LAN access from remote" 2> /dev/null 
		$iptables -D fwd_dmz -d $lan_ipaddr -j ACCEPT 2> /dev/null
        else
	        $iptables -t nat -F nat_dmz
	        $iptables -F fwd_dmz	
        fi
}


case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
