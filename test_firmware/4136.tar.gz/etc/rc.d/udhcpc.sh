#!/bin/sh

[ -f /etc/udhcpc/udhcpc.script ] || exit 0

iface=$2

RETVAL=0
prog="/sbin/udhcpc"
PID_FILE="/var/run/udhcpc${iface}.pid"
SCRIPT_FILE="/etc/udhcpc/udhcpc.script"
INTRA_SCRIPT_FILE="/etc/udhcpc/udhcpc-intra.script"
BIGPOND_INIT_PROG="/etc/rc.d/heartbeat.sh"
DYNAMIC_PPTP_PROG="/etc/rc.d/dyn_pptp.sh"
DYNAMIC_L2TP_PROG="/etc/rc.d/dyn_l2tp.sh"
DYNAMIC_PPPOE_PROG="/etc/rc.d/dyn_pppoe.sh"
WANIP_CHECK="/etc/rc.d/check_wanip_success.sh"

WAN_INFO=/tmp/wan/wan${iface}
wan_ifname=`nvram get wan${iface}_hwifname`
wan_proto=`nvram get wan${iface}_proto`
wan_phy_mode=`nvram get wan_phy_mode`
if [ "$wan_phy_mode" = "eth" ] && [ "$wan_proto" = "pppoe" ]; then
	wan_ifname=`nvram get wan${iface}_dhcphwifname`
fi
#wan_mtu=`nvram get wan${iface}_dhcp_mtu`
wan_mtu=`nvram get wan${iface}_dhcp_mtu`
hostname=`nvram get wan${iface}_hostname`
wan_default_iface=`nvram get wan_default_iface`
pppoe_intranet_wan_assign=`nvram get wan${iface}_pppoe_intranet_wan_assign`

fw_region=`cat /firmware_region`
module_name=`cat /module_name`
if [ "$fw_region" = "RU" ] && [ "$module_name" = "DEGN1000v3" ]; then
        RUSSIA_PPPOE=1
fi


if [ -z $hostname ]; then
	hostname=""
else
	hostname="-h ${hostname}"
fi


start() {
	# Start daemons.
	echo $"Starting dhcpc${iface}:"

	echo "dhcp" > ${WAN_INFO}

	if [ "$1" != "intra-start" ]; then
		if [ "$iface" = "$wan_default_iface" ]; then
			nvram set wan_ifname=$wan_ifname
		fi
		nvram set wan${iface}_ifname=$wan_ifname
		ifconfig $wan_ifname down

		if [ "$wan_mtu" = "0" ]; then
			ifconfig $wan_ifname mtu 1500
		else
			ifconfig $wan_ifname mtu $wan_mtu
		fi
		ifconfig $wan_ifname 0.0.0.0 up
	fi

	if [ "$wan_proto" = "pptp" ]; then
		if [ "`nvram get dy${iface}_pptp`" = "1" ]; then
                        echo "pptp:1" > ${WAN_INFO}
			echo "${prog} -i ${wan_ifname} -p ${PID_FILE} -s ${DYNAMIC_PPTP_PROG} ${hostname} &"
			${prog} -R -i ${wan_ifname} -p ${PID_FILE} -s ${DYNAMIC_PPTP_PROG} ${hostname} &                       
		fi
	elif [ "$wan_proto" = "l2tp" ]; then
		if [ "`nvram get dy${iface}_l2tp`" = "1" ]; then
                        echo "l2tp:1" > ${WAN_INFO}
			${prog} -R -i ${wan_ifname} -p ${PID_FILE} -s ${DYNAMIC_L2TP_PROG} ${clientid} ${vendorid} ${vendorinfo} ${hostname} &
		fi
	else                
                if [ "$wan_proto" = "pppoe" ]; then
                        if [ "$RUSSIA_PPPOE" = "1" ]; then
                            echo "pppoe:0" > ${WAN_INFO}
                        fi
                fi
                
		if [ "$1" = "intra-start" ]; then
			echo "${prog} -i ${wan_ifname} -p ${PID_FILE} -s ${INTRA_SCRIPT_FILE} ${hostname} &"
			${prog} -R -i ${wan_ifname} -p ${PID_FILE} -s ${INTRA_SCRIPT_FILE} ${hostname} &
		else
			echo "${prog} -i ${wan_ifname} -p ${PID_FILE} -s ${SCRIPT_FILE} ${hostname} &"
			${prog} -R -i ${wan_ifname} -p ${PID_FILE} -s ${SCRIPT_FILE} ${hostname} &		
		fi
	fi
	RETVAL=$?
	echo

	return $RETVAL
}


stop() { 
	# Stop daemons.
	echo $"Shutting down dhcpc${iface}:"
	
	#killall -17 udhcpc	#for release
        if [ -e ${PID_FILE} ]; then
                kill -17 `cat ${PID_FILE}`
		kill -9 `cat ${PID_FILE}`
	fi
	killall -9 bpalogin

	rm -f ${PID_FILE}

	RETVAL=$?
	echo
	return $RETVAL
}


# See how we were called.
case "$1" in
  start)
	start
	;;
  intra-start)
	start intra-start
	;;
  stop)
	stop
	;;
  intra-stop)
	start intra-stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

