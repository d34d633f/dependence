#!/bin/sh

iptables -t nat -N dnat
iptables -t nat -N nat_port_forward
iptables -t nat -N nat_port_trigger_inbound
iptables -t nat -N nat_dmz
iptables -t nat -N nat_local_server
iptables -t nat -N nat_upnp
iptables -t nat -N static_privateroute
iptables -t nat -N RIP_privateroute
iptables -t nat -N nat_nbt
iptables -t nat -N nat_ipsec
iptables -t nat -N eth_napt
iptables -t nat -N nat_http_hijack

iptables -N input_init
iptables -N input_dos
iptables -N input_local_server
iptables -N input_mac_filter
iptables -N input_iden
iptables -N input_ipsec

iptables -N forward_init
iptables -N wan_forward
iptables -N lan_forward
iptables -N fwd_port_forward
iptables -N fwd_port_trigger
iptables -N fwd_dmz
iptables -N fwd_block_site
iptables -N fwd_block_site_nntp
iptables -N fwd_block_svc
iptables -N fwd_dos_input
iptables -N fwd_dos_EchoChargen
iptables -t mangle -N fwd_dos_mangle
iptables -t mangle -N u_qos_chain
iptables -t mangle -N d_qos_chain
iptables -t mangle -N dscp_qos_chain
iptables -t mangle -N dscp_modify_chain
iptables -t mangle -N mangle_local_server
iptables -t mangle -N mangle_dns_hijack

iptables -N fwd_local_server
iptables -N fwd_upnp
iptables -N fwd_mac_filter
iptables -N fwd_vpn_passthru
iptables -N fwd_wifi_guest
iptables -N fwd_ipsec


iptables -N output_init
iptables -N output_dos
iptables -N local_server

iptables -N syn-flood
iptables -N ping-death



