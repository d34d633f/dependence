#!/bin/sh
# this script is used to control management control list function

#[ -f /bin/iptables ] || exit 0

. /etc/rc.d/tools.sh
NVRAM="/usr/sbin/nvram"
accept="ACCEPT"
log="LOG"
drop="DROP"
reject="REJECT"

RETVAL=0

wan_default_iface=`nvram get wan_default_iface`
ETH_WAN_INDEX=`nvram get eth_wan_iface`
wan_phy_mode=`nvram get wan_phy_mode`
wan_phy_auto=`nvram get wan_phy_auto`
if [ "$wan_phy_mode" = "adsl" ]; then
    MULTI_LAN=1
fi

if [ "$MULTI_LAN" = "1" ]; then
	iface=$2
        index=$iface
        intranet=$3	        
        wan_ip=`nvram get wan${iface}_default_ipaddr`
        if [ "$wan_phy_auto" = "1" ] && [ "$iface" = "$wan_default_iface" ]; then
                if [ "x$wan_ip" = "x" ]; then
                        iface=$ETH_WAN_INDEX
                        wan_ip=`nvram get wan${iface}_default_ipaddr`
                fi
        fi
        if [ "$iface" = "$ETH_WAN_INDEX" ]; then        
                index=$wan_default_iface
        fi
        WAN=wan${iface}
else
        wan_ip=`nvram get wan0_ipaddr`
fi

remote_endis=`nvram get remote${index}_endis`
remote_access=`nvram get remote${index}_access`
remote_iplist=`nvram get remote${index}_iplist`
remote_port=`nvram get remote${index}_port`

wan_proto=`nvram get wan${iface}_proto`
dy_pptp=`nvram get dy${iface}_pptp`
dy_l2tp=`nvram get dy${iface}_l2tp`
pppoe_intranet_wan_assign=`nvram get wan${iface}_pppoe_intranet_wan_assign`
fw_region=`cat /firmware_region`
module_name=`cat /module_name`
if [ "$fw_region" = "RU" ] && [ "$module_name" = "DEGN1000v3" ]; then
        RUSSIA_PPPOE=1
fi

if [ "$intranet" = "1" ]; then            
            if [ "$wan_proto" = "pptp" ]; then
            	    if [ "$dy_pptp" = "1" ]; then
            		    wan_ip=`$NVRAM get wan${iface}_dhcp_ipaddr`
            	    else
            		    wan_ip=`$NVRAM get wan${iface}_pptp_local_ip`
            	    fi
            fi
            if [ "$wan_proto" = "l2tp" ]; then
                    if [ "$dy_l2tp" = "1" ]; then
                            wan_ip=`$NVRAM get wan${iface}_dhcp_ipaddr`
                    else
                            wan_ip=`$NVRAM get wan${iface}_l2tp_local_ip`
                    fi
            fi
            if [ "$wan_proto" = "pppoe" ]; then
        	if [ "`cat /module_name`" = "DEGN1000v3" ]; then
        		if [ "$pppoe_intranet_wan_assign" = "0" ]; then
        		        wan_ip=`$NVRAM get wan${iface}_dhcp_ipaddr`
                        else
                                wan_ip=`$NVRAM get wan${iface}_pppoe_intranet_ip`
                        fi
		fi
	    fi
fi

iptables="iptables"
LOG_PREFIX=[type3]
mark_flag=3
accesslog_enable=`nvram get LogAccessEnable`
https_port=`nvram get https_port`

if [ "x$https_port" = "x" ]; then
        https_port="443"
fi

check_dual_interafce()
{
	if [ "$1" = "add" ];then
		OP="-A"
	else
		OP="-D"
	fi
	if [ "$wan_proto" = "pptp" ]; then
		if [ "$dy_pptp" = "1" ]; then
			dual_ip=`$NVRAM get wan_dhcp_ipaddr`
		else
			dual_ip=`$NVRAM get wan_pptp_local_ip`
		fi
	fi
    if [ "$wan_proto" = "l2tp" ]; then
        if [ "$dy_l2tp" = "1" ]; then
            dual_ip=`$NVRAM get wan_dhcp_ipaddr`
        else
            dual_ip=`$NVRAM get wan_l2tp_local_ip`
        fi
    fi
        
	if [ "$wan_proto" = "pppoe" ]; then
        	if [ "`cat /module_name`" = "DEGN1000v3" ] && [ "`cat /firmware_region`" = "RU" ]; then
                        if [ "$pppoe_intranet_wan_assign" = "0" ]; then
        		        dual_ip=`$NVRAM get wan${iface}_dhcp_ipaddr`
                        else
                                dual_ip=`$NVRAM get wan${iface}_pppoe_intranet_ip`
                        fi
		fi
	fi

	if [ "$dual_ip" = "" ];then return;fi

	if [ "$2" = "" ]; then
		$iptables -t mangle $OP mangle_local_server -p tcp -d $dual_ip --dport $remote_port -j MARK --set-mark $mark_flag                         
		$iptables -t mangle $OP mangle_local_server -p tcp -d $dual_ip --dport $remote_port -j ACCEPT
		$iptables $OP local_server -m mark --mark $mark_flag -d $dual_ip -p tcp --dport $https_port -j ACCEPT 2> /dev/null
	else
		if echo $2|grep \- >/dev/null;then
			$iptables -t mangle $OP mangle_local_server -d $dual_ip -m iprange --src-range $2 -p tcp --dport $remote_port -j MARK --set-mark $mark_flag
			$iptables -t mangle $OP mangle_local_server -d $dual_ip -m iprange --src-range $2 -p tcp --dport $remote_port -j ACCEPT
			$iptables $OP local_server -m mark --mark $mark_flag -d $dual_ip -m iprange --src-range $2 -p tcp --dport $https_port -j ACCEPT 2> /dev/null
		else
			$iptables -t mangle $OP mangle_local_server -d $dual_ip -s $2 -p tcp --dport $remote_port -j MARK --set-mark $mark_flag
			$iptables -t mangle $OP mangle_local_server -d $dual_ip -s $2 -p tcp --dport $remote_port -j ACCEPT
			$iptables $OP local_server -m mark --mark $mark_flag -d $dual_ip -s $2 -p tcp --dport $https_port -j ACCEPT 2> /dev/null
		fi
	fi
}

start() {
	echo $"Starting ${WAN} remote access"
	local remote_endis=`nvram get remote${index}_endis`
	local remote_access=`nvram get remote${index}_access`
	local remote_iplist=`nvram get remote${index}_iplist`
	local remote_port=`nvram get remote${index}_port`

	if [ "$wan_ip" = "" ]; then
    	    echo "No obtain wan IP address"
	    exit 
	fi

	if [ "$remote_endis" = "1" ]; then
		if [ "$remote_access" = "2" ]; then	# every one
			#The rule in mangle table mark packet which will be REDIRECT. 
			#This can prevent remote host access DUT by port 80 directly.
			$iptables -t mangle -A mangle_local_server -p tcp -d $wan_ip --dport $remote_port -j MARK --set-mark $mark_flag                         
			$iptables -t mangle -A mangle_local_server -p tcp -d $wan_ip --dport $remote_port -j ACCEPT
			#echo "$iptables -t nat -A nat_local_server -p tcp --dport $remote_port -j REDIRECT --to-ports $https_port"
			$iptables -t nat -A nat_local_server -p tcp --dport $remote_port -j REDIRECT --to-ports $https_port
			if [ "$accesslog_enable" = "1" ]; then
				$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -p tcp --dport $https_port -m log --log-prefix "$LOG_PREFIX[AUTH Permit configuration from wired Internet]" -j ACCEPT
			else
				$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -p tcp --dport $https_port -j ACCEPT
			fi

                        if [ "x$intranet" = "x" ]; then
			    check_dual_interafce add
                        fi
		else
			if [ "$remote_access" = "0" ]; then	# only this ip
				$iptables -t mangle -A mangle_local_server -d $wan_ip -s $remote_iplist -p tcp --dport $remote_port -j MARK --set-mark $mark_flag
				$iptables -t mangle -A mangle_local_server -d $wan_ip -s $remote_iplist -p tcp --dport $remote_port -j ACCEPT
				$iptables -t nat -A nat_local_server -s $remote_iplist -p tcp --dport $remote_port -j REDIRECT --to-ports $https_port

				if [ "$accesslog_enable" = "1" ]; then
					$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -s $remote_iplist -p tcp --dport $https_port -m log --log-prefix "$LOG_PREFIX[AUTH Permit configuration from wired Internet]" -j ACCEPT
				else
					$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -s $remote_iplist -p tcp --dport $https_port -j ACCEPT
				fi
			else
				$iptables -t mangle -A mangle_local_server -d $wan_ip -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j MARK --set-mark $mark_flag
				$iptables -t mangle -A mangle_local_server -d $wan_ip -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j ACCEPT
				$iptables -t nat -A nat_local_server -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j REDIRECT --to-ports $https_port	
				$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -m iprange --src-range $remote_iplist -p tcp --dport $https_port -j ACCEPT
			fi

                        if [ "x$intranet" = "x" ]; then
			        check_dual_interafce add $remote_iplist
                        fi
		fi
	fi	

	if [ "x$iface" != "x" ]; then            
                if [ "$intranet" = "1" ]; then
                    nvram set wan${index}_intra_ipaddr_remote=$wan_ip
                else
                    nvram set wan${index}_ipaddr_remote=$wan_ip
                fi
	fi
}


stop() {
	local remote_endis=`nvram get remote${index}_endis`
	local remote_access=`nvram get remote${index}_access`
	local remote_iplist=`nvram get remote${index}_iplist`
	local remote_port=`nvram get remote${index}_port`

	if [ "x$iface" != "x" ]; then
                if [ "$intranet" = "1" ]; then
	    	    wan_old_ip=`nvram get wan${index}_intra_ipaddr_remote`
                    nvram unset wan${index}_intra_ipaddr_remote
                else
                    wan_old_ip=`nvram get wan${index}_ipaddr_remote`
                    if [ "x$intranet" != "x" ]; then
                        nvram unset wan${index}_ipaddr_remote
                    fi
                fi                
	else
        	wan_old_ip=`nvram get wan0_ipaddr`
	fi        
   
        if [ "$RUSSIA_PPPOE" = "1" ]; then
                if [ "$wan_proto" != "pptp" ] && [ "$wan_proto" != "l2tp" ] && [ "$wan_proto" != "pppoe" ] && [ "$intranet" = "0" ]; then
                        old_intra_ip=`nvram get wan${index}_intra_ipaddr_remote`
                        nvram unset wan${index}_intra_ipaddr_remote
                fi
        else
                if [ "$wan_proto" != "pptp" ] && [ "$wan_proto" != "l2tp" ] && [ "$intranet" = "0" ]; then
                        old_intra_ip=`nvram get wan${index}_intra_ipaddr_remote`
                        nvram unset wan${index}_intra_ipaddr_remote
                fi
        fi

	if [ "$remote_access" = "2" ]; then	# every one 
		$iptables -t mangle -D mangle_local_server -p tcp -d $wan_old_ip --dport $remote_port -j ACCEPT 2> /dev/null 
		$iptables -t mangle -D mangle_local_server -p tcp -d $wan_old_ip --dport $remote_port -j MARK --set-mark $mark_flag 2> /dev/null 
		$iptables -t nat -D nat_local_server -p tcp --dport $remote_port -j REDIRECT --to-ports $https_port 2> /dev/null	
        	$iptables -D local_server -m mark --mark $mark_flag -d $wan_old_ip -p tcp --dport $https_port -j ACCEPT 2> /dev/null
		$iptables -D local_server -m mark --mark $mark_flag -d $wan_old_ip -p tcp --dport $https_port -m log --log-prefix "$LOG_PREFIX[AUTH Permit configuration from wired Internet]" -j ACCEPT 2> /dev/null
                if [ "x$intranet" = "x" ]; then
		        check_dual_interafce del
                fi

                if [ "x$old_intra_ip" != "x" ]; then
                        $iptables -t mangle -D mangle_local_server -p tcp -d $old_intra_ip --dport $remote_port -j ACCEPT 2> /dev/null 
		        $iptables -t mangle -D mangle_local_server -p tcp -d $old_intra_ip --dport $remote_port -j MARK --set-mark $mark_flag 2> /dev/null 
		        $iptables -t nat -D nat_local_server -p tcp --dport $remote_port -j REDIRECT --to-ports $https_port 2> /dev/null	
        	        $iptables -D local_server -m mark --mark $mark_flag -d $old_intra_ip -p tcp --dport $https_port -j ACCEPT 2> /dev/null
		        $iptables -D local_server -m mark --mark $mark_flag -d $old_intra_ip -p tcp --dport $https_port -m log --log-prefix "$LOG_PREFIX[AUTH Permit configuration from wired Internet]" -j ACCEPT 2> /dev/null
                fi
	else
		if [ "$remote_access" = "0" ]; then	# only this ip
			$iptables -t mangle -D mangle_local_server -d $wan_old_ip -s $remote_iplist -p tcp --dport $remote_port -j ACCEPT 2> /dev/null
			$iptables -t mangle -D mangle_local_server -d $wan_old_ip -s $remote_iplist -p tcp --dport $remote_port -j MARK --set-mark $mark_flag 2> /dev/null
			$iptables -t nat -D nat_local_server -s $remote_iplist -p tcp --dport $remote_port -j REDIRECT --to-ports $https_port 2> /dev/null	
			$iptables -D local_server -m mark --mark $mark_flag -d $wan_old_ip -s $remote_iplist -p tcp --dport $https_port -j ACCEPT 2> /dev/null
			$iptables -D local_server -m mark --mark $mark_flag -d $wan_old_ip -s $remote_iplist -p tcp --dport $https_port -m log --log-prefix "$LOG_PREFIX[AUTH Permit configuration from wired Internet]" -j ACCEPT 2> /dev/null

                        if [ "x$old_intra_ip" != "x" ]; then
                                $iptables -t mangle -D mangle_local_server -d $old_intra_ip -s $remote_iplist -p tcp --dport $remote_port -j ACCEPT 2> /dev/null
			        $iptables -t mangle -D mangle_local_server -d $old_intra_ip -s $remote_iplist -p tcp --dport $remote_port -j MARK --set-mark $mark_flag 2> /dev/null
			        $iptables -t nat -D nat_local_server -s $remote_iplist -p tcp --dport $remote_port -j REDIRECT --to-ports $https_port 2> /dev/null	
			        $iptables -D local_server -m mark --mark $mark_flag -d $old_intra_ip -s $remote_iplist -p tcp --dport $https_port -j ACCEPT 2> /dev/null
			        $iptables -D local_server -m mark --mark $mark_flag -d $old_intra_ip -s $remote_iplist -p tcp --dport $https_port -m log --log-prefix "$LOG_PREFIX[AUTH Permit configuration from wired Internet]" -j ACCEPT 2> /dev/null
                        fi
		else
			$iptables -t mangle -D mangle_local_server -d $wan_old_ip -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j ACCEPT
			$iptables -t mangle -D mangle_local_server -d $wan_old_ip -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j MARK --set-mark $mark_flag
			$iptables -t nat -D nat_local_server -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j REDIRECT --to-ports $https_port	2> /dev/null
			$iptables -D local_server -m mark --mark $mark_flag -d $wan_old_ip -m iprange --src-range $remote_iplist -p tcp --dport $https_port -j ACCEPT 2> /dev/null

                        if [ "x$old_intra_ip" != "x" ]; then
                                $iptables -t mangle -D mangle_local_server -d $old_intra_ip -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j ACCEPT
			        $iptables -t mangle -D mangle_local_server -d $old_intra_ip -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j MARK --set-mark $mark_flag
			        $iptables -t nat -D nat_local_server -m iprange --src-range $remote_iplist -p tcp --dport $remote_port -j REDIRECT --to-ports $https_port	2> /dev/null
			        $iptables -D local_server -m mark --mark $mark_flag -d $old_intra_ip -m iprange --src-range $remote_iplist -p tcp --dport $https_port -j ACCEPT 2> /dev/null
                        fi
		fi
                if [ "x$intranet" = "x" ]; then
		        check_dual_interafce del $remote_iplist
                fi
	fi
}


case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;      
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
