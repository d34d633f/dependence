#!/bin/sh

wan_iden=`nvram get WanIdentEnable`
wan_nbt=`nvram get WanNBTEnable`
wan_ifname=`nvram get wan_ifname`
log_enable=`nvram get LogFirewallEnable`

#iptables -D local_server -p icmp --icmp-type 8 -j LOG --log-level info --log-prefix "[WAN PING ACCEPT]"


iptables -F input_iden

#iptables -D INPUT -p tcp --dport 113 -j REJECT --reject-with tcp-reset 2> /dev/null
#iptables -D INPUT -p tcp --dport 113 -m log --log-prefix "FIREWALL Reject IDENT requests" -j REJECT --reject-with icmp-port-unreachable 2> /dev/null

if [ "$wan_iden" = "0" ]; then
	if [ "$log_enable" = "1" ]; then
		#iptables -I INPUT -p tcp --dport 113 -m log --log-prefix "FIREWALL Reject IDENT requests" -j REJECT --reject-with icmp-port-unreachable
		iptables -A input_iden -p tcp --dport 113 -m log --log-prefix "FIREWALL Reject IDENT requests" -j REJECT --reject-with icmp-port-unreachable
	else
		#iptables -I INPUT -p tcp --dport 113 -j REJECT --reject-with icmp-port-unreachable
		iptables -A input_iden -p tcp --dport 113 -j REJECT --reject-with icmp-port-unreachable

	fi
fi

iptables -t nat -F nat_nbt
if [ "$wan_nbt" = "0" ]; then
	if [ "$log_enable" = "1" ]; then
		iptables -t nat -A nat_nbt -p tcp --dport 445 -m log --log-prefix "FIREWALL Prohibit NBT and Microsoft-DS Routing" -j DROP
		iptables -t nat -A nat_nbt -p udp --dport 445 -m log --log-prefix "FIREWALL Prohibit NBT and Microsoft-DS Routing" -j DROP
		iptables -t nat -A nat_nbt -p tcp --dport 137:139 -m log --log-prefix "FIREWALL Prohibit NBT and Microsoft-DS Routing" -j DROP
		iptables -t nat -A nat_nbt -p udp --dport 137:139 -m log --log-prefix "FIREWALL Prohibit NBT and Microsoft-DS Routing" -j DROP
	else
		iptables -t nat -A nat_nbt -p tcp --dport 445 -j DROP
		iptables -t nat -A nat_nbt -p udp --dport 445 -j DROP
		iptables -t nat -A nat_nbt -p tcp --dport 137:139 -j DROP
		iptables -t nat -A nat_nbt -p udp --dport 137:139 -j DROP
	fi
fi
