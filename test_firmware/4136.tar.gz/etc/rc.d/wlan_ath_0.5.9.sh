#!/bin/sh
#
# script file to start WLAN
#
#set -o xtrace
WLAN_IF="ath0"
WAN_IF=`nvram get wan_ifname`
BR="br0"
sys_uptime=$([ -f /proc/uptime ] && cat /proc/uptime | awk '{print $1}' | awk -F. '{print $1}')
MSSID_num=1
SSID_ACT=0
MSSID_disable=1
RUN_GUEST_ACCESS_FILE=0
KVER=`uname -r | cut -f 1 -d '-'`
MODULE_PATH=/lib/modules/$KVER/net
hostapd=/sbin/hostapd
conf_hostapd=/tmp/hostapd/hostapd.conf
dir_hostapd=/tmp/hostapd
topo=/tmp/topology.conf
guest_access_file=/tmp/guest_access
################################################################################################

##MODE##
MODE="ap"
if [ "$(nvram get wds_endis_fun)" = "1" -a "$(nvram get wds_repeater_basic)" = "0" -a "$(nvram get wds_endis_mac_client)" = "1" ]; then        
    MODE="repeater"
fi
##

Ins_module()
{
    echo "Inserting modules"
    insmod $MODULE_PATH/adf.ko
    insmod $MODULE_PATH/asf.ko
    insmod $MODULE_PATH/ath_hal.ko
    insmod $MODULE_PATH/ath_rate_atheros.ko
    insmod $MODULE_PATH/ath_spectral.ko maxholdintvl=5000 nfrssi=1 nobeacons=0

    #load DFS if A band is supported,default is supported and set AP_NO_A_BAND=1 if not supported
    insmod $MODULE_PATH/ath_dfs.ko

    insmod $MODULE_PATH/ath_dev.ko
    insmod $MODULE_PATH/umac.ko flowmac_on=0
    insmod $MODULE_PATH/wlan_me.ko
    insmod $MODULE_PATH/ath_pktlog.ko

    Set_region
    #wlanlog

}
##end of Ins_module##

Rm_module()
{   
    echo "Removing modules"
    rmmod wlan_scan_ap
    rmmod wlan_scan_sta
    rmmod ath_pktlog
    sleep 2
    rmmod wlan_me
    sleep 2
    rmmod umac
    sleep 2
    rmmod ath_dev
    rmmod ath_dfs
    rmmod ath_spectral
    rmmod ath_rate_atheros
    rmmod ath_hal
    rmmod asf
    rmmod adf
    
    #killall wlanlog

}
##end of Rm_module##

Set_region()
{
    country_code_0=710              # Africa
    country_code_1=156              # Asia china
    country_code_2=36               # Australi
    country_code_3=124              # Canada
    country_code_4=276              # Europe Germany
    country_code_5=376              # Israel
    country_code_6=392              # Japan
    country_code_7=410              # Korea
    country_code_8=484              # Mexica
    #country_code_9=76               # South America Brazil
    country_code_9=376             # Middle East, use Israel instead
    country_code_10=840             # United States
    #country_code_12=156             # China
    #country_code_13=643             # Russia
    COUN=$((country_code_`nvram get wl_country`))
    #echo "iwpriv wifi0 setCountryID $COUN"
    iwpriv wifi0 setCountryID $COUN
}
##end of Set_region##

Basic_setting()
{
    echo "$1: basic settings"

    num=$2 #`cut -d 'ath' -f 1`
    AP_INDEX=$num
    if [ "$num" = "0" ]; then
        # 2.4G 
        WL_SSID=$(nvram get wl_ssid)
        WL_ISO=$(nvram get endis_wl_iso)
        WL_BCAST=$(nvram get endis_ssid_broadcast)
        ifconfig wifi0 txqueuelen 1000
    elif [ "$num" = "1" ]; then
        # 5G 
        WL_SSID=$(nvram get wla_ssid)
        WL_ISO=$(nvram get endis_wla_wireless_isolation)
        WL_BCAST=$(nvram get wla_endis_ssid_broadcast)
        ifconfig wifi1 txqueuelen 1000
    else
        #WL_SSID=`nvram get wl_ssid_$num`
        #WL_ISO=`nvram get endis_wlg1_iso`
        #WL_BCAST=`nvram get endis_ssid_broadcast_$num`
        WL_SSID=`nvram get wlg1_ssid`
        WL_ISO=`nvram get wlg1_endis_allow_guest`
        WL_BCAST=`nvram get wlg1_endis_guestNet`
        ifconfig wifi0 txqueuelen 1000
    fi
    ifconfig ath$num txqueuelen 1000

    case "$(nvram get wl_simple_mode)" in
    1)
        #echo "$1: up to 54M"
        iwpriv $1 mode 11G
        iwpriv $1 pureg 0
        ;;
    2)
        #echo "$1: up to 65M"
        iwpriv $1 mode 11NGHT20
        iwpriv $1 shortgi 0
        iwpriv $1 puren 0
        ;;
    3)
        #echo "$1: up to 150M"
        iwpriv $1 mode 11NGHT40PLUS
        iwpriv $1 shortgi 1
        iwpriv $1 puren 0
        iwpriv $1 extoffset 1
        ;;
    5)
        #echo "$1: up to 150M"
        iwpriv $1 mode 11NGHT40MINUS
        iwpriv $1 shortgi 1
        iwpriv $1 puren 0
        iwpriv $1 extoffset -1
        ;;
    6)    
        #echo "$1: up to 150M"
        iwpriv $1 mode 11NGHT40
        iwpriv $1 shortgi 1
        iwpriv $1 puren 0
        ;;
    esac
    
    iwconfig $1 essid "$WL_SSID"
    #iwconfig $1 freq mode master "$(nvram get wl_hidden_channel)"
    iwconfig $1 freq "$(nvram get wl_hidden_channel)"
    
    iwpriv $1 protmode 1   # 802.11g protection mode
    iwpriv $1 htweptkip 0
    #iwpriv $1 disablecoext 0
    iwpriv wifi0 ForBiasAuto 1
    iwpriv $1 bgscan 0
    iwconfig $1 frag "$(nvram get wl_frag)"

    iwpriv wifi0 AMPDU 1
    iwpriv wifi0 AMPDUFrames 32
    iwpriv wifi0 AMPDULim 50000

    WL_RTS=`nvram get wl_rts`
    if [ "$WL_RTS" = "2347" ];then
        iwconfig $1 rts off
    else
        iwconfig $1 rts "$WL_RTS"
    fi

    #iwconfig $1 rate "$(nvram get wl_rate)"
    iwpriv $1 wmm "$(nvram get endis_wl_wmm)"
    iwpriv $1 hide_ssid $((1-$WL_BCAST))
    [ "$(nvram get wl_plcphdr)" = "2" ] && iwpriv $1 shpreamble 0 || iwpriv $1 shpreamble 1
    #iwpriv $1 xr "$(nvram get endis_xr)"

    if [ "$WL_ISO" = "1" ]; then
        iwpriv $1 ap_bridge 0
    else
        iwpriv $1 ap_bridge 1
    fi

    iwpriv $1 disablecoext 1

}
##end of Basic_setting##


Security()
{
    echo "$1: Security, num=$2."
    #$1: ath0 | ath1 | ath[2-X]
    mkdir -p $dir_hostapd

    #num=`cut -d 'ath' -f 1`
    num=$2
    AP_INDEX=$num
    if [ "$num" = "0" ]; then
        WL_SSID=`nvram get wl_ssid`
        WL_SECTYPE=`nvram get wl_sectype`
        WL_AUTH=`nvram get wl_auth`
        WL_KEY=$(nvram get wl_key)

        # 'WPA Key
        WL_WPA1_KEY="$(nvram get wl_wpa1_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPA2_KEY="$(nvram get wl_wpa2_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        # 'WPASPSK Key
        WL_WPASPSK_KEY="$(nvram get wl_wpas_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        # 'WPAX Key Length
        WL_WPAX_KEYLEN="$(nvram get wl_sec_wpaphrase_len)"        

        # 'WPA/WPA2 Enterprise 
        WL_RADIUS_MODE="$(nvram get wl_radius_mode)"
    elif [ "$num" = "1" ]; then
        WL_SSID=`nvram get wla_ssid`
        WL_SECTYPE=`nvram get wla_sectype`
        WL_AUTH=`nvram get wla_auth`
        WL_KEY=$(nvram get wla_key)

        # 'WPA Key
        WL_WPA1_KEY="$(nvram get wla_wpa1_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPA2_KEY="$(nvram get wla_wpa2_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        # 'WPASPSK Key
        WL_WPASPSK_KEY="$(nvram get wla_wpas_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        # 'WPAX Key Length
        WL_WPAX_KEYLEN="$(nvram get wla_sec_wpaphrase_len)"

        # 'WPA/WPA2 Enterprise 
        WL_RADIUS_MODE="$(nvram get wla_radius_mode)"
    else
        AP_IFACE=$1
        #WL_SSID=$(nvram get wl_ssid_$AP_INDEX)
        #WL_SECTYPE=$(nvram get wl_sectype_$AP_INDEX)
        #WL_AUTH=$(nvram get wl_auth_$AP_INDEX)
        #WL_KEY=$(nvram get wl_key_$AP_INDEX)
        WL_SSID=$(nvram get wlg1_ssid)
        WL_SECTYPE=$(nvram get wlg1_sectype)
        WL_AUTH=$(nvram get wlg1_auth)
        WL_KEY=$(nvram get wlg1_key)

        # 'WPA Key
        #WL_WPA1_KEY="$(nvram get wl_wpa1_psk_$AP_INDEX | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        #WL_WPA2_KEY="$(nvram get wl_wpa2_psk_$AP_INDEX | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPA1_KEY="$(nvram get wlg1_wpa1_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPA2_KEY="$(nvram get wlg1_wpa2_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"

        # 'WPASPSK Key
        #WL_WPASPSK_KEY="$(nvram get wl_wpas_psk_$AP_INDEX | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        WL_WPASPSK_KEY="$(nvram get wlg1_wpas_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
        # 'WPAX Key Length
        #WL_WPAX_KEYLEN="$(nvram get wl_sec_wpaphrase_len)"
        WL_WPAX_KEYLEN="$(nvram get wlg1_sec_wpaphrase_len)"

        # 'WPA/WPA2 Enterprise 
        #WL_RADIUS_MODE="$(nvram get wl_radius_mode)"
        WL_RADIUS_MODE="$(nvram get wlg1_radius_mode)"
    fi
    #SSID="$(nvram get wl_ssid_$1 | sed -e 's/\\\\\\\\/\\/g' -e 's/\\\\\\`/`/g' -e 's/\\\"/"/g')"

    WPS_STAT="$(nvram get wps_status)"
    if [ "$WPS_STAT" = "1" ]; then
        WPS_CONF=0
    else
        WPS_CONF=1
    fi
    WPSPIN=`cat /tmp/wpspin`
    
    echo "WL_SSID=$WL_SSID, WL_SECTYPE=$WL_SECTYPE, WL_AUTH=$WL_AUTH, WL_KEY=$WL_KEY"
    case $WL_SECTYPE in
    1) #none
        echo "$1: Security none"
        cat /etc/ath/open.ap_bss > $dir_hostapd/$1.ap_bss
        ;;
    2) #wep
        echo "$1: Security wep"
        auth=$WL_AUTH    #1 shared  #2 auto  --- algs  1 shared else open @@
        #wep_default_key=$WL_KEY
        cat /etc/ath/wep.ap_bss > $dir_hostapd/$1.ap_bss
        if [ "$auth" = "1" ]; then
            echo "auth_algs=2" >> $dir_hostapd/$1.ap_bss
        else
            echo "auth_algs=1" >> $dir_hostapd/$1.ap_bss
        fi

        if [ "$AP_INDEX" = "0" ]; then
            # 2.4G
            WEP_KEY0=$(nvram get wl_key1)
            WEP_KEY1=$(nvram get wl_key2)
            WEP_KEY2=$(nvram get wl_key3)
            WEP_KEY3=$(nvram get wl_key4)
        elif [ "$AP_INDEX" = "1" ]; then
            # 5G 
            WEP_KEY0=$(nvram get wla_key1)
            WEP_KEY1=$(nvram get wla_key2)
            WEP_KEY2=$(nvram get wla_key3)
            WEP_KEY3=$(nvram get wla_key4)
        else
            #Guest
            #WEP_KEY0=$(nvram get wl_key1_$AP_INDEX)
            #WEP_KEY1=$(nvram get wl_key2_$AP_INDEX)
            #WEP_KEY2=$(nvram get wl_key3_$AP_INDEX)
            #WEP_KEY3=$(nvram get wl_key4_$AP_INDEX)
            
            WEP_KEY0=$(nvram get wlg1_key1)
            WEP_KEY1=$(nvram get wlg1_key2)
            WEP_KEY2=$(nvram get wlg1_key3)
            WEP_KEY3=$(nvram get wlg1_key4)
        fi

        echo "wep_default_key=$(($WL_KEY-1))" >> $dir_hostapd/$1.ap_bss
        echo "wep_key0=$WEP_KEY0" >> $dir_hostapd/$1.ap_bss
        echo "wep_key1=$WEP_KEY1" >> $dir_hostapd/$1.ap_bss
        echo "wep_key2=$WEP_KEY2" >> $dir_hostapd/$1.ap_bss
        echo "wep_key3=$WEP_KEY3" >> $dir_hostapd/$1.ap_bss
        iwpriv $1 wpa 0

        echo "$1: WEP_KEY0=$WEP_KEY0, WEP_KEY1=$WEP_KEY1, WEP_KEY2=$WEP_KEY2, WEP_KEY3=$WEP_KEY3"
        case "$WL_AUTH" in
        0) #open
	    echo "$1: Security wep open"
            iwpriv $1 authmode 1
            iwconfig $1 key ["$WL_KEY"] open
            ;;
        1) #shared
            echo "$1: Security wep share"
            iwpriv $1 authmode 2
            iwconfig $1 key ["$WL_KEY"] restricted
            ;;
        2) #auto
            echo "$1: Security wep auto"
            iwpriv $1 authmode 4
            iwconfig $1 key ["$WL_KEY"]
            ;;
        esac

        if [ "$WEP_KEY0" != "" ]; then
            iwconfig $1 key [1] "$WEP_KEY0"
        fi
        if [ "$WEP_KEY1" != "" ]; then
            iwconfig $1 key [2] "$WEP_KEY1"
        fi
        if [ "$WEP_KEY2" != "" ]; then
            iwconfig $1 key [3] "$WEP_KEY2"
        fi
        if [ "$WEP_KEY3" != "" ]; then
            iwconfig $1 key [4] "$WEP_KEY3"
        fi
        ;;

    3) #wpa-psk
        echo "$1: Security wpa-psk(TKIP)"
        cat /etc/ath/wpapsk.ap_bss > $dir_hostapd/$1.ap_bss
        if [ "$WL_WPAX_KEYLEN" != "64" ]; then
            echo "wpa_passphrase=$WL_WPA1_KEY" >> $dir_hostapd/$1.ap_bss
        else
            echo "wpa_psk=$WL_WPA1_KEY" >> $dir_hostapd/$1.ap_bss
        fi
        ;;
    4) #wpa2-psk
        echo "$1: Security wpa2-psk(AES)"
        cat /etc/ath/wpa2psk.ap_bss > $dir_hostapd/$1.ap_bss
        if [ "$WL_WPAX_KEYLEN" != "64" ]; then
            echo "wpa_passphrase=$WL_WPA2_KEY" >> $dir_hostapd/$1.ap_bss
        else
            echo "wpa_psk=$WL_WPA2_KEY" >> $dir_hostapd/$1.ap_bss
        fi
        ;;
    5) #wpa-psk/wpa2-psk
        echo "$1: Security wpa-psk(TKIP)+wpa2-psk(AES)"
        cat /etc/ath/wpaspsk.ap_bss > $dir_hostapd/$1.ap_bss
        if [ "$WL_WPAX_KEYLEN" != "64" ]; then
            echo "wpa_passphrase=$WL_WPASPSK_KEY" >> $dir_hostapd/$1.ap_bss
        else
            echo "wpa_psk=$WL_WPASPSK_KEY" >> $dir_hostapd/$1.ap_bss
        fi
        ;;
    6) #wpa/wpa2-enterprise
	    echo "$1: Security wpa/wpa2 enterprise"
        case "$WL_RADIUS_MODE" in
        0) #wpa (tkip)
	        echo "$1: wpa(tkip) encryption mode"
            sec_algo="TKIP"
            config_wpa $1 "$sec_algo" 1 
            ;;
        1) #wpa2 (aes)
	        echo "$1: wpa2(aes) encryption mode"
            sec_algo="CCMP"
            config_wpa $1 "$sec_algo" 2 
            ;;
        2) #wpa (tkip) + wpa2 (aes)
	        echo "$1: wpa(tkip) + wpa2(aes) encryption mode"
	        sec_algo="CCMP TKIP"
	        config_wpa $1 "$sec_algo" 3 
            ;;
        esac
        ;;
    esac

    #common settings
    echo "ssid=$WL_SSID" >> $dir_hostapd/$1.ap_bss
    if [ "$1" = "ath0" ]; then
        if [ "$(nvram get wds_endis_fun)" = "0" ]; then
            if [ "$(nvram get wl_sectype)" != "2"  -o "$(nvram get wl_auth)" != "1" ]; then
                echo "wps_disable=0" >> $dir_hostapd/$1.ap_bss
                echo "wps_upnp_disable=0" >> $dir_hostapd/$1.ap_bss
            fi
        fi

        echo "wps_configured=$WPS_CONF" >> $dir_hostapd/$1.ap_bss
        echo "wps_default_pin=$WPSPIN" >> $dir_hostapd/$1.ap_bss
        echo "wps_upnp_ad_period=$(nvram get upnp_AdverTime)" >> $dir_hostapd/$1.ap_bss
        echo "wps_upnp_ad_ttl=$(nvram get upnp_TimeToLive)" >> $dir_hostapd/$1.ap_bss
        echo "wps_ap_setup_locked=$(nvram get endis_pin)" >> $dir_hostapd/$1.ap_bss

        DEV_NAME=$(nvram get netbiosname)
        echo "wps_model_name=$DEV_NAME (Wireless AP)" >> $dir_hostapd/$1.ap_bss
        echo "wps_model_number=$DEV_NAME" >> $dir_hostapd/$1.ap_bss
        echo "wps_friendly_name=$DEV_NAME" >> $dir_hostapd/$1.ap_bss
        echo "wps_model_description=$DEV_NAME Wireless AP" >> $dir_hostapd/$1.ap_bss
        echo "wps_dev_name=$DEV_NAME (Wireless AP)" >> $dir_hostapd/$1.ap_bss
    fi
}
##end of Security##

ACL()
{
    echo "$1: ACL[$2] Start...."
    MACAC_ENABLED=`nvram get wl_access_ctrl_on`
    #iwpriv $1 maccmd $MACAC_ENABLED
    if [ "$MACAC_ENABLED" != "0" ]; then
        iwpriv $1 maccmd $MACAC_ENABLED
        MACAC_NUM=`nvram get wl_acl_num`
        if [ "$MACAC_NUM" != "0" ]; then
            num=1
            while [ $num -le $MACAC_NUM ]
            do
                AC_MAC=`nvram get wlacl$num | awk '{print $2}'`
                iwpriv $1 addmac $AC_MAC
                num=$(($num+1))
            done
        fi
    fi
}
##end of ACL##

Wds()
{
    if [ "$1" = "start" ]; then
        echo "Wds start:"
        if [ "$(nvram get wds_endis_fun)" = "1" ]; then
            brctl stp $BR on
            if [ "$(nvram get wds_repeater_basic)" = "1" ]; then  ##root-ap##          
                echo "root ap"
                for rep in 1 2 3 4; do
                    repeater_mac=$(nvram get repeater_mac$rep)
                    if [ "$repeater_mac" != "" ]; then
                        iwpriv ath0 addmac $repeater_mac 00:01:00:00:00:00
                        if [ "$(nvram get wl_simple_mode)" = "1" ]; then
                            iwpriv ath0 repeatermac $repeater_mac 00:01:01:00:00:00
                        else
                            iwpriv ath0 repeatermac $repeater_mac 00:02:01:00:00:00
                        fi
                    fi
                done

                if [ "$(nvram get wds_endis_mac_client)" = "1" ]; then
                    iwpriv ath0 maccmd 1 
                fi

            else  ##repeater##
                echo "repeater"
                wlanconfig wds5 create wlandev wifi0 wlanmode sta nosbeacon
                if [ "$(nvram get wl_sectype)" = "2" ]; then
                    AP_WEPKEY1=`nvram get wl_key1`
                    AP_WEPKEY2=`nvram get wl_key2`
                    AP_WEPKEY3=`nvram get wl_key3`
                    AP_WEPKEY4=`nvram get wl_key4`

                    iwpriv wds5 wpa 0
                    [ "$AP_WEPKEY1" = "" ] || iwconfig wds5 key [1] "$AP_WEPKEY1"
                    [ "$AP_WEPKEY2" = "" ] || iwconfig wds5 key [2] "$AP_WEPKEY2"
                    [ "$AP_WEPKEY3" = "" ] || iwconfig wds5 key [3] "$AP_WEPKEY3"
                    [ "$AP_WEPKEY4" = "" ] || iwconfig wds5 key [4] "$AP_WEPKEY4"

                    case "$(nvram get wl_auth)" in
                    0) #open
                        iwpriv wds5 authmode 1
                        iwconfig wds5 key ["$(nvram get wl_key)"] open
                        ;;
                    1) #shared
                        iwpriv wds5 authmode 2
                        iwconfig wds5 key ["$(nvram get wl_key)"] restricted
                        ;;
                    2) #auto
                        iwpriv wds5 authmode 4
                        iwconfig wds5 key ["$(nvram get wl_key)"]
                        ;;
                    esac
                fi

                iwpriv wds5 wds 1
                iwpriv wds5 vap_ind 1
                iwpriv wds5 bgscan 0
                iwconfig wds5 mode managed freq $(nvram get wl_hidden_channel)
                iwconfig wds5 ap $(nvram get basic_station_mac)

                if [ "$(nvram get wds_endis_mac_client)" = "1" ]; then
                    iwpriv ath0 maccmd 1 
                fi
            fi
        fi
    else
        echo "Wds stop:" 
        wds_if=`ifconfig -a | grep wds`
        if [ "x$wds_if" != "x" ]; then
            ifconfig wds5 down
            brctl delif $BR wds5
            #echo "wlanconfig wds5 destroy"
            wlanconfig wds5 destroy
        fi
        iwpriv ath0 wds 0
        brctl stp $BR off
    fi      
}
##end of Wds##


fixed_topoconf()
{
AP_IPADDR=$(nvram get lan_ipaddr)
AP_NETMASK=$(nvram get lan_netmask)

cat << EOF
bridge $BR
{
    ${AP_IPADDR}
    ${AP_NETMASK}
    interface ath0
    interface ath1
    interface ath2
    interface ath3
    interface ath4
    interface wds5
    interface eth0
}

radio wifi0
{
    ap 
    {

EOF

}
##end of fixed_topoconf##


Guest_access()
{
    ETH_P_ARP=0x0806
    ETH_P_RARP=0x8035
    ETH_P_IP=0x0800
    IPPROTO_ICMP=1
    IPPROTO_UDP=17
    DHCPS_DHCPC=67:68
    PORT_DNS=53

    cat<<EOF > $guest_access_file

#!/bin/sh

ebtables -F FORWARD
ebtables -F INPUT
ebtables -P FORWARD ACCEPT
ebtables -A FORWARD -p $ETH_P_ARP -j ACCEPT
ebtables -A FORWARD -p $ETH_P_RARP -j ACCEPT
ebtables -A FORWARD -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $DHCPS_DHCPC -j ACCEPT
ebtables -P INPUT ACCEPT
ebtables -A INPUT -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $DHCPS_DHCPC -j ACCEPT
ebtables -A INPUT -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $PORT_DNS -j ACCEPT
EOF

    #primary 
    if [ "$(nvram get endis_wl_iso)" = "1" -a "$(nvram get endis_wl_radio)" = "1" ]; then
        RUN_GUEST_ACCESS_FILE=1
        echo "ebtables -A FORWARD -i ath0 -j DROP" >> $guest_access_file
        echo "ebtables -A INPUT -i ath0 -p $ETH_P_IP --ip-dst $(nvram get lan_ipaddr) -j DROP" >> $guest_access_file
    fi
     
    #guest
    index=0
    while [ "$index" -lt "$MSSID_num" ]
    do
        #AP_GUEST_ENIFACE=`nvram get endis_allow_guest_ath$(($index))`
        AP_GUEST_ENIFACE=`nvram get wl_guest_access_local_endis_$(($index+2))`
        #AP_ENIFACE=`nvram get endis_wl_radio_$(($index+2))`
        AP_ENIFACE=`nvram get wlg1_endis_guestNet`
        
        AP_IFACE=ath$(($index+2))
        if [ "$AP_GUEST_ENIFACE" = "0" -a "$AP_ENIFACE" = "1" ]; then
            RUN_GUEST_ACCESS_FILE=1
            echo "ebtables -A FORWARD -i $AP_IFACE -j DROP" >> $guest_access_file
            echo "ebtables -A INPUT -i $AP_IFACE -p $ETH_P_IP --ip-dst $(nvram get lan_ipaddr) -j DROP" >> $guest_access_file
        fi
        index=$(($index+1))
    done 

    if [ "$RUN_GUEST_ACCESS_FILE" = "1" ]; then
        chmod +x $guest_access_file         
        $guest_access_file 
    else
        ebtables -F FORWARD
        ebtables -F INPUT
    fi
}
##end of Guest_access##

Create_vap()
{
    wlanconfig ath0 create wlandev wifi0 wlanmode ap
    
    index=0
    guest_enable=0
    while [ "$index" -lt "$MSSID_num" ]
    do
        #if [ "$(nvram get endis_wl_radio_$(($index+2)))" = "1" ]; then
        if [ "$(nvram get wlg1_endis_guestNet)" = "1" ]; then
            guest_enable=1
        fi
        index=$(($index+1))
    done
    
    index=0
    if [ "$guest_enable" = "1" ]; then
        while [ "$index" -lt "$MSSID_num" ]
        do
            wlanconfig ath$(($index+2)) create wlandev wifi0 wlanmode ap
            index=$(($index+1))
        done
    fi
}
##end of Create_vap##

Kill_vap()
{
    VAP=`ifconfig -a | grep ath2`
            
    index=0
    if [ "$VAP" != "" ]; then
        while [ "$index" -lt "$MSSID_num" ]
        do
            #echo "wlanconfig ath$(($index+2)) destroy"
            wlanconfig ath$(($index+2)) destroy

            index=$(($index+1))
        done
    fi
    wlanconfig ath0 destroy
}
##end of Kill_vap##

IF_Handle()
{
    echo "$1: IF_Handle."
    AP_IPADDR=$(nvram get lan_ipaddr)
    AP_NETMASK=$(nvram get lan_netmask)
      
    index=0
    while [ "$index" -le "$MSSID_num" ]     
    do
        if [ "$index" = "0" ]; then
            AP_IFACE=ath0
            AP_ENIFACE=`nvram get endis_wl_radio`
        else
            AP_IFACE=ath$(($index+1))
            #AP_ENIFACE=`nvram get endis_wl_radio_$(($index+1))`
            AP_ENIFACE=`nvram get wlg1_endis_guestNet`
            
        fi 
        if [ "$AP_ENIFACE" = "1" ]; then
            case "$SSID_ACT" in
            1)      
                iwpriv $AP_IFACE bintval 100
                iwpriv $AP_IFACE dtim_period 2
                ;;
            2)      
                iwpriv $AP_IFACE bintval 200
                iwpriv $AP_IFACE dtim_period 2
                ;;
            3)      
                iwpriv $AP_IFACE bintval 300
                iwpriv $AP_IFACE dtim_period 2
                ;;
            4)      
                iwpriv $AP_IFACE bintval 400
                iwpriv $AP_IFACE dtim_period 2
                ;;
            5)      
                iwpriv $AP_IFACE bintval 500
                iwpriv $AP_IFACE dtim_period 2
                ;;                  
            esac    
        fi      
        index=$(($index+1)) 
    done

    if [ "$1" = "start" ]; then
        echo "IF start:"
        ## topology.conf ##
        fixed_topoconf  > $topo

        if [ "$(nvram get wl_sectype)" != 2 -o "$(nvram get wl_auth)" != "1" ]; then
            echo -e "\t\tbss ath0" >> $topo
            echo -e "\t\t{" >> $topo
            echo -e "\t\t\tconfig /tmp/hostapd/ath0.ap_bss" >> $topo
            echo -e "\t\t}" >> $topo
        fi

        index=0
        while [ "$index" -lt "$MSSID_num" ]
        do
            #AP_ENIFACE=`nvram get endis_wl_radio_$(($index+2))`
            #AP_ENIFACE=`nvram get wlg1_endis_guestNet`
            #AP_SECTYPE=`nvram get wl_sectype_$(($index+2))`
            AP_SECTYPE=`nvram get wlg1_sectype`
            AP_IFACE=ath$(($index+2))
            if [ "$AP_ENIFACE" = "1" -a "$AP_SECTYPE" != "2" ]; then
                if [ "$MODE" != "repeater" ]; then
                    echo -e "\t\tbss $AP_IFACE" >> $topo
                    echo -e "\t\t{" >> $topo
                    echo -e "\t\t\tconfig /tmp/hostapd/$AP_IFACE.ap_bss" >> $topo
                    echo -e "\t\t}" >> $topo
                fi
            fi
            index=$(($index+1)) 
        done 

        echo -e "\t}" >> $topo
        echo -e "}" >> $topo

        index=0
        while [ "$index" -le "$MSSID_num" ]
        do
            if [ "$index" = "0" -a "$MODE" != "repeater" ]; then
            #2.4G
                AP_ENIFACE=`nvram get endis_wl_radio`
                AP_IFACE=ath$index
                if [ "$AP_ENIFACE" = "1" ]; then
                    ifconfig $AP_IFACE up
                    brctl addif $BR $AP_IFACE
                    sleep 1    
                fi
            elif [ "$MODE" != "repeater" ]; then
            #Guest for 2.4G
                #AP_ENIFACE=`nvram get endis_wl_radio_$(($index+2))`
                AP_ENIFACE=`nvram get wlg1_endis_guestNet`
                
                AP_IFACE=ath$(($index+1))
                if [ "$AP_ENIFACE" = "1" ]; then
                    ifconfig $AP_IFACE up
                    brctl addif $BR $AP_IFACE
                    sleep 1    
                fi
            fi      
            index=$(($index+1))
        done    
        #$hostapd $topo &           
    else
        echo "IF stop:"
        index=0
        while [ "$index" -le "$MSSID_num" ]
        do
            if [ "$index" = "0" ]; then
                AP_IFACE=ath0
            else
                AP_IFACE=ath$(($index+1))
            fi
            IF=$( [ -f /tmp/topology.conf ] && cat /tmp/topology.conf | grep bss | grep $AP_IFACE )
            if [ "x$IF" != "x" ]; then
                ifconfig $AP_IFACE down 
                brctl delif $BR $AP_IFACE
            fi
            index=$(($index+1))
        done 
        Kill_vap
    fi
}
##end of IF_Handle##

main()
{
    echo "$1: wlan_ath.sh..."
   if [ "$1" = "start" ]; then
        
        RADIO=`nvram get endis_wl_radio`
        if [ "$RADIO" = "1" ]; then 

            Ins_module
            nvram set wps_client=""
            nvram set wlan_busy=1

            if [ "$(nvram get wds_endis_fun)" = "1" -a "$(nvram get wds_repeater_basic)" = "0" ]; then
                Wds start
                sleep 1
                Create_vap

                index=0
                while [ "$index" -le "$MSSID_num" ]
                do
                    if [ "$index" = "0" ]; then
                        AP_ENIFACE=`nvram get endis_wl_radio`
                        AP_IFACE=ath0
                        AP_INDEX=0
                    else
                        #AP_ENIFACE=`nvram get endis_wl_radio_$(($index+1))`
                        AP_ENIFACE=`nvram get wlg1_endis_guestNet`
                        AP_IFACE=ath$(($index+1))
                        AP_INDEX=$(($index+1))
                    fi
                    if [ "$MODE" != "repeater" -a "$AP_ENIFACE" = "1" ]; then
                        iwpriv $AP_IFACE wds 1
                        iwpriv $AP_IFACE vap_ind 1
                        Basic_setting $AP_IFACE $AP_INDEX
                        Security $AP_IFACE  $AP_INDEX
                        ACL $AP_IFACE $AP_INDEX
                        SSID_ACT=$(($SSID_ACT+1))                                    
                    fi

                    index=$(($index+1))
                done 

                Guest_access
                IF_Handle start
                ifconfig wds5 up
                brctl addif $BR wds5
                sleep 1
            else
                Create_vap
                index=0
                while [ "$index" -le "$MSSID_num" ]
                do
                    if [ "$index" = "0" ]; then
                        AP_ENIFACE=`nvram get endis_wl_radio`
                        AP_IFACE=ath0
                        AP_INDEX=0
                    else
                        #AP_ENIFACE=`nvram get endis_wl_radio_$(($index+1))`
                        AP_ENIFACE=`nvram get wlg1_endis_guestNet`
                        AP_IFACE=ath$(($index+1))
                        AP_INDEX=$(($index+1))
                    fi
                    if [ "$MODE" != "repeater" -a "$AP_ENIFACE" = "1" ]; then
                        Basic_setting $AP_IFACE $AP_INDEX
                        Security $AP_IFACE $AP_INDEX
                        ACL $AP_IFACE $AP_INDEX
                        SSID_ACT=$(($SSID_ACT+1))                                     
                    fi
                    index=$(($index+1))
                done 
                Wds start
                Guest_access
                IF_Handle start
            fi

            if [ "$(nvram get wds_endis_fun)" = "0" ]; then
                if [ "$(nvram get wl_sectype)" != 2 -o "$(nvram get wl_auth)" != "1" -o "$SSID_ACT" != "1" ]; then
                    echo "Running hostapd!"
                    $hostapd $topo &
                fi
            fi

            echo $sys_uptime > /tmp/WLAN_uptime
            DECAYPOWER=$(nvram get wl_txctrl)
            [ "$DECAYPOWER" = "0" ] || iwpriv wifi0 tpscale $DECAYPOWER
                nvram set wlan_busy=0
        else
            echo "Wireless disabled"
        fi
    else
        MODLIST=`lsmod | grep ath_hal`
##
## If the modules are already unloaded, we do not need to do anything
##
        if [ "$MODLIST" = "" ]; then
            echo "Modules already unloaded"
            return 
        fi

        #pktlogconf -d          

        killall hostapd
        #killall -9 wpa_supplicant
        sleep 4
        Wds stop
        IF_Handle stop 
        rm -rf $dir_hostapd

        #rm -rf /tmp/br*
        #rm -rf /tmp/ap*
        #rm -rf /tmp/sta*
        #rm -rf /tmp/top*
        #rm -rf /tmp/conf*
        #rm -rf /tmp/sta_conf*

        Rm_module
   fi
}
##end of main##

case "$1" in 
"start")
    main start
    ;;  
"stop")
    main stop       
    ;;
"load_module")
    echo "wireless module test"
    Ins_module
    ;;
"restart")
    main stop
    main start    
    ;;
*)
    echo "Warning! You must input ./wlan_ath.sh [start|stop|restart]."
esac
