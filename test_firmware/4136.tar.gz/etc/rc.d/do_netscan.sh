#!/bin/sh

/usr/bin/killall -SIGUSR1 udhcpd
sleep 2
/usr/bin/killall -SIGUSR2 net-scan
sleep 1
/usr/bin/killall -SIGUSR1 net-scan
