#!/bin/sh

if [ "$(nvram get router_disable)" = "0" ]; then

    killall -SIGUSR1 udhcpd
    sleep 2
    killall -SIGUSR2 net-scan
    sleep 1
    killall -SIGUSR1 net-scan

fi

exit $RETVAL

