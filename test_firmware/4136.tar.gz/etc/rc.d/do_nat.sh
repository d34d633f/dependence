#!/bin/sh

. /etc/rc.d/tools.sh

iface=$2
action=$1
INFORM=$3

NVRAM="/usr/sbin/nvram"
IPTABLES="/usr/sbin/iptables"
IP="/usr/sbin/ip"
CAT="/bin/cat"
AREA_CHK="/usr/sbin/area-ck"

if [ "$action" = "restart" ]; then
    MESSAGE="Restart"
elif [ "$action" = "stop" ]; then
    MESSAGE="Stop"
elif [ "$action" = "start" ]; then
    MESSAGE="Start"
fi

ETH_WAN_INDEX=`$NVRAM get eth_wan_iface`
LAN_GROUP=0
PREF=3000
TABLE=20
TABLE_INDEX=${iface}

echo $"${MESSAGE} do nat for wan${iface} $INFORM" >>  /dev/console

wan_ifname=`$NVRAM get wan${iface}_ifname`
interface_group_map=`$NVRAM get interface_group_map`
vlan_enable=`$NVRAM get vlan_enable`
NAT_TYPE_FULLCONE=`$NVRAM get nat_type_fullcone`

wan_phy_auto=`$NVRAM get wan_phy_auto`
wan_ifname=`$NVRAM get wan${iface}_ifname`
wan_truehwifname=`$NVRAM get wan${iface}_hwifname`
wan_ipaddr=`$NVRAM get wan${iface}_default_ipaddr`
wan_netmask=`$NVRAM get wan${iface}_default_netmask`
nat_endis=`$NVRAM get wan${iface}_nat_enable`
nat_type=`$NVRAM get wan${iface}_nat_fitering`
wan_default_iface=`$NVRAM get wan_default_iface`

WAN_INFO="/tmp/wan/wan${iface}"
wan_proto=`$CAT ${WAN_INFO} | cut -d ":" -f1`
if [ "$wan_proto" = "pptp" ]; then
    dy_pptp=`$CAT ${WAN_INFO} | cut -d ":" -f2`
fi
if [ "$wan_proto" = "l2tp" ]; then
    dy_l2tp=`$CAT ${WAN_INFO} | cut -d ":" -f2`
fi
if [ "$wan_proto" = "pppoe" ]; then
    st_pppoe=`$CAT ${WAN_INFO} | cut -d ":" -f2`
fi

module_name=`cat /module_name`
firmware_region=`cat /firmware_region`

lan_ipaddr=""
lan_netmask=""
LAN_MASKLEN=""
LAN_SUBNET=""
lan_ifname=""

if [ "$iface" = "$ETH_WAN_INDEX" ]; then
    TABLE_INDEX=$wan_default_iface
fi

Remove_src_route_settings()
{
    echo "Remove_src_route_settings" >> /dev/console
    
    if [ "$wan_proto" = "pptp" ] || [ "$wan_proto" = "l2tp" ]; then
         if [ "$INFORM" = "dhcpc" ]; then  # dhcpc call stop
                PPP_DEV=`$IP route show table ${TABLE}${TABLE_INDEX} | grep "ppp"`
                if [ "x$PPP_DEV" != "x" ]; then
                      wan_intrnet_ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`
                      wan_intrnet_subnet=`$NVRAM get wan${iface}_dhcp_netmask`
                      wan_intrnet_ifname=`$NVRAM get wan${iface}_dhcp_ifname`    
                      wan_intrnet_gateway=`$NVRAM get wan${iface}_dhcp_gateway`

                      mask_len=`print_masklen $wan_intrnet_subnet`
                      sub_net=`print_subnet $wan_intrnet_ipaddr $wan_intrnet_subnet`
   		       if [ "x$mask_len" != "x" ] && [ "x$sub_net" != "x" ]; then
                      	    #echo "$IP route del  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}" >> /dev/console
                      	    $IP route del  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
                      fi
                else
                     $IP route flush table ${TABLE}${TABLE_INDEX} 2> /dev/null
                     $IP rule del table ${TABLE}${TABLE_INDEX} 2> /dev/null
                fi
         elif [ "$INFORM" = "static" ]; then  # static call stop
                PPP_DEV=`$IP route show table ${TABLE}${TABLE_INDEX} | grep "ppp"`
                if [ "x$PPP_DEV" != "x" ]; then
                      if [ "$wan_proto" = "pptp" ]; then
                            wan_intrnet_ipaddr=`$NVRAM get wan${iface}_pptp_my_ip`
                            wan_intrnet_subnet=`$NVRAM get wan${iface}_pptp_my_mask`
                            wan_intrnet_ifname=`$NVRAM get wan${iface}_hwifname`    
                            wan_intrnet_gateway=`$NVRAM get wan${iface}_pptp_gw`
                      elif [ "$wan_proto" = "l2tp" ]; then
                            wan_intrnet_ipaddr=`$NVRAM get wan${iface}_l2tp_my_ip`
                            wan_intrnet_subnet=`$NVRAM get wan${iface}_l2tp_my_mask`
                            wan_intrnet_ifname=`$NVRAM get wan${iface}_hwifname`    
                            wan_intrnet_gateway=`$NVRAM get wan${iface}_l2tp_gw`
                      fi  
                      mask_len=`print_masklen $wan_intrnet_subnet`
                      sub_net=`print_subnet $wan_intrnet_ipaddr $wan_intrnet_subnet`
                      if [ "x$mask_len" != "x" ] && [ "x$sub_net" != "x" ]; then
                      		#echo "$IP route del  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}" >> /dev/console
                      		$IP route del  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
			    fi
                else
                     $IP route flush table ${TABLE}${TABLE_INDEX} 2> /dev/null
                     $IP rule del table ${TABLE}${TABLE_INDEX} 2> /dev/null
                fi
         else # ppp call stop
                NAS_DEV=`$IP route show table ${TABLE}${TABLE_INDEX} | grep "vc"`
                if [ "x$NAS_DEV" != "x" ]; then                      
                      gateway=`$NVRAM get wan${iface}_default_gateway`
                      # remove default route info about ppp
                      #echo "$IP route del default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX}"
                      $IP route del default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null  

                      wan_intrnet_ifname=`$NVRAM get wan${iface}_hwifname`      
                      if [ "$wan_proto" = "pptp" ]; then 
                            if [ "$dy_pptp" = "1" ]; then 
                                    wan_intrnet_gateway=`$NVRAM get wan${iface}_dhcp_gateway`
                                    wan_intrnet_ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`
                                    wan_internet_netmask=`$NVRAM get wan${iface}_dhcp_netmask`
                                    mask_len=`print_masklen $wan_internet_netmask`
                                    sub_net=`print_subnet $wan_intrnet_ipaddr $wan_internet_netmask`
                            else
                                    wan_intrnet_gateway=`$NVRAM get wan${iface}_pptp_gw`
                                    wan_intrnet_ipaddr=`$NVRAM get wan${iface}_pptp_my_ip`
                                    wan_internet_netmask=`$NVRAM get wan${iface}_pptp_my_mask`
                                    mask_len=`print_masklen $wan_internet_netmask`
                                    sub_net=`print_subnet $wan_intrnet_ipaddr $wan_internet_netmask`
                            fi
                            
                      elif [ "$wan_proto" = "l2tp" ]; then 
                            if [ "$dy_l2tp" = "1" ]; then 
                                    wan_intrnet_gateway=`$NVRAM get wan${iface}_dhcp_gateway`
                                    wan_intrnet_ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`
                                    wan_internet_netmask=`$NVRAM get wan${iface}_dhcp_netmask`
                                    mask_len=`print_masklen $wan_internet_netmask`
                                    sub_net=`print_subnet $wan_intrnet_ipaddr $wan_internet_netmask`
                            else
                                    wan_intrnet_gateway=`$NVRAM get wan${iface}_l2tp_gw`
                                    wan_intrnet_ipaddr=`$NVRAM get wan${iface}_l2tp_my_ip`
                                    wan_internet_netmask=`$NVRAM get wan${iface}_l2tp_my_mask`
                                    mask_len=`print_masklen $wan_internet_netmask`
                                    sub_net=`print_subnet $wan_intrnet_ipaddr $wan_internet_netmask`
                            fi
                      fi
                    
                      # remove route info about dhcp/static info and add new default route info about  dhcp/static 
                      #$IP route del  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
                      #$IP route add  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
			    if [ "x$mask_len" != "x" ] && [ "x$sub_net" != "x" ]; then
                                    $IP route add default via $wan_intrnet_gateway dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null  
			    fi
                      
                else
                     $IP route flush table ${TABLE}${TABLE_INDEX} 2> /dev/null
                     $IP rule del table ${TABLE}${TABLE_INDEX} 2> /dev/null
                fi
         fi
    else
            if [ "$wan_proto" = "pppoe" ]; then 
                    if [ "$INFORM" = "dhcpc" ] || [ "$INFORM" = "static" ]; then 
                            if [ "$st_pppoe" = "0" ]; then
                                        wan_intrnet_ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`
                                        wan_intrnet_subnet=`$NVRAM get wan${iface}_dhcp_netmask`
                                        wan_intrnet_ifname=`$NVRAM get wan${iface}_hwifname`  
                            else
                                        wan_intrnet_ipaddr=`$NVRAM get wan${iface}_pppoe_intranet_ip`
                                        wan_intrnet_subnet=`$NVRAM get wan${iface}_pppoe_intranet_mask`
                                        wan_intrnet_ifname=`$NVRAM get wan${iface}_hwifname`
                            fi
                            mask_len=`print_masklen $wan_intrnet_subnet`
                            sub_net=`print_subnet $wan_intrnet_ipaddr $wan_intrnet_subnet`
 				    if [ "x$mask_len" != "x" ] && [ "x$sub_net" != "x" ]; then
                            		echo "$IP route del  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}" >> /dev/console
                            		$IP route del  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}  2> /dev/null
	  			    fi
                    else
                            gateway=`$NVRAM get wan${iface}_default_gateway`
                            # remove default route info about ppp
                            echo "$IP route del default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX}" >> /dev/console
                            $IP route del default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null  
                    fi
            else
                    $IP route flush table ${TABLE}${TABLE_INDEX} 2> /dev/null
                    #$IP route del  $LAN_SUBNET/$LAN_MASKLEN via $LAN_IPADDR dev $lan_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
                    #$IP route del default table ${TABLE}${TABLE_INDEX} 2> /dev/null
                    $IP rule del table ${TABLE}${TABLE_INDEX} 2> /dev/null
            fi
    fi
}

adjust_mss_value()
{
    echo "adjust_mss_value" >> /dev/console

    wan_interface=$wan_ifname
    if [ "$wan_proto" = "pptp" ] || [ "$wan_proto" = "l2tp" ]; then
        if [ "$INFORM" = "dhcpc" ] || [ "$INFORM" = "static" ]; then 
                wan_interface=`$NVRAM get wan${iface}_hwifname`  
            fi            
    fi

    MSS_MAX=`$NVRAM get wan${iface}_mss`

    $IPTABLES -D FORWARD -o $wan_interface -p tcp --tcp-flags SYN,RST SYN -m tcpmss --mss $(($MSS_MAX+1)):65535 -j TCPMSS --set-mss $MSS_MAX  2> /dev/null

    if [ "$1" = stop ]; then
          return  
    fi

	case "$wan_proto" in	
		static|dhcp|ipoa)
			proto_mtu=`$NVRAM get wan${iface}_dhcp_mtu`
			MSS_MAX=$(($proto_mtu-40))
			;;
		pppoe|pppoa)
			proto_mtu="$($NVRAM get wan${iface}_pppoe_mtu)"
			if [ "$wan_proto" = "pppoa" ]; then
				proto_mtu="$($NVRAM get wan${iface}_pppoa_mtu)"
			fi
			if [ "x$proto_mtu" = "x" ]; then
			    proto_mtu=`$NVRAM get wan_ppp_mtu`
			fi
			if [ "$proto_mtu" -gt "1492" ]; then
				proto_mtu=1492
			fi
			MSS_MAX=$(($proto_mtu-40))
			;;
                pptp)
			proto_mtu="$($NVRAM get wan${iface}_pptp_mtu)"
			if [ "x$proto_mtu" = "x" ]; then
			    proto_mtu=`$NVRAM get wan_ppp_mtu`
			fi
			if [ "$proto_mtu" -gt "1452" ]; then
                            proto_mtu=1452
                        fi
			MSS_MAX=$(($proto_mtu-80))
			;;
                l2tp)
                        proto_mtu="$($NVRAM get wan${iface}_l2tp_mtu)"
                        if [ "x$proto_mtu" = "x" ]; then
                            proto_mtu=`$NVRAM get wan_ppp_mtu`
                        fi
                        if [ "$proto_mtu" -gt "1452" ]; then
            	        	proto_mtu=1452
            		    fi
                        MSS_MAX=$(($proto_mtu-80))
                        ;;
		*)
                         proto_mtu=`$NVRAM get wan${iface}_dhcp_mtu`
			MSS_MAX=$(($proto_mtu-40))
	esac
        
  	$IPTABLES -I FORWARD -o $wan_interface -p tcp --tcp-flags SYN,RST SYN -m tcpmss --mss $(($MSS_MAX+1)):65535 -j TCPMSS --set-mss $MSS_MAX
        $NVRAM set wan${iface}_mss=$MSS_MAX
}

find_corresponding_lan_group()
{
        interface_group_map=`$NVRAM get interface_group_map`
        local index=$iface
        if [ "$iface" = "$ETH_WAN_INDEX" ]; then
                index=$wan_default_iface
        fi
        if [ "$vlan_enable" = "0" ]; then
            group1=`echo $interface_group_map | cut -d":" -f 1 | grep "wan${index}" | grep "eth0"`   
            group2=`echo $interface_group_map | cut -d":" -f 2 | grep "wan${index}" | grep "eth0"`   
            group3=`echo $interface_group_map | cut -d":" -f 3 | grep "wan${index}" | grep "eth0"`   
            group4=`echo $interface_group_map | cut -d":" -f 4 | grep "wan${index}" | grep "eth0"`  
        
            if [ "x$group1" != "x" ]; then                        
                   LAN_GROUP=1
            elif [ "x$group2" != "x" ]; then
                   LAN_GROUP=2
            elif [ "x$group3" != "x" ]; then
                   LAN_GROUP=3
            elif [ "x$group4" != "x" ]; then
                  LAN_GROUP=4
            fi
        elif [ "$vlan_enable" = "1" ]; then
    
            vlan_type=`$NVRAM get vlan_type`
            if [ "$vlan_type" = "0" ]; then
                    keyword="vlan"
            elif [ "$vlan_type" = "1" ]; then            
                    keyword="tag"
            fi
            group1=`echo $interface_group_map | cut -d":" -f 1 | grep "wan${index}" | grep "$keyword"`   
            group2=`echo $interface_group_map | cut -d":" -f 2 | grep "wan${index}" | grep "$keyword"`   
            group3=`echo $interface_group_map | cut -d":" -f 3 | grep "wan${index}" | grep "$keyword"`   
            group4=`echo $interface_group_map | cut -d":" -f 4 | grep "wan${index}" | grep "$keyword"`  
        
            if [ "x$group1" != "x" ]; then                        
                   LAN_GROUP=1
            elif [ "x$group2" != "x" ]; then
                   LAN_GROUP=2
            elif [ "x$group3" != "x" ]; then
                   LAN_GROUP=3
            elif [ "x$group4" != "x" ]; then
                  LAN_GROUP=4
            fi
        fi

        if [ "$LAN_GROUP" = "0" ]; then
		if [ "`cat /firmware_region`" = "GR" ]; then
                	pvc_item=$($NVRAM get "atmPVC2")
               		if [ "x$pvc_item" != "x" ]; then
	               		ENABLE=`echo "$pvc_item" | awk -F* '{print $1}'`
		        	if [ "$ENABLE" = "1" ]; then
                   			LAN_GROUP=1
				fi 
			fi
		else
            		echo "Can't find lan group. wan iface $index" >> /dev/console
		fi
        fi
}

get_corresponding_lan_info()
{    
        if [ "${LAN_GROUP}" = "0" ]; then
            return;
        fi        
        lan_ipaddr=`$NVRAM get lan${LAN_GROUP}_ipaddr`
        lan_netmask=`$NVRAM get lan${LAN_GROUP}_netmask`
        LAN_MASKLEN=`print_masklen $lan_netmask`
        LAN_SUBNET=`print_subnet $lan_ipaddr $lan_netmask`
        lan_ifname=`$NVRAM get lan${LAN_GROUP}_ifname`
}

src_route_settings()
{    
      if [ "${LAN_GROUP}" = "0" ]; then
            return;
      fi
      echo "src_route_settings" >> /dev/console
      gateway=`$NVRAM get wan${iface}_default_gateway`
    
      RUL_NUMBER="${TABLE}${TABLE_INDEX}"
      rule_exist=`$IP rule list | grep "$RUL_NUMBER"`
      if [ "x$rule_exist" = "x" ]; then
            echo "ip rule add from ${LAN_SUBNET}/${LAN_MASKLEN} table ${TABLE}${TABLE_INDEX}" >> /dev/console
            $IP rule add pref ${PREF}${iface} from ${LAN_SUBNET}/${LAN_MASKLEN} table ${TABLE}${TABLE_INDEX} 2> /dev/null
      fi        

      if [ "$wan_proto" = "pptp" ] || [ "$wan_proto" = "l2tp" ]; then

            if [ "$wan_proto" = "pptp" ]; then
                if [ "$dy_pptp" = "1" ]; then
                    wan_intrnet_ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`
                    wan_intrnet_subnet=`$NVRAM get wan${iface}_dhcp_netmask`
                    wan_intrnet_gateway=`$NVRAM get wan${iface}_dhcp_gateway`
                    wan_intrnet_ifname=`$NVRAM get wan${iface}_dhcp_ifname`    
                else
                    wan_intrnet_ipaddr=`$NVRAM get wan${iface}_pptp_my_ip`
                    wan_intrnet_subnet=`$NVRAM get wan${iface}_pptp_my_mask`
                    wan_intrnet_gateway=`$NVRAM get wan${iface}_pptp_gw`
                    wan_intrnet_ifname=`$NVRAM get wan${iface}_hwifname`    
                fi
            fi

            if [ "$wan_proto" = "l2tp" ]; then
                if [ "$dy_l2tp" = "1" ]; then
                    wan_intrnet_ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`
                    wan_intrnet_subnet=`$NVRAM get wan${iface}_dhcp_netmask`
                    wan_intrnet_gateway=`$NVRAM get wan${iface}_dhcp_gateway`
                    wan_intrnet_ifname=`$NVRAM get wan${iface}_dhcp_ifname`                       
                else
                    wan_intrnet_ipaddr=`$NVRAM get wan${iface}_l2tp_my_ip`
                    wan_intrnet_subnet=`$NVRAM get wan${iface}_l2tp_my_mask`
                    wan_intrnet_gateway=`$NVRAM get wan${iface}_l2tp_gw`                    
                    wan_intrnet_ifname=`$NVRAM get wan${iface}_hwifname`    
                fi       
            fi
            
            mask_len=`print_masklen $wan_intrnet_subnet`
            sub_net=`print_subnet $wan_intrnet_ipaddr $wan_intrnet_subnet`
            
            if [ "$wan_ipaddr" != "$wan_intrnet_ipaddr" ]; then                                        
                #echo "IP route del  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}"
                $IP route del  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}  2> /dev/null                    
                #echo "$IP route del default via $wan_intrnet_gateway dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}"
                $IP route del default via $wan_intrnet_gateway dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}  2> /dev/null
                #echo "$IP route add default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX}"
                $IP route add default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
                #echo "$IP route add  $sub_net/$mask_len via $wan_intrnet_ipaddr dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}"
                $IP route add  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}  2> /dev/null
            else
                if [ "$INFORM" = "dhcpc" ] || [ "$INFORM" = "static" ]; then 
                    gateway=$wan_intrnet_gateway
                    #echo "IP route add  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}"
                    $IP route add  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}  2> /dev/null
                    #echo "ip route add default via $gateway dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}" >> /dev/console
                    #$IP route add default via $gateway dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
                else
                    #echo "ip route add default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX}" >> /dev/console
                    $IP route add default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
                fi
            fi
      else
            if [ "$wan_proto" = "pppoe" ]; then
                     if [ "$INFORM" = "dhcpc" ] || [ "$INFORM" = "static" ]; then 
                                if [ "$st_pppoe" = "0" ]; then
                                        wan_intrnet_ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`
                                        wan_intrnet_subnet=`$NVRAM get wan${iface}_dhcp_netmask`
                                        wan_intrnet_ifname=`$NVRAM get wan${iface}_hwifname`  
                                else
                                        wan_intrnet_ipaddr=`$NVRAM get wan${iface}_pppoe_intranet_ip`
                                        wan_intrnet_subnet=`$NVRAM get wan${iface}_pppoe_intranet_mask`
                                        wan_intrnet_ifname=`$NVRAM get wan${iface}_hwifname`
                                fi

                                mask_len=`print_masklen $wan_intrnet_subnet`
                                sub_net=`print_subnet $wan_intrnet_ipaddr $wan_intrnet_subnet`
                                echo "$IP route add  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}" >> /dev/console
                                $IP route add  $sub_net/$mask_len dev $wan_intrnet_ifname table ${TABLE}${TABLE_INDEX}  2> /dev/null
                     else
                                $AREA_CHK $wan_ipaddr $gateway $wan_netmask
                                if [ "$?" != "1" ]; then
                    			$IP route add $gateway/32 dev $wan_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
                                fi
				if [ "`cat /firmware_region`" != "GR" ]; then
	                                echo "ip route add default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX}" >> /dev/console
                                	$IP route add default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
				else
	                                echo "no default route setting in table 20x"
				fi

                     fi
            else

                if [ "$wan_proto" = "dhcp" ] || [ "$wan_proto" = "static" ]; then
                        mask_len=`print_masklen $wan_netmask`
                        sub_net=`print_subnet $wan_ipaddr $wan_netmask`
                        #echo "$IP route add  $sub_net/$mask_len dev $wan_ifname table ${TABLE}${TABLE_INDEX}"  >> /dev/console
                        $IP route add  $sub_net/$mask_len dev $wan_ifname table ${TABLE}${TABLE_INDEX}  2> /dev/null
                 fi
   
                 if [ "$wan_proto" != "ipoa" ]; then
                 	$AREA_CHK $wan_ipaddr $gateway $wan_netmask
	                 if [ "$?" != "1" ]; then
    				$IP route add $gateway/32 dev $wan_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
	                 fi
			 if [ "`cat /firmware_region`" != "GR" ]; then
	                 	echo "ip route add default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX}" >> /dev/console
				$IP route add default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
			 else
	                        echo "no default route setting in table 20x"
			 fi
		 else
			if [ "x$gateway" != "x" ]; then
                                 $IP route add default via $gateway dev $wan_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
                        else
                                 $IP route add default dev $wan_ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
                        fi
		 fi
             fi
      fi
        
      if [ "$vlan_enable" = "1" ]; then              
            LANS="1 2 3 4"  
      else
            LANS="1"  
      fi
      for item in $LANS
      do
            IPADDR=`$NVRAM get lan${item}_ipaddr`
            SUBNET=`$NVRAM get lan${item}_netmask`
            mask_len=`print_masklen $SUBNET`
            sub_net=`print_subnet $IPADDR $SUBNET`
            ifname=`$NVRAM get lan${item}_ifname`
            #echo "ip route add  $sub_net/$mask_len via $IPADDR dev $ifname table ${TABLE}${TABLE_INDEX}" >> /dev/console
            $IP route add  $sub_net/$mask_len dev $ifname table ${TABLE}${TABLE_INDEX} 2> /dev/null
      done
        
      $IP route flush cache  
}

stop_wan_rule()
{                
    echo "stop_wan_rule" >> /dev/console

    local INTRANET=1
    local ipaddr=$wan_ipaddr
    local interface=$wan_ifname
    local lan_ifname=`$NVRAM get lan${LAN_GROUP}_ifname`
    if [ "$wan_proto" = "pptp" ] || [ "$wan_proto" = "l2tp" ]; then
        if [ "$INFORM" = "dhcpc" ]; then
            interface=`$NVRAM get wan${iface}_dhcp_ifname`
            ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`    	    
        fi
        if [ "$INFORM" = "static" ]; then
             if [ "$wan_proto" = "pptp" ]; then
                    ipaddr=`$NVRAM get wan${iface}_pptp_my_ip`
    		    interface=`$NVRAM get wan${iface}_hwifname`
             elif [ "$wan_proto" = "l2tp" ]; then
                    ipaddr=`$NVRAM get wan${iface}_l2tp_my_ip`
                    interface=`$NVRAM get wan${iface}_hwifname`
             fi
        fi
    fi

    if [ "$wan_proto" = "pppoe" ]; then
            if [ "$INFORM" = "dhcpc" ] || [ "$INFORM" = "static" ]; then                     
                    if [ "$st_pppoe" = "0" ]; then
                            ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`
                            interface=`$NVRAM get wan${iface}_hwifname`
                    else
                            ipaddr=`$NVRAM get wan${iface}_pppoe_intranet_ip`
                            interface=`$NVRAM get wan${iface}_hwifname`
                    fi
            fi    	
    fi            
                                                                             
    $IPTABLES -t nat -D nat_local_server_init -d $ipaddr -j nat_local_server 2> /dev/null
    $IPTABLES -t nat -D nat_port_forward_init -d $ipaddr -j nat_port_forward 2> /dev/null
    $IPTABLES -t nat -D nat_port_trigger_inbound_init -d $ipaddr -j nat_port_trigger_inbound 2> /dev/null

    $IPTABLES -t nat -D nat_upnp_init -i $interface -d $ipaddr -j nat_upnp 2> /dev/null
    $IPTABLES -t nat -D nat_dmz_init -d $ipaddr -j nat_dmz 2> /dev/null
    $IPTABLES -t nat -D group${LAN_GROUP}_nat_endis -o $interface -s ${LAN_SUBNET}/${LAN_MASKLEN} -j SNATP2P --to-source $ipaddr 2> /dev/null
    $IPTABLES -t nat -D group${LAN_GROUP}_nat_endis -o $lan_ifname -s ${LAN_SUBNET}/${LAN_MASKLEN} -j SNATP2P --to-source $ipaddr 2> /dev/null
    #$IPTABLES -t nat -D group${LAN_GROUP}_nat_endis -o $interface -j SNATP2P --to-source $ipaddr 2> /dev/null
    #$IPTABLES -t nat -D group${LAN_GROUP}_nat_endis -o $interface -s ${LAN_SUBNET}/${LAN_MASKLEN} -j SNATP2P --to-source $ipaddr
    #$IPTABLES -t nat -D nat_endis -o $interface -s ${LAN_SUBNET}/${LAN_MASKLEN} -j MASQUERADE  2> /dev/null
    #$IPTABLES -t nat -D group${LAN_GROUP}_nat_endis -o $interface -s ${LAN_SUBNET}/${LAN_MASKLEN} -j MASQUERADE  2> /dev/null                   
}

start_wan_rule()
{
    echo "start_wan_rule" >> /dev/console
    
    local INTRANET=0
    local ipaddr=$wan_ipaddr
    local interface=$wan_ifname
    local lan_ifname=`$NVRAM get lan${LAN_GROUP}_ifname`
    
    if [ "$wan_proto" = "pptp" ]; then        
    	if [ "$dy_pptp" = "0" ] && [ "$INFORM" = "static" ]; then
                    ipaddr=`$NVRAM get wan${iface}_pptp_my_ip`
                    interface=`$NVRAM get wan${iface}_hwifname`        
                    INTRANET=1  
    	fi
        if [ "$dy_pptp" = "1" ] && [ "$INFORM" = "dhcpc" ]; then
                    ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`
                    interface=`$NVRAM get wan${iface}_hwifname`
                    INTRANET=1
        fi
    fi
    if [ "$wan_proto" = "l2tp" ]; then
        if [ "$dy_l2tp" = "0" ] && [ "$INFORM" = "static" ]; then                      
                    ipaddr=`$NVRAM get wan${iface}_l2tp_my_ip`
                    interface=`$NVRAM get wan${iface}_hwifname`          
                    INTRANET=1   
        fi
        if [ "$dy_l2tp" = "1" ] && [ "$INFORM" = "dhcpc" ]; then
                    ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`
                    interface=`$NVRAM get wan${iface}_hwifname`
                    INTRANET=1
        fi
    fi

    if [ "$wan_proto" = "pppoe" ]; then
            if [ "$INFORM" = "dhcpc" ] || [ "$INFORM" = "static" ]; then 
                    if [ "$st_pppoe" = "0" ]; then
                            ipaddr=`$NVRAM get wan${iface}_dhcp_ipaddr`
                            interface=`$NVRAM get wan${iface}_hwifname`
                    else
                            ipaddr=`$NVRAM get wan${iface}_pppoe_intranet_ip`
                            interface=`$NVRAM get wan${iface}_hwifname`
                    fi
                    INTRANET=1
            fi    	
    fi              
    	
    $IPTABLES -t nat -A nat_local_server_init -d $ipaddr -j nat_local_server 2> /dev/null      
    $IPTABLES -t nat -A nat_upnp_init -i $interface -d $ipaddr -j nat_upnp 2> /dev/null  

    if [ "$nat_endis" = "1" ] && [ "$LAN_GROUP" != "0" ]; then   # nat enable and can find corresponds lan interfaces
        $IPTABLES -t nat -A nat_port_forward_init -d $ipaddr -j nat_port_forward 2> /dev/null  
        $IPTABLES -t nat -A nat_port_trigger_inbound_init -d $ipaddr -j nat_port_trigger_inbound 2> /dev/null  

        $IPTABLES -t nat -A nat_dmz_init -d $ipaddr -j nat_dmz 2> /dev/null  
        #logger "[NAT Address Translation to Internet IP Address $wan_ipaddr]"
        #$IPTABLES -t nat -A group${LAN_GROUP}_nat_endis -o $interface -j SNATP2P --to-source $ipaddr
        $IPTABLES -t nat -A group${LAN_GROUP}_nat_endis -o $interface -s ${LAN_SUBNET}/${LAN_MASKLEN} -j SNATP2P --to-source $ipaddr
	# for vritual server hairpin from LAN site
        $IPTABLES -t nat -A group${LAN_GROUP}_nat_endis -o $lan_ifname -s ${LAN_SUBNET}/${LAN_MASKLEN} -j SNATP2P --to-source $ipaddr
        #$IPTABLES -t nat -A group${LAN_GROUP}_nat_endis -o $interface -s ${LAN_SUBNET}/${LAN_MASKLEN} -j SNATP2P --to-source $ipaddr
        #$IPTABLES -t nat -A nat_endis -o $interface -s ${LAN_SUBNET}/${LAN_MASKLEN} -j MASQUERADE  2> /dev/null  
        #$IPTABLES -t nat -A group${LAN_GROUP}_nat_endis -o $interface -s ${LAN_SUBNET}/${LAN_MASKLEN} -j MASQUERADE  2> /dev/null  

         echo "Setting action=1${LAN_GROUP}${iface}${INTRANET}" >> /dev/console
         $NVRAM set action=1${LAN_GROUP}${iface}${INTRANET}

         echo "Enable IP forwarding"
         echo 1 > /proc/sys/net/ipv4/ip_forward || echo "/proc not available"
    elif [ "$LAN_GROUP" != "0" ]; then 
         echo "Setting action=1${LAN_GROUP}${iface}${INTRANET}" >> /dev/console
         $NVRAM set action=1${LAN_GROUP}${iface}${INTRANET}
         echo 1 > /proc/sys/net/ipv4/ip_forward || echo "/proc not available"
    else
         echo "Setting action=10${iface}${INTRANET}" >> /dev/console
         $NVRAM set action=10${iface}${INTRANET}
         echo 1 > /proc/sys/net/ipv4/ip_forward || echo "/proc not available"
    fi
	            
    adjust_mss_value   
}

stop_nat_type()
{                
    echo "stop_nat type" >> /dev/console

    local interface=$wan_ifname
	local type=$nat_type

    if [ "$type" = "1" ]; then #Full Cone NAT
            $IPTABLES -t nat -D dnat -i $interface -j CONENAT --conenat-step dnat --conenat-type full 2> /dev/null
            $IPTABLES -D wan_forward -i $interface -j CONENAT --conenat-step in --conenat-type full 2> /dev/null
	else    # Restricted Cone NAT
            $IPTABLES -t nat -D dnat -i $interface -j CONENAT --conenat-step dnat --conenat-type restrict 2> /dev/null
            $IPTABLES -D wan_forward -i $interface -j CONENAT --conenat-step in --conenat-type restrict 2> /dev/null
    fi
}

start_nat_type()
{                
    if [ "$nat_endis" = "1" ] && [ "$LAN_GROUP" != "0" ]; then
            echo "start_nat type" >> /dev/console
        
            local interface=$wan_ifname
        	local type=$nat_type
        
            if [ "$type" = "1" ]; then #Full Cone NAT
  		    $IPTABLES -t nat -A dnat -i $interface -j CONENAT --conenat-step dnat --conenat-type full
               	    $IPTABLES -A wan_forward -i $interface -j CONENAT --conenat-step in --conenat-type full
            else    # Restricted Cone NAT
                    $IPTABLES -t nat -A dnat -i $interface -j CONENAT --conenat-step dnat --conenat-type restrict
                    $IPTABLES -A wan_forward -i $interface -j CONENAT --conenat-step in --conenat-type restrict
            fi
    fi
}

Remove_src_route_settings
find_corresponding_lan_group

get_corresponding_lan_info

if [ "$action" = "stop" ]; then
    stop_wan_rule
    stop_nat_type
    adjust_mss_value stop
    exit 0
fi

if [ "$action" = "restart" ]; then
    stop_wan_rule
    stop_nat_type
fi

#
# handle src route setting
#
src_route_settings restart
start_wan_rule
start_nat_type
