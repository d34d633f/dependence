#!/bin/sh
# this script is used to control management control list function

#[ -f /bin/iptables ] || exit 0

RETVAL=0

iptables="iptables"

# autofw_port format : outbound-proto(tcp/udp):outbound-port(d-d),inbound-proto(tdp/udp):inbound-port(d-d)>private-port(d-d),on/off,desc
add_autofw_port()
{
	local trigger_timeout=`nvram get porttrigger_timeout`
	local trigger="`nvram get triggering$1`"
	if [ -z "$trigger" ]; then
		return 0
	fi

	local svc_name=`echo $trigger | awk -F' ' '{print $1}'`
	local user_flag=`echo $trigger | awk -F' ' '{print $2}'`
	local trigger_ipaddr=`echo $trigger | awk -F' ' '{print $3}'`
	local outbound_proto=`echo $trigger | awk -F' ' '{print $4}'`
	local outbound_port=`echo $trigger | awk -F' ' '{print $5}'`
	local inbound_proto=`echo $trigger | awk -F' ' '{print $6}'`
	local inbound_port1=`echo $trigger | awk -F' ' '{print $7}'`
	local inbound_port2=`echo $trigger | awk -F' ' '{print $8}'`
	local trigger_enable=`echo $trigger | awk -F' ' '{print $9}'`
	if [ "$trigger_enable" = "0" ]; then
		return 0
	fi
	#echo "svc_name=$svc_name user_flag=$user_flag trigger_ipaddr=$trigger_ipaddr outbound_proto=$outbound_proto outbound_port=$outbound_port inbound_proto=$inbound_proto inbound_port1=$inbound_port1 inbound_port2=$inbound_port2 trigger_enable=$trigger_enable"
	if [ "$trigger_ipaddr" != "any" ]; then
		local single_ipaddr="-s `echo $trigger_ipaddr`"
	fi
	type=`echo $inbound_proto | awk -F'/' '{print $2}'`
	if [ "$type" = "UDP" ]; then
		inbound_proto="*"
	elif [ "$inbound_proto" = "TCP" ]; then
		inbound_proto="tcp"
	else
		inbound_proto="udp"
	fi
	if [ "$outbound_proto" = "TCP" ]; then
		outbound_proto="tcp"
	else
		outbound_proto="udp"
	fi

	if [ "$inbound_proto" = "*" ]; then
		$iptables -A fwd_port_trigger $single_ipaddr -i br0 -p $outbound_proto --dport $outbound_port -j TRIGGER \
--trigger-type out --trigger-proto all --trigger-match $outbound_port-$outbound_port --trigger-relate $inbound_port1-$inbound_port2 --trigger-timeout $trigger_timeout
		inbound_proto="tcp"
		$iptables -t nat -A nat_port_trigger_inbound -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type dnat --trigger-timeout $trigger_timeout
		$iptables -A fwd_port_trigger -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type in --trigger-timeout $trigger_timeout
		inbound_proto="udp"
		$iptables -t nat -A nat_port_trigger_inbound -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type dnat --trigger-timeout $trigger_timeout
		$iptables -A fwd_port_trigger -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type in --trigger-timeout $trigger_timeout
	else
	$iptables -t nat -A nat_port_trigger_inbound -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type dnat --trigger-timeout $trigger_timeout
	$iptables -A fwd_port_trigger -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type in --trigger-timeout $trigger_timeout
	$iptables -A fwd_port_trigger $single_ipaddr -i br0 -p $outbound_proto --dport $outbound_port -j TRIGGER \
--trigger-type out --trigger-proto $inbound_proto --trigger-match $outbound_port-$outbound_port --trigger-relate $inbound_port1-$inbound_port2 --trigger-timeout $trigger_timeout
	fi
}

# autofw_port format : outbound-proto(tcp/udp):outbound-port(d-d),inbound-proto(tdp/udp):inbound-port(d-d)>private-port(d-d),on/off,desc
del_autofw_port()
{
	local trigger_timeout=`nvram get porttrigger_timeout`
	local trigger="`nvram get triggering$1`"
	if [ -z "$trigger" ]; then
		return 0
	fi

	local svc_name=`echo $trigger | awk -F' ' '{print $1}'`
	local user_flag=`echo $trigger | awk -F' ' '{print $2}'`
	local trigger_ipaddr=`echo $trigger | awk -F' ' '{print $3}'`
	local outbound_proto=`echo $trigger | awk -F' ' '{print $4}'`
	local outbound_port=`echo $trigger | awk -F' ' '{print $5}'`
	local inbound_proto=`echo $trigger | awk -F' ' '{print $6}'`
	local inbound_port1=`echo $trigger | awk -F' ' '{print $7}'`
	local inbound_port2=`echo $trigger | awk -F' ' '{print $8}'`
	local trigger_enable=`echo $trigger | awk -F' ' '{print $9}'`
	if [ "$trigger_enable" = "0" ]; then
		return 0
	fi
	#echo "svc_name=$svc_name user_flag=$user_flag trigger_ipaddr=$trigger_ipaddr outbound_proto=$outbound_proto outbound_port=$outbound_port inbound_proto=$inbound_proto inbound_port1=$inbound_port1 inbound_port2=$inbound_port2 trigger_enable=$trigger_enable"
	if [ "$trigger_ipaddr" != "any" ]; then
		local single_ipaddr="-s `echo $trigger_ipaddr`"
	fi
	type=`echo $inbound_proto | awk -F'/' '{print $2}'`
	if [ "$type" = "UDP" ]; then
		inbound_proto="*"
	elif [ "$inbound_proto" = "TCP" ]; then
		inbound_proto="tcp"
	else
		inbound_proto="udp"
	fi
	if [ "$outbound_proto" = "TCP" ]; then
		outbound_proto="tcp"
	else
		outbound_proto="udp"
	fi

	if [ "$inbound_proto" = "*" ]; then
		$iptables -D fwd_port_trigger $single_ipaddr -i br0 -p $outbound_proto --dport $outbound_port -j TRIGGER \
--trigger-type out --trigger-proto all --trigger-match $outbound_port-$outbound_port --trigger-relate $inbound_port1-$inbound_port2 --trigger-timeout $trigger_timeout
		inbound_proto="tcp"
		$iptables -t nat -D nat_port_trigger_inbound -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type dnat --trigger-timeout $trigger_timeout
		$iptables -D fwd_port_trigger -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type in --trigger-timeout $trigger_timeout
		inbound_proto="udp"
		$iptables -t nat -D nat_port_trigger_inbound -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type dnat --trigger-timeout $trigger_timeout
		$iptables -D fwd_port_trigger -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type in --trigger-timeout $trigger_timeout
	else	
	$iptables -t nat -D nat_port_trigger_inbound -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type dnat --trigger-timeout $trigger_timeout
	$iptables -D fwd_port_trigger -p $inbound_proto --dport $inbound_port1:$inbound_port2 -j TRIGGER --trigger-type in --trigger-timeout $trigger_timeout
	$iptables -D fwd_port_trigger $single_ipaddr -i br0 -p $outbound_proto --dport $outbound_port -j TRIGGER \
--trigger-type out --trigger-proto $inbound_proto --trigger-match $outbound_port-$outbound_port --trigger-relate $inbound_port1-$inbound_port2 --trigger-timeout $trigger_timeout
	fi
}

add_one() {
	[ "$1" = "" ] && return
	add_autofw_port $1
}

delete_one() {
	[ "$1" = "" ] && return
	del_autofw_port $1
}

start() {
	PT_disable=`nvram get disable_port_trigger`
	if [ "$PT_disable" = "0" ]; then
    num=1
		entry="$(nvram get triggering${num})"
		while [ "$entry" != "" ]; do
			add_autofw_port $num
    	num=$(($num+1))
			entry="`nvram get triggering${num}`"
    done
	fi
}

stop() {
	$iptables -F fwd_port_trigger
	$iptables -F nat_port_trigger_inbound -t nat
}

case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  add_one)
	add_one $2
	;;
  delete_one)
	delete_one $2
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|add_one|delete_one|restart}"
	exit 1
esac

exit $RETVAL
