#!/bin/sh

DSL_CTRL=/usr/sbin/dslctrl
DSL_DET=/usr/sbin/dsldet

wan_phy_mode=`nvram get wan_phy_mode`
xDSL_fallback=`nvram get xDSL_fallback`
vlan_enable=`nvram get vlan_enable`
lan_hwifname=`nvram get lan_hwifname`
annex=`nvram get annex`
dsl_mode=`nvram get ADSL_mode`
wan_phy_auto=`nvram get wan_phy_auto`
ETH_WAN_INDEX=9

RETVAL=0

if [ $# != 1 ] ; then
	echo "usage: $0 [start|stop|restart]"
	exit 0
fi

create_adsl_iptables_chain()
{
    if [ "$wan_phy_mode" = "adsl" ]; then
        iptables -t nat -N nat_port_forward_init
        iptables -t nat -N nat_port_trigger_inbound_init                   
        iptables -t nat -N nat_dmz_init
        iptables -t nat -N nat_local_server_init
        iptables -t nat -N nat_upnp_init        
    
        iptables -t nat -N nat_endis
    
        iptables -N group1_forward
        iptables -N group2_forward
        iptables -N group3_forward
        iptables -N group4_forward
    
        iptables -t nat -N group1_postroute
        iptables -t nat -N group2_postroute
        iptables -t nat -N group3_postroute
        iptables -t nat -N group4_postroute
    
        iptables -t nat -N group1_local_server
        iptables -t nat -N group2_local_server
        iptables -t nat -N group3_local_server
        iptables -t nat -N group4_local_server
    
        iptables -t nat -N group1_nat_endis
        iptables -t nat -N group2_nat_endis
        iptables -t nat -N group3_nat_endis
        iptables -t nat -N group4_nat_endis
    fi
}


services_init()
{                           
        nvram unset current_dsl_mode

        if [ "$wan_phy_auto" = "0" ]; then
                WAN_INTFS="1 2 3 4 5 6 7 8"
        else
                WAN_INTFS="1 2 3 4 5 6 7 8 9"
        fi
        for iface in $WAN_INTFS
        do
                    nvram unset wan${iface}_dns
                    nvram unset wan${iface}_default_ipaddr
                    nvram unset wan${iface}_default_netmask
                    nvram unset wan${iface}_default_gateway
        done    

        if [ "$wan_phy_mode" = "vdsl" ]; then    
            nvram set wan_hwifname=ptm0
            /etc/rc.d/firewall.sh flush   
        
            /etc/rc.d/set_vdsl_wan_port.sh 
            /sbin/cmdwan.sh init_config   

            /etc/rc.d/service_start.sh start
        
        elif [ "$wan_phy_mode" = "adsl" ]; then                 
                            
            create_adsl_iptables_chain

            if [ "$wan_phy_auto" = "1" ]; then
                    nvram set wan${ETH_WAN_INDEX}_hwifname=nas0
            fi                             
            /etc/rc.d/firewall.sh flush   
            /etc/rc.d/firewall.sh init
            /etc/rc.d/firewall.sh security                                  
        
            /etc/rc.d/atm_start.sh start
           
             /sbin/cmdwan.sh init_config   
              
            #start all services for all lan
            /etc/rc.d/common_service.sh start         
                 
            #start all services for each lan (1-4)            
             if [ "$vlan_enable" = "1" ]; then                                              
                    /etc/rc.d/lan_service.sh start all 
             else
                    /etc/rc.d/lan_service.sh start 1 
             fi            
        fi
}


start() {
    echo $"Starting xdsl: "

    if [ "$wan_phy_mode" = "adsl" ]; then    
        rm -rf > /tmp/dsl_ds_rate
        rm -rf > /tmp/dsl_us_rate
        if [ "`cat /tmp/eth_bringup_adsl`" != "eth" ]; then
                echo Link down > /tmp/WAN_status
                echo 0 > /tmp/WAN_uptime
        fi
        echo DOWN > /tmp/dsl_status

        if [ "`cat /tmp/eth_bringup_adsl`" != "eth" ]; then
                $DSL_DET &
        fi

        $DSL_CTRL startup $dsl_mode
        $DSL_CTRL getversion | awk -F: '{print $2}' > /tmp/dsl_version       
 
	annex=`nvram get annex`
	if [ "$annex" = "B" ] || [ "$annex" = "b" ]; then
                echo "To set AnnexB"
                sleep 2
                dslctrl setannex $dsl_mode 4      # for annex B

                #dslctrl setannex [value]
                #Value: 0  annex M and annex L are disabled
                #1  annex M is enabled, annex L is disabled
                #2  annex M is disabled, annex L is enabled
                #3  annex M and annex L are enabled
                #4  annex B is enabled, annex M and L are disabled
	fi
    fi
}

stop() {
    echo $"Stopping xdsl: "

    rm -rf > /tmp/dsl_ds_rate
    rm -rf > /tmp/dsl_us_rate

    if [ "`cat /tmp/eth_bringup_adsl`" != "eth" ]; then
        echo Link down > /tmp/WAN_status
        echo 0 > /tmp/WAN_uptime
    fi
    echo DOWN > /tmp/dsl_status
}

set_mode()
{
     echo $"Sstting Xdsl mode: "

     $DSL_CTRL setmode $dsl_mode

     annex=`nvram get annex`
     if [ "$annex" = "B" ] || [ "$annex" = "b" ]; then
                echo "To set AnnexB"
                sleep 2
                dslctrl setannex $dsl_mode 4      # for annex B

                #dslctrl setannex [value]
                #Value: 0  annex M and annex L are disabled
                #1  annex M is enabled, annex L is disabled
                #2  annex M is disabled, annex L is enabled
                #3  annex M and annex L are enabled
                #4  annex B is enabled, annex M and L are disabled
     fi
}

case "$1" in  
  start)
	start
	;;
  stop)
	stop
	;;
  setmode)
	set_mode
	;;
  services_init)
	services_init
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart} "
	exit 1
esac

exit $RETVAL
