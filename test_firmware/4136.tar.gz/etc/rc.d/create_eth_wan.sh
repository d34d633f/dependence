#!/bin/sh

RETVAL=0
wan_proto=`nvram get wan_proto`
wan_hwifname=`nvram get wan_hwifname`
nvram set wan_dhcphwifname=$wan_hwifname

#To check if HWNAT is enabled
if [ -f /proc/rtl865x/ip ]; then	
	if [ "$wan_hwifname" = "nas0" ]; then
		wan_hwifname="nas0_0"
		nvram set wan_hwifname=$wan_hwifname
		nvram set wan_dhcphwifname=$wan_hwifname
	fi
fi

if [ "$wan_hwifname" != "nas0_0" ]; then
	exit $RETVAL
fi

if [ -f /proc/rtl865x/ip ]; then
	if [ "$wan_proto" = "pppoe" ]; then
		nvram set wan_dhcphwifname=nas0_1
	fi
else
	nvram set wan_hwifname=nas0
	nvram set wan_dhcphwifname=nas0
	exit $RETVAL
fi

start() {
	# Start daemons.

	ifconfig nas0 up
	case "$wan_proto" in	
		static | dhcp)
			ethctl addsmux ipoe nas0 $wan_hwifname
			;;
		pppoe)
			wan_dhcphwifname=`nvram get wan_dhcphwifname`
			ethctl addsmux ipoe nas0 $wan_dhcphwifname
			ethctl addsmux pppoe nas0 $wan_hwifname
			;;
		pptp)
			ethctl addsmux ipoe nas0 $wan_hwifname
			;;
		l2tp)
			ethctl addsmux ipoe nas0 $wan_hwifname
			;;
		*)

			echo $"Usage: $0 {start|stop|restart}"
	esac

	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	wan_dhcphwifname=`nvram get wan_dhcphwifname`
	ethctl remsmux ipoe nas0 $wan_dhcphwifname
	ethctl remsmux ipoe nas0 $wan_hwifname
	ethctl remsmux pppoe nas0 $wan_hwifname
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

