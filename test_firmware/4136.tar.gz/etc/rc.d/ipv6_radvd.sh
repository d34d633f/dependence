#!/bin/sh
RETVAL=0
prog="/usr/sbin/radvd"
IPv6_FILE="/proc/net/if_inet6"
CONFIG_FILE="/tmp/radvd.config"
nvram="/usr/sbin/nvram"
IPV6_LAN_DHCP=`$nvram get ipv6_dhcps_enable`
IPV6_LAN_TYPE=`$nvram get ipv6_lan_type`
MIN_RT_ADV_GAP=`$nvram get min_rt_adv`
MAX_RT_ADV_GAP=`$nvram get max_rt_adv`
RT_ADV_MTU=`$nvram get rt_adv_mtu`
RT_LIFE_TIME=`$nvram get rt_life_time`
WAN_PHY_MODE=`$nvram get wan_phy_mode`
VLAN_ENABLE=`$nvram get vlan_enable`


calculate_prefix(){

	if [ -n "$TMP_LAN_IPV6" ];then
		if [ "$HEX_PRELEN" != "80" ];then
			# get LAN prefix that Global Scope:"00"
			TMP_PRELEN=`printf "%d" 0x$HEX_PRELEN`
			REMAINDER=`expr $TMP_PRELEN % 4`
			HEX_LEN=`expr $TMP_PRELEN / 4`
			I=0

			# get normal prefix
			while [ "$I" -lt "$HEX_LEN" ]
			do
				I=`expr $I + 1`
				EACH_CHAR=`expr substr "$TMP_LAN_IPV6" $I 1`
				PRE_LAN_IPV6="${PRE_LAN_IPV6}${EACH_CHAR}"
				BIT_16=`expr $I % 4`
				if [ "$BIT_16" = "0" ];then
					PRE_LAN_IPV6=`printf "%s:" $PRE_LAN_IPV6`
				fi
			done

			#get last char prefix if ((prefix%4) != 0)
			#REMAINDER=`expr $REMAINDER + 1`
			if [ "$REMAINDER" != "0" ];then
				I=`expr $I + 1`
				LAST_CHAR=`expr substr "$TMP_LAN_IPV6" $I 1`
				case $REMAINDER in
					"1")
						LAST_CHAR=$((LAST_CHAR & 8))
					;;
					"2")
						LAST_CHAR=$((LAST_CHAR & 12))
					;;
					"3")
						LAST_CHAR=$((LAST_CHAR & 14))
					;;
				esac
				LAST_CHAR=`printf "%x" $LAST_CHAR`
				PRE_LAN_IPV6="$PRE_LAN_IPV6$LAST_CHAR"
				BIT_16=`expr $I % 4`
				if [ "$BIT_16" = "0" ];then
					PRE_LAN_IPV6=`printf "%s:" $PRE_LAN_IPV6`
				fi
				#BIT_16=`expr $BIT_16 + 1`
				#if [ "$BIT_16" = "0" ];then
				#	PRE_LAN_IPV6=`printf "%s000:" $PRE_LAN_IPV6`
				#fi
			fi

			#To let prefix be set of 16 bit
			#BIT_16=`expr $BIT_16 + 1`
			if [ "$BIT_16" != "0" ];then
				case $BIT_16 in
					"1")
						PRE_LAN_IPV6=`printf "%s000:" $PRE_LAN_IPV6`
					;;
					"2")
						PRE_LAN_IPV6=`printf "%s00:" $PRE_LAN_IPV6`
					;;
					"3")
						PRE_LAN_IPV6=`printf "%s0:" $PRE_LAN_IPV6`
					;;
				esac
			fi
		fi
		#echo $PRE_LAN_IPV6
	fi
}


start() {

	echo "Start RADVD ..."
	if [ -e $CONFIG_FILE ]; then
		rm $CONFIG_FILE
	fi
	if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
		LAN_IF_NUM="1 2 3 4"
		for i in $LAN_IF_NUM;
		do
			LAN_IF_NAME=`$nvram get lan${i}_ifname`
			# get LAN ip that Global Scope:"00"
			TMP_LAN_IPV6=`cat $IPv6_FILE | grep ${LAN_IF_NAME} | awk '{print $1":"$4}' | awk -F: '/:00/{print $1}'`
			HEX_PRELEN=`cat $IPv6_FILE | grep ${LAN_IF_NAME} | awk '{print $1":"$4"/"$3}' | awk -F/ '/:00/{print $2}'`
			LAN_IPV6=`ifconfig ${LAN_IF_NAME} | grep Scope:Link | awk '{printf $3}' | awk -F/ '{printf $1}'`
			if [ -n "$TMP_LAN_IPV6" ];then
				calculate_prefix
			fi
				echo 'interface '$LAN_IF_NAME > $CONFIG_FILE
				echo '{' >> $CONFIG_FILE
				echo '	AdvSendAdvert on;' >> $CONFIG_FILE
				if [ -n "$MAX_RT_ADV_GAP" ];then
					echo '  MaxRtrAdvInterval '$MAX_RT_ADV_GAP';' >> $CONFIG_FILE
				fi
				if [ -n "$MIN_RT_ADV_GAP" ];then
					echo '  MinRtrAdvInterval '$MIN_RT_ADV_GAP';' >> $CONFIG_FILE
				fi
				if [ -n "$RT_ADV_MTU" ];then
					echo '  AdvLinkMTU '$RT_ADV_MTU';' >> $CONFIG_FILE
				fi
				if [ -n "$RT_LIFE_TIME" ];then
                	echo '	AdvDefaultLifetime  '$RT_LIFE_TIME';' >> $CONFIG_FILE
            	fi
				echo '  AdvDefaultPreference low;' >> $CONFIG_FILE
				echo '  AdvOtherConfigFlag on;' >> $CONFIG_FILE	#Enable Other Configure bit
				if [ "$IPV6_LAN_DHCP" = "1" ];then
					echo '	AdvManagedFlag on;' >> $CONFIG_FILE	#Enable Managed bit
				else
					echo '  RDNSS '$LAN_IPV6 >> $CONFIG_FILE
					echo '  {' >> $CONFIG_FILE
					echo '      ' >> $CONFIG_FILE
					echo '  };' >> $CONFIG_FILE
					if [ -n "$PRE_LAN_IPV6" ];then
						echo '	prefix '$PRE_LAN_IPV6':/'$TMP_PRELEN >> $CONFIG_FILE
						echo '	{' >> $CONFIG_FILE
						echo '		AdvOnLink on;' >> $CONFIG_FILE
						echo '		AdvAutonomous on;' >> $CONFIG_FILE
						echo '		AdvValidLifetime 2400;' >> $CONFIG_FILE
						echo '		AdvPreferredLifetime 1800;' >> $CONFIG_FILE
						echo '	};' >> $CONFIG_FILE
					fi
				fi
				echo '};' >> $CONFIG_FILE
			#fi
			unset LAN_IF_NAME
			unset TMP_LAN_IPV6
			unset HEX_PRELEN
			unset PRE_LAN_IPV6
		done
	else
		FOR_V6_READY_LOGO=`$nvram get ready_logo_mode`
		LAN_IF_NAME=`$nvram get lan_ifname`
		TMP_LAN_IPV6=`cat $IPv6_FILE | grep ${LAN_IF_NAME} | awk '{print $1":"$4}' | awk -F: '/:00/{print $1}'`
		HEX_PRELEN=`cat $IPv6_FILE | grep ${LAN_IF_NAME} | awk '{print $1":"$4"/"$3}' | awk -F/ '/:00/{print $2}'`
		LAN_IPV6=`ifconfig ${LAN_IF_NAME} | grep Scope:Link | awk '{printf $3}' | awk -F/ '{printf $1}'`
		if [ -n "$TMP_LAN_IPV6" ];then
			calculate_prefix
		fi
			echo 'interface '$LAN_IF_NAME > $CONFIG_FILE
			echo '{' >> $CONFIG_FILE
			echo '	AdvSendAdvert on;' >> $CONFIG_FILE
			if [ -n "$MAX_RT_ADV_GAP" ];then
				echo '	MaxRtrAdvInterval '$MAX_RT_ADV_GAP';' >> $CONFIG_FILE
			fi
			if [ -n "$MIN_RT_ADV_GAP" ];then
				echo '	MinRtrAdvInterval '$MIN_RT_ADV_GAP';' >> $CONFIG_FILE
			fi
			if [ -n "$RT_ADV_MTU" ];then
				echo '	AdvLinkMTU '$RT_ADV_MTU';' >> $CONFIG_FILE
            fi
			if [ -n "$RT_LIFE_TIME" ];then
				echo '	AdvDefaultLifetime  '$RT_LIFE_TIME';' >> $CONFIG_FILE
			fi
			echo '  AdvDefaultPreference low;' >> $CONFIG_FILE
			echo '  AdvOtherConfigFlag on;' >> $CONFIG_FILE #Enable Other Configure bit
			if [ "$IPV6_LAN_DHCP" = "1" ];then
				echo '  AdvManagedFlag on;' >> $CONFIG_FILE #Enable Managed bit
			else
				echo '  RDNSS '$LAN_IPV6 >> $CONFIG_FILE
				echo '  {' >> $CONFIG_FILE
				echo '      ' >> $CONFIG_FILE
				echo '  };' >> $CONFIG_FILE
				if [ -n "$PRE_LAN_IPV6" ];then
					echo '	prefix '$PRE_LAN_IPV6':/'$TMP_PRELEN >> $CONFIG_FILE
					echo '	{' >> $CONFIG_FILE
					echo '		AdvOnLink on;' >> $CONFIG_FILE
					echo '		AdvAutonomous on;' >> $CONFIG_FILE
					echo '		AdvValidLifetime 2400;' >> $CONFIG_FILE
					echo '		AdvPreferredLifetime 1800;' >> $CONFIG_FILE
					echo '	};' >> $CONFIG_FILE
				fi
			fi
			echo '};' >> $CONFIG_FILE
		if [ "$FOR_V6_READY_LOGO" = "1" ];then
			WAN_IF_NAME=`$nvram get ipv6_if_name`
			WAN_IPV6=`ifconfig ${WAN_IF_NAME} | grep Scope:Link | awk '{printf $3}' | awk -F/ '{printf $1}'`
			TMP_LAN_IPV6=`cat $IPv6_FILE | grep ${WAN_IF_NAME} | awk '{print $1":"$4}' | awk -F: '/:00/{print $1}'`
	        HEX_PRELEN=`cat $IPv6_FILE | grep ${LAN_IF_NAME} | awk '{print $1":"$4"/"$3}' | awk -F/ '/:00/{print $2}'`
			if [ -n "$TMP_LAN_IPV6" ];then
				PRE_LAN_IPV6=""
            	calculate_prefix
        	fi
			echo 'interface '$WAN_IF_NAME >> $CONFIG_FILE
            echo '{' >> $CONFIG_FILE
            echo '  AdvSendAdvert on;' >> $CONFIG_FILE
            if [ -n "$MAX_RT_ADV_GAP" ];then
                echo '  MaxRtrAdvInterval '$MAX_RT_ADV_GAP';' >> $CONFIG_FILE
            fi
            if [ -n "$MIN_RT_ADV_GAP" ];then
                echo '  MinRtrAdvInterval '$MIN_RT_ADV_GAP';' >> $CONFIG_FILE
            fi
            if [ -n "$RT_ADV_MTU" ];then
                echo '  AdvLinkMTU '$RT_ADV_MTU';' >> $CONFIG_FILE
            fi
            if [ -n "$RT_LIFE_TIME" ];then
                echo '  AdvDefaultLifetime  '$RT_LIFE_TIME';' >> $CONFIG_FILE
            fi
            echo '  AdvDefaultPreference low;' >> $CONFIG_FILE
            echo '  AdvOtherConfigFlag on;' >> $CONFIG_FILE #Enable Other Configure bit
            if [ "$IPV6_LAN_DHCP" = "1" ];then
                echo '  AdvManagedFlag on;' >> $CONFIG_FILE #Enable Managed bit
            else
                echo '  RDNSS '$WAN_IPV6 >> $CONFIG_FILE
                echo '  {' >> $CONFIG_FILE
                echo '      ' >> $CONFIG_FILE
                echo '  };' >> $CONFIG_FILE
                if [ -n "$PRE_LAN_IPV6" ];then
                    echo '  prefix '$PRE_LAN_IPV6':/'$TMP_PRELEN >> $CONFIG_FILE
                    echo '  {' >> $CONFIG_FILE
                    echo '      AdvOnLink on;' >> $CONFIG_FILE
                    echo '      AdvAutonomous on;' >> $CONFIG_FILE
                    echo '      AdvValidLifetime 2400;' >> $CONFIG_FILE
                    echo '      AdvPreferredLifetime 1800;' >> $CONFIG_FILE
                    echo '  };' >> $CONFIG_FILE
                fi
            fi
            echo '};' >> $CONFIG_FILE
		fi
	fi


	$prog -C $CONFIG_FILE

	RETVAL=$?
    return $RETVAL
}

stop() {

	echo "Stop RADVD ..."
	killall radvd
	if [ -e "$CONFIG_FILE" ];then
		rm $CONFIG_FILE
	fi
	RETVAL=$?
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart|reload)
    stop
    start
    RETVAL=$?
    ;;
  *)
    echo $"Usage: $0 {start|stop|restart}"
    exit 1
esac

exit $RETVAL
