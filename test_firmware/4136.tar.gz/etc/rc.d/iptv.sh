#!/bin/sh

NVRAM="/usr/sbin/nvram"

FW_REGION=`cat /firmware_region`
if [ "$FW_REGION" != "RU" ] && [ "$FW_REGION" != "GR" ]; then
    echo "Not support IPTV feature!"
    exit;
fi

iptv_bridge=`nvram get iptv_bridge`
if [ "$FW_REGION" = "GR" ] && [ "$iptv_bridge" != "1" ]; then
    echo "Not support IPTV bridge feature!"
    exit;
fi

df_lan_intf=`nvram get lan_ifname`
iptv1_lan_intf=`nvram get lan2_ifname`
iptv2_lan_intf=`nvram get lan3_ifname`

iptv1_enable=`nvram get atmPVC2 | awk -F* '{print $1}'`
iptv2_enable=`nvram get atmPVC3 | awk -F* '{print $1}'`

#LAN1="eth0.2"
#LAN2="eth0.3"
#LAN3="eth0.4"
#LAN4="eth0.5"
LAN1="eth0.5"
LAN2="eth0.4"
LAN3="eth0.3"
LAN4="eth0.2"
WLAN="wlan0"
GUEST1=""
GUEST2=""
GUEST3=""

#################################################
WLAN_VA_IF="wlan0-vap"
idx=0
for num in 1 2 3
do
	if [ "$(nvram get wlg"$num"_endis_guestNet)" = "1" ]; then
		eval GUEST"$num"=$WLAN_VA_IF"$idx"
		idx=$(($idx+1))
	else
		eval GUEST"$num"=""
	fi
done

echo IPTV Setup: Guest2:[$GUEST1] Guest3:[$GUEST2] Guest4:[$GUEST3]
#################################################


find_intf_name()
{
    	case "$1" in 

	     1)                                                                  
		echo "$LAN1"                                                           
		;;                                                                      
	     2)                                                               
		echo "$LAN2"                                                                    
		;;                                                                      
	     3)                                                                      
	    	echo "$LAN3"                                                              
		;;    
	     4)                                                                      
	    	echo "$LAN4"                                                              
		;;  
	     5)                                                                      
	    	echo "$WLAN"                                                              
		;; 
	     6)                                                                      
	    	echo "$GUEST1"
		if [ "$GUEST1" != "" ]; then
			iwpriv $GUEST1 set_mib guest_access=0
		fi                                                              
		;;                                                              	                            
	     7)                                                                      
	    	echo "$GUEST2"                                                              
		if [ "$GUEST2" != "" ]; then
			iwpriv $GUEST2 set_mib guest_access=0
		fi                                                              
		;;                                                              	                            
	     8)                                                                      
	    	echo "$GUEST3"                                                              
		if [ "$GUEST3" != "" ]; then
			iwpriv $GUEST3 set_mib guest_access=0
		fi                                                              
		;;                                                              	                            
	esac        
}


iptv_start()
{
    index=1
    is_iptv=0
    local ret;

    local iptv1_maps=`nvram get iptv1_intf_maps | sed 's/|/ /g'`  # 0|1|0|0|1|0 -- 0 1 0 0 1 0
    echo "$iptv1_maps"
    for member in $iptv1_maps
    do 
            if [ "$member" = "1" -a "$iptv1_enable" = "1" ]; then
	            name=`find_intf_name $index`
		    if [ "x$name" != "x" ]; then
	                    brctl delif $df_lan_intf $name 2> /dev/null 
        	            brctl delif $iptv2_lan_intf $name 2> /dev/null 
	                    brctl addif $iptv1_lan_intf $name 2> /dev/null
		    fi	
            else
                    name=`find_intf_name $index`
		    if [ "x$name" != "x" ]; then
                    	#brctl delif $iptv2_lan_intf $name 2> /dev/null
	                brctl delif $iptv1_lan_intf $name 2> /dev/null
	                brctl addif $df_lan_intf $name 2> /dev/null
		    fi
            fi
            index=$(($index+1))
    done

    if [ "$iptv1_enable" = "1" ]; then
         local iptv1_intf=`nvram get wan2_hwifname`
         echo "brctl addif $iptv1_lan_intf $iptv1_intf"
	 brctl addif $iptv1_lan_intf $iptv1_intf 2> /dev/null 
         is_iptv=$(($is_iptv+1))
    fi

    index=1
    local iptv2_maps=`nvram get iptv2_intf_maps | sed 's/|/ /g'`
    for member in $iptv2_maps
    do 
            if [ "$member" = "1" -a "$iptv2_enable" = "1" ]; then
                   name=`find_intf_name $index`
		    if [ "x$name" != "x" ]; then
                    	brctl delif $df_lan_intf $name 2> /dev/null 
	                brctl delif $iptv1_lan_intf $name 2> /dev/null 
        	        brctl addif $iptv2_lan_intf $name 2> /dev/null
		    fi
            else
                    name=`find_intf_name $index`
		    if [ "x$name" != "x" ]; then
                    	#brctl delif $iptv1_lan_intf $name 2> /dev/null
	                brctl delif $iptv2_lan_intf $name 2> /dev/null
        	        brctl addif $df_lan_intf $name 2> /dev/null
		    fi	
            fi
            index=$(($index+1))
    done

    if [ "$iptv2_enable" = "1" ]; then
         local iptv2_intf=`nvram get wan3_hwifname`
         echo "brctl addif $iptv2_lan_intf $iptv2_intf"
	 brctl addif $iptv2_lan_intf $iptv2_intf 2> /dev/null 
         is_iptv=$(($is_iptv+1))
         
    fi

     if [ "$is_iptv" != "0"  ]; then
            echo 1 > /proc/port_based_vlan_support
	    echo 1 > /proc/br_igmpsnoop	
     else
            echo 0 > /proc/port_based_vlan_support
	    local igmp_enable=`nvram get wan_endis_igmp`
	    if [ "$igmp_enable" = "1" ]; then
	    	echo 1 > /proc/br_igmpsnoop	
	    else	
	    	echo 0 > /proc/br_igmpsnoop
	    fi		
     fi
}

echo $"Checking iptv... "
iptv_start
