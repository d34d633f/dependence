#!/bin/sh

[ -f /usr/sbin/ripd ] || exit 0

RETVAL=0

find_wan()  #$1: lan group
{
     lan_group=$1
     WAN_INTFS="1 2 3 4 5 6 7 8"
     find_wan=`nvram get interface_group_map | cut -d":" -f $lan_group | grep "wan"`
     if [ "x$find_wan" != "x" ]; then
          temp=$find_wan
          for i in $WAN_INTFS
          do
              wan=`echo $temp | grep "wan$i"`
              if [ "x$wan" != "x" ]; then
                   find_wan=$i
                   break
              fi
         done
     fi
     echo $find_wan
}

wan_phy_mode=`nvram get wan_phy_mode`
if [ "$wan_phy_mode" = "adsl" ]; then
        multi_lan=1
	iface=$2	
        LAN=br${iface}
        wan_iface=`find_wan ${iface}`
        wan_ipadr=`nvram get wan${wan_iface}_default_ipaddr`           
        lan_ifname=`nvram get lan${iface}_ifname`
        wan_ifname=`nvram get wan${wan_iface}_ifname`
fi

prog="ripd"
RIP="/usr/sbin/ripd"
PID_FILE="/var/run/ripd${iface}.pid"
OPTION=""
rip_ver=`nvram get rip${iface}_ver`

if [ "$rip_ver" = "1" ] || [ "$rip_ver" = "2" ]; then
	rip_type="broadcast"
elif [ "$rip_ver" = "3" ]; then
	rip_type="multicast"
fi


start() {
	# Start daemons.
	[ "$rip_ver" = "0" -o "$rip_ver" = "" ] && exit 0
	
        if [ "x$iface" != "x" ]; then
            OPTION="-i ${iface}"                        
            if [ "x$wan_iface" != "x" ] && [ "$wan_ipadr" != "" ]; then
                OPTION="-i ${iface} -w ${wan_iface}"
            fi            
        fi

        echo $"Starting $prog $LAN:"

	${RIP} $OPTION &

        if [ "$multi_lan" = "1" ]; then
                iptables -I input_init 2 -i $lan_ifname -p udp --dport 520 -m pkttype ! --pkt-type $rip_type -j DROP
                if [ "$wan_ipadr" != "" ]; then
                        iptables -I input_init 2 -i $wan_ifname -p udp --dport 520 -m pkttype ! --pkt-type $rip_type -j DROP
        	        iptables -A local_server -i $wan_ifname -p udp --dport 520 -j ACCEPT
                fi
        else
        	iptables -I input_init 2 -p udp --dport 520 -m pkttype ! --pkt-type $rip_type -j DROP
        	iptables -A local_server -p udp --dport 520 -j ACCEPT
        fi

	RETVAL=$?
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting down ripd $LAN:"

        if [ -e ${PID_FILE} ]; then
		kill -9 `cat ${PID_FILE}`
	fi
	rm -f ${PID_FILE}

        if [ "$multi_lan" = "1" ]; then
            iptables -D local_server -i $wan_ifname -p udp --dport 520 -j ACCEPT > /dev/null 2>&1
	    iptables -D input_init -i $wan_ifname -p udp --dport 520 -m pkttype ! --pkt-type broadcast -j DROP > /dev/null 2>&1
	    iptables -D input_init -i $wan_ifname -p udp --dport 520 -m pkttype ! --pkt-type multicast -j DROP > /dev/null 2>&1
            iptables -D input_init -i $lan_ifname -p udp --dport 520 -m pkttype ! --pkt-type broadcast -j DROP > /dev/null 2>&1
	    iptables -D input_init -i $lan_ifname -p udp --dport 520 -m pkttype ! --pkt-type multicast -j DROP > /dev/null 2>&1
        else
	    iptables -D local_server -p udp --dport 520 -j ACCEPT > /dev/null 2>&1
	    iptables -D input_init -p udp --dport 520 -m pkttype ! --pkt-type broadcast -j DROP > /dev/null 2>&1
	    iptables -D input_init -p udp --dport 520 -m pkttype ! --pkt-type multicast -j DROP > /dev/null 2>&1
        fi

	rm -f ${PID_FILE}
	RETVAL=$?
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

