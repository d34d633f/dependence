#!/bin/sh

PROG="miniigd"

IFACE=$2
IS_MULTI_WAN=""
IGD_CONFIG=""
IGD_FIREWALL="/tmp/firewall_igd"

if [ "$IFACE" = "" ]; then
    BRIDGE_INTERFACE="br0"
	WAN_PROTO=`nvram get wan_proto`
else
    index=$(($IFACE-1))
	WAN_IFACE=$3
	WAN_NUM=$4
    BRIDGE_INTERFACE="br$index"
	WAN_PROTO=`nvram get wan${WAN_NUM}_proto`
	IGD_CONFIG="/tmp/igd_config${IFACE}"
	IGD_FIREWALL="/tmp/firewall_igd${WAN_NUM}"
	#echo "wan: [If${WAN_NUM}, $WAN_PROTO, $WAN_IFACE]"
fi

#BRIDGE_INTERFACE=br0
IGD_PID_FILE=/var/run/miniupnpd${IFACE}.pid
UPNP_ENABLED=`nvram get upnp_enable`

LAN_MAC=$(nvram get lan_hwaddr | sed -n 's/://gp')
UUID="12342409-1234-1234-5678-${LAN_MAC}"

start() {
	# for miniigd patch	
	#Set a flag to allow mini-igd to append firewall rule
	#echo 1 > /tmp/firewall_igd${IFACE}
	echo 1 > "${IGD_FIREWALL}"
	
	if [ $UPNP_ENABLED != 0 ]; then
		route del -net 239.255.255.250 netmask 255.255.255.255 ${BRIDGE_INTERFACE}
	  	route add -net 239.255.255.250 netmask 255.255.255.255 ${BRIDGE_INTERFACE}
		#eval `flash get WAN_DHCP`
		WAN_TYPE=1  #wan_type=DHCP, need to get nvram here 
		case "$WAN_PROTO" in	
			static)
				WAN_TYPE=0
				;;
			dhcp)		
				WAN_TYPE=1
				;;
			pppoe)
				WAN_TYPE=3
				;;
			pptp)
				WAN_TYPE=4
				;;
                        pppoa)
				WAN_TYPE=3
                                ;;
                        ipoa)
				WAN_TYPE=0
				;;
			#*)
				#echo $"wan_proto invalid: $WAN_PROTO"
		esac
		echo $"Starting $PROG: "
		if [ "$IGD_CONFIG" = "" ]; then
			miniigd -e $WAN_TYPE -i $BRIDGE_INTERFACE -P $IGD_PID_FILE -u $UUID
		else
			#echo "miniigd -e $WAN_TYPE -i $BRIDGE_INTERFACE -o $WAN_IFACE -n "$WAN_NUM" -P $IGD_PID_FILE -T $IGD_CONFIG -u $UUID"
			miniigd -e $WAN_TYPE -i $BRIDGE_INTERFACE -o $WAN_IFACE -n "$WAN_NUM" -P $IGD_PID_FILE -T $IGD_CONFIG -u $UUID
		fi
	fi
}

stop() {
	# Stop daemons.
	echo $"Shutting down $PROG: "
	if [ "$(nvram get wan_phy_mode)" = "adsl" ]; then
		#killall -15 miniigd 2> /dev/null		
		if [ -e ${IGD_PID_FILE} ]; then
                        killall -15 ${IGD_PID_FILE} 2 > /dev/null
			kill `cat ${IGD_PID_FILE}`
			rm -f $IGD_PID_FILE
		fi
        if [ -e "/var/run/miniupnpd.pid" ]; then
			kill `cat /var/run/miniupnpd.pid`
            rm -f /var/run/miniupnpd.pid
        fi
	else
		rm -f "/var/run/miniiupnp*.pid"
		killall -9 miniigd
	fi
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
