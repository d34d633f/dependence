#!/bin/sh
# this script is used to control management control list function

#[ -f /bin/iptables ] || exit 0

. /etc/rc.d/tools.sh

RETVAL=0
iptables="iptables"

LAN_INTFS="1 2 3 4"
find_lan()  #$1: lan group
{
     slect_wan=wan$1

    for i in $LAN_INTFS
    do 
            group=`nvram get interface_group_map | cut -d":" -f$i`
             if [ "x$group" != "x" ]; then
                    find=`echo $group | grep $slect_wan`
                    if [ "x$find" != "x" ]; then
                            lan_intf=$i
                            break
                    fi
            fi
    done
      
     echo $lan_intf
}

wan_default_iface=`nvram get wan_default_iface`
ETH_WAN_INDEX=`nvram get eth_wan_iface`
wan_phy_mode=`nvram get wan_phy_mode`
wan_phy_auto=`nvram get wan_phy_auto`
if [ "$wan_phy_mode" = "adsl" ]; then
        MULTI_WAN=1
fi

if [ "$MULTI_WAN" = "1" ]; then
        wan_iface=$2
        intranet=$3
        index=$wan_iface

        wan_ip=`nvram get wan${wan_iface}_default_ipaddr`
        if [ "$wan_phy_auto" = "1" ] && [ "$wan_iface" = "$wan_default_iface" ]; then
                if [ "x$wan_ip" = "x" ]; then
                        wan_iface=$ETH_WAN_INDEX
                        wan_ip=`nvram get wan${wan_iface}_default_ipaddr`
                fi
        fi
        if [ "$wan_iface" = "$ETH_WAN_INDEX" ]; then        
                index=$wan_default_iface
        fi
        lan_iface=`find_lan ${index}`
        
        if [ "$lan_iface" = "" ] || [ "$intranet" = "1" ]; then
            exit
        fi
fi

. /etc/rc.d/firewall_setup_function.sh

wan_ifname=`nvram get wan${wan_iface}_ifname`
#fw_disable=`nvram get fw_disable`
spi_enable=`nvram get wan${index}_endis_spi`

LAN_SUBNET=`nvram get lan${lan_iface}_netmask`
LAN_masklen=`print_masklen $LAN_SUBNET`

start() {
#	Kane suggest turing rp_filter off to avoid some troubles...
#	Using iptables to filter out IP spoofing instead.
#	for f in /proc/sys/net/ipv4/conf/*/rp_filter; do
#		echo 1 > $f
#	done
        echo $"Starting WAN${wan_iface} spi dos protect"
	if [ "$spi_enable" = "1" ]; then
        	#####################################################################
		# Enable support of dynamic IP addresses by kernel      
		echo 1 > /proc/sys/net/ipv4/ip_dynaddr
		# Enable broadcast echo Protection
		echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts
		# Disable ECN routing 
		echo 0 > /proc/sys/net/ipv4/tcp_ecn
		# Enable tcp SYN Cookie Protection
		#echo 1 > /proc/sys/net/ipv4/tcp_syncookies
		# Disable Source Routed Packets
		for f in /proc/sys/net/ipv4/conf/*/accept_source_route; do
			echo 1 >$f
		done
		# Disable ICMP Redirect Acceptance
		for f in /proc/sys/net/ipv4/conf/*/accept_redirects; do
			echo 0 > $f
		done
		# Log packets with impossible addressses
		for f in /proc/sys/net/ipv4/conf/*/log_martians; do
			echo 1 >$f
		done
		#########################################################################

                if [ "$MULTI_WAN" = "1" ]; then
                    wan_ifname=`nvram get wan${wan_iface}_ifname`
                    dos_firewall_advance $LAN_masklen
                    if [ "x$wan_iface" != "x" ]; then
                            nvram set wan${index}_spi_ifname=$wan_ifname
                    fi
                fi
		#add_dos_firewall_chain
                if [ "$MULTI_WAN" = "1" ]; then
                        TCPMSS=`iptables -L FORWARD | grep "TCPMSS" | wc -l`
                        insert_line=$(($TCPMSS+4+1))   # tcpmass+group_forwad+mac_filter
                        iptables -I FORWARD $insert_line -i $wan_ifname -j fwd_dos_input 2> /dev/null
                else
        		iptables -I FORWARD 4 -i $wan_ifname -j fwd_dos_input 2> /dev/null
                fi
		iptables -A FORWARD -i $wan_ifname -j fwd_dos_EchoChargen 2> /dev/null
		iptables -I FORWARD -t mangle -j fwd_dos_mangle 2> /dev/null		
	fi
}

stop() {
                if [ "$MULTI_WAN" = "1" ]; then
                    if [ "x$wan_iface" != "x" ]; then
                            wan_ifname=`nvram get wan${index}_spi_ifname`
                            nvram unset wan${index}_spi_ifname
                    fi
                fi

		iptables -D FORWARD -i $wan_ifname -j fwd_dos_input 2> /dev/null
		iptables -D FORWARD -i $wan_ifname -j fwd_dos_EchoChargen 2> /dev/null
		iptables -D FORWARD -t mangle -j fwd_dos_mangle 2> /dev/null

                 if [ "$MULTI_WAN" = "1" ]; then
                    del_dos_firewall_advance $LAN_masklen
                fi
}


case "$1" in  
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
