#!/bin/sh
WAN_PHY_MODE=`nvram get wan_phy_mode`
if [ "$WAN_PHY_MODE" = "adsl" ]; then
	iface=1
	if [ "$iface" = "`nvram get wan_default_iface`" ]; then
		DEFAULT_GW=1
	fi
else
	iface=""
	DEFAULT_GW=1
fi
WAN_IF_NAME=`nvram get wan${iface}_hwifname`
RETVAL=0
prog="pppd"
IPV6_USER_NAME=`nvram get ipv6_pppoe_username`
IPV6_PASSWD=`nvram get ipv6_pppoe_passwd`
IPV6_SERVERNAME=`nvram get ipv6_pppoe_servername`
PPPOE_PID=`ps | grep +ipv6 | grep pppd | awk '{printf $1 " "}'`
KEEP_ALIVE=`nvram get wan_pppoe_keepalive_time`
LCP_ECHO_FAILS="3"


start(){
	
	if [ "$IPV6_SERVERNAME" = "" ]; then
	$prog +ipv6 noip maxfail 0 plugin rp-pppoe.so ip_version 6 $WAN_IF_NAME  user $IPV6_USER_NAME password "$IPV6_PASSWD"  lcp-echo-failure ${LCP_ECHO_FAILS} lcp-echo-interval ${KEEP_ALIVE}
	else
	$prog +ipv6 noip maxfail 0 plugin rp-pppoe.so rp_pppoe_service ip_version 6 "${IPV6_SERVERNAME}" $WAN_IF_NAME  user $IPV6_USER_NAME password "$IPV6_PASSWD" lcp-echo-failure ${LCP_ECHO_FAILS} lcp-echo-interval ${KEEP_ALIVE}
	fi
	sleep 10
}

stop() {

	if [ -n "$PPPOE_PID" ];then
		kill $PPPOE_PID
	fi 

}

# See how we were called.
case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart|reload)
    stop
    start
    RETVAL=$?
    ;;
  *)
    echo $"Usage: $0 {start|stop|restart}"
    exit 1
esac

exit $RETVAL

