#!/bin/sh
#
#
. /etc/rc.d/tools.sh

TC="/usr/sbin/tc"
NVRAM="/usr/sbin/nvram"

RTL_FAST_PATH="/proc/FastPath"    ## realtek used
DSL_US_LINK_RATE="/tmp/dsl_us_rate"
DSL_DS_LINK_RATE="/tmp/dsl_ds_rate"
DSL_STATUS="/tmp/dsl_status"

U_QOS_CHAIN="u_qos_chain"
D_QOS_CHAIN="d_qos_chain"
DSCP_MODIFY="dscp_modify_chain"
QOS_DSCP="dscp_qos_chain"

HEST_Q_MARK="40"
H_Q_MARK="30"
N_Q_MARK="20"
L_Q_MARK="10"

SU_HEST_Q_MARK="90"
SU_H_Q_MARK="80"
SU_N_Q_MARK="70"
SU_L_Q_MARK="60"
SU_NO_MARK="50"

LAN_INTFS=`nvram get lan_hwifnames`
LAN_GROUP=""
NO_WAN=""

wan_phy_mode=`nvram get wan_phy_mode`
vlan_enable=`nvram get vlan_enable`

get_fast_lane_bandwidth()
{
    fast_lan_bandwidth=`nvram get fast_lan_bandwidth`
    case "$fast_lan_bandwidth" in
	0)
		echo "50"
		return
		;;
	1)
		echo "60"
		return
		;;
	2)
		echo "70"
		return
		;;
	3)
		echo "80"
		return
		;;
	*)
		exit 1
	esac
}

find_corresponding_lan_group()
{
        interface_group_map=`$NVRAM get interface_group_map`
        if [ "$vlan_enable" = "0" ]; then
            group1=`echo $interface_group_map | cut -d":" -f 1 | grep "wan${iface}" | grep "eth0"`   
            group2=`echo $interface_group_map | cut -d":" -f 2 | grep "wan${iface}" | grep "eth0"`   
            group3=`echo $interface_group_map | cut -d":" -f 3 | grep "wan${iface}" | grep "eth0"`   
            group4=`echo $interface_group_map | cut -d":" -f 4 | grep "wan${iface}" | grep "eth0"`  
        
            if [ "x$group1" != "x" ]; then                        
                   LAN_GROUP=1
            elif [ "x$group2" != "x" ]; then
                   LAN_GROUP=2
            elif [ "x$group3" != "x" ]; then
                   LAN_GROUP=3
            elif [ "x$group4" != "x" ]; then
                  LAN_GROUP=4
            fi
        elif [ "$vlan_enable" = "1" ]; then
    
            vlan_type=`$NVRAM get vlan_type`
            if [ "$vlan_type" = "0" ]; then
                    keyword="vlan"
            elif [ "$vlan_type" = "1" ]; then            
                    keyword="tag"
            fi
            group1=`echo $interface_group_map | cut -d":" -f 1 | grep "wan${iface}" | grep "$keyword"`   
            group2=`echo $interface_group_map | cut -d":" -f 2 | grep "wan${iface}" | grep "$keyword"`   
            group3=`echo $interface_group_map | cut -d":" -f 3 | grep "wan${iface}" | grep "$keyword"`   
            group4=`echo $interface_group_map | cut -d":" -f 4 | grep "wan${iface}" | grep "$keyword"`  
        
            if [ "x$group1" != "x" ]; then                        
                   LAN_GROUP=1
            elif [ "x$group2" != "x" ]; then
                   LAN_GROUP=2
            elif [ "x$group3" != "x" ]; then
                   LAN_GROUP=3
            elif [ "x$group4" != "x" ]; then
                  LAN_GROUP=4
            fi
        fi

        if [ "$LAN_GROUP" = "" ]; then
            echo "Can't find lan group. wan iface $iface" >> /dev/console
        fi
}


case "$wan_phy_mode" in
adsl)    
    WANNUM=`nvram get wan_default_iface`
    WAN_IF=`nvram get wan${WANNUM}_ifname`
    find_corresponding_lan_group

    if [ -f $DSL_STATUS ]; then  
            STATUS=`cat $DSL_STATUS`
            if  [ "$STATUS" = "DOWN" ]; then
                    echo "wan cable is not plug!"
                    NO_WAN="1"
            else
                    if [ -f $DSL_US_LINK_RATE ]; then            
                            UPRATE=`cat $DSL_US_LINK_RATE`
                            if  [ "x$UPRATE" != "x" ] && [ "$UPRATE" != "0" ]; then
                                UPRATE=$((8*${UPRATE}/10))
                            else
                                echo "upstream rate is 0 !"
                                NO_WAN="1"
                            fi              
                    else 
                        UPRATE=1100
                    fi
                    if [ "$(nvram get qos_threshold)" != "0" ]; then
                        UPRATE=`nvram get qos_uprate`
                    fi
                    if [ -f $DSL_DS_LINK_RATE ]; then            
                            DWRATE=`cat $DSL_DS_LINK_RATE`
                            if  [ "x$DWRATE" != "x" ] && [ "$DWRATE" != "0" ]; then
                                DWRATE=$((8*${DWRATE}/10))
                            else
                                echo "downstream rate is 0 !"
                            fi              
                    else 
                            DWRATE=20000
                    fi
            fi
    else 
            NO_WAN="1"
    fi    
    ;;
eth)
    WANNUM=
    WAN_IF=`nvram get wan${WANNUM}_ifname`    
    if [ -f /tmp/WAN_status ]; then
            WAN_STATUS=`cat /tmp/WAN_status`
            if [ "$WAN_STATUS" = "Link down" ]; then
                    NO_WAN="1"
            else
                    WAN_SPEED=`cat /tmp/WAN_status | cut -d"/" -f1`
                    case $WAN_SPEED in
        		"1000M")
        			UPRATE=1000000
                                DWRATE=1000000
        			;;
        		"100M")
        			UPRATE=100000
                                DWRATE=100000
        			;;
                        "10M")
        			UPRATE=10000
                                DWRATE=10000
        			;;
        		*)
        			UPRATE=10000
                                DWRATE=10000
        			;;
    		    esac
                    UPRATE=$((8*${UPRATE}/10))      
                    DWRATE=$((8*${DWRATE}/10))              
                    if [ "$(nvram get qos_threshold)" != "0" ]; then
                        UPRATE=`nvram get qos_uprate`
                    fi          
            fi
    fi
    ;;
vdsl)
    WANNUM=
    WAN_IF=`nvram get wan${WANNUM}_ifname`
    if [ "$(nvram get qos_bandwidth_type)" = "0" ]; then
        if [ -f $DSL_US_LINK_RATE ]; then
            UPRATE=`cat $DSL_US_LINK_RATE`
            UPRATE=$((8*${UPRATE}/10))
        else 
            UPRATE="102400"
        fi
    else
        UPRATE=`nvram get qos_uprate`
    fi      
    ;;
esac

DOWNLINK_RATE=102400

qos_enable=`nvram get qos_endis_on`
total_num=`nvram get qos_rule_count`

LAN_IF=`nvram get lan${LAN_GROUP}_ifname`
LAN_IPADDR=`nvram get lan${LAN_GROUP}_ipaddr`
LAN_SUBNET=`nvram get lan${LAN_GROUP}_netmask`
masklen=`print_masklen $LAN_SUBNET`
subnet=`print_subnet $LAN_IPADDR $LAN_SUBNET`

BANDCTL=`nvram get qos_threshold`
SU_ENABLE=`nvram get qos_enable_su`
FAST_LANE_ENABLE=`nvram get fast_lane_enable`

if [ "$FAST_LANE_ENABLE" = "1" ]; then
    SU_IP=`nvram get fast_lan_trusted_ip`    
    if [ "$SU_IP" = "" ]; then
        echo "no input fast lane IP address"
        NO_WAN="1"
    fi
    fast_lane_bandwidth=`get_fast_lane_bandwidth`
    SU_URATE=$((UPRATE*${fast_lane_bandwidth}/100))  
    QQ_URATE=$((UPRATE-$SU_URATE)) 
    SU_DS_URATE=$((DWRATE*${fast_lane_bandwidth}/100))  
    QQ_DS_URATE=$((DWRATE-$SU_DS_URATE)) 
elif [ "$SU_ENABLE" = "1" ]; then    
    SU_IP=`nvram get qos_su_ip`
    SU_URATE=$((UPRATE/2))  
    QQ_URATE=$((UPRATE-$SU_URATE)) 
fi



add="-A"
del="-D"

init_ht_tcp=0
init_h_tcp=0
init_m_tcp=0
init_l_tcp=0
init_ht_udp=0
init_h_udp=0
init_m_udp=0
init_l_udp=0

ht_tcp_port_list=""
h_tcp_port_list=""
m_tcp_port_list=""
l_tcp_port_list=""
ht_udp_port_list=""
h_udp_port_list=""
m_udp_port_list=""
l_udp_port_list=""

init_ht_mac=0
init_h_mac=0
init_m_mac=0
init_l_mac=0
ht_mac_list=""
h_mac_list=""
m_mac_list=""
l_mac_list=""

init_ht_phyport=0
init_h_phyport=0
init_m_phyport=0
init_l_phyport=0
ht_phyport_list=""
h_phyport_list=""
m_phyport_list=""
l_phyport_list=""

su_priority_switch()
{
	case "$1" in
	0)
		echo $SU_HEST_Q_MARK
		return
		;;
	1)
		echo $SU_H_Q_MARK
		return
		;;
	2)
		echo $SU_N_Q_MARK
		return
		;;
	3)
		echo $SU_L_Q_MARK
		return
		;;
	*)
		exit 1
	esac
}

priority_switch()
{
	case "$1" in
	0)
		echo $HEST_Q_MARK
		return
		;;
	1)
		echo $H_Q_MARK
		return
		;;
	2)
		echo $N_Q_MARK
		return
		;;
	3)
		echo $L_Q_MARK
		return
		;;
	*)
		exit 1
	esac
}

parsing_port()
{
	a=$1
	[ -f /tmp/array ] && rm /tmp/array
	str=`echo $a | cut -d ',' -f 1`
	set=15
	i=1
	count=0
	
	if [ "`echo $a | grep ','`" != "" ]; then
		while [ "$str" != "" ];
		do
		first=`echo $str | grep ':'`
		  if [ "$first" = "" ]; then
		     if [ "$(($count%$set))" = "$(($set-1))" ]; then
		         echo "$i" >> /tmp/count
		     fi
		     count=$(($count+1))  
		  else
		     if [ "$(($count%$set))" = "$(($set-2))" ]; then
		         echo "$i" >> /tmp/count
		     fi      
		     count=$(($count+2))
		  fi  
		i=$(($i+1))
		str=`echo $a | cut -d ',' -f $i`
		done
	else
		i=$(($i+1))
	fi
	
	#last one = i-1
	[ -f /tmp/count ] && numbers=`cat /tmp/count`
	start=1
	last=0
        
	for j in $numbers
	do
	  tmp=`echo $a | cut -d "," -f $start"-"$j`
	  echo "$tmp" >> /tmp/array
	  start=$(($j+1))
	  last=$j
	done
	start=$(($last+1))
	last=$(($i-1))
	
	tmp_last=`echo $a | cut -d "," -f $start"-"$last`
	echo "$tmp_last" >> /tmp/array
}

multi_port_rule()
{
	mproto=$1
	mport=$2
	mprio=$3
	
	case "$mprio" in
	0)
		## non_su hightest
		if [ "$mproto" = "TCP" ]; then
			if [ "$init_ht_tcp" = "0" ]; then
				ht_tcp_port_list=`echo "$mport"`
				init_ht_tcp=1
			else
				ht_tcp_port_list=`echo "$ht_tcp_port_list","$mport"`
			fi
		else
			if [ "$init_ht_udp" = "0" ]; then
				ht_udp_port_list=`echo "$mport"`
				init_ht_udp=1
			else
				ht_udp_port_list=`echo "$ht_udp_port_list","$mport"`
			fi
		fi
		;;
	1)
		## non_su high
		if [ "$mproto" = "TCP" ]; then
			if [ "$init_h_tcp" = "0" ]; then
				h_tcp_port_list=`echo "$mport"`
				init_h_tcp=1
			else
				h_tcp_port_list=`echo "$h_tcp_port_list","$mport"`
			fi
		else
			if [ "$init_h_udp" = "0" ]; then
				h_udp_port_list=`echo "$mport"`
				init_h_udp=1
			else
				h_udp_port_list=`echo "$h_udp_port_list","$mport"`
			fi
		fi
		;;
	2)
		## non_su normal
		if [ "$mproto" = "TCP" ]; then
			if [ "$init_m_tcp" = "0" ]; then
				m_tcp_port_list=`echo "$mport"`
				init_m_tcp=1
			else
				m_tcp_port_list=`echo "$m_tcp_port_list","$mport"`
			fi
		else
			if [ "$init_m_udp" = "0" ]; then
				m_udp_port_list=`echo "$mport"`
				init_m_udp=1
			else
				m_udp_port_list=`echo "$m_udp_port_list","$mport"`
			fi
		fi
		;;
	3)
		## non_su low
		if [ "$mproto" = "TCP" ]; then
			if [ "$init_l_tcp" = "0" ]; then
				l_tcp_port_list=`echo "$mport"`
				init_l_tcp=1
			else
				l_tcp_port_list=`echo "$l_tcp_port_list","$mport"`
			fi
		else
			if [ "$init_l_udp" = "0" ]; then
				l_udp_port_list=`echo "$mport"`
				init_l_udp=1
			else
				l_udp_port_list=`echo "$l_udp_port_list","$mport"`
			fi
		fi
		;;
	*)
		;;
	esac

}

set_phyport_iptables()
{
        set_prio=$1
        su=$2
        case "$set_prio" in
	0)
                phyport_list=$ht_phyport_list
                ;;
        1)
                phyport_list=$h_phyport_list
                ;;
        2)
                phyport_list=$m_phyport_list
                ;;
        3)
                phyport_list=$l_phyport_list
                ;;
        *)
                ;;
        esac

        for item in $phyport_list
        do
                if [ "$SU_ENABLE" = "1" ] || [ "$FAST_LANE_ENABLE" = "1" ]; then
                        if [ "$su" = "1" ]; then
                                #echo "iptables -t mangle ${add} $U_QOS_CHAIN -i ${item} -s $SU_IP -j MARK --set-mark $(su_priority_switch $set_prio)"
                                iptables -t mangle ${add} $U_QOS_CHAIN -i ${item} -s $SU_IP -j MARK --set-mark $(su_priority_switch $set_prio)	
                        else                                        
                                #echo "iptables -t mangle ${add} $U_QOS_CHAIN -i ${item} -s ! $SU_IP -j MARK --set-mark $(priority_switch $set_prio)"
                                iptables -t mangle ${add} $U_QOS_CHAIN -i ${item} -s ! $SU_IP -j MARK --set-mark $(priority_switch $set_prio)	
                        fi
                else
	                #uplink
                        echo "iptables -t mangle ${add} $U_QOS_CHAIN -i ${item} -j MARK --set-mark $(priority_switch $set_prio)"
	                iptables -t mangle ${add} $U_QOS_CHAIN -i ${item} -j MARK --set-mark $(priority_switch $set_prio)	
                fi
        done
}


set_mac_iptables()
{
        set_prio=$1
        su=$2
        case "$set_prio" in
	0)
                mac_list=$ht_mac_list
                ;;
        1)
                mac_list=$h_mac_list
                ;;
        2)
                mac_list=$m_mac_list
                ;;
        3)
                mac_list=$l_mac_list
                ;;
        *)
                ;;
        esac

        for mac in $mac_list
        do
                if [ "$SU_ENABLE" = "1" ] || [ "$FAST_LANE_ENABLE" = "1" ]; then
                        if [ "$su" = "1" ]; then
                                #echo "iptables -t mangle ${add} $U_QOS_CHAIN -s $SU_IP -m mac --mac-source $mac -j MARK --set-mark $(su_priority_switch $set_prio)"
                                iptables -t mangle ${add} $U_QOS_CHAIN -s $SU_IP -m mac --mac-source $mac -j MARK --set-mark $(su_priority_switch $set_prio)	
                        else
                                #echo "iptables -t mangle ${add} $U_QOS_CHAIN -s ! $SU_IP -m mac --mac-source $mac -j MARK --set-mark $(priority_switch $set_prio)"
                                iptables -t mangle ${add} $U_QOS_CHAIN -s ! $SU_IP -m mac --mac-source $mac -j MARK --set-mark $(priority_switch $set_prio)	
                        fi
                else
	                #uplink
                        #echo "iptables -t mangle ${add} $U_QOS_CHAIN -m mac --mac-source $mac -j MARK --set-mark $(priority_switch $set_prio)	"
	                iptables -t mangle ${add} $U_QOS_CHAIN -m mac --mac-source $mac -j MARK --set-mark $(priority_switch $set_prio)		
                fi
        done

}

set_multiport_iptables()
{
	set_proto=$1
	set_prio=$2
        su=$3

	line=`grep [0-9] -c /tmp/array`
	num=1

	while [ "$num" -le "$line" ]; do
		rule_list=`cat /tmp/array | sed -n $num"p"`		
		#uplink
                if [ "$SU_ENABLE" = "1" ] || [ "$FAST_LANE_ENABLE" = "1" ]; then
                        if [ "$su" = "1" ]; then
                                #echo "iptables -t mangle $add $U_QOS_CHAIN -s $SU_IP -p $set_proto -m multiport --dports $rule_list -j MARK --set-mark $(su_priority_switch $set_prio)"
                                iptables -t mangle $add $U_QOS_CHAIN -s $SU_IP -p $set_proto -m multiport --dports $rule_list -j MARK --set-mark $(su_priority_switch $set_prio) 2> /dev/null  
                        else
                                #echo "iptables -t mangle $add $U_QOS_CHAIN -s ! $SU_IP -p $set_proto -m multiport --dports $rule_list -j MARK --set-mark $(priority_switch $set_prio)	"
                                iptables -t mangle $add $U_QOS_CHAIN -s ! $SU_IP -p $set_proto -m multiport --dports $rule_list -j MARK --set-mark $(priority_switch $set_prio)	2> /dev/null  		
                        fi
                else
		        iptables -t mangle $add $U_QOS_CHAIN -p $set_proto -m multiport --dports $rule_list -j MARK --set-mark $(priority_switch $set_prio) 2> /dev/null  		
                fi
		num=$(($num+1))
	done
	
	[ -f /tmp/array ] && rm /tmp/array
	[ -f /tmp/count ] && rm /tmp/count
}

set_priority_rule()
{
        SU=$1
        if [ "$l_tcp_port_list" != "" ];then
		parsing_port "$l_tcp_port_list"
		set_multiport_iptables "tcp" "3" "$SU"
	fi
        if [ "$l_udp_port_list" != "" ];then
		parsing_port "$l_udp_port_list"
		set_multiport_iptables "udp" "3" "$SU"
	fi
        if [ "$l_mac_list" != "" ];then
		set_mac_iptables "3" "$SU"
	fi
        if [ "$l_phyport_list" != "" ];then
		set_phyport_iptables "3" "$SU"
	fi

        if [ "$m_tcp_port_list" != "" ];then
		parsing_port "$m_tcp_port_list"
		set_multiport_iptables "tcp" "2" "$SU"
	fi
        if [ "$m_udp_port_list" != "" ];then
		parsing_port "$m_udp_port_list"
		set_multiport_iptables "udp" "2" "$SU"
	fi
        if [ "$m_mac_list" != "" ];then
		set_mac_iptables "2" "$SU"
	fi
        if [ "$m_phyport_list" != "" ];then
		set_phyport_iptables "2" "$SU"
	fi

        if [ "$h_tcp_port_list" != "" ];then
		parsing_port "$h_tcp_port_list"
		set_multiport_iptables "tcp" "1" "$SU"
	fi
        if [ "$h_udp_port_list" != "" ];then
		parsing_port "$h_udp_port_list"
		set_multiport_iptables "udp" "1" "$SU"
	fi
        if [ "$h_mac_list" != "" ];then
		set_mac_iptables "1" "$SU"
	fi
        if [ "$h_phyport_list" != "" ];then
		set_phyport_iptables "1" "$SU"
	fi

	if [ "$ht_tcp_port_list" != "" ];then
		parsing_port "$ht_tcp_port_list"
		set_multiport_iptables "tcp" "0" "$SU"
	fi
        if [ "$ht_udp_port_list" != "" ];then
		parsing_port "$ht_udp_port_list"
		set_multiport_iptables "udp" "0" "$SU"
	fi	
        if [ "$ht_mac_list" != "" ];then
		set_mac_iptables "0" "$SU"
	fi	
        if [ "$ht_phyport_list" != "" ];then
		set_phyport_iptables "0" "$SU"
	fi
}

modify_DSCP()
{
	action=$1
	
	iptables -t mangle ${action} $DSCP_MODIFY -m mark --mark $HEST_Q_MARK -j DSCP --set-dscp 0x30
	iptables -t mangle ${action} $DSCP_MODIFY -m mark --mark $H_Q_MARK -j DSCP --set-dscp 0x20
	iptables -t mangle ${action} $DSCP_MODIFY -m mark --mark $N_Q_MARK -j DSCP --set-dscp 0x00
	iptables -t mangle ${action} $DSCP_MODIFY -m mark --mark $L_Q_MARK -j DSCP --set-dscp 0x10
}

#port qos
do_rule_by_phy_port()
{
	action=$1
	qos_lan_port=`echo $2 | awk '{print $3}'`
	qos_pri=`echo $2 | awk '{print $4}'`
	priority=$(priority_switch $qos_pri)
	# eth0.2, eth0.3, eth0.4, eth0.5 for realtek used ....i
	#Port sequence on web is 4 3 2 1, but eth device is eth0.2 eth0.3 eth0.4 eth0.5 from left to right while facing lan port of DUT
	#	4	3	2	1
	#     eth0.2   eth0.3  eth0.4  eth0.5
        case "$qos_lan_port" in
	1)
		#port_nu=2    #eth0.2
		port_nu=5	#eth0.5
		;;
	2)
		#port_nu=3    #eth0.3
		port_nu=4	#eth0.4
		;;
	3)
		#port_nu=4    #eth0.4
		port_nu=3	#eth0.3
		;;
	4)
		#port_nu=5    #eth0.5
		port_nu=2	#eth0.2
		;;
		*)
		exit 1
	esac

        DEV_NAME="eth0.${port_nu}"

        case "$qos_pri" in
	0)
                if [ "$init_ht_phyport" = "0" ]; then
			ht_phyport_list=`echo "$DEV_NAME"`
			init_ht_phyport=1
		else
			ht_phyport_list=`echo "$ht_phyport_list" "$DEV_NAME"`
		fi
                ;;
	1) 
                if [ "$init_h_phyport" = "0" ]; then
			h_phyport_list=`echo "$DEV_NAME"`
			init_h_phyport=1
		else
			h_phyport_list=`echo "$h_phyport_list" "$DEV_NAME"`
		fi
                ;;
        2) 
                if [ "$init_m_phyport" = "0" ]; then
			m_phyport_list=`echo "$DEV_NAME"`
			init_m_phyport=1
		else
			m_phyport_list=`echo "$m_phyport_list" "$DEV_NAME"`
		fi
                ;;

        3) 
                if [ "$init_l_phyport" = "0" ]; then
			l_phyport_list=`echo "$DEV_NAME"`
			init_l_phyport=1
		else
			l_phyport_list=`echo "$l_phyport_list" "$DEV_NAME"`
		fi                
                ;;

        *)
		;;
	esac
        	
	#only for uplink
	#iptables -t mangle ${action} $U_QOS_CHAIN -i eth0.${port_nu} -j MARK --set-mark $priority
}

do_rule_by_mac()
{
	action=$1
	qos_pri=`echo $2 | awk '{print $4}'`
	qos_mac=`echo $2 | awk '{print $9}'`
	priority=$(priority_switch $qos_pri)

        case "$qos_pri" in
	0)
                if [ "$init_ht_mac" = "0" ]; then
			ht_mac_list=`echo "$qos_mac"`
			init_ht_mac=1
		else
			ht_mac_list=`echo "$ht_mac_list" "$qos_mac"`
		fi
                ;;
	1) 
                if [ "$init_h_mac" = "0" ]; then
			h_mac_list=`echo "$qos_mac"`
			init_h_mac=1
		else
			h_mac_list=`echo "$h_mac_list" "$qos_mac"`
		fi
                ;;
        2) 
                if [ "$init_m_mac" = "0" ]; then
			m_mac_list=`echo "$qos_mac"`
			init_m_mac=1
		else
			m_mac_list=`echo "$m_mac_list" "$qos_mac"`
		fi
                ;;

        3) 
                if [ "$init_l_mac" = "0" ]; then
			l_mac_list=`echo "$qos_mac"`
			init_l_mac=1
		else
			l_mac_list=`echo "$l_mac_list" "$qos_mac"`
		fi                
                ;;

        *)
		;;
	esac

        #echo "ht_mac_list=$ht_mac_list"
        #echo "h_mac_list=$h_mac_list"
        #echo "m_mac_list=$m_mac_list"
        #echo "l_mac_list=$l_mac_list"

        #if [ "$SU_ENABLE" = "1" ] || [ "$FAST_LANE_ENABLE" = "1" ]; then
           # iptables -t mangle ${action} $U_QOS_CHAIN -s ! $SU_IP -m mac --mac-source $qos_mac -j MARK --set-mark $priority	
        #else
	    #uplink
	   # iptables -t mangle ${action} $U_QOS_CHAIN -m mac --mac-source $qos_mac -j MARK --set-mark $priority		
        #fi
}

	
do_rule_by_port()
{	
	action=$1
	qos_pri=`echo $2 | awk '{print $4}'`
	qos_proto=`echo $2 | awk '{print $5}'`
	qos_sport=`echo $2 | awk '{print $6}'`
	qos_dport=`echo $2 | awk '{print $7}'`
	
        if [ "$qos_proto" = "TCP/UDP" ]; then
		proto="TCP"
		proto_other="UDP"
	else
		proto=$qos_proto
		proto_other=""
	fi
	
	num=1
	while [ "`echo $qos_sport | awk -F',' '{print $'$num'}'`" != "" ]; do
		start_port=`echo $qos_sport | awk -F',' '{print $'$num'}'`
		end_port=`echo $qos_dport | awk -F',' '{print $'$num'}'`
		
		if [ "$start_port" != "$end_port" ]; then
			port="$start_port:$end_port"
		else
			port="$start_port"
		fi
		
		if [ "$proto" != "" ] ; then
				multi_port_rule "$proto" "$port" "$qos_pri"
		fi
		if [ "$proto_other" != "" ]; then
				multi_port_rule "$proto_other" "$port" "$qos_pri"
		fi
		num=$(($num+1))
	done
}

traffic_download_control_table()
{
        for intf in $LAN_INTFS
        do
                echo "tc qdisc add dev $intf root handle 10: htb default 2"
                $TC qdisc add dev $intf root handle 10: htb default 2
                echo "tc class add dev $intf parent 10: classid 10:1 htb rate ${DWRATE}kbit ceil ${DWRATE}kbit quantum 3000"
                $TC class add dev $intf parent 10: classid 10:1 htb rate ${DWRATE}kbit ceil ${DWRATE}kbit quantum 3000 
                echo "tc class add dev $intf parent 10:1 classid 10:10 htb rate ${SU_DS_URATE}kbit ceil ${DWRATE}kbit prio 0 quantum 3000"
                $TC class add dev $intf parent 10:1 classid 10:10 htb rate ${SU_DS_URATE}kbit ceil ${DWRATE}kbit prio 0 quantum 3000
                echo "tc class add dev $intf parent 10:1 classid 10:20 htb rate ${QQ_DS_URATE}kbit ceil ${QQ_DS_URATE}kbit prio 0 quantum 3000"
                $TC class add dev $intf parent 10:1 classid 10:20 htb rate ${QQ_DS_URATE}kbit ceil ${QQ_DS_URATE}kbit prio 0 quantum 3000

                #echo "$TC qdisc add dev $intf parent 10:10 handle 101: bfifo"
                $TC qdisc add dev $intf parent 10:10 handle 101: bfifo 
                #echo "$TC qdisc add dev $intf parent 10:20 handle 102: bfifo"
                $TC qdisc add dev $intf parent 10:20 handle 102: bfifo  

                #echo "$TC filter add dev $intf parent 10: protocol ip prio 100 handle $HEST_Q_MARK fw classid 10:10"
                $TC filter add dev $intf parent 10: protocol ip prio 100 handle $HEST_Q_MARK fw classid 10:10
                #echo "$TC filter add dev $intf parent 10: protocol ip prio 100 handle $H_Q_MARK fw classid 10:20"
                $TC filter add dev $intf parent 10: protocol ip prio 100 handle $H_Q_MARK fw classid 10:20
        done
}

traffic_control_table()
{
   if [ "`nvram get router_disable`" = "1" ]; then
	   WAN_IF=`nvram get wan_hwifname`
   fi	

    if [ "$qos_enable" = "1" ]; then        
        echo 1 > $RTL_FAST_PATH   # disable up stream fastpath used for realtek
        if [ "$SU_ENABLE" = "1" ] || [ "$FAST_LANE_ENABLE" = "1" ]; then                
    
                echo "$TC qdisc add dev $WAN_IF root handle 10: htb default 2"
                $TC qdisc add dev $WAN_IF root handle 10: htb default 2
                # 4 level priority
                echo "$TC class add dev $WAN_IF parent 10: classid 10:1 htb rate ${UPRATE}kbit ceil ${UPRATE}kbit"
                $TC class add dev $WAN_IF parent 10: classid 10:1 htb rate ${UPRATE}kbit ceil ${UPRATE}kbit quantum 3000 > /dev/null
    
                echo "$TC class add dev $WAN_IF parent 10:1 classid 10:2 htb rate ${SU_URATE}kbit ceil ${UPRATE}kbit quantum 3000"
                $TC class add dev $WAN_IF parent 10:1 classid 10:2 htb rate ${SU_URATE}kbit ceil ${UPRATE}kbit quantum 3000 > /dev/null
    
                 echo "$TC class add dev $WAN_IF parent 10:2 classid 10:90 htb rate $((45*${SU_URATE}/100))kbit ceil ${UPRATE}kbit prio 0"
                 $TC class add dev $WAN_IF parent 10:2 classid 10:90 htb rate $((45*${SU_URATE}/100))kbit ceil ${UPRATE}kbit prio 0 quantum 3000
                 echo "$TC class add dev $WAN_IF parent 10:2 classid 10:80 htb rate $((30*${SU_URATE}/100))kbit ceil ${UPRATE}kbit prio 0"
                 $TC class add dev $WAN_IF parent 10:2 classid 10:80 htb rate $((30*${SU_URATE}/100))kbit ceil ${UPRATE}kbit prio 0 quantum 3000
                 echo "$TC class add dev $WAN_IF parent 10:2 classid 10:70 htb rate $((15*${SU_URATE}/100))kbit ceil ${UPRATE}kbit prio 0"
                 $TC class add dev $WAN_IF parent 10:2 classid 10:70 htb rate $((15*${SU_URATE}/100))kbit ceil ${UPRATE}kbit prio 0 quantum 3000
                 echo "$TC class add dev $WAN_IF parent 10:2 classid 10:60 htb rate $((10*${SU_URATE}/100))kbit ceil ${UPRATE}kbit prio 0"
                 $TC class add dev $WAN_IF parent 10:2 classid 10:60 htb rate $((10*${SU_URATE}/100))kbit ceil ${UPRATE}kbit prio 0 quantum 3000
    
                 #echo "$TC class add dev $WAN_IF parent 10:2 classid 10:50 htb rate ${SU_URATE} kbit ceil ${UPRATE}kbit prio 3"
                 #$TC class add dev $WAN_IF parent 10:2 classid 10:50 htb rate ${SU_URATE} kbit ceil ${UPRATE}kbit prio 3
    
                 $TC qdisc add dev $WAN_IF parent 10:90 handle 109: bfifo 
                 $TC qdisc add dev $WAN_IF parent 10:80 handle 108: bfifo 
                 $TC qdisc add dev $WAN_IF parent 10:70 handle 107: bfifo 
                 $TC qdisc add dev $WAN_IF parent 10:60 handle 106: bfifo 
                 #$TC qdisc add dev $WAN_IF parent 10:50 handle 105: bfifo 
    
                 $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $SU_HEST_Q_MARK fw classid 10:90
                 $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $SU_H_Q_MARK fw classid 10:80
                 $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $SU_N_Q_MARK fw classid 10:70
                 $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $SU_L_Q_MARK fw classid 10:60
                 #$TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $SU_NO_MARK fw classid 10:50
    
                if [ "$FAST_LANE_ENABLE" = "1" ]; then 
                        MAX_QQ_URATE=${QQ_URATE}
                else
                        MAX_QQ_URATE=${UPRATE}
                fi

                 echo "$TC class add dev $WAN_IF parent 10:1 classid 10:3 htb rate ${QQ_URATE}kbit ceil ${MAX_QQ_URATE}kbit quantum 3000"
                 $TC class add dev $WAN_IF parent 10:1 classid 10:3 htb rate ${QQ_URATE}kbit ceil ${MAX_QQ_URATE}kbit quantum 3000 > /dev/null
    
                 echo "$TC class add dev $WAN_IF parent 10:3 classid 10:10 htb rate $((45*${QQ_URATE}/100))kbit ceil ${MAX_QQ_URATE}kbit prio 0"
                 $TC class add dev $WAN_IF parent 10:3 classid 10:10 htb rate $((45*${QQ_URATE}/100))kbit ceil ${MAX_QQ_URATE}kbit prio 0 quantum 3000
                 echo "$TC class add dev $WAN_IF parent 10:3 classid 10:20 htb rate $((30*${QQ_URATE}/100))kbit ceil ${MAX_QQ_URATE}kbit prio 0"
                 $TC class add dev $WAN_IF parent 10:3 classid 10:20 htb rate $((30*${QQ_URATE}/100))kbit ceil ${MAX_QQ_URATE}kbit prio 0 quantum 3000
                 echo "$TC class add dev $WAN_IF parent 10:3 classid 10:30 htb rate $((15*${QQ_URATE}/100))kbit ceil ${MAX_QQ_URATE}kbit prio 0"
                 $TC class add dev $WAN_IF parent 10:3 classid 10:30 htb rate $((15*${QQ_URATE}/100))kbit ceil ${MAX_QQ_URATE}kbit prio 0 quantum 3000
                 echo "$TC class add dev $WAN_IF parent 10:3 classid 10:40 htb rate $((10*${QQ_URATE}/100))kbit ceil ${MAX_QQ_URATE}kbit prio 0"
                 $TC class add dev $WAN_IF parent 10:3 classid 10:40 htb rate $((10*${QQ_URATE}/100))kbit ceil ${MAX_QQ_URATE}kbit prio 0 quantum 3000
    
                 $TC qdisc add dev $WAN_IF parent 10:10 handle 101: bfifo 
                 $TC qdisc add dev $WAN_IF parent 10:20 handle 102: bfifo 
                 $TC qdisc add dev $WAN_IF parent 10:30 handle 103: bfifo 
                 $TC qdisc add dev $WAN_IF parent 10:40 handle 104: bfifo 
    
                 $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $HEST_Q_MARK fw classid 10:10
                 $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $H_Q_MARK fw classid 10:20
                 $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $N_Q_MARK fw classid 10:30
                 $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $L_Q_MARK fw classid 10:40

                 if [ "$FAST_LANE_ENABLE" = "1" ]; then  
                            echo 0 > $RTL_FAST_PATH
                            traffic_download_control_table
                 fi
        else 
               #clean qdisc buffer
               #$TC qdisc del dev $WAN_IF root 2>/dev/null
               #add new qdisc
               echo "$TC qdisc add dev $WAN_IF root handle 10: htb default 2"
               $TC qdisc add dev $WAN_IF root handle 10: htb default 2
               # 4 level priority
               if [ $((10*${UPRATE}/100)) -gt 0 ]; then	# If the rate = 0kbit, the uplink bandwidth will be automatically maximum.
                   echo "$TC class add dev $WAN_IF parent 10: classid 10:1 htb rate ${UPRATE}kbit ceil ${UPRATE}kbit"
                   $TC class add dev $WAN_IF parent 10: classid 10:1 htb rate ${UPRATE}kbit ceil ${UPRATE}kbit quantum 3000 > /dev/null
               
                   echo "$TC class add dev $WAN_IF parent 10:1 classid 10:10 htb rate $((45*${UPRATE}/100))kbit ceil ${UPRATE}kbit prio 0"
                   $TC class add dev $WAN_IF parent 10:1 classid 10:10 htb rate $((45*${UPRATE}/100))kbit ceil ${UPRATE}kbit prio 0 quantum 3000
                   echo "$TC class add dev $WAN_IF parent 10:1 classid 10:20 htb rate $((30*${UPRATE}/100))kbit ceil ${UPRATE}kbit prio 0"
                   $TC class add dev $WAN_IF parent 10:1 classid 10:20 htb rate $((30*${UPRATE}/100))kbit ceil ${UPRATE}kbit prio 0 quantum 3000
                   echo "$TC class add dev $WAN_IF parent 10:1 classid 10:30 htb rate $((15*${UPRATE}/100))kbit ceil ${UPRATE}kbit prio 0"
                   $TC class add dev $WAN_IF parent 10:1 classid 10:30 htb rate $((15*${UPRATE}/100))kbit ceil ${UPRATE}kbit prio 0 quantum 3000
                   echo "$TC class add dev $WAN_IF parent 10:1 classid 10:40 htb rate $((10*${UPRATE}/100))kbit ceil ${UPRATE}kbit prio 0"
                   $TC class add dev $WAN_IF parent 10:1 classid 10:40 htb rate $((10*${UPRATE}/100))kbit ceil ${UPRATE}kbit prio 0 quantum 3000
               else
                   echo "$TC class add dev $WAN_IF parent 10: classid 10:1 htb rate $((${UPRATE}*1024))bit ceil $((${UPRATE}*1024))bit"
                   $TC class add dev $WAN_IF parent 10: classid 10:1 htb rate $((${UPRATE}*1024))bit ceil $((${UPRATE}*1024))bit quantum 3000 > /dev/null

                   echo "$TC class add dev $WAN_IF parent 10:1 classid 10:10 htb rate  $((45*${UPRATE}*1024/100))bit ceil $((${UPRATE}*1024))bit prio 0"
                   $TC class add dev $WAN_IF parent 10:1 classid 10:10 htb rate  $((45*${UPRATE}*1024/100))bit ceil $((${UPRATE}*1024))bit prio 0 quantum 3000
                   echo "$TC class add dev $WAN_IF parent 10:1 classid 10:20 htb rate $((30*${UPRATE}*1024/100))bit ceil $((${UPRATE}*1024))bit prio 0"
                   $TC class add dev $WAN_IF parent 10:1 classid 10:20 htb rate $((30*${UPRATE}*1024/100))bit ceil $((${UPRATE}*1024))bit prio 0 quantum 3000
                   echo "$TC class add dev $WAN_IF parent 10:1 classid 10:30 htb rate $((15*${UPRATE}*1024/100))bit ceil $((${UPRATE}*1024))bit prio 0"
                   $TC class add dev $WAN_IF parent 10:1 classid 10:30 htb rate $((15*${UPRATE}*1024/100))bit ceil $((${UPRATE}*1024))bit prio 0 quantum 3000
                   echo "$TC class add dev $WAN_IF parent 10:1 classid 10:40 htb rate $((10*${UPRATE}*1024/100))bit ceil $((${UPRATE}*1024))bit prio 0"
                   $TC class add dev $WAN_IF parent 10:1 classid 10:40 htb rate $((10*${UPRATE}*1024/100))bit ceil $((${UPRATE}*1024))bit prio 0 quantum 3000
               fi

               $TC qdisc add dev $WAN_IF parent 10:10 handle 101: bfifo 
               $TC qdisc add dev $WAN_IF parent 10:20 handle 102: bfifo 
               $TC qdisc add dev $WAN_IF parent 10:30 handle 103: bfifo 
               $TC qdisc add dev $WAN_IF parent 10:40 handle 104: bfifo 
               
               $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $HEST_Q_MARK fw classid 10:10
               $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $H_Q_MARK fw classid 10:20
               $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $N_Q_MARK fw classid 10:30
               $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $L_Q_MARK fw classid 10:40
       fi

   elif [ "$FAST_LANE_ENABLE" = "1" ]; then
               echo 0 > $RTL_FAST_PATH   # disable up stream fastpath used for realtek
               #add new qdisc
               echo "$TC qdisc add dev $WAN_IF root handle 10: htb default 2"
               $TC qdisc add dev $WAN_IF root handle 10: htb default 2
               # 4 level priority
               echo "$TC class add dev $WAN_IF parent 10: classid 10:1 htb rate ${UPRATE}kbit ceil ${UPRATE}kbit"
               $TC class add dev $WAN_IF parent 10: classid 10:1 htb rate ${UPRATE}kbit ceil ${UPRATE}kbit quantum 3000 > /dev/null
               
               echo "$TC class add dev $WAN_IF parent 10:1 classid 10:10 htb rate ${SU_URATE}kbit ceil ${UPRATE}kbit prio 0"
               $TC class add dev $WAN_IF parent 10:1 classid 10:10 htb rate ${SU_URATE}kbit ceil ${UPRATE}kbit prio 0 quantum 3000
               echo "$TC class add dev $WAN_IF parent 10:1 classid 10:20 htb rate ${QQ_URATE}kbit ceil ${QQ_URATE}kbit prio 0"
               $TC class add dev $WAN_IF parent 10:1 classid 10:20 htb rate ${QQ_URATE}kbit ceil ${QQ_URATE}kbit prio 0 quantum 3000

               $TC qdisc add dev $WAN_IF parent 10:10 handle 101: bfifo 
               $TC qdisc add dev $WAN_IF parent 10:20 handle 102: bfifo                
               
               $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $HEST_Q_MARK fw classid 10:10
               $TC filter add dev $WAN_IF parent 10: protocol ip prio 100 handle $H_Q_MARK fw classid 10:20

               traffic_download_control_table
   fi
}


traffic_control_rule()
{
	#qos_entry=MSN_messenger 0 MSN_messenger 1 TCP 443 443 ---- ----
	action=$1
	qos_entry=`nvram get qos_list$2`
        if [ "$qos_entry" = "0" ]; then
            return;
        fi

        echo "$qos_entry"
	qos_mode=`echo $qos_entry | awk '{print $2}'`       
	case "$qos_mode" in
	0)
		do_rule_by_port "$action" "$qos_entry"
		;;
	1)
		do_rule_by_port "$action" "$qos_entry"
		;;
	2)
		do_rule_by_phy_port "$action" "$qos_entry"
		;;
	3)
		do_rule_by_mac "$action" "$qos_entry"
		;;
	*)
		;;
	esac
	
}	

tc_table_clear()
{
	WAN_HWIF=`nvram get wan_hwifname`
	if [ "`nvram get router_disable`" = "1" ]; then
		WAN_IF="$($NVRAM get wan_hwifname)"
	fi	
	$TC qdisc del dev $WAN_IF root 2>/dev/null
	if [ "$WAN_HWIF" != "$WAN_IF" ]; then
		$TC qdisc del dev $WAN_HWIF root 2>/dev/null
	fi

        for intf in $LAN_INTFS
        do
                $TC qdisc del dev $intf root 2>/dev/null
        done
}

bandwidth_algorithm(){
########################################################################################
#Specification: Netgear SPEC2.0                                                        #
#Bandwidth Control - Traffic Shaping.                                                  #
#  Step 1: Using traceroute with data lenght 100B detects nearest IP on public domain. #
#        traceroute www.netgear.com (get nearest public domain)                        #
#  Step 2: Send data size of MTU to the nearest IP public domain 20 times.             #
#        traceroute -I -q 1 -p 33437 -f 3 211.76.114.1 --mtu (calculate                #
#  Step 3: Averaging Step 2 with following formular to calculate uplink bandwith.      #
#                       U = 0.9*(E*8)*19/T bps                                         #
#                                                                                      #
#                                                                                      #
########################################################################################       
	echo "S1: get nearest Public IP Domain"
	local NTGIP=`ping -c 1 www.netgear.com | grep 'PING' | sed 's/^.*(//' | sed 's/).*$//'`
	local TMPHOP=0
	local TMPIP=""
	local TMPE=0
	local TMPT=0
	local TMPU=0
	local PKTSIZE=0
	local TMPMAXHOP=2
	#local TMPI=0
	local QOS_UPRATE=`nvram get qos_uprate`

	echo "QoS: @@QOS_UPRATE is $QOS_UPRATE@@"
        rm -rf /tmp/check_bandwidth_failed

	if [ "$NTGIP" != "" ]; then
		traceroute -w 2 -m 20 $NTGIP 100 > /tmp/tmpip.txt
		i=1
		TMPIP=`sed -n ${i}p /tmp/tmpip.txt | cut -c 5- | sed 's/^.*(//' | sed 's/\..*//'`
		while [ "$TMPIP" != "" ]
		do
			if [ "$TMPIP" != "* * *" -a "$TMPIP" != "192" -a "$TMPIP" != "172" -a "$TMPIP" != "10" -a "$TMPIP" != "127" ]; then
				echo $TMPIP | grep -Eq '^-*[0-9]+$' && IPOK=1 || IPOK=0
				#if [ "`awk '{print $2}' $TMPIP`" != "*" ]; then
				if [ $IPOK -eq 1 ]; then
					TMPIP=`sed -n ${i}p /tmp/tmpip.txt | sed 's/^.*(//' | sed 's/).*//'`
					TMPHOP=`sed -n ${i}p /tmp/tmpip.txt | awk '{print $1}'`
					echo "@@checked IP($TMPIP):HOP($TMPHOP)@@"
					#break
				fi
				#fi
			else
				## Not find any nearest public IP ##
				i=$(($i+1))
				if [ $i -gt 20 ]; then
					echo "# QoS: host cannot be found!"
					nvram set qos_bandwidth_type=0
					echo "1" > /tmp/check_bandwidth_failed
					break;
				else
					TMPIP=`sed -n ${i}p /tmp/tmpip.txt | cut -c 5- | sed 's/^.*(//' | sed 's/\..*//'`
					continue;
				fi
			fi

		#if [ "$TMPHOP" = "0" -a "$TMPI" != "0" ]; then
		#	TMPIP=`sed -n ${TMPI}p /tmp/tmpip.txt | sed 's/^.*(//' | sed 's/).*//'`
		#	TMPHOP=`sed -n ${TMPI}p /tmp/tmpip.txt | awk '{print $1}'`
		#fi
		#echo "TMPIP Done: $TMPIP"
		#echo "TMPHOP Done: $TMPHOP"
	
		#local WANNUM=$($NVRAM get wan_default_iface)
		local WANIFACE=$($NVRAM get wan${WANNUM}_ifname)

		local MTUSIZE=`ifconfig $WANIFACE | grep MTU | sed 's/^.*MTU://' | sed 's/\ .*//'`
		while [ 1 -gt 0 ]
		do
			rm -f /tmp/pmtu-max
			## ping count will fix to 3 if "-M" is set ##
			C_CMD="ping -c 3 -M do -s $MTUSIZE $TMPIP"
			echo $C_CMD
			$C_CMD
			if [ -f /tmp/pmtu-max ];then
				MTUSIZE=`cat /tmp/pmtu-max`
				rm -f /tmp/pmtu-max
			else
				break;
			fi
		done
	
		if [ "$TMPHOP" = "1" ]; then
			TMPMAXHOP=2
		else
			TMPMAXHOP=$TMPHOP
		fi
		j=0
		local TMPQUERY=20
		local TMPQUERIED=0
		local TMPHALFQUERY=5 #$(($TMPQUERY>>2))
		rm -f /tmp/bwalg_info
		## retry 5 times ##
		while [ $j -lt 5 ]
		do
			C_CMD="bwalg -q $TMPQUERY -w 3 -u -f $TMPHOP -i $WANIFACE $TMPIP $MTUSIZE"
			echo $C_CMD
			$C_CMD
			if [ -f /tmp/bwalg_info ]; then
				TMPQUERIED=`cat /tmp/bwalg_info | cut -d',' -f1`
				if [ $j -eq 0 ]; then
					TMPSPD=`cat /tmp/bwalg_info | cut -d',' -f2`
				else
					TMPSPD1=`cat /tmp/bwalg_info | cut -d',' -f2`
					TMPSPD=$(( ($TMPSPD + $TMPSPD1) >>1 ))
				fi
				TMPQUERY=$(($TMPQUERY-TMPQUERIED+1))
				if [ $TMPQUERY -le  $TMPHALFQUERY ]; then
					break
				fi
			fi
			if [ $TMPQUERY -ge 18 ]; then
				#$TMPQUERY = 20
				break;
			fi
			j=$(($j+1)) 
		done
		if [ -f /tmp/bwalg_info ]; then
			echo "# QoS: check uplink bandwith succeed!"
			#$NVRAM set qos_uprate="`cat /tmp/detec_uprate`"
			echo $TMPSPD > /tmp/detec_uprate
			$NVRAM set qos_uprate="$TMPSPD"
			return;
		else
			echo "# QoS: check uplink bandwith failed!"
			#echo 0 > /tmp/detec_uprate
			#nvram set qos_threshold=0
			nvram set qos_bandwidth_type=0
			#if [ "$QOS_UP_BW_UNIT" = "Mbps" ]; then
			#	QOS_UPRATE=$(( $QOS_UPRATE * 1024 ))
			#	nvram set qos_uprate=$QOS_UPRATE
			#fi
		fi
		i=$(($i+1))
		TMPIP=`sed -n ${i}p /tmp/tmpip.txt | cut -c 5- | sed 's/^.*(//' | sed 's/\..*//'`
		done
	else
		## ping: Unknown host ##
		echo "# QoS: ping Unknow host!"
		nvram set qos_bandwidth_type=0
                echo "1" > /tmp/check_bandwidth_failed
		#if [ "$QOS_UP_BW_UNIT" = "Mbps" ]; then
		#	QOS_UPRATE=$(( $QOS_UPRATE * 1024 ))
		#	nvram set qos_uprate=$QOS_UPRATE
		#fi
	fi
}

classify_tos()
{
    # Highest Queue
    if [ "$SU_ENABLE" = "1" ] || [ "$FAST_LANE_ENABLE" = "1" ]; then
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x38 -j MARK --set-mark $SU_HEST_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x30 -j MARK --set-mark $SU_HEST_Q_MARK 2> /dev/null  

            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x38 -j MARK --set-mark $HEST_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x30 -j MARK --set-mark $HEST_Q_MARK 2> /dev/null  

            # High Queue
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x2e -j MARK --set-mark $SU_H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x28 -j MARK --set-mark $SU_H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x20 -j MARK --set-mark $SU_H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x26 -j MARK --set-mark $SU_H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x34 -j MARK --set-mark $SU_H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x22 -j MARK --set-mark $SU_H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x20 -j MARK --set-mark $SU_H_Q_MARK 2> /dev/null  

            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x2e -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x28 -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x20 -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x26 -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x34 -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x22 -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x20 -j MARK --set-mark $H_Q_MARK 2> /dev/null  

            # Normal Queue
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x1e -j MARK --set-mark $SU_N_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x1c -j MARK --set-mark $SU_N_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x1a -j MARK --set-mark $SU_N_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x18 -j MARK --set-mark $SU_N_Q_MARK 2> /dev/null  

            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x1e -j MARK --set-mark $N_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x1c -j MARK --set-mark $N_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x1a -j MARK --set-mark $N_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x18 -j MARK --set-mark $N_Q_MARK 2> /dev/null  

            # Low Queue
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x16 -j MARK --set-mark $SU_L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x14 -j MARK --set-mark $SU_L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x12 -j MARK --set-mark $SU_L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x10 -j MARK --set-mark $SU_L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x0e -j MARK --set-mark $SU_L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x0c -j MARK --set-mark $SU_L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x0a -j MARK --set-mark $SU_L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s $SU_IP -m dscp --dscp 0x08 -j MARK --set-mark $SU_L_Q_MARK 2> /dev/null  

            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x16 -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x14 -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x12 -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x10 -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x0e -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x0c -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x0a -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -s ! $SU_IP -m dscp --dscp 0x08 -j MARK --set-mark $L_Q_MARK 2> /dev/null  
    else
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x38 -j MARK --set-mark $HEST_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x30 -j MARK --set-mark $HEST_Q_MARK 2> /dev/null  
        
            # High Queue
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x2e -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x28 -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x20 -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x26 -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x34 -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x22 -j MARK --set-mark $H_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x20 -j MARK --set-mark $H_Q_MARK 2> /dev/null  
        
            # Normal Queue
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x1e -j MARK --set-mark $N_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x1c -j MARK --set-mark $N_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x1a -j MARK --set-mark $N_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x18 -j MARK --set-mark $N_Q_MARK 2> /dev/null  
            #iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x00 -j MARK --set-mark $N_Q_MARK
        
            # Low Queue
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x16 -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x14 -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x12 -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x10 -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x0e -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x0c -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x0a -j MARK --set-mark $L_Q_MARK 2> /dev/null  
            iptables -t mangle -A $QOS_DSCP -m dscp --dscp 0x08 -j MARK --set-mark $L_Q_MARK 2> /dev/null  
    fi
}


qos_init()
{
    echo "TC.sh start: qos init"  > /dev/console
     #for super user no priority 
     traffic_control_table
            
     if [ "$qos_enable" = "1" ]; then
            # incoming from lan/wlan with Tos, it will be treated as correspond priority mapping table
            iptables -A PREROUTING -t mangle -i $LAN_IF -s $subnet/$masklen -j $QOS_DSCP
            # incoming from lan/wlan witout Tos, but match with defined priority rule, it's priority will be set according to the rule.
      	    iptables -A PREROUTING -t mangle -i $LAN_IF -s $subnet/$masklen -m dscp --dscp 0x00 -j $U_QOS_CHAIN            
            # if incoming packet from lan/wlan without Tos but prioritize by application group, then Tos should be added into outgoing wan packets
            iptables -A POSTROUTING -t mangle -o $WAN_IF -s $subnet/$masklen -m dscp --dscp 0x00 -j $DSCP_MODIFY

            if [ "$FAST_LANE_ENABLE" = "1" ]; then   # use for downstream, only fast lane 
                    iptables -A POSTROUTING -t mangle -o $LAN_IF -j $D_QOS_CHAIN 
            fi
        
           classify_tos           
           modify_DSCP $add

    elif [ "$FAST_LANE_ENABLE" = "1" ]; then
            iptables -A PREROUTING -t mangle -i $LAN_IF -s $subnet/$masklen -j $U_QOS_CHAIN 
            iptables -A POSTROUTING -t mangle -o $LAN_IF -j $D_QOS_CHAIN 
    fi
}

add_all()
{
        echo "TC.sh start: rules set"  > /dev/console
	if [ "$qos_enable" = "1" ]; then      
                if [ "$SU_ENABLE" = "1" ] || [ "$FAST_LANE_ENABLE" = "1" ]; then   # only one will be enabled by Netgear spec
                    # if trusted IP enable, set default mark (SU_N_Q_MARK) for any packets from trusted IP, following Qos spec                    
                    iptables -A $U_QOS_CHAIN -t mangle -s ! $SU_IP -j MARK --set-mark $N_Q_MARK 2> /dev/null  
                else
                    iptables -A $U_QOS_CHAIN -t mangle -j MARK --set-mark $N_Q_MARK 2> /dev/null  
                fi
		count=1
                local qos_entry=$($NVRAM get qos_list$count)
	        while [ "x$qos_entry" != "x" ]; do
			traffic_control_rule $add $count
			count=$(($count+1))
		done
		set_priority_rule "0"   #set rule for no-su rule"
                if [ "$SU_ENABLE" = "1" ] || [ "$FAST_LANE_ENABLE" = "1" ]; then
                    iptables -A $U_QOS_CHAIN -t mangle -s $SU_IP -j MARK --set-mark $SU_N_Q_MARK 2> /dev/null  
                    set_priority_rule "1"   #set rule for su rule"
                fi

                if [ "$FAST_LANE_ENABLE" = "1" ];     then
                        iptables -A $D_QOS_CHAIN -t mangle -d $SU_IP -j MARK --set-mark $HEST_Q_MARK 2> /dev/null  
                        iptables -A $D_QOS_CHAIN -t mangle -d ! $SU_IP -j MARK --set-mark $H_Q_MARK 2> /dev/null 
                fi                
	elif [ "$FAST_LANE_ENABLE" = "1" ];     then
                iptables -A $U_QOS_CHAIN -t mangle -s $SU_IP -j MARK --set-mark $HEST_Q_MARK 2> /dev/null  
                iptables -A $U_QOS_CHAIN -t mangle -s ! $SU_IP -j MARK --set-mark $H_Q_MARK 2> /dev/null 

                iptables -A $D_QOS_CHAIN -t mangle -d $SU_IP -j MARK --set-mark $HEST_Q_MARK 2> /dev/null  
                iptables -A $D_QOS_CHAIN -t mangle -d ! $SU_IP -j MARK --set-mark $H_Q_MARK 2> /dev/null 
        fi
}

stop()
{
        echo "TC.sh stop:" > /dev/console
        iptables -D PREROUTING -t mangle -i $LAN_IF -s $subnet/$masklen -j $QOS_DSCP 2> /dev/null 
	iptables -D PREROUTING -t mangle -i $LAN_IF -s $subnet/$masklen -m dscp --dscp 0x00 -j $U_QOS_CHAIN 2> /dev/null 
        iptables -D PREROUTING -t mangle -i $LAN_IF -s $subnet/$masklen -j $U_QOS_CHAIN 2> /dev/null 
        iptables -D POSTROUTING -t mangle -o $WAN_IF -s $subnet/$masklen -m dscp --dscp 0x00 -j $DSCP_MODIFY 2> /dev/null 
        iptables -D POSTROUTING -t mangle -o $LAN_IF -j $D_QOS_CHAIN 

        iptables -t mangle -F $QOS_DSCP
	iptables -t mangle -F $U_QOS_CHAIN
        iptables -t mangle -F $DSCP_MODIFY
        iptables -t mangle -F $D_QOS_CHAIN
	tc_table_clear	
}

add_one()
{
	[ "$1" = "" ] && return
	if [ "$qos_enable" = "1" ]; then
	     n=$1
	     traffic_control_rule $add "${n}"
    fi
}

delete_one()
{
	[ "$1" = "" ] && return
	if [ "$qos_enable" = "1" ]; then
	     n=$1
	     traffic_control_rule $del "${n}"
	fi
}

delete_all()
{    
	iptables -t mangle -F $U_QOS_CHAIN
	iptables -t mangle -F $D_QOS_CHAIN
}

status()
{
	echo "show qdisc ............ "
	$TC -d -s qdisc
#	echo "show filter ............ "
#		$TC -d -s filter ls dev $WAN_IF
	echo "show class ............ "
	if [ "x$WAN_IF" != "x" ];then
		$TC -d -s class ls dev $WAN_IF
	fi
}


case "$1" in
  start)
       if [ "$NO_WAN" = "1" ]; then
            echo "NO wan !!!"
            exit;
       fi
       qos_init;    
       add_all;
       ;;
  stop)
       stop;
       ;;
  restart)
       stop;
       if [ "$NO_WAN" = "1" ]; then
            echo "NO wan !!!"
            exit;
       fi
       qos_init;
       add_all;
       ;;
  add_one)
       add_one $2;
       ;;
  delete_one)
       delete_one $2;
       ;;
  del_all)
       delete_all;
       ;;
  status)
	status;
	;;
  bwalg)        
	bandwidth_algorithm
	;;
  setup_rule)
	delete_all
	if  [ "$qos_enable" = "1" ]; then
		add_all
	fi	
	;;
  *)
   echo $"Usage: $0 {start|stop|restart|status}"
   exit 1
   ;;
esac

exit $RETVAL
