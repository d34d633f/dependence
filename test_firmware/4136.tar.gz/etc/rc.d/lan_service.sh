#!/bin/sh

RETVAL=0
UDHCPD_INIT_PROG="/etc/rc.d/udhcpd.sh"
DNSMASQ_INIT_PROG="/etc/rc.d/dnsmasq.sh"
UPNP_INIT_PROG="/etc/rc.d/mini-upnp.sh"
RIPD_INIT_PROG="/etc/rc.d/ripd.sh"
SAMBA_PROG="/sbin/cmdsamba"
NET_SCAN="/etc/rc.d/net_scan.sh"
vlan_enable=`nvram get vlan_enable`
wan_phy_mode=`nvram get wan_phy_mode`

if [ "$wan_phy_mode" = "adsl" ]; then
    lan_group=$2   # $2 all: start all services, 1-4: start group1-group4 services 
    if [ "$vlan_enable" = "1" ]; then
            lan_all_group="1 2 3 4"       
    else
            lan_all_group="1"      
    fi
    WAN_INTFS="1 2 3 4 5 6 7 8"
fi

find_wan()  #$1: lan group
{
     corr_wan=""
     lan_group=$1
     find_wan=`nvram get interface_group_map | cut -d":" -f $lan_group | grep "wan"`
     if [ "x$find_wan" != "x" ]; then
          temp=$find_wan
          for i in $WAN_INTFS
          do
              wan=`echo $temp | grep "wan$i"`
              if [ "x$wan" != "x" ]; then
                   corr_wan=$i
                   break
              fi
         done
     fi
     echo $corr_wan
}

lunch_all_services()  #$1: start/stop, $2: service name
{
    case "$2" in
        dhcpd)
    	    PROG=${UDHCPD_INIT_PROG}
    	    ;;
        dnsmasq)
    	    PROG=${DNSMASQ_INIT_PROG} 
    	    ;;
        upnp)
    	    PROG=${UPNP_INIT_PROG}
    	    ;;
        ripd)
    	    PROG=${RIPD_INIT_PROG}
    	    ;;
         net-scan)
    	    PROG=${NET_SCAN}
    	    ;;
    esac

    echo  
    for lan in $lan_all_group
    do   
            if [ "$PROG" = "${NET_SCAN}" ]; then
            	${PROG} $1 ${lan}
            elif [ "$PROG" != "${DNSMASQ_INIT_PROG}" ]; then
	            #${PROG} $1 ${lan}
                    local wan_iface=`find_wan ${lan}`
                    if [ "x$wan_iface" != "x" ]; then
			local router_mode=`nvram get wan${wan_iface}_router_mode`
			if [ "$router_mode" != "eoa" ]; then
		            	${PROG} $1 ${lan}
			fi
		    fi
            else
                    local wan_iface=`find_wan ${lan}`
                    if [ "x$wan_iface" != "x" ]; then
			local router_mode=`nvram get wan${wan_iface}_router_mode`
			if [ "$router_mode" != "eoa" ]; then
                            ${PROG} $1 ${wan_iface}
			fi
                    fi
            fi
    done        
}

start() {	       
        if [ "$lan_group" = "all" ]; then 
                echo $"Starting lan(1-4) services"
                lunch_all_services start dhcpd
                lunch_all_services start dnsmasq
                lunch_all_services start ripd
                lunch_all_services start net-scan
                lunch_all_services restart upnp
                ${SAMBA_PROG} start 					
        else               
                echo $"Starting lan($lan_group) services"     
                #${UDHCPD_INIT_PROG} start ${lan_group}
		${NET_SCAN} start ${lan_group}
                local wan_iface=`find_wan ${lan_group}`
                if [ "x$wan_iface" != "x" ]; then
			local router_mode=`nvram get wan${wan_iface}_router_mode`
			if [ "$router_mode" != "eoa" ]; then
                		${UDHCPD_INIT_PROG} start ${lan_group}
        	                ${DNSMASQ_INIT_PROG} start ${wan_iface}
                #if [ "x$wan_iface" != "x" ]; then
                #        ${DNSMASQ_INIT_PROG} start ${wan_iface}
                #fi
	        	        ${RIPD_INIT_PROG} start ${lan_group}
		                #${NET_SCAN} start ${lan_group}
		                ${UPNP_INIT_PROG} restart ${lan_group}
		                if [ "$lan_group" = "1" ]; then 
		                    ${SAMBA_PROG} start
				fi 
			fi
                fi
        fi
                		
	RETVAL=$?
	return $RETVAL
}

stop() {
        if [ "$lan_group" = "all" ]; then
                echo $"Stop lan(1-4) services"
        	lunch_all_services stop dhcpd
                lunch_all_services stop dnsmasq
                lunch_all_services stop ripd
                lunch_all_services stop net-scan
                lunch_all_services stop upnp
                ${SAMBA_PROG} stop 					
        else               
                echo $"Stop lan($lan_group) services"       
                local wan_iface=`find_wan ${lan_group}`
                if [ "x$wan_iface" != "x" ]; then         
    	                ${DNSMASQ_INIT_PROG} stop ${wan_iface}
                fi
    	         ${UDHCPD_INIT_PROG} stop ${lan_group}
    	         ${RIPD_INIT_PROG} stop ${lan_group}
                 ${NET_SCAN} stop ${lan_group}
                 ${UPNP_INIT_PROG} stop ${lan_group}
                if [ "$lan_group" = "1" ]; then 
                    ${SAMBA_PROG} stop 
                fi
        fi
	
	RETVAL=$?
	return $RETVAL
}


# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;; 
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

