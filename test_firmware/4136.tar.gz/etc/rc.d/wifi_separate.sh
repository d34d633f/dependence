#!/bin/sh

lan_ifname=`nvram get lan_ifname`
lan_hwifname=`nvram get lan_hwifname`
wlan_ifname=`nvram get wl_ifname`

EBTABLE_BIN="/usr/sbin/ebtables"
IPTABLES_BIN="/usr/sbin/iptables"

RETVAL=0


[ -f /usr/sbin/ebtables ] || exit 0
[ -f /usr/sbin/iptables ] || exit 0

start() {

	if [ "`nvram get WIFISecMode`" = "1" ]; then	# for Single SSID
		if [ "`nvram get WIFIGuestPort1Single`" = "1" ]; then
			${EBTABLE_BIN} -A FORWARD -i ra0 -o eth0 -j DROP
			#info=`${EBTABLE_BIN} -t broute -L BROUTING | grep 0x65`
			#if [ "x$info" = "x" ]; then
			#	${EBTABLE_BIN} -t broute -A BROUTING -i $wlan_ifname -j mark --mark-set 101
			#fi
			##${EBTABLE_BIN} -t broute -A BROUTING -i ra0 -j mark --mark-set 101
			#${IPTABLES_BIN} -A fwd_wifi_guest -i $lan_ifname -m mark --mark 101 -j DROP
		fi
	else # for MULTI SSID 
		num=0

		if [ "`nvram get WIFIGuestPort1Multi`" = "1" ]; then
			${EBTABLE_BIN} -A FORWARD -i ra${num} -o eth0 -j DROP
			#info=`${EBTABLE_BIN} -t broute -L BROUTING | grep 0x65`
			#if [ "x$info" = "x" ]; then
			#	${EBTABLE_BIN} -t broute -A BROUTING -i $wlan_ifname -j mark --mark-set 101
			#fi
			##${EBTABLE_BIN} -t broute -A BROUTING -i ra0 -j mark --mark-set 101
			#${IPTABLES_BIN} -A fwd_wifi_guest -i $lan_ifname -m mark --mark 101 -j DROP
			if [ "`nvram get WIFISsid1EnableMulti`" = "1" ]; then
				num=$((${num}+1))
			fi
		fi

		if [ "`nvram get WIFIGuestPort2Multi`" = "1" ]; then
			${EBTABLE_BIN} -A FORWARD -i ra${num} -o eth0 -j DROP
			#info=`${EBTABLE_BIN} -t broute -L BROUTING | grep 0x66`
			#if [ "x$info" = "x" ]; then
			#	${EBTABLE_BIN} -t broute -A BROUTING -i $wlan_ifname -j mark --mark-set 102
			#fi
			##${EBTABLE_BIN} -t broute -A BROUTING -i ra1 -j mark --mark-set 102
			#${IPTABLES_BIN} -A fwd_wifi_guest -i $lan_ifname -m mark --mark 102 -j DROP
			if [ "`nvram get WIFISsid2EnableMulti`" = "1" ]; then
				num=$((${num}+1))
			fi
		fi

		if [ "`nvram get WIFIGuestPort3Multi`" = "1" ]; then
			${EBTABLE_BIN} -A FORWARD -i ra${num} -o eth0 -j DROP
			#info=`${EBTABLE_BIN} -t broute -L BROUTING | grep 0x67`
			#if [ "x$info" = "x" ]; then
			#	${EBTABLE_BIN} -t broute -A BROUTING -i $wlan_ifname -j mark --mark-set 103
			#fi
			##${EBTABLE_BIN} -t broute -A BROUTING -i ra2 -j mark --mark-set 103
			#${IPTABLES_BIN} -A fwd_wifi_guest -i $lan_ifname -m mark --mark 103 -j DROP
			if [ "`nvram get WIFISsid3EnableMulti`" = "1" ]; then
				num=$((${num}+1))
			fi
		fi
		if [ "`nvram get WIFIGuestPort1Single`" = "1" ]; then
			if [ "${num}" = "0" ];then
				${EBTABLE_BIN} -A FORWARD -i ra${num} -o eth0 -j DROP
			else
				${EBTABLE_BIN} -A FORWARD -i ra3 -o eth0 -j DROP
			fi
			#info=`${EBTABLE_BIN} -t broute -L BROUTING | grep 0x65`
			#if [ "x$info" = "x" ]; then
			#	${EBTABLE_BIN} -t broute -A BROUTING -i $wlan_ifname -j mark --mark-set 101
			#fi
			##${EBTABLE_BIN} -t broute -A BROUTING -i ra0 -j mark --mark-set 101
			#${IPTABLES_BIN} -A fwd_wifi_guest -i $lan_ifname -m mark --mark 101 -j DROP
			if [ "`nvram get WIFISsid1Enable`" = "1" ]; then
				num=$((${num}+1))
			fi
		fi

	fi

	echo
	return $RETVAL  
}

stop() {
	#${EBTABLE_BIN} -t broute -D BROUTING -i ra0 -j mark --mark-set 101 2> /dev/null
	#${EBTABLE_BIN} -t broute -D BROUTING -i ra1 -j mark --mark-set 102 2> /dev/null
	#${EBTABLE_BIN} -t broute -D BROUTING -i ra2 -j mark --mark-set 103 2> /dev/null
	${EBTABLE_BIN} -F FORWARD 2> /dev/null
	${IPTABLES_BIN} -F fwd_wifi_guest 2> /dev/null
	echo
	return $RETVAL
}


case "$1" in
	start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
