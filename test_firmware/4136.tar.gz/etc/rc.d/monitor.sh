#!/bin/sh

UDHCPD_INIT_PROG="/etc/rc.d/udhcpd.sh"
DHCPRELAY_INIT_PROG="/etc/rc.d/dhcprelay.sh"
DNSMASQ_INIT_PROG="/etc/rc.d/dnsmasq.sh"
NTPCLIENT_INIT_PROG="/etc/rc.d/ntpclient.sh"
UPNP_INIT_PROG="/etc/rc.d/mini-upnp.sh"
SYSLOGD_INIT_PROG="/etc/rc.d/syslogd.sh"
DROPBEAR_INIT_PROG="/etc/rc.d/dropbear.sh"
TELNETD_INIT_PROG="/etc/rc.d/telnetd.sh"
SNMPD_INIT_PROG="/etc/rc.d/snmpd.sh"
RIPD_INIT_PROG="/etc/rc.d/ripd.sh"
#TR069_AGENT_PROG="/etc/rc.d/tr069-agent.sh"
TR069_AGENT_PROG="/etc/rc.d/cwmp-agent.sh"
SIP_ALG_PROG="/etc/rc.d/sip_alg.sh"
WAN_START_PROG="/etc/rc.d/wan_start.sh"
IPV6_PROG="/etc/rc.d/ipv6_start_up.sh"
IGMPPROXY_PROG="/etc/rc.d/igmpproxy.sh"
UDHCPD_PROG="/etc/rc.d/udhcpd.sh"    # use for relay agent 
REMOTE_PROG="/etc/rc.d/remote.sh"
USB_HTTPS_ACCESS_PROG="/etc/rc.d/usb_http_remote.sh"
USB_FTP_ACCESS_PROG="/etc/rc.d/usb_ftp_remote.sh"
WAN_PING_PROG="/etc/rc.d/wan_ping.sh"
DMZ_PROG="/etc/rc.d/dmz.sh"
VPN_PASSTHRU_PROG="/etc/rc.d/vpn_passthru.sh"
SPI_DOS_PROG="/etc/rc.d/spi_dos.sh"
ROUTING_PROG="/etc/rc.d/routing.sh"
UPDATE_USB_DEV="/sbin/update_usb"
log_file="/var/log/messages"
QOS_SET_PROG="/etc/rc.d/TC.sh"
VPN_PROG="/etc/rc.d/ipsec.sh"

wan_phy_mode=`nvram get wan_phy_mode`
if [ "$wan_phy_mode" = "adsl" ]; then
    MULTI_WAN=1    
fi


ddns_force_update_check()
{
	ddns_enable=`nvram get ddns_enable`
	if [ "$ddns_enable" != 1 ]; then
		return 0;
	fi

    if [ ! -f /tmp/ddns_force_update ]; then
        	return 0;
	fi

	#if WAN is not connected, return 0
	wan_ipaddr=`nvram get wan0_ipaddr`
	if [ "$wan_ipaddr" = "" ]; then
		return 0
	fi

	read last_update < /tmp/ddns_force_update
	current_time=`cat /proc/uptime| cut -d "." -f 1`

	#echo "==== last_update=$last_update, current_time=$current_time ====" //test
	if [ $current_time -ge $(($last_update + 86400)) ]; then			#force update if 
		echo $current_time > /tmp/ddns_force_update
		/etc/rc.d/wan_ddns.sh start
	fi
}

while true; do
	#action=`nvram get action`
   	wl1_action=`nvram get wl1_action`
	restore_enable=`nvram get restore_defaults`
	#wps_pbc_enable=`nvram get wps_pbc_defaults`
	firmware=`nvram get fw_tmpfile`
	startPos=`nvram get fw_startPos`
	endPos=`nvram get fw_endPos`
	#blk_site_enable=`nvram get bs_url_filter_enabled`
	blk_site_enable=`nvram get block_skeyword`
	blk_svc_enable=`nvram get blockserv_ctrl`
	wan_ip=`nvram get wan0_ipaddr`
	lan_proto=`nvram get lan_proto`
	run_lanip_selected=`nvram get run_lanip_selected`

	fw_update_running=`nvram get fw_update_running`
	if [ "$fw_update_running" = "1" ]; then
		/sbin/alarm 0
		continue
	fi
	
	# action = 1 -> Reboot
	# 	 = 2 -> Restart
	#	 = 3 -> restart when ip-up (dhcpc, ppp)
   	# wl1_action = 1 -> start wireless 

	if [ "$restore_enable" = "1" ]; then
		sleep 2
		echo "Restore Default settings..."
		nvram unset restore_defaults
		#nvram commit
		rm -f /tmp/configs/*
		cd /etc/nvram
		cp -f nvram.config /tmp/configs/nvram.config
        	#echo "auth_reboot=1" >> /tmp/configs/nvram.config
        	#echo "auth_ip=`nvram get auth_ip`" >> /tmp/configs/nvram.config
		commit
		reboot
	fi

	if [ "$run_lanip_selected" = "1" ]; then
		nvram unset run_lanip_selected
		/sbin/cmdlan.sh stop
    		/sbin/ip_conflict.sh stop
    		/sbin/conflict_wanlan.sh
    		/sbin/ip_conflict.sh start &
	fi
	
	#if [ "$wps_pbc_enable" = "1" ]; then
	#	echo "run wps pbc..."
	#	nvram set wps_pbc_defaults=0
	#	#/etc/rc.d/wifi wlan0 wps_pbc HW
        #        /etc/rc.d/wlan_ath.sh restart
	#fi	
    
        mount_entry=""
	#action=`nvram get action`
	#nvram unset action
	action=`nvram get _action_`
	if [ -n "$action" ]; then
		for i in $action
		do 
                       local usb_dev=`echo $i | cut -c 1-2`
                       if [ "$usb_dev" = "sd" ]; then
                                if [ "$mount_entry" = "" ]; then 
                                    mount_entry=$i
                                else                                    
                                    mount_entry="$mount_entry $i"
                                fi
                                continue;
                        fi

                        if [ "$i" = "1" ]; then
				echo "Reboot..........."
				sleep 2
				#auth_reboot=1 means an authorized host reboots this machine.a
				#auth_reboot will be use in boa
				
				if [ "`nvram get auth_reboot`" != "xxxx" ]; then
                                	nvram set auth_reboot=1
					echo "auth_reboot=1"
				else
					nvram unset auth_ip
                                	nvram unset auth_reboot
				fi
				nvram commit
				/etc/rc.d/wan_start.sh stop
				#reboot
				[ -f /tmp/reboot ] && /tmp/reboot || /sbin/reboot
			elif [ "$i" = "2" ]; then
				echo "Restart..........."
				echo 0 > /proc/sys/net/ipv4/ip_forward
				${WAN_START_PROG} stop
				/etc/rc.d/lan_start.sh
				${UDHCPD_INIT_PROG} stop
				${DNSMASQ_INIT_PROG} stop
				#${SYSLOGD_INIT_PROG} stop
				#${UPNP_INIT_PROG} stop
				${RIPD_INIT_PROG} stop
				${NTPCLIENT_INIT_PROG} stop
				${SIP_ALG_PROG} stop
				${IGMPPROXY_PROG} stop
				#${TR069_AGENT_PROG} stop
				if [ "`nvram get router_disable`" = "0" ]; then	# not AP mode
					if [ "`nvram get nat_disable`" = "0" ]; then	# not AP mode
						#${DNSMASQ_INIT_PROG} start
						#${UPNP_INIT_PROG} start
						echo "nat disable "
					fi
					${UDHCPD_INIT_PROG} start
					${WAN_START_PROG} start
					#${RIPD_INIT_PROG} start
				else	#AP mode
					iptables -F
					iptables -X
					iptables -Z
					iptables -F -t nat
					iptables -X -t nat
					iptables -Z -t nat
					iptables -P INPUT ACCEPT
					iptables -P FORWARD ACCEPT
					echo ">>>>>>>>>>>>>>> AP mode  <<<<<<<<<<<<<"
				fi
				#/etc/rc.d/resetbutton.sh restart
				/etc/rc.d/routing.sh start
				if [ "`nvram get router_disable`" = "0" ]; then
					${RIPD_INIT_PROG} start
				fi

				#if [ `nvram get pwd_changed` = "1" ]; then
				#	echo "encrypt /etc/passwd password field"
				#	userlogin
				#	nvram unset pwd_changed
				#fi
				nvram commit

			elif [ "$i" = "3" ]; then
				iface="0"
				if [ "`nvram get wan${iface}_ipaddr`" != "" ]; then                  
					ALIVE="`cat /tmp/WAN_status | grep 10`"
					if [ "$wan_phy_mode" != "eth" ] || [ "`nvram get wan_proto`" != "static" ] || [ "x$ALIVE" != "x" ]; then                  
						ledcontrol -n internet_off -s off
						ledcontrol -n internet_on -s on
					fi
					logger -- "[type4][Internet connected] IP address: $wan_ip,"
					if [ "$MULTI_WAN" = "1" ]; then 
						# scheduler for blk_site/blk
						/etc/rc.d/cmdsched.sh start both
						/etc/rc.d/wan_ddns.sh restart
						# this script first clean all ebtables rull and then do the pppoe passthrough and selective bridging traffic
						if [ -e /tmp/upnp_portmap ]; then
							rm -f /tmp/upnp_portmap
						fi						
						if [ "`nvram get TimerSettingAuto`" = "1" ]; then
							${NTPCLIENT_INIT_PROG} restart
						fi
						/etc/rc.d/vpn_passthru.sh restart
						if [ "$READY_LOGO" = "0" ];then
							$IPV6_PROG restart
						fi
						${USB_HTTPS_ACCESS_PROG} restart
						${USB_FTP_ACCESS_PROG} restart
						#/etc/rc.d/ppa.sh restart $iface
						${IGMPPROXY_PROG} restart
						if [ "`nvram get agent_enable`" = "1" ]; then
           						#tzconfig -x "`nvram get $(nvram get local_time_zone_name)`"
							#${TR069_AGENT_PROG} restart
							# No ideas why TR060 will need to run from uhttpd 
							/sbin/kill_event_pid 40 /var/run/uhttpd.pid
						fi
						if [ "`nvram get qos_endis_on`" = "1" ] || [ "`nvram get fast_lane_enable`" = "1" ]; then
							${QOS_SET_PROG} restart
						fi
						${VPN_PROG} restart
					else
						${DNSMASQ_INIT_PROG} restart
						/etc/rc.d/start_firewall_1.sh
						/etc/rc.d/start_firewall_2.sh

						# this script first clean all ebtables rull and then do the pppoe passthrough and selective bridging traffic
						if [ -e /tmp/upnp_portmap ]; then
							rm -f /tmp/upnp_portmap
	        				fi
						${UPNP_INIT_PROG} restart
						#if [ "`nvram get agent_enable`" = "1" ]; then
           					#	tzconfig -x "`nvram get $(nvram get local_time_zone_name)`"
						#	${TR069_AGENT_PROG} start
						#fi
						if [ "$blk_site_enable" -eq "2" ]; then
							/etc/rc.d/blk_site.sh restart
						fi

						#if [ "$blk_svc_enable" -eq "2" ]; then
							/etc/rc.d/blk_svc.sh restart
						#fi

						# scheduler for blk_site/blk_svc
						/etc/rc.d/cmdsched.sh start both
						/etc/rc.d/wan_ddns.sh restart
						/etc/rc.d/routing.sh restart
               			
						# RIP function support WAN port
						if [ "`nvram get router_disable`" = "0" ]; then   # not AP mode
							${RIPD_INIT_PROG} restart
						fi
						${SIP_ALG_PROG} start
						if [ "`nvram get TimerSettingAuto`" = "1" ]; then
							${NTPCLIENT_INIT_PROG} restart					
						fi
						/etc/rc.d/vpn_passthru.sh restart
						READY_LOGO=`nvram get ready_logo_mode`
						if [ "$READY_LOGO" = "0" ];then
							$IPV6_PROG restart
						fi
						/etc/rc.d/usb_http_remote.sh restart
						/etc/rc.d/usb_ftp_remote.sh restart
						/etc/rc.d/ppa.sh restart
						if [ "`nvram get lan_proto`" = "relay" ]; then  # restart dhcp relay agent
							${UDHCPD_PROG} restart
						fi	
						${IGMPPROXY_PROG} restart
						if [ "`nvram get agent_enable`" = "1" ]; then
           						#tzconfig -x "`nvram get $(nvram get local_time_zone_name)`"
							#${TR069_AGENT_PROG} restart
							# No ideas why TR060 will need to run from uhttpd 
							/sbin/kill_event_pid 40 /var/run/uhttpd.pid
						fi
						${VPN_PROG} restart
					fi
			  	else 
				# this script first clean all ebtables rull and then do the pppoe passthrough and selective bridging traffic
                                        echo ""
					${SIP_ALG_PROG} start
   		  		fi
           		#nvram commit
           		#tzconfig -x "`nvram get $(nvram get local_time_zone_name)`"
			#${IGMPPROXY_PROG} restart
         		elif [ "$i" = "4" ]; then
				action_script=`nvram get action_script`
				nvram unset action_script
				if [ ! $action_script = "" ]; then
					$action_script
				fi

			elif [ "$i" = "5" ]; then
				nvram commit

			elif [ "$i" = "7" ]; then
          			#/etc/rc.d/eco.sh restore
          			/etc/rc.d/cmdsched.sh start eco
          	        elif [ "$i" = "8" ]; then
          		#for inspection
				/usr/sbin/telnetd -l /bin/ash &
          	        elif [ "$i" = "9" ]; then
          	        	sleep 8
          	        	${TR069_AGENT_PROG} stop
				echo 10000 > /proc/gpio
          	        	/usr/sbin/upgradefw
                        elif [ "$i" -gt 1000 -a "$i" -lt 2000 ]; then            # here use to do xdsl multiple wan                                                           
                                local lan_iface=`echo $i | cut -c 2`
                                local wan_iface=`echo $i | cut -c 3`
                                local intranet=`echo $i | cut -c 4`   
                                if [ "$lan_iface" != "0" ]; then                                        
                                        ${UPNP_INIT_PROG} restart ${lan_iface}                                                                
                                fi
                                if [ "$wan_iface" != "0" ]; then
                                        ${DNSMASQ_INIT_PROG} restart ${wan_iface}
                                        ${REMOTE_PROG} restart ${wan_iface} ${intranet}
                                        ${WAN_PING_PROG} ${wan_iface} ${intranet}
                                        ${DMZ_PROG} restart ${wan_iface} 
                                        ${VPN_PASSTHRU_PROG} restart ${wan_iface}
                                        ${SPI_DOS_PROG} restart ${wan_iface} ${intranet}
                                        ${SIP_ALG_PROG} config ${wan_iface}
					iptv_bridge=`nvram get iptv_bridge`
					if [ "`cat /firmware_region`" = "GR" ] && [ "$iptv_bridge" != "1" ] && [ "$wan_iface" = "2" ]; then
						${IGMPPROXY_PROG} restart
					fi
                                fi
                                
                                ${ROUTING_PROG} start
				$IPV6_PROG restart

                                vlan_enable=`nvram get vlan_enable`
                                if [ "$vlan_enable" = "1" ]; then
                                        LAN_GROUPS="1 2 3 4"
                                else 
                                        LAN_GROUPS="1"
                                fi
                                for item in $LAN_GROUPS
                                do
                                         ${RIPD_INIT_PROG} restart ${item}
                                done

				if [ "$blk_site_enable" -eq "2" ]; then
					/etc/rc.d/blk_site.sh restart
				fi
				#if [ "$blk_svc_enable" -eq "2" ]; then
					/etc/rc.d/blk_svc.sh restart
				#fi
			else
				#check 6:script
				local act=`echo $i | awk -F\: '{print $1}'`
				local script=`echo $i | awk -F\: '{print $2}'`
				local commit=`echo $i | awk -F\: '{print $3}'`

				if [ "$act" = "6" -a -n "$script" ]; then
                                        if [ "$script" = "update_usb" ]; then
						echo "usb unplug, update usb"
                                                $UPDATE_USB_DEV
					elif [ "$script" = "tftpdstart" ]; then
						echo "start tftpd"
						#/usr/sbin/in.tftpd -v -i /etc/tftpserver.ini &
						#nvram set action=6:tftpdstop
					elif [ "$script" = "tftpdstop" ]; then
						echo "stop tftpd"
						killall in.tftpd
						#kenny.w added
					elif [ "$script" = "snmpfwupgradestart" ]; then   
						echo "@@snmp firmware upgrade start@@"
						#/sbin/remote_upgrade
						cp /usr/sbin/misc /tmp/misc
						ln -sf /tmp/misc /tmp/remote_upgrade
						$SNMPD_INIT_PROG stop 
						/tmp/remote_upgrade &
						#/etc/rc.d/snmp_fw_upgrade.sh
						#end of added
					elif [ "$script" = "wps_hw" ]; then						
                                                local fast_lan_push_button=`nvram get fast_lan_push_button`
                                                local FAST_LANE_ON=`nvram get fast_lane_enable`
                                                if [ "$fast_lan_push_button" = "1" ]; then                                                        
                                                        echo "@@ Push Fast Lane Button DOWN@@"
                                                        echo "FAST_LANE_ON = $FAST_LANE_ON"
                                                        if [ "$FAST_LANE_ON" = "1" ]; then
                                                            nvram set fast_lane_enable=0
                                                            nvram commit
                                                            ${QOS_SET_PROG} stop
                                                        elif [ "$FAST_LANE_ON" = "0" ]; then
                                                            nvram set fast_lane_enable=1
                                                            nvram commit
                                                            ${QOS_SET_PROG} restart    
                                                        fi                                                                                                               
                                                else
                                                        echo "@@ WPS_PBC Hardware Button DOWN @@"
        						if [ "`nvram get wds_endis_fun`" != "1" -a "`nvram get endis_wl_wps`" = "1" ]; then
        							local WL_SECTYPE=`nvram get wl_sectype`
        							if [ "$WL_SECTYPE" != "2" -a "$WL_SECTYPE" != "3" -a "$WL_SECTYPE" != "6" ]; then
        								## WDS can not run in WPS X, and WEP security mode can not call in WPS 2.0 ##
        								nvram set endis_wl_wps=1
        								/etc/rc.d/wlan_rtl.sh wps_pbc &
        							else
									echo 1004:0:100 > /proc/gpio
        							fi
        						else
								echo 1004:0:100 > /proc/gpio
        						fi
                                                fi
					elif [ "$script" = "wps_hw_btup" ]; then						
                                                local fast_lan_push_button=`nvram get fast_lan_push_button`
                                                if [ "$fast_lan_push_button" != "1" ]; then
                                                        echo "@@ WPS_PBC Hardware Button UP @@"
        						local WL_SECTYPE=`nvram get wl_sectype`
        						if [ "`nvram get endis_wl_radio`" = "0" ]; then
								echo 1004:5:100 > /proc/gpio
        						elif [ "`nvram get wds_endis_fun`" = "1" ]; then
								echo 1004:5:100 > /proc/gpio
        						elif [ "$WL_SECTYPE" = "2" -o "$WL_SECTYPE" = "3" -o "$WL_SECTYPE" = "6" ]; then
								echo 1004:5:100 > /proc/gpio
        						fi
                                                fi
					elif [ "$script" = "wlan_hw" ]; then
						## Inverse ON/OFF Control ##
						if [ "`ifconfig | grep -c wlan0`" = "0" ]; then
							nvram set endis_wl_radio=1
							nvram commit
							/etc/rc.d/wlan_rtl.sh wlan_hw_start
						else
							nvram set endis_wl_radio=0
							nvram commit
							/etc/rc.d/wlan_rtl.sh wlan_hw_stop
						fi
					elif [ "$script" = "internet_led" ]; then
						echo 502 > /proc/gpio
						echo 402 > /proc/gpio
						ALIVE=
						WANIP="`nvram get wan0_ipaddr`" # check default wan only
						if [ "$MULTI_WAN" = "1" ]; then
							if [ -f /tmp/dsl_status ];then
								ALIVE="`cat /tmp/dsl_status`"
							fi
						else
							if [ -f /tmp/WAN_status ];then
								ALIVE="`cat /tmp/WAN_status | grep 10`"
							fi
						fi
						## no wan ip, turn on internet red led ##
						if [ "x$WANIP" = "x" ]; then
							echo 401 > /proc/gpio
						fi
						## no wan ip, turn on internet red led ##
						if [ "x$ALIVE" != "x" -a "x$WANIP" != "x" ]; then
							echo 501 > /proc/gpio
						fi
					else 
						if [ "x$commit" != "x" -a "$commit" != "0" ]; then	
							nvram commit
		  				fi	
						${script} restart	
					fi	
               			fi
			fi	
		done	
	fi	
		
        if [ "$mount_entry" != "" ]; then
                echo "$UPDATE_USB_DEV \"$mount_entry\"" >> /dev/console
                ledcontrol -n usb1 -s on
                $UPDATE_USB_DEV "$mount_entry"
        fi
	
#wscd config ap,  restart wlan	
	if [ -e /tmp/reinitwscd ]; then
	    rm /tmp/reinitwscd
	    /etc/rc.d/wlan_rtl.sh restart
	  
           echo 1 > /tmp/igd_byebye
           sleep 1       
           echo 1 > /tmp/wscd_byebye     
	fi	
	
#upnp, request connection, start wan
	if [ -e /tmp/upnp_wan_restart ]; then
		echo "*** Running UPNP WAN Restart ***"
		UPNP_DATA=`cat /tmp/upnp_wan_restart`
		echo "$UPNP_DATA"
		rm /tmp/upnp_wan_restart
		if [ "$UPNP_DATA" = "1" ]; then
			/sbin/cmdwan.sh restart
			#echo "''/sbin/cmdwan.sh start" 
			echo "upnp request connection!!" > /dev/console
			sleep 1
		else
			WAN_PHY_MODE=`echo $UPNP_DATA | cut -d":" -f 2`
			WAN_NUM=`echo $UPNP_DATA | cut -d":" -f 3`
			if [ "$WAN_PHY_MODE" = "adsl" -a "x$WAN_NUM" != "x" ]; then
				/sbin/cmdwan.sh restart $WAN_NUM
				#echo "''/sbin/cmdwan.sh start $WAN_NUM" 
				echo "upnp request connection!!" > /dev/console
				sleep 1
			fi
		fi
		echo "*** Running Done ***"
	fi

##ping www.netgear.com at CA stage
  if [ -e /tmp/ping_netgear_now ]; then
      rm /tmp/ping_netgear_now
      /etc/rc.d/ping_netgear.sh
  fi	

	       
	#/etc/rc.d/urlfilter.sh check
	#ddns_force_update_check

	#To do check log entries <= 256 
	#/etc/rc.d/check_log_len.sh
					
	#/etc/rc.d/sleep.sh 7
	#If another action is waitting, do not run "alarm",
	#run another action directly
	if [ "`nvram get action`" = "" ]; then
		/sbin/alarm 0
	fi
done

