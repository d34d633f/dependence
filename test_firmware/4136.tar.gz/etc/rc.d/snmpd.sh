#!/bin/sh
# ucd-snmp init file for snmpd
#
# chkconfig: - 50 50
# description: Simple Network Management Protocol (SNMP) Daemon
#
# processname: /usr/sbin/snmpd
# config: /etc/snmp/snmpd.conf
# config: /usr/share/snmp/snmpd.conf
# pidfile: /var/run/snmpd

# source function library
#. /etc/rc.d/functions

SNMP_ENABLE="`nvram get enable_snmp_agent`"
SNMP_ROCOMMUNITY="`nvram get snmp_rocommunity`"
SNMP_RWCOMMUNITY="`nvram get snmp_rwcommunity`"
SNMPV3_ENABLE="`nvram get enable_snmpv3_agent`"
SNMPV3_USER="`nvram get snmpv3_user`"
SNMPV3_SEC_LEVEL="`nvram get sel_snmpv3_sec_level`"
SEL_SNMPV3_PRIV="`nvram get sel_snmpv3_priv`"
SNMPV3_PRIV="`nvram get snmpv3_priv`"
SEL_SNMPV3_AUTH="`nvram get sel_snmpv3_auth`"
SNMPV3_AUTH="`nvram get snmpv3_auth`"
SNMPV3_ENV_AUTH="MD5"
SNMPV3_ENV_PRIV="DES"
#SNMPV3_PRIV_AUTH="`nvram get snmpv3_priv_auth`"
SNMPV3_MAKER=""

PRODUCT_ID=`nvram get product_id`
LAN_IPADDR=`nvram get lan_ipaddr`

init_snmpd_conf()
{
	if [ ! -d /var/etc/snmp ]; then
		mkdir -p /var/etc/snmp
	fi;

    echo "sysname `nvram get product_id`" >> /var/etc/snmp/snmpd.conf
	if [ "x$SNMP_ROCOMMUNITY" != "x" ]; then
		echo "rocommunity $SNMP_ROCOMMUNITY" >> /var/etc/snmp/snmpd.conf
	fi
	if [ "x$SNMP_RWCOMMUNITY" != "x" ]; then
		echo "rwcommunity $SNMP_RWCOMMUNITY" >> /var/etc/snmp/snmpd.conf
	fi
	echo "" >> /var/etc/snmp/snmpd.conf
	#echo "view roview included  .1.3.6.1.2.1.4.1" >> /var/etc/snmp/snmpd.conf
    #echo "sysLocation Not set" >> /var/etc/snmp/snmpd.conf
    #echo "sysContact Not set" >> /var/etc/snmp/snmpd.conf

    echo "" >> /var/etc/snmp/snmpd.conf
	echo "rouser internal" >> /var/etc/snmp/snmpd.conf
	echo "createuser internal" >> /var/etc/snmp/snmpd.conf
	echo "agentSecName internal" >> /var/etc/snmp/snmpd.conf
	echo "iquerySecName internal" >> /var/etc/snmp/snmpd.conf
	echo "defaultMonitors yes" >> /var/etc/snmp/snmpd.conf
	echo "trapcommunity public" >> /var/etc/snmp/snmpd.conf
    #echo "trapcommunity  private" >> /var/etc/snmp/snmpd.conf
    echo "" >> /var/etc/snmp/snmpd.conf
	# send traps on authentication failures
    echo "authtrapenable 1" >> /var/etc/snmp/snmpd.conf
	# send v1 traps
	echo "trapsink 192.168.1.100:162 public" >> /var/etc/snmp/snmpd.conf
	# send v2 traps
    echo "trap2sink 192.168.1.100:162 public" >> /var/etc/snmp/snmpd.conf
    echo "informsink 192.168.1.100:162 public" >> /var/etc/snmp/snmpd.conf
	#echo "authcommunity execute,log,net public" > /var/etc/snmp/snmptrapd.conf	
    #echo "trapenable up" >> /var/etc/snmp/snmpd.conf
	echo "linkUpDownNotifications yes" >> /var/etc/snmp/snmpd.conf
	echo "notificationEvent linkUpTrap linkUp ifIndex ifAdminStatus ifOperStatus" >> /var/etc/snmp/snmpd.conf
	echo "notificationEvent linkDownTrap linkDown ifIndex ifAdminStatus ifOperStatus" >> /var/etc/snmp/snmpd.conf
	echo "monitor -r 15 -e linkUpTrap \"Generate linkUp\" ifOperStatus != 2" >> /var/etc/snmp/snmpd.conf
	echo "monitor -r 15 -e linkDownTrap \"Generate linkDown\" ifOperStatus == 2" >> /var/etc/snmp/snmpd.conf


    echo "" >> /var/etc/snmp/snmpd.conf
	## SNMPv3 ##
	if [ "x$SNMPV3_ENABLE" = "xon" ]; then
		echo "rouser $SNMPV3_USER $SNMPV3_MAKER" >> /var/etc/snmp/snmpd.conf
		case "$SNMPV3_MAKER" in
		"priv")
			echo "createuser $SNMPV3_USER $SNMPV3_ENV_AUTH $SNMPV3_AUTH $SNMPV3_ENV_PRIV $SNMPV3_PRIV" >> /var/etc/snmp/snmpd.conf
			;;
		"auth")
			echo "createuser $SNMPV3_USER $SNMPV3_ENV_AUTH $SNMPV3_AUTH" >> /var/etc/snmp/snmpd.conf
			;;
		"noauth")
			echo "createuser $SNMPV3_USER" >> /var/etc/snmp/snmpd.conf
			;;
		esac
	fi
	#echo "" >> /var/etc/snmp/snmpd.conf
    #echo "[snmp]" >> /var/etc/snmp/snmpd.conf
    #echo "doDebugging 1" >> /var/etc/snmp/snmpd.conf
    #echo "debugTokens  this,that,theother" >> /var/etc/snmp/snmpd.conf
}

init_snmptrapd_conf(){
	
	if [ ! -d /var/etc/snmp ]; then
		mkdir -p /var/etc/snmp
	fi

	echo "authcommunity execute,log,net public" > /var/etc/snmp/snmptrapd.conf	
	echo "traphandle .1.3.6.1.6.3.1.5.1 /bin/echo @markshih@"	>> /var/etc/snmp/snmptrapd.conf
	echo "traphandle .1.3.6.1.4.1.2021.251.1 page_me" >> /var/etc/snmp/snmptrapd.conf
	echo "traphandle .1.3.6.1.4.1.2021.251.2 /etc/rc.d/aaa.sh 3" >> /var/etc/snmp/snmptrapd.conf
	echo "traphandle default /etc/rc.d/aaa.sh" >> /var/etc/snmp/snmptrapd.conf
	#echo "traphandle .1.3.6.1.6.3.1.1.5.3 /bin/echo linkdown" >> /var/etc/snmp/snmptrapd.conf
	#echo "traphandle .1.3.6.1.6.3.1.1.5.4 /bin/echo linkup" >> /var/etc/snmp/snmptrapd.conf

}

#OPTIONS="-Lsd -Lf /dev/null -p /var/run/snmpd -a"
OPTIONS="-C -c /var/etc/snmp/snmpd.conf -Lsd -Lf /dev/null -p /var/run/snmpd.pid -a"
#OPTIONS="-c /var/etc/snmp/snmpd.conf -Lsd -Lf /dev/console -p /var/run/snmpd.pid -Dall -a"
RETVAL=0
prog="/usr/sbin/snmpd"
PID_FILE="/var/run/snmpd.pid"

start() {
	# Start daemons.
	local snmpd_enable=`nvram get snmpd_enable`

	echo -n $"Starting $prog: "
	if [ "$snmpd_enable" = "1" ]; then
		case "$SNMPV3_SEC_LEVEL" in
		"2")
			SNMPV3_MAKER="priv"
			;;
		"1")
			SNMPV3_MAKER="auth"
			;;
		"0")
			SNMPV3_MAKER="noauth"
			;;
		esac
			
		if [ "x$SEL_SNMPV3_AUTH" = "x0" ]; then
			SNMPV3_ENV_AUTH="MD5"
		else
			SNMPV3_ENV_AUTH="SHA"
		fi

		if [ "x$SEL_SNMPV3_PRIV" = "x0" ]; then
			SNMPV3_ENV_PRIV= "DES" #DES
		else
			SNMPV3_ENV_PRIV= "AES" #AES
		fi

		if [ -e /var/etc/snmp/snmpd.conf ]; then
			rm -f /var/etc/snmp/snmpd.conf
		fi
		init_snmpd_conf
		#init_snmptrapd_conf
		${prog} $OPTIONS
		RETVAL=$?
	fi;

	echo
	return $RETVAL
}

stop() {
	echo -n $"Stopping $prog: "
	killall -9 snmpd
	rm -f ${PID_FILE}
	RETVAL=$?
	echo
	return $RETVAL
}

reload(){
	echo -n $"Reloading $prog: "
	killproc /usr/sbin/snmpd -HUP
	RETVAL=$?
	echo
	return $RETVAL
}

restart(){
	stop
	if [ "x$SNMP_ENABLE" = "xon" -o "x$SNMPV3_ENABLE" = " xon" ];then
		start
	fi
}

condrestart(){
    [ -e /var/lock/subsys/snmpd ] && restart
    return 0
}

case "$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  restart)
        restart
        ;;
  reload)
        reload
        ;;
  condrestart)
        condrestart
        ;;
  status)
        status snmpd
        RETVAL=$?
        ;;
  run)
		snmpd -c /var/etc/snmp/snmpd.conf -Lsd -Lf /dev/console
		;;
  *)
        echo $"Usage: $0 {start|stop|status|restart|condrestart|reload}"
        RETVAL=1
esac

exit $RETVAL
