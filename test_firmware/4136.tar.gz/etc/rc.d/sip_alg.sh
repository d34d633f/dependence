#!/bin/sh

RETVAL=0

SIP_ALG_disable=`nvram get wan_endis_sipalg`
sip_ports=`nvram get sip_ports`
if [ "$sip_ports" = "" ]; then
	sip_ports="5060,5061"
fi
MODULE_PATH="/lib/modules/2.6.30"
#MODULE_NAME_1="/lib/modules/2.6.30/nf_conntrack_sip.ko ports=$sip_ports"
MODULE_NAME_1="nf_conntrack_sip"
MODULE_NAME_2="nf_nat_sip"

MODULE_NAME_1_FILE="/lib/modules/2.6.30/nf_conntrack_sip.ko"
MODULE_NAME_2_FILE="/lib/modules/2.6.30/nf_nat_sip.ko"

PROC_CONFIG="/proc/net/sipalg_devs"

wan_default_iface=`nvram get wan_default_iface`
ETH_WAN_INDEX=`nvram get eth_wan_iface`
wan_phy_mode=`nvram get wan_phy_mode`
wan_phy_auto=`nvram get wan_phy_auto`
if [ "$wan_phy_mode" = "adsl" ]; then
    MULTI_WAN=1
fi

if [ "$MULTI_WAN" = "1" ]; then
    iface=$2
    index=$iface
    wan_ip=`nvram get wan${iface}_default_ipaddr`
    if [ "$wan_phy_auto" = "1" ] && [ "$iface" = "$wan_default_iface" ]; then
                if [ "x$wan_ip" = "x" ]; then
                        iface=$ETH_WAN_INDEX
                        wan_ip=`nvram get wan${iface}_default_ipaddr`
                fi
    fi
    if [ "$iface" = "$ETH_WAN_INDEX" ]; then        
                index=$wan_default_iface
    fi
fi


start() {
	echo "Set SIP_ALG function enable ..."

	if [ "$SIP_ALG_disable" = "0" ]; then
		if ! /usr/sbin/lsmod |grep $MODULE_NAME_1 > /dev/null; then \
			/usr/sbin/insmod $MODULE_NAME_1_FILE ports=$sip_ports
		fi
		if ! /usr/sbin/lsmod |grep $MODULE_NAME_2 > /dev/null; then \
			/usr/sbin/insmod $MODULE_NAME_2_FILE
		fi
		echo "dst_port_range 255.255.255.255 5060 5061" > /proc/conntrack_killer
	fi

	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	echo "Set SIP_ALG function disable ..."

	#for module in $MODULE_NAME_2 $MODULE_NAME_1;
	for module in $MODULE_NAME_2 $MODULE_NAME_1;
	do
		#echo "remove $module kernel module"
		rmmod $module 2> /dev/null
	done
    	#echo "dst_port_range 255.255.255.255 5060 5061" > /proc/conntrack_killer
	
	RETVAL=$?
	return $RETVAL
}

proc_config() {

    if [ "$MULTI_WAN" = "1" ]; then
    	SIP_ALG_disable=0
	start
        sipalg_config=`cat $PROC_CONFIG`
        endis_sipalg=`nvram get wan${index}_endis_sipalg`
        bit_pos=$(($index-1))
        bit_set=$((1 << $bit_pos))
        if [ "$endis_sipalg" = "0" ]; then
            bit_map=$bit_set
            sipalg_value=$(($sipalg_config | $bit_map))
        elif [ "$endis_sipalg" = "1" ]; then
            bit_map=$((255 - $bit_set))
            sipalg_value=$(($sipalg_config & $bit_map))
        fi

        echo "sipalg config=$sipalg_value"
        echo $sipalg_value > $PROC_CONFIG
    else
        echo 256 > $PROC_CONFIG
    fi	
    echo "dst_port_range 255.255.255.255 5060 5061" > /proc/conntrack_killer
}


case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  config)
	proc_config
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

