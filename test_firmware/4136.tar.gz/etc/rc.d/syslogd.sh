#!/bin/sh

#[ -f /sbin/syslogd ] || exit 0

RETVAL=0
prog="syslogd"
PID_FILE="/var/run/syslogd.pid"
klogd="klogd"
RlogType=`nvram get RlogType`
RlogServer=`nvram get RlogServer`
RlogBitMap=`nvram get RlogBitMap`
AP_NAME=`nvram get product_id`

start() {
	# Start daemons.
	echo $"Starting $prog: "
	if [ "$RlogType" = "2" ]; then
		echo "${prog} -R $RlogServer -L -h $AP_NAME -m -1"
		${prog} -R $RlogServer -L  -h $AP_NAME -m -1
	elif [ "$RlogType" = "0" ]; then
		${prog} -m -1
        elif [ "$RlogType" = "1" ]; then
                echo "${prog} -R 255.255.255.255 -L -M -B -h $AP_NAME -m -1"
                ${prog} -R 255.255.255.255 -L -M -B -h $AP_NAME -m -1
	fi
	${klogd}
	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting down $prog: "
	#if [ -e ${PID_FILE} ]; then
	#	kill `cat ${PID_FILE}`
	#	rm -f ${PID_FILE}
	#fi
	killall -9 syslogd
	rm -f ${PID_FILE}
	killall -9 klogd
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

