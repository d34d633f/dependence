#!/bin/sh

wan_phy_mode=`nvram get wan_phy_mode`
wan_default_iface=`nvram get wan_default_iface`

if [ "$wan_phy_mode" = "adsl" ]; then
	if [ "$2" = "" ]; then
		lan_ifname=`nvram get lan${wan_default_iface}_ifname`
		lan_ipaddr=`nvram get lan${wan_default_iface}_ipaddr`
	else
		lan_ifname=`nvram get lan$2_ifname`
		lan_ipaddr=`nvram get lan$2_ipaddr`
	fi
else
	lan_ifname=`nvram get lan$2_ifname`
	lan_ipaddr=`nvram get lan$2_ipaddr`
fi

iptables -t nat -D PREROUTING -j nat_http_hijack 2> /dev/null  
iptables -t nat -I PREROUTING -j nat_http_hijack  

start()
{

	iptables -t nat -A nat_http_hijack -i $lan_ifname -p tcp --dport 80 -j DNAT --to-destination $lan_ipaddr:80

}

stop()
{

	iptables -t nat -F nat_http_hijack

}

# See how we were called.
case "$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  restart)
	stop
	start
	;;
  *)
        echo $"Usage: $0 {start|stop|restart|AddChain|restartChain}"
        exit 1
esac

exit $RETVAL

