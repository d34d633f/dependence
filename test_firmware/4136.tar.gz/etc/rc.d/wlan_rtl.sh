#!/bin/sh

#
# script file to start WLAN
#

WLAN_IF="wlan0"
WLAN_VA_IF="wlan0-vap"
WAN_IF=`nvram get wan_hwifname`
BR=`nvram get lan_ifname`
sys_uptime=$([ -f /proc/uptime ] && cat /proc/uptime | awk '{print $1}' | awk -F. '{print $1}')
MSSID_num=3
MSSID_ACT=0
MSSID_disable=1
WDS_REPEATER="0"
WEP_SHARED="0"
HEXDUMP=/usr/bin/hexdump

# Allow guest to access My Local Network
RUN_GUEST_ACCESS_FILE=0
guest_access_file=/tmp/guest_access

if [ "$(nvram get wds_repeater_basic)" = "1" ]; then
	CLI_ASSO=`nvram get wds_endis_mac_client`	## WDS base station
else
	CLI_ASSO=`nvram get wds_endis_ip_client`	## WDS repeater
fi

# config IPTV for guest network
iptv_conf()
{
	GUEST1=""
	GUEST2=""
	GUEST3=""

	idx=0
	for num in 1 2 3
	do
		if [ "$(nvram get wlg"$num"_endis_guestNet)" = "1" ]; then
			eval GUEST"$num"=$WLAN_VA_IF"$idx"
			idx=$(($idx+1))
		else
			eval GUEST"$num"=""
		fi
	done

	echo IPTV Setup: Guest2:[$GUEST1] Guest3:[$GUEST2] Guest4:[$GUEST3]

	for num in 1 2 3
	do
		# IPTV1
		atmPVC_en=`nvram get atmPVC2 | cut -d "*" -f 1`
		if [ "$atmPVC_en" = "1" ]; then
			if [ "`nvram get iptv1_intf_maps | cut -d"|" -f $(($num+5))`" = "1" ]; then
				eval guest='$GUEST'"$num"
				iwpriv $guest set_mib guest_access=0
			fi	
		fi
		# IPTV2
		atmPVC_en=`nvram get atmPVC3 | cut -d "*" -f 1`
		if [ "$atmPVC_en" = "1" ]; then
			if [ "`nvram get iptv2_intf_maps | cut -d"|" -f $(($num+5))`" = "1" ]; then
				eval guest='$GUEST'"$num"
				iwpriv $guest set_mib guest_access=0
			fi	
		fi
	done
}

# handle WPS unconfigured mode
PARAM_FILE="/tmp/flash_param"
config_wsc()
{
   if [ -f "$PARAM_FILE" ]; then
	WSC_SSID=`grep WSC_SSID $PARAM_FILE | cut -d"=" -f 2 | sed -e 's/\"//g'`	
	WSC_AUTH=`grep WSC_AUTH $PARAM_FILE | cut -d"=" -f 2`	
	WSC_PSK=`grep WSC_PSK $PARAM_FILE | cut -d"=" -f 2 | sed -e 's/\"//g'`	
	WSC_ENC=`grep WSC_ENC $PARAM_FILE | cut -d"=" -f 2`	
#	WSC_CONFIGBYEXTREG=`grep WSC_CONFIGBYEXTREG $PARAM_FILE | cut -d"=" -f 2`	
#	WSC_CONFIGURED=`grep WSC_CONFIGURED $PARAM_FILE | cut -d"=" -f 2`	

	nvram set wl_ssid="$WSC_SSID"

	# WPS 2.0 only support OPEN, WPA2-PSK, WPA/WPA2 mixed mode
	# But NETGEAR SPEC preferred send WPA2-AES, due to performance and interoperate issue
	if [ "$WSC_AUTH" = "1" -a "$WSC_ENC" = "1" ]; then
		# none security
		nvram set wl_sectype=1
	elif [ "$WSC_AUTH" = "32" -a "$WSC_ENC" = "8" ]; then
		# wpa2-aes
		nvram set wl_sectype=4
		nvram set wl_wpa2_psk="$WSC_PSK"
	else
		# wpa-tkip & wpa2-aes mixed mode
		nvram set wl_sectype=5
		nvram set wl_wpas_psk="$WSC_PSK"
	fi

	#if [ "$WSC_CONFIGURED" = "1" ]; then
		nvram set wps_status=5
	#fi

	echo 1 > /tmp/reinitwscd
	sleep 1
	nvram commit
	nvram set action=99
	
    else
	echo "$PARAM_FILE" not exist, skip set credential to AP!!
    fi
			
}


Kill_proc()
{
    if [ -f $1 ] ; then
       	  PID=`cat $1`
	  if [ $PID != 0 ]; then
	       kill -9 $PID
	  fi
          rm -f $1
    fi
}

Applications()
{
   if [ "$1" = "start" ]; then
          echo "starting app"
          IF_LIST=$WLAN_IF

          #### MBSSID #### (2,3,4,5)
          num=0
          while [ $num -lt $MSSID_num ]
          do
                  if [ "$(nvram get wlg"$(($num+1))"_endis_guestNet)" = "1" ]; then
                       IF_LIST="$IF_LIST $WLAN_VA_IF$num"
                  fi
          
          num=$(($num+1))
          done
       
          #num=0
          #if [ "$(nvram get wlg1_endis_guestNet)" = "1" -a "$(nvram get wlg1_sectype)" = "6" ]; then
          #     IF_LIST="$IF_LIST $WLAN_VA_IF$num"
          #fi
         
          iwcontrol $IF_LIST

          #added by dvd.chen, to restart mini_upnpd. Cause setting wireless might enable<->disable WPS
          if [ "$(nvram get wsc_stat_change)" = "1" ]; then
                /etc/rc.d/mini_upnp.sh restart
                nvram set wsc_stat_change=0
          fi
          
   else
          echo "stopping app"
          Kill_proc /var/run/iwcontrol.pid
          Kill_proc /var/run/auth-"$WLAN_IF".pid
	  
	  num=0
	  while [ $num -lt $MSSID_num ]
	  do
          	Kill_proc /var/run/auth-"$WLAN_VA_IF"$num.pid
		num=$(($num+1))	
	  done
          #Kill_proc /var/run/auth-"$WLAN_VA_IF"0.pid
   
   fi
}
Set_power()
{
    #val="$(nvram get wl_txctrl)"
    val="$(nvram get wl_txctrl_web)"
    if [ "$val" = "0" ]; then
        iwpriv wlan0 set_mib $1="$(nvram get $1)"
    else
        iwpriv wlan0 set_mib $1="$(nvram get $2)"
    fi

}

Basic_settings()
{  
    #echo "Basic...."
    SSID="$(nvram get wl_ssid | sed -e 's/\\\\\\\\/\\/g' -e 's/\\\\\\`/`/g' -e 's/\\\"/"/g')"
    CH=`nvram get wl_channel`
    #MODE=`nvram get wl_mode`
    MODE=`nvram get wl_simple_mode`
    COUN=`nvram get wl_country`
    WDS=`nvram get wds_endis_fun`
           
    ifconfig $WLAN_IF down
    iwpriv $WLAN_IF set_mib ssid="$SSID"
    iwpriv $WLAN_IF set_mib channel=$CH
    iwpriv $WLAN_IF set_mib disable_protection=0
    iwpriv $WLAN_IF set_mib oprates=4095
    iwpriv $WLAN_IF set_mib basicrates=15
    iwpriv $WLAN_IF set_mib shortGI20M=1
    iwpriv $WLAN_IF set_mib shortGI40M=1
    iwpriv $WLAN_IF set_mib ampdu=1
    iwpriv $WLAN_IF set_mib amsdu=1
    iwpriv $WLAN_IF set_mib disable_brsc=0
    iwpriv $WLAN_IF set_mib wifi_specific=2
    iwpriv $WLAN_IF set_mib MIMO_TR_mode=4 # 3->2T2R, 4->1T1R
    #iwpriv $WLAN_IF set_mib led_type=14 ##set to 12 in set_hw_nvram.sh
    iwpriv $WLAN_IF set_mib ledBlinkingFreq=7
    iwpriv $WLAN_IF set_mib lgyEncRstrct=15

    # HT20/HT40 coexistant mode, 0->disable, 1->enable
    if [ "$(nvram get wl_disablecoext)" = "0" ]; then
          iwpriv $WLAN_IF set_mib coexist=1
    else
          iwpriv $WLAN_IF set_mib coexist=0
    fi
  
    # Default disable WIFI isolation 
    if [ "$(nvram get endis_wlan_iso)" = "1" ]; then
          iwpriv $WLAN_IF set_mib block_relay=1
          iwpriv $WLAN_IF set_mib guest_access=1
    else
          iwpriv $WLAN_IF set_mib block_relay=0
          iwpriv $WLAN_IF set_mib guest_access=0
    fi
    
    ##transmit power
    Set_power "pwrlevelCCK_A" "mod_CCK_A"
#    Set_power "pwrlevelCCK_B" "mod_CCK_B"
    Set_power "pwrlevelHT40_1S_A" "mod_HT40_1S_A"
#    Set_power "pwrlevelHT40_1S_B" "mod_HT40_1S_B"
#    Set_power "pwrdiffHT40_2S" "mod_HT40_2S"
#    Set_power "pwrdiffHT20" "mod_diffHT20"
    Set_power "pwrdiffOFDM" "mod_diffOFDM"
  
    if [ "$CLI_ASSO" = "1" -a "$WDS" = "1" ]; then ## WDS only
         iwpriv $WLAN_IF set_mib wds_pure=1
    else
         iwpriv $WLAN_IF set_mib wds_pure=0
    fi
        
    ## 1->54M, 2->130M, 3->300M, 4->unknown, 5->300M, 2ndchoffset=2, 6->300M, auto channel
    case "$MODE" in
           1)
           iwpriv $WLAN_IF set_mib band=3
           iwpriv $WLAN_IF set_mib use40M=0
           iwpriv $WLAN_IF set_mib 2ndchoffset=0
           ;;
           2)    
           iwpriv $WLAN_IF set_mib band=11
           iwpriv $WLAN_IF set_mib use40M=0
           iwpriv $WLAN_IF set_mib 2ndchoffset=0
           iwpriv $WLAN_IF set_mib qos_enable=1
           ;;
           3|5|6)
           iwpriv $WLAN_IF set_mib band=11
           iwpriv $WLAN_IF set_mib use40M=1
           iwpriv $WLAN_IF set_mib qos_enable=1
           
           # P<=6, S=P+4;P>6, S=P-4
           if [ $CH -gt 9 ]; then
                iwpriv $WLAN_IF set_mib 2ndchoffset=2
           else
                iwpriv $WLAN_IF set_mib 2ndchoffset=1
           fi           
           ;;
    esac    
    
    case "$COUN" in
         0)
         iwpriv $WLAN_IF set_mib regdomain=3 # africa
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=2
         ;;
         1)   
         iwpriv $WLAN_IF set_mib regdomain=3 # asia ?
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=2
         ;;
         2)   
         #iwpriv $WLAN_IF set_mib regdomain=1 # australia
         #iwpriv $WLAN_IF set_mib txpwr_lmt_index=1
         iwpriv $WLAN_IF set_mib regdomain=14 # australia
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=4
         ;;
         3)   
         iwpriv $WLAN_IF set_mib regdomain=1 # canada
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=1
         ;;
         4)   
         iwpriv $WLAN_IF set_mib regdomain=3 # europe
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=2
         ;;
         5)   
         iwpriv $WLAN_IF set_mib regdomain=3 # israel ?
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=2
         ;;
         6)   
         iwpriv $WLAN_IF set_mib regdomain=6 # japan
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=3
         ;;
         7)   
         iwpriv $WLAN_IF set_mib regdomain=3 # korea ?
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=2
         ;;
         8)   
         iwpriv $WLAN_IF set_mib regdomain=1 # maxico
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=1
         ;;
         9)   
         iwpriv $WLAN_IF set_mib regdomain=1 # south america
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=1
         ;;
         10)   
         iwpriv $WLAN_IF set_mib regdomain=1 # america
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=1
         ;;
         11)   
         iwpriv $WLAN_IF set_mib regdomain=3 # middle_east
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=2
         ;;
         12)   
         iwpriv $WLAN_IF set_mib regdomain=3 # russia
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=2
         ;;
          *)
         iwpriv $WLAN_IF set_mib regdomain=3 # others
         iwpriv $WLAN_IF set_mib txpwr_lmt_index=2
         ;;
    esac
    
         
     num=1
     while [ "$num" -le "$MSSID_num" ]
     do
     if [ "$(nvram get wlg"$num"_endis_guestNet)" = "1" ]; then
           MSSID_disable=0
           MSSID_ACT=$(($MSSID_ACT+1))
     fi
     num=$(($num+1))
     done

    #for single guest network
    #if [ "$(nvram get wlg1_endis_guestNet)" = "1" ]; then
    #      MSSID_disable=0
    #      MSSID_ACT=$(($MSSID_ACT+1))
    #fi

    ############## set vap_enable=1  if any guest is enabled ################
    if [ "$MSSID_disable" = "0" ]; then
          iwpriv $WLAN_IF set_mib vap_enable=1
    else  
          iwpriv $WLAN_IF set_mib vap_enable=0
    fi
     
     ########### set wlan0 beacon #####################  
        case "$MSSID_ACT" in
           0)
           iwpriv $WLAN_IF set_mib bcnint=100
           iwpriv $WLAN_IF set_mib dtimperiod=2
           ;;
           1)
           iwpriv $WLAN_IF set_mib bcnint=200
           iwpriv $WLAN_IF set_mib dtimperiod=2
           ;;
           2)
           iwpriv $WLAN_IF set_mib bcnint=300
           iwpriv $WLAN_IF set_mib dtimperiod=2
           ;;
           3)
           iwpriv $WLAN_IF set_mib bcnint=400
           iwpriv $WLAN_IF set_mib dtimperiod=2
           ;;
           4)
           iwpriv $WLAN_IF set_mib bcnint=500
           iwpriv $WLAN_IF set_mib dtimperiod=2
           ;;
        esac
    
}

guestNet_settings()
{
	# Generate guestNet MAC address
	prefix_mac1=`nvram get wl_hwaddr | cut -b1`
	prefix_mac2=`nvram get wl_hwaddr | cut -b2`
	prefix_mac2=$(($prefix_mac2+2))
	postfix_mac=`nvram get wl_hwaddr | cut -d: -f2-6`
	guestNet_hwaddr=$prefix_mac1$prefix_mac2":"$postfix_mac

	ac_num=0
	if [ "$(nvram get wlg1_endis_guestNet)" = "1" ]; then
            SSID="$(nvram get wlg1_ssid)"
            BROADCAST="$(nvram get wlg1_endis_guestSSIDbro)"
            GUEST_ACCESS="$(nvram get wlg1_endis_allow_guest)"

            ifconfig $WLAN_VA_IF$ac_num down
            iwpriv $WLAN_VA_IF$ac_num copy_mib 
            #ifconfig $WLAN_VA_IF$ac_num hw ether $(nvram get hwaddr_$(($num+2)))
            ifconfig $WLAN_VA_IF$ac_num hw ether "$guestNet_hwaddr"
            iwpriv $WLAN_VA_IF$ac_num set_mib ssid="$SSID"
            iwpriv $WLAN_VA_IF$ac_num set_mib hiddenAP=$((1-$BROADCAST))
            iwpriv $WLAN_VA_IF$ac_num set_mib guest_access=$((1-$GUEST_ACCESS))
            iwpriv $WLAN_VA_IF$ac_num set_mib vap_enable=1
            iwpriv $WLAN_VA_IF$ac_num set_mib basicrates=0
            iwpriv $WLAN_VA_IF$ac_num set_mib oprates=0
            iwpriv $WLAN_VA_IF$ac_num set_mib wds_enable=0
	
            # Guest Network default enable wifi isolation
            #iwpriv $WLAN_VA_IF$ac_num set_mib block_relay=0
            #iwpriv $WLAN_VA_IF$ac_num set_mib guest_access=0

            if [ "$(nvram get endis_wlg_guest_wireless_isolation)" = "1" ]; then
                 iwpriv $WLAN_VA_IF$ac_num set_mib block_relay=1
            else
                 iwpriv $WLAN_VA_IF$ac_num set_mib block_relay=0
            fi
	fi

}

MSSID_settings()
{
    #echo "MSSID ..."
   
    
    #### MBSSID #### (2,3,4,5)
    num=1
    ac_num=0
    while [ $num -le $MSSID_num ]
    do      

       if [ "$(nvram get wlg"$num"_endis_guestNet)" = "1" ]; then

            SSID="$(nvram get wlg"$num"_ssid | sed -e 's/\\\\\\\\/\\/g' -e 's/\\\\\\`/`/g' -e 's/\\\"/"/g')"
            BROADCAST=$(nvram get wlg"$num"_endis_guestSSIDbro)
            GUEST_ACCESS=$(nvram get wlg"$num"_endis_allow_guest)
            
            ifconfig $WLAN_VA_IF$ac_num down
            iwpriv $WLAN_VA_IF$ac_num copy_mib 
#            ifconfig $WLAN_VA_IF$ac_num hw ether $(nvram get hwaddr_$(($num+2)))
            ifconfig $WLAN_VA_IF$ac_num hw ether $(nvram get wlg"$num"_hwaddr)
            iwpriv $WLAN_VA_IF$ac_num set_mib ssid="$SSID"
            iwpriv $WLAN_VA_IF$ac_num set_mib hiddenAP=$((1-$BROADCAST))
            iwpriv $WLAN_VA_IF$ac_num set_mib guest_access=$((1-$GUEST_ACCESS))
            iwpriv $WLAN_VA_IF$ac_num set_mib vap_enable=1
            iwpriv $WLAN_VA_IF$ac_num set_mib basicrates=0
            iwpriv $WLAN_VA_IF$ac_num set_mib oprates=0
            iwpriv $WLAN_VA_IF$ac_num set_mib wds_enable=0

            if [ "$(nvram get wlg"$num"_endis_guest_wireless_isolation)" = "1" ]; then
                 iwpriv $WLAN_VA_IF$ac_num set_mib block_relay=1
            else
                 iwpriv $WLAN_VA_IF$ac_num set_mib block_relay=0
            fi
            ac_num=$(($ac_num+1))

       fi
    
    num=$(($num+1))
    done
    
     

}

Adv_settings()
{
    #echo "ADV..."
    RADIO=`nvram get endis_wl_radio`
    BROADCAST=`nvram get endis_ssid_broadcast`
    WMM=`nvram get endis_wl_wmm`
    FRAG=`nvram get wl_frag`
    RTS=`nvram get wl_rts`
    PREAMBLE=`nvram get wl_plcphdr`
    
    iwpriv $WLAN_IF set_mib hiddenAP=$((1-$BROADCAST))
    
    #MODE=`nvram get wl_mode`
    MODE=`nvram get wl_simple_mode`
    if [ "$MODE" = "1" ]; then  
          iwpriv $WLAN_IF set_mib qos_enable=$WMM
    fi
    iwpriv $WLAN_IF set_mib fragthres=$FRAG
    iwpriv $WLAN_IF set_mib rtsthres=$RTS
    iwpriv $WLAN_IF set_mib preamble=$PREAMBLE
}


Wpa_conf()
{
    if [ "$(nvram get wl$1_sectype)" != "6" ]; then
         return
    fi

    WPAE_MODE=`nvram get wl$1_wpae_mode`
    if [ "$WPAE_MODE" = "WPAE-TKIP" ]; then
          ENC=2
          UNI_CIPH=1
          WPA2_UNI_CIPH=2
          PSK=`nvram get wl$1_wpa1_psk`
          PSK_LEN=`echo $PSK | wc -c`
          if [ "$PSK_LEN" = "65" ]; then
               USE_PASS=0
          else
               USE_PASS=1
          fi

    elif [ "$WPAE_MODE" = "WPAE-AES" ]; then
          ENC=4
          UNI_CIPH=1
          WPA2_UNI_CIPH=2  
          PSK=`nvram get wl$1_wpa2_psk`
          PSK_LEN=`echo $PSK | wc -c`
          if [ "$PSK_LEN" = "65" ]; then
               USE_PASS=0
          else
               USE_PASS=1
          fi
    elif [ "$WPAE_MODE" = "WPAE-TKIPAES" ]; then
	  # support additional WPA[AES], WPA2[TKIP]
          ENC=6
          UNI_CIPH=3	# 1
          WPA2_UNI_CIPH=3	# 2
          PSK=`nvram get wl$1_wpas_psk`
          PSK_LEN=`echo $PSK | wc -c`
          if [ "$PSK_LEN" = "65" ]; then
               USE_PASS=0
          else
               USE_PASS=1
          fi
    fi
	
    SSID="$(nvram get wl$1_ssid | sed -e 's/\\\\\\\\/\\/g' -e 's/\\\\\\`/`/g' -e 's/\\\"/"/g')"
    if [ "$ENC" = "0" -o "$ENC" = "1" ]; then
         ENABLE_1X=1
    else
         ENABLE_1X=0
    fi
    MAC_AUTH=0
    NON_WPA_CLIENT=0
    if [ "$(nvram get wl$1_key_length)" = "5" ]; then
          WEP_KEY=1
    else 
          WEP_KEY=2
    fi
    WEP_GROUP_KEY=""
    AUTH=1	# 1->Radius, 2->PSK         
    PRE_AUTH=0
    G_REKEY=86400
    RS_PORT=`nvram get wl$1_radiusPort`
    RS_IP=`nvram get wl$1_radiusSerIp`
    RS_PW=`nvram get wl$1_radiusSecret`
    RS_MAX_REQ=3
    RS_AWHILE=5
    

cat <<EOF
encryption = $ENC
ssid = "$SSID"
enable1x = $ENABLE_1X
enableMacAuth = $MAC_AUTH
supportNonWpaClient = $NON_WPA_CLIENT
wepKey = $WEP_KEY
wepGroupKey = ""
authentication = $AUTH
unicastCipher = $UNI_CIPH
wpa2UnicastCipher = $WPA2_UNI_CIPH
usePassphrase = $USE_PASS
psk = "0"
groupRekeyTime = $G_REKEY
rsPort = $RS_PORT
rsIP = $RS_IP
rsPassword = $RS_PW
rsMaxReq = $RS_MAX_REQ
rsAWhile = $RS_AWHILE
accountRsEnabled = 0
accountRsPort = 0
accountRsIP = 0.0.0.0
accountRsPassword = ""
accountRsUpdateEnabled = 0
accountRsUpdateTime = 0
accountRsMaxReq = 0
accountRsAWhile = 0

EOF

}

Security()
{
    #echo "Sec..."
    SEC=`nvram get wl$2_sectype`
    #WEP_LEN=`nvram get key_length$2`
    WEP_LEN=`nvram get wl$2_key_length`
    WEP_KEY=`nvram get wl$2_key`
    AUTH=`nvram get wl$2_auth`
    WEP_KEY1=`nvram get wl$2_key1`
    WEP_KEY2=`nvram get wl$2_key2`
    WEP_KEY3=`nvram get wl$2_key3`
    WEP_KEY4=`nvram get wl$2_key4`
    WPA_PSK1="$(nvram get wl$2_wpa1_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
    WPA_PSK2="$(nvram get wl$2_wpa2_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
    WPA_PSKS="$(nvram get wl$2_wpas_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"

    iwpriv $WLAN_IF$1$3 set_mib 802_1x=0
    key=`nvram get wl$2_key$WEP_KEY` 
    WEP_LEN=${#key}
    case "$SEC" in
    
          1)  ##none
          iwpriv $WLAN_IF$1$3 set_mib psk_enable=0
          iwpriv $WLAN_IF$1$3 set_mib encmode=0
          iwpriv $WLAN_IF$1$3 set_mib authtype=2
          ;;
          2)  ##wep
          iwpriv $WLAN_IF$1$3 set_mib psk_enable=0 
	  iwpriv $WLAN_IF$1$3 set_mib authtype=$AUTH
          if [ "$WEP_LEN" = "5" -o "$WEP_LEN" = "10" ]; then
		echo "WEP64bits"
                iwpriv $WLAN_IF$1$3 set_mib encmode=1	                
          else
		echo "WEP128bits"
                iwpriv $WLAN_IF$1$3 set_mib encmode=5
          fi


	  if [ "$WEP_LEN" = "5" -o "$WEP_LEN" = "13" ]; then
		ascii_key=`nvram get wl$2_key$WEP_KEY | ${HEXDUMP} -v -e '1/1 "%.2x"'|sed -e 's/0a//'`
		echo "Ascii key in hex value"
                echo $ascii_key
		iwpriv $WLAN_IF$1$3 set_mib wepkey$WEP_KEY=$ascii_key
	  else
		echo $key
		iwpriv $WLAN_IF$1$3 set_mib wepkey$WEP_KEY=$key
          	#iwpriv $WLAN_IF$1$3 set_mib wepkey1=$WEP_KEY1
	  	#iwpriv $WLAN_IF$1$3 set_mib wepkey2=$WEP_KEY2
	  	#iwpriv $WLAN_IF$1$3 set_mib wepkey3=$WEP_KEY3
	  	#iwpriv $WLAN_IF$1$3 set_mib wepkey4=$WEP_KEY4
	  fi    
	  
	  iwpriv $WLAN_IF$1$3 set_mib wepdkeyid=$(($WEP_KEY-1))

	  if [ "$AUTH" = "1" ]; then
	        WEP_SHARED="1"
	        #echo 1 > /proc/gpio
	  fi
   
          ;;
          3)  ##wpa-tkip
          iwpriv $WLAN_IF$1$3 set_mib authtype=2
          iwpriv $WLAN_IF$1$3 set_mib encmode=2
          iwpriv $WLAN_IF$1$3 set_mib psk_enable=1
          iwpriv $WLAN_IF$1$3 set_mib wpa_cipher=2
          iwpriv $WLAN_IF$1$3 set_mib passphrase="$WPA_PSK1"
          iwpriv $WLAN_IF$1$3 set_mib gk_rekey=3600
          ;;
          4)  ##wpa2-aes
          iwpriv $WLAN_IF$1$3 set_mib psk_enable=2
          iwpriv $WLAN_IF$1$3 set_mib encmode=2
          iwpriv $WLAN_IF$1$3 set_mib authtype=2
          iwpriv $WLAN_IF$1$3 set_mib wpa2_cipher=8
          iwpriv $WLAN_IF$1$3 set_mib passphrase="$WPA_PSK2"
          iwpriv $WLAN_IF$1$3 set_mib gk_rekey=3600
          ;;
          5)  ##wpa1 wpa2
          iwpriv $WLAN_IF$1$3 set_mib psk_enable=3
          iwpriv $WLAN_IF$1$3 set_mib encmode=2
          iwpriv $WLAN_IF$1$3 set_mib authtype=2
          iwpriv $WLAN_IF$1$3 set_mib wpa_cipher=10
          iwpriv $WLAN_IF$1$3 set_mib wpa2_cipher=10
          iwpriv $WLAN_IF$1$3 set_mib passphrase="$WPA_PSKS"
          iwpriv $WLAN_IF$1$3 set_mib gk_rekey=3600
          ;;
          6)  ##wpa 802_1x
          iwpriv $WLAN_IF$1$3 set_mib encmode=2
          iwpriv $WLAN_IF$1$3 set_mib authtype=2
          iwpriv $WLAN_IF$1$3 set_mib psk_enable=0
          iwpriv $WLAN_IF$1$3 set_mib 802_1x=1
	  Wpa_conf "$2" > /var/wpa-$WLAN_IF$1$3.conf
          auth $WLAN_IF$1$3 $BR auth /var/wpa-$WLAN_IF$1$3.conf
          ;;
    esac
    
}


Security_guestNet()
{
    ac_num=0
    if [ "$(nvram get wlg1_endis_guestNet)" = "1" ]; then
         Security "-vap" "g1" "$ac_num"
    fi
}

Security_MSSID()
{
    #### MBSSID #### (2,3,4,5)
    num=1
    ac_num=0
    while [ $num -le $MSSID_num ]
    do
       if [ "$(nvram get wlg"$num"_endis_guestNet)" = "1" ]; then
            #Security "-vap" "_$(($num+2))" "$ac_num"
            Security "-vap" "g$num" "$ac_num"
            ac_num=$(($ac_num+1))
       fi
    
    num=$(($num+1))
    done



}

Wds()
{
    #echo "WDS......."
    WDS=`nvram get wds_endis_fun`
    IS_ROOTAP=`nvram get wds_repeater_basic`
        
    if [ "$1" = "start" ]; then    
          WDS_SEC=`nvram get wl_sectype`
          #WEP_LEN=`nvram get key_length`
          WEP_LEN=`nvram get wl_key_length`
          WDS_KEY=`nvram get wl_key`
          WDS_WEPKEY=`nvram get wl_key$WDS_KEY`
          WPA_PSK1="$(nvram get wl_wpa1_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
          WPA_PSK2="$(nvram get wl_wpa2_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
          #WPA_PSKS="$(nvram get wl_wpas_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
          
          iwpriv $WLAN_IF set_mib wds_num=0       #reinitialize  
          
          if [ "$WDS_SEC" = "1" ]; then 
          #none
                iwpriv $WLAN_IF set_mib wds_encrypt=0
                iwpriv $WLAN_IF set_mib authtype=2
          elif [ "$WDS_SEC" = "2" -a "$WDS" = "1" ]; then 
          #wep
                if [ "$WEP_LEN" = "5" ]; then
                      iwpriv $WLAN_IF set_mib wds_encrypt=1
                      iwpriv $WLAN_IF set_mib wds_wepkey=$WDS_WEPKEY	                
                else
                      iwpriv $WLAN_IF set_mib wds_encrypt=5
                      iwpriv $WLAN_IF set_mib wds_wepkey=$WDS_WEPKEY
                fi
          elif [ "$WDS_SEC" = "3" -a "$WDS" = "1" ]; then
          #wpa-psk
                iwpriv $WLAN_IF set_mib wds_encrypt=2
                iwpriv $WLAN_IF set_mib wds_passphrase=$WPA_PSK1

          elif [ "$WDS_SEC" = "4" -a "$WDS" = "1" ]; then
          #wpa2-psk
                iwpriv $WLAN_IF set_mib wds_encrypt=4
                iwpriv $WLAN_IF set_mib wds_passphrase=$WPA_PSK2
          fi      
          
          ####  repeater mode  ####
          REP_IP=`nvram get repeater_ip`
          TAR_ROOTAP=$(nvram get basic_station_mac | sed -n 's/://gp')   
          
          if [ "$WDS" = "1" ]; then                                    
                if [ "$IS_ROOTAP" = "0" ]; then
                      #echo "41" > /proc/wan_port	# Bridge repeater mode
                      ifconfig $BR $REP_IP
                      brctl delif $BR $WAN_IF	# No need to add eth1 interface
                      iwpriv $WLAN_IF set_mib wds_add=$TAR_ROOTAP,0
                      WDS_REPEATER="1"
	                                     
                else                      
                      num=1
                      while [ $num -lt 5 ]
                      do 
                          tmprep=$(nvram get repeater_mac$num | sed -n 's/://gp')
                          
                          if [ "$tmprep" != "" ]; then
                              iwpriv $WLAN_IF set_mib wds_add=$tmprep,0                                                 
                          fi
                          num=$(($num+1))
                      done
                                           
                fi                
                iwpriv $WLAN_IF set_mib wds_enable=1
                brctl stp $BR on
                brctl setfd $BR 4
                    
          else  ##wds disabled
                iwpriv $WLAN_IF set_mib wds_enable=0
                iwpriv $WLAN_IF set_mib wds_encrypt=0
                brctl stp $BR off
                brctl setfd $BR 0
          fi    
                   
    else  # stop
          iwpriv $WLAN_IF set_mib wds_enable=0
          echo "Shutdown repeater..."
          #if [ "$IS_ROOTAP" = "0" ]; then
          #	echo "4" > /proc/wan_port	# WAN router mode
          #fi
	      
    fi
}

Guest_access()
{
    ETH_P_ARP=0x0806
    ETH_P_RARP=0x8035
    ETH_P_IP=0x0800
    IPPROTO_ICMP=1
    IPPROTO_UDP=17
    DHCPS_DHCPC=67:68
    PORT_DNS=53

cat<<EOF > $guest_access_file
#!/bin/sh

ebtables -F FORWARD
ebtables -F INPUT
ebtables -P FORWARD ACCEPT
ebtables -A FORWARD -p $ETH_P_ARP -j ACCEPT
ebtables -A FORWARD -p $ETH_P_RARP -j ACCEPT
ebtables -A FORWARD -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $DHCPS_DHCPC -j ACCEPT
ebtables -P INPUT ACCEPT
ebtables -A INPUT -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $DHCPS_DHCPC -j ACCEPT
ebtables -A INPUT -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $PORT_DNS -j ACCEPT
EOF

    # Primary Network
    #if [ "$(nvram get endis_wl_iso)" = "1" -a "$(nvram get endis_wl_radio)" = "1" ]; then
    if [ "$(nvram get endis_wlan_iso)" = "1" -a "$(nvram get endis_wl_radio)" = "1" ]; then
        RUN_GUEST_ACCESS_FILE=1
        echo "ebtables -A FORWARD -i $WLAN_IF -j DROP" >> $guest_access_file
        echo "ebtables -A INPUT -i $WLAN_IF -p $ETH_P_IP --ip-dst $(nvram get lan_ipaddr) -j DROP" >> $guest_access_file
    fi

    # Only has one Guest Network
    AP_ENABLE_ALLOW_GUEST=$(nvram get wlg1_endis_allow_guest)
    AP_ENIFACE=`nvram get wlg1_endis_guestNet`

    ac_num=0    
    if [ "$AP_ENABLE_ALLOW_GUEST" = "0" -a "$AP_ENIFACE" = "1" ]; then
            RUN_GUEST_ACCESS_FILE=1
            echo "ebtables -A FORWARD -i $WLAN_VA_IF$ac_num -j DROP" >> $guest_access_file
            echo "ebtables -A INPUT -i $WLAN_VA_If$ac_num -p $ETH_P_IP --ip-dst $(nvram get lan_ipaddr) -j DROP" >> $guest_access_file
    fi

    if [ "$RUN_GUEST_ACCESS_FILE" = "1" ]; then
        chmod +x $guest_access_file         
        $guest_access_file 
    else
        ebtables -F FORWARD
        ebtables -F INPUT
    fi
}

Acl()
{
	#echo "ACL...."
	iwpriv $WLAN_IF set_mib aclnum=0
	MACAC_ENABLED=`nvram get wl_access_ctrl_on`
	iwpriv $WLAN_IF set_mib aclmode=$MACAC_ENABLED
	if [ "$MACAC_ENABLED" != "0" ]; then
		MACAC_NUM=`nvram get wl_acl_num`
		if [ "$MACAC_NUM" != "0" ]; then
			num=1
			while [ $num -le $MACAC_NUM ]
			do
				AC_TBL=`nvram get wlacl$num`
				addr_tmp=`echo $AC_TBL | awk '{print $2}'`
				addr=`echo $addr_tmp | sed -n 's/://gp'`
				iwpriv $WLAN_IF set_mib acladdr=$addr
				num=$(($num+1))
			done
		fi
	fi
}

Update_conf()
{
     ENABLE_PIN=`nvram get endis_pin`
     MODE=`nvram get wps_status`
     UPNP=1
     CONF=9864
     CONN=1
     MAN=0
     SSID="$(nvram get wl_ssid | sed -e 's/\\\\\\\\/\\/g' -e 's/\\\\\\`/`/g' -e 's/\\\"/"/g')"
     PIN=`nvram get wps_pin`
     #PIN="49424324"
     RF=1
     DEVICE="$(nvram get netbiosname)"
     ENABLE_ATK=`nvram get endis_brutal`
     WPS_ATK_TIMES=`nvram get wps_atk_times`
     
     #echo "disable_configured_by_exReg = $DISABLE_PIN" > /var/wsc.conf
     if [ "$ENABLE_PIN" = "0" ]; then
	  echo "disable_configured_by_exReg = 1" > /var/wsc.conf
     else
	  echo "disable_configured_by_exReg = 0" > /var/wsc.conf
     fi
     echo "mode = $MODE" >> /var/wsc.conf
     echo "upnp = $UPNP" >> /var/wsc.conf
     echo "config_method = $CONF" >> /var/wsc.conf
     echo "connection_type = $CONN" >> /var/wsc.conf
     echo "manual_config = $MAN" >> /var/wsc.conf     
          
     SEC=`nvram get wl_sectype`
     case "$SEC" in
     1)#none
       ENC=1
       AUTH=1
       KEY=""
     ;;
     2)#wep
       ENC=2
       WEP_KEY=`nvram get wl_key`
       if [ "$(nvram get wl_auth)" = "1" ]; then
             AUTH=4
       else
             AUTH=1
       fi
       KEY=`nvram get wl_key$WEP_KEY`
       WEP_KEY1=`nvram get wl_key1`
       WEP_KEY2=`nvram get wl_key2`
       WEP_KEY3=`nvram get wl_key3`
       WEP_KEY4=`nvram get wl_key4`

     ;;
     3)#wpa
       ENC=4
       AUTH=2
       KEY="$(nvram get wl_wpa1_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
     ;;
     4)#wpa2
       ENC=8
       AUTH=32
       KEY="$(nvram get wl_wpa2_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
     ;;
     5)#wpa+wpa2
       #ENC=12 %%% for netgear requirement  %%% ---> tell the client it's wpa2
       #AUTH=34
       ENC=8
       AUTH=32
       KEY="$(nvram get wl_wpas_psk | sed -e 's/\\\\/\\/g' -e 's/\\`/`/g' -e 's/\\\"/\"/g')"
     ;;
     esac

     if [ "$ENC" = "2" ]; then
           echo "wep_transmit_key = $WEP_KEY" >> /var/wsc.conf
           echo "network_key = $KEY" >> /var/wsc.conf
           echo "wep_key2 = $WEP_KEY2" >> /var/wsc.conf
           echo "wep_key3 = $WEP_KEY3" >> /var/wsc.conf
           echo "wep_key4 = $WEP_KEY4" >> /var/wsc.conf
     else
           echo "network_key = $KEY" >> /var/wsc.conf
     fi
     
	 PRODUCT_NAME=$(nvram get product_id)
     echo "auth_type = $AUTH" >> /var/wsc.conf
     echo "encrypt_type = $ENC" >> /var/wsc.conf   
     echo "ssid = $SSID" >> /var/wsc.conf
     echo "pin_code = $PIN" >> /var/wsc.conf
     echo "rf_band = $RF" >> /var/wsc.conf
     echo "device_name = $DEVICE(Wireless AP)" >> /var/wsc.conf   
     echo "modelDescription = $PRODUCT_NAME Gateway" >> /var/wsc.conf   
     echo "model_name = $PRODUCT_NAME(Wireless AP)" >> /var/wsc.conf   
     echo "model_num = $PRODUCT_NAME" >> /var/wsc.conf
     echo "enable_atk = $ENABLE_ATK" >> /var/wsc.conf
     echo "Auth_Fail_Times = $WPS_ATK_TIMES" >> /var/wsc.conf    
     cat /var/wps/wscd.conf >> /var/wsc.conf
     

}

Wps()
{
     SEC=`nvram get wl_sectype`
     BC=`nvram get endis_ssid_broadcast`
     ACL=`nvram get wl_access_ctrl_on`
     if [ "$SEC" = "2" -o "$SEC" = "3" -o "$SEC" = "6" -o "$BC" = "0" -o "$ACL" = "1" ]; then
          WPS_ENABLED=0
     else
          WPS_ENABLED=1
     fi
    
     # update upnp advertise time
     upnp_AdverTime=`nvram get upnp_AdverTime`
     old_pattern="`grep max_age /tmp/wscd_config`"
     new_pattern="max_age $upnp_AdverTime"
     /bin/sed -i s/"$old_pattern"/"$new_pattern"/g /tmp/wscd_config
 
     #if [ "$1" = "start" -a "$(nvram get wds_endis_fun)" = "0" -a "$WEP_SHARED" = "0" ]; then
     if [ "$1" = "start" -a "$(nvram get wds_endis_fun)" = "0" -a "$WPS_ENABLED" = "1" ]; then
           echo "wps start"
           if [ "$(nvram get endis_wl_wps)" = "0" ]; then
               nvram set endis_wl_wps=1
           fi
           
           Update_conf
	   wscd -start -c /var/wsc.conf -w $WLAN_IF -fi /var/wscd-$WLAN_IF.fifo -daemon

	   WAIT=1
	   while [ $WAIT != 0 ]		
	   do	
	       if [ -e /var/wscd-$WLAN_IF.fifo ]; then
	           WAIT=0
	       else
	           sleep 1
	       fi
	   done
     
     elif [ "$1" = "stop" ]; then
           echo "wps stop"
           #rm -rf /var/wps
           Kill_proc "/var/run/wscd-$WLAN_IF.pid"
           
     else
           if [ "$(nvram get endis_wl_wps)" = "1" ]; then
               nvram set endis_wl_wps=0
           fi    
     fi

}

IF_Handle()
{
    if [ "$1" = "start" ]; then
          echo "IF_handle start...."
          
          brctl addif $BR $WLAN_IF 2> /dev/null
          ifconfig $WLAN_IF up  
                             
          #echo "wds interface...."          
          WDS_num=`iwpriv $WLAN_IF get_mib wds_num | cut -b 28`
          num=0
          while [ $num -lt $WDS_num ]
          do
                  brctl addif $BR $WLAN_IF-wds$num 2> /dev/null
                  ifconfig $WLAN_IF-wds$num 0.0.0.0
                  num=$(($num+1))
          done 
                   
          #### MBSSID #### (2,3,4,5)
          #echo "guest interface...."
          
          WDS=`nvram get wds_endis_fun`
          if [ "$CLI_ASSO" = "1" -a "$WDS" = "1" ]; then ## WDS only
               echo "Pure wds. No guest."
          
          else
               num=1
               ac_num=0
               while [ $num -le $MSSID_num ]
               do                 
                   if [ "$(nvram get wlg"$num"_endis_guestNet)" = "1" ]; then
                       echo "initializing $WLAN_VA_IF$ac_num" 
                       sleep 1
                       brctl addif $BR $WLAN_VA_IF$ac_num 2> /dev/null
                       ifconfig $WLAN_VA_IF$ac_num 0.0.0.0
		       
		       echo "checking security type .... "
		       SEC_M=`nvram get wl_sectype`
		       SEC_G=`nvram get wlg"$num"_sectype`
		       WLANIF=$WLAN_VA_IF"$ac_num"							
		       if [ "$SEC_M" = "6" ]; then
			 if [ "$SEC_G" = "1" -o "$SEC_G" = "2" ]; then
				ifconfig $WLAN_VA_IF$ac_num 0.0.0.0
				ifconfig $WLAN_VA_IF$ac_num down
				ifconfig $WLAN_VA_IF$ac_num up
			 fi
		       fi

                       ac_num=$(($ac_num+1))                     
                   fi
               num=$(($num+1))
               done    

               #ac_num=0
               #if [ "$(nvram get wlg1_endis_guestNet)" = "1" ]; then
               #    echo "initializing $WLAN_VA_IF$ac_num" 
               #    sleep 1
               #    brctl addif $BR $WLAN_VA_IF$ac_num 2> /dev/null
               #    ifconfig $WLAN_VA_IF$ac_num 0.0.0.0
               #fi             
          fi  
         
          
    else    
          echo "IF_handle stop...."
          ifconfig $WLAN_IF down
                           
          num=0
          while [ $num -lt 4 ]
          do
                  ifconfig $WLAN_IF-wds$num down
                  brctl delif $BR $WLAN_IF-wds$num 2> /dev/null
                  num=$(($num+1))                  
          done
          
          #### MBSSID #### (2,3,4,5)
          num=0
          while [ $num -lt $MSSID_num ]
          do
                  ifconfig $WLAN_VA_IF$num down
                  brctl delif $BR $WLAN_VA_IF$num 2> /dev/null                   
    
          num=$(($num+1))
          done   
          
          brctl delif $BR $WAN_IF 2> /dev/null
          brctl delif $BR $WLAN_IF 2> /dev/null
    fi
}

# For HW Push Button used only
wps_hw_pbc()
{
	# Cancel previous WPS action, then start it again!!

        if [ "`nvram get wl_sectype`" = "1" ]; then
            echo 1002 > /proc/gpio
        else
            echo 1001 > /proc/gpio
        fi 
#	echo 1002 > /proc/gpio		# turn off WPS LED

	echo 1 > /tmp/wscd_cancel
	sleep 1

	#rm -f /tmp/wps_client
	echo start > /tmp/wps_client
	rm -f /tmp/reinit_wscd
	rm -f /tmp/wscd_byebye
	rm -f /tmp/wscd_status
	wscd -sig_pbc $WLAN_IF
	echo 1004:120:500 > /proc/gpio	# blink WPS LED for 2 minutes
}

# check WPS LED status
chk_wps_led()
{
	echo Check WPS LED status
	
        if [ "`nvram get wl_sectype`" = "1" ]; then
            echo 1002 > /proc/gpio
        else
            echo 1001 > /proc/gpio
        fi 
}

main()
{
   if [ "$1" = "start" ]; then
          
          RADIO=`nvram get endis_wl_radio`
          wlan_force_start=`nvram get wlan_force_start`
          nvram unset wlan_force_start

          if [ -f /tmp/in_stop_sche -a "$wlan_force_start" != "1" ]; then
             
              echo "It's in wireless radio down time(wlan_rtl.sh)"
              logger "[type9][Wireless signal schedule] The wireless signal is OFF,"
              if [ "$(nvram get endis_wl_wps)" = "1" ]; then
                  nvram set endis_wl_wps=0
              fi  
              rm /tmp/in_stop_sche
              exit
                 
          elif [ "$RADIO" = "1" ]; then 
                 
                 Acl
                 Basic_settings
                 Adv_settings
                 Security         
                 Wds start
                 MSSID_settings
                 #guestNet_settings
                 Security_MSSID
                 #Security_guestNet
                 IF_Handle start
                 #Guest_access	# instead of guest_access mib
                 Wps start
                 echo $sys_uptime > /tmp/WLAN_uptime
                 Applications start

		 # IPTV
		 iptv_conf
		
                 # NETGEAR SPEC: stay on WLAN LED
                 echo 1101 > /proc/gpio

                 # WPS LED
                 #if [ "`nvram get wds_endis_fun`" = "1" -o "`nvram get endis_wl_wps`" = "0" ]; then
                     if [ "`nvram get wl_sectype`" = "1" ]; then
                         echo 1002 > /proc/gpio
                     else
                         echo 1001 > /proc/gpio
                     fi 
                 #fi
                 
          else
                 echo "Wireless is disabled"
                 echo 1102 > /proc/gpio		# turn-off WLAN LED
                 echo 1002 > /proc/gpio		# turn-off WPS LED
                 if [ "$(nvram get endis_wl_wps)" = "1" ]; then
                     nvram set endis_wl_wps=0
                 fi

		num=0
		while [ $num -lt $MSSID_num ]
		do
			if [ "$(nvram get wlg"$(($num+1))"_endis_guestNet)" = "0" ]; then
				ifconfig $WLAN_VA_IF"$num" down
			fi
			num=$(($num+1))
		done

                # if [ "$(nvram get wlg1_endis_guestNet)" = "0" ]; then
                #     ifconfig $WLAN_VA_IF down
                # fi
                 if [ "$(nvram get endis_wl_radio)" = "0" ]; then
                     ifconfig $WLAN_IF down
                 fi
                 exit    
          fi
                
   else
          echo "Wireless is disabled"
          echo 1102 > /proc/gpio		# turn-off WLAN LED
          echo 1002 > /proc/gpio		# turn-off WPS LED
          if [ "$(nvram get endis_wl_wps)" = "1" ]; then
              nvram set endis_wl_wps=0
          fi
          IF_Handle stop 
          Applications stop
          Wds stop
          Wps stop
                     
   fi

}

case "$1" in 

       start)
            main start
            ;;  
       stop)
            main stop       
            ;;
       restart)
            main stop
            main start    
            ;;
       sche_stop)
            main stop
            if [ "$(nvram get endis_wl_wps)" = "1" ]; then
                nvram set endis_wl_wps=0
            fi     
            nvram set sche_radio_onoff=0  
            logger "[type9][Wireless signal schedule] The wireless signal is OFF,"
            ;;
       sche_start)
            main start
            nvram set sche_radio_onoff=1       
            logger "[type9][Wireless signal schedule] The wireless signal is ON,"
            ;;
       wlan_hw_stop)
            main stop
            if [ "$(nvram get endis_wl_wps)" = "1" ]; then
                nvram set endis_wl_wps=0
            fi     
            ;;
       wlan_hw_start)
            main start
            ;;
       wps_pbc)
            wps_hw_pbc
            ;;
#       wsc)
#            nvram set wps_status=5
#            if [ "$(nvram get wl_sectype)" = 2 -o "$(nvram get wl_sectype)" = 3 ]; then
#                nvram set wl_mode=1
#            fi
#            nvram commit
#            echo 1 > /tmp/reinitwscd
#            sleep 1
#            nvram set action=99
#            ;;
	wsc)
	   config_wsc
	   ;;
	acl)
	   Acl
	   ;;
	chk_wps_led)
	   chk_wps_led
	   ;;
esac            
            
             
