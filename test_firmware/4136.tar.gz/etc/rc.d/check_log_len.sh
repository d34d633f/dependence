#!/bin/sh

LOG_FILE=/var/log/messages
REC_FILE=/var/log/mesg

MAX_LOG_LENGTH=`nvram get max_log_length`

length=$(wc -l $LOG_FILE | awk '{ print $1 }')
if [ "$length" -gt $MAX_LOG_LENGTH ]; then
	start_len=$((length - $MAX_LOG_LENGTH))
	sed -i "1,$start_len d" $LOG_FILE
	sed -i "1,$start_len d" $REC_FILE
fi
