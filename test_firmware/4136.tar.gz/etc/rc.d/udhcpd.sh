#!/bin/sh

RETVAL=0

iface=$2

prog="udhcpd"
PID_FILE="/var/run/udhcpd${iface}.pid"
CONFIG_FILE="/var/udhcpd${iface}.conf"
LEASES_FILE="/tmp/udhcpd${iface}.leases"

wan_phy_mode=`nvram get wan_phy_mode`



lan_ifname=`nvram get lan${iface}_ifname`
lan_proto=`nvram get lan${iface}_proto`
dhcp_start=`nvram get dhcp${iface}_start`
dhcp_end=`nvram get dhcp${iface}_end`
subnet=`nvram get lan${iface}_netmask`
lan_ipaddr=`nvram get lan${iface}_ipaddr`
domain=`nvram get wan_domain`
leasetime=`nvram get dhcp_lease`
dhcp_route=`nvram get dhcp_route`
dhcp_dns=`nvram get dhcp_dns`
wds_enable=`nvram get wds_endis_fun`
wds_mode=`nvram get wds_repeater_basic`

manual_ip() {
        num=1
        if [ "$wan_phy_mode" != "adsl" ]; then   
	    entry=`nvram get reservation$num`
        else
            entry=`nvram get lan${iface}_reservation$num`
        fi
	while [ "$entry" != "" ];
        do
		ip=`echo $entry | awk -F" " '{print $1}'`
		mac=`echo $entry | awk -F" " '{print $2}'`
		echo "static_lease $mac $ip" >> $CONFIG_FILE
		num=$(($num+1))

                if [ "$wan_phy_mode" != "adsl" ]; then   
		    entry=`nvram get reservation$num`
                else
                    entry=`nvram get lan${iface}_reservation$num`
                fi
        done
}

start() {
	[ -e ${PID_FILE} ] && exit 0

	# Start daemons.
        if [ "$wan_phy_mode" != "adsl" ]; then    
	    echo $"Starting $prog: "
        fi
	echo "start		$dhcp_start" > $CONFIG_FILE
	echo "end		$dhcp_end" >> $CONFIG_FILE
	echo "interface		$lan_ifname" >> $CONFIG_FILE
	echo "remaining		yes" >> $CONFIG_FILE
	#echo "lease_file	/tmp/udhcpd.leases" >> $CONFIG_FILE
	echo "lease_file	$LEASES_FILE" >> $CONFIG_FILE
	echo "pidfile		$PID_FILE" >> $CONFIG_FILE
	echo "option	subnet	$subnet" >> $CONFIG_FILE
        if [ "$dhcp_route" = "" ]; then
            echo "option	router	$lan_ipaddr" >> $CONFIG_FILE
        else
            echo "option	router	$dhcp_route" >> $CONFIG_FILE
        fi
        if [ "$dhcp_dns" = "" ]; then
            echo "option	dns	$lan_ipaddr" >> $CONFIG_FILE
        else
            echo "option	dns	$dhcp_dns" >> $CONFIG_FILE
        fi
	if [ "$domain" != "" ]; then	
		echo "option	domain	$domain" >> $CONFIG_FILE
	fi
	if [ "$leasetime" = "0" ]; then		#lease time = forever
		echo "option	lease	0xFFFFFFFF" >> $CONFIG_FILE	
	else	
		echo "option	lease	$(($leasetime*1800))" >> $CONFIG_FILE	#half hours to seconds	
	fi
	
	manual_ip
	
	if [ "$lan_proto" = "dhcp" ]; then
		${prog} ${CONFIG_FILE} &
	fi
	RETVAL=$?
	return $RETVAL
}

stop() {
	# Stop daemons.
        if [ "$wan_phy_mode" != "adsl" ]; then    
	    echo $"Shutting down $prog: "
        fi
	if [ -e ${PID_FILE} ]; then
		kill -9 `cat ${PID_FILE}`
	fi
	rm -f ${PID_FILE}

	RETVAL=$?
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
  if [ "$wds_enable" = "1" -a "$wds_mode" = "0" ]; then
  	echo "wds in repeater mode, no dhcpd on"
  else
  	start
  fi
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

