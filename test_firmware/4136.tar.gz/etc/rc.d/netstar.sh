#!/bin/sh

RETVAL=0
RUNENV=/usr/sbin/
NETSTAR=${RUNENV}netstar
NVRAM=${RUNENV}nvram
IPTABLES=${RUNENV}iptables
BLOCK_SITE=fwd_block_site

ipqueue_rule()
{
	lan_ipaddr=`${NVRAM} get lan_ipaddr`
	lan_ifname=`${NVRAM} get lan_ifname`
	if [ "$1" = "A" -o  "`nvram get bs_url_filter_enabled`" = "1" ];then
	echo 0 > /proc/sys/net/ipv4/netfilter/ip_conntrack_tcp_forward_accept
	echo 1 > /proc/sys/net/ipv4/netfilter/ip_conntrack_skip_fast_path_for_httpget
	else
	echo 1 > /proc/sys/net/ipv4/netfilter/ip_conntrack_tcp_forward_accept
	echo 0 > /proc/sys/net/ipv4/netfilter/ip_conntrack_skip_fast_path_for_httpget
	fi
	${IPTABLES} -I ${BLOCK_SITE} 1 -m urlstring --string "IO-DATA" --get-only 1 -j RETURN 
	${IPTABLES} -${1} ${BLOCK_SITE} -i ${lan_ifname} -p tcp -j QUEUE

}

start() {
	# Start daemons.
	if [ "`${NVRAM} get netstar_enabled`" =  "1" ];then
		ipqueue_rule A;
		${NETSTAR}
		echo $"Starting $prog: "
	fi
	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting down $prog: "
	ipqueue_rule D;
	killall -9 netstar
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  ipq)
  	ipqueue_rule $2
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

