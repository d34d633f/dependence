#!/bin/sh

IFACE=""
IFACE=$2
WAN_PHY_MODE=`nvram get wan_phy_mode`
if [ "$WAN_PHY_MODE" = "adsl" ]; then
#    if [ "$IFACE" = "`nvram get wan_default_iface`" ]; then
        DEFAULT_GW=1
#    fi
else
    DEFAULT_GW=1
fi

if [ "${DEFAULT_GW}" = "1" ]; then
	WAN_DEFAULT_IPADDR=`nvram get wan0_ipaddr`
fi

RELAY_TYPE=`nvram get ipv6_6to4_relay_type`
PARTS=`echo $WAN_DEFAULT_IPADDR | tr . ' '`
PREFIX48=`printf "2002:%02x%02x:%02x%02x" $PARTS`
RELAY_VIA_IP=::192.88.99.1
#LAN_IF_NAME=`nvram get lan_ifname`
TUNNEL_IF_NAME=`nvram get ipv6_if_name`
#LAN_HW_ADDR=`nvram get lan_hwaddr`
#FIRST_SET=`expr substr "$LAN_HW_ADDR" 1 2`
#FIRST_SET=$((FIRST_SET^2))
#TMP_LAN_ADDR=`echo $LAN_HW_ADDR | awk -F: '{printf '$FIRST_SET'$2":"$3"ff:fe"$4":"$5$6}'`
#TMP_LAN_ADDR="$STF_NET6$TMP_LAN_ADDR"
#MODULE_PATH="/lib/modules/2.6.30"
VLAN_ENABLE=`nvram get vlan_enable`

start() {
	echo "Start 6to4 Tunnel ..."
	if [ -n "$WAN_DEFAULT_IPADDR" ];then
		#insmod $MODULE_PATH/sit.ko
		if [ "$RELAY_TYPE" = "1" ];then
			STATIC_RELAY_IP=`nvram get ipv6_6to4_relay`
			RELAY_VIA_IP=::$STATIC_RELAY_IP
		fi
		ip tunnel add $TUNNEL_IF_NAME mode sit remote any local $WAN_DEFAULT_IPADDR
		ip link set dev $TUNNEL_IF_NAME up
		ip -6 addr add $PREFIX48::1/16 dev $TUNNEL_IF_NAME
		if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
			LAN_IF_NUM="1 2 3 4"
			for i in $LAN_IF_NUM;
			do
			 	STF_NET6="$PREFIX48":$i:
				LAN_IF_NAME=`nvram get lan${i}_ifname`
				LAN_IP6_ADDR=`ifconfig $LAN_IF_NAME | grep Scope:Link | awk '{printf $3}' | awk -F/ '{printf $1}'`
				TMP_LAN_ADDR=`echo $LAN_IP6_ADDR | awk -F:: '{printf $2}'`
				TMP_LAN_ADDR="$STF_NET6$TMP_LAN_ADDR"
				ip -6 addr add $TMP_LAN_ADDR/64 dev $LAN_IF_NAME
			done
		else
			STF_NET6="$PREFIX48":1:
			LAN_IF_NAME=`nvram get lan_ifname`
			LAN_IP6_ADDR=`ifconfig $LAN_IF_NAME | grep Scope:Link | awk '{printf $3}' | awk -F/ '{printf $1}'`
			TMP_LAN_ADDR=`echo $LAN_IP6_ADDR | awk -F:: '{printf $2}'`
			TMP_LAN_ADDR="$STF_NET6$TMP_LAN_ADDR"
			ip -6 addr add $TMP_LAN_ADDR/64 dev $LAN_IF_NAME
		fi
		ip -6 route add ::/0 via $RELAY_VIA_IP dev $TUNNEL_IF_NAME metric 1
	fi

	RETVAL=$?
    return $RETVAL
}

stop() {

	echo "Stop 6to4 Tunnel ..."
	ip link set dev sit1 down 
	rmmod sit

	RETVAL=$?
	return $RETVAL
}


# See how we were called.
case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart|reload)
    stop
    start
    RETVAL=$?
    ;;
  *)
    echo $"Usage: $0 {start|stop|restart}"
    exit 1
esac

exit $RETVAL
