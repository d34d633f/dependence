#!/bin/sh
START=70
OUT="/tmp/cmd_output"

RETVAL=0

flush_output()
{
    echo "" > "$OUT"
}
remove_output()
{
    rm -f "$OUT"
}
SED="/bin/sed"

usb0Mode="1"
usb1Mode="1"

start() {

	if [ $usb0Mode -eq 1 -o $usb1Mode -eq 1 ]; then
		if [ -f /lib/modules/*/ifxusb_host.ko ]; then
			[ $usb0Mode -eq 1 ] && echo -n "USB0: " || echo -n "USB1: "; echo "Loading USB Host mode driver"
			insmod /lib/modules/*/ifxusb_host.ko
		fi
	fi

#flush_output
#ifconfig eth0 > "$OUT"
#MAC_ADDR_BASE=`"$SED" -n 's,^.*HWaddr,,;1p' "$OUT"`
#USB_MAC_ADDR=`echo $MAC_ADDR_BASE|/usr/sbin/next_macaddr -7`
#
#	if [ $usb0Mode -eq 2 -o $usb1Mode -eq 2 ]; then
#		if [ -f /lib/modules/*/ifxusb_gadget.ko ] && [ -f /lib/modules/*/g_ether.ko ]; then
#			[ $usb0Mode -eq 2 ] && echo -n "USB0: " || echo -n "USB1: "; echo "Loading USB Device mode driver"
#			/sbin/insmod /lib/modules/*/ifxusb_gadget.ko
#			board_mac=`/usr/sbin/upgrade mac_get 0`
#			/sbin/insmod /lib/modules/*/g_ether.ko dev_addr="$USB_MAC_ADDR"
#			/usr/sbin/brctl addif $lan_main_0_interface usb0
#			/sbin/ifconfig usb0 0.0.0.0 up
#		fi
#	fi
#remove_output
}

stop() {

	echo "remove ifxusb_host"
	rmmod ifxusb_host

}

# See how we were called.
case "$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  restart|reload)
        stop
        start
        RETVAL=$?
        ;;
  *)
        echo $"Usage: $0 {start|stop|restart}"
        exit 1
esac

exit $RETVAL

