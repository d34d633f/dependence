#!/bin/sh


echo 0 > /tmp/detec_uprate


     traceroute -m 5 -w 2 www.netgear.com > /tmp/tmp_trace
          

     
     ######################## next hop behind gateway #################
     k=1
     dst_hop=2
     while [ "$k" -le "5" ]; 
     do
         tmp_sta=`cat /tmp/tmp_trace | sed -n $k"p" | cut -d "(" -f 2 | cut -d ")" -f 1`
         if [ "$tmp_sta" = "$(nvram get wan0_gateway)" ]; then
               dst_hop=$(($k+1))
               
         fi
         k=$(($k+1))
     done
     #########################
     echo "dst_hop=$dst_hop"
     DST=`cat /tmp/tmp_trace | sed -n $dst_hop"p" | cut -d "(" -f 2 | cut -d ")" -f 1`
     
     if [ "x$DST" = "x" ]; then
        echo 0 > /tmp/detec_uprate
        exit 
     fi
     pingdet -c 20 -s 1400 $DST > /tmp/tmp_ping
     C=0
     LAST_SEQ=0
     while [ "$C" -le "19" ]
     do
           TMP_TOTAL=`cat /tmp/tmp_ping  | grep "seq=$C" | cut -d "=" -f 4 | cut -d " " -f 1`
           if [ "$TMP_TOTAL" != "" ]; then
           
                  TOTAL=$TMP_TOTAL
                  LAST_SEQ=$C
           
           fi
     
           C=$(($C+1))
     done
     
     
     
     echo "Total time = $TOTAL, last_seq = $LAST_SEQ"
        
     TOTAL_I=`echo $TOTAL | cut -d "." -f 1`
     LAST_SEQ=$(($LAST_SEQ+1))  
     #11200=1400(byte)x8  -->bit

     AVG_BW=$((22400*$LAST_SEQ/$TOTAL_I))  
     
     echo "$AVG_BW" > /tmp/detec_uprate
