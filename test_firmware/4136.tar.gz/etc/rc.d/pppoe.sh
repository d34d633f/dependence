#!/bin/sh

#[ -f /usr/local/sbin/pppd ] || exit 0

RETVAL=0

ETH_WAN_INDEX=`nvram get eth_wan_iface`
wan_phy_auto=`nvram get wan_phy_auto`
wan_default_iface=`nvram get wan_default_iface`
wan_phy_mode=`nvram get wan_phy_mode`
if [ "$wan_phy_mode" = "adsl" ]; then
    MULTI_WAN=1    
fi

if [ "$MULTI_WAN" = "1" ]; then
    iface=$2
    manual=$3
    if [ "$iface" = "$wan_default_iface" ] || [ "$iface" = "$ETH_WAN_INDEX" ]; then
        DEFAULT_GW=1
    fi
else
    iface=""  
    manual=$2       
    DEFAULT_GW=1
fi


prog="pppd"
CALL_FILE="provider_pppoe_1492"
IP_UP="/etc/ppp/ip-up"
IP_DOWN="/etc/ppp/ip-down"
PLUG_IN="plugin rp-pppoe.so"
WAN_INFO=/tmp/wan/wan${iface}

fw_region=`cat /firmware_region`
module_name=`cat /module_name`

if [ "$MULTI_WAN" = "1" ];  then
    PID_FILE="/var/run/ppp${iface}.pid"    
else 
    PID_FILE="/var/run/pppd.pid"
fi

wan_ifname=`nvram get wan${iface}_hwifname`

if [ "$fw_region" != "GR" ]; then
    user=`nvram get wan${iface}_pppoe_username`
else 
    isp_type=`nvram get wan${iface}_pppoe_isp_type`
    if [ "$isp_type" = "0" ]; then  # T-online
        isp_id=`nvram get wan${iface}_pppoe_con_id`
        isp_num=`nvram get wan${iface}_pppoe_online_num` 
        isp_suffix=`nvram get wan${iface}_pppoe_co_suffix`
        user="${isp_id}${isp_num}${isp_suffix}@t-online.de"
    elif [ "$isp_type" = "1" ]; then  #1&1
        isp_name=`nvram get wan${iface}_pppoe_1and1_username`            
        user="1und1/${isp_name}@online.de"
    else   # other
        user=`nvram get wan${iface}_pppoe_username`
    fi
fi
password=`nvram get wan${iface}_pppoe_passwd`
mru=`nvram get wan${iface}_pppoe_mtu`
mtu=`nvram get wan${iface}_pppoe_mtu`
idle=`nvram get wan${iface}_pppoe_idletime`
demand=`nvram get wan${iface}_pppoe_demand`
dns_assign=`nvram get wan${iface}_pppoe_dns_assign`
keepalive_time=`nvram get wan_pppoe_keepalive_time`
service_name=`nvram get wan${iface}_pppoe_service`
pppoe_netmask=`nvram get wan${iface}_pppoe_netmask`
PPPOE_INTRANET_ASSIGN=`nvram get wan${iface}_pppoe_intranet_wan_assign`
PPPOE_MY_IP=`nvram get wan${iface}_pppoe_intranet_ip`
PPPOE_NETMASK=`nvram get wan${iface}_pppoe_intranet_mask`
pppoe_intranet_wan_assign=`nvram get wan${iface}_pppoe_intranet_wan_assign`

if [ "$fw_region" = "RU" ] && [ "$module_name" = "DEGN1000v3" ]; then
        RUSSIA_PPPOE=1
fi

if [ "$pppoe_netmask" = "" ]; then
	pppoe_netmask="0.0.0.0"
fi

wan_default_iface=`nvram get wan_default_iface`

if [ "$MULTI_WAN" = "1" ];  then
        iface_num="iface_num ${iface} unit ${iface}"
else
        iface_num="unit 0"
fi

if [ "$DEFAULT_GW" = "1" ];  then
        defaultroute="defaultroute"
        if [ "$MULTI_WAN" = "1" ];  then
            if [ "$wan_phy_auto" = "1" ] && [ "$iface" = "$wan_default_iface" ]; then
                    if [ "$demand" = "1" ]; then                             
                            ip route del default table 20${iface}
                    fi
            fi
        fi
else
        defaultroute=""
fi

if [ "$demand" = "0" ]; then ## Always ON ##
	persist_demand="persist"
	keep_alive=$keepalive_time
	lcp_echo_fails="3";
	idle="0"
elif [ "$demand" = "1" ]; then ## Dial on Demand ##
	if [ "$idle" = "0" ]; then
		persist_demand="persist"
	   	keep_alive="0";
   		lcp_echo_fails="0";
	else
		persist_demand="demand"
    	        keep_alive=$keepalive_time
	   	lcp_echo_fails="3";
		echo 1 > /proc/sys/net/ipv4/ip_forward
	fi       
else
	persist_demand="persist"	# for maual trigger 
	idle="0"
   	keep_alive="0";
   	lcp_echo_fails="0";
fi

if [ "$dns_assign" = "0" ]; then
	usepeerdns="usepeerdns"
else
	usepeerdns=""
fi

if [ "$mtu" = "0" ]; then
	mru="1492";
        mtu="1492";
fi

if [ "$(nvram get wan${iface}_pppoe_wan_assign)" = "1" ]; then
	if [ "$pppoe_netmask" = "0.0.0.0" ];then
		pppoe_ip="$(nvram get wan${iface}_pppoe_ip):0.0.0.0"
	else
		pppoe_ip=""
		dyn_wan_ip=`nvram get wan${iface}_pppoe_ip`
	fi
else
	pppoe_ip=""
fi


start() {
	# Start daemons.
	echo $"Starting pppoe${iface}:"        
	nvram set ppp_active=1
        echo "pppoe" > ${WAN_INFO}

        if [ "$MULTI_WAN" = "1" ];  then
                if [ "$DEFAULT_GW" = "1" ];  then
                    nvram set wan_hwifname=$wan_ifname
                fi
        fi        

	ifconfig ${wan_ifname} 0.0.0.0 up

	if [ "$manual" != "manual" ] && [ "$manual" != "manually" ]; then
		if [ "$demand" = "2" ]; then
			echo "Run Manual Connect...."
			RETVAL=$?
			return $RETVAL
		fi
	fi 

        if [ "$manual" = "manual" ] || [ "$manual" = "manually" ]; then
                demandex="demandex"
	fi		
	
	#do dial-on-demand and bring link up when starting
	if [ "`nvram get demandex`" = "1" ]; then
		nvram unset demandex	
		demandex="demandex"
	fi

	if [ "$RUSSIA_PPPOE" = "1" ]; then
                if [ "$pppoe_intranet_wan_assign" = "1" ]; then
                        echo "pppoe:1" > ${WAN_INFO}
                        wan_hwifname=`nvram get wan${iface}_hwifname`
                	    echo "ifconfig $wan_hwifname $PPPOE_MY_IP netmask $PPPOE_NETMASK up"
                	    ifconfig $wan_hwifname $PPPOE_MY_IP netmask $PPPOE_NETMASK up
                        if [ "$MULTI_WAN" = "1" ]; then
                                /etc/rc.d/do_nat.sh start ${iface} static
                        else        		
                		        iptables -t nat -D POSTROUTING -o $wan_hwifname -j SNATP2P --to-source $PPPOE_MY_IP > /dev/null 2>&1
                		        iptables -t nat -A POSTROUTING -o $wan_hwifname -j SNATP2P --to-source $PPPOE_MY_IP
                		        echo 1 > /proc/sys/net/ipv4/ip_forward 
                        fi
                elif [ "$pppoe_intranet_wan_assign" = "0" ]; then
                        echo "pppoe:0" > ${WAN_INFO}
                fi
	fi

        if [ "$pppoe_ip" = "" ]; then   
        	noipdefault="noipdefault"
        else
	        noipdefault=""
        fi			

        if [ "$service_name" = "" ]; then
                echo "${prog} maxfail -1 ${PLUG_IN} ${wan_ifname} ${pppoe_ip} user ${user} password \"${password}\" mru ${mru} mtu ${mtu} ${persist_demand} ${demandex} idle ${idle} $usepeerdns $defaultroute lcp-echo-failure ${lcp_echo_fails} lcp-echo-interval ${keep_alive} ${noipdefault} ${iface_num}"
                ${prog} maxfail -1 ${PLUG_IN} ${wan_ifname} ${pppoe_ip} user "${user}" password "${password}" mru ${mru} mtu ${mtu} ${persist_demand} ${demandex} idle ${idle} $usepeerdns ${defaultroute} lcp-echo-failure ${lcp_echo_fails} lcp-echo-interval ${keep_alive} ${noipdefault}  ${iface_num}
        else       
                echo "${prog} maxfail -1 ${PLUG_IN} rp_pppoe_service "${service_name}" ${wan_ifname} ${pppoe_ip} user ${user} password \"${password}\" mru ${mru} mtu ${mtu} ${persist_demand} ${demandex} idle ${idle} $usepeerdns $defaultroute lcp-echo-failure ${lcp_echo_fails} lcp-echo-interval ${keep_alive} ${noipdefault} ${iface_num}"
                ${prog} maxfail -1 ${PLUG_IN} rp_pppoe_service "${service_name}" ${wan_ifname} ${pppoe_ip} user "${user}" password "${password}" mru ${mru} mtu ${mtu} ${persist_demand} ${demandex} idle ${idle} $usepeerdns ${defaultroute} lcp-echo-failure ${lcp_echo_fails} lcp-echo-interval ${keep_alive} ${noipdefault} ${iface_num} 
        fi

	RETVAL=$?
	echo
 
	return $RETVAL
}

stop() {
	# Stop daemons.
	    echo $"Shutting down pppoe${iface}:"
		nvram set ppp_active=0

        if [ "$RUSSIA_PPPOE" = "1" ]; then              
                WAN_INFO="/tmp/wan/wan${iface}"
                st_pppoe=`cat ${WAN_INFO} | cut -d ":" -f2`
                if [ "$st_pppoe" = "1" ]; then
        		    wan_hwifname=`nvram get wan${iface}_hwifname`
        		    ifconfig $wan_hwifname 0.0.0.0
                    if [ "$MULTI_WAN" = "1" ]; then
                            /etc/rc.d/do_nat.sh stop ${iface} static
                    else
        		            iptables -t nat -D POSTROUTING -o $wan_hwifname -j SNATP2P --to-source $dyn_wan_ip > /dev/null 2>&1
                    fi
                fi
	    fi        

        if [ -e ${PID_FILE} ]; then
              PID=`cat ${PID_FILE}`
        fi
        
        if [ "$MULTI_WAN" = "1" ]; then
            ppp_item=0
            for item in `ls /var/run/ | grep ppp | grep -v pppd | grep -v ppp${iface}`
            do
                    ppp_item=$(($ppp_item+1))
            done        
        fi

        if [ "$PID" != "" ]; then
                kill -1 ${PID}  # call ip-dowm script
	        sleep 2
   	    	kill -9 ${PID}
	fi

        if [ -e ${PID_FILE} ]; then
		rm -f ${PID_FILE}
	fi

        if [ -f /var/run/pppd.pid ] && [ "$ppp_item" = "0" ]; then
                rm /var/run/pppd.pid
        fi

	ETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

