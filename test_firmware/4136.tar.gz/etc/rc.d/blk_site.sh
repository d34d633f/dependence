#!/bin/sh

IPTABLES="iptables"

blk_sites_enabled=`nvram get block_skeyword`
#blk_sites_item variable is splited by space character, if any problem, we need handle this variable...
#blk_sites_item=`nvram get block_KeyWord_DomainList`

# block trusted ip
blk_trusted_ip_enable=`nvram get block_endis_Trusted_IP`
blk_trusted_ip=`nvram get block_trustedip`
BLOCK_SITE=fwd_block_site
BLOCK_SITE_NNTP=fwd_block_site_nntp

wan_phy_mode=`nvram get wan_phy_mode`
if [ "$wan_phy_mode" != "adsl" ]; then
    LAN_IF=`nvram get lan_ifname`
else
    LAN_IF="br+"
fi

start() 
{
	echo "run blk_site.sh start !!!"
	[ "`nvram get block_KeyWord_DomainList`" = "" ] && exit 0

	nvram set blk_site_on=1
	#echo 0 > /proc/sys/net/ipv4/ct_fast_forward	#2:Block Sites doesn't work
	#echo 20 > /proc/sys/net/netfilter/ppa_threshold

        echo 0 > /proc/sys/net/ipv4/netfilter/ip_conntrack_tcp_forward_accept   #2:Block Sites doesn't work
        echo 1 > /proc/sys/net/ipv4/netfilter/ip_conntrack_skip_fast_path_for_httpget

# if $blk_sites_enabled=2, blk_sites service always running
	"$IPTABLES" -I $BLOCK_SITE 1 -m urlstring --string "NETGEAR" --get-only 1 -j RETURN
	"$IPTABLES" -I $BLOCK_SITE_NNTP 1 -m urlstring --string "NETGEAR" --get-only 1 -j RETURN

   if [ "$blk_sites_enabled" -gt "0" ] && [ "$blk_trusted_ip_enable" -eq "1" ]; then
      for blk_str in `nvram get block_KeyWord_DomainList`;
      do
         "$IPTABLES" -A $BLOCK_SITE_NNTP ! -s "$blk_trusted_ip" -m urlstring --string "$blk_str" -j ACCEPT
         #"$IPTABLES" -A $BLOCK_SITE ! -s "$blk_trusted_ip" -m string --string "$blk_str" \
	#-j REJECT --reject-with netgear-firewall-blocking-page
        "$IPTABLES" -A $BLOCK_SITE -i $LAN_IF -m urlstring --string "$blk_str" --trusted-ip "$blk_trusted_ip" \
	-j REJECT --reject-with firewall-blocking-page
      done
   else
      for blk_str in `nvram get block_KeyWord_DomainList`;
      do
         "$IPTABLES" -A $BLOCK_SITE_NNTP -m urlstring --string "$blk_str" -j ACCEPT
         "$IPTABLES" -A $BLOCK_SITE -m urlstring --string "$blk_str" -j REJECT --reject-with firewall-blocking-page
      done
   fi
   "$IPTABLES" -A $BLOCK_SITE_NNTP -m urlstring --string "NETGEAR" --allow-flag 1 -j RETURN
   "$IPTABLES" -A $BLOCK_SITE -m urlstring --string "NETGEAR" --allow-flag 1 -j RETURN
}

stop()
{
	echo "run blk_site.sh stop !!!"
	
	nvram set blk_site_on=0
	#echo 10 > /proc/sys/net/netfilter/ppa_threshold
	#[ "`nvram get blk_svc_on`" = "0" ] && echo 1 > /proc/sys/net/ipv4/ct_fast_forward	#2:Block Sites doesn't work

	[ "`nvram get blockserv_ctrl`" = "0" ] && echo 1 > /proc/sys/net/ipv4/netfilter/ip_conntrack_tcp_forward_accept #2:Bl    ock Sites doesn't work
	echo 0 > /proc/sys/net/ipv4/netfilter/ip_conntrack_skip_fast_path_for_httpget


	#[ "$blk_sites_enabled" = "0" ] && exit 0
	
	"$IPTABLES" -F $BLOCK_SITE
	"$IPTABLES" -F $BLOCK_SITE_NNTP
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit 1

