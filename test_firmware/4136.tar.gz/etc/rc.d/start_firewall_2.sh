#!/bin/sh

. /etc/rc.d/tools.sh
. /etc/rc.d/firewall_setup_function.sh

iptables="iptables"
TC_PROG="/etc/rc.d/TC.sh"
#TC_PROG="/etc/rc.d/qos_set.sh"

#[ -f $iptables ] || exit 0

accept="ACCEPT"
drop="DROP"
reject="REJECT"
log="LOG"
wan_ifname=`nvram get wan_ifname`
lan_ifname=`nvram get lan_ifname`

WAN_IPADDR=`nvram get wan0_ipaddr`
LAN_IPADDR=`nvram get lan_ipaddr`
LAN_SUBNET=`nvram get lan_netmask`
LAN_masklen=`print_masklen $LAN_SUBNET`
LAN_subnet=`print_subnet $LAN_IPADDR $LAN_SUBNET`




RETVAL=0
#echo 2 > /proc/fast_nat
/etc/rc.d/wan_ping.sh
/etc/rc.d/wan_iden.sh
/etc/rc.d/remote.sh start

if [ `nvram get wan_nat_enable` =  "1" ]; then

	# Block WAN ping	
	#wan_ping $wan_ifname

	# virtual server
	/etc/rc.d/forward_port.sh start
	# port trigger
	/etc/rc.d/autofw.sh start
	#fw_dmz
	/etc/rc.d/dmz.sh start
	
	#Aron add natgear spec TCP mss item---> pptp=mtu-80, other=mtu-40
	WAN_PROTO=`nvram get wan_proto`
	case "$WAN_PROTO" in	
		static|dhcp)
			proto_mtu=`nvram get wan_dhcp_mtu`
			MSS_MAX=$(($proto_mtu-40))
			;;
		pppoe)
			proto_mtu="$(nvram get wan_pppoe_mtu)"
			if [ "x$proto_mtu" = "x" ]; then
			proto_mtu=`nvram get wan_mulpppoe1_mtu`
			fi
			if [ "$proto_mtu" -gt "1492" ]; then
				proto_mtu=1492
			fi
			MSS_MAX=$(($proto_mtu-40))
			;;
		pptp)
			proto_mtu="$(nvram get wan_ppptp_mtu)"
			if [ "x$proto_mtu" = "x" ]; then
			proto_mtu=`nvram get wan_ppp_mtu`
			fi
			if [ "$proto_mtu" -gt "1452" ]; then
                 proto_mtu=1452
            fi
			MSS_MAX=$(($proto_mtu-80))
			;;
        l2tp)
            proto_mtu="$(nvram get wan_ppp_mtu)"
            if [ "x$proto_mtu" = "x" ]; then
                proto_mtu=`nvram get wan_l2tp_mtu`
            fi
            if [ "$proto_mtu" -gt "1492" ]; then
	        	proto_mtu=1492
		    fi
            MSS_MAX=$(($proto_mtu-80))
            ;;
		*)
			proto_mtu=`nvram get wan_dhcp_mtu`
			MSS_MAX=$(($proto_mtu-40))
	esac
	WAN_IF=`nvram get wan_ifname`
	#$iptables -t mangle -A POSTROUTING -p tcp --tcp-flags SYN,RST SYN -m tcpmss --mss $(($MSS_MAX+1)):1600 -j TCPMSS --set-mss $MSS_MAX
	$iptables -I FORWARD -o $WAN_IF -p tcp --tcp-flags SYN,RST SYN -m tcpmss --mss $(($MSS_MAX+1)):1600 -j TCPMSS --set-mss $MSS_MAX

	if [ "$WAN_PROTO" = "pppoe" ] && [ "`nvram get wan1_ipaddr`" != "" ]; then
			proto_mtu="$(nvram get wan1_ppp_mtu)"
			if [ "x$proto_mtu" = "x" ]; then
			proto_mtu=`nvram get wan_mulpppoe2_mtu`
			fi
			if [ "$proto_mtu" -gt "1492" ]; then
				proto_mtu=1492
			fi
			MSS_MAX=$(($proto_mtu-40))
			$iptables -I FORWARD -o ppp1 -p tcp --tcp-flags SYN,RST SYN -m tcpmss --mss $(($MSS_MAX+1)):65535 -j TCPMSS --set-mss $MSS_MAX
	fi	
	
fi

/etc/rc.d/dns_hijack.sh start

# DOS firewall
dos_firewall_advance $LAN_masklen
/etc/rc.d/spi_dos.sh start 

# Inbound defaults
#$iptables -A INPUT -j $log --log-level info --log-prefix "INPUT DROP : "
#$iptables -A FORWARD -j $log --log-level info --log-prefix "FORWARD DROP : "

if [ "`nvram get lan_proto`" = "relay" ]; then
#	iptables -A INPUT -i `nvram get lan_ifname` -p udp --dport 67 -m state --state NEW -j ACCEPT
	iptables -A local_server -p udp --dport 67 -m state --state NEW -j ACCEPT
fi

# for dhcp client, if dhcp client send re-new packet to server, and server reply with the broadcast address 
if [ "`nvram get wan_proto`" = "dhcp" ]; then
   HW_WAN_IF="`nvram get wan_hwifname`"
   iptables -A local_server -i $HW_WAN_IF -p udp --dport 68 -j ACCEPT
fi

# accept GRE for PPTP pass-through
#iptables -I FORWARD -p 0x2f -j ACCEPT
# for PPTP server send LCP-request 
if [ "`nvram get wan_proto`" = "pptp" ]; then
    HW_WAN_IF="`nvram get wan_hwifname`"
    iptables -A INPUT -i $HW_WAN_IF -p 0x2f -j ACCEPT
    iptables -A INPUT -i $HW_WAN_IF -p tcp --sport 1723 -j ACCEPT
fi

# Inbound accepts
$iptables -A input_init -i $lan_ifname -p icmp -m state --state NEW -j $accept # add the rule for ping
#add WAN_IPADDR prevent lan host connect to DUT's webpage by wan_ip + port 80
$iptables -A input_init -i $lan_ifname ! -d $WAN_IPADDR -m state --state NEW -j $accept
$iptables -A forward_init -i $lan_ifname -p tcp --tcp-flags ALL SYN -m state --state NEW -j ACCEPT
$iptables -A forward_init -i $lan_ifname -p tcp  -m state --state NEW -j DROP
#$iptables -A input_init -i $lan_ifname -m state --state NEW -j $accept

$iptables -A forward_init -i $lan_ifname -m state --state NEW -j $accept

if [ `nvram get wan_nat_enable` = "0" ]; then
$iptables -A forward_init -i $wan_ifname -m state --state NEW -j $accept
fi

# Allow established outbound connections back in
$iptables -A input_init -m state --state ESTABLISHED,RELATED -j $accept
$iptables -A forward_init -m state --state ESTABLISHED,RELATED -j $accept

#Traffic Control
${TC_PROG} restart

exit $RETVAL
