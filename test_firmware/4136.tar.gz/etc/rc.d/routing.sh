#!/bin/sh
#
#remove_routes	: Remove old routes
#intput		: interface(lan/wan0)
#
. /etc/rc.d/tools.sh

IPTABLES=/usr/sbin/iptables
ROUTE=/sbin/route
IP="/usr/sbin/ip"
AREA_CHK="/usr/sbin/area-ck"

vlan_enable=`nvram get vlan_enable`
wan_phy_mode=`nvram get wan_phy_mode`
if [ "$wan_phy_mode" = "adsl" ]; then
    MULTI_LAN=1
    PREF=30000
    STATIC_ROUTE_TABLE=200
fi

if [ "$MULTI_LAN" != "1" ]; then
    LAN_IPADDR=`nvram get lan_ipaddr`
    LAN_SUBNET=`nvram get lan_netmask`
    LAN_MASKLEN=`print_masklen $LAN_SUBNET`
    LAN_SUBNET=`print_subnet $LAN_IPADDR $LAN_SUBNET`    
fi

config_for_sw2()
{
   num=`nvram show | grep ^static_router | wc -l`
   rm -f /tmp/lan_route_tmp
   rm -f /tmp/wan_route_tmp
   count=0
   for tmp in `nvram show | grep ^static_router | awk -F"=" '{print $1}'`
      do 
         route=`nvram get "$tmp"`
         act=`echo "$route" | awk -F" " '{print $3}'`
         pri=`echo "$route" | awk -F" " '{print $2}'`
         iface=`echo "$route" | awk -F" " '{print $9}'`
         if [ "$act" = "1" ];then
            count=$(($count+1))
            if [ "$pri" = "0" ]; then
               st_route=`echo "$route" | awk -F" " '{print $4 ":" $5 ":" $6 ":" $7 ":" $3 " "}'`
            else
               st_route=`echo "$route" | awk -F" " '{print $4 ":" $5 ":" $6 ":" $7 ":0 "}'`
            fi
            if [ "$iface" = "1" ]; then
            	echo -n "$st_route" >> /tmp/wan_route_tmp
            else
            	echo -n "$st_route" >> /tmp/lan_route_tmp
            fi
         fi
      done
	all_lan_routes=`cat /tmp/lan_route_tmp`
    nvram set lan_route="$all_lan_routes"
	all_wan_routes=`cat /tmp/wan_route_tmp`
    nvram set wan0_route="$all_wan_routes"
    touch /tmp/configs/rm_old_route
    rm -f /tmp/lan_route_tmp
    rm -f /tmp/wan_route_tmp
}

remove_route_rule()
{
	if [ ! -f /tmp/configs/$1_route ]; then
		return
	fi

	for route in `cat /tmp/configs/$1_route`; do
		#ipaddress:netmask:gateway:metric:rip(on:1, off:0)
		ipaddress=`echo $route | awk -F: '{print $1}'`
		netmask=`echo $route | awk -F: '{print $2}'`
		gateway=`echo $route | awk -F: '{print $3}'`
		metric=`echo $route | awk -F: '{print $4}'`
		rip=`echo $route | awk -F: '{print $5}'`
		
                if [ "$MULTI_LAN" != "1" ]; then
                        if [ "$1" = "lan" ]; then  
                                area-ck $gateway $LAN_IPADDR $LAN_SUBNET
                		if [ "$?" = "1" ]; then 
                                    if [ "$netmask" = "255.255.255.255" ]; then
                                          #echo "$ROUTE del -host $ipaddress gw $gateway metric $metric"
                                          $ROUTE del -host $ipaddress gw $gateway metric $metric 2> /dev/null 
                                   else
                                         #echo "$ROUTE del -net $ipaddress netmask $netmask gw $gateway metric $metric"
                                          $ROUTE del -net $ipaddress netmask $netmask gw $gateway metric $metric 2> /dev/null 
                                    fi
                                    if [ "$?" = "0" ]; then                           
                        		    masklen=`print_masklen $netmask`
                        		    subnet=`print_subnet $ipaddress $netmask`
                        		    $IPTABLES -t nat -D static_privateroute -d $subnet/$masklen -j ACCEPT
                                    fi
                		fi
                        else
                             if [ "$netmask" = "255.255.255.255" ]; then
                                  #echo "$ROUTE del -host $ipaddress gw $gateway metric $metric"
                                  $ROUTE del -host $ipaddress gw $gateway metric $metric 2> /dev/null 
                           else
                                 #echo "$ROUTE del -net $ipaddress netmask $netmask gw $gateway metric $metric"
                                  $ROUTE del -net $ipaddress netmask $netmask gw $gateway metric $metric 2> /dev/null 
                            fi
                            if [ "$?" = "0" ]; then                           
                		    masklen=`print_masklen $netmask`
                		    subnet=`print_subnet $ipaddress $netmask`
                		    $IPTABLES -t nat -D static_privateroute -d $subnet/$masklen -j ACCEPT
                            fi
                        fi
                else 
                        if [ "$1" = "lan" ]; then    
                                if [ "$vlan_enable" = "1" ]; then
                                    LAN_GROUPS="1 2 3 4"
                                else
                                    LAN_GROUPS="1"
                                fi
                                for item in $LAN_GROUPS
                                do
                                        local lan_ipaddr=`nvram get lan${item}_ipaddr`
                                        local lan_subnet=`nvram get lan${item}_netmask`
                                        local lan_masklen=`print_masklen $lan_subnet`
                                        lan_subnet=`print_subnet $lan_ipaddr $lan_subnet`
        
                                        area-ck $gateway $lan_ipaddr $lan_subnet
                                        if [ "$?" = "1" ]; then
                                            match=1
                                            break
                                        fi
                                done

                                if [ "$match" = "1" ]; then           
                                    masklen=`print_masklen $netmask`
               		            subnet=`print_subnet $ipaddress $netmask`       
                                     if [ "$netmask" = "255.255.255.255" ]; then
                                            #echo "$IP route del $ipaddress/32 via $gateway metric $metric table $STATIC_ROUTE_TABLE"
                                            $IP route del $ipaddress/32 via $gateway metric $metric table $STATIC_ROUTE_TABLE
                                    else
                                            #echo "$ROUTE del -net $ipaddress netmask $netmask gw $gateway metric $metric"
                                            $IP route del $subnet/$masklen via $gateway metric $metric table $STATIC_ROUTE_TABLE 
                                    fi
                                    if [ "$?" = "0" ]; then
                                            masklen=`print_masklen $netmask`
                            		    subnet=`print_subnet $ipaddress $netmask`                                  
                                            #echo "$IPTABLES -t nat -D static_privateroute -d $subnet/$masklen -j ACCEPT"
                            		    $IPTABLES -t nat -D static_privateroute -d $subnet/$masklen -j ACCEPT 2> /dev/null 
                                    fi
                                fi
                        else 
                                masklen=`print_masklen $netmask`
               		        subnet=`print_subnet $ipaddress $netmask`     
                                if [ "$netmask" = "255.255.255.255" ]; then
                                            #echo "$ROUTE del -host $ipaddress gw $gateway metric $metric"
                                            $IP route del $ipaddress/32 via $gateway metric $metric table $STATIC_ROUTE_TABLE
                                    else
                                            #echo "$ROUTE del -net $ipaddress netmask $netmask gw $gateway metric $metric"
                                            $IP route del $subnet/$masklen via $gateway metric $metric table $STATIC_ROUTE_TABLE
                                fi
                                if [ "$?" = "0" ]; then
                                        masklen=`print_masklen $netmask`
            		                subnet=`print_subnet $ipaddress $netmask`
            		                $IPTABLES -t nat -D static_privateroute -d $subnet/$masklen -j ACCEPT 2> /dev/null 
                                fi
                        fi
                fi
	done
}
#
#add_routes	: Add all routes in lan_route and wan0_route
#input		: interface
#
add_route_rule()
{
        echo "add_route_rule $1"
	for route in `nvram get $1_route`; do
		#ipaddress:netmask:gateway:metric:rip(on:1, off:0)
		ipaddress=`echo $route | awk -F: '{print $1}'`
		netmask=`echo $route | awk -F: '{print $2}'`
		gateway=`echo $route | awk -F: '{print $3}'`
		metric=`echo $route | awk -F: '{print $4}'`
		rip=`echo $route | awk -F: '{print $5}'`
                
                if [ "$MULTI_LAN" != "1" ]; then
                        if [ "$1" = "lan" ]; then  
                		area-ck $gateway $LAN_IPADDR $LAN_SUBNET
                		if [ "$?" = "1" ]; then                            
                                    if [ "$netmask" = "255.255.255.255" ]; then
                                        #echo "$ROUTE add -host $ipaddress gw $gateway metric $metric"
                                         $ROUTE add -host $ipaddress gw $gateway metric $metric 2> /dev/null 
                                   else
                                        #echo "$ROUTE add -net $ipaddress netmask $netmask gw $gateway metric $metric"
                                        $ROUTE add -net $ipaddress netmask $netmask gw $gateway metric $metric 2> /dev/null 
                                    fi
                                    if [ "$?" = "0" ]; then
                        		    masklen=`print_masklen $netmask`
                        		    subnet=`print_subnet $ipaddress $netmask`
                        		    $IPTABLES -t nat -A static_privateroute -d $subnet/$masklen -j ACCEPT
                                    fi
                		fi  
                        else	# for WAN routing 
                                     local wan_ipaddr=`nvram get wan_default_ipaddr`
                                     local wan_netmask=`nvram get wan_default_netmask`
                                     local wan_ifname=`nvram get wan_ifname`
					
			             $AREA_CHK $wan_ipaddr $gateway $wan_netmask
			             if [ "$?" != "1" ]; then
                        		route add -net $gateway netmask 255.255.255.255 dev $wan_ifname
			             fi
                                   if [ "$netmask" = "255.255.255.255" ]; then
                                        #echo "$ROUTE add -host $ipaddress gw $gateway metric $metric"
                                         $ROUTE add -host $ipaddress gw $gateway metric $metric 2> /dev/null 
                                   else
                                        #echo "$ROUTE add -net $ipaddress netmask $netmask gw $gateway metric $metric"
                                        $ROUTE add -net $ipaddress netmask $netmask gw $gateway metric $metric 2> /dev/null 
                                    fi
                                    if [ "$?" = "0" ]; then
                        		    masklen=`print_masklen $netmask`
                        		    subnet=`print_subnet $ipaddress $netmask`
                        		    $IPTABLES -t nat -A static_privateroute -d $subnet/$masklen -j ACCEPT
                                    fi
                        fi
                else
                        if [ "$1" = "lan" ]; then                        
                                if [ "$vlan_enable" = "1" ]; then
                                    LAN_GROUPS="1 2 3 4"
                                else
                                    LAN_GROUPS="1"
                                fi
                                for item in $LAN_GROUPS
                                do
                                        local lan_ipaddr=`nvram get lan${item}_ipaddr`
                                        local lan_subnet=`nvram get lan${item}_netmask`
                                        local lan_masklen=`print_masklen $lan_subnet`
                                        lan_subnet=`print_subnet $lan_ipaddr $lan_subnet`
        
                                        area-ck $gateway $lan_ipaddr $lan_subnet
                                        if [ "$?" = "1" ]; then
                                            match=1
                                            break
                                        fi
                                done
        
                                if [ "$match" = "1" ]; then           
                                    masklen=`print_masklen $netmask`
               		            subnet=`print_subnet $ipaddress $netmask`       
                                    if [ "$netmask" = "255.255.255.255" ]; then
                                            #echo "$ROUTE add -host $ipaddress gw $gateway metric $metric"
                                            #$ROUTE add -host $ipaddress gw $gateway metric $metric 2> /dev/null 
                                            $IP route add $ipaddress/32 via $gateway metric $metric table $STATIC_ROUTE_TABLE
                                    else
                                            #echo "$ROUTE add -net $ipaddress netmask $netmask gw $gateway metric $metric"
                                            #$ROUTE add -net $ipaddress netmask $netmask gw $gateway metric $metric 2> /dev/null 
                                            $IP route add $subnet/$masklen via $gateway metric $metric table $STATIC_ROUTE_TABLE
                                    fi
                                    if [ "$?" = "0" ]; then                                                                     
                		        #echo "$IPTABLES -t nat -A static_privateroute -d $subnet/$masklen -j ACCEPT"
                		        $IPTABLES -t nat -A static_privateroute -d $subnet/$masklen -j ACCEPT 2> /dev/null 
                                    fi                                            
                                fi
                        else	# for WAN routing 
                                     local wan_default_iface=`nvram get wan_default_iface`
                                     local wan_ipaddr=`nvram get wan${wan_default_iface}_default_ipaddr`
                                     local wan_netmask=`nvram get wan${wan_default_iface}_default_netmask`
                                     local wan_ifname=`nvram get wan${wan_default_iface}_ifname`
					
			             $AREA_CHK $wan_ipaddr $gateway $wan_netmask
			             if [ "$?" != "1" ]; then
		                        $IP route add $gateway/32 dev $wan_ifname table $STATIC_ROUTE_TABLE 2> /dev/null
			             fi
                                    masklen=`print_masklen $netmask`
               		            subnet=`print_subnet $ipaddress $netmask`
                                    if [ "$netmask" = "255.255.255.255" ]; then
                                            #echo "$ROUTE add -host $ipaddress gw $gateway metric $metric"
                                            #$ROUTE add -host $ipaddress gw $gateway metric $metric 2> /dev/null 
                                            $IP route add $ipaddress/32 via $gateway metric $metric table $STATIC_ROUTE_TABLE
                                    else
                                            #echo "$ROUTE add -net $ipaddress netmask $netmask gw $gateway metric $metric"
                                            #$ROUTE add -net $ipaddress netmask $netmask gw $gateway metric $metric 2> /dev/null 
                                            $IP route add $subnet/$masklen via $gateway metric $metric table $STATIC_ROUTE_TABLE
                                    fi
                                    if [ "$?" = "0" ]; then                		        
                		        $IPTABLES -t nat -A static_privateroute -d $subnet/$masklen -j ACCEPT 2> /dev/null 
                                   fi
                        fi
                fi
	done
}

start()
{
	#
	#1. Remove old routes
	#
	echo -e "\n Static routes setting:"
	#if [ -f /tmp/configs/rm_old_route ]; then
		#rm /tmp/configs/rm_old_route
		#remove_route_rule "lan"
		#remove_route_rule "wan0"
		#route_op del lan
		#route_op del wan0
	#fi
        if [ "$MULTI_LAN" != "1" ]; then
                remove_route_rule "lan"
	        remove_route_rule "wan0"
        else                
                static_r_table=`$IP rule list | grep static`                
                if [ "x$static_r_table" = "x" ]; then 
                        echo "200 static" > /tmp/rt_tables                           
                        $IP rule add pref ${PREF} table static
                fi
                #$IP route flush table static
                remove_route_rule "lan"
                remove_route_rule "wan0"
                #$IPTABLES -t nat -F static_privateroute 
        fi

	if [ -f /tmp/configs/lan_route ]; then
		nvram get lan_route > /tmp/configs/lan_route
		nvram get wan0_route > /tmp/configs/wan0_route
	else
                echo "config_for_sw2"
		config_for_sw2
		nvram get lan_route > /tmp/configs/lan_route
		nvram get wan0_route > /tmp/configs/wan0_route
	fi
	#
	#2. add routes in lan_route, wan0_route
	# 
	wan0_ip=`nvram get wan$(nvram get wan_default_iface)_ipaddr`

	add_route_rule "lan"
	#route_op add lan

        if [ "$MULTI_LAN" != "1" ]; then
	    if [ $wan0_ip = "" ]; then
		    echo WAN is down
		    exit 0
	    fi
        fi
	
	add_route_rule "wan0"
	#route_op add wan0
}


case "$1" in
  start|restart)
        start
 	;;
 	config_for_sw2)
 	config_for_sw2
 	;;
  *)
        echo $"Usage: $0 {start|restart|wan}"
        exit 1
esac

