#!/bin/sh
# this script is used to control management control list function

#[ -f /bin/iptables ] || exit 0

. /etc/rc.d/tools.sh

iptables="iptables"
NVRAM="/usr/sbin/nvram"

accept="ACCEPT"
log="LOG"
drop="DROP"
reject="REJECT"

RETVAL=0

wan_phy_mode=`nvram get wan_phy_mode`
if [ "$wan_phy_mode" = "adsl" ]; then
        MULTI_LAN=1
fi

mark_flag=5
https_port=`nvram get https_port`
if [ "x$https_port" = "x" ]; then
        https_port="443"
fi

start() {
        local wan_ip=`nvram get wan0_ipaddr`
	local usb_enableHvia=`nvram get usb_enableHvia`
	local usb_HTTP_via_port=`nvram get usb_HTTP_via_port`

	if [ "$usb_enableHvia" = "0" ]; then
		$iptables -t mangle -A PREROUTING -p tcp --dport $usb_HTTP_via_port -j MARK --set-mark $mark_flag 
		$iptables -t nat -A nat_local_server -p tcp --dport $usb_HTTP_via_port -j REDIRECT --to-ports $https_port
		$iptables -A local_server -m mark --mark $mark_flag -d $wan_ip -p tcp --dport $https_port -j ACCEPT
	fi	

        if [ "$MULTI_LAN" = "1" ]; then
                nvram set wan_ipaddr_usb_http=$wan_ip
        fi
}

stop() {
        local wan_ip=`nvram get wan0_ipaddr`
	local usb_enableHvia=`nvram get usb_enableHvia`
	local usb_HTTP_via_port=`nvram get usb_HTTP_via_port`

        if [ "$MULTI_LAN" = "1" ]; then
                wan_ip=`nvram get wan_ipaddr_usb_http`
        fi

	$iptables -t mangle -D PREROUTING -p tcp --dport $usb_HTTP_via_port -j MARK --set-mark $mark_flag 2> /dev/null
	$iptables -t nat -D nat_local_server -p tcp --dport $usb_HTTP_via_port -j REDIRECT --to-ports $https_port 2> /dev/null
	$iptables -D local_server -m mark --mark $mark_flag -d $wan_ip -p tcp --dport $https_port -j ACCEPT 2> /dev/null
}


case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;  
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
