#!/bin/sh

echo "set default by SKU"

factory_default=`nvram get factory_default`
region=`cat /firmware_region`
HW_VER=`cat /hardware_version`
iptv_bridge=`nvram get iptv_bridge`

#To check /firmware_region and correct default setting accordingly.
if [ "$region" = "NA" ]; then
        #nvram set GUI_Region="English"
        #nvram set wl_country="16"
        if [ "$factory_default" = "1" ]; then
                nvram set GUI_Region="English"
                nvram set wl_country=10
                nvram set ntp_server="GMT+8"
                nvram set ntpserver_select="GMT+8"
                nvram set ntp_hidden_select=4
                nvram set time_zone="GMT+8"
                nvram set email_ntpserver="GMT+8"
                nvram set ntpserver1="time-b.netgear.com"
                nvram set ntpserver2="time-c.netgear.com"
                nvram set wan1_pppoe_mtu=1492
                nvram set wan1_proto="pppoe"
                nvram set multi_pvc=0
                nvram set atmPVC1="1*8*35*0*ubr:pcr=6000"
		nvram set atmPVC2="0*0*0*0*ubr:pcr=6000*0*0"
		nvram set atmPVC3="0*0*0*0*ubr:pcr=6000*0*0"
        fi
elif [ "$region" = "PR" ]; then
        #nvram set GUI_Region="Chinese"
        if [ "$factory_default" = "1" ]; then
                nvram set GUI_Region="Chinese"
                nvram set wl_country=1
                nvram set ntp_server="GMT-8"
                nvram set ntpserver_select="GMT-8"
                nvram set ntp_hidden_select=32
                nvram set time_zone="GMT-8"
                nvram set email_ntpserver="GMT-8"
                nvram set ntpserver1="time-e.netgear.com"
                nvram set ntpserver2="time-f.netgear.com"
                nvram set multi_pvc=0
		nvram set atmPVC1="1*0*38*1*ubr:pcr=6000*0*0"
		nvram set atmPVC2="0*0*0*0*ubr:pcr=6000*0*0"
		nvram set atmPVC3="0*0*0*0*ubr:pcr=6000*0*0"
        fi
elif [ "$region" = "RU" ]; then
        #nvram set GUI_Region="Russian"
        if [ "$factory_default" = "1" ]; then
                nvram set GUI_Region="Russian"
                nvram set wl_country=12
                nvram set ntp_server="GMT-3"
                nvram set ntpserver_select="GMT-3"
                nvram set ntp_hidden_select=26
                nvram set time_zone="GMT-3"
                nvram set email_ntpserver="GMT-3"
                nvram set ntpserver1="time-f.netgear.com"
                nvram set ntpserver2="time-g.netgear.com"
                nvram set multi_pvc=3
		nvram set atmPVC1="1*0*38*1*ubr:pcr=6000*0*0"
		nvram set atmPVC2="0*0*0*0*ubr:pcr=6000*0*0"
		nvram set atmPVC3="0*0*0*0*ubr:pcr=6000*0*0"
                nvram set wan2_proto=iptv
                nvram set wan3_proto=iptv
        fi        
elif [ "$region" = "AU" ]; then
        #nvram set GUI_Region="English"
        if [ "$factory_default" = "1" ]; then
                nvram set GUI_Region="English"
                nvram set wl_country=2
                nvram set ntp_server="GMT-10"
                nvram set ntpserver_select="GMT-10"
                nvram set ntp_hidden_select=35
                nvram set time_zone="GMT-10"
                nvram set email_ntpserver="GMT-10"
                nvram set ntpserver1="time-d.netgear.com"
                nvram set ntpserver2="time-e.netgear.com"
                nvram set wizard_select_country="AUSTRALIA"           
                nvram set multi_pvc=0
		if [ "$HW_VER" != "DGN1000v3-3DDAUS" ]; then
			nvram set atmPVC1="1*0*38*1*ubr:pcr=6000*0*0"
			nvram set atmPVC2="0*0*0*0*ubr:pcr=6000*0*0"
			nvram set atmPVC3="0*0*0*0*ubr:pcr=6000*0*0"
		fi
        fi
elif [ "$region" = "GR" ]; then
        #nvram set GUI_Region="German"
        if [ "$factory_default" = "1" ]; then
                nvram set GUI_Region="German"
		nvram set Language_Selection="German"
                nvram set wl_country=4
                nvram set ntp_server="GMT-1"
                nvram set ntpserver_select="GMT-1"
                nvram set ntp_hidden_select=18
                nvram set time_zone="GMT-1"
                nvram set email_ntpserver="GMT-1"
                nvram set ntpserver1="time-g.netgear.com"
                nvram set ntpserver2="time-h.netgear.com"       
                nvram set multi_pvc=2
                nvram set wizard_select_country="GR"
		nvram set wizard_select_GR_provider="T-Online"
                nvram set wan1_pppoe_mtu=1492
                nvram set wan1_proto="pppoe"
                nvram set atmPVC1="1*1*32*0*ubr:pcr=6000*1*7"
                nvram set atmPVC2="1*1*32*0*ubr:pcr=6000*1*8"
		nvram set atmPVC3="0*0*0*0*ubr:pcr=6000*0*0"
                nvram set wan1_pppoe_demand=1
		nvram unset GR_pppoe_vid
        	if [ "$iptv_bridge" = "1" ]; then
                	nvram set wan2_proto="iptv"         
                	#nvram set wan3_proto="iptv"
		else
                	nvram set wan2_proto="dhcp"         
			nvram set wan_endis_igmp=1
			nvram set wan1_endis_igmp=1
			nvram set wan2_endis_igmp=1
		fi
        fi        
elif [ "$region" = "WW" ]; then
        if [ "$factory_default" = "1" ]; then
                nvram set GUI_Region="English"
                nvram set wl_country=4
                nvram set ntp_server="GMT-0"
                nvram set ntpserver_select="GMT-0"
                nvram set ntp_hidden_select=17
                nvram set time_zone="GMT-0"
                nvram set email_ntpserver="GMT-0"
                nvram set ntpserver1="time-g.netgear.com"
                nvram set ntpserver2="time-h.netgear.com"
                nvram set multi_pvc=0
		nvram set atmPVC1="1*0*38*1*ubr:pcr=6000*0*0"
		nvram set atmPVC2="0*0*0*0*ubr:pcr=6000*0*0"
		nvram set atmPVC3="0*0*0*0*ubr:pcr=6000*0*0"
        fi
elif [ "$region" = "BZ" ]; then
        if [ "$factory_default" = "1" ]; then
                nvram set GUI_Region="English"
                nvram set wl_country=9
                nvram set ntp_server="GMT-3"
                nvram set ntpserver_select="GMT-3"
                nvram set ntp_hidden_select=13
                nvram set time_zone="GMT-3"
                nvram set email_ntpserver="GMT-3"
                nvram set ntpserver1="time-h.netgear.com"
                nvram set ntpserver2="time-a.netgear.com"
                nvram set wizard_select_country="BRAZIL"           
                nvram set multi_pvc=0
		nvram set atmPVC1="1*0*35*0*ubr:pcr=6000*0*0"
		nvram set atmPVC2="0*0*0*0*ubr:pcr=6000*0*0"
		nvram set atmPVC3="0*0*0*0*ubr:pcr=6000*0*0"
        fi
elif [ "$region" = "PT" ]; then
        if [ "$factory_default" = "1" ]; then
        	nvram set GUI_Region="Portuguese"
	        nvram set multi_pvc=0
		nvram set atmPVC1="1*0*38*1*ubr:pcr=6000*0*0"
		nvram set atmPVC2="0*0*0*0*ubr:pcr=6000*0*0"
		nvram set atmPVC3="0*0*0*0*ubr:pcr=6000*0*0"
	fi
fi

if [ "$factory_default" = "1" ]; then
        nvram set factory_default=0
        nvram commit
fi
