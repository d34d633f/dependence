#!/bin/sh

prog="wscd"
BRIDGE_INTERFACE=br0
WPS_ENABLED=`nvram get WPSEnable`
WSC_EXTERNAL_REGISTRAR=`nvram get WIFIWscExternalRegistrar`
LAN_MAC=$(nvram get lan_hwaddr | sed -n 's/://gp')
LAN_IP=`nvram get lan_ipaddr`
UUID="bc329e00-1dd8-11b2-8601-${LAN_MAC}"
AOSS_ACTION=`nvram get WIFIAOSSAction`

start() {
	# for miniigd patch	
	#Set a flag to allow mini-igd to append firewall rule

	#rnd_port=`cat /tmp/wscd_config.old | grep port | awk '{print $NF}'`
	
	if [ "$WPS_ENABLED" = "1" ] && [ "$WSC_EXTERNAL_REGISTRAR" = "1" ] && [ "$AOSS_ACTION" != "1" ]; then


		rm -f  /tmp/wscd_config.old 
		cp /etc/rc.d/wscd.conf /var/wps/wscd.conf.1
		cp /etc/rc.d/wscd_config /tmp/wscd_config.1

		/bin/sed -e 's/aabbccddeeff/'${LAN_MAC}'/g' /var/wps/wscd.conf.1 > /var/wps/wscd.conf
		rm /var/wps/wscd.conf.1

		#/bin/sed -e 's/aabbccddeeff/'${LAN_MAC}'/g' /tmp/wscd_config.1 > /tmp/wscd_config
		/bin/sed -e 's/aabbccddeeff/'${LAN_MAC}'/g' /tmp/wscd_config.1 > /tmp/wscd_config.2
		rm /tmp/wscd_config.1

		#generate random port
		rnd_seed=`cat /proc/stat | grep intr | awk '{print $2}'`
		echo "$rnd_seed" > /dev/urandom
		tmp_rnd_num=`dd if=/dev/urandom bs=1 count=1 2>/dev/null | hexdump -d | head -1 | awk '{print 0+$NF}'`
		rnd_num=$((${tmp_rnd_num}%10000))
		rnd_port=$((${rnd_num} + 50000))

		/bin/sed -e 's/57788/'${rnd_port}'/g' /tmp/wscd_config.2 > /tmp/wscd_config
		rm /tmp/wscd_config.2

		rnd_port=`cat /tmp/wscd_config | grep port | awk '{print $NF}'`

		echo $"Starting $prog: "
		route del -net 239.255.255.250 netmask 255.255.255.255 br0
	  	route add -net 239.255.255.250 netmask 255.255.255.255 br0
		#(cd /tmp && /usr/sbin/wscd -i ra0 -a $LAN_IP -m 1 -p 57788 -D) 
		(cd /tmp && /usr/sbin/wscd -i ra0 -a $LAN_IP -m 1 -p "$rnd_port" -D)
	fi
}

stop() {
	# Stop daemons.
	echo $"Shutting down $prog: "
	killall -9 wscd 2> /dev/null
	sleep 2
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL
