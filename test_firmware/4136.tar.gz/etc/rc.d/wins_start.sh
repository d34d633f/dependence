#! /bin/sh

start(){
wins &
}

stop(){
ps > /tmp/tmp_ps
grep "wins" /tmp/tmp_ps > /tmp/wins_pid
if [ "`cat /tmp/wins_pid`" != "" ]; then
PID=`echo $(awk -F" " '{ print $1 }' /tmp/wins_pid)`
rm /tmp/tmp_ps
rm /tmp/wins_pid
kill -9 $PID
else
echo "none"
fi
}

case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    *)
    exit 1
esac

