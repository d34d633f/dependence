#!/bin/sh

SERVER_ROOT=/www

. ${SERVER_ROOT}/cgi-bin/functions.sh
. ${SERVER_ROOT}/cgi-bin/webupgrade.sh

snmp_fwupgrade_file=$(nvram get "fw_filename")

if [ -e /tmp/$snmp_fwupgrade_file ]; then 
	file_name=/tmp/$snmp_fwupgrade_file
	offset=0
else
    exit
fi

errCode=0
imginstall $file_name $offset
result=$errCode

if [ "$errCode" = "0" ]; then
		echo "update firmware successe!!"
else
		echo "update firmware failure!!"
    rm -f $file_name
    #nvram set action=1 #Reboot Device
fi