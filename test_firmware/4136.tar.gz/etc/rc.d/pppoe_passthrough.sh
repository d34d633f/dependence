#!/bin/sh

PPPoE_PassThrough=`nvram get PPPoEPassThrough_enable`
WAN_IF=`nvram get wan_ifname`
WAN_MAC=`nvram get wan_hwaddr`
BR_NAME=`nvram get lan_ifname`

PPP_DISC=0x8863
PPP_SES=0x8864

BRCTL_BIN="/usr/sbin/brctl"
EBTABLE_BIN="/usr/sbin/ebtables"

RETVAL=0

ipv6_pass=`nvram get ipv6_pass`

[ -f /usr/sbin/ebtables ] || exit 0
[ -f /usr/sbin/brctl ] || exit 0


start() {
echo $"Starting PPPoE Pass Through: "

	${BRCTL_BIN} addif $BR_NAME $WAN_IF

	${EBTABLE_BIN} -t broute -D BROUTING -p $PPP_DISC -d ! $WAN_MAC -j ACCEPT 
	${EBTABLE_BIN} -t broute -D BROUTING -p $PPP_SES -d ! $WAN_MAC -j ACCEPT 
	${EBTABLE_BIN} -t broute -D BROUTING -i $WAN_IF -j DROP
   
	${EBTABLE_BIN} -t filter -D FORWARD -p $PPP_DISC -j ACCEPT
	${EBTABLE_BIN} -t filter -D FORWARD -p $PPP_SES -j ACCEPT
	${EBTABLE_BIN} -t filter -D FORWARD -o $WAN_IF -j DROP

	${EBTABLE_BIN} -t broute -A BROUTING -p $PPP_DISC -d ! $WAN_MAC -j ACCEPT 
	${EBTABLE_BIN} -t broute -A BROUTING -p $PPP_SES -d ! $WAN_MAC -j ACCEPT 
	${EBTABLE_BIN} -t broute -A BROUTING -i $WAN_IF -j DROP
  
	${EBTABLE_BIN} -t filter -A FORWARD -p $PPP_DISC -j ACCEPT
	${EBTABLE_BIN} -t filter -A FORWARD -p $PPP_SES -j ACCEPT  
	${EBTABLE_BIN} -t filter -A FORWARD -o $WAN_IF -j DROP
  
	#echo 1 > /proc/rtk_promiscuous
 
	echo
	return $RETVAL  
}

stop() {
	echo $"Stoping PPPoE Pass Through: "

	#if [ "$ipv6_pass" = "1" ]; then
	#	echo 1 > /proc/rtk_promiscuous
	#else
	#	echo 0 > /proc/rtk_promiscuous
	#fi
	${BRCTL_BIN} delif $BR_NAME $WAN_IF 2> /dev/null

	${EBTABLE_BIN} -t broute -D BROUTING -p $PPP_DISC -d ! $WAN_MAC -j ACCEPT 2> /dev/null
	${EBTABLE_BIN} -t broute -D BROUTING -p $PPP_SES -d ! $WAN_MAC -j ACCEPT 2> /dev/null
	${EBTABLE_BIN} -t broute -D BROUTING -i $WAN_IF -j DROP 2> /dev/null
  
	${EBTABLE_BIN} -t filter -D FORWARD -p $PPP_DISC -j ACCEPT 2> /dev/null
	${EBTABLE_BIN} -t filter -D FORWARD -p $PPP_SES -j ACCEPT 2> /dev/null
	${EBTABLE_BIN} -t filter -D FORWARD -o $WAN_IF -j DROP 2> /dev/null
   
	echo
	return $RETVAL
}



if [ "$PPPoE_PassThrough" = "1" ]; then 
   start
      
elif [ "$PPPoE_PassThrough" = "0" ]; then

   stop
fi


exit $RETVAL

