#!/bin/sh

. /etc/rc.d/tools.sh

prog="firewall"
iptables="iptables"

accept="ACCEPT"
log="LOG"
drop="DROP"
reject="REJECT"
NVRAM="/usr/sbin/nvram"
IP="/usr/sbin/ip"
ALL_LAN_INTFS="br+"
ALL_NAS_INTFS="vc+"
ALL_PPP_INTFS="ppp+"
ALL_ETH_INTFS="nas+"

NNTP_PORT=119

vlan_enable=`nvram get vlan_enable`
wan_phy_auto=`nvram get wan_phy_auto`

flush_tables()
{
    echo $"Firewall: flush tables"
    $iptables -F 
    $iptables -Z		

    $iptables -P INPUT $accept
    $iptables -P FORWARD $accept
    $iptables -P OUTPUT $accept    

    $iptables -F -t nat
    $iptables -Z -t nat
    $iptables -F -t mangle

    $iptables -F -t nat
    $iptables -Z -t nat
}

filter_table_init()
{
    echo $"Firewall: Init filter table"
    #$iptables -F 
    #$iptables -Z		
    #$iptables -F -t nat
    #$iptables -Z -t nat
    #$iptables -F -t mangle
    
    $iptables -A INPUT -j input_ipsec
    #MAC filter used
    $iptables -A INPUT -j input_mac_filter
    $iptables -A INPUT -i $ALL_PPP_INTFS -j input_dos
    $iptables -A INPUT -i $ALL_NAS_INTFS -j input_dos
    if [ "$wan_phy_auto" = "1" ]; then
            $iptables -A INPUT -i $ALL_ETH_INTFS -j input_dos
    fi
    $iptables -A INPUT -j input_iden
    $iptables -A INPUT -j input_init

    $iptables -A INPUT -i $ALL_PPP_INTFS -j local_server
    $iptables -A INPUT -i $ALL_NAS_INTFS -j local_server
    if [ "$wan_phy_auto" = "1" ]; then
            $iptables -A INPUT -i $ALL_ETH_INTFS -j local_server
    fi
                   
    $iptables -A FORWARD -j fwd_ipsec
    $iptables -A FORWARD -j fwd_mac_filter
    $iptables -A FORWARD -j fwd_block_svc
    $iptables -A FORWARD -i $ALL_LAN_INTFS -o $ALL_PPP_INTFS -p tcp -j fwd_block_site
    $iptables -A FORWARD -i $ALL_LAN_INTFS -o $ALL_NAS_INTFS -p tcp -j fwd_block_site
    if [ "$wan_phy_auto" = "1" ]; then
            $iptables -A FORWARD -i $ALL_LAN_INTFS -o $ALL_ETH_INTFS -p tcp -j fwd_block_site
    fi        
    #$iptables -A FORWARD -i $ALL_PPP_INTFS -o $ALL_LAN_INTFS -p tcp --sport $NNTP_PORT -j fwd_block_site_nntp
    #$iptables -A FORWARD -i $ALL_NAS_INTFS -o $ALL_LAN_INTFS -p tcp --sport $NNTP_PORT -j fwd_block_site_nntp
    $iptables -A FORWARD -i $ALL_LAN_INTFS -o $ALL_PPP_INTFS -p tcp --dport $NNTP_PORT -j fwd_block_site_nntp
    $iptables -A FORWARD -i $ALL_LAN_INTFS -o $ALL_NAS_INTFS -p tcp --dport $NNTP_PORT -j fwd_block_site_nntp
    if [ "$wan_phy_auto" = "1" ]; then
            $iptables -A FORWARD -i $ALL_LAN_INTFS -o $ALL_ETH_INTFS -p tcp --dport $NNTP_PORT -j fwd_block_site_nntp
    fi
    $iptables -A FORWARD -j fwd_port_trigger
    $iptables -A FORWARD -j fwd_vpn_passthru
    $iptables -A FORWARD -j fwd_wifi_guest
    $iptables -A FORWARD -j forward_init
    $iptables -A FORWARD -i $ALL_LAN_INTFS -j lan_forward
    $iptables -A FORWARD -i $ALL_PPP_INTFS -j wan_forward
    if [ "$wan_phy_auto" = "1" ]; then
            $iptables -A FORWARD -i $ALL_ETH_INTFS -j wan_forward
    fi
    $iptables -A FORWARD -i $ALL_NAS_INTFS -j wan_forward
    $iptables -A FORWARD -j fwd_port_forward
    $iptables -A FORWARD -j fwd_upnp
    $iptables -A FORWARD -j fwd_dmz
    $iptables -A FORWARD -j fwd_local_server

    $iptables -t mangle -A PREROUTING -j mangle_local_server
    $iptables -t mangle -A PREROUTING -j mangle_dns_hijack

    if [ "$vlan_enable" != "1" ]; then
        LAN_INTFS="1"
    else
        LAN_INTFS="4 3 2 1"
    fi
    for item in $LAN_INTFS
    do
        index=$(($item-1))
        $iptables -I FORWARD -i br${index} -j group${item}_forward
    done
  
    if [ "$vlan_enable" != "1" ]; then
        LAN_INTFS="1"
    else
        LAN_INTFS="1 2 3 4"
    fi
    for item in $LAN_INTFS
    do
        lan_ifname=`nvram get lan${item}_ifname`
        LAN_IPADDR=`nvram get lan${item}_ipaddr`
        LAN_SUBNET=`nvram get lan${item}_netmask`
        masklen=`print_masklen $LAN_SUBNET`
        subnet=`print_subnet $LAN_IPADDR $LAN_SUBNET`
        # do not forward non-lan ip address
        $iptables -I group${item}_forward ! -s $subnet/$masklen -j DROP
    done

    iptables -A OUTPUT -j output_init
    iptables -A OUTPUT -j output_dos
    
    # Inbound handle
    $iptables -A input_init -m state --state INVALID -j $drop                                                      # Drop invalid packets
    $iptables -A input_init -i $ALL_LAN_INTFS -p icmp -m state --state NEW -j $accept            # add the rule for ping from lan sides
    $iptables -A input_init -i $ALL_LAN_INTFS -m state --state NEW -j $accept
    
    # Forward handle
    $iptables -A forward_init -m state --state INVALID -j $drop                                                 # Drop invalid packets
    $iptables -A forward_init -i $ALL_LAN_INTFS -p tcp --tcp-flags ALL SYN -m state --state NEW -j ACCEPT
    $iptables -A forward_init -i $ALL_LAN_INTFS -p tcp  -m state --state NEW -j DROP
    $iptables -A forward_init -i $ALL_LAN_INTFS -m state --state NEW -j $accept
    
    # Allow established outbound connections back in
    $iptables -A input_init -m state --state ESTABLISHED,RELATED -j $accept
    $iptables -A forward_init -m state --state ESTABLISHED,RELATED -j $accept

    # Inbound defaults
    $iptables -P INPUT $drop
    $iptables -P FORWARD $drop
    $iptables -P OUTPUT $accept      
}

find_wan()  #$1: lan group
{
     lan_group=$1
     WAN_INTFS="1 2 3 4 5 6 7 8"
     find_wan=`nvram get interface_group_map | cut -d":" -f $lan_group | grep "wan"`
     if [ "x$find_wan" != "x" ]; then
          temp=$find_wan
          for i in $WAN_INTFS
          do
              wan=`echo $temp | grep "wan$i"`
              if [ "x$wan" != "x" ]; then
                   find_wan=$i
                   break
              fi
         done
     fi
     echo $find_wan
}

update_rules()
{
    item=$1
    TABLE=20
    lan_ifname=`nvram get lan${item}_ifname`
    LAN_IPADDR=`nvram get lan${item}_ipaddr`
    LAN_SUBNET=`nvram get lan${item}_netmask`
    masklen=`print_masklen $LAN_SUBNET`
    subnet=`print_subnet $LAN_IPADDR $LAN_SUBNET`

    # do not forward non-lan ip address
    $iptables -F group${item}_forward
    $iptables -I group${item}_forward ! -s $subnet/$masklen -j DROP

    $iptables -t nat -F group${item}_postroute
    $iptables -t nat -F group${item}_local_server

    $iptables -t nat -I group${item}_postroute -s $LAN_IPADDR -j ACCEPT
    $iptables -t nat -I group${item}_local_server -p icmp -s $subnet/$masklen -j ACCEPT

   correspond_wan_iface=`find_wan ${item}`
   if [ "x${correspond_wan_iface}" != "x" ]; then
            wan_ipaddr=`nvram get wan${correspond_wan_iface}_default_ipaddr`
            if [ "x$wan_ipaddr" != "x" ]; then
                    $iptables -t nat -F group${item}_nat_endis
                    nat_endif=`nvram get wan${correspond_wan_iface}_nat_enable`
                    if [ "$nat_endif" = "1" ]; then
                            interface=`nvram get wan${correspond_wan_iface}_ifname`
			    lan_ipaddr=`nvram get lan${item}_ipaddr`
                            lan_netmask=`nvram get lan${item}_netmask`
                            masklen=`print_masklen $lan_netmask`
                            subnet=`print_subnet $lan_ipaddr $lan_netmask`
                            lan_ifname=`nvram get lan${item}_ifname`

                            #$iptables -t nat -A group${item}_nat_endis -o $interface -s ${subnet}/${masklen} -j MASQUERADE 
                            $iptables -t nat -A group${item}_nat_endis -o $interface -s ${subnet}/${masklen} -j SNATP2P --to-source $wan_ipaddr
			    $iptables -t nat -A group${item}_nat_endis -o $lan_ifname -s ${subnet}/${masklen} -j SNATP2P --to-source $wan_ipaddr 2> /dev/null
                            #$iptables -t nat -A group${item}_nat_endis -o $interface  -j SNATP2P --to-source $wan_ipaddr

                            $IP rule del table ${TABLE}${correspond_wan_iface} 
                            $IP rule add from ${subnet}/${masklen} table ${TABLE}${correspond_wan_iface} 
                    fi
            fi
    fi   
}

nat_table_init()
{
    echo $"Firewall: init nat table"
    echo 0 > /proc/sys/net/ipv4/ip_forward || echo "/proc not available"
    #$iptables -F -t nat
    #$iptables -Z -t nat
    $iptables -t nat -P PREROUTING ACCEPT
    $iptables -t nat -P POSTROUTING ACCEPT
    $iptables -t nat -P OUTPUT ACCEPT
    
    $iptables -t nat -A PREROUTING -i $ALL_PPP_INTFS -j dnat
    $iptables -t nat -A PREROUTING -i $ALL_NAS_INTFS -j dnat
    if [ "$wan_phy_auto" = "1" ]; then
            $iptables -t nat -A PREROUTING -i $ALL_ETH_INTFS -j dnat
    fi

    $iptables -t nat -A PREROUTING -j nat_local_server_init
    $iptables -t nat -A PREROUTING -j nat_port_forward_init
    $iptables -t nat -A PREROUTING -j nat_port_trigger_inbound_init
    $iptables -t nat -A PREROUTING -i $ALL_PPP_INTFS -j nat_upnp_init
    $iptables -t nat -A PREROUTING -i $ALL_NAS_INTFS -j nat_upnp_init
    if [ "$wan_phy_auto" = "1" ]; then
            $iptables -t nat -A PREROUTING -i $ALL_ETH_INTFS -j nat_upnp_init
    fi
    $iptables -t nat -A PREROUTING -j nat_dmz_init
    $iptables -t nat -A PREROUTING -j nat_nbt
   
    if [ "$vlan_enable" != "1" ]; then
        LAN_INTFS="1"
    else
        LAN_INTFS="1 2 3 4"
    fi
    for item in $LAN_INTFS
    do
        index=$(($item-1))
        $iptables -t nat -A POSTROUTING -o br${index} -j group${item}_postroute
        $iptables -t nat -I nat_local_server -j group${item}_local_server
        $iptables -t nat -A nat_endis -j group${item}_nat_endis
        lan_ifname=`nvram get lan${item}_ifname`
        LAN_IPADDR=`nvram get lan${item}_ipaddr`
        LAN_SUBNET=`nvram get lan${item}_netmask`
        masklen=`print_masklen $LAN_SUBNET`
        subnet=`print_subnet $LAN_IPADDR $LAN_SUBNET`
        $iptables -t nat -A group${item}_postroute -s $LAN_IPADDR -j ACCEPT
	#for CONFIG_NETFILTER_BRIDGE lan & wireless bridge
        $iptables -t mangle -A PREROUTING -s $subnet/$masklen -d $subnet/$masklen -j MARK --set-mark 119
        $iptables -t nat -A group${item}_postroute -s $subnet/$masklen -d $subnet/$masklen -m mark --mark 119 -j ACCEPT
        $iptables -t nat -I group${item}_local_server -p icmp -s $subnet/$masklen -j ACCEPT
    done
        
    $iptables -t nat -A POSTROUTING -j nat_ipsec
    #for static routing in LAN domain.
    $iptables -t nat -A POSTROUTING -o $ALL_LAN_INTFS -j static_privateroute
    #for RIP routing in LAN domain.
    $iptables -t nat -A POSTROUTING -o $ALL_LAN_INTFS -j RIP_privateroute
    $iptables -t nat -A POSTROUTING -j nat_endis

    #/etc/rc.d/nat_type.sh start
}


do_security()
{
        echo $"Firewall: Security settings"

        /etc/rc.d/wan_iden.sh    
    
        if [ `nvram get nat_disable` = 0 ]; then            
    	    /etc/rc.d/forward_port.sh start             # virtual server            
    	    /etc/rc.d/autofw.sh start                       # port trigger    	    
        fi     
       
        #blk_site_enable=`nvram get block_skeyword`
	blk_svc_enable=`nvram get blockserv_ctrl`

        if [ "$blk_site_enable" -eq "2" ]; then
	    /etc/rc.d/blk_site.sh restart
	fi
	#if [ "$blk_svc_enable" -eq "2" ]; then
	    /etc/rc.d/blk_svc.sh restart
	#fi

        /etc/rc.d/vpn_passthru.sh init
        /etc/rc.d/sip_alg.sh restart

	/etc/rc.d/dns_hijack.sh restart 1		#for br0	
}


case "$1" in
  flush)
        flush_tables
        ;;
  init)
	filter_table_init
        if [ `nvram get nat_disable` = "0" ]; then
            nat_table_init
        fi
	;;
  update_rules)
	update_rules $2
	;;
  security)
	do_security
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {init|lan_rule|restart}"
	exit 1
esac


exit $RETVAL


