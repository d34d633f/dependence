#!/bin/sh
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin


#STATUS_FILE="/var/status.txt"

#echo "stop application" > $STATUS_FILE

######### stop application #########
	/bin/killall crond
	/bin/killall telnetd
	/bin/killall upnp
	/bin/killall udhcpc
	