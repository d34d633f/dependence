#!/bin/sh

RETVAL=0
prog="dhcp6c"
CONFIG_FILE="/tmp/dhcp6c.config"
WAN_PHY_MODE=`nvram get wan_phy_mode`
WAN_IF_NAME=`nvram get ipv6_if_name`
WAN_TYPE=`nvram get ipv6_type`
DOMAIN_NAME=`nvram get ipv6_dhcp_domainName`
VLAN_ENABLE=`nvram get vlan_enable`

start() {

	if [ "$WAN_TYPE" = "autoDetect" ];then
		DETECT_TYPE=`cat /tmp/ipv6_auto_output | awk '{printf $1}'`
		case "$DETECT_TYPE" in
		Auto)
			WAN_TYPE="autoConfig"
			;;
		DHCP)
			WAN_TYPE="dhcp"
			;;	
		esac
	fi
	if [ "$WAN_TYPE" = "dhcp" ];then
		echo "Start DHCPv6 Client ..."
		echo 'interface '$WAN_IF_NAME' {' > $CONFIG_FILE
		echo '	request domain-name-servers;' >> $CONFIG_FILE
		echo '	request domain-name;' >> $CONFIG_FILE
		echo '	request sip-server-address;' >> $CONFIG_FILE
		echo '	request sip-server-domain-name;' >> $CONFIG_FILE
		echo '	request ntp-servers;' >> $CONFIG_FILE
		#echo '	send rapid-commit;' >> $CONFIG_FILE
		echo '	send ia-na 1;' >> $CONFIG_FILE
		echo '	send ia-pd 11;' >> $CONFIG_FILE
		echo '};' >> $CONFIG_FILE
		echo 'id-assoc na 1 { #' >> $CONFIG_FILE
		echo '};' >> $CONFIG_FILE
			echo 'id-assoc pd 11 { #' >> $CONFIG_FILE
		if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
			LAN_IF_NUM="1 2 3 4"
			for i in $LAN_IF_NUM;
			do
				LAN_IF_NAME=`nvram get lan${i}_ifname`
				if [ "x" != "x"ifconfig $LAN_IF_NAME ];then
				echo '	prefix-interface '$LAN_IF_NAME' {' >> $CONFIG_FILE	
				echo '		sla-len 2;' >> $CONFIG_FILE
				echo '		sla-id '$((i-1))';' >> $CONFIG_FILE
				echo '	};' >> $CONFIG_FILE
				fi
			done
		else
			LAN_IF_NAME=`nvram get lan_ifname`
			echo '	prefix-interface '$LAN_IF_NAME' {' >> $CONFIG_FILE
			echo '		sla-len 0;' >> $CONFIG_FILE
			echo '	};' >> $CONFIG_FILE	
		fi
		echo '};' >> $CONFIG_FILE
	elif [ "$WAN_TYPE" = "autoConfig" ];then
		echo "Start DHCPv6 Client ..."
		echo 'interface '$WAN_IF_NAME' {' > $CONFIG_FILE
		echo '  request domain-name-servers;' >> $CONFIG_FILE
		echo '  request domain-name;' >> $CONFIG_FILE
		echo '  request sip-server-address;' >> $CONFIG_FILE
		echo '  request sip-server-domain-name;' >> $CONFIG_FILE
		echo '  request ntp-servers;' >> $CONFIG_FILE
		echo ' send ia-pd 11;' >> $CONFIG_FILE
		echo '};' >> $CONFIG_FILE
		echo 'id-assoc pd 11 { #' >> $CONFIG_FILE
		if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
			LAN_IF_NUM="1 2 3 4"
			for i in $LAN_IF_NUM;
			do
				LAN_IF_NAME=`nvram get lan${i}_ifname`
				if [ "x" != "x`ifconfig $LAN_IF_NAME`" ];then
				echo '	prefix-interface '$LAN_IF_NAME' {' >> $CONFIG_FILE
				echo '		sla-len 2;' >> $CONFIG_FILE
				echo '		sla-id '$((i-1))';' >> $CONFIG_FILE
				echo '	};' >> $CONFIG_FILE
				fi
			done
		else
			LAN_IF_NAME=`nvram get lan_ifname`
			echo '	prefix-interface '$LAN_IF_NAME' {' >> $CONFIG_FILE
			echo '		sla-len 0;' >> $CONFIG_FILE
			echo '	};' >> $CONFIG_FILE
		fi
		echo '};' >> $CONFIG_FILE
	fi
	

	$prog -c $CONFIG_FILE $WAN_IF_NAME
	#sleep 5

	RETVAL=$?
	return $RETVAL
}

stop() {

	echo "Stop DHCPv6 Client ..."
	killall $prog
	if [ -e "$CONFIG_FILE" ];then
		rm $CONFIG_FILE
	fi
	RETVAL=$?
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart|reload)
    stop
    start
    RETVAL=$?
    ;;
  *)
    echo $"Usage: $0 {start|stop|restart}"
    exit 1
esac

exit $RETVAL
