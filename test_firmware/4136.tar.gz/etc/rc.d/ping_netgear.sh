#!/bin/sh

IF="eth1"
wan_proto=$(nvram get wan_proto)
if [ "$wan_proto" = "pppoe" -o "$wan_proto" = "l2tp" -o "$wan_proto" = "pptp" ]; then
    IF="ppp0"
fi    


#ping -c 3 -I $IF www.netgear.com > /tmp/ping_netgear
ping -c 3 www.netgear.com > /tmp/ping_netgear

RES=`cat /tmp/ping_netgear | grep rec | cut -d ',' -f2 | cut -d " " -f2`
if [ "$RES" = "1" -o "$RES" = "2" -o "$RES" = "3" ]; then
     echo 1 > /tmp/ping_netgear_res
else
     echo 0 > /tmp/ping_netgear_res
fi