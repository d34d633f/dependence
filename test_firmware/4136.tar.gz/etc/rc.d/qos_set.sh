#!/bin/sh

##################################################################################
##         Initial Setting                                                      ##
##	(Entry File: S56init_ipqos.sh)                                              ##
## Step 1: ipqos_preinit                                                        ##
## Step 2: /etc/rc.d/ipqos_init	                                                ##
##   ========================================================================   ##
## Conclusion:                                                                  ##
##                                                                              ##
##	(1). PREROUTING or OUTPUT Chains are both use LAN_X parse to set mark data. ##
##  (2). MAC cannot set in OUTPUT Chain.										##
##  (3). ppacmd control enable/disable has been disalbed in this script.        ##
##                                                                              ##
## Revision:                                                                    ##
##                                                                              ##
##   [04/26]:Comment out all of "ppacmd control" as above (3).                  ##
##           Refine tc control for ADSL mode.(take off all of imqx)             ##
##################################################################################
NVRAM="/usr/sbin/nvram"
PPE_PLATFORM="VR9"
WAN_IF=`$NVRAM get wan_ifname`
LAN_IF=`$NVRAM get lan_ifname`
LAN_IPADDR=`$NVRAM get lan_ipaddr`
LAN_SUBNET=`$NVRAM get lan_netmask`
#SU_IP="192.168.1.101/32"
SU_IP=`$NVRAM get qos_su_ip`
CLSCOUNTFILE="/tmp/ipqos_class_count"

# Define interface types
# NOTE: These values should match with the values in the enum 
QOS_INTF_LAN=0
QOS_INTF_LOCAL=7
QOS_INTF_ALL=13
QOS_INTF_WAN_ATM=9
QOS_INTF_WAN_PTM=10
QOS_INTF_WAN_ETH_0=11
QOS_INTF_WAN_ETH_1=12
QOS_INTF_LAN_SPECIFIC=14

QOS_TYPE_MFC=0
QOS_TYPE_DSCP=1
QOS_TYPE_802_1P=2

QOS_ENABLE=`$NVRAM get qos_endis_on`
#qos_threshold=`$NVRAM get qos_threshold`
QOS_BW_CTL_ON=`$NVRAM get qos_threshold`
QOS_UP_BW=`$NVRAM get qos_uprate`
QOS_UP_BW_UNIT=`$NVRAM get qos_width`

QOS_QUEUE_COUNTS=4
LTQ_QUEUE_COUNTS=8

if [ -f /tmp/ppe_firmware ]; then
	. /tmp/ppe_firmware
else
	PPE_FIRMWARE="E5"
	echo "QoS: have no load ppe_firmware, default fireware E5!"
fi
case "`$NVRAM get wan_phy_mode`" in
adsl)
    wanphy_phymode=0
    wanphy_tc=0 #ATM-TC

	TC_ACTION=0  #TC rules ADD action input for TCP ACK Prio
	ADSL_MODE_ON=1 #denotes ADSL Mode
	#wan mode is ATM
	qIfTypeActive=$QOS_INTF_WAN_ATM;
	DEF_UPSTREAM_RATE="1100"
	DEF_DOWNSTREAM_RATE="14000"
	BANDWIDTH_RATIO=80
	RATE_FOR_DOWNSTREAM_OTHERS="2000kbit"
	RATE_UNIT=kbit
	if [ -f /tmp/dsl_us_rate ]; then
		WAN_SPEED=`cat /tmp/dsl_us_rate`
	else
		WAN_SPEED=10
	fi
	WANNUM=1
    ;;
eth)
    wanphy_phymode=2 #MII1
    wanphy_tc=0

	TC_ACTION=2 #TC rules DELETE action input for TCP ACK Prio
	ADSL_MODE_ON=0
	#wan mode is MII1
	qIfTypeActive=$QOS_INTF_WAN_ETH_1;
	DEF_UPSTREAM_RATE="1048576"
	DEF_DOWNSTREAM_RATE="1048576"
	BANDWIDTH_RATIO=100
	RATE_FOR_DOWNSTREAM_OTHERS="1048300kbit"
	RATE_UNIT=kbit
	if [ -f /tmp/WAN_status ]; then
		WAN_SPEED=`cat /tmp/WAN_status | cut -d"/" -f1`
		case $WAN_SPEED in
		"1000M")
			WAN_SPEED=1000000
			;;
		"100M")
			WAN_SPEED=100000
			;;
		*)
			WAN_SPEED=10000
			;;
		esac
	else
		WAN_SPEED=10000
	fi
	WANNUM=
    ;;
vdsl)
    wanphy_phymode=3
    wanphy_tc=1 #PTM-TC

	TC_ACTION=2 #TC rules DELETE action input for TCP ACK Prio
	ADSL_MODE_ON=0
	#wan mode is PTM
	qIfTypeActive=$QOS_INTF_WAN_PTM;
	DEF_UPSTREAM_RATE="60000"
	DEF_DOWNSTREAM_RATE="100000"
	BANDWIDTH_RATIO=100
	RATE_FOR_DOWNSTREAM_OTHERS="99800kbit"
	RATE_UNIT=kbit
	if [ -f /tmp/dsl_us_rate ]; then
		WAN_SPEED=`cat /tmp/dsl_us_rate`
	else
		WAN_SPEED=10
	fi
	WANNUM=
    ;;
esac

#ACTUAL_UPSTREAM_RATE=$DEF_UPSTREAM_RATE
#ACTUAL_DOWNSTREAM_RATE=$DEF_DOWNSTREAM_RATE

# Initial QOS Rate #
preinit() {
	echo "QoS: start preinit"
	ACTUAL_UPSTREAM_RATE=$DEF_UPSTREAM_RATE
	ACTUAL_DOWNSTREAM_RATE=$DEF_DOWNSTREAM_RATE


	# read queue rates from file /tmp/ipqos_rates
	if [ "x$QOS_BW_CTL_ON" = "x1" ]; then
		ACTUAL_UPSTREAM_RATE=$QOS_UP_BW
		if [ "$ACTUAL_UPSTREAM_RATE" = "" ]; then
			ACTUAL_UPSTREAM_RATE=1000
		fi
	else
		if [ -f /tmp/ipqos_rates ]; then
			. /tmp/ipqos_rates
			#here these atm and ptm macros are kept since only adsl script can put these rates first. 
			#For wan ethernet, the rates are negotiated later at end of this script in qos_rate_update
			if [ ! -z $IPQOS_UP_RATE ]; then
				if [ $qIfTypeActive -eq $QOS_INTF_WAN_ATM -o  $qIfTypeActive -eq $QOS_INTF_WAN_PTM ]; then
					ACTUAL_UPSTREAM_RATE=$IPQOS_UP_RATE
				fi
			fi
			if [ ! -z $IPQOS_DOWN_RATE ]; then
				if [ $qIfTypeActive -eq $QOS_INTF_WAN_ATM -o  $qIfTypeActive -eq $QOS_INTF_WAN_PTM ]; then
					ACTUAL_DOWNSTREAM_RATE=$IPQOS_DOWN_RATE
				fi
			fi
		fi
	fi
	MAX_UPSTREAM_RATE_TMP=`expr $ACTUAL_UPSTREAM_RATE \* $BANDWIDTH_RATIO / 100`
	MAX_DOWNSTREAM_RATE_TMP=`expr $ACTUAL_DOWNSTREAM_RATE \* $BANDWIDTH_RATIO / 100`
	#$NVRAM set qos_bk_up_link_rate=$MAX_UPSTREAM_RATE_TMP
	#$NVRAM set qos_bk_down_link_rate=$MAX_DOWNSTREAM_RATE_TMP
	$NVRAM set qos_bk_queue_method=0

	MAX_UPSTREAM_RATE=`expr $ACTUAL_UPSTREAM_RATE \* $BANDWIDTH_RATIO / 100`$RATE_UNIT
	MAX_DOWNSTREAM_RATE=`expr $ACTUAL_DOWNSTREAM_RATE \* $BANDWIDTH_RATIO / 100`$RATE_UNIT

	#Update the QoS Flags
	#queuecfg -c 0/0
	#nvram set qos_bk_red_count=0
	#nvram set qos_bk_red_enable=0
	#nvram set qos_bk_mfc_count=$QOS_QUEUE_COUNTS
	#nvram set qos_bk_mfc_enable=1
	#nvram set qos_bk_dscp_count=0
	#nvram set qos_bk_dscp_enable=0
	#nvram set qos_bk_onep_count=0
	#nvram set qos_bk_onep_enable=0
	#nvram set qos_bk_queue_enable_count=4
	#nvram set qos_bk_queue_type=0
	#nvram set qos_bk_sum_cr=0
	#nvram set qos_bk_sum_pr=0
	#nvram set qos_bk_sum_wt=0
	#Update the Rates
	#queuecfg -r 0/0

	#Call to make TCP ACK Prioritization when QOS is disabled
	#if [ $ADSL_MODE_ON -eq 1 -a $qos_threshold -eq 0 -a $qm_tcpackprio -eq 1 ]; then
	#    . /etc/rc.d/ipqos_tcp_ack_prio $TC_ACTION
	#fi
	if [ -f "/var/run/qos_rate_update.pid" ]; then
        kill -9 `cat /var/run/qos_rate_update.pid`
        rm -f /var/run/qos_rate_update.pid
		rm -rf /tmp/ipqos_rates
    fi

	#Update the negotiated rates
	if [ "x$QOS_BW_CTL_ON" != "x1" ]; then
		#qos_rate_update &
		rate_update $WAN_SPEED $WAN_SPEED
		sleep 2
	fi
}

q_init(){
	# read queue rates from file /tmp/ipqos_rates
	if [ "x$QOS_BW_CTL_ON" = "x1" ]; then
		ACTUAL_UPSTREAM_RATE=$QOS_UP_BW
		if [ "$ACTUAL_UPSTREAM_RATE" = "" ]; then
			ACTUAL_UPSTREAM_RATE=1000
		fi
	else
		if [ -f /tmp/ipqos_rates ]; then
			. /tmp/ipqos_rates
			if [ ! -z $IPQOS_UP_RATE ]; then
				ACTUAL_UPSTREAM_RATE=$IPQOS_UP_RATE
	    	fi
		    if [ ! -z $IPQOS_DOWN_RATE ]; then
				ACTUAL_DOWNSTREAM_RATE=$IPQOS_DOWN_RATE
			fi
		fi
	fi
	MAX_UPSTREAM_RATE_TMP=`expr $ACTUAL_UPSTREAM_RATE \* $BANDWIDTH_RATIO / 100`
	MAX_DOWNSTREAM_RATE_TMP=`expr $ACTUAL_DOWNSTREAM_RATE \* $BANDWIDTH_RATIO / 100`
	#$NVRAM set qos_bk_up_link_rate=$MAX_UPSTREAM_RATE_TMP
	#$NVRAM set qos_bk_down_link_rate=$MAX_DOWNSTREAM_RATE_TMP
	MAX_UPSTREAM_RATE=`expr $ACTUAL_UPSTREAM_RATE \* $BANDWIDTH_RATIO / 100`$RATE_UNIT
	MAX_DOWNSTREAM_RATE=`expr $ACTUAL_DOWNSTREAM_RATE \* $BANDWIDTH_RATIO / 100`$RATE_UNIT

	QUEUE_METHOD=`$NVRAM get qos_bk_queue_method`
	wanmode=${wanphy_phymode}
	WAN_IFNAME=`$NVRAM get wan${WANNUM}_ifname`
	iface=${WAN_IFNAME}
	#########################################Upstream - Queuing##########################################
	if [ "$QUEUE_METHOD" = "1" ]; then
		#Upstream Q Dev varies based on VLAN-Enabled or VLAN-Disabled
		#TBD: Select imq0 or individual device based on VLAN Enable field.
		UPSTREAM_Q_DEV=${iface} #imq0

		# Enable the imq device
		#ifconfig $UPSTREAM_Q_DEV up

		#create a root htb queue on UPSTREAM_Q_DEV device
		C_CMD="tc qdisc add dev $UPSTREAM_Q_DEV root handle 1: htb default 43"
		echo $C_CMD
		$C_CMD
		#Attach one class to root queue
		PORT_RATE=$ACTUAL_UPSTREAM_RATE$RATE_UNIT
		C_CMD="tc class add dev $UPSTREAM_Q_DEV parent 1: classid 1:1 htb rate $PORT_RATE"
		echo $C_CMD
		$C_CMD

		#if [ $qIfTypeActive -eq $QOS_INTF_WAN_ATM -a $wanmode -eq 0 ]; then #ADSL
		#	iptables -t mangle -nvL POSTROUTING | grep  ${iface}
		#	if [ $? -ne 0 ]; then
		#		C_CMD="iptables -t mangle -A POSTROUTING -o ${iface} -j IMQ --todev 0"
		#		echo "$C_CMD"
		#		$C_CMD
		#	fi
		#fi
	fi
	if [ $QUEUE_METHOD -eq 2 ]; then
		if [ $qIfTypeActive -eq $QOS_INTF_WAN_PTM ]; then
			PORT=7
		fi
		if [ $qIfTypeActive -eq $QOS_INTF_WAN_ETH_1 ]; then
			PORT=1
		fi
		#initialize PTM FW queues
		ppacmd setctrlwfq -p $PORT -c enable
		ppacmd setctrlrate -p $PORT -c enable
		PORT_RATE=$ACTUAL_UPSTREAM_RATE
		ppacmd setrate -p $PORT -r $PORT_RATE
		#QUEUE_TYPE=`/usr/sbin/nvram get qos_bk_queue_type`
		ppacmd setwfq -p $PORT -q 0 -w 100
		ppacmd setwfq -p $PORT -q 1 -w 100
		ppacmd setwfq -p $PORT -q 2 -w 100
		ppacmd setwfq -p $PORT -q 3 -w 100
		ppacmd setwfq -p $PORT -q 4 -w 100
		ppacmd setwfq -p $PORT -q 5 -w 100
		ppacmd setwfq -p $PORT -q 6 -w 100
		ppacmd setwfq -p $PORT -q 7 -w 100
		echo eth1 prio 0 queue 7 prio 1 queue 6 prio 2 queue 5 prio 3 queue 4 prio 4 queue 3 prio 5 queue 2 prio 6 queue 1 prio 7 queue 0 > /proc/eth/prio 1> /dev/null
	fi
	if [ $QUEUE_METHOD -eq 3 ]; then
		#initialize eth wan queues
		#Port Cfg to classify based on PCP or DSCP
		switch_utility QOS_PortCfgSet 6 2 0

		#For port 5 queues 20-23 are allocated, utilize queues 28-31 which are PTM queues not used in Eth1 mode.
		switch_utility QOS_QueuePortSet 20 5 0
		switch_utility QOS_QueuePortSet 21 5 1
		switch_utility QOS_QueuePortSet 22 5 2
		switch_utility QOS_QueuePortSet 23 5 3

		switch_utility QOS_QueuePortSet 28 5 4
		switch_utility QOS_QueuePortSet 29 5 5
		switch_utility QOS_QueuePortSet 30 5 6
		switch_utility QOS_QueuePortSet 31 5 7

		#disable flow control on port 6
		switch_utility RegisterSet 0x94b 0x1c0
		#Additional regiseter set to achieve SP.
		switch_utility RegisterSet 0x4A 0x118
		#PCP (802.1p) to queue assignment
		#<Index(802.1p)><traffic class>
		switch_utility QOS_PcpClassSet 0 0
		switch_utility QOS_PcpClassSet 1 1
		switch_utility QOS_PcpClassSet 2 2
		switch_utility QOS_PcpClassSet 3 3
		switch_utility QOS_PcpClassSet 4 4
		switch_utility QOS_PcpClassSet 5 5
		switch_utility QOS_PcpClassSet 6 6
		switch_utility QOS_PcpClassSet 7 7

		#If Sched type of queues is SP set queues 0-3;12-15=0xffff
		echo " init queues to 0xffff"   
		for i in 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31; do
			switch_utility QOS_SchedulerCfgSet $i 0 0xffff
		done
		# Re-Setting egress cos map for mii1 interfaces 
		#wan_index=`echo $wan_main_index | tr ',' ' '`
		#for i in $wan_index
		#do
		#	eval wanmode='$'wan_${i}_wanMode
		#	# perform mapping only if wanmode is mii0
		#	if [ $wanmode -eq 2 ]; then
		#		eval vlan='$'wan_${i}_vlanId

		#		#reset egress cos map
		#		vconfig set_egress_map eth1.$vlan 0 0
		#		vconfig set_egress_map eth1.$vlan 1 0
		#		vconfig set_egress_map eth1.$vlan 2 0
		#		vconfig set_egress_map eth1.$vlan 3 0
		#		vconfig set_egress_map eth1.$vlan 4 0
		#		vconfig set_egress_map eth1.$vlan 5 0
		#		vconfig set_egress_map eth1.$vlan 6 0
		#		vconfig set_egress_map eth1.$vlan 7 0
		#	fi
		#done
fi
	#########################################Upstream - Queuing##########################################
}

init(){
	echo "QoS: start init"
	#ACTUAL_UPSTREAM_RATE=$DEF_UPSTREAM_RATE
	#ACTUAL_DOWNSTREAM_RATE=$DEF_DOWNSTREAM_RATE
	#########################################Common##########################################
	# Get the path of the imq kernel module. Insert the imq kernel module #
	insmod /lib/modules/*/imq.ko

	qos_bk_red_enable=0
	qos_bk_mfc_enable=1
	qos_bk_class_rate_limit_enb=0
	#Update Flags
	#queuecfg -u 0/0
	#Update Rates
	#queuecfg -r 0/0

	#Set queuing method as none
	if [ "`$NVRAM get qos_bk_queue_method`" = "" ]; then
		$NVRAM set qos_bk_queue_method=0
	fi
	#########################################Common##########################################

	##########################################Upstream - Queuing##########################################
	# Creating chain IPQOS_QUEUE_MAP that will be used to add the Queue CpeId to Priority Mapping
	iptables -t mangle -N IPQOS_QUEUE_MAP

	qos_bk_queuing_mode=1
	#qos_bk_port_shaping_enable=0
	i=1
	while [ $i -le $QOS_QUEUE_COUNTS ]
	do 
		q_mgmt $i 0
		i=$(( $i + 1 ))
	done
	q_disable

	if [ $qIfTypeActive -eq $QOS_INTF_WAN_PTM ]; then
		# If red is enabled and platform is not VR9 then SW.
		# Also since port shaping is not supported in VRX-PTM FW, we will move to software.
		if [ $class_rate_limit_enb -eq 1 -o $port_shaping_enable -eq 1 ]; then
		    #echo "Disable Routed Acceleration, Disable Bridged Acceleration"
			#ppacmd control --disable-lan --disable-wan
			echo "PTM: Disabling Routed & Disabling Bridged Acceleration"
			# Set sw queuing method for all queues
			echo "Setting Queuing Method to Software"
			$NVRAM set qos_bk_queue_method=1
    	else
			#echo "QOS_INTF_WAN_PTM, not rate limit."
			#echo "Enable Routed Acceleration, Enable Bridged Acceleration"
			#ppacmd control --enable-lan --enable-wan
			# Set PPE FW  queuing method for all queues
			echo "PTM: Enabling Routed & Enabling Bridged Acceleration"
			# Set sw queuing method for mgmt traffic
			#echo "Setting Queuing Method to PPE FW"
			$NVRAM set qos_bk_queue_method=2
		fi
	fi
	if [ $qIfTypeActive -eq $QOS_INTF_WAN_ETH_1 ]; then
		if [ $qos_bk_class_rate_limit_enb -eq 0 ]; then
			if [ "$PPE_FIRMWARE" = "A5" ] || [ "$PPE_FIRMWARE" = "D5" ]; then
				#echo "Enable Routed Acceleration, Enable Bridged Acceleration */
				#ppacmd control --enable-lan --enable-wan
				echo "ETH: Enabling Routed & Enabling Bridged Acceleration"
				# Set HW GigFlow  queuing method for all queues
				# Set sw queuing method for mgmt traffic
				echo "Setting Queuing Method to HW GigFlow"
				$NVRAM set qos_bk_queue_method=3
			else
				if [ $qos_bk_red_enable -eq 1 ]; then
					#echo "Disable Routed Acceleration, Disable Bridged Acceleration"
					#ppacmd control --disable-lan --enable-wan
					echo "ETH: Disabling Routed & Disabling Bridged Acceleration"
					# Enable sw queuing method for all queues
					#"Setting Queuing Method to Software"
					$NVRAM set qos_bk_queue_method=1
				else
					#echo "Enable Routed Acceleration, Enable Bridged Acceleration"
					#ppacmd control --enable-lan --enable-wan
					echo "ETH: Enabling Routed & Enabling Bridged Acceleration"
					# Set PPE FW  queuing method for all queues
					# Set sw queuing method for mgmt traffic
					echo "Setting Queuing Method to PPE FW"
					$NVRAM set qos_bk_queue_method=2
				fi
			fi
		else
			if [ $qos_bk_red_enable -eq 1 -o $qos_bk_class_rate_limit_enb -eq 1 -o "$PPE_FIRMWARE" = "E5" ]; then
				# Disable Routed Acceleration, Disable Bridged Acceleration
				#ppacmd control --disable-lan --enable-wan
				echo "ETH: Disabling Routed & Disabling Bridged Acceleration"
				# Set sw queuing method for all queues
				echo "Setting Queuing Method to Software"
				$NVRAM set qos_bk_queue_method=1
			else
			    # Enable Routed Acceleration
				#ppacmd control --enable-lan --enable-wan
				if [ $qos_bk_mfc_enable -eq 1 ]; then
					# Disable Bridged Acceleration */
					echo "ETH: Enabling Routed & Disabling Bridged Acceleration - Not Proper"
					# TBD: Remove wan bridge interface from ppa
				else
					# Enable Bridged Acceleration
					echo "Enabling Routed & Enabling Bridged Acceleration"
					# TBD: Add wan bridge interface from ppa
				fi
				# Set PPE FW  queuing method for all queues */
				# Set sw queuing method for mgmt traffic */
				echo "Setting Queuing Method to PPE FW"
				$NVRAM set qos_bk_queue_method=2
			fi
		fi
	fi

	if [ $qIfTypeActive -eq $QOS_INTF_WAN_ATM ]; then
		if [ $qos_bk_queuing_mode -eq 1 -o $qos_bk_class_rate_limit_enb -eq 1 ]; then
			# Disable Routed Acceleration, Disable Bridged Acceleration 
			#ppacmd control --disable-lan --enable-wan
			echo "ATM: Disabling Routed & Disabling Bridged Acceleration"
			# Set sw queuing method for all queues
			echo "Setting Queuing Method to Software"
			$NVRAM set qos_bk_queue_method=1
		else
			#TBD: Will be done later
			echo "Not handled yet"
		fi
	fi

	# Enable the Required queuing method 
	echo "Initializing Queues(method:`$NVRAM get qos_bk_queue_method`)"
	q_init

	i=1
	while [ $i -le $QOS_QUEUE_COUNTS ]
	do
		q_mgmt $i 1
		i=$(( $i + 1 ))
	done 
	# Updating classinfo into the qdisc for QOS Rate Limiting */	
	#update_qdisc_scaning_classinfo(&qos_queues[i]);		
	#queuecfg -q 0/0
	#########################################Upstream - Queuing##########################################

	#########################################Upstream - Classification##########################################
	# Create chains and add default rules
	# Creating chain INPUT_INTF_CHECK
	iptables -t mangle -N INPUT_INTF_CHECK
	#TBD: The INPUT_INTF_CHECK chain should be created by the system if it is to be used for purposes other than QOS.

	# Add rules in INPUT_INTF_CHECK chain
	iptables -t mangle -A INPUT_INTF_CHECK -i br+ -j MARK --set-mark 0x40000000
	# TBD: all bring up/down scripts should add/delete appropriate mark based on LAN and WAN 

	# Add a rule to jump to INPUT_INTF_CHECK
	#iptables -t mangle -I PREROUTING 1 -j INPUT_INTF_CHECK 
	iptables -t mangle -A PREROUTING -j INPUT_INTF_CHECK

	# Creating chain IPQOS_LAN_ING
	iptables -t mangle -N IPQOS_LAN_ING

	#Add a rule to jump to IPQOS_LAN_ING if input interface is LAN
	iptables -t mangle -A PREROUTING -m mark --mark 0x40000000 -j IPQOS_LAN_ING
	# TBD: current support only for taffic generated from LAN. Seperate mark required for WAN.

	# Creating chain IPQOS_LAN_DSCP_ALL
	iptables -t mangle -N IPQOS_LAN_DSCP_ALL

	## Testing DSCP ##
	#iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x1 -j MARK --set-mark 0x01
	#iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x2 -j MARK --set-mark 0x02
	#iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x3 -j MARK --set-mark 0x03
	#iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x4 -j MARK --set-mark 0x04

	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x38 -j MARK --set-mark 0x01
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x30 -j MARK --set-mark 0x01
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m mark --mark 0x01 -j IPQOS_QUEUE_MAP
	
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x2E -j MARK --set-mark 0x02
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x28 -j MARK --set-mark 0x02
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x20 -j MARK --set-mark 0x02
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x26 -j MARK --set-mark 0x02
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x24 -j MARK --set-mark 0x02
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x22 -j MARK --set-mark 0x02
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x20 -j MARK --set-mark 0x02
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m mark --mark 0x02 -j IPQOS_QUEUE_MAP

	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x1E -j MARK --set-mark 0x03
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x1C -j MARK --set-mark 0x03
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x1A -j MARK --set-mark 0x03
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x18 -j MARK --set-mark 0x03
	#iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x00 -j MARK --set-mark 0x03
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m mark --mark 0x03 -j IPQOS_QUEUE_MAP

	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x16 -j MARK --set-mark 0x04
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x14 -j MARK --set-mark 0x04
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x12 -j MARK --set-mark 0x04
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x10 -j MARK --set-mark 0x04
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x0E -j MARK --set-mark 0x04
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x0C -j MARK --set-mark 0x04
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x0A -j MARK --set-mark 0x04
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m dscp --dscp 0x08 -j MARK --set-mark 0x04
	iptables -t mangle -A IPQOS_LAN_DSCP_ALL -m mark --mark 0x04 -j IPQOS_QUEUE_MAP

	#Add a rule to jump to IPQOS_LAN_DSCP_ALL after processing all the MFC
	iptables -t mangle -A IPQOS_LAN_ING -j IPQOS_LAN_DSCP_ALL

	# Creating chain IPQOS_OUTPUT
	#iptables -t mangle -N IPQOS_OUTPUT

	# Creating chain IPQOS_OUTPUT_DSCP_ALL
	#iptables -t mangle -N IPQOS_OUTPUT_DSCP_ALL

	#Add a rule to jump to IPQOS_OUTPUT_DSCP_ALL after processing all the MFC
	#iptables -t mangle -A IPQOS_OUTPUT -j IPQOS_OUTPUT_DSCP_ALL

	# Following lines will create classifier rules using iptables utility
	# add the classifiers from rc.conf
	class_add

	#Initialize HW Classifiers
	echo "QoS: Configuring HW Classifiers"
	#queuecfg -s 0/0

	# Creating chain IPQOS_OUTPUT_MAP
	#iptables -t mangle -N IPQOS_OUTPUT_MAP
	#iptables -t mangle -F IPQOS_OUTPUT_MAP

    prio_mod1=$(( $LTQ_QUEUE_COUNTS<<6 ))
   	prio_mod2=$(( ($LTQ_QUEUE_COUNTS -1) << 6 ))
	#iptables -t mangle -A IPQOS_OUTPUT_MAP -m mark --mark 0xffffff1 -j MARK --set-mark $prio_mod1
	#iptables -t mangle -A IPQOS_OUTPUT_MAP -m mark --mark 0xffffff2 -j MARK --set-mark $prio_mod2
	#iptables -t mangle -A IPQOS_OUTPUT_MAP -m mark --mark $prio_mod2 -j ACCEPT
	#queuecfg -p 0/0

	# Add rules to the OUTPUT chain
	# Add a rule to jump to IPQOS_OUTPUT for locally generated traffic
	#iptables -t mangle -A OUTPUT -j IPQOS_OUTPUT
	#iptables -t mangle -A OUTPUT -j IPQOS_LAN_ING
	#########################################Upstream - Classification##########################################

	####################################Downstream - Queuing, Classification####################################
	# Enable the imq device
	#ifconfig imq1 up

	# Create a root htb queue on imq1 device
	#tc qdisc add dev imq1 root handle 1: htb
	#tc class add dev imq1 parent 1: classid 1:1 htb rate $MAX_DOWNSTREAM_RATE
	# Traffic sub class for normal wan traffic
	#tc class add dev imq1 parent 1:1 classid 1:41 htb rate $RATE_FOR_DOWNSTREAM_OTHERS ceil $MAX_DOWNSTREAM_RATE prio 2
	#tc qdisc add dev imq1 parent 1:41 handle 41: bfifo limit 100k
	#tc filter add dev imq1 protocol ip parent 1:0 prio 1 handle 0xffffff5 fw classid 1:41

	# Creating chain IPQOS_PREROUTE_SYSTEM
	#iptables -t mangle -N IPQOS_PREROUTE_SYSTEM
	# Add a rule to jump to IPQOS_PREROUTE_SYSTEM chain for wan traffic
	#iptables -t mangle -A PREROUTING -m mark ! --mark 0x40000000 -j IPQOS_PREROUTE_SYSTEM
	# map normal wan traffic to imq1
	#iptables -t mangle -A IPQOS_PREROUTE_SYSTEM -j MARK --set-mark 0xffffff5
	#iptables -t mangle -A IPQOS_PREROUTE_SYSTEM -j IMQ --todev 1
	#iptables -t mangle -A IPQOS_PREROUTE_SYSTEM -j ACCEPT
	####################################Downstream - Queuing, Classification####################################

	#########################################Default Rules - Classification##########################################
	# Following lines will create  default classifier rules for Local traffic
	# Create a default classifier chain for LAN traffic
	iptables -t mangle -N PREROUTE_DEFAULT

	# Make a jump to PREROUTE_DEFAULT chain from IPQOS_LAN_ING for unclassified LAN traffic
	iptables -t mangle -A PREROUTING -j PREROUTE_DEFAULT

	# Create a default classifier chain for Local traffic
	#iptables -t mangle -N OUTPUT_DEFAULT

	# Make a jump to OUTPUT_DEFAULT chain from IPQOS_OUTPUT for unclassified Local traffic
	#iptables -t mangle -A IPQOS_OUTPUT -j OUTPUT_DEFAULT

	# Add the rules to DEFAULT chains
	mgmt
	#########################################Default Rules Classification##########################################

	#########################################Post Initialization########################################
	# ipqos init is completed. Indicate this in file /tmp/ipqos/init_status
	echo "IPQOS_INIT_STATUS=\"1\"" > /tmp/ipqos_init_status

	# call script to configure iptables rules for web management traffic
	# remove iptables rules if already present and then configure
	#. /etc/rc.d/ipqos_mgmt_traffic_config web stop
	#. /etc/rc.d/ipqos_mgmt_traffic_config web start

	# Call ipqos_rate_change script if rates are changed
	# Nothing to do if rates are not changed
	INVOKE_RATE_UPDATE=0
	if [ -f /tmp/ipqos_rates ]; then
		if [ "$QOS_BW_CTL_ON" = "x0" ]; then
			. /tmp/ipqos_rates
			if [ ! -z $IPQOS_UP_RATE ]; then
				if [ $IPQOS_UP_RATE != $ACTUAL_UPSTREAM_RATE ]; then
					ACTUAL_UPSTREAM_RATE=$IPQOS_UP_RATE
					INVOKE_RATE_UPDATE=1
				fi
					if [ ! -z $IPQOS_DOWN_RATE ]; then
					if [ $IPQOS_DOWN_RATE != $ACTUAL_DOWNSTREAM_RATE ]; then
						ACTUAL_DOWNSTREAM_RATE=$IPQOS_DOWN_RATE
						INVOKE_RATE_UPDATE=1
					fi
				fi
			fi
		fi
		if [ $INVOKE_RATE_UPDATE = 1 ]; then
			# rates are changed
			rate_update $ACTUAL_UPSTREAM_RATE $ACTUAL_DOWNSTREAM_RATE
		fi
	fi
	##########################################Post Initialization########################################
}


q_disable(){
	echo "QoS: q_disable start"

	QUEUE_METHOD=`$NVRAM get qos_bk_queue_method`
	#qm_upPortRateLim=`/usr/sbin/nvram get qm_upPortRateLim`
	wanmode=$wanphy_phymode
	WAN_IFNAME=`$NVRAM get wan${WANNUM}_ifname`
	iface=${WAN_IFNAME}

	#echo "QUEUE_METHOD is $QUEUE_METHOD"
	#echo "qIfTypeActive is $qIfTypeActive"
	####################################Upstream Queues########################################
	if [ "x$QUEUE_METHOD" = "x1" ]; then
		#Upstream Q Dev varies based on VLAN-Enabled or VLAN-Disabled
		#TBD: Select imq0 or individual device based on VLAN Enable field.
		UPSTREAM_Q_DEV=${iface} #imq0
		tc qdisc del dev $UPSTREAM_Q_DEV root handle 1: htb
	
		#if [ $qIfTypeActive -eq $QOS_INTF_WAN_ATM -a $wanmode -eq 0 ]; then
		#	iptables -t mangle -nvL POSTROUTING | grep  ${iface}
		#	if [ $? -eq 0 ]; then
		#		iptables -t mangle -D POSTROUTING -o ${iface} -j IMQ --todev 0
		#	fi
		#fi
	    # make interface device
    	#ifconfig $UPSTREAM_Q_DEV down

	    #enable PPA if PPA is supported
		#CMD="ppacmd control --enable-lan --enable-wan"
		#echo $CMD
		$CMD
	fi
	if [ "x$QUEUE_METHOD" = "x2" ]; then
		echo "diable QUEUE_METHOD 2"
		if [ $qIfTypeActive -eq $QOS_INTF_WAN_PTM ]; then
			PORT=7
		fi
		if [ $qIfTypeActive -eq $QOS_INTF_WAN_ETH_1 ]; then
			PORT=1
		fi
		#disable PTM FW queues
		ppacmd setctrlwfq -p $PORT -c disable
		ppacmd setctrlrate -p $PORT -c disable

		#QUEUE_TYPE=`nvram get qos_bk_queue_type`
		ppacmd setwfq -p $PORT -q 0 -w 100
		ppacmd setwfq -p $PORT -q 1 -w 100
		ppacmd setwfq -p $PORT -q 2 -w 100
		ppacmd setwfq -p $PORT -q 3 -w 100
		ppacmd setwfq -p $PORT -q 4 -w 100
		ppacmd setwfq -p $PORT -q 5 -w 100
		ppacmd setwfq -p $PORT -q 6 -w 100
		ppacmd setwfq -p $PORT -q 7 -w 100

		echo eth1 prio 0 queue 1 prio 1 queue 1 prio 2 queue 1 prio 3 queue 1 prio 4 queue 1 prio 5 queue 1 prio 6 queue 1 prio 7 queue 0 > /proc/eth/prio 1> /dev/null
	fi
	if [ "x$QUEUE_METHOD" = "x3" ]; then
		#disable GRx switch queue config
		switch_utility QOS_PortCfgSet 6 0 0

		#For port 0 queues 0-3 are de-allocated in Eth1 mode.
		switch_utility QOS_QueuePortSet 28 7 0
		switch_utility QOS_QueuePortSet 29 7 1
		switch_utility QOS_QueuePortSet 30 7 2
		switch_utility QOS_QueuePortSet 31 7 3
		#enable flow control on port 6(default state)
		switch_utility PortCfgSet 6 1 0 0 0 0 0 0 255 0 0

		#deallocate PCP-Class assignment
		switch_utility QOS_PcpClassSet 0 0
		switch_utility QOS_PcpClassSet 1 0
		switch_utility QOS_PcpClassSet 2 1
		switch_utility QOS_PcpClassSet 3 1
		switch_utility QOS_PcpClassSet 4 2
		switch_utility QOS_PcpClassSet 5 2
		switch_utility QOS_PcpClassSet 6 3
		switch_utility QOS_PcpClassSet 7 3

	    #reset queues 0-3,28-31 to default state
	    #If Sched type of queues is SP set queues 0-3;12-15=0xffff
        #echo " init queues to 0xffff"   
        for i in 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31; do
            switch_utility QOS_SchedulerCfgSet $i 0 0xffff
        done
	    # Re-Setting egress cos map for mii1 interfaces 
		#wan_index=`echo $wan_main_index | tr ',' ' '`
		#for i in $wan_index
		#do
		#	eval wanmode='$'wan_${i}_wanMode
		#	# perform mapping only if wanmode is mii0
		#	if [ $wanmode -eq 2 ]; then
		#		eval vlan='$'wan_${i}_vlanId

		#		#reset egress cos map
		#		vconfig set_egress_map eth1.$vlan 0 0
		#		vconfig set_egress_map eth1.$vlan 1 0
		#		vconfig set_egress_map eth1.$vlan 2 0
		#		vconfig set_egress_map eth1.$vlan 3 0
		#		vconfig set_egress_map eth1.$vlan 4 0
		#		vconfig set_egress_map eth1.$vlan 5 0
		#		vconfig set_egress_map eth1.$vlan 6 0
		#		vconfig set_egress_map eth1.$vlan 7 0
		#	fi
		#done
	fi
	#Set queuing method as none
	$NVRAM set qos_bk_queue_method=0
}

disable(){
	echo "QoS: disable start"

	if [ -e /tmp/ipqos_init_status ]; then
		. /tmp/ipqos_init_status
		if [ -z "$IPQOS_INIT_STATUS" ] || [ "x$IPQOS_INIT_STATUS" = "x0" ]; then
			echo "QoS: No QoS queue in iptables, bye!"
			return
		fi
	else
		echo "QoS: No QoS queue in iptables, bye!"
		return
	fi


	####################################Upstream Classifiers########################################
	# Flush the chains for default classifier rules
	iptables -t mangle -F PREROUTE_DEFAULT
	#iptables -t mangle -F OUTPUT_DEFAULT
	# Remove the references to the default classifier chains from PREROUTING and IPQOS_OUTPUT
	iptables -t mangle -D PREROUTING -j PREROUTE_DEFAULT
	#iptables -t mangle -D IPQOS_OUTPUT -j OUTPUT_DEFAULT
    # Flush IPQOS_LAN_ING chain
	iptables -t mangle -F IPQOS_LAN_ING
    # Flush IPQOS_OUTPUT chain
	#iptables -t mangle -F IPQOS_OUTPUT
    # Flush IPQOS_QUEUE_MAP chain
	iptables -t mangle -F IPQOS_QUEUE_MAP
    # Flush IPQOS_LAN_DSCP_ALL chain
	iptables -t mangle -F IPQOS_LAN_DSCP_ALL
    # Flush IPQOS_OUTPUT_DSCP_ALL chain
	#iptables -t mangle -F IPQOS_OUTPUT_DSCP_ALL
	# Flush & deletet IPQOS_OUTPUT_MAP
	#iptables -t mangle -F IPQOS_OUTPUT_MAP
	#iptables -t mangle -X IPQOS_OUTPUT_MAP
	# Flush the INPUT_INTF_CHECK chain
	# TBD: Should be done by system shutdown script if this chain is using for purpose other than QoS
	iptables -t mangle -F INPUT_INTF_CHECK
	# Remove references to IPQOS_LAN_ING from PREROUTING chain
	iptables -t mangle -D PREROUTING -m mark --mark 0x40000000 -j IPQOS_LAN_ING
	# Remove references to IPQOS_OUTPUT from OUTPUT chain
	#iptables -t mangle -D OUTPUT -j IPQOS_OUTPUT
	iptables -t mangle -D OUTPUT -j IPQOS_LAN_ING

	# flush and delete all the chains created for adding the classifier rules
	i=1
	while [ "x$($NVRAM get qos_list$i)" != "x" ]
	do
		# Flush and delete all classifier chains created for LAN traffic
		QOS_CHAIN="LAN_$i"
		iptables -t mangle -F $QOS_CHAIN
		iptables -t mangle -X $QOS_CHAIN
		# Flush and delete all classifier chains created for Local traffic
		#QOS_CHAIN="OUTPUT_$i"
		#iptables -t mangle -F $QOS_CHAIN
		#iptables -t mangle -X $QOS_CHAIN
		i=$(( $i + 1 ))
	done

	# Flush and delete IPQOS_LAN_DSCP_ALL
	QOS_CHAIN="IPQOS_LAN_DSCP_ALL"
	iptables -t mangle -F $QOS_CHAIN
	iptables -t mangle -X $QOS_CHAIN
	# Flush and delete IPQOS_OUTPUT_DSCP_ALL
	#QOS_CHAIN="IPQOS_OUTPUT_DSCP_ALL"
	#iptables -t mangle -F $QOS_CHAIN
	#iptables -t mangle -X $QOS_CHAIN

	i=1
	while [ $i -le $QOS_QUEUE_COUNTS ]
	do
		QOS_CHAIN="IPQOS_QUEUE_$i"
		# Flush and delete all queue priority chains
		iptables -t mangle -F $QOS_CHAIN
		iptables -t mangle -X $QOS_CHAIN
		i=$(( $i + 1 ))
	done

	# Delete the the INPUT_INTF_CHECK chain form the system
	# TBD: Should be done by system shutdown script if this this chain is using for purpose other than QoS

	# Need to be recovered later 
	iptables -t mangle -D PREROUTING -j INPUT_INTF_CHECK
	iptables -t mangle -X INPUT_INTF_CHECK
	# Delete IPQOS_LAN_ING chain from the system
	iptables -t mangle -X IPQOS_LAN_ING
	# Delete IPQOS_OUTPUT chain from the system
	#iptables -t mangle -X IPQOS_OUTPUT
	# Delete IPQOS_QUEUE_MAP chain from the system
	iptables -t mangle -X IPQOS_QUEUE_MAP

	# Delete default classifier rule chains fom the system
	iptables -t mangle -X PREROUTE_DEFAULT
	#iptables -t mangle -X OUTPUT_DEFAULT


	#Disable HW Classifiers
	echo "QoS: Configuring HW Classifiers disable"
	#queuecfg -t 0/0
	####################################Upstream Classifiers########################################
	####################################Downstream Classifiers########################################

	# delete the chain added for wan traffic
	#iptables -t mangle -D PREROUTING -m mark ! --mark 0x40000000 -j IPQOS_PREROUTE_SYSTEM
	#iptables -t mangle -F IPQOS_PREROUTE_SYSTEM
	#iptables -t mangle -X IPQOS_PREROUTE_SYSTEM
	####################################Downstream Classifiers########################################

	####################################Upstream Queues########################################
	#Disable the queues
	q_disable
	####################################Upstream Queues########################################

	############################Disable Downstream Queues######################################
	# Remove the traffic queues added for SIP, RTP traffic on downstream direction
	#tc qdisc del dev imq1 root handle 1: htb
	# make imq1 interface down
	#ifconfig imq1 down
	# Remove IMQ Module
	#rmmod imq
	############################Disable Downstream Queues######################################

	####################################Post Disabling########################################
	# Mark as qos disabled in /tmp/ipqos_init_status
	echo "IPQOS_INIT_STATUS=\"0\"" > /tmp/ipqos_init_status

	if [ -f "/var/run/qos_rate_update.pid" ]; then
        kill -9 `cat /var/run/qos_rate_update.pid`
        rm -f /var/run/qos_rate_update.pid
    fi
}

rate_update(){
	echo "QoS: rate_update start."

	if [ "x$QOS_BW_CTL_ON" = "x0" ]; then
		case "$wanphy_phymode" in
    	0) #ADSL(0,A5)
	        TC_ACTION=1 #TC rules CHANGE action for TCP ACK Prio
			ADSL_MODE_ON=1  #Denotes ADSL Mode
			ACTUAL_UPSTREAM_RATE="$1"
	        ACTUAL_DOWNSTREAM_RATE="$2"
			;;
		*) #ETH(2,D5) or VDSL(3,E5)
			ADSL_MODE_ON=0
			ACTUAL_UPSTREAM_RATE="$1"
	        ACTUAL_DOWNSTREAM_RATE="$2"
			;;
		esac
		DOWNSTREAM_BW_RESERVED_HIGHPRIO=200
		#RATE_FOR_DOWNSTREAM_OTHERS=`expr $ACTUAL_DOWNSTREAM_RATE - $DOWNSTREAM_BW_RESERVED_HIGHPRIO`$RATE_UNIT
		RATE_FOR_DOWNSTREAM_OTHERS=`expr $ACTUAL_DOWNSTREAM_RATE - $DOWNSTREAM_BW_RESERVED_HIGHPRIO`

		#echo "Rate update: up rate = $ACTUAL_UPSTREAM_RATE"
		#echo "Rate update: down rate = $ACTUAL_DOWNSTREAM_RATE"
		# Run ipqos tem scripts
		if [ -f /tmp/ipqos_init_status ]; then
			. /tmp/ipqos_init_status
		fi
		# write rates to file
		echo "IPQOS_UP_RATE=\"$ACTUAL_UPSTREAM_RATE\"" > /tmp/ipqos_rates
		echo "IPQOS_DOWN_RATE=\"$ACTUAL_DOWNSTREAM_RATE\"" >> /tmp/ipqos_rates
		MAX_UPSTREAM_RATE_TMP=`expr $ACTUAL_UPSTREAM_RATE \* $BANDWIDTH_RATIO / 100`
		MAX_DOWNSTREAM_RATE_TMP=`expr $ACTUAL_DOWNSTREAM_RATE \* $BANDWIDTH_RATIO / 100`
		#$NVRAM set qos_bk_up_link_rate=$MAX_UPSTREAM_RATE_TMP
		#$NVRAM set qos_bk_down_link_rate=$MAX_DOWNSTREAM_RATE_TMP
	
		MAX_UPSTREAM_RATE=`expr $ACTUAL_UPSTREAM_RATE \* $BANDWIDTH_RATIO / 100`$RATE_UNIT
		MAX_DOWNSTREAM_RATE=`expr $ACTUAL_DOWNSTREAM_RATE \* $BANDWIDTH_RATIO / 100`$RATE_UNIT
		RATE_FOR_DOWNSTREAM_OTHERS=`expr $RATE_FOR_DOWNSTREAM_OTHERS \* $BANDWIDTH_RATIO / 100`$RATE_UNIT

		#Update Flags
		#queuecfg -u 0/0
		#Update Rates
		#queuecfg -r 0/0


		#Call 'ipqos_tcp_ack_prio' to change TC HTB hierarchy rates for TCP ACK Prioritization
		#if [ $ADSL_MODE_ON -eq 1 -a $qm_enable -eq 0 -a $qm_tcpackprio -eq 1 ]; then
		#    . /etc/rc.d/ipqos_tcp_ack_prio $TC_ACTION
		#fi
	fi
	if [ ! -z "$IPQOS_INIT_STATUS" ] && [ $QOS_ENABLE -eq 1 -a $IPQOS_INIT_STATUS -eq 1 ]; then
		# if ipqos_init is done, update the queues with changed rates
		# Modify rates of Downstream direction queues
		#tc class change dev imq1 parent 1: classid 1:1 htb rate $MAX_DOWNSTREAM_RATE
		#tc class change dev imq1 parent 1:1 classid 1:41 htb rate $RATE_FOR_DOWNSTREAM_OTHERS ceil $MAX_DOWNSTREAM_RATE prio 2
		# Modify rates of UPSTREAM direction queues
		#Configure Queues
		
		#queuecfg -q 0/0
		i=1
		while [ $i -le $QOS_QUEUE_COUNTS ]
		do 
			q_mgmt $i 0
			i=$(( $i + 1 ))
		done
		q_disable
	fi

}

q_mgmt(){ 
## $1: quque [1-4] $2: add|delete|change
	echo "QoS: q_mgmt start"
	
	# LQ Define NF_MARK MASK 
	SP_WFQ_PRIO_MASK=0x3C0
	SP_WFQ_CPEID_MASK=0x3F
	SP_WFQ_NFMARK_MASK=0xFFFFFC00
	# STREAM_RATE_LIMIT_MASK=0x3FF

	# Check required command line parameters are available
	QQ_INST=$1
    case "$QQ_INST" in
    1)
        QQ_QPRIO=4
		#QQ_PEAKRATE=$(( ($MAX_UPSTREAM_RATE_TMP>>1) - ($MAX_UPSTREAM_RATE_TMP>>4) )) #44%
		QQ_PEAKRATE=$(( $MAX_UPSTREAM_RATE_TMP * 45 / 100 )) #45%
        ;;
    2)
        QQ_QPRIO=3
		QQ_PEAKRATE=$(( $MAX_UPSTREAM_RATE_TMP * 30 / 100 )) #31%
        ;;
    3)
        QQ_QPRIO=2
		QQ_PEAKRATE=$(( $MAX_UPSTREAM_RATE_TMP * 15 / 100 )) #15%
        ;;
    4)
        QQ_QPRIO=1
		QQ_PEAKRATE=$(( $MAX_UPSTREAM_RATE_TMP * 10 / 100 )) #10%
        ;;
    *)
        exit 1
    esac

    QQ_CPEID=$QQ_INST # `nvram get qq_$(($QQ_INST))_cpeId`
    #QQ_PCPEID=1 #`nvram get qq_$(($QQ_INST))_pcpeId`
    #QQ_ENABLE=1 #`nvram get qq_$(($QQ_INST))_enable`
    #QQ_WTENABLE=0 #`nvram get qq_$(($QQ_INST))_wtEnable`
	QQ_SHAPERENABLE=$QOS_BW_CTL_ON #`nvram get qq_$(($QQ_INST))_shaperEnable`
    #eval QQ_IFTYPE=`nvram get qq_$(($QQ_INST))_qIfType`
    #eval QQ_QIF=`nvram get qq_$(($QQ_INST))_qIf`
    QQ_QLEN=102400 #`nvram get qq_$(($QQ_INST))_qLen`
    #QQ_QWT=0 #`nvram get qq_$(($QQ_INST))_qWt`
	#    eval QQ_QPRIO=$QQ_INST #`nvram get qq_$(($QQ_INST))_qPrio`
    #QQ_REDTH=0 #`nvram get qq_$(($QQ_INST))_redTh`
    #QQ_REDPCT=0 #`nvram get qq_$(($QQ_INST))_redPct`
    #QQ_DROPTYPE=0 #`nvram get qq_$(($QQ_INST))_dropType`
    #QQ_SCHEDTYPE=0 #`nvram get qq_$(($QQ_INST))_schedType`
    #QQ_SHAPERATE=0 #`nvram get qq_$(($QQ_INST))_shapeRate`
    QQ_SBS=0 #`nvram get qq_$(($QQ_INST))_sbs`
    #QQ_PEAKRATE=$(( ($MAX_UPSTREAM_RATE_TMP * $QQ_INST) / 10 )) #`nvram get qq_$(($QQ_INST))_peakRate`
    #QQ_COMMITRATE=0 #`nvram get qq_$(($QQ_INST))_commitRate`
    #QQ_EGRESSPVC=0 #`nvram get qq_$(($QQ_INST))_egressPVC`
    #QQ_MINTH=30720 #`nvram get qq_$(($QQ_INST))_uiRedTh`
    #QQ_PROB=0.02 #nvram get qq_$(($QQ_INST))_flRedProb`

    # Prepare IPQOS_QUEUE chain name
    IPQOS_QUEUE_CHAIN_NAME="IPQOS_QUEUE_$QQ_CPEID"
	if [ "x$2" = "x1" ]; then
		#create the IPQOS_QUEUE chain with name 'IPQOS_QUEUE_CHAIN_NAME' for storing priority of the queue
		iptables -t mangle -N $IPQOS_QUEUE_CHAIN_NAME
		# Insert a rule in the IPQOS_QUEUE_MAP chain at the location of order and jump to LAN_CHAIN_NAME chain
		iptables -t mangle -A IPQOS_QUEUE_MAP -j $IPQOS_QUEUE_CHAIN_NAME
		# Add a rule to give configured classification, if classifier matches, remark the packet with given QId
		NF_MARK=`expr -$QQ_QPRIO + $LTQ_QUEUE_COUNTS + 1`
		MOD_MARK=$(( $NF_MARK<<6 ))
		#iptables -t mangle -A $IPQOS_QUEUE_CHAIN_NAME -m mark --mark $QQ_CPEID/$SP_WFQ_CPEID_MASK -j MARK --or-mark $MOD_MARK
		iptables -t mangle -A $IPQOS_QUEUE_CHAIN_NAME -m mark --mark $QQ_CPEID/$SP_WFQ_CPEID_MASK -j MARK --set-mark $MOD_MARK
		# Comment Default target is accept so no need to accept
		# Packet hits all the rules in this chain. So add a rule to accept the packet.
		# This will block the packet to travel through other chains
		iptables -t mangle -A $IPQOS_QUEUE_CHAIN_NAME -m mark --mark $MOD_MARK/$MOD_MARK -j ACCEPT
	fi
	if [ "x$2" = "x0" ]; then
		NF_MARK=`expr -$QQ_QPRIO + $LTQ_QUEUE_COUNTS + 1`
		MOD_MARK=$(( $NF_MARK<<6 ))
		# remove from IPQOS_QUEUE_MAP
		iptables -t mangle -D IPQOS_QUEUE_MAP -j $IPQOS_QUEUE_CHAIN_NAME 2> /dev/null
	    # Flush the chain that has to be deleted and then delete the chain
		iptables -t mangle -F $IPQOS_QUEUE_CHAIN_NAME 2> /dev/null
		iptables -t mangle -X $IPQOS_QUEUE_CHAIN_NAME 2> /dev/null
    fi

	QUEUE_METHOD=`$NVRAM get qos_bk_queue_method`
	if [ $QUEUE_METHOD -eq 1 ]; then

		#Upstream Q Dev varies based on VLAN-Enabled or VLAN-Disabled
		#TBD: Select imq0 or individual device based on VLAN Enable field.
		UPSTREAM_Q_DEV=`$NVRAM get wan${WANNUM}_ifname` #imq0

		if [ "x$2" = "x1" ]; then
			act="add"
		fi
		if [ "x$2" = "x0" ]; then
			act="delete"
		fi
		if [ "x$2" = "x2" ]; then
			act="change"
		fi

		C_CLASS="4$QQ_QPRIO"
		#C_PRIO=`expr $QQ_QPRIO - 1`
		C_PRIO=`expr $QQ_INST - 1`
		C_CEIL=${QQ_PEAKRATE}kbit
		C_CMD="tc class $act dev $UPSTREAM_Q_DEV parent 1:1 classid 1:$C_CLASS htb rate 1kbit ceil $C_CEIL prio $C_PRIO"
		# execute the class command
		$C_CMD
		echo "$C_CMD"

		if [ "x$2" = "x1" -o "x$2" = "x0" ]; then
			Q_CMD="tc qdisc $act  dev"
			# Form the rule
			# add device
			Q_CMD="$Q_CMD $UPSTREAM_Q_DEV"

			# add parent
			Q_PARENT="4$QQ_QPRIO"
			Q_CMD="$Q_CMD parent 1:$Q_PARENT"

			# add handle
			Q_CMD="$Q_CMD handle $Q_PARENT:"
			#Q_CMD="$Q_CMD bfifo"
			# add limit
			#if [ ! -z $QQ_QLEN ]; then
			#	Q_CMD="$Q_CMD limit $QQ_QLEN"
			#	#Q_CMD="$Q_CMD limit 100k"
			#fi
			# execute the qdisc command
			Q_CMD="$Q_CMD pfifo"
			echo "$Q_CMD"
			$Q_CMD

			# handle any packets rather than ip
			#F_CMD="tc filter $act  dev $UPSTREAM_Q_DEV protocol all parent 1:0 prio 1 u32 match"
			# add handle
			#F_CMD_HANDLE=`expr -$QQ_QPRIO + $LTQ_QUEUE_COUNTS + 1`
			#F_CMD_HANDLE=$(( $F_CMD_HANDLE<<6 ))
			#F_CMD="$F_CMD mark $F_CMD_HANDLE $SP_WFQ_PRIO_MASK"

			# add filter type
			#F_CMD="$F_CMD flowid 1:$C_CLASS"
			#F_CMD="tc filter $act dev $UPSTREAM_Q_DEV parent 1:0 protocol all prio 1 handle $QQ_QPRIO fw classid 1:$C_CLASS"
			F_CMD="tc filter $act dev $UPSTREAM_Q_DEV parent 1:0 protocol ip prio 100 handle $MOD_MARK fw classid 1:$C_CLASS"
			echo "$F_CMD"
			$F_CMD
		fi
	fi
	if [ $QUEUE_METHOD -eq 2 ]; then
		QUEUE_NO=`expr $QQ_QPRIO - 1`

		if [ $qIfTypeActive -eq $QOS_INTF_WAN_PTM ]; then
			PORT=7
		fi
		if [ $qIfTypeActive -eq $QOS_INTF_WAN_ETH_1 ]; then
			PORT=1
		fi
		#PTM mode: firmware queues are used
		#if [ $QQ_SCHEDTYPE -eq 0 ]; then
			#SP scheduling
			if [ "x$2" = "x1" ]; then
				C_CMD="ppacmd setwfq -p $PORT -q $QUEUE_NO -w 100"
				# execute the class command
				$C_CMD
				#echo $C_CMD
			fi
			if [ "x$2" = "x0" ]; then
				#classifier rules are deleted, nothing to be done in queues
				echo "nothing to be done"   
				#disable SP
				#Reset the SP config
			fi
		#fi
		

        if [ "x$2" = "x1" ]; then
            #rates in PPE firmware are interms of kbps
            PEAK_RATE=$QQ_PEAKRATE
            #set rate to queue
			C_CMD="ppacmd setrate -p $PORT -r $PEAK_RATE -q $QUEUE_NO"
			$C_CMD
			echo $C_CMD
        fi
        if [ "x$2" = "x0" ]; then
            #disable rateshaping
            #ppacmd setctrlrate -p 1 -c disable
            echo "nothing to be done"
        fi
	fi

	if [ $QUEUE_METHOD -eq 3 ]; then
		#eth wan mode, VR9 switch queues
		QUEUE_NO=`expr $QQ_QPRIO - 1`
		#echo "QUEUE=$QUEUE_NO" 
#		if [ $QQ_SCHEDTYPE -eq 0 ]; then

			#SCHEDULER Type is SP
			SCHEDTYPE=0
			Q_WEIGHT=0xffff
			RATE=$QQ_PEAKRATE
			#echo "weight=$Q_WEIGHT; rate=$RATE"
#		fi
		if [ "x$2" = "x1" ]; then
			QUEUE_NO=`expr $QQ_QPRIO - 1`
			#set scheduler to queue
			if [ $QUEUE_NO -lt 4 ]; then
				#QUEUE=`expr 15 - $QUEUE_NO`
				QUEUE=`expr 20 + $QUEUE_NO`
				switch_utility QOS_SchedulerCfgSet $QUEUE $SCHEDTYPE $Q_WEIGHT
				#echo $C_CMD
			fi
			if [ $QUEUE_NO -gt 3 ]; then
				#QUEUE_NO=`expr 15 - $QUEUE_NO`
				#QUEUE=`expr $QUEUE_NO - 8`

				QUEUE=`expr 24 + $QUEUE_NO`
				switch_utility QOS_SchedulerCfgSet $QUEUE $SCHEDTYPE $Q_WEIGHT
				#echo $C_CMD
			fi
		fi
		if [ "x$2" = "x0" ]; then
			QUEUE_NO=`expr $QQ_QPRIO - 1`

			#reset scheduler to queue
			if [ $QUEUE_NO -lt 4 ]; then
				#   QUEUE=`expr 15 - $QUEUE_NO`
				QUEUE=`expr 20 + $QUEUE_NO`
				switch_utility QOS_SchedulerCfgSet $QUEUE 0 0x1800
				#echo $C_CMD
			fi
			#else
			if [ $QUEUE_NO -gt 3 ]; then
				#QUEUE_NO=`expr 15 - $QUEUE_NO`
				#   QUEUE=`expr $QUEUE_NO - 8`
				QUEUE=`expr 24 + $QUEUE_NO`
				switch_utility QOS_SchedulerCfgSet $QUEUE 0 0x1800
				#echo $C_CMD
			fi
		fi
		if [ "x$QQ_SHAPERENABLE" = "x1" ]; then
			if [ "x$2" = "x1" ]; then
				QUEUE_NO=`expr $QQ_QPRIO - 1`
				SHAPER_INST=$QUEUE_NO
				QQ_SBS=1000

				#set shaper instance based on QQ_INST
				switch_utility QOS_ShaperCfgSet $SHAPER_INST $QQ_SHAPERENABLE $QQ_SBS $RATE
				#echo $C_CMD

				#Assign shaper to queue
				if [ $QUEUE_NO -lt 4 ]; then

					#QUEUE=`expr 15 - $QUEUE_NO`
					QUEUE=`expr 20 + $QUEUE_NO`
					switch_utility QOS_ShaperQueueAssign $SHAPER_INST $QUEUE
					#echo $C_CMD
				fi
				if [ $QUEUE_NO -gt 3 ]; then
					#QUEUE_NO=`expr 15 - $QUEUE_NO`
					#QUEUE=`expr $QUEUE_NO - 8`
					QUEUE=`expr 24 + $QUEUE_NO`
					switch_utility QOS_ShaperQueueAssign $SHAPER_INST $QUEUE
					#echo $C_CMD
				fi
			fi
			if [ "x$2" = "x0" ]; then
				QUEUE_NO=`expr $QQ_QPRIO - 1`
				SHAPER_INST=$QUEUE_NO

				#DeAssign shaper to queue
				if [ $QUEUE_NO -lt 4 ]; then
					#QUEUE=`expr 15 - $QUEUE_NO`
					QUEUE=`expr 20 + $QUEUE_NO`
					switch_utility QOS_ShaperQueueDeassign $SHAPER_INST $QUEUE
					#echo $C_CMD
				fi
				if [ $QUEUE_NO -gt 3 ]; then
					#QUEUE_NO=`expr 15 - $QUEUE_NO`
					#QUEUE=`expr $QUEUE_NO - 8`
					QUEUE=`expr 24 + $QUEUE_NO`
					switch_utility QOS_ShaperQueueDeassign $SHAPER_INST $QUEUE
					#echo $C_CMD
				fi
			fi
		fi
	fi
}

mgmt(){
	defQ=2
	# flush the default chains to remeve previously configured rules
	iptables -t mangle -F PREROUTE_DEFAULT
	#iptables -t mangle -F OUTPUT_DEFAULT

	# Add a rule to mark all the unclassified packet with the default queue for LAN traffic
	iptables -t mangle -A PREROUTE_DEFAULT -j MARK --set-mark $defQ
	
	# Mark the default DSCP if configured
	#iptables -t mangle -A PREROUTE_DEFAULT -j DSCP --set-dscp $qm_defDSCP

	iptables -t mangle -A PREROUTE_DEFAULT -j IPQOS_QUEUE_MAP

    #iptables -t mangle -A OUTPUT_DEFAULT -j MARK --set-mark $defQ
    # Add a rule to mark all the unclassified packet with the default queue for LAN traffic
    # Mark the default DSCP if configured
	#iptables -t mangle -A OUTPUT_DEFAULT -j DSCP --set-dscp $qm_defDSCP
	#iptables -t mangle -A OUTPUT_DEFAULT -j IPQOS_QUEUE_MAP

}

class_delete(){ #$1: qos_listx

	echo "QoS: class_delete start"
	local i=$1
	local BREAK=""
	if [ "x$i" != "x" ]; then
		n=$i
		BREAK="break"
	else
		n=1
	fi
	
	if [ -e $CLSCOUNTFILE ]; then
		#get IPQOS_CLASS_COUNT
		. $CLSCOUNTFILE
		rm -f $CLSCOUNTFILE
	else
		echo "QoS: cannot find any rule exist."
		return
	fi
	#while [ "x$(nvram get qos_list$n)" != "x" ]; do
	while [ $n -le $IPQOS_CLASS_COUNT ]; do
		QOS_CPEID=$n
		eval LAN_CHAIN_NAME="LAN_$QOS_CPEID"
		#eval OUTPUT_CHAIN_NAME="OUTPUT_$QOS_CPEID"

		# remove from IPQOS_LAN_ING
		iptables -t mangle -D IPQOS_LAN_ING -j $LAN_CHAIN_NAME

		# remove from IPQOS_OUTPUT
		#iptables -t mangle -D IPQOS_OUTPUT -j $OUTPUT_CHAIN_NAME

		# delete rules step by step
		#iptables -t mangle -D $LAN_CHAIN_NAME $QOS_RULE1 -j MARK --set-mark $NF_MARK

		# flush the chain that has to be deleted and then delete the chain
		iptables -t mangle -F $LAN_CHAIN_NAME
		#iptables -t mangle -F $OUTPUT_CHAIN_NAME

		# Delete the user-defined chains from the system
		iptables -t mangle -X $LAN_CHAIN_NAME
		#iptables -t mangle -X $OUTPUT_CHAIN_NAME
		n=$(( $n + 1 ))
		$BREAK
	done

}

class_add(){
	echo "QoS: start class_add"
	# define QOS type 
	# NOTE: thease values should match with the values in the enum
	# TBD: If want to support other types, should add here
	local QOS_TYPE_MFC=0
	local QOS_TYPE_DSCP=1
	local QOS_TYPE_802_1P=2

	# Read the index passed as command line parameter passed as this script
	#Get the qId of the classifier
	local i=$1
	local BREAK=""

	if [ "x$QOS_ENABLE" = "x0" -o "x$QOS_ENABLE" = "x" ]; then
		echo "QoS have not be enabled!"
		return
	fi

	#if [ -e $CLSCOUNTFILE ]; then
	#	#get IPQOS_CLASS_COUNT
	#	. $CLSCOUNTFILE
	#else
	#	echo "QoS: cannot find any rule exist."
	#	return
	#fi

	if [ "x$i" != "x" ]; then
		n=$i
		BREAK="break"
	else
		n=1
	fi
	#QOS_ENTRY=MSN_messenger 0 MSN_messenger 1 TCP 443 443 ---- ----
	local QOS_ENTRY=$($NVRAM get qos_list$n)
	while [ "x$QOS_ENTRY" != "x" ]; do
		local QOS_MODE=`echo $QOS_ENTRY | awk '{print $2}'`
		local QOS_LAN_PORT=`echo $QOS_ENTRY | awk '{print $3}'`
		local QOS_QID=`echo $QOS_ENTRY | awk '{print $4}'`
		local QOS_PROTO=`echo $QOS_ENTRY | awk '{print $5}'`
		local QOS_SRCPORT=`echo $QOS_ENTRY | awk '{print $6}'`
		local QOS_SRCPORTEND=`echo $QOS_ENTRY | awk '{print $7}'`
		local qos_name=`echo $QOS_ENTRY | awk '{print $8}'`
		local QOS_SRCMAC=`echo $QOS_ENTRY | awk '{print $9}'`
        local QOS_CPEID=$n
		
		local QOS_RULE1=""
		local QOS_RULE2=""
		local start_port=""
		local end_port=""
		local IS_MULTI_PROTO=""
		local QOS_TOS=0x00

		## QUEUE Priority ID starting from 0 so it should be add 1."
		NF_MARK=$(($QOS_QID+1))

		# check classifier type
		# For MFC classification
        #check and add protocol
		if [ "$QOS_MODE" = "0" -o "$QOS_MODE" = "1" ]; then
			## Applications or Online Gaming ##
			if [ "x$QOS_PROTO" != "x----" ]; then
				IS_MULTI_PROTO=`echo $QOS_PROTO | grep "/"`
				if [ "x$IS_MULTI_PROTO" != "x" ]; then
					QOS_RULE1=`echo $QOS_PROTO | cut -d"/" -f 1`
					QOS_RULE1="-p $QOS_RULE1"
					#QOS_RULE1="$QOS_RULE1 $QOS_PROTO"
					QOS_RULE2=`echo $QOS_PROTO | cut -d"/" -f 2`
					QOS_RULE2="-p $QOS_RULE2"
					#QOS_RULE2="$QOS_RULE2 $QOS_PROTO"
				else
					QOS_RULE1="-p $QOS_PROTO"
					#QOS_RULE1="$QOS_RULE1 $QOS_PROTO"				
				fi
			fi
			if [ "x$QOS_SRCPORT" != "x----" ]; then
				QOS_RULE1="$QOS_RULE1 -m multiport --ports "
				if [ "x$IS_MULTI_PROTO" != "x" ]; then
					QOS_RULE2="$QOS_RULE2 -m multiport --ports "
				fi
			fi

			num=1
			start_port=`echo $QOS_SRCPORT | awk -F',' '{print $'$num'}'`
			while [ "x$start_port" != "x" ]; do
				end_port=`echo $QOS_SRCPORTEND | awk -F',' '{print $'$num'}'`
				if [ "x$end_port" != "x" ] && [ "$start_port" != "$end_port" ]; then
					QOS_RULE1="${QOS_RULE1}${start_port}:${end_port}"
					if [ "x$IS_MULTI_PROTO" != "x" ]; then
						QOS_RULE2="${QOS_RULE2}${start_port}:${end_port}"
					fi
				else
					QOS_RULE1="${QOS_RULE1}${start_port}"
					if [ "x$IS_MULTI_PROTO" != "x" ]; then
						QOS_RULE2="${QOS_RULE2}${start_port}"
					fi
				fi
				num=$(($num+1))
				start_port=`echo $QOS_SRCPORT | awk -F',' '{print $'$num'}'`
				if [ "x$start_port" != "x" ]; then
					QOS_RULE1="${QOS_RULE1},"
					if [ "x$IS_MULTI_PROTO" != "x" ]; then
						QOS_RULE2="${QOS_RULE2},"
					fi
				fi
			done								
		fi
		if [ "$QOS_MODE" = "2" ]; then
			## Ethernet LAN Port ##
			echo "do nothing, ## Ethernet LAN Port ##"
			# change port number 1
			QOS_LAN_PORT=`echo $($NVRAM get lan_eth_ports) | awk -F' ' '{print $'$QOS_LAN_PORT'}'`
			QOS_RULE1="$QOS_RULE1 -m phyport --phyport"
			QOS_RULE1="$QOS_RULE1 $QOS_LAN_PORT"
		fi
		if [ "$QOS_MODE" = "3" ]; then 
	        ## MAC Address ##
			if [ "x$QOS_SRCMAC" != "x----" ]; then
				QOS_RULE1="$QOS_RULE1 -m mac --mac-source"
				QOS_RULE1="$QOS_RULE1 $QOS_SRCMAC"
			fi
		fi

		#echo "QOS_RULE1: $QOS_RULE1"
		#if [ "x$IS_MULTI_PROTO" != "x" ]; then
		#	echo "QOS_RULE2: $QOS_RULE2"
		#fi

		# iptables action to perform is always insert
		act="A"
		# Prepare LAN and OUTPUT rule chain name
		eval LAN_CHAIN_NAME="LAN_$QOS_CPEID"
		#eval OUTPUT_CHAIN_NAME="OUTPUT_$QOS_CPEID"

		# (1). First consider the LAN traffic
		iptables -t mangle -N $LAN_CHAIN_NAME
		# Insert a rule in the IPQOS_LAN_ING chain at the location of order and jump to LAN_CHAIN_NAME chain
		iptables -t mangle -$act IPQOS_LAN_ING -j $LAN_CHAIN_NAME
		# (2). Second consider the local traffic
		#iptables -t mangle -N $OUTPUT_CHAIN_NAME
		# Insert a rule in the OUTPUT chain at the location of order and jump to OUTPUT_CHAIN chain
		#iptables -t mangle -$act IPQOS_OUTPUT -j $OUTPUT_CHAIN_NAME

		# Mark the Qid to the packet if classifier matches
		C_CMD="iptables -t mangle -A $LAN_CHAIN_NAME $QOS_RULE1 -j MARK --set-mark $NF_MARK"
		$C_CMD
		echo "$C_CMD"
		if [ "x$IS_MULTI_PROTO" != "x" ]; then
			C_CMD="iptables -t mangle -A $LAN_CHAIN_NAME $QOS_RULE2 -j MARK --set-mark $NF_MARK"
			$C_CMD
			#echo "$C_CMD"
		fi
	
		if [ "$QOS_MODE" = "0" ]; then
			case "$QOS_QID" in
			0)
				QOS_TOS=0xC0
				;;
			1)
				QOS_TOS=0x80
				;;
			2)
				QOS_TOS=0x00
				;;
			3)
				QOS_TOS=0x40
				;;
			esac
				
			C_CMD="iptables -t mangle -A $LAN_CHAIN_NAME $QOS_RULE1 -m dscp --dscp 0x00 -j TOS --set-tos $QOS_TOS"
			$C_CMD
			#echo "$C_CMD"
			if [ "x$IS_MULTI_PROTO" != "x" ]; then
				C_CMD="iptables -t mangle -A $LAN_CHAIN_NAME $QOS_RULE2 -m dscp --dscp 0x00 -j TOS --set-tos $QOS_TOS"
				$C_CMD
				#echo "$C_CMD"
			fi
		fi 
		#C_CMD="iptables -t mangle -A $OUTPUT_CHAIN_NAME $QOS_RULE1 -j MARK --set-mark $NF_MARK"
		#$C_CMD
		#echo "$C_CMD"
		#if [ "x$IS_MULTI_PROTO" != "x" ]; then
		#	C_CMD="iptables -t mangle -A $OUTPUT_CHAIN_NAME $QOS_RULE2 -j MARK --set-mark $NF_MARK"
		#	$C_CMD
		#	echo "$C_CMD"
		#fi

		# Mark DSCP if outgoing DSCP is configured
		#iptables -t mangle -A $LAN_CHAIN_NAME -m mark --mark $NF_MARK -j DSCP --set-dscp $QOS_DSCPMARK
		#iptables -t mangle -A $OUTPUT_CHAIN_NAME -m mark --mark $NF_MARK -j DSCP --set-dscp $QOS_DSCPMARK

		# Packet hits all the rules in this chain. So add a rule to accept the packet.
		# This will block the packet to travel through other chains
		iptables -t mangle -A $LAN_CHAIN_NAME -m mark --mark $NF_MARK -j IPQOS_QUEUE_MAP
		#iptables -t mangle -A $OUTPUT_CHAIN_NAME -m mark --mark $NF_MARK -j IPQOS_QUEUE_MAP

		$BREAK

		n=$(( $n + 1 ))
		QOS_ENTRY=$($NVRAM get qos_list$n)
	done
	n=$(( $n -1 ))
	if [ $n -gt 0 ]; then
		echo "IPQOS_CLASS_COUNT=\"$n\"" > $CLSCOUNTFILE
		$NVRAM set ipqos_class_count=$n
	else
		$NVRAM set ipqos_class_count=0
	fi
}

bandwidth_algorithm(){
########################################################################################
#Specification: Netgear SPEC2.0                                                        #
#Bandwidth Control - Traffic Shaping.                                                  #
#  Step 1: Using traceroute with data lenght 100B detects nearest IP on public domain. #
#        traceroute www.netgear.com (get nearest public domain)                        #
#  Step 2: Send data size of MTU to the nearest IP public domain 20 times.             #
#        traceroute -I -q 1 -p 33437 -f 3 211.76.114.1 --mtu (calculate                #
#  Step 3: Averaging Step 2 with following formular to calculate uplink bandwith.      #
#                       U = 0.9*(E*8)*19/T bps                                         #
#                                                                                      #
#                                                                                      #
########################################################################################
	echo "S1: get nearest Public IP Domain"
	local NTGIP=`ping -c 1 www.netgear.com | grep 'PING' | sed 's/^.*(//' | sed 's/).*$//'`
	local TMPHOP=0
	local TMPIP=""
	local TMPE=0
	local TMPT=0
	local TMPU=0
	local PKTSIZE=0
	local TMPMAXHOP=2
	#local TMPI=0
	local QOS_UPRATE=`nvram get qos_uprate`

	echo "QoS: @@QOS_UPRATE is $QOS_UPRATE@@"

	if [ "$NTGIP" != "" ]; then
		traceroute -w 2 -m 20 $NTGIP 100 > /tmp/tmpip.txt
		i=1
		TMPIP=`sed -n ${i}p /tmp/tmpip.txt | cut -c 5- | sed 's/^.*(//' | sed 's/\..*//'`
		while [ "$TMPIP" != "" ]
		do
			if [ "$TMPIP" != "* * *" -a "$TMPIP" != "192" -a "$TMPIP" != "172" -a "$TMPIP" != "10" -a "$TMPIP" != "127" ]; then
				echo $TMPIP | grep -Eq '^-*[0-9]+$' && IPOK=1 || IPOK=0
				#if [ "`awk '{print $2}' $TMPIP`" != "*" ]; then
				if [ $IPOK -eq 1 ]; then
					TMPIP=`sed -n ${i}p /tmp/tmpip.txt | sed 's/^.*(//' | sed 's/).*//'`
					TMPHOP=`sed -n ${i}p /tmp/tmpip.txt | awk '{print $1}'`
					echo "@@checked IP($TMPIP):HOP($TMPHOP)@@"
					break
				fi
				#fi
			#else
			#	## Not find any nearest public IP ##
			#	TMPI=$i
			fi
			i=$(($i+1))
			TMPIP=`sed -n ${i}p /tmp/tmpip.txt | cut -c 5- | sed 's/^.*(//' | sed 's/\..*//'`
			#echo "TMPIP: $TMPIP"
			#TMPIP=`$TCMD`
		done
		#if [ "$TMPHOP" = "0" -a "$TMPI" != "0" ]; then
		#	TMPIP=`sed -n ${TMPI}p /tmp/tmpip.txt | sed 's/^.*(//' | sed 's/).*//'`
		#	TMPHOP=`sed -n ${TMPI}p /tmp/tmpip.txt | awk '{print $1}'`
		#fi
		#echo "TMPIP Done: $TMPIP"
		#echo "TMPHOP Done: $TMPHOP"
	
		#local WANNUM=$($NVRAM get wan_default_iface)
		local WANIFACE=$($NVRAM get wan${WANNUM}_ifname)

		local MTUSIZE=`ifconfig $WANIFACE | grep MTU | sed 's/^.*MTU://' | sed 's/\ .*//'`
		while [ 1 -gt 0 ]
		do
			rm -f /tmp/pmtu-max
			## ping count will fix to 3 if "-M" is set ##
			C_CMD="ping -c 3 -M do -s $MTUSIZE $TMPIP"
			echo $C_CMD
			$C_CMD
			if [ -f /tmp/pmtu-max ];then
				MTUSIZE=`cat /tmp/pmtu-max`
				rm -f /tmp/pmtu-max
			else
				break;
			fi
		done
	
		if [ "$TMPHOP" = "1" ]; then
			TMPMAXHOP=2
		else
			TMPMAXHOP=$TMPHOP
		fi
		i=0
		local TMPQUERY=20
		local TMPQUERIED=0
		local TMPHALFQUERY=5 #$(($TMPQUERY>>2))
		rm -f /tmp/bwalg_info
		## retry 5 times ##
		while [ $i -lt 5 ]
		do
			C_CMD="bwalg -q $TMPQUERY -w 3 -u -f $TMPHOP -i $WANIFACE $TMPIP $MTUSIZE"
			echo $C_CMD
			$C_CMD
			if [ -f /tmp/bwalg_info ]; then
				TMPQUERIED=`cat /tmp/bwalg_info | cut -d',' -f1`
				if [ $i -eq 0 ]; then
					TMPSPD=`cat /tmp/bwalg_info | cut -d',' -f2`
				else
					TMPSPD1=`cat /tmp/bwalg_info | cut -d',' -f2`
					TMPSPD=$(( ($TMPSPD + $TMPSPD1) >>1 ))
				fi
				TMPQUERY=$(($TMPQUERY-TMPQUERIED+1))
				if [ $TMPQUERY -gt 20 ]; then
					$TMPQUERY = 20
				fi
				if [ $TMPQUERY -le  $TMPHALFQUERY ]; then
					break
				fi
			fi
			i=$(($i+1)) 
		done
		if [ -f /tmp/bwalg_info ]; then
			echo "# QoS: check uplink bandwith succeed!"
			#$NVRAM set qos_uprate="`cat /tmp/detec_uprate`"
			echo $TMPSPD > /tmp/detec_uprate
			$NVRAM set qos_uprate="$TMPSPD"
		else
			echo "# QoS: check uplink bandwith failed!"
			#echo 0 > /tmp/detec_uprate
			#nvram set qos_threshold=0
			nvram set qos_bandwidth_type=0
			#if [ "$QOS_UP_BW_UNIT" = "Mbps" ]; then
			#	QOS_UPRATE=$(( $QOS_UPRATE * 1024 ))
			#	nvram set qos_uprate=$QOS_UPRATE
			#fi
		fi
	else
		## ping: Unknown host ##
		echo "# QoS: ping Unknow host!"
		nvram set qos_bandwidth_type=0
		#if [ "$QOS_UP_BW_UNIT" = "Mbps" ]; then
		#	QOS_UPRATE=$(( $QOS_UPRATE * 1024 ))
		#	nvram set qos_uprate=$QOS_UPRATE
		#fi
	fi
}

class_skip(){
	echo "# class_skip, do noting"
}

ipqos_mgmt_traffic_config(){
	echo "# ipqos_mgmt_traffic_config, do noting"
	#"do noting"
	#"for SIP_MGMT"
}

tcp_ack_prio(){
	#"need to porting for ADSL"
	#TCP ACK PRIO MACROS
	echo "tcp_ack_prio starting"

	local UPLINK_PERCENTAGE=50
	local DOWNLINK_PERCENTAGE=60

	# Calculating TCP ACK Prioritization Rates
	local TCP_ACK_RATE_TMP=`expr $MAX_UPSTREAM_RATE_TMP \* $UPLINK_PERCENTAGE \* $DOWNLINK_PERCENTAGE / 10000`
	local TCP_ACK_RATE=`expr $MAX_UPSTREAM_RATE_TMP \* $UPLINK_PERCENTAGE \* $DOWNLINK_PERCENTAGE / 10000`$RATE_UNIT
	local RATE_FOR_REST_UPSTREAM=`expr $MAX_UPSTREAM_RATE_TMP - $TCP_ACK_RATE_TMP`$RATE_UNIT

	#TCP ACK PRIO MACROS

	local RATE_UNIT=kbit
	local UPSTREAM_DEV=imq0

	local BFIFO_LIMIT=30000k
	local U32_MASK_FULL=0xffff
	local TCP_TOTAL_IP_DATA_MASK=0xffc0
	local TCP_TOTAL_IP_DATA=0x0000
	local U8_MASK_FULL=0xff
	local U8_MASK_LSB=0x0f
	local PROTOCOL_TCP=6
	local TCP_ACK_BIT_SET=0x10
	local TCP_HEADER_LENGTH=0x05

	$NVRAM set qos_bk_queue_method=0

	if [ $ADSL_MODE_ON -eq 1 ]; then
		case "$1" in
		0)
			TC_ACTION=add #Denotes ADD action for TC rules
			IPT_ACTION=A # Denotes iptables ADD action
			ifconfig $UPSTREAM_DEV up
			;;
		1)
			TC_ACTION=change # Denotes CHANGE action for TC rules
			;;
		2)
			TC_ACTION=del # Denotes DELETE action for TC Rules
			IPT_ACTION=D # Denotes DELETE action for iptable rules
			ifconfig $UPSTREAM_DEV down
			;;
		esac

		if [ $1 -eq 2 ]; then
			tc qdisc $TC_ACTION dev $UPSTREAM_DEV root handle 1: htb
			ifconfig $UPSTREAM_DEV down
		else
			tc qdisc $TC_ACTION dev $UPSTREAM_DEV root handle 1: htb

			tc class $TC_ACTION dev $UPSTREAM_DEV parent 1: classid 1:1 htb rate $MAX_UPSTREAM_RATE
			tc class $TC_ACTION dev $UPSTREAM_DEV parent 1:1 classid 1:22 htb rate $TCP_ACK_RATE ceil $MAX_UPSTREAM_RATE
			tc class $TC_ACTION dev $UPSTREAM_DEV parent 1:1 classid 1:33 htb rate $RATE_FOR_REST_UPSTREAM ceil $MAX_UPSTREAM_RATE

			tc qdisc $TC_ACTION dev $UPSTREAM_DEV parent 1:22 handle 22: bfifo limit $BFIFO_LIMIT
			tc qdisc $TC_ACTION dev $UPSTREAM_DEV parent 1:33 handle 33: bfifo limit $BFIFO_LIMIT

			tc filter $TC_ACTION dev $UPSTREAM_DEV parent 1:0 protocol ip u32 \
				match ip protocol $PROTOCOL_TCP $U8_MASK_FULL \
				match u8 $TCP_HEADER_LENGTH $U8_MASK_LSB at 0 \
				match u16 $TCP_TOTAL_IP_DATA $TCP_TOTAL_IP_DATA_MASK at 2 \
				match u8 $TCP_ACK_BIT_SET $U8_MASK_FULL at 33 flowid 1:22
			tc filter $TC_ACTION dev $UPSTREAM_DEV parent 1:0 protocol ip u32 match mark 33 $U32_MASK_FULL flowid 1:33
		fi

		if [ $1 -eq 0 -o $1 -eq 2 ]; then
			#iptables -t mangle -$IPT_ACTION POSTROUTING -p tcp -m length --length :66 -j MARK --set-mark 22
			iptables -t mangle -$IPT_ACTION POSTROUTING -m length --length 67: -j MARK --set-mark 33
			iptables -t mangle -$IPT_ACTION POSTROUTING -o $default_wan_conn_iface -j IMQ --todev 0
		fi
	fi
}

ipqos_lcp_prio_defaults(){
	#"need to check"
	echo "# ipqos_lcp_prio_defaults,  do noting"
}

case "$1" in
start)
	echo "qos_set.sh start:"  > /dev/console
    if [ "$QOS_ENABLE" = "1" ]; then
		preinit
		#Update Flags
		#queuecfg -u 0/0
		#Update Rates
		#queuecfg -r 0/0
        #ORP: Should be compared with oldenable. should be ... && oldenable=0
        init
    fi
	;;
stop)
	echo "qos_set.sh stop:" > /dev/console
    #set_rule=$1
	#Update Flags
	#queuecfg -u 0/0
	#Update Rates
	#queuecfg -r 0/0
    #ORP: Should be compared with oldenable. should be ... && oldenable=0
    disable
	#if [ -f "/var/run/qos_rate_update.pid" ]; then
	#	kill -9 `cat /var/run/qos_rate_update.pid`
	#	rm -f /var/run/qos_rate_update.pid
	#fi
	;;
restart)
	echo "QoS: restart"
	disable
	if [ "$QOS_ENABLE" = "1" ]; then
		preinit
		init
	fi
	;;
rate_update)
	#$2: upstream rate $3: downstream rate
	rate_update $2 $3
	;;
setup_rule)
	class_delete
	if  [ "x$QOS_ENABLE" = "x1" ]; then
		class_add
	fi
	#stop 1;
	#start 1;
	;;
del_all)
	disable;
	;;
preinit)
	preinit;
	;;
q_mgmt)
	q_mgmt $2 $3
	;;
unset_list)
	local n=1
	while [ "`$NVRAM get qos_list$n`" -ne "" ];
	do
		$NVRAM unset qos_list$n
		n=$((n+1))
	done
	;;
bwalg)
	bandwidth_algorithm
	;;
*)
	echo "command: qos_set.sh [start|stop|restart|del_all|preinit|setup_rule]"
	;;
esac

n=`$NVRAM show | grep qos_list | wc -l | tr -d ' '`
$NVRAM set qos_cur_list_cnt=$n
$NVRAM commit
