#!/bin/sh
#
# The purpose of this script is the same as pppoe.sh
# but support to multi wan interface(created using ip-alias or vconfig)
#
#
#[ -f /usr/local/sbin/pppd ] || exit 0
#	note: $1 --> start, stop, restart 
#		  $2 --> interface nembered	  

if [ $# -lt 2 ]; then
        echo $"Usage: $0 {start|stop|restart} { 0|1|2|3}"
        exit 1
fi

IFACE=$2

manual=$3

RETVAL=0
prog="pppd"
#PID_FILE="/var/run/`nvram get wan$(($IFACE-1))_ifname`.pid"
PID_FILE="/var/run/ppp$(($IFACE-1)).pid"
PLUG_IN="plugin rp-pppoe.so"
#INTERFACE=`nvram get wan_hwifname`

wan_ifname=`nvram get wan_hwifname`
user=`nvram get wan_mulpppoe${2}_username`
password=`nvram get wan_mulpppoe${2}_passwd`
mtu=`nvram get wan_mulpppoe${2}_mtu`
mru=$mtu
idle=`nvram get wan_mulpppoe${2}_idletime`
demand=`nvram get wan_mulpppoe${2}_demand`
service=`nvram get wan_mulpppoe_service`
auto_dns=`nvram get wan_mulpppoe${2}_autodns`

if [ "$demand" = "0" ]; then
	persist_demand="persist"
	idle="0"
elif [ "$demand" = "1" ]; then
        if [ "$idle" = "0" ]; then
                persist_demand="persist"
        else
                persist_demand="demand"
                echo 1 > /proc/sys/net/ipv4/ip_forward
        fi
else
	persist_demand="persist"	# for maual trigger 
	idle="0"
fi

if [ "$auto_dns" = "0" ]; then
	usepeerdns=""
else
	usepeerdns="usepeerdns"
fi

start() {
	# Start daemons.
	echo $"Starting $prog: "

   #ifconfig ${wan_ifname} 0.0.0.0 up
	#if [ "$IFACE" = "2" ] && [ "x$user" = "x" ]; then
   if [ "x$user" = "x" ]; then   # if user name is empty, do not lauch pppoe services
			echo "Session $IFACE not enabled...."
			RETVAL=$?
			return $RETVAL
	fi
		
	ifconfig ${wan_ifname} 0.0.0.0 up
	if [ "$manual" != "manual" ]; then
		if [ "$demand" = "2" ]; then
			echo "Run Manual Connect...."
			RETVAL=$?
			return $RETVAL
		fi
	fi

	if [ "$manual" = "manual" ]; then
                demandex="demandex"
	fi		

        ##do dial-on-demand and bring link up when starting
        #if [ "`nvram get demandex`" = "1" ]; then
        #        nvram unset demandex
        #        demandex="demandex"
        #fi

 
if [ "`nvram get wan_current_iface`" = "$IFACE" ]; then
	nvram set wan${IFACE}_pppoe_username=$user
	nvram set wan${IFACE}_pppoe_passwd=$password
	nvram set wan${IFACE}_pppoe_mtu=$mtu
	nvram set wan${IFACE}_pppoe_idletime=$idle
	nvram set wan${IFACE}_pppoe_demand=$demand
	nvram set wan${IFACE}_pppoe_service=$service
fi
	wan_ifname=`echo $wan_ifname | awk -F: '{print $1}'` #cant use ip-alias in pppd!


if [ "${service}" = "" ]; then
	service_name=""
else
	service_name="rp_pppoe_service ${service}"
fi

	${prog} maxfail -1 ${PLUG_IN} session $(($IFACE-1)) ${service_name} ${wan_ifname} user ${user} password ${password} mtu ${mtu} mru ${mru} ${persist_demand} ${demandex} idle ${idle} ${usepeerdns} defaultroute lcp-echo-failure 3 lcp-echo-interval 30 iface_num ${IFACE} multi_vlans default_iface `nvram get wan_default_iface` unit $(($IFACE-1)) noipdefault 


	if [ "${IFACE}" = "2" -a "${demand}" = "1" ];then
		if [ "`nvram get wan_mulpppoe2_autodns`" = "1" ];then
			nvram set wan1_dns=168.168.168.168
		else
			nvram set wan1_dns="`nvram get wan_mulpppoe2_dns`"
		fi
		for i in "`nvram get wan1_dns`"; 
		do 
			if [ ! "$i" = "0.0.0.0" ];then
				route add -host $i dev ppp$(($IFACE-1))
			fi
		done
		/etc/rc.d/dnsmasq.sh restart
	fi
	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting down $prog: "
	if [ -e ${PID_FILE} ]; then
      echo "kill ${PID_FILE}"
		ppp_pid=`cat ${PID_FILE}`
		kill -1 ${ppp_pid}
		sleep 2	
		kill -9 ${ppp_pid}
		rm -f ${PID_FILE}
	fi

	ETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart} {0|1|2|3}"
	exit 1
esac

exit $RETVAL

