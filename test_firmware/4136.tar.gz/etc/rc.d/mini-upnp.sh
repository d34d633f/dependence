#!/bin/sh

UPNP_ENABLED=`nvram get upnp_enable`


iface=$2

def_iface=`nvram get wan_default_iface`
lan_group=""    #multi lan group such as bridge, br[0-3].
wan_group=""    #multi wan such as wan[1-8].
wan_num=""
IS_MULTI_WAN=""
SYMBOL="eth"



## Initialize lan group ##
## igmpproxy only support 1 upstream interface. ##
#if [ "$(nvram get wan_phy_mode)" = "adsl" ]; then
if [ "x${iface}" != "x" ]; then
	if [ "$(nvram get vlan_enable)" = "1" ]; then 
		if [ "$(nvram get vlan_type)" = "0" ]; then
			SYMBOL="vlan"       # port based vlan
		elif [ "$(nvram get vlan_type)" = "1" ]; then
			SYMBOL="tag"        # tag based vlan
		fi
	else
                SYMBOL="eth"
        fi
	IS_MULTI_WAN="1"
else
	IS_MULTI_WAN=""
fi
#fi

#echo "yyy, iface=${iface}"

## upnp in multi-upstream interfaces ##
upnp_multi_queue() {
    local i=$1
    local interface_group_map="`nvram get interface_group_map`"

    # Parsing Multi-WAN from Multi-LAN Group br[0-3] #
    wan_group=`echo $interface_group_map | cut -d":" -f $i | grep "wan"`
    #if [ "x$wan_group" != "x" ]; then
        lan_group=`echo $interface_group_map | cut -d":" -f $i | grep ${SYMBOL}`
        #wifi_group=`echo $interface_group_map | cut -d":" -f $i | grep "ath"`
        #if [ "x$lan_group" != "x" -o "y$wifi_group" != "y" ]; then
        if [ "x$lan_group" != "x" ]; then
            wan_num=`echo $wan_group | sed 's/^.*wan//g' | sed 's/|.*$//g'`
            if [ "x$wan_num" != "x" ]; then
                lan_ifname=`nvram get lan${i}_ifname`
                wan_ifname=`nvram get wan${wan_num}_ifname`
            else # Incorrect WAN Number #
                wan_group=""
                wan_num=""
            fi
        else # Empty LAN #
            wan_group=""
            wan_num=""
        fi
    #else # Empty WAN #
    #    wan_group=""
    #    wan_num=""
    #fi
}

start() {
    local interface_group_map="`nvram get interface_group_map`"
	if [ $UPNP_ENABLED = 1 ]; then
	    if [ "x$IS_MULTI_WAN" != "x" ]; then
    	# Running Multi-WAN #
			if [ "$interface_group_map" = ":::" ]; then
				## default wan interface ##
				#wan_ifname=`nvram get wan${def_iface}_ifname`
				#/etc/rc.d/pre_upnp.sh ${def_iface}
				#/etc/rc.d/mini_igd.sh start 1 ${wan_ifname}
				#/etc/rc.d/mini_upnp.sh start 1
				echo "## No any LAN Interface in Groups ##"
			else
				## At least one will be set ##
    	    	#for i in 1 2 3 4; do
    	    	for i in ${iface}; do
					upnp_multi_queue $i
					if [ "x$lan_group" != "x" ]; then
					if [ "x$wan_num" != "x" ]; then 
						#echo "Multi-WAN: current interface ${iface}"
						## $0:script, $1:[start/stop], $2:(bridge[0-3]), $3:(eth/nas[1-8]) $4(wan number)  ##
						/etc/rc.d/pre_upnp.sh ${wan_num}
						if [ "x${wan_ifname}" = "x" ]; then
							/etc/rc.d/mini_igd.sh start ${i} none ${wan_num}
						else
							/etc/rc.d/mini_igd.sh start ${i} ${wan_ifname} ${wan_num}
						fi
						/etc/rc.d/mini_upnp.sh start ${i}
						echo "" ## unknowing return value ##
						sleep 1
					else
						## would be default WAN interface ##
						wan_ifname=`nvram get wan${def_iface}_ifname`
						/etc/rc.d/pre_upnp.sh ${wan_num}
						#/etc/rc.d/mini_igd.sh start ${i} ${wan_ifname} ${def_iface}
						/etc/rc.d/mini_igd.sh start ${i} none 99
						/etc/rc.d/mini_upnp.sh start ${i}
						echo "" ## unknowing return value ##
						sleep 1
					fi
					fi
				done
			fi
		else
			#iface=`nvram get lan_ifname`
			/etc/rc.d/pre_upnp.sh
			/etc/rc.d/mini_igd.sh start
			/etc/rc.d/mini_upnp.sh start
		fi
	fi
}


stop() {
	/etc/rc.d/mini_upnp.sh stop ${iface}
	/etc/rc.d/mini_igd.sh stop ${iface}
	/etc/rc.d/del_conntrack.sh upnp
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	sleep 1
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

