#!/bin/sh

WAN_PHY_MODE=`nvram get wan_phy_mode`
if [ "$WAN_PHY_MODE" = "adsl" ];then
        iface=1
        if [ "$iface" = "`nvram get wan_default_iface`" ]; then
                DEFAULT_GW=1
        fi
else
        iface=""
        DEFAULT_GW=1
fi
WAN_HWIFNAME=`nvram get wan${iface}_hwifname`
IPV6_PASS=`nvram get ipv6_pass`
WAN_IFNAME=`nvram get ipv6_if_name`
LAN_IFNAME=`nvram get lan_ifname`
MODULE_NAME=ipv6pass
MODULE=/lib/modules/2.6.30/$MODULE_NAME.ko
VLAN_ENABLE=`nvram get vlan_enable`
PPPoE_PASS=`nvram get PPPoEPassThrough_enable`

start() {
	echo "Set IPv6 passthrough module..."

	if ! /usr/sbin/insmod |grep $MODULE_NAME > /dev/null; then 
		echo "insert $MODULE kernel module"; 
		if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
			GROUP_MAP=`nvram get interface_group_map | awk -F: '{printf $1"\n"$2"\n"$3"\n"$4}'| grep wan1`
			LAN_IFNAME=`echo $GROUP_MAP | awk -F'|' '{printf $1"\n"$2}' | grep -v wan1`
		fi
			/usr/sbin/insmod $MODULE wan_ifname=$WAN_IFNAME lan_ifname=$LAN_IFNAME wan_hwifname=$WAN_HWIFNAME; 
		echo 1 > /proc/ipv6_passthrough
	fi

	RETVAL=$?
	return $RETVAL
}

stop() {

	echo "remove $MODULE kernel module"
	rmmod $MODULE_NAME
	if [ "$PPPoE_PASS" = "1" ]; then
		echo 1 > /proc/ipv6_passthrough
	else
		echo 0 > /proc/ipv6_passthrough
	fi

	RETVAL=$?
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

