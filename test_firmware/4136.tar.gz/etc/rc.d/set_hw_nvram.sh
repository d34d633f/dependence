#!/bin/sh

#'flash set hw_params' will set all needed hw_setting vars from HW_SETTING_AREA and
#write then into various files. Then only lan_mac and wan_mac will be set to nvram,
#other wlan params will stay in files located under /tmp/hw_oaram for wlan script to follow

echo "set_hw_nvram"

if [ "$1" = "reset" ]; then
	nvram unset lan_hwaddr
	nvram unset wan_factory_mac
	nvram unset wl_ssid
	nvram unset wl_hwaddr
	nvram unset wps_pin
	nvram unset serial_no
	nvram unset annex
	nvram unset annex_changed
	nvram unset bootcode_ver
	nvram commit
	reboot
	exit 1
fi	

lan_hwifname=`nvram get lan_hwifname`
lan_hwaddr=`nvram get lan_hwaddr`
wan_hwaddr=`nvram get wan_factory_mac`

pincode=`nvram get wps_pin`
aeskey=`nvram get aeskey_default`
region=`nvram get region_boardinfo`

commit="0"

fw_region=`cat firmware_region`

boot_lan_mac=`bootenv_get MACADDR`
if [ "$boot_lan_mac" != "" ]; then
	echo $boot_lan_mac > /tmp/mac_temp
	mc /tmp/mac_temp
	boot_wan_mac=`cat /tmp/mac_temp`
	rm -f /tmp/mac_temp
fi
#boot_wan_mac=`bootenv_get wan_mac | cut -d "=" -f 2`
boot_wpspin=`bootenv_get pincode`
boot_wlpreset=`bootenv_get wlpreset`
boot_coext2_4G=`bootenv_get coext2_4G`

if [ "$boot_lan_mac" = "" ]; then
    boot_lan_mac="00:30:ab:00:00:01"
fi
if [ "$boot_wan_mac" = "" ]; then
	boot_wan_mac="00:30:ab:00:00:02"
fi

if [ "`nvram get lan_hwaddr`" = "" ] || [ "`nvram get lan_hwaddr`" != $boot_lan_mac ]; then
	nvram set lan_hwaddr=$boot_lan_mac
	echo "nvram set lan_hwaddr=$boot_lan_mac"
	commit="1"
fi

if [ "`nvram get wan_factory_mac`" = "" ] || [ "`nvram get wan_factory_mac`" != $boot_wan_mac ]; then
	nvram set wan_factory_mac=$boot_wan_mac
	echo "nvram set wan_factory_mac=$boot_wan_mac"
	nvram unset wan_hwaddr
	commit="1"
fi

WL_SSID="`nvram get wl_ssid`"
## If wireless factory default setting is none ##
if [ "x$WL_SSID" = "x" ]; then
	nvram set wl_preset=1
	## factory default setting ##
	WL_SSID=`echo  $boot_wlpreset | cut -d ";" -f1 | sed 's/^.*"//'`
	WL_WPASPSK_KEY=`echo  $boot_wlpreset | cut -d ";" -f2 | sed 's/".*$//'`
	echo "***wlpreset: $boot_wlpreset***"
	echo "***WL_SSID: $WL_SSID, WL_KEY: $WL_WPASPSK_KEY***"
	WL_SECTYPE=4
	if [ "x$WL_SSID" = "x" -o "x$WL_WPASPSK_KEY" = "x" ]; then
		nvram set wl_ssid="NETGEAR"
		#nvram set wlg1_ssid="NETGEAR-Guest1"
		nvram set wl_sectype="1"
		#nvram set wla_sectype="1"
		#nvram set wlg1_sectype="1"

		nvram set wps_status=1
	else
		nvram set wl_ssid=$WL_SSID
		#nvram set wlg1_ssid="NETGEAR-Guest1"
		nvram set wl_sectype=$WL_SECTYPE
		#nvram set wlg1_sectype=$WL_SECTYPE
		#nvram set wl_wpas_psk=$WL_WPASPSK_KEY	
		#nvram set wlg1_wpas_psk=$WL_WPASPSK_KEY
		nvram set wl_wpa2_psk=$WL_WPASPSK_KEY	
		#nvram set wlg1_wpa2_psk=$WL_WPASPSK_KEY
		nvram set wl_wpae_mode="WPAE-TKIPAES"
		#nvram set wlg1_wpae_mode="WPAE-TKIPAES"
		nvram set wl_sec_wpaphrase_len=${#WL_WPASPSK_KEY}

		nvram set wps_status=5
	fi

	# NETGEAR TD56, guest network default is none security
	nvram set wlg1_ssid="NETGEAR-Guest1"
	nvram set wlg1_sectype="1"

	## Coexistence for 2.4G ##
	## Alex need to fix ##
	#if [ "x$boot_coext2_4G" = "xEnable" ]; then
	#	nvram set wl_disablecoext="0"
	#else
	#	nvram set wl_disablecoext="1"
	#fi

	commit="1"
fi

if [ "`nvram get wl_hwaddr`" = "" ] || [ "`nvram get wl_hwaddr`" != $boot_lan_mac ]; then
        lan_mac1=`echo $boot_lan_mac | cut -d ":" -f1`
        lan_mac2=`echo $boot_lan_mac | cut -d ":" -f2`
        lan_mac3=`echo $boot_lan_mac | cut -d ":" -f3`
        lan_mac4=`echo $boot_lan_mac | cut -d ":" -f4`
        lan_mac5=`echo $boot_lan_mac | cut -d ":" -f5`
        lan_mac6=`echo $boot_lan_mac | cut -d ":" -f6`
        #local_bit=02
        #new_lan_mac1=$(($lan_mac1|$local_bit))
        #wl_mac=$new_lan_mac1:$lan_mac2:$lan_mac3:$lan_mac4:$lan_mac5:$lan_mac6
        wl_mac=$lan_mac1:$lan_mac2:$lan_mac3:$lan_mac4:$lan_mac5:$lan_mac6
	nvram set wl_hwaddr=$wl_mac
	echo "nvram set wl_hwaddr=$wl_hwaddr"

	lan_mac1_1=`echo $boot_lan_mac | cut -d ":" -f1 | cut -c 1`
	lan_mac1_2=`echo $boot_lan_mac | cut -d ":" -f1 | cut -c 2`
	
	num=1
	# NETGEAR SPEC: the b[1] of MSB which is locally administered bit must be 1.
	for local_bit in 2 4 6 
	do
		mac_overflow=0
		new_lan_mac1_t=$lan_mac1_2
		new_lan_mac1_t=`printf %d 0x"$new_lan_mac1_t"`
		new_lan_mac1_t=$(($new_lan_mac1_t+$local_bit))
		if [ $new_lan_mac1_t -ge 16 ]; then
			new_lan_mac1_t=$(($new_lan_mac1_t-16))
			mac_overflow=1
		fi
		new_lan_mac1_hex=`printf %x $new_lan_mac1_t`
		if [ $mac_overflow = 0 ]; then
			new_lan_mac1="$lan_mac1_1""$new_lan_mac1_hex"
		else
			lan_mac1_1_t=$(($lan_mac1_1+1))
			new_lan_mac1="$lan_mac1_1_t""$new_lan_mac1_hex"
		fi
		wl_mac=$new_lan_mac1:$lan_mac2:$lan_mac3:$lan_mac4:$lan_mac5:$lan_mac6
		nvram set wlg"$num"_hwaddr=$wl_mac
		num=$(($num+1))
	done

#	num=1
#	# NETGEAR SPEC: the b[1] of MSB which is locally administered bit must be 1.
#	for local_bit in 2 6 10
#	do
#		new_lan_mac1_t=$(($lan_mac1_2|$local_bit))
#		new_lan_mac1_hex=`printf %x $new_lan_mac1_t`
#		new_lan_mac1="$lan_mac1_1""$new_lan_mac1_hex"
#		wl_mac=$new_lan_mac1:$lan_mac2:$lan_mac3:$lan_mac4:$lan_mac5:$lan_mac6
#		nvram set wlg"$num"_hwaddr=$wl_mac
#		num=$(($num+1))
#	done

	commit="1"
fi

pincode_env=`bootenv_get pincode`
if [ "$pincode_env" != "" ] && [ "$pincode" != "$pincode_env" ]; then
	#nvram set pincode_default=$pincode_env
	nvram set wps_pin=$pincode_env
	commit="1"
fi
#region_env=`uboot_printenv  region | cut -d "=" -f 2`
#region=`nvram get region_boardinfo`
#if [ "${region}" != "${region_env}" ]; then
#	nvram set region_boardinfo=${region_env}
#	commit="1"
#fi

bootcode_ver=`nvram get bootcode_ver`
bootcode_env=`bootenv_get VER`
if [ "$bootcode_ver" != "$bootcode_env" ]; then
	nvram set bootcode_ver=$bootcode_env
	commit="1"
fi

sn=`nvram get serial_no`
boot_sn=`bootenv_get serial_no`
if [ "$boot_sn" != "" ] && [ "$sn" != "$boot_sn" ]; then
	nvram set serial_no=$boot_sn
        local ver=`cat /module_name`
        if [ "$ver" = "DGN1000v3" ]; then
		nvram set igd_devinfo_sn=$boot_sn
                nvram set TR069_conn_req_pwd="`nvram get igd_devinfo_sn`"
        fi
	commit="1"
fi

annex_changed=`nvram get annex_changed`
annex=`nvram get annex`
boot_annex=`bootenv_get annex`
if [ "$boot_annex" != "" ] && [ "$annex" != "$boot_annex" ] && [ "$annex_changed" = "" ]; then
	nvram set annex=$boot_annex
	commit="1"
fi


# wireless hw settings
SET_values()
{
    nvram set $1=$2
}

#pwrlevelCCK_A=`nvram get pwrlevelCCK_A`
#if [ "$pwrlevelCCK_A" = "" ]; then
	SET_values "pwrlevelCCK_A" `flash get TX_POWER_CCK_A | cut -d= -f 2 | sed -e 's/,//g'`
	SET_values "pwrlevelHT40_1S_A" `flash get TX_POWER_HT40_1S_A | cut -d= -f 2 | sed -e 's/,//g'`
	SET_values "pwrdiffOFDM" `flash get TX_POWER_DIFF_OFDM | cut -d= -f 2 | sed -e 's/,//g'`

#	commit="1"
#fi


if [ "$commit" = "1" ]; then
	nvram commit
fi



