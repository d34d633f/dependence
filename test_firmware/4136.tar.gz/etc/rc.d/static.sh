#!/bin/sh

RETVAL=0

iface=$2
NVRAM="/usr/sbin/nvram"
CAT="/bin/cat"
CUT="/usr/bin/cut"
wan_ifname=`nvram get wan${iface}_hwifname`
WAN_IPADDR=`nvram get wan${iface}_ipaddr`
WAN_SUBNET=`nvram get wan${iface}_netmask`
WAN_GATEWAY=`nvram get wan${iface}_gateway`
RESOLV_CONF="/etc/resolv.conf"
dns1=`nvram get wan${iface}_ether_dns1`
dns2=`nvram get wan${iface}_ether_dns2`
dns="$dns1 $dns2"
wan_domain=`nvram get wan${iface}_domain`
wan_mtu=`nvram get wan${iface}_dhcp_mtu`
nat_endis=`nvram get wan${iface}_nat_enable`

WAN_INFO=/tmp/wan/wan${iface}

ETH_WAN_INDEX=`nvram get eth_wan_iface`
wan_default_iface=`nvram get wan_default_iface`
wan_phy_auto=`nvram get wan_phy_auto`
wan_phy_mode=`nvram get wan_phy_mode`
if [ "$wan_phy_mode" = "adsl" ]; then
    MULTI_WAN=1        
fi

if [ "$MULTI_WAN" = "1" ]; then
    wan_default_iface=`nvram get wan_default_iface`
    if [ "$iface" = "$wan_default_iface" ] || [ "$iface" = "$ETH_WAN_INDEX" ]; then
        if [ "$iface" = "$ETH_WAN_INDEX" ]; then
                default_ipaddr=`nvram get wan${wan_default_iface}_default_ipaddr`
	        if [ "x$default_ipaddr" != "x" ]; then
			exit;
		fi	
        fi
        DEFAULT_GW=1
    fi
else
    DEFAULT_GW=1
fi

start() {
    echo $"Starting static wan${iface}:"

    echo "static" > ${WAN_INFO}

    if [ "$DEFAULT_GW" = "1" ]; then
	   /usr/sbin/nvram set wan_ifname=$wan_ifname
    fi
     /usr/sbin/nvram set wan${iface}_ifname=$wan_ifname

   ifconfig $wan_ifname down

   if [ "$wan_mtu" = "0" ]; then
      ifconfig $wan_ifname mtu 1500
   else
      ifconfig $wan_ifname mtu $wan_mtu
   fi

	ifconfig $wan_ifname $WAN_IPADDR netmask $WAN_SUBNET
        if [ "$DEFAULT_GW" = "1" ]; then
		/usr/sbin/area-ck $WAN_IPADDR $WAN_GATEWAY $WAN_SUBNET
                if [ "$?" != "1" ]; then
                        route add -net ${WAN_GATEWAY} netmask 255.255.255.255 dev $wan_ifname
                fi
                echo "route add default gw ${WAN_GATEWAY}"
        	route add default gw ${WAN_GATEWAY}
        	echo search $wan_domain > $RESOLV_CONF
        	for i in $dns; do
        		echo adding dns $i
        		echo nameserver	$i >> $RESOLV_CONF
        	done

                /usr/sbin/nvram set wan0_ipaddr=$WAN_IPADDR
	        /usr/sbin/nvram set wan0_netmask=$WAN_SUBNET
	        /usr/sbin/nvram set wan0_gateway=$WAN_GATEWAY
	        /usr/sbin/nvram set wan0_dns="$dns"
        fi 
	
	/usr/sbin/nvram set wan${iface}_default_ipaddr=$WAN_IPADDR
	/usr/sbin/nvram set wan${iface}_default_netmask=$WAN_SUBNET
	/usr/sbin/nvram set wan${iface}_default_gateway=$WAN_GATEWAY
        /usr/sbin/nvram set wan${iface}_dns="$dns"
       
        if [ "$DEFAULT_GW" = "1" ]; then
             if [ "$MULTI_WAN" = "1" ]; then
                        # dual wan (adsl/eth) mode
                        if [ "$wan_phy_auto" = "1" ] && [ "$iface" != "$ETH_WAN_INDEX" ]; then
                                WAN_INFO="/tmp/wan/wan${ETH_WAN_INDEX}"
                                wan_proto=`$CAT ${WAN_INFO} | ${CUT} -d ":" -f1`
                                if [ "$wan_proto" = "pptp" ] || [ "$wan_proto" = "l2tp" ]; then
                                        is_dyn=`$CAT ${WAN_INFO} | ${CUT} -d ":" -f2`
                                        if [ "$is_dyn" = "1" ]; then
                                                /etc/rc.d/do_nat.sh stop $ETH_WAN_INDEX dhcpc
                                                U_PID_FILE="/var/run/udhcpc${ETH_WAN_INDEX}.pid"  
                                                PID=`$CAT ${U_PID_FILE}`
                                                /bin/kill -9 ${PID}  
                                        else    
                                                /etc/rc.d/do_nat.sh stop $ETH_WAN_INDEX static
                                        fi
                                        PID_FILE="/var/run/ppp${ETH_WAN_INDEX}.pid" 
                                        sleep 1
                                elif [ "$wan_proto" = "pppoe" ]; then
				        PID_FILE="/var/run/ppp${ETH_WAN_INDEX}.pid"    							    
			        elif [ "$wan_proto" = "dhcp" ]; then
					PID_FILE="/var/run/udhcpc${ETH_WAN_INDEX}.pid"    
				 fi      
				 PID=`$CAT ${PID_FILE}`            
				 /bin/kill -9 ${PID}                                
                                 /etc/rc.d/do_nat.sh stop $ETH_WAN_INDEX
                                 sleep 1
                                 /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_default_ipaddr
                                 /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_default_netmask
                                 /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_default_gateway
                                 /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_dns
                                 /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_dhcp_ipaddr
            		         /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_dhcp_netmask
            		         /usr/sbin/nvram unset wan${ETH_WAN_INDEX}_dhcp_gateway
                                  name=`/usr/sbin/nvram get wan${ETH_WAN_INDEX}_hwifname`
			        /sbin/ifconfig $name 0.0.0.0 down
                        fi
        		/etc/rc.d/do_nat.sh restart $iface        	                           
             fi
	     /usr/sbin/nvram set action=3
        else
            echo "not default route"
            /etc/rc.d/do_nat.sh restart $iface    	    
        fi

	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
        echo $"Shutting down static${iface}:"
	ifconfig $wan_ifname 0.0.0.0

         if [ "$MULTI_WAN" = "1" ]; then
                /etc/rc.d/do_nat.sh stop ${iface}
	        /usr/sbin/nvram unset wan${iface}_default_ipaddr
	        /usr/sbin/nvram unset wan${iface}_default_netmask
	        /usr/sbin/nvram unset wan${iface}_default_gateway
                /usr/sbin/nvram unset wan${iface}_dns                
         fi

	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

