#!/bin/sh

LOG_FILE=/var/log/messages
REC_FILE=/var/log/mesg
REC_FILE_tmp=/var/log/mesg-tmp

NTP_sync_flag=`nvram get NTP_sync_flag`
NTP_sync_offset=`nvram get NTP_sync_offset`
NTP_sync_OK=`nvram get NTP_sync_OK`

sync()
{
	if [ "$NTP_sync_flag" = "1" -a "$NTP_sync_OK" != "1" ]; then
		rec_line=`wc -l $REC_FILE | awk '{print $1}'`

		#for item in `cat $REC_FILE | grep "NETGEAR" | awk '{print $(NF-1)}'`
		for item in `cat $REC_FILE | grep "NETGEAR" | grep -v "Time synchronized with NTP server" | awk '{print $(NF-1)}'`
		do
			O_time=$item
			N_time=$(($O_time+$NTP_sync_offset))
	        	
			#sed -i "/NETGEAR/s/$O_time NETGEAR/$N_time/g" $REC_FILE
			sed -i "s/$O_time/$N_time/g" $REC_FILE
		done

		nvram set NTP_sync_OK=1
	fi
}

update()
{
	if [ "$NTP_sync_flag" = "1" -a "$NTP_sync_OK" = "1" ]; then
		cp $REC_FILE $REC_FILE_tmp

		TimeAdjust=`nvram get TimeZoneAdjust_firstly`

		add_dec=`echo $TimeAdjust | awk -F',' '{print $1}'`
		Timestamp=`echo $TimeAdjust | awk -F',' '{print $2}'`

		for item in `cat $REC_FILE_tmp | grep "NETGEAR" | awk '{print $(NF-1)}'`
		do
			O_time=$item
			N_time=$item
			if [ "$Timestamp" != "" ]; then
				if [ "$add_dec" = "+" ]; then
					N_time=$(($N_time+$Timestamp))
				fi
				if [ "$add_dec" = "-" ]; then
					N_time=$(($N_time-$Timestamp))
				fi
			fi
	       		pattern=`date -d 1970.01.01-00:00:$N_time +'%A, %B %d,%Y %R:%S'`
			sed -i "/NETGEAR/s/$O_time NETGEAR/$pattern/g" $REC_FILE_tmp
		done

		mv $REC_FILE_tmp $LOG_FILE
	fi
}

# See how we were called.
case "$1" in
  sync)
	sync	
	;;
  update)
	update	
	;;
  *)
	echo $"Usage: $0 {sync|update}"
	exit 1
esac

