# !/bin/sh
Time=0
WAIT_TIME=30 #sec
SetTimer()
{
	DEF_TOUT=${1:-10};
	if [ "${DEF_TOUT}" -ne "0" ];then
		sleep "${DEF_TOUT}" && kill -s 14 $$ &
		CHPROCIDS="${CHPROCIDS} $!"
		TIMEORIC=$!
	fi
}
AlarmHandler()
{
	if [ "`ps |grep tftp|grep -v grep|cut -d " " -f 14`" != "tftp" ]; then
		read_file="`cat /tmp/inspection`"
		if [ ${#read_file} -gt 200 ];then
			killall wlan_ralink.sh
			killall aoss
			nvram unset aoss_running
			nvram unset wps_running
			chmod 777 /tmp/inspection
			/tmp/inspection &
			/bin/echo 2 >/proc/tc3162/wps_button
			exit 1
		fi
	#	/bin/echo 0 >/proc/tc3162/wps_button
	fi
}
test_function()
{
	if [ ! -e /tmp/INSPECTION_STATUS_B ];then
		exit 1
	fi
	CHPROCIDS=$$
	trap AlarmHandler 14
	$PROG &
#	Time=$((${Time}+1))
	while [ "${Time}" -lt "${WAIT_TIME}" ]
	do
		SetTimer 1 
		wait $!
		Time=$((${Time}+1))
	done
}
test_function;
exit 1
