#!/bin/sh

#$1, wireless interface ath0; $2, up or down

PATH="$PATH:/sbin:/usr/sbin"

iwconfig=/sbin/iwconfig
iwpriv=/sbin/iwpriv
nvram=/usr/sbin/nvram
ifconfig=/sbin/ifconfig
wlanconfig=/sbin/wlanconfig
hostapd=/usr/sbin/hostapd
conf_hostapd=/tmp/hostapd/hostapd.conf
dir_hostapd=/tmp/hostapd
brctl=/usr/sbin/brctl
wifi=/etc/rc.d/wifi.sh
insmod=/usr/sbin/insmod
rmmod=/sbin/rmmod
ifconfig=/sbin/ifconfig
cat=/bin/cat


set_common_confs() #$1: ath0
{
    echo "$1: Common confs set(dtim, bintval, frag, rts, wmm)"
    $iwpriv $1 protmode 0   # here to disable 802.11g protection mode
    $iwpriv $1 dtim_period "$($nvram get wl_dtim)"
    $iwpriv $1 bintval "$($nvram get wl_bcn)"
    $iwconfig $1 frag "$($nvram get wl_frag)"

    if [ "$($nvram get wl_rts)" = "2347" ];then
	$iwconfig $1 rts off
    else
    	$iwconfig $1 rts "$($nvram get wl_rts)"
    fi
    $iwconfig $1 rate "$($nvram get wl_rate)"
   
    $iwpriv $1 wmm "$($nvram get endis_wl_wmm)"
    [ "$($nvram get endis_ssid_broadcast)" = "1" ] && $iwpriv $1 hide_ssid 0 || $iwpriv $1 hide_ssid 1
    $iwpriv $1 countryie "$($nvram get wl_country)"	
    [ "$($nvram get wl_plcphdr)" = "2" ] && $iwpriv $1 shpreamble 0 || $iwpriv $1 shpreamble 1
    $iwpriv $1 xr "$($nvram get endis_xr)"
   
}
config_psk_hostapd()
{
cat <<EOF
interface=$1
bridge=$($nvram get lan_ifname)
driver=madwifi
debug=0
dump_file=/tmp/hostapd.dump
wpa=$4
wpa_passphrase=$2
wpa_key_mgmt=WPA-PSK
wpa_pairwise=$3
EOF

}

config_wpa_psk() #$1: interface $2: wpa_passphrase $3: wpa_pairwise $4: wpa
{
#    killall hostapd
    $iwpriv $1 wpa 0
    $iwconfig $1 key off
    $iwpriv $1 wpa 3
    $iwpriv $1 authmode 1

    [ -d $dir_hostapd ] && rm -rf $dir_hostapd
    mkdir -p $dir_hostapd
    config_psk_hostapd "$1" "$2" "$3" "$4" > $conf_hostapd
    $hostapd -B $conf_hostapd
}


config_8021x_hostapd()
{
cat <<EOF
interface=$1
bridge=$($nvram get lan_ifname)
driver=madwifi
debug=0
dump_file=/tmp/hostapd.dump
wpa=$3
ieee8021x=1
own_ip_addr=127.0.0.1
auth_server_addr=$4
auth_server_port=$5
auth_server_shared_secret=$6
wpa_key_mgmt=WPA-EAP
wpa_pairwise=$2
wpa_group_rekey=$7
EOF

}

config_wpa()
{
    $iwpriv $1 wpa 0
    $iwconfig $1 key off
    $iwpriv $1 wpa 3
    $iwpriv $1 authmode 1

    radius_ip=$($nvram get wl_radius_ip)
    radius_port=$($nvram get wl_radius_port)
    radius_key=$($nvram get wl_radius_key)
    group_rekey=$($nvram get wl_radius_rekey_interval)

    [ -d $dir_hostapd ] && rm -rf $dir_hostapd
    mkdir -p $dir_hostapd
    config_8021x_hostapd "$1" "$2" "$3" "$radius_ip" "$radius_port" "$radius_key" "$group_rekey" > $conf_hostapd
    $hostapd -B $conf_hostapd
}


set_security() #$1: ath0
{
    case "$($nvram get wl_sectype)" in
	1) #disabled
	    echo "$1: Security disabled"
	    $iwpriv $1 wpa 0
	    $iwpriv $1 authmode 1
	    $iwconfig $1 key off
	    ;;
	2) #wep
	    $iwpriv $1 wpa 0
	    $iwconfig $1 key [1] "$($nvram get wl_key1)"
	    $iwconfig $1 key [2] "$($nvram get wl_key2)"
	    $iwconfig $1 key [3] "$($nvram get wl_key3)"
	    $iwconfig $1 key [4] "$($nvram get wl_key4)"
	    
	    case "$($nvram get wl_auth)" in
		0) #open
		    echo "$1: Security wep open"
		    $iwpriv $1 authmode 1
		    $iwconfig $1 key ["$($nvram get wl_key)"] open
		    ;;
		1) #shared
		    echo "$1: Security wep share"
		    $iwpriv $1 authmode 2
		    $iwconfig $1 key ["$($nvram get wl_key)"] restricted
		    ;;
                2) #auto
		    echo "$1: Security wep auto"
                    $iwpriv $1 authmode 4
                    $iwconfig $1 key ["$($nvram get wl_key)"]
                    ;;

	    esac
	    ;;
        3) #wpa-psk
	    echo "$1: Security wpa-psk(TKIP)"
            sec_algo="TKIP"
            psk_phrase=$($nvram get wl_wpa1_psk)
            config_wpa_psk $1 "$psk_phrase" "$sec_algo" 1
            ;;
        4) #wpa2-psk
	    echo "$1: Security wpa2-psk(AES)"
            sec_algo="CCMP"
            psk_phrase=$($nvram get wl_wpa2_psk)
            config_wpa_psk $1 "$psk_phrase" "$sec_algo" 2
            ;;
        5) #wpa-psk/wpa2-psk
	    echo "$1: Security wpa-psk(TKIP)+wpa2-psk(AES)"
            sec_algo="CCMP TKIP"
            psk_phrase=$($nvram get wl_wpas_psk)
            config_wpa_psk $1 "$psk_phrase" "$sec_algo" 3
            ;;
	6) #wpa/wpa2-enterprise
	    echo "$1: Security wpa/wpa2 enterprise"
            case "$($nvram get wl_radius_encryption_mode)" in
		0) #wpa (tkip)
		    echo "$1: wpa(tkip) encryption mode"
		    sec_algo="TKIP"
		    config_wpa $1 "$sec_algo" 1 
		    ;;
		1) #wpa2 (aes)
		    echo "$1: wpa2(aes) encryption mode"
		    sec_algo="CCMP"
		    config_wpa $1 "$sec_algo" 2 
		    ;;
                2) #wpa (tkip) + wpa2 (aes)
		    echo "$1: wpa(tkip) + wpa2(aes) encryption mode"
		    sec_algo="CCMP TKIP"
		    config_wpa $1 "$sec_algo" 3 
                    ;;
	    esac
	   
            
            ;;

    esac
}

wlconf_up() #$1: ath0
{
	$wlanconfig $1 create wlandev wifi0 wlanmode ap 
}

set_acl() #$1: ath0
{
    echo "$1: ACL set"
    case "$($nvram get wl_access_ctrl_on)" in
	0)
	    $iwpriv $1 maccmd 0
	    ;;
	1)
	    $iwpriv $1 maccmd 1
	    en_wds="$($nvram get wds_endis_fun)"
	    en_repeater="$($nvram get wds_repeater_basic)"
	    en_rep_cl_asso="$($nvram get wds_endis_ip_client)"
	    en_sta_cl_asso="$($nvram get wds_endis_mac_client)"	
	    if [ "$en_wds" = "1" -a \( "$en_repeater" = "0" -a "$en_rep_cl_asso" = "0" -o "$en_repeater" != 0 -a "$en_sta_cl_asso" = "0" \) -o "$en_wds" = "0" ]; then 
	    	MACAC_NUM="$($nvram get wl_acl_num)"
	    	if [ "$MACAC_NUM" != 0 ]; then
			num=1
			while [ $num -le $MACAC_NUM ]
			do
			mac=$($nvram get wlacl$num)
			addr=$(echo "$mac" | while read name value; do echo "$value"; done)
			$iwpriv $1 addmac $addr
			num=$(($num + 1))
			done
	    	fi
	    fi
	    ;;	
    esac

}

#configure g mode: g-and-b, b-only or g-only
config_mode() #$1: 0,b only  1,auto  2,g only, $2: ath0
{	
   case "$1" in
	1)
	    echo "$2: Wireless mode 11g+b"
	    $iwpriv $2 mode 11g
	    $iwpriv $2 pureg 0
	    ;;
	
	2)
	    echo "$2: Wireless mode 11g only"
	    $iwpriv $2 mode 11g
	    $iwpriv $2 pureg 1
	    ;;

	3)
	    echo "$2: Wireless mode 11b only"
	    $iwpriv $2 mode 11b
	    $iwpriv $2 pureg 0
	    ;;
	
	4)
	    $iwpriv $2 turbo 1
    esac
}

modules_path=/lib/modules/2.6.20.19/net

insert_modules()
{
    $insmod $modules_path/mtlk.ko ap=1

    case "$($nvram get wl_country_code)" in
	0)  #Africa 	    
    	    echo "wl country \"Africa\""
	    ;;
        1)  #Asia china
	    echo "wl country \"Asia\""
            ;;
        2)  #Australia
	    echo "wl country \"Australia\""
            ;;
        3)  #Canada 
	    echo "wl country \"Canada\""
            ;;
        4)  #Europe Germany
	    echo "wl country \"Europe\""
            ;;
        5)  #Israel
	    echo "wl country \"Israel\""
            ;;
        6)  #Japan 
	    echo "wl country \"Japan\""
            ;;
        7)  #Korea
	    echo "wl country \"Korea\""
            ;;
        8)  #Mexico
	    echo "wl country \"Mexico\""
            ;;
        9) #Middle East (Iran) 
	    echo "wl country \"Middle East\""
            ;;
        10)  #South America Brazil
	    echo "wl country \"South America\""
            ;;
        11) #United States 
	    echo "wl country \"United States\""
            ;;
        12) #Default, use madwifi default value
	    echo "wl country \"default North America\""
            ;;
	esac

    echo 1 > /proc/sys/dev/wifi0/softled
    echo 1 > /proc/sys/dev/wifi0/ledon
}

rmmod_modules()
{
    local rm_mods="mtlk"
    local mod

    echo 0 > /proc/sys/dev/wifi0/softled
    echo 0 > /proc/sys/dev/wifi0/ledon

    for mod in $rm_mods; do
	$rmmod $mod
    done
}


enable_route()
{
    echo "enable route ......"
    /sbin/cmdroute start	
    ifconfig br0 "$($nvram get lan_ipaddr)"	
    rm /tmp/.route_disable -f
}


disable_route()
{
    /sbin/cmdroute stop
    touch /tmp/.route_disable
}


setup_wds()
{
    local  ifs wds_if
    $brctl stp "$($nvram get lan_ifname)" on
    if [ "$($nvram get wds_repeater_basic)" = "0" ];then
	echo "set up wds in repeater mode ....."
	$wlanconfig wds1 create wlandev wifi0 wlanmode wds
	sleep 1
	disable_assoc=$($nvram get wds_endis_ip_client)
	ifs=$(grep wds /proc/net/dev|sed 's/\(\ *\)\(wds[^:]*\)\(.*\)/\2/')
	wds_if=$(echo $ifs | sed 's/.*[[:blank:]]//')
	config_mode "$($nvram get wl_mode)" $wds_if
	$iwpriv $wds_if wds 1
	$iwpriv $wds_if wds_add "$($nvram get basic_station_mac)"
	$iwpriv $wds_if compression 0
	set_security $wds_if
	$ifconfig $wds_if up
	[ "$disable_assoc" = 1 ] && $iwpriv ath0 maccmd 1
	[ ! -e /tmp/.route_disable ] && disable_route
	ifconfig br0 "$($nvram get repeater_ip)"
    else
	echo "set up wds in station mode ......"
	num=1
	lan_hwaddr=$($nvram get lan_hwaddr)
	while [ $num -le 4 ]
	do
		wdsmac=$($nvram get repeater_mac$num)
		if [ "x$wdsmac" != "x" ]; then
			echo $wdsmac
			$wlanconfig wds$num create wlandev wifi0 wlanmode wds
			sleep 1
			ifs=$(grep wds$num /proc/net/dev|sed 's/\(\ *\)\(wds[^:]*\)\(.*\)/\2/')
			wds_if=$(echo $ifs | sed 's/.*[[:blank:]]//')
			config_mode "$($nvram get wl_mode)" $wds_if
			$iwpriv $wds_if wds 1
			$iwpriv $wds_if wds_add $wdsmac
			$iwpriv $wds_if compression 0
		    	set_security $wds_if
			$ifconfig $wds_if up
		fi
		num=$(($num+1))
	done
	[ "$($nvram get wds_endis_mac_client)" = 1 ] && $iwpriv ath0 maccmd 1	
    fi	   
}


remove_wds_dev ()
{
    if [ "$($nvram get wds_repeater_basic)" = "0" ];then
	echo "remove wds (repeater mode)....."
	$wlanconfig wds1 destroy
    else
	echo "remove wds station mode ......"
	num=1
	while [ $num -le 4 ]
	do
		wdsmac=$($nvram get repeater_mac$num)
		$wlanconfig wds$num destroy
		num=$(($num+1))
	done
    fi
}


brctl_wds()
{
    local i
    for i in $1; do
        $brctl addif "$($nvram get lan_ifname)" $i
    done

}


Lantiq_test()
{
	$iwpriv $1 sNetworkMode 23
	$iwconfig $1 channel auto
	$iwconfig $1 essid "Lantiq_AP_DNI"
	$iwpriv $1 s11hRadarDetect 0
	$iwpriv $1 sCountry US
	$iwconfig $1 key off
	$iwpriv $1 sFortyMHzOpMode 1
	$iwpriv $1 sAocsIsEnabled 0
	$iwpriv $1 sAocsBonding 0
	$iwpriv $1 sFixedRate auto
	$iwpriv $1 sFixedHTRate auto
	$iwpriv $1 sReliableMcast 1
	$iwpriv $1 s11nProtection 1
	$iwpriv $1 sERPProtection 1
	$iwpriv $1 sAdvancedCoding 1
	$iwpriv $1 sStaKeepaliveIN 1000
	$iwpriv $1 sLongRetryLimit 7
	$iwpriv $1 sOnlineACM 59
	$iwpriv $1 sShortRetryLim 7
	$iwpriv $1 sMaxConnections 32
	$iwpriv $1 sDiscNACKEnable 1
	$iwpriv $1 sDisconnOnNACKS 1
	$iwpriv $1 sDisconnOnNACKs 1
	$iwpriv $1 sBE.AggrTimeout 1
	$iwpriv $1 sBK.AggrTimeout 1
	$iwpriv $1 sVO.AggrTimeout 1
	$iwpriv $1 sVI.AggrTimeout 1
	$iwpriv $1 sTxAntennas 123
	$iwpriv $1 sMACWdTimeoutMs 30000
	$iwpriv $1 sMACWdPeriodMs 50000
	$iwpriv $1 sBridgeMode 0
	$ifconfig $1 up
        $brctl addif "$($nvram get lan_ifname)" $1
}


set_wds_down() #$1: interface
{
    local i
    echo "Destroy wds devices:$1"
    for i in $1; do
        $ifconfig $i down
        sleep 1
	$brctl delif "$($nvram get lan_ifname)" $i
    done
    $brctl stp "$($nvram get lan_ifname)" off	
}


case "$2" in
    up)
	#if [ "$($nvram get endis_wl_radio)" = "1" ]; then
	if [ "$($nvram get wl1_radio)" = "0" ]; then
    		if ! grep -q -e ^mtlk /proc/modules; then
        		insert_modules
		fi
		Lantiq_test $1
		#wlconf_up $1
		#$iwconfig $1 essid -- "$($nvram get wl_ssid)"
		#config_mode "$($nvram get wl_mode)" $1
		#$iwconfig $1 channel "$($nvram get wl_channel)"
                #set_common_confs $1
		#set_security $1
                #set_acl $1 
		#$ifconfig $1 up
                #$ifconfig $1 down
		#[ "$($nvram get wds_endis_fun)" = 1 ] && setup_wds
		#$ifconfig $1 up
                #$brctl addif "$($nvram get lan_ifname)" $1
                #devs_wds1=$(grep wds /proc/net/dev|sed 's/\(\ *\)\(wds[^:]*\)\(.*\)/\2/')
		#[ "x${devs_wds1}" != "x" ] && brctl_wds "$devs_wds1"
#
		#[ \( "$($nvram get wds_endis_fun)" != 1 -o "$($nvram get wds_repeater_basic)" != 0 \) -a -e /tmp/.route_disable ] && enable_route
		#$cat /proc/uptime | sed 's/ .*//' > /tmp/WLAN_uptime
        else
		[ -e /tmp/.route_disable ] && enable_route
	fi
	;;
    down)
	killall hostapd
	[ -d $dir_hostapd ] && rm -rf $dir_hostapd
        devs_wds=$(grep wds /proc/net/dev|sed 's/\(\ *\)\(wds[^:]*\)\(.*\)/\2/')
	[ "x${devs_wds}" != "x" ] && set_wds_down "$devs_wds"
	$ifconfig $1 $2
	$brctl delif "$($nvram get lan_ifname)" $1
	$wlanconfig $1 destroy
	[ "$($nvram get wds_endis_fun)" = 1 ] && remove_wds_dev
	$ifconfig wifi0 $2
	if grep -q -e ^ath_ahb /proc/modules; then
		rmmod_modules
	fi
	;;
    restart)
	$wifi wlan0 down
	$wifi wlan0 up
	;;
    *)
	echo "Usage: wifi [interface] [up/down/restart]"
	;;
esac


