#!/bin/sh

BUF1=""
BUF2=""
DEC=0
ALPH=""

Hex_to_Dec()
{
   
         case $1 in
         a)
              DEC=10          
         ;;
         b)
              DEC=11          
         ;;
         c)
              DEC=12       
         ;;
         d)
              DEC=13          
         ;;
         e)
              DEC=14          
         ;;
         f)
              DEC=15          
         ;;
         *)
              DEC=$1  
         
         ;;
         esac

}

Dec_to_Alph()
{
         case $1 in
         0)
              ALPH=A
         ;;
         1)
              ALPH=B
         ;;
         2)
              ALPH=C
         ;;
         3)
              ALPH=D
         ;;
         4)
              ALPH=E
         ;;
         5)
              ALPH=F
         ;;
         6)
              ALPH=G
         ;;
         7)
              ALPH=H
         ;;
         8)
              ALPH=I
         ;;
         9)
              ALPH=J
         ;;
         10)
              ALPH=K
         ;;
         11)
              ALPH=L
         ;;
         12)
              ALPH=M
         ;;
         13)
              ALPH=N
         ;;
         14)
              ALPH=O
         ;;
         15)
              ALPH=P
         ;;
         16)
              ALPH=Q
         ;;
         17)
              ALPH=R
         ;;
         18)
              ALPH=S
         ;;
         19)
              ALPH=T
         ;;
         20)
              ALPH=U
         ;;
         21)
              ALPH=V
         ;;
         22)
              ALPH=W
         ;;
         23)
              ALPH=X
         ;;
         24)
              ALPH=Y
         ;;
         25)
              ALPH=Z
         ;;
     
         esac



}


    mac_pri=`nvram get lan_hwaddr | sed -e 's/://g' | awk {'print toupper($_)'}`
    md5_pri=`echo -n "0x$mac_pri" | md5sum | cut -d " " -f 1`
    echo "md5_pri=$md5_pri"
    ssid_sub=""
    k=0
    while [ "$k" -lt "6" ]; 
    do
         digit1=`echo $md5_pri | cut -c $((2*$k+1))`
         digit2=`echo $md5_pri | cut -c $((2*$k+2))`
         Hex_to_Dec $digit1
         digit1=$(($DEC*16))
         Hex_to_Dec $digit2
         digit2=$DEC
         BUF1=$(($(($digit1+$digit2))%10))
         ssid_sub=$ssid_sub$BUF1
         
         
         
         k=$(($k+1))
    done
    
    #echo "ssid_sub=$ssid_sub"
    nvram set wl_ssid="ziggo$ssid_sub"
    
    
    #passphrase
    PASS=""
    k=5
    while [ "$k" -lt "13" ]; 
    do
         digit1=`echo $md5_pri | cut -c $((2*$k+1))`
         digit2=`echo $md5_pri | cut -c $((2*$k+2))`
         
         Hex_to_Dec $digit1
         digit1=$(($DEC*16))
         Hex_to_Dec $digit2
         digit2=$DEC
         BUF1=$(($(($digit1+$digit2))%26))
         Dec_to_Alph $BUF1
         PASS=$PASS$ALPH
         
         
         
         k=$(($k+1))
    done
    
    
    
    
    nvram set wl_wpas_psk="$PASS"
    
