#!/bin/sh

. /etc/rc.d/tools.sh

INTERFACE=`nvram get lan_ifname`
LAN_IPADDR=`nvram get lan_ipaddr`
LAN_SUBNET=`nvram get lan_netmask`
masklen=`print_masklen $LAN_SUBNET`
subnet=`print_subnet $LAN_IPADDR $LAN_SUBNET`
NAT_TYPE_FULLCONE=`nvram get nat_type_fullcone`
wan_ifname=`nvram get wan_ifname`
NVRAM="/usr/sbin/nvram"

lan1_enable=`nvram get lan1_enable`
lan2_enable=`nvram get lan2_enable`
lan3_enable=`nvram get lan3_enable`

iptables="iptables"

#echo "Enable IP forwarding"
#echo 1 > /proc/sys/net/ipv4/ip_forward || echo "/proc not available"

#echo "Enable SNATP2P and CONENAT Modules"
echo 0 > /proc/sys/net/ipv4/ip_forward || echo "/proc not available"
$iptables -F -t nat
#$iptables -X -t nat
$iptables -Z -t nat
$iptables -t nat -P PREROUTING ACCEPT
$iptables -t nat -P POSTROUTING ACCEPT
$iptables -t nat -P OUTPUT ACCEPT

iptables -t nat -A POSTROUTING -j nat_ipsec
#$iptables -t nat -A POSTROUTING -s $subnet/$masklen -j MASQUERADE

#
# Add SNATP2P rule for each wan interface
#
$iptables -t nat -A PREROUTING -i $wan_ifname -j dnat
lan_ifname=`nvram get lan_ifname`
wan_ifname=`nvram get wan_ifname`
wan_ipaddr=`nvram get wan0_ipaddr`
if [ "`$NVRAM get wan_proto`" = "pptp" ]; then
	if [ "`$NVRAM get dy_pptp`" = "1" ]; then
		dhcp_if=`$NVRAM get wan_dhcp_ifname`
		dhcp_wan=`$NVRAM get wan_dhcp_ipaddr`
		$iptables -t nat -A eth_napt -o $dhcp_if -s $subnet/$masklen -j SNATP2P --to-source $dhcp_wan
		$iptables -t nat -A PREROUTING -d $dhcp_wan -j nat_local_server
	else 
		PPTP_MY_IP=`$NVRAM get wan_pptp_local_ip`
		wan_hwifname=`$NVRAM get wan_hwifname`
		$iptables -t nat -A eth_napt -o $wan_hwifname -s $subnet/$masklen -j SNATP2P --to-source ${PPTP_MY_IP}
		$iptables -t nat -A PREROUTING -d $PPTP_MY_IP -j nat_local_server
	fi
	/etc/rc.d/igmpproxy.sh restart
fi
if [ "`$NVRAM get wan_proto`" = "l2tp" ]; then
    if [ "`$NVRAM get dy_l2tp`" = "1" ]; then
        dhcp_if=`$NVRAM get wan_dhcp_ifname`
        dhcp_wan=`$NVRAM get wan_dhcp_ipaddr`
        $iptables -t nat -A eth_napt -o $dhcp_if -s $subnet/$masklen -j SNATP2P --to-source $dhcp_wan
        $iptables -t nat -A PREROUTING -d $dhcp_wan -j nat_local_server
    else
        L2TP_MY_IP=`$NVRAM get wan_l2tp_local_ip`
        wan_hwifname=`$NVRAM get wan_hwifname`
        $iptables -t nat -A eth_napt -o $wan_hwifname -s $subnet/$masklen -j SNATP2P --to-source ${L2TP_MY_IP}
        $iptables -t nat -A PREROUTING -d $L2TP_MY_IP -j nat_local_server
    fi
    /etc/rc.d/igmpproxy.sh restart
fi
if [ "`$NVRAM get wan_proto`" = "pppoe" ]; then
	if [ "`$NVRAM get wan_pppoe_wan_assign`" = "1" ] && [ "`$NVRAM get wan_pppoe_netmask`" != "0.0.0.0" ]; then
		dyn_wan_ip=`$NVRAM get wan_pppoe_ip`
		pppoe_netmask=`$NVRAM get wan_pppoe_netmask`
		pppoe_wan_hwifname=`$NVRAM get wan_hwifname`
		ifconfig $pppoe_wan_hwifname $dyn_wan_ip netmask $pppoe_netmask up
		$iptables -t nat -A eth_napt -o $pppoe_wan_hwifname -s $subnet/$masklen -j SNATP2P --to-source $dyn_wan_ip
		$iptables -t nat -A PREROUTING -d $dyn_wan_ip -j nat_local_server
		/etc/rc.d/igmpproxy.sh restart
	fi

        if [ "`cat /module_name`" = "DEGN1000v3" ]; then
        	if [ "$(nvram get wan_pppoe_intranet_wan_assign)" = "1" ]; then
	                wan_hwifname=`nvram get wan_dhcphwifname`
			wan_intra_ip=`nvram get wan_pppoe_intranet_ip`
		else
                	wan_hwifname=`nvram get wan_dhcphwifname`
			wan_intra_ip=`nvram get wan_dhcp_ipaddr`
		fi
		
                $iptables -t nat -A eth_napt -o $wan_hwifname -s $subnet/$masklen -j SNATP2P --to-source $wan_intra_ip
		$iptables -t nat -A PREROUTING -d $wan_intra_ip -j nat_local_server
		/etc/rc.d/igmpproxy.sh restart
        fi
fi

#$iptables -t nat -A PREROUTING -i $wan_ifname -d $wan_ipaddr -j nat_local_server
$iptables -t nat -A PREROUTING -d $wan_ipaddr -j nat_local_server
$iptables -t nat -A PREROUTING -d $wan_ipaddr -j nat_port_forward
$iptables -t nat -A PREROUTING -d $wan_ipaddr -j nat_port_trigger_inbound
if [ "`$NVRAM get wan_proto`" = "pptp" ]; then
	if [ "`$NVRAM get dy_pptp`" = "1" ]; then
		pptp_static_wan=`$NVRAM get wan_dhcp_ipaddr`
	else 
		pptp_static_wan=`$NVRAM get wan_pptp_local_ip`
	fi
	wan_hwifname=`$NVRAM get wan_hwifname`
	iptables -t nat -A PREROUTING -d $pptp_static_wan -j nat_port_forward
	iptables -t nat -A PREROUTING -d $pptp_static_wan -j nat_port_trigger_inbound
	iptables -t nat -A PREROUTING -d $pptp_static_wan -j nat_upnp
fi
if [ "`$NVRAM get wan_proto`" = "l2tp" ]; then
    if [ "`$NVRAM get dy_l2tp`" = "1" ]; then
        l2tp_static_wan=`$NVRAM get wan_dhcp_ipaddr`
    else
        l2tp_static_wan=`$NVRAM get wan_l2tp_local_ip`
    fi
    wan_hwifname=`$NVRAM get wan_hwifname`
    iptables -t nat -A PREROUTING -d $l2tp_static_wan -j nat_port_forward
    iptables -t nat -A PREROUTING -d $l2tp_static_wan -j nat_port_trigger_inbound
    iptables -t nat -A PREROUTING -d $l2tp_static_wan -j nat_upnp
fi
if [ "`$NVRAM get wan_proto`" = "pppoe" ]; then
	if [ "`$NVRAM get wan_pppoe_wan_assign`" = "1" ] && [ "`$NVRAM get wan_pppoe_netmask`" != "0.0.0.0" ]; then
		pppoe_static_wan=`$NVRAM get wan_pppoe_ip`
		iptables -t nat -A PREROUTING -d $pppoe_static_wan -j nat_port_forward
		iptables -t nat -A PREROUTING -d $pppoe_static_wan -j nat_port_trigger_inbound
		iptables -t nat -A PREROUTING -d $pppoe_static_wan -j nat_upnp
	fi
fi
if [ "`$NVRAM get wan_proto`" = "pppoe" ]; then
        if [ "`cat /module_name`" = "DEGN1000v3" ]; then
        	if [ "$(nvram get wan_pppoe_intranet_wan_assign)" = "1" ]; then
			pppoe_static_wan=`$NVRAM get wan_pppoe_intranet_ip`
		else
			pppoe_static_wan=`$NVRAM get wan_dhcp_ipaddr`
		fi
		iptables -t nat -A PREROUTING -d $pppoe_static_wan -j nat_port_forward
		iptables -t nat -A PREROUTING -d $pppoe_static_wan -j nat_port_trigger_inbound
		iptables -t nat -A PREROUTING -d $pppoe_static_wan -j nat_upnp
	fi
fi
		
$iptables -t nat -A PREROUTING -i $wan_ifname -d $wan_ipaddr -j nat_upnp
$iptables -t nat -A PREROUTING -d $wan_ipaddr -j nat_dmz
$iptables -t nat -A PREROUTING -j nat_nbt

#$iptables -t nat -A POSTROUTING -o $wan_ifname -j SNATP2P --to-source $wan_ipaddr
$iptables -t nat -A POSTROUTING -o $lan_ifname -s $LAN_IPADDR -j ACCEPT

#for CONFIG_NETFILTER_BRIDGE lan & wireless bridge
$iptables -t mangle -A PREROUTING -j mangle_local_server
$iptables -t mangle -A PREROUTING -s $subnet/$masklen -d $subnet/$masklen -j MARK --set-mark 119
$iptables -t nat -A POSTROUTING -o $lan_ifname -s $subnet/$masklen -d $subnet/$masklen -m mark --mark 119 -j ACCEPT
#for static routing in LAN domain.
$iptables -t nat -A POSTROUTING -o $lan_ifname -j static_privateroute
#for RIP routing in LAN domain.
$iptables -t nat -A POSTROUTING -o $lan_ifname -j RIP_privateroute

$iptables -t nat -A POSTROUTING -j eth_napt

#$iptables -t nat -A POSTROUTING -o $wan_ifname -s $subnet/$masklen -j MASQUERADE
#$iptables -t nat -A POSTROUTING -s $subnet/$masklen -j SNATP2P --to-source $wan_ipaddr
$iptables -t nat -A eth_napt -s $subnet/$masklen -j SNATP2P --to-source $wan_ipaddr

$iptables -t nat -I nat_local_server -p icmp -s $subnet/$masklen -j ACCEPT
# do not forward non-lan ip address
$iptables -I FORWARD -i $lan_ifname ! -s $subnet/$masklen -j DROP


/etc/rc.d/nat_type.sh start

echo "Enable IP forwarding"
echo 1 > /proc/sys/net/ipv4/ip_forward || echo "/proc not available"

/etc/rc.d/conflict.sh start
