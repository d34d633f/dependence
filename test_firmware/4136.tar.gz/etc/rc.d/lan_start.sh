#!/bin/sh

. /etc/rc.d/tools.sh

NVRAM="/usr/sbin/nvram"
INITFILE=/tmp/bridge_init
lan_group=$1
action=$1

lan_ifname=`nvram get lan_ifname`
lan_hwifname=`nvram get lan_hwifname`
lan_hwifnames=`nvram get lan_hwifnames`
wan_hwifname=`nvram get wan_hwifname`
wl_ifname=`nvram get wl_ifname`
router_disable=`nvram get router_disable`
wan_phy_mode=`nvram get wan_phy_mode`
vlan_enable=`nvram get vlan_enable`

echo "Launch lan_start.sh"

ifconfig  lo 127.0.0.1 netmask 255.0.0.0

# if the wan type is adsl mode, need support multiple lan group1 - group4 (br0 - br3)
if [ "$wan_phy_mode" = "adsl" ]; then
    lan1_ifname=`nvram get lan1_ifname`     
    lan2_ifname=`nvram get lan2_ifname`     
    lan3_ifname=`nvram get lan3_ifname`       
    lan4_ifname=`nvram get lan4_ifname`

    LAN1_IPADDR=`nvram get lan1_ipaddr`
    LAN1_SUBNET=`nvram get lan1_netmask`

    LAN2_IPADDR=`nvram get lan2_ipaddr`
    LAN2_SUBNET=`nvram get lan2_netmask`

    LAN3_IPADDR=`nvram get lan3_ipaddr`
    LAN3_SUBNET=`nvram get lan3_netmask`

    LAN4_IPADDR=`nvram get lan4_ipaddr`
    LAN4_SUBNET=`nvram get lan4_netmask`

    lan_hwaddr=`nvram get lan_hwaddr`
else
    lan_hwaddr=`nvram get lan_hwaddr`
    LAN_IPADDR=`nvram get lan_ipaddr`
    LAN_SUBNET=`nvram get lan_netmask`
fi

find_wan()  #$1: lan group
{
     lan_group=$1
     find_wan=`nvram get interface_group_map | cut -d":" -f $lan_group | grep "wan"`
     if [ "x$find_wan" != "x" ]; then
          temp=$find_wan
          for i in $WAN_INTFS
          do
              wan=`echo $temp | grep "wan$i"`
              if [ "x$wan" != "x" ]; then
                   find_wan=$i
                   break
              fi
         done
     fi
     echo $find_wan
}

Remove_Eth_From_Bridge()   # $1: bridge index 1 2 3 4,  $2: eth name
{
    ALL_BR_INTF=$1  
    ETH_NAMES=$2

    for item in $ETH_NAMES
    do
        ifconfig $item down
    done

    for item in $ALL_BR_INTF
    do  
        BNAME=`nvram get lan${item}_ifname`     
        for eth in $ETH_NAMES
        do
            brctl delif $BNAME $eth 2> /dev/null    
        done
    done           
}

Restart_Bridge_Group()   # $1: bridge index  $2: action
{
    ALL_BR_INTF=$1
    WAN_INTFS="1 2 3 4 5 6 7 8"
    TABLE=20    

     for item in $ALL_BR_INTF
     do 
          BNAME=`nvram get lan${item}_ifname`     
          ifconfig $BNAME down  2> /dev/null    
    done

    if [ "x$2" != "x" ]; then
        START_BR_INTF=$2
    else
        START_BR_INTF=$ALL_BR_INTF
    fi

    for item in $START_BR_INTF
    do 
          BNAME=`nvram get lan${item}_ifname`  
     
          exist_br_intf=`ifconfig -a | grep "$BNAME"`
	  if [ "x$exist_br_intf" = "x" ];  then
          	brctl addbr $BNAME 2> /dev/null     
	  fi
          brctl addbr $BNAME 2> /dev/null     
         
          brctl setfd $BNAME 0 2> /dev/null
          brctl stp $BNAME 0 2> /dev/null

          LAN_IPADDR=`nvram get lan${item}_ipaddr`
          LAN_SUBNET=`nvram get lan${item}_netmask`
        
          if [ "$item" = "1" ]; then
                  ifconfig $BNAME $LAN_IPADDR netmask $LAN_SUBNET

                  for wan_iface in $WAN_INTFS
                  do 
                            wan_ipaddr=`nvram get wan${wan_iface}_default_ipaddr`
                            mask_len=`print_masklen $LAN_SUBNET`
                             sub_net=`print_subnet $LAN_IPADDR $LAN_SUBNET`
                             ip route add  $sub_net/$mask_len dev $BNAME table ${TABLE}${wan_iface} 2> /dev/null
                  done    
          else
                  ifconfig $BNAME 0.0.0.0
                  if [ "$vlan_enable" = "1" ]; then                
                          ifconfig $BNAME $LAN_IPADDR netmask $LAN_SUBNET

                          for wan_iface in $WAN_INTFS
                          do 
                                          mask_len=`print_masklen $LAN_SUBNET`
                                          sub_net=`print_subnet $LAN_IPADDR $LAN_SUBNET`
                                          #ip route add  $sub_net/$mask_len via $LAN_IPADDR dev $BNAME table ${TABLE}${wan_iface} 2> /dev/null
                                          ip route add  $sub_net/$mask_len dev $BNAME table ${TABLE}${wan_iface} 2> /dev/null
                          done                
                  fi
          fi
        
          #correspond_wan_iface=`find_wan ${item}`
          #if [ "x${correspond_wan_iface}" != "x" ]; then
             #       wan_ipaddr=`nvram get wan${correspond_wan_iface}_default_ipaddr`
                #    if [ "x$wan_ipaddr" != "x" ]; then
                   #       mask_len=`print_masklen $LAN_SUBNET`
                      #    sub_net=`print_subnet $LAN_IPADDR $LAN_SUBNET`
                         # ip route add  $sub_net/$mask_len via $LAN_IPADDR dev $BNAME table ${TABLE}${correspond_wan_iface} 2> /dev/null
                    #fi
          #fi
     done                                                    
}

Find_Bridge()
{
    search_name=$1
    group1=`nvram get interface_group_map | cut -d":" -f 1 | grep "$search_name"`   
    group2=`nvram get interface_group_map | cut -d":" -f 2 | grep "$search_name"`   
    group3=`nvram get interface_group_map | cut -d":" -f 3 | grep "$search_name"`   
    group4=`nvram get interface_group_map | cut -d":" -f 4 | grep "$search_name"`   

    if [ "x$group1" != "x" ]; then                        
           echo "1"
    elif [ "x$group2" != "x" ]; then
            echo "2"
    elif [ "x$group3" != "x" ]; then
            echo "3"
    elif [ "x$group4" != "x" ]; then
            echo "4"
    else
            echo "0"
    fi
}

Stop_Vlan_Intf()  # $1: index
{
        VLAN_ID="$1"
        for vid in $VLAN_ID
        do 
               vport_ifname="$lan_hwifname.$vid"
               # down the eth0.x interface and remove from bridge group
               Remove_Eth_From_Bridge "1 2 3 4" $vport_ifname               
               vconfig rem $vport_ifname            
        done
}

Restart_TagBased_Vlan_Group()
{
    TAG_BASED_MAP=`nvram get vlan_alltags | sed 's/,/ /g'`
    if [ "x$lan_group" != "x" ]; then
            echo "Restart lan($lan_group) with tag-based vlan enabled:"     
            exit_tag=`nvram get interface_group_map | cut -d ":" -f $lan_group`
            if [ "x$exit_tag" != "x" ]; then     
                    for item in 1 2 3 4
                    do
                            tag=`echo $exit_tag | grep tag${item}`
                            if [ "x$tag" != "x" ]; then 
                                vid=`echo $TAG_BASED_MAP | cut -d " " -f ${item}`
                                Stop_Vlan_Intf ${vid} 2> /dev/null

                                vport_ifname="${lan_hwifname}.${vid}"
                                vconfig add $lan_hwifname $vid
                                ifconfig $vport_ifname 0.0.0.0                                     
                            fi
                    done
            fi

            Restart_Bridge_Group $lan_group

            if [ "x$vport_ifname" != "x" ]; then  
                lan_intf=`nvram get lan${lan_group}_ifname`
                brctl addif $lan_intf $vport_ifname 2> /dev/null    
            fi

            /etc/rc.d/lan_service.sh restart ${lan_group}
    else
            echo "Restart lan(1-4) with tag-based vlan enabled:" 
                        
            Remove_Eth_From_Bridge "1 2 3 4" $lan_hwifname
            ifconfig $lan_hwifname 0.0.0.0 up       

            df_pvid=`echo ${TAG_BASED_MAP} | cut -d " " -f 1`
            exist_vlan_intf=`ifconfig -a | grep "eth0\."`
            exist_tag_vlan_intf=`ifconfig -a | grep "eth0.$df_pvid"`
            
            if [ "x$exist_vlan_intf" != "x" ] && [ "x$exist_tag_vlan_intf" = "x" ]; then  
                     echo "stop all vlan"                    
            elif [ "x$exist_vlan_intf" = "x" ]; then  
                     echo "stop tag based vlan"                         
            fi

            VLAN_INTERFACES=`ifconfig -a | grep "eth0\." | cut -d " " -f 1 | cut -d "." -f 2`
            Stop_Vlan_Intf "${VLAN_INTERFACES}" 2> /dev/null
    
            for port in ${TAG_BASED_MAP}
            do 
                       vport_ifname="${lan_hwifname}.${port}"
                       vconfig add $lan_hwifname $port
                       ifconfig $vport_ifname 0.0.0.0
            done

            # restart all bridge                      
             Restart_Bridge_Group "1 2 3 4"

             for tag in 1 2 3 4
             do                                      
                    group=`Find_Bridge tag${tag}` 
                    lan_intf=`nvram get lan${group}_ifname`

                    if [ "$group" = "0" ]; then
                        continue
                    fi

                    vlan=`echo $TAG_BASED_MAP | cut -d " " -f $tag`
                    vport_ifname="$lan_hwifname.${vlan}"  

                    brctl addif $lan_intf $vport_ifname 2> /dev/null
             done                                                
    fi
}

Restart_PortBased_Vlan_Group()
{
    TAG_BASED_MAP=`nvram get vlan_alltags | sed 's/,/ /g'`
    VLAN_GROUP_MAP=`nvram get vlan_port_map | sed 's/,/ /g'`

    if [ "x$lan_group" != "x" ]; then        
            echo "Restart lan($lan_group) with port-based vlan enabled:"                
            # remove and shutdown the eth0.x from slecet bridge interface
            port=1
            for item in $VLAN_GROUP_MAP
            do 
                br_iface=$(($item+1))
                if [ "$br_iface" = "$lan_group" ]; then
                    Stop_Vlan_Intf ${port} 2> /dev/null
    
                    vport_ifname="${lan_hwifname}.${port}"
                    vconfig add $lan_hwifname $port
                    ifconfig $vport_ifname 0.0.0.0
                fi
                port=$(($port+1))
            done
          
            # restart select bridge interface
            Restart_Bridge_Group $lan_group
            
            # add relative eth0.x into select bridge interface
            port=1
            lan_intf=`nvram get lan${lan_group}_ifname`
            for item in $VLAN_GROUP_MAP
            do 
                br_iface=$(($item+1))
                if [ "$br_iface" = "$lan_group" ]; then
                    vport_ifname="${lan_hwifname}.${port}"
                    #echo " brctl addif $lan_intf $vport_ifname"                                                 
                    brctl addif $lan_intf $vport_ifname 2> /dev/null
                fi
                port=$(($port+1))
            done
            /etc/rc.d/lan_service.sh restart ${lan_group}
    else  
            echo "Restart lan(1-4) with port-based vlan enabled:" 

            Remove_Eth_From_Bridge "1 2 3 4" $lan_hwifname
            ifconfig $lan_hwifname 0.0.0.0 up       

            #echo "down all vlan/tag interfaces"         
            df_pvid=`echo ${TAG_BASED_MAP} | cut -d " " -f 1`
            exist_vlan_intf=`ifconfig -a | grep "eth0\."`
            exist_tag_vlan_intf=`ifconfig -a | grep "eth0.$df_pvid"`
            
            if [ "x$exist_vlan_intf" != "x" ] && [ "x$exist_tag_vlan_intf" != "x" ]; then  
                     echo "stop all vlan"                     
            elif [ "x$exist_vlan_intf" = "x" ]; then  
                     echo "stop port based vlan"                    
            fi                       

            VLAN_INTERFACES=`ifconfig -a | grep "eth0\." | cut -d " " -f 1 | cut -d "." -f 2`
            Stop_Vlan_Intf "${VLAN_INTERFACES}" 2> /dev/null
    
            for port in 1 2 3 4
            do 
                   vport_ifname="${lan_hwifname}.${port}"
                    vconfig add $lan_hwifname $port
                    ifconfig $vport_ifname 0.0.0.0
            done

            # restart all bridge                                    
             Restart_Bridge_Group "1 2 3 4"                               

             for vlan in 1 2 3 4
             do 
                    vport_ifname="$lan_hwifname.$vlan"                
    
                    group=`Find_Bridge vlan${vlan}` 
                    lan_intf=`nvram get lan${group}_ifname`

                    if [ "$group" = "0" ]; then
                        continue
                    fi
                    vlan_id=$(($vlan-1))
                    port=1
                    for item in $VLAN_GROUP_MAP
                    do 
                            if [ "$item" = "$vlan_id" ]; then
                                vport_ifname="$lan_hwifname.$port"      
                                #echo " brctl addif $lan_intf $vport_ifname"                                                 
                                brctl addif $lan_intf $vport_ifname 2> /dev/null
                            fi
                            port=$(($port+1))
                    done
             done                        
    fi
}

remove_vlan_intfs()
{
    exist_vlan_intf=`ifconfig -a | grep "eth0\."`        
    if [ "$exist_vlan_intf" != "" ]; then            
         TAG_BASED_MAP=`nvram get vlan_alltags | sed 's/,/ /g'`
         df_pvid=`echo ${TAG_BASED_MAP} | cut -d " " -f 1`
         exist_tag_vlan_intf=`ifconfig -a | grep "eth0.$df_pvid"`
            
          if [ "x$exist_tag_vlan_intf" != "x" ]; then  
               echo "stop tag based vlan"
          elif [ "x$exist_tag_vlan_intf" = "x" ]; then  
               echo "stop port based vlan"
          fi

          VLAN_INTERFACES=`ifconfig -a | grep "eth0\." | cut -d " " -f 1 | cut -d "." -f 2`
          Stop_Vlan_Intf "$VLAN_INTERFACES"
    fi
    # shutdoen lan interface (eth0) and remove from bridge                 
    #Remove_Eth_From_Bridge "1 2 3 4" $lan_hwifname
    
    # restart all bridge                      
    for item in 2 3 4
    do 
          BNAME=`nvram get lan${item}_ifname`     
          ifconfig $BNAME down   
          brctl delbr $BNAME 2> /dev/null 
    done
}

if [ "$action" = "vlan_remove" ]; then
    echo "remove all vlan intfs"
    remove_vlan_intfs
    exit;
fi

if [ "$wan_phy_mode" = "adsl" ]; then     
    if [ "$vlan_enable" = "1" ]; then                                                                 
            vlan_type=`nvram get vlan_type`            
            if [ "$vlan_type" = "0" ]; then   # port based vlan                        
                    Restart_PortBased_Vlan_Group
            elif [ "$vlan_type" = "1" ]; then   # tag based vlan
                    Restart_TagBased_Vlan_Group
            fi          
    else        
                 #exist_vlan_intf=`ifconfig -a | grep "eth0\."`
                 if [ "$exist_vlan_intf" != "" ]; then            
                        TAG_BASED_MAP=`nvram get vlan_alltags | sed 's/,/ /g'`
                        df_pvid=`echo ${TAG_BASED_MAP} | cut -d " " -f 1`
                        exist_tag_vlan_intf=`ifconfig -a | grep "eth0.$df_pvid"`
            
                        if [ "x$exist_tag_vlan_intf" != "x" ]; then  
                              echo "stop tag based vlan"                             
                        elif [ "x$exist_tag_vlan_intf" = "x" ]; then  
                              echo "stop port based vlan"                                   
                        fi

                        VLAN_INTERFACES=`ifconfig -a | grep "eth0\." | cut -d " " -f 1 | cut -d "." -f 2`
                        Stop_Vlan_Intf "$VLAN_INTERFACES"                                         
                fi
                # shutdoen lan interface (eth0) and remove from bridge                 
                Remove_Eth_From_Bridge "1 2 3 4" "$lan_hwifnames"

                # restart all bridge                      
                Restart_Bridge_Group "1 2 3 4" "1 2 3"
        
                #group=`Find_Bridge $lan_hwifname`    
                group=1
                                
                # add ethernet (eth0) to right bridge interface
                lan_intf=`nvram get lan${group}_ifname`
		if [ "x$lan_hwifnames" != "x" ]; then
                	for i in $lan_hwifnames; do
                		echo "ifconfig $i hw ether $lan_hwaddr"
				ifconfig $i down	
	                	ifconfig $i hw ether $lan_hwaddr        
				ifconfig $i up
                        	echo "brctl addif $lan_intf $i"
	                        brctl addif $lan_intf $i 2> /dev/null
        	        done
		else
                	echo "ifconfig $lan_hwifname hw ether $lan_hwaddr"
	                ifconfig $lan_hwifname hw ether $lan_hwaddr        
        	        ifconfig $lan_hwifname 0.0.0.0
                	brctl addif $lan_intf $lan_hwifname 2> /dev/null         
		fi

                if [ "x$lan_group" != "x" ]; then  
                        /etc/rc.d/lan_service.sh restart ${lan_group}
                fi                                                                   
    fi    
else   
    # not adsl type
    # shutdoen lan interface (eth0) and remove from br0 
    ifconfig $lan_hwifname down
    brctl delif $lan_ifname $lan_hwifname 2> /dev/null
    brctl delif $lan_ifname $wan_hwifname 2> /dev/null

    # down the bridge (br0) 
    if [ -f $INITFILE ]; then    
          ifconfig $lan_ifname down      
    fi

    # create the bridge (br0) 
    if [ ! -f $INITFILE ]; then   
        brctl addbr $lan_ifname 2> /dev/null         
    fi

    brctl setfd $lan_ifname 0 2> /dev/null
    
    if [ "$(nvram get endis_wl_radio)" = "1" -a "$router_disable" = "1" ]; then
          brctl stp $lan_ifname 1 2> /dev/null
    else
           brctl stp $lan_ifname 0 2> /dev/null
    fi

    #Use as Access Point
    # To avoid to change mac address on br0, there are 2 ways as the followings,
    # 1. changed eth1 hwaddr equal to eth0 
    # 2. brctl addif br0 eth1, brctl addif br0 eth0
    
    echo "Configuring LAN , lan_ifname = $lan_ifname ........"
    
    if [ "x$lan_hwifnames" != "x" ]; then
    	for i in $lan_hwifnames; do
		ifconfig $i down	
        	ifconfig $i hw ether $lan_hwaddr
		ifconfig $i up
        	ifconfig $i hw ether $lan_hwaddr
        	echo "brctl addif $lan_ifname $i"
                brctl addif $lan_ifname $i 2> /dev/null
       	done
    else 	
        ifconfig $lan_hwifname hw ether $lan_hwaddr
        brctl addif $lan_ifname $lan_hwifname 2> /dev/null
    fi	
    ifconfig $lan_hwifname 0.0.0.0
    ifconfig $lan_ifname $LAN_IPADDR netmask $LAN_SUBNET

fi


echo "handle IPv6"

IPV6_PASS=`nvram get ipv6_pass`
extra_wan=`nvram get extra_wan_for_ipv6`
wan_hwaddr=`nvram get wan_factory_mac`
if [ "$extra_wan" != "" ]; then
	ifconfig $extra_wan hw ether $wan_hwaddr 2> /dev/null    
fi

extra_wan=`nvram get extra_wan_for_bridge`
if [ "$extra_wan" != "" ]; then
	ifconfig $extra_wan hw ether $wan_hwaddr 2> /dev/null    
fi

lan_hwaddr=`nvram get lan_hwaddr`

if [ ! -f $INITFILE ]; then
	echo 1 > $INITFILE 	
fi


