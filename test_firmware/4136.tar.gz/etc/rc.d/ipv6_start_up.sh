#!/bin/sh
WAN_PHY_MODE=`nvram get wan_phy_mode`
if [ "$WAN_PHY_MODE" = "adsl" ]; then
	iface=1
	if [ "$iface" = "`nvram get wan_default_iface`" ]; then
		DEFAULT_GW=1
	fi
else
	iface=""
	DEFAULT_GW=1
fi
WAN_IF_NAME=`nvram get wan${iface}_hwifname`
IPV6_WAN_TYPE=`nvram get ipv6_type`
IPV6_LAN_DHCP=`nvram get ipv6_dhcps_enable`
IPV6_LAN_TYPE=`nvram get ipv6_lan_type`
IPV6_GATEWAY=`nvram get ipv6_default_gateway`
IPV6_CONE=`nvram get wan_ipv6_cone_fitering`
VLAN_ENABLE=`nvram get vlan_enable`
PPPOE_PID=`ps | grep +ipv6 | grep pppd | awk '{printf $1}'`
IPv6_FILE="/proc/net/if_inet6"
UHTTPD_PID="/var/run/uhttpd.pid"
MODULE_PATH="/lib/modules/2.6.32.32"
MODULE=`cat /module_name`

defult_if_id() {

	IF_ID_ENABLE=`nvram get ipv6_dhcps_interface_id_enable`
	if [ "$IF_ID_ENABLE" = "0" ] || [ -z "$IF_ID_ENABLE" ];then
		if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
			LAN_IF_NUM="1 2 3 4"
			for i in $LAN_IF_NUM;
			do
				LAN_IF_NAME=`nvram get lan${i}_ifname`
				LAN_HW_ADDR=`ifconfig ${LAN_IF_NAME} | grep HWaddr | awk '{printf $5}'`
				if [ "x" != "x$LAN_HW_ADDR" ];then
				FIRST_SET=`expr substr "$LAN_HW_ADDR" 1 2`
				FIRST_SET=0x${FIRST_SET}
				FIRST_SET=$((FIRST_SET^2))
				FIRST_SET=`printf "%02x" $FIRST_SET`
				LAN_ADDR=`echo $LAN_HW_ADDR | awk -F: '{printf "'$FIRST_SET'"$2":"$3"ff:fe"$4":"$5$6}'`
				DELETE_IPV6=`ifconfig ${LAN_IF_NAME} | grep Scope:Link |awk '{printf $3}'`
				ip -6 addr delet $DELETE_IPV6 dev ${LAN_IF_NAME}
				ip -6 addr add fe80::$LAN_ADDR/64 dev ${LAN_IF_NAME}
				fi
			done
		else
			LAN_IF_NAME=`nvram get lan_ifname`
			LAN_HW_ADDR=`ifconfig ${LAN_IF_NAME} | grep HWaddr | awk '{printf $5}'`
			FIRST_SET=`expr substr "$LAN_HW_ADDR" 1 2`
			FIRST_SET=0x${FIRST_SET}
			FIRST_SET=$((FIRST_SET^2))
			FIRST_SET=`printf "%02x" $FIRST_SET`
			LAN_ADDR=`echo $LAN_HW_ADDR | awk -F: '{printf "'$FIRST_SET'"$2":"$3"ff:fe"$4":"$5$6}'`
			DELETE_IPV6=`ifconfig ${LAN_IF_NAME} | grep Scope:Link |awk '{printf $3}'`
			ip -6 addr delet $DELETE_IPV6 dev ${LAN_IF_NAME}
			ip -6 addr add fe80::$LAN_ADDR/64 dev ${LAN_IF_NAME}
		fi
	fi
}

id_enable() {

	IF_ID_ENABLE=`nvram get ipv6_dhcps_interface_id_enable`
	if [ "$IF_ID_ENABLE" = "1" ];then
		if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
			LAN_IF_NUM="1 2 3 4"
			for i in $LAN_IF_NUM;
			do
				INTERFACE_ID=`nvram get ipv6_dhcps_interface${i}_id`
				if [ -n "$INTERFACE_ID" ];then
					LAN_IF_NAME=`nvram get lan${i}_ifname`
					DELETE_IPV6=`ifconfig ${LAN_IF_NAME} | grep Scope:Link |awk '{printf $3}'`
					ip -6 addr delet $DELETE_IPV6 dev ${LAN_IF_NAME}
					ip -6 addr add fe80::$INTERFACE_ID/64 dev ${LAN_IF_NAME}
				fi
			done
		else
			INTERFACE_ID=`nvram get ipv6_dhcps_interface_id`
			if [ -n "$INTERFACE_ID" ];then
				LAN_IF_NAME=`nvram get lan_ifname`
				DELETE_IPV6=`ifconfig ${LAN_IF_NAME} | grep Scope:Link |awk '{printf $3}'`
				ip -6 addr delet $DELETE_IPV6 dev ${LAN_IF_NAME}
				ip -6 addr add fe80::$INTERFACE_ID/64 dev ${LAN_IF_NAME}
			fi
		fi
	fi
}

user_fixed() {

	RESOLV_CONFIG_FILE="/tmp/resolv.conf"
	IPV6_WAN_ADDR=`nvram get ipv6_fixed_wan_ip`
	IPV6_WAN_PREF=`nvram get ipv6_fixed_wan_prefix_len`
	IPV6_GATEWAY=`nvram get ipv6_fixed_gw_ip`
	IPV6_DNS1=`nvram get ipv6_fixed_dns1`
	IPV6_DNS2=`nvram get ipv6_fixed_dns2`
	IPV6_IF_NAME=`nvram get ipv6_if_name`

	nvram set ipv6_default_gateway=$IPV6_GATEWAY
	if [ -n "$IPV6_DNS1" ];then
		echo -n > $RESOLV_CONFIG_FILE
		echo 'adding dns '$IPV6_DNS1
		echo 'nameserver '$IPV6_DNS1 >> $RESOLV_CONFIG_FILE
		if [ -n "$IPV6_DNS2" ];then
			echo 'adding dns '$IPV6_DNS2
			echo 'nameserver '$IPV6_DNS2 >> $RESOLV_CONFIG_FILE
		fi
	fi
	ip -6 addr add $IPV6_WAN_ADDR/$IPV6_WAN_PREF dev $IPV6_IF_NAME
	ip -6 route add default via $IPV6_GATEWAY dev $IPV6_IF_NAME

	if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
		LAN_IF_NUM="1 2 3 4"
		for i in $LAN_IF_NUM;
		do
			IPV6_LAN_ADDR=`nvram get ipv6_fixed_lan${i}_ip`
			IPV6_LAN_PREF=`nvram get ipv6_fixed_lan${i}_prefix_len`
			LAN_IF_NAME=`nvram get lan${i}_ifname`
			ip -6 addr add $IPV6_LAN_ADDR/$IPV6_LAN_PREF dev $LAN_IF_NAME
		done	
	else
		IPV6_LAN_ADDR=`nvram get ipv6_fixed_lan_ip`
		IPV6_LAN_PREF=`nvram get ipv6_fixed_lan_prefix_len`
		LAN_IF_NAME=`nvram get lan_ifname`
		ip -6 addr add $IPV6_LAN_ADDR/$IPV6_LAN_PREF dev $LAN_IF_NAME
		LAN_IFNAME=`nvram get lan_hwifnames`
		for IFNAME in ${LAN_IFNAME};
		do
			LAN_LOCAL_IPV6=`ifconfig ${IFNAME} | grep Scope:Link |awk '{printf $3}'`
			ip -6 addr del $LAN_LOCAL_IPV6 dev $IFNAME  2> /dev/null
		done
	fi
}

check_mac_assign() 
{
       local proto=`nvram get wan_proto`
       local macassign=0
       case "$proto" in	                                       
       		static|dhcp|bigpond)  
                    macassign=`nvram get wan_ether_mac_assign`      
		    ;;
       		pppoe)
                    macassign=`nvram get wan_pppoe_mac_assign`
 		    ;;                                       
                pptp)
                    macassign=`nvram get wan_pptp_mac_assign`                        			
                    ;;
                l2tp)
                     macassign=`nvram get wan_l2tp_mac_assign`                                           
                     ;;                        		
        esac                

        echo $macassign
}

start() {
	echo "set IPv6 ..."
	if [ "$IPV6_WAN_TYPE" = "disabled" ];then
		echo "Disable IPv6 ..."
		echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6
		return
	fi
	if [ "$IPV6_WAN_TYPE" = "autoDetect" ];then
		if [ ! -e "/tmp/ipv6_auto_output" ];then
			echo "Detecting..." > /tmp/ipv6_auto_output
		fi
		nvram set net_web_sig_handle=1
		kill -31 `cat ${UHTTPD_PID}`
		echo "WAN IPv6 Detecting..."
		DETECT_TYPE=`cat /tmp/ipv6_auto_output | awk '{printf $1}'`
		while [ "$DETECT_TYPE" = "Detecting..." ]
		do
			sleep 1
			DETECT_TYPE=`cat /tmp/ipv6_auto_output | awk '{printf $1}'`
		done
		case "$DETECT_TYPE" in
		6to4)
			IPV6_WAN_TYPE="6to4"
			;;
		Pass)
			IPV6_WAN_TYPE="bridge"
			;;
		Auto)
			IPV6_WAN_TYPE="autoConfig"
			;;
		DHCP)
			IPV6_WAN_TYPE="dhcp"
			;;
		the)
			return
			;;
		*)
			IPV6_WAN_TYPE="autoDetect"
			;;
		esac
	fi
	id_enable
	case "$IPV6_WAN_TYPE" in
		6to4)
			nvram set ipv6_if_name=sit1
			echo 1 > /proc/sys/net/ipv6/conf/all/forwarding
			echo 0 > /proc/sys/net/ipv6/conf/all/autoconf
			/etc/rc.d/ipv6_6to4.sh start
			;;
		autoConfig)
			nvram set ipv6_if_name=$WAN_IF_NAME
			nvram set net_web_sig_handle=2
			kill -31 `cat ${UHTTPD_PID}`
			sleep 5
			echo 1 > /proc/sys/net/ipv6/conf/all/forwarding
			echo 0 > /proc/sys/net/ipv6/conf/all/autoconf
			/etc/rc.d/ipv6_dhcp6c.sh start
			IPV6_GATEWAY=`nvram get ipv6_default_gateway`
			ip -6 route add default via $IPV6_GATEWAY dev $WAN_IF_NAME
			;;
		autoDetect)
			;;
		dhcp)
			nvram set ipv6_if_name=$WAN_IF_NAME
			echo 0 > /proc/sys/net/ipv6/conf/all/autoconf
			echo 1 > /proc/sys/net/ipv6/conf/all/forwarding
			TMP_WAN_IPV6=`ifconfig ${WAN_IF_NAME} | grep Scope:Global `
			if [ -n $TMP_LAN_IPV6 ];then
				DELETE_IPV6=`echo $TMP_WAN_IPV6 | awk '{printf $3}' `
				ip -6 addr delet $DELETE_IPV6 dev ${WAN_IF_NAME}
			fi
			nvram set net_web_sig_handle=2
			kill -31 `cat ${UHTTPD_PID}`
			sleep 5
			#echo 0 > /proc/sys/net/ipv6/conf/all/autoconf
			/etc/rc.d/ipv6_dhcp6c.sh start
			IPV6_GATEWAY=`nvram get ipv6_default_gateway`
			ip -6 route add default via $IPV6_GATEWAY dev $WAN_IF_NAME
			;;
		fixed)
			nvram set ipv6_if_name=$WAN_IF_NAME
			echo 1 > /proc/sys/net/ipv6/conf/all/forwarding
			echo 0 > /proc/sys/net/ipv6/conf/all/autoconf
			user_fixed
			;;
		bridge)
			LAN_IFNAME=`nvram get lan_hwifnames`
			IFNAME=`echo "${LAN_IFNAME}" | awk '{printf $1}' `
			ifconfig $IFNAME promisc
			ifconfig br0 promisc
			if [ "$WAN_PHY_MODE" = "eth" ] && [ "$MODULE" = "DEGN1000v3" ];then
				#enable custom_Passthru (for realtak ethernet wan)
				echo 1 > /proc/custom_Passthru
			else
				/etc/rc.d/ipv6_passthrough.sh start
			fi
			sleep 5
			#lan phy down
				echo "1" > /proc/rtl865x/dni_phyDown
			sleep 3
			#lan phy up
				echo "0" > /proc/rtl865x/dni_phyDown
			return
			;;
		pppoe)
			nvram set ipv6_if_name=
			/etc/rc.d/ipv6_pppoe.sh start
			echo 1 > /proc/sys/net/ipv6/conf/all/forwarding
			echo 0 > /proc/sys/net/ipv6/conf/all/autoconf
			;;
		*)
			echo $IPV6_WAN_TYPE "error type!"
			return
			;;
	esac

	sleep 5

	READY_LOGO_MODE=`nvram get ready_logo_mode`
	IPV6_IF_NAME=`nvram get ipv6_if_name`
	wan_ping=`nvram get wan${iface}_endis_rspToPing`
	log_enable=`nvram get LogFirewallEnable`
	WAN_GLOBAL_IPV6=`ifconfig ${IPV6_IF_NAME} | grep Scope:Global |awk '{printf $3}' | awk -F/ '{printf $1}'`
	if [ "$READY_LOGO_MODE" != "1" ];then
		if [ "$wan_ping" = "1" ]; then
			ip6tables -t mangle -A PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_GLOBAL_IPV6 -j ACCEPT
		else
			 if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
				LAN_IF_NUM="1 2 3 4"
 				for i in $LAN_IF_NUM;
				do
					LAN_IF_NAME=`nvram get lan${i}_ifname`
					ip6tables -t mangle -A PREROUTING -p icmpv6 --icmpv6-type 128 -i $LAN_IF_NAME -d $WAN_GLOBAL_IPV6 -j ACCEPT
				done
			else
				LAN_IF_NAME=`nvram get lan_ifname`
				ip6tables -t mangle -A PREROUTING -p icmpv6 --icmpv6-type 128 -i $LAN_IF_NAME -d $WAN_GLOBAL_IPV6 -j ACCEPT

			fi

			if [ "$log_enable" = "1" ]; then
				ip6tables -t mangle -A PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_GLOBAL_IPV6 -j LOG --log-level 7 --log-prefix "FIREWALL Block Ping from Internet"
			fi
			ip6tables -t mangle -A PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_GLOBAL_IPV6 -j DROP
		fi

		if [ "$IPV6_CONE" = "1" ];then
			ip6tables -t mangle -I PREROUTING -i $IPV6_IF_NAME -j IPV6CONE --ipv6cone-type restrict
		else
			ip6tables -t mangle -I PREROUTING -i $IPV6_IF_NAME -j IPV6CONE --ipv6cone-type full
		fi
	fi

	if [ ! -e /var/run/radvd.pid ];then 
	/etc/rc.d/ipv6_radvd.sh start
	fi

	if [ "$READY_LOGO_MODE" != "1" ];then
	if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
		LAN_IF_NUM="1 2 3 4"
		for i in $LAN_IF_NUM;
		do
			#if [ ! -e /var/run/dhcp6s.pid ];then
			/etc/rc.d/ipv6_dhcp6s.sh start ${i}
			#fi
			LAN_IF_NAME=`nvram get lan${i}_ifname`
			LAN_IP6_ADDR=`ifconfig ${LAN_IF_NAME} | grep Scope:Link | awk '{printf $3}' | awk -F/ '{printf $1}'`
			nvram set ipv6_lan${i}_addr=${LAN_IP6_ADDR}
			ip6tables -A PREROUTING -t mangle -i ${LAN_IF_NAME} -p udp --dport 53 -j IPV6DNS_HIJACK --url .www.routerlogin.com,.routerlogin.com,.www.routerlogin.net,.routerlogin.net,.readyshare.routerlogin.net --state normal 
		done
	else
		if [ ! -e /var/run/dhcp6s.pid ];then
		/etc/rc.d/ipv6_dhcp6s.sh start
		fi
		LAN_IF_NAME=`nvram get lan_ifname`
		LAN_IP6_ADDR=`ifconfig ${LAN_IF_NAME} | grep Scope:Link | awk '{printf $3}' | awk -F/ '{printf $1}'`
		nvram set ipv6_lan_addr=${LAN_IP6_ADDR}
		ip6tables -A PREROUTING -t mangle -i ${LAN_IF_NAME} -p udp --dport 53 -j IPV6DNS_HIJACK --url .www.routerlogin.com,.routerlogin.com,.www.routerlogin.net,.routerlogin.net,.readyshare.routerlogin.net --state normal
	fi

	#lan phy down
	echo "1" > /proc/rtl865x/dni_phyDown
	sleep 3
	#lan phy up
	echo "0" > /proc/rtl865x/dni_phyDown
	fi
	echo "IPv6 init finish!!"

	RETVAL=$?
	return $RETVAL
}

stop() {

	echo "remove ipv6 ..."
	
	if [ "$READY_LOGO_MODE" != "1" ];then
	echo 1 > /proc/sys/net/ipv6/conf/all/autoconf
	echo 0 > /proc/sys/net/ipv6/conf/all/forwarding
	fi

	if [ -n "$PPPOE_PID" ];then
		kill $PPPOE_PID
	fi
	ip6tables -t mangle -F

	/etc/rc.d/ipv6_6to4.sh stop
	/etc/rc.d/ipv6_dhcp6c.sh stop
	/etc/rc.d/ipv6_radvd.sh stop
	/etc/rc.d/ipv6_dhcp6s.sh stop
	/etc/rc.d/ipv6_passthrough.sh stop
	#disable custom_Passthru (for realtek ethernet wan)
		if [ "$MODULE" = "DEGN1000v3" ];then
			echo 0 > /proc/custom_Passthru
		fi

	if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
		LAN_IF_NUM="1 2 3 4"
		for i in $LAN_IF_NUM;
		do
			LAN_IF_NAME=`nvram get lan${i}_ifname`
			TMP_LAN_IPV6=`ifconfig ${LAN_IF_NAME} | grep Scope:Global `
			while [ -n "$TMP_LAN_IPV6" ]
			do
				DELETE_IPV6=`echo $TMP_LAN_IPV6 | awk '{printf $3}' `
				ip -6 addr delet $DELETE_IPV6 dev ${LAN_IF_NAME}
				TMP_LAN_IPV6=`ifconfig ${LAN_IF_NAME} | grep Scope:Global`	
			done
		done
	else
		LAN_IF_NAME=`nvram get lan_ifname`
		TMP_LAN_IPV6=`ifconfig ${LAN_IF_NAME} | grep Scope:Global `
		while [ -n "$TMP_LAN_IPV6" ]
		do
			DELETE_IPV6=`echo $TMP_LAN_IPV6 | awk '{printf $3}' `
			ip -6 addr delet $DELETE_IPV6 dev ${LAN_IF_NAME}
			TMP_LAN_IPV6=`ifconfig ${LAN_IF_NAME} | grep Scope:Global`
		done
	fi

	IPV6_IF_NAME=`nvram get ipv6_if_name`
	TMP_WAN_IPV6=`ifconfig ${IPV6_IF_NAME} | grep Scope:Global | awk '{printf $3}' | awk -F/ '{printf $1}'`
	ip6tables -t mangle -D PREROUTING -p icmpv6 --icmpv6-type 128 -d $TMP_WAN_IPV6 -j ACCEPT 2> /dev/null
	ip6tables -t mangle -D PREROUTING -p icmpv6 --icmpv6-type 128 -d $TMP_WAN_IPV6 -j DROP 2> /dev/null
	ip6tables -t mangle -D PREROUTING -i $IPV6_IF_NAME -j IPV6CONE --ipv6cone-type restrict 2> /dev/null
	ip6tables -t mangle -D PREROUTING -i $IPV6_IF_NAME -j IPV6CONE --ipv6cone-type full	2> /dev/null
	 if [ "$WAN_PHY_MODE" = "adsl" ] && [ "$VLAN_ENABLE" = "1" ]; then
		LAN_IF_NUM="1 2 3 4"
		for i in $LAN_IF_NUM;
		do
			LAN_IF_NAME=`nvram get lan${i}_ifname`
			ip6tables -t mangle -D PREROUTING -p icmpv6 --icmpv6-type 128 -i $LAN_IF_NAME -d $TMP_WAN_IPV6 -j ACCEPT 2> /dev/null
		done
	else
		LAN_IF_NAME=`nvram get lan_ifname`
		ip6tables -t mangle -D PREROUTING -p icmpv6 --icmpv6-type 128 -i $LAN_IF_NAME -d $TMP_WAN_IPV6 -j ACCEPT 2> /dev/null
	fi
	while [ -n "$TMP_WAN_IPV6" ]
	do
		DELETE_IPV6=`echo $TMP_WAN_IPV6 | awk '{printf $3}' `
		ip -6 addr delet $DELETE_IPV6 dev ${WAN_IF_NAME}
		TMP_WAN_IPV6=`ifconfig ${WAN_IF_NAME} | grep Scope:Global`
	done
	ip -6 route delete default
	defult_if_id

	RETVAL=$?
	return $RETVAL
}


# See how we were called.
# insmod $MODULE_PATH/ipv6.ko #if ipv6 is module
case "$1" in
  start)
	if [ -e "$IPv6_FILE" ];then
    	start
	else
		echo "ipv6 module is not insert"
	fi
    ;;
  stop)
    stop
    ;;
  restart|reload)
    stop
    start
    RETVAL=$?
    ;;
  *)
    echo $"Usage: $0 {start|stop|restart}"
    exit 1
esac

exit $RETVAL

