#!/bin/sh

lan_ifname=`nvram get lan$2_ifname`
lan_ipaddr=`nvram get lan$2_ipaddr`

iptables -t mangle -D PREROUTING -j mangle_dns_hijack 2> /dev/null
iptables -t mangle -I PREROUTING -j mangle_dns_hijack

start()
{
        #if [ "`nvram get wan_lan_ip_conflict`" = "1" ]; then
        if [ "`nvram get wanlan_conflict`" = "1" ]; then
		iptables -t mangle -A mangle_dns_hijack -i $lan_ifname ! -d $lan_ipaddr -p udp --dport 53 -j DNS_HIJACK --url .as.xboxlive.com,.tgs.xboxlive.com,.macs.xboxlive.com --state blank
	else
		dns_hijack=$(nvram get dns_hijack)

		if [ "$dns_hijack" = "1" ];then
			iptables -t mangle -A mangle_dns_hijack -i $lan_ifname ! -d $lan_ipaddr -p udp --dport 53 -j DNS_HIJACK --url .as.xboxlive.com,.tgs.xboxlive.com,.macs.xboxlive.com --state blank
		elif [ "$dns_hijack" = "0" ];then
			iptables -t mangle -A mangle_dns_hijack -i $lan_ifname ! -d $lan_ipaddr -p udp --dport 53 -j DNS_HIJACK --url .www.routerlogin.com,.routerlogin.com,.www.routerlogin.net,.routerlogin.net,.readyshare.routerlogin.net --state normal
		fi
	fi
}

stop()
{

	#if [ "`nvram get wan_lan_ip_conflict`" = "1" ]; then
	if [ "`nvram get wanlan_conflict`" = "1" ]; then
                iptables -t mangle -D mangle_dns_hijack -i $lan_ifname ! -d $lan_ipaddr -p udp --dport 53 -j DNS_HIJACK --url .as.xboxlive.com,.tgs.xboxlive.com,.macs.xboxlive.com --state blank 2> /dev/null  
        else
                dns_hijack=$(nvram get dns_hijack)

                if [ "$dns_hijack" = "1" ];then
                        iptables -t mangle -D mangle_dns_hijack -i $lan_ifname ! -d  $lan_ipaddr -p udp --dport 53 -j DNS_HIJACK --url .as.xboxlive.com,.tgs.xboxlive.com,.macs.xboxlive.com --state blank 2> /dev/null  
                elif [ "$dns_hijack" = "0" ];then
                        iptables -t mangle -D mangle_dns_hijack -i $lan_ifname ! -d  $lan_ipaddr -p udp --dport 53 -j DNS_HIJACK --url .www.routerlogin.com,.routerlogin.com,.www.routerlogin.net,.routerlogin.net,.readyshare.routerlogin.net --state normal 2> /dev/null  
                fi
        fi

	iptables -t mangle -F mangle_dns_hijack

}

# See how we were called.
case "$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  restart)
	stop
	start
	;;
  *)
        echo $"Usage: $0 {start|stop|restart|AddChain|restartChain}"
        exit 1
esac

exit $RETVAL

