#!/bin/sh

NVRAM="/usr/sbin/nvram"

ETH_WAN_INDEX=`nvram get eth_wan_iface`
wan_phy_auto=`nvram get wan_phy_auto`
wan_phy_mode=`nvram get wan_phy_mode`
wan_default_iface=`nvram get wan_default_iface`
if [ "$wan_phy_mode" = "adsl" ]; then
        MULTI_WAN=1
fi

if [ "$MULTI_WAN" = "1" ]; then
        iface=$1
        index=$iface
        intranet=$2
        wan_ifname=`nvram get wan${iface}_ifname`        

        if [ "$wan_phy_auto" = "1" ] && [ "$iface" = "$wan_default_iface" ]; then
                wan_ip=`nvram get wan${iface}_default_ipaddr`
                if [ "x$wan_ip" = "x" ]; then
                        iface=$ETH_WAN_INDEX
                        wan_ifname=`nvram get wan${iface}_ifname` 
                fi
        fi
        if [ "$iface" = "$ETH_WAN_INDEX" ]; then        
                index=$wan_default_iface
        fi
fi

echo $"restart WAN${iface} respond ping"

READY_LOGO_MODE=`nvram get ready_logo_mode`
wan_ping=`nvram get wan${index}_endis_rspToPing`

wan_ifname=`nvram get wan${iface}_hwifname`
log_enable=`nvram get LogFirewallEnable`
WAN_LOCAL_IPV6=`ifconfig ${wan_ifname} | grep Scope:Link |awk '{printf $3}' | awk -F/ '{printf $1}'`
IPV6_WAN_TYPE=`nvram get ipv6_type`
wan_proto=`nvram get wan${iface}_proto`
dy_pptp=`nvram get dy${iface}_pptp`
dy_l2tp=`nvram get dy${iface}_l2tp`
pppoe_intranet_wan_assign=`nvram get wan${iface}_pppoe_intranet_wan_assign`
wan_ip=""

fw_region=`cat /firmware_region`
module_name=`cat /module_name`
if [ "$fw_region" = "RU" ] && [ "$module_name" = "DEGN1000v3" ]; then
        RUSSIA_PPPOE=1
fi

get_intra_wan_ip()
{
        if [ "$wan_proto" = "pptp" ]; then
        	if [ "$dy_pptp" = "1" ]; then
        		wan_ip=`$NVRAM get wan${iface}_dhcp_ipaddr`
        	else
        		wan_ip=`$NVRAM get wan${iface}_pptp_local_ip`
        	fi
        fi

        if [ "$wan_proto" = "l2tp" ]; then
                if [ "$dy_l2tp" = "1" ]; then
                        wan_ip=`$NVRAM get wan${iface}_dhcp_ipaddr`
                else
                        wan_ip=`$NVRAM get wan${iface}_l2tp_local_ip`
                fi
        fi

        if [ "$wan_proto" = "pppoe" ]; then
        	if [ "`cat /module_name`" = "DEGN1000v3" ] && [ "`cat /firmware_region`" = "RU" ]; then
        		if [ "$pppoe_intranet_wan_assign" = "0" ]; then
        		        wan_ip=`$NVRAM get wan${iface}_dhcp_ipaddr`
                        else
                                wan_ip=`$NVRAM get wan${iface}_pppoe_intranet_ip`
                        fi
		fi
	fi
}

check_dual_interafce()
{
	if [ "$1" = "add" ];then
		OP="-A"
	else
		OP="-D"
	fi
	if [ "$wan_proto" = "pptp" ]; then
		if [ "$dy_pptp" = "1" ]; then
			dual_ip=`$NVRAM get wan${iface}_dhcp_ipaddr`
		else
			dual_ip=`$NVRAM get wan${iface}_pptp_local_ip`
		fi
	fi
    if [ "$wan_proto" = "l2tp" ]; then
        if [ "$dy_l2tp" = "1" ]; then
            dual_ip=`$NVRAM get wan${iface}_dhcp_ipaddr`
        else
            dual_ip=`$NVRAM get wan${iface}_l2tp_local_ip`
        fi
    fi
        
	if [ "$wan_proto" = "pppoe" ]; then
        	if [ "`cat /module_name`" = "DEGN1000v3" ]; then
        		if [ "$pppoe_intranet_wan_assign" = "0" ]; then
        		        dual_ip=`$NVRAM get wan${iface}_dhcp_ipaddr`
                        else
                                dual_ip=`$NVRAM get wan${iface}_pppoe_intranet_ip`
                        fi
		fi
	fi

	if [ "$dual_ip" = "" ];then return;fi

        if [ "$1" = "add" ]; then
                if [ "$wan_ping" = "1" ]; then
        	        iptables -t nat $OP nat_local_server -p icmp --icmp-type 8 -d $dual_ip -j ACCEPT                     
        	        iptables $OP local_server -p icmp --icmp-type 8 -d $dual_ip -j ACCEPT	
                else
                        if [ "$log_enable" = "1" ]; then
                	        iptables $OP local_server -p icmp --icmp-type 8 -d $dual_ip -m log --log-prefix "FIREWALL Block Ping from Internet" -j DROP
                	else
                	        iptables $OP local_server -p icmp --icmp-type 8 -d $dual_ip -j DROP
                	fi         
                fi
        else
                iptables $OP local_server -p icmp --icmp-type 8 -d $dual_ip -j ACCEPT 2> /dev/null
                iptables $OP local_server -p icmp --icmp-type 8 -d $dual_ip -j DROP 2> /dev/null
                iptables $OP local_server -p icmp --icmp-type 8 -d $dual_ip -m log --log-prefix "FIREWALL Block Ping from Internet" -j DROP 2> /dev/null
                iptables -t nat $OP nat_local_server -p icmp --icmp-type 8 -d $dual_ip -j ACCEPT 2> /dev/null
        fi
}

if [ "$MULTI_WAN" = "1" ]; then
    if [ "$intranet" = "1" ]; then
            local old_wan_ip=`nvram get wan${index}_intra_ipaddr_ping`
            nvram unset wan${index}_intra_ipaddr_ping
            
            iptables -D local_server -p icmp --icmp-type 8 -d $old_wan_ip -j ACCEPT 2> /dev/null
            iptables -D local_server -p icmp --icmp-type 8 -d $old_wan_ip -j DROP 2> /dev/null
            iptables -D local_server -p icmp --icmp-type 8 -d $old_wan_ip -m log --log-prefix "FIREWALL Block Ping from Internet" -j DROP 2> /dev/null
            iptables -t nat -D nat_local_server -p icmp --icmp-type 8 -d $old_wan_ip -j ACCEPT 2> /dev/null            
    else
            local old_wan_ip=`nvram get wan${index}_ipaddr_ping`
            if [ "x$intranet" != "x" ]; then
                    nvram unset wan${index}_ipaddr_ping
            fi

            iptables -D local_server -p icmp --icmp-type 8 -d $old_wan_ip -j ACCEPT 2> /dev/null
            iptables -D local_server -p icmp --icmp-type 8 -d $old_wan_ip -j DROP 2> /dev/null
            iptables -D local_server -p icmp --icmp-type 8 -d $old_wan_ip -m log --log-prefix "FIREWALL Block Ping from Internet" -j DROP 2> /dev/null
            iptables -t nat -D nat_local_server -p icmp --icmp-type 8 -d $old_wan_ip -j ACCEPT 2> /dev/null

            if [ "$RUSSIA_PPPOE" = "1" ]; then
                    if [ "$wan_proto" != "pptp" ] && [ "$wan_proto" != "l2tp" ] && [ "$wan_proto" != "pppoe" ] && [ "$intranet" = "0" ]; then
                        old_intra_ip=`nvram get wan${index}_intra_ipaddr_ping`
                        nvram unset wan${index}_intra_ipaddr_ping                
        
                        iptables -D local_server -p icmp --icmp-type 8 -d $old_intra_ip -j ACCEPT 2> /dev/null
                        iptables -D local_server -p icmp --icmp-type 8 -d $old_intra_ip -j DROP 2> /dev/null
                        iptables -D local_server -p icmp --icmp-type 8 -d $old_intra_ip -m log --log-prefix "FIREWALL Block Ping from Internet" -j DROP 2> /dev/null
                        iptables -t nat -D nat_local_server -p icmp --icmp-type 8 -d $old_intra_ip -j ACCEPT 2> /dev/null
                    fi
            else
                    if [ "$wan_proto" != "pptp" ] && [ "$wan_proto" != "l2tp" ] && [ "$intranet" = "0" ]; then
                        old_intra_ip=`nvram get wan${index}_intra_ipaddr_ping`
                        nvram unset wan${index}_intra_ipaddr_ping                
        
                        iptables -D local_server -p icmp --icmp-type 8 -d $old_intra_ip -j ACCEPT 2> /dev/null
                        iptables -D local_server -p icmp --icmp-type 8 -d $old_intra_ip -j DROP 2> /dev/null
                        iptables -D local_server -p icmp --icmp-type 8 -d $old_intra_ip -m log --log-prefix "FIREWALL Block Ping from Internet" -j DROP 2> /dev/null
                        iptables -t nat -D nat_local_server -p icmp --icmp-type 8 -d $old_intra_ip -j ACCEPT 2> /dev/null
                    fi
            fi

            if [ "x$intranet" = "x" ]; then
                    check_dual_interafce "del"
            fi
    fi
else
    iptables -D local_server -p icmp --icmp-type 8 -j ACCEPT 2> /dev/null
    iptables -D local_server -p icmp --icmp-type 8 -j DROP 2> /dev/null
    iptables -D local_server -p icmp --icmp-type 8 -m log --log-prefix "FIREWALL Block Ping from Internet" -j DROP 2> /dev/null
    iptables -t nat -D nat_local_server -p icmp --icmp-type 8 -j ACCEPT 2> /dev/null
fi
    ip6tables -t mangle -D PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_LOCAL_IPV6 -j ACCEPT 2> /dev/null
    ip6tables -t mangle -D PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_LOCAL_IPV6 -j DROP 2> /dev/null


if [ "$wan_ping" = "1" ]; then
    if [ "$MULTI_WAN" = "1" ]; then
            if [ "$intranet" = "1" ]; then
                    get_intra_wan_ip
                    nvram set wan${index}_intra_ipaddr_ping=$wan_ip
                    if [ "$wan_ip" = "" ];then return;fi

                    iptables -t nat -A nat_local_server -p icmp --icmp-type 8 -d $wan_ip -j ACCEPT
    		    iptables -A local_server -p icmp --icmp-type 8 -d $wan_ip -j ACCEPT                                       
            else
                    local wan_ip=`nvram get wan${iface}_default_ipaddr`

                    nvram set wan${index}_ipaddr_ping=$wan_ip
                    iptables -t nat -A nat_local_server -p icmp --icmp-type 8 -d $wan_ip -j ACCEPT
    		    iptables -A local_server -p icmp --icmp-type 8 -d $wan_ip -j ACCEPT    
                      
                    if [ "x$intranet" = "x" ]; then
                            check_dual_interafce "add"
                    fi
            fi
    else
		iptables -t nat -A nat_local_server -p icmp --icmp-type 8 -j ACCEPT
		iptables -A local_server -p icmp --icmp-type 8 -j ACCEPT
    fi
	ip6tables -t mangle -A PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_LOCAL_IPV6 -j ACCEPT

else
        if [ "$MULTI_WAN" = "1" ]; then
                if [ "$intranet" = "1" ]; then         
                        get_intra_wan_ip                       
                        nvram set wan${index}_intra_ipaddr_ping=$wan_ip                        
                        if [ "$wan_ip" = "" ];then return;fi
    
                        if [ "$log_enable" = "1" ]; then
        			    iptables -A local_server -p icmp --icmp-type 8 -d $wan_ip -m log --log-prefix "FIREWALL Block Ping from Internet" -j DROP
        		else
        			    iptables -A local_server -p icmp --icmp-type 8 -d $wan_ip -j DROP
        		fi                 
                else
                        local wan_ip=`nvram get wan${iface}_default_ipaddr`
                        nvram set wan${index}_ipaddr_ping=$wan_ip
                        if [ "$log_enable" = "1" ]; then
        			    iptables -A local_server -p icmp --icmp-type 8 -d $wan_ip -m log --log-prefix "FIREWALL Block Ping from Internet" -j DROP
        		else
        			    iptables -A local_server -p icmp --icmp-type 8 -d $wan_ip -j DROP
        		fi          
                        if [ "x$intranet" = "x" ]; then
                                check_dual_interafce "add"
                        fi                                    
                fi
        else
		if [ "$log_enable" = "1" ]; then
			iptables -A local_server -p icmp --icmp-type 8 -m log --log-prefix "FIREWALL Block Ping from Internet" -j DROP
		else
			iptables -A local_server -p icmp --icmp-type 8 -j DROP

		fi
        fi
		
		#IPv6
		if [ "$log_enable" = "1" ]; then
			ip6tables -t mangle -A PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_LOCAL_IPV6 -j LOG --log-level 7 --log-prefix "FIREWALL Block Ping from Internet"
		fi
		if [ "$READY_LOGO_MODE" != "1" ];then
		ip6tables -t mangle -A PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_LOCAL_IPV6 -j DROP
		fi
fi

if [ "$IPV6_WAN_TYPE" != "disabled" ] && [ "$READY_LOGO_MODE" != "1" ];then
	IPV6_IF_NAME=`nvram get ipv6_if_name`
	WAN_GLOBAL_IPV6=`ifconfig ${IPV6_IF_NAME} | grep Scope:Global |awk '{printf $3}' | awk -F/ '{printf $1}'`
	if [ -n "$WAN_GLOBAL_IPV6" ];then
	ip6tables -t mangle -D PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_GLOBAL_IPV6 -j ACCEPT 2> /dev/null
	ip6tables -t mangle -D PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_GLOBAL_IPV6 -j DROP 2> /dev/null

	if [ "$wan_ping" = "1" ]; then
        ip6tables -t mangle -A PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_GLOBAL_IPV6 -j ACCEPT
    else
        if [ "$log_enable" = "1" ]; then
            ip6tables -t mangle -A PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_GLOBAL_IPV6 -j LOG --log-level 7 --log-prefix "FIREWALL Block Ping from Internet"
        fi
        ip6tables -t mangle -A PREROUTING -p icmpv6 --icmpv6-type 128 -d $WAN_GLOBAL_IPV6 -j DROP
    fi
	fi
fi
