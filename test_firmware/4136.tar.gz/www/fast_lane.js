
function fast_lan_Main()
{
	location.href="FAST_lane.htm";
}

function show_trustedip()
{
	var cf=document.forms[0];
	var lanip_array=new Array();
	lanip_array=lan_ip.split('.');
	cf.su_IPAddress1.value=lanip_array[0];
	cf.su_IPAddress2.value=lanip_array[1];
	cf.su_IPAddress3.value=lanip_array[2];
}

function check_apply(cf)
{
        if(cf.fast_lan_enable.checked == true)
    		cf.fast_lane_endis.value=1;
    	else
    		cf.fast_lane_endis.value=0;
    
		if(cf.bandwidth.selectedIndex == 0)
			cf.fast_lan_bandwidth.value=0;
		else if(cf.bandwidth.selectedIndex == 1)
				cf.fast_lan_bandwidth.value=1;
		else if(cf.bandwidth.selectedIndex == 2)
				cf.fast_lan_bandwidth.value=2;
		else if(cf.bandwidth.selectedIndex == 3)
				cf.fast_lan_bandwidth.value=3;

        cf.fast_lane_IPAddress.value=cf.su_IPAddress1.value+'.'+cf.su_IPAddress2.value+'.'+cf.su_IPAddress3.value+'.'+cf.su_IPAddress4.value;
        if(checkipaddr(cf.fast_lane_IPAddress.value)==false)
		{
			alert("$invalid_ip");
			return false;
		}
		if(isSameIp(cf.fast_lane_IPAddress.value,lan_ip)==true)
		{
			alert("$invalid_ip");
			return false;
		}
		if(isSameSubNet(cf.fast_lane_IPAddress.value,lan_subnet,lan_ip,lan_subnet) == false)
		{	
			alert("$same_subnet_ip_trusted");
			return false;
		}

		if(cf.fast_lan_button[0].checked == true)
				cf.fast_lan_push_button.value = 0;
		else if(cf.fast_lan_button[1].checked == true)
					cf.fast_lan_push_button.value = 1;
}
