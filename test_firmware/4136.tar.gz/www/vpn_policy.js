
function check_vpn_policy_edit(cf)
{
	if( array_num == 0 )
	{
		location.href="edit_fail.htm";
		return false;
	}
	var count_select=0;
	var select_num;
	if( array_num == 1)
	{
		if(cf.ruleSelect.checked == true)
		{
			count_select++;
			select_num=1;
		}
	}
	else for(i=0;i<array_num;i++)
		if(cf.ruleSelect[i].checked == true)
		{
			count_select++;
			select_num=i+1;
		}
	if(count_select==0)
	{
		location.href="edit_fail.htm";
		return false;
	}
	else
	{
		cf.vpn_select_edit.value=select_num;
		cf.submit_flag.value="vpn_policy_editnum";
        var policy = eval ( 'vpn_policyArray' + select_num );
        var policy_info=policy.split('*');
        if(policy_info[0] == 0){
                cf.action="/apply.cgi?/VPN_edit_auto_policy.htm timestamp="+ts;
        }
        else if(policy_info[0] == 1){
                cf.action="/apply.cgi?/VPN_edit_manual_policy.htm timestamp="+ts;
        }
		cf.submit();
		return true;
	}
}


function check_vpn_services_apply(cf)
{
	for(i=1 ; i<=array_num ; i++)
	{
		checked = eval ( 'cf.ruleEndis' + i + '.checked' );
		if(checked == true){
                document.getElementById("rule_enable"+i).value = 1;
                document.getElementById("rule"+i).value = 1;
        }
		else {
                document.getElementById("rule_enable"+i).value = 0;
                document.getElementById("rule"+i).value = 0;
        }
	}

	cf.submit_flag.value="VPN_policy";
	cf.submit();
	return true;
}

function check_vpn_policy_del(cf)
{
	if( array_num == 0 )
	{
		location.href="del_fail.htm";
		return false;
	}
	var count_select=0;
	var select_num;
	if( array_num == 1)
	{
		if(cf.ruleSelect.checked == true)
		{
			count_select++;
			select_num=1;
		}
	}
	else for(i=0;i<array_num;i++)
		if(cf.ruleSelect[i].checked == true)
		{
			count_select++;
			select_num=i+1;
		}
	if(count_select==0)
	{
		location.href="del_fail.htm";
		return false;
	}
	else
	{
		cf.vpn_select_del.value=select_num;
		cf.submit_flag.value="vpn_policy_del";
		cf.submit();
		return true;
	}
}

function setIP(cf, local)
{
	var type;
    
    if (local == 1) {
        type = cf.loacl_ip_type.value;
        if (type == 0 || type == 1) {  /* default and any */
            setDisabled(1, cf.lsip_1, cf.lsip_2, cf.lsip_3, cf.lsip_4);
            setDisabled(1, cf.leip_1, cf.leip_2, cf.leip_3, cf.leip_4);
            setDisabled(1, cf.lmip_1, cf.lmip_2, cf.lmip_3, cf.lmip_4);
        }
        else  if (type == 2) {  /* single */
            setDisabled(0, cf.lsip_1, cf.lsip_2, cf.lsip_3, cf.lsip_4);
            setDisabled(1, cf.leip_1, cf.leip_2, cf.leip_3, cf.leip_4);
            setDisabled(1, cf.lmip_1, cf.lmip_2, cf.lmip_3, cf.lmip_4);
        }
        else  if (type == 3) { /* range */
                setDisabled(1, cf.lmip_1, cf.lmip_2, cf.lmip_3, cf.lmip_4);
                setDisabled(0, cf.lsip_1, cf.lsip_2, cf.lsip_3, cf.lsip_4);
                setDisabled(0, cf.leip_1, cf.leip_2, cf.leip_3, cf.leip_4);
        }
        else{
                setDisabled(0, cf.lmip_1, cf.lmip_2, cf.lmip_3, cf.lmip_4);
                setDisabled(0, cf.lsip_1, cf.lsip_2, cf.lsip_3, cf.lsip_4);
                setDisabled(1, cf.leip_1, cf.leip_2, cf.leip_3, cf.leip_4);
        }
    }
    else {
         type = cf.remote_ip_type.value;
         if (type == 0 || type == 1) {
            setDisabled(1, cf.rsip_1, cf.rsip_2, cf.rsip_3, cf.rsip_4);
            setDisabled(1, cf.reip_1, cf.reip_2, cf.reip_3, cf.reip_4);
            setDisabled(1, cf.rmip_1, cf.rmip_2, cf.rmip_3, cf.rmip_4);
        }
        else  if (type == 2) {
            setDisabled(0, cf.rsip_1, cf.rsip_2, cf.rsip_3, cf.rsip_4);
            setDisabled(1, cf.reip_1, cf.reip_2, cf.reip_3, cf.reip_4);
            setDisabled(1, cf.rmip_1, cf.rmip_2, cf.rmip_3, cf.rmip_4);
        }
        else  if (type == 3) {
               setDisabled(0, cf.rsip_1, cf.rsip_2, cf.rsip_3, cf.rsip_4);
               setDisabled(0, cf.reip_1, cf.reip_2, cf.reip_3, cf.reip_4);
               setDisabled(1, cf.rmip_1, cf.rmip_2, cf.rmip_3, cf.rmip_4);
        }
        else{
               setDisabled(0, cf.rsip_1, cf.rsip_2, cf.rsip_3, cf.rsip_4);
               setDisabled(1, cf.reip_1, cf.reip_2, cf.reip_3, cf.reip_4);
               setDisabled(0, cf.rmip_1, cf.rmip_2, cf.rmip_3, cf.rmip_4);
        }
    }
}

function check_manual_policy(form, type)
{                     
       if(form.policy_name.value == "") {
            alert("$vpn_invalid_policy_name");
            return false;
       }       
        // check endpoint IP Address
        if (form.endpoint_type.value == 0){
                if(checkipaddr(form.endpoint_data.value) == false) {
                    alert("$vpn_invalid_endpoint_ip");
                                return false;
                 }
        }      
        
        if (array_num > 0){
            for(i=1; i<=array_num ; i++){
                var policy = eval ( 'vpn_policyArray' + i );
                var policy_info=policy.split('*');
                var name=policy_info[2];
                var endpoint=policy_info[4];

                if(type == 0) {                    
                    if(form.policy_name.value == name) {
                        alert("$vpn_rule_duplicated");
                        return false;
                    }
                    if(form.endpoint_data.value == endpoint) {
                        alert("$vpn_endpoint_duplicated");
                        return false;
                    }
                }
                else  if(type == 1) {
                     if(select_edit != i) {
                         if((form.policy_name.value == name)) {
                            alert("$vpn_rule_duplicated");
                            return false;
                        }
                        if(form.endpoint_data.value == endpoint) {
                            alert("$vpn_endpoint_duplicated");
                            return false;
                        }
                    }
                }
            }
        }      

        if (form.loacl_ip_type.value == 0 || form.remote_ip_type.value == 0) { 
                    alert("$vpn_traffic_type");
                    return false;
        }

        if (form.loacl_ip_type.value == 2) { 
            form.l_start_ip.value=form.lsip_1.value+'.'+form.lsip_2.value+'.'+form.lsip_3.value+'.'+form.lsip_4.value;
             if(checkipaddr(form.l_start_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
        }
        else  if (form.loacl_ip_type.value == 3) { 
            form.l_start_ip.value=form.lsip_1.value+'.'+form.lsip_2.value+'.'+form.lsip_3.value+'.'+form.lsip_4.value;
            form.l_end_ip.value=form.leip_1.value+'.'+form.leip_2.value+'.'+form.leip_3.value+'.'+form.leip_4.value;
            if(checkipaddr(form.l_start_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
             if(checkipaddr(form.l_end_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
             if(isSameSubNet(form.l_start_ip.value, "255.255.255.0", form.l_end_ip.value, "255.255.255.0") == false) {
                            alert("$vpn_invalid_rangeip1");
                	        return false;
             }
             if(parseInt(form.lsip_4.value) > parseInt(form.leip_4.value)) {
                            alert("$vpn_invalid_rangeip2");
                	        return false;
             }            
        }
        else if  (form.loacl_ip_type.value == 4) {        
            form.l_start_ip.value=form.lsip_1.value+'.'+form.lsip_2.value+'.'+form.lsip_3.value+'.'+0;
            form.l_subnet.value=form.lmip_1.value+'.'+form.lmip_2.value+'.'+form.lmip_3.value+'.'+form.lmip_4.value;
            var ipaddr_array=form.l_start_ip.value.split('.');
            if(checkIP(ipaddr_array[0],ipaddr_array[1],ipaddr_array[2],ipaddr_array[3],254)==false)
        	{
        		alert("$invalid_ip");
        		return false;
        	}
        	if(form.lsip_1.value=="127")
        	{
        		alert("$invalid_ip");
        		return false;
        	}
        	if(parseInt(ipaddr_array[0])>=224)
        	{
        		alert("$invalid_ip");
        		return false;
        	}            

            if(checksubnet(form.l_subnet.value, 1)==false)
        	{
                    		alert("$invalid_mask");
                    		return false;
        	}
        }

         if (form.remote_ip_type.value == 2) { 
            form.r_start_ip.value=form.rsip_1.value+'.'+form.rsip_2.value+'.'+form.rsip_3.value+'.'+form.rsip_4.value;
             if(checkipaddr(form.r_start_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
        }
        else  if (form.remote_ip_type.value == 3) { 
            form.r_start_ip.value=form.rsip_1.value+'.'+form.rsip_2.value+'.'+form.rsip_3.value+'.'+form.rsip_4.value;
            form.r_end_ip.value=form.reip_1.value+'.'+form.reip_2.value+'.'+form.reip_3.value+'.'+form.reip_4.value;
            if(checkipaddr(form.r_start_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
             if(checkipaddr(form.r_end_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
              if(isSameSubNet(form.r_start_ip.value, "255.255.255.0", form.r_end_ip.value, "255.255.255.0") == false) {
                            alert("$vpn_invalid_rangeip1");
                	        return false;
             }
             if(parseInt(form.rsip_4.value) > parseInt(form.reip_4.value)) {
                            alert("$vpn_invalid_rangeip2");
                	        return false;
             }            
        }
        else if (form.remote_ip_type.value == 4) {    
            form.r_start_ip.value=form.rsip_1.value+'.'+form.rsip_2.value+'.'+form.rsip_3.value+'.'+0;
            form.r_subnet.value=form.rmip_1.value+'.'+form.rmip_2.value+'.'+form.rmip_3.value+'.'+form.rmip_4.value;
            var ipaddr_array=form.r_start_ip.value.split('.');
            if(checkIP(ipaddr_array[0],ipaddr_array[1],ipaddr_array[2],ipaddr_array[3],254)==false)
        	{
        		alert("$invalid_ip");
        		return false;
        	}
        	if(form.rsip_1.value=="127")
        	{
        		alert("$invalid_ip");
        		return false;
        	}
        	if(parseInt(ipaddr_array[0])>=224)
        	{
        		alert("$invalid_ip");
        		return false;
        	}            

            if(checksubnet(form.r_subnet.value, 1)==false)
        	{
                    		alert("$invalid_mask");
                    		return false;
        	} 
        }
}

function check_vpn(value)
{
    if(array_num >= 5) {
        alert("$vpn_max_entry");
        return false;
    }
    
    if(value == 0) 
        location.href="VPN_add_auto_policy.htm";
    else if(value == 1) 
        location.href="VPN_add_manual_policy.htm";
}

function check_auto_policy(form, type)
{      
        if(form.policy_name.value == "") {
            alert("$vpn_invalid_policy_name");
            return false;
        }        

        if (form.pfs_enable.checked == true)
            form.pfs_endis.value = 1;
        else if (form.pfs_enable.checked == false)
            form.pfs_endis.value = 0;

        // check endpoint IP Address
        if (form.endpoint_type.value == 0){
                if(checkipaddr(form.endpoint_data.value) == false) {
                    alert("$vpn_invalid_endpoint_ip");
                                return false;
                 }
        }                    

        if (array_num > 0){
            for(i=1; i<=array_num ; i++){             
                var policy = eval ( 'vpn_policyArray' + i );
                var policy_info=policy.split('*');
                var name=policy_info[2];
                var endpoint=policy_info[4];   

                if(type == 0) {                    
                    if(form.policy_name.value == name) {
                        alert("$vpn_rule_duplicated");
                        return false;
                    }
                    if(form.endpoint_data.value == endpoint) {
                        alert("$vpn_endpoint_duplicated");
                        return false;
                    }
                }
                else  if(type == 1) {
                    if(select_edit != i) {
                         if((form.policy_name.value == name)) {
                            alert("$vpn_rule_duplicated");
                            return false;
                        }
                        if(form.endpoint_data.value == endpoint) {
                            alert("$vpn_endpoint_duplicated");
                            return false;
                        }
                    }
                }
            }
        }

        if (form.loacl_ip_type.value == 2) {     /* single IP Address */
            form.l_start_ip.value=form.lsip_1.value+'.'+form.lsip_2.value+'.'+form.lsip_3.value+'.'+form.lsip_4.value;
             if(checkipaddr(form.l_start_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
        }
        else  if (form.loacl_ip_type.value == 3) {   /* range IP Address */
            form.l_start_ip.value=form.lsip_1.value+'.'+form.lsip_2.value+'.'+form.lsip_3.value+'.'+form.lsip_4.value;
            form.l_end_ip.value=form.leip_1.value+'.'+form.leip_2.value+'.'+form.leip_3.value+'.'+form.leip_4.value;
            if(checkipaddr(form.l_start_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
             if(checkipaddr(form.l_end_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
              if(isSameSubNet(form.l_start_ip.value, "255.255.255.0", form.l_end_ip.value, "255.255.255.0") == false) {
                            alert("$vpn_invalid_rangeip1");
                	        return false;
             }
             if(parseInt(form.lsip_4.value) > parseInt(form.leip_4.value)) {
                            alert("$vpn_invalid_rangeip2");
                	        return false;
             }            
        }
        if (form.loacl_ip_type.value == 4) {        /* subnet IP Address */
            //form.l_start_ip.value=form.lsip_1.value+'.'+form.lsip_2.value+'.'+form.lsip_3.value+'.'+form.lsip_4.value;
		form.l_start_ip.value=form.lsip_1.value+'.'+form.lsip_2.value+'.'+form.lsip_3.value+'.'+0;
            form.l_subnet.value=form.lmip_1.value+'.'+form.lmip_2.value+'.'+form.lmip_3.value+'.'+form.lmip_4.value;
            var ipaddr_array=form.l_start_ip.value.split('.');
            if(checkIP(ipaddr_array[0],ipaddr_array[1],ipaddr_array[2],ipaddr_array[3],254)==false)
        	{
        		alert("$invalid_ip");
        		return false;
        	}
        	if(form.lsip_1.value=="127")
        	{
        		alert("$invalid_ip");
        		return false;
        	}
        	if(parseInt(ipaddr_array[0])>=224)
        	{
        		alert("$invalid_ip");
        		return false;
        	}            

            if(checksubnet(form.l_subnet.value, 1)==false)
        	{
                    		alert("$invalid_mask");
                    		return false;
        	}
        }

         if (form.remote_ip_type.value == 2) { 
            form.r_start_ip.value=form.rsip_1.value+'.'+form.rsip_2.value+'.'+form.rsip_3.value+'.'+form.rsip_4.value;
             if(checkipaddr(form.r_start_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
        }
        else  if (form.remote_ip_type.value == 3) { 
            form.r_start_ip.value=form.rsip_1.value+'.'+form.rsip_2.value+'.'+form.rsip_3.value+'.'+form.rsip_4.value;
            form.r_end_ip.value=form.reip_1.value+'.'+form.reip_2.value+'.'+form.reip_3.value+'.'+form.reip_4.value;
            if(checkipaddr(form.r_start_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
             if(checkipaddr(form.r_end_ip.value) == false) {
                	        alert("$invalid_myip");
                	        return false;
             }
              if(isSameSubNet(form.r_start_ip.value, "255.255.255.0", form.r_end_ip.value, "255.255.255.0") == false) {
                            alert("$vpn_invalid_rangeip1");
                	        return false;
             }
             if(parseInt(form.rsip_4.value) > parseInt(form.reip_4.value)) {
                            alert("$vpn_invalid_rangeip2");
                	        return false;
             }            
        }
        else if (form.remote_ip_type.value == 4) {    
            //form.r_start_ip.value=form.rsip_1.value+'.'+form.rsip_2.value+'.'+form.rsip_3.value+'.'+form.rsip_4.value;
		form.r_start_ip.value=form.rsip_1.value+'.'+form.rsip_2.value+'.'+form.rsip_3.value+'.'+0;
            form.r_subnet.value=form.rmip_1.value+'.'+form.rmip_2.value+'.'+form.rmip_3.value+'.'+form.rmip_4.value;
            var ipaddr_array=form.r_start_ip.value.split('.');
            if(checkIP(ipaddr_array[0],ipaddr_array[1],ipaddr_array[2],ipaddr_array[3],254)==false)
        	{
        		alert("$invalid_ip");
        		return false;
        	}
        	if(form.rsip_1.value=="127")
        	{
        		alert("$invalid_ip");
        		return false;
        	}
        	if(parseInt(ipaddr_array[0])>=224)
        	{
        		alert("$invalid_ip");
        		return false;
        	}            

             if(checksubnet(form.r_subnet.value, 1)==false)
        	{
                    		alert("$invalid_mask");
                    		return false;
        	}
        }

        if(form.l_id_type.value == 0) {
             if(checkipaddr(form.l_id_data.value) == false) {
                	        alert("$vpn_invalid_local_id_ip");
                	        return false;
             }           
        }

         if(form.r_id_type.value == 0) {
             if(checkipaddr(form.r_id_data.value) == false) {
                	        alert("$vpn_invalid_remote_id_ip");
                	        return false;
             }           
        }
        
        if(form.ike_mode.value == 0) {
            form.ike_direction.value = form.ike_dir.value;
            form.ike_exchange.value = form.ike_exchange_mode.value;
        }
}

function check_logs_clear(form)
{
	form.action="/func.cgi?/VPN_status.htm timestamp="+ts;
	form.submit_flag.value="vpn_logs_clear";
	return true;
}

function drop_apply(index)
{
    var form=document.forms[0];

    form.vpn_action.value = "drop";    
    form.vpn_policy_num.value = index;
    //form.action="/apply.cgi?/VPN_sa_status.htm timestamp="+ts;
	//form.submit_flag.value="VPN_sa_status";
    form.submit();
}

function connect_apply(index)
{
    var form=document.forms[0];

    form.vpn_action.value = "connect";
    form.vpn_policy_num.value = index;
    //form.action="/apply.cgi?/VPN_sa_status.htm timestamp="+ts;
	//form.submit_flag.value="VPN_sa_status";
    form.submit();
}


