function ipv6_write_ip(ipv6_ip_addr,lan_number)
{
	if(ipv6_ip_addr != "")
		ipv6_ip_addr = remove_space(ipv6_ip_addr);

	if(ipv6_ip_addr == "")
	{
		document.write("<TR><TD nowrap>$spacebar"+"$ipv6_not_available</TD></TR>");
	}
	else if (ipv6_ip_addr == "N/A")
	{
		document.write("<TR><TD nowrap>$spacebar"+"N/A</TD></TR>")
	}
	else
	{
		var each_ip = ipv6_ip_addr.split(' ');
		var i, ip_count = 0;

		for(i=0; i<each_ip.length; i++)
		{
			if(lan_number != ""){
				var each_if_num = each_ip[i].split('@');
				if(each_if_num[0] == lan_number){
					ip_count++;
                    var lan_prefix_split = each_if_num[1].split('#');
                    document.write("<TR><TD nowrap><img src=/spacer.gif width=20 height=12 border=0><u>"+lan_prefix_split[0]+"</u>"+lan_prefix_split[1]+"</TD></TR>");
				}
			}
			else
			{
				var lan_prefix_split = each_ip[i].split('#');
				ip_count++;
				//document.write("<TR><TD nowrap>$spacebar"+each_ip[i]+"</TD></TR>");
				document.write("<TR><TD nowrap><img src=/spacer.gif width=20 height=12 border=0><u>"+lan_prefix_split[0]+"</u>"+lan_prefix_split[1]+"</TD></TR>");	
			}
		}
		if(ip_count == 0)
        {
            document.write("<TR><TD nowrap><img src=/spacer.gif width=20 height=12 border=0>"+"Not Available</TD></TR>");
        }
	} 
}

function ipv6_load_common(cf)
{
	/* IP Address Assignment */
        if( ipv6_ip_assign == "1" )
        {
                cf.ipv6_lan_ip_assign[0].checked = true;
        }
        else if( ipv6_ip_assign == "0" )
        {
                cf.ipv6_lan_ip_assign[1].checked = true;
        }

        /* Use This Interface ID  */
        if(ipv6_interface_type == "1")
        {
                cf.enable_interface.checked = true;
        }
        else
        {
                cf.enable_interface.checked = false;
        }
        set_interface();
        var interface_id_array = ipv6_interface_id.split(':');
		var interface_id_array2 = ipv6_interface2_id.split(':');
		var interface_id_array3 = ipv6_interface3_id.split(':');
		var interface_id_array4 = ipv6_interface4_id.split(':');
        var i;
        //for( i=0; i<interface_id_array.length; i++ )
        for( i=0; i<cf.IP_interface.length; i++ )
        {
                //cf.IP_interface[i].value = interface_id_array[i];
			var id_num = i / 4
			if ( id_num < 1 )
				if(ipv6_interface_id == "")
					cf.IP_interface[i].value = "";
				else
					cf.IP_interface[i].value = interface_id_array[ i%4 ];
			else if ( id_num < 2 )
				if(ipv6_interface2_id == "")
					cf.IP_interface[i].value = "";
				else
					cf.IP_interface[i].value = interface_id_array2[ i%4 ];
			else if ( id_num < 3 )
				if(ipv6_interface3_id == "")
					cf.IP_interface[i].value = "";
				else
					cf.IP_interface[i].value = interface_id_array3[ i%4 ];
			else if ( id_num < 4 )
				if(ipv6_interface4_id == "")
					cf.IP_interface[i].value = "";
				else
					cf.IP_interface[i].value = interface_id_array4[ i%4 ];
        }

	/* IPv6 Filtering */
	if(ipv6_cone_fitering == 0)
	{
		cf.IPv6Filtering[0].checked = true;
	}
	else if(ipv6_cone_fitering == 1)
	{
		cf.IPv6Filtering[1].checked = true;
	}
}

function ipv6_save_common(cf)
{
	var i;
        cf.ipv6_hidden_interface_id.value = "";

	/* Use This Interface ID */
        if( cf.enable_interface.checked == true )
        {
                cf.ipv6_hidden_enable_interface.value = "1";
				var lan_start_num=((lan_num - 1) * 4)
		        for( i=lan_start_num; i<(lan_start_num+4); i++ )
        		{
        		        if( check_ipv6_IP_address(cf.IP_interface[i].value) == false )
               			{
               		         alert("$invalid_ip" + " Interface ID");
               		         return false;
               		 	}
               		 	if( cf.IP_interface[i].value == "" )
               		 	{
               		         cf.IP_interface[i].value = "0";
               		 	}
						var arrary = i/4;
               		 	//if( i < (cf.IP_interface.length-1) )
						if( (i+1)%4 != 0 )
              		 	{
                     		//cf.ipv6_hidden_interface_id.value = cf.ipv6_hidden_interface_id.value + cf.IP_interface[i].value + ":";
                     		if ( arrary < 1)
								cf.ipv6_hidden_interface_id.value = cf.ipv6_hidden_interface_id.value + cf.IP_interface[i].value + ":";
							else if ( arrary < 2)
								cf.ipv6_hidden_interface_id2.value = cf.ipv6_hidden_interface_id2.value + cf.IP_interface[i].value + ":";
							else if ( arrary < 3)
								cf.ipv6_hidden_interface_id3.value = cf.ipv6_hidden_interface_id3.value + cf.IP_interface[i].value + ":";
							else if ( arrary < 4)
								cf.ipv6_hidden_interface_id4.value = cf.ipv6_hidden_interface_id4.value + cf.IP_interface[i].value + ":";
                		}
                		//else if( i == (cf.IP_interface.length-1) )
						else if( (i+1)%4 == 0 )
                		{
                        	//cf.ipv6_hidden_interface_id.value = cf.ipv6_hidden_interface_id.value + cf.IP_interface[i].value;
                        	if ( arrary < 1)
								cf.ipv6_hidden_interface_id.value = cf.ipv6_hidden_interface_id.value + cf.IP_interface[i].value;
							else if ( arrary < 2)
								cf.ipv6_hidden_interface_id2.value = cf.ipv6_hidden_interface_id2.value + cf.IP_interface[i].value;
							else if ( arrary < 3)
								cf.ipv6_hidden_interface_id3.value = cf.ipv6_hidden_interface_id3.value + cf.IP_interface[i].value;
							else if ( arrary < 4)
								cf.ipv6_hidden_interface_id4.value = cf.ipv6_hidden_interface_id4.value + cf.IP_interface[i].value;
                		}
        		}
		}
		else
		{
				cf.ipv6_hidden_enable_interface.value = "0";
		}


	/* save IPv6 Filtering */
	if(cf.IPv6Filtering[0].checked == true)
	{
		cf.ipv6_hidden_filtering.value = "0"; 
	}
	else if(cf.IPv6Filtering[1].checked == true)
	{
		cf.ipv6_hidden_filtering.value = "1";
	}
	return true;
}

function set_interface()
{
        var cf = document.forms[0];
        var i;
	for( i=0; i<cf.IP_interface.length; i++)
	{
		if( cf.enable_interface.checked == true )
        	{
                	cf.IP_interface[i].disabled = false;
        	}
       	 	else if( cf.enable_interface.checked == false )
        	{	
                	cf.IP_interface[i].disabled = true;
        	}
	}
}
//bug 26966 dns server ipv6 address should be able to leave these fields unspecified
function check_ipv6_DNS_address(ipv6_dns_value)
{
	var i;

	if(ipv6_dns_value != "")
	{
		for(i=0; i<ipv6_dns_value.length;)
		{
			if((ipv6_dns_value.charAt(i)>="0" && ipv6_dns_value.charAt(i)<="9") || (ipv6_dns_value.charAt(i)>="a" && ipv6_dns_value.charAt(i)<="f") || (ipv6_dns_value.charAt(i)>="A" && ipv6_dns_value.charAt(i)<="F"))
			{
				i++;
			}
			else
			{
				return false;
			}
		}
	}

	return true;	
}

function check_ipv6_IP_address(ipv6_ip_value)
{
	var i;

	if(ipv6_ip_value != "")
	{
		for(i=0; i<ipv6_ip_value.length;)
		{
			if((ipv6_ip_value.charAt(i)>="0" && ipv6_ip_value.charAt(i)<="9") || (ipv6_ip_value.charAt(i)>="a" && ipv6_ip_value.charAt(i)<="f") || (ipv6_ip_value.charAt(i)>="A" && ipv6_ip_value.charAt(i)<="F"))
			{
				i++;
			}
			else
			{
				return false;
			}
		}
	}
	else//bug 23597:the address can't blank
		//ipv6_ip_value="0"
		return false;

	return true;	
}

function get_lan_number(group)
{
	var group_arrary = group.split(':');
	var i;
	var lan_num = 1;
	for(i=0;i<group_arrary.length;i++)
	{
		var group_wan = group_arrary[i].split('|');
		if (group_wan[0] == "wan1")
		{
			if (group_wan[1] == "eth0")
			{
				lan_num = 1;
			}else{
				lan_num = group_wan[1].split("vlan");
				lan_num = lan_num[1];
			}
		}else if (group_wan[1] == "wan1")
		{
			if (group_wan[0] == "eth0")
			{
				lan_num = 1;
			}else{
				lan_num = group_wan[0].split("vlan");
				lan_num = lan_num[1];
			}
		}
	}
	return lan_num; 
}
