function checkPort(name, port)
{
	var msg = "";
	var portNum = parseInt(port,10);

	if (port.length == 0)
	{
		msg = name + " " + "$trigger_null";
		alert(msg);
		return false;
	}
	for(i=0;i<port.length;i++)
	{
		c=port.charAt(i);
		if("0123456789".indexOf(c,0)<0)
		{
			msg = "$trigger_invalid" + name;
			alert(msg);			
			return false;
		}	
	}
	if (isNaN(portNum) || portNum < 1 || portNum > 65535)
	{
		msg = "$trigger_invalid" + name + "$trigger_1_65535";
		alert(msg);
		return false;
	}
	return true;
}
function check_tr069(form,kick,hidden)
{
	if(form.enable_tr069.checked == true)
		form.hidden_enable_tr069.value = "1";
	else
		form.hidden_enable_tr069.value = "0";
	
	if( kick == 1 )
		form.set_kick.value = "kick";
	else
		form.set_kick.value = "no";
	
	//interval check
	var i;
	var msg = "";
	if (hardware_version == "DGN1000v3-3DDAUS") {		// by dodo's requirement
		var intervalNum = parseInt(form.interval.value,10);	
		intervalNum = intervalNum * 60;
		if (isNaN(intervalNum) || intervalNum < 60 || intervalNum > 86400)
		{
			msg = "$trigger_invalid" + "$tr069_informInterval" + form.interval.value + ", must be in the range 1-1440 minutes.\n";	// by dodo's requirement
			alert(msg);
			return false;
		} 
		form.interval.value = intervalNum;
	} else {
		var portNum = parseInt(form.interval.value,10);
		if (isNaN(portNum) || portNum < 30 || portNum > 21600)
		{
			msg = "$trigger_invalid" + "$tr069_informInterval" + ", must be in the range 1-21600.\n";
			alert(msg);
			return false;
		} 
	}
	
	//acs password check
	for(i=0;i<form.acs_password.value.length;i++)
	{       
		if(isValidChar_space(form.acs_password.value.charCodeAt(i))==false)
		{
			alert("$password_error");
			return false;
		}
	}
	
	//port check
	if(checkPort("$tr069_requestPort", form.con_port.value)==false)
		return false;	
	
	//con password check
	for(i=0;i<form.con_password.value.length;i++)
	{       
		if(isValidChar_space(form.con_password.value.charCodeAt(i))==false)
		{
			alert("$password_error");
			return false;
		}
	}
	
	if( kick == 1 )	{
		form.submit_flag.value="tr069_kick";
		if( hidden == 1 )
			form.action="/apply.cgi?/tr069_hidden.htm timestamp=" + timestampBuff;
		else if( hidden == 2 )
			form.action="/apply.cgi?/TR069.htm timestamp=" + timestampBuff;
		else
			form.action="/apply.cgi?/tr069.htm timestamp=" + timestampBuff;
	}
	
	return true;

}
