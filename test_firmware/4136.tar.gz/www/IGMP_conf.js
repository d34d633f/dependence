function check_IGMP_conf()
{

	return true;
}
