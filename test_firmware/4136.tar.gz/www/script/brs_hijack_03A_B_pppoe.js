function initPage()
{
	//var head_tag = document.getElementsByTagName("h1");
	//var head_text = document.createTextNode(bh_pppoe_connection);
	//head_tag[0].appendChild(head_text);
	
	var paragraph = document.getElementsByTagName("p");
	var paragraph_text = document.createTextNode(bh_enter_info_below);
	paragraph[0].appendChild(paragraph_text);
	

	if ( netgear_region == "GR" && gr_pppoe_type == "T-Online" ) {	
		var tonlineid = document.getElementById("tonlineid");
		var tonlineid_text = document.createTextNode(bh_tonline_id + " :");
		tonlineid.appendChild(tonlineid_text);

		var tonlinenum = document.getElementById("tonlinenum");
		var tonlinenum_text = document.createTextNode(bh_tonline_num + " :");
		tonlinenum.appendChild(tonlinenum_text);

		var tonlinesuf = document.getElementById("tonlinesuf");
		var tonlinesuf_text = document.createTextNode(bh_tonline_suf + " :");
		tonlinesuf.appendChild(tonlinesuf_text);

		//set event action
		var tonlineid_input = document.getElementById("inputTonlineConnectionId");
		tonlineid_input.onkeypress = ssidKeyCode;

		//set event action
		var tonlinenum_input = document.getElementById("inputTonlineNumber");
		tonlinenum_input.onkeypress = ssidKeyCode;

		//set event action
		var tonlinesuf_input = document.getElementById("inputTonlineSuffix");
		tonlinesuf_input.onkeypress = ssidKeyCode;
	}
	else if ( netgear_region == "GR" && gr_pppoe_type == "1&1" ) {
		var login_name = document.getElementById("loginName");
		var login_text = document.createTextNode(bh_pppoe_login_name + " :");
		login_name.appendChild(login_text);
		
		var login_name_msg1 = document.getElementById("loginName_msg1");
		var login_text_msg1 = document.createTextNode("1und1/");
		login_name_msg1.appendChild(login_text_msg1);
		
		var login_name_msg2 = document.getElementById("loginName_msg2");
		var login_text_msg2 = document.createTextNode("@online.de");
		login_name_msg2.appendChild(login_text_msg2);

		//set event action
		var name_input = document.getElementById("inputName");
		name_input.onkeypress = ssidKeyCode;
	}
	else {
		var login_name = document.getElementById("loginName");
		var login_text = document.createTextNode(bh_pppoe_login_name + " :");
		login_name.appendChild(login_text);

		//set event action
		var name_input = document.getElementById("inputName");
		name_input.onkeypress = ssidKeyCode;
	}

	var passwd = document.getElementById("passwd");
	var passwd_text = document.createTextNode(bh_ddns_passwd + " :");
	passwd.appendChild(passwd_text);

	var passwd_input = document.getElementById("inputPasswd");
	passwd_input.onkeypress = ssidKeyCode;
	
	var btns_container_div = document.getElementById("btnsContainer_div");
	btns_container_div.onclick = function()
	{
		return checkPPPoE();
	}
	
	var btn = document.getElementById("btn_text_div");
	var btn_text = document.createTextNode(bh_next_mark);
	btn.appendChild(btn_text);

	//show firmware version
        showFirmVersion("none");
}

function checkPPPoE()
{
	var forms = document.getElementsByTagName("form");
        var cf = forms[0];
	
	if ( netgear_region == "GR" && gr_pppoe_type == "T-Online" ) {
		var pppoe_connectionid = document.getElementById("inputTonlineConnectionId");
		var pppoe_tnumber = document.getElementById("inputTonlineNumber");
		var pppoe_usersuffix = document.getElementById("inputTonlineSuffix");
	}
	else {
		var pppoe_name = document.getElementById("inputName");
		if(pppoe_name.value == "")
		{
			alert(bh_login_name_null);
			return false;
		}
	}

	var pppoe_passwd = document.getElementById("inputPasswd");
	var i;
	for(i=0;i<pppoe_passwd.value.length;i++)
	{
		if(isValidChar(pppoe_passwd.value.charCodeAt(i))==false)
		{
			alert(bh_password_error);
			return false;
		}
	}

	cf.submit();

	return true;
}

addLoadEvent(initPage);
