﻿if (HelpItem=='firmware'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        "Cette page affiche la version du firmware de votre appareil ainsi que des informations utilisées par les techniciens de D-Link lorsque vous demandez une assistance technique. Ces informations ne sont qu'une référence, car il est rarement nécessaire de charger un nouveau firmware sur votre routeur.<br><br>" +
                                        '<a href="helpmaintenance.html#Firmware">En savoir plus...</a>';

} else if (HelpItem=='system'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        "Cette page permet d'enregistrer la configuration de votre routeur dans un fichier sur votre ordinateur, pour vous prémunir au cas où vous deviez réinitialiser les paramètres d'usine par défaut de votre routeur. Vous pourrez restaurer les paramètres du routeur à partir d'un fichier de configuration préalablement enregistré. Il existe également une fonction permettant de réinitialiser votre routeur sur les paramètres d'usine par défaut. En réinitialisant votre routeur sur les paramètres d'usine par défaut, vous effacerez votre configuration actuelle.<br><br>" +
                                        '<a href="helpmaintenance.html#System">En savoir plus...</a>';

} else if (HelpItem=='diag'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        "Cette page affiche le résultat du diagnostic de votre routeur et les résultats des tests de connexion. Le statut de la connectivité Internet n'indiquera RÉUSSITE que si vous avez correctement configuré votre connexion Internet et si votre routeur est actuellement en ligne.<br><br>" +
                                        '<a href="helpmaintenance.html#Diag">En savoir plus...</a>';

} else if (HelpItem=='acadmin'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        "Cette page permet de modifier le mot de passe de votre routeur requis pour accéder à cette interface Web de gestion. Pour des raisons de sécurité, nous vous recommandons de remplacer le mot de passe par défaut de sortie d'usine. Assurez-vous de choisir un mot de passe dont vous pourrez vous souvenir, ou écrivez-le et conservez le dans un endroit sûr et séparé afin d'y avoir accès ultérieurement. Si vous oubliez le mot de passe de votre périphérique, la seule solution est de réinitialiser votre routeur sur les paramètres de sortie d'usine par défaut, ce qui supprimera tous les paramètres de configuration de votre périphérique.<br><br>" +
                                        '<a href="helpmaintenance.html#Password">En savoir plus...</a>';

} else if (HelpItem=='acip'){
  document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br> ' +
                                        'You can restrict users who can access the local management using IP address.<br><br>' +
                                        '<a href="helpmaintenance.html#Access">More...</a>';

} else if (HelpItem=='syslog'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        "Cette page permet d'activer, de configurer et d'afficher le journal système de votre routeur. Le journal système garde une trace de l'activité de votre routeur. En fonction de la quantité de détails que vous incluez dans le journal, votre routeur peut conserver un nombre limité d'entrées de journal, en raison des limites de la mémoire du routeur. Si vous disposez d'un serveur externe SYSLOG, vous pouvez choisir de configurer la journalisation externe ; toutes les entrées de journal seront alors envoyées vers votre serveur distant.<br><br>" +
                                        "Vous pouvez également configurer le routeur pour qu'il envoie le journal système par e-mail à une adresse e-mail spécifique, mais vous devrez disposer des informations sur le serveur d'e-mail fournies par votre FAI.<br><br>" +
                                        '<a href="helpmaintenance.html#SystemLog">En savoir plus...</a>';

}else if (HelpItem=='captcha'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Cette page vous permet d\'activer ou de désactiver la fonction CAPTCHA dans votre page de connexion. Si vous voulez améliorer la sécurité de votre routeur, vous devez activer la fonction. Otherwisze vous pouvez le désactiver si vous ne pouvez pas authentifier reconnaissent la photo.<br><br>';
}
