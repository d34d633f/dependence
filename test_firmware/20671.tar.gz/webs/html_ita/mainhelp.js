﻿if (HelpItem=='firmware'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        'Questa pagina contiene la versione del firmware utilizzato dal dispositivo e le informazioni che devono essere fornite ai tecnici D-Link nel caso in cui fosse necessario richiedere un supporto.  Questi dati sono disponibili a titolo informativo in quanto generalmente non è necessario aggiornare il firmware del router.<br><br>' +
                                        '<a href="helpmaintenance.html#Firmware">Ulteriori informazioni...</a>';

} else if (HelpItem=='system'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        'Questa pagina consente di salvare la configurazione del router in un file memorizzato sul computer. Il file può essere utilizzato nel caso in cui fosse necessario ripristinare le impostazioni di default del dispositivo.  In questo modo è possibile ripristinare le impostazioni del router, caricandole dal file di configurazione precedentemente salvato.  È inoltre disponibile una funzione che consente di ripristinare le impostazioni di default del router.  Ripristinando le impostazioni di default del router, tutte le impostazioni della configurazione corrente vengono cancellate.<br><br>' +
                                        '<a href="helpmaintenance.html#System">Ulteriori informazioni...</a>';

} else if (HelpItem=='diag'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        "Questa pagina mostra l'esito dell'auto diagnostica del router e i risultati dei test di connessione.  Lo stato della connessione Internet viene indicato con PASS esclusivamente se la configurazione è corretta e se il router è online.<br><br>" +
                                        '<a href="helpmaintenance.html#Diag">Ulteriori informazioni...</a>';

} else if (HelpItem=='acadmin'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        'Questa  pagina consente di modificare la password del router, necessaria per accedere alla presente interfaccia di gestione basata sul web.  Per ragioni di sicurezza, si raccomanda di sostituire le password di default con una nuova password.  Si consiglia di impostare una password semplice da ricordare o di prenderne nota, conservandola in un luogo sicuro per una futura consultazione.  Se la password viene dimenticata, è necessario ripristinare le impostazioni di default del router. Questa operazione comporta la perdita di tutti i parametri di configurazione.<br><br>' +
                                        '<a href="helpmaintenance.html#Password">Ulteriori informazioni...</a>';

} else if (HelpItem=='acip'){
  document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br> ' +
                                        'You can restrict users who can access the local management using IP address.<br><br>' +
                                        '<a href="helpmaintenance.html#Access">More...</a>';

} else if (HelpItem=='syslog'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        "La presente pagina consente di abilitare, configurare e visualizzare i log di sistema del router.  I log di sistema registrano un record per l'attività del router.  Per ragioni di limiti di memoria, il router può registrare un numero limitato di voci, in funzione del numero di dettagli inclusi nel log.  Se si dispone di un server SYSLOG esterno è necessario configurare un logging esterno. In questo modo tutte le voci dei log vengono inviate al server remoto.<br><br>" +
                                        "È inoltre possibile configurare il router in modo che invii i log di sistema via email a un indirizzo specificato. A tal fine è necessario disporre di informazioni sul server di posta, fornite dall'ISP.<br><br>" +
                                        '<a href="helpmaintenance.html#SystemLog">Ulteriori informazioni...</a>';

} else if (HelpItem=='captcha'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        'Uesta pagina consente di attivare o disattivare la funzione di CAPTCHA nella vostra pagina di log in. Se si desidera migliorare il router di sicurezza, è necessario attivare la funzione. Otherwisze si può disabilitare se non si poteva recongnize autenticare la foto.<br><br>';
}
