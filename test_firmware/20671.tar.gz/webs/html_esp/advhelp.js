﻿if (HelpItem=='webfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Create a list of websites that you would like the devices on ' +
                                        'your network to be allowed or denied access to.<br><br>' +
                                        '<a href="helpadvanced.html#Filter">Más...</a>';
} else if (HelpItem=='ddns'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'DDNS - This stands for Dynamic DNS.<br> ' +
                                        'By creating a static hostname, users will be able to point to this in order to access ' +
                                        'a dynamic IP address from anywhere in the world.<br><br>' +
                                        '<a href="helpadvanced.html#DDNS">Más...</a>';
}else if (HelpItem=='acservice'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'La gestión remota debería estar deshabilitada por defecto. Sin embargo, si quiere entrar en el sistema y gestionar su router desde otro dispositivo de internet , puede habilitar el router para que acepte tales órdenes desde el puerto de internet  Esta opción puede ser útil si su administrador de red no se encuentra in situ o la Asistencia técnica solicita ese acceso.<br><br>' +
                                        '<a href="helpadvanced.html#RM">Más...</a>';

} else if (HelpItem=='wirelessadv'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Por defecto no es necesario cambiar estas opciones para que el router opere en modo inalámbrico. La opción Potencia de transmisión es la potencia de la señal de radio. Debe disminuir la potencia si añade una antena de alta ganancia, puesto que se excederían los limites de funcionamiento.<br><br>' +
                                        '<a href="helpadvanced.html#WirelessAdv">Más...</a>';
} else if (HelpItem=='portforwarding'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Consulte en el menú desplegable Nombre de la aplicación la lista de las aplicaciones predefinidas. Si no figura en la lista, puede definir fácilmente una nueva regla.<br><br>' +
                                        '<a href="helpadvanced.html#PortForwarding">Más...</a>';
} else if (HelpItem=='porttriggering'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Use esta característica si ha intentado ejecutar una de las aplicaciones de red que figuran en la lista y no ha establecido la comunicación esperada.<br><br>' +
										'Consulte en el menú desplegable Nombre de la aplicación la lista de las aplicaciones predefinidas. Si no figura en la lista, puede definir fácilmente una nueva regla.<br><br>'+
                                        '<a href="helpadvanced.html#ApplicationRules">Más...</a>';
} else if (HelpItem=='dmz'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Enable the DMZ option only as a last resort. If you are having trouble ' +
                                        'using an application from a computer behind the router, first try opening ' +
                                        'ports associated with the application in the <b>Port Forwarding</b> section.<br><br>' +
                                        '<a href="helpadvanced.html#DMZ">Más...</a>';
} else if (HelpItem=='infilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Asígnele a cada regla un Nombre que sea significativo para usted.<br><br>' +
                                        'Cada regla puede Permitir el tráfico saliente de la WAN.<br><br>' +
                                        'Las direcciones IP de origen son direcciones del lado WAN, y las direcciones IP de destino son direcciones del lado LAN.<br><br>' +
                                        'Haga clic en el botón Guardar para grabar una regla completa en la Lista de reglas.<br><br>' +
                                        'Haga clic en la casilla de verificación Eliminar de la Lista de Reglas, y luego haga clic en el botón Eliminar para borrar una regla definitivamente.<br><br>'+
                                        '<a href="helpadvanced.html#Inbound">Más...</a>';
} else if (HelpItem=='outfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Asígnele a cada regla un Nombre que sea significativo para usted.<br><br>' +
                                        'Cada regla puede Denegar el tráfico saliente de la LAN.<br><br>' +
                                        'Las direcciones IP de origen son direcciones del lado LAN, y las direcciones IP de destino son direcciones del lado WAN.<br><br>' +
                                        'Haga clic en el botón Guardar para grabar una regla completa en la Lista de reglas.<br><br>' +
                                        'Haga clic en la casilla de verificación Eliminar de la Lista de Reglas, y luego haga clic en el botón Eliminar para borrar una regla definitivamente.<br><br>'+
                                        '<a href="helpadvanced.html#Outbound">Más...</a>';
} else if (HelpItem=='macfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Create a list of MAC addresses that you would either like to allow or deny access to your ' +
                                        'network depending on the current <b>Global Policy</b>.<br><br>' +
                                        '<a href="helpadvanced.html#Filter">Más...</a>';

} else if (HelpItem=='wlmacfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
													'Cree una lista de direcciones MAC para las que quiere permitir o denegar el acceso de sus ' +
													'usuarios a su router inalámbrico. Haga clic en Eliminar si quiere borrar una dirección MAC ' +
													'de la lista de filtro MAC.<br><br>' +
//                                        'Create a list of MAC addresses that you would either like to allow or deny users access to '+
//                                        'the wireless router. Click on Remove if you want to take out a MAC address from the MAC filter list.<br><br>' +
                                        '<a href="helpadvanced.html#WirelessFilter">Más...</a>';

} else if (HelpItem=='wlbridge'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Selecting Acess Point enables access point functionality. Wireless bridge functionality ' +
                                        'will still be available and wireless stations will be able to associate to the AP.<br><br> ' +
                                        'Select Disabled in Bridge Restrict which disables wireless bridge restriction. <br><br>' +
                                        'Any wireless bridge will be granted access. Selecting Enabled or Enabled(Scan) enables ' +
                                        'wireless bridge restriction. Only those bridges selected in Remote Bridges will be granted access.<br><br>' +
                                        '<a href="helpadvanced.html#WirelessAdv">Más...</a>';

} else if (HelpItem=='wlanQos'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Puedes dar a usos de las multimedias un más de alta calidad del servicio y de la prioridad en una red sin hilos así que los usos tales como videos estarán de más de alta calidad. <br><br>' +
                                        '<a href="helpadvanced.html#QoS">Más...</a>';

} else if (HelpItem=='lanQos'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Puedes dar a usos de las multimedias un más de alta calidad del servicio y de la prioridad en el LAN así que los usos tales como videos estarán de más de alta calidad.<br><br>' +
                                        '<a href="helpadvanced.html#QoS">Más...</a>';

}  else if (HelpItem=='tod'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Give each rule a name that is meaningful to you. For example, a schedule for Monday ' +
                                        'through Friday from 3:00pm to 9:00pm, might be called "After School" and enter the MAC address ' +
                                        'that you want to blocking.<br><br>' +
                                        '<a href="helpadvanced.html#Parental">Más...</a>';

} else if (HelpItem=='dns'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'If "Enable Automatic Assigned DNS" checkbox is selected, this router will accept the first received DNS assignment from one of the Internat conection protocols. PPPoA, PPPoE or MER/DHCP enabled PVC(s) during the connection establishment. If the checkbox is not selected, enter the primary and optional secondary DNS server IP addresses manually. ONly do so if you having problems with you DNS servers.<br><br>' +							
                                        'DDNS stands for Dynamic DNS. ' +
                                        'By creating a static hostname, users will be able to point to this in order to access ' +
                                        'a dynamic IP address from anywhere in the world.<br><br>' +
                                        '<a href="helpadvanced.html#DNS">Más...</a>';

} else if (HelpItem=='portmap'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'To use this feature, mapping groups should be created. <br>' +
                                        'If you need to remove an entry, then click on the Remove button.<br><br>' +
                                        '<a href="helpadvanced.html#Network">Más...</a>';

} else if (HelpItem=='qosadd'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
       ' QoS (Quality of service) le permite al router priorizar el flujo de paquetes de datos por su router y por su red. Esto es muy importante para los programas susceptibles al tiempo, como VoIP, que puede dar lugar a la caída de una llamada. Se puede evitar gran cantidad de datos no críticos a fin de que no afecten a estos programas sensibles al tiempo. D-Link ha configurado algunas de las reglas más usadas para QoS. VoIP y H.323. se usan a menudo para las llamadas por internet. <br><br>'                    
									  +  '<a href="helpadvanced.html#QoS">Más...</a>';

} else if (HelpItem=='adslsetting'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'No cambie estos parámetros excepto que se lo haya indicado su ISP. Por defecto, el router de  D-Link establecerá la mejor conexión. No ha de cambiar ninguno de los parámetros excepto que se lo señale la Asistencia Técnica de D-Link.<br><br>' +
                                        '<a href="helpadvanced.html#ADSLAdv">Más...</a>';

} else if (HelpItem=='snmp'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'En esta página podrá configurar la puerta de enlace como agente SNMP.<br><br>' +
                                        '<a href="helpadvanced.html#SNMP">Más...</a>';

} else if (HelpItem=='certificate'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'A local certificate identifies your router over the network.  To apply for a certificate, ' +
                                        'click on <b><font color="rgb(108,169,213)">Create Certificate Request</font></b> and if you have an existing certificate, click on ' +
                                        '<b><font color="rgb(108,169,213)">Import Certificate</font></b> to retrieve it.<br><br> ' +
                                        'Trusted certificate authority (CA) allows you to verify the certificates of your peers.<br><br>' +
                                        '<a href="helpadvanced.html#Network">Más...</a>';

} else if (HelpItem=='staticroute'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Usted puede seleccionar qué entrada a utilizar, byinterface o especificando una entrada.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">Más...</a>';

} else if (HelpItem=='dfltgateway'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        '<b>NOTE</b>: If changing the AutomaticAssigned Default Gateway from unselected to selected, ' +
                                        'You must reboot the router to get the automatic assigned default gateway.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">Más...</a>';

} else if (HelpItem=='dos'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'If "Enable Attack Prevent" checkbox isselected, the router will detect some attacks. ' +
                        'When the router detects attack, it will drop the packets and log them in the "System log".<br><br>' +
                                'If "Prevent IP Spoofing" checkbox is selected,the route will drop the packets from WAN interface ' +
                        'with private source ip address. The private ip addressranges are as: 10.0.0.0/8, 172.16.0.0/12, ' +
                        'and 192.168.0.0/16.<br><br>' +
                                        '<a href="helpadvanced.html#Firewall">Más...</a>';

} else if (HelpItem=='tr069'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Provides a means to monitor status andperformance as well as set configuration parameters ' +
                                        'from WAN side.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">Más...</a>';

} else if (HelpItem=='rip'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Enabling RIP provides a protocol that determines the best path to a target by estimating ' +
                                        'the distance in number of hops or intermediate routers.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">Más...</a>';

}

