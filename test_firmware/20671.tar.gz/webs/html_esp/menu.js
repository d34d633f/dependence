﻿var TabHeader="";
var SideItem="";
var HelpItem="";
var ModemVer='<%ejGet(modelName)%>';
var FirmwareVer='<%ejGet(sysVersion)%>';
var shippingArea='<%ejGetOther(ProdInfo,shippingArea)%>';
var HardwareVer='C2';
var loadesp;

// for wan link status
var InternetCon ='<%ejGetWan(status)%>'; 

var currentuser = '<%ejGet(curUserName)%>';
currentuser='admin';
var updatesettings=0;
var logintro=0;
if (currentuser != 'user') {
	updatesettings=1;
	logintro=1;
}
var CHome = 1;
var CAdvanced = 2;
var CMaintain = 3;
var CStatus = 4;
var CHelp = 5;
var CEnd = 5;
var delaytimer=300;

  var user = 'admin';
  var proto = 'PPPoE';
  var ipExt = '0';
  var dhcpen = '1';
  var std = 'annex_a';
  var wireless = '1';
  var voice = '';
  var buildSnmp = '1';
  var buildDdnsd = '1';
  var buildSntp = '1';
  var buildPureBridge = '0';
  var buildPortmap = '1';
  var buildipp = '0';
  var buildSes = '';  //SUPPORT_SES 
  var siproxd = '0';
  var tod = '1';
  var QosEnabled = 'false';
  var buildRip = '1';  //SUPPORT_SES 
  var buildUsbHost = "<%ejGetOther(sysInfo, buildUsbHost)%>";
  var buildUsbFtp = "<%ejGetOther(sysInfo, buildUsbFtp)%>";
  var buildUsbSmb = "<%ejGetOther(sysInfo, buildUsbSmb)%>";
  var ipsec = '0';
  var certificate = '1';
  var wirelessqos = '1';
  var tr69c = '1';
  var buildPptpClient = '0';
  var buildDOS = '1';
  var buildPT = '1';
  var buildQoS='1';
  var urlFilter = '1';

  var QuickSetup=0;
  var VirtualServers=0;
  var PortTriggering=0;
  var DMZHost=0;
  var ALG=0;
  //var Outgoing=0;
  //var Incoming=0;
  var Filter=0;
  var AttackPrevent=0;
  var MACFiltering=0;
  var ParentalControl=0;
  var QualityofService=0;
  var DefaultGateway=0;
  var StaticRoute=0;
  var RIP=0;
  var Routing=0;
  var DNSServer=0;
  var DynamicDNS=0;
  var Annex="";
  var PortMapping=0;
  var PPTPClient=0;
  var IPSec=0;
  var wlBasic=0;
  var wlSecurity=0;
  var wlMACFilter=0;
  var wlBridge=0;
  var wlAdvanced=0;
  var wlQos=0;
  var wlSES=0;
  var wlStationInfo=0;
  var WirelessAdv=0;
  var MassStorage=0;
  var PrintServer=0;
  var Settings=0;
  var SNMP=0;
  var TR069Client=0;
  var cert = 0;
  var InternetTime=0;
  //var Services=0;
  //var IPAddresses=0;
  //var Passwords=0;
  var AccessControl=0;
  var Security="";
  var UpdateSoftware=0;
  var mi;
if ( user != 'support' && user != 'user') {
  if ( buildPureBridge == 0) {
      VirtualServers=1;
    if(buildPT == '1')
      PortTriggering=1;
      //add compile option
      DMZHost=1;
        if ( siproxd == '1' )
           ALG =1;
      //Outgoing=1;
      //Incoming=1;
	  //MACFiltering=1;
      Filter=1;
        if (buildDOS == '1')
          AttackPrevent=1;      
         if ( tod == '1' )
            ParentalControl=1;
  }
}

if ( buildPureBridge == 0) {
  QuickSetup=1;
  if ( user != 'user') {
      if (buildQoS == '1')
        QualityofService=1;
        DefaultGateway=1;
        //add compile option
        StaticRoute=1;
        Routing=1;
      if ( buildRip == '1')
        RIP=1;
      //add compile option
      DNSServer=1;
      if ( buildDdnsd == '1')
        DynamicDNS=1;
  }
}

if ( std == 'annex_c' )
  Annex="adslcfgc.html";
else
  Annex="adslcfg.html"; 

if ( buildPortmap == '1' ) {
  PortMapping=1;
}

if ( buildPptpClient == '1' ) {
  PPTPClient=1;
}

if ( ipsec == '1' ) {
  IPSec=1;
}

if (certificate == '1')  {
	cert = 1;
}


if ( wireless == '1' ) {
  wlBasic=1;
  wlSecurity=1;
  wlMACFilter=1;
  wlBridge=1;
  wlAdvanced=1;
  WirelessAdv=1;
  if (buildQoS == '1'){
  if ( wirelessqos == '1' ) { 
     wlQos=1;
  }
  }
  //SUPPORT_SES
  if ( buildSes == '1' ) {
     wlSES=1;
  }
  wlStationInfo=1;
}

if ( buildUsbHost == '1' ) {
  if ( buildUsbFtp == '1' || buildUsbSmb == '1' ) {
    MassStorage=1;
  }
  if ( buildipp == '1' ) {
    PrintServer=1;
  }
}

if ( user != 'user') {
  Settings=1;
  if ( buildSnmp == '1' )
  	SNMP=1;
  if ( tr69c == '1' )
  	TR069Client=1;
  if ( (buildPureBridge == '0') && (buildSntp == '1') )
   	InternetTime=1;
  
  //Services=1;
  //IPAddresses=1;
  //Passwords=1;
  AccessControl=1;
}

var HomeMenu=new Array();
var AdvMenu=new Array();
var MaintainMenu = new Array();
var StatMenu=new Array();
var HelpMenu=new Array();

var TabMenu = new Array();

var tabPos = GetTABpos();

HomeMenu[0 ]=new Gitem(CHome, "Configuración de Internet", "wancfg1.html", 1, "euhelp.js");
HomeMenu[1 ]=new Gitem(CHome, "Configuración inalámbrica", "wireless.html", wlBasic, "euhelp.js");
HomeMenu[2 ]=new Gitem(CHome, "Configuración de LAN",    "lan.html", 1, "euhelp.js");
HomeMenu[3 ]=new Gitem(CHome, "Hora y Fecha", 	"time.html", 1, "euhelp.js");
HomeMenu[4 ]=new Gitem(CHome, "Control parental",    "blockwebsite.html", 1, "euhelp.js");
HomeMenu[5 ]=new Gitem(CHome, "Programa inalámbrico",    "wirelesschedule.html", 1, "euhelp.js");
    if (MassStorage == 1)
    {
        if (buildnetusb != '1')
	HomeMenu[6 ]=new Gitem(CHome, "USB Setup", 	"storagecfg.html", 1, "setuphelp.js", -1);
        else
	HomeMenu[6 ]=new Gitem(CHome, "USB Setup", 	"storagecfg.html", 1, "setuphelp.js", -1);
            
	HomeMenu[7 ]=new Gitem(CHome, "Salir del sistema",  "logouth.html",	1, ""); 
    }
    else
    {
	HomeMenu[6 ]=new Gitem(CHome, "Salir del sistema",  "logouth.html",	1, "");  
    }

/*
AdvMenu[0 ]=new Gitem(CAdvanced, "Advanced Wireless", "wirelessadv.html", WirelessAdv, "advhelp.js");
AdvMenu[1 ]=new Gitem(CAdvanced, "Port Forwarding", "scvrtsrv.cmd?action=view", VirtualServers, "advhelp.js");
AdvMenu[2 ]=new Gitem(CAdvanced, "Port Triggering",    "scprttrg.cmd?action=view", PortTriggering, "advhelp.js");
AdvMenu[3 ]=new Gitem(CAdvanced, "DMZ",            "scdmz.html", DMZHost, "advhelp.js");
AdvMenu[4 ]=new Gitem(CAdvanced, "Filtering Options",	"filter.html", Filter, "advhelp.js");
//AdvMenu[5 ]=new Gitem(CAdvanced, "Bridge Filters",        "scmacflt.cmd?action=view", MACFiltering, "advhelp.js");
//AdvMenu[6 ]=new Gitem(CAdvanced, "Web Filter",      "scurlflt.cmd", urlFilter, "advhelp.js");
AdvMenu[5 ]=new Gitem(CAdvanced, "Parental Control",      "todmngr.tod?action=view", ParentalControl, "advhelp.js");
AdvMenu[6 ]=new Gitem(CAdvanced, "Firewall Settings",      "doscfg.html", 1, "advhelp.js");
AdvMenu[7 ]=new Gitem(CAdvanced, "DNS",    "dnscfg.html", DNSServer, "advhelp.js");
AdvMenu[8 ]=new Gitem(CAdvanced, "Dynamic DNS",    "ddnsmngr.cmd", DynamicDNS, "advhelp.js");
//AdvMenu[1 ]=new Gitem(CAdvanced, "Port Mapping",    "portmap.cmd", PortMapping, "advhelp.js");
//AdvMenu[9 ]=new Gitem(CAdvanced, "QoS",    "qoscls.cmd?action=view", QualityofService, "advhelp.js");
//AdvMenu[10]=new Gitem(CAdvanced, "ADSL", Annex, 1, "advhelp.js");
//AdvMenu[11]=new Gitem(CAdvanced, "SNMP", "snmpconfig.html", SNMP, "advhelp.js");
//AdvMenu[12]=new Gitem(CAdvanced, "TR-069 Client", 	"tr69cfg.html", TR069Client, "advhelp.js");
//AdvMenu[13]=new Gitem(CAdvanced, "Certificate", "certificate.html", cert, "advhelp.js");
AdvMenu[9 ]=new Gitem(CAdvanced, "Network Tools", 		 "network.html", 1, "advhelp.js");
AdvMenu[10]=new Gitem(CAdvanced, "Routing", 		 "routing.html", Routing, "advhelp.js");
AdvMenu[11]=new Gitem(CAdvanced, "Logout",  "logouta.html",	1, ""); 
*/
mi = 0;
AdvMenu[mi++]=new Gitem(CAdvanced, "Direccionamiento de puerto", "portforwarding.html", 1, "advhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Reglas de aplicación",    "apprules.html", 1, "advhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Configuración de QoS",            "qos.html", 1, "advhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Filtro de saliente",	"scoutflt.html", 1, "advhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Filtro de entrada",      "scinflt.html", 1, "advhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Filtro inalámbrica", 		 "wlmacflt.html", 1, "advhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Configuración de DNS",    "dns.html", DNSServer, "advhelp.js");
//AdvMenu[mi++]=new Gitem(CAdvanced, "Routing",    "routing.html", 1, "euhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Firewall y DMZ",    "firewall.html", 1, "euhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Parámetros ADSL avanzados", 		 Annex, 1, "advhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Parámetros inalámbricos avanzados", 		 "wirelessadv.html", 1, "euhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Parámetros LAN avanzados", 		 "lanadv.html", 1, "euhelp.js");
//AdvMenu[11]=new Gitem(CAdvanced, "Port Mapping", 		 "portmap.cmd", 1, "euhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Disposición del SNMP", 		 "snmpconfig.html", 1, "advhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Gestión remota", 		 "access.html", AccessControl, "advhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Encaminamiento Info",  "routecfg.html",	1, "advhelp.js");
AdvMenu[mi++]=new Gitem(CAdvanced, "Wi-Fi Protegidas Configuración",  "wlprotected.html",	1, "");  
AdvMenu[mi++]=new Gitem(CAdvanced, "Salir del sistema",  "logouta.html",	1, ""); 
//AdvMenu[mi++]=new Gitem(CAdvanced, "Save and Reboot", 		 "rebootinfo.cgi", 1, "advhelp.js");

MaintainMenu[0 ]=new Gitem(CMaintain, "Contraseña", 	"password.html", Settings, "mainhelp.js");
MaintainMenu[1 ]=new Gitem(CMaintain, "CAPTCHA configuración", 	"captcha.html", 1, "mainhelp.js");
MaintainMenu[2 ]=new Gitem(CMaintain, "Guardar/restaurar parámetros", 	"updatesettings.html", updatesettings, "mainhelp.js");
MaintainMenu[3 ]=new Gitem(CMaintain, "Actualización del firmware", "upload.html", 1, "mainhelp.js");
MaintainMenu[4 ]=new Gitem(CMaintain, "Access Controls", 	"access.html", 0, "mainhelp.js");
MaintainMenu[5 ]=new Gitem(CMaintain, "Diagnósticos", 	"diag.html", 1, "mainhelp.js");
MaintainMenu[6 ]=new Gitem(CMaintain, "Registro del sistema", 	"logintro.html", logintro, "mainhelp.js");
MaintainMenu[7 ]=new Gitem(CMaintain, "Salir del sistema",  "logoutm.html",	1, "");


StatMenu[0 ]=new Gitem(CStatus, "Estado del dispositivo", "info.html", 1, "statushelp.js");
StatMenu[1 ]=new Gitem(CStatus, "Clientes conectados", 	"wlstationlist.html", 1, "statushelp.js");
StatMenu[2 ]=new Gitem(CStatus, "Estadísticas", 	"statistic.html", 1, "statushelp.js");
StatMenu[3 ]=new Gitem(CStatus, "Encaminamiento Info", "routingtable.html", 1, "statushelp.js");
StatMenu[4]=new Gitem(CStatus, "Salir del sistema",  "logoutm.html",	1, "");


HelpMenu[0 ]=new Gitem(CHelp, "Menú", "helpmenu.html", 1, "");
HelpMenu[1 ]=new Gitem(CHelp, "Básico", "helpbasic.html", 1, "");
HelpMenu[2 ]=new Gitem(CHelp, "Avanzados", "helpadvanced.html", 1, "");
HelpMenu[3 ]=new Gitem(CHelp, "Mantenimiento", "helpmaintenance.html", 1, "");
HelpMenu[4 ]=new Gitem(CHelp, "Estado", "helpstatus.html", 1, "");
HelpMenu[5 ]=new Gitem(CMaintain, "Salir del sistema",  "logoutm.html",	1, "");

var home='index.html';
var adv=getDefaultPage(1); //'scvrtsrv.cmd?action=view';
var maintenace=getDefaultPage(2);
var status=getDefaultPage(3);
var help=getDefaultPage(4);


TabMenu[0 ] =new Gtab("Configuración", home);
TabMenu[1 ] =new Gtab("Avanzado", adv); //"portmap.cmd");
TabMenu[2 ] =new Gtab("Mantenimiento", maintenace); //"upload.html");
TabMenu[3 ] =new Gtab("Estado", status);
TabMenu[4 ] =new Gtab("Ayuda", help);

function getDefaultPage(ID)
{
	var sideMenu = HomeMenu;
	
	if (ID == 1)
	{
		sideMenu = AdvMenu;
	}
	else if (ID == 2)
	{
		sideMenu = MaintainMenu;
	}	
	else if (ID == 3)
	{
		sideMenu = StatMenu;
	}
	else if (ID == 4)
	{
		sideMenu = HelpMenu;
	}

	for(i=0;i < sideMenu.length;i++)
    {               
		if (sideMenu[i].ishow == 1)
        	return sideMenu[i].surl;
    }
}

function Gitem(ifolder,sname,surl,ishow,shelp)
{
    this.ifolder=ifolder;
    this.sname=sname;
    this.surl=surl;
    this.ishow=ishow;
    this.shelp=shelp;
}

function Gtab(sname,surl)
{
    this.sname=sname;
    this.surl=surl;
}

function doLink(surl)
{
    shref =""+surl;
    document.location.href = shref;
}

function GetTABpos()
{
	var tabOn = 0;

	for(i=0; i < TabMenu.length; i++)
	{
		if (TabHeader == TabMenu[i].sname)
			tabOn = i;
	}

	return tabOn;
}

function GetSidepos(menu)
{
	var tabOn = 0;

	for(i=0; i < menu.length; i++)
	{
		if (SideItem == menu[i].sname)
			tabOn = i;
	}

	return tabOn;
}

function WFI_user(){
	    var top1 = '<TD width=155 class=';
	var top2 = '><A href="';
	var top3 = '" onclick=buttonchange()>';
	var top4 = '</A></TD>';

	var result = "";


	tabPos = GetTABpos();
		for(i=2; i < TabMenu.length; i++)
	{
		if (i<TabMenu.length -1)  
			top1 = '<TD width=315 class=';
		else 
			top1 = '<TD width=150 class=';
		if (tabPos == i)
			result = result + top1 + 'topnavon' + top2 + TabMenu[i].surl + top3 + TabMenu[i].sname + top4;
		else
			result = result + top1 + 'topnavoff' + top2 + TabMenu[i].surl + top3 + TabMenu[i].sname + top4;
			
	}		

	document.write(result);
}

function WFI_support(){
	    var top1 = '<TD width=155 class=';
	var top2 = '><A href="';
	var top3 = '" onclick=buttonchange()>';
	var top4 = '</A></TD>';

	var result = "";


	tabPos = GetTABpos();
		for(i=0; i < TabMenu.length; i++)
	{
		if ( i == 1) continue;
		if ( i<TabMenu.length -1)  
			top1 = '<TD width=206 class=';
		else 
			top1 = '<TD width=150 class=';
		if (tabPos == i)
			result = result + top1 + 'topnavon' + top2 + TabMenu[i].surl + top3 + TabMenu[i].sname + top4;
		else
			result = result + top1 + 'topnavoff' + top2 + TabMenu[i].surl + top3 + TabMenu[i].sname + top4;
			
	}		

	document.write(result);
}


function WFI_admin(){
	    var top1 = '<TD width=155 class=';
	var top2 = '><A href="';
	var top3 = '" onclick=buttonchange()>';
	var top4 = '</A></TD>';

	var result = "";


	tabPos = GetTABpos();
		for(i=0; i < TabMenu.length; i++)
	{
		if (tabPos == i)
			result = result + top1 + 'topnavon' + top2 + TabMenu[i].surl + top3 + TabMenu[i].sname + top4;
		else
			result = result + top1 + 'topnavoff' + top2 + TabMenu[i].surl + top3 + TabMenu[i].sname + top4;
			
	}		

	document.write(result);
}
function Write_Folder_Images()
{/*
    var top1 = '<TD width=155 class=';
	var top2 = '><A href="';
	var top3 = '">';
	var top4 = '</A></TD>';

	var result = "";

	var currentuser = "user";
	tabPos = GetTABpos();
	*/

	if (currentuser == "admin") 
		WFI_admin();
	else if  (currentuser == "support") 
		WFI_support();
	else if (currentuser == "user") 
		WFI_user();
	/*
	for(i=0; i < TabMenu.length; i++)
	{
		if (currentuser == "user"  &&  i < 2) continue;
		if (currentuser == "user" && i<TabMenu.length -1)  
			top1 = '<TD width=315 class=';
		else 
			top1 = '<TD width=150 class=';

		if (currentuser == "support"  &&  i == 2) continue;
		if (currentuser == "support" && i<TabMenu.length -1)  
			top1 = '<TD width=206 class=';
		else 
			top1 = '<TD width=150 class=';
		if (tabPos == i)
			result = result + top1 + 'topnavon' + top2 + TabMenu[i].surl + top3 + TabMenu[i].sname + top4;
		else
			result = result + top1 + 'topnavoff' + top2 + TabMenu[i].surl + top3 + TabMenu[i].sname + top4;
			
	}		

	document.write(result);
	*/
}

function ChangeLang(cb)
{	
	var loc = 'webui.cgi?language=';
	loc += cb.value;
	if(top.frames[0].quicksetup == '1')
		loc += '&item=' + top.frames[0].currurl;
	else
		loc += '&item=' + loadesp;
//	alert(loc);	
	var code = 'location="' + loc +'"';
    eval(code);
}

function buttonchange(){
top.frames[0].quicksetup = 0;

}

function Write_Item_Images()
{
	var sideMenu = HomeMenu;;
	var top = '<TD id=sidenav_container><DIV id=sidenav><UL>';
	var bottom1 = '</LI></UL></DIV>';
	var bottom2 = '</TD>';
	var side1 = '<LI><DIV ';
	var side2 = '><A href="';
	var side3 = '" onclick=buttonchange()>';
	var side4 = '</A></DIV></LI>';
	var result = "";

	if (tabPos == 0)
	{
		sideMenu = HomeMenu;
	}
	else if (tabPos == 1)
	{
		sideMenu = AdvMenu;
	}
	else if (tabPos == 2)
	{
		sideMenu = MaintainMenu;
	}	
	else if (tabPos == 3)
	{
		sideMenu = StatMenu;
	}
	else if (tabPos == 4)
	{
		sideMenu = HelpMenu;
	}
 	if (currentuser == "user" && tabPos < 2)  
		sideMenu = MaintainMenu;
	var g_FID= GetSidepos(sideMenu);

	for(i=0;i < sideMenu.length;i++)
    {               
		if ((g_FID == i)&&(sideMenu[i].ishow == 1)){
			result = result + side1 + 'class=sidenavoff' + side2 + sideMenu[i].surl + side3 + sideMenu[i].sname + side4;
			loadesp = sideMenu[i].surl;			
			}
		else if (sideMenu[i].ishow == 1)
			result = result + side1 + side2 + sideMenu[i].surl + side3 + sideMenu[i].sname + side4;
        
    }

	document.write(top);
	document.write(result);
	document.write(bottom1);
		document.writeln('<DIV>');
		if (InternetCon == 'Up')
			{
			document.write("<table>");
			document.write("<tr>");
			document.write("<td><IMG alt='' src='images/InternetLED_Green.gif'></td>");
			document.write("<td><font color=lightgreen><b><BR>Con conexión a internet</b></td>");
			document.write("</tr>");
			document.write("</table></DIV>");
			}
		else
			{
			document.write("<table>");
			document.write("<tr>");
			document.write("<td><IMG alt='' src='images/InternetLED_gray.gif'></td>");
			document.write("<td><font color=gray><b><BR>Sin conexión a internet</b></td>");
			document.write("</tr>");
			document.write("</table></DIV>");
			}
	
	document.writeln('<DIV><BR></DIV>');
	document.writeln("<DIV align=center>");
	document.write("<table>");
	document.write("<tr>");
	document.writeln("<td><SELECT  name='language' id='language' onchange=ChangeLang(this)>");
	document.writeln("<OPTION value='Spain' selected>Español</OPTION>");
	document.writeln("<OPTION value='English'>English</OPTION>");
	document.writeln("<OPTION value='French'>Français</OPTION>");
	document.writeln("<OPTION value='German'>Deutsch</OPTION>");
	document.writeln("<OPTION value='Italy'>Italiano</OPTION></td>");
	document.write("</tr>");
	document.write("<tr><td><BR></td></tr>");
	document.write("<tr>");
	document.writeln("<td><input type=button onClick='btnReboot()' value='Reiniciar'></td>");
	document.write("</tr>");
	document.write("</table>");
	document.write("</DIV>");
	document.write(bottom2);
	
}

function mainTableStart()
{
	var tabPos;

   document.write('<style>');
	document.write('div.overflow');
	document.write('{');
	document.write('	overflow: auto;');
	if (HelpItem != ""){
	  document.write('	width: 530px;');
	} else {
	  document.write('	width: 660px;');
	}
	document.write('}');
  document.write('</style>');

	tabPos = GetTABpos();

	if (tabPos == 4)
		document.write('<DIV align="center" style="display: hidden" id="tblmain">');
	else
		document.write('<DIV align="center" style="display: none" id="tblmain">');

	document.write('<TABLE cellSpacing=0 width="800"><TR><TD>');
	document.write('<TABLE id=header_container width="800"><TR>');
	document.write('<TD align=left width="200">Producto: ' + ModemVer + '</TD>');
//	document.write('<TD align=right width="200">Hardware Version: ' + HardwareVer + '</TD>');
	document.write('<TD align=right width="50"></TD>');
//	document.write('<TD align=right width="550">Firmware Version: ' + FirmwareVer + ' Hardware Version: ' + HardwareVer + '</TD>');
	document.write('<TD align=right width="550">Firmware Version: '  + FirmwareVer + '</TD>');
	document.write('</TR></TABLE>');
}

function logo()
{
	document.write('<TABLE cellSpacing=0 width="800"><TR><TD id=masthead_container width="800"><IMG alt="" src="images/img_masthead.gif"></TD></TR></TABLE>');
}

function TopNav()
{
	document.write('<TABLE id=topnav_container border=0 width="800"><TR><TD id=modnum><IMG alt="" src="images/img_modnum.gif"></TD>');
	Write_Folder_Images();
	document.write('</TR></TABLE>');
}
function ThirdRowStart()
{
	document.write('<TABLE id=content_container cellSpacing=0 summary="" border=0 width="800"><TR>');
}

function mainBodyStart()
{
	document.write('<TD id=maincontent_container><TABLE><TR><TD>');
	
  if (HelpItem != ""){	
	  document.write('<DIV id=maincontent style="width:558">');
	} else {
	  document.write('<DIV id=maincontent style="width:665">');
	}
}
function mainBodyEnd()
{
	document.write('</DIV>');
	document.write('</TD></TR></TABLE></TD>');
}
function ThirdRowEnd()
{
	var sideMenu;

	if (tabPos == 0)
	{
		sideMenu = HomeMenu;
	}
	else if (tabPos == 1)
	{
		sideMenu = AdvMenu;
	}
	else if (tabPos == 2)
	{
		sideMenu = MaintainMenu;
	}	
	else if (tabPos == 3)
	{
		sideMenu = StatMenu;
	}
	else if (tabPos == 4)
	{
		sideMenu = HelpMenu;
	}

	var g_FID= GetSidepos(sideMenu);

  if (HelpItem != ""){	
	document.write('<TD id=sidehelp_container>');
	document.write('<DIV id=help_text>');
	document.write('<LABEL id="helpLabel"></label>');
	document.write('<script language="Javascript" src="' + sideMenu[g_FID].shelp + '"></script>');	
	document.write('</DIV>');
	document.write('</TD>');
	}

	document.write('</TR></TABLE>');
	
}
function Footer()
{
	document.write('<TABLE id=footer_container cellSpacing=0 border=0><TR><TD id=leftimage>');
	document.write('<IMG height=35 alt="" src="images/img_bottom.gif" width=114></TD>');
	document.write('<TD>&nbsp;</TD></TR></TABLE>');
	
}
function mainTableEnd()
{
	document.write('</TD></TR></TABLE><DIV id=copyright>Copyright &copy; 2005-2007 D-Link Systems, Inc.</DIV></DIV>');
	setTimeout("document.getElementById('tblmain').style.display = 'block'", delaytimer);
	
}

function btnReboot(){
  var code = 'location="rebootinfo.cgi"';
  eval(code);
}
