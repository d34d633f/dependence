﻿if (HelpItem=='deviceinfo'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Auf dieser Seite wird ein Überblick über den Status des Routers (inklusive Firmware-Version des Geräts) sowie über Ihre Internetkonfiguration (inklusive Wireless- und Ethernet-Status) angezeigt.<br><br>' +
                                        '<a href="helpstatus.html#DeviceInfo">Weitere Informationen...</a>';

} else if (HelpItem=='connectclients'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Zeigt eine Liste der Clients an, welche zur Zeit mit dem Router verbunden sind. Dabei wird zwischen per Drahtlosnetzwerk und per Kabelnetzwerk verbundenen Clients unterschieden.In der Liste der verbundenen Clients per Drahtlosnetzwerk werden alle momentan per Drahtlosnetzwerk verbundene Clients angezeigt. In der Auflistung der per Kabelnetzwerk verbundenen Clients werden nur solche Clients angezeigt, welche eine dynamisch zugewiesene 	IP-Adresse vom DHCP-Server in diesem Router erhalten haben.<br><br>' +
                                        '<a href="helpstatus.html#WirelessClients">Weitere Informationen...</a>';

} else if (HelpItem=='dhcpclient'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Zeigt eine Liste der momentan mit dem Router verbundenen Clients an, getrennt nach WLAN- und LAN-Clients.  In der Liste der WLAN-Clients werden alle momentan verbundenen drahtlosen PCs und Clients angezeigt.  Die Liste der LAN-Clients zeigt alle aktiven mittels DHCP dynamisch zugewiesenen IP-Adressen an. Dies schließt sowohl die drahtlos als auch die über Ethernet verbundenen PCs und Clients ein.<br><br>' +
                                        '<a href="helpmenu.html">MWeitere Informationen...</a>';
} else if (HelpItem=='log'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Check the log frequently to detect unauthorized network usage.<br><br>' +
                                        '<a href="helpstatus.html#Logs">Weitere Informationen...</a>';

} else if (HelpItem=='statistics'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Auf dieser Seite werden Statistiken zum Router-Netzwerk sowie zum Datentransfer angezeigt. Diese Daten werden eventuell vom Technischen Kundendienst von D-Link benötigt, um zu bestimmen, ob Ihr Router ordnungsgemäß funktioniert.  Die Angaben dienen lediglich zu Ihrer Information. Sie beeinflussen nicht die Funktionstüchtigkeit des Routers.<br><br>' +
                                        '<a href="helpstatus.html#Statistics">Weitere Informationen...</a>';

}else if (HelpItem=='ber'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Der Test der ADSL Spitze Fehlerhäufigkeit (BRUSTBEERE) stellt die Qualität des ADSL Anschlußes. ' +
                                        'des Tests wird getan fest, indem er die untätigen Zellen bringt, die ein bekanntes Muster enthalten und die empfangenen Daten mit diesem bekannten Muster vergleichen, um auf alle mögliche Störungen zu überprüfen.<br><br>' +
                                        '<a href="helpstatus.html#BER">Weitere Informationen...</a>';
}
else if (HelpItem=='routingtable'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
  													'Die Routingtabelle zeigt die eingerichteten statischen Routen, das jeweilige Zielnetz, 						Subnetzmaske sowie Gateway an.<br><br>'+
                                        '<a href="helpstatus.html#RoutingInfo">Weitere Informationen...</a>';
}