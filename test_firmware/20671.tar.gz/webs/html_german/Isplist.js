﻿var CountryList=new Array();
var ISPList=new Array();

var ispPrtcl;
var ispEncap;
var ispVPI;
var ispVCI;
var ispMTU;

var PPPoEPPPoA=new Array();
var Dynamic=new Array();
var Static=new Array();

var cn=0;
CountryList[cn++]=new Citem("Belgium", 3);
CountryList[cn++]=new Citem("Bosnia and Herzegovina", 2);
CountryList[cn++]=new Citem("Bulgaria", 1);
CountryList[cn++]=new Citem("Croatia", 4);
CountryList[cn++]=new Citem("Czech Republic", 4);
CountryList[cn++]=new Citem("Denmark", 1);
CountryList[cn++]=new Citem("Finland", 4);
CountryList[cn++]=new Citem("France", 13);
CountryList[cn++]=new Citem("Germany", 15);
CountryList[cn++]=new Citem("Greece", 8);
CountryList[cn++]=new Citem("Hungary", 2);
CountryList[cn++]=new Citem("Ireland", 4);
CountryList[cn++]=new Citem("Italy", 12);
CountryList[cn++]=new Citem("Lichtenstein", 1);
CountryList[cn++]=new Citem("FYROM", 1);
CountryList[cn++]=new Citem("Montenegro", 1);
CountryList[cn++]=new Citem("Netherlands", 5);
CountryList[cn++]=new Citem("Norway", 2);
CountryList[cn++]=new Citem("Poland", 5);
CountryList[cn++]=new Citem("Portugal", 3);
CountryList[cn++]=new Citem("Romania", 1);
CountryList[cn++]=new Citem("Serbia", 7);
CountryList[cn++]=new Citem("Slovak Republic", 4);
CountryList[cn++]=new Citem("Slovenia", 1);
CountryList[cn++]=new Citem("Spain", 10);
CountryList[cn++]=new Citem("Sweden", 7);
CountryList[cn++]=new Citem("Switzerland", 6);
CountryList[cn++]=new Citem("United Kingdom", 30);

var num=0;
//Belgium
ISPList[num++]=new ISPitem("Belgium", "Belgacom/Skynet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Belgium", "Scarlet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Belgium", "Versatel/Tele2", "PPPoA", "VC Mux", 8, 35, 0);

//Bosnia
ISPList[num++]=new ISPitem("Bosnia and Herzegovina", "BiHNet", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Bosnia and Herzegovina", "HT", "PPPoE", "LLC", 8, 35, 1492);

//Bulgaria
ISPList[num++]=new ISPitem("Bulgaria", "BTC", "PPPoE", "LLC", 0, 35, 0);

//Croatia
ISPList[num++]=new ISPitem("Croatia", "H Telecom", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++]=new ISPitem("Croatia", "Iskon", "PPPoE", "LLC", 0, 33, 1492);
ISPList[num++]=new ISPitem("Croatia", "Optima Telekom", "PPPoE", "LLC", 0, 35, 1492);
ISPList[num++]=new ISPitem("Croatia", "T-Com", "PPPoE", "LLC", 0, 33, 1492);

//Czech Republic
ISPList[num++]=new ISPitem("Czech Republic", "GTS Novera", "PPPoE", "LLC", 8, 48, 0);
ISPList[num++]=new ISPitem("Czech Republic", "Radiokomunikace", "PPPoE", "LLC", 8, 48, 0);
ISPList[num++]=new ISPitem("Czech Republic", "Telefonica O2", "PPPoE", "LLC", 8, 48, 0);
ISPList[num++]=new ISPitem("Czech Republic", "Volny", "PPPoE", "LLC", 8, 48, 0);

//Denmark
ISPList[num++]=new ISPitem("Denmark", "TDC", "PPPoE", "LLC", 0, 35, 0);

//Finland
ISPList[num++]=new ISPitem("Finland", "DNA/Finnet", "Dynamic IP", "LLC", 0, 100, 0);
ISPList[num++]=new ISPitem("Finland", "Elisa", "Dynamic IP", "LLC", 0, 100, 0);
ISPList[num++]=new ISPitem("Finland", "Saunalahti", "Dynamic IP", "LLC", 0, 100, 0);
ISPList[num++]=new ISPitem("Finland", "Sonera", "Dynamic IP", "LLC", 0, 33, 0);

//France
ISPList[num++]=new ISPitem("France", "Alice", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("France", "AOL", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("France", "Bouygues Telecom", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("France", "Club Internet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("France", "Darty", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("France", "Easynet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("France", "Free", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("France", "Free (Degroupe)", "Static IP", "VC Mux", 8, 36, 0);
ISPList[num++]=new ISPitem("France", "Neuf Cegetel", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("France", "Nordnet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("France", "Orange (Wanadoo)", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("France", "SFR", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("France", "Tele2", "PPPoE", "LLC", 8, 35, 0);

//Germany
ISPList[num++]=new ISPitem("Germany", "1und1", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++]=new ISPitem("Germany", "Alice", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++]=new ISPitem("Germany", "AOL Germany", "PPPoE", "LLC", 1, 32, 1400);
ISPList[num++]=new ISPitem("Germany", "Arcor", "PPPoE", "LLC", 1, 32, 1488);
ISPList[num++]=new ISPitem("Germany", "Congster", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++]=new ISPitem("Germany", "Freenet", "PPPoE", "LLC", 1, 32, 1454);
ISPList[num++]=new ISPitem("Germany", "GMX", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++]=new ISPitem("Germany", "Hansenet", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++]=new ISPitem("Germany", "HeLi NET", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++]=new ISPitem("Germany", "Kamp-DSL", "PPPoE", "LLC", 1, 32, 1460);
ISPList[num++]=new ISPitem("Germany", "M-Net", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++]=new ISPitem("Germany", "Netcologne", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++]=new ISPitem("Germany", "T-Online", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++]=new ISPitem("Germany", "Tiscali Germany", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++]=new ISPitem("Germany", "Versatel", "PPPoE", "LLC", 1, 32, 1492);

//Greece
ISPList[num++]=new ISPitem("Greece", "Altec", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Greece", "Forthnet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Greece", "Hellas On Line", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Greece", "NetOne", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Greece", "On Telecoms", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Greece", "Otenet	", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Greece", "Tellas", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Greece", "Vivodi", "PPPoE", "LLC", 8, 35, 0);

//Hungary
ISPList[num++]=new ISPitem("Hungary", "Matav", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++]=new ISPitem("Hungary", "Invitel", "PPPoE", "LLC", 8, 35, 0);

//Ireland
ISPList[num++]=new ISPitem("Ireland", "Eircom", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Ireland", "Esat", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Ireland", "NTL", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Ireland", "TalkTalk", "PPPoE", "LLC", 8, 35, 1492);

//Italy
ISPList[num++]=new ISPitem("Italy", "Aruba", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++]=new ISPitem("Italy", "BT Albacom", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++]=new ISPitem("Italy", "Cheapnet", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++]=new ISPitem("Italy", "Eutelia", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++]=new ISPitem("Italy", "INFOSTRADA", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Italy", "Kataweb", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++]=new ISPitem("Italy", "McLink", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++]=new ISPitem("Italy", "Tele 2", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Italy", "Telecom Italia (PPPoE)", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Italy", "Telecom Italia (PPPoA)", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++]=new ISPitem("Italy", "Tiscali", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++]=new ISPitem("Italy", "Vira", "PPPoA", "VC Mux", 8, 35, 0);

//Lichtenstein
ISPList[num++]=new ISPitem("Lichtenstein", "Telecom FL", "PPPoE", "LLC", 8, 35, 0);

//FYROM
ISPList[num++]=new ISPitem("FYROM", "Maktel", "PPPoE", "LLC", 1, 32, 0);

//Montenegro
ISPList[num++]=new ISPitem("Montenegro", "T-Com", "PPPoE", "LLC", 0, 33, 1492);

//Netherlands
ISPList[num++]=new ISPitem("Netherlands", "BBned", "PPPoA", "VC Mux", 0, 35, 0);
ISPList[num++]=new ISPitem("Netherlands", "KPN", "PPPoA", "VC Mux", 8, 48, 0);
ISPList[num++]=new ISPitem("Netherlands", "Tele2", "Dynamic IP", "LLC", 0, 35, 0);
ISPList[num++]=new ISPitem("Netherlands", "Tiscali NL", "PPPoA", "VC Mux", 8, 48, 0);
ISPList[num++]=new ISPitem("Netherlands", "Versatel", "PPPoA", "VC Mux", 0, 32, 0);

//Norway
ISPList[num++]=new ISPitem("Norway", "Nexgentel", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++]=new ISPitem("Norway", "Telenor", "PPPoE", "LLC", 8, 35, 0);

//Poland
ISPList[num++]=new ISPitem("Poland", "Dialog", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++]=new ISPitem("Poland", "Dialog (TPSA)", "PPPoA", "VC Mux", 0, 35, 0);
ISPList[num++]=new ISPitem("Poland", "Netia", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Poland", "Netia (TPSA)", "PPPoA", "VC Mux", 0, 35, 0);
ISPList[num++]=new ISPitem("Poland", "TPSA", "PPPoA", "VC Mux", 0, 35, 0);

//Portugal
ISPList[num++]=new ISPitem("Portugal", "Clix", "PPPoE", "LLC", 0, 35, 0);
ISPList[num++]=new ISPitem("Portugal", "PT", "PPPoE", "LLC", 0, 35, 0);
ISPList[num++]=new ISPitem("Portugal", "Zon", "PPPoE", "LLC", 0, 35, 0);

//Romania
ISPList[num++]=new ISPitem("Romania", "Romtelecom", "PPPoE", "LLC", 0, 35, 0);

//Serbia
ISPList[num++]=new ISPitem("Serbia", "BeotelNET", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Serbia", "DrenikNet", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Serbia", "EUNet", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Serbia", "Neobee Net", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Serbia", "PTT Net", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Serbia", "SezamPro", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Serbia", "VeratNet", "PPPoE", "LLC", 8, 35, 1492);

//Slovak Republic
ISPList[num++]=new ISPitem("Slovak Republic", "GTS Nextra", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++]=new ISPitem("Slovak Republic", "Slovanet", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++]=new ISPitem("Slovak Republic", "SWAN", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++]=new ISPitem("Slovak Republic", "T-COM", "PPPoE", "LLC", 1, 32, 0);

//Slovenia
ISPList[num++]=new ISPitem("Slovenia", "Siol/Telekom", "PPPoE", "LLC", 1, 32, 1480);

//Spain
ISPList[num++]=new ISPitem("Spain", "Auna", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++]=new ISPitem("Spain", "Jazztel", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++]=new ISPitem("Spain", "Orange", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Spain", "Telefonica(IP Dinamica)", "PPPoE", "LLC", 8, 32, 0);
ISPList[num++]=new ISPitem("Spain", "Telefonica(IP Estatica)", "Static IP", "LLC", 8, 32, 0);
ISPList[num++]=new ISPitem("Spain", "Wanadoo", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++]=new ISPitem("Spain", "Ya.com(PPPoA)", "PPPoA", "VC Mux", 8, 32, 0);
ISPList[num++]=new ISPitem("Spain", "Ya.com(PPPoE)", "PPPoE", "LLC", 8, 32, 0);
ISPList[num++]=new ISPitem("Spain", "Ya.com(IP Dinamica)", "Dynamic IP", "LLC", 8, 32, 0);
ISPList[num++]=new ISPitem("Spain", "Ya.com(IP Estatica)", "Static IP", "LLC", 8, 32, 0);

//Sweden
ISPList[num++]=new ISPitem("Sweden", "Bredbandsbolaget(PPPoE)", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Sweden", "Bredbandsbolaget(Static IP)", "Static IP", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Sweden", "Glocalnet(PPPoE)", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Sweden", "Glocalnet(Static IP)", "Static IP", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Sweden", "Telia", "Dynamic IP", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Sweden", "Tele2(Dynamic IP)", "Dynamic IP", "LLC", 8, 35, 0);
ISPList[num++]=new ISPitem("Sweden", "Tele2(PPPoE)", "PPPoE", "LLC", 8, 35, 0);

//Switzerland
ISPList[num++]=new ISPitem("Switzerland", "Bluewin", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Switzerland", "Econophone", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Switzerland", "Green", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Switzerland", "Sunrise", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Switzerland", "Tele2", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++]=new ISPitem("Switzerland", "VTX", "PPPoE", "LLC", 8, 35, 1492);

//United Kingdom
ISPList[num++]=new ISPitem("United Kingdom", "AOL", "PPPoA", "VC Mux", 0, 38, 1400);
ISPList[num++]=new ISPitem("United Kingdom", "BT", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++]=new ISPitem("United Kingdom", "Bulldog", "PPPoA", "VC Mux", 0, 38, 1458);
ISPList[num++]=new ISPitem("United Kingdom", "Demon Internet", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++]=new ISPitem("United Kingdom", "Easynet", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++]=new ISPitem("United Kingdom", "Eclipse", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "Entanet", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "Freedom 2 surf", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "Griffin", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "Madasfish", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "Namesco", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "Netservices", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "Nildram", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++]=new ISPitem("United Kingdom", "O2", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "One.Tel", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++]=new ISPitem("United Kingdom", "Orange", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "PlusNet", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "Pipex", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++]=new ISPitem("United Kingdom", "Sky Broadband", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "T-Mobile", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "TalkTalk", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "Tesco.Net", "PPPoA", "VC Mux", 0, 38, 1432);
ISPList[num++]=new ISPitem("United Kingdom", "Tiscali", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++]=new ISPitem("United Kingdom", "Toucan", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "Twang", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "UK Online", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++]=new ISPitem("United Kingdom", "Virgin", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++]=new ISPitem("United Kingdom", "Virgin.Net", "PPPoA", "VC Mux", 0, 38, 1432);
ISPList[num++]=new ISPitem("United Kingdom", "Wanadoo", "PPPoA", "VC Mux", 0, 38, 1458);
ISPList[num++]=new ISPitem("United Kingdom", "Zen Internet", "PPPoA", "VC Mux", 0, 38, 0);


function Citem(scountry, iispcount)
{
    this.scountry=scountry;
    this.iispcount=iispcount;
}


function ISPitem(scountry,sname,sprtcl,sencap,ivpi, ivci, imtu)
{
    this.scountry=scountry;
    this.sname=sname;
    this.sprtcl=sprtcl;
    this.sencap=sencap;
    this.ivpi=ivpi;
    this.ivci=ivci;
    this.imtu=imtu;
}

function changeISP(cb1, cb2){

var value = cb1[cb1.selectedIndex].value;
	
	cb2.options.length=0;

	cb2.options[0]=new Option("(Click to select)", "-1");

	if ((value == -1)||(value == -2)){
		cb2.options[1]=new Option("Others", "-2");
		if ((value == -2))
			cb2.selectedIndex = cb2.length - 1;

		return;
	}

	var count =0;

	for (i=0; i < ISPList.length; i++){
		if (CountryList[cb1[cb1.selectedIndex].value].scountry == ISPList[i].scountry){
			cb2.options[count+1]=new Option(ISPList[i].sname, i);
			count++;
		}

		if (count == CountryList[cb1[cb1.selectedIndex].value].iispcount){
			break;
		}
	}

	cb2.options[count + 1]=new Option("Others", "-2");
	
}

function createCountry(cb){
	
	cb.options.length=0;

	cb.options[0]=new Option("(Click to select)", "-1");

	var count =0;

	for (i=0; i < CountryList.length; i++){
		cb.options[i+1]=new Option(CountryList[i].scountry, i);
		count++;
	}

	cb.options[count + 1]=new Option("Others", "-2");
	
}

function getISPDetails(cb){

var value = cb[cb.selectedIndex].value;

	if ((value == -1)||(value == -2)){
		ispPrtcl = "";
		ispEncap = "";
		ispVPI = 0;
		ispVCI = 35;
		ispMTU = 0;
		return;
	}

	ispPrtcl = ISPList[cb[cb.selectedIndex].value].sprtcl;
	ispEncap = ISPList[cb[cb.selectedIndex].value].sencap;
	ispVPI = ISPList[cb[cb.selectedIndex].value].ivpi;
	ispVCI = ISPList[cb[cb.selectedIndex].value].ivci;
	ispMTU = ISPList[cb[cb.selectedIndex].value].imtu;
	
}

function setContype(cb){
	
	cb.options.length = 0;

	cb.options[0] = new Option("(Click to Select)", "-1");
	cb.selectedIndex = 0;

	if (ispPrtcl == "PPPoA"){
		cb.options[1] = new Option("VC-Mux", "PPPoAVCMux");
		cb.options[2] = new Option("LLC", "PPPoALLC");
		if (ispEncap == "LLC")
			cb.selectedIndex = 2;
		else if (ispEncap == "VC Mux")
			cb.selectedIndex = 1;
	} else if (ispPrtcl == "PPPoE"){
		cb.options[1] = new Option("VC-Mux", "PPPoEVCMux");
		cb.options[2] = new Option("LLC", "PPPoELLC");
		if (ispEncap == "LLC")
			cb.selectedIndex = 2;
		else if (ispEncap == "VC Mux")
			cb.selectedIndex = 1;
	} else if (ispPrtcl == "Dynamic IP"){
		cb.options[1] = new Option("LLC", "DynLLC");
		cb.options[2] = new Option("VC-Mux", "DynVCMux");
		if (ispEncap == "LLC")
			cb.selectedIndex = 1;
		else if (ispEncap == "VC Mux")
			cb.selectedIndex = 2;
	} else if (ispPrtcl == "Static IP"){
		cb.options[1] = new Option("LLC", "MerLLC");
		cb.options[2] = new Option("VC-Mux", "MerVCMux");
//		cb.options[2] = new Option("1483 Routed IP LLC", "IPoALLC");
//		cb.options[3] = new Option("1483 Routed IP VC-Mux", "IPoAVCMux");
		if (ispEncap == "LLC")
			cb.selectedIndex = 1;
		else if (ispEncap == "VC Mux")
			cb.selectedIndex = 2;
	} else if (ispPrtcl == "Bridge"){
		cb.options[1] = new Option("LLC", "MerLLC");
		cb.options[2] = new Option("VC-Mux", "MerVCMux");
		if (ispEncap == "LLC")
			cb.selectedIndex = 1;
		else if (ispEncap == "VC Mux")
			cb.selectedIndex = 2;
	}
}
