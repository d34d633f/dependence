﻿if (HelpItem=='firmware'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Auf dieser Seite werden die Firmware-Version Ihres Geräts und sonstige Informationen angezeigt, die hilfreich für den Kundendienst von D-Link sind, wenn Sie technische Unterstützung benötigen. Diese Angaben sind in erster Linie zu Ihrer Information gedacht, da ein Upload neuer Firmware auf den Router meist unnötig ist.<br><br>' +
                                        '<a href="helpmaintenance.html#Firmware">Weitere Informationen...</a>';

} else if (HelpItem=='system'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Über diese Seite können Sie die Konfiguration des Routers als Datei auf Ihrem Computer speichern. Dies ist eine Sicherheitsmaßnahme für den Fall, dass Sie den Router auf die Werkseinstellungen zurücksetzen müssen.  Sie können dann Ihre Router-Einstellungen mit Hilfe einer solchen vorher gespeicherten Konfigurationsdatei wiederherstellen.  Es besteht hier außerdem die Möglichkeit, den Router auf die Werkseinstellungen zurückzusetzen.  Wenn Sie den Router auf die werkseitigen Voreinstellungen zurücksetzen, werden alle aktuellen Konfigurationseinstellungen gelöscht.<br><br>' +
                                        '<a href="helpmaintenance.html#System">Weitere Informationen...</a>';

} else if (HelpItem=='diag'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Auf dieser Seite werden die Ergebnisse der Selbstdiagnose des Routers sowie der Überprüfung der Verbindungen angezeigt.  Der Status der Internetverbindung lautet nur dann "BESTANDEN", wenn die Internetverbindung korrekt konfiguriert wurde und der Router online ist.<br><br>' +
                                        '<a href="helpmaintenance.html#Diag">Weitere Informationen...</a>';

} else if (HelpItem=='acadmin'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Auf dieser Seite können Sie Ihr Router-Kennwort ändern, das Sie für den Zugriff auf diese webbasierte Verwaltungsoberfläche benötigen.  Aus Sicherheitsgründen sollten Sie das Gerätekennwort ändern.  Wählen Sie ein Kennwort, das Sie sich merken können, oder schreiben Sie es auf, und bewahren Sie es an einem sicheren Ort auf.  Falls Sie Ihr Gerätekennwort vergessen, bleibt Ihnen nur die Möglichkeit, Ihren Router auf die Werkseinstellungen zurückzusetzen. Dadurch gehen alle Ihre Einstellungen der Gerätekonfiguration verloren.<br><br>' +
                                        '<a href="helpmaintenance.html#Password">Weitere Informationen...</a>';

} else if (HelpItem=='acip'){
  document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br> ' +
                                        'You can restrict users who can access the local management using IP address.<br><br>' +
                                        '<a href="helpmaintenance.html#Access">More...</a>';

} else if (HelpItem=='syslog'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Auf dieser Seite können Sie das Systemprotokoll des Routers aktivieren, konfigurieren und anzeigen.  Im Systemprotokoll werden alle Aktivitäten des Routers gespeichert.  Aufgrund der begrenzten Speicherkapazität des Routers hängt die Anzahl der möglichen Protokolleinträge davon ab, wie ausführlich Sie das Protokoll eingerichtet haben.  Wenn Sie über einen externen SYSLOG-Server verfügen, sollten Sie eine externe Protokollierung einrichten. Alle Protokolleinträge werden dann an den Remote-Server versendet.<br><br>' +
                                        'Sie können den Router auch so konfigurieren, dass er das Systemprotokoll an eine bestimmte E-Mail-Adresse sendet. Sie müssen in diesem Fall die Daten des E-Mail-Servers eingeben, die Sie von Ihrem Internetdienstanbieter erhalten haben.<br><br>' +
                                        '<a href="helpmaintenance.html#SystemLog">Weitere Informationen...</a>';

} else if (HelpItem=='captcha'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Diese Seite ermöglicht es Ihnen zu ermöglichen, oder deaktivieren Sie die CAPTCHA-Funktion in Ihrem Login-Seite. Wenn Sie möchten, dass zur Verbesserung der Sicherheit Ihres Routers, sollten Sie die Funktion. Otherwisze können Sie deaktivieren, wenn Sie nicht recongnize der Authentifizierung Bild.<br><br>';
}

