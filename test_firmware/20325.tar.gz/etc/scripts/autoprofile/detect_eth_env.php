<?

function cmd($cmd)	{echo $cmd."\n";}

del("/runtime/internetprofile/eth_env");

$WAN1_devname = "eth1";	// Hard code for DIR-518.

cmd("udhcpc -i ".$WAN1_devname." -d -D 1 -R 2 | grep -q 'yes' || xmldbc -s /runtime/internetprofile/eth_env/dhcp no");

cmd("pppd pty_pppoe pppoe_discovery pppoe_device ".$WAN1_devname." | grep -q 'yes' || xmldbc -s /runtime/internetprofile/eth_env/pppoe no");
	
?>
