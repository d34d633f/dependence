<?
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/phyinf.php";
include "/htdocs/phplib/trace.php";
include "/etc/services/WIFI/function.php";

/*-------------------------------------------------------
 * [$ACTIVEPRO]
 * 		the profile uid which user selected from web UI,
 *		when user select a profile to active, 
 *		we should check the profile first.
 *-------------------------------------------------------
 * [$TYPE] eth, 3g, wisp
 * [$ACTION]
 *	- starttest: 
 *	- stop:
 *	- checkresult: check testing result	
 *-------------------------------------------------------*/

function detect_static($act, $id, $ifname, $profile, $hlper)
{
	$detect_type = "static";
	$r_p = XNODE_getpathbytarget("/runtime", "internetprofile/entry", "profileuid", $id, 0);
	
	anchor($profile."/config");
	$ipaddr = query("ipaddr");
	$mask = query("mask");
	$gateway = query("gateway");
	$dns_cnt = query("dns/count");
	if($dns_cnt > 0) { $dns1 = query("dns/entry"); }
	if($dns_cnt > 1) { $dns1 = query("dns/entry:2"); }
	$mtu = query("mtu");
	
	if ( $ipaddr == "" || $mask == "" || $gateway == "" )
	{ 
		set($r_p."/status", "disconnected");
		set($r_p."/pingresult", "failed");
		return ; 
	}

	if($act=="starttest")
	{
		echo "phpsh ".$hlper.
		     " TYPE=".$detect_type.
		     " INTERFACE=".$ifname.
		     " IP=".$ipaddr.
		     " SUBNET=".$mask.
		     " ROUTER=".$gateway.
		     " PROUID=".$id."\n";
	}
	else if($act=="stoptest")
	{
		echo "ip addr del ".$ipaddr."/".$mask." dev ".$ifname."\n";
		echo 'xmldbc -s '.$r_p.'/status disconnected\n';
	}
}

function detect_dhcp($act, $id, $ifname, $profile, $hlper)
{
	$detect_type = "dhcp";
	
	$udhcpc_helper = "/var/run/".$id."-test-udhcpc.sh";
	$udhcpc_pid = "/var/run/".$id."-test-udhcpc.pid";
	
	anchor($profile."/config");
	$host = query("hostname");
	
	if($act=="starttest")
	{
		/* Generate the callback script for udhcpc. */
		fwrite(w, $udhcpc_helper,
		'#!/bin/sh\n'.
		'echo [$0]: act=$1 ifname=$interface ip=$ip mask=$subnet gw=$router dns=$dns... > /dev/console\n'.
		'phpsh '.$hlper.
		' TYPE='.$detect_type.
		' ACTION=$1'.
		' INTERFACE=$interface'.
		' IP=$ip'.
		' SUBNET=$subnet'.
		' "ROUTER=$router"'.
		' "DNS=$dns"'.
		' "PROUID='.$id.'"'.
		' "PID='.$udhcpc_pid.'"\n'.
		' xmldbc -k test-udhcpc \n'.
		'exit 0\n'
			);
		$udhcpc_fail = "/var/run/".$id."-test-udhcpc-fail.sh";
		
		fwrite ("w",$udhcpc_fail, 
			'#!/bin/sh\n'.
			'echo [$0]:> /dev/console\n'.
			'/etc/scripts/killpid.sh '.$udhcpc_pid.'\n'.
			'phpsh '.$hlper.
			' TYPE='.$detect_type.
			' "PROUID='.$id.'"\n'.
			'exit 0\n'
			);
		echo "chmod +x ".$udhcpc_fail."\n";

		echo "xmldbc -t 'test-udhcpc:5:".$udhcpc_fail."'\n";
		
		echo "chmod +x ".$udhcpc_helper."\n";
		echo "udhcpc -i ".$ifname." -H ".$host." -p ".$udhcpc_pid." -s ".$udhcpc_helper."\n";
	}
	else if($act=="stoptest")
	{
		echo "/etc/scripts/killpid.sh ".$udhcpc_pid."\n";
	}
}

function pppoptions($id, $inf, $ifname, $over, $profile)
{
	anchor($profile."/config");
	
	$optfile	= "/etc/ppp/options.".$id;
	
	$mtu = query("mtu");
	if($over=="eth")
	{
		if ($mtu=="" || $mtu > 1492) { $mtu = 1492; }
	}
	else if($over=="tty")
	{
		if ($mtu=="" || $mtu > 1500) { $mtu = 1500; }
	}
	
	$user	= get("s", "username");
	$pass	= get("s", "password");

	$idle = query("dialup/idletimeout");
	if($over=="eth") { $mode = "auto"; } /* alwayson */
	
	$static = query("static");
	if ($static==1)	$ipaddr = query("ipaddr");
	else $ipaddr = "";
	
	$auth_proto	= query("authprotocol");
	
	if($over=="tty")
	{
		$infp   = XNODE_getpathbytarget("", "inf", "uid", "LAN-1", 0);
		if (query($infp."/active")==1 && query($infp."/disable")!=1)
		{
			$inet   = query($infp."/inet");
			$inetp  = XNODE_getpathbytarget("/inet", "entry", "uid", $inet, 0);
			$lan1ip = query($inetp."/ipv4/ipaddr");
		}
		$infp   = XNODE_getpathbytarget("", "inf", "uid", "LAN-2", 0);
		if (query($infp."/active")==1 && query($infp."/disable")!=1)
		{
			$inet   = query($infp."/inet");
			$inetp  = XNODE_getpathbytarget("/inet", "entry", "uid", $inet, 0);
			$lan2ip = query($inetp."/ipv4/ipaddr");
		}
	}
	
	fwrite("w", $optfile, "noauth nodeflate nobsdcomp nodetach");
	fwrite("a", $optfile, " noccp\n");
	
	/* convert mtu to number. */
	$mtu = $mtu + 1 - 1;

	/* static options */
	fwrite("a", $optfile, "lcp-echo-failure 3\n");
	fwrite("a", $optfile, "lcp-echo-interval 30\n");
	fwrite("a", $optfile, "lcp-echo-failure-2 14\n");
	fwrite("a", $optfile, "lcp-echo-interval-2 6\n");
	fwrite("a", $optfile, "lcp-timeout-1 10\n");
	fwrite("a", $optfile, "lcp-timeout-2 10\n");
	fwrite("a", $optfile, "ipcp-accept-remote ipcp-accept-local\n");
	fwrite("a", $optfile, "mtu ".$mtu."\n");
	fwrite("a", $optfile, "linkname ".$inf."\n");
	fwrite("a", $optfile, "ipparam ".$inf."\n");
	fwrite("a", $optfile, "usepeerdns\n");	/* always use peer's dns.*/
	
	if ($user!="") fwrite("a",$optfile, 'user "'.$user.'"\n');
	else
	{
		if ($over=="tty")			fwrite("a",$optfile, 'user guest\n');
	}
	
	if ($pass!="") fwrite("a",$optfile, 'password "'.$pass.'"\n');
	else
	{
		if ($over=="tty")			fwrite("a",$optfile, 'password guest\n');
	}
	
	fwrite("a",$optfile, "persist\nmaxfail 1\n");

	/* Set local and remote IP */
	if ($ipaddr=="")
	{
		fwrite("a",$optfile, "noipdefault\n");
	}
	else
	{
		fwrite("a", $optfile, $ipaddr.":10.112.113.".cut($inf, 1, "-")."\n");
		if ($static==1) fwrite("a", $optfile, "ipcp-ignore-local\n");
	}

	if ($over=="eth")
	{
		$service= get("s", "servicename");
		fwrite("a", $optfile, "kpppoe pppoe_device ".$ifname."\n");
		fwrite("a", $optfile, "pppoe_hostuniq\n");
		if ($service!="") fwrite("a", $optfile, "pppoe_srv_name \"".$service."\"\n");
	}
	else if($over=="tty")
	{
		if ($auth_proto!="")
		{
			/* Authentication protocol PAP only */
			if($auth_proto=="PAP")
			{
				fwrite("a", $optfile, "refuse-eap\n");
				fwrite("a", $optfile, "refuse-chap\n");
				fwrite("a", $optfile, "refuse-mschap\n");
				fwrite("a", $optfile, "refuse-mschap-v2\n");
			}
			/* Authentication protocol CHAP only */
			if($auth_proto=="CHAP")
			{
				fwrite("a", $optfile, "refuse-eap\n");
				fwrite("a", $optfile, "refuse-pap\n");
				fwrite("a", $optfile, "refuse-mschap\n");
				fwrite("a", $optfile, "refuse-mschap-v2\n");
			}
		}
		fwrite("a",$optfile, "tty_ppp3g ppp3g_chat /etc/ppp/chat.".$id."-".$inf."\n");
		fwrite("a",$optfile, "modem\n");
		fwrite("a",$optfile, "crtscts\n");
		fwrite("a",$optfile, $ifname."\n");
		fwrite("a",$optfile, "115200\n");
		fwrite("a",$optfile, "novj\n");
		
		if ($lan1ip != "" || $lan2ip != "")
		{
			if($lan1ip != "") $lanip = $lan1ip;
			if($lan2ip != "") $lanip = $lanip.",".$lan2ip;
			fwrite("a",$optfile, "excluded_peer_ip ".$lanip."\n");
		}
	}

	return $optfile;
}

function detect_pppoe($act, $id, $inf, $over, $optfile, $hlper)
{
	if($over=="eth") { $type = "pppoe"; }
	else if($over=="tty") { $type = "3g"; }
	
	$sfile		= "/var/run/ppp-".$inf.".status";
	$pppd_pid	= "/var/run/ppp-".$inf.".pid";
	$dialuppid = "/var/run/ppp-".$id."-dialup.pid";
	$dialupsh	= "/var/run/ppp-".$id."-dialup.sh";
	
	$ipup = "/var/run/wantest/ppp/".$id."-ip-up";
	$ipdown = "/var/run/wantest/ppp/".$id."-ip-down";
	$pppstatus = "/var/run/wantest/ppp/".$id."-ppp-status";
	
	$r_pro_path = XNODE_getpathbytarget("/runtime", "internetprofile/entry", "profileuid", $id, 0);

	if ($over == "eth")
	{
		$pro_path = XNODE_getpathbytarget("/internetprofile", "entry", "uid", $id, 0);
		$user	= get("", $pro_path."/config/username");
		$pass	= get("", $pro_path."/config/password");
		if ($user == "" || $pass == "")
		{ 
			set($r_pro_path."/status", "disconnected");
			set($r_pro_path."/pingresult", "failed");
			return ; 
		}
	}

	if($act=="starttest")
	{
		fwrite("w", $ipup, "#!/bin/sh\n");
		fwrite("a", $ipup, "echo [$0]: ifname[$1] device[$2] speed[$3] ip[$4] remote[$5] param[$6] > /dev/console\n");
		fwrite("a", $ipup, "phpsh /etc/scripts/autoprofile/checkip.php ".
											 " TYPE=".$type.
											 " PROUID=".$id.
											 " PID=".$pppd_pid.
											 " DIALPID=".$dialuppid.
											 " DIALSH=".$dialupsh.
											 " DST=$5\n");
		
		fwrite("w", $ipdown, "#!/bin/sh\n");
		fwrite("a", $ipdown, "echo stop... > /dev/console\n");
		
		fwrite("w", $pppstatus, "#!/bin/sh\n");
		fwrite("a", $pppstatus, 'echo "[$0]: [$1] [$2] [$3] [$4] ['.$id.']" > /dev/console\n');
		
		fwrite("a", $pppstatus, 'xmldbc -s '.$r_pro_path.'/status $2 > /dev/console\n');
		
		/* Dial-up script */
		fwrite("w", $dialupsh, "#!/bin/sh\n");
		fwrite("a", $dialupsh, 'chmod +x '.$ipup.' '.$pppstatus.'\n');
		fwrite("a", $dialupsh, 'cp '.$ipup.' /etc/ppp/ip-up\n');
		fwrite("a", $dialupsh, 'cp '.$ipdown.' /etc/ppp/ip-down\n');
		fwrite("a", $dialupsh, 'cp '.$pppstatus.' /etc/ppp/ppp-status\n');
		fwrite("a", $dialupsh,
			'echo $$ > '.$dialuppid.'\n'.
			'pppd file '.$optfile.'\n');
		fwrite("a", $dialupsh, 'rm -f '.$dialuppid.'\nexit 0\n');
		
		echo 'chmod +x '.$dialupsh.'\n';
		
		if($over=="eth") { echo $dialupsh.' &\n'; }
		else if($over=="tty") { echo $dialupsh.'\n'; }
	}
	else if($act=="stoptest")
	{
		echo '/etc/scripts/killpid.sh '.$dialuppid.'\n';
		echo '/etc/scripts/killpid.sh '.$pppd_pid.'\n';
		echo 'rm -f '.$dialupsh.'\n';
		echo 'xmldbc -s '.$r_pro_path.'/status disconnected\n';
	}
}

function detect_3g($act, $id, $pro_type, $dialno, $apn, $3G, $ttyp, $3g_over, $detect_hlper)
{
	if ($ttyp!="")
	{
		$devname = query($ttyp."/devname");
		$devnum  = query($ttyp."/devnum");
		$vid     = query($ttyp."/vid");
		$pid     = query($ttyp."/pid");
	}
	
	if($act=="starttest")
	{
		echo 'xmldbc -s '.$ttyp.'/apn "'.$apn.'"\n';
		echo 'xmldbc -s '.$ttyp.'/dialno "'.$dialno.'"\n';
		echo 'usb3gkit -o /etc/ppp/chat.'.$id.'-'.$3G.' -v 0x'.$vid.' -p 0x'.$pid.' -d '.$devnum.'\n';
		$3g_ifname = $devname;
		
		$optfile = pppoptions($id, $3G, $3g_ifname, $3g_over, $pro_path);
		detect_pppoe($act, $id, $3G, $3g_over, $optfile, $detect_hlper);
	}
	else if($act=="stoptest")
	{
		/*
		$reslov = fread("", "/etc/ppp/resolv.conf.".$WAN3);
		$nameserver = cut($reslov, 0, "\n");
		$dns = cut($nameserver, 1, " ");
		echo "ip route del ".$dns." dev ppp0\n";
		*/
	}
}

function detect_wisp($act, $id, $ifname, $hlper)
{
	$detect_type = "wisp";
	
	$udhcpc_helper = "/var/run/".$id."-test-udhcpc.sh";
	$udhcpc_pid = "/var/run/".$id."-test-udhcpc.pid";
	
	if($act=="starttest")
	{
		/* Generate the callback script for udhcpc. */
		fwrite(w, $udhcpc_helper,
		'#!/bin/sh\n'.
		'echo [$0]: act=$1 ifname=$interface ip=$ip mask=$subnet gw=$router dns=$dns... > /dev/console\n'.
		'phpsh '.$hlper.
		' TYPE='.$detect_type.
		' ACTION=$1'.
		' INTERFACE=$interface'.
		' IP=$ip'.
		' SUBNET=$subnet'.
		' "ROUTER=$router"'.
		' "DNS=$dns"'.
		' "PROUID='.$id.'"'.
		' "PID='.$udhcpc_pid.'"\n'.
		'exit 0\n'
		);
		
		echo "chmod +x ".$udhcpc_helper."\n";
		echo "udhcpc -i ".$ifname." -H dir518L -p ".$udhcpc_pid." -s ".$udhcpc_helper."\n";
	}
	else if($act=="stoptest")
	{
		echo "/etc/scripts/killpid.sh ".$udhcpc_pid."\n";
	}
}

function phytype($protype)
{
	if($protype=="STATIC" || $protype=="DHCP" || $protype=="PPPoE") { return "eth"; }
	else if($protype=="USB3G") { return "3g"; }
	else if($protype=="WISP") { return "wisp"; }
	
	TRACE_error("unkonw type:[".$protype."]\n");
}

function getlevel($protype)
{
	if($protype=="STATIC") { return "1"; }
	else if($protype=="DHCP") { return "2"; }
	else if($protype=="PPPoE") { return "3"; }
	else if($protype=="USB3G") { return "4"; }
	else if($protype=="WISP") { return "5"; }
	
	TRACE_error("unkonw type:[".$protype."]\n");
}

function clean_result($path, $prouid)
{
	foreach($path)
	{
		$r_prouid = query("profileuid");
		if($r_prouid==$prouid)
		{
			$r_path = $path.":".$InDeX;
			break;
		}
	}
	
	if($r_path!="") { del($r_path); }
}

function get_last_uid($path, $protype)
{
	$lastuid = "";
	foreach($path)
	{
		$type = query("profiletype");
		if($type==$protype)
		{
			$lastuid = query("uid");
		}
	}
	return $lastuid;
}

function get_first_index($path, $protype)
{
	foreach($path)
	{
		$type = query("profiletype");
		if($type==$protype)
		{
			$index = $InDeX;
			break;
		}
	}
	return $index;
}

function get_entry_index($path, $id)
{
	foreach($path)
	{
		$uid = query("uid");
		if($id==$uid)
		{
			$index = $InDeX;
			break;
		}
		else { $index=0; }
	}
	return $index;
}

function set_information($path, $id, $type)
{
	clean_result($path, $id);
	$r_cnt = get("x", $path."#");
	$r_cnt = $r_cnt + 1;
	set($path.":".$r_cnt."/profileuid", $id);
	set($path.":".$r_cnt."/type", $type);
	$level = getlevel($type);
	set($path.":".$r_cnt."/level", $level);
}

function is_profile_valid($path)
{
	$type = get("",$path."/profiletype");
	if ($type == "STATIC")
	{
		if (get("",$path."/config/ipaddr") == "" || get("",$path."/config/mask") == "" ||get("",$path."/config/gateway") == "")
		{	return 0;}
		else
		{	return 1;}
	}
	else if ($type == "PPPoE")
	{
/* HuanYao Kang: This may causes the detect fail if the network topology is unusual.
		if (get("","/runtime/internetprofile/eth_env/pppoe") == "no")
		{ return 0;}
*/
		if (get("",$path."/config/username") == "" || get("",$path."/config/password") == "")
		{	return 0;}
		else
		{	return 1;}
	}
	else if ($type == "DHCP")
	{	
/* HuanYao Kang: This may causes the detect fail if the network topology is unusual.
		if (get("","/runtime/internetprofile/eth_env/dhcp") == "no")
		{ return 0;}
*/
		return 1; 
	}
	else if ($type == "USB3G")
	{	return 1; }
	else if ($type == "WISP")
	{	return 1; }
	else 
	{
		TRACE_error("[ERROR] [is_profile_valid] Unexpected type:".$type." in path:".$path);
		exit;
	}
}
function get_next_profile($type)
{
	if ($type == "")
	{
		TRACE_error("[ERROR] [get_next_profile] Unexpected type:".$type);
		exit;
	}
	$pro_p = "/internetprofile";
	$current_profile_p = "/runtime/internetprofile/current_uid/".$type;
	$current_profile = get("",$current_profile_p);
	if ($current_profile == "")
	{
		foreach ($pro_p."/entry")
		{
			$profile_type = get("","profiletype");
			if ($type == phytype($profile_type) && 
				is_profile_valid($pro_p."/entry:".$InDeX) == "1")
			{
				$current_profile = get("","uid");
				set ($current_profile_p, $current_profile);
				return $current_profile;
			}
		}
		set($current_profile_p,"");
		return "NoNextProfile";
	}
	
	else
	{
		$current_index = get_entry_index ($pro_p."/entry", $current_profile);
		foreach ($pro_p."/entry")	
		{
			$profile_type = get("","profiletype");
			if ($InDeX>$current_index && 
				$type == phytype($profile_type) && 
				is_profile_valid($pro_p."/entry:".$InDeX) == "1")
			{
				$current_profile = get("","uid");
				set ($current_profile_p, $current_profile);
				return $current_profile;
			}
		}
		set($current_profile_p,"");
		return "NoNextProfile";
	}
}

function fatal_error($msg)
{
	TRACE_error("Error:[profile_helper.php] ".$msg);
	exit;
}

function cmd($msg) 
{	
	//TRACE_error("Tracing: ".$msg);
	echo $msg." \n"; 
}

function get_inf_ip($inf)
{
	$inf_runtime_path = XNODE_getpathbytarget("/runtime","inf","uid",$inf,0);
	if ($inf_runtime_path == "") 
	{ fatal_error("inf_runtime_path emtpy"); exit; }
	
	$addrtype = get("",$inf_runtime_path."/inet/addrtype");
	if ($addrtype == "ipv4") {$ip = get("",$inf_runtime_path."/inet/ipv4/ipaddr");}
	if ($addrtype == "ppp4") {$ip = get("",$inf_runtime_path."/inet/ppp4/local");}
	return $ip;
}

cmd("echo $$ > /var/run/profile_helper.pid");
$ETH = $WAN1;
$3G = $WAN3;
$WISP = $WAN7;

/* ethernet */
$eth_p	= XNODE_getpathbytarget("", "inf", "uid", $ETH, 0);
$eth_phyinf	= query($eth_p."/phyinf");
$eth_ifname	= PHYINF_getifname($eth_phyinf);
$eth_inet	= query($eth_p."/inet");
$eth_inet_p = XNODE_getpathbytarget("/inet", "entry", "uid", $eth_inet, 0);
$eth_over = query($eth_inet_p."/ppp4/over");

/* 3g */
$3g_p	= XNODE_getpathbytarget("", "inf", "uid", $3G, 0);
$3g_phyinf	= query($3g_p."/phyinf");
$3g_inet	= query($3g_p."/inet");
$3g_inet_p = XNODE_getpathbytarget("/inet", "entry", "uid", $3g_inet, 0);
$3g_over = query($3g_inet_p."/ppp4/over");

/* wisp */
$wisp_p = XNODE_getpathbytarget("", "inf", "uid", $WISP, 0);
$wisp_phyinf = query($wisp_p."/phyinf");
$wisp_phyinf_path = XNODE_getpathbytarget("", "phyinf", "uid", $wisp_phyinf, 0);
$wisp_wifi = query($wisp_phyinf_path."/wifi");
$wisp_wifi_p = XNODE_getpathbytarget("/wifi", "entry", "uid", $wisp_wifi, 0);

$sitesurvey_5G_e = "/runtime/wifi_tmpnode/sitesurvey_5G/entry";
$sitesurvey_24G_e = "/runtime/wifi_tmpnode/sitesurvey_24G/entry";

$profile_entry = "/internetprofile/entry";
$profile_run_entry = "/runtime/internetprofile/entry";
$detect_hlper = "/etc/scripts/autoprofile/checkip.php";
$detect_result_finish = 1;
$result_best = 10;
$result_best_uid = "";

$phyinfp = XNODE_getpathbytarget("", "phyinf", "uid", $3g_phyinf, 0);
$slot	= query($phyinfp."/slot");
$ttyp	= XNODE_getpathbytarget("/runtime/tty", "entry", "slot", $slot, 0);

$3g_status_run_path = "/runtime/internetprofile/3gstatus";
$wisp_status_run_path = "/runtime/internetprofile/wispstatus";

if($ACTIVEPRO!="") /* if user active profile from web UI */
{
	$pro_path = XNODE_getpathbytarget("/internetprofile", "entry", "uid", $ACTIVEPRO, 0);
	$pro_type = query($pro_path."/profiletype");
	
	if ($ACTIVEPRO=="PRO-3GAUTO")
	{ $pro_type = "USB3G"; }
	
	set_information($profile_run_entry, $ACTIVEPRO, $pro_type);
	
	echo "phpsh /etc/scripts/activeprofile.php PROUID=".$ACTIVEPRO."\n";
}
else
{

	if($ACTION=="starttest" || $ACTION=="stoptest")
	{
		TRACE_info("===================== profile_helper.php, action=".$ACTION." type=".$TYPE." id=".$ID);
		if ($ACTION == "starttest") 
		{
			if ($ID != get("","/runtime/internetprofile/current_uid/current_helperid"))
			{
				TRACE_error("This id is not correct.");
				exit ;
			}
		}
		if($TYPE=="eth")
		{
			if ($ACTION=="starttest")
			{
				if (get("","/runtime/internetprofile/current_uid/current_type") != $TYPE)
				{ fatal_error("This type is not enabled"); }
				cmd("echo $$ > /var/run/profile_helper.pid");

				$current_profile = get_next_profile($TYPE);
				if ($current_profile != "NoNextProfile")
				{
					$pro_path = XNODE_getpathbytarget("/internetprofile","entry","uid",$current_profile,0);
					if ($pro_path == "")
					{ fatal_error("cannot get profile path"); }
					$pro_type = get("",$pro_path."/profiletype");
					
					set_information($profile_run_entry, $current_profile, $pro_type);
					
					if ($pro_type == "STATIC")
					{	// need to ping the gateway, try next profile if gateway is not response.
					
						$ip = get ("",$pro_path."/config/ipaddr");
						$mask = get ("",$pro_path."/config/mask");
						$gateway = get ("",$pro_path."/config/gateway");
						
						TRACE_info("=========================Detecting Static profile");
						
						cmd ("ifconfig ".$eth_ifname." ".$ip."/".$mask);
						cmd ("result=`ping ".$gateway."`");
						cmd ("ifconfig ".$eth_ifname." 0.0.0.0");
						
						cmd ("echo $result | grep -q alive && phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=stoptest TYPE=eth");
						cmd ("echo $result | grep -q alive && phpsh /etc/scripts/autoprofile/profile_helper.php ACTIVEPRO=".$current_profile);
						
						cmd ("echo $result | grep -q alive || phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=starttest TYPE=eth ID=".$ID);
					}
					else
					{ //DHCP or PPPOE, try to active it and check the result.
						TRACE_info("=========================Activing profile:".$current_profile);

						cmd ("phpsh /etc/scripts/autoprofile/profile_helper.php  ACTIVEPRO=".$current_profile);
						cmd ("xmldbc -t 'profile_timer:3:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=checkresult TYPE=eth ID=".$ID."'"); 
					}
				}
				else
				{
					// No other profile to try.
					TRACE_info("=========================No other profile to try.");
					cmd ("phpsh /etc/scripts/inactiveinf.php");
					
					// Go back to test again.
					cmd ("xmldbc -t 'profile_timer:30:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=starttest TYPE=eth ID=".$ID."'"); 
				}
			}
			else if ($ACTION=="stoptest")
			{
				$current_profile_p = "/runtime/internetprofile/current_uid/".$TYPE;
				set($current_profile_p, "");
				set("/runtime/internetprofile/current_uid/retry_counter",0);	// clear retry counter.
				cmd("xmldbc -k profile_timer");
				cmd("/etc/scripts/killpid.sh /var/run/profile_helper.pid");
			}
			
		}
		else if($TYPE=="3g")
		{
			if ($ACTION=="starttest")
			{
				if (get("","/runtime/internetprofile/current_uid/current_type") != $TYPE)
				{ fatal_error("This type is not enabled"); }
				
				if ($ttyp=="") {fatal_error("3G might not exised."); }
				cmd("echo $$ > /var/run/profile_helper.pid");
				
				$auto_config_path = "/runtime/device/SIM/PINsts";
				$PINsts = get("",$auto_config_path);
				
				if ($PINsts == "" || $PINsts == "CHECKING")
				{	// 3G auto config is not ready, wait for sometime.
					TRACE_info("=========================SIM is not ready, wait.(".$PINsts.")");
					cmd ("xmldbc -t 'profile_timer:3:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=starttest TYPE=".$TYPE." ID=".$ID."'"); 
					exit ;
				}
				else if ($PINsts == "ERROR")	// prevent the sim locked.
				{ 
					TRACE_error("[profile_helper][Error] SIM card PIN code error."); 
					exit ;
				}
				
				$3g_auto_tried = get("","/runtime/internetprofile/current_uid/3g_auto_tried");
				$current_profile = get_next_profile($TYPE);
				if ($current_profile != "NoNextProfile" && $3g_auto_tried != "1")
				{
					$pro_path = XNODE_getpathbytarget("/internetprofile","entry","uid",$current_profile,0);
					if ($pro_path == "")
					{ fatal_error("cannot get profile path"); }
					$pro_type = get("",$pro_path."/profiletype");
					
					set_information($profile_run_entry, $current_profile, $pro_type);
					
					TRACE_info("=========================Activing profile:".$current_profile);
					cmd ("phpsh /etc/scripts/autoprofile/profile_helper.php  ACTIVEPRO=".$current_profile);
					cmd ("while [ -f /var/run/ppp-WAN-3.status ] ; do echo 'Waiting for service down' > /dev/console ;sleep 1; done;");
					cmd ("xmldbc -t 'profile_timer:20:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=checkresult TYPE=".$TYPE." ID=".$ID."'"); 
				}
				else
				{	//  Try auto if it is not tried.
					if ($3g_auto_tried != "1" && $PINsts == "UNLOCKED")
					{
						$current_profile = "PRO-3GAUTO";
						
						set_information($profile_run_entry, $current_profile, "USB3G");
						
						TRACE_info("=========================Activing profile:".$current_profile);
						cmd ("phpsh /etc/scripts/autoprofile/profile_helper.php  ACTIVEPRO=".$current_profile);
						set ("/runtime/internetprofile/current_uid/3g_auto_tried", "1");
						cmd ("while [ -f /var/run/ppp-WAN-3.status ] ; do echo 'Waiting for service down' > /dev/console ;sleep 1; done;");
						cmd ("xmldbc -t 'profile_timer:60:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=checkresult TYPE=".$TYPE." ID=".$ID."'"); 	// auto profile might needs more time to check.
						set("/runtime/internetprofile/current_uid/".$TYPE, "");
					}
					else
					{
						TRACE_info("=========================No other profile to try.");
						set ("/runtime/internetprofile/current_uid/3g_auto_tried", 0);
						cmd ("phpsh /etc/scripts/inactiveinf.php");
						cmd ("xmldbc -t 'profile_timer:60:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=starttest TYPE=3g ID=".$ID."'"); 
						set("/runtime/internetprofile/current_uid/".$TYPE, "");
					}
				}
			}
			else if ($ACTION=="stoptest")
			{
				set ("/runtime/internetprofile/current_uid/3g_auto_tried", "0");
				$current_profile_p = "/runtime/internetprofile/current_uid/".$TYPE;
				set($current_profile_p, "");
				set("/runtime/internetprofile/current_uid/retry_counter",0);	// clear retry counter.
				set ("/runtime/internetprofile/current_uid/3g_auto_tried", 0);
				
				cmd("xmldbc -k profile_timer");
				cmd("/etc/scripts/killpid.sh /var/run/profile_helper.pid");
			}
		}
		else if($TYPE=="wisp")
		{
			if ($ACTION=="starttest")
			{
				if (get("","/runtime/internetprofile/current_uid/current_type") != $TYPE)
				{ fatal_error("This type is not enabled"); }
				
				cmd("echo $$ > /var/run/profile_helper.pid");
				$current_profile = get_next_profile($TYPE);
				if ($current_profile == "NoNextProfile")
				{	//if there is no wisp profile
					set ("/runtime/internetprofile/current_uid/wisp_testing",0);
					$current_profile = get_next_profile($TYPE);
					if ($current_profile == "NoNextProfile")
					{	fatal_error("No WISP profile existed."); }
					cmd ("event SITESURVEY");
					cmd ("sleep 60");
					TRACE_info("starting another round testing.");
				}
				
				$current_profile_path = XNODE_getpathbytarget("/internetprofile", "entry", "uid", $current_profile, "0");
				$current_profile_name = get("",$current_profile_path."/profilename");
				$suvery_5G_path = XNODE_getpathbytarget("/runtime/wifi_tmpnode/sitesurvey_5G", "entry", "ssid", $current_profile_name, "0");
				if ($suvery_5G_path == "")
				{
					$suvery_2G_path = XNODE_getpathbytarget("/runtime/wifi_tmpnode/sitesurvey_24G", "entry", "ssid", $current_profile_name, "0");
					if ($suvery_2G_path == "")
					{
						TRACE_error("[profile_helper]:[Notice]: ".$current_profile_name." is not available, Continue to next profile");
						echo "xmldbc -t 'profile_timer:1:phpsh /etc/scripts/autoprofile/profile_helper.php TYPE=wisp ACTION=starttest ID=".$ID."' \n";
						exit;
					}
					else
					{ $rssi = get("",$suvery_2G_path."/rssi"); }
				}
				else
				{ $rssi = get("",$suvery_5G_path."/rssi"); }
				if ($rssi != "" && $rssi < 30)
				{
					TRACE_error("[profile_helper]:[Notice]: ".$current_profile_name." has weak signal(".$rssi."), Continue to next profile");
					echo "xmldbc -t 'profile_timer:1:phpsh /etc/scripts/autoprofile/profile_helper.php TYPE=wisp ACTION=starttest ID=".$ID."' \n";
					exit;
				}

				
				
				
				TRACE_info("=========================Activing profile:".$current_profile);

				set ("/runtime/internetprofile/current_uid/wisp_testing",1);	// Ignore WISP_PHYDOWN when testing.
				cmd ("phpsh /etc/scripts/autoprofile/profile_helper.php ACTIVEPRO=".$current_profile);
				cmd ("xmldbc -t 'profile_timer:5:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=checkresult TYPE=".$TYPE." ID=".$ID."'"); 
			}
			else if ($ACTION=="stoptest")
			{
				$current_profile_p = "/runtime/internetprofile/current_uid/".$TYPE;
				set($current_profile_p, "");
				set("/runtime/internetprofile/current_uid/retry_counter",0);	// clear retry counter.
				
				set ("/runtime/internetprofile/current_uid/wisp_testing",0);
				cmd ("xmldbc -k profile_timer");
				cmd("/etc/scripts/killpid.sh /var/run/profile_helper.pid");
			}
		}
	}
	else if($ACTION=="checkresult")
	{
		cmd("echo $$ > /var/run/profile_helper.pid");
		
		if (get("","/runtime/internetprofile/current_uid/current_type") != $TYPE)
		{ fatal_error("This type is not enabled"); }
				

		if($TYPE=="eth")
		{
			$current_profile_p = "/runtime/internetprofile/current_uid/".$TYPE;
			$current_profile = get("",$current_profile_p);
			
			$ip = get_inf_ip($ETH);
			TRACE_info("=========================ip:".$ip);
			if ($ip == "")
			{ $result = "failed"; }
			else
			{ $result = "success"; }
			
			// handle result.
			if ($result == "failed")
			{
				TRACE_info("=========================Failed:".$current_profile);
				$recheck_counter = get("","/runtime/internetprofile/current_uid/retry_counter");
				TRACE_info("=========================recheck_counter:".$recheck_counter);
				if ($recheck_counter == "") { $recheck_counter = 0; }
				if ($recheck_counter < 10)
				{
					//wait for sometime to re-check again.
				cmd ("xmldbc -t 'profile_timer:1:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=checkresult TYPE=".$TYPE." ID=".$ID."'");
					set("/runtime/internetprofile/current_uid/retry_counter",$recheck_counter+1);
				}
				else
				{
					//This profile is failure.
					cmd ("xmldbc -t 'profile_timer:1:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=starttest TYPE=".$TYPE." ID=".$ID."'");
					set("/runtime/internetprofile/current_uid/retry_counter",0);
				}
			}
			else if ($result == "success")
			{
				TRACE_info("=========================Success:".$current_profile);
				cmd ("xmldbc -t 'profile_timer:1:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=stoptest TYPE=".$TYPE." ID=".$ID."'");
			}
		}
		else if($TYPE=="3g")
		{
			$current_profile_p = "/runtime/internetprofile/current_uid/".$TYPE;
			$current_profile = get("",$current_profile_p);
			
			$ip = get_inf_ip($3G);
			TRACE_info("=========================ip:".$ip);
			if ($ip == "")
			{ $result = "failed"; }
			else
			{ $result = "success"; }
			
			// handle result.
			if ($result == "failed")
			{
				TRACE_info("=========================Failed:".$current_profile);
				$recheck_counter = get("","/runtime/internetprofile/current_uid/retry_counter");
				TRACE_info("=========================recheck_counter:".$recheck_counter);
				if ($recheck_counter == "") { $recheck_counter = 0; }
				if ($recheck_counter < 10)
				{
					//wait for sometime to re-check again.
					cmd ("xmldbc -t 'profile_timer:1:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=checkresult TYPE=".$TYPE." ID=".$ID."'");
					set("/runtime/internetprofile/current_uid/retry_counter",$recheck_counter+1);
				}
				else
				{
					//This profile is failure.
					cmd ("xmldbc -t 'profile_timer:1:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=starttest TYPE=".$TYPE." ID=".$ID."'");
					set("/runtime/internetprofile/current_uid/retry_counter",0);
				}
			}
			else if ($result == "success")
			{
				TRACE_info("=========================Success:".$current_profile);
				set("/runtime/internetprofile/current_uid/retry_counter",0);
				cmd ("xmldbc -t 'profile_timer:1:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=stoptest TYPE=".$TYPE." ID=".$ID."'");
			}
		}
		else if($TYPE=="wisp")
		{
			$wisp_testing = get("","/runtime/internetprofile/current_uid/wisp_testing");
			if ($wisp_testing != "1")
			{ fatal_error("WISP is not testing.");}
			
			$current_profile_p = "/runtime/internetprofile/current_uid/".$TYPE;
			$current_profile = get("",$current_profile_p);

			$ip = get_inf_ip($WISP);
			TRACE_info("=========================PROFILE:".$PROFILE);
			TRACE_info("=========================ip:".$ip);
			if ($ip == "") { $result = "failed"; }
			else					 { $result = "success"; }
			
			// handle result.
			if ($result == "failed")
			{
				$recheck_counter = get("","/runtime/internetprofile/current_uid/retry_counter");
				TRACE_info("=========================Failed:".$current_profile);
				TRACE_info("=========================recheck_counter:".$recheck_counter);
				if ($recheck_counter == "") { $recheck_counter = 0; }
				if ($recheck_counter < 15)
				{
					//wait for sometime to re-check again.
					cmd ("xmldbc -t 'profile_timer:1:phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=checkresult TYPE=".$TYPE." PROFILE=".$current_profile." ID=".$ID."'");
					set("/runtime/internetprofile/current_uid/retry_counter",$recheck_counter+1);
				}
				else
				{
					//This profile is failure.
					cmd ("phpsh /etc/scripts/inactiveinf.php");
					cmd ("phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=starttest TYPE=".$TYPE." ID=".$ID);
					set("/runtime/internetprofile/current_uid/retry_counter",0);
				}
			}
			else if ($result == "success")
			{
				TRACE_info("=========================Success:".$current_profile);
//				cmd ("phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=stoptest TYPE=".$TYPE);
				set("/runtime/internetprofile/current_uid/retry_counter",0);
				set ("/runtime/internetprofile/current_uid/wisp_testing",0);
			}
		}
		else { TRACE_error("unkonw type:[".$TYPE."]\n"); }
	}
	else if ($ACTION=="linkup" || $ACTION=="linkdown")
	{
		TRACE_info("===================== profile_helper.php, action=".$ACTION." type=".$TYPE." ID=".$ID);

		if ($TYPE == "wisp")
		{
			if ($ACTION =="linkup")	//link up: Get WAN IP.
			{
//				set ("/runtime/internetprofile/current_uid/wisp_link_status","up");
					cmd("service INET.WAN-7 restart");	// HuanYao todo: This is never enter.
			}
			else	//linkdown
			{
				$wisp_testing = get("","/runtime/internetprofile/current_uid/wisp_testing");
				TRACE_info("=========================wisp_testing:".$wisp_testing);
				if ($wisp_testing == "1")
				{ fatal_error("WISP testing, ignore this message.");}
				cmd("phpsh /etc/scripts/inactiveinf.php");
//				echo "service WAN stop \n";
//				if (get("","/runtime/internetprofile/current_uid/wisp_link_status") != "trying")
					cmd ("phpsh /etc/scripts/autoprofile/profile_helper.php ACTION=starttest TYPE=".$TYPE." ID=".$ID);
//				set ("/runtime/internetprofile/current_uid/wisp_link_status","down");
			}
		}
	}
}

?>
