#!/bin/sh
udevstart
