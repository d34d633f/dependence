#!/bin/sh
MFC=`mfc mode state`
if [ "$MFC" == "off" ] ; then 
	echo "Starting wanmonitor" > /dev/console
	wanmonitor & 
else
	echo "In MFC mode." > /dev/console
fi
