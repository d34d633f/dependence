HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/webinc/feature.php";
include "/htdocs/webinc/config.php";

$result = "OK";

if($FEATURE_NOLAN==1) { $feature_lan = "false"; }
else { $feature_lan = "true"; }

if($FEATURE_HAVEBGMODE==1) { $feature_bridge = "true"; }
else { $feature_bridge = "false"; }

if($FEATURE_HAVEAPCLIENT==1){ $feature_apclient = "true"; }
else { $feature_apclient = "false"; }

if($FEATURE_HAVEREPEATER==1){ $feature_repeater = "true"; }
else { $feature_repeater = "false"; }

if($FEATURE_GUESTZONE==1){ $feature_guestzone = "true"; }
else { $feature_guestzone = "false"; }

if($FEATURE_DUAL_BAND==1){ $feature_dualband = "true"; }
else { $feature_dualband = "false"; }

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
	<soap:Body>
		<GetDeviceFeatureAlphaResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetDeviceFeatureAlphaResult><?=$result?></GetDeviceFeatureAlphaResult>
			<FeatureLAN><?=$feature_lan?></FeatureLAN>
			<FeatureBridge><?=$feature_bridge?></FeatureBridge>
			<FeatureAPClient><?=$feature_apclient?></FeatureAPClient>
			<FeatureRepeater><?=$feature_repeater?></FeatureRepeater>
			<FeatureGuestZone><?=$feature_guestzone?></FeatureGuestZone>
			<FeatureDualBand><?=$feature_dualband?></FeatureDualBand>
		</GetDeviceFeatureAlphaResponse>
	</soap:Body>
</soap:Envelope>