HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

include "etc/templates/hnap/GetIPv6Settings.php";


?>
<soap:Envelope 
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<GetIPv6StatusResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetIPv6StatusResult><?=$result?></GetIPv6StatusResult>
			<IPv6_ConnectionType><?=$ConnectionType?></IPv6_ConnectionType>
			<IPv6_Network_Status><?=$wan_status?></IPv6_Network_Status>
			<IPv6_ConnectionTime><?=$wan_delta_uptime?></IPv6_ConnectionTime>
			<IPv6_WanLinkLocalAddress><?=$wanlladdr?></IPv6_WanLinkLocalAddress>
			<IPv6_Address><?=$str_wanipaddr?></IPv6_Address>
			<IPv6_DefaultGateway><?=$DefaultGateway?></IPv6_DefaultGateway>
			<IPv6_LanAddress><?=$LanAddress?></IPv6_LanAddress>
			<IPv6_LanLinkLocalAddress><?=$LanLinkLocalAddress?></IPv6_LanLinkLocalAddress>
			<IPv6_PrimaryDNS><?=$str_wanDNSserver?></IPv6_PrimaryDNS>
			<IPv6_SecondaryDNS><?=$str_wanDNSserver2?></IPv6_SecondaryDNS>
			<IPv6_DhcpPd><?=$enpd?></IPv6_DhcpPd>
			<IPv6_DhcpPd_IP><?=$lan_pl?></IPv6_DhcpPd_IP>
			<IPv6_LanIPv6AddressPrefix><?=$pd_prefix?></IPv6_LanIPv6AddressPrefix>
		</GetIPv6StatusResponse>
	</soap:Body>
</soap:Envelope>
