HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/webinc/config.php";

$path_dev_log = "/device/log";
$reslut = "OK";

if (get("x", $path_dev_log."/email/enable") == "1") { $enable = true; }
else { $enable = false; }

$email_from = get("x", $path_dev_log."/email/from");
$email_to = get("x", $path_dev_log."/email/to");
$email_subj = get("x", $path_dev_log."/email/subject");

$smt_addr = get("x", $path_dev_log."/email/smtp/server");
if (get("x", $path_dev_log."/email/smtp/port") == "") { $smt_port = "25"; }
else { $smt_port = get("x", $path_dev_log."/email/smtp/port"); }

if (get("x", $path_dev_log."/email/authenable") == "1") { $auth = true; }
else { $auth = false; }
$name = get("x", $path_dev_log."/email/smtp/user");
$passwd = get("x", $path_dev_log."/email/smtp/password");

if (get("x", $path_dev_log."/email/logfull") == "1") { $log_full = true; }
else { $log_full = false; }
if (get("x", $path_dev_log."/email/logsch") == "1") { $log_sch = true; }
else { $log_sch = false; }
$sch_name = get("x", $path_dev_log."/email/schedule");

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
	<soap:Body>
		<GetSysEmailSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetSysEmailSettingsResult><?=$reslut?></GetSysEmailSettingsResult>
			<SysEmail><?=$enable?></SysEmail>
			<EmailFrom><?=$email_from?></EmailFrom>
			<EmailTo><?=$email_to?></EmailTo>
			<EmailSubject><?=$email_subj?></EmailSubject>
			<SMTPServerAddress><?=$smt_addr?></SMTPServerAddress>
			<SMTPServerPort><?=$smt_port?></SMTPServerPort>
			<Authentication><?=$auth?></Authentication>
			<AccountName><?=$name?></AccountName>
			<AccountPassword><?=$passwd?></AccountPassword>
			<OnLogFull><?=$log_full?></OnLogFull>
			<OnSchedule><?=$log_sch?></OnSchedule>
			<ScheduleName><?=$sch_name?></ScheduleName>
		</GetSysEmailSettingsResponse>
	</soap:Body>
</soap:Envelope>