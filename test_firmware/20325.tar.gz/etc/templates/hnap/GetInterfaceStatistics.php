HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/trace.php";

$Interface = get("h","/runtime/hnap/GetInterfaceStatistics/Interface");

$result = "OK";

$path_tx = "/stats/tx/bytes";
$path_rx = "/stats/rx/bytes";
$path_tx_pkts = "/stats/tx/packets";
$path_rx_pkts = "/stats/rx/packets";
$path_tx_drop = "/stats/tx/drop";
$path_rx_drop = "/stats/rx/drop";
$path_tx_error = "/stats/tx/error";
$path_rx_error = "/stats/rx/error";

$tx = "N/A";
$rx = "N/A";
$tx_pkts = "N/A";
$rx_pkts = "N/A";
$tx_drop = "N/A";
$error = "N/A";

/* Get active profile */
$active_profile_path = XNODE_getpathbytarget("/runtime/internetprofile", "entry", "active", "1", 0);
$active_profile_uid = get("",$active_profile_path."/profileuid");
$active_profile_type =  get("",$active_profile_path."/type");

$path_prefix = "/runtime/hnap/InternetStatistics_tmp";

function get_runtime_eth_path($uid)
{
	$p = XNODE_getpathbytarget("", "inf", "uid", $uid, 0);
	if($p == "") return $p;

	return XNODE_getpathbytarget("/runtime", "phyinf", "uid", query($p."/phyinf"));
}

function set_clear($Interface)
{
	include "/htdocs/webinc/config.php";

	$path_tx = "/stats/tx/bytes";
	$path_rx = "/stats/rx/bytes";
	$path_tx_pkts = "/stats/tx/packets";
	$path_rx_pkts = "/stats/rx/packets";
	$path_tx_drop = "/stats/tx/drop";
	$path_rx_drop = "/stats/rx/drop";
	$path_tx_error = "/stats/tx/error";
	$path_rx_error = "/stats/rx/error";

	if ($Interface == "WAN-1" || $Interface == "WAN-3" || $Interface == "WAN-7-24" || $Interface == "WAN-7-5")
	{
		if ($Interface == "WAN-1")
		{
			$path_wan = get_runtime_eth_path($WAN1);
		}
		else if ($Interface == "WAN-3")
		{
			$uid = "PPP.WAN-3";
			$path_wan = XNODE_getpathbytarget("/runtime", "phyinf", "uid", $uid);
		}
		else if ($Interface == "WAN-7-24")
		{
			$path_wan = XNODE_getpathbytarget("/runtime", "phyinf", "uid", $WLAN1_REP);
		}
		else if ($Interface == "WAN-7-5")
		{
			$path_wan = XNODE_getpathbytarget("/runtime", "phyinf", "uid", $WLAN2_REP);
		}
		$tx = query($path_wan.$path_tx);											$rx = query($path_wan.$path_rx);
		$tx_pkts = query($path_wan.$path_tx_pkts);						$rx_pkts = query($path_wan.$path_rx_pkts);
		$tx_drop = query($path_wan.$path_tx_drop);						$rx_drop = query($path_wan.$path_rx_drop);
		$tx_error = query($path_wan.$path_tx_error);					$rx_error = query($path_wan.$path_rx_error);
		$error = $tx_error+$rx_error;
	}
	else if ($Interface == "LAN")
	{
		$path_lan1 = get_runtime_eth_path($LAN1);
		
		$tx = query($path_lan1.$path_tx);											$rx = query($path_lan1.$path_rx);
		$tx_pkts = query($path_lan1.$path_tx_pkts);						$rx_pkts = query($path_lan1.$path_rx_pkts);
		$tx_drop = query($path_lan1.$path_tx_drop);						$rx_drop = query($path_lan1.$path_rx_drop);
		$tx_error = query($path_lan1.$path_tx_error);					$rx_error = query($path_lan1.$path_rx_error);
		$error = $tx_error+$rx_error;
	}
	else if ($Interface == "WLAN2.4G" || $Interface == "WLAN5G")
	{
		foreach ("/phyinf")
		{
			if ($Interface == "WLAN2.4G") 
			{
				$band_uid = $WLAN1;
				$freq = "2.4";
			}
			else
			{ 
				$band_uid = $WLAN2;
				$freq = "5";
			}
			
			if (get ("","media/freq") != $freq ) { continue; }
			
			$uid = query("uid");
			if($uid==$band_uid)
			{
				$path_wifi = XNODE_getpathbytarget("/runtime", "phyinf", "uid", $band_uid);
				
				if ($path_wifi == "") continue;
				if (isdigit($tx) == 0)
				{
					$tx = 0;								$rx = 0;
					$tx_pkts = 0;						$rx_pkts = 0;
					$tx_drop = 0;						$rx_drop = 0;
					$error = 0;
				}
				$tx += query($path_wifi.$path_tx);											$rx += query($path_wifi.$path_rx);
				$tx_pkts += query($path_wifi.$path_tx_pkts);						$rx_pkts += query($path_wifi.$path_rx_pkts);
				$tx_drop += query($path_wifi.$path_tx_drop);						$rx_drop += query($path_wifi.$path_rx_drop);
				$tx_error = query($path_wifi.$path_tx_error);					  $rx_error = query($path_wifi.$path_rx_error);
				$error += $tx_error+$rx_error;
			}
		}
	}
	$path_prefix = "/runtime/hnap/InternetStatistics_tmp/".$Interface;
	set ($path_prefix."/tx", $tx);                                
	set ($path_prefix."/rx", $rx);
	
	set ($path_prefix."/tx_pkts", $tx_pkts);
	set ($path_prefix."/rx_pkts", $rx_pkts);
	
	set ($path_prefix."/error", $error);

}

function return_zero_if_empty($path)
{
	$tmp = get("",$path);
	if ($tmp == "")
	{ return 0; }			
	return $tmp;
}
$path_prefix = "/runtime/hnap/InternetStatistics_tmp";
if ($Interface == "WAN")
{
	if ($active_profile_type == "DHCP" || $active_profile_type == "STATIC" || $active_profile_type == "PPPoE")
	{
		$path_wan = get_runtime_eth_path($WAN1);
		$path_tmp = $path_prefix."/WAN-1";
	}
	else if ($active_profile_type == "USB3G")
	{
		$uid = "PPP.WAN-3";
		$path_wan = XNODE_getpathbytarget("/runtime", "phyinf", "uid", $uid);
		$path_tmp = $path_prefix."/WAN-3";
	}
	else if ($active_profile_type == "WISP")
	{
		$band = query("/runtime/internetprofile/wispstatus/band");
		$path_wan = XNODE_getpathbytarget("/runtime", "phyinf", "uid", $band);
		if ($band == $WLAN1_REP)
		{ $path_tmp = $path_prefix."/WAN-7-24"; }
		else if ($band == $WLAN2_REP)
		{ $path_tmp = $path_prefix."/WAN-7-5"; }
	}
	
	$tx = query($path_wan.$path_tx) - return_zero_if_empty($path_tmp."/tx");
	$rx = query($path_wan.$path_rx) - return_zero_if_empty($path_tmp."/rx");
	
	$tx_pkts = query($path_wan.$path_tx_pkts) - return_zero_if_empty($path_tmp."/tx_pkts");						
	$rx_pkts = query($path_wan.$path_rx_pkts) - return_zero_if_empty($path_tmp."/rx_pkts");
	
	$tx_drop = query($path_wan.$path_tx_drop) - return_zero_if_empty($path_tmp."/tx_drop");						
	$rx_drop = query($path_wan.$path_rx_drop) - return_zero_if_empty($path_tmp."/rx_drop");
	
	$tx_error = query($path_wan.$path_tx_error);
	$rx_error = query($path_wan.$path_rx_error);
	$error = $tx_error+$rx_error - return_zero_if_empty($path_tmp."/error");
}
else if ($Interface == "LAN")
{
	$path_lan1 = get_runtime_eth_path($LAN1);
	$path_tmp = $path_prefix."/LAN";
	
	$tx = query($path_lan1.$path_tx) - return_zero_if_empty($path_tmp."/tx");											
	$rx = query($path_lan1.$path_rx) - return_zero_if_empty($path_tmp."/rx");
	
	$tx_pkts = query($path_lan1.$path_tx_pkts) - return_zero_if_empty($path_tmp."/tx_pkts");						
	$rx_pkts = query($path_lan1.$path_rx_pkts) - return_zero_if_empty($path_tmp."/rx_pkts");
	
	$tx_drop = query($path_lan1.$path_tx_drop) - return_zero_if_empty($path_tmp."/tx_drop");						
	$rx_drop = query($path_lan1.$path_rx_drop) - return_zero_if_empty($path_tmp."/rx_drop");
	
	$tx_error = query($path_lan1.$path_tx_error);					
	$rx_error = query($path_lan1.$path_rx_error);
	$error = $tx_error+$rx_error - return_zero_if_empty($path_tmp."/error");
}
else if ($Interface == "WLAN2.4G" || $Interface == "WLAN5G")
{
	foreach ("/phyinf")
	{
		if ($Interface == "WLAN2.4G") 
		{
			$band_uid = $WLAN1;
			$freq = "2.4";
		}
		else
		{ 
			$band_uid = $WLAN2;
			$freq = "5";
		}
		
		if (get ("","media/freq") != $freq ) { continue; }
		
		$uid = query("uid");
		if($uid==$band_uid)
		{
			$path_wifi = XNODE_getpathbytarget("/runtime", "phyinf", "uid", $band_uid);
			
			if ($path_wifi == "") continue;
			if (isdigit($tx) == 0)
			{
				$tx = 0;								$rx = 0;
				$tx_pkts = 0;						$rx_pkts = 0;
				$tx_drop = 0;						$rx_drop = 0;
				$error = 0;
			}
			$tx += query($path_wifi.$path_tx);											
			$rx += query($path_wifi.$path_rx);
			
			$tx_pkts += query($path_wifi.$path_tx_pkts);						
			$rx_pkts += query($path_wifi.$path_rx_pkts);
			
			$tx_drop += query($path_wifi.$path_tx_drop);						
			$rx_drop += query($path_wifi.$path_rx_drop);
			
			$tx_error = query($path_wifi.$path_tx_error);					  
			$rx_error = query($path_wifi.$path_rx_error);
			$error += $tx_error+$rx_error;
		}
	}
	
	if ($Interface == "WLAN2.4G" )
	{
		$path_tmp = $path_prefix."/WLAN2.4G";
	}
	else if ($Interface == "WLAN5G" )
	{
		$path_tmp = $path_prefix."/WLAN5G";
	}
	
	$tx -= return_zero_if_empty($path_tmp."/tx");
	$rx -= return_zero_if_empty($path_tmp."/rx");
	
	$tx_pkts -= return_zero_if_empty($path_tmp."/tx_pkts");
	$rx_pkts -= return_zero_if_empty($path_tmp."/rx_pkts");
	$tx_drop -= return_zero_if_empty($path_tmp."/tx_drop");
	$rx_drop -= return_zero_if_empty($path_tmp."/rx_drop");
	$error -= return_zero_if_empty($path_tmp."/error");
}
else if ($Interface == "ClearAll")
{
	set_clear("WAN-1");
	set_clear("WAN-3");
	set_clear("WAN-7-24");
	set_clear("WAN-7-5");
	
	set_clear("LAN");
	set_clear("WLAN2.4G");
	set_clear("WLAN5G");
}

/* Internet session */
function getSessionNumber($ip)
{
	if ($ip == "")
	{ return 0; }
	
	$cmd = "grep ". $ip ." /proc/net/nf_conntrack | grep -v \"[UNREPLIED]\" | wc -l";
	setattr("/runtime/device/conntrace_number", "get", $cmd);
	$session = get("htm", "/runtime/device/conntrace_number");
	del("/runtime/device/conntrace_number");
	return $session;
}

if ($active_profile_type == "DHCP" || $active_profile_type == "STATIC" || $active_profile_type == "PPPoE")
{
	$wan_runtime_path = XNODE_getpathbytarget("/runtime", "inf", "uid", $WAN1, 0);
	$wan_type = get ("", $wan_runtime_path."/inet/addrtype");

	if ($wan_type == "ipv4")
	{ $wan_ip = get("", $wan_runtime_path."/inet/ipv4/ipaddr"); }
	else if ($wan_type == "ppp4")
	{ $wan_ip = get("", $wan_runtime_path."/inet/ppp4/local"); }
}
else if ($active_profile_type == "USB3G")
{
	$wan_runtime_path = XNODE_getpathbytarget("/runtime", "inf", "uid", $WAN3, 0);
	$wan_ip = get("", $wan_runtime_path."/inet/ppp4/local");
}
else if ($active_profile_type == "WISP")
{
	$wan_runtime_path = XNODE_getpathbytarget("/runtime", "inf", "uid", $WAN7, 0);
	$wan_ip = get("", $wan_runtime_path."/inet/ipv4/ipaddr");
}
$session = getSessionNumber($wan_ip);
/* Internet session end*/
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
<soap:Body>
	<GetInterfaceStatisticsResponse xmlns="http://purenetworks.com/HNAP1/">
		<GetInterfaceStatisticsResult><?=$result?></GetInterfaceStatisticsResult>
			<Interface><?=$Interface?></Interface>
			<InterfaceStatistics>
				<StatisticInfo>
					<Sent><?=$tx?></Sent>
					<Received><?=$rx?></Received>
					<TXPackets><?=$tx_pkts?></TXPackets>
					<RXPackets><?=$rx_pkts?></RXPackets>
					<TXDropped><?=$tx_drop?></TXDropped>
					<RXDropped><?=$rx_drop?></RXDropped>
					<Session><?=$session?></Session>
					<Errors><?=$error?></Errors>
				</StatisticInfo>
			</InterfaceStatistics>
	</GetInterfaceStatisticsResponse>
</soap:Body>
</soap:Envelope>