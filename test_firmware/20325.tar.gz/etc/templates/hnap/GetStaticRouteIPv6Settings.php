HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

include "/htdocs/webinc/config.php";
include "/htdocs/phplib/trace.php";

$result = "OK";

?>
<soap:Envelope 
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
	<soap:Body>
		<GetStaticRouteIPv6SettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetStaticRouteIPv6SettingsResult><?=$result?></GetStaticRouteIPv6SettingsResult>
			<StaticRouteIPv6List> 
			<?				
				//+++ Jerry Kao, Get parameter from /route6 directly.
				$Route_entry  = "/route6/static/entry";
				
				foreach($Route_entry)
				{															
					if (query("enable") == "1") { $Status = true; }
					else                        { $Status = false; }
					
					if (query("metric") != "")  { $Metric = query("metric"); }
					else                        { $Metric = "1"; }
					
					if (query("inf") == "PD")	{ $Interface = "LAN(DHCP-PD)"; }
					else
					{ 
						$Interface = substr(get("x", "inf"), 0, 3); 
					}
					
					$Name      = query("description");
					$IPAddress = query("network");
					$PrefixLen = query("prefix"); 
					$Gateway   = query("via");															
					
					echo "			<SRIPv6Info>\n";
					echo "				<Status>".$Status."</Status>\n";
					echo "				<Name>".$Name."</Name>\n";
					echo "				<DestNetwork>".$IPAddress."</DestNetwork>\n";
					echo "				<PrefixLen>".$PrefixLen."</PrefixLen>\n";
					echo "				<Gateway>".$Gateway."</Gateway>\n";
					echo "				<Metric>".$Metric."</Metric>\n";
					echo "				<Interface>".$Interface."</Interface>\n";
					echo "			</SRIPv6Info>\n";										
				}       				
			?>        				
			</StaticRouteIPv6List>
		</GetStaticRouteIPv6SettingsResponse>
	</soap:Body>
</soap:Envelope>