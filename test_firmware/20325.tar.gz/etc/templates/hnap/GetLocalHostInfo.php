HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/inet.php";
include "/htdocs/phplib/trace.php";

$list_entry = "/runtime/mydlink/userlist/entry";

$result = "OK";

$ip_addr = $_SERVER["REMOTE_ADDR"];
$mac_addr = INET_ARP($ip_addr);

TRACE_debug("$_SERVER=".$_SERVER["REMOTE_ADDR"]);
TRACE_debug("ip_addr=".$ip_addr);
TRACE_debug("mac_addr=".$mac_addr);

foreach($list_entry)
{
	$list_addr = get("", "ipv4addr");
	if ($ip_addr == $list_addr)
	{
		$hostname = get("", "hostname");
	}
	else { $hostname = ""; }
}

?>

<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
<soap:Body>
<GetLocalHostInfoResponse xmlns="http://purenetworks.com/HNAP1/">
	<GetLocalHostInfoResult><?=$result?></GetLocalHostInfoResult>
		<Hostname><?=$hostname?></Hostname>
		<IPAddress><?=$ip_addr?></IPAddress>
		<MACAddress><?=$mac_addr?></MACAddress>
	</GetLocalHostInfoResponse>
</soap:Body>
</soap:Envelope>
