HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "<"."?";?>xml version="1.0" encoding="utf-8"<? echo "?".">";
include "/htdocs/phplib/xnode.php"; 
include "/htdocs/webinc/config.php";
include "/htdocs/webinc/feature.php";
include "/htdocs/phplib/wifi.php";

$wifiverify = get("","/runtime/devdata/wifiverify");
if ($wifiverify==1) {$FEATURE_NOACMODE=1;}

$path_phyinf_wlan1 = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN1, 0);
$path_phyinf_wlan2 = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN2, 0);
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetWLanRadiosResponse xmlns="http://purenetworks.com/HNAP1/">
		<GetWLanRadiosResult>OK</GetWLanRadiosResult>
		<RadioInfos>
		<?if($path_phyinf_wlan1==""){echo "<!--";}?>
			<RadioInfo>
			<RadioID>2.4GHZ</RadioID>
			<Frequency>2</Frequency>
			<SupportedModes>
			<?if ($wifiverify==1)
				{
					echo "<string>802.11b</string>\n";
					echo "<string>802.11g</string>\n";
					echo "<string>802.11n</string>\n";
					echo "<string>802.11bg</string>\n";
					echo "<string>802.11gn</string>\n";
					echo "<string>802.11bgn</string>\n";
				}
				else
				{
					echo "<string>802.11n</string>\n";
					echo "<string>802.11gn</string>\n";
					echo "<string>802.11bgn</string>\n";
				}
			?>
			</SupportedModes>
			<Channels><?
			echo "\n";
			$clist = WIFI_getchannellist("g");
			$count = cut_count($clist, ",");
			$i = 0;
			while($i < $count)
			{
				$channel = cut($clist, $i, ',');
				echo "\t\t\t\t<int>".$channel."</int>";
				$i++;
				if($i < $count) echo "\n";
			}?>
			</Channels>
			<WideChannels>
			<?
			$bandwidth = query($path_phyinf_wlan1."/media/dot11n/bandwidth");     			
			if ($bandWidth != "20")
			{
				$startChannel = 3;
				while( $startChannel <= 9 )
				{
					echo "<WideChannel>\n";
					echo "	<Channel>".$startChannel."</Channel>\n";
					echo "	<SecondaryChannels>\n";
					$secondaryChnl = $startChannel - 2;
					echo "		<int>".$secondaryChnl."</int>\n";	
					$secondaryChnl = $startChannel + 2;
					echo "		<int>".$secondaryChnl."</int>\n";
					echo "	</SecondaryChannels>\n";
					echo "</WideChannel>\n";	
					$startChannel++;	
				}
			}
			?>
			</WideChannels>
			<SupportedSecurity>
			<?
				if ($wifiverify==1)
				{
					echo "<SecurityInfo>\n";
					echo "	<SecurityType>WPA2-TKIP+AES</SecurityType>\n";
					echo "	<Encryptions>\n";
					echo "		<string>TKIP</string>\n";
					echo "		<string>AES</string>\n";
					echo "		<string>TKIPORAES</string>\n";
					echo "	</Encryptions>\n";
					echo "</SecurityInfo>\n";
					echo "<SecurityInfo>\n";
					echo "	<SecurityType>WPA+WPA2-TKIP+AES</SecurityType>\n";
					echo "	<Encryptions>\n";
					echo "		<string>TKIP</string>\n";
					echo "		<string>AES</string>\n";
					echo "		<string>TKIPORAES</string>\n";
					echo "	</Encryptions>\n";
					echo "</SecurityInfo>\n";
				}
				else
				{
					echo "<SecurityInfo>\n";
					echo "	<SecurityType>WEP</SecurityType>\n";
					echo "	<Encryptions>\n";
					echo "		<string>WEP-64</string>\n";
					echo "		<string>WEP-128</string>\n";
					echo "	</Encryptions>\n";
					echo "</SecurityInfo>\n";
					echo "<SecurityInfo>\n";
					echo "	<SecurityType>WPA-Personal</SecurityType>\n";
					echo "	<Encryptions>\n";
					echo "		<string>TKIP</string>\n";
					echo "		<string>AES</string>\n";
					echo "		<string>TKIPORAES</string>\n";
					echo "	</Encryptions>\n";
					echo "</SecurityInfo>\n";
				}
			?>
			</SupportedSecurity>
			</RadioInfo>
			<?if($path_phyinf_wlan1==""){echo "-->";}?>
			<?if($path_phyinf_wlan2==""){echo "<!--";}?>
			<RadioInfo>
			<RadioID>5GHZ</RadioID>
			<Frequency>5</Frequency>
			<SupportedModes>
				<string>802.11a</string>
				<string>802.11n</string>
				<string>802.11an</string><?
				if($FEATURE_NOACMODE!=1)
				{
					echo "\n";
					echo "\t\t\t\t<string>802.11ac</string>\n";
					echo "\t\t\t\t<string>802.11acn</string>\n";
					echo "\t\t\t\t<string>802.11acna</string>";
				}?>
			</SupportedModes>
			<Channels><?
			echo "\n";
			$clist = WIFI_getchannellist("a");
			$count = cut_count($clist, ",");
			$i = 0;
			while($i < $count)
			{
				$channel = cut($clist, $i, ',');
				echo "\t\t\t\t<int>".$channel."</int>";
				$i++;
				if($i < $count) echo "\n";
			}?>
			</Channels>
			<WideChannels>
			<?
			$bandwidth = query($path_phyinf_wlan2."/media/dot11n/bandwidth");     			
			if ($bandWidth != "20")
			{
				$startChannel = 44;
				while( $startChannel <= 56 )
				{
					echo "<WideChannel>\n";
					echo "	<Channel>".$startChannel."</Channel>\n";
					echo "	<SecondaryChannels>\n";
					$secondaryChnl = $startChannel - 8;
					echo "		<int>".$secondaryChnl."</int>\n";	
					$secondaryChnl = $startChannel + 8;
					echo "		<int>".$secondaryChnl."</int>\n";
					echo "	</SecondaryChannels>\n";
					echo "</WideChannel>\n";	
					$startChannel=$startChannel+4;	
				}
				echo "<WideChannel>\n";
		    	echo "	<Channel>157</Channel>\n";
				echo "	<SecondaryChannels>\n";
				echo "		<int>149</int>\n";	
				echo "		<int>165</int>\n";
				echo "	</SecondaryChannels>\n";
				echo "</WideChannel>\n";
			}
			?>
			</WideChannels>
			<SupportedSecurity>
			<?
				if ($wifiverify==1)
				{
					echo "<SecurityInfo>\n";
					echo "	<SecurityType>WPA2-TKIP+AES</SecurityType>\n";
					echo "	<Encryptions>\n";
					echo "		<string>TKIP</string>\n";
					echo "		<string>AES</string>\n";
					echo "		<string>TKIPORAES</string>\n";
					echo "	</Encryptions>\n";
					echo "</SecurityInfo>\n";
					echo "<SecurityInfo>\n";
					echo "	<SecurityType>WPA+WPA2-TKIP+AES</SecurityType>\n";
					echo "	<Encryptions>\n";
					echo "		<string>TKIP</string>\n";
					echo "		<string>AES</string>\n";
					echo "		<string>TKIPORAES</string>\n";
					echo "	</Encryptions>\n";
					echo "</SecurityInfo>\n";
				}
				else
				{
					echo "<SecurityInfo>\n";
					echo "	<SecurityType>WEP</SecurityType>\n";
					echo "	<Encryptions>\n";
					echo "		<string>WEP-64</string>\n";
					echo "		<string>WEP-128</string>\n";
					echo "	</Encryptions>\n";
					echo "</SecurityInfo>\n";
					echo "<SecurityInfo>\n";
					echo "	<SecurityType>WPA-Personal</SecurityType>\n";
					echo "	<Encryptions>\n";
					echo "		<string>TKIP</string>\n";
					echo "		<string>AES</string>\n";
					echo "		<string>TKIPORAES</string>\n";
					echo "	</Encryptions>\n";
					echo "</SecurityInfo>\n";
				}
			?>
			</SupportedSecurity>
			</RadioInfo>
			<?if($path_phyinf_wlan2==""){echo "-->";}?>
		</RadioInfos>
    </GetWLanRadiosResponse>
  </soap:Body>
</soap:Envelope>
