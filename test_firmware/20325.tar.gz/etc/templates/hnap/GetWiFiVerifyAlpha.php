HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/trace.php"; 

$wifiverify = get("","/runtime/devdata/wifiverify");
$encr_check_wlan1 = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN1, 0);
$encr_check_wlan2 = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN2, 0);
$encr_wifi_wlan1 = XNODE_getpathbytarget("/wifi", "entry", "uid", query($encr_check_wlan1."/wifi"), 0);
$encr_wifi_wlan2 = XNODE_getpathbytarget("/wifi", "entry", "uid", query($encr_check_wlan2."/wifi"), 0);
//WPS Enable
if(query($encr_wifi_wlan1."/wps/enable")==1)	{$enable="Enable";}
else	{$enable="Disable";}

//WPS Configured
if(query($encr_wifi_wlan1."/wps/configured")==1 || query($encr_wifi_wlan2."/wps/configured")==1)	{$configured="Configured";}
else	{$configured="Unconfigured";}

//Get Device PIN
$pin = query($encr_wifi_wlan1."/wps/pin");
if ($pin == "")
{
	$pin = query("/runtime/devdata/pin");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
	<soap:Body>
		<GetWiFiVerifyAlphaResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetWPSSettingResult><?=$result?></GetWPSSettingResult>
			<Wifiverify><?=$wifiverify?></Wifiverify>
			<WPS>
				<Enable><?=$enable?></Enable>
				<Configured><?=$configured?></Configured>
				<PIN><?=$pin?></PIN>
			</WPS>
		</GetWiFiVerifyAlphaResponse>
	</soap:Body>
</soap:Envelope>
