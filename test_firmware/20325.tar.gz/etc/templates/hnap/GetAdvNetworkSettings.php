HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
$path_inf_lan1 = XNODE_getpathbytarget("", "inf", "uid", $LAN1, 0);
$path_inf_wan1 = XNODE_getpathbytarget("", "inf", "uid", $WAN1, 0);
$wan1_phyinf = get("x", $path_inf_wan1."/phyinf");
$path_phyinf_wan1 = XNODE_getpathbytarget("", "phyinf", "uid", $wan1_phyinf, 0);

if(get("x", $path_inf_lan1."/upnp/count") == "1")	$UPNP = true;
else	$UPNP = false;

if(get("x", "/device/multicast/igmpproxy")=="1")	$MulticastIPv4 = true;
else	$MulticastIPv4 = false;
if(get("x", "/device/multicast/mldproxy")=="1")	$MulticastIPv6 = true;
else	$MulticastIPv6 = false;

$speed = get("x", $path_phyinf_wan1."/media/linktype");
if($speed == "AUTO")		$WANPortSpeed = "Auto";
else if($speed == "10F")	$WANPortSpeed = "10Mbps";
else if($speed == "100F")	$WANPortSpeed = "100Mbps";
else if($speed == "1000F")	$WANPortSpeed = "1000Mbps";

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<GetAdvNetworkSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetAdvNetworkSettingsResult>OK</GetAdvNetworkSettingsResult>
			<UPNP><?=$UPNP?></UPNP>
			<MulticastIPv4><?=$MulticastIPv4?></MulticastIPv4> 
			<MulticastIPv6><?=$MulticastIPv6?></MulticastIPv6> 
			<WANPortSpeed><?=$WANPortSpeed?></WANPortSpeed>
		</GetAdvNetworkSettingsResponse>
	</soap:Body>
</soap:Envelope>
