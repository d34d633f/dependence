HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/inet.php";

$result = "OK";
$dmz_path = "/nat/entry/dmz";
if(get("", $dmz_path."/enable")=="1")
{
	$enable = "true";
	$ipaddr = ipv4ip(get("", INET_getpathbyinf($LAN1)."/ipv4/ipaddr"), get("", INET_getpathbyinf($LAN1)."/ipv4/mask"), get("", $dmz_path."/hostid"));
}
else
{
	$enable = "false";
	$ipaddr = "";
}
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
	<soap:Body>
		<GetDMZSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetDMZSettingsResult><?=$result?></GetDMZSettingsResult>
			<Enabled><?=$enable?></Enabled>
			<IPAddress><?=$ipaddr?></IPAddress>
		</GetDMZSettingsResponse>
	</soap:Body>
</soap:Envelope>