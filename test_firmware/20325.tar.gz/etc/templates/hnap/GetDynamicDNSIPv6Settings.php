HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";	
			
$result = "OK";
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<GetDynamicDNSIPv6SettingsResponse xmlns="http://purenetworks.com/HNAP1/"> 
			<GetDynamicDNSIPv6SettingsResult><?=$result?></GetDynamicDNSIPv6SettingsResult> 
			<DynamicDNSIPv6List>				
<?
foreach("/ddns6/entry")
{
	echo "\t\t\t\t<DDNSIPv6Info>\n";
	if (get("x","enable")=="1")	$Status = "Enabled";
	else 						$Status = "Disabled";
	$IPv6Address = get("x","v6addr"); 
	$Hostname = get("x","hostname");
	echo "\t\t\t\t\t<Status>".$Status."</Status>\n";
	echo "\t\t\t\t\t<IPv6Address>".$IPv6Address."</IPv6Address>\n";
	echo "\t\t\t\t\t<Hostname>".$Hostname."</Hostname>\n";
	echo "\t\t\t\t</DDNSIPv6Info>\n";
}                  
?>
			</DynamicDNSIPv6List> 
		</GetDynamicDNSIPv6SettingsResponse>
	</soap:Body>
</soap:Envelope>
