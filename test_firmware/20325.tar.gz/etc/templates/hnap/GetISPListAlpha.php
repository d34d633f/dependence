HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/trace.php";

$isp_entry = "/runtime/services/operator/entry";

$result = "OK";
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<GetISPListAlphaResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetISPListAlphaResult><?=$result?></GetISPListAlphaResult>
					<?
						foreach($isp_entry)
						{
							echo "			<CountryList>\n";
							echo "				<Country>".get("x","country")."</Country>\n";
							foreach($isp_entry.":".$InDeX."/entry")
							{
								echo "				<ISPList>\n";
								echo "					<DialNumber>".get("x","dialno")."</DialNumber>\n";
								echo "					<APN>".get("x","apn")."</APN>\n";
								echo "					<ProfileName>".get("x","profilename")."</ProfileName>\n";
								echo "					<Username>".get("x","username")."</Username>\n";
								echo "					<Password>".get("x","password")."</Password>\n";
								echo "				</ISPList>\n";
							}
							echo "			</CountryList>\n";
						}
					?>
		</GetISPListAlphaResponse>
	</soap:Body>
</soap:Envelope>
