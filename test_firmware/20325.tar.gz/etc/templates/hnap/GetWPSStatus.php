HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
/*This HNAP action is refer the /htdocs/web/wpsstate.php in dlob.hans */
include "/htdocs/webinc/config.php";

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<GetWPSStatusResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetWPSStatusResult><?=$result?></GetWPSStatusResult>
				<WPSStatusLists>
				<?
				foreach ("/runtime/phyinf")
				{
					if (get("", "type")=="wifi")
					{
						$uid = get("", "uid");
						if($uid == $WLAN1)
						{$uid = "RADIO_2.4GHz";}
						else if($uid == $WLAN2)
						{$uid = "RADIO_5GHz";}
						$status = get("", "media/wps/enrollee/state");
						if($status=="WPS_IN_PROGRESS" || $status=="")
						{$status = "WPS_IN_PROGRESS";}
						else if($status=="WPS_SUCCESS")
						{$status = "WPS_SUCCESS";}
						else
						{$status = "ERROR";}

						echo "					<WPSStatus>\n";
						echo "						<RadioID>".$uid."</RadioID>\n";
						echo "						<Status>".$status."</Status>\n";
						echo "					</WPSStatus>\n";
					}
				}
				?>
				</WPSStatusLists>
		</GetWPSStatusResponse>
	</soap:Body>
</soap:Envelope>