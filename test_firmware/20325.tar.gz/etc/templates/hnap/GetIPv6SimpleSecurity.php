HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/webinc/config.php";

$result = "OK";

$Simple_Security = "Disable";

if (get("x", "/device/simple_security") == "1") 
{ 
	$Simple_Security = "Enable"; 
}
else 
{ 
	$Simple_Security = "Disable"; 
}


?>
<soap:Envelope 
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
	<soap:Body>
		<GetIPv6SimpleSecurityResponse xmlns="http://purenetworks.com/HNAP1/">
			<Status><?=$Simple_Security?></Status>
		</GetIPv6SimpleSecurityResponse>
	</soap:Body>
</soap:Envelope>