HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/webinc/config.php";

$path = "/route/static";
$entry = $path."/entry";
$result = "OK";

$nodebase = "/runtime/hnap/GetStaticRouteIPv4Settings";
del("/runtime/hnap/GetStaticRouteIPv4Settings");
$nodebase = $nodebase."/entry";

$i=0;

foreach ($entry)
{
	$i++;
	
	$uid = get("x", "uid");
	
	if (get("x", "enable") == "1") { set($nodebase.":".$i."/Enabled", true); }
	else { set($nodebase.":".$i."/Enabled", false); }
	
	set($nodebase.":".$i."/Name", get("x", "name"));
	
	set($nodebase.":".$i."/IPAddress", get("x", "network"));
	
	$netmask = ipv4int2mask(get("x", "mask"));
	set($nodebase.":".$i."/NetMask", $netmask);
	
	set($nodebase.":".$i."/Gateway", get("x", "via"));
	
	if (query("metric") != "") { set($nodebase.":".$i."/Metric", get("x", "metric")); }
	else { set($nodebase.":".$i."/Metric", "1"); }
	
	set($nodebase.":".$i."/Interface", get("x", "inf"));
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
	<soap:Body>
		<GetStaticRouteIPv4SettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetStaticRouteIPv4SettingsResult><?=$result?></GetStaticRouteIPv4SettingsResult>
			<StaticRouteIPv4List> 
			<?
				foreach($nodebase)
				{
					echo "				<SRIPv4Info>\n";
					echo "				<Enabled>".get("x", "Enabled")."</Enabled>\n";
					echo "				<Name>".get("x", "Name")."</Name>\n";
					echo "				<IPAddress>".get("x", "IPAddress")."</IPAddress>\n";
					echo "				<NetMask>".get("x", "NetMask")."</NetMask>\n";
					echo "				<Gateway>".get("x", "Gateway")."</Gateway>\n";
					echo "				<Metric>".get("x", "Metric")."</Metric>\n";
					echo "				<Interface>".get("x", "Interface")."</Interface>\n";
					echo "				</SRIPv4Info>\n";
				}
			?>        				
			</StaticRouteIPv4List>
		</GetStaticRouteIPv4SettingsResponse>
	</soap:Body>
</soap:Envelope>