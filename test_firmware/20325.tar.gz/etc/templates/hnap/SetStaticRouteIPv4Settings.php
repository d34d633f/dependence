﻿HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/webinc/config.php";

$nodebase = "/runtime/hnap/SetStaticRouteIPv4Settings/StaticRouteIPv4Data";
$node_info = $nodebase."/SRIPv4Info";
$path = "/route/static";
$entry = $path."/entry";
$result = "OK";

$max_rules = query($path."/max");
if($max_rules == "") { set($path."/max", "32"); }

set("/runtime/hnap/dummy", "");
movc($path, "/runtime/hnap/dummy"); //Remove the children nodes of /route/static
del("/runtime/hnap/dummy");

set($path."/seqno", "1");
set($path."/max", "32"); 
set($path."/count", "0");

foreach($node_info)
{
	$uid = "SRT-".$InDeX;
	set($entry.":".$InDeX."/uid", $uid);
	set($path."/seqno", $InDeX+1);
	set($path."/count", $InDeX);
	
	if (get("x", "Enabled") == "true") { set($entry.":".$InDeX."/enable", "1"); }
	else { set($entry.":".$InDeX."/enable", "0"); }
	
	set($entry.":".$InDeX."/name",get("x", "Name"));
	
	$netmask = ipv4mask2int(get("x", "NetMask"));
	set($entry.":".$InDeX."/mask", $netmask);
	
	$networkid = ipv4networkid(get("x", "IPAddress"), $netmask);
	set($entry.":".$InDeX."/network", $networkid);
	
	set($entry.":".$InDeX."/via", get("x", "Gateway"));
	
	set($entry.":".$InDeX."/metric", get("x", "Metric"));
	
	set($entry.":".$InDeX."/inf", get("x", "Interface"));
}

fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "echo \"[$0]-->Static Route IPv4\" > /dev/console\n");

if($result == "OK")
{
	fwrite("a",$ShellPath, "/etc/scripts/dbsave.sh > /dev/console\n");
	fwrite("a",$ShellPath, "service ROUTE.STATIC restart > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
	<SetStaticRouteIPv4SettingsResponse xmlns="http://purenetworks.com/HNAP1/">
		<SetStaticRouteIPv4SettingsResult><?=$result?></SetStaticRouteIPv4SettingsResult>
	</SetStaticRouteIPv4SettingsResponse>
	</soap:Body>
</soap:Envelope>