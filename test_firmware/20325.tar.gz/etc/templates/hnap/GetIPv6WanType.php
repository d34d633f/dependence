HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

include "etc/templates/hnap/GetIPv6Settings.php";

$get_wantype = $ConnectionType;

if($get_wantype != "") $rlt = "OK";
else $rlt = "ERROR";

//TRACE_info("==[Get IPv6 WanType.php]: ".$get_wantype);
?>
<soap:Envelope 
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<GetIPv6WanTypeResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetIPv6WanTypeResult><?=$rlt?></GetIPv6WanTypeResult>
			<IPv6_ConnectionType><?=$get_wantype?></IPv6_ConnectionType>
		</GetIPv6WanTypeResponse>
	</soap:Body>
</soap:Envelope>
