HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";

$nodebase= "/runtime/hnap/GetSysLogSettings";
$result = OK;

$SysLog = query("/device/log/remote/enable");
$IPAddress = query("/device/log/remote/ipv4/ipaddr");

if($SysLog==1) $SysLog = "true";
else $SysLog = "false";


?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<GetSysLogSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
      <GetSysLogSettingsResult><?=$result?></GetSysLogSettingsResult> 
      <SysLog><?=$SysLog?></SysLog> 
      <IPAddress><?=$IPAddress?></IPAddress>
    </GetSysLogSettingsResponse> 
	</soap:Body>
</soap:Envelope>