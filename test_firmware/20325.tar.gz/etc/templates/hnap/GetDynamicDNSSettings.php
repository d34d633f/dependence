HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
$path_inf_wan1 = XNODE_getpathbytarget("", "inf", "uid", $WAN1, 0);
$path_run_inf_wan1 = XNODE_getpathbytarget("/runtime", "inf", "uid", $WAN1, 0);	
			
if(get("x", $path_inf_wan1."/ddns4")!="")	$DDNS4_Enabled = true;
else										$DDNS4_Enabled = false;

$DDNS4_ServerAddress	= get("x", "/ddns4/entry:1/provider");
/*
	provider	=>	Server Address (Web Show)
	DLINK			dlinkddns.com(Free)
	DYNDNS.C		DynDns.org(Custom)
	DYNDNS			DynDns.org(Free)
	DYNDNS.S		DynDns.org(Static)
*/
if($DDNS4_ServerAddress=="DLINK")			{$DDNS4_ServerAddress="dlinkddns.com(Free)";}
else if($DDNS4_ServerAddress=="DYNDNS.C")	{$DDNS4_ServerAddress="dyndns.org(Custom)";}
else if($DDNS4_ServerAddress=="DYNDNS")		{$DDNS4_ServerAddress="dyndns.org(Free)";}
else if($DDNS4_ServerAddress=="DYNDNS.S")	{$DDNS4_ServerAddress="dyndns.org(Static)";}
$DDNS4_Hostname 		= get("x", "/ddns4/entry:1/hostname");
$DDNS4_Username		= get("x", "/ddns4/entry:1/username");
$DDNS4_Password		= get("x", "/ddns4/entry:1/password");
$DDNS4_Timeout		= get("x", "/ddns4/entry:1/interval")/60;

if(get("x", $path_run_inf_wan1."/ddns4/valid")=="1")
{
	$status = get("x", $path_run_inf_wan1."/ddns4/status");
	$result = get("x", $path_run_inf_wan1."/ddns4/result");
	if ($status == "IDLE")
	{
		if($result == "SUCCESS")$DDNS4_Status = "Connected";
		else					$DDNS4_Status = "Disconnected";
	}
	else
	{
		$DDNS4_Status = "Disconnected";
	}
}
else
{	
	$DDNS4_Status = "Disconnected";
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<GetDynamicDNSSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetDynamicDNSSettingsResult>OK</GetDynamicDNSSettingsResult>
			<Enabled><?=$DDNS4_Enabled?></Enabled> 
			<ServerAddress><?=$DDNS4_ServerAddress?></ServerAddress> 
			<Hostname><?=$DDNS4_Hostname?></Hostname> 
			<Username><?=$DDNS4_Username?></Username> 
			<Password><?=$DDNS4_Password?></Password> 
			<Timeout><?=$DDNS4_Timeout?></Timeout> 
			<Status><?=$DDNS4_Status?></Status>
		</GetDynamicDNSSettingsResponse>
	</soap:Body>
</soap:Envelope>
