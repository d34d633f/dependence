HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/trace.php"; 

$result = "OK";
$enable = get("","/webaccess/enable");
$RemoteHttp = get("","/webaccess/httpenable");
$RemoteHttpPort = get("","/webaccess/httpport");
$RemoteHttps = get("","/webaccess/httpsenable");
$RemoteHttpsPort = get("","/webaccess/httpsport");

if($enable==1) $enable = "true"; else $enable = "false";
if($RemoteHttp==1) $RemoteHttp = "true"; else $RemoteHttp = "false";
if($RemoteHttps==1) $RemoteHttps = "true"; else $RemoteHttps = "false";

function print_StorageUserInfo()
{
	echo "<StorageUserInfoLists>\n";
	foreach("/webaccess/account/entry")
	{
		$username = get("","username");
		$passwd = get("","passwd");
		$path = get("","entry/path");
		if (substr($path,0,1) != "/")
		{
			$path = "/".$path;
		}
		$permission = get("","entry/permission");
		
		if($username != "Admin" && $username != "admin")
		{
			if($permission == "rw") $permission = "true";
			else $permission = "false";
			
			echo "\t<StorageUser>\n";
			echo "\t\t<UserName>".escape("x",$username)."</UserName>\n";
			echo "\t\t<Password>".escape("x",$passwd)."</Password>\n";
			echo "\t\t<AccessPath>".escape("x",$path)."</AccessPath>\n";
			echo "\t\t<Promission>".escape("x",$permission)."</Promission>\n";
			echo "\t</StorageUser>\n";
		}
	}
	echo "</StorageUserInfoLists>\n";
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
<soap:Body>
<GetUSBStorageSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
<GetUSBStorageSettingsResult><?=$result?></GetUSBStorageSettingsResult>
<Enabled><?=$enable?></Enabled>
<RemoteHttp><?=$RemoteHttp?></RemoteHttp>
<RemoteHttpPort><?=$RemoteHttpPort?></RemoteHttpPort>
<RemoteHttps><?=$RemoteHttps?></RemoteHttps>
<RemoteHttpsPort><?=$RemoteHttpsPort?></RemoteHttpsPort>
<?print_StorageUserInfo();?>
</GetUSBStorageSettingsResponse>
</soap:Body>
</soap:Envelope>
