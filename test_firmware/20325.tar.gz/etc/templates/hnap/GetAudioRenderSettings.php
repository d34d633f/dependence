HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
$result = "OK";

if(get("","/device/audiorender/airplay") == "1")	{$AirPlay="true";}
else												{$AirPlay="false";}

if(get("","/device/audiorender/dlna") == "1")	{$DLNA="true";}
else											{$DLNA="false";}

if(get("","/runtime/device/audiocableplug") == "1")	{$AudioCablePlug="true";}
else												{$AudioCablePlug="false";}
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:xsd="http://www.w3.org/2001/XMLSchema"
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<GetAudioRenderSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetAudioRenderSettingsResult><?=$result?></GetAudioRenderSettingsResult>
			<AirPlay><?=$AirPlay?></AirPlay>
			<DLNA><?=$DLNA?></DLNA>
			<AudioCablePlug><?=$AudioCablePlug?></AudioCablePlug>
			<MediaName><? echo get("x","/device/audiorender/medianame");?></MediaName>
		</GetAudioRenderSettingsResponse>
	</soap:Body>
</soap:Envelope>