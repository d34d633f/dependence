#!/bin/sh
echo [$0]: $1 ... > /dev/console
echo "skip [$0]"
