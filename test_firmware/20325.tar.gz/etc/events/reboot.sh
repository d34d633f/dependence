#!/bin/sh

if [ "`xmldbc -g /runtime/device/layout`" != "router" ]; then
	reboot	
else
	if [ "`service INET.WAN-1 status`" == "stopped" ] ; then 
		echo "reboot directly"
		reboot
	else
		event WAN-1.DOWN add reboot
		event STATUS.CRITICAL
		killall radvd
		service INET.WAN-2 stop
		service INET.WAN-1 stop
		xmldbc -t "reboot:5:reboot"
	fi
fi
