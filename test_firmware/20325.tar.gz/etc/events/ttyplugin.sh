#!bin/sh
echo [$0] ... > /dev/console
service SIM.CHK restart
exit 0
