#!/bin/sh
event INET_UNLIGHT

if [ "`devdata get -e mfcmode`" == "1" ]; then
	devdata set -e mfcmode=0
	echo "Disable mfc mode!"
fi

event STATUS.CRITICAL
devconf del
if [ "`xmldbc -g /runtime/device/layout`" != "router" ]; then
	reboot
else
	if [ "`service INET.WAN-1 status`" == "stopped" ] ; then 
		echo "reboot directly"
		reboot
	else
		event WAN-1.DOWN add reboot
		service INET.WAN-2 stop
		service INET.WAN-1 stop
		xmldbc -t "reboot:5:reboot"
	fi
fi
