#!/bin/sh

sleep 10
ncecho 'Sending ARPing'
arping -U `ifconfig brtrunk  | grep 'inet addr:'| cut -d: -f2 | awk '{ print $1}'` -I brtrunk -c 1 &
sleep 1
arping -U `ifconfig brtrunk  | grep 'inet addr:'| cut -d: -f2 | awk '{ print $1}'` -I brtrunk -c 1 &
sleep 1
arping -U `ifconfig brtrunk  | grep 'inet addr:'| cut -d: -f2 | awk '{ print $1}'` -I brtrunk -c 1 &
sleep 1
arping -U `ifconfig brtrunk  | grep 'inet addr:'| cut -d: -f2 | awk '{ print $1}'` -I brtrunk -c 1 &
sleep 1
arping -U `ifconfig brtrunk  | grep 'inet addr:'| cut -d: -f2 | awk '{ print $1}'` -I brtrunk -c 1 &
sleep 1
arping -U `ifconfig brtrunk  | grep 'inet addr:'| cut -d: -f2 | awk '{ print $1}'` -I brtrunk -c 1 &
sleep 1
arping -U `ifconfig brtrunk  | grep 'inet addr:'| cut -d: -f2 | awk '{ print $1}'` -I brtrunk -c 1 &

