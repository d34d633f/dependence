<?php
    // Creatin a Product Registrion Reminder Turnoff
    $File = "/tmp/Popup_RemindLater"; 
    $Handle = fopen($File, 'w');
    fclose($Handle);  
?>