<?php
    // Creatin a Product Registrion Reminder Turnoff
    $File = "/var/Prod_Reg_Rem_TurnOff"; 
    $Handle = fopen($File, 'w');
    fclose($Handle);  
?>