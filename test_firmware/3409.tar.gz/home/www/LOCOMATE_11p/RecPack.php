<?php

  	$RecvPacket = conf_get("system:monitor:stats:lan:lanRecvPacket");
	$RecvBytes = conf_get("system:monitor:stats:lan:lanRecvBytes");
	$TransPacket = conf_get("system:monitor:stats:lan:lanTransPacket");
	$TransBytes = conf_get("system:monitor:stats:lan:lanTransBytes");
    	
	$RecvPacke = explode(' ',$RecvPacket);
	$RecvPack = $RecvPacke[1];
	
	$RecvByte = explode(' ',$RecvBytes);
        $RecvByt = $RecvByte[1];
	
	$TransPacke = explode(' ',$TransPacket);
        $TransPack = $TransPacke[1];
	
	$TransByte = explode(' ',$TransBytes);
        $TransByt = $TransByte[1];
	
	echo $response = $RecvPack.":".$RecvByt.":".$TransPack.":".$TransByt;

?>
