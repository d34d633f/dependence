<?php /* Smarty version 2.6.18, created on 2010-06-09 10:14:04
         compiled from BasicWirelessSettings.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'input_row', 'BasicWirelessSettings.tpl', 61, false),array('function', 'ip_field', 'BasicWirelessSettings.tpl', 63, false),array('modifier', 'regex_replace', 'BasicWirelessSettings.tpl', 167, false),array('modifier', 'default', 'BasicWirelessSettings.tpl', 300, false),)), $this); ?>
	<tr>
		<td>
			<table class="tableStyle">
				<tr>
					<td colspan="3"><script>tbhdr('Wireless Settings','radioSettings')</script></td>
				</tr>
				<tr>
					<td class="subSectionBodyDot">&nbsp;</td>
					<td class="spacer100Percent paddingsubSectionBody" style="padding: 0px;">
						<table class="tableStyle">
						<tr>
							<td>
								<div  id="WirelessBlock">
									<table class="inlineBlockContent" style="margin-top: 10px; width: 100%;">
										<tr>
											<td>
												<ul class="inlineTabs">
<?php if ($this->_tpl_vars['config']['TWOGHZ']['status']): ?>
														<li id="inlineTab1" <?php if ($this->_tpl_vars['data']['activeMode'] == '2' || $this->_tpl_vars['data']['activeMode'] == '1' || $this->_tpl_vars['data']['activeMode'] == '0' || $this->_tpl_vars['data']['activeMode0'] == '0' || $this->_tpl_vars['data']['activeMode0'] == '1' || $this->_tpl_vars['data']['activeMode0'] == '2'): ?>class="Active" activeRadio="true"<?php else: ?> activeRadio="false"<?php endif; ?> currentId="1"><a id="inlineTabLink1" href="javascript:void(0)">802.11p-Radio1<span class="Active" onmouseover='showLayer(this);' onmouseout='hideLayer(this);'><b class="RadioText<?php if ($this->_tpl_vars['data']['activeMode'] == '0' || $this->_tpl_vars['data']['activeMode0'] == '0'): ?>Active<?php endif; ?>"><?php if ($this->_tpl_vars['data']['activeMode'] == '0' || $this->_tpl_vars['data']['activeMode0'] == '0'): ?><img src="../images/activeRadio.gif"><span>Radio is set to 'ON'</span><?php endif; ?></b></span><?php if ($this->_tpl_vars['config']['MODE11G']['status']): ?><span class="Active" onmouseover='showLayer(this);' onmouseout='hideLayer(this);'><b class="RadioText<?php if ($this->_tpl_vars['data']['activeMode'] == '1' || $this->_tpl_vars['data']['activeMode0'] == '1'): ?>Active<?php endif; ?>"><?php if ($this->_tpl_vars['data']['activeMode'] == '1' || $this->_tpl_vars['data']['activeMode0'] == '1'): ?><img src="../images/activeRadio.gif"><span>Radio is set to 'ON'</span><?php endif; ?></b></span><?php endif; ?><?php if ($this->_tpl_vars['config']['MODE11N']['status']): ?><span class="Active" onmouseover='showLayer(this);' onmouseout='hideLayer(this);'><b class="RadioText<?php if ($this->_tpl_vars['data']['activeMode'] == '2' || $this->_tpl_vars['data']['activeMode0'] == '2'): ?>Active<?php endif; ?>"><?php if ($this->_tpl_vars['data']['activeMode'] == '2' || $this->_tpl_vars['data']['activeMode0'] == '2'): ?><img src="../images/activeRadio.gif"><span>Radio is set to 'ON'</span><?php endif; ?></b></span><?php endif; ?></a></li>
<?php endif; ?>

<!--@@@FIVEGHZSTART@@@-->
<?php if ($this->_tpl_vars['config']['FIVEGHZ']['status']): ?>
														<li id="inlineTab2" <?php if ($this->_tpl_vars['data']['activeMode'] == '3' || $this->_tpl_vars['data']['activeMode'] == '4' || $this->_tpl_vars['data']['activeMode1'] == '3' || $this->_tpl_vars['data']['activeMode1'] == '4'): ?>class="Active" activeRadio="true"<?php else: ?> activeRadio="false"<?php endif; ?> currentId="2"><a id="inlineTabLink2" href="javascript:void(0)">802.11p-Radio2<span class="Active" onmouseover='showLayer(this);' onmouseout='hideLayer(this);'><b class="RadioText<?php if ($this->_tpl_vars['data']['activeMode'] == '3' || $this->_tpl_vars['data']['activeMode1'] == '3'): ?>Active<?php endif; ?>"><?php if ($this->_tpl_vars['data']['activeMode'] == '3' || $this->_tpl_vars['data']['activeMode1'] == '3'): ?><img src="../images/activeRadio.gif"><span>Radio is set to 'ON'</span><?php endif; ?></b></span><?php if ($this->_tpl_vars['config']['MODE11N']['status']): ?><span class="Active" onmouseover='showLayer(this);' onmouseout='hideLayer(this);'><b class="RadioText<?php if ($this->_tpl_vars['data']['activeMode'] == '4' || $this->_tpl_vars['data']['activeMode1'] == '4'): ?>Active<?php endif; ?>"><?php if ($this->_tpl_vars['data']['activeMode'] == '4' || $this->_tpl_vars['data']['activeMode1'] == '4'): ?><img src="../images/activeRadio.gif"><span>Radio is set to 'ON'</span><?php endif; ?></b></span><?php endif; ?></a></li>
<?php endif; ?>
<!--@@@FIVEGHZEND@@@-->
												</ul>
											</td>
										</tr>
									</table>
								</div>
								<div id="IncludeTabBlock">
								<input type="hidden" name="activeMode" id="activeMode" value="<?php echo $this->_tpl_vars['data']['activeMode']; ?>
">
								<input type="hidden" name="currentMode" id="currentMode" value="<?php echo $this->_tpl_vars['data']['activeMode']; ?>
">
                                <input type="hidden" name="previousInterfaceNum" id="previousInterfaceNum">
<?php if ($this->_tpl_vars['config']['TWOGHZ']['status']): ?>
	<?php if ($this->_tpl_vars['config']['CLIENT']['status']): ?>
		<?php $this->assign('apMode', $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan0']['apMode']); ?>
	<?php endif; ?>
<div  class="BlockContent" id="wlan1">
<table class="BlockContent Trans" id="table_wlan1">
<tr class="Gray" style="display:none;">
<td class="DatablockLabel" style="width: 1%;">Wireless Mode</td>
<td class="DatablockContent" style="width: 100%;">
<span class="legendActive">2.4GHz Band</span>
<?php if ($this->_tpl_vars['config']['MODE11N']['status']): ?><input type="radio" style="padding: 2px;" name="WirelessMode1" id="WirelessMode1" <?php if ($this->_tpl_vars['data']['activeMode'] == '2' || $this->_tpl_vars['data']['activeMode0'] == '2' || ( $this->_tpl_vars['data']['activeMode'] == '' && $this->_tpl_vars['defaultMode0'] == '2' )): ?>checked="checked"<?php endif; ?> value="2"><span id="mode_ng" <?php if ($this->_tpl_vars['data']['activeMode'] == '2' || $this->_tpl_vars['data']['activeMode0'] == '2'): ?>class="Active" onmouseover='showLayer(this);' onmouseout='hideLayer(this);'>11p<img src="../images/activeRadio.gif"><span>Radio is set to 'ON'</span><?php else: ?>>11p<?php endif; ?></span><?php endif; ?>
	
<input type="hidden" name="<?php echo $this->_tpl_vars['parentStr']['wlanSettings']['wlanSettingTable']['wlan0']['operateMode']; ?>" id="activeMode0" value="<?php echo $this->_tpl_vars['data']['activeMode0']; ?>">
<input type="hidden" name="radioStatus0" id="radioStatus0" value="<?php echo $this->_tpl_vars['data']['radioStatus0']; ?>">
<?php if ($this->_tpl_vars['config']['CLIENT']['status']): ?>
	<input type="hidden" name="apMode0" id="apMode0" value="<?php echo $this->_tpl_vars['apMode']; ?>">
<?php endif; ?>
<input type="hidden" name="modeWlan0" id="modeWlan0" value="<?php if ($this->_tpl_vars['data']['activeMode'] > 2): ?>2<?php else: ?><?php echo $this->_tpl_vars['data']['activeMode']; ?><?php endif; ?>">
</td>
</tr>
<?php $this->assign('radioStatus', $this->_tpl_vars['parentStr']['wlanSettings']['wlanSettingTable']['wlan0']['radioStatus']); ?>
<?php $this->assign('operateMode', $this->_tpl_vars['parentStr']['wlanSettings']['wlanSettingTable']['wlan0']['operateMode']); ?>
<?php if ($this->_tpl_vars['config']['SCH_WIRELESS_ON_OFF']['status']): ?>
<input type="hidden" name="sch_Stat" id="sch_Stat" value="<?php echo $this->_tpl_vars['data']['basicSettings']['scheduledWirelessStatus']; ?>">
<?php endif; ?>
<?php echo smarty_function_input_row(array('row_id' => 'radioRow1','label' => 'Turn Radio On','id' => 'chkRadio0','name' => $this->_tpl_vars['parentStr']['wlanSettings']['wlanSettingTable']['wlan0']['radioStatus'],'type' => 'checkbox','value' => $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan0']['radioStatus']), $this);?>
</table>
</div>
<?php endif; ?>
<!--@@@FIVEGHZSTART@@@-->
<?php if ($this->_tpl_vars['config']['FIVEGHZ']['status']): ?>
	<?php if ($this->_tpl_vars['config']['CLIENT']['status']): ?>
		<?php $this->assign('apMode', $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan1']['apMode']); ?>
	<?php endif; ?>
<div  class="BlockContent" id="wlan2">
<table class="BlockContent Trans" id="table_wlan2">
<tr class="Gray" style="display:none;"> 
<td class="DatablockLabel" style="width: 1%;">Wireless Mode</td>
<td class="DatablockContent" style="width: 100%;">
<?php if ($this->_tpl_vars['config']['MODE11N']['status']): ?><input type="radio" style="padding: 2px;" name="WirelessMode<?php if ($this->_tpl_vars['config']['DUAL_CONCURRENT']['status']): ?>2<?php else: ?>1<?php endif; ?>" id="WirelessMode<?php if ($this->_tpl_vars['config']['DUAL_CONCURRENT']['status']): ?>2<?php else: ?>1<?php endif; ?>" <?php if ($this->_tpl_vars['data']['activeMode'] == '4' || $this->_tpl_vars['data']['activeMode1'] == '4' || ( $this->_tpl_vars['data']['activeMode'] == '' && $this->_tpl_vars['defaultMode1'] == '4' )): ?>checked="checked"<?php endif; ?> value="4"><span id="mode_na" <?php if ($this->_tpl_vars['data']['activeMode'] == '4' || $this->_tpl_vars['data']['activeMode1'] == '4'): ?>class="Active" id="radioAct" onmouseover='showLayer(this);' onmouseout='hideLayer(this);'>11<img src="../images/activeRadio.gif"><span>Radio is set to 'ON'</span><?php else: ?>>11<?php endif; ?></span><?php endif; ?>

<input type="hidden" name="<?php echo $this->_tpl_vars['parentStr']['wlanSettings']['wlanSettingTable']['wlan1']['operateMode']; ?>" id="activeMode1" value="<?php echo $this->_tpl_vars['data']['activeMode1']; ?>">
<input type="hidden" name="radioStatus1" id="radioStatus1" value="<?php echo $this->_tpl_vars['data']['radioStatus1']; ?>">
<?php if ($this->_tpl_vars['config']['CLIENT']['status']): ?>
<input type="hidden" name="apMode1" id="apMode1" value="<?php echo $this->_tpl_vars['apMode']; ?>">
<?php endif; ?>
<input type="hidden" name="modeWlan1" id="modeWlan1" value="<?php if ($this->_tpl_vars['data']['activeMode'] < 3): ?>4<?php else: ?><?php echo $this->_tpl_vars['data']['activeMode']; ?>  <?php endif; ?>">
</td>
</tr>
<?php if ($this->_tpl_vars['config']['SCH_WIRELESS_ON_OFF']['status']): ?>
<?php echo smarty_function_ip_field(array('id' => 'radioBkup1','name' => $this->_tpl_vars['parentStr']['wlanSettings']['wlanSettingTable']['wlan1']['scheduledRadioBackup'],'type' => 'hidden','value' => $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan1']['scheduledRadioBackup']), $this);?>
 <?php endif; ?>
<?php $this->assign('radioStatus', $this->_tpl_vars['parentStr']['wlanSettings']['wlanSettingTable']['wlan1']['radioStatus']); ?>
<?php $this->assign('operateMode', $this->_tpl_vars['parentStr']['wlanSettings']['wlanSettingTable']['wlan1']['operateMode']); ?>
<?php echo smarty_function_input_row(array('row_id' => 'radioRow2','label' => 'Turn Radio On','id' => 'chkRadio1','name' => $this->_tpl_vars['parentStr']['wlanSettings']['wlanSettingTable']['wlan1']['radioStatus'],'type' => 'checkbox','value' => $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan1']['radioStatus']), $this);?>
</table>
</div>
<?php endif; ?>
<!--@@@FIVEGHZEND@@@-->
</div>
</td>
</tr>
</table>
</td>
<td class="subSectionBodyDotRight">&nbsp;</td>
</tr>
<tr>
<td colspan="3" class="subSectionBottom">&nbsp;</td>
</tr>
</table>
</td>
</tr>
</table>

    <?php if ($this->_tpl_vars['support5GHz'] == true): ?>
            <input id="supports5GHz" value='true' type="hidden">
    <?php else: ?>
            <input id="supports5GHz" value='false' type="hidden">
    <?php endif; ?>

	<script language="javascript">
	<!--
        var prevInterface = <?php echo ((is_array($_tmp=@$_POST['previousInterfaceNum'])) ? $this->_run_mod_handler('default', true, $_tmp, "''") : smarty_modifier_default($_tmp, "''")); ?>
;
    	<?php if ($this->_tpl_vars['config']['TWOGHZ']['status']): ?>
			var ChannelList_0 = <?php echo $this->_tpl_vars['ChannelList_0']; ?>
; //11b
			<?php if ($this->_tpl_vars['config']['MODE11G']['status']): ?>
				var ChannelList_1 = <?php echo $this->_tpl_vars['ChannelList_1']; ?>
; //11bg
				<?php if ($this->_tpl_vars['config']['MODE11N']['status']): ?>
					var ChannelList_0_20 = <?php echo $this->_tpl_vars['ChannelList_0_20']; ?>
;
					var wlan0_40MHzSupport = <?php echo $this->_tpl_vars['wlan0_40MHzSupport']; ?>
;
					<?php if ($this->_tpl_vars['wlan0_40MHzSupport'] == true && $this->_tpl_vars['ChannelList_0_40'] != ''): ?>
						var ChannelList_0_40 = <?php echo $this->_tpl_vars['ChannelList_0_40']; ?>
;
					<?php endif; ?>
                        
				<?php endif; ?>
				<?php if ($this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan0']['apMode'] != 0 && $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan0']['apMode'] != 5): ?>
					var disableChannelonWDS0 = true;
				<?php endif; ?>
				<?php if ($this->_tpl_vars['interface'] == 'wlan1'): ?>
					<?php echo 'window.onload=function changeHelp() {$(\'helpURL\').value=$(\'helpURL\').value+\'_g\';};'; ?>

				<?php endif; ?>
			<?php endif; ?>
		<?php endif; ?>
//<!--@@@FIVEGHZSTART@@@-->
		<?php if ($this->_tpl_vars['config']['FIVEGHZ']['status']): ?>
			var ChannelList_3 = <?php echo $this->_tpl_vars['ChannelList_3']; ?>
; //11a
			<?php if ($this->_tpl_vars['config']['MODE11N']['status']): ?>
				var ChannelList_1_20 = <?php echo $this->_tpl_vars['ChannelList_1_20']; ?>
;
				var wlan1_40MHzSupport = <?php echo $this->_tpl_vars['wlan1_40MHzSupport']; ?>
;
				<?php if ($this->_tpl_vars['wlan1_40MHzSupport'] == true && $this->_tpl_vars['ChannelList_1_40'] != ''): ?>
					var ChannelList_1_40 = <?php echo $this->_tpl_vars['ChannelList_1_40']; ?>
;
				<?php endif; ?>

			<?php endif; ?>
			<?php if ($this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan1']['apMode'] != 0 && $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan1']['apMode'] != 5): ?>
				var disableChannelonWDS1 = true;
			<?php endif; ?>
			<?php if ($this->_tpl_vars['interface'] == 'wlan2'): ?>
				<?php echo 'window.onload=function changeHelp() {$(\'helpURL\').value=$(\'helpURL\').value+\'_a\';};'; ?>

			<?php endif; ?>
		<?php endif; ?>
//<!--@@@FIVEGHZEND@@@-->
		var form = new formObject();
		<?php if ($this->_tpl_vars['config']['TWOGHZ']['status']): ?>
            $('cb_chkRadio0').observe('click',form.tab1.setActiveMode.bindAsEventListener(form.tab1,true));
            var i = 0;
			$RD('WirelessMode1').each( function(radio) <?php echo ' {
                if (parseInt(radio.value) <= 2) {
				    $(radio).observe(\'click\',form.tab1.enableMode.bindAsEventListener(form.tab1, i++));
                }
			});
            '; ?>

        <?php endif; ?>
//<!--@@@FIVEGHZSTART@@@-->
		<?php if ($this->_tpl_vars['config']['FIVEGHZ']['status']): ?>
            $('cb_chkRadio1').observe('click',form.tab2.setActiveMode.bindAsEventListener(form.tab2,true));
            var i = 3;
			$RD(<?php if ($this->_tpl_vars['config']['DUAL_CONCURRENT']['status']): ?>'WirelessMode2'<?php else: ?>'WirelessMode1'<?php endif; ?>).each( function(radio) <?php echo '{
                if (parseInt(radio.value) >= 3)
				    $(radio).observe(\'click\',form.tab2.enableMode.bindAsEventListener(form.tab2, i++));
			});
            '; ?>

		<?php endif; ?>
//<!--@@@FIVEGHZEND@@@-->

<?php echo '
            if (prevInterface != \'\') {
                    if(prevInterface == \'1\'){
                        form.tab1.activate();
                    }
                    else if(prevInterface == \'2\'){
                        form.tab2.activate();
                    }
             }
             else {
'; ?>

            <?php if ($this->_tpl_vars['config']['TWOGHZ']['status']): ?>
                    form.tab1.activate();
            <?php endif; ?>
//<!--@@@FIVEGHZSTART@@@-->
            <?php if ($this->_tpl_vars['config']['FIVEGHZ']['status']): ?>
                <?php if ($this->_tpl_vars['data']['radioStatus1'] == '1' && $this->_tpl_vars['data']['radioStatus0'] != '1'): ?>
                    form.tab2.activate();
                <?php endif; ?>
            <?php endif; ?>
//<!--@@@FIVEGHZEND@@@-->
<?php echo '
            }
'; ?>

	-->
	</script>
