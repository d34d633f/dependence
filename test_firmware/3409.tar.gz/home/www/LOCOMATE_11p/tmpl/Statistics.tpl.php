<?php /* Smarty version 2.6.18, created on 2010-01-11 08:55:29
         compiled from Statistics.tpl */   ?>
<tr>
	<td>
		<table class="tableStyle">
			<tr>
				<td colspan="3">
					<table class='tableStyle'>
						<tr>
							<td colspan='2' class='subSectionTabTopLeft spacer60Percent font12BoldBlue'>Wired Ethernet</td>
							<td class='subSectionTabTopRight spacer40Percent'>
								<a href='javascript: void(0);' onclick="showHelp('Wired Ethernet','wiredEthernet');"><img src='images/help_icon.gif' width='12' height='12' title='Click for help'/></a></td>
						</tr>
						<tr>
							<td colspan='3' class='subSectionTabTopShadow'></td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td class="subSectionBodyDot">&nbsp;</td>
				<td class="spacer100Percent paddingsubSectionBody" style="padding: 0px;">
					<table class="tableStyle">
						<tr>
							<td>
								<div  id="BlockContentTable">
									<table class="BlockContentTable">
										<tr>
											<th>&nbsp;</th>
											<th>Received</th>
											<th class="Last">Transmitted</th>
										</tr>
										<tr>
											<th>Packets</th>
												<td><span id="RecvPacket"></span></td>
												<td><span id="TransPacket"></span></td>	
										</tr>
										<tr class="Alternate">
											<th>Bytes</th>
											<td class="Alternate"><span  id="RecvBytes"></span></td>
											<td class="Alternate"><span  id="TransBytes"></span></td>
										</tr>
									</table>
								</div>
							</td>
						</tr>
					</table>
				</td>
				<td class="subSectionBodyDotRight">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="3" class="subSectionBottom">&nbsp;</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td class="spacerHeight21">&nbsp;</td>
</tr>
<?php if( $this->_tpl_vars['data']['monitor']['stats']['wlan0']['wlanRecvUnicastPacket'] != "" ): ?>
<?php if ($this->_tpl_vars['config']['TWOGHZ']['status'] && $this->_tpl_vars['data']['radioStatus0'] == '1'): ?>
<tr id="wlan1">
	<td>
		<table class="tableStyle" style="width: 432px;">
			<tr>
				<td colspan="3">
					<table class='tableStyle'>
						<tr>
							<td colspan='2' class='subSectionTabTopLeft spacer60Percent font12BoldBlue'>Wireless Radio1</td>
							<td class='subSectionTabTopRight spacer40Percent'><a href='javascript: void(0);' onclick="showHelp('Wireless Statistics','wirelessStatistics');"><img src='images/help_icon.gif' width='12' height='12' title='Click for help'/></a></td>
						</tr>
						<tr>
							<td colspan='3' class='subSectionTabTopShadow'></td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td class="subSectionBodyDot">&nbsp;</td>
				<td class="spacer100Percent paddingsubSectionBody" style="padding: 0px;">
					<table class="tableStyle">
						<tr>
							<td>
								<div  id="BlockContentTable">
									<table class="BlockContentTable">
										<tr>
											<th>&nbsp;</th>
											<th>Received</th>
											<th class="Last">Transmitted</th>
										</tr>
										<tr>
											<th>Unicast Packets</th>
											<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan0']['wlanRecvUnicastPacket']; ?>
</td>											<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan0']['wlanTransUnicastPacket']; ?>
</td>										</tr>
										<tr class="Alternate">
											<th>Broadcast Packets</th>
											<td class="Alternate"><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan0']['wlanRecvBroadcastPacket']; ?></td>
											<td class="Alternate"><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan0']['wlanTransBroadcastPacket']; ?></td>
										</tr>
										<tr>
											<th>Multicast Packets</th>
											<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan0']['wlanRecvMulticastPacket']; ?></td>
											<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan0']['wlanTransMulticastPacket']; ?></td>
										</tr>
										<tr class="Alternate">
											<th>Total Packets</th>
											<td class="Alternate"><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan0']['wlanRecvPacket']; ?></td>
											<td class="Alternate"><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan0']['wlanTransPacket']; ?></td>
										</tr>
										<tr>
											<th>Total Bytes</th>
											<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan0']['wlanRecvBytes']; ?>
</td>
											<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan0']['wlanTransBytes']; ?></td>
										</tr>
									</table>
								</div>
							</td>
						</tr>
					</table>
				</td>
				<td class="subSectionBodyDotRight">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="3" class="subSectionBottom">&nbsp;</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td class="spacerHeight21"></td>
</tr>
<?php endif; ?>
<?php endif; ?>
<!--@@@FIVEGHZSTART@@@-->
<?php if( $this->_tpl_vars['data']['monitor']['stats']['wlan1']['wlanRecvUnicastPacket'] != "" ): ?>
<?php if ($this->_tpl_vars['config']['FIVEGHZ']['status'] && $this->_tpl_vars['data']['radioStatus1'] == '1'): ?>
	<tr id="wlan2">
		<td>
			<table class="tableStyle" style="width: 432px;">
				<tr>
					<td colspan="3">
						<table class='tableStyle'>
							<tr>
								<td colspan='2' class='subSectionTabTopLeft spacer60Percent font12BoldBlue'>Wireless Radio2</td>
								<td class='subSectionTabTopRight spacer40Percent'>
									<a href='javascript: void(0);' onclick="showHelp('Wireless Statistics','wirelessStatistics');"><img src='images/help_icon.gif' width='12' height='12' title='Click for help'/></a></td>
							</tr>
							<tr>
								<td colspan='3' class='subSectionTabTopShadow'></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td class="subSectionBodyDot">&nbsp;</td>
					<td class="spacer100Percent paddingsubSectionBody" style="padding: 0px;">
						<table class="tableStyle">
							<tr>
								<td>
									<div  id="BlockContentTable">
										<table class="BlockContentTable">
											<tr>
												<th>&nbsp;</th>
												<th>Received</th>
												<th class="Last">Transmitted</th>
											</tr>
											<tr>
												<th>Unicast Packets</th>
												<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan1']['wlanRecvUnicastPacket']; ?>
</td>
												<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan1']['wlanTransUnicastPacket']; ?>
</td>
											</tr>
											<tr class="Alternate">
												<th>Broadcast Packets</th>
												<td class="Alternate"><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan1']['wlanRecvBroadcastPacket']; ?>
</td>
												<td class="Alternate"><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan1']['wlanTransBroadcastPacket']; ?>
</td>
											</tr>
											<tr>
												<th>Multicast Packets</th>
												<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan1']['wlanRecvMulticastPacket']; ?>
</td>
												<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan1']['wlanTransMulticastPacket']; ?>
</td>
											</tr>
											<tr class="Alternate">
												<th>Total Packets</th>
												<td class="Alternate"><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan1']['wlanRecvPacket']; ?>
</td>
												<td class="Alternate"><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan1']['wlanTransPacket']; ?>
</td>
											</tr>
											<tr>
												<th>Total Bytes</th>
												<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan1']['wlanRecvBytes']; ?>
</td>
												<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['wlan1']['wlanTransBytes']; ?>
</td>
											</tr>
										</table>
									</div>
								</td>
							</tr>
						</table>
					</td>
					<td class="subSectionBodyDotRight">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" class="subSectionBottom">&nbsp;</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
                <td class="spacerHeight21"></td>
        </tr>
<?php endif; ?>
<?php endif; ?>
<!--@@@FIVEGHZEND@@@-->

<!--@@@ GPS Statistics @@@-->
<?php if ($this->_tpl_vars['config']['FIVEGHZ']['status'] && $this->_tpl_vars['data']['radioStatus1'] == '1'): ?>
        <tr id="wlan2">
                <td>
                        <table class="tableStyle" style="width: 432px;">
			<tr>
				<td colspan="3">
					<table class='tableStyle'>
						<tr>
						<td colspan='2' class='subSectionTabTopLeft spacer60Percent font12BoldBlue'>GPS Statistics</td>
							<td class='subSectionTabTopRight spacer40Percent'>
								<a href='javascript: void(0);' onclick="showHelp('Wireless Statistics','wirelessStatistics');"><img src='images/help_icon.gif' width='12' height='12' title='Click for help'/></a></td>
						</tr>
						<tr>
							<td colspan='3' class='subSectionTabTopShadow'></td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td class="subSectionBodyDot">&nbsp;</td>
				<td class="spacer100Percent paddingsubSectionBody" style="padding: 0px;">
					<table class="tableStyle">
						<tr>
							<td>
								<div  id="BlockContentTable">
									<table class="BlockContentTable">
										<tr>
											<th width="100">Latitude</th>
											<td><?php echo $this->_tpl_vars['data']['monitor']['stats']['gpsStats']['gpslatitude']; ?>
</td>
                                                                                   </tr>
                                                                                        <tr class="Alternate">
                                                                                                <th>Longitude</th>
                                                                                                <td class="Alternate"><?php echo $this->_tpl_vars['data']['monitor']['stats']['gpsStats']['gpslongitude']; ?>
</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <th>Altitude</th>
                                                                                                <td><?php echo $this->_tpl_vars['data']['monitor']['stats']['gpsStats']['gpsaltitude']; ?>
</td>
                                                                                        </tr>
                                                                                        <tr class="Alternate">
                                                                                                <th>Time</th>
                                                                                                <td class="Alternate"><?php echo $this->_tpl_vars['data']['monitor']['stats']['gpsStats']['gpstime']; ?>
</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                               <th>Number of Satellites</th>
                                                                                                <td><?php echo $this->_tpl_vars['data']['monitor']['stats']['gpsStats']['gpsnumberOfStatelliteUsed']; ?>
</td>
                                                                                        </tr>
                                                                                </table>
                                                                        </div>
                                                                </td>
                                                        </tr>
                                                </table>
                                        </td>
                                        <td class="subSectionBodyDotRight">&nbsp;</td>
                                </tr>
                                <tr>
                                        <td colspan="3" class="subSectionBottom">&nbsp;</td>
                                </tr>
                        </table>
                </td>
        </tr>
<?php endif; ?>
<!--@@@  GPS Statistics@@@-->

<script language="javascript">
<!--

<?php if ($this->_tpl_vars['config']['CLIENT']['status']): ?>
	<?php if (( $this->_tpl_vars['config']['TWOGHZ']['status'] && $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan0']['apMode'] == 5 ) || ( $this->_tpl_vars['config']['FIVEGHZ']['status'] && $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan1']['apMode'] == 5 )): ?>
		//Form.disable(document.dataForm);
		//window.top.frames['action'].$('refresh').disabled=true;
		//window.top.frames['action'].$('refresh').src="images/refresh_off.gif";
	<?php endif; ?>
<?php endif; ?>
-->

function changeRecPack(){
        var oOptions = {
                method: "get",
                asynchronous: false,
                onSuccess: function (oXHR, oJson) {
                        var response = oXHR.responseText;
                        if(response != '') {
				var respons = response.split(":");
				$('RecvPacket').update(respons[0]);
				$('RecvBytes').update(respons[1]);
				$('TransPacket').update(respons[2]);
				$('TransBytes').update(respons[3]);
                          }
                        else {
					var req = new Ajax.Request('RecPack.php', oOptions);
                                                return false;
                        }
                        return false;
                },
        };
 new Ajax.Request('RecPack.php', oOptions);
setTimeout("changeRecPack()",1000);
}
window.onload = changeRecPack();

</script>
