<?php /* Smarty version 2.6.18, created on 2010-06-09 10:14:04
        compiled from BasicWirelessSettings.tpl */           
?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'input_row', 'ApplicationProfile.tpl', 61, false),array('function', 'ip_field', 'ApplicationProfile.tpl', 63, false),array('modifier', 'regex_replace', 'ApplicationProfile.tpl', 167, false),array('modifier', 'default', 'ApplicationProfile.tpl', 300, false),)), $this); ?>
	<tr>
		<td>
			<table class="tableStyle">
				<tr>
					<td colspan="3"><script>tbhdr('Application Profiles','radioSettings')</script></td>
				</tr>
				<tr>
					<td class="subSectionBodyDot">&nbsp;</td>
					<td class="spacer100Percent paddingsubSectionBody" style="padding: 0px;">
						<table class="tableStyle">
						<tr>
							<td>
								<div  id="WirelessBlock">
									<table class="inlineBlockContent" style="margin-top: 10px; width: 100%;">
										<tr>
											<td>
												<?php $a1 = $this->_tpl_vars['data']['applicationSettings']['app1Status']; ?>
												<?php $a2 = $this->_tpl_vars['data']['applicationSettings']['app2Status']; ?>
												<?php $a3= $this->_tpl_vars['data']['applicationSettings']['app3Status']; ?>
												<?php $a4 = $this->_tpl_vars['data']['applicationSettings']['app4Status']; ?>

				<ul class="inlineTabs">
				<?php if ($this->_tpl_vars['config']['APPLICATION1']['status']): ?>
					<li id="inlineTab1"  class="Active"><a id="inlineTabLink1" href="javascript:applications(1, <?php echo $a1; ?>)">Application-1</a></li> 
				<?php endif; ?>
				<?php if ($this->_tpl_vars['config']['APPLICATION2']['status']): ?>
					 <li id="inlineTab2"><a id="inlineTabLink2" href="javascript:applications(2, <?php echo $a2; ?>)">Application-2</a></li>
				<?php endif; ?>
				<?php if ($this->_tpl_vars['config']['APPLICATION3']['status']): ?>
					<li id="inlineTab3"><a id="inlineTabLink3" href="javascript:applications(3, <?php echo $a3; ?>)">Application-3</a></li>	
				<?php endif; ?>
				<?php if ($this->_tpl_vars['config']['APPLICATION4']['status']): ?>
					<li id="inlineTab4"><a id="inlineTabLink4" href="javascript:applications(4, <?php echo $a4; ?>)">Application-4</a></li>
				<?php endif; ?>
				</ul>
				</td>
			</tr>
		</table>
 </div>
                                                        </td>
                                                </tr>

                                                </table>

<!-- APPLICATION 1 STARTING HERE -->
<div  class="BlockContent" id="application1">
<table  class="tableStyle">
<tr><td style="padding:2px;"></td><td></td></tr>
<?php if($this->_tpl_vars['data']['applicationSettings']['app1Name']!="INVALID" && $this->_tpl_vars['data']['applicationSettings']['app1Name']!=""){ ?>
<?php echo smarty_function_input_row(array('label' => 'Application-1 Name','id' => 'app1Name','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app1Name'],'type' => 'text','class' => 'input','value' => $this->_tpl_vars['data']['applicationSettings']['app1Name'], 'readonly'=>'readonly'), $this); ?>

<a style="float:right; margin:7px 25px 0 0;" href="<?php echo $this->_tpl_vars['data']['applicationSettings']['app1Name']; ?>"><img src="images/icon_download.jpg" title="Download" /></a>
<?php } else { ?>
<?php echo smarty_function_input_row(array('label' => 'Application-1 Name','id' => 'app1Name','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app1Name'],'type' => 'text','class' => 'input', 'value' => 'INVALID', 'readonly'=>'readonly'), $this); ?>
<?php } ?>


<?php//  $arg = conf_get("system:applicationSettings:app1arg"); 	$arg1 = strstr($arg, ' '); ?>
<?php// echo smarty_function_input_row(array('label' => 'Application-1 Arguments','id' => 'app1ArgName','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app1arg'],'type' => 'text','class' => 'input','value' => $arg1,'size' => '30','maxlength' => '29'), $this);?>



<?php echo smarty_function_input_row(array('label' => 'Application-1 Arguments','id' => 'app1ArgName','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app1arg'],'type' => 'text','class' => 'input','value' => ltrim(str_replace('\ ',' ',strstr(conf_get("system:applicationSettings:app1arg"), ' ')))), $this);?>
				

<?php// echo smarty_function_input_row(array('label' => 'Application-1 Arguments','id' => 'app1ArgName','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app1arg'],'type' => 'text','class' => 'input','value' => $this->_tpl_vars['data']['applicationSettings']['app1arg'], 'size' => '30','maxlength' => '29'), $this);?>


<?php $this->assign('app1Status', $this->_tpl_vars['data']['applicationSettings']['app1Status']); ?>
    <?php echo smarty_function_input_row(array('label' => 'Start Application-1','id' => 'app1Radio','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app1Status'],'type' => 'radio','options' => "1-Enable,0-Disable",'selectCondition' => "==".($this->_tpl_vars['app1Status'])), $this);?>


<?php echo smarty_function_input_row(array('label' => 'Select Application-1 to upload','id' => 'application1File','class' => 'input','name' => 'application1File','type' => 'file','oncontextmenu' => 'return false','onkeydown' => "this.blur()",'onpaste' => 'return false'), $this);?>

<?php // echo smarty_function_input_row(array('label' => '','id' => 'app1FileName','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app1FileName'],'type' => 'hidden','class' => 'input','value' => $this->_tpl_vars['data']['applicationSettings']['app1FileName'],'size' => '30','maxlength' => '29'), $this);?>
	</td></tr>
</table>
</div>
<!-- APPLICATION 1 ENDING HERE -->

<!-- APPLICATION 2 STARTING HERE -->
<div  class="BlockContent" id="application2" style="display:none;">
<table  class="tableStyle">
<tr><td style="padding:2px;"></td><td></td></tr>
<?php if($this->_tpl_vars['data']['applicationSettings']['app2Name']!="INVALID" && $this->_tpl_vars['data']['applicationSettings']['app2Name']!=""){ ?>
<?php echo smarty_function_input_row(array('label' => 'Application-2 Name','id' => 'app2Name','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app2Name'],'type' => 'text','class' => 'input','value' => $this->_tpl_vars['data']['applicationSettings']['app2Name'], 'readonly'=>'readonly'), $this);?>

<a style="float:right; margin:7px 25px 0 0;" href="<?php echo $this->_tpl_vars['data']['applicationSettings']['app2Name']; ?>"><img src="images/icon_download.jpg" title="Download" /></a>
<?php } else { ?>
<?php echo smarty_function_input_row(array('label' => 'Application-2 Name','id' => 'app2Name','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app2Name'],'type' => 'text','class' => 'input', 'value' => 'INVALID', 'readonly'=>'readonly'), $this);?>
<?php } ?>
<?php echo smarty_function_input_row(array('label' => 'Application-2 Arguments','id' => 'app2ArgName','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app2arg'],'type' => 'text','class' => 'input','value' => ltrim(str_replace('\ ',' ',strstr(conf_get("system:applicationSettings:app2arg"), ' ')))),$this);?>

 
<?php $this->assign('app2Status', $this->_tpl_vars['data']['applicationSettings']['app2Status']); ?>
    <?php echo smarty_function_input_row(array('label' => 'Start Application-2','id' => 'app2Radio','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app2Status'],'type' => 'radio','options' => "1-Enable,0-Disable",'selectCondition' => "==".($this->_tpl_vars['app2Status'])), $this);?>


<?php echo smarty_function_input_row(array('label' => 'Select Application-2 to upload','id' => 'application2File','class' => 'input','name' => 'application2File','type' => 'file','oncontextmenu' => 'return false','onkeydown' => "this.blur()",'onpaste' => 'return false'), $this);?>

<?php // echo smarty_function_input_row(array('label' => '','id' => 'app2FileName','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app2FileName'],'type' => 'hidden','class' => 'input','value' => $this->_tpl_vars['data']['applicationSettings']['app2FileName'],'size' => '30','maxlength' => '29'), $this);?>


</td></tr>
</table>
</div>
<!-- APPLICATION 2 ENDING HERE -->
<!--PPLICATION 3 STARTING HERE -->
<div  class="BlockContent" id="application3" style="display:none;">
<table  class="tableStyle">
<tr><td style="padding:2px;"></td><td></td></tr>
<?php if($this->_tpl_vars['data']['applicationSettings']['app3Name']!="INVALID" && $this->_tpl_vars['data']['applicationSettings']['app3Name']!=""){ ?>
<?php echo smarty_function_input_row(array('label' => 'Application-3 Name','id' => 'app3Name','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app3Name'],'type' => 'text','class' => 'input','value' => $this->_tpl_vars['data']['applicationSettings']['app3Name'],'size' => '30','maxlength' => '29', 'readonly'=>'readonly'), $this);?>

<a style="float:right; margin:7px 25px 0 0;" href="<?php echo $this->_tpl_vars['data']['applicationSettings']['app3Name']; ?>"><img src="images/icon_download.jpg" title="Download" /></a>
<?php } else { ?>
<?php echo smarty_function_input_row(array('label' => 'Application-3 Name','id' => 'app3Name','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app3Name'],'type' => 'text','class' => 'input', 'value' => 'INVALID', 'readonly'=>'readonly'), $this);?>
<?php } ?>
<?php echo smarty_function_input_row(array('label' => 'Application-3 Arguments','id' => 'app3ArgName','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app3arg'],'type' => 'text','class' => 'input','value' => ltrim(str_replace('\ ',' ',strstr(conf_get("system:applicationSettings:app3arg"), ' ')))), $this);?>


<?php $this->assign('app3Status', $this->_tpl_vars['data']['applicationSettings']['app3Status']); ?>
    <?php echo smarty_function_input_row(array('label' => 'Start Application-3','id' => 'app3Radio','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app3Status'],'type' => 'radio','options' => "1-Enable,0-Disable",'selectCondition' => "==".($this->_tpl_vars['app3Status'])), $this);?>


<?php echo smarty_function_input_row(array('label' => 'Select Application-3 to upload','id' => 'application3File','class' => 'input','name' => 'application3File','type' => 'file','oncontextmenu' => 'return false','onkeydown' => "this.blur()",'onpaste' => 'return false'), $this);?>

<?php // echo smarty_function_input_row(array('label' => '','id' => 'app3FileName','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app3FileName'],'type' => 'hidden','class' => 'input','value' => $this->_tpl_vars['data']['applicationSettings']['app3FileName'],'size' => '30','maxlength' => '29'), $this);?>


</td></tr>
</table>
</div>
<!-- APPLICATION 3 ENDING HERE -->


<!-- APPLICATION 4 STARTING HERE -->
<div  class="BlockContent" id="application4" style="display:none;">
<table  class="tableStyle">
<tr><td style="padding:2px;"></td><td></td></tr>
<?php if($this->_tpl_vars['data']['applicationSettings']['app4Name']!="INVALID" && $this->_tpl_vars['data']['applicationSettings']['app4Name']!=""){ ?>
<?php echo smarty_function_input_row(array('label' => 'Application-4 Name','id' => 'app4Name','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app4Name'],'type' => 'text','class' => 'input','value' => $this->_tpl_vars['data']['applicationSettings']['app4Name'], 'readonly'=>'readonly'), $this);?>

<a style="float:right; margin:7px 25px 0 0;" href="<?php echo $this->_tpl_vars['data']['applicationSettings']['app4Name']; ?>"><img src="images/icon_download.jpg" title="Download" /></a>
<?php } else { ?>
<?php echo smarty_function_input_row(array('label' => 'Application-4 Name','id' => 'app4Name','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app4Name'],'type' => 'text','class' => 'input', 'value' => 'INVALID', 'readonly'=>'readonly'), $this);?>
<?php } ?>
<?php echo smarty_function_input_row(array('label' => 'Application-4 Arguments','id' => 'app4ArgName','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app4arg'],'type' => 'text','class' => 'input','value' => ltrim(str_replace('\ ',' ',strstr(conf_get("system:applicationSettings:app4arg"), ' ')))), $this);?>


<?php $this->assign('app4Status', $this->_tpl_vars['data']['applicationSettings']['app4Status']); ?>
    <?php echo smarty_function_input_row(array('label' => 'Start Application-4','id' => 'app4Radio','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app4Status'],'type' => 'radio','options' => "1-Enable,0-Disable",'selectCondition' => "==".($this->_tpl_vars['app4Status'])), $this);?>


<?php echo smarty_function_input_row(array('label' => 'Select Application-4 to upload','id' => 'application4File','class' => 'input','name' => 'application4File','type' => 'file','oncontextmenu' => 'return false','onkeydown' => "this.blur()",'onpaste' => 'return false'), $this);?>

<?php// echo smarty_function_input_row(array('label' => '','id' => 'app4FileName','name' => $this->_tpl_vars['parentStr']['applicationSettings']['app4FileName'],'type' => 'hidden','class' => 'input','value' => $this->_tpl_vars['data']['applicationSettings']['app4FileName'],'size' => '30','maxlength' => '29'), $this);?>

</td></tr>
</table>
</div>
<!-- APPLICATION 4 ENDING HERE -->
				</td>
					<td class="subSectionBodyDotRight">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" class="subSectionBottom">&nbsp;</td>
				</tr>
			</table>
		</td>
	</tr>
	</table>
     </td>
</tr>
