conf_set system:basicSettings:cloudStatus $1
conf_save
