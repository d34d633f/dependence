#!/bin/ash

#TODO:
#	I using many temp file to save the status and data,
#	if you have enough energy please help to modify it
#	to the best way.
#					Ralph H. 2016/05/23

#database
bwc_file="/tmp/bwc_mac_list" #FORMAT: MAC Interface if_num
bwc_fwid_file="/tmp/bwc_fwid_list" #FORMAT: MAC flowid iface ip(for tunnel)
#tmp files
bwc_new_file="/tmp/bwc_mac_list.new"
bwc_tmp_file="/tmp/bwc_mac_list.tmp"
bwc_tcpdump_tmp_file="/tmp/bwc_tcpdump.tmp"
#switch
get_bwc_disabled=$(uci get qcawifi.etc.bwc_disabled)
get_cp_enabled=$(uci get coova.chilli.Enable)
#interface
captive_portal_list=$(uci get coova.chilli.WifiList 2>&-)
cp_max=0
lan_if="eth0" #LAN PORT
#lock
bwc_lock="/tmp/bwc.lock"
#multi ethernet interface
multi_eth=0

# Ralph H.:
# tc rate limit have 2 way:
# 1. LAN to wifi (l2w)
# 2. wifi to LAN (w2l)
# If captive portal is enabled:
# 1. all package will send out via tunnel
# 2. iptables/ebtables/tcpdump can not filter MAC at tunnel

for i in $captive_portal_list
do
	cp_max=$(($cp_max+1))
done

check_multi_eth() {
	for i in $(seq 1 5)
	do
		if [ -d "/proc/sys/net/ipv4/conf/eth${i}" ]; then
			multi_eth=$(($multi_eth+1))
		fi
	done
}

init_rule() {
	#lan, for bridge
	lan_rate_max=$(uci get qcawifi.etc.bwc_w2l_max)
	tc qdisc del dev $lan_if root
	tc qdisc add dev $lan_if root handle 1:0 htb default 1
	tc class add dev $lan_if parent 1:0 classid 1:1 htb rate ${lan_rate_max}bit

	#for AP, multi-ethernet interface
	if [ ! $multi_eth = 0 ]; then
		for i in $(seq 1 $(($multi_eth)))
		do
			tc qdisc del dev eth$i root
			tc qdisc add dev eth$i root handle $((30+$i)):0 htb default 1
			tc class add dev eth$i parent $((30+$i)):0 classid $((30+$i)):1 htb rate ${lan_rate_max}bit
		done
	fi

	if [ "$get_cp_enabled" = "1" ]; then
		#lan to wifi, for tunnel
		for i in $(seq 0 $((cp_max-1)))
		do
			tc qdisc del dev tun$i root
			tc qdisc add dev tun$i root handle $(($i+1))"00":0 htb default 1
			tc class add dev tun$i parent $(($i+1))"00":0 classid $(($i+1))"00":1 htb rate ${lan_rate_max}bit
		done
	fi

	for i in $(seq 0 23)
	do
		get_wifi_up=$(uci -p /var/state get qcawifi.@wifi-iface[${i}].up 2>&-)
		get_bwc_disabled=$(uci get qcawifi.@wifi-iface[${i}].bwc_disabled 2>&-)
		if [ "$get_wifi_up" = "1" -a "$get_bwc_disabled" = "0" ];then
			get_rate_max=$(uci get qcawifi.@wifi-iface[${i}].bwc_l2w_max)
			if [ ! "$get_rate_max" = "" ]; then
				id=$(($i+2))
				iface=$(uci -p /var/state get qcawifi.@wifi-iface[${i}].ifname 2>&-)
				tc qdisc del dev $iface root
				tc qdisc add dev $iface root handle $id:0 htb default 1
				tc class add dev $iface parent $id:0 classid $id:1 htb rate ${get_rate_max}bit
			fi
		fi
	done

}

add_mac() {
	sed -i s/\+//g $bwc_tmp_file
	while read line;
	do
		if [ "$line" = "" ]; then
			continue
		fi
		mac=$(echo ${line} | cut -d " " -f1 | tr A-Z a-z)
		iface=$(echo ${line} | cut -d " " -f2)
		if_id=$(echo ${line} | cut -d " " -f3)
		l2w_rate_limit=$(uci get qcawifi.@wifi-iface[${if_id}].bwc_l2w_limit)
		w2l_rate_limit=$(uci get qcawifi.@wifi-iface[${if_id}].bwc_w2l_limit)
		id=$(($if_id+2))

		#set flowid, start from 100
		#example: N=lan to wifi flowid, N+1=wifi to lan flowid
		for i in $(seq 100 2 600)
		do
			fw_id=$(grep ${i} ${bwc_fwid_file} 2>&-)
			if [ "$fw_id" = "" ]; then
				fw_id=$i
				echo $mac $i $iface >> $bwc_fwid_file
				break
			fi
		done

		if [ ! "$mac" = "" -a ! "$iface" = "" ]; then
			#LAN to wifi
			tc class add dev $iface parent $id:1 classid $id:$fw_id htb rate ${l2w_rate_limit}bit
			tc filter add dev $iface parent $id:0 protocol all handle $fw_id fw flowid $id:$fw_id
			ebtables -t broute -I bandwidth_control -d ${mac} -j mark --set-mark ${fw_id} --mark-target ACCEPT
			#wifi to LAN
			tc class add dev $lan_if parent 1:1 classid 1:$(($fw_id+1)) htb rate ${w2l_rate_limit}bit
			tc filter add dev $lan_if parent 1:0 protocol all handle $(($fw_id+1)) fw flowid 1:$(($fw_id+1))
			ebtables -t broute -I bandwidth_control -s ${mac} -j mark --set-mark $(($fw_id+1)) --mark-target ACCEPT

			#for AP, multi-ethernet interface
			if [ ! $multi_eth = 0 ]; then
				for i in $(seq 1 $multi_eth)
				do
					tc class add dev eth$i parent $((30+$i)):1 classid $((30+$i)):$(($fw_id+1000+$i)) htb rate ${w2l_rate_limit}bit
					tc filter add dev eth$i parent $((30+$i)):0 protocol all handle $(($fw_id+$i)) fw flowid $((30+$i)):$(($fw_id+1000+$i))
				done
			fi

			find_tun_by_iface $iface
			cp_count=$?
			if [ "$get_cp_enabled" = "1" -a ! $cp_count = 99 ]; then
				#LAN to wifi, for tunnel
				tc class add dev tun$cp_count parent $((cp_count+1))"00":1 classid $((cp_count+1))"00":$fw_id htb rate ${l2w_rate_limit}bit
				tc filter add dev tun$cp_count parent $((cp_count+1))"00":0 protocol all handle $fw_id fw flowid $((cp_count+1))"00":$fw_id
				#wifi to LAN, for tunnel
				tc class add dev tun$cp_count parent $((cp_count+1))"00":1 classid $((cp_count+1))"00":$(($fw_id+1)) htb rate ${w2l_rate_limit}bit
				tc filter add dev tun$cp_count parent $((cp_count+1))"00":0 protocol all handle $(($fw_id+1)) fw flowid $((cp_count+1))"00":$(($fw_id+1))
			fi
		fi
	done < $bwc_tmp_file
}

del_mac() {
	sed -i s/\-//g $bwc_tmp_file
	while read line;
	do
		if [ "$line" = "" ]; then
			continue
		fi
		mac=$(echo ${line} | cut -d " " -f1 | tr A-Z a-z)
		iface=$(echo ${line} | cut -d " " -f2)
		if_id=$(echo ${line} | cut -d " " -f3)
		l2w_rate_limit=$(uci get qcawifi.@wifi-iface[${if_id}].bwc_l2w_limit)
		w2l_rate_limit=$(uci get qcawifi.@wifi-iface[${if_id}].bwc_w2l_limit)
		id=$(($if_id+2))
		fw_id=$(grep ${mac} ${bwc_fwid_file} | grep ${iface} | cut -d " " -f2)
		
		if [ ! "$mac" = "" -a ! "$iface" = "" -a ! "$fw_id" = "" ]; then
			#LAN to wifi
			get_prio_id=$(tc -s filter show dev ${iface} | grep "${id}:${fw_id}" | sed s/".*pref "//g | sed s/" fw.*"//g)
			tc filter del dev $iface parent $id: prio $get_prio_id
			tc class del dev $iface parent $id:1 classid $id:$fw_id htb rate ${l2w_rate_limit}bit
			ebtables -t broute -D bandwidth_control -d ${mac} -j mark --set-mark ${fw_id} --mark-target ACCEPT
			#wifi to LAN
			get_prio_id=$(tc -s filter show dev ${lan_if} | grep "1:$(($fw_id+1))" | sed s/".*pref "//g | sed s/" fw.*"//g)
			tc filter del dev $lan_if parent 1: prio $get_prio_id
			tc class del dev $lan_if parent 1:1 classid 1:$(($fw_id+1)) htb rate ${w2l_rate_limit}bit
			ebtables -t broute -D bandwidth_control -s ${mac} -j mark --set-mark $(($fw_id+1)) --mark-target ACCEPT

			#for AP, multi-ethernet interface
			if [ ! $multi_eth = 0 ]; then
				for i in $(seq 1 $multi_eth)
				do
					get_prio_id=$(tc -s filter show dev eth${i} | grep "$((30+$i)):$(($fw_id+1000+$i))" | sed s/".*pref "//g | sed s/" fw.*"//g)
					tc filter del dev eth$i parent $((30+$i)): prio $get_prio_id
					tc class del dev eth$i parent $((30+$i)):1 classid $((30+$i)):$(($fw_id+1000+$i)) htb rate ${w2l_rate_limit}bit
				done
			fi

			find_tun_by_iface $iface
			cp_count=$?
			if [ "$get_cp_enabled" = "1" -a ! $cp_count = 99 ]; then
				sta_ip=$(grep ${mac} ${bwc_fwid_file} | grep ${iface} | cut -d " " -f4)
				#LAN to wifi, for tunnel
				get_prio_id_tun=$(tc -s filter show dev tun${cp_count} | grep "$(($cp_count+1))'00':${fw_id}" | sed s/".*pref "//g | sed s/" fw.*"//g)
				tc filter del dev tun$cp_count parent $(($cp_count+1))"00": prio $get_prio_id_tun
				tc class del dev tun$cp_count parent $(($cp_count+1))"00":1 classid $(($cp_count+1))"00":$fw_id htb rate ${l2w_rate_limit}bit
				get_prio_id_tun=$(tc -s filter show dev tun$cp_count | grep "$(($cp_count+1))'00':$(($fw_id+1))" | sed s/".*pref "//g | sed s/" fw.*"//g)
				#wifi to LAN, for tunnel
				tc filter del dev tun$cp_count parent $(($cp_count+1))"00": prio $get_prio_id_tun
				tc class del dev tun$cp_count parent $(($cp_count+1))"00":1 classid $(($cp_count+1))"00":$(($fw_id+1)) htb rate ${l2w_rate_limit}bit
				if [ ! "$sta_ip" = "" ]; then
					iptables -t mangle -D bandwidth_control -o tun$cp_count -d $sta_ip -j MARK --set-mark $fw_id
					iptables -t mangle -D bandwidth_control -i tun$cp_count -s $sta_ip -j MARK --set-mark $(($fw_id+1))
				fi
			fi
			sed -i /${mac}/d $bwc_fwid_file
		fi
	done < $bwc_tmp_file
}

scan_if() {
	if [ -f $bwc_tmp_file ]; then
		rm $bwc_tmp_file
	fi

	for i in $(seq 0 23)
	do
		get_wifi_up=$(uci -p /var/state get qcawifi.@wifi-iface[${i}].up 2>&-)
		get_fn_disabled=$(uci get qcawifi.@wifi-iface[${i}].bwc_disabled 2>&-)
		l2w_rate_limit=$(uci get qcawifi.@wifi-iface[${i}].bwc_l2w_limit 2>&-)
		if [ "$get_wifi_up" = "1" -a "$get_fn_disabled" = "0" -a ! "$l2w_rate_limit" = "auto" ]; then
			ath=$(uci -p /var/state get qcawifi.@wifi-iface[${i}].ifname 2>&-)
			sta_list=$(iwinfo ${ath} assoclist | grep dBm | tr A-Z a-z)
			if [ ! "$sta_list" = "" ]; then
				#find MAC, we just interested in which client is connected.
				echo $sta_list > $bwc_new_file
				sed -i s/"ago "/\\n/g $bwc_new_file
				#format: MAC ATH id
				sed -i s/" .*"/" ${ath} $i"/g $bwc_new_file
				cat $bwc_new_file >> $bwc_tmp_file
			fi
		fi
	done
	#sort MAC
	if [ -f $bwc_tmp_file ]; then
		sort $bwc_tmp_file > $bwc_new_file
		rm $bwc_tmp_file
	else
		echo "" > $bwc_new_file
	fi
}

check_mac() {
	#first time to scan
	if [ ! -f $bwc_file -a -f $bwc_new_file ]; then
		#Remove invalid MAC Address
		sed -i '/.*00:00:00:00:00:00.*/'d $bwc_new_file
		cp $bwc_new_file $bwc_tmp_file
		add_mac
	elif [ -f $bwc_file -a -f $bwc_new_file ]; then
		#Remove invalid MAC Address
		sed -i '/.*00:00:00:00:00:00.*/'d $bwc_new_file
		sed -i '/.*00:00:00:00:00:00.*/'d $bwc_file
		diff $bwc_file $bwc_new_file | sed '1,3d' |grep "-" > $bwc_tmp_file
		del_mac
		diff $bwc_file $bwc_new_file | sed '1,3d' |grep "+" > $bwc_tmp_file
		add_mac
	fi

	if [ -f $bwc_new_file ]; then
		mv $bwc_new_file $bwc_file
	fi
}

get_ip_from_mac() {
	#remove all tmp file
	if [ -f $bwc_tcpdump_tmp_file ]; then
		rm $bwc_tcpdump_tmp_file
	fi

	if [ -f $bwc_tmp_file ]; then
		rm $bwc_tmp_file
	fi

	while read line;
	do
		mac=$(echo ${line} | cut -d " " -f1 | tr A-Z a-z) #upper to lower for grep tcpdump
		fw_id=$(echo ${line} | cut -d " " -f2)
		iface=$(echo ${line} | cut -d " " -f3)
		sta_ip=$(echo ${line} | cut -d " " -f4)

		find_tun_by_iface $iface
		cp_count=$?

		#get ip from mac by tcpdump
		if [ "$get_cp_enabled" = "1" -a "$sta_ip" = "" -a ! "$mac" = "" -a ! $cp_count = 99 ]; then
                        tcpdump -e -nni $iface ether host $mac -c 5 >> $bwc_tcpdump_tmp_file &
			sleep 1
			killall tcpdump 2>&-
			sta_ip=$(grep -i "${mac} >" ${bwc_tcpdump_tmp_file} | grep -o '\([0-9]\{1,3\}\.\)\{3\}[0-9]\{1,3\}' | sed '2,10d' 2>&-)
			rm $bwc_tcpdump_tmp_file 2>&-
			if [ ! "$sta_ip" = "" ]; then
				ip_d1=$(echo ${sta_ip} | cut -d "." -f1)
				ip_d2=$(echo ${sta_ip} | cut -d "." -f2)
				ip_d3=$(echo ${sta_ip} | cut -d "." -f3)
				ip_d4=$(echo ${sta_ip} | cut -d "." -f4)
				#check ip is valid, ignore 169.254
				if [ ! "$ip_d1" = "169" -a ! "$ip_d2" = "254" ]; then
					iptables -t mangle -I bandwidth_control -o tun$cp_count -d $sta_ip -j MARK --set-mark $fw_id
					iptables -t mangle -I bandwidth_control -i tun$cp_count -s $sta_ip -j MARK --set-mark $(($fw_id+1))
				fi
			fi
                fi

		echo $mac $fw_id $iface $sta_ip >> $bwc_tmp_file
	done < $bwc_fwid_file
	#update sta ip
	if [ -f $bwc_tmp_file ]; then
		mv $bwc_tmp_file $bwc_fwid_file
	fi
}

find_tun_by_iface() {
	cp_count=0
	for i in $captive_portal_list
	do
		if [ "$i" = "$1" ]; then
			return $cp_count;
		fi
		cp_count=$(($cp_count+1))
	done
	return 99;
}

del_iptables_rule() {
	iptables -t mangle -nvL bandwidth_control | grep MARK > $bwc_tmp_file
	while read line;
	do
		iptables -t mangle -D bandwidth_control 1
	done < $bwc_tmp_file
	rm $bwc_tmp_file
}

reset_all_rule() {
	rm $bwc_file $bwc_fwid_file $bwc_new_file $bwc_tmp_file
	init_rule
	ebtables -t broute -F bandwidth_control
	iptables -t mangle -F bandwidth_control
	#del_iptables_rule
}

#main
if [ $get_bwc_disabled -eq 1 ]; then
	exit
fi

if [ -f $bwc_lock ]; then
	echo "Bandwidth control: Working, now is locking!"
	exit
fi

if [ "$1" = "reset" ]; then
	reset_all_rule
fi

check_multi_eth

if [ "$1" = "init" ]; then
	init_rule
else
	touch $bwc_lock
	scan_if
	check_mac
	get_ip_from_mac
	rm $bwc_lock
fi
