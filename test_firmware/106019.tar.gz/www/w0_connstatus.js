<!--# exec cgi /bin/mjson wifi_iface @=wifi0_vap* up=1 mode=sta -->
