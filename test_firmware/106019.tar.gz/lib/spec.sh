#!/bin/sh

get_spec_opt()
{
#echo $1 > /dev/ttyS0
lua - <<LUA_END
#!/usr/bin/lua
  require("nixio.fs");s=require("luci.spec")
  --print(s.spec_table.tc_outgoing_for_each_individual_ssid)
  opt={0,0,0,0,0,0,0,0,0,0}
  
  arg_pstr="$1"

  if arg_pstr~="all" then
    print(s.spec_table.$1)
  else
    if s.spec_table.tc_outgoing_for_each_individual_ssid==1 then opt[1]=1; end
    specopt=table.concat(opt,",")
    print(specopt)
  end
LUA_END
}

get_opmode()
{
    wifi_dev=$1
    
    #Single Radio
    #uci get network.sys.opmode|sed -e "s/'//g"

    #Dual Radio
    #uci get wireless.$1.opmode|sed -e "s/'//g"
    echo ap
}

get_w2g_w5g_phy_map()
{
	local wifi_dev=$1
	
	case "${wifi_dev}" in
		wifi0)
			local wifi0phy=$(get_spec_opt "wifi_list['phy2G']")
			echo "${wifi0phy}";;
		wifi1)
			local wifi1phy=$(get_spec_opt "wifi_list['phy5G']")
			echo "${wifi1phy}";;
		wifi2g)
			local wifi2gphy=$(get_spec_opt "wifi_list['phy2G']")
			echo "${wifi2gphy}";;
		wifi5g)
			local wifi5gphy=$(get_spec_opt "wifi_list['phy5G']")
			echo "${wifi5gphy}";;
		*) 
			echo "w2g_w5g_phy_map: unknown wifi_dev '${wifi_dev}'" > /dev/ttyS0 
		;;
	esac
}

get_wifi_cfg_list()
{
	get_spec_opt wifi_cfg_list_seq_str
}

get_modelname()
{
	cat /etc/modelname
}

#case $1 in
#	get_spec_opt)      get_spec_opt "$2" ;;
#esac


