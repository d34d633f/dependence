#!/bin/sh


# status: 22(not work)/14
# internet: 1/4/15(SW control enabled[1]/blue/orange)
# LAN1
# LAN2
# LAN3
# WiFi: 16 Controlled by gpio.c
# USB: 
# PWR: 11
# Status: 17
# WPS: 0
#
gpio_led_init() {
	insmod /lib/modules/$(uname -r)/kernel/arch/mips/atheros/ar934x_gpio.ko
	#Disable the JTAG function
	mm 0xb804006c 0x00000042 
	for i in 0 1 4 11 15 17 ;do
		echo $i > /sys/class/gpio/export
		echo out > /sys/class/gpio/gpio$i/direction
		echo 0 > /sys/class/gpio/gpio$i/value
		echo 1 > /sys/class/gpio/gpio$i/value
		
		#keep status led on.
		if [ $i = 17 ] ; then
			echo 0 > /sys/class/gpio/gpio$i/value
		fi
	done
}
gpio_on()
{
	echo 0 > /sys/class/gpio/gpio$1/value
}

gpio_off()
{
	echo 1 > /sys/class/gpio/gpio$1/value
}

led_internet_sw()
{
	gpio_off 15
	gpio_off 4
	gpio_off 1
}

led_internet_hw()
{
	gpio_on 15
	gpio_off 4
	gpio_off 1
}

case $1 in
on)
	gpio_on $2
	;;
off)
	gpio_off $2
	;;
led_internet_hw)
	led_internet_hw
	;;
led_internet_sw)
	led_internet_sw
	;;
SWITCH_CONTROL)
	if [ "$2" = "off" ];then
		led_internet_sw
	else
		led_internet_hw
	fi
	;;
INTERNET_LED)
	if [ "$2" = "off" ];then
		if [ "$3" = "green" ];then
			gpio_off 4
		else
			gpio_off 1
		fi
	else
		if [ "$3" = "green" ];then
			gpio_on 4
		else
			gpio_on 1
		fi
	fi
	;;
start)
	gpio_led_init
	echo 13 > /sys/module/ar934x_gpio/parameters/export_int
	;;
*)
	echo "$0 [start] to initial gpio driver at booting"
	echo "$0 [on|off <num>] to control gpio"
	echo "$0 [led_internet_hw|led_internet_sw] to switch internet gpio"
	;;
esac
