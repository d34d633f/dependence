#!/bin/sh

DNICONFIG=/bin/config
WIFI0=ra0
WIFI1=rai0

clear_wifi_ebtables(){
ETH_P_ARP=0x0806
ETH_P_RARP=0x8035
ETH_P_IP=0x0800
IPPROTO_ICMP=1
IPPROTO_UDP=17
DHCPS_DHCPC=67:68
PORT_DNS=53

ebtables -D FORWARD -p $ETH_P_ARP -j ACCEPT
ebtables -D FORWARD -p $ETH_P_RARP -j ACCEPT
ebtables -D FORWARD -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $DHCPS_DHCPC -j ACCEPT
ebtables -D INPUT -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $DHCPS_DHCPC -j ACCEPT
ebtables -D INPUT -p $ETH_P_IP --ip-proto $IPPROTO_UDP --ip-dport $PORT_DNS -j ACCEPT

ebtables -L | grep  "ra" > /tmp/wifi_rules
while read loop
        do
		ebtables -D INPUT $loop;
		ebtables -D FORWARD $loop;
        done < /tmp/wifi_rules

}
enable_ralink11n() {

    [ -f /etc/board.conf ] && . /etc/board.conf
    update-wifi;
    if [ "$wlg_exist" = "on" ]; then
        wlg_radio=`ifconfig $WIFI0 | grep "UP"`
        if [ -n "$wlg_radio" ]; then
            cat /proc/uptime | sed 's/ .*//' > /tmp/WLAN_uptime
            # Turn on wlan LED (2.4G) if wlan LED is controled by 'ledcontrol'
            [ $WLAN_LED_CONTROL -eq 1 ] && /sbin/ledcontrol -n wlan -c blue -s on
        fi
    fi
    if [ "$wla_exist" = "on" ]; then
        wla_radio=`ifconfig $WIFI1 | grep "UP"`
        if [ -n "$wla_radio" ]; then
            cat /proc/uptime | sed 's/ .*//' > /tmp/WLAN_uptime_5G
            # Turn on wlan LED (5G) if wlan LED is controled by 'ledcontrol'
            [ $WLAN_LED_CONTROL -eq 1 ] && /sbin/ledcontrol -n wlan -c blue -s on
        fi
    fi

    # restart iptv file, to make wireless port join into br1
    if [ $WLAN_IPTV_SUPPORT -eq 1 -a -f /etc/init.d/net-iptv ]; then
        /etc/init.d/net-iptv start
    fi
}

disable_ralink11n() {

    [ -f /etc/board.conf ] && . /etc/board.conf
    #when wlan down killall the wscd progress,after wlan up will enable it if neccessary
    killall wscd
    # If WPS led is blinking, just stop it.
    test -f /var/run/wps_led.pid && {
        kill $(cat /var/run/wps_led.pid)
        /sbin/ledcontrol -n wps -c green -s off
        rm -f /var/run/wps_led.pid
    }
    wpsled wps_lock_down off;
    /sbin/apdown;
    [ "on" = "${ebtables_exist}" ] && clear_wifi_ebtables;
    rm -f /tmp/WLAN_uptime*
    # Turn off wlan LED if wlan LED is controled by 'ledcontrol'
    if [ $WLAN_LED_CONTROL -eq 1 ]; then
        /sbin/ledcontrol -n wlan -c blue -s off
    fi
}

update_config()
{
    local val
    case "$1" in
        on)
            val=1;
            ;;
        *)
            val=0;
            ;;
    esac

    $DNICONFIG set endis_wl_radio=$val
    if [ $NUM_RADIO -eq 2 ]; then
        $DNICONFIG set endis_wla_radio=$val
    fi
    $DNICONFIG commit
}

wifitoggle_ralink11n() {

    WIFI_TOGGLE_LOCK_FILE=/tmp/.wifi_toggle_lock
    [ -f /etc/board.conf ] && . /etc/board.conf
    if [ "$wlg_exist" = "on" -a "$wla_exist" = "on" ]; then
        NUM_RADIO=2
    else
        NUM_RADIO=1
    fi
    MAX_VAP=2

    if [ -f $WIFI_TOGGLE_LOCK_FILE ]; then
    # Just exit if previous wifi toggle is not done.
        exit
    fi
    touch $WIFI_TOGGLE_LOCK_FILE

    active_radio=0
    num=0
    VAPLIST=`iwconfig | grep ra | cut -f1 -d' '` 
    for i in $VAPLIST; do
    # check if wifi interface is up.
        radio_status=`ifconfig | grep $i`
        if [ "x$radio_status" != "x" ]; then
        # if interface is up, increate active_radio counter.
            active_radio=`expr $active_radio + 1`
        fi
        num=`expr $num + 1`
    done

    if [ $active_radio -eq 0 ]; then
        NEXT_STATE=on
    else
    # if any one radio is down, then next action is to turn off every radio.
        NEXT_STATE=off
    fi

    echo "Turn Radio to $NEXT_STATE"

    # wps led should be turn on if security is not none and wireless is switch on
    if [ $NUM_RADIO -eq 1 ]; then
        WPS_LED_OFF='echo 1 > /proc/simple_config/simple_config_led'
        WPS_LED_ON='echo 2 > /proc/simple_config/simple_config_led'
    else
        WPS_LED_OFF='echo 0 > /proc/simple_config/tricolor_led'
        WPS_LED_ON='echo 1 > /proc/simple_config/tricolor_led'
    fi
    [ "$wlg_exist" = "on" ] && G_SECURITY_TYPE=`$DNICONFIG get wl_sectype`
    [ "$wla_exist" = "on" ] && A_SECURITY_TYPE=`$DNICONFIG get wla_sectype`

    if [ "$NEXT_STATE" = "on" ]; then
        num=0
        while [ $num -lt $MAX_VAP ]; do
            vap_status=`ifconfig -a | grep ra$num`
            if [ "x$vap_status" != "x" ]; then
                ifconfig ra$num up 2>&1 > /dev/null
            fi
            num=`expr $num + 1`
        done
        num=0
        while [ $num -lt $MAX_VAP ]; do
            vap_status=`ifconfig -a | grep rai$num`
            if [ "x$vap_status" != "x" ]; then
                ifconfig rai$num up 2>&1 > /dev/null
            fi
            num=`expr $num + 1`
        done
        if [ $NUM_RADIO -eq 1 ]; then
            [ "${G_SECURITY_TYPE}" -gt "1" ] && eval ${WPS_LED_ON} || eval ${WPS_LED_OFF}
        else
            [ "${G_SECURITY_TYPE}" -gt "1" -o "${A_SECURITY_TYPE}" -gt "1" ] && eval ${WPS_LED_ON} || eval ${WPS_LED_OFF}
        fi

        if [ "$wlg_exist" = "on" ]; then
            cat /proc/uptime | sed 's/ .*//' > /tmp/WLAN_uptime
            # Turn on wlan LED (2.4G) if wlan LED is controled by 'ledcontrol'
            [ $WLAN_LED_CONTROL -eq 1 ] && /sbin/ledcontrol -n wlan -c blue -s on
        fi
        if [ "$wla_exist" = "on" ]; then
            cat /proc/uptime | sed 's/ .*//' > /tmp/WLAN_uptime_5G
            # Turn on wlan LED (5G) if wlan LED is controled by 'ledcontrol'
            [ $WLAN_LED_CONTROL -eq 1 ] && /sbin/ledcontrol -n wlan -c blue -s on
        fi
    else
        #to solve bug 35086,when call the command wlan toggle,if it will turn off the wireless radio,
        #then set /tmp/wps_process_state value NULL.
        echo "" > /tmp/wps_process_state
        num=0
        while [ $num -lt $MAX_VAP ]; do
            vap_status=`ifconfig | grep ra$num`
            if [ "x$vap_status" != "x" ]; then
                ifconfig ra$num down 2>&1 > /dev/null
            fi
            num=`expr $num + 1`
        done
        num=0
        while [ $num -lt $MAX_VAP ]; do
            vap_status=`ifconfig | grep rai$num`
	    if [ "x$vap_status" != "x" ]; then
                ifconfig rai$num down 2>&1 > /dev/null
            fi
	    num=`expr $num + 1`
	done
        if [ $NUM_RADIO -eq 1 ]; then
            [ -n "${G_SECURITY_TYPE}" ] && eval ${WPS_LED_OFF}
        else
            [ -n "${G_SECURITY_TYPE}" -a -n "${A_SECURITY_TYPE}" ] && eval ${WPS_LED_OFF}
        fi
        test -f /var/run/wps_led.pid && {
            kill $(cat /var/run/wps_led.pid)
            /sbin/ledcontrol -n wps -c green -s off
            rm -f /var/run/wps_led.pid
        }
        rm -f /tmp/WLAN_uptime*
        # Turn off wlan LED if wlan LED is controled by 'ledcontrol'
        if [ $WLAN_LED_CONTROL -eq 1 ]; then
            /sbin/ledcontrol -n wlan -c blue -s off
        fi
    fi

    update_config $NEXT_STATE

    rm $WIFI_TOGGLE_LOCK_FILE
}

wifischedule_ralink11n_new() {
    local band=$2               # 11g/11a
    local newstate=$3           # on/off

    [ -z "$band" -o -z "$newstate" ] && return

    [ -f /etc/board.conf ] && . /etc/board.conf
    if [ "$band" = "11g" ]; then
        tmp_mode=`$DNICONFIG get wl_conf_mode` 
        if [ "$newstate" = "off" ]; then
              $DNICONFIG set limit_internet=1
              if [ "x$tmp_mode" = "x2" ]; then
			echo "1">/proc/sys/net/ipv4/access_schedule
              fi
        else
              $DNICONFIG set limit_internet=0
              echo "0">/proc/sys/net/ipv4/access_schedule
        fi
    fi
    $DNICONFIG commit
}

wifischedule_ralink11n() {
    local band=$2               # 11g/11a
    local newstate=$3           # on/off

    [ -z "$band" -o -z "$newstate" ] && return

    [ -f /etc/board.conf ] && . /etc/board.conf
    if [ "$wlg_exist" = "on" -a "$wla_exist" = "on" ]; then
        NUM_RADIO=2
    else
        NUM_RADIO=1
    fi
    MAX_VAP=2

    if [ "$band" = "11g" ];then
        # for 802.11g
        if [ "$wlg_exist" != "on" ];then
            return;
        fi
        sched_status=wlg_onoff_sched
        on_off=endis_wl_radio
        hw_wifi=ra0
        vap_prefix=ra	
        wifi_uptime_file=/tmp/WLAN_uptime
        log_message="2.4G"
    else
        # for 802.11a
        if [ "$wla_exist" != "on" ];then
            return
        fi
        sched_status=wla_onoff_sched
        on_off=endis_wla_radio
        if [ $NUM_RADIO -eq 2 ];then
            hw_wifi=rai0
        else
            hw_wifi=ra0
        fi
        vap_prefix=rai
        search_mode="IEEE 802.11na|IEEE 802.11a"
        wifi_uptime_file=/tmp/WLAN_uptime5G
        log_message="5G"
    fi

    WIFI_SCHED_LOCK_FILE=/tmp/.wifi_sched_lock_$band
    if [ -f $WIFI_SCHED_LOCK_FILE ]; then
       # Just exit
        return
    fi
    touch $WIFI_SCHED_LOCK_FILE

    #when NTP is off, wireless schedule run its default setting
    #(No schedule to turn off the wireless signal)
    if [ -f /tmp/ntp_updated ];then
        ntp_success=1
    else
        ntp_success=1
    fi

    if [ $NUM_RADIO -eq 1 ]; then
        WPS_LED_OFF='echo 1 > /proc/simple_config/simple_config_led'
        WPS_LED_ON='/sbin/ledcontrol -n wps -c green -s on; echo 2 > /proc/simple_config/simple_config_led'
    else
    # wps led should be turn on if security is not none and wireless is switch on
        WPS_LED_OFF='echo 0 > /proc/simple_config/tricolor_led'
    #sometimes we will call /sbin/ledcontrol -n wps -c green -s off, at this time if we want to turn on wps led,
    #we should first call ledcontrol to turn on wps led first
        WPS_LED_ON='/sbin/ledcontrol -n wps -c green -s on; echo 1 > /proc/simple_config/tricolor_led'
    fi

    [ "$wlg_exist" = "on" ] && G_SECURITY_TYPE=`$DNICONFIG get wl_sectype`
    [ "$wla_exist" = "on" ] && A_SECURITY_TYPE=`$DNICONFIG get wla_sectype`

    radio_status=`ifconfig | grep $hw_wifi`

    if [ "$newstate" = "on" ]; then
        if [ "x$radio_status"  != "x" ];then
            rm $WIFI_SCHED_LOCK_FILE
            return
        fi
        # if NTP fail, just turn on do not check the overlop time
        if [ $ntp_success -eq 1 ];then
        # It will check whether the now time should turn on wireless.
        # if no, it will set wlg_onoff_sched to 1, or it will set to 0.
        # Then we will check wlg_onoff_sched value, to decide whether to
        # turn on wireles or just exit
            /sbin/cmdsched_wlan_status $band
            wl_off=`$DNICONFIG get ${sched_status}`
        fi
        $DNICONFIG set ${on_off}=1
        $DNICONFIG commit
        $DNICONFIG set ${sched_status}=0
        num=0
        while [ $num -lt $MAX_VAP ]; do
            vap=$vap_prefix$num
            vap_status=`ifconfig -a | grep $vap`
            if [ "x$vap_status" != "x" ]; then
                    ifconfig $vap up 2>&1 > /dev/null
            fi
            num=`expr $num + 1`
        done

        if [ $NUM_RADIO -eq 2 ];then
           #if one of the radio with security is up,we should turn on WPS LED
            [ "${G_SECURITY_TYPE}" -gt "1" -a "x`ifconfig | grep wifi0`" != "x" -o "${A_SECURITY_TYPE}" -gt "1" -a "x`ifconfig | grep wifi1`" != "x" ] && eval ${WPS_LED_ON} || eval ${WPS_LED_OFF}
            logger "[wireless signal schedule] The $log_message wireless signal is ON,"
        else
            [ "${G_SECURITY_TYPE}" -gt "1" -o "${A_SECURITY_TYPE}" -gt "1" ] && eval ${WPS_LED_ON} || eval ${WPS_LED_OFF}
            logger "[wireless signal schedule] The wireless signal is ON,"
        fi

        cat /proc/uptime | sed 's/ .*//' > $wifi_uptime_file
        # Turn on wlan LED if wlan LED is controled by 'ledcontrol'
        if [ $WLAN_LED_CONTROL -eq 1 ]; then
            /sbin/ledcontrol -n wlan -c blue -s on
        fi
    else
        if [ $ntp_success = 0 -o "x$radio_status" = "x" ];then
            rm $WIFI_SCHED_LOCK_FILE
            return
        fi
        num=0
        while [ $num -lt $MAX_VAP ]; do
            vap=$vap_prefix$num	
            vap_status=`ifconfig | grep $vap`
            if [ "x$vap_status" != "x" ]; then
                    ifconfig $vap down 2>&1 > /dev/null
            fi
            num=`expr $num + 1`
        done
        $DNICONFIG set ${sched_status}=1
        $DNICONFIG set ${on_off}=0

        if [ $NUM_RADIO -eq 2 ];then
        # If none of the radio with security is up,we should turn off WPS led.
        # For wps_led.pid modification,it still has some issues, eg,2.4G radio
        # is with WPA security, 5G radio is in wps process,
        # we now is schedule 5G to off state,expected result we should stop
        # blink the wps led and keep wps led on.
        # Since we now can not check whether the WPS is for 2.4G or 5G, we will
        # just leave it blinking. This should be fixed in the future.

            if ! [ "${G_SECURITY_TYPE}" -gt "1" -a "x`ifconfig | grep wifi0`" != "x" -o "${A_SECURITY_TYPE}" -gt "1" -a "x`ifconfig | grep wifi1`" != "x" ];then
                eval ${WPS_LED_OFF}
                test -f /var/run/wps_led.pid && {
                    kill $(cat /var/run/wps_led.pid)
                    /sbin/ledcontrol -n wps -c green -s off
                    rm -f /var/run/wps_led.pid
                }
            fi
            logger "[wireless signal schedule] The $log_message wireless signal is OFF," 
        else
            [ "${G_SECURITY_TYPE}" -gt "1" -o "${A_SECURITY_TYPE}" -gt "1" ] && eval ${WPS_LED_OFF}
            test -f /var/run/wps_led.pid && {
                kill $(cat /var/run/wps_led.pid)
                /sbin/ledcontrol -n wps -c green -s off
                rm -f /var/run/wps_led.pid
            }
            logger "[wireless signal schedule] The wireless signal is OFF,"
        fi

        rm -f $wifi_uptime_file
        # Turn off wlan LED if wlan LED is controled by 'ledcontrol'
        if [ $WLAN_LED_CONTROL -eq 1 ]; then
            /sbin/ledcontrol -n wlan -c blue -s off
        fi
    fi

    rm $WIFI_SCHED_LOCK_FILE
}

wps_ralink11n() {
    local interface=$1
    if [ "$interface" = "ra0" ]; then
        local configured=`$DNICONFIG get wps_status`
    elif [ "$interface" = "rai0" ]; then
        local configured=`$DNICONFIG get wla_wps_status`
    fi
    if [ "$configured" = "5" ]; then
        configured=2
    fi
    shift 2
        case $1 in
            -c|--client_pin)
                if [ -n "$2" ]; then
                        iwpriv ${interface} set WscConfMode=0 1>/dev/null 2>&1
                        iwpriv ${interface} set WscConfMode=7
                        iwpriv ${interface} set WscConfStatus=$configured
                        sleep 1
			iwpriv ${interface} set WscMode=1
			iwpriv ${interface} set WscPinCode=$2
			iwpriv ${interface} set WscGetConf=1
			shift 2
                fi
                ;;
            -p|--pbc_start)
                iwpriv ${interface} set WscConfMode=0 1>/dev/null 2>&1
		iwpriv ${interface} set WscConfMode=7
		iwpriv ${interface} set WscConfStatus=$configured
		sleep 1
		iwpriv ${interface} set WscMode=2
		iwpriv ${interface} set WscGetConf=1
                shift
                ;;
            -s|--wps_stop)
                ledcontrol -n wps -c green -s off 2>/dev/null
                iwpriv ${interface} set WscConfMode=0 1>/dev/null 2>&1
		iwpriv ${interface} set WscConfMode=7
                shift
                ;;
            *)
                shift
                ;;
        esac
}

wifistainfo_ralink11n() {
    local device=$1
    local band=$2               # 11g/11a

    vap_prefix=ra
    for vif in `ifconfig | grep "\<$vap_prefix" | awk '{print $1}'`; do
        iwpriv ${vif} show sta
    done
    [ -f /proc/mt7620/wlstainfo ] && cat /proc/mt7620/wlstainfo | cut -f1 -d ';'
    [ -f /proc/mt7620/wlastainfo ] && cat /proc/mt7620/wlastainfo | cut -f1 -d ';'
}

wifiradio_ralink11n() {
    local band=$2               # 11g/11a

    if [ "$band" = "11g" ]; then
       vif=$WIFI0
    else
       vif=$WIFI1
    fi

    shift
    while [ "$#" -gt "0" ]; do
        case $1 in
            -s|--status)
                isup=`ifconfig $vif | grep UP`
                [ -n "$isup" ] && echo "ON" || echo "OFF"
                shift
                ;;
            -c|--channel)
                chan=`iwlist $vif chan | grep Current | awk -F '=' '{print $2}'`
                echo "$chan"
                shift
                ;;
            --coext)
                if [ "$2" = "on" ]; then
                    iwpriv $vif set HtBssCoex=1 
                else
                    iwpriv $vif set HtBssCoex=0
                fi
                shift 2
                ;;
            *)
                shift
                ;;
        esac
    done
}

