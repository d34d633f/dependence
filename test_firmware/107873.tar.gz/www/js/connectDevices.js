/**
 * For Connected Devices page.
 **/
(function ($) {

	"use strict";

	var checkNum = 0;
	var thisSegment = "";
	var checkDev = new Array();
	var name_ssid = new Array();
	var ip_address = new Array();
	var mac_address = new Array();
	var vmac_address = new Array();
	var number = 0;
	var count = 0;

	$.MAX_ACL_NUM = 64;

	$(function() {
		/*******************************************************************************************
		*
		*       Connected Devices page
		*
		******************************************************************************************/

		$.checkBoxs = function(id) {
			if($('#'+id).is(':checked') == true) {
				$('#'+id).prop('checked', true);
				$('#'+id).addClass('checked');
			} else {
				$('#'+id).prop('checked', false);
				$('#'+id).removeClass('checked');
			}
		}

		$.refreshAttachedDevices = function() {
			if ( !$('.running').length ) {
				$.submit_wait('.main:first', $.PAGE_WAITING_DIV);
			}
			$.getData("refresh_dev.aspx", function(json) {
				var newRow = "",
				i = 0,
				ip;
				$('tbody','.repeatDevices:first').html("");
				accessCtrlOn = json.acl_on;
				if ( accessCtrlOn == "0" ) {
					$('.wifiDevices:first').addClass("disAcl");
					$('#accessControl').prop('checked', false);
				} else {
					$('.wifiDevices:first').removeClass("disAcl");
					$('#accessControl').prop('checked', true);
				}
                                
				if ( json.extender.length > 0 ) {
					newRow = '<tr>';
					newRow += '<td><span class="tdLabel">'+lan_mark_ip+'</span>' + json.extender[0].ip + '</td>';
					newRow += '<td><span class="tdLabel">'+network_name+'</span>' + json.extender[0].name + '</td>';
					newRow += '<td><span class="tdLabel">'+qos_mac+'</span>' + json.extender[0].mac.toUpperCase() + '</td>';
					newRow += '<td><span class="tdLabel">'+virtual_macaddr+'</span>' + json.extender[0].vmac.toUpperCase() + '</td>';
					newRow += '</tr>';
					$('tbody','.repeatDevices:first').append(newRow);
				}
				$('tbody','.wiredDevices:first').html("");
				if ( json.wired.length > 0 ) {
					for ( i = 0; i < json.wired.length; i++ ) {
						newRow = '<tr>';
						newRow += '<td><span class="tdLabel">'+lan_mark_ip+'</span>' + json.wired[i].ip + '</td>';
						newRow += '<td><span class="tdLabel">'+network_name+'</span>' + json.wired[i].name + '</td>';
						newRow += '<td><span class="tdLabel">'+qos_mac+'</span>' + json.wired[i].mac.toUpperCase() + '</td>';
						newRow += '<td><span class="tdLabel">'+virtual_macaddr+'</span>' + json.wired[i].vmac.toUpperCase() + '</td>';
						newRow += '</tr>';
						$('tbody','.wiredDevices:first').append(newRow);
					}
				}
				$('tbody','.wifiDevices:first').html("");
				if ( json.wifi.length > 0 ) {
					for ( i = 0; i < json.wifi.length; i++ ) {
						if ( json.wifi[i].ip == "" ) {
							ip = block_mark;
						} else {
							ip = json.wifi[i].ip;
						}
						name_ssid[i] = json.wifi[i].name;
						ip_address[i] = ip;
						mac_address[i] = json.wifi[i].mac.toUpperCase();
						vmac_address[i] = json.wifi[i].vmac.toUpperCase();

						if ( accessCtrlOn == "0" && json.wifi[i].ip == "") {
							continue;
						}

						newRow = '<tr>';
						newRow += '<td><span class="tdLabel">'+lan_mark_ip+'</span>' + ip + '</td>';
						newRow += '<td><span class="tdLabel">'+network_name+'</span>' + json.wifi[i].name + '</td>';
						newRow += '<td><span class="tdLabel">'+qos_mac+'</span>' + json.wifi[i].mac.toUpperCase() + '</td>';
						newRow += '<td><span class="tdLabel">'+virtual_macaddr+'</span>' + json.wifi[i].vmac.toUpperCase() + '</td>';
						newRow += '<td><span class="tdLabel">'+deny_mark+'</span>';
						if ( json.wifi[i].action == "1" ) {
							newRow += '<input type="checkbox" id="wifiDev' + i + '" onClick="$.checkBoxs(this.id);" checked /><label class="wifidev" for="wifiDev' + i + '"></label></td>';
						} else {
							newRow += '<input type="checkbox" id="wifiDev' + i + '" onClick="$.checkBoxs(this.id);" /><label class="wifidev" for="wifiDev' + i + '"></label></td>';
						}
						newRow += '</tr>';
						$('tbody','.wifiDevices:first').append(newRow);
						$('<input type="hidden" name="wifiNewItem' + i + '" id="wifiNewItem' + i + '" value="" />').appendTo('tbody');
					}
					if ($('tbody','.wifiDevices:first').find('tr').length > 10 ) {
						$('#wifiDevicesDiv').addClass('limitDevicesHeight');
					} else {
						$('#wifiDevicesDiv').removeClass('limitDevicesHeight');
					}
					number = json.wifi.length;
				}
				$('.running').remove();
			});
		}

		if ( $('#connectDevicesForm').length ) {
			if(accessCtrlOn == "1") {
				$('#accessControl').prop('checked', true);
				$('.btn.primary').prop('disabled', false);
			} else {
				$('#accessControl').prop('checked', false);
				$('.btn.primary').prop('disabled', true);
			}

			$('#accessControl').change(function(){
				if ( $('#accessControl').is(':checked') == false ) {
					$('#accessCtrlToggle').val('0');
					$('.btn.primary').prop('disabled', true);
				} else {
					$('#accessCtrlToggle').val('1');
					$('.btn.primary').prop('disabled', false);
				}
				$.submit_wait('.main:first', $.PAGE_WAITING_DIV);
				$('input[name=submit_flag]', '#connectDevicesForm').val("wlacl_ctl");
				$.postForm('#connectDevicesForm','',function(json){
					if ( json.status == '1' ) {
						setTimeout(function(){
							$.refreshAttachedDevices();
						}, parseInt(json.wait,10) * 1000);
					} else {
						$('.running').remove();
						$.alertBox(json.msg);
					}
				});
			});

			$('.secondary').click(function() {
				top.location.href = "connectDevices.htm" + $.ID_2;
				if ( json.status == '1' ) {
					location.href = "/connectDevices.htm"+$.ID_2;
				} else {
					$.alertBox(json.msg);
				}
			});

			$('.primary').click(function(){
				$('.errorMsg').remove();
				if( wps_progress_status == "2" ) {
					$.alertBox(wps_in_progress);
					return false;
				}
				$('#devTotalNum').val(number);

				for(var i=0; i<$('#devTotalNum').val(); i++) {
					if($('#wifiDev'+i).prop('checked')) {
						checkDev[i] = 1;
						count++;
					} else {
						checkDev[i] = 0;
					}
					$('#wifiNewItem'+i).val(checkDev[i]+' '+mac_address[i]+' '+$.xss_replace(name_ssid[i]));
				}

				if (count >= 64) {
					$.addErrMsgAfter('err_msg', acl_length_64);
					return false;
				}

				if ( !$('.errorMsg').length ) {
					$.submit_wait('.main:first', $.PAGE_WAITING_DIV);
					$('input[name=submit_flag]', '#connectDevicesForm').val("wifi_devices");
					$.postForm('#connectDevicesForm', '', function(json) {
						if ( json.status == '1' ) {
							setTimeout(function(){
								$.refreshAttachedDevices();
							}, parseInt(json.wait,10) * 1000);
						} else {
							$('.running').remove();
							$.alertBox(json.msg);
						}
					});
				}
			});
			$.refreshAttachedDevices();
		}
	});
}(jQuery));
