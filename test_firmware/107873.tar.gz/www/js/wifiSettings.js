/**
 * For WiFi Settings page
 */
(function ($) {

	"use strict";
	
	var checkNum = 0;
	
	$(function () {
		/*******************************************************************************************
		*
		*	WiFi Settings page
		*
		******************************************************************************************/

		if ($('#wifiSettingsForm').length) {

			// toggle the various settings panes
			$('.sectionWrap').find('.expand').on('touchclick', function () {
				if ($(this).parents('.sectionWrap').hasClass('open')) {
					$(this)
						.find('i')
						.removeClass('dnintg-expanded')
						.addClass('dnintg-collapsed')
						.parents('.sectionWrap')
						.removeClass('open')
						.find('.sectionDetails')
						.slideUp();
				} else {
					$(this)
						.find('i')
						.removeClass('dnintg-collapsed')
						.addClass('dnintg-expanded')
						.parents('.sectionWrap')
						.addClass('open')
						.find('.sectionDetails')
						.slideDown();
				}
			});

		} // end wifi settings
		
		/*******************************************************************************************
		*
		*	IP Address
		*
		******************************************************************************************/
		if ( $("input[name='ip_assign']").length) {
			$("input[name='ip_assign']").on('click', function(){
				if ($(this).val() == "1"){
					$('input', '.ipAddressInput').prop("disabled", true);
				} else {
					$('input', '.ipAddressInput').prop("disabled", false);
				}
			});
		}
		
		if ($('#autoDisablePIN').length){
			$('#autoDisablePIN').on('change', function () {
				if($(this).prop('checked')) {
					$('#numberOfEntries').prop("disabled", false);
				} else {
					$('#numberOfEntries').prop("disabled", true);
				}
			});
		}

		$.checkBoxs = function(id) {
			if($('#'+id).is(':checked') == true) {
				$('#'+id).prop('checked', true);
				$('#'+id).addClass('checked');
			} else {
				$('#'+id).prop('checked', false);
				$('#'+id).removeClass('checked');
			}
		}

		$.wpsWarning = function() {
			if($('#ssidBc').is(':checked') == false) {
				$.confirmBox(wps_warning1, null, null, null, function(){
					$('#ssidBc').prop('checked', true);
					$('#ssidBc').addClass('checked');
				});
			}
		}

		$.setChannel = function() {
			var wChannel = document.getElementById("channel");
			if($('#wRegion').val() == 8 || $('#wRegion').val() == 10)
				wChannel.options.length = 12;
			else
				wChannel.options.length = 14;
			for(var i=1; i<wChannel.options.length; i++) {
				wChannel.options[i].value = i;
				wChannel.options[i].text = (i < 10)? "0" + i : i;
			}
		}

		$.changeWEPShowHidden = function() {
			var secOptions = document.getElementById('secType'),
			sel = secOptions.value;
			if($('#opmode').val() != '1') {
				$("#secType option[value='2']").remove();
			} else {
				if ( sel == '2' )
					sel = '0';
				if(confMode == "0") {
					secOptions.options[2].value = '2';
					secOptions.options[2].text = sec_wep_phrase;
					secOptions.options[3].value = '6';
					secOptions.options[3].text = sec_wpa2_phrase;
					secOptions.options[4] = new Option(sec_wpas_phrase, '7');
				} else {
					secOptions.options[1].value = '2';
					secOptions.options[1].text = sec_wep_phrase;
					secOptions.options[2].value = '6';
					secOptions.options[2].text = sec_wpa2_phrase;
					secOptions.options[3] = new Option(sec_wpas_phrase, '7');
				}
			}
			$('.securityOptions').val(sel);
			if($('#whatPwd').val() == '0' || sameSec == '0' || confMode != "2")
				$('.securityOptions').trigger('change');
		};

		var modeArray = new Array(),
		modeValue = new Array(),
		selectMode = $('#opmode').val();
		$('option', '#opmode').each(function(i, ele){
			modeArray[i] = $(ele).html();
			modeValue[i] = $(ele).attr("value");
		});
		$.changeModeShowHidden = function() {
			var options = 3,
			i = 0;
			selectMode = $('#opmode').val();
			if($('#secType').val() == '2' && ($('#whatPwd').val() == '0' || confMode == "0")) {
				options = 1;
			}
			$('#opmode').empty();
			for ( ; i < options; i++ ) {
				if ( selectMode == modeValue[i] )
					$('<option value="'+modeValue[i]+'" selected>'+modeArray[i]+'</option>').appendTo('#opmode');
				else
					$('<option value="'+modeValue[i]+'">'+modeArray[i]+'</option>').appendTo('#opmode');
			}
		};

		$.check_wizard_dhcp = function(check) {
			if(check == 1)
				$('#runTestFlag').val('test');
			else
				$('#runTestFlag').val('no');
			return true;
		}
 
                $.check_static_ip_mask_gtw = function() {
                        var ipAddr = $('#ethr1').val()+'.'+$('#ethr2').val()+'.'+$('#ethr3').val()+'.'+$('#ethr4').val(),
                        maskAddr = $('#mask1').val()+'.'+$('#mask2').val()+'.'+$('#mask3').val()+'.'+$('#mask4').val(),
                        gatewayAddr = $('#gateway1').val()+'.'+$('#gateway2').val()+'.'+$('#gateway3').val()+'.'+$('#gateway4').val(),
                        dnsAddr = $('#priAddr1').val()+'.'+$('#priAddr2').val()+'.'+$('#priAddr3').val()+'.'+$('#priAddr4').val();
			if($.checkipaddr(ipAddr) == false || $.is_sub_or_broad(ipAddr, ipAddr, maskAddr) == false) {
				$.addErrMsgAfter('ethr4', ip_invalid);
				return false;
			}
			if((maskAddr == "0.0.0.0") || (maskAddr == "255.255.255.255")) {
				$.addErrMsgAfter('mask4', subnet_invalid);
				return false;
			}
                        if($.checksubnet(maskAddr) == false) {
                                $.addErrMsgAfter('mask4', subnet_invalid);
				return false;
                        }
                        if($.checkgateway(gatewayAddr) == false) {
                                $.addErrMsgAfter('gateway4', gateway_invalid);
				return false;
                        }
                        if($.isGateway(ipAddr,maskAddr,gatewayAddr) == false) {
                                $.addErrMsgAfter('gateway4', gateway_invalid);
				return false;
                        }
                        if($.isSameIp(ipAddr, gatewayAddr) == true) {
                                $.addErrMsgAfter('gateway4', gateway_invalid);
				return false;
                        }
			if($.isSameSubNet(ipAddr,maskAddr,gatewayAddr,maskAddr) == false) {
				$.addErrMsgAfter('gateway4', same_subnet_ip_gtw);
				return false;
			}
                        if($.checkipaddr(dnsAddr) == false) {
                                $.addErrMsgAfter('priAddr4', primary_dns_invalid);
				return false;
                        }
			if($.check_wizard_dhcp(0) == false)
				return false;
			return true;
                 }

		$.returnTop = function(id_flag) {
			var mao = $(id_flag);
			if(mao.length > 0) {
				var pos = mao.offset();
				$("body,html").animate({scrollTop:pos.top}, 1000);
			}
		}

		$.wpsDisplay = function(id) {
			$.checkBoxs(id);
			if(wps_protect_pin_flag == '1') {
				if(($('#enablePIN').is(':checked') == false) || ($('#enablePIN').prop('disabled') == true))
					$('#wladv_appin_cfg').hide();
				else
					$('#wladv_appin_cfg').show();
				if($('#autoDisablePIN').prop('checked'))
					$('#numberOfEntries').prop("disabled", false);
				else
					$('#numberOfEntries').prop("disabled", true);
			} else {
				$('#wladv_appin_cfg').hide();
			}
		}

		$.expandedAllSection = function() {
			$('.sectionWrap').find('.expand')
				.find('i')
				.removeClass('dnintg-collapsed')
				.addClass('dnintg-expanded')
				.parents('.sectionWrap')
				.addClass('open')
				.find('.sectionDetails')
				.slideDown();
		}

		if ($('#wifiSettingsForm').length) {
			if(rootSecurity == '8' || rootSecurity == "3" || rootSecurity == "4" || rootSecurity == "5")
				rootSecurity = '7';
			if ( confMode != "2" ) {
				$('.whatPwdLi').hide();
				$('option:first', '#secType').after('<option value="1">'+none+'</option>');
			}
			$('#wRegion').val(region);
			$('#ssid').val(SSID);
			if(APEnable == '1')
				$('#enableAp').prop('checked', true);
			else
				$('#enableAp').prop('checked', false);
			if(broadcast == '1')
				$('#ssidBc').prop('checked', true);
			else
				$('#ssidBc').prop('checked', false);
			if(disCoext == '0')
				$('#enableCoexist').prop('checked', true);
			else
				$('#enableCoexist').prop('checked', false);
			$('#channel').val(channel);
			$.setChannel();

			if(mode == '3' || mode == '5' || mode == '6')
				$('#opmode').val('3');
			else if(mode == '2')
				$('#opmode').val('2');
			else
				$('#opmode').val('1');
			$.changeWEPShowHidden();

			if(link_status == '1' && confMode == '2') {
				$('#enableCoexistRow').addClass('hide');
				$('#channel').prop("disabled", true);
				$('#channel').css({'background-color':'#ebebe4'});
				$('#opmode').prop("disabled", true);
				$('#opmode').css({'background-color':'#ebebe4'});
			} else {
				$('#enableCoexistRow').removeClass('hide');
				$('#channel').prop("disabled", false);
				$('#opmode').prop("disabled", false);
			}

			if(sameSec == '0' || confMode != "2" ) {
				$('.securityOptionsWrap').show();
				$('#whatPwd').val('0');
				if(security == "2") {
					$('#secType').val('2');
					$('.wep').show();
					$('.wpa').hide();
					$('#wepAuth').val(authType);
					$('#wepEnc').val(encrLen);
					$('#wepEnc').trigger('change');
					if(keyNum == '1')
						$('#wepKeyNo1').attr('checked', 'checked');
					else if(keyNum == '2')
						$('#wepKeyNo2').attr('checked', 'checked');
					else if(keyNum == '3')
						$('#wepKeyNo3').attr('checked', 'checked');
					else
						$('#wepKeyNo4').attr('checked', 'checked');
					$('#key1').val(key1);
					$('#key2').val(key2);
					$('#key3').val(key3);
					$('#key4').val(".");
				} else if(security == "3" || security == "6" || security == "7") {
					$('#secType').val(security);
					$('.wep').hide();
					$('.wpa').show();
					$('#passphrase').val(password);
					$('#verifyPwd').val(password);
					if(password.length >= $.MIN_PWD_CHARACTERS)
						$('.verifyPwd').prop('disabled', false);
					else
						$('.verifyPwd').prop('disabled', true);
				} else if ( confMode != "2" && security == "1" ) {
					$('#secType').val('1');
					$('.wep').hide();
					$('.wpa').hide();
				} else {
					$('#secType').val('0');
					$('.wep').hide();
					$('.wpa').hide();
				}
			} else {
				$('#secType').val('0');
				$('.securityOptionsWrap').hide();
				$('.wep').hide();
				$('.wpa').hide();
				if(security == "1") {
					$('#whatPwd').val('2');
				} else {
					$('#whatPwd').val('1');
				}
			}
			$.checkPass();
			setTimeout(function() {
				if(security == "2") {
					$('#key4').val(key4);
					$('#passphrase').val("");
					$('#verifyPwd').val("");
				} else if(security == "3" || security == "6" || security == "7") {
					$('#key4').val("");
					$('#passphrase').val(password);
					$('#verifyPwd').val(password);
				} else {
					$('#key4').val("");
					$('#passphrase').val("");
					$('#verifyPwd').val("");
				}
				$('#key4').removeAttr('style');
			}, $.chromeTimer);

			$.changeModeShowHidden();

			if(lanTypeOpt == '0') {
				$('input', '.ipAddressInput').prop("disabled", false);
				$('#staticAssign').attr('checked', 'checked');
			} else {
				$('input', '.ipAddressInput').prop("disabled", true);
				$('#dhcpAssign').attr('checked', 'checked');
			}
			if(ether_get_ip != "") {
				var ip_array = ether_get_ip.split('.');
				$('#ethr1').val(ip_array[0]);
				$('#ethr2').val(ip_array[1]);
				$('#ethr3').val(ip_array[2]);
				$('#ethr4').val(ip_array[3]);
			}
			if(ether_get_subnet != "") {
				var mask_array=ether_get_subnet.split('.');
				$('#mask1').val(mask_array[0]);
				$('#mask2').val(mask_array[1]);
				$('#mask3').val(mask_array[2]);
				$('#mask4').val(mask_array[3]);
			}
			if(ether_get_gateway != "") {
				var gtw_array=ether_get_gateway.split('.');
				$('#gateway1').val(gtw_array[0]);
				$('#gateway2').val(gtw_array[1]);
				$('#gateway3').val(gtw_array[2]);
				$('#gateway4').val(gtw_array[3]);
			}
			if(ether_get_dns1 != "") {
				var dns_array=ether_get_dns1.split('.');
				$('#priAddr1').val(dns_array[0]);
				$('#priAddr2').val(dns_array[1]);
				$('#priAddr3').val(dns_array[2]);
				$('#priAddr4').val(dns_array[3]);
			}

			if(wps_protect_pin_flag == '1') {
				$('#wladv_enable_wps').show();
			} else {
				$('#wladv_enable_wps').hide();
			}

			if(WPSenable == '0') {
				$('#wladv_pin').css({"color": "gray"});
				$('#wladv_enable_wps').css({"color": "gray"});
				$('#wladv_keep_exist').css({"color": "gray"});
				$('#wladv_appin_cfg').css({"color": "gray"});
				$('#enablePIN').prop("disabled", true);
				$('#autoDisablePIN').prop("disabled", true);
				$('#numberOfEntries').prop("disabled", true);
				$('#keepSettings').prop("disabled", true);
			}

			if((enableToggle == '1') || (lockDown == '1')) {
				$('#enablePIN').prop('checked', false);
				$('.pinWrap').css({"background-color": "gray"});
			} else {
				$('#enablePIN').prop('checked', true);
			}
			if(wps_protect_pin_flag == '1') {
				if(WPSProtect == '0')
					$('#autoDisablePIN').prop('checked', false);
				else
					$('#autoDisablePIN').prop('checked', true);
			}
			if(WPSStatus == '5')
				$('#keepSettings').prop('checked', true);
			else
				$('#keepSettings').prop('checked', false);
			$.wpsDisplay();

			$('#secType').change(function() {
				$.changeModeShowHidden();
			});

			$('.secondary').click(function() {
				top.location.href = "wifiSettings.htm" + $.ID_2;
			});

			$('.primary[id!=continueBt]').click(function(){
				$('.errorMsg').remove();
				if( wps_progress_status == "2" ) {
					$.alertBox(wps_in_progress);
					return false;
				}
				if ( !$.REG_SSID.test($('#ssid').val()) ) {
					$.addErrMsgAfter('ssid',ssid_invalid);
					$.returnTop("#fixedtop");
					return false;
				}

				$.checkSecurity('secType', 'wepEnc', 'passphrase');
				$('#wifiRegion').val($('#wRegion').val());
				$('#wifi2GHzSSID').val($.do_xss_ssid($('#ssid').val()));
				if($('#ssidBc').prop('checked'))
					$('#wifiSSIDBroadcast').val('1');
				else
					$('#wifiSSIDBroadcast').val('0');
				if($('#enableAp').prop('checked'))
					$('#wifiAPMode').val('1');
				else
					$('#wifiAPMode').val('0');
				if($('#enableCoexist').prop('checked'))
					$('#wifiCoext').val('0');
				else
					$('#wifiCoext').val('1');
				$('#wifiChannel').val($('#channel').val());
				if($('#secType').val() == '2')
					$('#wifiMode').val(1);
				else
					$('#wifiMode').val($('#opmode').val());
				if($('#whatPwd').val() == '2') {
					$('#wifiPwd').val('2');
					$('#wifiSecOptions').val('1');
				} else if($('#whatPwd').val() == '0') {
					$('#wifiPwd').val('0');
					if($('#secType').val() == '2') {
						$('#wifiSecOptions').val('2');
						if($('#wepAuth').val() == '1')
							$('#wifiWEPAuthType').val('1');
						else
							$('#wifiWEPAuthType').val('2');
						if($('#wepEnc').val() == '5')
							$('#wifiWEPEncrStr').val('5');
						else
							$('#wifiWEPEncrStr').val('13');
						$('#wifi2GHzKeyNum').val($('input:radio[name="wep_key_no"]:checked').val());
						$('#wifiWEPKey1').val($.do_xss_pass($('#key1').val()));
						$('#wifiWEPKey2').val($.do_xss_pass($('#key2').val()));
						$('#wifiWEPKey3').val($.do_xss_pass($('#key3').val()));
						$('#wifiWEPKey4').val($.do_xss_pass($('#key4').val()));
						$('ul strong:last', '#continue').html($.xss_format($('#wifiWEPKey'+$('#wifi2GHzKeyNum').val()).val()));
					} else {
						if($('#secType').val() == '3')
							$('#wifiSecOptions').val('3');
						else if($('#secType').val() == '6')
							$('#wifiSecOptions').val('6');
						else if ( confMode != "2" && $('#secType').val() == '1')
							$('#wifiSecOptions').val('1');
						else
							$('#wifiSecOptions').val('7');
						if($('.verifyPwd').val() != $('.primaryPwd').val() && $('.primaryPwd').val().length >= $.MIN_PWD_CHARACTERS) {
							$('.verifyPwd').addClass('alert');
							$.addErrMsgAfter('verifyPwd', error_not_same_pwd, false, 'err_passsame');
							$.returnTop("#ssid");
							return false;
o						}
						$('#wifi2GHzPassword').val($.do_xss_pass($('#passphrase').val()));
						$('ul strong:last', '#continue').html($.xss_format($('#passphrase').val()));
                                
					}
				} else {
					$('#wifiPwd').val('1');
					$('#wifiSecOptions').val(rootSecurity);
					if(rootSecurity == "2") {
						$('#wifiWEPAuthType').val(rootAuthType);
						$('#wifiWEPEncrStr').val(rootEncrLen);
						$('#wifi2GHzKeyNum').val(rootKeyNum);
						$('#wifiWEPKey1').val($.do_xss_pass(rootKey1));
						$('#wifiWEPKey2').val($.do_xss_pass(rootKey2));
						$('#wifiWEPKey3').val($.do_xss_pass(rootKey3));
						$('#wifiWEPKey4').val($.do_xss_pass(rootKey4));
					} else if(rootSecurity != "1") {
						$('#wifi2GHzPassword').val($.do_xss_pass(rootPassword));
					}
					$('ul strong:last', '#continue').html($.xss_format($.showPassKey(rootSecurity, rootKeyNum, "root")));
				}

				if ( $('#staticAssign').is(':checked') ) {
					if($.check_static_ip_mask_gtw() == false) {
						$.expandedAllSection();
						$.returnTop("#ipAddressSection");
						return false;
					}
				}

				$('#etherIPAddr').val($('#ethr1').val()+'.'+$('#ethr2').val()+'.'+$('#ethr3').val()+'.'+$('#ethr4').val());
				$('#etherSubnet').val($('#mask1').val()+'.'+$('#mask2').val()+'.'+$('#mask3').val()+'.'+$('#mask4').val());
				$('#etherGateway').val($('#gateway1').val()+'.'+$('#gateway2').val()+'.'+$('#gateway3').val()+'.'+$('#gateway4').val());
				$('#etherDNSAddr1').val($('#priAddr1').val()+'.'+$('#priAddr2').val()+'.'+$('#priAddr3').val()+'.'+$('#priAddr4').val());

				if(WPSStatus == '5' && $('#keepSettings').is(':checked') == false)
					$('#keep2GhzSettings').val('1');
				else
					$('#keep2GhzSettings').val('5');

				if(protectPINFlag == 1) {
					if($('#enablePIN').prop('checked'))
						$('#wifiEnablePIN').val('0');
					else
						$('#wifiEnablePIN').val('1');
					if($('#autoDisablePIN').prop('checked'))
						$('#wifiDisablePIN').val('1');
					else
						$('#wifiDisablePIN').val('0');
					if($('#numberOfEntries').val() == '')
						$('#numOfEntries').val('3');
					else
						$('#numOfEntries').val($('#numberOfEntries').val());
				}

				if ( !$('.errorMsg').length ) {
					if($('#wifiSecOptions').val() == '1') {
						$.confirmBox(wps_warning3, null, function(){
							$.submitSameIP();
						}, null, null);
					} else if($('#wifiSecOptions').val() == '2' || $('#wifiSecOptions').val() == '3') {
						$.confirmBox(wps_warning2, null, function(){
							$.submitSameIP();
						}, null, null);
                    } else if(($('#wifiSecOptions').val() == '7') && ($('#wifiMode').val() == '2' || $('#wifiMode').val() == '3')) {
                        $.confirmBox(new_wpa_mixed_pop_message, null, function(){
                            $.submitSameIP();
                        }, null, null);
					} else {
						$.submitSameIP();
					}
				} else {
					$.returnTop("#ssid");
					return false;
				}
			});

			$.submitSameIP = function() {
				if($('#staticAssign').is(':checked')) {
					if($.isSameIp($('#etherIPAddr').val(), old_lan_ip) == false) {
						$.confirmBox(changelanip + $('#etherIPAddr').val() + " ?", null, function() {
							$.alertBox(changelanip_renew, null, function() {
								$('#changeIPFlag').val('1');
								$.submitApply();
							});
						}, null, null);
					} else {
						$('#changeIPFlag').val('0');
						$.submitApply();
					}
				} else {
					$('#changeIPFlag').val('0');
					$.submitApply();
				}
			}

			$.submitApply = function() {
				$.submit_wait('.main:first', $.PAGE_APPLYING_DIV);
				$.returnTop("#fixedtop");
				$('input[name=submit_flag]', '#wifiSettingsForm').val("wifi_settings");
				$.postForm('#wifiSettingsForm', '', function(json) {
					if ( json.status == '1' ) {
						var time = parseInt(json.wait) * 1000;
						if ( $.isMac || $.isPhonePad)
							time = 1000;
						setTimeout(function() {
							$('#wifiSettingsDiv').hide();
							$('.running').remove();
							$('#continue').show();
							if(confMode == '2') {
								$('.extender').show();
								$('.accesspoint').hide();
							} else {
								$('.extender').hide();
								$('.accesspoint').show();
							}
							$('#fixedFooter').show();
							$('#continueBt').click(function() {
								$.change_domain(json.url);
							});
						}, time);
					} else {
						$.alertBox(json.msg);
					}
				});
				$('ul strong:first', '#continue').html($.xss_format($('#ssid').val()));
				$('ul strong:eq(1)', '#continue').html($.formatSecType($('#wifiSecOptions').val()));
				if($('#wifiSecOptions').val() == "1")
					$('ul li:last', '#continue').hide();
			}
		}

		/*******************************************************************************************
		*
		*    support own style of checkbox.
		*
		*******************************************************************************************/
		$('body').find(':checkbox').each(function () {
			if($(this).is(':checked')) {
				$(this).addClass('checked');
			} else {
				$(this).removeClass('checked');
			}
		});
		$('body').find(':text,:password,:radio,:checkbox').each(function() {
			$(this).change(function() {
				$('.first').prop('disabled', false);
			});
		});
		$('body').find('select').each(function() {
			$(this).change(function() {
				$('.first').prop('disabled', false);
			});
		});

	}); // end ready function

}(jQuery));
