/**
 * For WiFi Coverage page
 */
(function ($) {

	"use strict";

	
	$(function () {
		/*******************************************************************************************
		 * 
		 * init  page
		 *
		 *******************************************************************************************/
		if ( $('#wifiOutputPowerForm').length ) {
			$('#saveBt').click(function() {
				$.submit_wait('.main:first', $.PAGE_WAITING_DIV);
				$.postForm('#wifiOutputPowerForm', '', function(json) {
					if ( json.status == "1" ) {
						setTimeout('$(".running").remove();', parseInt(json.wait, 10) * 1000);
					} else {
						$.alertBox(json.msg);
					}
				});
			});
			$('#resetBt').click(function () {
				document.location.reload();
			});
		}
	}); // end ready function

}(jQuery));
