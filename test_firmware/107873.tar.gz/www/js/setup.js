/**
 * For setup flow
 */
(function ($) {

	"use strict";
	
	var checkNum = 0;
	var chooseSSID = new Array();
	var chooseSecurity = new Array();
	var chooseSectype = new Array();
	var chooseMode = new Array();
	var rootSSID = "";
	var securityType = "";
	var secType = "";
	var simpleMode = "";

	$.selectWepEncrStr = function(encrStr) {
		$('.errorMsg').remove();
		$('.wepPwd').attr('maxlength', $('#'+encrStr).val()*2);
		$('.wepPwd').val('');
		$('.btn.primary').prop('disabled', true);
	}
	$('.encrStrSel').trigger('change');

	$(function () {
		/*******************************************************************************************
		*
		*	select networks page
		*
		******************************************************************************************/
		$.checkMode = function(mode, security) {
			var modeType = "";
			if(mode == "G") {
				modeType = "1";
			} else if (mode == "GN20") {
				modeType = "2";
			} else if (mode == "GN40P") {
				modeType = "3";
			} else if (mode == "GN40M") {
				modeType = "5";
			} else if (mode == "GN40") {
				modeType = "6";
			} else {
				modeType = "2";
			}
			return modeType;
		}

		$.chooseExist = function(num){
			var selectItem = $('tr:eq('+num+')', '#availableNetworks'),
			security = $('td:eq(2)', selectItem).html(),
			channel = $('td:eq(3)', selectItem).html();
			rootSSID = chooseSSID[num];
			secType = chooseSectype[num];
			securityType = chooseSecurity[num];
			simpleMode = $.checkMode(chooseMode[num], chooseSecurity[num]);

			$('#2GHzSecurity').val(security);
			$('#2GHzChannel').val(channel);
			$('#2GHzSectype').val(secType);
			$('#2GHzMode').val(simpleMode);
			
			$.enableButton('nextStep', '#selectNetworkForm', 0, true);
		}

		function sortJSON(bef, aft) {
			return aft.signal - bef.signal;
		}

		function generateList() {

			$.getData('ca_available_network.aspx',function(json){
				if ( typeof(json.list) == 'object') {
					$('#availableNetworks').empty();
					json.list.sort(sortJSON);
					var len = json.list.length;
					var scanResult = '[';
					for(var j=0; j<len-1; j++) {
						scanResult = scanResult + '{"ssid":"' + json.list[j].ssid.replace(/&nbsp;/g, ' ') + '","channel":"' + json.list[j].channel + '","signal":"' + json.list[j].signal + '","security":"' + json.list[j].security + '","sectype":"' + json.list[j].sectype + '","mode":"' + json.list[j].mode + '"},';
					}
					scanResult = scanResult + '{"ssid":"' + json.list[len-1].ssid.replace(/&nbsp;/g, ' ') + '","channel":"' + json.list[len-1].channel + '","signal":"' + json.list[len-1].signal + '","security":"' + json.list[len-1].security + '","sectype":"' + json.list[len-1].sectype + '","mode":"' + json.list[len-1].mode + '"}]';
					$(eval(scanResult)).each(function(i,ele) {
						chooseSSID[i] = ele.ssid;
						chooseSectype[i] = ele.sectype;
						chooseSecurity[i] = ele.security;
						chooseMode[i] = ele.mode;
						var item = "<tr>"
						+ "<td><label title='"+ele.ssid
						+"'><input type='radio' name='sel_network' id='selNetwork"+(i+1)+"' value='"+ele.ssid.replace(/ /g, '%20')
						+"' onclick='$.chooseExist("+i+");' />"
						+ "<span class='phoneLabel'>"+network_name+"</span>"
						+ ele.ssid.replace(/ /g, '&nbsp;') + "</label></td>"
						+ "<td><span class='phoneLabel'>"+signal_strength+"</span>"
						+ "<i class='signalStrength "+$.getSignalType(ele.signal)
						+ "'></i> <span class='largeScreenOnly'>"+ele.signal+"%</span></td>"
						+ "<td title='"+ele.security+"'>" + ele.security + "</td>"
						+ "<td>"+ele.channel+"</td></tr>";
						if(ele.ssid != "" && ele.signal != "" && ele.channel != "" && ele.security != "")
							$('#availableNetworks').append(item);
					});
				}
			});
		}

		if ( $('#countryForm').length) {
			$('#wRegion').val(wlan_get_country);
			$('#nextStep').click(function() {
				$.submit_wait('body', $.WAITING_DIV);
				$.postForm('#countryForm', '', function(json) {
					if ( json.status == '1' ) {
						location.href = json.url+$.ID_2;
					} else {
						$('.running').remove();
						$.alertBox(json.msg);
					}
				});
			});
		}

		if ($('#selectNetworkForm').length) {
			checkNum = 3;
			$('#refreshBtLink').click(function() {
				$('.scanning').show();
				$.get('ca_searching_network.aspx'+$.ID_2, function(result) {
					try {
						var json = eval("(" + result + ")");
						if ( $.reset_login(json) )
							return false;
					} catch(e) {}
					setTimeout(function(){
						$('.scanning').hide();
						generateList();
					}, 20 * 1000);
				});
			});
			$('#refreshBtLink').trigger('click');

			$('#manualNetwork').click(function(){
				$.enableButton('nextStep', '#selectNetworkForm', 0, true);
			});
			
			$('#nextStep').click(function() {
				if ($("input[type='radio']:checked").val() != "") {
					if($("input[type='radio']:checked").val() == "manual") {
						location.href = "ca_extender_manual.htm"+$.ID_2;
					} else if(securityType == "OFF") {
						if($.xss_replace(rootSSID).length > 28)
							$('#client2GHzSSID').val($.do_xss_ssid($.xss_replace(rootSSID).substring(0, 28) + '_EXT'));
						else
							$('#client2GHzSSID').val($.do_xss_ssid($.xss_replace(rootSSID)) + '_EXT');
						$('#root2GHzSSID').val($.do_xss_ssid($.xss_replace(rootSSID)));
						$('#2GHzSecurity').val('1');
						$('#selectNetworkForm').attr('action', '/admin.cgi?/ca_extender_bgn.htm timestamp='+ts);
						$('#selectNetworkForm').attr('method', 'post');
						$.submit_wait('body',$.APPLYING_DIV);
						$.postForm('#selectNetworkForm','',function(json){
							if ( json.status == '1' ) {
								location.href = json.url+$.ID_2;
							} else {
								$.alertBox(json.msg);
							}
						});
					} else {
						$('#selectNetworkForm').attr('action', 'ca_extender_existing.htm');
						$('#selectNetworkForm').append('<input type="hidden" name="id" value="'+$.getUrlParam('id')+'" />');
						$('#selectNetworkForm').attr('method', 'get');
						$('#selectNetworkForm').submit();
					}
				} else {
					$.submit_wait('body',$.APPLYING_DIV);
					$.postForm('#selectNetworkForm','',function(json){
						if ( json.status == '1' ) {
							location.href = json.url+$.ID_2;
						} else {
							$.alertBox(json.msg);
						}
					});
				}
			});
		} // end $('#selectNetworkForm').length

		/*******************************************************************************************
		*
		*	Manual Input Security Password page
		*
		******************************************************************************************/
		$.checkManualInput = function() {
			if ( $('#securityTypeMan').val() != 0 ) {
				var sec_type = $('#securityTypeMan').val();
				switch(sec_type) {
					case '1': //None
						break;
					case '2': //WEP
						var reg = $.REG_KEY_64,
						msg = wep_64;
						if ( $('#wepEncManual').val() == '13' ) {
							reg = $.REG_KEY_128;
							msg = wep_128;
						}
						if (!reg.test($('#keyManual').val())) {
							$.addErrMsgAfter('keyManual', msg);
						}
						break;
					case '3': // WPA-PSK [TKIP]
					case '6': // WPA2-PSK [AES]
					case '7': // WPA-PSK [TKIP] + WPA2-PSK [AES]
						 if ( !$.REG_WPA_PWD.test($('#pwdMan').val()) ) {
							$.addErrMsgAfter('pwdMan', wpa_phrase, false, 'err_pripass');
						 }
						break;
					default:
						$.addErrMsgAfter('securityTypeMan', no_security);
				}
			} else {
				$.addErrMsgAfter('securityTypeMan', no_security);
			}
		};

		$.setMaxLen = function() {
			if ( $('#securityTypeMan').val() == '2' ) {
				$('#keyManual').attr('maxlength', $('#wepEncManual').val()*2);
				$('#keyManual').val('');
				$.enableButton('nextStep', '#manualSettingsForm', 0, false);
			} else if ( $('#securityTypeMan').val() != '0' && $('#securityTypeMan').val() != '1' ) {
				$('#pwdMan').attr('maxlength', 64);
				$('#pwdMan').val('');
				$.enableButton('nextStep', '#manualSettingsForm', 0, false);
			} else if ($('#securityTypeMan').val() == '1') {
				$.enableButton('nextStep', '#manualSettingsForm', 0, true);
			} else {
				$.enableButton('nextStep', '#manualSettingsForm', 0, false);
			}
		}

		if ($('#securityTypeMan').length) {

			$('#securityTypeMan').on('change', function () {

				var thisParent = $(this).parents('.formElements');

				if ($(this).val() != 0)
					$('.errorMsg').remove();
				if ($(this).val() > 2) {
					thisParent.find('.wep').slideUp();
					thisParent.find('.wpa').slideDown();
					thisParent.find('.wepwpa').slideDown();
					thisParent.find('.wepwpa').find(':password').val('');
					$('#pwdMan').keyup(function() {
						if ( $(this).val().length >= 8 ) {
							$.enableButton('nextStep', '#manualSettingsForm', 0, true);
						} else {
							$.enableButton('nextStep', '#manualSettingsForm', 0, false);
						}
					});
					$('#pwdMan').trigger('keyup');
					$('#pwdMan').change(function() {
						if ( $(this).val().length >= 8 ) {
							$.enableButton('nextStep', '#manualSettingsForm', 0, true);
						} else {
							$.enableButton('nextStep', '#manualSettingsForm', 0, false);
						}
					});
				} else if ($(this).val() > 1) {
					thisParent.find('.wep').slideDown();
					thisParent.find('.wpa').slideUp();
					thisParent.find('.wepwpa').slideDown();
					thisParent.find('.wepwpa').find(':password').val('');
					$('#keyManual').keyup(function() {
						if ( $(this).val().length >= 5 ) {
							$.enableButton('nextStep', '#manualSettingsForm', 0, true);
						} else {
							$.enableButton('nextStep', '#manualSettingsForm', 0, false);
						}
					});
					$('#keyManual').trigger('keyup');
					$('#keyManual').change(function() {
						if ( $(this).val().length >= 5 ) {
							$.enableButton('nextStep', '#manualSettingsForm', 0, true);
						} else {
							$.enableButton('nextStep', '#manualSettingsForm', 0, false);
						}
					});

				} else if ($(this).val() > 0) {
					// hide the password pane
					thisParent.find('.pwdInput').slideUp();
					// reset the password fields
					thisParent.find('.pwdInput').find(':password').val('');
					$.enableButton('nextStep', '#manualSettingsForm', 0, true);
				} else {
					thisParent.find('.pwdInput').slideUp();
					thisParent.find('.pwdInput').find(':password').val('');
					$.enableButton('nextStep', '#manualSettingsForm', 0, false);
				}
			});
			
			$('#securityTypeMan').trigger('change');
		}

		if ($('#manualSettingsForm').length) {
			setTimeout(function(){
				$('#ssidMan').val("");
				$('#keyManual').val("");
				$('#pwdMan').val("");
				$('#ssidMan').removeAttr("style");
			}, $.chromeTimer);
			$('#nextStep').click(function() {
				$('.errorMsg').remove();
				if ( !$.REG_SSID.test($('#ssidMan').val()) ) {
					$.addErrMsgAfter('ssidMan',ssid_invalid);
				}
				$.checkManualInput();
				if($('#ssidMan').val().length > 28)
					$('#client2GHzSSID').val($.do_xss_ssid($('#ssidMan').val().substring(0, 28)) + '_EXT');
				else
					$('#client2GHzSSID').val($.do_xss_ssid($('#ssidMan').val()) + '_EXT');
				$('#2GHzSecurity').val($('#securityTypeMan').val());
				$('#root2GHzSSID').val($.do_xss_ssid($('#ssidMan').val()));
				if ( $('#securityTypeMan').val() == 2 ) {
					$('#2GHzEncrLen').val($('#wepEncManual').val());
					$('#2GHzKeyNo').val($('#wepKeyNoManual').val());
					$('#2GHzAuthType').val($('#wepAuthManual').val());
					$('#2GHzWepPass').val($.do_xss_pass($('#keyManual').val()));
				} else if ( $('#securityTypeMan').val() != 0 ) {
					$('#2GHzPassword').val($.do_xss_pass($('#pwdMan').val()));
				}
				if ( !$('.errorMsg').length ) {
					$.submit_wait('body', $.APPLYING_DIV);
					$.postForm('#manualSettingsForm', '', function(json) {
						if ( json.status == '1' ) {
							var time = parseInt(json.wait) * 1000;
							setTimeout(function() {
								location.href = json.url+$.ID_2;
							}, time);
						} else {
							$.alertBox(json.msg);
						}
					});
				}
			});
		}


		/*******************************************************************************************
		*
		*	2.4GHz Existing Network page
		*
		******************************************************************************************/
		$.setSecurityType = function(security, sectype) {
			var securiType = "";
			if(security == "WEP") {
				securiType = "2";
			} else if(security == "WPA-PSK") {
				if(sectype.indexOf('TKIPAES') > -1)
					securiType = "8";
				else if(sectype.indexOf('AES') > -1)
					securiType = "4";
				else
					securiType = "3";
			} else if(security == "WPA2-PSK") {
				if(sectype.indexOf('AES') > -1)
					securiType = "6";
				else
					securiType = "5";
			} else if(security == "WPA/WPA2-PSK") {
				if(sectype.indexOf('AES') > -1)
					securiType = "7";
				else
					securiType = "8";
			} else {
				securiType = "1";
			}

			return securiType;
		};

		$.checkExistInput = function(type) {
			if ( existSecurity == "WEP" || type == "2" ) {
				var reg = $.REG_KEY_64,
				msg = wep_64;
				if ( $('#encrStr').val() == '13' ) {
					reg = $.REG_KEY_128;
					msg = wep_128;
				}
				if (!reg.test($('#password').val())) {
					$.addErrMsgAfter('password', msg);
				}
			} else {
				if ( !$.REG_WPA_PWD.test($('#pwd').val()) ) {
					$.addErrMsgAfter('pwd', wpa_phrase, false, 'err_pripass');
				}
			}
		};

		if ( $('#bgnExistingNetworkForm').length ) {
			//setting the ssid and security according to url query
			var existSSID = $.getUrlParam('sel_network');
			existSSID = existSSID.replace(/%20/g, ' ');
			var existSecurity = $.getUrlParam('2GHzSecurity');
			var existSectype = $.getUrlParam('2GHzSectype');
			$('#root2GHzSSID').val($.do_xss_ssid(existSSID));
			if(existSSID.length > 28)
				$('#client2GHzSSID').val($.do_xss_ssid(existSSID.substring(0, 28)) + '_EXT');
			else
				$('#client2GHzSSID').val($.do_xss_ssid(existSSID) + '_EXT');
			$('#2GHzSecurity').val($.setSecurityType(existSecurity, existSectype));
			$('#2GHzChannel').val($.getUrlParam('2GHzChannel'));
			$('#2GHzMode').val($.getUrlParam('2GHzMode'));
			$('#2GHzSSIDShow').html($.xss_format(existSSID));

			if(existSecurity == "WEP")
				$('#2GHzSecurityShow').html(sec_wep_phrase);
			else if(existSecurity == "WPA/WPA2-PSK")
				$('#2GHzSecurityShow').html(sec_wpas_phrase);
			else
				$('#2GHzSecurityShow').html(existSecurity+" ["+existSectype+"]");

			if ( existSecurity == "WEP" ) {
				$('.formElements').find('.wep').show();
				$('.formElements').find('.wepwpa').show();
				$('.formElements').find('.wpa').hide();
				$('#password').attr('maxlength', $('#encrStr').val()*2);
				$('#encrStr').trigger('change');
				$('#password').keyup(function() {
					if ( $(this).val().length >= 5 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
				$('#password').trigger('keyup');
				$('#password').change(function() {
					if ( $(this).val().length >= 5 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
			} else {
				$('.formElements').find('.wep').hide();
				$('.formElements').find('.wepwpa').show();
				$('.formElements').find('.wpa').show();
				$('#pwd').keyup(function() {
					if ( $(this).val().length >= 8 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
				$('#pwd').trigger('keyup');
				$('#pwd').change(function() {
					if ( $(this).val().length >= 8 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
			}

			$('#nextStep').click(function() {
				$('.errorMsg').remove();
				$.checkExistInput(existSecurity);

				if ( existSecurity == "WEP" ) {
					$('#2GHzEncrLen').val($('#encrStr').val());
					$('#2GHzKeyNo').val($('#keyNum').val());
					$('#2GHzAuthType').val($('#authType').val());
					$('#2GHzWepPass').val($.do_xss_pass($('#password').val()));
				} else {
					$('#2GHzPassword').val($.do_xss_pass($('#pwd').val()));
				}

				if ( !$('.errorMsg').length ) {
					$('.running').remove();
					$.submit_wait('body', $.APPLYING_DIV);
					$.postForm('#bgnExistingNetworkForm','',function(json){
						if ( json.status == '1' ) {
							var time = parseInt(json.wait) * 1000;
							setTimeout(function() {
								location.href = json.url+$.ID_2;
							}, time);
						} else {
							$.alertBox(json.msg);
						}
					});
				}
			});
		}
		/*******************************************************************************************
		*
		*       Failure! Continue Setting page
		*
		******************************************************************************************/
		if ( $('#continueNetworkForm').length ) {
			$('#2GHzSSIDShow').html(rootSSIDShow);
			$('#show_mac').html(ca_retry_mac + lan_mac + "." + adapter_macaddr + lan_mac + "." + ca_cancel);

			if(rootSecurity == "7" || rootSecurity == "8")
				$('#2GHzSecurityShow').html(sec_wpas_phrase);
			else
				$('#2GHzSecurityShow').html($.formatSecType(rootSecurity));

			if ( rootSecurity == "1" ) {
				$('.formElements').find('.wep').hide();
				$('.formElements').find('.wepwpa').hide();
				$('.formElements').find('.wpa').hide();
				$.enableButton('continueBt', '#continueNetworkForm', 0, true);
			} else if ( rootSecurity == "2" ) {
				$('.formElements').find('.wep').show();
				$('.formElements').find('.wepwpa').show();
				$('.formElements').find('.wpa').hide();
				$('#encrStrFail').val(rootEncrLen);
				$('#authTypeFail').val(rootAuthType);
				$('#keyNumFail').val(rootKeyNum);
				$('#wepPassFail').attr('maxlength', $('#encrStrFail').val()*2);
				$('#encrStrFail').trigger('change');
				if ( rootKeyNum == '1' )
					$('#wepPassFail').val(rootKey1);
				else if ( rootKeyNum == '2' )
					$('#wepPassFail').val(rootKey2);
				else if ( rootKeyNum == '3' )
					$('#wepPassFail').val(rootKey3);
				else
					$('#wepPassFail').val(rootKey4);
				$('#wepPassFail').keyup(function() {
					if ( $(this).val().length >= 5 ) {
						$.enableButton('continueBt', '#continueNetworkForm', 0, true);
					} else {
						$.enableButton('continueBt', '#continueNetworkForm', 0, false);
					}
				});
				$('#wepPassFail').trigger('keyup');
				$('#wepPassFail').change(function() {
					if ( $(this).val().length >= 5 ) {
						$.enableButton('continueBt', '#continueNetworkForm', 0, true);
					} else {
						$.enableButton('continueBt', '#continueNetworkForm', 0, false);
					}
				});
				$('#wepPassFail').trigger('change');
			} else {
				$('.formElements').find('.wep').hide();
				$('.formElements').find('.wepwpa').show();
				$('.formElements').find('.wpa').show();
				$('.networkPwd').attr('maxlength', 64);
				$('#passphrase').val(rootPassword);
				$('#passphrase').keyup(function() {
					if ( $(this).val().length >= 8 ) {
						$.enableButton('continueBt', '#continueNetworkForm', 0, true);
					} else {
						$.enableButton('continueBt', '#continueNetworkForm', 0, false);
					}
				});
				$('#passphrase').trigger('keyup');
				$('#passphrase').change(function() {
					if ( $(this).val().length >= 8 ) {
						$.enableButton('continueBt', '#continueNetworkForm', 0, true);
					} else {
						$.enableButton('continueBt', '#continueNetworkForm', 0, false);
					}
				});
				$('#passphrase').trigger('change');
			}

			$('#continueBt').click(function() {
				$('.errorMsg').remove();
				$('#root2GHzSSID').val($.do_xss_ssid(rootSSIDShow));
				$('#client2GHzSSID').val($.do_xss_ssid(clientSSID));
				$('#2GHzSecurity').val(rootSecurity);
				$('#2GHzChannel').val(channel);
				$('#2GHzMode').val(mode);
				$.checkExistInput(rootSecurity);
				if ( rootSecurity == "2" ) {
					$('#2GHzEncrLen').val($('#encrStrFail').val());
					$('#2GHzKeyNo').val($('#keyNumFail').val());
					$('#2GHzAuthType').val($('#authTypeFail').val());
					$('#2GHzWepPass').val($.do_xss_pass($('#wepPassFail').val()));
				} else if ( rootSecurity != "1" && rootSecurity != "0" ) {
					$('#2GHzPassword').val($.do_xss_pass($('#passphrase').val()));
				}
				if ( !$('.errorMsg').length ) {
					$('.running').remove();
					$.submit_wait('body', $.APPLYING_DIV);
					$.postForm('#continueNetworkForm','', function(json){
						if ( json.status == '1' ) {
							var time = parseInt(json.wait) * 1000;
							setTimeout(function() {
								location.href = json.url+$.ID_2;
							}, time);
						} else {
							$.alertBox(json.msg);
						}
					});
				}
			});

			if ($('#cancelBt', '#continueNetworkForm').length) {
				$('#cancelBt').attr('href', 'ca_extender_setup.htm'+$.ID_2);
			}
			if ($('#skipBt', '#continueNetworkForm').length) {
				$('#skipBt').attr('href', 'status.htm'+$.ID_2);
			}
		}

		/*******************************************************************************************
		*
		*	Existing Page. ca_extender_bgn.htm
		*
		******************************************************************************************/
		if ($('#networkSettingsForm').length) {
			$('#ssid').val(rootSSIDShow);
			if(rootSecurity == "8" || rootSecurity == "3" || rootSecurity == "4" || rootSecurity == "5")
				rootSecurity = "7";
			if( rootSamesec == '0' ) {
				$('.securityOptionsWrap').hide();
				$('.pwdInput').hide();
				if ( rootSecurity == '1' )
					$('#whatPwd').val('2');
				else
					$('#whatPwd').val('1');
			} else {
				$('.securityOptionsWrap').show();
				$('#whatPwd').val('0');
				$('#securityOptions').val(rootSecurity);
				if(rootSecurity == '2') {
					$('.wep').show();
					$('.wpa').hide();
					$('#wepEnc').val(rootEncrLen);
					$('#wepAuth').val(rootAuthType);
					$('#wepEnc').trigger('change');
					if(rootKeyNum == '1')
						$('#wepKeyNo1').prop('checked', true);
					else if(rootKeyNum == '2')
						$('#wepKeyNo2').prop('checked', true);
					else if(rootKeyNum == '3')
						$('#wepKeyNo3').prop('checked', true);
					else
						$('#wepKeyNo4').prop('checked', true);
					$('#key1').val(rootKey1);
					$('#key2').val(rootKey2);
					$('#key3').val(rootKey3);
					$('#key4').val(".");
				} else {
					$('.wep').hide();
					$('.wpa').show();
					$('#pwd').val(rootPassword);
					$('#verifyPwd').val(rootPassword);
					$('#pwd').trigger('change');
				}
			}
			$.checkPass();
			setTimeout(function(){
				if ( rootSecurity == '2' ) {
					$('#key4').val(rootKey4);
					$('#pwd').val("");
					$('#verifyPwd').val("");
				} else {
					$('#key4').val("");
					$('#pwd').val(rootPassword);
					$('#verifyPwd').val(rootPassword);
				}
				$('#key4').removeAttr("style");
			}, $.chromeTimer);
			$('#nextStep').click(function() {
				$('.errorMsg').remove();
				if ( !$.REG_SSID.test($('#ssid').val()) ) {
					$.addErrMsgAfter('ssid',ssid_invalid);
				}
				$.checkSecurity('securityOptions', 'wepEnc', 'pwd');

				$('#client2GHzSSID').val($.do_xss_ssid($('#ssid').val()));
				if($('#whatPwd').val() == '2') {
					$('#client2GHzSameSec').val('2');
					$('#client2GHzSecurity').val('1');
				} else if($('#whatPwd').val() == '0') {
					$('#client2GHzSameSec').val('0');
					if($('#securityOptions').val() == '2') {
						$('#client2GHzSecurity').val('2');
						$('#clientMode').val('1');
						if($('#wepAuth').val() == '1')
							$('#client2GHzAuthType').val('1');
						else
							$('#client2GHzAuthType').val('2');
						if($('#wepEnc').val() == '5')
							$('#client2GHzEncrLen').val('5');
						else
							$('#client2GHzEncrLen').val('13');
						$('#client2GHzKeyNum').val($('input:radio[name="wep_key_no"]:checked').val());
						$('#client2GHzKey1').val($.do_xss_pass($('#key1').val()));
						$('#client2GHzKey2').val($.do_xss_pass($('#key2').val()));
						$('#client2GHzKey3').val($.do_xss_pass($('#key3').val()));
						$('#client2GHzKey4').val($.do_xss_pass($('#key4').val()));
						$('ul strong:last', '#continue').html($.xss_format($('#key'+$('#client2GHzKeyNum').val()).val()));
					} else {
						if ( $('.verifyPwd').val() != $('.primaryPwd').val() && $('.primaryPwd').val().length >= $.MIN_PWD_CHARACTERS ) {
							$('.verifyPwd').addClass('alert');
							$.addErrMsgAfter('verifyPwd', error_not_same_pwd, false, 'err_passsame');
							return false;
						}
						if($('#securityOptions').val() == '6')
							$('#client2GHzSecurity').val('6');
						else
							$('#client2GHzSecurity').val('7');
						$('#client2GHzPassword').val($.do_xss_pass($('#pwd').val()));
						$('ul strong:last', '#continue').html($.xss_format($('#pwd').val()));
					}
				} else {
					$('#client2GHzSameSec').val('1');
					$('#client2GHzSecurity').val(rootSecurity);
					if(rootSecurity == "2") {
						$('#client2GHzAuthType').val(rootAuthType);
						$('#client2GHzEncrLen').val(rootEncrLen);
						$('#client2GHzKeyNum').val(rootKeyNum);
						$('#client2GHzKey1').val($.do_xss_pass(rootKey1));
						$('#client2GHzKey2').val($.do_xss_pass(rootKey2));
						$('#client2GHzKey3').val($.do_xss_pass(rootKey3));
						$('#client2GHzKey4').val($.do_xss_pass(rootKey4));
						$('#clientMode').val('1');
					} else {
						$('#client2GHzPassword').val($.do_xss_pass(rootPassword));
					}
					$('ul strong:last', '#continue').html($.xss_format($.showPassKey(rootSecurity, rootKeyNum, "root")));
				}

				if ( !$('.errorMsg').length ) {
					$.submit_wait('body', $.APPLYING_DIV);
					$.postForm('#networkSettingsForm', '', function(json) {
						if ( json.status == '1' ) {
							var time = parseInt(json.wait) * 1000;
							if ( $.isMac || $.isPhonePad)
								time = 1000;
							setTimeout(function() {
								$('#networkSettingsDiv').hide();
								$('.running').remove();
								$('.secondary', '#fixedFooter').hide();
								$('#nextStep', '#fixedFooter').hide();
								$('#continueBt', '#fixedFooter').show();
								$('#continueBt').click(function() {
									$.change_domain(json.url);
								});
								$('#continue').show();
							}, time);
						} else {
							$.alertBox(json.msg);
						}
					});
					$('ul strong:first', '#continue').html($.xss_format($('#ssid').val()));
					$('ul strong:eq(1)', '#continue').html($.formatSecType($('#client2GHzSecurity').val()));
					if($('#client2GHzSecurity').val() == "1")
						$('ul li:last', '#continue').hide();
				}
			});
		}

		/*******************************************************************************************
		 * 
		 * Setup Success page
		 *
		 *******************************************************************************************/
		if ( $('#successForm').length ) {
			$('ul strong:first').html(clientSSID.replace(/ /g, '&nbsp;'));
			$('ul strong:eq(1)').html($.formatSecType(clientSecType));
			if(clientSecType == "1")
				$('ul li:last').hide();
			else
				$('ul strong:last').html($.showPassKey(clientSecType, clientKeyNum, "client"));

			if ($('.extender.gray', '#successForm').length ) {
				$('a.btn.primary').html(retry_mark);
				$('a.btn.primary').attr('href', 'ca_extender_continue.htm'+$.ID_2);
			} else if ($('.accesspoint.gray', '#successForm').length ) {
				$('a.btn.primary').html(retry_mark);
				$('a.btn.primary').attr('href', 'ca_access_checking.htm'+$.ID_2);
			} else {
				$('a.btn.primary').click(function() {
					$.submit_wait('body', $.WAITING_DIV);
					$('input[name=submit_flag]', '#successForm').val("finish");
					$.postForm('#successForm','',function(json){
						if ( have_reg == "1" || serialNumber == "N/A" )
							location.href = "/status.htm"+$.ID_2;
						else
						{
							$.ajax({
								url: registerUrl + "checkRegistrationStatusbySerial",
								jsonp: "callback",
								dataType: "jsonp",
								data: {
									serial_number: serialNumber
								},
								timeout: 15000,
								// work with the response
								success: function( response ) {
									if(response.errorCode==200) {
										if(response.registrationStatus != 0) {
											$('input[name=submit_flag]', '#successForm').val("reg_info");
											$.postForm('#successForm','',function(json){});
											location.href = "/status.htm"+$.ID_2;
										} else
											location.href = "/registerInfo.htm"+$.ID_2;
									} else {
										location.href = "/status.htm"+$.ID_2;
									}
								},
								error: function() {
									location.href = "/status.htm"+$.ID_2;
								}
							});
						}
					});
				});
			}

			if ($('.connectionState.accesspoint', '#successForm').length ) {
				$('a.btn.secondary').attr('href', 'ca_access_connect.htm'+$.ID_2);
			} else if ($('.connectionState.extender', '#successForm').length ) {
				$('a.btn.secondary').attr('href', 'ca_extender_bgn.htm'+$.ID_2);
			}
		}
	}); // end ready function

}(jQuery));
 
