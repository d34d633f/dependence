#!/bin/sh

REALM="$(/bin/config get netbiosname)"
UHTTPD_BIN="/usr/sbin/uhttpd"
PX5G_BIN="/usr/sbin/px5g"
COOKIE="$(/bin/config get t_cookie)"

uhttpd_stop()
{
	kill -9 $(pidof uhttpd)
}

uhttpd_start()
{
	/sbin/artmtd -r region

        $UHTTPD_BIN -h /www -r $REALM -x /cgi-bin -t 60 -p 0.0.0.0:80

	if [ "x$COOKIE" != "x" ]; then
		echo $COOKIE > /tmp/cookie
		/bin/config set t_cookie=""
	fi
}

case "$1" in
	stop)
		uhttpd_stop
	;;
	start)
		uhttpd_start
	;;
	restart)
		uhttpd_stop
		uhttpd_start
	;;
	*)
		logger -- "usage: $0 start|stop|restart"
	;;
esac

