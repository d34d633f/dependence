#! /bin/sh

PROFILE="/tmp/Wireless/RT2860/RT2860.dat"
#PROFILE="test.dat"

help() {
	echo "Usage: $0 [0-15]"
	echo "    [0-15]: MCS number"
}

if [ $# -ne 1 ]; then
	help
	exit
else
	echo "You choose MCS-$1"
fi

APCLITXMCS=`cat $PROFILE | grep ApCliTxMcs | awk -F= '{print $2}'`
if [ "$APCLITXMCS" != "" ]; then
	echo "Original AP-Client TX MCS is $APCLITXMCS"
else
	echo "AP-Client TX MCS is not configured"
fi

APTXMCS=`cat $PROFILE | grep HT_MCS | awk -F= '{print $2}'`
echo "Original AP TX MCS is $APTXMCS"
echo "--------------------------------"

cat $PROFILE
sed -i '/^HT_MCS/d' $PROFILE
sed -i '/^ApCliTxMcs/d' $PROFILE
echo "--------------------------------"
echo "HT_MCS=$1" >> $PROFILE
echo "ApCliTxMcs=$1" >> $PROFILE
cat $PROFILE

echo "Shutdown interfaces"
ifconfig apcli0 down
ifconfig ra0 down
echo "Remove module"
rmmod rt2860v2_ap
insmod rt2860v2_ap
echo "Bring up interfaces"
ifconfig ra0 up
ifconfig apcli0 up
echo "Bridge interfaces"
brctl addif br0 ra0
brctl addif br0 apcli0
