#!/bin/sh

echo enable > /sys/devices/platform/serial8250.0/console

#sleep 3;wlan updateconf;wlan down;wlan up
/sbin/basic_log.sh &
/sbin/console_log.sh &
/sbin/wireless_log.sh &
/sbin/capture_packet.sh 
