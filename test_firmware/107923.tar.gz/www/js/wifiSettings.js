/**
 * For WiFi Settings page
 */
(function ($) {

	"use strict";
	
	var checkNum = 0;
	var modeArray = new Array();
	var modeValue = new Array();
	var modeArray5g = new Array();
	var modeValue5g = new Array();
	var ht20_array = new Array(
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "136(DFS)", "140(DFS)" ), //0 -> Africa
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)", "140(DFS)", "149", "153", "157", "161", "165" ), //1 -> Asia
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "132(DFS)", "136(DFS)", "140(DFS)", "149", "153", "157", "161", "165" ), //2 -> Australia
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "136(DFS)", "140(DFS)", "149", "153", "157", "161", "165" ), //3 -> Canada
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)", "140(DFS)" ), //4 -> Europe
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)" ), //5 -> Israel
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)", "140(DFS)" ), //6 -> Japan
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "149", "153", "157", "161" ), //7 -> Korea
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161", "165" ), //8 -> Mexico
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)", "140(DFS)", "149", "153", "157", "161", "165" ), //9 -> South America
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "136(DFS)", "140(DFS)", "149", "153", "157", "161", "165" ), //10 -> North America
		new Array ( "149", "153", "157", "161", "165" ), //11 -> China
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161", "165" ), //12 -> India
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161", "165" ), //13 -> Malaysia
		new Array ( "" ), //14 -> Middle East (Yemen)
		new Array ( "149", "153", "157", "161", "165" ), //15 -> Middle East (Qatar)
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)" ), //16 -> Middle East(Kuwait)
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161", "165" ), //17 -> Middle East (Saudi Arabia)
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)", "140(DFS)" ), //18 -> Middle East (United Arab Emirates)
		new Array ( "36", "40", "44", "48" ), //19 -> Russia
		new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161", "165" ), //20 -> Singapore
		new Array ( "56", "60", "64", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)", "140(DFS)", "149", "153", "157", "161", "165" ) //21 -> Taiwan
			);
	var ht40_array = new Array(
			new Array ( "" ), //0
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)", "149", "153", "157", "161" ), //1
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "132(DFS)", "136(DFS)", "149", "153", "157", "161" ), //2
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "149", "153", "157", "161" ), //3
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)" ), //4
			new Array ( "" ), //5
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)" ), //6
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "149", "153", "157", "161" ), //7
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161" ), //8
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)", "149", "153", "157", "161" ), //9
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "149", "153", "157", "161" ), //10
			new Array ( "149", "153", "157", "161" ), //11
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161" ), //12
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161" ), //13
			new Array ( "" ), //14
			new Array ( "149", "153", "157", "161" ), //15
			new Array ( "" ), //16
			new Array ( "" ), //17
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)" ), //18
			new Array ( "36", "40", "44", "48" ), //19
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161" ), //20
			new Array ( "60", "64", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)", "149", "153", "157", "161" ) //21
				);
	var ht80_array = new Array(
			new Array ( "" ), //0
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "149", "153", "157", "161" ), //1
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "149", "153", "157", "161" ), //2
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "149", "153", "157", "161" ), //3
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)" ), //4
			new Array ( "" ), //5
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)" ), //6
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "149", "153", "157", "161" ), //7
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161" ), //8
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "149", "153", "157", "161" ), //9
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "149", "153", "157", "161" ), //10
			new Array ( "149", "153", "157", "161" ), //11
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161" ), //12
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161" ), //13
			new Array ( "" ), //14
			new Array ( "149", "153", "157", "161" ), //15
			new Array ( "" ), //16
			new Array ( "" ), //17
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)" ), //18
			new Array ( "36", "40", "44", "48" ), //19
			new Array ( "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "149", "153", "157", "161" ), //20
			new Array ( "60", "64", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "149", "153", "157", "161" ) //21
	);

	$(function () {
		/*******************************************************************************************
		*
		*	WiFi Settings page
		*
		******************************************************************************************/

		if ($('#wifiSettingsForm').length) {

			// toggle the various settings panes
			$('.sectionWrap').find('.expand').on('touchclick', function () {
				if ($(this).parents('.sectionWrap').hasClass('open')) {
					$(this)
						.find('i')
						.removeClass('dnintg-expanded')
						.addClass('dnintg-collapsed')
						.parents('.sectionWrap')
						.removeClass('open')
						.find('.sectionDetails')
						.slideUp();
				} else {
					$(this)
						.find('i')
						.removeClass('dnintg-collapsed')
						.addClass('dnintg-expanded')
						.parents('.sectionWrap')
						.addClass('open')
						.find('.sectionDetails')
						.slideDown();
				}
			});

			var opmode = document.getElementById('opmode');
			opmode.options[0].text = wlan_mode_1;
			opmode.options[1].text = wlan_mode_2;
			opmode.options[2].text = wlan_mode_3;

			var opmode = document.getElementById('opmode5g');
			opmode.options[0].text = wlan_mode_1;
			opmode.options[1].text = an_wlan_mode_1;
			opmode.options[2].text = an_wlan_mode_2;
			opmode.options[3].text = an_wlan_mode_3;

		} // end wifi settings
		
		/*******************************************************************************************
		*
		*	IP Address
		*
		******************************************************************************************/
		if ( $("input[name='ip_assign']").length) {
			$("input[name='ip_assign']").on('click', function(){
				if ($(this).val() == "1"){
					$('input', '.ipAddressInput').prop("disabled", true);
				} else {
					$('input', '.ipAddressInput').prop("disabled", false);
				}
			});
		}
		
		if ($('#autoDisablePIN').length){
			$('#autoDisablePIN').on('change', function () {
				if($(this).prop('checked')) {
					$('#numberOfEntries').prop("disabled", false);
				} else {
					$('#numberOfEntries').prop("disabled", true);
				}
			});
		}

		$.checkBoxs = function(id) {
			if($('#'+id).is(':checked') == true) {
				$('#'+id).prop('checked', true);
				$('#'+id).addClass('checked');
			} else {
				$('#'+id).prop('checked', false);
				$('#'+id).removeClass('checked');
			}
		}

		$.wpsWarning = function(id) {
			if($('#'+id).is(':checked') == false) {
				$.confirmBox(wps_warning1, null, null, null, function(){
					$('#'+id).prop('checked', true);
					$('#'+id).addClass('checked');
				});
			}
		}

		$.setChannel = function() {
			var wChannel = document.getElementById("channel");
			
			if($('#wRegion').val() == 8 || $('#wRegion').val() == 10)
				wChannel.options.length = 12;
			else
				wChannel.options.length = 14;

			for(var i=1; i<wChannel.options.length; i++) {
				wChannel.options[i].value = i;
				wChannel.options[i].text = (i < 10)? "0" + i : i;
			}
		}

		$.setChannel5g = function(from) {
			var cf = document.forms["wifiSettingsForm"];
			if (from == 2) {
				$.setAChannel(cf.channel_5g);
			} else {
				$.setAwlan_mode();
				$.setAChannel(cf.channel_5g);
			}
		}

		$.setAwlan_mode = function() {
			if (ac_router_flag == 1) {
				$.setACwlan_mode();
			} else {
				$.setANwlan_mode();
			}
		};

		$.setACwlan_mode = function() {
			var cf = document.forms["wifiSettingsForm"];
			var index = cf.wregion.value;
			var currentMode = cf.opmode_5g.selectedIndex;

			// bug 34916, change index number to region name, make the code easy to read and change.
			if (index == "0" || index == "5" || index == "16" || index == "17")
			{ //Israel,Middle East(Turkey/Egypt/Tunisia/Kuwait) Middle East(Saudi Arabia) Africa
				cf.opmode_5g.options.length = 1;
				cf.opmode_5g.options[0].text = an_wlan_mode_1;
				cf.opmode_5g.options[0].value = "7";
				cf.opmode_5g.selectedIndex = 0;
				cf.opmode_5g.disabled=true;// bug 34916, grey out mode, this region not support both HT20 and HT40
				$('#opmode5g').css({'background-color':'#ebebe4'});
			}
			else if ( index == "14" )
			{           // Middle East(Algeria/Syria/Yemen), this country do not support HT20 HT40,grayout channel
				cf.channel_5g.selectedIndex=0;
				cf.opmode_5g.selectedIndex=0;
				cf.channel_5g.disabled=true;
				$('#channel5g').css({'background-color':'#ebebe4'});
				cf.opmode_5g.options.length = 4;
				cf.opmode_5g.options[0].text = wlan_mode_1;
				cf.opmode_5g.options[1].text = an_wlan_mode_1;
				cf.opmode_5g.options[2].text = an_wlan_mode_2;
				cf.opmode_5g.options[3].text = an_wlan_mode_3;
				cf.opmode_5g.options[0].value = "1";
				cf.opmode_5g.options[1].value = "7";
				cf.opmode_5g.options[2].value = "8";
				cf.opmode_5g.options[3].value = "9";
				cf.opmode_5g.disabled=true;// bug 34916, grey out mode, this region not support both HT20 and HT40
				$('#opmode5g').css({'background-color':'#ebebe4'});
			}
			else{
				cf.opmode_5g.options.length = 4;
				cf.opmode_5g.options[0].text = wlan_mode_1;
				cf.opmode_5g.options[1].text = an_wlan_mode_1;
				cf.opmode_5g.options[2].text = an_wlan_mode_2;
				cf.opmode_5g.options[3].text = an_wlan_mode_3;
				cf.opmode_5g.options[0].value = "1";
				cf.opmode_5g.options[1].value = "7";
				cf.opmode_5g.options[2].value = "8";
				cf.opmode_5g.options[3].value = "9";
				if ( mode5g == '1' )
					cf.opmode_5g.selectedIndex = 0;
				else if ( mode5g == '7')
					cf.opmode_5g.selectedIndex = 1;
				else if ( mode5g == '8' )
                                        cf.opmode_5g.selectedIndex = 2;
				else // mode_an == '3' '5' '6' '9'
					cf.opmode_5g.selectedIndex = 3;
				cf.opmode_5g.disabled=false;
				$('#opmode5g').css({'background-color':'#fff'});
			}
			$('#opmode5g').trigger('change');
		};

		$.setANwlan_mode = function() {
			var cf = document.forms["wifiSettingsForm"];
			var index = cf.wregion.value;
			var currentMode = cf.opmode_5g.selectedIndex;

			// bug 34916, change index number to region name, make the code easy to read and change.
			if (index == "0" || index == "5" || index == "16" || index == "17")
			{ //Israel,Middle East(Turkey/Egypt/Tunisia/Kuwait) Middle East(Saudi Arabia) Africa
				cf.opmode_5g.options.length = 2;
				cf.opmode_5g.options[0].text = an_wlan_mode_1;
				cf.opmode_5g.options[1].text = an_wlan_mode_2;
				cf.opmode_5g.options[0].value = "1";
				cf.opmode_5g.options[1].value = "2";
				cf.opmode_5g.selectedIndex = 1;
				cf.opmode_5g.disabled=true;// bug 34916, grey out mode, this region not support both HT20 and HT40
				$('#opmode5g').css({'background-color':'#ebebe4'});
			}
			else if ( index == "14" )
			{               // Middle East(Algeria/Syria/Yemen), this country do not support HT20 HT40,grayout channel
				cf.channel_5g.selectedIndex=0;
				cf.opmode_5g.selectedIndex=0;
				cf.channel_5g.disabled=true;
				$('#channel5g').css({'background-color':'#ebebe4'});
				cf.opmode_5g.options.length = 3;
				cf.opmode_5g.options[0].text = an_wlan_mode_1;
				cf.opmode_5g.options[1].text = an_wlan_mode_2;
				cf.opmode_5g.options[2].text = an_wlan_mode_3;
				cf.opmode_5g.options[0].value = "1";
				cf.opmode_5g.options[1].value = "2";
				cf.opmode_5g.options[2].value = "3";
				cf.opmode_5g.disabled=true;// bug 34916, grey out mode, this region not support both HT20 and HT40
				$('#opmode5g').css({'background-color':'#ebebe4'});
			}

			else{
				cf.opmode_5g.options.length = 3;
				cf.opmode_5g.options[0].text = an_wlan_mode_1;
				cf.opmode_5g.options[1].text = an_wlan_mode_2;
				cf.opmode_5g.options[2].text = an_wlan_mode_3;
				cf.opmode_5g.options[0].value = "1";
				cf.opmode_5g.options[1].value = "2";
				cf.opmode_5g.options[2].value = "3";
				if ( mode5g == '1' || mode5g == '7' )
					cf.opmode_5g.selectedIndex = 0;
				else if ( mode5g == '2' || mode5g == '8' )
					cf.opmode_5g.selectedIndex = 1;
				else // mode_an == '3' '5' '6' '9'
					cf.opmode_5g.selectedIndex = 2;
				cf.opmode_5g.disabled=false;
				$('#opmode5g').css({'background-color':'#fff'});
			}
			$('#opmode5g').trigger('change');
		};

		$.setAChannel = function(channel) {
			var index = document.getElementById("wRegion").value;
			var currentMode = document.getElementById("opmode5g").value;
			var option_array = document.getElementById("channel5g").options;
			var chValue = channel.value;
			var find_value = 0;
			var i, j = 0, val;
			var tmp_array = ht40_array[index];

			if ( 1 == currentMode || 2 == currentMode || 7 == currentMode )
			{
				tmp_array = ht20_array[index];
			}
			else if( 9 == currentMode)
			{
				tmp_array = ht80_array[index];
			}

			channel.options.length = tmp_array.length+1;

			if ( dfs_channel_router_flag == 1 ) //Australia, Canada, Europe
			{
				channel.options[j].value = 0;
				channel.options[j].text = Auto;
				j++;
			}

			for ( i = 0; i < tmp_array.length; i++ )
			{
				if ( tmp_array[i].indexOf("(DFS)") > -1 )
				{
					if ( 0 == hidden_dfs_channel && ( 1 == dfs_channel_router_flag ||
						( dfs_channel2_router_flag == 1 &&  index == 4 ) //Australia, Canada, Europe
						) ) //Japan, United States
					{
						val =  tmp_array[i].split("(DFS)")[0];
						channel.options[j].value = val;
						channel.options[j].text = tmp_array[i];
						j++;
					}
				}
				else
				{
					if(currentMode == 9 && index == 21)//50244
						if(tmp_array[i] == "60" || tmp_array[i] == "64")
							continue;
					if( index == 17 && (tmp_array[i] == "149" || tmp_array[i] == "153" || tmp_array[i] == "157" || tmp_array[i] == "161") )//53381
						continue;
					channel.options[j].value = channel.options[j].text = tmp_array[i];
					j++;
				}
			}
			channel.options.length = j;

			for(i=0; i<option_array.length; i++)
			{
				if(option_array[i].value == chValue)
				{
					find_value = 1;
					channel.selectedIndex = i;
					break
				}
			}
			if (find_value == 0)
			{/* to fix bug 27403 */
				for(i=0;i<option_array.length;i++)
				{
					if(option_array[i].value == wla_get_channel)
					{
						find_value = 1;
						channel.selectedIndex = i;
						break;
					}
				}
			}
			if(find_value == 0)
				channel.selectedIndex = 0;

		};


		$.changeWEPShowHidden = function() {
			var secOptions = document.getElementById('secType'),
			sel = secOptions.value;
			if ($('#opmode').val() != '1') {
				$("#secType option[value='2']").remove();
			} else {
				if ( confMode == "0" ) {
					secOptions.options[2].value = '2';
					secOptions.options[2].text = sec_wep_phrase;
					secOptions.options[3].value = '6';
					secOptions.options[3].text = sec_wpa2_phrase;
					secOptions.options[4] = new Option(sec_wpas_phrase, '7');
				} else {
					secOptions.options[1].value = '2';
					secOptions.options[1].text = sec_wep_phrase;
					secOptions.options[2].value = '6';
					secOptions.options[2].text = sec_wpa2_phrase;
					secOptions.options[3] = new Option(sec_wpas_phrase, '7');
				}
				$('#secType').val(sel);
			}
			$('#secType').trigger('change');
		};

		$.changeWEPShowHidden5g = function() {
			var secOptions = document.getElementById('secType5g'),
			sel = secOptions.value;
			if ($('#opmode5g').val() != '1') {
				$("#secType5g option[value='2']").remove();
			} else {
				if ( confMode == "0" ) {
					secOptions.options[2].value = '2';
					secOptions.options[2].text = sec_wep_phrase;
					secOptions.options[3].value = '6';
					secOptions.options[3].text = sec_wpa2_phrase;
					secOptions.options[4] = new Option(sec_wpas_phrase, '7');
				} else {
					secOptions.options[1].value = '2';
					secOptions.options[1].text = sec_wep_phrase;
					secOptions.options[2].value = '6';
					secOptions.options[2].text = sec_wpa2_phrase;
					secOptions.options[3] = new Option(sec_wpas_phrase, '7');
				}
				$('#secType5g').val(sel);
			}
			$('#secType5g').trigger('change');
		};

		$.changeModeShowHidden = function(id) {
			var options = 3,
			i = 0,
			selectMode = $('#opmode').val();
			if($('#'+id).val() == '2' && ($('#whatPwd').val() == '0' || confMode == "0")) {
				options = 1;
			}
			$('#opmode').empty();
			for ( ; i < options; i++ ) {
				if ( selectMode == modeValue[i] )
					$('<option value="'+modeValue[i]+'" selected>'+modeArray[i]+'</option>').appendTo('#opmode');
				else
					$('<option value="'+modeValue[i]+'">'+modeArray[i]+'</option>').appendTo('#opmode');
			}
		};

		$.changeModeShowHidden5g = function(id) {
			var options = 4,
			i = 0,
			selectMode5g = $('#opmode5g').val();
			if($('#'+id).val() == '2' && ($('#whatPwd5g').val() == '0' || confMode == "0")) {
				options = 1;
			}
			$('#opmode5g').empty();
			for ( ; i < options; i++ ) {
				if ( selectMode5g == modeValue5g[i] )
					$('<option value="'+modeValue5g[i]+'" selected>'+modeArray5g[i]+'</option>').appendTo('#opmode5g');
				else
					$('<option value="'+modeValue5g[i]+'">'+modeArray5g[i]+'</option>').appendTo('#opmode5g');
			}
		};

		$.check_wizard_dhcp = function(check) {
			if(check == 1)
				$('#runTestFlag').val('test');
			else
				$('#runTestFlag').val('no');
			return true;
		}
 
		$.check_static_ip_mask_gtw = function() {
			var ipAddr = $('#ethr1').val()+'.'+$('#ethr2').val()+'.'+$('#ethr3').val()+'.'+$('#ethr4').val(),
			maskAddr = $('#mask1').val()+'.'+$('#mask2').val()+'.'+$('#mask3').val()+'.'+$('#mask4').val(),
			gatewayAddr = $('#gateway1').val()+'.'+$('#gateway2').val()+'.'+$('#gateway3').val()+'.'+$('#gateway4').val(),
			dnsAddr = $('#priAddr1').val()+'.'+$('#priAddr2').val()+'.'+$('#priAddr3').val()+'.'+$('#priAddr4').val();
			if($.checkipaddr(ipAddr) == false || $.is_sub_or_broad(ipAddr, ipAddr, maskAddr) == false) {
				$.addErrMsgAfter('ethr4', ip_invalid);
				return false;
			}
			if((maskAddr == "0.0.0.0") || (maskAddr == "255.255.255.255")) {
				$.addErrMsgAfter('mask4', subnet_invalid);
				return false;
			}
			if($.checksubnet(maskAddr) == false) {
				$.addErrMsgAfter('mask4', subnet_invalid);
				return false;
			}
			if($.checkgateway(gatewayAddr) == false) {
				$.addErrMsgAfter('gateway4', gateway_invalid);
				return false;
			}
			if($.isGateway(ipAddr,maskAddr,gatewayAddr) == false) {
				$.addErrMsgAfter('gateway4', gateway_invalid);
				return false;
			}
			if($.isSameIp(ipAddr, gatewayAddr) == true) {
				$.addErrMsgAfter('gateway4', gateway_invalid);
				return false;
			}
			if($.isSameSubNet(ipAddr,maskAddr,gatewayAddr,maskAddr) == false) {
				$.addErrMsgAfter('gateway4', same_subnet_ip_gtw);
				return false;
			}
			if($.checkipaddr(dnsAddr) == false) {
				$.addErrMsgAfter('priAddr4', primary_dns_invalid);
				return false;
			}
			if($.check_wizard_dhcp(0) == false)
				return false;
			return true;
		}

		$.setAble = function(flag) {
			if ( flag == "0" ) {
				$('#ipStart4').prop("disabled", false);
				$('#ipEnd4').prop("disabled", false);
			} else if ( flag == "1" ) {
				$('#ipStart4').prop("disabled", true);
				$('#ipEnd4').prop("disabled", true);
			}
		};

		$.returnTop = function(id_flag) {
			var mao = $(id_flag);
			if(mao.length > 0) {
				var pos = mao.offset();
				$("body,html").animate({scrollTop:pos.top}, 1000);
			}
		}

		$.wpsDisplay = function(id) {
			$.checkBoxs(id);
			if(wps_protect_pin_flag == '1') {
				if(($('#enablePIN').is(':checked') == false) || ($('#enablePIN').prop('disabled') == true))
					$('#wladv_appin_cfg').hide();
				else
					$('#wladv_appin_cfg').show();
				if($('#autoDisablePIN').prop('checked'))
					$('#numberOfEntries').prop("disabled", false);
				else
					$('#numberOfEntries').prop("disabled", true);
			} else {
				$('#wladv_appin_cfg').hide();
			}
		}

		$.expandedAllSection = function() {
			$('.sectionWrap').find('.expand')
				.find('i')
				.removeClass('dnintg-collapsed')
				.addClass('dnintg-expanded')
				.parents('.sectionWrap')
				.addClass('open')
				.find('.sectionDetails')
				.slideDown();
		}

		if ($('#wifiSettingsForm').length) {
			if(rootSecurity == '8' || rootSecurity == "3" || rootSecurity == "4" || rootSecurity == "5")
				rootSecurity = '7';

			if(root5gSecurity == '8' || root5gSecurity == "3" || root5gSecurity == "4" || root5gSecurity == "5")
				root5gSecurity = '7';

			if ( confMode != "2" ) {
				$('.whatPwdLi').hide();
				$('option:first', '#secType').after('<option value="1">'+none+'</option>');
				$('.ethernet').hide();
			}else{
				if(!(link_status == "1" && link_status_5g == "1"))
					$('.ethernet').hide();
			}

			if ( confMode != "2" )
			{
				$('.whatPwdLi5g').hide();
				$('option:first', '#secType5g').after('<option value="1">'+none+'</option>');
			}

			if (region == '12')
				$('#wRegion').val('4');
			else
				$('#wRegion').val(region);
			$('#ssid').val(SSID);
			$('#ssid5g').val(SSID5g);

			if(APEnable == '1')
				$('#enableAp').prop('checked', true);
			else
				$('#enableAp').prop('checked', false);

			if(APEnable5g == '1')
				$('#enableAp5g').prop('checked', true);
			else
				$('#enableAp5g').prop('checked', false);

			if(broadcast == '1')
				$('#ssidBc').prop('checked', true);
			else
				$('#ssidBc').prop('checked', false);

			if(broadcast5g == '1')
				$('#ssidBc5g').prop('checked', true);
			else
				$('#ssidBc5g').prop('checked', false);

			if(disCoext == '0')
				$('#enableCoexist').prop('checked', true);
			else
				$('#enableCoexist').prop('checked', false);

			$('#channel').val(channel);
			$.setChannel();

			$('#channel5g').val(channel5g);
			$.setChannel5g(1);

			if(mode == '3' || mode == '5' || mode == '6')
				$('#opmode').val('3');
			else if(mode == '2')
				$('#opmode').val('2');
			else
				$('#opmode').val('1');

			if(mode5g == '9')
				$('#opmode5g').val('9');
			else if(mode5g == '8')
				$('#opmode5g').val('8');
			else if(mode5g == '7')
                                $('#opmode5g').val('7');
			else
				$('#opmode5g').val('1');

			$.changeWEPShowHidden();
			$.changeWEPShowHidden5g();

			if(confMode == '2'){
				if( fastlane_type == "1" ){
					$('.ethernet').hide();
					if( furfing_mode_type == "2.4G" ){
						$('.column.first.wifi').hide();
						$('.column.first.continue').hide();
					}
					else{
						$('.column.second.wifi').hide();
						$('.column.second.continue').hide();
					}
				}
			}

			if(link_status == '1' && confMode == '2') {
				$('#enableCoexistRow').addClass('hide');
				$('#channel').prop("disabled", true);
				$('#channel').css({'background-color':'#ebebe4'});
				$('#opmode').prop("disabled", true);
				$('#opmode').css({'background-color':'#ebebe4'});
			} else {
				$('#enableCoexistRow').removeClass('hide');
				$('#channel').prop("disabled", false);
				$('#opmode').prop("disabled", false);
			}


			if(link_status_5g == '1' && confMode == '2') {
				$('#enableCoexistRow5g').addClass('hide');
				$('#channel5g').prop("disabled", true);
				$('#channel5g').css({'background-color':'#ebebe4'});
				$('#opmode5g').prop("disabled", true);
				$('#opmode5g').css({'background-color':'#ebebe4'});
			} else {
				$('#enableCoexistRow5g').removeClass('hide');
				$('#channel5g').prop("disabled", false);
				$('#opmode5g').prop("disabled", false);
			}

			if(sameSec == '0' || confMode != "2" ) {
				$('.securityOptionsWrap.first').show();
				$('#whatPwd').val('0');
				if(security == "2") {
					$('#secType').val('2');
					$('#wepAuth').val(authType);
					$('#wepEnc').val(encrLen);
					$('#wepEnc').trigger('change');
					if(keyNum == '1')
						$('#wepKeyNo1').attr('checked', 'checked');
					else if(keyNum == '2')
						$('#wepKeyNo2').attr('checked', 'checked');
					else if(keyNum == '3')
						$('#wepKeyNo3').attr('checked', 'checked');
					else
						$('#wepKeyNo4').attr('checked', 'checked');
					$('#key1').val(key1);
					$('#key2').val(key2);
					$('#key3').val(key3);
					$('#key4').val(".");
				} else if(security == "3" || security == "6" || security == "7") {
					$('#secType').val(security);
					$('#passphrase').val(password);
					$('#verifyPwd').val(password);
					if(password.length >= $.MIN_PWD_CHARACTERS)
						$('#verifyPwd').prop('disabled', false);
					else
						$('#verifyPwd').prop('disabled', true);
				} else if ( confMode != "2" && security == "1" ) {
					$('#secType').val('1');
				} else {
					$('#secType').val('0');
				}
			} else {
				$('#secType').val('0');
				$('.securityOptionsWrap.first').hide();
				if(security == "1") {
					$('#whatPwd').val('2');
				} else {
					$('#whatPwd').val('1');
				}
			}
			$('#secType').trigger('change');

			if(sameSec5g == '0' || confMode != "2" ) {
				$('.securityOptionsWrap.second').show();
				$('#whatPwd5g').val('0');
				if(security5g == "2" || security5g == "8") {
					$('#secType5g').val('2');
					$('#wepAuth5g').val(authType5g);
					$('#wepEnc5g').val(encrLen5g);
					$('#wepEnc5g').trigger('change');
					if(keyNum5g == '1')
						$('#wepKeyNo5g1').attr('checked', 'checked');
					else if(keyNum5g == '2')
						$('#wepKeyNo5g2').attr('checked', 'checked');
					else if(keyNum5g == '3')
						$('#wepKeyNo5g3').attr('checked', 'checked');
					else
						$('#wepKeyNo5g4').attr('checked', 'checked');
					$('#key5g1').val(key5g1);
					$('#key5g2').val(key5g2);
					$('#key5g3').val(key5g3);
					$('#key5g4').val(".");
				} else if(security5g == "3" || security5g == "6" || security5g == "5" || security5g == "7" || security5g == "9") {
					$('#secType5g').val(security5g);
					$('#passphrase5g').val(password5g);
					$('#verifyPwd5g').val(password5g);
					if(password5g.length >= $.MIN_PWD_CHARACTERS)
						$('#verifyPwd5g').prop('disabled', false);
					else
						$('#verifyPwd5g').prop('disabled', true);
				} else if ( confMode != "2" && security5g == "1" ) {
					$('#secType5g').val('1');
				} else {
					$('#secType5g').val('0');
				}
			} else {
				$('#secType5g').val('0');
				$('.securityOptionsWrap.second').hide();
				if(security5g == "1") {
					$('#whatPwd5g').val('2');
				} else {
					$('#whatPwd5g').val('1');
				}
			}
			$('#secType5g').trigger('change');

			$.checkPass();
			$.checkPass5g();

			setTimeout(function() {
				if(security == "2") {
					$('#key4').val(key4);
					$('#passphrase').val("");
					$('#verifyPwd').val("");
				} else if(security == "3" || security == "6" || security == "7") {
					$('#key4').val("");
					$('#passphrase').val(password);
					$('#verifyPwd').val(password);
				} else {
					$('#key4').val("");
					$('#passphrase').val("");
					$('#verifyPwd').val("");
				}
				$('#key4').removeAttr('style');
			}, $.chromeTimer);

			setTimeout(function() {
				if(security5g == "2") {
					$('#key5g4').val(key5g4);
					$('#passphrase5g').val("");
					$('#verifyPwd5g').val("");
				} else if(security5g == "3" || security5g == "6" || security5g == "5" || security5g == "7" || security5g == "9") {
					$('#key5g4').val("");
					$('#passphrase5g').val(password5g);
					$('#verifyPwd5g').val(password5g);
				} else {
					$('#key5g4').val("");
					$('#passphrase5g').val("");
					$('#verifyPwd5g').val("");
				}
				$('#key5g4').removeAttr('style');
			}, $.chromeTimer);

			$('option', '#opmode').each(function(i, ele){
				modeArray[i] = $(ele).html();
				modeValue[i] = $(ele).attr("value");
			});
			$.changeModeShowHidden("secType");

			$('option', '#opmode5g').each(function(i, ele){
				modeArray5g[i] = $(ele).html();
				modeValue5g[i] = $(ele).attr("value");
			});
			$.changeModeShowHidden5g("secType5g");

			$('#deviceName').val(deviceName);

			if(lanTypeOpt == '0') {
				$('input', '.ipAddressInput').prop("disabled", false);
				$('#staticAssign').attr('checked', 'checked');
			} else {
				$('input', '.ipAddressInput').prop("disabled", true);
				$('#dhcpAssign').attr('checked', 'checked');
			}

			if(ether_get_ip != "") {
				var ip_array = ether_get_ip.split('.');
				$('#ethr1').val(ip_array[0]);
				$('#ethr2').val(ip_array[1]);
				$('#ethr3').val(ip_array[2]);
				$('#ethr4').val(ip_array[3]);
			}

			if(ether_get_subnet != "") {
				var mask_array=ether_get_subnet.split('.');
				$('#mask1').val(mask_array[0]);
				$('#mask2').val(mask_array[1]);
				$('#mask3').val(mask_array[2]);
				$('#mask4').val(mask_array[3]);
			}

			if(ether_get_gateway != "") {
				var gtw_array=ether_get_gateway.split('.');
				$('#gateway1').val(gtw_array[0]);
				$('#gateway2').val(gtw_array[1]);
				$('#gateway3').val(gtw_array[2]);
				$('#gateway4').val(gtw_array[3]);
			}

			if(ether_get_dns1 != "") {
				var dns_array=ether_get_dns1.split('.');
				$('#priAddr1').val(dns_array[0]);
				$('#priAddr2').val(dns_array[1]);
				$('#priAddr3').val(dns_array[2]);
				$('#priAddr4').val(dns_array[3]);
			}

			if(dhcpTypeOpt == '1') {
				$('input', '.dhcpAddressInput').prop("disabled", false);

				$('#enableAssign').attr('checked', 'checked');
				$.setAble("0");
			} else {
				$('input', '.dhcpAddressInput').prop("disabled", true);
				$('#disableAssign').attr('checked', 'checked');
				$.setAble("1");
			}
			if(ether_get_ip != "") {
				var ip_array = ether_get_ip.split('.');
				$('#ipStart1').val(ip_array[0]);
				$('#ipStart2').val(ip_array[1]);
				$('#ipStart3').val(ip_array[2]);
				$('#ipEnd1').val(ip_array[0]);
				$('#ipEnd2').val(ip_array[1]);
				$('#ipEnd3').val(ip_array[2]);
			}
			if(dhcpStart != "")
				$('#ipStart4').val(dhcpStart.split('.')[3]);
			if(dhcpEnd != "")
				$('#ipEnd4').val(dhcpEnd.split('.')[3]);
			if(liveboxDetect == '1')
				$("#dhcp_able").show();
			else
				$("#dhcp_able").hide();

			if(wps_protect_pin_flag == '1') {
				$('#wladv_enable_wps').show();
			} else {
				$('#wladv_enable_wps').hide();
			}

			if(WPSenable == '0') {
				$('#wladv_pin').css({"color": "gray"});
				$('#wladv_enable_wps').css({"color": "gray"});
				$('#wladv_keep_exist').css({"color": "gray"});
				$('#wladv_keep_exist_5g').css({"color": "gray"});
				$('#wladv_appin_cfg').css({"color": "gray"});
				$('#enablePIN').prop("disabled", true);
				$('#autoDisablePIN').prop("disabled", true);
				$('#numberOfEntries').prop("disabled", true);
				$('#keepSettings').prop("disabled", true);
			}

			if((enableToggle == '1') || (lockDown == '1')) {
				$('#enablePIN').prop('checked', false);
				$('.pinWrap').css({"background-color": "gray"});
			} else {
				$('#enablePIN').prop('checked', true);
			}

			if(wps_protect_pin_flag == '1') {
				if(WPSProtect == '0')
					$('#autoDisablePIN').prop('checked', false);
				else
					$('#autoDisablePIN').prop('checked', true);
			}

			if(WPSStatus == '5')
				$('#keepSettings').prop('checked', true);
			else
				$('#keepSettings').prop('checked', false);

			$.wpsDisplay();

			$('#opmode').change(function() {
				$.changeWEPShowHidden();
			});
			$('#opmode5g').change(function() {
				$.changeWEPShowHidden5g();
			});

			$('#secType').change(function() {
				$.changeModeShowHidden("secType");
			});

			$('#secType5g').change(function() {
				$.changeModeShowHidden5g("secType5g");
			});

			$('.secondary').click(function() {
				top.location.href = "wifiSettings.htm" + $.ID_2;
			});

			$('.primary[id!=continueBt]').click(function(){
				$('.errorMsg').remove();

				if( wps_progress_status == "2" ) {
					$.alertBox(wps_in_progress);
					return false;
				}

				if ( !$.REG_SSID.test($('#ssid').val()) ) {
					$.addErrMsgAfter('ssid',ssid_invalid);
					$.returnTop("#fixedtop");
					return false;
				}

				if ( !$.REG_SSID.test($('#ssid5g').val()) ) {
					$.addErrMsgAfter('ssid5g',ssid_invalid);
					$.returnTop("#fixedtop");
					return false;
				}

				$.checkSecurity('secType', 'wepEnc', 'passphrase');
				$.checkSecurity5g('secType5g', 'wepEnc5g', 'passphrase5g');

				$('#wifiRegion').val($('#wRegion').val());
				$('#wifi2GHzSSID').val($.do_xss_ssid($('#ssid').val()));
				$('#wifi5GHzSSID').val($.do_xss_ssid($('#ssid5g').val()));

				if($('#ssidBc').prop('checked'))
					$('#wifiSSIDBroadcast').val('1');
				else
					$('#wifiSSIDBroadcast').val('0');

				if($('#ssidBc5g').prop('checked'))
					$('#wifiSSIDBroadcast5g').val('1');
				else
					$('#wifiSSIDBroadcast5g').val('0');

				if($('#enableAp').prop('checked'))
					$('#wifiAPMode').val('1');
				else
					$('#wifiAPMode').val('0');

				if($('#enableAp5g').prop('checked'))
					$('#wifiAPMode5g').val('1');
				else
					$('#wifiAPMode5g').val('0');

				if($('#enableCoexist').prop('checked'))
					$('#wifiCoext').val('0');
				else
					$('#wifiCoext').val('1');

				$('#wifiCoext5g').val('0');

				$('#wifiChannel').val($('#channel').val());
				$('#wifiChannel5g').val($('#channel5g').val());

				if($('#secType').val() == '2')
					$('#clientMode').val(1);
				else
					$('#clientMode').val($('#opmode').val());

				if($('#secType5g').val() == '2') {
					/*if (ac_router_flag == 1)
						$('#clientMode5g').val(7);
					else*/
						$('#clientMode5g').val(1);
				} else {
					$('#clientMode5g').val($('#opmode5g').val());
				}

				if($('#whatPwd').val() == '2') {
					$('#wifiPwd').val('2');
					$('#wifiSecOptions').val('1');
				} else if($('#whatPwd').val() == '0') {
					$('#wifiPwd').val('0');
					if($('#secType').val() == '2') {
						$('#wifiSecOptions').val('2');
						if($('#wepAuth').val() == '1')
							$('#wifiWEPAuthType').val('1');
						else
							$('#wifiWEPAuthType').val('2');
						if($('#wepEnc').val() == '5')
							$('#wifiWEPEncrStr').val('5');
						else
							$('#wifiWEPEncrStr').val('13');
						$('#wifi2GHzKeyNum').val($('input:radio[name="wep_key_no"]:checked').val());
						$('#wifiWEPKey1').val($.do_xss_pass($('#key1').val()));
						$('#wifiWEPKey2').val($.do_xss_pass($('#key2').val()));
						$('#wifiWEPKey3').val($.do_xss_pass($('#key3').val()));
						$('#wifiWEPKey4').val($.do_xss_pass($('#key4').val()));
						$('.column.first ul strong:last', '#continue').html($.xss_format($('#wifiWEPKey'+$('#wifi2GHzKeyNum').val()).val()));
					} else {
						if($('#secType').val() == '3')
							$('#wifiSecOptions').val('3');
						else if($('#secType').val() == '6')
							$('#wifiSecOptions').val('6');
						else if ( confMode != "2" && $('#secType').val() == '1')
							$('#wifiSecOptions').val('1');
						else
							$('#wifiSecOptions').val('7');
						if($('.verifyPwd').val() != $('.primaryPwd').val() && $('.primaryPwd').val().length >= $.MIN_PWD_CHARACTERS) {
							$('.verifyPwd').addClass('alert');
							$.addErrMsgAfter('verifyPwd', error_not_same_pwd, false, 'err_passsame');
							$.returnTop("#ssid");
							return false;
						}
						$('#wifi2GHzPassword').val($.do_xss_pass($('#passphrase').val()));
						$('.column.first ul strong:last', '#continue').html($.xss_format($('#passphrase').val()));
					}
				} else {
					$('#wifiPwd').val('1');
					$('#wifiSecOptions').val(rootSecurity);
					if(rootSecurity == "2") {
						$('#wifiWEPAuthType').val(rootAuthType);
						$('#wifiWEPEncrStr').val(rootEncrLen);
						$('#wifi2GHzKeyNum').val(rootKeyNum);
						$('#wifiWEPKey1').val($.do_xss_pass(rootKey1));
						$('#wifiWEPKey2').val($.do_xss_pass(rootKey2));
						$('#wifiWEPKey3').val($.do_xss_pass(rootKey3));
						$('#wifiWEPKey4').val($.do_xss_pass(rootKey4));
					} else if(rootSecurity != "1") {
						$('#wifi2GHzPassword').val($.do_xss_pass(rootPassword));
					}
					$('.column.first ul strong:last', '#continue').html($.xss_format($.showPassKey(rootSecurity, rootKeyNum, "root")));
				}

				if($('#whatPwd5g').val() == '2') {
					$('#wifiPwd5g').val('2');
					$('#wifiSecOptions5g').val('1');
				} else if($('#whatPwd5g').val() == '0') {
					$('#wifiPwd5g').val('0');
					if($('#secType5g').val() == '2') {
						$('#wifiSecOptions5g').val('2');
						if($('#wepAuth5g').val() == '1')
							$('#wifiWEPAuthType5g').val('1');
						else
							$('#wifiWEPAuthType5g').val('2');
						if($('#wepEnc5g').val() == '5')
							$('#wifiWEPEncrStr5g').val('5');
						else
							$('#wifiWEPEncrStr5g').val('13');
						$('#wifi5GHzKeyNum').val($('input:radio[name="wep_key_no_5g"]:checked').val());
						$('#wifiWEPKey5g1').val($.do_xss_pass($('#key5g1').val()));
						$('#wifiWEPKey5g2').val($.do_xss_pass($('#key5g2').val()));
						$('#wifiWEPKey5g3').val($.do_xss_pass($('#key5g3').val()));
						$('#wifiWEPKey5g4').val($.do_xss_pass($('#key5g4').val()));
						$('.column.second ul strong:last', '#continue').html($.xss_format($('#wifiWEPKey5g'+$('#wifi5GHzKeyNum').val()).val()));
					} else {
						if($('#secType5g').val() == '3')
							$('#wifiSecOptions5g').val('3');
						else if($('#secType5g').val() == '6')
							$('#wifiSecOptions5g').val('6');
						else if ( confMode != "2" && $('#secType5g').val() == '1')
							$('#wifiSecOptions5g').val('1');
						else
							$('#wifiSecOptions5g').val('7');
						if($('#verifyPwd5g').val() != $('#passphrase5g').val() && $('#passphrase5g').val().length >= $.MIN_PWD_CHARACTERS) {
							$('#verifyPwd5g').addClass('alert');
							$.addErrMsgAfter('verifyPwd5g', error_not_same_pwd, false, 'err_passsame');
							$.returnTop("#ssid5g");
							return false;
						}
						$('#wifi5GHzPassword').val($.do_xss_pass($('#passphrase5g').val()));
						$('.column.second ul strong:last', '#continue').html($.xss_format($('#passphrase5g').val()));
					}
				} else {
					$('#wifiPwd5g').val('1');
					$('#wifiSecOptions5g').val(root5gSecurity);
					if(root5gSecurity == "2") {
						$('#wifiWEPAuthType5g').val(root5gAuthType);
						$('#wifiWEPEncrStr5g').val(root5gEncrLen);
						$('#wifi2GHzKeyNum5g').val(root5gKeyNum);
						$('#wifiWEPKey5g1').val($.do_xss_pass(root5gKey1));
						$('#wifiWEPKey5g2').val($.do_xss_pass(root5gKey2));
						$('#wifiWEPKey5g3').val($.do_xss_pass(root5gKey3));
						$('#wifiWEPKey5g4').val($.do_xss_pass(root5gKey4));
					} else if(root5gSecurity != "1") {
						$('#wifi5GHzPassword').val($.do_xss_pass(root5gPassword));
					}
					$('.column.second ul strong:last', '#continue').html($.xss_format($.showPassKey(root5gSecurity, root5gKeyNum, "root5g")));
				}

				if ( $('#staticAssign').is(':checked') ) {
					if($.check_static_ip_mask_gtw() == false) {
						$.expandedAllSection();
						$.returnTop("#ipAddressSection");
						return false;
					}
				}

				$('#etherIPAddr').val($('#ethr1').val()+'.'+$('#ethr2').val()+'.'+$('#ethr3').val()+'.'+$('#ethr4').val());
				$('#etherSubnet').val($('#mask1').val()+'.'+$('#mask2').val()+'.'+$('#mask3').val()+'.'+$('#mask4').val());
				$('#etherGateway').val($('#gateway1').val()+'.'+$('#gateway2').val()+'.'+$('#gateway3').val()+'.'+$('#gateway4').val());
				$('#etherDNSAddr1').val($('#priAddr1').val()+'.'+$('#priAddr2').val()+'.'+$('#priAddr3').val()+'.'+$('#priAddr4').val());

				if ( $('#enableAssign').is(':checked') )
					$('#etherDHCPAssign').val('1');
				else
					$('#etherDHCPAssign').val('0');

				$('#etherDHCPStart').val($('#ipStart1').val()+'.'+$('#ipStart2').val()+'.'+$('#ipStart3').val()+'.'+$('#ipStart4').val());
				$('#etherDHCPEnd').val($('#ipEnd1').val()+'.'+$('#ipEnd2').val()+'.'+$('#ipEnd3').val()+'.'+$('#ipEnd4').val());

				if(WPSStatus == '5' && $('#keepSettings').is(':checked') == false){
					$('#keep2GhzSettings').val('1');
					$('#keep5GhzSettings').val('1');
				}
				else{
					$('#keep2GhzSettings').val('5');
					$('#keep5GhzSettings').val('5');
				}

				if(protectPINFlag == 1) {
					if($('#enablePIN').prop('checked'))
						$('#wifiEnablePIN').val('0');
					else
						$('#wifiEnablePIN').val('1');
					if($('#autoDisablePIN').prop('checked'))
						$('#wifiDisablePIN').val('1');
					else
						$('#wifiDisablePIN').val('0');
					if($('#numberOfEntries').val() == '')
						$('#numOfEntries').val('3');
					else
						$('#numOfEntries').val($('#numberOfEntries').val());
				}

				if ( !$('.errorMsg').length ) {
					if($('#wifiSecOptions').val() == '1' || $('#wifiSecOptions5g').val() == '1') {
						$.confirmBox(wps_warning3, null, function(){
							$.submitSameIP();
						}, null, null);
					} else if($('#wifiSecOptions').val() == '2' || $('#wifiSecOptions').val() == '3' || $('#wifiSecOptions5g').val() == '2' || $('#wifiSecOptions5g').val() == '3') {
						$.confirmBox(wps_warning2, null, function(){
							$.submitSameIP();
						}, null, null);
					} else {
						$.submitSameIP();
					}
				} else {
					$.returnTop("#ssid");
					return false;
				}
			});

			$.submitSameIP = function() {
				if($('#staticAssign').is(':checked')) {
					if($.isSameIp($('#etherIPAddr').val(), old_lan_ip) == false) {
						$.confirmBox(changelanip + $('#etherIPAddr').val() + " ?", null, function() {
							$.alertBox(changelanip_renew, null, function() {
								$('#changeIPFlag').val('1');
								$.submitApply();
							});
						}, null, null);
					} else {
						$('#changeIPFlag').val('0');
						$.submitApply();
					}
				} else {
					$('#changeIPFlag').val('0');
					$.submitApply();
				}
			}

			$.submitApply = function() {
				$.submit_wait('.main:first', $.PAGE_APPLYING_DIV);
				$.returnTop("#fixedtop");
				$('input[name=submit_flag]', '#wifiSettingsForm').val("wifi_settings");
				$.postForm('#wifiSettingsForm', '', function(json) {
					if ( json.status == '1' ) {
						var time = parseInt(json.wait) * 1000;
						if ( $.isMac || $.isPhonePad)
							time = 1000;
						setTimeout(function() {
							$('#wifiSettingsDiv').hide();
							$('.running').remove();
							$('#continue').show();
							$('.continue').hide();
							if($('#enableAp').prop('checked'))
								$('.first.continue').show();
							if($('#enableAp5g').prop('checked'))
								$('.second.continue').show();
							if(confMode == '2') {
								$('.extender').show();
								$('.accesspoint').hide();
							} else {
								$('.extender').hide();
								$('.accesspoint').show();
							}
							$('#fixedFooter').show();
							$('#continueBt').click(function() {
								$.change_domain(json.url);
							});
						}, time);
					} else {
						$.alertBox(json.msg);
					}
				});
				$('.column.first ul strong:first', '#continue').html($.xss_format($('#ssid').val()));
				$('.column.first ul strong:eq(1)', '#continue').html($.formatSecType($('#wifiSecOptions').val()));
				if($('#wifiSecOptions').val() == "1")
					$('.column.first ul li:last', '#continue').hide();

				$('.column.second ul strong:first', '#continue').html($.xss_format($('#ssid5g').val()));
				$('.column.second ul strong:eq(1)', '#continue').html($.formatSecType($('#wifiSecOptions5g').val()));
				if($('#wifiSecOptions5g').val() == "1")
					$('.column.second ul li:last', '#continue').hide();

			}
		}

		/*******************************************************************************************
		*
		*    support own style of checkbox.
		*
		*******************************************************************************************/
		$('body').find(':checkbox').each(function () {
			if($(this).is(':checked')) {
				$(this).addClass('checked');
			} else {
				$(this).removeClass('checked');
			}
		});
		$('body').find(':text,:password,:radio,:checkbox').each(function() {
			$(this).change(function() {
				$('.first').prop('disabled', false);
			});
		});
		$('body').find('select').each(function() {
			$(this).change(function() {
				$('.first').prop('disabled', false);
			});
		});

	}); // end ready function

}(jQuery));
