/**
 * For setup flow
 */
(function ($) {

	"use strict";
	
	var checkNum = 0,
	chooseSSID = new Array(),
	chooseSecurity = new Array(),
	chooseSectype = new Array(),
	chooseMode = new Array(),
	chooseSSID5g = new Array(),
	chooseSecurity5g = new Array(),
	chooseSectype5g = new Array(),
	chooseMode5g = new Array(),
	rootSSID = "",
	securityType = "",
	secType = "",
	simpleMode = "",
	rootSSID5g = "",
	securityType5g = "",
	secType5g = "",
	simpleMode5g = "";

	$.selectWepEncrStr = function(encrStr) {
		var thisParents = $('#'+encrStr).parents('.formElements');
		thisParents.find('#err_wep').remove();
		thisParents.find('.wepPwd').attr('maxlength', $('#'+encrStr).val()*2);
		thisParents.find('.wepPwd').val('');
		$('.btn.primary').prop('disabled', true);
	};

	$(function () {
		/*******************************************************************************************
		*
		*	select networks page
		*
		******************************************************************************************/
		$.checkMode = function(mode, security) {
			var modeType = "";
			if(mode == "G") {
				modeType = "1";
			} else if (mode == "GN20") {
				modeType = "2";
			} else if (mode == "GN40P") {
				modeType = "3";
			} else if (mode == "GN40M") {
				modeType = "5";
			} else if (mode == "GN40") {
				modeType = "6";
			} else {
				modeType = "2";
			}
			return modeType;
		}

		$.chooseExist = function(num){
			var selectItem = $('tr:eq('+num+')', '#availableNetworks'),
			security = $('td:eq(2)', selectItem).html(),
			channel = $('td:eq(3)', selectItem).html();
			rootSSID = chooseSSID[num];
			secType = chooseSectype[num];
			securityType = chooseSecurity[num];
			simpleMode = $.checkMode(chooseMode[num], chooseSecurity[num]);

			$('#2GHzSecurity').val(security);
			$('#2GHzChannel').val(channel);
			$('#2GHzSectype').val(secType);
			$('#2GHzMode').val("6");
			
			$('.column.first').val("checked");

			if( $("#ap5g").is(":checked") == false || ($("#ap5g").is(":checked") == true && ($(".column.second").val() == "checked" || $("#manualNetwork5g").is(":checked")== true)))
				$.enableButton('nextStep', '#selectNetworkForm', 0, true);
			else
				$.enableButton('nextStep', '#selectNetworkForm', 0, false);
		}

		function sortJSON(bef, aft) {
			return aft.signal - bef.signal;
		}

		function generateList() {

			$.getData2('ca_available_network.aspx',function(json){
				if ( typeof(json.list) == 'object') {
					$('#availableNetworks').empty();
					json.list.sort(sortJSON);
					var len = json.list.length;
					var scanResult = '[';
					for(var j=0; j<len-1; j++) {
						scanResult = scanResult + '{"ssid":"' + json.list[j].ssid.replace(/&nbsp;/g, ' ') + '","channel":"' + json.list[j].channel + '","signal":"' + json.list[j].signal + '","security":"' + json.list[j].security + '","sectype":"' + json.list[j].sectype + '","mode":"' + json.list[j].mode + '"},';
					}
					scanResult = scanResult + '{"ssid":"' + json.list[len-1].ssid.replace(/&nbsp;/g, ' ') + '","channel":"' + json.list[len-1].channel + '","signal":"' + json.list[len-1].signal + '","security":"' + json.list[len-1].security + '","sectype":"' + json.list[len-1].sectype + '","mode":"' + json.list[len-1].mode + '"}]';
					$(eval(scanResult)).each(function(i,ele) {
						chooseSSID[i] = ele.ssid;
						chooseSectype[i] = ele.sectype;
						chooseSecurity[i] = ele.security;
						chooseMode[i] = ele.mode;
						var item = "<tr>"
						+ "<td><label title='"+ele.ssid
						+"'><input type='radio' name='sel_network' id='selNetwork"+(i+1)+"' value='"+ele.ssid.replace(/ /g, '%20')
						+"' onclick='$.chooseExist("+i+");' />"
						+ "<span class='phoneLabel'>"+network_name+"</span>"
						+ ele.ssid.replace(/ /g, '&nbsp;') + "</label></td>"
						+ "<td><span class='phoneLabel'>"+signal_strength+"</span>"
						+ "<i class='signalStrength "+$.getSignalType(ele.signal)
						+ "'></i> <span class='largeScreenOnly'>"+ele.signal+"%</span></td>"
						+ "<td title='"+ele.security+"'>" + ele.security + "</td>"
						+ "<td>"+ele.channel+"</td></tr>";
						if(ele.ssid != "" && ele.signal != "" && ele.channel != "" && ele.security != "")
							$('#availableNetworks').append(item);
					});
				}
				$('.wait2g').hide();
				$('#scanning_bg').hide();
			},function (){generateList();} );
		}

		$.chooseExist5g = function(num) {
			var selectItem = $('tr:eq('+num+')', '#availableNetworks5g'),
			security5g = $('td:eq(2)', selectItem).html(),
			channel5g = $('td:eq(3)', selectItem).html();
			rootSSID5g = chooseSSID5g[num];
			secType5g = chooseSectype5g[num];
			securityType5g = chooseSecurity5g[num];
			simpleMode5g = $.checkMode(chooseMode5g[num], chooseSecurity5g[num]);

			$('#5GHzSecurity').val(security5g);
			$('#5GHzChannel').val(channel5g);
			$('#5GHzSectype').val(secType5g);
			$('#5GHzMode').val("9");


			$('.column.second').val("checked");

			if( $("#ap").is(":checked") == false || ($("#ap").is(":checked") == true && ($(".column.first").val() == "checked" || $("#manualNetwork").is(":checked")== true)))
				$.enableButton('nextStep', '#selectNetworkForm', 0, true);
			else
				$.enableButton('nextStep', '#selectNetworkForm', 0, false);
		}

		function generateList5g() {
			$.getData2('ca_available_network_5g.aspx',function(json){
				if ( typeof(json.list) == 'object') {
					$('#availableNetworks5g').empty();
					json.list.sort(sortJSON);
					var len = json.list.length;
					var scanResult = '[';
					for(var j=0; j<len-1; j++) {
						scanResult = scanResult + '{"ssid":"' + json.list[j].ssid.replace(/&nbsp;/g, ' ') + '","channel":"' + json.list[j].channel + '","signal":"' + json.list[j].signal + '","security":"' + json.list[j].security + '","sectype":"' + json.list[j].sectype + '","mode":"' + json.list[j].mode + '"},';
					}
					scanResult = scanResult + '{"ssid":"' + json.list[len-1].ssid.replace(/&nbsp;/g, ' ') + '","channel":"' + json.list[len-1].channel + '","signal":"' + json.list[len-1].signal + '","security":"' + json.list[len-1].security + '","sectype":"' + json.list[len-1].sectype + '","mode":"' + json.list[len-1].mode + '"}]';
					$(eval(scanResult)).each(function(i,ele) {
						chooseSSID5g[i] = ele.ssid;
						chooseSectype5g[i] = ele.sectype;
						chooseSecurity5g[i] = ele.security;
						chooseMode5g[i] = ele.mode;
						var item = "<tr>"
						+ "<td><label title='"+ele.ssid
						+"'><input type='radio' name='sel_network_5g' id='selNetwork"+(i+1)+"5g' value='"+ele.ssid.replace(/ /g, '%20')
						+"' onclick='$.chooseExist5g("+i+");' />"
						+ "<span class='phoneLabel'>"+network_name+"</span>"
						+ ele.ssid.replace(/ /g, '&nbsp;') + "</label></td>"
						+ "<td><span class='phoneLabel'>"+signal_strength+"</span>"
						+ "<i class='signalStrength "+$.getSignalType(ele.signal)
						+ "'></i> <span class='largeScreenOnly'>"+ele.signal+"%</span></td>"
						+ "<td title='"+ele.security+"'>" + ele.security + "</td>"
						+ "<td>"+ele.channel+"</td></tr>";
					if(ele.ssid != "" && ele.signal != "" && ele.channel != "" && ele.security != "")
						$('#availableNetworks5g').append(item);
					});
				}
				$('.wait5g').hide();
				$('#scanning_bg').hide();
			}, function (){ generateList5g();});
		}

		if ( $('#welcomeForm').length) {
			if ( gui_region == "Dutch" || gui_region == "Romanian" )			{
				$('.processButtons').addClass('displayInline');
			}
			if (conf_mode == "2"){
				$('#nextStep').click(function() {
					$.submit_wait('body', $.WAITING_DIV);
					$.postForm('#welcomeForm', '', function(json) {
						if ( json.status == '1' ) {
							location.href = json.url+$.ID_2;
						} else {
							$('.running').remove();
							$.alertBox(json.msg);
						}
					});
				});
			}
		}

		if ( $('#countryForm').length) {
			$('#wRegion').val(wlan_get_country);
			$('#nextStep').click(function() {
				$.submit_wait('body', $.WAITING_DIV);
				$.postForm('#countryForm', '', function(json) {
					if ( json.status == '1' ) {
						location.href = json.url+$.ID_2;
					} else {
						$('.running').remove();
						$.alertBox(json.msg);
					}
				});
			});
		}

		if ($('#selectNetworkForm').length) {
			$('.largeScreenOnly').show();
			if (fastlane_type == '1' && furfing_mode_type == '2.4G') {
				$('.column.first').show();
				$('.column.second').hide();
				$('.column.first').css({'margin-left':'24%'});
				$("#ap").prop('checked', true);
				$("#ap5g").prop('checked', false);
				$('.largeScreenOnly').hide();
			}
			else if (fastlane_type == '1' && furfing_mode_type == '5G'){
				$('.column.first').hide();
				$('.column.second').show();
				$('.column.second').css({'margin-left':'24%'});
				$("#ap").prop('checked', false);
				$("#ap5g").prop('checked', true);
				$('.largeScreenOnly').hide();
			}
			checkNum = 3;
			$('#refreshBtLink').click(function() {
				$('.wait2g').show();$('#scanning_bg').show();
				$.get('ca_searching_network.aspx'+$.ID_2, function(result) {
					try {
						var json = eval("(" + result + ")");
						if ( $.reset_login(json) )
							return false;
					} catch(e) {}
					setTimeout(function(){
						$('.wait2g').hide();$('#scanning_bg').hide();
						generateList();
					}, 35 * 1000);
				});
			});

			$('#refreshBtLink5g').click(function() {
				$('.wait5g').show();$('#scanning_bg').show();
				$.get('ca_searching_network.aspx'+$.ID_2, function(result) {
					try {
						var json = eval("(" + result + ")");
						if ( $.reset_login(json) )
							return false;
					} catch(e) {}
					setTimeout(function(){
						$('.wait5g').hide();$('#scanning_bg').hide();
						generateList5g();
					}, 35 * 1000);
				});
			});

			$('#manualNetwork').click(function(){
				if($("#ap5g").is(":checked") == true && $(".column.second").val() != "checked" && $("#manualNetwork5g").is(":checked") == false)
					$.enableButton('nextStep', '#selectNetworkForm', 0, false);
				else
					$.enableButton('nextStep', '#selectNetworkForm', 0, true);
			});

			$('#manualNetwork5g').click(function(){
				if($("#ap").is(":checked") == true && $(".column.first").val() != "checked" && $("#manualNetwork").is(":checked") == false)
                                        $.enableButton('nextStep', '#selectNetworkForm', 0, false);
                                else
                                        $.enableButton('nextStep', '#selectNetworkForm', 0, true);
			});

			$('#ap').click(function() {
				if($("#ap").is(":checked") == false){
					$(".column.first").val("");
					if( $(".column.second").val() == "checked" || $("#manualNetwork5g").is(":checked") == true )
						$.enableButton('nextStep', '#selectNetworkForm', 0, true);
					else
						$.enableButton('nextStep', '#selectNetworkForm', 0, false);
				}else
					$.enableButton('nextStep', '#selectNetworkForm', 0, false);
			});

			$('#ap5g').click(function() {
				if($("#ap5g").is(":checked") == false){
					$(".column.second").val("");
					if( $(".column.first").val() == "checked" || $("#manualNetwork").is(":checked") == true )
						$.enableButton('nextStep', '#selectNetworkForm', 0, true);
					else
						$.enableButton('nextStep', '#selectNetworkForm', 0, false);
				}else
					$.enableButton('nextStep', '#selectNetworkForm', 0, false);
			});

			$('.wait2g').show();
			$('.wait5g').show();
			$('#scanning_bg').show();
			$.get('ca_searching_network.aspx'+$.ID_2, function(result) {
				try {
					var json = eval("(" + result + ")");
					if ( $.reset_login(json) )
						return false;
				} catch(e) {}
				setTimeout(function(){
					generateList();
					generateList5g();
				}, 35 * 1000);
				setTimeout(function(){
					$('.wait2g').hide();
					$('.wait5g').hide();
					$('#scanning_bg').hide();
				}, 60 * 1000);
			});
			
			$('#nextStep').click(function() {

				if ($("input[type='radio']:checked").val() != "") {

					if ( $("#ap").is(":checked") == true ) {
						$('#2GHzOption').val(1);
						if ( $('#manualNetwork').is(":checked") == true )
							$('#2GHzRadio').val("manual");
						else
							$('#2GHzRadio').val("");
						if ($.xss_replace(rootSSID).length > 28)
							$('#client2GHzSSID').val($.do_xss_ssid($.xss_replace(rootSSID).substring(0, 26)));
		    				else
							$('#client2GHzSSID').val($.do_xss_ssid($.xss_replace(rootSSID)));
				    			$('#root2GHzSSID').val($.do_xss_ssid($.xss_replace(rootSSID)));
					} else {
						$('#2GHzOption').val(0);
						$('#2GHzRadio').val("");
						$('#root2GHzSSID').val("12345678NETGEAR");
						$('#2GHzSecurity').val('1');
					}

					if ( $("#ap5g").is(":checked") == true ) {
						$('#5GHzOption').val(1);
						if ( $('#manualNetwork5g').is(":checked") == true )
							$('#5GHzRadio').val("manual");
						else
							$('#5GHzRadio').val("");
						if ($.xss_replace(rootSSID5g).length > 28)
							$('#client5GHzSSID').val($.do_xss_ssid($.xss_replace(rootSSID5g).substring(0, 26)));
						else
							$('#client5GHzSSID').val($.do_xss_ssid($.xss_replace(rootSSID5g)));
						$('#root5GHzSSID').val($.do_xss_ssid($.xss_replace(rootSSID5g)));
					} else {
						$('#5GHzOption').val(0);
						$('#5GHzRadio').val("");
						$('#root5GHzSSID').val("12345678NETGEAR-5G");
						$('#5GHzSecurity').val('1');
					}

					if (($("#ap").is(":checked") == true && securityType == "OFF" && $("#ap5g").is(":checked") == true && securityType5g == "OFF" ) || ( $("#ap").is(":checked") == true && securityType == "OFF" && $("#ap5g").is(":checked") == false ) || ( $("#ap").is(":checked") == false && $("#ap5g").is(":checked") == true && securityType5g == "OFF" ) ) {
						if ( $("#ap").is(":checked") == true )
							$('#2GHzSecurity').val('1');
						if ( $("#ap5g").is(":checked") == true )
							$('#5GHzSecurity').val('1');

						$('#selectNetworkForm').attr('action', '/admin.cgi?/ca_extender_bgn.htm timestamp='+ts);
						$('#selectNetworkForm').attr('method', 'post');
						$.submit_wait('body',$.APPLYING_DIV);
						$.postForm('#selectNetworkForm','',function(json){
							if ( json.status == '1' ) {
								location.href = json.url+$.ID_2;
							} else {
								$.alertBox(json.msg);
							}
						});
					} else {
						$('#selectNetworkForm').attr('action', 'ca_extender_existing.htm');
						$('#selectNetworkForm').append('<input type="hidden" name="id" value="'+$.getUrlParam('id')+'" />');
						$('#selectNetworkForm').attr('method', 'get');
						$('#selectNetworkForm').submit();
					}
				} else {
					$.submit_wait('body',$.APPLYING_DIV);
					$.postForm('#selectNetworkForm','',function(json){
						if ( json.status == '1' ) {
							location.href = json.url+$.ID_2;
						} else {
							$.alertBox(json.msg);
						}
					});
				}
			});
		} // end $('#selectNetworkForm').length

		/*******************************************************************************************
		*
		*	2.4GHz Existing Network page
		*
		******************************************************************************************/
		$.checkManualInput = function() {
			if ( $('#securityTypeMan').val() != 0 ) {
				var sec_type = $('#securityTypeMan').val();
				switch(sec_type) {
					case '1': //None
						break;
					case '2': //WEP
						var reg = $.REG_KEY_64,
						msg = wep_64;
						if ( $('#wepEncManual').val() == '13' ) {
							reg = $.REG_KEY_128;
							msg = wep_128;
						}
						if (!reg.test($('#keyManual').val())) {
							$.addErrMsgAfter('keyManual', msg, false, 'err_wep');
						}
						break;
					case '3': // WPA-PSK [TKIP]
					case '6': // WPA2-PSK [AES]
					case '7': // WPA-PSK [TKIP] + WPA2-PSK [AES]
						 if ( !$.REG_WPA_PWD.test($('#pwdMan').val()) ) {
							$.addErrMsgAfter('pwdMan', wpa_phrase, false, 'err_pripass');
						 }
						break;
					default:
						$.addErrMsgAfter('securityTypeMan', no_security);
				}
			} else {
				$.addErrMsgAfter('securityTypeMan', no_security);
			}
		}

		$.checkManualInput5g = function() {
			if ( $('#securityTypeMan5g').val() != 0 ) {
				var sec_type = $('#securityTypeMan5g').val();
				switch(sec_type) {
					case '1': //None
						break;
					case '2': //WEP
						var reg = $.REG_KEY_64,
						    msg = wep_64;
						if ( $('#wepEncManual5g').val() == '13' ) {
							reg = $.REG_KEY_128;
							msg = wep_128;
						}
						if (!reg.test($('#keyManual5g').val())) {
							$.addErrMsgAfter('keyManual5g', msg, false, 'err_wep_5g');
						}
						break;
					case '3': // WPA-PSK [TKIP]
					case '6': // WPA2-PSK [AES]
					case '7': // WPA-PSK [TKIP] + WPA2-PSK [AES]
						if ( !$.REG_WPA_PWD.test($('#pwdMan5g').val()) ) {
							$.addErrMsgAfter('pwdMan5g', wpa_phrase, false, 'err_pripass_5g');
						}
						break;
					default:
						$.addErrMsgAfter('securityTypeMan5g', no_security);
				}
			} else {
				$.addErrMsgAfter('securityTypeMan5g', no_security);
			}
		}

		$.setMaxLen = function() {
			if ( $('#securityTypeMan').val() == '2' ) {
				$('#keyManual').attr('maxlength', $('#wepEncManual').val()*2);
				$('#keyManual').val('');
				$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
			} else if ( $('#securityTypeMan').val() != '0' && $('#securityTypeMan').val() != '1' ) {
				$('#pwdMan').attr('maxlength', 64);
				$('#pwdMan').val('');
				$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
			} else if ($('#securityTypeMan').val() == '1') {
				$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
			} else {
				$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
			}
		}

		$.setMaxLen5g = function() {
			if ( $('#securityTypeMan5g').val() == '2' ) {
				$('#keyManual5g').attr('maxlength', $('#wepEncManual5g').val()*2);
				$('#keyManual5g').val('');
				$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
			} else if ( $('#securityTypeMan5g').val() != '0' && $('#securityTypeMan5g').val() != '1' ) {
				$('#pwdMan5g').attr('maxlength', 64);
				$('#pwdMan5g').val('');
				$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
			} else if ($('#securityTypeMan5g').val() == '1') {
				$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
			} else {
				$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
			}
		}

		if ($('.manual2GHzSecurity').length) {
			$('.manual2GHzSecurity').on('change', function () {
				var thisParent = $(this).parents('.formElements');
				if ($(this).val() != 0)
					$('.errorMsg').remove();
				if ($(this).val() > 2) {
					thisParent.find('.wep').slideUp();
					thisParent.find('.wpa').slideDown();
					thisParent.find('.wepwpa').slideDown();
					thisParent.find('.wepwpa').find(':password').val('');
					var pwdPass = thisParent.find('.wpa').find('.networkPwd');
					pwdPass.keyup(function() {
						if ( pwdPass.val().length >= 8 ) {
							$.enableButton('nextStep', '#manualSettingsForm', 0, true);
						} else {
							$.enableButton('nextStep', '#manualSettingsForm', 0, false);
						}
					});
					pwdPass.trigger('keyup');
					pwdPass.change(function() {
						if ( pwdPass.val().length >= 8 ) {
							$.enableButton('nextStep', '#manualSettingsForm', 0, true);
						} else {
							$.enableButton('nextStep', '#manualSettingsForm', 0, false);
						}
					});
				} else if ($(this).val() > 1) {
					thisParent.find('.wep').slideDown();
					thisParent.find('.wpa').slideUp();
					thisParent.find('.wepwpa').slideDown();
					thisParent.find('.wepwpa').find(':password').val('');
					var wepPass = thisParent.find('.wep').find('.wepPwd');
					wepPass.keyup(function() {
						if ( wepPass.val().length >= 5 ) {
							$.enableButton('nextStep', '#manualSettingsForm', 0, true);
						} else {
							$.enableButton('nextStep', '#manualSettingsForm', 0, false);
						}
					});
					wepPass.trigger('keyup');
					wepPass.change(function() {
						if ( wepPass.val().length >= 5 ) {
							$.enableButton('nextStep', '#manualSettingsForm', 0, true);
						} else {
							$.enableButton('nextStep', '#manualSettingsForm', 0, false);
						}
					});
				} else if ($(this).val() > 0) {
					thisParent.find('.pwdInput').slideUp();
					thisParent.find('.pwdInput').find(':password').val('');
					$.enableButton('nextStep', '#manualSettingsForm', 0, true);
				} else {
					thisParent.find('.pwdInput').slideUp();
					thisParent.find('.pwdInput').find(':password').val('');
					$.enableButton('nextStep', '#manualSettingsForm', 0, false);
				}
			});
			
			$('.manual2GHzSecurity').trigger('change');
		}

		$.setSecurityType = function(security, sectype) {
			var securiType = "";
			if(security == "WEP") {
				securiType = "2";
			} else if(security == "WPA-PSK") {
				if(sectype.indexOf('AES') > -1)
					securiType = "7";
				else
					securiType = "7";
			} else if(security == "WPA2-PSK") {
				if(sectype.indexOf('AES') > -1)
					securiType = "6";
				else
					securiType = "7";
			} else if(security == "WPA/WPA2-PSK") {
				securiType = "7";
			} else {
				securiType = "1";
			}

			return securiType;
		};

		$.checkExistInput = function(existSecurity) {
			if ( existSecurity == "OFF" || existSecurity == "1" ) {
			} else if ( existSecurity == "WEP" || existSecurity == "2" ) {
				var reg = $.REG_KEY_64,
					msg = wep_64;
				if ( $('#encrStr').val() == '13' ) {
					reg = $.REG_KEY_128;
					msg = wep_128;
				}
				if (!reg.test($('#password').val())) {
					$.addErrMsgAfter('password', msg);
				}
			} else {
				if ( !$.REG_WPA_PWD.test($('#pwd').val()) ) {
					$.addErrMsgAfter('pwd', wpa_phrase, false, 'err_pripass');
				}
			}
		};

		$.checkExistInput5g = function(existSecurity) {
			if ( existSecurity == "OFF" || existSecurity == "1" ) {
			} else if ( existSecurity == "WEP" || existSecurity == "2" ) {
				var reg = $.REG_KEY_64,
					msg = wep_64;
				if ( $('#encrStr5g').val() == '13' ) {
					reg = $.REG_KEY_128;
					msg = wep_128;
				}
				if (!reg.test($('#password5g').val())) {
					$.addErrMsgAfter('password5g', msg);
				}
			} else {
				if ( !$.REG_WPA_PWD.test($('#pwd5g').val()) ) {
					$.addErrMsgAfter('pwd5g', wpa_phrase, false, 'err_pripass_5g');
				}
			}
		};

		$.showExistSecInfo = function(existSecurity, existSectype, id) {
			if ( existSecurity == "OFF" )
				$('#'+id).html(none);
			else if ( existSecurity == "WEP" )
				$('#'+id).html(sec_wep_phrase);
			else if ( existSecurity == "WPA/WPA2-PSK" )
				$('#'+id).html(sec_wpas_phrase);
			else
				$('#'+id).html(existSecurity+" ["+existSectype+"]");
		};

		$.showExistInfo = function(existSecurity, existSectype) {
			$.showExistSecInfo(existSecurity, existSectype, "2GHzSecurityShow");

			if ( existSecurity == "OFF" ) {
				$('.first.existing').find('.wep').hide();
				$('.first.existing').find('.wepwpa').hide();
				$('.first.existing').find('.wpa').hide();
			} else if ( existSecurity == "WEP" ) {
				$('.first.existing').find('.wep').show();
				$('.first.existing').find('.wepwpa').show();
				$('.first.existing').find('.wpa').hide();
				$('#password').attr('maxlength', $('#encrStr').val()*2);
				$('#encrStr').trigger('change');
				$('#password').keyup(function() {
					if ( $(this).val().length >= 5 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
				$('#password').trigger('keyup');
				$('#password').change(function() {
					if ( $(this).val().length >= 5 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
			} else {
				$('.first.existing').find('.wep').hide();
				$('.first.existing').find('.wepwpa').show();
				$('.first.existing').find('.wpa').show();
				$('#pwd').keyup(function() {
					if ( $(this).val().length >= 8 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
				$('#pwd').trigger('keyup');
				$('#pwd').change(function() {
					if ( $(this).val().length >= 8 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
			}
		};

		$.showExistInfo5g = function(existSecurity, existSectype) {
			$.showExistSecInfo(existSecurity, existSectype, "5GHzSecurityShow");

			if ( existSecurity == "OFF" ) {
				$('.second.existing').find('.wep').hide();
				$('.second.existing').find('.wepwpa').hide();
				$('.second.existing').find('.wpa').hide();
			} else if ( existSecurity == "WEP" ) {
				$('.second.existing').find('.wep').show();
				$('.second.existing').find('.wepwpa').show();
				$('.second.existing').find('.wpa').hide();
				$('#password5g').attr('maxlength', $('#encrStr5g').val()*2);
				$('#encrStr5g').trigger('change');
				$('#password5g').keyup(function() {
					if ( $(this).val().length >= 5 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
				$('#password5g').trigger('keyup');
				$('#password5g').change(function() {
					if ( $(this).val().length >= 5 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
			} else {
				$('.second.existing').find('.wep').hide();
				$('.second.existing').find('.wepwpa').show();
				$('.second.existing').find('.wpa').show();
				$('#pwd5g').keyup(function() {
					if ( $(this).val().length >= 8 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
				$('#pwd5g').trigger('keyup');
				$('#pwd5g').change(function() {
					if ( $(this).val().length >= 8 ) {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, true);
					} else {
						$.enableButton('nextStep', '#bgnExistingNetworkForm', 0, false);
					}
				});
			}
		};

		if ( $('#bgnExistingNetworkForm').length ) {
			//setting the ssid and security according to url query
			var existOption = $.getUrlParam('2GHzOption'),
			existRadio = $.getUrlParam('2GHzRadio'),
			existOption5g = $.getUrlParam('5GHzOption'),
			existRadio5g = $.getUrlParam('5GHzRadio');

			$('#2GHzOption').val(existOption);
			$('#5GHzOption').val(existOption5g);

			if ( existOption == "1" )
			{
				if ( existRadio == "manual" )
				{
					$('.column.first.manual').show();
					setTimeout(function(){
						$('#ssidMan').val("");
						$('#keyManual').val("");
						$('#pwdMan').val("");
						$('#ssidMan').removeAttr("style");
					}, $.chromeTimer);
				}
				else
				{
					var existSSID = $.getUrlParam('sel_network');
					existSSID = existSSID.replace(/%20/g, ' ');
					var existSecurity = $.getUrlParam('2GHzSecurity');
					var existSectype = $.getUrlParam('2GHzSectype');

					if ( existSecurity != "OFF" )
						$('.column.first.existing').show();

					$('#root2GHzSSID').val($.do_xss_ssid(existSSID));
					if(existSSID.length > 28)
						$('#client2GHzSSID').val($.do_xss_ssid(existSSID.substring(0, 26)));
					else
						$('#client2GHzSSID').val($.do_xss_ssid(existSSID));
					$('#2GHzSecurity').val($.setSecurityType(existSecurity, existSectype));
					$('#2GHzChannel').val($.getUrlParam('2GHzChannel'));
					$('#2GHzMode').val($.getUrlParam('2GHzMode'));
					$('#2GHzSSIDShow').html($.xss_format(existSSID));

					$.showExistInfo(existSecurity, existSectype);
				}
			}
			else
			{
				$('.column.first.manual').hide();
				$('.column.first.existing').hide();
				$('#root2GHzSSID').val("12345678NETGEAR");
				$('#2GHzSecurity').val($.setSecurityType(existSecurity5g, existSectype5g));
				if ( existOption5g == "1" ) {
					if ( existRadio5g == "manual" ) {
						$('.column.second.manual').css({'margin-left':'24%'});
					} else {
						$('.column.second.existing').css({'margin-left':'24%'});
					}
				}
			}

			if ( existOption5g == "1" )
			{
				if ( existRadio5g == "manual" )
				{
					$('.column.second.manual').show();
					setTimeout(function(){
						$('#ssidMan5g').val("");
						$('#keyManual5g').val("");
						$('#pwdMan5g').val("");
						$('#ssidMan5g').removeAttr("style");
					}, $.chromeTimer);
				}
				else
				{
					var existSSID5g = $.getUrlParam('sel_network_5g');
					existSSID5g = existSSID5g.replace(/%20/g, ' ');
					var existSecurity5g = $.getUrlParam('5GHzSecurity');
					var existSectype5g = $.getUrlParam('5GHzSectype');

					if ( existSecurity5g != "OFF" )
						$('.column.second.existing').show();

					$('#root5GHzSSID').val($.do_xss_ssid(existSSID5g));
					if(existSSID5g.length > 28)
						$('#client5GHzSSID').val($.do_xss_ssid(existSSID5g.substring(0, 26)));
					else
						$('#client5GHzSSID').val($.do_xss_ssid(existSSID5g));
					$('#5GHzSecurity').val($.setSecurityType(existSecurity5g, existSectype5g));
					$('#5GHzChannel').val($.getUrlParam('5GHzChannel'));
					$('#5GHzMode').val($.getUrlParam('5GHzMode'));
					$('#5GHzSSIDShow').html($.xss_format(existSSID5g));

					$.showExistInfo5g(existSecurity5g, existSectype5g);
				}
			}
			else
			{
				$('.column.second.manual').hide();
				$('.column.second.existing').hide();
				$('#root5GHzSSID').val("12345678NETGEAR-5G");
				$('#5GHzSecurity').val($.setSecurityType(existSecurity, existSectype));
				if ( existOption == "1" ) {
					if ( existRadio == "manual" ) {
						$('.column.first.manual').css({'margin-left':'24%'});
					} else {
						$('.column.first.existing').css({'margin-left':'24%'});
					}
				}
			}

			$('#nextStep').click(function() {
				$('.errorMsg').remove();

				if ( existOption == "1" )
				{
					if ( existRadio == "manual" )
					{
						if ( !$.REG_SSID.test($('#ssidMan').val()) ) {
							$.addErrMsgAfter('ssidMan',ssid_invalid);
						}

						$.checkManualInput();

						if($('#ssidMan').val().length > 28)
							$('#client2GHzSSID').val($.do_xss_ssid($('#ssidMan').val().substring(0, 26)));
						else
							$('#client2GHzSSID').val($.do_xss_ssid($('#ssidMan').val()));
						$('#2GHzSecurity').val($('#securityTypeMan').val());
						$('#root2GHzSSID').val($.do_xss_ssid($('#ssidMan').val()));

						if ( $('#securityTypeMan').val() == 2 ) {
							$('#2GHzEncrLen').val($('#wepEncManual').val());
							$('#2GHzKeyNo').val($('#wepKeyNoManual').val());
							$('#2GHzAuthType').val($('#wepAuthManual').val());
							$('#2GHzWepPass').val($.do_xss_pass($('#keyManual').val()));
						} else if ( $('#securityTypeMan').val() != 0 ) {
							$('#2GHzPassword').val($.do_xss_pass($('#pwdMan').val()));
						}
					}
					else
					{
						$.checkExistInput(existSecurity);
						if ( existSecurity == "WEP" ) {
							$('#2GHzEncrLen').val($('#encrStr').val());
							$('#2GHzKeyNo').val($('#keyNum').val());
							$('#2GHzAuthType').val($('#authType').val());
							$('#2GHzWepPass').val($.do_xss_pass($('#password').val()));
						} else if ( existSecurity != "OFF" ) {
							$('#2GHzPassword').val($.do_xss_pass($('#pwd').val()));
						}
					}
				}

				if ( existOption5g == "1" )
				{
					if ( existRadio5g == "manual" )
					{
						if ( !$.REG_SSID.test($('#ssidMan5g').val()) ) {
							$.addErrMsgAfter('ssidMan5g',ssid_invalid);
						}

						$.checkManualInput5g();

						if($('#ssidMan5g').val().length > 28)
							$('#client5GHzSSID').val($.do_xss_ssid($('#ssidMan5g').val().substring(0, 26)));
						else
							$('#client5GHzSSID').val($.do_xss_ssid($('#ssidMan5g').val()));
						$('#5GHzSecurity').val($('#securityTypeMan5g').val());
						$('#root5GHzSSID').val($.do_xss_ssid($('#ssidMan5g').val()));

						if ( $('#securityTypeMan5g').val() == 2 ) {
							$('#5GHzEncrLen').val($('#wepEncManual5g').val());
							$('#5GHzKeyNo').val($('#wepKeyNoManual5g').val());
							$('#5GHzAuthType').val($('#wepAuthManual5g').val());
							$('#5GHzWepPass').val($.do_xss_pass($('#keyManual5g').val()));
						} else if ( $('#securityTypeMan5g').val() != 0 ) {
							$('#5GHzPassword').val($.do_xss_pass($('#pwdMan5g').val()));
						}
					}
					else
					{
						$.checkExistInput5g(existSecurity5g);
						if ( existSecurity5g == "WEP" ) {
							$('#5GHzEncrLen').val($('#encrStr5g').val());
							$('#5GHzKeyNo').val($('#keyNum5g').val());
							$('#5GHzAuthType').val($('#authType5g').val());
							$('#5GHzWepPass').val($.do_xss_pass($('#password5g').val()));
						} else if ( existSecurity5g != "OFF" ) {
							$('#5GHzPassword').val($.do_xss_pass($('#pwd5g').val()));
						}
					}
				}

				if ( !$('.errorMsg').length ) {
					$('.running').remove();
					$.submit_wait('body', $.APPLYING_DIV);
					$.postForm('#bgnExistingNetworkForm','',function(json){
						if ( json.status == '1' ) {
							var time = parseInt(json.wait) * 1000;
							setTimeout(function() {
								location.href = json.url+$.ID_2;
							}, time);
						} else {
							$.alertBox(json.msg);
						}
					});
				}
			});
		}
		/*******************************************************************************************
		*
		*       Failure! Continue Setting page
		*
		******************************************************************************************/
		$.checkContinueInput = function(existSecurity) {
			if ( existSecurity == "OFF" || existSecurity == "1" ) {
			} else if ( existSecurity == "WEP" || existSecurity == "2" ) {
				var reg = $.REG_KEY_64,
					msg = wep_64;
				if ( $('#encrStrFail').val() == '13' ) {
					reg = $.REG_KEY_128;
					msg = wep_128;
				}
				if (!reg.test($('#wepPassFail').val())) {
					$.addErrMsgAfter('wepPassFail', msg);
				}
			} else {
				if ( !$.REG_WPA_PWD.test($('#passphrase').val()) ) {
					$.addErrMsgAfter('passphrase', wpa_phrase, false, 'err_pripass');
				}
			}
		};

		$.checkContinueInput5g = function(existSecurity) {
			if ( existSecurity == "OFF" || existSecurity == "1" ) {
			} else if ( existSecurity == "WEP" || existSecurity == "2" ) {
				var reg = $.REG_KEY_64,
					msg = wep_64;
				if ( $('#encrStrFail5g').val() == '13' ) {
					reg = $.REG_KEY_128;
					msg = wep_128;
				}
				if (!reg.test($('#wepPassFail5g').val())) {
					$.addErrMsgAfter('wepPassFail5g', msg);
				}
			} else {
				if ( !$.REG_WPA_PWD.test($('#passphrase5g').val()) ) {
					$.addErrMsgAfter('passphrase5g', wpa_phrase, false, 'err_pripass_5g');
				}
			}
		};

		if ( $('#continueNetworkForm').length ) {
			$('#show_mac').html(ca_retry_mac + lan_mac + "." + adapter_macaddr + lan_mac + "." + ca_cancel);

			if ((rootOption == "1" && linkStatus == "0" )|| ( rootOption == "1" && rootOption5g == "1"))
			{
				$('.column.first').show();
				$('#2GHzSSIDShow').html(rootSSIDShow);

				if(rootSecurity == "7" || rootSecurity == "8")
					$('#2GHzSecurityShow').html(sec_wpas_phrase);
				else
					$('#2GHzSecurityShow').html($.formatSecType(rootSecurity));

				if ( rootSecurity == "1" ) {
					$('.column.first').find('.formElements').find('.wep').hide();
					$('.column.first').find('.formElements').find('.wepwpa').hide();
					$('.column.first').find('.formElements').find('.wpa').hide();
					$.enableButton('continueBt', '#continueNetworkForm', 0, true);
				} else if ( rootSecurity == "2" ) {
					$('.column.first').find('.formElements').find('.wep').show();
					$('.column.first').find('.formElements').find('.wepwpa').show();
					$('.column.first').find('.formElements').find('.wpa').hide();
					$('#encrStrFail').val(rootEncrLen);
					$('#authTypeFail').val(rootAuthType);
					$('#keyNumFail').val(rootKeyNum);
					$('#wepPassFail').attr('maxlength', $('#encrStrFail').val()*2);
					$('#encrStrFail').trigger('change');
					if ( rootKeyNum == '1' )
						$('#wepPassFail').val(rootKey1);
					else if ( rootKeyNum == '2' )
						$('#wepPassFail').val(rootKey2);
					else if ( rootKeyNum == '3' )
						$('#wepPassFail').val(rootKey3);
					else
						$('#wepPassFail').val(rootKey4);
					$('#wepPassFail').keyup(function() {
						if ( $(this).val().length >= 5 ) {
							$.enableButton('continueBt', '#continueNetworkForm', 0, true);
						} else {
							$.enableButton('continueBt', '#continueNetworkForm', 0, false);
						}
					});
					$('#wepPassFail').trigger('keyup');
					$('#wepPassFail').change(function() {
						if ( $(this).val().length >= 5 ) {
							$.enableButton('continueBt', '#continueNetworkForm', 0, true);
						} else {
							$.enableButton('continueBt', '#continueNetworkForm', 0, false);
						}
					});
					$('#wepPassFail').trigger('change');
				} else {
					$('.column.first').find('.formElements').find('.wep').hide();
					$('.column.first').find('.formElements').find('.wepwpa').show();
					$('.column.first').find('.formElements').find('.wpa').show();
					$('#passphrase').attr('maxlength', 64);
					$('#passphrase').val(rootPassword);
					$('#passphrase').keyup(function() {
						if ( $(this).val().length >= 8 ) {
							$.enableButton('continueBt', '#continueNetworkForm', 0, true);
						} else {
							$.enableButton('continueBt', '#continueNetworkForm', 0, false);
						}
					});
					$('#passphrase').trigger('keyup');
					$('#passphrase').change(function() {
						if ( $(this).val().length >= 8 ) {
							$.enableButton('continueBt', '#continueNetworkForm', 0, true);
						} else {
							$.enableButton('continueBt', '#continueNetworkForm', 0, false);
						}
					});
					$('#passphrase').trigger('change');
				}
			}

			if ((rootOption5g == "1" && linkStatus5g == "0")||(rootOption5g == "1" && rootOption == "1" ))
			{
				$('.column.second').show();
				$('#5GHzSSIDShow').html(rootSSIDShow5g);

				if(rootSecurity5g == "7" || rootSecurity5g == "8")
					$('#5GHzSecurityShow').html(sec_wpas_phrase);
				else
					$('#5GHzSecurityShow').html($.formatSecType(rootSecurity5g));

				if ( rootSecurity5g == "1" ) {
					$('.column.second').find('.formElements').find('.wep').hide();
					$('.column.second').find('.formElements').find('.wepwpa').hide();
					$('.column.second').find('.formElements').find('.wpa').hide();
					$.enableButton('continueBt', '#continueNetworkForm', 0, true);
				} else if ( rootSecurity5g == "2" ) {
					$('.column.second').find('.formElements').find('.wep').show();
					$('.column.second').find('.formElements').find('.wepwpa').show();
					$('.column.second').find('.formElements').find('.wpa').hide();
					$('#encrStrFail5g').val(rootEncrLen5g);
					$('#authTypeFail5g').val(rootAuthType5g);
					$('#keyNumFail5g').val(rootKeyNum5g);
					$('#wepPassFail5g').attr('maxlength', $('#encrStrFail5g').val()*2);
					$('#encrStrFail5g').trigger('change');
					if ( rootKeyNum5g == '1' )
						$('#wepPassFail5g').val(rootKey5g1);
					else if ( rootKeyNum5g == '2' )
						$('#wepPassFail5g').val(rootKey5g2);
					else if ( rootKeyNum5g == '3' )
						$('#wepPassFail5g').val(rootKey5g3);
					else
						$('#wepPassFail5g').val(rootKey5g4);
					$('#wepPassFail5g').keyup(function() {
						if ( $(this).val().length >= 5 ) {
							$.enableButton('continueBt', '#continueNetworkForm', 0, true);
						} else {
							$.enableButton('continueBt', '#continueNetworkForm', 0, false);
						}
					});
					$('#wepPassFail5g').trigger('keyup');
					$('#wepPassFail5g').change(function() {
						if ( $(this).val().length >= 5 ) {
							$.enableButton('continueBt', '#continueNetworkForm', 0, true);
						} else {
							$.enableButton('continueBt', '#continueNetworkForm', 0, false);
						}
					});
					$('#wepPassFail5g').trigger('change');
				} else {
					$('.column.second').find('.formElements').find('.wep').hide();
					$('.column.second').find('.formElements').find('.wepwpa').show();
					$('.column.second').find('.formElements').find('.wpa').show();
					$('#passphrase5g').attr('maxlength', 64);
					$('#passphrase5g').val(rootPassword5g);
					$('#passphrase5g').keyup(function() {
						if ( $(this).val().length >= 8 ) {
							$.enableButton('continueBt', '#continueNetworkForm', 0, true);
						} else {
							$.enableButton('continueBt', '#continueNetworkForm', 0, false);
						}
					});
					$('#passphrase5g').trigger('keyup');
					$('#passphrase5g').change(function() {
						if ( $(this).val().length >= 8 ) {
							$.enableButton('continueBt', '#continueNetworkForm', 0, true);
						} else {
							$.enableButton('continueBt', '#continueNetworkForm', 0, false);
						}
					});
					$('#passphrase5g').trigger('change');
				}
			}

			$('#continueBt').click(function() {
				$('.errorMsg').remove();
				if (rootOption == "1")
				{
					$('#2GHzOption').val(rootOption);
					$('#root2GHzSSID').val($.do_xss_ssid(rootSSIDShow));
					$('#client2GHzSSID').val($.do_xss_ssid(clientSSID));
					$('#2GHzSecurity').val(rootSecurity);
					$('#2GHzChannel').val(channel);
					$('#2GHzMode').val(mode);
					$.checkContinueInput(rootSecurity);
					if ( rootSecurity == "2" ) {
						$('#2GHzEncrLen').val($('#encrStrFail').val());
						$('#2GHzKeyNo').val($('#keyNumFail').val());
						$('#2GHzAuthType').val($('#authTypeFail').val());
						$('#2GHzWepPass').val($.do_xss_pass($('#wepPassFail').val()));
					} else if ( rootSecurity != "1" && rootSecurity != "0" ) {
						$('#2GHzPassword').val($.do_xss_pass($('#passphrase').val()));
					}
				}else{
					$('#2GHzOption').val(0);
					$('#root2GHzSSID').val("12345678NETGEAR");
					$('#2GHzSecurity').val('1');
				}

				if (rootOption5g == "1")
				{
					$('#5GHzOption').val(rootOption5g);
					$('#root5GHzSSID').val($.do_xss_ssid(rootSSIDShow5g));
					$('#client5GHzSSID').val($.do_xss_ssid(clientSSID5g));
					$('#5GHzSecurity').val(rootSecurity5g);
					$('#5GHzChannel').val(channel5g);
					$('#5GHzMode').val(mode5g);
					$.checkContinueInput5g(rootSecurity5g);
					if ( rootSecurity5g == "2" ) {
						$('#5GHzEncrLen').val($('#encrStrFail5g').val());
						$('#5GHzKeyNo').val($('#keyNumFail5g').val());
						$('#5GHzAuthType').val($('#authTypeFail5g').val());
						$('#5GHzWepPass').val($.do_xss_pass($('#wepPassFail5g').val()));
					} else if ( rootSecurity5g != "1" && rootSecurity5g != "0" ) {
						$('#5GHzPassword').val($.do_xss_pass($('#passphrase5g').val()));
					}
				}else{
					$('#5GHzOption').val(0);
					$('#root5GHzSSID').val("12345678NETGEAR-5G");
					$('#5GHzSecurity').val('1');
				}

				if ( !$('.errorMsg').length ) {
					$('.running').remove();
					$.submit_wait('body', $.APPLYING_DIV);
					$.postForm('#continueNetworkForm','', function(json){
						if ( json.status == '1' ) {
							var time = parseInt(json.wait) * 1000;
							setTimeout(function() {
								location.href = json.url+$.ID_2;
							}, time);
						} else {
							$.alertBox(json.msg);
						}
					});
				}
			});

			if ($('#cancelBt', '#continueNetworkForm').length) {
				$('#cancelBt').attr('href', 'ca_extender_setup.htm'+$.ID_2);
			}
			if ($('#skipBt', '#continueNetworkForm').length) {
				$('#skipBt').attr('href', 'status.htm'+$.ID_2);
			}
		}

		/*******************************************************************************************
		*
		*	Extender Bgn Page. ca_extender_bgn.htm
		*
		******************************************************************************************/
		$.showPass = function() {
			if(rootSecurity == "8" || rootSecurity == "3" || rootSecurity == "4" || rootSecurity == "5")
				rootSecurity = "7";
			if( rootSamesec == '0' ) {
				$('.column.first.bgn').find('.securityOptionsWrap').hide();
				$('.column.first.bgn').find('.pwdInput').hide();
				if ( rootSecurity == '1' )
					$('#whatPwd').val('2');
				else
					$('#whatPwd').val('1');
			} else {
				$('.column.first.bgn').find('.securityOptionsWrap').show();
				$('.column.first.bgn').find('.whatPwd').val('0');
				$('.column.first.bgn').find('.securityOptions').val(rootSecurity);
				if(rootSecurity == '2') {
					$('.column.first.bgn').find('.wep').show();
					$('.column.first.bgn').find('.wpa').hide();
					$('#wepEnc').val(rootEncrLen);
					$('#wepAuth').val(rootAuthType);
					$('#wepEnc').trigger('change');
					if(rootKeyNum == '1')
						$('#wepKeyNo1').prop('checked', true);
					else if(rootKeyNum == '2')
						$('#wepKeyNo2').prop('checked', true);
					else if(rootKeyNum == '3')
						$('#wepKeyNo3').prop('checked', true);
					else
						$('#wepKeyNo4').prop('checked', true);
					$('#key1').val(rootKey1);
					$('#key2').val(rootKey2);
					$('#key3').val(rootKey3);
					$('#key4').val(rootKey4);
				} else {
					$('.column.first.bgn').find('.wep').hide();
					$('.column.first.bgn').find('.wpa').show();
					$('#pwd').val(rootPassword);
					$('#verifyPwd').val(rootPassword);
					$('#pwd').trigger('change');
				}
			}
		}

		$.showPass5g = function() {
			if(rootSecurity5g == "8" || rootSecurity5g == "3" || rootSecurity5g == "4" || rootSecurity5g == "5")
				rootSecurity5g = "7";
			if( rootSamesec5g == '0' ) {
				$('.column.second.bgn').find('.securityOptionsWrap').hide();
				$('.column.second.bgn').find('.pwdInput').hide();
				if ( rootSecurity5g == '1' )
					$('#whatPwd5g').val('2');
				else
					$('#whatPwd5g').val('1');
			} else {
				$('.column.second.bgn').find('.securityOptionsWrap').show();
				$('.column.second.bgn').find('.whatPwd').val('0');
				$('.column.second.bgn').find('.securityOptions').val(rootSecurity5g);
				if(rootSecurity5g == '2') {
					$('.column.second.bgn').find('.wep').show();
					$('.column.second.bgn').find('.wpa').hide();
					$('#wepEnc5g').val(rootEncrLen5g);
					$('#wepAuth5g').val(rootAuthType5g);
					$('#wepEnc5g').trigger('change');
					if(rootKeyNum5g == '1')
						$('#wepKeyNo5g1').prop('checked', true);
					else if(rootKeyNum5g == '2')
						$('#wepKeyNo5g2').prop('checked', true);
					else if(rootKeyNum5g == '3')
						$('#wepKeyNo5g3').prop('checked', true);
					else
						$('#wepKeyNo5g4').prop('checked', true);
					$('#key5g1').val(rootKey5g1);
					$('#key5g2').val(rootKey5g2);
					$('#key5g3').val(rootKey5g3);
					$('#key5g4').val(rootKey5g4);
				} else {
					$('.column.second.bgn').find('.wep').hide();
					$('.column.second.bgn').find('.wpa').show();
					$('#pwd5g').val(rootPassword5g);
					$('#verifyPwd5g').val(rootPassword5g);
					$('#pwd5g').trigger('change');
				}
			}
		}

		if ($('#networkSettingsForm').length) {
			if (fastlane_type == '1' && furfing_mode_type == '2.4G') {
				$('.column.first').hide();
				$('.column.second').show();
				$('.column.second').css({'margin-left':'24%'});
			}
			else if (fastlane_type == '1' && furfing_mode_type == '5G'){
				$('.column.first').show();
				$('.column.second').hide();
				$('.column.first').css({'margin-left':'24%'});
			}
//			if ( rootOption == "1" )
//			{
//				$('.column.first.bgn').show();
			if ( rootOption == "1" && rootOption5g == "0")
			{
				$('#ssid').val(rootSSIDShow + '_2GEXT');
				$('#ssid5g').val(rootSSIDShow + '_5GEXT');
			}else if ( rootOption == "0" && rootOption5g == "1" )
			{
				$('#ssid').val(rootSSIDShow5g + '_2GEXT');
				$('#ssid5g').val(rootSSIDShow5g + '_5GEXT');
			}else
			{
				$('#ssid').val(rootSSIDShow + '_2GEXT');
				$('#ssid5g').val(rootSSIDShow5g + '_5GEXT');
			}

				$.showPass();
				$.checkPass();
				setTimeout(function(){
					if ( rootSecurity == '2' ) {
						$('#key4').val(rootKey4);
						$('#pwd').val("");
						$('#verifyPwd').val("");
					} else {
						$('#key4').val("");
						$('#pwd').val(rootPassword);
						$('#verifyPwd').val(rootPassword);
					}
					$('#key4').removeAttr("style");
					$('#key5g4').removeAttr("style");
				}, $.chromeTimer);
//			}
//			else
//			{
//				$('.column.first.bgn').hide();
//			}

//			if ( rootOption5g == "1" )
//			{
//				$('.column.second.bgn').show();
				$.showPass5g();
				$.checkPass5g();
				setTimeout(function(){
					if ( rootSecurity5g == '2' )
					{
						$('#key5g4').val(rootKey5g4);
						$('#pwd5g').val("");
						$('#verifyPwd5g').val("");
					} else {
						$('#key5g4').val("");
						$('#pwd5g').val(rootPassword5g);
						$('#verifyPwd5g').val(rootPassword5g);
					}
				}, $.chromeTimer);
//			}
//			else
//			{
//				$('.column.second.bgn').hide();
//			}

			$('#nextStep').click(function() {
				$('.errorMsg').remove();

//				if ( rootOption == "1" )
//				{
					if ( !$.REG_SSID.test($('#ssid').val()) ) {
						$.addErrMsgAfter('ssid',ssid_invalid);
					}
					$.checkSecurity('securityOptions', 'wepEnc', 'pwd');
					$('#client2GHzSSID').val($.do_xss_ssid($('#ssid').val()));
					$('#wifiChannel').val(rootChannel);
					if($('#whatPwd').val() == '2') {
						$('#client2GHzSameSec').val('2');
						$('#client2GHzSecurity').val('1');
					} else if($('#whatPwd').val() == '0') {
						$('#client2GHzSameSec').val('0');
						if($('#securityOptions').val() == '2') {
							$('#client2GHzSecurity').val('2');
							if($('#wepAuth').val() == '1')
								$('#client2GHzAuthType').val('1');
							else
								$('#client2GHzAuthType').val('2');
							if($('#wepEnc').val() == '5')
								$('#client2GHzEncrLen').val('5');
							else
								$('#client2GHzEncrLen').val('13');
							$('#client2GHzKeyNum').val($('input:radio[name="wep_key_no"]:checked').val());
							$('#client2GHzKey1').val($.do_xss_pass($('#key1').val()));
							$('#client2GHzKey2').val($.do_xss_pass($('#key2').val()));
							$('#client2GHzKey3').val($.do_xss_pass($('#key3').val()));
							$('#client2GHzKey4').val($.do_xss_pass($('#key4').val()));
							$('.column.first ul strong:last', '#continue').html($.xss_format($('#key'+$('#client2GHzKeyNum').val()).val()));
						} else {
							if ( $('#verifyPwd').val() != $('#pwd').val() && $('#pwd').val().length >= $.MIN_PWD_CHARACTERS ) {
								$('#verifyPwd').addClass('alert');
								$.addErrMsgAfter('verifyPwd', error_not_same_pwd, false, 'err_passsame');
							}
							if ( $('#verifyPwd5g').val() != $('#pwd5g').val() && $('#pwd5g').val().length >= $.MIN_PWD_CHARACTERS ) {
								$('#verifyPwd5g').addClass('alert');
								$.addErrMsgAfter('verifyPwd5g', error_not_same_pwd, false, 'err_passsame');
							}
							if($('#securityOptions').val() == '6')
								$('#client2GHzSecurity').val('6');
							else
								$('#client2GHzSecurity').val('7');
							$('#client2GHzPassword').val($.do_xss_pass($('#pwd').val()));
							$('.column.first ul strong:last', '#continue').html($.xss_format($('#pwd').val()));
						}
					} else {
						$('#client2GHzSameSec').val('1');
						$('#client2GHzSecurity').val(rootSecurity);
						if(rootSecurity == "2") {
							$('#client2GHzAuthType').val(rootAuthType);
							$('#client2GHzEncrLen').val(rootEncrLen);
							$('#client2GHzKeyNum').val(rootKeyNum);
							$('#client2GHzKey1').val($.do_xss_pass(rootKey1));
							$('#client2GHzKey2').val($.do_xss_pass(rootKey2));
							$('#client2GHzKey3').val($.do_xss_pass(rootKey3));
							$('#client2GHzKey4').val($.do_xss_pass(rootKey4));
						} else {
							$('#client2GHzPassword').val($.do_xss_pass(rootPassword));
						}
						$('.column.first ul strong:last', '#continue').html($.xss_format($.showPassKey(rootSecurity, rootKeyNum, "root")));
					}
//				}

//				if ( rootOption5g == "1" )
//				{
					if ( !$.REG_SSID.test($('#ssid5g').val()) ) {
						$.addErrMsgAfter('ssid5g', ssid_invalid);
					}
					$.checkSecurity5g('securityOptions5g', 'wepEnc5g', 'pwd5g');
					$('#client5GHzSSID').val($.do_xss_ssid($('#ssid5g').val()));
					$('#wifiChannel5g').val(rootChannel5g);
					if($('#whatPwd5g').val() == '2') {
						$('#client5GHzSameSec').val('2');
						$('#client5GHzSecurity').val('1');
					} else if($('#whatPwd5g').val() == '0') {
						$('#client5GHzSameSec').val('0');
						if($('#securityOptions5g').val() == '2') {
							$('#client5GHzSecurity').val('2');
							if($('#wepAuth5g').val() == '1')
								$('#client5GHzAuthType').val('1');
							else
								$('#client5GHzAuthType').val('2');
							if($('#wepEnc5g').val() == '5')
								$('#client5GHzEncrLen').val('5');
							else
								$('#client5GHzEncrLen').val('13');
							$('#client5GHzKeyNum').val($('input:radio[name="wep_key_no_5g"]:checked').val());
							$('#client5GHzKey1').val($.do_xss_pass($('#key5g1').val()));
							$('#client5GHzKey2').val($.do_xss_pass($('#key5g2').val()));
							$('#client5GHzKey3').val($.do_xss_pass($('#key5g3').val()));
							$('#client5GHzKey4').val($.do_xss_pass($('#key5g4').val()));
							$('.column.second ul strong:last', '#continue').html($.xss_format($('#key5g'+$('#client5GHzKeyNum').val()).val()));
						} else {
							if ( $('#verifyPwd5g').val() != $('#pwd5g').val() && $('#pwd5g').val().length >= $.MIN_PWD_CHARACTERS ) {
								$('#verifyPwd5g').addClass('alert');
								$.addErrMsgAfter('verifyPwd5g', error_not_same_pwd, false, 'err_passsame');
							}
							if($('#securityOptions5g').val() == '6')
								$('#client5GHzSecurity').val('6');
							else
								$('#client5GHzSecurity').val('7');
							$('#client5GHzPassword').val($.do_xss_pass($('#pwd5g').val()));
							$('.column.second ul strong:last', '#continue').html($.xss_format($('#pwd5g').val()));
						}
					} else {
						$('#client5GHzSameSec').val('1');
						$('#client5GHzSecurity').val(rootSecurity5g);
						if(rootSecurity5g == "2") {
							$('#client5GHzAuthType').val(rootAuthType5g);
							$('#client5GHzEncrLen').val(rootEncrLen5g);
							$('#client5GHzKeyNum').val(rootKeyNum5g);
							$('#client5GHzKey1').val($.do_xss_pass(rootKey5g1));
							$('#client5GHzKey2').val($.do_xss_pass(rootKey5g2));
							$('#client5GHzKey3').val($.do_xss_pass(rootKey5g3));
							$('#client5GHzKey4').val($.do_xss_pass(rootKey5g4));
						} else {
							$('#client5GHzPassword').val($.do_xss_pass(rootPassword5g));
						}
						$('.column.second ul strong:last', '#continue').html($.xss_format($.showPassKey5g(rootSecurity5g, rootKeyNum5g, "root")));
					}
//				}

				if ( !$('.errorMsg').length ) {
					$.submit_wait('body', $.APPLYING_DIV);
					$.postForm('#networkSettingsForm', '', function(json) {
						if ( json.status == '1' ) {
							var time = parseInt(json.wait) * 1000;
							setTimeout(function() {
								$('#networkSettingsDiv').hide();
								$('.running').remove();
								$('.secondary', '#fixedFooter').hide();
								$('#nextStep', '#fixedFooter').hide();
								$('#continueBt', '#fixedFooter').show();
								$('#continueBt').click(function() {
									$.change_domain(json.url);
								});
								$('#continue').show();
							}, time);
						} else {
							$.alertBox(json.msg);
						}
					});

//					if ( rootOption == "1" )
//					{
						$('.column.first ul strong:first', '#continue').html($.xss_format($('#ssid').val()));
						$('.column.first ul strong:eq(1)', '#continue').html($.formatSecType($('#client2GHzSecurity').val()));
						if($('#client2GHzSecurity').val() == "1")
							$('.column.first ul li:last', '#continue').hide();
//					}

//					if ( rootOption5g == "1" )
//					{
						$('.column.second ul strong:first', '#continue').html($.xss_format($('#ssid5g').val()));
						$('.column.second ul strong:eq(1)', '#continue').html($.formatSecType($('#client5GHzSecurity').val()));
						if($('#client5GHzSecurity').val() == "1")
							$('.column.second ul li:last', '#continue').hide();
//					}
				}
			});
		}

		/*******************************************************************************************
		 * 
		 * Setup Success page
		 *
		 *******************************************************************************************/

		$.displayLinkStatus = function() {
			/* 
			 * 0: disabled 
			 * 1: green 
			 * 2: amber 
			 * 3: red 
			 * 4: not connected 
			 */

			if (rootap_link_status_2g == "0")
				rootap_2g_on = 0; // interface with 2g root ap is off

			if (rootap_link_status_5g == "0")
				rootap_5g_on = 0; // interface with 5g root ap is off

			if (client_link_status_2g == "0")
				client_2g_on = 0; //fastlane mode or 2g ap radio is off
			else
				$("#networkStatus_2g").css('display', 'block');

			if (client_link_status_5g == "0")
				client_5g_on = 0; //fastlane mode or 5g ap radio is off
			else
				$("#networkStatus_5g").css('display', 'block');

			if (access_point_mode != "0") {
				if (rootap_link_status_2g != "0" || rootap_link_status_5g != "0") {
					if (rootap_link_status_2g == "0")
					{
						client_link_status_2g = rootap_link_status_5g;
						client_link_status_5g = rootap_link_status_5g;
					}
					else if (rootap_link_status_5g == "0"){
						client_link_status_2g = rootap_link_status_2g;
                                                client_link_status_5g = rootap_link_status_2g;
					}else{
						client_link_status_2g = rootap_link_status_2g;
                                                client_link_status_5g = rootap_link_status_5g;
					}
				}
				if(fastlane_type == "1"){
					if(furfing_mode_type == "2.4G"){
						client_link_status_2g = 0;
						client_link_status_5g = rootap_link_status_2g;
					}
					else{
						client_link_status_5g = 0;
                                                client_link_status_2g = rootap_link_status_5g;
					}									}	
			//	client_link_status_2g = rootap_link_status_2g;
			//	client_link_status_5g = rootap_link_status_5g;

				if (rootap_link_status_2g == "3") {
					$("#cc_blackshade").addClass('smallMarkImage');
					$("#cc_blackshade").addClass('blackShade');

					$("#cc_icon1").addClass('smallMarkImage');
					$("#cc_icon1").addClass('whiteCircleTop');
					$("#cc_icon2").addClass('smallMarkImage');
					if (rootap_2g_on == 1)
						$("#cc_icon2").addClass('linkRate24g_top');
					else
						$("#cc_icon2").addClass('linkRate5g_right'); //to be improved

					$("#cc_text1").addClass('letters_green_topLine');
					$("#cc_text1").html(best_connection);

					if (rootap_2g_on == 1 && rootap_5g_on == 1) {
						$("#cc_icon3").addClass('smallMarkImage');
						$("#cc_icon3").addClass('whiteCircleBottom');
						$("#cc_icon4").addClass('smallMarkImage');
						$("#cc_icon4").addClass('linkRate5g_bottom');
						$("#cc_text2").addClass('letters_green_bottomLine');
						$("#cc_text2").html(best_connection);
					}
				} else if (rootap_link_status_2g == "2" || rootap_link_status_2g == "1") {
					$("#cc_blackshade").addClass('smallMarkImage');
					$("#cc_blackshade").addClass('blackShade');

					if (rootap_2g_on == 1 && rootap_5g_on == 1) {
						$("#cc_icon1").addClass('smallMarkImage');
						$("#cc_icon1").addClass('whiteEllipse');
						$("#cc_icon2").addClass('smallMarkImage');
						$("#cc_icon2").addClass('linkRate24g_left');
						$("#cc_icon3").addClass('smallMarkImage');
						$("#cc_icon3").addClass('linkRate5g_right');
						$("#cc_text1").addClass('letters_topLine');
						if (rootap_link_status_2g == "2")
							$("#cc_text1").html(good_connection);
						else //3
							$("#cc_text1").html(poor_connection);
					} else {
						$("#cc_icon1").addClass('smallMarkImage');
						$("#cc_icon1").addClass('whiteCircleTop');
						$("#cc_icon2").addClass('smallMarkImage');
						if (rootap_2g_on == 1)
							$("#cc_icon2").addClass('linkRate24g_top');
						else
							$("#cc_icon2").addClass('linkRate5g_right'); //to be improved

						$("#cc_text1").addClass('letters_green_topLine');
						if (rootap_link_status_2g == "2")
							$("#cc_text1").html(good_connection);
						else //3
							$("#cc_text1").html(poor_connection);
					}

					$("#cc_text2").addClass('letters_bottomLine');
					$("#cc_text2").html(move_to_extender);
				}
			}

			if (access_point_mode == "0") {
				client_link_status_2g = rootap_link_status_2g;
				client_link_status_5g = rootap_link_status_5g;
			}

			if (access_point_mode != "0") { //repeater mode
				if (rootap_link_status_2g == "1" || rootap_link_status_5g == "1" 
						|| rootap_link_status_2g == "2" || rootap_link_status_5g == "2" 
						|| rootap_link_status_2g == "3" || rootap_link_status_5g == "3") {
							$("#title_string").html("Your extender has successfully connected to your existing WiFi network");
						} else {
							$("#title_string").append("You have created an access point but we did not detect an Internet connection.");
						}
			} else { //access point
				if (client_link_status_2g == "1" || client_link_status_5g == "1"
						|| client_link_status_2g == "2" || client_link_status_5g == "2"
						|| client_link_status_2g == "3" || client_link_status_5g == "3") {
							$("#title_string").html("You have successfully created an access point.");
						} else {
							$("#title_string").html("You have created an access point but we did not detect an Internet connection.");
						}
			}

			// sta band 2.4G link status
			$("#cc_location1").addClass('confirmation');
			$("#cc_location1").addClass('location12');
			if (rootap_link_status_2g == "3")
				$("#cc_location1").addClass('best1');
			else if (rootap_link_status_2g == "2")
				$("#cc_location1").addClass('ok1');
			else if (rootap_link_status_2g == "1")
				$("#cc_location1").addClass('poor1');
			else if (rootap_link_status_2g == 0)
				$("#cc_location1").addClass('noConnected1');
			else //4
				$("#cc_location1").addClass('disable1');

			// sta band 5G link status
			$("#cc_location4").addClass('confirmation');
			$("#cc_location4").addClass('location34');
			if (rootap_link_status_5g == "3")
				$("#cc_location4").addClass('best4');
			else if (rootap_link_status_5g == "2")
				$("#cc_location4").addClass('ok4');
			else if (rootap_link_status_5g == "1")
				$("#cc_location4").addClass('poor4');
			else if (rootap_link_status_5g == "0")
				$("#cc_location4").addClass('noConnected4');
			else //4
				$("#cc_location4").addClass('disable4');

			// ap band 2.4G link status
			$("#cc_location2").addClass('confirmation');
			$("#cc_location2").addClass('location12');
			if (client_link_status_2g == "3")
				$("#cc_location2").addClass('best2');
			else if (client_link_status_2g == "2")
				$("#cc_location2").addClass('ok2');
			else if (client_link_status_2g == "1")
				$("#cc_location2").addClass('poor2');
			else if (client_link_status_2g == "0")
				$("#cc_location2").addClass('noConnected2');
			else //4
				$("#cc_location2").addClass('disable2');

			// ap band 2.4G link status
			$("#cc_location3").addClass('confirmation');
			$("#cc_location3").addClass('location34');
			if (client_link_status_5g == "3")
				$("#cc_location3").addClass('best3');
			else if (client_link_status_5g == "2")
				$("#cc_location3").addClass('ok3');
			else if (client_link_status_5g == "1")
				$("#cc_location3").addClass('poor3');
			else if (client_link_status_5g == "0")
				$("#cc_location3").addClass('noConnected3');
			else //4
				$("#cc_location3").addClass('disable3');
		};

		if ( $('#successForm').length ) {

			$.displayLinkStatus();

			//			if ( rootOption == '1' )
			//			{
			$('.first ul strong:first').html(clientSSID.replace(/ /g, '&nbsp;'));
			$('.first ul strong:eq(1)').html($.formatSecType(clientSecType));
			if(clientSecType == "1")
				$('.first ul li:last').hide();
			else
				$('.first ul strong:last').html($.showPassKey(clientSecType, clientKeyNum, "client"));
			//			}

			//			if ( root5gOption == '1' )
			//			{
			$('.second ul strong:first').html(client5gSSID.replace(/ /g, '&nbsp;'));
			$('.second ul strong:eq(1)').html($.formatSecType(client5gSecType));
			if(client5gSecType == "1")
				$('.second ul li:last').hide();
			else
				$('.second ul strong:last').html($.showPassKey(client5gSecType, client5gKeyNum, "client5g"));
			//			}

			if(fastlane_type == "1" && furfing_mode_type == "2.4G"){
				$('.first.networkStatus_2g').hide();
			}
			if(fastlane_type == "1" && furfing_mode_type == "5G"){
                                $('.second.networkStatus_5g').hide();
                        }

			if ( wl_conf_mode == "2" && ( (rootOption == "1" && root5gOption == "0" && (link_status == "0" || link_status == "")) || ( rootOption == "0" && root5gOption == "1" && (link_status_5g == "0" || link_status_5g == "") ) || ( rootOption == "1" && root5gOption == "1" && (link_status == "0" || link_status == "" || link_status_5g == "0" || link_status_5g == "") )) ) {
				$('a.btn.primary').html(retry_mark);
				$('a.btn.primary').attr('href', 'ca_extender_continue.htm'+$.ID_2);
			} else if ( wl_conf_mode == "0" && (ip_status == "0" || ip_status == "")){
				$('a.btn.primary').html(retry_mark);
				$('a.btn.primary').attr('href', 'ca_access_checking.htm'+$.ID_2);
			} else {
				$('a.btn.primary').click(function() {
					$.submit_wait('body', $.WAITING_DIV);
					$('input[name=submit_flag]', '#successForm').val("finish");
					$.postForm('#successForm','',function(json){
						if ( have_reg == "1" || serialNumber == "N/A" )
							location.href = "/status.htm"+$.ID_2;
						else
						{
							$.ajax({
								url: registerUrl + "checkRegistrationStatusbySerial",
								jsonp: "callback",
								dataType: "jsonp",
								data: {
									serial_number: serialNumber
								},
								timeout: 15000,
								// work with the response
								success: function( response ) {
									if(response.errorCode==200) {
										if(response.registrationStatus != 0) {
											$('input[name=submit_flag]', '#successForm').val("reg_info");
											$.postForm('#successForm','',function(json){});
											location.href = "/status.htm"+$.ID_2;
										} else
											location.href = "/registerInfo.htm"+$.ID_2;
									} else {
										location.href = "/status.htm"+$.ID_2;
									}
								},
								error: function() {
									location.href = "/status.htm"+$.ID_2;
								}
							});
						}
					});
				});
			}

			if ($('.connectionState.accesspoint', '#successForm').length ) {
				$('a.btn.secondary').attr('href', 'ca_access_connect.htm'+$.ID_2);
			} else if ($('.connectionState.extender', '#successForm').length ) {
				$('a.btn.secondary').attr('href', 'ca_extender_bgn.htm'+$.ID_2);
			}
		}

		/*******************************************************************************************
                *
                *    support own style of checkbox.
                *
                *******************************************************************************************/
                $('body').find(':checkbox').each(function () {
                        if($(this).is(':checked')) {
                                $(this).addClass('checked');
                        } else {
                                $(this).removeClass('checked');
                        }
                });

	}); // end ready function

}(jQuery));
 
