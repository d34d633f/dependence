var subnet_mask = new Array(0, 128, 192, 224, 240, 248, 252, 254, 255);

var msg = new Array("The IP Address entered is invalid",	//INVALID_IP_ADDRESS
					"The IP Address cannot be zero.",	//ZERO_IP_ADDRESS
					"IP Address",	//IP_ADDRESS_DESC
					"The Subnet Mask entered is invalid",	//INVALID_MASK_ADDRESS
					"The Subnet Mask cannot be zero",	//ZERO_MASK_ADDRESS
					"Subnet Mask",	//MASK_ADDRESS_DESC
					"The Gateway IP Address entered is invalid",	//INVALID_GATEWAY_ADDRESS
					"The Gateway IP Address cannot be zero",	//ZERO_GATEWAY_ADDRESS
					"Gateway IP Address",	//GATEWAY_ADDRESS_DESC
					"The IP Address and the Gateway IP Address are not in the same subnet",	//NOT_SAME_DOMAIN
					"The Starting IP Address entered is invalid (IP Range: 1~254)",	//INVALID_START_IP
					"Please enter another Starting IP Address",	//ZERO_START_IP
					"Starting IP Address",	//START_IP_DESC
					"The LAN IP Address and the Start IP Address are not in the same subnet",	//START_INVALID_DOMAIN
					"The Ending IP Address entered is invalid (IP Range: 1~254)",	//INVALID_END_IP
					"Please enter another Ending IP Address",	//ZERO_END_IP
					"Ending IP Address",	//END_IP_DESC
					"The LAN IP Address and the End IP Address are not in the same subnet",	//END_INVALID_DOMAIN
					"The Primary DNS Address entered is invalid",	//INVALID_DNS_ADDRESS
					"The Primary DNS Address cannot be zero",	//ZERO_DNS_ADDRESS
					"Primary DNS Address",	//DNS_ADDRESS_DESC
					"The SSID field cannot be blank",	//SSID_EMPTY_ERROR					
					"WEP cannot be disabled when the Authentication type is set to Shared Key",	//AUTH_TYPE_ERROR
					"The length of the Passphrase must be at least 8 characters",	//PSK_LENGTH_ERROR
					"The Confirmed Passphrase does not match the Passphrase",	//PSK_MATCH_ERROR
					"The Confirmed Password does not match the New Password",	//MATCH_PWD_ERROR
					"The selected WEP key field cannot be blank",	//WEP_KEY_EMPTY
					"Please enter another Key",	//WIZARD_KEY_EMPTY
					"Quit setup wizard and discard settings?",	//QUIT_WIZARD
					"The legal characters for a MAC Address are 0~9, A~F, or a~f",	//MAC_ADDRESS_ERROR	 																	
					"The Ending IP Address must be greater than the Starting IP Address",	//IP_RANGE_ERROR
					"The Secondary DNS Address entered is invalid",	//INVALID_SEC_DNS_ADDRESS
					"The Secondary DNS Address cannot be zero",	//ZERO_SEC_DNS_ADDRESS
					"Secondary DNS Address",	//SEC_DNS_ADDRESS_DESC
					"The confirmed password does not match the new Admin password",	//ADMIN_PASS_ERROR
					"The confirmed password does not match the new User password",	//USER_PASS_ERROR
					"Please enter another Server Name",	//DDNS_SERVER_ERROR
					"Please enter another Host Name",	//DDNS_HOST_ERROR
					"Please enter another User Name",	//DDNS_USER_ERROR
					"Please enter another Password",	//DDNS_PASS_ERROR
					"Restore to Factory Default Settings?",	//RESTORE_DEFAULT
					"Are you sure you want to reboot the Wireless Bridge?",	//REBOOT_DEVICE
					"Load settings from a saved configuration file?",	//LOAD_SETTING
					"Please select a saved configuration file to upload",	//LOAD_FILE_ERROR
					"Only the Admin account can download the settings",	//DOWNLOAD_SETTING_ERROR
					"Please enter either a Host Name or an IP Address",	//PING_IP_ERROR
					"Please enter another SMTP Server or IP Address",	//SMTP_SERVER_ERROR
					"Please enter a valid email Address",	//EMAIL_ADDRESS_ERROR
					"Are you sure that you want to delete this Virtual Server Rule?",	//DEL_SERVER_MSG
					"Are you sure that you want to delete this Application Rule",	//DEL_APPLICATION_MSG
					"Are you sure that you want to delete this Filter?",	//DEL_FILTER_MSG
					"Are you sure that you want to delete this Route?",	//DEL_ROUTE_MSG
					"Are you sure that you want to delete this MAC Address?",	//DEL_MAC_MSG
					"Are you sure that you want to delete this Keyword?",	//DEL_KEYWORD_MSG
					"Are you sure that you want to delete this Domain?",	//DEL_DOMAIN_MSG
					"Are you sure that you want to delete this Entry?",	//DEL_ENTRY_MSG
					"Are you sure that you want to delete this DHCP Reservation?",	//DEL_STATIC_DHCP_MSG
					"Please enter another name",	//NAME_ERROR
					"Please enter a Trigger Port number",	//TRIGGER_PORT_ERROR
					"Please enter a Firewall Port number",	//PUBLIC_PORT_ERROR
					"Please enter another Private Port number",	//PRIVATE_PORT_ERROR
					"Please enter a Private IP Address.",	//PRIVATE_IP_ERROR
					"Please enter another port number",	//PORT_ERROR
					"Please select a Keyword to delete",	//DEL_KEYWORD_ERROR
					"The Keyword entered already exists in the list",	//SAME_KEYWORD_ERROR
					"Please enter another Keyword",	//KEYWORD_ERROR
					"Unable to add another Keyword",	//ADD_KEYWORD_ERROR
					"Please select a Blocked Domain to delete",	//DEL_BLOCK_DOMAIN_ERROR
					"Please select a Permitted Domain to delete",	//DEL_PERMIT_DOMAIN_ERROR
					"The Domain entered already exists in the list of Blocked Domains",	//SAME_BLOCK_DOMAIN
					"Please enter another Blocked Domain",	//BLOCK_DOMAIN_ERROR
					"Unable to add another Blocked Domain",	//ADD_BLOCK_DOMAIN_ERROR
					"The Domain entered already exists in the list of Permitted Domains",	//SAME_PERMIT_DOMAIN
					"Please enter another Permitted Domain",	//PERMIT_DOMAIN_ERROR
					"Unable to add another Permitted Domain",	//ADD_PERMIT_DOMAIN_ERROR
					"Please select a Firmware file to upgrade the router to",	//FIRMWARE_UPGRADE_ERROR
					"Please enter another Domain",	//DOMAIN_ERROR
					"Unable to add another Control Domains",	//ADD_CONTROL_DOMAIN_ERROR
					"Please select a Control Domain to delete",	//DEL_CONTROL_DOMAIN_ERROR
					"Please enter at least one Control Domain",	//CONTROL_DOMAIN_ERROR
					"The RADIUS Server 1 IP Address entered is invalid",	//INVALID_RADIUS_SERVER1_IP
					"The Radius Server 1 IP Address cannot be zero",	//ZERO_RADIUS_SERVER1_IP
					"Radius Server 1 IP Address",	//RADIUS_SERVER1_IP_DESC
					"The RADIUS Server 2 IP Address entered is invalid",	//INVALID_RADIUS_SERVER2_IP
					"The Radius Server 2 IP Address cannot be zero",	//ZERO_RADIUS_SERVER2_IP
					"Radius Server 2 IP Address",	//RADIUS_SERVER2_IP_DESC
					"The IP Address entered is invalid (IP Range: 1~254)",	//INVALID_STATIC_DHCP_IP
					"Please enter another IP Address",	//ZERO_STATIC_DHCP_IP
					"Please enter another Name",	//STATIC_DHCP_NAME
					"The Server IP Address entered is invalid",	//INVALID_SERVER_IP
					"The Server IP Address cannot be zero",	//ZERO_SERVER_IP
					"Server IP Address",	//SERVER_IP_DESC
					"The Passwords entered do not match",	//MATCH_WIZARD_PWD_ERROR
					"The Source Start IP Address entered is invalid",	//INVALID_SOURCE_START_IP
					"The Source Start IP Address cannot be zero",	//ZERO_SOURCE_START_IP
					"Source Start IP Address",	//SOURCE_START_IP_DESC
					"The Source End IP Address entered is invalid",	//INVALID_SOURCE_END_IP
					"The Source End IP Address cannot be zero",	//ZERO_SOURCE_END_IP
					"Source End IP Address",	//SOURCE_END_IP_DESC
					"The Destination Start IP Address entered is invalid",	//INVALID_DEST_START_IP
					"The Destination Start IP Address cannot be zero",	//ZERO_DEST_START_IP
					"Destination Start IP Address",	//DEST_START_IP_DESC
					"The Destination End IP Address entered is invalid",	//INVALID_DEST_END_IP
					"The Destination End IP Address cannot be zero",	//ZERO_DEST_END_IP
					"Destination End IP Address",	//DEST_END_IP_DESC
					"The length of the Passphrase must be between 8 and 63 characters",	//PSK_OVER_LEN
					"Reset JumpStart?",	//RESET_JUMPSTAR
					"Are you sure that you want to delete this rule?",	//DEL_RULE_MSG
					"Are you sure that you want to delete this schedule?",	// DEL_SCHEDULE_MSG
					"Unable to add another schedule",			// ADD_SCHEDULE_ERROR
					"Schedule Name can not empty",	//SCHEDULE_NAME_ERROR
					"Schedule Name can not enter all space",	//SCHEDULE_NAME_SPACE_ERROR
					"The Start Time entered is invalid",	// START_TIME_ERROR
					"The End Time entered is invalid",	// END_TIME_ERROR,
					"The Start Time cannot be greater than the End Time",	//	TIME_RANGE_ERROR
					"Please select a machine first",		// SELECT_MACHINE_ERROR
					"Please select an Application Name first",	// SELECT_APPLICATION_ERROR
					"Please select a Computer Name first",		// SELECT_COMPUTER_ERROR
					"Please enter another Wireless Security Password",	// SECURITY_PWD_ERROR
					"The URL/Domain entered is already in the list",		//	DUPLICATE_URL_ERROR
					"Login Name error",  //LOGIN_NAME_ERROR
					"Login Password error"	//LOGIN_PASS_ERROR
				);
var INVALID_IP_ADDRESS = 0;
var ZERO_IP_ADDRESS = 1;
var IP_ADDRESS_DESC = 2;
var INVALID_MASK_ADDRESS = 3;
var ZERO_MASK_ADDRESS = 4;
var MASK_ADDRESS_DESC = 5;
var INVALID_GATEWAY_ADDRESS = 6;
var ZERO_GATEWAY_ADDRESS = 7;
var GATEWAY_ADDRESS_DESC = 8;
var NOT_SAME_DOMAIN = 9;
var INVALID_START_IP = 10;
var ZERO_START_IP = 11;
var START_IP_DESC = 12;
var START_INVALID_DOMAIN = 13;
var INVALID_END_IP = 14;
var ZERO_END_IP = 15;
var END_IP_DESC = 16;
var END_INVALID_DOMAIN = 17;
var INVALID_DNS_ADDRESS = 18;
var ZERO_DNS_ADDRESS = 19;
var DNS_ADDRESS_DESC = 20;
var SSID_EMPTY_ERROR = 21;
var AUTH_TYPE_ERROR = 22;
var PSK_LENGTH_ERROR = 23;
var PSK_MATCH_ERROR = 24;
var MATCH_PWD_ERROR = 25;
var WEP_KEY_EMPTY = 26;
var WIZARD_KEY_EMPTY = 27;
var QUIT_WIZARD = 28;
var MAC_ADDRESS_ERROR = 29;
var IP_RANGE_ERROR = 30;
var INVALID_SEC_DNS_ADDRESS = 31;
var ZERO_SEC_DNS_ADDRESS = 32;
var SEC_DNS_ADDRESS_DESC = 33;
var ADMIN_PASS_ERROR = 34;
var USER_PASS_ERROR = 35;
var DDNS_SERVER_ERROR = 36;
var DDNS_HOST_ERROR = 37;
var DDNS_USER_ERROR = 38;
var DDNS_PASS_ERROR = 39;
var RESTORE_DEFAULT = 40;
var REBOOT_DEVICE = 41;
var LOAD_SETTING = 42;
var LOAD_FILE_ERROR = 43;
var DOWNLOAD_SETTING_ERROR = 44;
var PING_IP_ERROR = 45;
var SMTP_SERVER_ERROR = 46;
var EMAIL_ADDRESS_ERROR = 47;
var DEL_SERVER_MSG = 48;
var DEL_APPLICATION_MSG = 49;
var DEL_FILTER_MSG = 50;
var DEL_ROUTE_MSG = 51;
var DEL_MAC_MSG = 52;
var DEL_KEYWORD_MSG = 53;
var DEL_DOMAIN_MSG = 54;
var DEL_ENTRY_MSG = 55;
var DEL_STATIC_DHCP_MSG = 56;
var NAME_ERROR = 57;
var TRIGGER_PORT_ERROR = 58;
var PUBLIC_PORT_ERROR = 59;
var PRIVATE_PORT_ERROR = 60;
var PRIVATE_IP_ERROR = 61;
var PORT_ERROR = 62;
var DEL_KEYWORD_ERROR = 63;
var SAME_KEYWORD_ERROR = 64;
var KEYWORD_ERROR = 65;
var ADD_KEYWORD_ERROR = 66;
var DEL_BLOCK_DOMAIN_ERROR = 67;
var DEL_PERMIT_DOMAIN_ERROR = 68;
var SAME_BLOCK_DOMAIN = 69;
var BLOCK_DOMAIN_ERROR = 70;
var ADD_BLOCK_DOMAIN_ERROR = 71;
var SAME_PERMIT_DOMAIN = 72;
var PERMIT_DOMAIN_ERROR = 73;
var ADD_PERMIT_DOMAIN_ERROR = 74;
var FIRMWARE_UPGRADE_ERROR = 75;
var DOMAIN_ERROR = 76;
var ADD_CONTROL_DOMAIN_ERROR = 77;
var DEL_CONTROL_DOMAIN_ERROR = 78;
var CONTROL_DOMAIN_ERROR = 79;
var INVALID_RADIUS_SERVER1_IP = 80;
var ZERO_RADIUS_SERVER1_IP = 81;
var RADIUS_SERVER1_IP_DESC = 82;
var INVALID_RADIUS_SERVER2_IP = 83;
var ZERO_RADIUS_SERVER2_IP = 84;
var RADIUS_SERVER2_IP_DESC = 85;
var INVALID_STATIC_DHCP_IP = 86;
var ZERO_STATIC_DHCP_IP = 87;
var STATIC_DHCP_NAME = 88;
var INVALID_SERVER_IP = 89;
var ZERO_SERVER_IP = 90;
var SERVER_IP_DESC = 91;
var MATCH_WIZARD_PWD_ERROR = 92;
var INVALID_SOURCE_START_IP = 93;
var ZERO_SOURCE_START_IP = 94;
var SOURCE_START_IP_DESC = 95;
var INVALID_SOURCE_END_IP = 96;
var ZERO_SOURCE_END_IP = 97;
var SOURCE_END_IP_DESC = 98;
var INVALID_DEST_START_IP = 99;
var ZERO_DEST_START_IP = 100;
var DEST_START_IP_DESC = 101;
var INVALID_DEST_END_IP = 102;
var ZERO_DEST_END_IP = 103;
var DEST_END_IP_DESC = 104;
var PSK_OVER_LEN = 105;
var RESET_JUMPSTAR = 106;
var DEL_RULE_MSG = 107;
var DEL_SCHEDULE_MSG = 108;
var ADD_SCHEDULE_ERROR = 109;
var SCHEDULE_NAME_ERROR = 110
var SCHEDULE_NAME_SPACE_ERROR = 111;
var START_TIME_ERROR = 112;
var END_TIME_ERROR = 113;
var TIME_RANGE_ERROR = 114;
var SELECT_MACHINE_ERROR = 115;
var SELECT_APPLICATION_ERROR = 116;
var SELECT_COMPUTER_ERROR = 117;
var SECURITY_PWD_ERROR = 118;
var DUPLICATE_URL_ERROR = 119;
var LOGIN_NAME_ERROR = 120;
var LOGIN_PASS_ERROR = 121;

var default_rule = new Array(new rule_obj("FTP", "TCP", 21, 21),
							 new rule_obj("HTTP", "TCP", 80, 80),
							 new rule_obj("HTTPS", "TCP", 443, 443),
							 new rule_obj("DNS", "UDP", 53, 53),
							 new rule_obj("SMTP", "TCP", 25, 25),
							 new rule_obj("POP3", "TCP", 110, 110),
							 new rule_obj("Telnet", "TCP", 23, 23),
							 new rule_obj("IPSec", "UDP", 500, 500),
							 new rule_obj("PPTP", "TCP", 1723, 1723),
							 new rule_obj("NetMeeting", "TCP", 1720, 1720),
							 new rule_obj("DCS-1000", "TCP", 80, 80),
							 new rule_obj("DCS-2000 DCS-5300", "TCP", 800, 800),
							 new rule_obj("i2eye", "TCP", 1720, 1720),
							 new rule_obj("DCS-3120", "TCP", 3120, 3120)
						  );

var default_appl = new Array(new appl_obj("Battle.net", "TCP", "6112", "TCP", "6112"),
							 new appl_obj("Dialpad", "TCP", "7175", "TCP", "51200-51201,51210"),
							 new appl_obj("ICU II", "TCP", "2019", "TCP", "2000-2038,2050-2051,2069,2085,3010-3030"),
							 new appl_obj("MSN Gaming Zone", "TCP", "47624", "TCP", "2300-2400,28800-29000"),
							 new appl_obj("PC-to-Phone", "TCP", "12053", "TCP", "12120,12122,24150-24220"),
							 new appl_obj("Quick Time 4", "TCP", "554", "TCP", "6970-6999")
							);
							
function rule_obj(name, prot, public_port, private_port){	
	this.name = name;
	this.prot = prot;		
	this.public_port = public_port;
	this.private_port = private_port;
}

function appl_obj(name, trigger_prot, trigger_port, public_prot, public_port){
	this.name = name;
	this.trigger_prot = trigger_prot;		
	this.trigger_port = trigger_port;
	this.public_prot = public_prot;
	this.public_port = public_port;
}

function set_application_option(){    
	for (var i = 0; i < default_rule.length; i++){
		var temp_rule = default_rule[i];
		document.write("<option>" + temp_rule.name + "</option>");
	}
}

function set_special_appl_option(){  
	for (var i = 0; i < default_appl.length; i++){
		var temp_appl = default_appl[i];
		document.write("<option>" + temp_appl.name + "</option>");
	}
}

function addr_obj(addr, desc, allow_zero, e_msg1, e_msg2, e_msg3, is_mask){	
	this.addr = addr;
	this.desc = msg[desc];
	this.allow_zero = allow_zero;	
	this.e_msg1 = msg[e_msg1];
	this.e_msg2 = msg[e_msg2];	
	
	if (e_msg3 != -1){
		this.e_msg3 = msg[e_msg3];	
	}
	this.is_mask = is_mask;	
}

function varible_obj(var_value, desc, min, max, is_even){	
	this.var_value = var_value;
	this.desc = desc;
	this.min = min;
	this.max = max;		
	this.is_even = is_even;		
}

function ip4_obj(ip, min_range, max_range, e_msg1, e_msg2){	
	this.ip = ip;	
	this.min_range = min_range;
	this.max_range = max_range;		
	this.e_msg1 = msg[e_msg1];
	this.e_msg2 = msg[e_msg2];	
}

function check_hex(data){	
	data = data.toUpperCase();
	
	if (!(data >= 'A' && data <= 'F') && !(data >= '0' && data <= '9')){	
		return false;
	}	
	return true;
}

function check_ip4(ip4){
	var temp_ip = (ip4.ip).split(" ");
	
	if (ip4.ip == ""){
		alert(ip4.e_msg1);
		return false;
	}else if (isNaN(ip4.ip) || temp_ip.length > 1 || parseInt(ip4.ip) < ip4.min_range || parseInt(ip4.ip) > ip4.max_range){
		alert(ip4.e_msg2);
		return false;
	}
	return true;
}

function check_mac(mac){
    var temp_mac = mac.split(":");
    var error = true;
    
    if (temp_mac.length == 6){
	    for (var i = 0; i < 6; i++){        
	        var temp_str = temp_mac[i];
	        
	        if (temp_str == ""){
	            error = false;
	        }else{        	
	            if (!check_hex(temp_str.substring(0,1)) || !check_hex(temp_str.substring(1))){
	                error = false;
	            }
	        }
	        
	        if (!error){
	            break;
	        }
	    }
	}else{
		error = false;
	}
    return error;
}

function check_varible(obj){	
	var temp_obj = (obj.var_value).split(" ");
	
	if (temp_obj == ""){
		alert(obj.desc + " cannot be left blank");	
		return false;
	}else if (temp_obj.length > 1){
		alert("Please enter another " + obj.desc + " value");
		return false;
	}else if (isNaN(obj.var_value)){
		alert(obj.desc + " must be a number");
		return false;
	}else if (parseInt(obj.var_value) < obj.min || parseInt(obj.var_value) > obj.max){
		alert("The " + obj.desc + " value range is " + obj.min + " ~ " + obj.max + "");
		return false;
	}else if (obj.is_even && (parseInt(obj.var_value) % 2 != 0)){
		alert(obj.desc + " must be an even number");
		return false;
	}
	return true;
}

function check_integer(which_value, min, max){	   
	var temp_obj = (which_value).split(" ");
	
	if (temp_obj == "" || temp_obj.length > 1 || isNaN(which_value)){	  
		return false;
	}else if (parseInt(which_value,10) < min || parseInt(which_value,10) > max){
		return false;
	}
	
	return true;
}

function get_seq(index){
	var seq;
	
	switch(index){
		case 0:
			seq = "1st";
			break;
		case 1:
			seq = "2nd";
			break;
		case 2:
			seq = "3rd";
			break;
		case 3:
			seq = "4th";
			break;
	}
	return seq;
}

function check_ip_range(order, my_obj){
	var which_ip = (my_obj.addr[order]).split(" ");				
	var start, end;
	
	if ((order != 0 && order != 3) || my_obj.is_mask){
		start = 0;
		end = 255;
	}else{					
		start = 1;
		end = 254;				
	}
					
	if (isNaN(which_ip) || which_ip == "" || which_ip.length > 1){
		alert("The " + get_seq(order) + " octet of the " + my_obj.desc + " must be a number");
		return false;
	}else if (parseInt(which_ip) < start || parseInt(which_ip) > end){
		alert("The " + get_seq(order) + " octet of the " + my_obj.desc + " must be a number between " + start + " and " + end + "");
		return false;
	}				
	return true;
}

function check_address(my_obj, mask_obj){
	var count_zero = 0;
	var count_ip_zero = 0;
	var count_ip_cast = 0;
	var ip = my_obj.addr;
	var mask;
	var allow_cast = false;

	if (my_obj.addr.length == 4){
		
		for(var i = 0; i < ip.length; i++){
			if (ip[i] == "0"){
				count_zero++;			
			}				
		}

		if (!my_obj.allow_zero && count_zero == 4){	
			alert(my_obj.e_msg2);			
			return false;
		}else{
			if (count_zero != 4){
				if (check_address.arguments.length == 2 && mask_obj != null){
					mask = mask_obj.addr;
					count_zero = 0;					
					for(var i = 0; i < mask.length; i++){
						if (mask[i] == "0"){
							count_zero++;
						}
					}
					
					if (count_zero != 4){
						for (var i = ip.length - count_zero; i < ip.length; i++){			
							if (ip[i] == "0"){
								count_ip_zero++;
							}else if (ip[i] == "255"){
								count_ip_cast++;
							}			
						}
						
									
						if (count_zero != 0){
							if ((count_zero == count_ip_zero && !my_obj.is_network) || (count_zero == count_ip_cast)){
								alert(my_obj.e_msg2);
								return false;
							}
							
							if (count_zero > 1){
								allow_cast = true;
							}
						}
					}else{
						return true;
					}										
				}
				
				for(var i = 0; i < ip.length; i++){
					if (!check_ip_range(i, my_obj, allow_cast)){
						return false;
					}
				}
			}
		}
	}else{	
		alert(my_obj.e_msg2);
		return false;
	}

	return true;
}


function check_mask(my_mask){
	var temp_mask = my_mask.addr;							
	var in_range = false;
	var error;
	
		if (my_mask.addr.length == 4){
			
			for (var i = 0; i < temp_mask.length; i++){	
				var mask = parseInt(temp_mask[i]);
								
				for (var j = 0; j < subnet_mask.length; j++){
					if (mask == subnet_mask[j]){							
						in_range = true;
						break;
					}else{
						in_range = false;
					}
				}
				
				if (!in_range){	
					error = "The " + get_seq(i) + " octect of the " 
						+ my_mask.desc + " must be ";
					for (var j = 0; j < subnet_mask.length; j++){
						error += subnet_mask[j];
						if (j < subnet_mask.length - 1){
							error += ",";
						}
					}
					alert(error);
					return false;
				}
				
				if (i != 0 && mask != 0){ 
					if (parseInt(temp_mask[i-1]) != 255){  
						alert(my_mask.e_msg1);
						return false;
					}
				}					
			}
	
		}else{	
			alert(my_mask.e_msg1);
			return false;
		}

	
	return true;
}

function check_domain(ip, mask, gateway){
	var temp_ip = ip.addr;
	var temp_mask = mask.addr;
	var temp_gateway = gateway.addr;
	var is_same = true;

	if (temp_gateway[0] == 0 && temp_gateway[1] == 0 && temp_gateway[2] == 0 && temp_gateway[3] == 0){
		if (gateway.allow_zero){
			return is_same;
		}
	}
	for (var i = 0; i < temp_ip.length - 1; i++){
		if ((temp_ip[i] & temp_mask[i]) != (temp_gateway[i] & temp_mask[i])){
			is_same = false;		
			break;
		}
	}
	return is_same;
}

function check_lan_setting(ip, mask, gateway){				
	if (!check_address(ip, mask)){	
		return false;
	}else if (!check_mask(mask)){	
		return false;   
	}else if (!check_address(gateway, mask)){	
		return false;	
	}else if (!check_domain(ip, mask, gateway)){							
		alert(msg[NOT_SAME_DOMAIN]);
		return false;
	}
	return true;
}

function check_ssid(id){
	if (get_by_id(id).value == ""){
	    alert(msg[SSID_EMPTY_ERROR]);
	    return false;
	}
	return true;        
}

function check_port(port){                 
    var temp_port = port.split(" ");
    
    if (isNaN(port) || port == "" || temp_port.length > 1 
    		|| (parseInt(port) < 1 || parseInt(port) > 65534)){
        return false;
    }
    return true;
}

function check_pf_port(port){
    var temp_port = port.split(" ");
    
    if (isNaN(port) || port == "" || temp_port.length > 1 
    		|| (parseInt(port) < 0 || parseInt(port) > 65535)){
        return false;
    }
    return true;
}

function change_color(table_name, row){
    var obj = get_by_id(table_name);
    for (var i = 1; i < obj.rows.length; i++){
        if (row == i){
            obj.rows[i].style.backgroundColor = "#FFFF00";
        }else{
            obj.rows[i].style.backgroundColor = "#FFFFFF";
        }
    }       
}

function get_by_id(id){
	with(document){
		return getElementById(id);
	}
}

function get_by_name(name){
	with(document){
		return getElementsByName(name);
	}
}

function send_submit(which_form){
	get_by_id(which_form).submit();
}

function set_protocol(which_value, obj){
    for (var i = 0; i < 3; i++){    
        if (which_value == obj.options[i].value){
            obj.selectedIndex = i;
            break;
        }
    }
}

function set_schedule(data, index){ 
	var schd = get_by_name("schd");  
	
    if (data[index] == "0"){
        schd[0].checked = true;      
    }else{
        schd[1].checked = true;        
    }
    
    get_by_id("hour1").selectedIndex = data[index+1];
    get_by_id("min1").selectedIndex = data[index+2];
    get_by_id("am1").selectedIndex = data[index+3];
    get_by_id("hour2").selectedIndex = data[index+4];
    get_by_id("min2").selectedIndex = data[index+5];
    get_by_id("am2").selectedIndex = data[index+6];
    get_by_id("day1").selectedIndex = data[index+7];
    get_by_id("day2").selectedIndex = data[index+8];
}

function set_schedule_list(data, obj){
	
	for (var i = 0; i < obj.options.length; i++){
		if (data == obj.options[i].value){
			obj.selectedIndex = i;
			break;
		}
	}	
}

function set_schedule_option(){    
	for (var i = 0; i < 20; i++){
		var temp_sch = get_by_id("schedule_rule_" + i).value;
		var temp_data = temp_sch.split("/");
		
		if (temp_data.length > 1){
			document.write("<option value='" + temp_data[0] + "'>" + temp_data[0] + "</option>");
		}else{
			break;
		}
	}
}
 
function set_dhcp_list(){     
	var temp_dhcp_list = get_by_id("dhcp_list").value.split(",");
	
	for (var i = 0; i < temp_dhcp_list.length; i++){	
		var temp_data = temp_dhcp_list[i].split("/");
		if(temp_data.length > 1){		
		document.write("<option value='" + temp_data[1] + "'>" + temp_data[0] + "</option>");	
		}
	}
}

function set_mac(mac){
	var temp_mac = mac.split(":");
	
	for (var i = 0; i < 6; i++){
		var obj = get_by_id("mac" + (i+1)); 
		obj.value = temp_mac[i];
	}
	
}

function copy_application(index){    
	var data;
	
	if (get_by_id("application" + index).selectedIndex > 0){
		data = default_rule[get_by_id("application" + index).selectedIndex - 1];		
		get_by_id("name" + index).value = data.name;
		get_by_id("public_port" + index).value = data.public_port;
		get_by_id("private_port" + index).value = data.private_port;
		set_protocol(data.prot, get_by_id("protocol" + index));	
	}else{
		alert(msg[SELECT_APPLICATION_ERROR]);
	}		
}

function copy_special_appl(index){                 
	var name = get_by_id("name" + index);
	var trigger_port = get_by_id("trigger_port" + index);
	var trigger_type = get_by_id("trigger" + index);
	var public_port = get_by_id("public_port" + index);
	var public_type = get_by_id("public" + index);
	var application = get_by_id("application" + index);		
	var data;
	
	if (application.selectedIndex > 0){
		data = default_appl[application.selectedIndex - 1];
		name.value = data.name;		
		trigger_port.value = data.trigger_port;			
		public_port.value = data.public_port;				
		set_protocol(data.trigger_prot, trigger_type);   
		set_protocol(data.public_prot, public_type);    		
	}else{
		alert(msg[SELECT_APPLICATION_ERROR]);
	}
	
}

function copy_ip(index){   

	if (get_by_id("ip_list" + index).selectedIndex > 0){
		get_by_id("ip" + index).value = get_by_id("ip_list" + index).options[get_by_id("ip_list" + index).selectedIndex].value;
	}else{
		alert(msg[SELECT_COMPUTER_ERROR]);
	}
}

function check_ascii_key_fun(data){	

	if (!(data >= 'A' && data <= 'Z') && !(data >= '0' && data <= '9') && !(data >= 'a' && data <= 'z')){	
		return false;
	}	
	return true;
}

function Find_word(strOrg,strFind){
	var index = 0;
	index = strOrg.indexOf(strFind,index);
	if (index > -1){
		return true;
	}
	return false;
}

function set_selectIndex(which_value, obj){
    for (var pp=0; pp<obj.options.length; pp++){
        if (which_value == obj.options[pp].value){
            obj.selectedIndex = pp;
            break;
        }
    }
}

	function change_wls_mode(){
		var html_file;
		switch(get_by_id("Wls_mode").selectedIndex){
			case 0 : 
				html_file = "bWlsBridgeSetting.asp";
				get_by_id("wlan0_mode").value = "bridge";
				break;
			
			case 1 :
				html_file = "bWlsWorkgroup.asp";
				get_by_id("wlan0_mode").value = "mbridge";
				break;
				
			case 2 :
				html_file = "bWlsWanSetting.asp";
				get_by_id("wlan0_mode").value = "sta";
				break;	   	
		}
		parent.ApplyType.value = 0;
		location.href = html_file;
	}
	
	function SiteSurvey(){
			if(parent.ApplyType.value == 0 ){
				document.getElementById("iframe_scan").src="list.asp";
				document.getElementById('WlsScan').style.display ="";
				parent.ApplyType.value=1;
			}else if(parent.ApplyType.value == 1 ){
				var now = new Date();
				var totle_sec = now.getHours()*60 + now.getMinutes()*60 + now.getSeconds();				
				if(totle_sec - parent.last_timer.value > 3){					
					parent.last_timer.value = totle_sec ;
					document.getElementById('WlsScan').style.display ="";
					ScanReload.value=1;
					document.getElementById("iframe_scan").src="list.asp";
				}		
			}
	}

	function check_wep_key(){
		
			if(get_by_id("EnableEncryption").checked == true){
				if(get_by_id("KeyNumber").selectedIndex == 0){
				
						get_by_id("wlan0_wep_default_key").value = "1";
											
						if(get_by_id("KeySize").value == 0){ 
							if(get_by_id("KeyType").value == 0){ 				
																
									if(get_by_id("key1_64_hex").value == "" ){
											alert("key1 can not be empty");
											return false;
									}
									
									if (get_by_id("key1_64_hex").value.length < 10){
											alert("The length of Key" + 1 + " must be " + 10 + " characters");
											get_by_id("key1_64_hex").select();
											get_by_id("key1_64_hex").value="";
											return false;
									}else{
											for (var j = 0; j < get_by_id("key1_64_hex").value.length; j++){
												if (!check_hex(get_by_id("key1_64_hex").value.substring(j, j+1))){
														alert("Key" + 1 + " is invalid. The legal characters are 0~9, A~F, or a~f");
														get_by_id("key1_64_hex").select();
														get_by_id("key1_64_hex").value="";
														return false;
												}
											}
									}
	
							}else if(get_by_id("KeyType").value == 1){
						
									if(get_by_id("key1_64_ascii").value == "" ){
											alert("key1 can not be empty");
											return false;
									}

									if (get_by_id("key1_64_ascii").value.length != 5){
											alert("The length of Key" + 1 + " must be " + 5 + " characters");
											get_by_id("key1_64_ascii").select();
											get_by_id("key1_64_ascii").value="";
											return false;
									}
							}
						}else if(get_by_id("KeySize").value == 1){
							if(get_by_id("KeyType").value == 0){			
							
									if(get_by_id("key1_128_hex").value == "" ){
											alert("key1 can not be empty");
											return false;
									}
									
									if (get_by_id("key1_128_hex").value.length < 26){
											alert("The length of Key" + 1 + " must be " + 26 + " characters");
											get_by_id("key1_128_hex").select();
											get_by_id("key1_128_hex").value="";
											return false;
									}else{
											for (var j = 0; j < get_by_id("key1_128_hex").value.length; j++){
												if (!check_hex(get_by_id("key1_128_hex").value.substring(j, j+1))){
														alert("Key" + 1 + " is invalid. The legal characters are 0~9, A~F, or a~f");
														get_by_id("key1_128_hex").select();
														get_by_id("key1_128_hex").value="";
														return false;
												}
											}
									}
							}else if(get_by_id("KeyType").value == 1){
								
									if(get_by_id("key1_128_ascii").value == "" ){
											alert("key1 can not be empty");
											return false;
									}
								
									if (get_by_id("key1_128_ascii").value.length != 13){
											alert("The length of Key" + 1 + " must be " + 13 + " characters");
											get_by_id("key1_128_ascii").select();
											get_by_id("key1_128_ascii").value="";
											return false;
									}
							}
						}
				}else if(get_by_id("KeyNumber").selectedIndex == 1){
				
						get_by_id("wlan0_wep_default_key").value = "2";
					
						if(get_by_id("KeySize").value == 0){
							if(get_by_id("KeyType").value == 0){		
							
									if(get_by_id("key2_64_hex").value == "" ){
											alert("key2 can not be empty");
											return false;
									}
									
									if (get_by_id("key2_64_hex").value.length < 10){
											alert("The length of Key" + 2 + " must be " + 10 + " characters");
											get_by_id("key2_64_hex").select();
											get_by_id("key2_64_hex").value="";
											return false;
									}else{
											for (var j = 0; j < get_by_id("key2_64_hex").value.length; j++){
												if (!check_hex(get_by_id("key2_64_hex").value.substring(j, j+1))){
														alert("Key" + 2 + " is invalid. The legal characters are 0~9, A~F, or a~f");
														get_by_id("key2_64_hex").select();
														get_by_id("key2_64_hex").value="";
														return false;
												}
											}
									}
							}else if(get_by_id("KeyType").value == 1){
									if(get_by_id("key2_64_ascii").value == "" ){
											alert("key2 can not be empty");
											return false;
									}
								
									if (get_by_id("key2_64_ascii").value.length != 5){
											alert("The length of Key" + 2 + " must be " + 5 + " characters");
											get_by_id("key2_64_ascii").select();
											get_by_id("key2_64_ascii").value.value="";
											return false;
									}
							}
						}else if(get_by_id("KeySize").value == 1){
							if(get_by_id("KeyType").value == 0){
									if(get_by_id("key2_128_hex").value == "" ){
											alert("key2 can not be empty");
											return false;
									}
									if (get_by_id("key2_128_hex").value.length < 26){
											alert("The length of Key" + 2 + " must be " + 26 + " characters");
											get_by_id("key2_128_hex").select();
											get_by_id("key2_128_hex").value="";
											return false;
									}else{
											for (var j = 0; j < get_by_id("key2_128_hex").value.length; j++){
												if (!check_hex(get_by_id("key2_128_hex").value.substring(j, j+1))){
														alert("Key" + 2 + " is invalid. The legal characters are 0~9, A~F, or a~f");
														get_by_id("key2_128_hex").select();
														get_by_id("key2_128_hex").value="";
														return false;
												}
											}
									}
							}else if(get_by_id("KeyType").value == 1){ 
									if(get_by_id("key2_128_ascii").value == "" ){
											alert("key2 can not be empty");
											return false;
									}
									if (get_by_id("key2_128_ascii").value.length != 13){
											alert("The length of Key" + 2 + " must be " + 13 + " characters");
											get_by_id("key2_128_ascii").select();
											get_by_id("key2_128_ascii").value="";
											return false;
									}
							}
						}
				}else if(get_by_id("KeyNumber").selectedIndex == 2){
						get_by_id("wlan0_wep_default_key").value = "3";
					
						if(get_by_id("KeySize").value == 0){
							if(get_by_id("KeyType").value == 0){
									if(get_by_id("key3_64_hex").value == "" ){
											alert("key3 can not be empty");
											return false;
									}
									if (get_by_id("key3_64_hex").value.length < 10){
											alert("The length of Key" + 3 + " must be " + 10 + " characters");
											get_by_id("key3_64_hex").select();
											get_by_id("key3_64_hex").value="";
											return false;
									}else{
											for (var j = 0; j < get_by_id("key3_64_hex").value.length; j++){
												if (!check_hex(get_by_id("key3_64_hex").value.substring(j, j+1))){
														alert("Key" + 3 + " is invalid. The legal characters are 0~9, A~F, or a~f");
														get_by_id("key3_64_hex").select();
														get_by_id("key3_64_hex").value="";
														return false;
												}
											}
									}
	
							}else if(get_by_id("KeyType").value == 1){
									if(get_by_id("key3_64_ascii").value == "" ){
											alert("key3 can not be empty");
											return false;
									}
									if (get_by_id("key3_64_ascii").value.length != 5){
											alert("The length of Key" + 3 + " must be " + 5 + " characters");
											get_by_id("key3_64_ascii").select();
											get_by_id("key3_64_ascii").value="";
											return false;
									}
							}
						}else if(get_by_id("KeySize").value == 1){
							if(get_by_id("KeyType").value == 0){ 				
									if(get_by_id("key3_128_hex").value == "" ){
											alert("key3 can not be empty");
											return false;
									}
									if (get_by_id("key3_128_hex").value.length < 26){
											alert("The length of Key" + 3 + " must be " + 26 + " characters");
											get_by_id("key3_128_hex").select();
											get_by_id("key3_128_hex").value="";
											return false;
									}else{
											for (var j = 0; j < get_by_id("key3_128_hex").value.length; j++){
												if (!check_hex(get_by_id("key3_128_hex").value.substring(j, j+1))){
														alert("Key" + 3 + " is invalid. The legal characters are 0~9, A~F, or a~f");
														get_by_id("key3_128_hex").select();
														get_by_id("key3_128_hex").value.value="";
														return false;
												}
											}
									}
							}else if(get_by_id("KeyType").value == 1){
									if(get_by_id("key3_128_ascii").value == "" ){
											alert("key3 can not be empty");
											return false;
									}
									if (get_by_id("key3_128_ascii").value.length != 13){
											alert("The length of Key" + 3 + " must be " + 13 + " characters");
											get_by_id("key3_128_ascii").select();
											get_by_id("key3_128_ascii").value="";											
											return false;
									}
							}
						}
				}else if(get_by_id("KeyNumber").selectedIndex == 3){
						get_by_id("wlan0_wep_default_key").value = "4";
					
						if(get_by_id("KeySize").value == 0){
							if(get_by_id("KeyType").value == 0){				
									if(get_by_id("key4_64_hex").value == "" ){
											alert("key4 can not be empty");
											return false;
									}
									if (get_by_id("key4_64_hex").value.length < 10){
											alert("The length of Key" + 4 + " must be " + 10 + " characters");
											get_by_id("key4_64_hex").select();
											get_by_id("key4_64_hex").value="";
											return false;
									}else{
											for (var j = 0; j < get_by_id("key4_64_hex").value.length; j++){
												if (!check_hex(get_by_id("key4_64_hex").value.substring(j, j+1))){
														alert("Key" + 4 + " is invalid. The legal characters are 0~9, A~F, or a~f");
														get_by_id("key4_64_hex").select();
														get_by_id("key4_64_hex").value="";
														return false;
												}
											}
									}
							}else if(get_by_id("KeyType").value == 1){
									if(get_by_id("key4_64_ascii").value == "" ){
											alert("key4 can not be empty");
											return false;
									}
									if (get_by_id("key4_64_ascii").value.length != 5){
											alert("The length of Key" + 4 + " must be " + 5 + " characters");
											get_by_id("key4_64_ascii").select();
											get_by_id("key4_64_ascii").value="";
											return false;
									}
							}
						}else if(get_by_id("KeySize").value == 1){
							if(get_by_id("KeyType").value == 0){ 			
									if(get_by_id("key4_128_hex").value == "" ){
											alert("key4 can not be empty");
											return false;
									}
						
									if (get_by_id("key4_128_hex").value.length < 26){
											alert("The length of Key" + 4 + " must be " + 26 + " characters");
											get_by_id("key4_128_hex").select();
											get_by_id("key4_128_hex").value="";
											return false;
									}else{
											for (var j = 0; j < get_by_id("key4_128_hex").value.length; j++){
												if (!check_hex(get_by_id("key4_128_hex").value.substring(j, j+1))){
														alert("Key" + 4 + " is invalid. The legal characters are 0~9, A~F, or a~f");
														get_by_id("key4_128_hex").select();
														get_by_id("key4_128_hex").value="";
														return false;
												}
											}
									}
	
							}else if(get_by_id("KeyType").value == 1){
									if(get_by_id("key4_128_ascii").value == "" ){
											alert("key4 can not be empty");
											return false;
									}
									if (get_by_id("key4_128_ascii").value.length != 13){
											alert("The length of Key" + 4 + " must be " + 13 + " characters");
											get_by_id("key4_128_ascii").select();
											get_by_id("key4_128_ascii").value="";
											return false;
									}
							}
						}
				}
			}
		return true;
	}
	
	function show_key_text(){
		if(get_by_id("KeyType").selectedIndex == 0){
			if(get_by_id("KeySize").selectedIndex == 0){
				get_by_id("key1_64_ascii").style.display = "none"; 
				get_by_id("key2_64_ascii").style.display = "none"; 
				get_by_id("key3_64_ascii").style.display = "none"; 
				get_by_id("key4_64_ascii").style.display = "none";
				get_by_id("key1_128_ascii").style.display = "none"; 
				get_by_id("key2_128_ascii").style.display = "none"; 
				get_by_id("key3_128_ascii").style.display = "none"; 
				get_by_id("key4_128_ascii").style.display = "none";
				get_by_id("key1_64_hex").style.display = ""; 
				get_by_id("key2_64_hex").style.display = ""; 
				get_by_id("key3_64_hex").style.display = ""; 
				get_by_id("key4_64_hex").style.display = "";
				get_by_id("key1_128_hex").style.display = "none"; 
				get_by_id("key2_128_hex").style.display = "none"; 
				get_by_id("key3_128_hex").style.display = "none"; 
				get_by_id("key4_128_hex").style.display = "none";
			}else{
				get_by_id("key1_64_ascii").style.display = "none"; 
				get_by_id("key2_64_ascii").style.display = "none"; 
				get_by_id("key3_64_ascii").style.display = "none"; 
				get_by_id("key4_64_ascii").style.display = "none";
				get_by_id("key1_128_ascii").style.display = "none"; 
				get_by_id("key2_128_ascii").style.display = "none"; 
				get_by_id("key3_128_ascii").style.display = "none"; 
				get_by_id("key4_128_ascii").style.display = "none";
				get_by_id("key1_64_hex").style.display = "none"; 
				get_by_id("key2_64_hex").style.display = "none"; 
				get_by_id("key3_64_hex").style.display = "none"; 
				get_by_id("key4_64_hex").style.display = "none";
				get_by_id("key1_128_hex").style.display = ""; 
				get_by_id("key2_128_hex").style.display = ""; 
				get_by_id("key3_128_hex").style.display = ""; 
				get_by_id("key4_128_hex").style.display = "";
			}
		}else if(get_by_id("KeyType").selectedIndex == 1){
			if(get_by_id("KeySize").selectedIndex == 0){
				get_by_id("key1_64_ascii").style.display = ""; 
				get_by_id("key2_64_ascii").style.display = ""; 
				get_by_id("key3_64_ascii").style.display = ""; 
				get_by_id("key4_64_ascii").style.display = "";
				get_by_id("key1_128_ascii").style.display = "none"; 
				get_by_id("key2_128_ascii").style.display = "none"; 
				get_by_id("key3_128_ascii").style.display = "none"; 
				get_by_id("key4_128_ascii").style.display = "none";
				get_by_id("key1_64_hex").style.display = "none"; 
				get_by_id("key2_64_hex").style.display = "none"; 
				get_by_id("key3_64_hex").style.display = "none"; 
				get_by_id("key4_64_hex").style.display = "none";
				get_by_id("key1_128_hex").style.display = "none"; 
				get_by_id("key2_128_hex").style.display = "none"; 
				get_by_id("key3_128_hex").style.display = "none"; 
				get_by_id("key4_128_hex").style.display = "none";
			}else{
				get_by_id("key1_64_ascii").style.display = "none"; 
				get_by_id("key2_64_ascii").style.display = "none"; 
				get_by_id("key3_64_ascii").style.display = "none"; 
				get_by_id("key4_64_ascii").style.display = "none";
				get_by_id("key1_128_ascii").style.display = ""; 
				get_by_id("key2_128_ascii").style.display = ""; 
				get_by_id("key3_128_ascii").style.display = ""; 
				get_by_id("key4_128_ascii").style.display = "";
				get_by_id("key1_64_hex").style.display = "none"; 
				get_by_id("key2_64_hex").style.display = "none"; 
				get_by_id("key3_64_hex").style.display = "none"; 
				get_by_id("key4_64_hex").style.display = "none";
				get_by_id("key1_128_hex").style.display = "none"; 
				get_by_id("key2_128_hex").style.display = "none"; 
				get_by_id("key3_128_hex").style.display = "none"; 
				get_by_id("key4_128_hex").style.display = "none";
			}
		}
	}
	
	function Change_Valid_Index(){
		var KeyTitle     	= new Array();
		var Key_64_hex   	= new Array();
		var Key_128_hex  	= new Array();
		var Key_64_ascii 	= new Array();
		var Key_128_ascii  	= new Array();
	
		var nowKeyIndex;
		var KeyNumber = get_by_id("KeyNumber");
		               
  		if(KeyNumber != null){
    			if(KeyNumber.options[KeyNumber.selectedIndex].text == "First")
        				nowKeyIndex = 0;
   				else if(KeyNumber.options[KeyNumber.selectedIndex].text == "Second")
        				nowKeyIndex = 1;
    			else if(KeyNumber.options[KeyNumber.selectedIndex].text == "Third")
        				nowKeyIndex = 2;
    			else if(KeyNumber.options[KeyNumber.selectedIndex].text == "Fourth")
        				nowKeyIndex = 3;

    		for(i=0; i<4; i++){
    
	  			KeyTitle[i]    	  = get_by_id("k"+(i+1)+"str");  
  				Key_64_hex[i]     = get_by_id("key"+(i+1)+"_64_hex"); 
  				Key_128_hex[i]    = get_by_id("key"+(i+1)+"_128_hex");
  				Key_64_ascii[i]   = get_by_id("key"+(i+1)+"_64_ascii"); 
  				Key_128_ascii[i]  = get_by_id("key"+(i+1)+"_128_ascii"); 

        		if(DisableEncryption.checked == true ){  
        				KeyTitle[i].style.color = "black";                
       					KeyTitle[i].style.fontWeight = "normal";
        				Key_64_hex[i].disabled = true;
        				Key_128_hex[i].disabled = true;
        				Key_64_ascii[i].disabled = true;
        				Key_128_ascii[i].disabled = true;
				}else{
	  
        				if(i == nowKeyIndex){                      
							KeyTitle[i].style.color = "blue";               
							KeyTitle[i].style.fontWeight = "bold";		  
							Key_64_hex[i].disabled = false;
							Key_128_hex[i].disabled = false;
							Key_64_ascii[i].disabled = false;
							Key_128_ascii[i].disabled = false;
        				}else{														
							KeyTitle[i].style.color = "black";
							KeyTitle[i].style.fontWeight = "normal";
							Key_64_hex[i].disabled = true;
							Key_128_hex[i].disabled = true;
							Key_64_ascii[i].disabled = true;
							Key_128_ascii[i].disabled = true;
        				}
      			}
     		}
	   }
	}

	function save_wep_key(){
				if(EnableEncryption.checked == true){
						if(get_by_id("KeyType").selectedIndex == 0){
								if(get_by_id("KeySize").selectedIndex == 0){ 			
										get_by_id("wlan0_wep64_key_1").value = get_by_id("key1_64_hex").value;
										get_by_id("wlan0_wep64_key_2").value = get_by_id("key2_64_hex").value;
										get_by_id("wlan0_wep64_key_3").value = get_by_id("key3_64_hex").value;
										get_by_id("wlan0_wep64_key_4").value = get_by_id("key4_64_hex").value;
								}else if(get_by_id("KeySize").selectedIndex == 1){			
										get_by_id("wlan0_wep128_key_1").value = get_by_id("key1_128_hex").value;
										get_by_id("wlan0_wep128_key_2").value = get_by_id("key2_128_hex").value;
										get_by_id("wlan0_wep128_key_3").value = get_by_id("key3_128_hex").value;
										get_by_id("wlan0_wep128_key_4").value = get_by_id("key4_128_hex").value;
								}
						}else if(get_by_id("KeyType").selectedIndex == 1){
								if(get_by_id("KeySize").selectedIndex == 0){			
										get_by_id("wlan0_wep64_key_1").value = get_by_id("key1_64_ascii").value;
										get_by_id("wlan0_wep64_key_2").value = get_by_id("key2_64_ascii").value;
										get_by_id("wlan0_wep64_key_3").value = get_by_id("key3_64_ascii").value;
										get_by_id("wlan0_wep64_key_4").value = get_by_id("key4_64_ascii").value;
								}else if(get_by_id("KeySize").selectedIndex == 1){			
										get_by_id("wlan0_wep128_key_1").value = get_by_id("key1_128_ascii").value;
										get_by_id("wlan0_wep128_key_2").value = get_by_id("key2_128_ascii").value;
										get_by_id("wlan0_wep128_key_3").value = get_by_id("key3_128_ascii").value;
										get_by_id("wlan0_wep128_key_4").value = get_by_id("key4_128_ascii").value;
								}
						}
				}
		}

	function CheckIP(textValue)
	{
		var i,j=0;
		for(i=0;i<textValue.length;i++)
		{
			ch=textValue.charAt(i);
			if(ch==".")
				j++;
		}
		if(j!=3)
			return false;       // the number of '.' must be three
	
		ipSplit=textValue.split('.');
	
		if(ipSplit.length!=4) return false;   //// the number of ipSplit must be four
	
		for(i=0; i<ipSplit.length; i++)
		{
			if(isNaN(ipSplit[i]) || ipSplit[i]==null || ipSplit[i]==""|| ipSplit[i]==" ")
				return false;
		} //check if ipSplit[i] is invaild number
	
		for(i=0; i<ipSplit.length; i++)
		{
			if(ipSplit[i]>255)  return false; // case 11
		}
		if(ipSplit[0]==0 && ipSplit[1]==0 && ipSplit[2]==0 && ipSplit[3]==0)  return false; // case 12
		if(ipSplit[0]==11 && ipSplit[1]==0 && ipSplit[2]==0 && ipSplit[3]==0)  return false; // case 13
		if(ipSplit[0]==11 && ipSplit[1]==127 && ipSplit[2]==255 && ipSplit[3]==255)  return false; // case 14
		if(ipSplit[0]==11 && ipSplit[1]==255 && ipSplit[2]==255 && ipSplit[3]==255)  return false; // case 15
	
		if(ipSplit[0]==127) return false;  //case 1
		if(ipSplit[0]>=224 && ipSplit[0]<=255) return false; //case 2
	
		if(ipSplit[0]==128 && ipSplit[1]==0) return false;   //case 3
		if(ipSplit[0]==191 && ipSplit[1]==255) return false;  // case 4
		if(ipSplit[0]==0 || ipSplit[3]==0) return false; // case 16,17  papa add 2004.12.14
	
		if(ipSplit[3]==255 || ipSplit[3]==0)
		{
			if(ipSplit[0]>=192 && ipSplit[0]<=255) return false;  //case 7, 10
	
			if(ipSplit[2]==255 || ipSplit[2]==0)
			{
				if(ipSplit[0]>=128 && ipSplit[0]<=191) return false; //case 6, 9
	
				if(ipSplit[1]==255 || ipSplit[1]==0)
				if(ipSplit[0]>=64 && ipSplit[0]<=127) return false; //case 5, 8
			}
	
		}
	
		return true;
	}
	
	function hex_to_a(inValue)
	{
		outValue = "";
		var k = '';
		for (j = 0; j < inValue.length; j++) {
			l = j % 2;
			if (l == 0)
				k += "%";
			k += inValue.substr(j, 1);
		}
		outValue = unescape(k);
		return outValue;
	}
	
	function a_to_hex(inValue) {
		var outValue = "";
		if (inValue) {
			for (j = 0; j < inValue.length; j++) {
				if(inValue.charCodeAt(j).toString(16) < 10)
					outValue += 0;
				if(inValue.charCodeAt(j).toString(16) > 'a' && inValue.charCodeAt(j).toString(16) <= 'f')
					if(inValue.charCodeAt(j).toString(16).length == 1)
						outValue += 0;
				outValue += inValue.charCodeAt(j).toString(16);
			}
		}
		return outValue;
	}

	function ReplaceAll(strOrg,strFind,strReplace){
		var index = 0;
		while(strOrg.indexOf(strFind,index) != -1){
				strOrg = strOrg.replace(strFind,strReplace);
				index = strOrg.indexOf(strFind,index);
		}
		return strOrg
	}
	
	function resetMaxWindowsSize(){
		top.ifrMain.width="680";
		top.service_tree.width="0";
	}
	
	function restoreWindowsSize(){
		top.ifrMain.width="585";
		top.service_tree.width="165";
	}
