function genHeaderTable(titleName){  
    document.write("<table border=0 cellspacing=0><tr><td width=10 height=5></td><td></td></tr>");
    document.write("<tr><td></td><td>");
    document.write("<table id=tabBigFrame class=tabBigFrame><tr><td align=center>");
    document.write("<table id=tabBigTitle class=tabBigTitle cellspacing=0 >");
    document.write("    <tr><td class=tdBigTitle valign=middle >&nbsp;&nbsp;&nbsp;" + titleName + "</td></tr>");
    document.write("    <tr><td valign=top><table width=100% class=tabTopLine cellspacing=0><tr><td>");
}

function genHeaderTableEnd()
{
	document.write("		</td></tr></table>");	
	document.write("	</td></tr></table>");	
	document.write("</td></tr></table>");
	document.write("</td></tr></table>");
}


function genSubTableStart(titleName){
    document.write("<table id=tabSubConfig class=tabSubConfig cellspacing=0>");
    document.write("    <tr><td class=tdSubTitle valign=top>&nbsp;&nbsp;&nbsp;<font style='position: relative; top:1;'>" + titleName + "</font></td></tr>");
    document.write("    <tr><td align=center>");
}

function genSubTableEnd()
{
    document.write("    </td></tr)");
    document.write("</table>");
}

function chgCursor(targetName)
{
	if(navigator.appName =="Microsoft Internet Explorer")
		targetName.style.cursor = "hand";
	else
    	targetName.style.cursor = "pointer";

}
