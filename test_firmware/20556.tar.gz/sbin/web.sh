# reload web server alphapd
killall -q alphapd
alphapd &

