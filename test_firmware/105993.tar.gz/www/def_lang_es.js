//Version=1.01b01
//Language=SPANISH
//Date=Tue, 24, Feb, 2015
//Merged=FALSE
//Merged Fw=FALSE
var msg = new Array ( //
	"La dirección IP introducida no es válida.", //INVALID_IP_ADDRESS
	"La dirección IP no puede ser cero.", //ZERO_IP_ADDRESS
	"Dirección IP", //IP_ADDRESS_DESC
	"La máscara de subred introducida no es válida.", //INVALID_MASK_ADDRESS
	"La máscara de subred no puede ser cero.", //ZERO_MASK_ADDRESS
	"SuMáscara de subred", //MASK_ADDRESS_DESC
	"La dirección IP de puerta de enlace introducida no es válida", //INVALID_GATEWAY_ADDRESS
	"La dirección IP de puerta de enlace no puede ser cero", //ZERO_GATEWAY_ADDRESS
	"Dirección IP de puerta de enlace", //GATEWAY_ADDRESS_DESC
	"%s La dirección IP de puerta de enlace %s debe estar dentro de la subred WAN.,", //NOT_SAME_DOMAIN
	"La dirección IP de inicio introducida no es válida (rango de IP: 1~254)", //INVALID_START_IP
	"Introduzca otro servidor SMTP o dirección IP", //SMTP_SERVER_ERROR
	"Dirección IP de inicio", //START_IP_DESC
	"La dirección IP de LAN y la dirección IP de inicio no están en la misma subred,", //START_INVALID_DOMAIN
	"La dirección IP final introducida no es válida.", //INVALID_END_IP
	"Introduzca otro dominio", //DOMAIN_ERROR
	"La dirección IP de LAN y la dirección IP final no están en la misma subred,", //END_INVALID_DOMAIN
	"La dirección DNS primaria introducida no es válida.", //INVALID_DNS_ADDRESS
	"La dirección DNS primaria no puede ser cero", //ZERO_DNS_ADDRESS
	"Dirección del DNS primario", //DNS_ADDRESS_DESC
	"El campo SSID no puede estar vacío.", //SSID_EMPTY_ERROR
	"No se puede desactivar la WEP cuando el tipo de autenticación está establecido en Clave compartida", //AUTH_TYPE_ERROR
	"La frase secreta debe tener una longitud mínima de 8 caracteres", //PSK_LENGTH_ERROR
	"La frase secreta confirmada no coincide con la frase secreta.", //PSK_MATCH_ERROR
	"La contraseña confirmada no coincide con la nueva contraseña.", //MATCH_PWD_ERROR
	"El campo de la clave WEP seleccionada no puede estar en blanco", //WEP_KEY_EMPTY
	"Introduzca otra dirección IP", //ZERO_STATIC_DHCP_IP
	"¿Desea salir del asistente de configuración y descartar los parámetros?", //QUIT_WIZARD
	"La dirección MAC introducida no es válida.", //MAC_ADDRESS_ERROR
	"La dirección IP final debe ser superior a la dirección IP de inicio,", //IP_RANGE_ERROR
	"La dirección DNS secundaria introducida no es válida.", //INVALID_SEC_DNS_ADDRESS
	"La dirección DNS secundaria no puede ser cero o estar en blanco.", //ZERO_SEC_DNS_ADDRESS
	"Dirección del DNS secundario", //SEC_DNS_ADDRESS_DESC
	"La contraseña confirmada no coincide con la nueva contraseña de administrador.", //ADMIN_PASS_ERROR
	"La contraseña confirmada no coincide con la nueva contraseña de usuario.", //USER_PASS_ERROR
	"El nombre de host no es válido.", //DDNS_HOST_ERROR
	"Introduzca otra dirección IP de inicio", //ZERO_START_IP
	"¿Está seguro de que desea reiniciar el dispositivo en los parámetros predeterminados de fábrica?\nEsta acción causará la pérdida de todos los parámetros actuales.", //RESTORE_DEFAULT
	"¿Está seguro de que desea reiniciar el dispositivo?\nEl reinicio desconectará todas las sesiones de Internet activas.", //REBOOT_ROUTER
	"¿Cargar parámetros desde un archivo de configuración guardado?", //LOAD_SETTING
	"Debe introducir primero el nombre de un archivo de configuración.", //LOAD_FILE_ERROR
	"Introduzca como mínimo un dominio de control.", //CONTROL_DOMAIN_ERROR
	"Introduzca otro nombre de servidor", //DDNS_SERVER_ERROR
	"¿Está seguro de que desea eliminar esta regla de servidor virtual?", //DEL_SERVER_MSG
	"¿Está seguro de que desea eliminar esta regla de aplicación?", //DEL_APPLICATION_MSG
	"¿Está seguro de que desea eliminar este filtro?", //DEL_FILTER_MSG
	"¿Está seguro de que desea eliminar esta ruta?", //DEL_ROUTE_MSG
	"¿Está seguro de que desea eliminar esta dirección MAC?", //DEL_MAC_MSG
	"¿Está seguro de que desea eliminar esta palabra clave?", //DEL_KEYWORD_MSG
	"¿Está seguro de que desea eliminar este dominio?", //DEL_DOMAIN_MSG
	"¿Está seguro de que desea eliminar esta entrada?", //DEL_ENTRY_MSG
	"¿Está seguro de que desea eliminar esta reserva DHCP?", //DEL_STATIC_DHCP_MSG
	"Introduzca otro número de puerto", //PORT_ERROR
	"Introduzca otro dominio permitido", //PERMIT_DOMAIN_ERROR
	"Seleccione un archivo de firmware para actualizar el router a", //FIRMWARE_UPGRADE_ERROR
	"La palabra clave introducida ya existe en la lista", //SAME_KEYWORD_ERROR
	"Introduzca otra clave", //WIZARD_KEY_EMPTY
	"No se puede añadir otra palabra clave", //ADD_KEYWORD_ERROR
	"Seleccione antes un equipo.", //SELECT_MACHINE_ERROR
	"El dominio introducido ya existe en la lista de dominios bloqueados", //SAME_BLOCK_DOMAIN
	"No se puede añadir otro dominio bloqueado", //ADD_BLOCK_DOMAIN_ERROR
	"El dominio introducido ya existe en la lista de dominios permitidos", //SAME_PERMIT_DOMAIN
	"Introduzca otra contraseña", //DDNS_PASS_ERROR
	"No se puede añadir otro dominio permitido", //ADD_PERMIT_DOMAIN_ERROR
	"Introduzca otro dominio bloqueado", //BLOCK_DOMAIN_ERROR
	"No se puede añadir otro dominio de control", //ADD_CONTROL_DOMAIN_ERROR
	"Introduzca otra contraseña de seguridad inalámbrica", //SECURITY_PWD_ERROR
	"La dirección IP del servidor RADIUS 1 introducida no es válida.", //INVALID_RADIUS_SERVER1_IP
	"La dirección IP del servidor Radius 1 no puede ser cero o estar en blanco", //ZERO_RADIUS_SERVER1_IP
	"Dirección IP del servidor Radius 1", //RADIUS_SERVER1_IP_DESC
	"La dirección IP del servidor RADIUS 2 introducida no es válida.", //INVALID_RADIUS_SERVER2_IP
	"La dirección IP del servidor Radius 2 no puede ser cero o estar en blanco", //ZERO_RADIUS_SERVER2_IP
	"Dirección IP del servidor Radius 2", //RADIUS_SERVER2_IP_DESC
	"La dirección IP introducida no es válida (rango de IP: 1~254)", //INVALID_STATIC_DHCP_IP
	"Introduzca otra dirección IP final", //ZERO_END_IP
	"Introduzca otro nombre,", //NAME_ERROR
	"La dirección IP de servidor introducida no es válida", //INVALID_SERVER_IP
	"La dirección IP del servidor no puede ser cero o estar en blanco.", //ZERO_SERVER_IP
	"Dirección IP del servidor", //SERVER_IP_DESC
	"Las contraseñas introducidas no coinciden", //MATCH_WIZARD_PWD_ERROR
	"La dirección IP de inicio de origen introducida no es válida", //INVALID_SOURCE_START_IP
	"La dirección IP de inicio de origen no puede ser cero o estar en blanco", //ZERO_SOURCE_START_IP
	"Dirección IP de inicio de origen", //SOURCE_START_IP_DESC
	"La dirección IP final de origen introducida no es válida", //INVALID_SOURCE_END_IP
	"La dirección IP final de origen no puede ser cero o estar en blanco", //ZERO_SOURCE_END_IP
	"Dirección IP final de origen", //SOURCE_END_IP_DESC
	"La dirección IP de inicio de destino introducida no es válida", //INVALID_DEST_START_IP
	"La dirección IP de inicio de destino no puede ser cero o estar en blanco", //ZERO_DEST_START_IP
	"Dirección IP de inicio de destino", //DEST_START_IP_DESC
	"La dirección IP final de destino introducida no es válida", //INVALID_DEST_END_IP
	"La dirección IP final de destino no puede ser cero o estar en blanco", //ZERO_DEST_END_IP
	"Dirección IP final de destino", //DEST_END_IP_DESC
	"La frase secreta debe tener una longitud de entre 8 y 63 caracteres", //PSK_OVER_LEN
	"¿Reiniciar JumpStart?", //RESET_JUMPSTAR
	"¿Está seguro de que desea eliminar esta regla?", //DEL_RULE_MSG
	"¿Está seguro de que desea eliminar este programa?", //DEL_SCHEDULE_MSG
	"No se puede añadir otro programa", //ADD_SCHEDULE_ERROR
	"El nombre del programa no puede estar vacío", //SCHEDULE_NAME_ERROR
	"El nombre del programa no permite introducir todo espacios", //SCHEDULE_NAME_SPACE_ERROR
	"La hora de inicio introducida no es válida.", //START_TIME_ERROR
	"La hora final introducida no es válida.", //END_TIME_ERROR
	"La hora de inicio no puede ser posterior a la hora final", //TIME_RANGE_ERROR
	"Seleccione una palabra clave para eliminar", //DEL_KEYWORD_ERROR
	"Seleccione una dominio permitido para eliminar", //DEL_PERMIT_DOMAIN_ERROR
	"Seleccione una dominio bloqueado para eliminar", //DEL_BLOCK_DOMAIN_ERROR
	"La regla de control paterno ya está en la lista.", //DUPLICATE_URL_ERROR
	"Error de nombre de inicio de sesión", //LOGIN_NAME_ERROR
	"Error de contraseña de inicio de sesión", //LOGIN_PASS_ERROR
	"%s está en conflicto con la dirección IP de LAN; introdúzcalo de nuevo.", //THE_SAME_LAN_IP
	"La PSK debe ser hexadecimal.", //THE_PSK_IS_HEX
	"La dirección IP y la dirección IP de reserva no están en la misma subred.", //SER_NOT_SAME_DOMAIN
	"Hay datos sin guardar en esta página. ¿Desea abandonarla?%s Si no es así, pulse Cancelar y, a continuación, Guardar parámetros.%s Si es así, pulse Aceptar.", //IS_CHANGE_DATA
	"La contraseña confirmada no coincide con la nueva contraseña de usuario.", //DDNS_PASS_ERROR_MARTH
	"El nombre de la regla no puede ser una cadena vacía", //INBOUND_NAME_ERROR
	"El número de puerto final debe ser superior al número de puerto de inicio", //PORT_RANGE_ERROR
	"¿Está seguro de que desea activar/desactivar?", //CHECK_ENABLE
	"¿Está seguro que quiere eliminarlo?", //DEL_MSG
	"Debe omitir todos los cambios realizados para definir un nuevo programa.\n Pulse “Aceptar” para omitir los cambios y mostrar la página Programa.\n En caso contrario, pulse “Cancelar”.", //GO_SCHEDULE
	"Introduzca el nombre de usuario.", //PPP_USERNAME_EMPTY
	"No se ha cambiado nada, ¿desea guardar?", //FORM_MODIFIED_CHECK
	"Seleccione antes un nombre de aplicación", //SELECT_APPLICATION_ERROR
	"Seleccione antes un nombre de ordenador", //SELECT_COMPUTER_ERROR
	"Introduzca otro nombre", //STATIC_DHCP_NAME
	"Seleccione una dominio de control para eliminar", //DEL_CONTROL_DOMAIN_ERROR
	"Introduzca otra palabra clave", //KEYWORD_ERROR
	"Introduzca una dirección IP privada.", //PRIVATE_IP_ERROR
	"Introduzca un número de puerto de cortafuegos", //PUBLIC_PORT_ERROR
	"Introduzca un número de puerto de activación", //TRIGGER_PORT_ERROR
	"Introduzca una dirección de correo electrónico válida", //EMAIL_ADDRESS_ERROR
	"Introduzca un nombre de host o una dirección IP", //PING_IP_ERROR
	"Sólo la cuenta de administrador puede descargar los parámetros", //DOWNLOAD_SETTING_ERROR
	"Introduzca otro nombre de usuario", //DDNS_USER_ERROR
	"Dirección IP final", //END_IP_DESC
	"" //MAX
);
var INVALID_IP_ADDRESS=0;
var ZERO_IP_ADDRESS=1;
var IP_ADDRESS_DESC=2;
var INVALID_MASK_ADDRESS=3;
var ZERO_MASK_ADDRESS=4;
var MASK_ADDRESS_DESC=5;
var INVALID_GATEWAY_ADDRESS=6;
var ZERO_GATEWAY_ADDRESS=7;
var GATEWAY_ADDRESS_DESC=8;
var NOT_SAME_DOMAIN=9;
var INVALID_START_IP=10;
var SMTP_SERVER_ERROR=11;
var START_IP_DESC=12;
var START_INVALID_DOMAIN=13;
var INVALID_END_IP=14;
var DOMAIN_ERROR=15;
var END_INVALID_DOMAIN=16;
var INVALID_DNS_ADDRESS=17;
var ZERO_DNS_ADDRESS=18;
var DNS_ADDRESS_DESC=19;
var SSID_EMPTY_ERROR=20;
var AUTH_TYPE_ERROR=21;
var PSK_LENGTH_ERROR=22;
var PSK_MATCH_ERROR=23;
var MATCH_PWD_ERROR=24;
var WEP_KEY_EMPTY=25;
var ZERO_STATIC_DHCP_IP=26;
var QUIT_WIZARD=27;
var MAC_ADDRESS_ERROR=28;
var IP_RANGE_ERROR=29;
var INVALID_SEC_DNS_ADDRESS=30;
var ZERO_SEC_DNS_ADDRESS=31;
var SEC_DNS_ADDRESS_DESC=32;
var ADMIN_PASS_ERROR=33;
var USER_PASS_ERROR=34;
var DDNS_HOST_ERROR=35;
var ZERO_START_IP=36;
var RESTORE_DEFAULT=37;
var REBOOT_ROUTER=38;
var LOAD_SETTING=39;
var LOAD_FILE_ERROR=40;
var CONTROL_DOMAIN_ERROR=41;
var DDNS_SERVER_ERROR=42;
var DEL_SERVER_MSG=43;
var DEL_APPLICATION_MSG=44;
var DEL_FILTER_MSG=45;
var DEL_ROUTE_MSG=46;
var DEL_MAC_MSG=47;
var DEL_KEYWORD_MSG=48;
var DEL_DOMAIN_MSG=49;
var DEL_ENTRY_MSG=50;
var DEL_STATIC_DHCP_MSG=51;
var PORT_ERROR=52;
var PERMIT_DOMAIN_ERROR=53;
var FIRMWARE_UPGRADE_ERROR=54;
var SAME_KEYWORD_ERROR=55;
var WIZARD_KEY_EMPTY=56;
var ADD_KEYWORD_ERROR=57;
var SELECT_MACHINE_ERROR=58;
var SAME_BLOCK_DOMAIN=59;
var ADD_BLOCK_DOMAIN_ERROR=60;
var SAME_PERMIT_DOMAIN=61;
var DDNS_PASS_ERROR=62;
var ADD_PERMIT_DOMAIN_ERROR=63;
var BLOCK_DOMAIN_ERROR=64;
var ADD_CONTROL_DOMAIN_ERROR=65;
var SECURITY_PWD_ERROR=66;
var INVALID_RADIUS_SERVER1_IP=67;
var ZERO_RADIUS_SERVER1_IP=68;
var RADIUS_SERVER1_IP_DESC=69;
var INVALID_RADIUS_SERVER2_IP=70;
var ZERO_RADIUS_SERVER2_IP=71;
var RADIUS_SERVER2_IP_DESC=72;
var INVALID_STATIC_DHCP_IP=73;
var ZERO_END_IP=74;
var NAME_ERROR=75;
var INVALID_SERVER_IP=76;
var ZERO_SERVER_IP=77;
var SERVER_IP_DESC=78;
var MATCH_WIZARD_PWD_ERROR=79;
var INVALID_SOURCE_START_IP=80;
var ZERO_SOURCE_START_IP=81;
var SOURCE_START_IP_DESC=82;
var INVALID_SOURCE_END_IP=83;
var ZERO_SOURCE_END_IP=84;
var SOURCE_END_IP_DESC=85;
var INVALID_DEST_START_IP=86;
var ZERO_DEST_START_IP=87;
var DEST_START_IP_DESC=88;
var INVALID_DEST_END_IP=89;
var ZERO_DEST_END_IP=90;
var DEST_END_IP_DESC=91;
var PSK_OVER_LEN=92;
var RESET_JUMPSTAR=93;
var DEL_RULE_MSG=94;
var DEL_SCHEDULE_MSG=95;
var ADD_SCHEDULE_ERROR=96;
var SCHEDULE_NAME_ERROR=97;
var SCHEDULE_NAME_SPACE_ERROR=98;
var START_TIME_ERROR=99;
var END_TIME_ERROR=100;
var TIME_RANGE_ERROR=101;
var DEL_KEYWORD_ERROR=102;
var DEL_PERMIT_DOMAIN_ERROR=103;
var DEL_BLOCK_DOMAIN_ERROR=104;
var DUPLICATE_URL_ERROR=105;
var LOGIN_NAME_ERROR=106;
var LOGIN_PASS_ERROR=107;
var THE_SAME_LAN_IP=108;
var THE_PSK_IS_HEX=109;
var SER_NOT_SAME_DOMAIN=110;
var IS_CHANGE_DATA=111;
var DDNS_PASS_ERROR_MARTH=112;
var INBOUND_NAME_ERROR=113;
var PORT_RANGE_ERROR=114;
var CHECK_ENABLE=115;
var DEL_MSG=116;
var GO_SCHEDULE=117;
var PPP_USERNAME_EMPTY=118;
var FORM_MODIFIED_CHECK=119;
var SELECT_APPLICATION_ERROR=120;
var SELECT_COMPUTER_ERROR=121;
var STATIC_DHCP_NAME=122;
var DEL_CONTROL_DOMAIN_ERROR=123;
var KEYWORD_ERROR=124;
var PRIVATE_IP_ERROR=125;
var PUBLIC_PORT_ERROR=126;
var TRIGGER_PORT_ERROR=127;
var EMAIL_ADDRESS_ERROR=128;
var PING_IP_ERROR=129;
var DOWNLOAD_SETTING_ERROR=130;
var DDNS_USER_ERROR=131;
var END_IP_DESC=132;

var which_lang = new Array ( //
	"Cuando está activada la característica, el tráfico en Internet estará protegido mediante un servidor de seguridad preparado para DNS. Esta característica proporciona \"antiphishing\" para proteger la conexión a Internet frente a fraudes, además de mejoras en la navegación, tal como la corrección automática de errores de escritura habituales en direcciones URL.", //_Advanced_01
	"Aunque esté activada la característica DNS avanzado, la dirección IP de DNS de la estación de trabajo se podrá seguir modificando a la IP del servidor DNS que desee. Tenga en cuenta que el router no dicta la resolución de nombre DNS cuando la dirección IP de DNS se configura en la estación de trabajo.", //_Advanced_03
	"Si ha seleccionado esta opción y tiene configuración de VPN o Intranet en la red, puede desactivar el servicio de DNS avanzado si tiene problemas con la conexión.", //_Advanced_04
	"Servicio DNS avanzado", //bwn_ict_dns
	"DNS avanzado es una opción de seguridad gratuita que proporciona \"antiphishing\" para proteger contra fraudes su conexión a Internet, así como mejoras en la navegación, como la corrección automática de errores de escritura habituales en la URL.", //bwn_msg_Modes_dns
	"Habilitar control de acceso", //aa_EAC
	"Mi tipo de USB es", //new_bwn_mici_usb
	"No puede elegir TKIP cuando está en Sólo 802.11n", //_tkip_11n
	"SharePort para la zona de invitados", //bln_title_guest_use_shareport
	"Acti", //IPV6_TEXT3
	"Mezcla de 802.11n y 802.11g", //bwl_Mode_10
	"Introduzca la información de la dirección AFTR suministrada por su proveedor de servicios de Internet (ISP).", //IPV6_TEXT148
	"Regenerar", //_regenerate
	"Introduzca los parámetros siguientes en el dispositivo inalámbrico que está añadiendo a la red inalámbrica y tome nota de ello para futuras consultas.", //TEXT048
	"Habilitar notificación de correo electrónico", //te_EnEmN
	"Parámetros para USB 3,5 G", //usb3g_titile
	"Nombre de APN", //usb3g_apn_name
	"Marcar número", //usb3g_dial_num
	"Modo de reconexión (0:siempre/1:A petición/2:Manual)", //usb3g_reconnect_mode
	"Tiempo de inactividad", //usb3g_max_idle_time
	"DISPOSITIVO USB (0:Módem 3G/1:CÓDIGO K)", //usb_device
	"Manual para USB 3,5 G", //usb3g_manual
	"Estadísticas para USB 3,5 G", //usb3g_stat_titile
	"Parámetros para USB", //bln_title_usb
	"Configuración de WCN", //usb_wcn
	"Utilice esta sección para configurar su puerto USB. Existen varias configuraciones entre las que elegir: USB de red, adaptador para USB 3G y configuración WCN.", //bwn_intro_usb
	"USB de red", //usb_network
	"Adaptador para USB 3G", //usb_3g
	"Marcar número", //wwan_dial_num
	"Tipo de conexión a Internet WWAN", //bwn_wwanICT
	"Escriba la dirección de correo electrónico a la que desea enviar el mensaje.", //help862
	"Protocolo de autenticación", //wwan_auth_label
	"Automático (PAP+CHAP)", //wwan_auth_auto
	"Excedido tiempo de espera de autenticación PAP – la autenticación ha fallado.", //IPPPPPAP_AUTH_ISSUE
	"Sólo CHAP", //wwan_auth_chap
	"Sólo MS CHAP", //wwan_auth_mschap
	"Selecciónelo para compartir una impresora, escáner o dispositivo de almacenamiento USB conectado al puerto USB de la parte posterior del router con", //usb_network_help
	"Seleccione Adaptador para USB 3G para utilizar un adaptador 3G para dar acceso a Internet utilizando una señal celular EV-DO. Simplemente conecte un adaptador para USB 3G para conectar a Internet (necesita suscripción y señal disponible EV-DO de terceros).", //usb_3g_help
	"Si tiene problemas para acceder a Internet a través del router. Compruebe de nuevo los parámetros que ha introducido en esta página y verifíquelos con su proveedor de servicios de Internet (ISP), si es necesario.", //usb_3g_help_support_help
	"Selecciónelo para configurar su red inalámbrica utilizando Windows Connect Now (WCN). WCN le permite copiar sus parámetros inalámbricos desde el router a una unidad flash USB y utilizarlos para configurar automáticamente los parámetros inalámbricos en sus ordenadores o en otros dispositivos compatibles con WCN.", //usb_wcn_help
	"Mi enchufe de tipo USB es", //bwn_mici_usb
	"Configure el intervalo de tiempo de detección de USB de red, el router detectará automáticamente el dispositivo USB.", //_info_netowrk
	"Activar secuencias de multidifusión", //anet_multicast_enable
	"Intervalo de detección de USB de red", //bwn_usb_time
	"segundos (rango: de 3 a 600 segundos)", //bwn_bytes_usb
	"No puede elegir la clave compartida cuando está activado WPS.", //_wps_albert_1
	"No puede elegir la clave WPA-Enterprise cuando está activado WPS.", //_wps_albert_2
	"Configure los parámetros de su tipo de conexión a Internet.  Si no está seguro de los  parámetros, póngase en contacto con su proveedor de servicios de Internet (ISP).", //usb_config2
	"Elija un dispositivo para aplicar la política.", //ac_alert_choose_dev
	"El tipo de conexión a Internet no es para la conexión 3G a Internet.  Seleccione WWAN para admitir la conexión 3G a Internet.", //usb_config3
	"El tipo de conexión a Internet es para la conexión 3G a Internet, seleccione otro tipo de conexión a Internet.", //usb_config4
	"El tipo de conexión a Internet que ha seleccionado es para la conexión 3G a Internet.  Se cambiarán los parámetros USB de USB/WCN de red a Adaptador para USB 3G.", //usb_config5
	"El tipo de conexión a Internet que ha seleccionado no es para la conexión 3G a Internet.  Se cambiarán los parámetros USB de Adaptador para USB 3G a USB de red.", //usb_config6
	"Seleccione el tipo de dispositivo de USB que se tiene que conectar al puerto USB.", //bwn_msg_usb
	"País", //_country
	"Seleccione su país", //_select_country
	"Seleccione su ISP", //_select_ISP
	"Australia", //country_1
	"Italia", //country_2
	"Portugal", //country_3
	"Reino Unido", //country_4
	"Indonesia", //country_5
	"Malasia", //country_6
	"Singapur", //country_7
	"Personales", //_aa_bsecure_personals
	"Sudáfrica", //country_9
	"Hong Kong", //country_10
	"Taiwán", //country_11
	"Egipto", //country_12
	"República Dominicana", //country_13
	"El Salvador", //country_14
	"Brasil", //country_15
	"Seleccione esta opción si desea agregar una red invitada", //S500
	"Tipo de red", //S496
	"Activar acceso remoto a almacenamiento HTTP", //sto_http_2
	"correo electrónico, El botón Enviar correo electrónico está deshabilitado actualmente porque no se ha activado la notificación por correo electrónico en la pantalla <a href='tools_email.asp' onclick='return jump_if();' shape='rect'>Herramientas &rarr; Correo electrónico</a>.", //logs_LW39b_email
	"Utilice HTTPS", //LV3
	"Sistema inalámbrico %s%s con dirección MAC %m asegurada y vinculada", //GW_WIRELESS_DEVICE_LINK_UP
	"Se borraron todas las entradas de registro.", //LT248
	"Descubrimiento de los servidores PPPoE para la sesión PPPoE %s", //GW_PPPOE_EVENT_DISCOVERY_ATTEMPT
	"Banda de frecuencia 5GHz", //GW_WLAN_RADIO_1_NAME
	"Puerto del servidor SMTP", //te_SMTPSv_Port
	"No se puede cambiar el modo 802.11 a Sólo 802.11n mientras exista un SSID con seguridad WEP.", //GW_WLAN_CHANGING_PHY_MODE_TO_11NG_ONLY_INVALID
	"Seleccione su red inalámbrica", //S558
	"Seleccione la radio que desea configurar", //KRL8
	"La selección ayuda a definir la escala de la zona de invitados.", //LY30
	"El servidor virtual '%s' no puede usar el puerto de administración de la WAN HTTPS del router, %u", //GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"La configuración protegida Wi-Fi está desactivada porque la seguridad de SSID '%s' está establecida en WPA-Enterprise.", //GW_WIFISC_DISABLED_AUTOMATICALLY
	"Desactivado", //_off
	"Banda de frecuencia 2,4 GHz", //GW_WLAN_RADIO_0_NAME
	"Error de protocolo de la sesión PPPoE %s. El intento de conexión ha fallado.", //GW_PPPOE_EVENT_DISCOVERY_REQUEST_ERROR
	"El nombre %s de la sesión PPPoE está en conflicto con otro nombre de sesión", //GW_WAN_PPPOE_SESSION_NAME_CONFLICT
	"Problema al recibir los registros La memoria está demasiado baja para mostrar los registros o existe un problema con la conexión.", //S525
	"La contraseña y la confirmación de contraseña no coinciden. Vuelva a confirmar la contraseña de usuario.", //YM174
	"Debe examinar estas advertencias porque pueden haberse desactivado o modificado algunas características.", //KR136
	"Terminación de la ID %u de la sesión PPPoE %s", //GW_PPPOE_EVENT_DISCONNECT
	"Endpoint independente", //af_EFT_0
	"Utilice esta sección para permitir el enrutamiento entre la zona de host y la zona de invitados; los clientes invitados no pueden acceder a los datos de clientes de host si la función no está habilitada.", //LY34
	"Cierre de %s inalámbrico", //GW_WIRELESS_SHUT_DOWN
	"Reinicio de %s inalámbrico", //GW_WIRELESS_RESTART
	"El tiempo de inactividad de administración debe estar dentro del rango de 1 a 65535.", //S528
	"El direccionamiento de puertoss ALG no logró asignar la sesión para los paquetes TCP de %v:%u a %v:%u", //GW_PORT_FORWARD_TCP_PACKET_ALLOC_FAILURE
	"Utilice esta sección para configurar los parámetros de la zona de invitados del router. La zona de invitados ofrece una zona de red separada para que el invitado acceda a Internet.", //guestzone_Intro_1
	"El servidor virtual '%s' no puede usar el puerto de administración de la WAN HTTPS del router, %u", //GW_NAT_VIRTUAL_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"Activar gestión remota", //ta_ERM
	"El puerto debe estar en rango (de 1 a 65535)", //te_SMTPSv_Port_alert
	"%sError al iniciar la función inalámbrica", //GW_WIRELESS_DEVICE_START_FAILED
	"El direccionamiento de puertoss ALG no logró asignar la sesión para los paquetes UDP de %v:%u a %v:%u", //GW_PORT_FORWARD_UDP_PACKET_ALLOC_FAILURE
	"%sDesconectar todas las estaciones", //GW_WIRELESS_DEVICE_DISCONNECT_ALL
	"Emisión de solicitud de oferta para la sesión PPPoE %s", //GW_PPPOE_EVENT_OFFER_REQUEST
	"La IP %v del router debe ser una dirección de host válida", //GW_ROUTES_ROUTERS_IP_ADDRESS_INVALID
	"La activación del puerto ALG no logró asignar la sesión para los paquetes UDP de %v:%u a %v:%u", //GW_PORT_TRIGGER_UDP_PACKET_ALLOC_FAILURE
	"No se puede establecer la seguridad WEP para un SSID mientras el modo 802.11 está en sólo 802.11n.", //GW_WLAN_SETTING_SSID_SECURITY_TO_WEP_INVALID
	"El servidor virtual '%s' no puede usar el puerto de administración de la WAN HTTP del router, %u", //GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT
	"Tiempo de espera, estación izquierda", //GW_WLAN_STATION_TIMEOUT
	"El servidor virtual '%s' no puede usar la dirección IP del router, %v.", //GW_NAT_VIRTUAL_SERVER_IP_ADDRESS_CAN_NOT_MATCH_ROUTER
	"%s' [protocolo:%u]->%v está en conflicto con '%s' [protocolo:%u]->%v.", //GW_NAT_VIRTUAL_SERVER_PROTO_CONFLICT_INVALID
	"Especifica si la zona de invitados estará habilitada o deshabilitada.", //LY28
	"Intentando establecer la conexión de PPPoE %s", //GW_PPPOE_EVENT_CONNECT
	"Puerto trigger", //GW_NAT_TRIGGER_PORT
	"modo de funcionamiento", //tc_opmode
	"Asignar automáticamente una clave de red para las bandas de frecuencia de 2.4 GHz y 5 GHz (recomendado)", //wwz_auto_assign_key3
	"Suministre un nombre para la red inalámbrica de la zona de invitados.", //LY292
	"Es importante hacer más segura su red inalámbrica ya que se utiliza para proteger la integridad de la información que se transmite a través de la red inalámbrica. El router admite 4 tipos de seguridad inalámbrica; WEP, Sólo WPA, Sólo WPA2 y WPA/WPA2 (detección automática).", //LY293
	"Si elige la opción de seguridad WEP, este dispositivo  <strong>SOLO</strong> funcionará en <strong>modo inalámbrico antiguo (802.11B/G)</strong>. Esto significa que <strong>NO</strong> obtendrá el rendimiento 11N puesto que la especificación draft 11N no admite WEP.", //bws_msg_WEP_4
	"Puede que esté creada la ruta para %v en la interfaz %s: en esta interfaz, sólo se pueden crear rutas a través de puertas de enlace", //GW_ROUTES_ON_LINK_DATALINK_CHECK_INVALID
	"Parámetros de DNS", //wwa_dnsset
	"Este asistente está diseñado para ayudarle a conectar su dispositivo inalámbrico invitado a su router inalámbrico. Le guiará a través de instrucciones paso a paso para mostrarle cómo conectar su dispositivo inalámbrico invitado. Haga clic en el botón siguiente para comenzar.", //wireless_gu
	"Añadir dispositivo inalámbrico invitado con WPS", //add_gu_wps
	"Banda de Frecuencia inalámbrica", //wwl_band
	"Banda de Frecuencia", //_band
	"Establecer manualmente el nombre de la red de la banda 5 GHz", //wwa_5G_nname
	"ZONA DE INVITADOS", //_guestzone
	"Selección de zona de invitados", //guestzone_title_1
	"Activar autenticación gráfica", //_graph_auth
	"Incluir red inalámbrica", //guestzone_inclw
	"Invitado", //guest
	"inferior a la red inalámbrica", //lower_wnt
	"igual a la red inalámbrica", //equal_wnt
	"inferior", //_lowest
	"Lista de SSID", //ssid_lst
	"SSID múltiple", //mult_ssid
	"Añadir/Editar SSID", //add_ed_ssid
	"Active o desactive las reglas definidas con las casillas de verificación de la izquierda.", //help75a
	"Filtro de respuesta a ping en el interfaz WAN", //wpin_filter
	"El protocolo de impresión por puerto TCP usa una dirección IP fija y el puerto TCP para comunicarse con la impresora.", //tps_raw1
	"(GMT+06:30) Rangún", //up_tz_52
	"La dirección IP de destino es la misma", //_r_alert_new1
	"Parámetros de correo electrónico", //te_EmSt
	"Bloquedo el paquete saliente de %v a %v (Protocolo de IP %u)", //IPNAT_BLOCKED_EGRESS
	"Modo de seguridad inalámbrica", //bws_WSMode
	"Enviar pings a direcciones IP WAN públicas es un método habitualmente usado por los hackers para probar si su dirección IP WAN es válida.", //anet_wan_ping_1
	"Asígnele a la regla un nombre que sea significativo para usted, por ejemplo <code>Servidor de juegos</code>. También puede escoger de una lista de juegos populares, y deberá rellenar", //help65
	"UPNP", //ta_upnp
	"Velocidad de transmisión", //bwl_TxR
	"Se ha completado la medición de la velocidad de la interfaz WAN", //GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED
	"Tiempo medio de ping (en milisegundos)", //tsc_pingt_msg106
	"Todo el día", //tsc_AllDay
	"Tiger Woods 2K4", //gw_gm_53
	"No se ha iniciado la medición de la interfaz WAN porque faltan recursos", //GW_WAN_RATE_ESTIMATOR_RESOURCE_ERROR
	"Perdida concesión en dirección IP", //DHCP_CLIENT_LOST_LEASE
	"Seleccione la programación temporal que desee aplicar a esta directiva.", //_aa_wiz_s3_msg
	"Tiempo de espera para la autentificación", //bwsAT_
	"La exactitud horaria es importante para la precisión de los registros y las reglas de firewall programadas.", //hhtt_intro
	"Final Fantasy XI (PC)", //gw_gm_20
	"La dirección IP del servidor de autenticación.", //help388
	"Establecer la fecha y la hora manualmente", //tt_StDT
	"Sin conexión", //psOffline
	"Estado", //_status
	"En caso contrario, pulse 'Cancelar'.", //up_ae_wic_3
	"Qué visualizar", //sl_WtV
	"Se ha solicitado STA con MAC (%m) para el registro WPS", //WIFISC_AP_PROXY_PROCESS_START
	"El asistente para instalación no ha podido comunicarse con la impresora.", //wprn_nopr2
	"Cuando está buscando redes inalámbricas disponibles, este es el nombre que aparecerá en la lista (a menos que el estatus de visibilidad esté establecido como invisible, vea más abajo). Este nombre también se conoce como SSID. A efectos de seguridad, se recomienda cambiar el nombre de red preconfigurado.", //help352
	"Nombre de red (SSID)", //wwz_wwl_wnn
	"Dirección IP", //_ipaddr
	"iniciar gw_wireless_schedule", //GW_WLS_SCHEDULE_START
	"Dirección de inicio de la conversación", //help820
	"Si todos los ordenadores de la LAN obtienen correctamente sus direcciones IP del servidor DHCP del router, esta opción puede permanecer deshabilitada. Sin embargo, si una de los ordenadores de la LAN no logra obtener una dirección IP del servidor DHCP del router, es posible que un cliente DHCP anterior haya desactivado incorrectamente el flag de transmisión de paquetes DHCP. Al habilitar esta opción, el router siempre transmitirá sus respuestas a todos los clientes, lo que supondrá que el tráfico de la LAN se vea incrementado.", //help326
	"(GMT+08:00) Krasnoyarsk", //up_tz_54
	"Nota: Algunos exploradores tienen limitaciones que hacen imposible actualizar la pantalla de estado de la WAN cuando el estado cambia. Algunos exploradores requieren que actualice la pantalla para obtener el estado actualizado. Algunos exploradores informan de una condición de error cuando intentan obtener el estado WAN.", //help773
	"Reglas de filtrado MAC", //am_MACFILT
	"son el mismo equipo.", //aa_alert_7_new1
	"Cada dispositivo de red tiene su propia dirección MAC, definida por el fabricante del hardware. Algunos ISP pueden comprobar la dirección MAC de su ordenador. Algunos ISP guardan la dirección MAC del adaptador de red en el ordenador o router usado al realizar la primera conexión a su servicio. En consecuencia, el ISP solo da acceso a las solicitudes que provienen de un ordenador o router que tenga esa concreta dirección MAC. Este router tiene una dirección MAC diferente a la del ordenador o router que inicialmente se conectó al ISP", //help302
	"La opción de control de acceso le permite controlar la conexión y desconexión de su red. Use esta característica como los controles de acceso solo para dar acceso a sitios aprobados, limitar el acceso a la web según horas o fechas, y/o bloquear el acceso a Internet para aplicaciones como las utilidades P2P o los juegos.", //aa_intro
	"Se muestran los clientes que ha especificado para tener direcciones DHCP reservadas. Una entrada puede cambiarse haciendo clic sobre el icono Modificar, o eliminar haciendo clic sobre el icono Eliminar. Cuando hace clic en el icono Modificar, el elemento se resalta, y se activa la sección 'Modificar reserva DHCP'para modificarla.", //help348
	"Los paquetes recibidos por el host DMZ han traducido sus direcciones IP: de la dirección IP del router del lado WAN a la dirección IP del host DMZ del lado LAN. Sin embargo, los números de puerto no se traducen; así que las aplicaciones del host DMZ pueden depender de números de puerto específicos.", //haf_dmz_30
	"Informativo", //sl_Infrml
	"Inalámbrico", //_wireless
	"Dirección IP del servidor RADIUS", //bws_RIPA
	"Activar esta opción puede proporcionar protección frente a ciertos tipos de ataques de \“suplantación\”. No obstante, active con cuidado esta opción. Con algunos modems, se puede perder la conexión WAN cuando se activa esta opción. En ese caso, puede que sea necesario cambiar la subred de LAN por otra que no sea 192.168.0.x (por ejemplo, 192.168.2.x), para volver a establecer la conexión WAN.", //KR108
	"Si la velocidad automática de uplink está desactivada, estas opciones le permiten poner la velocidad de uplink manualmente. La velocidad de uplink es la velocidad a que los datos pueden transferirse del router a su ISP. Esto lo determina el ISP. Los ISP a menudo especifican la velocidad como un par downlink/uplink; por ejemplo, 1,5 Mbps/284 kbps. Siguiendo con este ejemplo, usted debería entrar '284'. También puede probar su velocidad de uplink con un servicio como <a href='http://www.dslreports.com'>www.dslreports.com</a> Tenga en cuenta, sin embargo, aquellos sitios, como DSL Reports, que no consideran como sobrecarga muchos protocolos de la red, por lo que las velocidades serán ligeramente inferior que la velocidad de uplinl medida o la velocidad media del ISP.", //help83
	"Si <strong>la velocidad de uplink medida </strong> es incorrecta (es decir, el rendimiento es inferior al óptimo), desactive <strong>velocidad de uplink automática</strong> y escriba la <strong> velocidad de uplink automática </strong>. Para lograr el valor más adecuado, puede ser necesaria cierta experimentación o rendimiento.", //hhase_intro
	"Error al cargar la configuración desde la memoria no volátil (Error de número mágico). Restablecer configuración a valores de fábrica", //RUNTIME_CONFIG_MAGIC_NUM_ERROR
	"Sáb.", //_Sat
	"Reglas de filtro de sitio web", //awf_title_WSFR
	"Usted puede escoger una computadora de la lista de clientes DHCP en el menú desplegable 'Nombre de ordenador'o puede entrar manualmente la dirección de IP del ordenador servidor.", //help18_a
	"PERMITE el acceso a los ordenadores SOLO a estos sitios", //dlink_wf_op_1
	"Llanto lejano", //gw_gm_18
	"Call of Duty", //gw_gm_7
	"Se ha localizado almacenamiento masivo USB con %u protocolo %u de subclase", //USB_LOG_STORAGE_TYPE
	"Servidor de juegos", //help346
	"Esto provocará que se pierda la configuración actual.", //up_rb_5
	"WEP", //_WEP
	"MSCHAP envía respuesta de autentificación (falla y no se reintenta).", //IPMSCHAP_AUTH_FAIL_AND_NO_RETRY
	"SWAT 4", //gw_gm_82
	"Los protocolos de autenticación admitidos son PAP y CHAP.", //bw_sap
	"Entre la información de dirección estática proporcionada por su proveedor de servicios internet (ISP)", //bwn_msg_SWM
	"La conexión de red no funciona. Pulse “Aceptar” para volver a intentarlo.", //li_alert_2
	"Cuando el control de acceso está deshabilitado, cada dispositivo de la LAN tiene acceso ilimitado a internet. Sin embargo, si habilita el control de acceso, el acceso a internet queda restringido para aquellos dispositivos que tienen una política de control de acceso configurada. Todos los otros dispositivos tienen acceso ilimitado a internet.", //help120
	"El host IGMP ha rechazado el grupo %v por los bajos recursos del sistema", //IGMP_HOST_LOW_RESOURCES
	"Exactamente 10 o 26 caracteres, usando 0-9 y A-F", //wwl_s4_intro_z3
	"Active esta opción para obtener un rendimiento y una experiencia mejorados con los juegos en línea y otras aplicaciones interactivas, tales como VoIP.", //help78
	"Windows 2000", //help339
	"Activar la seguridad sencilla IPv6", //IPv6_Simple_Security_enable
	"Introduzca el rango de puertos que desee abrir al tráfico de Internet (por ejemplo, <code>6000-6200</code>).", //help51
	"EL DIRECCIONAMIENTO DE LA PARTE DE INTERNET OBTENIDO MEDIANTE PPPOE ENTRA EN CONFLICTO CON EL DIRECCIONAMIENTO SELECCIONADO PARA LA PARTE LAN. SE DESACTI", //GW_WAN_LAN_ADDRESS_CONFLICT_PPP
	"Errores", //ss_Errors
	"Si una actualización de DNS dinámico falla por cualquiera razón (por ejemplo, porque se introducen parámetros incorrectos), el router automáticamente deshabilita la característica de DNS dinámico y hace constar el fallo en el registro.", //help899
	"Introduzca el código de autenticación gráfica.", //li_alert_4
	"La opción DMZ (zona desmilitarizada) permite definir un único ordenador de su red fuera del router. Si tiene un ordenador que no puede ejecutar correctamente aplicaciones de Internet desde detrás del router, puede poner el ordenador en la DMZ para disponer de acceso ilimitado a Internet.", //haf_dmz_40
	"Haga clic en el icono Editar para cambiar un programa existente.", //hhts_edit
	"Nombre de la red inalámbrica (SSID)", //wwl_wnn
	"Se ha tenido acceso al sitio Web %S desde %s", //WEB_FILTER_LOG_URL_ACCESSED_MAC
	"Habilitado WMM", //aw_WE
	"Ayuda para la configuración", //help201a
	"Active su prueba gratuita de 30 días aquí", //_bsecure_activate_trial
	"Introduzca la contraseña o la clave suministrada por su proveedor de servicios. Si el proveedor de servicios DNS dinámico le ha suministrado una sola clave, introduzca dicha clave en los tres campos.", //help896
	"Protocolo de comunicaciones usado por la conversación", //help815
	"Máscara de subred", //_netmask
	"espere, por favor...", //_please_wait
	"Repita estos pasos para cada regla de servidor virtual que desee añadir. Después de que la lista esté completa, haga clic en <span class='button_ref'>Guardar parámetros</span> en la parte superior de la página.", //help12
	"La opción de filtro de la dirección MAC se usa para controlar el acceso a red basado en la dirección MAC del adaptador de red. Una dirección MAC es un ID único asignado por el fabricante del adaptador de red. Esta característica puede ser configurada para PERMITIR o DENEGAR el acceso a la red o a internet.", //am_intro_1
	"LCP establece aut. local: %04x", //IPPPPLCP_SET_LOCAL_AUTH
	"Crimson Skies", //gw_gm_11
	"No guardar paramétros", //_dontsavesettings
	"La clave WPA (Acceso protegido Wi-Fi) debe cumplir las directrices siguientes", //wwl_s4_intro_za1
	"Predeterminado de MTU =", //_308
	"MAC", //aa_AT_1
	"Tunel local L2TP 0x%04X abortado", //IPL2TP_TUNNEL_ABORTING
	"Añadir/modificar reserva de DHCP", //help330
	"Cliente L2TP", //wwa_msg_l2tp
	"4:00 AM", //tt_time_5
	"Introduzca la dirección IP del equipo en su LAN (por ejemplo <code>192.168.0.50</code>)", //help6
	"HORA", //_time
	"xDSL u otra red Frame Relay", //at_xDSL
	"Paso 2: Iniciar el ejecutable de instalación en el equipo", //wprn_intro4
	"Normalmente, esta opción está configurada como “auto”. Si tiene problemas para conectarse a la WAN, intente otras opciones.", //help296
	"LAN", //_LAN
	"Warcraft III", //gw_gm_60
	"Seleccione el equipo al que se aplica esta directiva.", //_aa_wiz_s4_msg
	"64 bits", //wwl_64bits
	"Disco lleno", //IPFAT_DISK_FULL
	"Vaya al menú Inicio, seleccione Programas, seleccione Accesorios y seleccione Símbolo del sistema. En la línea de comandos escriba <code>ipconfig /all</code>y pulse Intro La dirección física mostrada para el adaptador que está conectado al router es la dirección MAC", //help341
	"Presione “Aceptar” para abandonar estos cambios y mostrar la página de programación.", //aa_sched_conf_2
	"Intentando iniciar sesión local 0x%04X de L2TP", //IPL2TP_SESSION_CONNECTING
	"Ha fallado la sincronización de tiempos (estado %d)", //NET_RTC_SYNCHRONIZATION_FAILED
	"Comprobación automática en línea de la existencia de una versión más reciente del firmware", //tf_AutoCh
	"El fabricante de la impresora y/o el modelo no pudieron determinarse, posiblemente debido a que la impresora dio un ID de dispositivo no válido. El asistente no puede continuar sin esta información.", //wprn_iderr2
	"Estos dos valores IP (<i>desde</i> y <i>hasta</i>) definen un rango de direcciones IP que usa el servidor DHCP al asignar direcciones a los ordenadores y dispositivos de su red de área local. Las direcciones que están fuera de este rango no las gestiona el servidor DHCP; por lo tanto, estas direcciones pueden usarse para los dispositivos configurados manualmente o para aquellos dispositivos que no pueden usar DHCP para obtener automáticamente los datos de la dirección de red.", //help319
	"<b>Nota:</b> Al poner un ordenador en la DMZ, podría exponerlo a", //af_intro_2
	"Al hacer clic en este botón se actualiza la pantalla de las entradas del registro. Puede que haya nuevos eventos desde la última vez que accedió al registro.", //help800
	"Información del dispositivo", //sd_title_Dev_Info
	"El filtro del puerto de acceso a Internet ha descartado el paquete de %v a %v (protocolo %u)", //GW_INET_ACCESS_DROP_PORT_FILTER
	"Windows Connect Now", //_connow
	"SIP ALG rechazó el paquete de %v:%u a %v:%u", //IPSIPALG_REJECTED_PACKET
	"Se ha eliminado el paquete TCP de %v:%u a %v:%u por no poder modificar las opciones de encabezado", //IPNAT_TCP_UNABLE_TO_MODIFY_OPTIONS
	"Seleccionar servidor NTP", //tt_SelNTPSrv
	"Un entorno de radiofrecuencia con ruido puede causar una alta tasa de errores en la LAN inalámbrica.", //help812
	"Usuario", //_user
	"(GMT+08:00) Taipei", //up_tz_59
	"Aplicaciones especiales", //SPECIAL_APP
	"NINGUNA", //wwl_NONE
	"Iniciando servicios WAN", //GW_WAN_SERVICES_STARTED
	"Acceso Web prohibido", //fb_FbWbAc
	"Ha de abrir la interfaz de gestión basada en web y hacer clic sobre el botón Conectar cada vez que desee conectarse a internet.", //help275
	"No se ha detectado ninguna impresora", //wprn_nopr
	"Zona horaria", //tt_TimeZ
	"Consejos para solucionar problemas", //wprn_tt
	"Seleccione su zona horaria en el menú desplegable", //help841
	"Definir una nueva programación.", //aa_sched_new
	"1:00 PM", //tt_time_14
	"HTTP", //gw_vs_1
	"Ajustes de syslog", //tsl_SLSt
	"H.323 ALG ha rechazado el paquete de %v:%u a %v:%u", //IPH323ALG_REJECTED_PACKET
	"Paso 4 - Seleccione el método de filtrado", //aa_wiz_s1_msg4
	"Windows 98", //help336
	"Nombre del sistema", //ta_sn
	"Dependiendo de si ha iniciado sesión actualmente en BigPond, puede hacer clic en <span class='button_ref'>Inicio de sesión BigPond</span> para intentar establecer la conexión WAN o <span class='button_ref'>Cerrar sesión de BigPond</span> para interrumpir la conexión WAN.", //help780
	"Interfaz", //_interface
	"Sitio web %S bloqueado para %v", //WEB_FILTER_LOG_URL_BLOCKED
	"El puerto admin remoto entra en conflicto con el elemento de servidor virtual", //vs_http_port
	"El router proporciona un estricto firewall apretado en virtud de cómo NAT trabaja. A menos que configure el router para lo contrario, NAT no responde a solicitudes entrantes no solicitadas en cualquier puerto, con lo que hace invisible su LAN a los ciberataques de internet. Sin embargo, ciertas aplicaciones de red pueden no funcionar con un firewall estricto. Esas aplicaciones necesitan abrir puertos selectivamente en el firewall para funcionar correctamente. Las opciones de esta página controlan", //haf_intro_1
	"(GMT-06:00) América Central", //up_tz_07
	"Si no está familiarizado con los parámetros inalámbricos avanzados, por favor lea la sección de ayuda antes de modificar estos parámetros.", //aw_intro
	"Dirección de puerta de enlace", //wwa_gw
	"Servicios de centinela", //_sentinel_serv
	"Elija esta opción si su proveedor de servicios de Internet le facilita información de dirección IP que se debe configurar manualmente.", //wwa_msg_sipa
	"Se ha eliminado el paquete TCP de %v a %v por encabezado de paquete no identificable", //IPNAT_TCP_UNABLE_TO_HANDLE_HEADER
	"Puede seleccionar un ordenador de la lista de clientes DHCP en el menú desplegable <strong>Nombre de ordenador</strong>, o puede entrar manualmente la dirección IP del ordenador al que quiere abrir el puerto especificado.", //hhav_ip
	"Pocas aplicaciones verdaderamente requieren el uso del host DMZ. Los siguientes ejemplos muestran cuándo podría requerirse un host DMZ.", //haf_dmz_50
	"Detenida directiva %s; el acceso a Internet para dirección MAC %m ha cambiado a: %s", //GW_INET_ACCESS_POLICY_END_MAC
	"La opción de configuración del calendario se utiliza para administrar las reglas de programación temporal para diversas características del cortafuegos y del control paterno.", //tsc_intro_Sch
	"Acceso denegado al sistema inalámbrico con la dirección MAC %m", //GW_WLAN_ACCESS_DENIED
	"Nombre de dominio local", //_262
	"Esta opción está activada por defecto para que su router determine de forma automática qué programas deben tener prioridad de red.", //help79
	"No se ha configurado BigPond correctamente", //GW_BIGPOND_CONFIG
	"Alto", //aw_TP_0
	"Estableciendo (espere, por favor)", //_sdi_s3
	"Resultado de ping", //tsc_pingr
	"Prueba de ping de IPv6", //tsc_pingt_v6
	"WPA-Personal", //_WPApersonal
	"Parámetros de correo electrónico", //_email
	"PPPoE confirmando oferta de sesión", //PPPOE_EVENT_DISCOVERY_REQUEST
	"Cortafuegos", //_firewall
	"Conexión de dirección IP estática", //wwa_wanmode_sipa
	"Comprobación del sistema", //_syscheck
	"La dirección IP de la parte LAN del cliente.", //help784
	"Desconocido", //UNKNOWN
	"UPnP es la abreviación de Universal Plug and Play, que es una arquitectura de red que proporciona compatibilidad entre equipos de red, software y periféricos. Este router tiene capacidad de UPnP opcional, y puede trabajar con otros dispositivos y software UPnP.", //help_upnp_1
	"Wolfenstein: Enemy Territory", //gw_gm_61
	"(opcional)", //_optional
	"Si se asigna un valor demasiado bajo a la fragmentación puede producirse un rendimiento escaso.", //help181
	"Internet", //help569
	"Si no está familiarizado con los parámetros inalámbricos avanzados, por favor lea la sección de ayuda antes de modificar estos parámetros.", //anet_intro
	"Introduzca la contraseña correcta arriba<br> y, a continuación, escriba los caracteres que<br> ve en la imagen siguiente.", //_authword
	"Bloqueado el paquete TCP saliente desde %v:%u hasta %v:%u porque %s se recibió pero no existe ninguna conexión activa", //IPNAT_TCP_BLOCKED_EGRESS_NOT_SYN
	"Nombre de gateway", //ta_GWN
	"Si no está autorizado a modificar la configuración del enrutador, póngase en contacto con el administrador del mismo.", //wprn_tt3
	"MTU", //help293
	"Si su ISP ha asignado una dirección IP fija, escoja esta opción. El ISP proporciona el valor para el", //help265_2
	"Se ha eliminado paquete de %v a %v (protocolo IP %u) por imposibilidad de crear una nueva sesión", //IPNAT_UNABLE_TO_CREATE_CONNECTION
	"Siempre activado", //help270
	"Parámetros de Opciones avanzadas inalámbricas", //aw_title_2
	"Configuración del firewall", //_firewalls
	"Activado/Sin configurar", //LW67
	"Establecida la sesión 0x%04X de PPPoE", //PPPOE_EVENT_UP
	"Protocolo", //_protocol
	"WPA-Personal y WPA-Enterprise", //help372
	"(GMT+02:00) Bucarest", //up_tz_32
	"Kbps", //at_kbps
	"Cable u otra red de banda ancha", //at_Cable
	"100 Mbps", //anet_wp_1
	"Asigne un nombre significativo al servidor virtual, por ejemplo <code>Servidor web</code>. Están disponibles", //help17
	"Por defecto no hay ninguna clave de acceso configurada. Se recomienda que cree una clave de acceso para que su router sea seguro.", //ta_intro_Adm2
	", compruébelo", //tool_admin_check
	"Red PPP activada con dirección IP %v", //IPPPPIPCP_PPP_LINK_UP
	"Parar", //_stop
	"Servidor Syslog definido como dirección IP %v", //GW_SYSLOG_STATUS
	"Configuración del servidor DHCP", //bd_title_DHCPSSt
	"El nombre del router puede cambiarse aquí.", //help827
	"Compruebe la última versión del firmware", //tf_FWCheckInf
	"INFORMACIÓN DE FIRMWARE y PAQUETE DE IDIOMA", //tf_FWInf
	"Cada regla puede controlar hasta ocho rangos de direcciones de IP WAN. La casilla de verificación de cada rango IP permite deshabilitar rangos ya definidos.", //hhai_ipr
	"Se recomienda que deje estos parámetros como sus valores por defecto. Si los ajusta podría limitar el rendimiento de su red inalámbrica.", //hhaw_1
	"Permite que varios clientes VPN se conecten a sus redes corporativas mediante IPSec. Algunos clientes VPN admiten el cruce de IPSec a través de NAT. Esta opción puede interferir en el funcionamiento de dichos clientes VPN. Si tiene problemas para conectar con su red corporativa, pruebe a desactivar esta opción.", //help34
	"Acti", //_network_usb_auto
	"La máscara de subred de su router en la red de área local", //help309
	"No puede añadir nuevas direcciones MAC. Puede reusar sólo las direcciones MAC de otras políticas.", //aa_alert_15
	"Guardar parámetros", //_savesettings
	"Asigne un nombre a la programación que signifique algo para usted, como “regla semanal”.", //help193
	"Parámetros de servidor virtual", //help14_p
	"Need for Speed: Hot Pursuit 2", //gw_gm_32
	"Bloqueada la solicitud de conexión entrante TCP de %v:%u a %v:%u", //IPNAT_TCP_BLOCKED_INGRESS_SYN
	"Si activa esta característica, el puerto WAN de su router responderá a las solicitudes ping desde Internet que se hayan enviado a a la dirección IP WAN.", //anet_msg_wan_ping
	"Los filtros entrantes pueden usarse para limitar el acceso a un servidor de su red a un sistema o grupo de sistemas", //ai_intro_2
	"Máscara de subred L2TP", //help285
	"Estadísticas de la LAN", //ss_LANStats
	"Restauración en curso.", //ta_alert_4
	"Copiar la dirección MAC del PC", //_clone
	"Diablo I y II", //gw_gm_14
	"Se ha eliminado un paquete GRE desde %v a %v por encabezado de paquete no identificable", //PPTP_ALG_GRE_UNABLE_TO_HANDLE_HEADER
	"Bloquear algún acceso", //_aa_block_some
	"Establecido: la conexión está transmitiendo o recibiendo datos", //help819_3
	"11:00 PM", //tt_time_24
	"Normalmente el correo electrónico se envía a la hora de inicio señalada en la programación, y la hora finall de la programación no se usa. Sin embargo, si reinicia el router durante el tiempo de la programación, se generarán mensajes de correo electrónico adicionales para enviar.", //help873
	"Colisiones", //ss_Collisions
	"Entre la dirección del servidor SMTP para el envío de correo electrónico.", //help863
	"Esta opción habilita la configuración de un segundo servidor RADIUS opcional. El segundo servidor de RADIUS puede ser usado como reserva para el servidor RADIUS primario. El segundo servidor RADIUS se consulta sólo cuando el servidor primario no está disponible o no responde. Los campos <span class='option'>Dirección IP de servidor RADIUS </span>, <span class='option'>Puerto de servidor RADIUS </span>, <span class='option'>Ssecreto compartido de segundo servidor RADIUS </span>,<span class='option'>Autentificación de dirección MAC segunda </span> proporcionan los parámetros correspondientes al segundo servidor RADIUS.", //help397
	"Lista de servidores virtuales", //av_title_VSL
	"OFDM", //help636
	"Enviarme un mensaje de correo si hay nuevo firmware disponible", //tf_ENFA
	"Con esta entrada del Servidor Virtual, todo el tráfico de Internet en el Puerto 8888 será redirigido a su servidor Web interno en el puerto 80 en la dirección IP 192.168.0.50.", //help13
	"Paso 3: Configurar la conexión a internet", //wwa_title_s3
	"Paso 1: Configurar la conexión de Internet", //ES_wwa_title_s1
	"Se ha abortado la medición de la velocidad WAN porque no hay convergencia", //GW_WAN_RATE_ESTIMATOR_CONVERGENCE_ERROR
	"BigPond", //wwa_wanmode_bigpond
	"En la sección WAN (Wide Area Network) se configura el tipo de conexión a internet.", //help254
	"Para administrar conexiones entrantes que usan un protocolo distinto a ICMP, TCP, UDP, y IGMP (tambi n GRE y ESP, cuando estos protocolos son habilitados por los ALG PPTP y IPSec).", //haf_dmz_70
	"Se produjo un error del sistema al adjuntar con programación %s", //GW_SCHED_ATTACH_FAILED
	"El campo SSID no puede estar en blanco", //_badssid
	"Configuración almacenada en memoria no volátil", //RUNTIME_CONFIG_STORING_CONFIG_IN_NVRAM
	"Está disponible una actualización del Firmware", //FW_UPDATE_AVAILABLE
	"La característica de DNS dinámico le permite alojar un servidor (web, FTP, servidor de juegos, etc.) usando un nombre de dominio que usted haya adquirido (www.whateveryournameis.com) con su dirección IP asignada dinámicamente. La mayoría de los proveedores de servicios internet de banda ancha asignan direcciones IP dinámicas (que cambian). Cuando usa un proveedor de servicios de DNS dinámico, sus amigos pueden escribir su nombre de host para conectarse a su servidor, sin importar cuál es su dirección IP.", //help891
	"Conexión PPPoE, PPTP, L2TP.", //help777
	"Autentificación de dirección MAC", //help393
	"Tipo de conexión a internet", //bwn_ict
	"Jun", //tt_Jun
	"Se ha conectado el tunel local 0x%04X de L2TP a \'%s\'", //IPL2TP_TUNNEL_CONNECTED
	"Command and Conquer Zero Hour", //gw_gm_9
	"Aliens vs. Predator", //gw_gm_2
	"Asistente para la configuración de red inalámbrica", //wwl_wl_wiz
	"El rango DHCP no es válido, DE no es mayor que A", //network_dhcp_range
	"Paso 4: Imprimir una página de prueba", //wprn_intro6
	"BigPond no funciónó, estado=%d con error=%d, respuesta de servidor=%s", //GW_BIGPOND_FAIL
	"Dirección restringida", //af_EFT_1
	"Utilizar Unicasting (Unidifusión)", //_use_unicasting
	"Estado de la red", //_networkstate
	"Año", //tt_Year
	"No se pudo montar el dispositivo USB", //IPASYNCFILEUSB_MOUNT_FAILED
	"Filtrado UDP Endpoint", //af_UEFT
	"Por defecto está seleccionada la velocidad de transmisión más rápida posible. Tiene la opción de escoger la velocidad si es necesario.", //help356
	"Clave precompartida", //help381
	"Filtro entrante", //_inboundfilter
	"Aplicar filtros de puerto avanzados", //_aa_apply_port_filter
	"Dest<br />puerto<br />final", //aa_FPR_c7
	"Jedi Knight III: Jedi Academy", //gw_gm_27
	"No se ha configurado BigPond correctamente", //BIGPOND_NOT_PROPERLY_CFGD
	"Como alternativa, puede localizar una dirección MAC en cualquier sistema operativo, siguiendo los pasos mostrados a continuación:", //help335
	"(GMT+08:00) Perth", //up_tz_58
	"Nunca", //_never
	"Al hacer clic en este botón, borra todas las entradas del registro.", //help801
	"Tiempo de ping más largo (en milisegundos)", //tsc_pingt_msg105
	"ADVERTENCIA: ¡JavaScript no está activado en este explorador!", //li_WJS
	"Ddirección de correo electrónico del destinatario", //te_ToEm
	"12:00 AM", //tt_time_1
	"Señal", //help787
	"Obtenga automáticamente la dirección del servidor DNS de IPv6", //IPV6_TEXT65_v6
	"Registros de puerta de enlace", //GW_EMAIL_SUBJ
	"La activación del puerto ALG no logró asignar la sesión para los paquetes UDP de %v:%u a %v:%u", //IPPORTTRIGGERALG_UDP_PACKET_ALLOC_FAILURE
	"Si es la primera vez que trabaja en redes y nunca ha configurado un router, haga clic en<span class=\"button_ref\">Asistente de configuración</span>  y el router le guiará a lo largo de los sencillos pasos que le permitirán tener su red a punto y en funcionamiento.", //bi_wiz
	"Fuera", //_Out
	"Compruebe en el menú desplegable <strong> Nombre de la aplicación </strong> la lista de las aplicaciones predefinidas. Si escoge una de las aplicaciones predefinidas, haga clic en el botón de flecha junto al menú desplegable para completar el campo correspondiente", //hhpt_app
	"Conexión DHCP (dirección IP dinámica)", //_dhcpconn
	"Parámetros del router", //bln_title_Rtrset
	"Servidor de Impresión", //_ps
	"Esta entrada es opcional. Introduzca un nombre de dominio para la red local. El servidor DHCP del AP proporcionará este nombre de dominio a los ordenadores de la LAN inalámbrica. De este modo, por ejemplo, si introduce aquí <code>mired.net</code>, y dispone de un ordenador portátil inalámbrico con un nombre de <code>chris</code>, ese ordenador portátil se conocerá como <code>chris.mired.net</code>.", //_1044
	"Escoja esta opción si sus adaptadores inalámbricos ADMITEN WPA2", //wwl_text_best
	"Dirección IP del servidor PPTP (puede ser la misma que la puerta de enlace)", //wwa_pptp_svraddr
	"Se ha completado la medición de la velocidad WAN. La velocidad del flujo ascendente es de %u kbps", //GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED
	"Ordenadores LAN", //_LANComputers
	"Puede establecer los parámetros de correo electrónico iguales a los de su programa de cliente de correo electrónico", //hhte_intro
	"H.323 (NetMeeting)", //as_NM
	"Asistente para la configuración", //wwa_setupwiz
	"y", //help264
	"(compatibilidad para algunos servidores DHCP)", //bw_WDUU_note
	"MMS", //as_MMS
	"Nombre del servicio", //_srvname
	"La regla se aplica a un flujo de mensajes cuya dirección IP del lado LAN no coincide con el rango establecido aquí.", //help93
	"Minuto", //tt_Minute
	"Estado", //sa_State
	"Habilitado 802.11d", //aw_dE
	"Nombre de host o dirección IP", //tsc_pingt_h
	"Nombre de host o direcciones IPv6", //tsc_pingt_h_v6
	"Estadísticas inalámbricas", //ss_WStats
	"El autentificador MSCHAP ha enviado un desafío.", //IPMSCHAP_AUTH_SEND_CHALLENGE
	"Cuando esta opción está habilitada, su router periódicamente comprobará en línea si hay una nueva versión del firmware.", //help889
	"H.323 (NetMeeting)", //as_H323
	"Elemento de direccionamiento de puerto", //tool_admin_pfname
	"Se ha eliminado el paquete de %v a %v (protocolo %u) porque la sesión ya existe", //IPNAT_SESSION_ALREADY_EXISTS
	"Establezca la conexión por cable con BigPond", //wwa_title_set_bigpond
	"(GMT-04:00) Santiago", //up_tz_16
	"Cambiado estado de BigPond, nuevo estado=%d", //GW_BIGPOND_STATUS
	"Para configurar esta conexión necesita que su proveedor de servicios internet le haya proporcionado un nombre de usuario y una clave de acceso, así como una dirección IP de servidor BigPond. Si no tiene esta información, contacte con su ISP.", //wwa_msg_set_bigpond
	"Active como mínimo un rango de IP de origen para %s", //ai_alert_5
	"Seleccione esta opción si quiere sincronizar el reloj del router a un servidor horario de red en internet. Si usted usan programaciones o registros, esta es la mejor forma para asegurarse de que las programaciones y registros se realizan con precisión.", //help848
	"Volver al castillo Wolfenstein", //gw_gm_41
	"Asistente para directivas", //_aa_pol_wiz
	"Filtros IP", //IP_FILTERS
	"Starsiege Tribes", //gw_gm_50
	"Seleccione su tipo de conexión a Internet a continuación:", //wwa_intro_s3
	"Se ha eliminado un paquete ESP desde %v debido a que ya existe un intento de conexión pendiente de %v a %v", //IPSEC_ALG_ESP_ESTABLISH_ALREADY_PENDING
	"Individual (80, 68, 888)", //help59
	"¿Seguro que quiere restablecer el dispositivo sin configuración?", //wps_reboot_need
	"Fragmentación dinámica", //at_DF
	"Si los servidores del ISP asignan las direcciones IP del router al establecer una conexión, escoja esta opción.", //help265_7
	"El mes de final del horario debe de verano debe ser distinto del mes de inicio de dicho horario.", //tt_alert_dstchkmonth
	"(GMT-01:00) Islas de Cabo Verde", //up_tz_23
	"Avanzado", //_advanced
	"Dirección IP estática", //STATIC_IP_ADDRESS
	"Paso 2: Asegure su red inalámbrica", //wwl_title_s3
	"Esta es una lista de todos los clientes inalámbricos que están actualmente conectados a su router inalámbrico.", //hhsw_intro
	"MENÚ", //ish_menu
	"(GMT+02:00) Cairo", //up_tz_33
	"No se pudo comprobar la existencia de nuevo firmware", //GW_FW_NOTIFY_FIRMWARE_ERROR
	"Más información", //_bsecure_more_info
	"Versión del firmware actual", //tf_CFWV
	"2º", //tt_week_2
	"Ejemplo:", //help3
	"Creador", //_creator
	"Retransmisión DNS", //bln_title_DNSRly
	"El filtro de puertos de acceso a Internet eliminó un paquete de %v:%u[%s] a %v:%u (protocolo %u)", //GW_INET_ACCESS_DROP_PORT_FILTER_MAC
	"Glosario", //ish_glossary
	"Una clave WEP más larga es más segura que una corta", //wwl_s4_intro_z4
	"Por defecto, la característica de control de acceso está deshabilitada. Si usted necesita control de acceso, marque esta opción.", //help118
	"Shareaza", //gw_gm_66
	"Cuando se activa DNS Relay, el enrutador desempeña el papel de un servidor DNS.  Las solicitudes DNS enviadas al enrutador se transmiten al servidor DNS del ISP.  Éste proporciona una dirección DNS constante que pueden utilizar los ordenadores de la LAN , incluso cuando el enrutador obtenga una dirección de servidor DNS diferente del ISP al restablecer la conexión WAN Debe desacti", //help312dr2
	"Todo el día, 24 horas", //tsc_24hrs
	"Compruebe en el menú desplegable <strong> Nombre de la aplicación </strong> la lista de las aplicaciones predefinidas. Si escoge una de las aplicaciones predefinidas, haga clic en el botón de flecha junto al menú desplegable para completar el campo correspondiente", //hhag_10
	"Algunos ISP pueden verificar el nombre de host de su ordenador. El nombre de host identifica su sistema ante el servidor del ISP. Así sabe si su ordenador puede recibir una dirección IP. En otros términos, sabe que está pagando su servicio.", //help261
	"Tipo de tráfico trigger", //as_TPrt
	"Esto sucederá si se ha configurado una regla de control de acceso para este equipo de la LAN.", //help28
	"11:00 AM", //tt_time_12
	"Actualizar estadísticas", //ss_reload
	"Fuera", //EGRESS
	"Esta impresora <span id='status_text'> </span> está conectada al router.", //sps_fp
	"Unreal Tournament 2004", //gw_gm_57
	"Elija esta opción si su conexión a Internet le proporciona automáticamente una dirección IP. La mayoría de los módems por cable utilizan este tipo de conexión.", //wwa_msg_dhcp
	"Paso 1 - Seleccione un nombre único para su directiva", //aa_wiz_s1_msg1
	"Debe iniciar la sesión como “admin” para realizar esta acción", //MUST_BE_LOGGED_IN_AS_ADMIN
	"(GMT+09:30) Darwin", //up_tz_64
	"detener gw_wireless_schedule", //GW_WLS_SCHEDULE_STOP
	"Wake-on-LAN ALG rechazó paquete desde %v:%u hasta %v:%u", //IPWOLALG_REJECTED_PACKET
	"Actualizar dispositivo a wsetting.wfc", //WCN_LOG_UPDATE
	"Esta opción se debe activar si la velocidad de subida de Internet es lenta. Permite reducir el impacto sobre los paquetes de red urgentes por parte de otros de gran tamaño con prioridad baja, al dividir estos en varios paquetes más pequeños.", //help80
	"Aquí puede añadir entradas a la lista de reglas de filtro entrante que figura abajo", //help171
	"Lun.", //_Mon
	"(GMT+10:00) Canberra, Melbourne, Sidney", //up_tz_66
	"Paso 2: Establecer su contraseña de seguridad inalámbrica", //wwl_title_s4_2
	"Si no utiliza la opción Todo el día, indique aquí la hora. La hora de inicio se escribe en dos campos. El primer cuadro es para la hora y el segundo para los minutos. Los eventos de correo electrónico se desencadenan normalmente con la hora de inicio.", //help196
	"La oferta de sesión PPPoE tenía errores. No se logró la conexión.", //PPPOE_EVENT_DISCOVERY_REQUEST_ERROR
	"Inicio de sesión", //li_Log_In
	"Sesiones LAN No-UDP/TCP/ICMP", //af_gss
	"Puerta de enlace predeterminada", //_defgw
	"El servidor NTP no está configurado.", //YM185
	"Añadiendo dispositivo inalámbrico:", //add_wireless_device
	"Introduzca el puerto público como [8.888]", //help8
	"Su ISP le proporciona toda esta información", //help258
	"El concentrador de acceso finalizó la sesión 0x%04X de PPPoE", //PPPOE_EVENT_TERMINATED
	"¿Está seguro de que desea reiniciar el dispositivo?", //up_rb_1
	"Use las casillas de verificación a la izquierda para habilitar o deshabilitar entradas de servidor virtuales completadas.", //help25_b
	"Guardar registro", //sl_saveLog
	"Use esta opción para ver los registros del router. Puede definir qué tipos y niveles de eventos quiere ver. Este router también admite un servidor syslog externo para que pueda enviar los archivos de registro a un ordenador de su red en el que se esté ejecutando una utilidad syslog.", //sl_intro
	"Especifique un equipo con su dirección IP o MAC o seleccione 'Otros Equipos' para aquellos que no tengan una directiva.", //_aa_wiz_s4_help
	"Se ha desconectado el cable de interfaz WAN", //GW_WAN_CARRIER_LOST
	"(bytes)", //bwn_bytes
	"Registrarse al servicio de notificación por correo electrónico para recibir un aviso por correo electrónico cuando esté disponible una nueva versión del firmware.", //help890_1
	"Conexión BigPond", //help779
	"Dirección MAC", //_macaddr
	"Conexiones TCP restablecidas o cerradas. La conexión no se cierra instantáneamente para que los paquetes grandes pueden pasar o pueda restablecerse la conexión.", //help823_13
	"Activar gestión", //ta_ELM
	"Activar acceso remoto a almacenamiento HTTPS", //sto_http_4
	"Activar secuencias de multidifusión IPv4", //anet_multicast_enable_v4
	"Siguiente actualización de DNS dinámica programada para %s", //GW_DYNDNS_UPDATE_NEXT
	"Escriba la contraseña asociada a la cuenta.", //help866
	"Estado del enrutador", //sl_RStat
	"Roger Wilco", //gw_gm_78
	"Cree un nombre para la regla que sea significativo para usted.", //help90
	"Se ha cerrado el túnel PPTP con ID 0x%04X", //PPTP_EVENT_TUNNEL_DOWN
	"Modo WAN estático.", //bwn_SWM
	"El filtro de Web rechazó el paquete desde %v:%u hasta %v:%u", //IPWEBFILTER_REJECTED_PACKET
	"Cargada imagen de actualización de firmware no válida - descartándola", //GW_UPGRADE_FAILED
	"Esta opción se usa para abrir", //ag_intro
	"La opción Admin se utiliza para establecer una contraseña para acceder a la administración basada en la web. De forma predeterminada no existe contraseña configurada. Se recomienda encarecidamente crear una contraseña para mantener seguro el nuevo router.", //ta_intro_Adm
	"Dirección IP del servidor L2TP", //bwn_L2TPSIPA
	"No se está aplicando ninguna directiva de acceso a Internet. Permitido acceso a Internet no restringido para todos", //GW_INET_ACCESS_UNRESTRICTED
	"(GMT-05:00) Bogotá, Lima, Quito", //up_tz_11
	"Desactivado", //_disabled
	"Envío de un correo electrónico de registro ya que el registro está lleno", //GW_LOG_EMAIL_ON_LOG_FULL
	"7:00 AM", //tt_time_8
	"Permite que Windows Media Player, mediante el protocolo MMS, reciba contenido multimedia transmitido desde Internet.", //help43
	"Conectando", //ddns_connecting
	"Habilitar", //_enable
	"A petición", //help272
	"Abr", //tt_Apr
	"Fecha u hora no válidas", //tt_alert_invlddt
	"(Mbit/s)", //bwl_MS
	"El puerto admin remoto entra en conflicto con", //tool_admin_portconflict
	"Nombre de la aplicación", //gw_SelVS
	"Siempre activado", //bwn_RM_0
	"Haga clic sobre el icono <strong>Modificar</strong> de la lista de reglas para cambiar una regla.", //hhai_edit
	"Dirección de correo electrónico De", //te_FromEm
	"La puerta de enlace está midiendo la conexión de red.", //wt_p_1
	"Solicitando tiempo desde %v", //NET_RTC_REQUEST_TIME
	"Introduzca un nombre para la regla de aplicación especial, por ejemplo <code>Aplicación de juego</code>, el cual le ayudará a identificar la regla en el futuro. Si lo prefiere, puede seleccionar un nombre de la lista <span class='option'>Aplicación</span>, en la cual se incluyen nombres de aplicaciones comunes.", //help48
	"N/A", //N_A
	"Máscara de subred PPTP", //help279
	"6º", //tt_week_6
	"Soldier of Fortune II: Double Helix", //gw_gm_48
	"Invisible", //bwl_VS_1
	"Confirmación de la actualización del firmware en la página de estatus", //help882
	"(GMT+03:00) Teherán", //up_tz_41
	"Configuración cargada desde memoria no volátil", //RUNTIME_CONFIG_LOADED_CONFIG_FROM_NVRAM
	"Tiempo de espera de la sesión excedido; vuelva a intentarlo.", //li_alert_1
	"La dirección IP de su router en la red de área local. Los parámetros de red de área local se basan en la dirección asignada aquí. Por ejemplo 192.168.0.1.", //help307
	"Cuando se necesita, se establece la conexión a internet", //help273
	"Seleccione las casillas de verificación de los días que desee o, si quiere seleccionar los siete días de la semana, marque el botón de radio Toda la semana.", //help194
	"¿Está seguro de que desea restablecer la configuración predeterminada de fábrica del dispositivo?", //up_rb_4
	"Puede encontrar una versión de Firmware %d.%d más reciente para su enrutador %s %s en", //NEWER_FW_VERSION
	"Tipo de conexión a internet con PPTP", //bwn_PPTPICT
	"Imagen de actualización del firmware cargada con éxito - instalando", //GW_UPGRADE_SUCCEEDED
	"(direcciones dentro de la subred de LAN)", //bwl_AS
	"La regla se aplica a un flujo de mensajes cuyo número de puerto del lado WAN se encuentra en el rango establecido aquí.", //help96
	"Canal inalámbrico", //_wchannel
	"Asigna manualmente una clave de red", //wwz_manual_key
	"Haga clic en el botón inferior para seguir configurando el router.", //ap_intro_cont
	"Habilitar la entrada a un servidor syslog", //tsl_EnLog
	"L2TP", //_L2TP
	"Intervalo de dirección IP de DHCP", //bd_DIPAR
	"Estadísticas", //_stats
	"Entre 8 y 63 caracteres (una clave WPA más larga es más segura que una corta)", //wwl_s4_intro_za2
	"La sesión local 0x%04X de L2TP no funciona", //IPL2TP_SESSION_DOWN
	"Tipo de conexión a internet con IP dinámica (DHCP)", //bwn_DIAICT
	"Vaya al menú Inicio, seleccione Ejecutar, escriba <code>winipcfg</code>, y presione Intro Aparecerá una ventana emergente. Seleccione la tarjeta adecuada del menú desplegable y verá la dirección de la tarjeta. Ésta es la dirección MAC del dispositivo.", //help338
	"Escriba la dirección IP LAN del servidor syslog", //help859
	"Añadir", //_add
	"Control de acceso", //_acccon
	"No se puede resolver, verifique que el nombre es correcto", //tsc_pingt_msg4
	"Desconectar", //ddns_disconnect
	"Verificar contraseña", //_verifypw
	"Configuración de filtrado MAC", //am_intro_2
	"Añadir política", //_aa_pol_add
	"Warcraft II", //gw_gm_59
	"Haga clic en <span class='button_ref'>Guardar</span> para añadir los parámetros a la lista de servidores virtuales", //help11
	"Sistema", //_system
	"Normalmente esta opción está desactivada, y debe permanecer desactivada siempre que el servidor DHCP de la parte WAN proporcione correctamente una dirección IP al enrutador. Sin embargo, si el enrutador no puede obtener una dirección IP del servidor DHCP, puede que el servidor DHCP funcione mejor con respuestas unidifusión. En este caso, active la opción unidifusión y observe si el enrutador puede obtener una dirección IP. En este modo, el enrutador acepta respuestas unidifusicón desde el servidor DHCP en vez de respuestas de difusión.", //help261a
	"(GMT-10:00) Hawai", //up_tz_02
	"'Ping' comprueba si un ordenador que está en internet está en activo y respondiendo.", //hhtsc_pingt_intro
	"Asigne un nombre al servidor virtual (por ejemplo <code>Servidor web</code>)", //help5
	"Menú de asistencia", //help767s
	"Splinter Cell: Pandora Tomorrow", //gw_gm_45
	"Conexión con nombre de usuario / contraseña (PPPoE)", //wwa_wanmode_pppoe
	"Destino y gateway no pueden estar en la misma subred %v", //GW_ROUTES_GATEWAY_SUBNET_SAME
	"Un host necesita soportar", //haf_dmz_60
	"La característica de correo electrónico se puede usar para enviar archivos de registro del sistema, mensajes de alerta del router y notificaciones de actualización del firmware a su dirección de correo electrónico.", //te_intro_Em
	"Escoja esta opción si no quiere habilitar ninguna característica de seguridad", //wwl_text_none
	"Introduzca el nombre de usuario o la clave suministrada por su proveedor de servicios. Si el proveedor de servicios DNS dinámico le ha suministrado una sola clave, introduzca dicha clave en los tres campos.", //help895
	"Intentando volver a conectar bajo petición la conexión WAN", //GW_WAN_RECONNECT_ON_ACTIVE
	"Equipo", //aa_Machine
	"iniciar gw_wireless_schedule", //GW_WLS_SCHEDULE_INIT
	"Mié.", //_Wed
	"7:00 PM", //tt_time_20
	"Dest IP<br />inicio", //aa_FPR_c3
	"Introduzca los puertos TCP que se deben abrir (por ejemplo, <code>6159-6180, 99</code>).", //help68
	"Es más útil impedir que dispositivos inalámbricos no autorizados puedan conectarse a su red.", //help150
	"Nombre de cuenta", //te_Acct
	"El cliente SMTP ha enviado el correo electrónico satisfactoriamente", //IPSMTPCLIENT_MSG_SENT
	"Quake 3", //gw_gm_38
	"Esta opción funciona con un servidor RADIUS para autentificar clientes inalámbricos. Los clientes inalámbricos deben haber establecido las credenciales necesarias antes de intentar autentificar al servidor a través de este gateway. Además, puede ser necesario, para configurar el servidor RADIUS, permitir estea gateway  para autentificar usuarios.", //help384
	"1:00 AM", //tt_time_2
	"Velocidad de subida automática", //at_AUS
	"Haga clic en el icono Borrar para borrar permanentemente un programa.", //hhts_del
	"Preferencia dada a los paquetes salientes de esta conversación por QoS Engine. Los números más pequeños representan prioridad más alta.", //help818
	"No se puede realizar la actualización de firmware desde un dispositivo inalámbrico. Para realizar una actualización asegúrese de que está utilizando un PC que está conectado al enrutador por cable.", //help886
	"Elija un nombre exclusivo para la política", //_aa_wiz_s2_msg
	"Seleccione el protocolo utilizado por el tráfico de Internet que regresa al router a través del rango de puertos abiertos (por ejemplo, <code>Ambos</code>).", //help52
	"segundos ...", //wps_KR46
	"Asigne un nombre a la red, utilizando un máximo de 32 caracteres.", //wwz_wwl_intro_s3_1
	"Ghost Recon", //gw_gm_19
	"La característica de DDNS le permite alojar un servidor (web, FTP, servidor de juegos, etc.) usando un nombre de dominio que haya adquirido (www.whateveryournameis.com) con su dirección IP asignada dinámicamente. La mayoría de proveedores de servicios internet de banda ancha asignan direcciones IP dinámicas (que cambian). Al usar un proveedor de servicios de DDNS, sus amigos pueden entrar su nombre de host para conectarse a su servidor de juegos sin importar cuál es su dirección IP.", //td_intro_DDNS
	"(GMT+07:00) Bangkok, Hanoi, Yakarta", //up_tz_53
	"Inicio y final del horario de verano", //help845
	"Esta página se actualizará en breve.", //wt_p_3
	"(GMT+06:00) Sri Jayawardenepura", //up_tz_51
	"Otra opción es dirigir el ejecutable de configuración a una carpeta de su ordenador que contenga un controlador de impresión que usted previamente haya descargado del sitio web del fabricante de la impresora.", //wprn_s3d
	"Error en autenticación CHAP – compruebe detalles de inicio de sesión.", //IPPPPCHAP_AUTH_FAIL
	"Tiberian Sun", //gw_gm_52
	"Paquete TCP bloqueado desde %v:%u hasta %v:%u porque el control %s no es válido", //IPNAT_TCP_BAD_FLAGS
	"Nombre", //_name
	"Introduzca la dirección IP de red local del sistema en el que se aloja el servidor, por ejemplo <code>192.168.0.50</code>.", //help66
	"Mensaje de error de ICMP entrante bloqueado (tipo de ICMP %u) desde %v hasta %v por no existir ninguna sesión activa de UDP entre %v:%u y %v:%u", //IPNAT_UDP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"FTP ALG rechazó el paquete de %v:%u a %v:%u", //IPFTPALG_REJECTED_PACKET
	"No está permitido el acceso a este sitio Web desde este ordenador.", //fb_p_1
	"Tipo de conexión", //_contype
	"El puerto que usará para acceder a la interfaz de gestión desde internet. Por ejemplo, si usted especifica el puerto 1080, para acceder el router desde internet, deberá usar una URL con el formato: <code>http://my.domain.com:1080/</code>.", //help829
	"Reglas de aplicación", //_specappsr
	"La opción Invisible le permite ocultar su red inalámbrica. Cuando esta opción está establecida como Visible, el nombre de su red inalámbric se difunde a cualquiera que esté dentro del alcance de su señal. Si no usa encriptación, cualquiera se podría conectar a su red. Cuando está habilitado el modo Invisible, debe introducir manualmente el nombre de la red inalámbrica (SSID) del cliente para conectarse a la red.", //help353
	"Halo: Combat Evolved", //gw_gm_23
	"Broadcast siempre", //help325
	"Modo de reconexión", //bwn_RM
	"Opciones de registro", //sl_LogOps
	"Todos los datos de la conexión de red y de internetse muestran en la página de información del dispositivo, así como la versión del firmware.", //help772
	"Método", //_aa_method
	"Detalles del registro", //sl_LogDet
	"Es una medida relativa de la calidad de señal. El valor se expresa como un porcentaje de la mejor calidad teórica. La calidad de la señal puede reducirse por la distancia, por interferencia con otras fuentes de radiofrecuencia (como los teléfonos inalámbricos o redes inalámbricas vecinas) y por obstáculos situados entre el enrutador y el dispositivo inalámbrico.", //help788
	"Continuar", //_continue
	"La página Estadísticas muestra todas las estadísticas de los paquetes LAN, WAN e inalámbricos que se hayan enviado o recibido.", //help804
	"Info del dispositivo", //_devinfo
	"Sí", //_yes
	"SSID", //help699
	"(GMT+10:00) Yakutsk", //up_tz_62
	"En esta sección puede añadir entradas a la lista de reglas de programación que figura abajo o modificar las entradas existentes.", //help192
	"Activar DHCP-PD", //DHCP_PD_ENABLE
	"Need for Speed", //gw_gm_31
	"Siempre se está conectado a internet", //help271
	"Permite que varios equipos de la LAN se conecten a sus redes corporativas mediante el protocolo PPTP.", //help33
	"Bloqueado paquete entrante TCP desde %v:%u hasta %v:%u con con respuesta inesperada %lu (esperado %lu a %lu)", //IPNAT_TCP_BLOCKED_INGRESS_BAD_ACK
	"Iniciar el ping al host especificado", //htsc_pingt_p
	"Comprobar ahora", //tf_CKN
	"Comprobar el estado de la impresora", //wprn_cps
	"(GMT+06:00) Ekaterimburgo", //up_tz_45
	"De forma predeterminada, el router determina automáticamente si la conexión existente es xDSL, una red de relé de marco u otro tipo de conexión (como un módem por cable o Ethernet), y muestra el resultado como <span class='option'>Detectada xDSL o red de relé de marco</span>. Si dispone de una conexión de red poco habitual en la que se conecta a través de xDSL pero establece los parámetros \"Estática\" o \"DHCP\" en la configuración de WAN, al definir esta opción en <span class='option'>xDSL u otra red de relé de marco</span> se garantiza que el router reconocerá que debe controlar el tráfico de una forma algo diferente para proporcionar un rendimiento óptimo. Tras seleccionar la opción <span class='option'>xDSL u otra red de relé de marco</span>, la velocidad de subida medida se suele reducir con respecto a los valores registrados anteriormente en dichas conexiones, pero se obtienen mejores resultados.", //help84
	"Está disponible la versión %d.%d del firmware", //GW_FW_NOTIFY_FIRMWARE_AVAIL
	"Paquetes RX caídos", //ss_RXPD
	"Se ha bloqueado el sitio Web %S para %s", //WEB_FILTER_LOG_URL_BLOCKED_MAC
	"El puerto trigger ALG no pudo asignar sesión para el paquete TCP desde %v:%u hasta %v:%u", //IPPORTTRIGGERALG_TCP_PACKET_ALLOC_FAILURE
	"Nota: puede que también necesite suministrar un nombre de host. Si no dispone de esta información o la desconoce, póngase en contacto con su ISP.", //wwa_note_hostname
	"Acción", //ai_Action
	"Restablecer configuración en valores de fábrica", //RUNTIME_CONFIG_RESET_CONFIG_TO_FACTORY_DEFAULTS
	"No se ha detectado ninguna impresora", //sps_nopr
	"Horas", //gw_hours
	"Vie.", //_Fri
	"Impresión LPD/LPR", //tps_lpd
	"Actualización del firmware", //tf_FWUg
	"10 Mbps", //anet_wp_0
	"Battlefield 1942", //gw_gm_4
	"Estas dos opciones seleccionan alguna variante de las normas de seguridad del acceso protegido Wi-Fi (WPA), publicadas por la Wi-Fi Alliance. El <span class='option'>modo WPA</span> delimita aún más la variante que debe utilizar el router.", //help373
	"Ajuste del horario de verano", //tt_dsoffs
	"Asignar automáticamente una clave de red (recomendado)", //wwz_auto_assign_key
	"Doom 3", //gw_gm_15
	"Si desea información sobre las características de seguridad que admiten sus adaptadores inalámbricos, consulte la documentación de los adaptadores.", //wwl_s3_note_1
	"Haga clic en <strong>Guardar</strong> para añadir un programa completado a la lista siguiente.", //hhts_save
	"Detección automática", //at_Auto
	"Pings enviados", //tsc_pingt_msg100
	"No funciona la red PPP", //IPPPPIPCP_PPP_LINK_DOWN
	"Tipo de dirección", //aa_AT
	"Ubi.com", //gw_gm_71
	"Paso 3 - Seleccione el equipo al que se aplica esta directiva", //aa_wiz_s1_msg3
	"BigPond dejó de funcionar, consultar registro para más detalles", //BIGPOND_FAILED
	"Tiempo entre actualizaciones periódicas para el DNS dinámico, si su dirección IP dinámica no ha cambiado. El tiempo de espera se expresa en horas.", //help898
	"Dirección IP de servidor PPTP", //bwn_PPTPSIPA
	"Enrutamiento", //_routing
	"Cree una lista de direcciones MAC a las que quiera permitir o denegar el acceso a su red", //hham_intro
	"Registrador interno WPS no ha recibido ninguna solicitud desde ninguna estación inalámbrica en 2 minutos y se ha detenido.", //WIFISC_IR_REGISTRATION_FAIL_3
	"La opción de filtro entrante es un método avanzado de control de datos recibidos desde internet. Con esta característica puede configurar reglas de filtrado de datos entrantes que controla los datos basados en un rango de dirección IP.", //ai_intro_1
	"Paso 2: Seleccionar la zona horaria.", //wwa_title_s2
	"(GMT+11:00) Vladivostok", //up_tz_69
	"MSCHAP ha enviado respuesta de autentificación al puerto.", //IPMSCHAP_AUTH_RESULT
	"Los parámetros actuales del sistema pueden guardarse como un archivo en el disco duro local. El archivo guardado o cualquier otro archivo de configuración guardado y creado por el dispositivo puede cargarse en la unidad.", //tss_intro2
	"Si escoge esta opción, el router encuentra de forma automática el canal con menor interferencia y lo usa para la red inalámbrica. Si inhabilita esta opción, el router usa el canal que especifique en la opción <span class='option'>Canal inalámbrico</span>.", //help354
	"(GMT-03:00) Buenos Aires, Georgetown", //up_tz_19
	"Debe introducir primero el nombre de un archivo de configuración.", //ta_alert_5
	"Broadcast siempre", //bd_DAB
	"WPA-Enterprise", //_WPAenterprise
	"El control de acceso a Internet ha descartado el paquete de %v:%u[%s] a %v:%u (protocolo %u)", //GW_INET_ACCESS_DROP_ACCESS_CONTROL_MAC
	"Impresora", //sps_pr
	"(GMT+02:00) Harare, Pretoria", //up_tz_34
	"Clave precompartida", //_psk
	"DNS dinámico", //_dyndns
	"Denegar", //_deny
	"Bloqueado el paquete entrante TCP desde %v:%u hasta %v:%u porque %s no es permitido en estado %s", //IPNAT_TCP_BLOCKED_INGRESS_UNEXP_FLAGS
	"Tiempo máximo de inactividad", //help276
	"a", //_to
	"IP", //aa_AT_0
	"Dic", //tt_Dec
	"Se ha iniciado la directiva %s; el acceso a Internet para todos los sistemas no especificados ha cambiado a: %s", //GW_INET_ACCESS_POLICY_START_OTHERS
	"(GMT+12:00) Magadán", //up_tz_75
	"(GMT+12:00) Fiji, Kamchatka, Islas Marshall", //up_tz_72
	"Sin respuesta del host, intentándolo de nuevo...", //tsc_pingt_msg11
	"¿Está seguro de que desea eliminar esta entrada?", //up_ae_de_1
	"Esta parte de la pantalla continuamente se actualiza para mostrar todos los ordenadores habilitados con DHCP y los dispositivos conectados al lado LAN de su router. El 'rango'de detección está limitado al rango de direcciones configurado en el servidor DHCP. Los ordenadores que tienen una dirección fuera de este rango no se mostrarán. Si el cliente DHCP (es decir, un ordenador configurado para 'Obtener automáticamente una dirección') proporciona un nombre de host, este también se mostrará. Cualquier ordenador o dispositivo que tenga una dirección IP estática que se encuentre dentro del 'rango'de detección puede también mostrarse aquí; sin embargo, no figurará su nombre de host:", //help781
	"Entre la dirección MAC del ordenador.", //help161_2
	"6:00 PM", //tt_time_19
	"Utilice la dirección MAC del cliente para autorizar el acceso a la red a través del punto de acceso.", //am_intro
	"Número de fallos en la transmisión que causan la pérdida de un paquete.", //help811
	"Medio", //aw_TP_1
	"(GMT) Casablanca, Monrovia", //up_tz_24
	"Se han enviado los detalles de la autentificación MSCHAP al autentificador.", //IPMSCHAP_AUTH_SENT
	"Use esta opción para ver los clientes inalámbricos que están conectados a su router inalámbrico.", //sw_intro
	"El protocolo de impresión LPD/LPR usa una dirección IP y un nombre de cola fijas para comunicarse con su impresora.", //tps_lpd1
	"y", //help257
	"El enrutador se volverá a programar utilizando el archivo firmware descargado. Por favor, espere <span id='show_sec'></span>&nbsp;segundos para que acabe este proceso; posteriormente, podrá acceder de nuevo a estas páginas Web.  Si presiona Actualizar o Atrás en su explorador puede que no se realice la operación.", //_upgintro
	"Cerrado: la conexión ya no está activa, pero la sesión se está rastreando por si todavía está pendiente la retransmisión de algún paquete.", //help819_8
	"(segundos)", //bws_secs
	"Bloqueado el paquete ICMP saliente (tipo de ICMP %u ) desde %v hasta %v", //IPNAT_ICMP_BLOCKED_EGRESS_PACKET
	"Redirección de Puertos", //PORT_FORWARDING
	"IP dinámica (DHCP)", //bwn_Mode_DHCP
	"Hora", //tt_Hour
	"Entre las direcciones IP de los servidores DNS. Deje en blanco el campo del servidor secundario si no lo usa.", //help290a
	"BigPond está cerrando la sesión", //BIGPOND_LOGGING_OUT
	"Si usted está teniendo problema al recibir los multicast streams desde Internet, asegúrese de que la opción de Multicast Streams está habilitada.", //hhan_mc
	"Servidor DNS primario", //_dns1
	"Servidor DNS IPv6 primario", //_dns1_v6
	"Herramientas", //_tools
	"Desconectado", //_sdi_s2
	"Puerto USB", //sps_usbport
	"Se produjo un error del sistema al asignar programación %s", //GW_SCHED_ALLOC_FAILED
	"Impide a todos los usuarios de la WAN el acceso a dicha capacidad. (Los usuarios de la LAN no se ven afectados por las reglas de filtro entrante.)", //help179
	"Habilitar BigPond:", //help262
	"Permitir", //_allow
	"Seleccione el nivel de los eventos que quiere ver.", //help798
	"Obtenida dirección IP mediante DHCP. La dirección IP es %v", //DHCP_CLIENT_GOT_LEASE
	"Velocidad de puerto WAN", //anet_wan_phyrate
	"Nota", //_note
	"Dest<br />puerto<br />inicio", //aa_FPR_c6
	"Puertos UDP a abrir", //help69
	"Tiempo de validez de DHCP", //bd_DLT
	"Lista de reglas de filtro entrante", //ai_title_IFRL
	"La interfaz LAN funciona.", //GW_LAN_INTERFACE_UP
	"REGISTROS", //_logs
	"Desactive el filtrado MAC", //am_FM_2
	"Enviando correo electrónico de registro tras la petición del administrador", //GW_LOG_EMAIL_ON_USER_REQUEST
	"El puerto al que se va acceder desde Internet.", //help21
	"Modo 802.11", //bwl_Mode
	"Modo de dirección", //bwn_AM
	"Servidor BigPond", //bwn_BPS
	"Introduzca la información suministrada por su proveedor de servicios de Internet (ISP).", //_ispinfo
	"Velocidad", //_rate
	"(GMT-07:00) Hora de las Rocosas (EE.UU./Canadá)", //up_tz_06
	"Éxito[M6]", //_success
	"Servicio de controles parentales centinela", //_bsecure_parental_serv
	"Establezca la conexión con nombre de usuario y contraseña (L2TP)", //wwa_set_l2tp_title
	"Mac OS X", //help342
	"Seleccione esta opción si su ISP requiriera utilizar una conexión PPPoE (Protocolo de punto a punto a través de Ethernet). Normalmente, los proveedores de DSL utilizan esta opción. Para obtener acceso a Internet, este método de conexión requiere la introducción de un <span class='option'>nombre de usuario</span> y una <span class='option'>contraseña</span> (suministrados por el proveedor de servicios de Internet).", //help265
	"El servidor SMTP (correo)%s está en la dirección IP %v", //GW_SMTP_EMAIL_RESOLVED_DNS
	"Pings perdidos.", //tsc_pingt_msg102
	"Puerto del servidor RADIUS", //bws_RSP
	"Intentando establecer una conexión PPPoE", //PPPOE_EVENT_CONNECT
	"Configuración de hora automática", //tt_auto
	"El subsistema PPTP está escaso de recursos. Puede verse afectada la conectividad.", //PPTP_EVENT_LOW_RESOURCES_TO_QUEUE
	"El túnel local 0x%04X de L2TP ha recibido un mensaje de control inesperado (ignorado)", //IPL2TP_TUNNEL_UNEXPECTED_MESSAGE
	"Neverwinter Nights", //gw_gm_34
	"5º", //tt_week_5
	"Más abajo figuran en detalla sus parámetros de seguridad inalámbrica. Imprima esta página, o anote la información en un papel, de forma que pueda configurar los parámetros correctamente en sus adaptadores de cliente inalámbricos.", //wwl_intro_end
	"Tabla de directivas", //aa_Policy_Table
	"Cofiguración de la hora", //tt_TimeConf
	"ninguno", //_none
	"Paso 2: Seleccionar la programación", //_aa_wiz_s3_title
	"Frase secreta que debe coincidir con el servidor de autentificación.", //help392
	"Enviando correo electrónico de registro siguiendo programación temporal", //GW_LOG_EMAIL_ON_SCHEDULE
	"Seleccione la zona horaria adecuada para su ubicación. Esta información es necesaria para configurar las opciones basadas en la hora para el router.", //wwa_intro_s2
	"Dirección IP de puerta de enlace PPTP", //_PPTPgw
	"Se ha tenido acceso al sitio Web %S desde %v", //WEB_FILTER_LOG_URL_ACCESSED
	"MMS ALG rechazó el paquete de %v:%u a %v:%u", //IPMMSALG_REJECTED_PACKET
	"Configuración inalámbrica", //_wirelesst
	" Hay dos formas de configurar su conexión a internet: puede usar el asistente de conexión a internet basado en web, o puede configurar manualmente la conexión.", //int_intro
	"Acceso denegado al sistema LAN con la dirección MAC %m", //GW_LAN_ACCESS_DENIED
	"Jedi Knight II: Jedi Outcast", //gw_gm_26
	"Paquete GRE de entrada bloqueado de %v a %v", //PPTP_ALG_GRE_BLOCKED_INGRESS
	"(GMT+01:00) África central occidental", //up_tz_30
	"Starcraft", //gw_gm_49
	"Programación", //_sched
	"No se pudo montar dispositivo FAT", //IPFAT_MOUNT_FAILED
	"KALI", //gw_gm_75
	"Aquí se muestran los números de versión del firmware actualmente instalado en su router y la más reciente actualización disponible.", //help883
	"Cargando archivo de configuración; por favor, espere.", //ta_alert_6
	"Iniciada directiva %s; el acceso a Internet para la dirección IP %v ha cambiado a %s", //GW_INET_ACCESS_POLICY_START_IP
	"Muestra la hora actual del router. Si no es correcta, use las opciones siguientes para configurar la hora correctamente.", //help841a
	"10:00 PM", //tt_time_23
	"Reglas de direccionamiento de puerto", //ag_title_4
	"WinMX", //gw_gm_68
	"Bloqueado el paquete TCP saliente desde %v:%u hasta %v:%u porque %s no es permitido en estado[M1] %s", //IPNAT_TCP_BLOCKED_EGRESS_UNEXP_FLAGS
	"Nombre de host", //help260
	"FIN Wait: el sistema cliente ha solicitado que cese la conexión.", //help819_4
	"Si todos los dispositivos inalámbricos que quiere conectar con este router pueden conectarse con el mismo modo de transmisión, puede mejorar el rendimiento escogiendo el modo 'Solo'. Si algunos dispositivos usan un modo de transmisión diferente, escoja el modo 'Mixto'.", //help357
	"TCP", //_TCP
	"Se ha recibido el desafío de autentificación de MSCHAP desde el puerto.", //IPMSCHAP_CHALLENGE_RECVD
	"UPnP (Universal Plug and Play) admite la funcionalidad plug and play peer-to-peer para los dispositivos de la red.", //anet_msg_upnp
	"Al hacer clic en el botón <span class=\"button_ref\">Liberar DHCP</span> se anula la asignación de la dirección IP del routerEl router no responderá a los mensajes IP del lado de la WAN hasta que haga clic en el botón <span class=\"button_ref\">Renovar DHCP</span> o encienda de nuevo el router. Haga clic en el botón <span class=\"button_ref\">Renovar DHCP</span> para que el router solicite una nueva dirección IP del servidor del ISP.", //help776
	"Seleccione el método de configuración para configurar su red inalámbrica", //KR49
	"Aquí se pueden activar o desactivar las ALG. Algunos protocolos y aplicaciones requieren un control especial de la carga IP para poder funcionar con la traducción de direcciones de red (NAT). Cada ALG ofrece un control especial para un protocolo o una aplicación específica. De forma predeterminada, existen varias ALG activadas para las aplicaciones comunes.", //help32
	"Asheron's Call", //gw_gm_3
	"El número de segundos de tiempo de inactividad hasta que el router considera terminada la sesión.", //help823
	"Dirección IP L2TP", //_L2TPip
	"Reiniciar el dispositivo", //_reboot
	"Has dos modos de añadir un dispositivo inalámbrico a su red inalámbrica:", //wps_p3_1
	"Paso 3: Insertar el CD del controlador de la impresora si se solicita", //wprn_intro5
	"Servicio de seguridad centinela", //_bsecure_security_serv
	"recibide en", //tsc_pingt_msg8
	"Unreal Tournament", //gw_gm_56
	"La sección Actualización del firmware se puede utilizar para actualizar al código de firmware más reciente a fin de mejorar la funcionalidad y el rendimiento.", //tf_intro_FWU
	"(GMT+08:00) Kuala Lumpur, Singapur", //up_tz_57
	"El servidor de actualización de firmware %s está en la dirección IP %v", //GW_FW_NOTIFY_RESOLVED_DNS
	"Puerto y dirección restringidos", //af_EFT_2
	"(GMT-12:00) Enewetak, Kwajalein", //up_tz_00
	"Los programaciones se usan con otras características para definir cuándo esas características son efectivas.", //hhts_intro
	"Autenticación", //_auth
	"El túnel local 0x%04X de L2TP se está desconectando", //IPL2TP_TUNNEL_DISCONNECTING
	"No se logró la sincronización de tiempo tras reintentarlo… abandonando", //NET_RTC_SYNCHRONIZATION_FAILED_AFTER_RETRIES
	"Versión del firmware", //sd_FWV
	"Lista de Reglas de programación", //tsc_SchRuLs
	"Activar la partición WLAN evita que los clientes inalámbricos asociados se comuniquen entre sí.", //KR58_ww
	"opcional", //YM98
	"Guardar configuración", //ta_SavConf
	"Dirección DNS secundaria", //wwa_sdns
	"Esta opción restaura todos los parámetros de configuración por defecto, tal como eran cuando adquirió el router. Cualquiera parámetro que no haya sido guardado se perderá. Si quiere guardar los parámetros de configuración del router, use la opción anterior Guardar parámetros", //help876
	"Esta opción usa el acceso protegido Wi-Fi con una clave precompartida (PSK)", //help380
	"Filtro de red", //_netfilt
	"Días", //gw_days
	"Entrar en el sistema", //li_Login
	"WAN ya está conectada", //WAN_ALREADY_CONNECTED
	"Sólo WPA2", //bws_WPAM_3
	"La dirección gateway %v no ha de ser la dirección de la interfaz buscada", //GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS
	"Se ha de especificar una contraseña", //GW_DYNDNS_PASSWORD_INVALID
	"Elemento del servidor virtual", //tool_admin_vsname
	"(GMT+06:00) Astana, Dhaka", //up_tz_50
	"IP estática", //static_PPPoE
	"Hora de inicio", //tsc_StrTime
	"Tiempo de ping más corto (en milisegundos)", //tsc_pingt_msg104
	"Error de ID de dispositivo de impresión", //wprn_iderr
	"Al seleccionar esta opción, se mostrarán los parámetros inalámbricos actuales para que configure el dispositivo inalámbrico manualmente", //wps_KR42
	"Tiempo de espera", //td_Timeout
	"Aplicar filtro Web", //_aa_apply_web_filter
	"Restaurar como No configurado", //resetUnconfiged
	"Juegos", //GAMING
	"8:00 AM", //tt_time_9
	"Paquete entrante bloqueado de %v a %v (protocolo IP %u)", //IPNAT_BLOCKED_INGRESS
	"La interfaz WAN funciona. Conexión a Internet establecida con dirección IP %v y puerta de enlace %v predeterminada", //GW_WAN_INTERFACE_UP
	"Dirección IP del router", //_ripaddr
	"Tiempo de espera", //sa_TimeOut
	"Bloqueado el paquete TCP saliente desde %v:%u hasta %v:%u con la secuencia inesperada %lu (esperado %lu a %lu)", //IPNAT_TCP_BLOCKED_EGRESS_BAD_SEQ
	"La interfaz LAN no funciona.", //GW_LAN_INTERFACE_DOWN
	"Dependiendo de si la conexión WAN está establecida actualmente, puede hacer clic en <span class='button_ref'>Conectar</span> para intentar establecer la conexión WAN o en <span class='button_ref'>Desconectar</span> para interrumpir la conexión WAN", //help778
	"Nombre de cola", //sps_qname
	"segundos", //_seconds
	"Registro eliminado por dirección IP %v", //GW_LOGS_CLEARED
	"Advertencia", //sl_Warning
	"Dirección del equipo", //aa_MAC
	"Seleccione esta opción si su dispositivo inalámbrico admite WPS (Wi-Fi Protected Setup)", //wps_KR51
	"Manual", //help274
	"Al usar un intervalo de guarda corto (400ns), puede aumentar el rendimiento. Sin embargo, también puede aumentarla  tasa de errores en ciertas instalaciones, debido a la sensibilidad aumentada a las reflexiones de radiofrecuencia.", //aw_sgi_h1
	"Bloqueado el paquete direccionado desde %v hasta %v", //IPSTACK_REJECTED_SOURCE_ROUTED_PACKET
	"Dirección DNS primaria", //wwa_pdns
	"Use esta opción para restaurar los parámetros de configuración del router previamente guardados.", //help834
	"Dom.", //_Sun
	"Número de dispositivos", //sto_no_dev
	"Para impedir que intrusos accedan a su red, el router asignará automáticamente seguridad (clave WEP o WPA) a su red.", //wwz_auto_assign_key2
	"Número de canales continuos espaciales", //bwl_NSS
	"(GMT-04:00) Caracas, La Paz", //up_tz_15
	"Una vez que haya encontrado el archivo que ha de usar, haga clic en el botón <span class='button_ref'>Cargar</span>, abajo, para empezar el proceso de actualización del firmware. Esta operación puede tardar un minuto o más.", //help880
	"Intentando conectar a servidor L2TP", //IPL2TP_TUNNEL_CONNECTING
	"Acti", //bwn_mici_guest_use_shareport
	"Tiempo sincronizado", //NET_RTC_SYNCHRONIZED
	"(GMT-06:00) Saskatchewan", //up_tz_10
	"Encendido", //_on
	"No está registrado, actualice el explorador", //NOT_LOGGED_IN_PLEASE_REFRESH
	"Paquete GRE de entrada bloqueado de %v a %v", //IPSEC_ALG_ESP_BLOCKED_INGRESS
	"Continuar", //ub_continue
	"Nombre de usuario o clave", //td_UNK
	"No se pudo montar dispositivo PV%d", //IPPMVM_MOUNT_FAILED
	"Rise of Nations", //gw_gm_42
	"La dirección LAN que quiere reser", //_1066
	"Toda la semana", //tsc_AllWk
	"Servidor virtual", //_virtserv
	"La opción Servidor virtual proporciona a los usuarios de Internet acceso a servicios de su LAN. Esta funcionalidad es útil para alojar servicios en línea como Servidores FTP, Web o de juegos. Para cada servidor virtual, defina un puerto público en su router para la redirección a una Dirección IP de LAN interna y a un puerto LAN.", //help2
	"Seleccione esta opción si desea que los registros se envíen por correo electrónico cuando estén llenos.", //help869
	"LCP define opciones locales: ACCM: %lx, ACFC: %u, PFC: %u, MRU: %u", //IPPPPLCP_SET_LOCAL_OPTIONS
	"Reiniciar el dispositivo", //ts_rd
	"IPSec ALG rechazó el paquete de %v:%u a %v:%u", //IPSEC_ALG_REJECTED_PACKET
	"Por favor, espere, resolviendo...", //tsc_pingt_msg3
	"Sistema inalámbrico con dirección MAC %m desconectado por motivo: %s", //GW_WIRELESS_DEVICE_DISCONNECTED
	"Radio inalámbrica", //sd_WRadio
	"Permitidos, Sitios Web - %s%s, Puertos - %s", //ALLOWED_WEB_SITES
	"BitTorrent", //gw_sa_1
	"UDP", //_UDP
	"Al poner un ordenador en la DMZ puede exponer a dicho ordenador a", //help166
	"La sección de control de acceso le permite para controlar el acceso (entrada y salida) de los dispositivos de su red. Use esta característica como controles parentales para otorgar acceso a sitios aprobados, limitar el acceso a web según horas o fechas, y/o bloquear el acceso a aplicaciones tales como utilidades o juegos peer-to-peer.", //help117
	"Tipo de conexión a internet con L2TP", //bwn_L2TPICT
	"El router automáticamente registra (guarda) los eventos de posible interés en su memoria interna. Si no hay suficiente memoria interna para todos los eventos, se borran los registros de los eventos más antiguos, pero se conservan los registros de los últimos eventos. La opción Registros le permite ver los registros del router. Usted puede definir qué tipos de eventos quiere ver y qué nivel de eventos. El router también admite servidor de registros del sistema (syslog) a fin de que pueda enviar los archivos de registro a un ordenador de su red que está ejecutando una utilidad de registro del sistema.", //help795
	"No", //_no
	"(GMT+09:30) Adelaida", //up_tz_63
	"Debe introducir primero el nombre de un archivo de firmware.", //tf_FWF1
	"(GMT+10:00) Brisbane", //up_tz_65
	"Prioridad", //_priority
	"La WAN ya está desconectada", //WAN_ALREADY_DISCONNECTED
	"Hay datos sin guardar en esta página. ¿Desea renunciar a ellos?", //up_jt_1
	"Acceso a Internet para todos los sistemas no especificados establecido en: %s", //GW_INET_ACCESS_INITIAL_OTHERS
	"Las direcciones IP de inicio y final son direcciones del lado WAN.", //hhai_ip
	"Esta opción se usa para abrir un puerto o", //as_intro_SA
	"Los test de ping envían los paquetes  'ping' para probar un ordenador que está en internet.", //tsc_pingt_mesg
	"(GMT+04:30) Kabul", //up_tz_44
	"Puede que tenga problemas al acceder a un servidor virtual utilizando su identidad pública (dirección IP del lado WAN de la puerta de enlace o su nombre DNS dinámico) desde un equipo de la LAN. Es posible que las solicitudes no realicen un bucle de retorno o que se le redirija a la página \"Prohibido\".", //help27
	"IPSec (VPN)", //as_IPSec
	"Admin", //_admin
	"eDonkey", //gw_gm_65
	"Para actualizar el firmware, localice el fichero de actualización en el disco duro local por medio del botón Examinar. Una vez haya encontrado el fichero que ha de utilizar, haga clic en el botón Cargar para iniciar la actualización del firmware.", //tf_intro_FWChB
	"Bloqueado", //BLOCKED
	"BigPond Cable (Australia)", //wwa_msg_bigpond
	"Habilitar la entrada a un servidor syslog", //help857
	"Close Wait: el sistema servidor ha pedido que cese la conexión.", //help819_5
	"Bajo", //aw_TP_2
	"Tiempo de espera para la autentificación", //help385
	"La configuración ha terminado!", //_setupdone
	"Iniciar sesión en el enrutador", //li_intro
	"El cliente SMTP no ha podido enviar el correo electrónico", //IPSMTPCLIENT_MSG_FAILED
	"Antes de ejecutar estos asistentes, asegúrese de que ha seguido todos los pasos presentados en la guía de instalación rápida incluida en el paquete.", //bwz_note_ConWz
	"Gnutella", //gw_gm_64
	"Modo de reconexión:", //help268
	"Ninguno bloqueado", //NONE_BLOCKED
	"Mayo", //tt_May
	"Tipo de conexión a internet con Big Pond", //bwn_BPICT
	"2:00 PM", //tt_time_15
	"Mar.", //_Tue
	"Borrar estadísticas", //ss_clear_stats
	"La hora de finalización se indica en el mismo formato que la hora de inicio. La hora se introduce en el primer cuadro y los minutos en el segundo. La hora de finalización se utiliza para la mayoría de las reglas, pero normalmente no se utiliza para los eventos de correo electrónico.", //help197
	"Las reglas de filtro se pueden usar con servidor virtual, direccionamiento de puerto o características de administración remota.", //ai_intro_3
	"Conexión WAN demasiado tiempo inactiva, por ello intentando desconectar", //GW_WAN_DISCONNECT_ON_INACTIVE
	"El usuario ha hecho pública la dirección %v DHCP", //DHCP_CLIENT_RELEASED_LEASE
	"Establezca la conexión de dirección IP estática", //wwa_set_sipa_title
	"(GMT+12:00) Auckland, Wellington", //up_tz_71
	"Los ALG proporcionan una gestión especial de la carga IP para algunos protocolos y aplicaciones a fin de que funcionen con traducción de la dirección de red (NAT). Si tiene problemas al usar cualquiera de estas aplicaciones, pruebe a habilitar y deshabilitar el correspondiente ALG.", //hhaf_alg
	"Seleccione esta opción si donde usted se encuentra se aplica el horario de verano.", //help843
	"Compruebe que hay una impresora conectada al puerto USB del enrutador.", //wprn_tt11
	"Estadísticas de tráfico", //_tstats
	"LCP establece opciones remotas: ACCM: %lx, ACFC: %u, PFC: %u, MRU: %u", //IPPPPLCP_SET_REMOTE_OPTIONS
	"Compruebe ahora en línea la última versión del firmware y del paquete de idioma", //tf_COLF
	"(GMT+01:00) Bruselas, Copenhague, Madrid, París", //up_tz_28
	"Mar", //tt_Mar
	"Registre solamente acceso Web", //_aa_allow_all
	"Conexión con nombre de usuario / contraseña (L2TP)", //wwa_wanmode_l2tp
	"Host DMZ", //_dmzh
	"El servidor %s de tiempo está en la dirección IP %v", //GW_TIME_RESOLVED_DNS
	"EAP (802.1x)", //bws_EAPx
	"Nombre de directiva", //aa_PolName
	"Para establecer esta conexión necesitará disponer de una lista completa de la información IP suministrada por su proveedor de servicios de Internet. Si tiene una conexión IP estática y no tiene esta información, póngase en contacto con su ISP.", //wwa_set_sipa_msg
	"Paso 1: Seleccionar nombre de directiva", //_aa_wiz_s2_title
	"PPTP conectado al servidor \'%s\' con ID 0x%04X", //PPTP_EVENT_TUNNEL_CONNECTED
	"No se ha localizado ningún interfaz de almacenamiento masivo USB compatible con WCN", //USB_LOG_STORAGE_NOT_FOUND
	"Se ha iniciado el dispositivo", //GW_INIT_DONE
	"IP dinámica", //carriertype_ct_0
	"Estos son los parámetros de la interfaz LAN (Local Area Network, red de área local) para el router. Los parámetros de la red de área local (LAN) del router están configurados a partir de la dirección IP y máscara de subred asignadas en esta sección. La dirección IP también se usa para acceder a la interfaz de gestión basada en web.", //help305
	"Impresión de puerto Raw TCP", //tps_raw
	"Puerto público", //av_PubP
	"Modo WPA:", //help374
	"PPTP ha recibido una petición de liberación de túnel desde la aplicación, ahora se cerrará el túnel.", //PPTP_EVENT_TUNNEL_CLEAR_DOWN_REQUEST
	"Haga clic sobre el icono <strong>Borrar</strong> para eliminar una regla", //hhac_delete
	"Sesión local 0x%04X de L2TP finalizando", //IPL2TP_SESSION_CLEAR_DOWN_REQUEST
	"Directiva", //aa_ACR_c2
	"Las solicitudes del equipo de la LAN no realizarán un bucle de retorno si el acceso a Internet está bloqueado a la hora de acceder. Para solucionar este problema, acceda al equipo de la LAN mediante su identidad del lado de la LAN.", //help29
	"(GMT-11:00) Midway Island, Samoa", //up_tz_01
	"Aplicación", //_app
	"Máscara de subred LAN no válida", //bln_alert_1
	"Estimando velocidad de interfaz WAN", //GW_WAN_RATE_ESTIMATOR_STARTED_ON_WAN
	"Cortafuegos &amp; Seguridad", //sl_FWandSec
	"Para mayor seguridad, se recomienda que deshabilite la opción de respuesta de ping WAN. A menudo usuarios maliciosos de internet usan los ping para localizar redes o PC activos.", //hhan_ping
	"NAT", //sa_NAT
	"Al acti", //help828
	"No se puede encontrar registro DNS para servidor SMTP (correo electrónico) %s", //GW_SMTP_EMAIL_FAILED_DNS
	"Número de paquetes caídos debido a colisiones de Ethernet (dos o más dispositivos que intentan usar un circuito Ethernet al mismo tiempo).", //help810
	"Wake On LAN", //_WOL
	"A petición", //bwn_RM_1
	"Ninguno: esta entrada se usa como un marcador de posición para posibles conexiones futuras.", //help819_1
	"Bloqueado mensaje de error de ICMP entrante (tipo de ICMP %u ) desde %v hasta %v por no existir ninguna conexión activa de TCP entre %v:%u y %v:%u", //IPNAT_TCP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"(GMT-04:00) Hora del Atlántico (Canadá)", //up_tz_14
	"Star Trek: Elite Force II", //gw_gm_51
	"Dirección IP del servidor", //td_SvAd
	"Puede entrar puertos en", //hhag_40
	"Los filtros entrantes pueden usarse para limitar el acceso a un servidor de su red a un sistema o grupo de sistemas. Las reglas de filtro pueden usarse con los servidores virtuales, los juegos o la administración remota. Cada filtro puede ser usado para", //help169
	"La cantidad de tiempo que un ordenador puede tener una dirección IP antes de que necesite reno", //help324
	"Realizar ping es una función de la utilidad de Internet que envía una serie de mensajes cortos a un ordenador de destino e informa de los resultados. Puede utilizarla para comprobar si un ordenador está funcionando y para obtener una idea de la calidad de la conexión en dicho ordenador, en función de la velocidad de las respuestas.", //htsc_intro
	"Partición WLAN", //KR4_ww
	"Los ordenadores (y otros dispositivos) conectados a su LAN también necesitan que su configuración TCP/IP sea 'DHCP' u 'Obtener automáticamente una dirección IP'.", //help317
	"Secuencias de multidifusión", //anet_multicast
	"Secuencias de multidifusión IPv4", //anet_multicast_v4
	"Secuencias de multidifusión IPv6", //anet_multicast_v6
	"Agregar nueva directiva", //_aa_wiz_s1_title
	"El módulo RTE 0x%04X del túnel local de L2TP se ha cerrado.", //IPL2TP_SHUTDOWN_COMPLETE
	"Last ACK: tiempo de espera hasta que una conexión que estaba en Close Wait se cierra completamente.", //help819_7
	"Seleccione el protocolo (por ejemplo, <code>TCP</code>).", //help9
	"Número de paquetes caídos al ser recibidos, debido a errores, colisiones o a las limitaciones de recursos del router.", //help809
	"Detectada portadora Ethernet de LAN", //GW_LAN_CARRIER_DETECTED
	"¿Está seguro de que desea eliminar todas las entradas de registro?", //sl_alert_1
	"Puerto trigger", //as_TPRange_b
	"1º", //tt_week_1
	"Si desea renunciar, pulse Aceptar.", //up_jt_3
	"Borrar", //_clear
	"Finalizando sesión 0x%04X de PPPoE", //PPPOE_EVENT_DISCONNECT
	"El registrador interno WPS ha fallado al añadir la estación inalámbrica %m, motivo: %s, err_code %u.", //WIFISC_IR_REGISTRATION_FAIL_2
	"IP estática", //_sdi_staticip
	"Dele a cada programación un nombre que sea significativo para usted. Por ejemplo, una programación de lunes a viernes de 3:00 pm a 9:00 pm, pueda llamarse 'después de la escuela '", //hhts_name
	"WAN", //WAN
	"Indique una contraseña para el usuario 'admin', quién tendrá pleno acceso a la interfaz de administración basada en la Web.", //help824
	"Los ordenadores que han obtenido una dirección IP del servidor DHCP del router figurarán en la lista de clientes DHCP. Seleccione un dispositivo de los del menú desplegable y haga clic sobre la flecha para añadir la dirección MAC de aquel dispositivo a la lista", //hham_add
	"Estadísticas de la WAN", //ss_WANStats
	"Intentando iniciar la conexión WAN bajo petición", //GW_WAN_CONNECT_ON_ACTIVE
	"Debe abandonar todos los cambios para definir una nueva programación.", //aa_sched_conf_1
	"Detenida directiva %s; el acceso a Internet para todos los sistemas no especificados ha cambiado a: %s", //GW_INET_ACCESS_POLICY_END_OTHERS
	"Lista de Reservas DHCP", //bd_title_list
	"Registro del Acceso Web", //_aa_logging
	"Bloqueado el mensaje de error ICMP entrante (tipo de ICMP %u ) desde %v hasta %v por no existir ninguna sesión activa para el protocolo %u entre %v y %v", //IPNAT_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"Nombre de usuario", //_username
	"eMule", //gw_gm_67
	"No se puede encontrar registro DNS para el servidor de tiempos %s", //GW_TIME_FAILED_DNS
	"Consulte la documentación proporcionada con el router para obtener las instrucciones de configuración de la impresora correspondientes a su sistema operativo.", //wprn_tt1
	"9:00 PM", //tt_time_22
	"Dirección IP", //help256
	"No se puede establecer la política de acceso a Internet para la dirección IP %v", //GW_INET_ACCESS_INITIAL_IP_FAIL
	"Detalles", //_aa_details
	"Permite aplicaciones que usan el protocolo Real Time Streaming para recibir el flujo de medios desde internet. QuickTime y Real Player son algunas de las aplicaciones más habituales que usan este protocolo.", //help36
	"Dirección IP y número de puerto de la aplicación del lado de la WAN.", //help817
	"PPPoE (nombre de usuario/clave de acceso)", //bwn_Mode_PPPoE
	"Permitir todos", //_allowall
	"Borrar la lista siguiente...", //awf_clearlist
	"Deberá reiniciar el enrutador antes de que tenga efecto la configuración guardada en una página anterior. Puede reiniciar ahora el enrutador con el botón 'Reiniciar' mostrado a continuación, o pulsar el botón 'Continuar' y realizar otros cambios.", //sc_intro_rb3
	"Puertos TCP a abrir", //help67
	"Quake 2", //gw_gm_37
	"Otros", //aa_AT_2
	"Paso 1: Establecer la clave de acceso.", //wwa_title_s1
	"Nombre del controlador", //tps_drname
	"Copiar los parámetros horarios del ordenador", //tt_CopyTime
	"El servidor de la sesión L2TP ha empezado a enviar números de secuencias para la sesión local 0x%04X", //IPL2TP_SEQUENCING_ACTIVATED
	"Reser", //bd_Reserve
	"MSN Messenger ALG rechazó el paquete desde %v:%u hasta %v:%u", //IPMSNMESSENGERALG_REJECTED_PACKET
	"La sección inalámbrica le permite para ver los clientes inalámbricos que están conectados a su router inalámbrico.", //help782
	"Dungeon Siege", //gw_gm_16
	"El direccionamiento de puertoss ALG no logró asignar la sesión para los paquetes UDP de %v:%u a %v:%u", //IPPORTFORWARDALG_UDP_PACKET_ALLOC_FAILURE
	"Modelo", //wprn_mod
	"Nota:", //help119
	"Silent Hunter II", //gw_gm_46
	"Active el filtrado MAC y PERMITA el acceso a la red a los ordenadores que figuran en la lista", //am_FM_3
	"Use esta información para configurar su ordenador para la impresión LPD/LPR.", //sps_lpd1
	"Configuración del sistema", //tss_SysSt
	"Restaurar la configuración desde el archivo", //ta_ResConf
	"Flash actualizada a configuración inalámbrica", //WCN_LOG_SAVE
	"Tipo de tráfico de firewall", //as_FPrt
	"Conexiones UDP", //help823_11
	"Cada día", //tsc_EvDay
	"Haga clic sobre el botón <span class='button_ref'>Borrar</span> para quitar la dirección MAC de la lista de filtrado MAC.", //ham_del
	"PPPoE", //_PPPoE
	"Se muestra porque ha conectado correctamente su nuevo router a internet", //wwa_intro_online1
	"Final del horario de verano", //tt_dstend
	"Regla de programa", //tsc_SchRu
	"No se logró el intento de autenticación de configuración para la dirección IP %v", //GW_AUTH_FAILED
	"Programaciones", //_scheds
	"(GMT+09:00) Irkutsk, Ulan Bator", //up_tz_56
	"Servidor DNS secundario", //_dns2
	"Servidor DNS IPv6 secundario", //_dns2_v6
	"Debe entrar un nombre de host o dirección IP", //tsc_pingt_msg2
	"Estas opciones se configuran automáticamente y sólo deben ser modificadas por usuarios avanzados.", //tps_apc1
	"El control de acceso a internet ha perdido un paquete desde %v:%u hasta %v:%u (protocolo %u)", //GW_INET_ACCESS_DROP_ACCESS_CONTROL_WITH_PORT
	"(GMT+05:45) Katmandú", //up_tz_48
	"Clave de acceso de admin", //_password_admin
	"Use esta sección para configurar el servidor DHCP integrado a fin de que asigne las direcciones IP a los ordenadores de su red.", //bd_intro_
	"Ddirección IP del servidor RADIUS", //help387
	"Permitida autenticación de configuración por dirección IP %v", //GW_AUTH_SUCCEEDED
	"Enviados detalles de autenticación CHAP a igual.", //IPPPPCHAP_AUTH_SENT
	"El servicio de controles paternos es un modo sencillo aunque efectivo de limitar el acceso a sitios Web ofensivos, ilegales o no recomendables. Este servicio protegerá a todos los PC u ordenadores Apple que se encuentren detrás de su enrutador y se actualiza siempre automáticamente en tiempo real. (No es necesario que lo descargue o indique sitios manualmente.) Este servicio es rápido y no ralentizará su red.", //_bsecure_parental_blurb
	"El asistente le guiará a través de los pasos que se han de realziar para añadir una nueva política para el control de acceso", //_aa_wiz_s1_msg
	"El número de paquetes recibidos por el enrutador.", //help807
	"(GMT+09:00) Seúl", //up_tz_61
	"Dirección IP de puerta de enlace de L2TP", //_L2TPgw
	"Error de autenticación MSCHAP: compruebe los datos de inicio de sesión.", //IPMSCHAP_AUTH_FAIL
	"Avanzado:", //help395
	"Una vez que disponga de la actualización del firmware en su ordenador, use esta opción para buscar el archivo y cargue la información en el router", //help888
	"Medal of Honor: juegos", //gw_gm_29
	"La regla se aplica a un flujo de mensajes cuya dirección IP del lado WAN no coincide con el rango establecido aquí.", //help95
	"Periodo de emisión de señales", //aw_BP
	"Deteniendo servicios WAN", //GW_WAN_SERVICES_STOPPED
	"TeamSpeak", //gw_gm_79
	"Seleccione un servidor horario de red para la sincronización. Puede escribir la dirección de un servidor horario o seleccionar uno de la lista. Si tiene problemas al usar un servidor, escoja otro.", //help850
	"Está alojando un servidor de web en un PC que tiene la dirección IP de LAN 192.168.0.50 y su ISP está bloqueando el puerto 80.", //help4
	"(GMT-03:00) Brasilia", //up_tz_18
	"Cuando usa el servidor virtual, el direccionamiento de puerto o la administración remota para abrir puertos específicos al tráfico de internet, puede estar aumentando la exposición de su LAN a los ciberataques de internet.", //help168a
	"PPTP ALG ha rechazado el paquete desde %v:%u hasta %v:%u", //PPTP_ALG_REJECTED_PACKET
	"Dirección del servidor SMTP", //te_SMTPSv
	"Battlefield 2", //gw_gm_84
	"El módulo RTE 0x%04X del túnel local L2TP está escaso de recursos.", //IPL2TP_LOW_RESOURCES
	"Haga clic sobre <strong>Añadir política</strong> para empezar a crear una regla. Puede cancelar el proceso en cualquier momento. Cuando haya terminado de crear una regla, ésta se añadirá a la <strong>Tabla de Política</strong>, abajo", //hhac_add
	"10/100 Mbps automático", //anet_wp_auto2
	"RTSP", //as_RTSP
	"Autenticación y seguridad", //_authsecmodel
	"MTU", //bwn_MTU
	"Steam", //gw_gm_72
	"WAN", //_WAN
	"Proxy IGMP mejorado", //anet_multicast_enhanced
	"Command and Conquer Generals", //gw_gm_8
	"WPA", //_WPA
	"Vuelva a introducir la contraseña o la clave suministrada por el proveedor de servicios. Si el proveedor de servicios DNS dinámico le ha suministrado una sola clave, introduzca dicha clave en los tres campos.", //help897
	"Bloqueado el paquete TCP entrante desde %v:%u hasta %v:%u con con respuesta inesperada %lu (esperado %lu a %lu)", //IPNAT_TCP_BLOCKED_INGRESS_BAD_SEQ
	"Respuesta de", //tsc_pingt_msg7
	"Ene", //tt_Jan
	"Battlefield Vietnam", //gw_gm_5
	"Wireless avanzado", //_adwwls
	"Pings recibidos", //tsc_pingt_msg101
	"Unreal", //gw_gm_55
	"PING WAN", //anet_wan_ping
	"Los parámetros <warn>WINS/NetBIOS no pueden conocerse desde internet en este modo internet; WINS no funcionará como se espera.</warn>", //GW_DHCP_SERVER_WINS_INCOMPATIBILITY_WARNING
	"Autentificación de dirección MAC", //bws_RMAA
	"Paso 2 - Seleccione una programación", //aa_wiz_s1_msg2
	"6:00 AM", //tt_time_7
	"Iniciado desde la WAN hasta la LAN.", //help822a
	"America's Army", //gw_gm_1
	"(GMT+03:00) Bagdad", //up_tz_37
	"Modo de seguridad", //bws_SM
	"(GMT+10:00) Hobart", //up_tz_68
	"Exactamente 64 caracteres, usando 0-9 y A-Z", //wwl_s4_intro_za3
	"Anterior", //_prev
	"Activar acceso a la web SharePort", //sto_http_1
	"El Asistente para instalación de la impresora requiere el protocolo de impresión del puerto TCP sin formato. Este protocolo está desactivado actualmente en el enrutador.", //wprn_foo1
	"Una red inalámbrica usa canales específicos del espectro inalámbrico para gestionar la comunicación entre clientes. Algunos canales de su área pueden interferir con otros dispositivos electrónicos. Escoja el canal más nítido para obtener el mejor rendimiento y alcance de su red inalámbrica.", //help355
	"Registrado", //aa_ACR_c6
	"Segundo secreto compartido del servidor RADIUS", //bws_2RSSS
	"Secreto compartido del servidor RADIUS:", //help391
	"p.m.", //_PM
	"Defina los rangos de las direcciones internet a los que se aplica esta regla. Para una única dirección IP, escriba la misma dirección en ambas casillas <span class='option'>Inicio</span> y <span class='option'>Final</span>. Se pueden introducir hasta ocho rangos. La casilla de verificación <span class='option'>Habilitar</span> le permite acti", //help174
	"Tiempo de espera excedido de PPPoE esperando conexión. No se logró la conexión.", //PPPOE_EVENT_DISCOVERY_TIMEOUT
	"Dispositivo %s, wsetting.wfc: archivo no encontrado", //WCN_LOG_NO_WSETTING
	"Error de papel", //psPaperError
	"Si deja esta opción sin marcar, está haciendo que el router ignore los comandos <code>ping</code> para la dirección IP WAN pública del router.", //anet_wan_ping_2
	"Para actualizar el firmware, siga estos pasos:", //help878
	"Registrado", //LOGGED
	"Manual", //bwn_RM_2
	"Secreto compartido del servidor RADIUS", //bws_RSSs
	"(GMT+04:00) Bakú, Tiflis, Yereván", //up_tz_43
	"RTSP ALG rechazó el paquete de %v:%u a %v:%u", //IPRTSPALG_REJECTED_PACKET
	"no puede borrarse o cambiársele el nombre porque se está utilizando.", //GW_SCHEDULES_IN_USE_INVALID_s2
	"Ayuda de Opciones avanzadas", //help1
	"Zona de juegos MSN", //gw_gm_73
	"Al hacer clic sobre cualesquiera de estos enlaces o botones, accederá a otro sitio web con información adicional.", //hhtsn_intro
	"Ping", //_ping
	"Velocidad de uplink manual", //at_UpSp
	"Paso 6 - Configuración de la conexión de acceso a web", //aa_wiz_s1_msg6
	"Dirección IP de PPTP", //_PPTPip
	"Un DTIM es una cuenta atrás que advierte a los clientes de la siguiente ventana para que estén atentos a los mensajes de emisión y multidifusión. Cuando el router inalámbrico ha almacenado los mensajes de emisión y multidifusión, envía el siguiente DTIM con un valor de intervalo DTIM. Los clientes inalámbricos detectan las balizas y están a punto para recibir los mensajes de emisión y multidifusión. El valor por defecto es 1. Los parámetros válidos están comprendidos entre 1 y 255.", //help185
	"Haga clic en este botón después de cambiar las opciones de registro para hacerlas efectivas y permanente.", //help799
	"(GMT-03:30) Terranova", //up_tz_17
	"Todos los detalles sobre la conexión a Internet y de red se muestran en esta página. La versión de firmware también se muestra aquí.", //sd_intro
	"Transferir", //tf_Upload
	"Segundo", //tt_Second
	"Esto hará que todos los parámetros inalámbricos se pierdan.", //wps_lost
	"Nota:", //help26
	"(GMT+02:00) Helsinki, Riga, Tallinn", //up_tz_35
	"Use esta sección para configurar su tipo de conexión a internet. Existen", //bwn_intro_ICS
	"Utilice esta sección para configurar su tipo de conexión a Internet. Existen varios tipos de conexión entre los que elegir: IP estática, DHCP, PPPoE, PPTP, L2TP y USB 3G. Si no está seguro del método de conexión, póngase en contacto con su proveedor de servicios de Internet.", //bwn_intro_ICS_3G
	"Utilice esta sección para configurar su tipo de conexión a Internet. Existen varios tipos de conexión entre los que elegir: IP estática, DHCP, PPPoE, PPTP, L2TP y DS-Lite. Si no está seguro del método de conexión, póngase en contacto con su proveedor de servicios de Internet.", //bwn_intro_ICS_v6
	"Si está activada, esta opción hará que el router mida automáticamente el ancho de banda de subida útil cada vez que se restablezca la interfaz WAN (tras un reinicio, por ejemplo).", //help81
	"Esta opción le permite guardar la configuración del router en un archivo de su ordenador. Asegúrese de que guarda la configuración antes de actualizar el firmware.", //help833
	"Enviado", //ss_Sent
	"Intervalo de actualización de la clave de grupo", //help378
	"Tribes of Vengeance", //gw_gm_80
	"Carga correcta", //_uploadgood
	"PIN", //KR38
	"El ejecutable de configuración buscará un controlador de impresora compatible en su ordenador. Si no lo encuentra, se le pedirá que introduzca el CD con el controlador que se la ha proporcionado con la impresora.", //wprn_s3c
	"El router sólo proporciona protección de firewall o al host DMZ. El router no direcciona un paquete TCP que no coincide con una sesión DMZ activa, a menos que sea un paquete de establecimiento de conexión(SYN). Excepto por esta protección limitada, el host DMZ está efectivamente 'fuera del firewall '. Quien quiera usar un host DMZ debe tener en cuenta que, para disponer dde mayor protección, deberá disponer de un firewall en ese sistema de host DMZ.", //haf_dmz_20
	"Recibido", //ss_Received
	"Marque esta opción para conectar a internet a través de cable de banda ancha de Telstra BigPond, en Australia. Telstra BigPond proporciona los valores para", //help263
	"Pruega GRATUITA de 30 días", //_bsecure_free_trial
	"Opciones para notificación de actualización de firmware", //tf_FUNO
	"GI corta", //aw_sgi
	"Tiempo que transcurre antes de que se le pida a un cliente que se vuelva a autentificar.", //help386
	"Existen", //help254_ict
	"Existen varios tipos de conexión entre los que elegir: IP estática, DHCP, PPPoE, PPTP, L2TP y USB 3G. Si no está seguro del método de conexión, póngase en contacto con su proveedor de servicios de Internet. Nota: si utiliza la opción PPPoE, necesitará asegurarse de que se elimina o desactiva todo el software de cliente PPPoE de sus ordenadores.", //help254_ict_3G
	"Elegir el método de filtrado", //_aa_wiz_s5_msg1
	"Comprobar la contraseña o clave", //td_VPWK
	"Need for Speed 3", //gw_gm_33
	"Age of Empires", //gw_gm_0
	"Filtro de dirección MAC", //_macfilt
	"Para usar esta característica, ha de disponer de una cuenta de DNS dinámico con uno de los proveedores que figuran en el menú desplegable.", //TA16
	"(compatibilidad para ciertos clientes DHCP)", //bd_DAB_note
	"Seleccione los tipos de eventos que quiere ver.", //help796
	"¿Desea reprogramar el dispositivo utilizando el archivo de firmware?", //tf_really_FWF
	"(GMT-07:00) Arizona", //up_tz_05
	"3:00 PM", //tt_time_16
	"Esta dirección de correo electrónico aparecerá como el remitente cuando usted reciba un archivo de registro o una notificación de actualización del firmware por medio del correo electrónico.", //help861
	"Seleccione el protocolo utilizado por el servicio.", //help19
	"Modo WAN DHCP", //bwn_DWM
	"ICMP", //_ICMP
	"Half Life", //gw_gm_22
	"Envío por correo electrónico del registro cuando esté completo o según programación", //help868
	"Frase secreta", //IPV6_TEXT24
	"5:00 AM", //tt_time_6
	"Haga clic sobre este botón para empezar a crear una nueva política de control de acceso.", //_501_12
	"Verifique <strong>Habilitar control de acceso</strong> si quiere establecer reglas que limiten el acceso a internet a determinados ordenadores de la LAN", //hhac_en
	"Configuración manual", //int_LWlsWz
	"Seleccionar velocidad de transmisión", //at_STR
	"Ago", //tt_Aug
	"Active el filtrado MAC y DENIEGUE el acceso a la red a los ordenadores que figuran en la lista", //am_FM_4
	"Paso 5 - Selección de filtros", //aa_wiz_s1_msg5
	"Control de acceso", //ACCESS_CONTROL
	"Error al actualizar el registro de DNS dinámico: %s. Compruebe la configuración. Desactivando DynDNS", //GW_DYNDNS_HERROR
	"Puertos para abrir", //sps_ports
	"Si no tiene la opción de servidor de NTP, aquí puede establecer manualmente la hora del su router o puede hacer clic en el botón <span class='button_ref'>Copiar los parámetros horarios del ordenador</span> para copiar la hora del ordenador que está usando. (Asegúrese de que la hora de ordenador es la correcta.)", //help851
	"Puede seleccionar un ordenador de la lista de clientes DHCP en el menú desplegable <strong> Nombre del ordenador </strong>, o puede escribir la dirección IP del ordenador de la LAN al que quiere abrir el puerto específico.", //hhag_20
	"Esta regla de equipo ya está en uso.", //aa_alert_7
	"Dirección IP del DMZ", //af_DI
	"Sitio de descarga disponible", //tf_ADS
	"Prueba de ping", //tsc_pingt
	"Ver niveles", //sl_VLevs
	"Cifrado", //wwl_enc
	"Una dirección MAC es un ID único asignado por el fabricante del adaptador de red.", //help151
	"Escoja un puerto para abrirlo a la gestión remota.", //hhta_pt
	"El control de acceso a Internet ha eliminado un paquete de %v:%u[%s] a %v:%u (protocolo %u)", //GW_INET_ACCESS_DROP_ACCESS_CONTROL
	"Acti", //te_EnAuth
	"STA con MAC (%m) WPS proceso cerrado", //WIFISC_AP_PROXY_PROCESS_CLOSE
	"Nombre del ordenador", //bd_CName
	"Se recomienda que use los parámetros por defecto si no tiene una red.", //help305rt
	"Contraseña no válida; vuelva a intentarlo.", //li_alert_3
	"Actualizando registro DNS dinámico al excederse el tiempo de espera", //GW_DYNDNS_UPDATE_TO
	"4º", //tt_week_4
	"Día", //tt_Day
	"Perdida portadora Ethernet de LAN", //GW_LAN_CARRIER_LOST
	"Cada regla puede <strong>Permitir</strong> o <strong>Denegar</strong> el acceso desde la WAN", //hhai_action
	"y cómo es el control implementado. Puede definir", //help121
	"Para establecer esta conexión necesitará disponer de un nombre de usuario y una contraseña de su proveedor de servicios de Internet. Si no tiene esta información, póngase en contacto con su ISP.", //wwa_msg_set_pppoe
	"Paquete ICMP entrante bloqueado (tipo de ICMP %u ) desde %v hasta %v", //IPNAT_ICMP_BLOCKED_INGRESS_PACKET
	"para mejorar la funcionalidad y el rendimiento.", //tf_intro_FWU2
	"Habilitar o deshabilitar rlas reglas definidas por medio de las casillas de verificación a la izquierda", //at_ESE
	"Los servicios de seguridad constituyen un excelente modo de proteger todos sus PC con un conjunto unificado de servicios que se gestionan desde cualquier explorador web. Incluye anti-virus, cortafuegos, detección de intrusiones, filtrado de contenidos, detección de Spam (correo masivo no deseado) y bloqueador de mensajes emergentes. Puede seleccionar algunos o todos los servicios a un precio bajo.", //_bsecure_security_blurb
	"Lista de clientes DHCP", //bd_DHCP
	"Introduzca la cuenta para enviar correo electrónico.", //help865
	"La clave WEP (Wired Equivalent Privacy) ha de cumplir una de las siguientes pautas:", //wwl_s4_intro_z1
	"Descargar", //help501
	"El ISP proporciona este parámetro, si es necesario. El valor puede ser igual que la dirección IP de gateway.", //help280
	"Conexión DHCP", //help775
	"Conectar", //_connect
	"activado BigPond", //GW_BIGPOND_INIT
	"Siempre", //_always
	"(minutos)", //_minutes
	"Puerto de firewall", //as_IPR_b
	"Empleo", //_aa_bsecure_employment
	"El control de acceso a Internet ha eliminado un paquete erróneo de %v a %v (protocolo %u)", //GW_INET_ACCESS_DROP_BAD_PKT
	"Dark Reign 2", //gw_gm_12
	"Hexen II", //gw_gm_25
	"Seleccione cuándo se inicia y cúando finaliza el horario de verano. Por ejemplo, supongamos que para el inicio del horario de verano selecciona Mes = 'Oct', Semana = '3', Día = 'Dom'y Hora = '2 am'. Esto equivale a decir: 'el horario de verano se inicia el tercer domingo de octubre a las 2:00 am'.", //help846
	"Seleccione una de las opciones de configuración de hora, Automático o Manual. No ambas", //tt_alert_1only
	"Gamespy Arcade", //gw_gm_76
	"Registro visualizado por dirección IP %v", //GW_LOGS_VIEWED
	"Cuando está habilitada WPA enterprise, el router usa EAP (802.1x) para autentificar los clientes por medio de un servidor remoto RADIUS.", //bws_msg_EAP
	"El registrador interno WPS ha iniciado %s el registro", //WIFISC_IR_REGISTRATION_INPROGRESS
	"Esta es una lista de todas las conversaciones activas entre ordenadores de la WAN y ordenadores de la LAN.", //hhsa_intro
	"Esta sección le permite guardar sus archivos de registro en un servidor syslog", //help856
	"Dir", //sa_Dir
	"Miembros de IGMP Multicast", //_bln_title_IGMPMemberships
	"L2TP (nombre de usuario/clave de acceso)", //bwn_Mode_L2TP
	"Jue.", //_Thu
	"Se ha detectado diferencia en PIN (2ª mitad)", //KR30
	"Beacons son paquetes que envía un router inalámbrico para sincronizar dispositivos inalámbricos. Especifique un valor de beacon period entre 20 y 1000. El valor por defecto es 100 milisegundos.", //help184
	"Escoja la opción mejor para su instalación.", //_worksbest
	"no disponible", //_unavailable
	"El sistema de archivos detectado no es compatible (FAT32,FAT16,FAT12)", //IPFAT_INCOMPATIBLE_FILESYS
	"Bloqueado el paquete entrante TCP desde %v:%u hasta %v:%u porque %s se recibió pero no hay ninguna conexión activa", //IPNAT_TCP_BLOCKED_INGRESS_NOT_SYN
	"(GMT-08:00) Hora del Pacífico (EE.UU./Canadá); Tijuana", //up_tz_04
	"Aplicar ahora los parámetros de registro", //sl_ApplySt
	"Desafío de autenticación CHAP recibido de igual.", //IPPPPCHAP_CHALLENGE_RECVD
	"En esta sección se añaden los sitios web que se usarán para el control de acceso.", //help141
	"Revocar", //bd_Revoke
	"Paso 1: Detectar la impresora", //wprn_intro3
	"Tiempo de conexión", //_conuptime
	"Compruebe que la impresora está encendida.", //wprn_tt4
	"La tecnología de red inalámbrica permite la comunicación desde cualquier lugar.", //help383
	"Sin respuesta del router al ping, se intentará de nuevo.", //tsc_pingt_msg6
	"Iniciado desde la LAN hasta la WAN.", //help821a
	"PPPoE ha recibido oferta de sesión", //PPPOE_EVENT_SESSION_OFFER_RECVD
	"Myth", //gw_gm_30
	"Si se considera un usuario avanzado y ya ha configurado un router antes, haga clic en <span class='button_ref'>Configuración manual </span> para introducir manualmente los parámetros.", //bi_man
	"Mixto (1020-5000, 689)", //help60
	"Puerto de admin remoto", //ta_RAP
	"BigPond (Australia)", //bwn_Mode_BigPond
	"El estado actual de la impresora provocará que la página de prueba dé error al imprimirse más tarde durante el proceso de instalación.", //wprn_cps2
	"Inicio del horario de verano", //tt_dststart
	"Cuando el protocolo es TCP, SPI verifica que los números de secuencia del paquete están dentro del rango válido para la sesión, y desecha los paquetes con una secuencia numérica no válida.", //help164_1
	"Ha pasado el tiempo de espera de autentificación MSCHAP; la autentificación ha fallado.", //IPMSCHAP_AUTH_TIMEOUT
	"Enviar correo electrónico ahora", //sl_emailLog
	"Parámetros de red inalámbrica", //bwl_title_1
	"Contraseña BigPond", //bwn_BPP
	"Actualizar", //sl_reload
	"Paso 1: Nombre su red inalámbrica", //wwl_title_s1
	"No se pudo montar la unidad", //IPDRIVE_MOUNT_FAILED
	"Asistente de configuración para la conexión a Internet", //int_ConWz
	"Permiso", //sto_permi
	"La opción <code>Revocar</code> está disponible para cuando la tabla de asignación está completa o casi completa, y es necesario disponer de espacio en la tabla para nuevas entradas y usted sabe que alguna de las asignaciones actuales ya no se necesitan. Al hacer clic sobre <code>Revocar</code>, cancela la asignación temporal para un determinado dispositivo de la LAN y deja libre una entrada de la tabla de asignación. Haga esto solo si el dispositivo ya no necesita la dirección IP asignada temporalmente, porque, por ejemplo, ya no está en la red.", //help329
	"Se ha desconectado el túnel local 0x%04X de L2TP", //IPL2TP_TUNNEL_DISCONNECTED
	"Filtro entrante de admin remota", //help830
	"MTU (Maximum Transmission Unit, unidad de transmisión máxima) es un parámetro que determina el tamaño máximo (en bytes) que pueden tener los paquetes que el router enviará a la WAN. Si los dispositivos de la LAN envían paquetes más grandes, el router los dividirá en paquetes más pequeños. Debería configurar este parámetro para que coincidiera con el MTU de la conexión a su ISP. Los valores habituales son 1.500 bytes para una conexión Ethernet y 1.492 bytes para una conexión PPPoE. Si el MTU del router es demasiado alto, los paquetes serán fragmentados en el flujo descendente. Si el MTU del router es demasiado bajo, el router fragmentará los paquetes sin que sea necesario, y en casos extremos es posible que no se puedan establecer algunas conexiones. En otros casos puede verse afectado el rendimiento de la red.", //help294
	"(GMT-02:00) Atlántico central", //up_tz_21
	"Fecha del último firmware", //tf_LFWD
	"BigPond ha iniciado sesión, estado=%d, respuesta del servidor=%s", //GW_BIGPOND_SUCCESS
	"Denegar todos", //_denyall
	"Clasificación automática", //at_AC
	"Estatus de visibilidad", //bwl_VS
	"En esta sección puede ver los dispositivos de la LAN que actualmente tienen direcciones IP asignadas de forma temporal.", //help327
	"Para completar el proceso de instalación, el asistente iniciará ahora un archivo ejecutable en el equipo.", //wprn_s2a
	"(horas)", //td_
	"El concentrador de acceso PPTP remoto es demasiado lento para responder. Puede haber problemas de conectividad.", //PPTP_EVENT_TUNNEL_WINDOW_TIMEOUT
	"Potencia de transmisión", //aw_TP
	"Tipo de conexión a internet con dirección IP estática", //bwn_SIAICT
	"Algunas aplicaciones como los juegos de Internet, la videoconferencia, la telefonía por Internet y otras, requieren varias conexiones. Estas aplicaciones tienen dificultades para trabajar a través del NAT (Traducción de direcciones de red). Esta sección se utiliza para abrir varios puertos o un rango de puertos en el router y redirigir los datos a través de esos puertos a un PC único de la red. Puede introducir los puertos en diversos formatos", //help57
	"Habilitar el horario de verano.", //tt_dsen2
	"Desconectando (espere, por favor...)", //_sdi_s5
	"Fabricante", //wprn_man
	"2:00 AM", //tt_time_3
	"(GMT-03:00) Groenlandia", //up_tz_20
	"RIP ha rechazado la ruta %v del peer router %v por los bajos recursos del sistema", //RIP_LOW_RESOURCES
	"Nombre del servicio", //help266
	"Conectado", //CONNECTED
	"Si su ISP ha asignado una dirección IP fija, escoja esta opción. El ISP proporciona los valores para los campos siguientes:", //help265_5
	"Día(s)", //tsc_Days
	"(GMT-05:00) Indiana (Este)", //up_tz_13
	"General", //sd_General
	"UPnP ayuda a otros hosts UPnP de la LAN a interoperar con el router. Deje la opción UPnP habilitada mientras la LAN tiene otras aplicaciones UPnP", //hhan_upnp
	"Consulte al administrador de sistemas de la red corporativa si su cliente de VPN admite NAT transversal.", //help35
	"La dirección IP del sistema en su red interna que proporcionará el servicio virtual, por ejemplo <code>192.168.0.50</code>.", //help18
	"Asistente de configuración de la impresora", //bwz_psw
	"Fecha y hora", //tt_DaT
	"Los programaciones pueden crearse para que se cumplan las reglas. Por ejemplo, si quiere restringir el acceso web de lunes a viernes desde 3 pm hasta 8 pm, puede crear una programación escogiendo Lun, Mar, Mier, Jue y Vier y escribir 3 pm para la hora de inicio y 8 pm para la hora de fin.", //help190
	"SYN enviado: uno de los sistemas está intentando iniciar una conexión.", //help819_2
	"Tiempo máximo de inactividad", //bwn_MIT
	"Asígnele a cada regla un <strong>Nombre</strong> que sea significativo para usted", //hhai_name
	"Envío por correo electrónico del registro cuando esté completo o según programación", //te__title_EmLog
	"(GMT+05:30) Calcuta, Chennai, Bombay, Nueva Delhi", //up_tz_47
	"SMTP ha fallado durante el diálogo remitente/destinatario", //IPSMTPCLIENT_DIALOG_FAILED
	"Haga clic sobre el botón<strong>Borrar</strong> para eliminar la dirección MAC de la lista de filtrado MAC.", //hham_del
	"Si su proveedor de servicios de Internet no aparece en la lista o no sabe quién es, seleccione el tipo de conexión a Internet que aparece a continuación:", //wwa_msg_ispnot
	"Número de paquetes que han caído al ser enviados, debido a errores, colisiones o a las limitaciones de recursos del router.", //help808
	"Intentando establecer una conexión PPTP.", //PPTP_EVENT_TUNNEL_ESTABLISH_REQUEST
	"Permite que los ordenadores de la LAN utilicen Microsoft Windows Messenger (el cliente de mensajería de Internet que se suministra con Microsoft Windows) y MSN Messenger. El SIP ALG también se debe activar cuando se activa el ALG de Windows Messenger.", //help37
	"Solicitado reinicio para WCN", //WCN_LOG_REBOOT
	"No se logró la conexión PPTP. Comprobar detalles de servidor PPTP remoto.", //PPTP_EVENT_TUNNEL_CONNECT_FAIL
	"Anchura de canal", //bwl_CWM
	"(GMT-05:00) Hora del este (EE.UU./Canadá)", //up_tz_12
	"Cancelar", //_cancel
	"Activar ULA", //IPV6_ULA_TEXT02
	"Habilitar DMZ", //af_ED
	"(GMT+03:00) Kuwait, Riad", //up_tz_38
	"Intervalo DTIM", //aw_DI
	"(GMT+02:00) Atenas, Estambul, Minsk", //up_tz_31
	"Haga clic sobre el icono <strong>Eliminar</strong> de la lista de reglas para eliminar una regla.", //hhai_delete
	"La opción de servidor virtual le permite definir un puerto público de su router para el redireccionamiento a una dirección IP de la LAN interna y al puerto privado de la LAN, si se requiere. Esta característica es útil para alojar servicios en línea, como FTP o servidores eeb.", //av_intro_vs
	"La sección de parámetros del cortafuegos es una característica avanzada que se utiliza para permitir o denegar que el tráfico pase a través del dispositivo. Funciona del mismo modo que los filtros IP con parámetros adicionales. Puede crear más reglas detalladas para el dispositivo.", //av_intro_if
	"Intentando volver a conectar la conexión WAN siempre activada", //GW_WAN_RECONNECT_ALWAYS_ON
	"Clave de acceso de seguridad inalámbrica", //wwl_WSP
	"Entrada", //INGRESS
	"Restringido", //RESTRICTED
	"Use este tipo de conexión a internet si su proveedor de servicios internet (ISP) no le proporciona la información de dirección IP y/o un nombre de usuario y clave de acceso.", //bwn_msg_DHCPDesc
	"El número de puerto utilizado para conectarse al servidor de autenticación.", //help390
	"La activación del aislamiento de L2 (capa 2) impide que los clientes inalámbricos asociados se comuniquen entre sí.", //KR58
	"Vuelva a escribir la contraseña asociada a la cuenta.", //help867
	"Intentando iniciar la conexión WAN siempre activada", //GW_WAN_CONNECT_ALWAYS_ON
	"RTSP ALG rechazó paquete desde %v:%u hasta %v:%u con el puerto RTP impar %u", //IPRTSPALG_REJECTED_ODD_RTP_PACKET
	"Campos de direccionamiento de puerto", //help60f
	"Counter Strike", //gw_gm_10
	"(minutos, 0=infinito)", //bwn_min
	"Mes", //tt_Month
	"Fecha de firmware actual", //tf_CFWD
	"Red avanzada", //_advnetwork
	"Tipo de conexión a internet con PPPOE", //bwn_PPPOEICT
	"Puerto del servidor RADIUS:", //help389
	"Seleccione la hora de ajuste, si donde usted se encuentra se aplica el horario de verano.", //help844
	"4:00 PM", //tt_time_17
	"L2TP (Layer Two Tunneling Protocol) usa una red privada virtual para conectar con el ISP. Este método de conexión requiere que usted introduzca un <span class='option'>Nombre de usuario</span> y una <span class='option'>Clave de acceso</span> (proporcionados por su proveedor de servicios internet) para obtener el acceso a internet.", //help284
	"Sistema inalámbrico con dirección MAC %m asociada", //GW_WIRELESS_DEVICE_ASSOCIATED
	"Segunda autentificación de la dirección MAC", //bws_2RMAA
	"SIP", //as_SIP
	"SysLog", //help704
	"El registrador interno WPS ha fallado al añadir la nueva estación, motivo %s", //WIFISC_IR_REGISTRATION_FAIL_1
	"(GMT) Hora de Greenwich: Dublín, Edimburgo, Lisboa, Londres", //up_tz_25
	"Con la regla de aplicación del ejemplo anterior activada, el router abrirá un rango de puertos (6000-6200) al tráfico entrante procedente de Internet cada vez que un ordenador de la red interna inicie una aplicación que envíe datos a Internet con un puerto del rango 6500-6700.", //help55
	"La conexión inalámbrica funciona", //GW_WLAN_LINK_UP
	"Habilitar relé DNS", //bln_EnDNSRelay
	"Regla de filtro de entrada", //ai_title_IFR
	"PPTP", //_PPTP
	"Ambos", //_both
	"(GMT+03:00) Nairobi", //up_tz_40
	"Desconecte y vuelva a insertar el cable USB de la impresora.", //wprn_tt8
	"Deshabilitar soft reset", //tps_dsr
	"Otro", //at_Prot_1
	"Esta opción reinicia el router. Resulta útil para reiniciar cuando no está cerca del dispositivo.", //help875
	"Parámetros de filtro de sitios web", //awsf_p
	"exactamente 5 o 13 caracteres alfanuméricos.", //wwl_s4_intro_z2
	"Para configurar esta conexión necesita que su proveedor de servicios internet le haya proporcionado un nombre de usuario y una clave de acceso, así como una dirección IP L2TP. Si no tiene esta información, contacte con su ISP.", //wwa_set_l2tp_msg
	"(GMT+04:00) Abu Dabi, Muscat", //up_tz_42
	"Error", //_error
	"Dest IP<br />final", //aa_FPR_c4
	"Habilitar servidor NTP", //tt_EnNTP
	"La dirección IP de la LAN no es válida, dirección IP en rango del servidor DHCP", //network_dhcp_ip_in_server
	"Para actualizar el firmware, su PC debe tener una conexión por cable con el router. Entre el nombre del archivo de actualización del firmware y haga clic en el botón Cargar.", //tf_msg_wired
	"Establezca la conexión con nombre de usuario y contraseña (PPPoE)", //wwa_title_set_pppoe
	"Asegúrese de que la programación está definida como <code>Always</code>", //help10
	"Para circunstancias especiales se dispone de otras opciones.", //bwl_CWM_h2
	"Comprobación en línea", //help884
	"Reiniciando", //rb_Rebooting
	"Time Wait: tiempo de espera hasta que una conexión que estaba en FIN se cierra completamente.", //help819_6
	"9:00 AM", //tt_time_10
	"Esta sección muestra las reglas de programación actualmente definidas. Una regla de programación puede cambiarse haciendo clic en el icono Modificar, o eliminarla haciendo clic en el icono Eliminar. Cuando hace clic el icono Modificar, el elemento se destaca, y la sección 'Modificar regla de programación 'se activa.", //help199
	"Un método de conexión en el que su ISP le asigna su dirección IP cuando el enrutador solicita una al servidor del ISP. Algunos ISP le exigirán que efectúe determinadas configuraciones en su parte antes de que su enrutador se pueda conectar a Internet.", //help259
	"Configuración ALG (Application Level Gateway)", //af_algconfig
	"Cliente PPTP.", //wwa_msg_pptp
	"Segunda dirección IP del servidor RADIUS", //bws_2RIPA
	"Paso 3: Seleccione equipo", //_aa_wiz_s4_title
	"Nota: Puede tener que proporcionar un nombre de servicio. Si no lo sabe con certeza, contacte con su ISP.", //wwa_note_svcn
	"Detectada xDSL u otra red de relé de marco", //help85
	"El filtro de puerto de acceso a internet ha perdido un paquete desde %v:%u hasta %v:%u (protocolo %u)", //GW_INET_ACCESS_DROP_PORT_FILTER_WITH_PORT
	"Estado de BigPond", //sd_BPSt
	"(GMT+06:00) Almaty", //up_tz_49
	"World of Warcraft", //gw_gm_62
	"BigPond ha cerrado la sesión", //BIGPOND_LOGGED_OUT
	"Notificación por correo electrónico de una versión más reciente del firmware", //tf_EmNew
	"No se puede establecer la política de acceso a Internet para la dirección MAC %m", //GW_INET_ACCESS_INITIAL_MAC_FAIL
	"Dirección MAC", //help303
	"No aparece en la lista o se desconoce", //wwa_selectisp_not
	"Bloqueado el paquete TCP saliente desde %v:%u hasta %v:%u con respuesta inesperada %lu (esperado %lu a %lu)", //IPNAT_TCP_BLOCKED_EGRESS_BAD_ACK
	"La regla se aplica a un flujo de mensajes cuya dirección e IP del lado LAN se encuentra en el rango establecido aquí.", //help94
	"Xbox Live", //gw_gm_70
	"Se ha eliminado el paquete ICMP de %v a %v porque el encabezado de paquete no es identificable", //IPNAT_ICMP_UNABLE_TO_HANDLE_HEADER
	"FTP", //_FTP
	"Filtrado NAT Endpoint", //_neft
	"Administración", //ta_A12n
	"BigPond ha cerrado la sesión", //GW_BIGPOND_LOGOUT
	"Una regla de aplicación permite abrir uno o varios puertos en el router cuando este detecta el envío de datos a Internet en un puerto o rango de puertos de \"activación\". La regla de aplicación se aplica a todos los ordenadores de la red interna.", //help46
	"Compruebe a menudo el registro para detectar el uso de redes no autorizadas.", //hhsl_intro
	"Herramientas de ayuda", //help770
	"Para establecer esta conexión necesitará disponer de un nombre de usuario y una contraseña de su proveedor de servicios de Internet. Necesitará también la dirección IP de PPTP. Si no tiene esta información, póngase en contacto con su ISP.", //wwa_msg_set_pptp
	"No se puede encontrar registro DNS para el servidor de actualización de firmware %s", //GW_FW_NOTIFY_FAILED_DNS
	"Rainbow Six: Raven Shield", //gw_gm_40
	"El router usa el protocolo IGMP para soportar la multidifusión eficiente: transmisión de contenido idéntico, como multimedia, desde un origen hasta", //bln_IGMP_title_h
	"Use <strong>802.11d</strong> sólo para países en los que se requiere.", //hhaw_11d
	"De lo contrario, haga clic en Cancelar y en clic Guardar parámetros.", //up_jt_2
	"Iniciada directiva %s; el acceso a Internet para dirección MAC %m cambiado a: %s", //GW_INET_ACCESS_POLICY_START_MAC
	"Elija esta opción si su conexión a Internet requiere un nombre de usuario y una contraseña para navegar por la red. La mayoría de los módems DSL utilizan este tipo de conexión.", //wwa_msg_pppoe
	"Suponga que configur el servidor DHCP para gestionar direcciones desde 192.168.0.100 a 192.168.0.199. Esto significa que desde 192.168.0.3 hasya 192.168.0.99 y  desde 192.168.0.200 hasta 192.168.0.254 NO están gestionadas por el servidor DHCP. Los ordenadores o dispositivos que usan direcciones de estos rangos se han de configurar manualmente. Suponga que tiene un ordenador como servidor web que tiene la dirección manualmente configurada 192.168.0.100. Puesto que se encuentra dentro del 'rango gestionado', asegúrese de crear una reserva para esta dirección y hágala coincidir con el ordenador pertinente (vea <a href='#Static_DHCP'>Static DHCP Client</a> más abajo)", //help323
	"La cuenta \"admin\" puede acceder a la interfaz de gestión. El administrador tiene acceso de lectura/escritura y puede cambiar las contraseñas.", //ta_intro1
	"3º", //tt_week_3
	"Servidor DHCP", //_dhcpsrv
	"IP dinámica", //Dynamic_PPPoE
	"Habilitar:", //help102
	"WINS/NetBIOS no puede funcionar en este modo dados los parámetros de conexión a internet.", //GW_DHCP_SERVER_WINS_MODE_INVALID
	"Bits a 1 en la máscara especifica qué bits de la dirección IP han de coincidir.", //help107
	"Servidores de WON", //gw_gm_69
	"Filtrado", //aa_ACR_c5
	"Puede asignar un nombre a cada ordenador al que se le asigne una dirección IP reservada. De esta forma podrá realizar un seguimiento de los ordenadores que se han asignado de este modo.", //help345
	"Compruebe en el menú desplegable <strong>Nombre de aplicación</strong> la una lista de tipos de servidor predefinidos. Si escoge uno de los tipos de servidor predefinidos, haga clic sobre el botón de flecha junto al menú desplegable para rellenar el campo correspondiente.", //hhav_name
	"Puerto privado", //av_PriP
	"% perdido", //tsc_pingt_msg103
	"Si necesita usar la funcionalidad de UPnP, lo puede habilitar aquí.", //help_upnp_2
	"Modo de conectividad WAN incorrecto", //WAN_MODE_INCORRECT
	"La contraseña WEP ha de tener exactamente 5 caracteres alfanuméricos.", //wwl_alert_pv5_2_5
	"Paso 4: Seleccionar el método de filtrado", //_aa_wiz_s5_title
	"El número PIN no es válido.", //KR22_ww
	"Especificar reglas para prohibir el acceso a direcciones IP y puertos específicos", //_aa_wiz_s7_help
	"El servidor de la sesión de L2TP ha dejado de enviar números de secuencias para la sesión local 0x%04X", //IPL2TP_SEQUENCING_DEACTIVATED
	"Configuración avanzada de la impresora", //tps_apc
	"(GMT-06:00) Ciudad de Méjico", //up_tz_09
	"Jul", //tt_Jul
	"La interfaz WAN no funciona.", //GW_WAN_INTERFACE_DOWN
	"Restaure valores de configuración inalámbricos", //WCN_LOG_RESTORE
	"Everquest", //gw_gm_17
	"Acceso a Internet para la dirección IP %v establecido en %s", //GW_INET_ACCESS_INITIAL_IP
	"¿Desea omitir todos los cambios realizados en este asistente?", //_wizquit
	"La sección Parámetros del sistema permite reiniciar el dispositivo o restaurar el router con los parámetros predeterminados de fábrica. Al restaurar en la unidad los parámetros predeterminados de fábrica se borrarán todos los parámetros, incluidas las reglas que haya creado.", //tss_intro
	"Al establecer <span class='option'>Habilitar servidor DHCP </span> , se muestran las opciones siguientes.", //help318
	"Las opciones de syslog le permiten enviar registros a un servidor syslog", //tsl_intro
	"3:00 AM", //tt_time_4
	"8:00 PM", //tt_time_21
	"Conectada sesión local 0x%04X de L2TP", //IPL2TP_SESSION_CONNECTED
	"Umbral de fragmentación", //aw_FT
	"Guardar", //_save
	"No estimado", //at_NEst
	"Una vez que una aplicación del lado LAN ha establecido una conexión a través de un puerto específico, la NAT enviará peticiones de conexión entrante con el mismo puerto a la aplicación del lado independientemente de su origen. Esta es la opción menos restrictiva, por lo que da mayor conectividad y permite que algunas aplicaciones (aplicaciones P2P en particular) se comporten casi como si estuvieran directamente conectadas a internet.", //af_EFT_h0
	"FIRMWARE", //_firmware
	"Rogue Spear", //gw_gm_43
	"Inicie WPS en el dispositivo inalámbrico que está añadiendo a la red inalámbrica en", //wps_messgae1_1
	"El módulo RTE 0x%04X del túnel local L2TP se está cerrando.", //IPL2TP_SHUTDOWN_STARTED
	"Paquetes TX caídos", //ss_TXPD
	"(GMT+08:00) Pekín, Chongqing, Hong Kong, Urumqi", //up_tz_55
	"Haga clic en Siguiente si todavía quiere asegurar el router con una contraseña y establecer la zona horaria.", //wwa_intro_online2
	"Seleccione el protocolo de salida utilizado por la aplicación (por ejemplo, <code>Ambos</code>).", //help50
	"Introduzca los puertos UDP que se deben abrir (por ejemplo, <code>6159-6180, 99</code>).", //help70
	"La activación de WMM puede ayudar a controlar la latencia y la fluctuación cuando se transmiten contenidos multimedia a través de una conexión inalámbrica.", //help188_wmm
	"Reserva DHCP", //bd_title_SDC
	"(GMT+09:00) Osaka, Sapporo, Tokio", //up_tz_60
	"Ultima", //gw_gm_54
	"Copia de seguridad opcional del servidor RADIUS", //help396
	"Cierre de sesión del administrador", //GW_ADMIN_LOGOUT
	"Serious Sam II", //gw_gm_44
	"Activar UPnP", //ta_EUPNP
	"Esta opción debe estar habilitada si cualquier aplicación de la LAN participa en un grupo de multidifusión. Si una aplicación LAN multimedia no recibe el contenido como era de esperar, pruebe a habilitar esta opción.", //igmp_e_h
	"El número de paquetes enviado desde el enrutador.", //help806
	"DENIEGA el acceso a los ordenadores SOLO a estos sitios", //dlink_wf_op_0
	"Introduzca el rango de puertos de salida utilizado por la aplicación (por ejemplo, <code>6500-6700</code>).", //help49
	"Ejemplo:", //help367
	"Vínculos", //gw_gm_28
	"Windows Me", //help337
	"Opciones de administración", //ta_AdmSt
	"SysLog", //_syslog
	"(GMT-06:00) Hora central (EE.UU./Canadá)", //up_tz_08
	"Si está seleccionada, el usuario debe conectarse desde el mismo ordenador siempre acceda a la red inalámbrica.", //help394
	"Paso 5: Filtro de puerto", //_aa_wiz_s7_title
	"La opción Configuración de la hora permite configurar, actualizar y mantener la hora correcta en el reloj interno del sistema. En esta sección puede definir la zona horaria en la que se encuentra y definir el servidor NTP (Protocolo de hora de red). También puede configurar el horario de verano para que se ajuste la hora cuando sea necesario.", //tt_intro_Time
	"Error al actualizar la entrada dinámica DNS: %s. Se reintentará luego", //GW_DYNDNS_SERROR
	"Acti", //IPV6_TEXT105
	"Puerto", //sps_port
	"Si SPI está habilitado o no, el router siempre rastrea los estados de la conexión TCP y garantiza que los flags del paquete TCP son válidos para el estado actual.", //help164_2
	"Espere a que el enrutador se reinicie. Ello puede requerir otro minuto o más.", //help881
	"IP de destino", //_destip
	"La opción Configuración de la hora le permite configurar, actualizar y mantener la hora correcta en el reloj del sistema interno del router. En esta sección puede definir la zona horaria en la que se encuentra y definir el servidor de tiempo. También puede configurar el horario de verano para que la hora se ajuste automáticamente cuando corresponda.", //help840
	"Dirección IP del servidor L2TP (puede ser la misma que la puerta de enlace)", //wwa_l2tp_svra
	"Fechas del horario de verano", //tt_dsdates
	"Tenga en cuenta que las conexiones VPN L2TP suelen usar IPSec para asegurar la conexión. Para lograr", //help34b
	"10:00 AM", //tt_time_11
	"Habilitar DNS dinámico", //td_EnDDNS
	"La velocidad real de transmisión del cliente en megabits por segundo.", //help786
	"Nombre de usuario", //bwn_UN
	"Ya se ha utilizado este nombre de directiva.", //aa_alert_8
	"Habilitar QoS Engine", //wprn_tt2
	"LCP establece aut. remota: %04x", //IPPPPLCP_SET_REMOTE_AUTH
	"Tiempo de espera excedido para el módulo RTE 0x%04X del túnel local de L2TP – el servidor remoto no responde", //IPL2TP_FATAL_TIMEOUT
	"<strong> Sesiones LAN No-UDP/TCP/ICMP </strong> está activado normalmente. Facilita conexiones de VPN a un host remoto.", //hhaf_ngss
	"Parámetros de red", //bln_title_NetSt
	"Tipo de tráfico", //av_traftype
	"PPTP (nombre de usuario/clave de acceso)", //bwn_Mode_PPTP
	"Esta sección muestra las políticas de control de acceso actualmente definidas. Una política puede cambiarse haciendo clic sobre el icono Modificar, y eliminar haciendo clic sobre el icono Eliminar. Cuando hace clic en el icono Modificar, el asistente de políticas se inicia y le guía a lo largo del proceso de cambiar una política. Usted puede habilitar o deshabilitar políticas específicas de la lista si hace clic sobre la casilla de verificación 'Habilitar'.", //help140
	"Un protocolo de impresión requerido está desactivado", //wprn_rppd
	"Aquí se muestran todos los detalles de la conexión a la LAN y a la WAN.", //hhsd_intro
	"La autentificación MSCHAP se ha realizado correctamente.", //IPMSCHAP_AUTH_SUCCESS
	"Supongamos que aloja un servidor de juegos en línea que se ejecuta en un PC con una dirección IP privada de 192.168.0.50. Este juego requiere la apertura de varios puertos (6159-6180, 99) en el router para que los usuarios de Internet se puedan conectar.", //help63
	"Conecte un extremo del cable Ethernet suministrado con el router al puerto que lleva la etiqueta INTERNET en la parte posterior del router. Enchufe el otro extremo de este cable al puerto Ethernet de su ordenador.", //ES_cable_lost_desc
	"Se ha aplicado la nueva configuración.", //ap_intro_sv
	"Máscara de subred L2TP", //_L2TPsubnet
	"Enviar correo electrónico de inicio de sesión ante de reiniciar", //GW_LOG_EMAIL_BEFORE_REBOOT
	"Cualquiera", //at_Any
	"Las opciones siguientes se aplican a todos los modos de WAN", //help288
	"A menos que esté seleccionado uno de estos modos de encriptación, las transmisiones inalámbricas hacia y desde su red inalámbrica puede ser interceptadas fácilmente e interpretadas por usuarios desautorizados.", //bws_SM_h1
	"Además de los filtros que figuran en la lista, se dispone de dos filtros predefinidos que pueden aplicarse donde hay filtros entrantes:", //help177
	"(GMT+05:00) Islamabad, Karachi, Taskent", //up_tz_46
	"Espere <span id ='show_sec'></span>&nbsp;segundos.", //rb_wait
	"Nombre de red inalámbrica", //bwl_NN
	"Ha fallado el intento de conexión de sesión local 0x%04X de L2TP", //IPL2TP_SESSION_CONNECT_FAIL
	"Final Fantasy XI (PS2)", //gw_gm_21
	"ÓPTIMA", //wwl_BEST
	"Asistencia", //_support
	"No puede añadir nuevas direcciones IP. Puede reusar sólo las direcciones IP de otras políticas.", //aa_alert_14
	"Estado del cable", //_cablestate
	"DHCP significa Dynamic Host Configuration Protocol (protocolo de configuración de host dinámico). En la sección DHCP es donde configura el servidor DHCP integrado para que asigne las direcciones IP a los ordenadores y otros dispositivos de su red de área local (LAN).", //help314
	"Asistente para añadir dispositivo inalámbrico con WPS (WI-FI PROTECTED SETUP)", //wps_LW13
	"Crítico", //sl_Critical
	"Se han guardado los nuevos parámetros.", //sc_intro_sv
	"El Registro del sistema está inactivo", //SYSTEM_LOG_INACTIVE
	"Mi conexión a internet es", //bwn_mici
	"Minutos", //gw_mins
	"Si el enrutador se queda sin corriente por algún motivo, no puede mantener el reloj en marcha y no tendrá la hora correcta cuando se vuelva a encender. Para mantener la hora correcta de programaciones y registros, indique la hora correcta después de reiniciar el enrutador o debe acti", //help852
	"Entrada", //_In
	"Seleccione esta opción si desea enviar los registros por correo electrónico según una programación temporal.", //help870
	"Zona de juegos MSN (DX)", //gw_gm_74
	"Cortafuegos y seguridad", //help797
	"Rainbow Six", //gw_gm_39
	"La clave WEP ha de tener exactamente 10 dígitos hexadecimales (0-9 o A-F).", //wwl_alert_pv5_3_10
	"La sección de filtro de dirección MAC puede usarse para filtrar el acceso de red a máquinas basadas en las únicas direcciones MAC de su adaptador, o adaptadores, de red.", //help149
	"Use esta característica si intenta ejecutar una de las aplicaciones de red de la lista y no se realiza la comunicación como es de esperar.", //hhpt_intro
	"Se ha conectado el cable de interfaz WAN", //GW_WAN_CARRIER_DETECTED
	"Id de usuario de BigPond", //bwn_BPU
	"Seleccione esta opción si desea que se aplique esta programación todo el día durante el/los día(s) seleccionado(s)", //help195
	"El valor inicial del tiempo de espera depende del tipo y el estado de la conexión.", //help823_1
	"Conexión a internet", //_internetc
	"Resuelto para", //tsc_pingt_msg5
	"Introduzca una dirección MAC para cada punto de acceso que quiera conectar con WDS.", //help189a
	"Desencadenador", //_trigger
	"El ID de Ethernet (dirección MAC) del cliente inalámbrico.", //help783
	"La puerta de enlace no se reprogramará.", //ub_intro_2
	"Por razones de seguridad, se recomienda que cambie la clave de acceso para las admin. Asegúrese de que se anota las nuevas claves de accesos para evitar tener que reiniciar el router en caso de que se le olvidaran.", //hhta_pw
	"Paso 6: Configuración de la conexión de acceso a web", //_aa_wiz_s8_title
	"La regla puede Permitir o Denegar mensajes.", //help173
	"Ayuda de estado", //help771
	"Dirección IP del servidor Syslog", //tsl_SLSIPA
	"Añadir reglas de filtros de puerto", //_aa_wiz_s7_msg
	"12:00 PM", //tt_time_13
	"(GMT+10:00) Guam, Port Moresby", //up_tz_67
	"Servidor DNS primario, servidor DNS secundario", //help289a
	"BigPond ha iniciado la sesión", //BIGPOND_LOGGED_IN
	"Cuando un host de la LAN está configurado como un host DMZ, se convierte en el destino para todos los paquetes entrantes que no coinciden con cualquier otra sesión o regla entrante. Si cualquiera otra regla entrante está en el lugar apropiado, se usará esta en lugar de enviar paquetes al host DMZ; por lo tanto, una sesión activa, un servidor virtual, un puerto trigger o una regla de direccionamiento de puerto tendrá prioridad al enviar un paquete al host DMZ. (La política de DMZ se parece a una regla de direccionamiento de puerto por defecto que direcciona cada puerto que no está específicamente enviado a ninguna otra parte.)", //haf_dmz_10
	"Estado de las sesiones que utilizan el protocolo TCP.", //help819
	"Si la barra de progreso no aparece, no se habrá abierto el ejecutable de configuración y la configuración no estará completa. Vea más adelante la sección de Solución de problemas.", //wprn_s3b
	"Puerto TCP", //sps_tcpport
	"Configure el filtro de sitios web a continuación", //dlink_wf_intro
	"Filtro de sitio Web", //_websfilter
	"Nombre del servidor de BigPond", //sd_BPSN
	"Clave de acceso de usuario", //_password_user
	"Detenida directiva %s; el acceso a Internet para la dirección IP %v cambiado a: %s", //GW_INET_ACCESS_POLICY_END_IP
	"Escoja el modo que usará el router para conectarse a internet.", //bwn_msg_Modes
	"La dirección IP ' + mf.dmz_address.value + ' no es válida.", //up_gX_1
	"Siguiente", //_next
	"Configuración", //_setup
	"El host recibirá un ping repetidamente hasta que usted apriete este botón.", //htsc_pingt_s
	"Correo electrónico", //EMAIL
	"Modo", //_mode
	"Feb", //tt_Feb
	"Use esta información para configurar su ordenador para la impresión por puerto TCP.", //sps_raw1
	"Actualizado satisfactoriamente la entrada de DNS dinámico para %s", //GW_DYNDNS_SUCCESS
	"El direccionamiento de puertoss ALG no logró asignar la sesión para los paquetes TCP de %v:%u a %v:%u", //IPPORTFORWARDALG_TCP_PACKET_ALLOC_FAILURE
	"Router IGMP ha rechazado el grupo %v debido a bajos recursos del sistema", //IGMP_ROUTER_LOW_RESOURCES
	"La opción 'Auto 20/40 MHz'suele ser la mejor", //bwl_CWM_h1
	"(GMT+04:00) Moscú, San Petersburgo, Volgogrado", //up_tz_39
	"Permite que los dispositivos y aplicaciones que utilizan VoIP (voz sobre IP) se puedan comunicar a través de NAT. Algunas aplicaciones y dispositivos VoIP tienen la capacidad de detectar dispositivos NAT y funcionar con ellos. Esta ALG puede interferir en el funcionamiento de dichos dispositivos. Si tiene problemas a la hora de realizar llamadas VoIP, pruebe a desactivar esta ALG.", //help40
	"Redirección de Puertos", //_pf
	"Se ha eliminado el paquete UDP de %v a %v porque el encabezado de paquete no es identificable", //IPNAT_UDP_UNABLE_TO_HANDLE_HEADER
	"<warn>La ruta IP gateway %v se ajusta a la dirección de la interfaz buscada y se deshabilitará.</warn>", //GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS_WARNING
	"Acceso a Internet para la dirección MAC %m establecido en %s", //GW_INET_ACCESS_INITIAL_MAC
	"Se ha realizado con éxito la autenticación CHAP.", //IPPPPCHAP_AUTH_SUCCESS
	"Normalmente el transmisor inalámbrico funciona al 100 %. En ciertas circunstancias, sin embargo, podría ser necesario aislar determinadas frecuencias a un área más pequeña. Con esta reducción, puede impedir transmisiones más allá del área inalámbrica designada o de la de la oficina doméstica o corporativa.", //help187
	"Bloquear todos los accesos", //_aa_block_all
	"La conexión inalámbrica no funciona", //GW_WLAN_LINK_DOWN
	"Tiempo que transcurre antes de que se cambie la clave de grupo usada para la difusión y multidifusión de datos.", //help379
	"(GMT+11:00) Islas Salomón, Nueva Caledonia", //up_tz_70
	"Mensaje de error de ICMP entrante bloqueado (tipo ICMP %u ) desde %v hasta %v porque no existe ninguna sesión de ICMP activa entre %v y %v", //IPNAT_ICMP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"Programación", //GW_SCHEDULES_IN_USE_INVALID_s1
	"Esta página no está incluida en la Lista de sitios Web permitidos del enrutador.", //fb_p_2
	"Estado de impresora", //sps_ps
	"Debe configurar el router para que permita que las aplicaciones de software ejecutadas en cualquier ordenador de la red se conecten a un servidor basado en web o a otro usuario de Internet.", //help47
	"Paso 4: Guardar parámetros y conectar", //wwa_title_s4
	"5:00 PM", //tt_time_18
	"Cuando se habilita esta opción, los registros de actividad del router o las notificaciones de actualización del firmware pueden enviarse por correo electrónico a una dirección de correo electrónico designada, y se muestran los parámetros siguientes.", //help860
	"UPnP ha eliminado la entrada %v <-> %v:%d <-> %v%d %s '%s' (el cliente ha liberado la dirección)", //GW_UPNP_IGD_PORTMAP_RELEASE
	"El Asistente para la configuración de la conexión a Internet se ha completado. Haga clic en el botón Guardar para guardar los parámetros y reiniciar el router.", //wwa_intro_s4
	"Algún ISP puede requerir que escriba un nombre de servicio. Sólo escriba un nombre de servicio si su ISP lo requiere.", //help267
	"Sesión local 0x%04X de L2TP abortada", //IPL2TP_SESSION_ABORTED
	"Esta sección le permite gestionar los parámetros de configuración del router, reiniciar el router y restaurar en el router los parámetros por defecto. Al restaurar en el router los parámetros por defecto, se borrará todos los parámetros, incluidas las reglas que haya creado.", //help874
	"Sep", //tt_Sep
	"Se ha eliminado el paquete ESP de %v a %v porque el encabezado del paquete no es identificable", //IPSEC_ALG_ESP_UNABLE_TO_HANDLE_HEADER
	"Intervalo de actualización de la clave de grupo", //bws_GKUI
	"Habilita el router para reconocer ciertos canales continuos de audio y vídeo generados por un PC Windows Media Center y para priorizarlos respecto al resto de tráfico. Estos canales continuos los usan los sistemas conocidos como Windows Media Extenders, por ejemplo, la Xbox 360.", //help80b
	"En estos casos, puede usar los filtros entrantes para limitar la exposición especificando las direcciones IP de los hosts de internet en los que confia para que su LAN acceda a través de los puertos que ha abierto. Puede, por ejemplo, permitir que solo accedan a un servidor de juegos de su LAN doméstica las ordenadores de amigos a los que ha invitado para jugar en ese servidor.", //help168c
	"BigPond iniciando sesión", //BIGPOND_LOGGING_IN
	"Conexión con nombre de usuario / contraseña (PPTP)", //wwa_wanmode_pptp
	"Rango (50-100)", //help58
	"Conectado", //ddns_connected
	"Error al cargar", //ub_Upload_Failed
	"WPS termina para STA con MAC (%m) en msg: %s", //WIFISC_AP_PROXY_END_ON_MSG
	"PPTP (Point to Point Tunneling Protocol) usa una red privada virtual para conectarse a su ISP. Este método de conexión se usa, sobre todo, en Europa. Este método de conexión requiere que usted introduzca un <span class='option'>Nombre de usuario</span> y una <span class='option'>Clave de acceso</span> (proporcionados por su proveedor de servicios internet) para obtener el acceso a internet", //help278
	"Introduzca una frase secreta alfanumérica de 8 a 63 caracteres. Para lograr una buena seguridad debe tener una longitud amplia y no debe ser una frase conocida habitual.", //KR18
	"Un syslog es un servidor que recopila los registros de diferentes fuentes. Si la LAN incluye un servidor syslog, puede usar esta opción para enviar los registros del router a ese servidor.", //hhts_def
	"Usado cuando su ISP le proporciona una dirección IP que no cambia. La información IP se entra manualmente en los parámetros de configuración IP. Usted debe entrar el", //help255
	"Segundo puerto del servidor RADIUS", //bws_2RSP
	"Introduzca el puerto privado como [80]", //help7
	"Visible", //bwl_VS_0
	"Filtrado TCP Endpoint", //af_TEFT
	"Si la opción <span class='option'>Tipo de conexión</span> se ha establecido en <span class='option'>Detección automática</span>, aquí se mostrará el tipo de conexión detectado automáticamente.", //help86
	"Nombre de red (SSID)", //sd_NNSSID
	"Acceder a esta página Web puede afectar a la medida.", //wt_p_2
	"Puerta de enlace", //_gateway
	"Hora actual del router.", //tt_CurTime
	"a.m.", //_AM
	"Desconectado", //DISCONNECTED
	"Soldier of Fortune", //gw_gm_47
	"(GMT-01:00) Azores", //up_tz_22
	"WPS Internal Registrar ha detectado una superposición de sesión entre %m y %m", //WIFISC_IR_REGISTRATION_SESSION_OVERLAP
	"Haga que las dos contraseñas admin sean iguales e inténtelo de nuevo", //_pwsame_admin
	"La IP de la WAN se ha cambiado a %v, actualizando a proveedor de DNS dinámico", //GW_DYNDNS_UPDATE_IP
	"Se ha asignado la dirección IP de %v a un ordenador de la red (%s).", //GW_DHCPSERVER_NEW_ASSIGNMENT
	"Windows/MSN Messenger", //as_WM
	"(GMT-09:00) Alaska", //up_tz_03
	"Introduzca el PIN de su dispositivo inalámbrico, luego haga clic en el botón Conectar.", //KR43
	"las contraseñas no coinciden, introdúzcalas de nuevo", //YM177
	"Dependiendo del tipo de conexión WAN, puede lle", //help774
	"Haga clic sobre el icono <strong>Edición</strong> para modificar una regla existente usando el asistente de políticas", //hhac_edit
	"(GMT+02:00) Jerusalén", //up_tz_36
	"Nombre de host", //_hostname
	"La inicialización de control de acceso a Internet falló", //GW_INET_ACCESS_INITIAL_FAIL
	"Ha fallado la inicialización del filtro web", //GW_WEB_FILTER_INITIAL_FAIL
	"Acti", //te_OnFull
	"Paso 3: Establecer su contraseña de seguridad inalámbrica", //wwl_title_s4
	"Modo de reconexión:", //help281
	"Gamespy Tunnel", //gw_gm_77
	"Clonar la dirección MAC del PC", //_clonemac
	"Esto es un resumen del número de paquetes transferidos entre la WAN y la LAN desde la última vez que se inicializó el router.", //hhss_intro
	"Velocidad de subida medida", //at_MUS
	"La velocidad WAN suele detectarse de forma automática. Si usted está teniendo problemas para conectarse a la WAN, seleccione la velocidad manualmente.", //hhan_wans
	"Habilite esta opción si quiere permitir que WISH priorice el tráfico inalámbrico.", //YM141
	"La clave es una frase secreta de hasta 63 caracteres alfanuméricos en formato ASCII (American Standard Code for Information Interchange) a ambos extremos de la conexión inalámbrica. No puede ser inferior a ocho caracteres, aunque para más seguridad es necesario que tenga más caracteres y no debe ser una frase conocida. Esta frase se usada para generar claves de sesión que son únicas para cada cliente inalámbrico.", //help382
	"(hora:minuto, 12 horas)", //tsc_hrmin
	"(hora:minuto, 24 horas)", //tsc_hrmin1
	"Esta es la velocidad de subida medida la última vez que se restableció la interfaz WAN. Puede que el valor sea inferior al proporcionado por el ISP ya que no incluye toda la carga de protocolo de red asociada a la red del ISP. En general, esta cifra se situará entre el 87% y el 91% de la velocidad de subida declarada para las conexiones xDSL y en torno a 5 kbps menos para las conexiones de red por cable.", //help82
	"Heretic II", //gw_gm_24
	"Delta Force", //gw_gm_13
	"Umbral RTS", //aw_RT
	"Windows XP", //help340
	"LAN inalámbrica", //sd_WLAN
	"Active esta opción si su servidor SMTP requiere autenticación.", //help864
	"Puede haber nuevo firmware para su", //tf_intro_FWU1
	"Sistema operativo no compatible", //wprn_bados
	"Métrico", //_metric
	"Filtro entrante", //INBOUND_FILTER
	"Paquete UDP entrante bloqueado de %v%u a %v%u", //IPNAT_UDP_BLOCKED_INGRESS
	"Esta opción activa y desactiva la característica de conexión inalámbrica del router. Cuando configura esta opción, los parámetros siguientes se hacen efectivos.", //help351
	"Use estas opciones si prefiere crear su propia clave.", //wwz_manual_key2
	"Máscara de subred PPTP", //_PPTPsubnet
	"El puerto que se utilizará en su red interna.", //help20
	"Blanco y negro", //gw_gm_6
	"Modo WPA", //bws_WPAM
	"BUENA", //wwl_GOOD
	"Postal 2: Share the Pain", //gw_gm_36
	"Entre su nombre de host completo; por ejemplo: <code>myhost.mydomain.net</code>.", //help894
	"Máscara de subred", //_subnet
	"La ventana de transmisión PPTP es %u", //PPTP_EVENT_REMOTE_WINDOW_SIZE
	"Paso 1: Seleccione el método de configuración para su red inalámbrica", //wps_KR35
	"La opción <code>Reservar</code> convierte esta asignación de IP dinámica en una reserva DHCP y añade la entrada correspondiente a la Lista de reservas DHCP.", //help329_rsv
	"Vietcong", //gw_gm_58
	"Abriendo WAN mediante %s", //GW_WAN_MODE_IS
	"Utilice esta sección para configurar los parámetros de red interna de su AP y configurar también el servidor DHCP incorporado para asignar direcciones IP a los ordenadores de su red. La dirección IP que está configurada aquí es la dirección IP que utiliza para acceder a la interfaz de gestión basada en la web. Si cambia aquí la dirección IP, puede que necesite ajustar los parámetros de red del PC para acceder de nuevo a la red.", //ns_intro_
	"DNS relay ALG rechazó paquete desde %v:%u hasta %v:%u", //IPDNSRELAYALG_REJECTED_PACKET
	"Las estadísticas de tráfico muestran los paquetes de recepción y transmisión que pasan a través del router.", //ss_intro
	"Debería tener en cuenta estos avisos puesto que se pueden haber deshabilitado algunas características.", //KR112
	"<warn>No todas las estaciones pueden funcionar en el canal 100-140. Cambie el canal si la estación falla al establecer la conexión.</warn>", //GW_WLAN_11A_CH_MID_BAND_WARN
	"Activar ataque para prevenir ARP", //ip_mac_binding_desc
	"Al habilitar esta opción (parámetro por defecto), se habilita una única conexión VPN a un host remoto. (Pero, para múltiples conexiones VPN, ha de usarse el ALG VPN apropiado.) Al deshabilitar esta opción, no obstante, solo se deshabilita la VPN si también se deshabilita el ALG VPN apropiado.", //LW50
	"La regla %s entra en conflicto con una conexión existente (%v:%u (público %v:%u)--->%v:%u). La conectividad de la regla puede verse afectada hasta que finalice la conexión.", //GW_NAT_CONFLICTING_CONNECTIONS_LOG
	"Los avisos se han generado como resultado de cambios en la configuración.", //KR111
	"Entradas de registro", //KR109
	"<warn>La regla %s entra en conflicto con una conexión existente (%v:%u (público %v:%u)--->%v:%u). La conectividad de la regla puede verse afectada hasta que finalice la conexión.</warn>", //GW_NAT_CONFLICTING_CONNECTIONS_WARNING
	"La configuración del  modo del punto de acceso HNAP  %s devuelve %s, %s", //GW_PURE_SETACCESSPOINTMODE
	"Se ha bloqueado el paquete de %v a %v recibido desde la interfaz de red incorrecta (spoofing de dirección IP).", //GW_NAT_REJECTED_SPOOFED_PACKET
	"Mensaje", //KR110
	"<warn>La ruta IP del gateway%v no se encuentra en la subred de la interfaz (%v/%v) y se deshabilitará.</warn>", //GW_ROUTES_ROUTE_GATEWAY_NOT_IN_SUBNET_WARNING
	"Cuando se habilita esta opción, el router restringe el tráfico de salida a fin de no exceder el ancho de banda del uplink WAN.", //KR107
	"Comprobación anti-spoof", //KR105
	"Se ha bloqueado el paquete de %v a %v (ataque LAND)", //IPSTACK_REJECTED_LAND_ATTACK
	"WEP", //LS321
	"Mensajes de correo electrónico con registros", //KR67
	"el puerto final de destino debe estar comprendido entre 0 y 65535 inclusive.", //YM71
	"El rango de IP de origen '%v-%v' está duplicado.", //GW_FIREWALL_RANGE_DUPLICATED_INVALID
	"Dirección de hardware", //LS422
	"Usar Windows Connect Now", //bwz_LWCNWz
	"La dirección IP del gateway WAN no es válida: %v", //GW_WAN_WAN_GATEWAY_IP_ADDRESS_INVALID
	"Guardar la configuración en el Asistente para la configuración de la red inalámbrica", //ta_wcn
	"Un PIN es un número que se puede usar para añadir el router a una red existente o para crear una red. El PIN por defecto suele figurar en la parte superior del router. Para mayor seguridad, se puede generar un nuevo PIN. En cualquier momento, puede restaurar el PIN por defecto. Solo el administrador (cuenta «admin») puede cambiar o restablecer el PIN.", //LW57
	"Clave WEP 2", //_wepkey2
	"Salto", //tsc_pingt_msg109
	"Tipo de nodo NetBIOS", //bd_NETBIOS_REG_TYPE
	"Pulse el botón de comando (físico o virtual) del dispositivo inalámbrico que está añadiendo a su red inalámbrica dentro de", //wps_messgae1_2
	"Cree un número aleatorio que sea un PIN válido. Este número será el PIN del router, que luego podrá copiar en el interfaz de usuario de registro.", //LW60
	"Error al restablecer", //_rs_failed
	"Seleccione esta opción si el dispositivo está conectado a un flujo de red local procedente de otro router. En este modo, el dispositivo funciona como un bridge entre la red, en su puerto WAN, y los dispositivos, en su puerto LAN, y los que están conectados a él inalámbricamente.", //KR62
	"El campo PIN del dispositivo inalámbrico no puede estar vacío.", //KR20
	"Para un mayor rendimiento, use la opción Clasificación automática a fin de establecer automáticamente la prioridad para sus aplicaciones.", //at_intro_2
	"Anuncios NetBIOS", //bd_NETBIOS_ENABLE
	"La máscara de subred de la red de área local.", //KR77
	"Super G con Dynamic Turbo", //help364
	"Comprar", //_aa_bsecure_shopping
	"Proxies públicos", //_aa_bsecure_public_proxies
	"Clave WEP 1", //wepkey1
	"Enviar/recibir autorización", //ZM11
	"Hora de inicio", //tsc_start_time
	"el puerto final de origen debe estar comprendido entre 0 y 65535 inclusive.", //YM69
	"Si los anuncios NetBIOS están activados, cambiar este parámetro hace que la información WINS pueda conocerse desde el lado WAN, si está disponible.", //KR82
	"Solo el administrador puede borrar las estadísticas. El botón Borrar estadísticas está deshabilitado porque usted no ha entrado en el sistema como administrador.", //ss_intro_user
	"El nombre de programación '%s' está reservado y no puede usarse", //GW_SCHEDULES_NAME_RESERVED_INVALID
	"Añadir estación inalámbrica", //LW12
	"Windows Media Center", //YM75
	"La ruta IP del gateway %v no es válida", //GW_ROUTES_GATEWAY_IP_ADDRESS_INVALID
	"El intervalo de actualización de la clave de grupo WPA debe estar comprendido entre 30 y 65535 segundos.", //GW_WLAN_WPA_REKEY_TIME_INVALID
	"WEP es la encriptación inalámbrica estándar. Para utilizarla, ha de introducir la(s) misma(s) clave(s) en el router y en las estaciones inalámbricas. Para claves de 64 bit ha de introducir 10 dígitos hexadecimales en cada cuadro de clave. Para claves de 128 bit ha de introducir  26 dígitos hexadecimales en cada cuadro de clave. Un dígito hexadecimal puede ser un número del 0 al 9 o una letra desde la  A hasta la F. Para un uso más seguro de WEP, establezca el tipo de autentificación como «Clave compartida» cuando WEP esté habilitada.", //bws_msg_WEP_1
	"Habilitar el modo oculto es otra forma de asegurar la red. Con esta opción habilitada, ningún cliente inalámbrico podrá ver su red inalámbrica cuando busquen redes disponibles. Para que sus dispositivos inalámbricos se conecten a su red, tendrá que introducir manualmente el nombre de red inalámbrica en cada dispositivo.", //YM125
	"Apuestas", //_aa_bsecure_gambling
	"Modo bridge", //KR14
	"La dirección FROM indicada (%s) no es válida", //GW_SMTP_FROM_ADDRESS_INVALID
	"Indica cómo están los hosts de la red para realizar el registro de nombre NetBIOS  y descubrirlos.", //KR89
	"Máscara de subred:", //help106
	"Al configurar el router para acceder a internet, asegúrese de que elegido el <strong>Tipo de conexión a internet</strong> correcto en el menú desplegable. Si no sabe qué opción elegir, contacte con su <strong>proveedor de servicios internet (ISP)</strong>.", //LW35
	"Voz (más urgente).", //YM151
	"Se han guardado los cambios. Debe reiniciarse el router para que los cambios surtan efecto. Puede reiniciar ahora o continuar haciendo cambios y reiniciar más tarde.", //YM2
	"Nota: vea <a href='../Help/Tools.shtml#wcn' onclick='return jump_if();' style='white-space: nowrap;'>Help -&gt; Tools</a> para posibles limitaciones respecto a esta característica.", //ta_wcn_note
	"Alguien más ha cambiado la configuración del router durante el funcionamiento del asistente.\nLa función del asistente se va a cancelar, inténtelo de nuevo.", //YM131
	"HTTP y HTTPS no pueden estar en el mismo puerto LAN.", //GW_WEB_SERVER_SAME_PORT_LAN
	"Tiempo de espera de la sesión", //KR25
	"Reiniciar ahora", //YM3
	"<warn>El ALG Wake-On-LAN se ha habilitado automáticamente porque lo requiere una entrada de servidor virtual creada por usted.</warn>", //GW_NAT_WOL_ALG_ACTIVATED_WARNING
	"El rango de dirección IP de destino para el filtro de puerto no es válido", //YM20
	"Habilite esta opción si quiere permitir que WISH priorice el tráfico inalámbrico.", //YM86
	"Dirección MAC %m de WAN no válida", //GW_WAN_MAC_ADDRESS_INVALID
	"El formato de la dirección de correo electrónico del destinatario no es correcto", //IPSMTPCLIENT_MSG_WRONG_RECEPIENT_ADDR_FORMAT
	"WISH soporta coincidencias entre reglas. Si más de una regla se corresponde con un flujo de mensaje específico, se usará la regla que tenga mayor prioridad.", //YM146
	"Advertencias de configuración", //LS151
	"El nombre no puede ser una cadena vacía.", //GW_QOS_RULES_NAME_INVALID
	"%s' [protocol:%d]->%v entra en conflicto con '%s' [protocol:%d]->%v.", //GW_NAT_VS_PROTO_CONFLICT_INVALID
	"El nombre no puede ser una cadena vacía.", //GW_WISH_RULES_NAME_INVALID
	"Error al añadir la estación inalámbrica %s, motivo %s, código de error %u", //WIFISC_IR_REGISTRATION_FAIL
	"LISTA DE RUTA", //r_rlist
	"Introduzca una dirección específica del servidor DNS.", //IPV6_TEXT109
	"128 bit (26 dígitos hexadecimales)", //bws_WKL_1
	"Organiza información para que pueda ser administrada, actualizada y además puedan acceder a ella fácilmente los usuarios y aplicaciones.", //help473
	"Protección inalámbrica adicional", //aw_erpe
	"Ambos rangos de puerto no pueden estar vacíos.", //GW_NAT_PORT_FORWARD_RANGE_BOTH_EMPTY_INVALID
	"La ruta IP del gateway %v no está en la subred de la interfaz", //GW_ROUTES_GATEWAY_IP_ADDRESS_IN_SUBNET_INVALID
	"Asistente inalámbrico", //LW37
	"Esta característica está deshabilitada cuando se entra en el sistema como usuario", //tsc_pingdisallowed
	"Para guardar la configuración, haga clic en el botón <strong>Guardar configuración</strong>.", //ZM20
	"Tipo de cifrado:", //help376
	"La notificación por correo electrónico no está habilitada en la página Herramientas->Parámetros de correo, pero la notificación por correo de nuevas versiones de firmware sí que está habilitada en la página Herramientas->Firmware.", //GW_FW_NOTIFY_EMAIL_DISABLED_INVALID
	"La clave WEP no es válida", //YM122
	"La dirección DMZ  %v no puede ser igual a la dirección IP de la LAN.", //GW_NAT_DMZ_CONFLICT_WITH_LAN_IP_INVALID
	"Configuración incorrecta: compruebe los registros", //_sdi_s7
	"Configuración de QoS Engine", //at_title_SESet
	"El puerto inicio debe ser inferior al puerto final: %d-%d.", //GW_INET_ACL_START_PORT_INVALID
	"Error al enviar los datos de correo electrónico", //IPSMTPCLIENT_DATA_FAILED
	"M-Node (por defecto) es un modo mixto de funcionamiento. Primero se realiza el funcionamiento de difusión para registrar hosts y descubrir otros; si el funcionamiento de multidifusión falla, se prueban los servidores WINS, si hay alguno. Este modo favorece el funcionamiento de difusión, que puede ser preferible si los servidores WINS son rechazados por un enlace de red lento y la mayoría de servicios de red, como servidores o impresoras, son locales a la LAN.", //KR91
	"Banda de frecuencia en funcionamiento. Elija 2.4 GHz para conseguir visibilidad de los dispositivos heredados y un rango más largo. Elija 5 GHz para conseguir menos interferencias; las interferencias pueden dañar el rendimiento.", //KR971
	"Restaurar valores por defecto", //tss_RestAll_b
	"%s de '%s' [%s:%s]->%s entra en conflicto con '%s' [%s:%s]->%s.", //GW_NAT_PORT_TRIGGER_CONFLICT_INVALID
	"Se aplicará la fragmentación cuando el tamaño de trama en bytes sea mayor que el umbral de fragmentación.", //LW54
	"Si ya dispone de un servidor DHCP en su red o utiliza direcciones IP estáticas en todos los dispositivos de su red, desmarque <strong>Habilitar servidor DHCP</strong> para deshabilitar esta característica.", //TA7
	"La dirección IP de este dispositivo en la red de área local.", //KR74
	"Clave WEP por defecto", //bws_DFWK
	"Si es principiante en redes inalámbricas y nunca ha configurado un router inalámbrico, haga clic en <strong>Asistente de configuración de red inalámbrica</strong>, y el router le guiará a través de los pocos pasos que le lle", //LW46
	"El servidor SMTP (correo)%s está en la dirección IP %v", //IPSMTPCLIENT_RESOLVED_DNS
	"Interfaz", //help110
	"La dirección IP del gateway PPTP no es válida", //YM107
	"El valor del tiempo de espera no puede ser mayor que 8760.", //YM180
	"La máscara de subred de la WAN %v no es válida", //GW_WAN_WAN_SUBNET_INVALID
	"<warn>DMZ está deshabilitada porque se ha cambiado la subred de la LAN.</warn>", //GW_NAT_DMZ_DISABLED_WARNING
	"¿Quiere deshabilitar la entrada de reserva DHCP para la dirección IP?", //YM93
	"<warn>El ALG FTP se ha habilitado automáticamente porque lo requiere una entrada de servidor virtual creada por usted.</warn>", //GW_NAT_FTP_ALG_ACTIVATED_WARNING
	"Host libre", //_aa_bsecure_free_host
	"La máscara de red para la ruta no es válida", //_r_alert2
	"La dirección MAC no es válida", //LS47
	"La máscara de subred de la LAN no deja direcciones que pueda usar el servidor DHCP.", //GW_DHCP_SERVER_SUBNET_SIZE_INVALID
	"No puede añadir una nueva dirección MAC %m. Solo puede reutilizar direcciones MAC de otras políticas.", //GW_INET_ACCESS_POLICY_TOO_MANY_MAC_INVALID
	"La dirección IP inicio ha de ser inferior que la dirección IP final: %v-%v", //GW_FIREWALL_START_IP_ADDRESS_INVALID
	"segundos.", //YM8
	"%s': La prioridad, %u, ha de estar comprendida entre 0 y 7", //GW_WISH_RULES_PRIORITY_RANGE
	"Viajar", //_aa_bsecure_travel
	"La métrica de ruta es un valor comprendido entre 1 y 16 que indica el coste de usar esa ruta. Un valor de 1 es el coste más bajo, y 15 es el coste más alto. Un valor de 16 indica que el router no puede llegar a esa ruta. Al intentar llegar a un destino determinado, los ordenadores de la red seleccionan la mejor ruta e ignoran las que no son realizables.", //help113
	"Cliente BigPond", //ZM6
	"(la longitud se aplica a todas las claves)", //bws_length
	"El control ActiveX WCN proporciona el enlace WCN necesario entre el router y su PC a través del navegador. El navegador intentará descargar el control ActiveX WCN, si no está ya en su ordenador. Para que esto se realice correctamente, ha de estar establecida la conexión WAN, y, en el navegador, el parámetro de seguridad de internet ha de estar definido como Medio o más bajo (seleccione Herramientas &rarr; Opciones de internet &rarr; Seguridad &rarr; Nivel personalizado &rarr; Medio).", //help836
	"Intente de nuevo realizar la restauración con el archivo de configuración válido.", //rs_intro_2
	"La dirección IP %v ya existe.", //GW_INET_ACL_IP_ADDRESS_DUPLICATION_INVALID
	"Debe iniciar sesión como administrador para utilizar estas características.", //KR7
	"(También denominado SSID)", //ZM1
	"Seleccione un filtro que controle el acceso para este puerto de administración según las necesidades. Si no ve el filtro que necesita en la lista de filtros, vaya a la pantalla <a href=\"Inbound_Filter.asp\" onclick=\"return jump_if();\">Opciones avanzadas  Filtro de entrada</a> y cree un nuevo filtro.", //hhta_831
	"Configuración manual de la conexión a internet", //LW30
	"La máscara de subred L2TP no es válida", //YM110
	"Punto a punto (sin difusión)", //bd_NETBIOS_REG_TYPE_P
	"La máscara de subred de la LAN no es válida.", //GW_LAN_SUBNET_MASK_INVALID
	"No se pueden crear más reservas", //YM88
	"La dirección IP del WINS primario no es válida", //GW_DHCP_SERVER_NETBIOS_PRIMARY_WINS_INVALID
	"Nombre (si existe)", //YM187
	"%s nombre %s de '%s' no está definido.", //GW_NAT_NAME_UNDEFINED_INVALID
	"Radar inalámbrico detectado en el canal %d", //GW_WIRELESS_RADAR_DETECTED
	"Clave precompartida", //LW25
	"El proceso de restauración no es válido", //_rs_invalid
	"La dirección IP del servidor DNS primario no es válida", //YM113
	"Configuración protegida Wi-Fi", //LW65
	"Seleccione esta opción si su dispositivo inalámbrico tiene botón", //KR41
	"La dirección IP del servidor DNS primario no es válida: %v", //GW_WAN_DNS_SERVER_PRIMARY_INVALID
	"El PIN del dispositivo inalámbrico no es válido", //KR21
	"Red de Área Personal", //help643
	"En el campo <span class='option'>Dirección IP del router</span> debe figurar la dirección IP de este dispositivo. El <span class='option'>Gateway</span> debe tener la dirección IP del router ascendente. Ambas direcciones han de estar dentro de la subred de la LAN, especificada en <span class='option'>Máscara de subred</span>.", //KR63
	"El siguiente Asistente de configuración web se ha creado para asistirle en la configuración de la impresora. Este asistente de configuración le guiará a través de las instrucciones detalladas para configurar la impresora.", //LW31
	"La dirección IP del servidor DNS secundario no es válida: %v", //GW_WAN_DNS_SERVER_SECONDARY_INVALID
	"La dirección IP final remota no es válida.", //YM55
	"Para obtener información sobre el método de configuración que admite el dispositivo inalámbrico, consulte la documentación de los adaptadores.", //KR37
	"Marque esta casilla para permitir que el servidor DHCP ofrezca los parámetros de configuración NetBIOS a los hosts de la LAN.", //KR80
	"La máscara de subred de la WAN no es válida", //YM100
	"Wake On LAN", //_wakeonlan
	"El dispositivo puede estar demasiado ocupado para poder recibirlo correctamente. Intente de nuevo el proceso de restauración. También es posible que usted haya entrado en el sistema como usuario en vez de como administrador solo los administradores pueden restaurar el archivo de configuración. Consulte el registro del sistema por posibles errores.", //rs_intro_3
	"PainKiller", //gw_gm_35
	"Será redirigido a la página de inicio de sesión en", //YM7
	"Si no utiliza Super G con Dynamic Turbo para mejorar la velocidad, habilite Búsqueda automática de canales para que el router pueda seleccionar el mejor canal posible en el que pueda funcionar su red inalámbrica.", //YM124g
	"La dirección MAC %m ya existe.", //GW_INET_ACL_MAC_ADDRESS_DUPLICATION_INVALID
	"la dirección IP inicio de destino no es válida.", //YM66
	"Optimum Online", //manul_conn_13
	"Avisos NetBIOS", //bd_NETBIOS
	"Objetivo", //sa_Target
	"En este apartado se definen las reglas de aplicación.", //help56_a
	"<warn>El servidor DHCP se está reconfigurando porque la subred de la LAN no es apropiada; asegúrese que su servidor está correcto.</warn>", //GW_DHCP_SERVER_RECONFIG_WARNING
	"Fallo", //_wifisc_addfail
	"El beacon period debe estar comprendido entre 100 y 1000.", //GW_WLAN_BEACON_PERIOD_INVALID
	"Best Effort (BE)", //YM79
	"El tamaño máximo de agregación no es válido", //YM32
	"Se guardará la configuración inalámbrica actual del router en su ordenador por medio de la tecnología Windows Connect Now de Microsoft , lo que permitirá que la configuración se transmita a través del asistente de configuración de red inalámbrica de Microsoft.", //ta_intro_wcn
	"Seleccione esta opción si sus adaptadores inalámbricos ADMITEN WPA", //wwl_text_better
	"Background (BK)", //YM78
	"Canal", //sd_channel
	"Tenga en cuenta que no se pueden asociar diferentes ordenadores de la LAN  a las reglas de direccionamiento de puerto que contengan algún puerto en común; tales reglas se contradirían entre ellas.", //KR53
	"<strong>Bloquee los parámetros de seguridad inalámbrica</strong> cuando todos los dispositivos de red inalámbricos estén configurados.", //LW16
	"TCP", //GW_NAT_TCP
	"Este router tiene un puerto USB; por ello, si dispone de una unidad flash USB, un puerto USB en su PC, y el sistema operativo de su PC es Windows XP Service Pack 2 (SP2) o superior, puede transferir los datos de configuración inalámbrica entre su PC y el router con la unidad flash USB. Vaya al Panel de control de Windows y seleccione Asistente de configuración de red inalámbrica. Este asistente le ofrecerá dos opciones: «Usar una unidad flash USB» y «Configurar una red manualmente». Seleccione «Usar una unidad flash USB».", //help202
	"[CRIT]", //CRIT
	"La regla se aplica a un flujo de mensajes para los que las direcciones IP de otros ordenadores fallan dentro del rango establecido aquí.", //YM154
	"La característica QoS ayuda a mejorar el rendimiento de la red al otorgar prioridad a los flujos de datos de las aplicaciones de red.", //help76
	"%s': el primer puerto del host 1, %u, debe ser inferior que último puerto del host 1, %u", //GW_WISH_RULES_HOST1_PORT
	"Para el modo 11g Turbo, el canal debe ser 6.", //GW_WLAN_11G_TURBO_INVALID
	"Entretenimiento", //_aa_bsecure_entertainment
	"Inactivo", //YM165
	"Indique un nombre para esta regla que signifique algo para usted.", //help172
	"Estilo de vida", //_aa_bsecure_lifestyles
	"La dirección de DMZ debe estar dentro de la subred (%v) de la LAN.", //GW_NAT_DMZ_NOT_IN_SUBNET_INVALID
	"Modo Turbo", //sd_TMode
	"%s rango de puerto '%s' de '%s' no es válido.", //GW_NAT_PORT_FORWARD_PORT_RANGE_INVALID
	"%s': La última IP local '%v' no está en la subred de la LAN", //GW_QOS_RULES_LOCAL_IP_END_SUBNET
	"AES", //bws_CT_2
	"Tenga en cuenta que no es posible controlar el acceso a los sitios web que usan el protocolo seguro HTTP; es decir, aquellos cuya URL tiene el formato <code>https://...</code>.", //_bsecure_parental_limits
	"64 Kbytes", //aw_64
	"Humor", //_aa_bsecure_humor
	"P-Node indica que SOLO se usan servidores WINS. Este parámetro es útil para forzar el funcionamiento NetBIOS a los servidores WINS configurados. Ha de haber configurado al menos la IP del servidor WINS primario par apuntar a un servidor WINS operativo.", //KR92
	"Modo router", //KR13
	"El nombre de política no puede estar duplicado: %s.", //GW_INET_ACL_POLICY_NAME_DUPLICATE_INVALID
	"La NAT no envía ninguna petición de conexión entrante con la misma dirección de puerto que una conexión ya establecida.", //YM136
	"Versión de hardware", //TA3
	"Super G sin Turbo:", //help360
	"Advertencias", //YM10
	"Dirección IP del servidor PPTP: %v", //GW_WAN_PPTP_SERVER_IP_ADDRESS_INVALID
	"Vídeo", //YM150
	"La dirección IP %v está en uso; debe anular su arrendamiento y restaurar los parámetros de red del dispositivo que la usa.", //GW_DHCP_SERVER_RESERVATION_IN_USE
	"Puerto de firewall", //GW_NAT_INPUT_PORT
	"Reinicio por %s completado", //WIFISC_AP_REBOOT_COMPLETE
	"Última versión de firmware", //YM182
	"1.000 Mbps", //LW3
	"La clave WPA Personal debe tener como mínimo 8 caracteres.", //YM116
	"Clave WEP", //LW22
	"Lo sentimos", //OOPS
	"Sesiones WISH", //YM158
	"Fallo al enviar/recibir", //ZM16
	"Seleccione la categoría de edad", //_aa_bsecure_select_age
	"La ruta IP de destino %s no es válida", //GW_ROUTES_DESTINATION_IP_ADDRESS_INVALID
	"Restablecimiento por %s completado", //WIFISC_AP_RESET_COMPLETE
	"Modo de registro NetBIOS", //bd_NETBIOS_REG
	"La dirección IP del gateway de la LAN no es válida.", //GW_LAN_GATEWAY_IP_ADDRESS_INVALID
	"Guarda la regla de programación nueva o modificada.", //KR96
	"El archivo de configuración se ha exportado correctamente", //GW_XML_CONFIG_GET_SUCCESS
	"Entrada renovación UPnP %v <-> %v:%d <-> %v:%d %s tiempo de espera:%d '%s'", //GW_UPNP_IGD_PORTMAP_REFRESH
	"Para lograr un mejor rendimiento inalámbrico, use en modo de seguridad <strong>Solo WPA2</strong> (o, en otros términos, cifrado AES).", //bws_msg_WPA_2
	"La dirección IP de la LAN no es válida.", //GW_LAN_IP_ADDRESS_INVALID
	"Inicio de IP remota", //KR5
	"El QoS admite superposiciones entre las reglas, en las que más de una regla puede coincidir para un flujo de mensaje específico. Si se detecta que coincide más de una regla, se utilizará la regla con la prioridad más alta.", //help88c
	"El nombre de programación %s no está definido.", //GW_INET_ACL_SCHEDULE_NAME_INVALID
	"El inicio del puerto remoto de %s', %u, debe ser inferior al final del puerto remoto, %u", //GW_QOS_RULES_REMOTE_PORT
	"La dirección IP para '%s' debe estar dentro de la subred de la LAN (%v).", //GW_NAT_IP_ADDRESS_INVALID
	"Las claves hexadecimales de 128-bit tienen una longitud exacta de 26 caracteres. (456FBCDF123400122225271730 es una cadena válida de 26 caracteres para la encriptación de 128-bit .)", //help369
	"En vez de entrar un nombre para la regla de aplicación especial, puede seleccionarlo en la lista de aplicaciones comunes, y el resto de valores de configuración se incluirán en ella como corresponde.", //help48a
	"Configuración inalámbrica", //LW38
	"se ha de especificar la cuenta de usuario", //GW_DYNDNS_USER_NAME_INVALID
	"La dirección IP de destino es la dirección del host o de la red a la que quiere acceder.", //hhav_r_dest_ip
	"El número de puerto admin remoto no es válido.", //YM175
	"Wi-Fi Protected Setup se usa para añadir fácilmente dispositivos a una red por medio de un PIN o un botón. Los dispositivos han de admitir Wi-Fi Protected Setup para que puedan configurarse con este método.", //LY3
	"Entrada UPnP añadida %v <-> %v:%d <-> %v:%d %s tiempo de espera:%d '%s'", //GW_UPNP_IGD_PORTMAP_ADD
	"UPnP entra en conflicto con la entrada existente %v <-> %v:%d <-> %v:%d %s '%s'", //GW_UPNP_IGD_PORTMAP_CONFLICT
	"Mensaje", //KRA1
	"Puerto", //_vs_port
	"<warn>La tabla de control de acceso se esta reconfigurando porque se ha cambiado la subred de la LAN.</warn>", //GW_INET_ACL_RECONFIGURED_WARNING
	"Habilita el funcionamiento 802.11d. 802.11d es una especificación inalámbrica para el funcionamiento en dominios reguladores adicionales. Este suplemento a las especificaciones 802.11 define las necesidades de capa física (canalización, patrones de salto, nuevos valores para atributos MIB actuales y otros requisitos para ampliar el funcionamiento de las WLAN 802.11 a nuevos dominios reguladores (países). El estándar actual 802.11 define el funcionamiento para solo unos pocos dominios reguladores (países). Este suplemento añade los requisitos y definiciones necesarios que permiten a los equipos de WLAN 802.11 funcionar en mercados que no tienen el estándar actual. Habilite esta opción si se encuentra en unos de estos 'dominios reguladores adicionales'.", //help186
	"Para la mayoría de aplicaciones, los clasificadores de prioridad garantizan las prioridades correctas, y no se requieren reglas WISH específicas.", //YM145
	"Desacti", //WIFISC_AP_UNSET_SELECTED_REGISTRAR
	"No se puede especificar el DNS secundario si no se da también un primario.", //GW_WAN_DNS_SERVER_SECONDARY_WITHOUT_PRIMARY_INVALID
	"WISH (Wireless Intelligent Stream Handling) prioriza el tráfico de", //YM72
	"Consejos útiles", //_hints
	"%s': primer puerto local, %u, ha de ser menor que el último puerto local, %u", //GW_QOS_RULES_LOCAL_PORT
	"La dirección IP de inicio local no es válida.", //YM52
	"Chat", //_aa_bsecure_chat
	"IP de destino", //help104
	"Tenga en cuenta que, en la actual implementación de WCN de Microsoft, no puede guardar los parámetros inalámbricos si ya existe un perfil con el mismo nombre. Para sal", //help839
	"La dirección IP de la WAN no es válida", //YM99
	"Por edad", //_aa_bsecure_byage
	"El nombre '%s' ya existe.", //GW_INET_ACL_NAME_DUPLICATE_INVALID
	"La dirección final del servidor DHCP %v no es válida en la subred de la LAN %v.", //GW_DHCP_SERVER_POOL_TO_INVALID
	"En curso", //KR26
	"¿Quiere habilitar la entrada de reserva DHCP para la dirección IP?", //YM92
	"La IP reservada %v no es válida", //GW_DHCP_SERVER_RESERVED_IP_INVALID
	"En el menú desplegable se pueden seleccionar las opciones más comunes: UDP, TCP, y UDP y TCP .", //help19x1
	"Inestable", //_aa_bsecure_unstable
	"La dirección IP reservada %v debe estar en el rango DHCP configurado.", //GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID
	"La regla de filtro '%s' no se puede eliminar ni renombrar porque está en uso.", //GW_FIREWALL_FILTER_NAME_INVALID
	"Puede necesitar este archivo más adelante para cargar su configuración en caso de que se hayan restaurado los parámetros por defecto del router.", //ZM19
	"Vídeo (VI)", //YM80
	"Dirección IP del servidor WINS secundario", //bd_NETBIOS_WINS_2
	"Reinicializa el área Añadir/actualizar de la pantalla, con lo que se borran todos los cambios que haya podido hacer antes de hacer clic en el botón Añadir/actualizar.", //KR57
	"Activo", //YM164
	"La dirección IP no está permitida", //_logsyslog_alert2
	"Mejor esfuerzo.", //YM149
	"El tiempo de espera del servidor DHCP no es válido", //LT120
	"Automático (WPA o WPA2) - Personal", //KR48
	"El intervalo de reconexión %u no es válido (ha de estar comprendido entre 20 y 180)", //GW_WAN_RECONNECT_INTERVAL_INVALID
	"Controla el filtrado de punto final para paquetes de protocolo TCP.", //YM139
	"El puerto inicio remoto debe estar comprendido entre 0 y 65535 inclusive.", //YM61
	"<warn>La tabla de servidor virtual se esta reconfigurando porque se ha cambiado la subred de la LAN.</warn>", //GW_NAT_VIRTUAL_SERVER_TABLE_RECONFIGURED_WARNING
	"Necesita reiniciar", //YM1
	"Longitud de la clave WEP", //bws_WKL
	"PIN (Número de identificación personal)", //wps_p3_2
	"Los parámetros se han guardado correctamente", //KR102
	"%s': Local IP start '%v' no está en la subred de la LAN", //GW_QOS_RULES_LOCAL_IP_START_SUBNET
	"La dirección IP PPTP %v no es válida", //GW_WAN_PPTP_IP_ADDRESS_INVALID
	"Alcohol", //_aa_bsecure_alcohol
	"Los nombres de reglas de filtro de puertos no pueden estar duplicados.", //YM14
	"El modo Dynamic Turbo no está permitido con 802.11b.", //GW_WLAN_11B_DYNAMIC_TURBO_INVALID
	"Entrada UPnP finalizada  %v <-> %v:%d <-> %v%d %s '%s'", //GW_UPNP_IGD_PORTMAP_EXPIRE
	"Una vez que el router está configurado como lo desea, puede guardar los parámetros de configuración en un archivo de configuración. Puede que necesite este archivo para poder cargar la configuración más adelante en el caso de que se restablezcan los parámetros predeterminados del router. Para guardar la configuración, haga clic en el botón <strong>Guardar configuración</strong>.", //TA18
	"Esta opción está disponible solo cuando el <span class='option'>modo 802.11</span> está establecido como <span class='option'>Solo 802.11ng</span>.", //aw_erpe_h2
	"El primer puerto de destino para el filtro de puerto no es válido", //YM21
	"Aquí se introduce la prioridad del flujo del mensaje. Están definidas cuatro prioridades:", //YM147
	"Cuando está activada la opción de mensaje de correo de registro, los mensajes de registro se envían a internet a través del router ascendente.", //KR68
	"Este asistente le ayuda a añadir dispositivos inalámbricos a la red inalámbrica.", //LW61
	"DEBE especificarse un nombre de usuario de L2TP", //GW_WAN_L2TP_USERNAME_INVALID
	"La IP de WINS secundario no es válida", //LT120z
	"WPA/WPA2", //KR97
	"La máscara de subred L2TP %v no es válida", //GW_WAN_L2TP_SUBNET_INVALID
	"Guardar parámetros en el disco duro local", //help_ts_ss
	"Automóvil", //_aa_bsecure_automobile
	"Agregar dispositivo inalámbrico con WPS", //LW13
	"Periodo de tiempo", //sch_time
	"Para proteger su privacidad, puede configurar características de seguridad inalámbrica. Este dispositivo admite tres modos de seguridad inalámbrica: WEP, WPA-Personal y WPA-Enterprise. WEP es el estándar de encriptación inalámbrica original. WPA ofrece un mayor grado de seguridad. WPA-Personal no requiere un servidor de autentificación. La opción WPA-Enterprise requiere un servidor RADIUS externo.", //bws_intro_WlsSec
	"DEBE especificarse una contraseña PPPoE", //GW_WAN_PPPOE_PASSWORD_INVALID
	"Antes de usar el asistente WCN del router, ha de ejecutar el Asistente de configuración de red inalámbrica en su PC. Si todavía no lo ha hecho, baja al Panel de control de Windows y seleccione Asistente de configuración de red inalámbrica. Cuando el asistente le presente las opciones de «Usar una unidad flash USB» o «Configurar una red manualmente», elija la segunda. (De hecho, no tendrá que hacer la configuración manualmente; se lle", //help211
	"La máscara de subred no es válida", //LS202
	"Hora final", //tsc_EndTime
	"Este asistente le guiará a través de los pasos necesarios para añadir un dispositivo inalámbrico a su red inalámbrica.", //KR34
	"Clave WEP 3", //_wepkey3
	"Rango de puerto remoto", //at_RePortR
	"OSPF", //help640
	"La dirección del servidor indicada (%s) no es válida", //GW_SMTP_SERVER_ADDRESS_INVALID
	"La dirección IP del gateway L2TP no es válida: %v", //GW_WAN_L2TP_GATEWAY_IP_ADDRESS_INVALID
	"Muestra el valor actual del PIN del router.", //LW58
	"Clave en uso", //LW22usekey
	"No se permite el modo turbo estático con 802.11b", //GW_WLAN_11B_STATIC_TURBO_INVALID
	"La dirección IP final de destino no es válida.", //YM67
	"<warn>Cambiar los parámetros de seguridad inalámbrica puede hacer que Wi-Fi Protected Setup no funcione como se espera.</warn>", //GW_WIFISC_CFG_CHANGED_WARNING
	"Reiniciar durante la petición DNS", //ZM10
	"No se puede usar el canal 802.11b/g si el modo 802.11 es 802.11a.", //GW_WLAN_11A_CHANNEL_INVALID
	"Reglas QoS Engine", //at_title_SERules
	"El puerto admin remoto debe estar en el rango de 1 a 65535.", //YM176
	"NetBIOS permite a los hosts de la  LAN que descubran otros ordenadores dentro de la red; por ejemplo, dentro del vecindario de la red.", //KR81
	"Puerto TCP", //GW_NAT_TCP_PORT
	"La regla se aplica a un flujo de mensajes cuyo número puerto del host 2 está dentro del rango definido aquí.", //YM155
	"Este modo es compatible con dispositivos anteriores sin Turbo (antiguos). Se ha habilitar este modo cuando en la red inalámbrica hay algunos dispositivos sin Turbo pero que admiten otras características Super G mencionadas anteriormente.", //help365
	"Àmbito NetBIOS", //bd_NETBIOS_SCOPE
	"Sesión abortada", //KR28
	"Filtro web", //_webfilter
	"El número de paquetes de agregación no es válido", //YM33
	"Automático", //YM76
	"Desbloquear configuración de punto de acceso", //WIFISC_AP_SETUP_UNLOCKED
	"El servidor virtual '%s' no puede usar el puerto de administración de la WAN HTTPS del router, %u", //GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"Liberar", //LS313
	"Asistente Windows Connect Now de Microsoft", //bwz_WCNWz
	"Servidor de entrada a DNS Lookup", //ZM9
	"La dirección IP reservada para está dirección MAC(%m) ya está activa.", //GW_DHCP_SERVER_RESERVED_MAC_UNIQUENESS_INVALID
	"Parámetros PIN", //LY5
	"Para la mayoría de las aplicaciones, los clasificadores de prioridad aseguran las prioridades correctas y no se necesitan reglas WISH específicas.", //YM87
	"El nombre de filtro de Ping WAN %s no existe", //GW_NAT_WAN_PING_FILTER_INVALID
	"Si el sistema operativo de su PC es Windows XP Service Pack 2 (SP2) o superior y su navegador es Windows Internet Explorer (IE), puede utilizar esta opción para guardar partes de la clave de los parámetros de seguridad inalámbrica actuales del router en su PC con la tecnología Windows Connect Now (WCN). Los parámetros estarán disponibles para transmitirlos a otros dispositivos inalámbricos.", //help835
	"(1..255)", //at_lowpriority
	"Se requiere un nombre para el número %d de regla", //YM49
	"No puede añadir la nueva dirección IP %v. Solo puede reutilizar direcciones IP de otras políticas.", //GW_INET_ACCESS_POLICY_TOO_MANY_IP_INVALID
	"Dirección IP del servidor L2TP no válida", //YM112
	"H-Node es un estado híbrido de funcionamiento. Primero se prueban los servidores WINS, si hay alguno, y después se difunde por la red local. Este suele ser el modo favorito si ha configurado servidores WINS .", //KR90
	"Tenga en cuenta que WCN solo guarda unos pocos parámetros de seguridad inalámbrica. Cuando use WCN para transmitir los parámetros a otros dispositivos inalámbricos, puede tener que definir manualmente otros parámetros en esos dispositivos.", //help838
	"Habilite esta opción sólo si usted ha comprado su propio nombre de dominio y lo ha registrado con un proveedor de servicios de DNS dinámico. Los parámetros siguientes se muestran si la opción está habilitada.", //help892
	"Si está usando la opción PPPoE, necesitará quitar o deshabilitar cualquier software de cliente PPPoE de sus ordenadores", //KR73
	"Hay", //wwl_intro_s3_2
	"La métrica para la ruta no es válida", //_r_alert5
	"<warn>El nombre de filtro de Ping WAN  %s ya no existe, el PING WAN se deshabilitará.</warn>", //GW_NAT_WAN_PING_FILTER_WARNING
	"La dirección IP final local no es válida.", //YM53
	"Tenga en cuenta que WCN solo establece algunas de las opciones inalámbricas. Habrá de ir a la página <a href='wireless.asp'>Parámetros inalámbricos</a> para establecer otras opciones inalámbricas, como  el modo Super G y la tasa de transmisión.", //help215
	"WISH es la sigla de Wireless Intelligent Stream Handling, una tecnología desarrollada para mejorar su experiencia de usar una red inalámbrica, por medio de la priorización del tráfico de diferentes aplicaciones.", //YM140
	"La dirección del servidor DHCP %v ha sido rechazada por el dispositivo de red. Si dispone de más de un servidor  DHCP en su red, pueden darse conflictos de dirección IP.", //GW_DHCPSERVER_REJECTED
	"Permite al router reconocer transferencias HTTP para muchos canales continuos de audio y vídeo, y priorizarlos respecto al resto de tráfico. Tales canales son usados  con frecuencia por los reproductores de medios digitales.", //YM142
	"La contraseña no es válida", //GW_SMTP_PASSWORD_INVALID
	"La regla se aplica a un flujo de mensajes para los que la dirección IP del ordenador falla dentro del rango establecido aquí.", //YM152
	"El rango IP final del servidor DHCP no es válido", //LT119a
	"Si tiene problemas para acceder a internet a través del router, compruebe los parámetros que ha introducido en esta página y verifíquelos con su  ISP si es necesario.", //LW36
	"El algoritmo de encriptación usado para garantizar la comunicación de los datos. TKIP (Temporal Key Integrity Protocol) ofrece generación de clave por paquete y se basa en WEP. AES (Advanced Encryption Standard) es una encriptación muy segura basada en el bloqueo. Con la opción «TKIP y AES», el router negocia el tipo de cifrado con el cliente, y usa AES cuando está disponible.", //help377
	"%s '%s' no es válido.", //GW_NAT_PORT_TRIGGER_PORT_RANGE_INVALID
	"Las claves WEP no son válidas", //YM121
	"El umbral de fragmentación no es válido", //YM29
	"La página de sesiones WISH muestra todos los detalles de las sesiones inalámbricas locales activas que pasan por el router cuando WISH está habilitado. Una sesión WISH es una conversación entre un programa o aplicación que está en un ordenador del lado de la LAN inalámbrica y otro ordenador, con independencia de cómo esté conectado.", //YM159
	"El número de puerto no es válido", //YM120
	"MEJOR", //wwl_BETTER
	"Habilite la opción DMZ solo como último recurso. Si tiene problemas al usar una aplicación desde un ordenador que está detrás del router, pruebe primero a abrir puertos asociados con la aplicación en los apartados <a href='adv_virtual.asp' onclick='return jump_if();'>Servidor virtual</a> o <a href='adv_portforward.asp' onclick='return jump_if();'>Direccionamiento de puerto</a>.", //hhaf_dmz
	"La máscara de subred PPTP no es válida", //YM106
	"Bloquear sitios no clasificados", //_aa_bsecure_block_unrated
	"Se ha de especificar un nombre de usuario Big Pond", //GW_WAN_BIGPOND_USERNAME_INVALID
	"Por ejemplo, 192.168.0.101.", //KR76
	"El servidor DHCP no puede ofrecer más direcciones IP porque todas las direcciones disponibles se están usando. Aumente el número de direcciones IP disponibles en la configuración del servidor DHCP.", //GW_DHCPSERVER_EXHAUSTED
	"La dirección IP del servidor L2TP no es válida: %v", //GW_WAN_L2TP_SERVER_IP_ADDRESS_INVALID
	"La contraseña WEP ha de tener exactamente 13 caracteres alfanuméricos.", //wwl_alert_pv5_2
	"La ruta de la subred %v no es válida", //GW_ROUTES_SUBNET_INVALID
	"Drogas", //_aa_bsecure_drugs
	"La dirección IP no puede ser igual a la dirección IP de LAN del router.", //LW1
	"Un ordenador de red no ha renovado su «arrendamiento»de %v y ha perdido el derecho a usar esa dirección. Si el dispositivo sigue usando esa dirección, puede crear conflictos de dirección IP.", //GW_DHCPSERVER_EXPIRED
	"La dirección IP %v debe estar dentro de la subred de la LAN (%v).", //GW_INET_ACL_IP_ADDRESS_IN_LAN_SUBNET_INVALID
	"Solo difusión (usar cuando no hay servidores WINS configurados)", //bd_NETBIOS_REG_TYPE_B
	"Finanzas", //_aa_bsecure_financial
	"La NAT envía peticiones de conexión entrante a un host del lado LAN solo cuando provienen de la misma dirección IP con la que se ha establecido la conexión. Esto permite a la aplicación remota enviar datos a través de un puerto distinto al usado cuando se creó la sesión saliente.", //YM135
	"Rango de IP de inicio del servidor DHCP no válido", //LT119
	"Público", //_vs_public
	"B-Node indica que SOLO se usa la difusión de red local. Este parámetro es útil cuando no hay servidores WINS disponibles; sin embargo, es mejor que primero pruebe el funcionamiento M-Node.", //KR93
	"Administración remota del gateway habilitada en puerto: %u", //GW_SECURE_REMOTE_ADMINSTRATION
	"La dirección IP y, donde corresponde, el número de puerto del ordenador que ha originado una conexión de red.", //YM160
	"IP asignada", //LS423
	"La dirección IP del gateway L2TP %v ha de estar dentro de la subred de la WAN.", //GW_WAN_L2TP_GATEWAY_IN_SUBNET_INVALID
	"%s': la primera IP del host 1, %v, ha de ser menor que la última IP del host 1, %v", //GW_WISH_RULES_HOST1_IP
	"Privado", //_vs_private
	"Este parámetro no es efectivo si «Conocer información NetBIOS desde la WAN» está activado.", //KR86
	"Dirección IP del WINS secundario", //bd_NETBIOS_SEC_WINS
	"La dirección IP inicio ha de ser menor que la dirección IP final: %v-%v.", //GW_INET_ACL_START_IP_ADDRESS_INVALID
	"Autenticación", //auth
	"No se puede detener el proceso", //KR24
	"5 GHz", //KR17
	"Rango IP del host 2", //YM84
	"Una regla de calidad de servicio (QoS) identifica un flujo de mensaje específico y asigna una prioridad a dicho flujo.", //help88
	"Al habilitar la gestión remota, usted y otras personas podrán cambiar la configuración del router desde un ordenador de internet.", //hhta_en
	"La dirección IP PPPoE no es válida", //YM103
	"En modo bridge, el dispositivo admite", //KR64
	"Por solicitud reguladora, no se puede usar los canales52-140 si no se habilita la detección por radar.", //GW_WLAN_11A_DFS_CHANNEL_INVALID
	"Configuración protegida Wi-Fi", //LW4
	"Capa física", //help645
	"En modo Turbo Static 11a, el canal debe ser uno de los valores: 42, 50, 58, 152 o 160.", //GW_WLAN_11A_STATIC_TURBO_INVALID
	"Modo súper G™", //help358
	"No dispone de permisos para realizar la acción especificada.", //YM6
	"Selección de categorías", //_aa_bsecure_categ_select
	"La prioridad ha de ser un número comprendido entre 1 y 255 inclusive.", //YM58
	"Joven (13-17)", //_aa_bsecure_age_youth
	"Haga clic en <strong>Asistente para añadir dispositivos inalámbricos</strong> para usar Wi-Fi Protected Setup a fin de añadir dispositivos inalámbricos a la red inalámbrica.", //LW17
	"Dirección IP final de destino no válida para el filtro de puerto", //YM18
	"WPA2-PSK/AES (también llamada WPA2 Personal)", //LT210
	"El tiempo de inactividad no es válido (el rango permitido es de %u a %u)", //GW_WAN_IDLE_TIME_INVALID
	"Dirección del grupo de multidifusión", //YM186
	"Deportes", //_aa_bsecure_sports
	"El nombre '%s' ya está en uso.", //GW_QOS_RULES_NAME_ALREADY_USED
	"El siguiente asistente usa la tecnología Windows Connect Now de Microsoft para configurar automáticamente los parámetros inalámbricos en el router. Asegúrese de que ha ejecutado correctamente el asistente de configuración inalámbrica de red  de Microsoft en su ordenador antes de usar esta característica.", //bwz_intro_WCNWz
	"La tabla del servidor DHCP para %v no está en la subred de la LAN %v.", //GW_DHCP_SERVER_POOL_TO_IN_SUBNET_INVALID
	"<warn>H.323 se ha habilitado automáticamente porque lo requiere una entrada de servidor virtual creada por usted.</warn>", //GW_NAT_H323_ALG_ACTIVATED_WARNING
	"Aislamiento L2", //KR4
	"La IP del WINS primario no es válida", //LT120y
	"Los parámetros de red Wi-Fi Protected Setup se han guardado correctamente.", //KR103
	"Teléfono IP Calista", //YM44
	"Si se considera un usuario avanzado y ha configurado anteriormente un router inalámbrico, haga clic en <strong>Configuración manual de red inalámbrica</strong> para introducir todos los parámetros manualmente.", //LW47
	"Ha fallado la exportación del archivo de configuración WIFISC_AP_SET_APSETTINGS_COMPLETE,SetAPSettings por (%s) completado", //GW_XML_CONFIG_GET_FAILED
	"Establecer parámetros AP por (%s) completado", //WIFISC_AP_SET_APSETTINGS_COMPLETE
	"Longitud de la clave WEP", //wwl_WKL
	"La comunicación con el router ha fallado", //YM168
	"El nombre '%s' ya está en uso.", //GW_NAT_NAME_USED_INVALID
	"El valor de índice del servidor %d no es válido", //GW_DYNDNS_SERVER_INDEX_VALUE_INVALID
	"[WARN]", //WARN
	"Empresa", //LW23
	"Red avanzada", //ADVANCED_NETWORK
	"DEBE especificarse una contraseña PPTP", //GW_WAN_PPTP_PASSWORD_INVALID
	"Restaurar el PIN por defecto del router.", //LW59
	"Si ha habilitado la seguridad inalámbrica, asegúrese de de que ha tomado nota de la clave o frase secreta que ha configurado. Necesitará introducir esta información en todos los dispositivos inalámbricos que conecte a su red inalámbrica.", //YM126
	"Activado", //_enabled
	"La interfaz para la ruta no es válida", //_r_alert4
	"Añadir estación inalámbrica", //LY10
	"La dirección inicio del servidor DHCP %v no es válida en la subred de la LAN %v.", //GW_DHCP_SERVER_POOL_FROM_INVALID
	"Bloquear configuración del punto de acceso", //WIFISC_AP_SETUP_LOCKED
	"¿Quiere desechar los cambios realizados en la entrada de reserva?", //YM91
	"Ha fallado el establecimiento del registrador seleccionado, razón (%s), err_code (%u)", //WIFISC_AP_SET_SELECTED_REGISTRAR_FAIL
	"No se ha cambiado nada, ¿desea guardar?", //_ask_nochange
	"Desconocido", //GW_NAT_UNKNOWN
	"En modo Turbo Dynamic 11a, el canal debe ser uno de los valores: 40, 48, 56, 153 o 161.", //GW_WLAN_11A_DYNAMIC_TURBO_INVALID
	"Tenga en cuenta que, incluso cuando el servidor NTP está habilitado, ha de elegir una zona horaria y definir los parámetros del horario de verano.", //YM163
	"Para usar esta característica, ha de disponer de una cuenta de DNS dinámico con uno de los proveedores que figuran en el menú desplegable.", //YM181
	"Permiso insuficiente", //_cantapplysettings_1
	"Advertencias", //YM11
	"(de 8 a 63 caracteres)", //wwl_wsp_chars_2
	"Dirección IP del WINS primario", //bd_NETBIOS_PRI_WINS
	"Clave WEP por defecto para usar", //wwl_DWKL
	"PIN del dispositivo inalámbrico", //KR44
	"obj_word +  está en conflicto con el puerto del servidor virtual.", //TEXT056
	"La dirección IP del servidor no es válida", //YM130
	"Seleccionar servidor DNS dinámico", //KR99
	"La dirección IP del WINS primario ha de estar especificada si también está especificada la secundaria.", //GW_DHCP_SERVER_PRIMARY_AND_SECONDARY_WINS_IP_INVALID
	"Habilitar comprobación anti-spoof", //KR106
	"El número de protocolo '%s' del servidor virtual, %d, ha de ser 0 o estar comprendido entre 3 y 255.", //GW_NAT_VS_PROTOCOL_INVALID
	"Seleccione esta opción si quiere configurar manualmente la red", //KR52
	"Bienvenido al asistente para añadir dispositivos inalámbricos", //KR33
	"Ha de haber entrado en el sistema como «admin» para lle", //ZM23
	"Este asistente se ha creado para ayudarlo en la conexión de un dispositivo inalámbrico al router, y lo guiará a través de las instrucciones detalladas sobre cómo conectar el dispositivo. Haga clic en el botón que figura a continuación para empezar.", //LW40
	"Bloquear los parámetros de seguridad inalámbrica", //LY4
	"Si se considera un usuario avanzado y ha configurado anteriormente un router inalámbrico, haga clic en <strong>Configuración manual de la conexión a internet</strong> para introducir todos los parámetros manualmente.", //LW34
	"¿Está seguro que quiere eliminarlo?", //YM25
	"Dirección IP de inicio de destino no válida para el filtro de puerto", //YM15
	"Modo&nbsp;Súper&nbsp;G&trade;", //bwl_SGM
	"La dirección del servidor RADIUS no es válida.", //GW_WLAN_80211X_RADIUS_INVALID
	"%s': Protocolo, %u, ha de estar comprendido entre 0 y 257", //GW_WISH_RULES_PROTOCOL
	"Entrar en el sistema", //LS316
	"El usuario ha salido del sistema", //ZM15
	"<warn>Se ha deshabilitado un reserva DHCP porque entra en conflicto con la IP de la LAN de los routers.</warn>", //GW_DHCP_SERVER_RESERVATION_DISABLED_IN_CONFLICT_WARNING
	"Se ha de especificar el host", //GW_DYNDNS_HOST_NAME_INVALID
	"Configuración manual de red inalámbrica", //LW42
	"La dirección IP del gateway PPTP no es válida: %v", //GW_WAN_PPTP_GATEWAY_IP_ADDRESS_INVALID
	"El archivo de configuración restaurado se ha cargado correctamente.", //rs_intro_4
	"%s': la última IP remota '%v' está en la subred de la LAN", //GW_QOS_RULES_REMOTE_IP_END_SUBNET
	"N/A", //_NA
	"La dirección IP del gateway es la dirección IP del  router, si hay, usada para alcanzar el destino especificado.", //hhav_r_gateway
	"[INFO]", //INFO
	"Métrico", //help112
	"Nota: algunas actualizaciones de firmware restablecen las opciones de configuración en los valores predeterminados de fábrica. Antes de realizar una actualización, asegúrese de guardar la configuración actual en la pantalla.\nMöchten Sie die Aktualisierung wirklich durchführen?", //tf_msg_FWUgReset
	"Conocer la información NetBIOS desde la WAN", //bd_NETBIOS_WAN
	"Forzar short slot para los clientes 11N", //aw_igslot
	"(el valor predeterminado no coincide con nada)", //ZM2
	"No tiene permisos para lle", //LT7
	"Establecer el registrador seleccionado", //WIFISC_AP_SET_SELECTED_REGISTRAR
	"Cuando se han completado los preparativos necesarios, la tecnología WCN transmitirá los parámetros de la red inalámbrica desde su PC hasta el router. Después deberá reiniciar el router para que los parámetros sean efectivos.", //help214
	"Ambos", //at_Both
	"Día de la semana", //ZM22
	"Restaurar los parámetros por defecto", //help_ts_rfd
	"Si el sistema operativo de su PC es Windows XP Service Pack 2 (SP2) o superior y su navegador es Windows Internet Explorer (IE), puede utilizar la tecnología Windows Connect Now (WCN) como ayuda para la configuración de los parámetros de seguridad inalámbrica del router", //help209
	"el puerto inicio de destino debe estar comprendido entre 0 y 65535 inclusive.", //YM70
	"UPnP ha cambiado VS entrada %v <-> %v:%d <-> %v:%d %s por %s", //GW_UPNP_IGD_PORTMAP_VS_CHANGE
	"EL apartado de filtro web es uno de los dos medios por los que puede especificar los sitios web a los quiere permitir el acceso. También tiene la opción de usar el servicio de control parental centinela, que le permite especificar numerosas categorías de sitios web y evitarse la molestia de tener que introducir las URL de los determinados sitios web. Si desea más información acerca del servicio centinela, vaya a <a href='../Tools/Sentinel.shtml'>Herramientas &rarr; Centinela</a>.", //help143s
	"Este modo no es compatible con los dispositivos sin turbo antiguos. Solo debe estar habilitado cuando todos los dispositivos de la red inalámbrica tienen habilitado Static Turbo.", //help363
	"Grupo de noticias web", //_aa_bsecure_web_newsgroup
	"La dirección del DNS primario no es válida", //YM128
	"%s de '%s' no puede estar vacío.", //GW_NAT_PORT_TRIGGER_PORT_RANGE_EMPTY_INVALID
	"La tecnología StreamEngine&trade; se aplica a las transmisiones multimedia que se producen entre el lado WAN del router de subida y los clientes del bridge.", //KR72
	"Contraseña o clave", //td_PWK
	"Rango IP del host 1", //YM82
	"El tiempo de espera de la autentificación no es válido.", //YM119
	"El bridge puede analizar el tráfico en el lado WAN del router ascendente para determinar la velocidad de su conexión WAN.", //KR70
	"La dirección IP y, donde corresponde, el número de puerto del ordenador hacia el que se ha establecido una conexión de red.", //YM161
	"El tamaño de la tabla del servidor DHCP es demasiado grande (no puede haber más de 256 direcciones).", //GW_DHCP_SERVER_POOL_SIZE_INVALID
	"Establecido", //_sdi_s4b
	"Servidor de autentificación DNS Lookup", //ZM8
	"La dirección del DNS secundario no es válida", //YM129
	"La longitud máxima de las claves ASCII de 64-bit es de 5 caracteres (DMODE es una cadena válida de 5 caracteres para la encriptación de 64-bit.)", //help370
	"El bloqueo de los parámetros de seguridad inalámbrica evita que los parámetros puedan ser modificados por cualquier registro externo nuevo que use su PIN. Los dispositivos se pueden añadir a la red inalámbrica usando Wi-Fi Protected Setup. Es posible cambiar los parámetros de red inalámbrica con <a href='wireless.asp' shape='rect'>Configuración manual de la red inalámbrica</a>, <a href='wizard_wlan.asp' shape='rect'>Asistente de configuración de la red inalámbrica</a>, o un registrador gestor de WLAN  externo existente.", //LY29
	"Aviso mientras se escribe el archivo de configuración: %s", //GW_XML_CONFIG_WRITE_WARN
	"El nombre '%s' ya está en uso", //GW_FIREWALL_NAME_INVALID
	"%s': la primera IP del host 2, %v, ha de ser menor que la última IP del host 2, %v", //GW_WISH_RULES_HOST2_IP
	"Página del producto", //TA2
	"Conectar", //LS314
	"Tipo de tráfico", //_vs_traffictype
	"El valor del tiempo de espera no puede ser mayor que 8760.", //GW_DYNDNS_TIMEOUT_TOO_BIG_INVALID
	"Introduzca el PIN de su dispositivo inalámbrico y haga clic en el botón \"Conectar\" siguiente", //wps_p3_4
	"Seleccione esta opción si su dispositivo inalámbrico admite la configuración protegida Wi-Fi", //KR51
	"La dirección IP del gateway PPTP %v ha de estar dentro de la subred de la WAN.", //GW_WAN_PPTP_GATEWAY_IN_SUBNET_INVALID
	"Haga clic en el botón <span class='button_ref'>Guardar con Windows Connect Now</span>, y la tecnología WCN capturará los parámetros de red inalámbrica de su router y los guardará en su PC.", //help837
	"Seleccione antes un nombre de aplicación", //TEXT052
	"Abierto", //OPEN
	"Nuevos", //_aa_bsecure_news
	"Actualizar", //YM34
	"Wireless avanzado", //_advwls
	"<warn>La reserva DHCP %v se ha deshabilitado porque la tabla DHCP es demasiado pequeña.</warn>", //GW_DHCP_SERVER_RESERVATION_DISABLED_OUT_OF_POOL_WARNING
	"Los parámetros de filtro MAC bloquearán todas las máquinas. Esto no está permitido.", //GW_MAC_FILTER_ALL_LOCKED_OUT_INVALID
	"Clave WEP 4", //_wepkey4
	"opcional", //LT124
	"Motor de búsqueda", //_aa_bsecure_search_engine
	"Solo WPA'", //KR47
	"Si elige la opción de seguridad WEP, este dispositivo  <strong>SOLO</strong> funcionará en <strong>modo inalámbrico antiguo (802.11B/G)</strong>. Esto significa que <strong>NO</strong> obtendrá el rendimiento 11N puesto que la especificación draft 11N no admite WEP.", //bws_msg_WEP_3
	"<warn>La dirección del servidor de correo electrónico entre en conflicto con la dirección LAN del router; el correo electrónico se deshabilitará.</warn>", //GW_SMTP_LAN_ADDRESS_CONFLICT_WARNING
	"El modo IP de la LAN no es válido", //GW_LAN_IP_MODE_INVALID
	"El servidor Big Pond especificado no es un nombre de dominio o una dirección IP correctos.", //GW_WAN_BIGPOND_SERVER_NOTSTD15
	"El umbral de fragmentación debe estar comprendido entre 256 y 2346.", //GW_WLAN_FRAGMENT_THRESHOLD_INVALID
	"El nombre de dominio asignado no es válido", //GW_LAN_DOMAIN_NAME_INVALID
	"El nombre de dispositivo asignado no es válido", //GW_LAN_DEVICE_NAME_INVALID
	"Se ha detectado coincidencia de sesiones", //_wifisc_overlap
	"El asistente mostrará los parámetros de red inalámbrica para guiarle a través de la configuración manual, le pedirá que introduzca el PIN del dispositivo o le indicará que pulse el botón de configuración del dispositivo. Si el dispositivo admite Wi-Fi Protected Setup y tiene un botón de configuración, puede añadirlo a la red simplemente pulsando el botón de configuración del dispositivo y luego el del router en 60 segundos. El LED de estado del router parpadeará tres veces si el dispositivo se ha añadido correctamente a la red.", //LW62
	"El proceso se ha detenido. Puede hacer clic en el botón Cancelar para volver a la página inicial del asistente y reiniciar el proceso", //KR23
	"Pornografía", //_aa_bsecure_pornography
	"El nombre no puede ser una cadena vacía.", //GW_NAT_NAME_INVALID
	"Número de clientes dinámicos DHCP", //bd_title_clients
	"Dirección IP del servidor PPTP no válida", //YM108
	"La dirección IP final de destino no está en la subred de la LAN", //YM19
	"STA con MAC (%m) registrado en", //WIFISC_AP_PROXY_PROCESS_COMPLETE
	"El registro '%s' es un duplicado de '%s'.", //GW_NAT_ENTRY_DUPLICATED_INVALID
	"%s' [%s:%s] entra en conflicto con '%s'[%s:%s] en diferentes direcciones IP.", //GW_NAT_PORT_FORWARD_CONFLICT_INVALID
	"¿Está seguro de que quiere realizar la actualización?", //YM38
	"El servidor NTP no está configurado", //tt_alert_nontp
	"Configuración protegida Wi-Fi", //LY2
	"Se ha detectado diferencia en PIN (2ª mitad)", //KR29
	"Sesión finalizada", //KR31
	"Inicio erróneo", //_init_fail
	"el puerto inicio de origen debe estar comprendido entre 0 y 65535 inclusive.", //YM68
	"Dirección MAC", //sd_macaddr
	"Modo de puerto WAN", //KR12
	"Un método de cifrado de datos para la comunicación inalámbrica, diseñado para proporcionar el mismo nivel de intimidad que una red con cables. WEP no es tan seguro como el cifrado WPA. Para acceder a una red WEP, debe conocer la clave. La clave es una cadena de caracteres que crea el usuario. Al utilizar WEP, debe determinar el nivel de cifrado. El tipo de cifrado determina la longitud de la clave. Un cifrado de 128 bits requiere una clave más larga que el cifrado de 64 bits. Las claves se definen introduciendo una cadena en formato HEX (hexadecimal, que utiliza caracteres 0 a 9, A a F) o ASCII (American Standard Code for Information Interchange, caracteres alfanuméricos). El formato ASCII se facilita para que pueda introducir una cadena más fácil de recordar. La cadena ASCII se convierte a formato HEX para utilizarla en la red. Se definen cuatro claves para que pueda cambiar de clave fácilmente. Se selecciona una clave predeterminada para utilizarla en la red.", //help366
	"Punto de acceso registrado en el registrador (%s) a través de %s", //WIFISC_AP_REGISTRATION_COMPLETE
	"Máxima ganancia TPC", //aw_TPC
	"Dirección MAC del punto de acceso WDS", //aw_WDSMAC
	"El puerto final remoto debe estar comprendido entre 0 y 65535 inclusive.", //YM62
	"Protección extra para las redes inalámbricas 11b vecinas. Desactive esta opción para reducir el efecto adverso de las redes antiguas en el rendimiento 802.11ng.", //aw_erpe_h
	"El modo de reconexión no es válido", //GW_WAN_RECONNECT_MODE_INVALID
	"DelAPSettings por (%s) completado", //WIFISC_AP_DEL_APSETTINGS_COMPLETE
	"Solo la cuenta «Admin» puede cambiar los parámetros de seguridad.", //LW15
	"Si es principiante en redes y nunca ha configurado un router, haga clic en <strong>Asistente de configuración de la conexión a internet</strong>, y el router lo guiará a través de los pocos pasos que lo lle", //LW33
	"Correcto. Para añadir otro dispositivo, haga clic en el botón Cancelar o en el botón Estado inalámbrico para comprobar el estado inalámbrico.", //KR27
	"Controla el filtrado de punto final para los paquetes del protocolo UDP.", //YM138
	"%s' [%s:%d]->%v/%d entra en conflicto con'%s' [%s:%d]->%v:%d.", //GW_NAT_VS_PORT_CONFLICT_INVALID
	"Dirección IP del servidor WINS primario", //bd_NETBIOS_WINS_1
	"Paso 5: Categorías de centinela", //_aa_wiz_s6_title
	"Reglas WISH", //YM77
	"QoS", //YM48
	"La reserva de dirección IP no es válida", //YM89
	"La clave precompartida debe ser de caracteres HEX si su longitud es 64.", //GW_WLAN_WPA_PSK_HEX_STRING_INVALID
	"La dirección IP de la WAN  %v no es válida", //GW_WAN_WAN_IP_ADDRESS_INVALID
	"¿Desea renunciar a todos los cambios realizados en esta página?", //LS4
	"El proveedor de servicio DNS dinámico no se admite.", //KR98
	"Background (menos urgente).", //YM148
	"Automático (WPA o WPA2)", //bws_WPAM_2
	"Si quiere recibir una notificación cuando haya nuevo firmware, seleccione la casilla que figura junto a <span class='option'>Notificación por correo electrónico por nueva versión de firmware</span>.", //help877a
	"Añadir/actualizar", //KR56
	"Nombre de host", //LS424
	"La direcciones del servidor DHCP %v ha sido rechazada por el dispositivo de red. Compruebe su red por posibles conflictos de dirección IP.", //GW_DHCPSERVER_DECLINED
	"No se ha seleccionado ningún día", //GW_SCHEDULES_DAY_INVALID
	"UDP", //GW_NAT_UDP
	"No se puede establecer conexión con el servidor de correo electrónico", //IPSMTPCLIENT_CANNOT_CREATE_CONNECTION
	"Comprobarlo todo", //_aa_check_all
	"Reno", //LS312
	"La dirección IP no es válida", //KR2
	"Protocolo", //_vs_proto
	"La dirección del destinatario (%s) no es válida", //GW_SMTP_TO_ADDRESS_INVALID
	"El punto de acceso ha fallado al registrarse en el registrador (%s) a través de %s, razón (%s), err code (%u)", //WIFISC_AP_REGISTRATION_FAIL
	"El nombre '%s' ya está en uso.", //GW_WISH_RULES_NAME_ALREADY_USED
	"Cuando una aplicación LAN que usa un protocolo distinto a UDP, TCP o ICMP inicia una sesión en internet, la NAT del router puede rastrearla, incluso aunque no reconozca el protocolo. Esta característica es útil porque habilita ciertas aplicaciones (lo que es más importante, una conexión VPN a un host remoto) sin necesitar un ALG.", //LW48
	"La dirección IP inicio remota no es válida.", //YM54
	"PIN actual", //LW9
	"Este asistente se ha creado para ayudarlo en la configuración de la red inalámbrica. Y lo guiará a través de las instrucciones detalladas sobre cómo configurar su red inalámbrica y hacerla segura.", //LW41
	"Habilitar el rastreo automático de canal", //ebwl_AChan
	"El umbral RTS debe estar comprendido entre 1 y 2347.", //GW_WLAN_RTS_THRESHOLD_INVALID
	"Se ha de especificar una contraseña L2TP", //GW_WAN_L2TP_PASSWORD_INVALID
	"Algunos cambios de configuración afectan a otros parámetros del sistema. Dichos cambios pueden afectar de forma negativa, lanzando advertencias que se le deben notificar. Una advertencia puede indicar que se ha modificado, o incluso desactivado, una característica, para que coincida con las nuevas condiciones de funcionamiento.", //YM12
	"El usuario está saliendo del sistema", //ZM14
	"En este caso, el término «puerto» se refiere a los conectores Ethernet del dispositivo.", //KR60
	"El umbral RTS no es válido", //YM28
	"La programación no es válida.", //YM184
	"Si quiere utilizar nuestros fáciles asistentes basados en web para que lo ayuden en la configuración de la tecnología Windows Connect Now de Microsoft, haga clic en el botón Asistente de configuración que figura más abajo.", //int_intro_WCNWz7
	"Clave compartida", //bws_Auth_2
	"El archivo de configuración restaurado no es correcto. Es posible que haya restaurado un archivo que no es para este dispositivo o que el archivo esté corrompido.", //rs_intro_1
	"El protocolo usado por los mensajes.", //help92
	"Ambos", //GW_NAT_BOTH
	"Se ha restaurado correctamente", //rs_success
	"(GMT+01:00) Budapest, Viena, Praga, Varsovia", //up_tz_29b
	"Día", //day
	"<warn>Se está deshabilitando el servidor DHCP porque la subred de la LAN no es la apropiada.</warn>", //GW_DHCP_SERVER_DISABLED_WARNING
	"Contraseña", //_password
	"La dirección MAC %m no es válida.", //GW_INET_ACCESS_POLICY_MAC_INVALID
	"Configuración protegida Wi-Fi", //LW2
	"Asigne una dirección IP que no esté siendo utilizada del rango de direcciones IP disponible para la  LAN.", //KR75
	"La grabación del archivo de configuración ha fallado: %s", //GW_XML_CONFIG_WRITE_FAILED
	"Habilitar WISH", //YM73
	"El nombre '%s' ya está en uso.", //GW_WISH_RULES_NAME_USED_INVALID
	"El tamaño de la tabla del servidor DHCP es demasiado grande para la subred de la LAN %v.", //GW_DHCP_SERVER_POOL_SIZE_IN_SUBNET_INVALID
	"Tamaño máximo de agregación", //aw_AS
	"Esta es una lista de todas las conversaciones activas en las que hay clientes inalámbricos de la red local.", //YM171
	"La IP reservada %v entra en conflicto con la dirección IP de la LAN configurada", //GW_DHCP_SERVER_RESERVED_IP_NOT_LAN_IP_INVALID
	"El servidor virtual '%s' no puede usar el puerto de administración de la WAN HTTP del router, %u", //GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT
	"El campo máscara de subred identifica la parte de la IP de destino que está en uso.", //hhav_r_netmask
	"LISTA DE SERVIDORES VIRTUALES", //vs_vslist
	"CORTAFUEGOS DE IPv6", //if_iflist
	"Tenga en cuenta que algunas de estas opciones pueden interactuar con otras restricciones de puerto. El filtrado independiente del punto final tiene prioridad sobre los filtros entrantes o las programaciones; por ello, es posible, para una petición de sesión entrante relacionada con una sesión saliente, entrar a través de un puerto en vez de a través de un filtro entrante de ese puerto. No obstante, los paquetes se recharazán cuando se envíen a puerto bloqueado (ya esté bloqueado por una programación o por un filtro entrante) para el que no hay sesiones activas. El filtrado restringido de direcciones y puertos garantiza que los filtros entrantes y las programaciones funcionan con precisión, pero impide un cierto nivel de conectividad, y, por consiguiente, puede ser necesario usar puertos triggers, servidores virtuales o direccionamiento de puerto para abrir los puertos que necesita la aplicación. El filtrado restringido de direcciones lleva a una posición de equilibrio, que evita los problemas de comunicación con determinados tipos de router NAT (las NAT simétricas en particular), pero permite que los filtros entrantes y el acceso programado funcionen como se espera.", //YM137
	"Clasificadores de prioridad", //YM74
	"La dirección IP del servidor de registro del sistema %v no está en la subred de la LAN.", //GW_SYSLOG_ADDRESS_IN_SUBNET_INVALID
	"Active esta opción si tiene un servidor syslog actualmente en la LAN y desea enviarle mensajes de registro.", //help858
	"La dirección MAC ya está en uso: %s", //GW_MAC_FILTER_MAC_UNIQUENESS_INVALID
	"Botón", //KR40
	"El filtro de dirección MAC no puede ser una dirección NULA: %m", //GW_MAC_FILTER_NULL_MAC_INVALID
	"32 Kbytes", //aw_32
	"La subred de la WAN entra en conflicto con la subred de la LAN", //GW_WAN_LAN_SUBNET_CONFLICT_INVALID
	"Activado/Configurado", //LW66
	"DelAPSettings por (%s) ha fallado, razón (%s), err_code (%u)", //WIFISC_AP_DEL_APSETTINGS_FAIL
	"(13 caracteres o 26 dígitos hexadecimales)", //wwl_wsp_chars_1
	"Los servidores WINS guardan información sobre los hosts de la red, lo que permite que los hosts que «registren» a sí mismos y descubran otros hosts disponibles; por ejemplo, para usar en el vecindario de la red.", //KR85
	"El tamaño de la MTU no es válido", //YM115
	"Rango de puerto del host 1", //YM83
	"128 bits", //wwl_128bits
	"Cuando se produce un excesivo número de colisiones de paquetes inalámbricos, se puede mejorar el rendimiento inalámbrico usando el protocolo de negociación RTS/CTS (Request to Send/Clear to Send).", //LW51
	"Ha de introducir un valor numérico comprendido entre 0 y 8760 inclusive.", //YM178
	"Sectas", //_aa_bsecure_cults
	"Prohibido", //YM5
	"Comprobación de actualizaciones de firmware", //KR65
	"Las actualizaciones del firmware se publican periódicamente para mejorar la funcionalidad de su router y para añadirle características. Si tiene algún problema con una determinada característica del router, compruebe su hay disponible alguna actualización del firmware para su router.", //ZM17
	"<strong>Habilitar</strong> si otros dispositivos inalámbricos que quiere incluir en la red local admiten Wi-Fi Protected Setup.", //LW14
	"Guardar en Windows Connect Now", //ta_wcn_bv
	"El servidor virtual '%s' no puede usar la dirección IP del router, %v.", //GW_NAT_VS_IP_ADDRESS_CAN_NOT_MATCH_ROUTER
	"El programa '%s' no se puede eliminar o renombrar porque se está utilizando.", //GW_SCHEDULES_IN_USE_INVALID
	"Clave WEP 3", //wepkey3
	"Estimación de velocidad en internet", //KR69
	"Charla AIM", //YM43
	"ICQ", //YM45
	"El nombre de usuario no es válido", //GW_SMTP_USERNAME_INVALID
	"Super G con Static Turbo", //help362
	"Si quiere recibir una notificación cuando haya nuevo firmware, seleccione la casilla que figura junto a <span class='option'>Notificación por correo electrónico por nueva versión de firmware</span>.", //tf_intro_FWChA
	"PC REMOTO", //_remotedesktop
	"Parámetros PIN", //LW7
	"El modo Super G Turbo ha de usar el canal 6 para la comunicación. Con Super G con Static Turbo, se ha de establecer <span class='option'>modo 802.11 Mode</span> para 802.11g. Para que el funcionamiento sea correcto, el umbral RTS y el umbral de fragmentación de la pantalla <a href='adv_wlan_perform.asp'>Avanzado &rarr;Parámetros inalámbricos avanzados</a>han de estar con sus valores por defecto.", //help359
	"Configure la dirección IP del servidor WINS que prefiera.", //KR84
	"DTIM debe estar comprendido entre 1 y 255.", //YM30
	"Rango de puerto local", //at_LoPortR
	"La tabla del servidor DHCP DE %v no está en la subred de la LAN %v.", //GW_DHCP_SERVER_POOL_FROM_IN_SUBNET_INVALID
	"El filtro de direcciones MAC no puede tener formato de dirección de multidifusión: %m", //GW_MAC_FILTER_MULTICAST_MAC_INVALID
	"<warn>La inicialización del correo electrónico ha fallado</warn>", //GW_SMTP_INIT_FAILED_WARNING
	"El servidor DHCP se ha detenido", //GW_DHCPSERVER_STOP
	"Para proteger su privacidad, puede usar el modo de seguridad inalámbrica para configurar características de seguridad inalámbrica. Este dispositivo admite tres modos de seguridad inalámbrica: WEP, WPA-Personal y WPA-Enterprise. WEP es el estándar de encriptación inalámbrica original. WPA ofrece un mayor grado de seguridad. WPA-Personal no requiere un servidor de autentificación. La opción WPA-Enterprise requiere un servidor RADIUS externo.", //help350
	"La dirección DMZ %v no está permitida.", //GW_NAT_DMZ_NOT_ALLOWED_INVALID
	"Cuando se habilita, esta opción hace que el router automáticamente intente priorizar los canales continuos de tráfico que, de otro modo, no reconocería, a partir del comportamiento que muestran dichos canales. Y se eliminar la prioridad de los canales continuos que manifiestan características de tráfico masivo, como transferencias de archivos, mientras que dejan el tráfico interactivo, como juegos o VoIP, con su prioridad normal.", //YM143
	"La importación del archivo de configuración GW_NAT_PORT_DUP_INVALID,%s '%s' de '%s' no debe contener números duplicados.", //GW_XML_CONFIG_SET_FAILED
	"%s '%s' de '%s' no debe contener números duplicados.", //GW_NAT_PORT_DUP_INVALID
	"segundos para que se conecte el dispositivo inalámbrico. Si desea detener el proceso, haga clic en el botón Cancelar siguiente.", //KR46
	"Paso 1: Seleccione el método de configuración para su red inalámbrica", //KR35
	"Se ha de especificar una contraseña Big Pond", //GW_WAN_BIGPOND_PASSWORD_INVALID
	"Se ha de especificar el protocolo.", //YM57
	"Se ha de reiniciar el router antes de que los parámetros sean efectivo. Puede reiniciarlo ahora, o seguir realizando cambio y reiniciarlo más tarde.", //KR104
	"el formato de la dirección del remitente no es correcto", //IPSMTPCLIENT_MSG_WRONG_SENDER_ADDR_FORMAT
	"CERRAR SESIÓN", //LS317
	"Las contraseñas introducidas no coinciden", //YM102
	"Si se activa WDS, este punto de acceso funcionará como un repetidor inalámbrico capaz de establecer comunicación con otros AP a través de enlaces WDS. Se debe tener en cuenta que WDS no es compatible con WPA. Por tanto, no es posible utilizar ambas características a la vez. Los enlaces WDS son bidireccionales; en consecuencia, es preciso que este AP conozca la dirección MAC del otro AP (para crear el enlace WDS), al tiempo que el otro AP debe disponer de un enlace WDS que le conecte con este AP.", //help188
	"La dirección IP no es válida", //_logsyslog_alert1
	"Dirección MAC no válida", //KR3
	"Odio", //_aa_bsecure_hate
	"No puede usar el canal 802.11a cuando el modo 802.11 es 802.11b/g.", //GW_WLAN_11BG_CHANNEL_INVALID
	"El cálculo de velocidad se ha completado", //RATE_ESTIMATOR_RATE_COMPLETED
	"La clave WEP ha de tener exactamente 26 dígitos hexadecimales (0-9 o A-F).", //wwl_alert_pv5_3
	"Límite de agregación", //aw_aggr
	"Iniciado", //_wifisc_addstart
	"Especifique la interfaz LAN o WAN que debe usar el paquete IP para salir del router, cuando se usa la ruta.", //help111
	"%s': primera IP remota '%v' está en la subred de la LAN", //GW_QOS_RULES_REMOTE_IP_START_SUBNET
	"El último puerto de destino para el filtro de filtro no es válido", //YM22
	"No se puede usar una dirección MAC de multidifusión en WDS.", //GW_WLAN_WDS_MAC_ADDR_INVALID
	"Restablecer el PIN con su valor por defecto", //LW10
	"Esta parte de la pantalla presenta los parámetros de configuración de la página <a href='wireless.asp'>Configuración &rarr; Parámetros inalámbricos</a>. La <span class='option'>dirección MAC</span> es el identificador de la tarjeta inalámbrica asignado por defecto.", //LT291
	"En este apartado se definen la reglas WISH.", //YM156
	"Adolescente (9-12)", //_aa_bsecure_age_ado
	"Seleccione esta opción si sus adaptadores inalámbricos NO ADMITEN WPA", //wwl_text_good
	"%s': Prioridad, %d, ha de estar comprendida entre 1 y 255", //GW_QOS_RULES_PRIORITY_RANGE
	"Con programación temporal", //te_OnSch
	"Correo web", //_aa_bsecure_web_mail
	"Asegúrese de que los puntos de acceso están configurados con el mismo número de canal.", //help188b
	"La dirección IP inicio (%v) de '%s' no debe estar dentro de la subred de la LAN (%v).", //GW_INET_ACL_START_IP_ADDRESS_IN_LAN_SUBNET_INVALID
	"Regulación del tráfico WAN", //at_title_Traff
	"Especifica una mitad del enlace WDS. El otro punto de acceso ha de tener también la dirección MAC de este punto de acceso para crear el enlace WDS hacia este punto de acceso.", //help189
	"Se ha detectado un radar inalámbrico, cambie al canal %d", //GW_WIRELESS_SWITCH_CHANNEL
	"Se ha de especificar un servidor Big Pond", //GW_WAN_BIGPOND_SERVER_INVALID
	"Error de análisis del archivo de configuración en la línea %u carácter %u", //GW_XML_CONFIG_SET_PARSE
	"Habilitar <strong>WMM</strong> podría ayudar a controlar la latencia e inestabilidad al transmitir el contenido multimedia por una conexión inalámbrica.", //hhaw_wmm
	"Esta zona de la pantalla refleja los parámetros de configuración de la página <a href=\"wireless.asp\">Configuración &rarr; Parámetros inalámbricos</a>, de la página <a href=\"adv_wish.asp\">Opciones avanzadas &rarr; WISH</a> y la página <a href=\"../Advanced/Protected_Setup.shtml\">Opciones avanzadas &rarr; Configuración protegida Wi-Fi</a>. La <span class=\"option\">Dirección MAC</span> es el identificador de la tarjeta inalámbrica asignado en la fábrica.", //LT290wifisc
	"El nombre de la regla no puede ser una cadena vacía", //GW_FIREWALL_RULE_NAME_INVALID
	"Programación", //GW_NAT_SCHEDULE
	"Especifica el próximo salto que se ha de realizar si se usa esta ruta. Un gateway de 0.0.0.0 implica que no hay próximo salto, y la dirección IP que coincide es directamente conectada al router de la interfaz especificada: LAN o WAN.", //help109
	"El modo RIP no es válido", //GW_LAN_RIP_MODE_INVALID
	"El transmisor inalámbrico empezará a enviar tramas RTS  (y a esperar CTS) cuando el tamaño de las tramas de datos en bytes sea superior al umbral RTS.", //LW52
	"Ventanas emergentes", //_aa_bsecure_popups
	"El modo solo WPA2 no admite TKIP.", //GW_WLAN_WPA_WPA2_TKIP_INVALID
	"2.4GHz", //KR16
	"Servidor virtual", //_vs_title
	"CORTAFUEGOS DE IPv6", //_if_title
	"Se ha de especificar un nombre de usuario PPPoE", //GW_WAN_PPPOE_USERNAME_INVALID
	"La máscara de subred PPTP %v no es válida", //GW_WAN_PPTP_SUBNET_INVALID
	"El ámbito NetBIOS no es una forma válida", //GW_DHCP_SERVER_NETBIOS_SCOPE_INVALID
	"El modo IP estática siempre está activado, por ello no hay botones de acción disponibles.", //KR94
	"DESEA", //YM63
	"Puerta de enlace", //help108
	"Esta programación ya está en uso en '%s'", //GW_SCHEDULES_DUPLICATED_INVALID
	"Solo WPA", //bws_WPAM_1
	"El puerto público debe estar en el rango (1 - 65535) para el servidor virtual.", //KR11
	"Si ya dispone de un servidor DHCP en su red o utiliza direcciones IP estáticas en todos los dispositivos de su red, desmarque <strong>Habilitar servidor DHCP</strong> para deshabilitar esta característica.", //LW45
	"Final de IP remota", //KR6
	"El tipo de registro NetBIOS no es válido", //GW_DHCP_SERVER_NETBIOS_TYPE_INVALID
	"Juegos", //_aa_bsecure_games
	"Seleccione esta opción si desea configurar el dispositivo inalámbrico manualmente", //KR42
	"El tiempo de inactividad no es válido", //YM104
	"Vales", //_aa_bsecure_tickets
	"Seleccione esta opción su dispositivo inalámbrico admite PIN", //KR39
	"Modo mixto (difusión y punto a punto)", //bd_NETBIOS_REG_TYPE_M
	"Introduzca arriba un nombre de host o una dirección IP y haga clic en \"Ping\"", //tsc_pingt_msg1
	"Entrada UPnP eliminada %v <-> %v:%d %s", //GW_UPNP_IGD_PORTMAP_DEL
	"La dirección IP del gateway L2TP no es válida", //YM111
	"Desconectar", //LS315
	"La longitud de la clave no es correcta, debe tener entre 8 y 64 caracteres", //GW_WLAN_WPA_PSK_LEN_INVALID
	"Permitir a cualquier usuario WAN el acceso a la capacidad relacionada.", //help178
	"Obteniendo la lista de sesiones activas. Espere", //YM167
	"La longitud máxima de las claves ASCII de 128-bit es de 13 caracteres (2002HALOSWIN1 es una cadena válida de 13 caracteres para la encriptación de 128-bit).", //help371
	"Anarquía", //_aa_bsecure_anarchy
	"Reiniciar más tarde", //YM4
	"Información criminal", //_aa_bsecure_criminal_skills
	"Los avisos han aumentado como consecuencia de unos cambios en la configuración.\nEl sistema no puede generar una lista de esos avisos ahora, pero lo intentará.", //YM188
	"Las opciones de filtrado de punto final de la NAT controlan cómo la NAT del router gestionar las peticiones de conexión entrante a los puertos que ya se están usando.", //YM133
	"El puerto inicio local debe estar comprendido entre 0 y 65535 inclusive.", //YM59
	"Manualmente", //_aa_bsecure_manually
	"La dirección de correo electrónico no está configurada.", //YM169
	"Use este apartado para configurar los parámetros de red internos de su router. La dirección IP configurada aquí es la dirección IP que usa para acceder a la interfaz de gestión basada en web. Si cambia aquí la dirección IP, es posible que tenga que ajustar los parámetros de red del PC para poder acceder de nuevo a la red.", //YM97
	"Niño (0-8)", //_aa_bsecure_age_child
	"WPA es el estándar más antiguo; selecciones esta opción si los clientes que usará con el router solo admiten el estándar más antiguo. WPA2 es la nueva implementación del más potente estándar de seguridad IEEE 802.11i . Con la opción «WPA2», el router intenta primero con WPA2 , pero pasa a  WPA si el cliente solo admite WPA. Con la opción «Solo WPA2», el router se asocia solo con los clientes que también admiten la seguridad WPA2.", //help375
	"La dirección de este sitio web '%s' no es válida.", //GW_WEB_FILTER_WEBSITE_INVALID_INVALID
	"Semana", //ZM21
	"Sesiones de internet", //YM157
	"El control ActiveX WCN proporciona el enlace WCN necesario entre el router y su PC a través del navegador que comunica los datos de configuración inalámbrica sin una unidad flash USB. El navegador intentará descargar el control ActiveX WCN, si no está ya en su ordenador. Para que esto se realice correctamente, ha de estar establecida la conexión WAN, y, en el navegador, el parámetro de seguridad de internet ha de estar definido como Medio o más bajo (seleccione Herramientas &rarr; Opciones de internet &rarr; Seguridad &rarr; Nivel personalizado &rarr; Medio).", //help213
	"¿Está seguro de que desea activar/desactivar", //YM24
	"PBC (Configuración del botón de pulsación)", //wps_p3_3
	"Si su red inalámbrica ya está configurada con Wi-Fi Protected Setup, la configuración manual de la red inalámbrica destruirá la red inalámbrica existente.", //LW43
	"En este apartado se definen las reglas de QoS Engine.", //help99_s
	"La reserva de dirección MAC no es válida", //YM90
	"TKIP y AES", //bws_CT_3
	"Tenga en cuenta que, si introduce menos caracteres en la clave WEP que los necesarios, el resto de la clave se sustituirá por ceros.", //help371_n
	"<warn>Se ha configurado una reserva DHCP  %v para %v, compruebe que cumple con los requisitos de su red.</warn>", //GW_DHCP_SERVER_RESERVATION_RECONFIG_WARNING
	"El gateway para la ruta no es válido", //_r_alert3
	"La métrica RIP no es válida", //GW_LAN_RIP_METRIC_INVALID
	"El intervalo de actualización de la clave de grupo WPA debe estar comprendido entre 30 y 65535 segundos.", //YM118
	"La dirección del gateway no es válida", //YM127
	"StreamEngine", //KR71
	"Habilitar WDS", //aw_WDSEn
	"Recibir mensaje desconocido", //KR32
	"Local", //sa_Local
	"El tiempo de inactividad no puede ser cero.", //GW_WEB_SERVER_IDLE_TIME
	"Esta opción controla cómo reacciona el dispositivo al tráfico en el conector WAN.", //KR59
	"La dirección IP del gateway de la WAN %v ha de estar dentro de la subred de la WAN.", //GW_WAN_WAN_GATEWAY_IN_SUBNET_INVALID
	"Rango de IP local", //at_LoIPR
	"Voz (VO)", //YM81
	"Número de paquetes de agregación", //aw_AP
	"Esta zona de la pantalla refleja los parámetros de configuración de la página <a href=\"wireless.asp\">Configuración &rarr; Parámetros inalámbricos</a> y de la página <a href=\"adv_wish.asp\">Opciones avanzadas &rarr; WISH</a>. La <span class=\"option\">Dirección MAC</span> es el identificador de la tarjeta inalámbrica asignado en la fábrica.", //LT290
	"La prioridad dada a los paquetes se ha enviado inalámbricamente durante esta conversación  por el WISH logic. Las prioridades son:", //YM162
	"Error de análisis del archivo de configuración (MIME)", //GW_XML_CONFIG_SET_PARSE_MIME
	"Puerto UDP", //GW_NAT_UDP_PORT
	"Correcto", //YM9
	"El tamaño de la MTU no es válido (el rango permitido es de %u a %u)", //GW_WAN_MTU_INVALID
	"Hay", //LW63
	"La estación %s (%m) se ha añadido correctamente", //WIFISC_IR_REGISTRATION_SUCCESS
	"La dirección IP de los paquetes que han tomado está ruta.", //help105
	"La dirección del servidor DHCP %v ha sido liberada por el dispositivo de red porque no quiere usarla más.", //GW_DHCPSERVER_RELEASED
	"Abrir el asistente de configuración de impresora", //LW32
	"SetAPSettings por (%s) ha fallado, razón (%s), err_code (%u)", //WIFISC_AP_SET_APSETTINGS_FAIL
	"Dirección IP no válida para la ruta", //KR8
	"El campo Nombre le permite especificar un nombre para identificar esta ruta; por ejemplo, «Red 2»", //hhav_r_name
	"Híbrido (punto a punto y difusión)", //bd_NETBIOS_REG_TYPE_H
	"Cuando la asignación no es perfecta, se pueden quitar las correspondencias sueltas entre los modos de clasificación en «cono» y «el filtrado de punto final»: Si este router está configurado para el filtrado independiente del punto final, implementa un comportamiento de cono completo; el filtrado restringido de direcciones implementa un comportamiento de cono restringido; y el filtrado restringido de direcciones y puertos implementa un comportamiento de cono restringido a puerto.", //KR55
	"La dirección IP PPPoE %v entrará en conflicto con la subred de la LAN", //GW_WAN_PPPOE_LAN_SUBNET_CONFLICT_INVALID
	"El archivo de configuración se ha importado correctamente", //GW_XML_CONFIG_SET_SUCCESS
	"El puerto final local debe estar comprendido entre 0 y 65535 inclusive.", //YM60
	"No se han podido guardar los parámetros", //KR100
	"Seleccione esta opción si el puerto WAN está conectado a internet. El dispositivo funciona como un router NAT.", //KR61
	"64 bit (10 dígitos hexadecimales)", //bws_WKL_0
	"Utilice el modo <strong>WPA o WPA2</strong> para lograr un equilibrio entre una seguridad sólida y la mejor compatibilidad. Este modo utiliza WPA para los clientes heredados, al mismo tiempo que mantiene una mayor seguridad con las estaciones compatibles con WPA2. Asimismo, se utilizará el cifrado más sólido que pueda admitir el cliente. Para mayor seguridad, utilice el modo <strong>Sólo WPA2</strong>. Este modo utiliza el cifrado AES(CCMP) y no se permite el acceso con seguridad WPA de las estaciones heredadas. Para obtener la máxima compatibilidad, utilice <strong>Sólo WPA</strong>. Este modo utiliza el cifrado TKIP. Algunos juegos y dispositivos heredados sólo funcionan en este modo.", //bws_msg_WPA
	"La dirección IP L2TP no es válida", //YM109
	"El restablecimiento por %s ha fallado razón (%s), err_code (%u)", //WIFISC_AP_RESET_FAIL
	"%s': el primer puerto del host 2, %u, debe ser inferior al último puerto del host 2, %u", //GW_WISH_RULES_HOST2_PORT
	"Cargar los parámetros desde el disco duro local", //help_ts_ls
	"La dirección IP del gateway de la WAN no es válida", //YM101
	"Automática", //KR50
	"El protocolo ha de ser un número", //YM56
	"URL/dominio del sitio web", //aa_WebSite_Domain
	"La máxima tasa de transmisión debe estar comprendida entre 8 kbps y 100 Mbps, inclusive.", //GW_QOS_RULES_MAX_TRANS
	"%s': El protocolo, %d, ha de estar comprendido entre 0 y 257", //GW_QOS_RULES_PROTOCOL
	"Ha de tener al menos un HTTP o HTTPS habilitado.", //GW_WEB_SERVER_NO_ACCESS
	"Configure la dirección IP del servidor WINS de respaldo, si lo hay", //KR87
	"%s' es un duplicado de '%s'", //GW_WISH_RULES_DUPLICATED
	"La dirección IP de inicio de destino no debe estar en la subred de LAN", //YM16
	"El nombre '%s' ya está en uso", //GW_SCHEDULES_NAME_CONFLICT_INVALID
	"Clave WEP 4", //wepkey4
	"HTTP y HTTPS no pueden estar en el mismo puerto WAN.", //GW_WEB_SERVER_SAME_PORT_WAN
	"La dirección IP final de origen no es válida", //YM65
	"Parámetros de red", //bln_title
	"STA con MAC (%m) ha fallado al registrarse, razón (%s), err_code (%u)", //WIFISC_AP_PROXY_PROCESS_FAIL
	"Más información", //_more
	"Enviar/recibir nombre de entrada", //ZM12
	"Titular", //_aa_bsecure_banner_ad
	"Estado inalámbrico", //LY23
	"Para la mayoría de aplicaciones, la clasificación automática será adecuada, y no se requerirán reglas específicas de QoS Engine.", //help88b
	"Seleccionar más de un canal continuo espacial puede mejorar el rendimiento, pero en algunos casos puede disminuir la calidad de la señal.", //bwl_NSS_h1
	"Nota: No conecte más de una unidad flash USB al enrutador ni siquiera cuando utilice un hub USB.", //help203
	"No hay una máquina definida en la política %s.", //GW_INET_ACL_NO_MACHINE_IN_LAN_SUBNET_INVALID
	"Antes de ejecutar estos asistentes, asegúrese de que ha seguido todos los pasos presentados en la guía de instalación rápida incluida en el paquete.", //LW39c
	"Set Selected Registrar completado", //WIFISC_AP_SET_SELECTED_REGISTRAR_COMPLETE
	"Nombre de cliente DHCP no válido", //GW_DHCP_CLIENT_CLIENT_NAME_INVALID
	"La recuperación de la lista de sesiones activas ha fallado. Se está intentando de nuevo", //YM166
	"Reinicio por %s fallo, razón (%s), err_code (%u)", //WIFISC_AP_REBOOT_FAIL
	"Aquí se introduce la prioridad del flujo de mensajes: 1 es la máxima prioridad (más urgente) y 255 es la mínima prioridad (menos urgente).", //help91
	"Los siguientes asistentes de configuración basados en la web están diseñados para ayudarle en la configuración de su red inalámbrica y en la conexión del dispositivo inalámbrico.", //LW39
	"La contraseña y la confirmación de la contraseña no coinciden. Vuelva a confirmar la contraseña de administración.", //YM173
	"Un nombre de regla de filtro de puerto no puede estar en blanco.", //YM13
	"Su navegador web es demasiado antiguo para usar esta página web. Actualice su navegador.", //YM172
	"La ganancia máxima TCP no es válida", //YM31
	"Seleccione las categorías de centinela que se han de filtrar.", //_aa_wiz_s6_msg
	"La contraseña sólo puede contener caracteres imprimibles.", //S493
	"Rango de puerto del host 2", //YM85
	"El campo \"Nombre\" no puede estar en blanco.", //GW_SCHEDULES_NAME_INVALID
	"El gateway no es válido", //LS204
	"16 Kbytes", //aw_16
	"(vaya a la página <a href='wireless.asp'> Configuración &rarr; Parámetros inalámbricos &rarr; Configuración manual de la red inalámbrica</a>.)", //aw_erpe_h3
	"Iniciar el asistente.", //LW64
	"Día(s)", //_days
	"Especifica si la entrada ha de estar habilitada o deshabilitada.", //help103
	"-", //YM183
	"El intervalo de actualización de la clave de grupo no es válido", //YM117
	"Antes, los términos «de cono completo», «de cono restringido», «de cono restringido a puerto» y «simétrica» se usaban par referirse a distintos tipos de NAT. Aquí no se usan estos términos porque no describen completamente el comportamiento de la NAT de este router.", //KR54
	"Esta página de enrutamiento le permite especificar rutas que determinan cómo se mueve los datos alrededor de su red.", //av_intro_r
	"La longitud de las claves hexadecimales de 64-bit es exactamente de 10 caracteres. (12345678FA es una cadena válida de 10 caracteres para la encriptación de 64-bit.)", //help368
	"Cada ruta tiene al lado una casilla de verificación, marque esta casilla si quiere que la ruta se habilite.", //hhav_enable
	"Se han de configurar los servidores DNS.", //GW_WAN_DNS_SERVERS_INVALID
	"Se ha restaurado correctamente", //_rs_succeeded
	"Se ha de especificar un nombre de usuario PPTP", //GW_WAN_PPTP_USERNAME_INVALID
	"Dirección IP %v de L2TP no válida", //GW_WAN_L2TP_IP_ADDRESS_INVALID
	"El nombre no puede ser una cadena vacía.", //GW_INET_ACL_NAME_INVALID
	"Días", //days
	"Este es un parámetro avanzado y suele dejarse en blanco. Permite configurar un nombre de «dominio» NetBIOS bajo el que funcionarán los hosts de la red.", //KR88
	"La dirección IP PPPoE %v no es válida", //GW_WAN_PPPOE_IP_ADDRESS_INVALID
	"Para que la seguridad sea buena, debe tener más longitud y no ser una frase conocida.", //KR19
	"El cálculo de velocidad se ha completado. La velocidad de subida es de %u kbps", //RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED
	"El beacon period no es válido", //YM27
	"Esta zona de la pantalla refleja los parámetros de configuración de la página <a href=\"wireless.asp\">Configuración &rarr; Parámetros inalámbricos</a> y de la página <a href=\"../Advanced/Protected_Setup.shtml\">Opciones avanzadas &rarr; Configuración protegida Wi-Fi</a>. La <span class=\"option\">Dirección MAC</span> es el identificador de la tarjeta inalámbrica asignado en la fábrica.", //LT291wifisc
	"Nombre de filtro de puertos", //KR1
	"Regla \'", //YM51
	"Enviar/recibir señal de monitorización del funcionamiento", //ZM13
	"El DNS primario no es válido.", //GW_LAN_PRIMARY_DNS_INVALID
	"En modo 11a no se puede usar Turbo.", //GW_WLAN_11A_DFS_TURBO_INVALID
	"Cambiar el nombre de la red inalámbrica es el primer paso para asegurar su red inalámbrica. Cámbielo por un nombre que le resulte familiar pero que no contenga información personal.", //YM123
	"Si en su red hay dispositivos que siempre han de tener direcciones IP fijas, añada una <strong>reserva DHCP</strong> para cada uno de estos dispositivos.", //TA8
	"Dirección IP no válida para el servidor virtual", //KR9
	"Por ejemplo, 192.168.0.1.", //KR79
	"El inicio de la IP remota de %s', '%v', debe ser inferior al final de la IP remota, '%v'", //GW_QOS_RULES_REMOTE_IP
	"Adulto (+18)", //_aa_bsecure_age_adult
	"No inicializado", //ZM7
	"El inicio de puerto de destino no debe ser superior al final de puerto de destino para el filtro de puertos", //YM23
	"Nota: Algunas actualizaciones de firmware restauran las opciones de configuración del router con sus valores por defecto.Antes de efectuar una actualización de la versión, asegúrese de guardar la configuración actual desde la pantalla Tools-System (herramientas-sistema).\n ¿Todavía desea actualizar la versión?", //tf_USSW
	"Habilitar la característica Wi-Fi Protected Setup.", //LW55
	"Activar red inalámbrica", //bwl_EW
	"Se agota", //LS425
	"Clave WEP", //wwl_WK
	"Generar nuevo PIN", //LW11
	"<warn>El ALG PPTP se ha habilitado automáticamente porque lo requiere una entrada del servidor virtual creada por usted.</warn>", //GW_NAT_PPTP_ALG_ACTIVATED_WARNING
	"¿Está seguro que quiere eliminarlo", //YM35
	"Seleccionar día(s)", //tsc_sel_days
	"El router se ha de reiniciar antes de que los parámetros restaurados sean efectivos. Puede reiniciarlo ahora, o seguir realizando cambios y reiniciarlo más tarde.", //sc_intro_rb4
	"La hora para el nombre de la programación no es válido: '%s'", //GW_SCHEDULES_TIME_INVALID
	"El tiempo de validez no es válido (ha de estar comprendido entre 1 y 65535)", //GW_DHCP_SERVER_LEASE_TIME_INVALID
	"No se puede enviar el mensaje de correo electrónico porque no se puede resolver la dirección IP del servidor", //IPSMTPCLIENT_NO_SERVER_IP_ADDRESS
	"El puerto privado debe estar en el rango (1 - 65535) para el servidor virtual.", //KR10
	"https es un protocolo no admitido.", //GW_WEB_FILTER_HTTPS_NOT_SUPPORTED_INVALID
	"El PIN del dispositivo inalámbrico debe tener 4 u 8 dígitos", //KR22
	"Ambos", //_vs_both
	"La contraseña de seguridad inalámbrica debe tener por lo menos 8 caracteres.", //wwl_alert_pv5_4
	"El punto de acceso no debe bloquearse antes de la configuración.", //GW_WIFISC_LOCK_VERIFY_ERR
	"Las tramas inalámbricas se pueden dividir en unidades más pequeñas (fragmentos) para mejorar el rendimiento ante interferencias de radiofrecuencia y en los límites de la cobertura de radiofrecuencia.", //LW53
	"La dirección del sitio web '%s' ya está en uso.", //GW_WEB_FILTER_WEB_SITE_IS_USED_INVALID
	"La dirección IP inicio de origen no es válida.", //YM64
	"La ruta de la interfaz no es válida", //GW_ROUTES_INTERFACE_INVALID
	"El DNS secundario no es válido.", //GW_LAN_SECONDARY_DNS_INVALID
	"Conocer NetBIOS desde la WAN", //bd_NETBIOS_LEARN_FROM_WAN_ENABLE
	"<warn>La tabla de direccionamiento de puerto se está reconfigurando porque la subred de la LAN ha cambiado.</warn>", //GW_NAT_PORT_FORWARDING_TABLE_RECONFIGURED_WARNING
	"Banda 802.11", //KR15
	"El punto de acceso ha fallado al registrarse en el registrador (%s) a través de %s, no esperado (%s), en estado (%s)", //WIFISC_AP_REGISTRATION_UNEXPECTED_EVENT
	"<warn>La dirección IP del servidor de registro del sistema no está en la subred de la LAN; puede tener que reconfigurarse.</warn>", //GW_SYSLOG_ADDRESS_NOT_IN_SUBNET_WARNING
	"La dirección IP WINS secundario no es válida.", //GW_DHCP_SERVER_NETBIOS_SECONDARY_WINS_INVALID
	"Tenga en cuenta que esta característica no se aplica al host DMS (si hay uno habilitado). El host DMZ siempre gestiona este tipo de sesiones.", //LW49
	"Añadir/actualizar regla de programa", //KR95
	"8 Kbytes", //aw_8
	"La dirección IP del servidor DNS secundario no es válida", //YM114
	"Tipo de cifrado", //bws_CT
	"Clasificación R", //_aa_bsecure_rrated
	"Bloquear los parámetros de seguridad inalámbrica", //LW6
	"También puede introducir cualquier cadena de texto en un cuadro de clave WEP, que se convertirá en una clave hexadecimal utilizando los valores ASCII de los caracteres. Se pueden introducir 5 caracteres de texto para las claves de 64 bits y 13 caracteres para las claves de 128 bits.", //bws_msg_WEP_2
	"El inicio de la IP local de %s', '%v', debe ser inferior al final de la IP local, '%v'", //GW_QOS_RULES_LOCAL_IP
	"La tabla de direcciones IP FROM no puede ser mayor que la de TO.", //GW_DHCP_SERVER_POOL_FROM_TO_ORIENTATION_INVALID
	"TKIP", //bws_CT_1
	"El bloqueo de la base de datos de configuración ha fallado GW_DHCP_SERVER_RESERVED_IP_UNIQUENESS_INVALID,La IP reservada %v entra en conflicto con otra reserva", //GW_XML_CONFIG_SET_LOCK
	"La IP reservada %v está en conflicto con otra reserva", //GW_DHCP_SERVER_RESERVED_IP_UNIQUENESS_INVALID
	"Clave WEP 2", //wepkey2
	"Opciones de conexión manual a internet", //LW28
	"Clave WEP 1", //_wepkey1
	"Desactive este parámetro para la configuración manual.", //KR83
	"La dirección IP del servidor de registro del sistema no es válida.", //GW_SYSLOG_ADDRESS_INVALID
	"La dirección IP PPTP no es válida", //YM105
	"Cliente DHCP", //ZM5
	"Control ActiveX WCN", //help212
	"Pulse el botón de pulsación en su dispositivo inalámbrico y haga clic en el botón \"Conectar\" siguiente en un plazo de 120 segundos", //wps_p3_5
	"Para especificar cualquier otro protocolo, seleccione «Otro» en la lista e introduzca el número de protocolo correspondiente (<a href='http://www.iana.org/assignments/protocol-numbers' target='_blank'> tal como ha sido asignado por IANA</a>) en la casilla <span class='option'>Protocolo</span>.", //help19x2
	"Paso 2: Conecte su dispositivo inalámbrico", //KR36
	"La métrica de ruta %u no es válida, debe ser de 1 a 16", //GW_ROUTES_METRIC_INVALID
	"El campo SSID no puede estar vacío.", //GW_WLAN_SSID_INVALID
	"La dirección IP no es válida", //LS46
	"El valor del tiempo de espera no puede ser menor que o igual a cero.", //YM179
	"La dirección IP del router de la red de área local. Por ejemplo, 192.168.0.1.", //KR78
	"El bridge comprueba en el sitio de asistencia si hay actualizaciones para el router ascendente.", //KR66
	"Revista", //_aa_bsecure_magazine
	"El dispositivo puede estar demasiado ocupado para recibirlo correctamente ahora. Vuelva a intentar guardar los parámetros.", //KR101
	"El modo Solo WPA no admite AES.", //GW_WLAN_WPA_WPA_AES_INVALID
	"Filtro entrante", //GW_NAT_INBOUND_FILTER
	"El nombre de la política no puede estar vacío.", //GW_INET_ACL_POLICY_NAME_INVALID
	"Internet", //sa_Internet
	"Red peer-to-peer (igual a igual) entre clientes inalámbricos", //help406
	"La regla se aplica a un flujo de mensajes para cuyo número de puerto del host 1 está dentro del rango establecido aquí.", //YM153
	"Rango de IP remota", //at_ReIPR
	"Se están aplicando una o más directivas de acceso a Internet. Se restringirá el acceso a Internet de acuerdo con estas directivas", //GW_INET_ACCESS_RESTRICTED
	"DTIM debe estar comprendido entre 1 y 255.", //GW_WLAN_DTIM_INVALID
	"Una regla WISH identifica un flujo de mensaje y le asigna una prioriza a dicho flujo.", //YM144
	"(GMT+01:00) Ámsterdam, Berlín, Berna, Roma, Estocolmo", //up_tz_26
	"Seleccione un filtro que controle el acceso según lo establecido por esta regla. Si no ve el filtro que necesita en la lista de filtros, vaya a la pantalla <a href='Inbound_Filter.asp'>Opciones avanzadas&nbsp;&rarr;&nbsp;Filtro de&nbsp;entrada</a> y cree un nuevo filtro.", //help71
	"HNAP AddPortMapping ha modificado %dth la entrada de servidor virtual de '%s' %v:%d<->%v:%d %S a '%s' %v:%d<->%v:%d %S", //GW_PURE_ADDPORTMAPPING_MODIFY
	"Usuario detenido", //tsc_pingt_msg10
	"La dirección IP de la impresora y el número de puerto TCP se muestran <a href='../Status/PS.shtml' onclick='return jump_if();'>aquí</a>.", //tps_foo
	"HNAP AddPortMapping ha modificado %dth la entrada del servidor virtual de '%s' %v:%d<->%v:%d %S a %S", //GW_PURE_ADDPORTMAPPING_CHG_PROTOCOL
	"El mensaje anterior se repite %d veces", //LOG_PREV_MSG_REPEATED_N_TIMES
	"La <strong>Contraseña</strong> se utiliza para verificar que está autorizado para realizar cambios en un dispositivo. Encontrará la contraseña impresa en la etiqueta de la parte posterior del dispositivo.", //ca_intro
	"Las direcciones de internet conocidas por DHCP entran en conflicto con las direcciones seleccionadas para el lado LAN. Las comunicaciones a internet se deshabilitarán hasta que haya cambiado las direcciones del lado LAN para solucionar el problema.", //GW_WAN_LAN_ADDRESS_CONFLICT_DHCP
	"En este apartado se muestran las reglas de filtro entrante actuales. Se puede cambiar una regla de filtro entrante haciendo clic en el icono Editar, o eliminarla haciendo clic en el icono Eliminar. Al hacer clic en el icono Editar, el elemento se destaca, y se activa el apartado «Actualizar regla de filtro entrante» para poder modificarla.", //help176
	"HNAP AddPortMapping ha creado %dth la entrada de servidor virtual '%s' %v:%d<->%v:%d %S", //GW_PURE_ADDPORTMAPPING_CREATE
	"Seleccione una programación para el momento de habilitación de la regla. Si no ve la programación que necesita en la lista de programaciones, vaya a la pantalla <a href='tools_schedules.asp' onclick='return jump_if();'>Herramientas &rarr; Programaciones</a> y cree una nueva programación.", //hhag_30
	"Haga clic en el botón <strong>Añadir</strong> o <strong>Actualizar</strong> para almacenar una regla finalizada en la lista de reglas siguiente.", //hhai_save
	"Administrador", //ADMIN
	"Se ha detectado la siguiente impresora. Haga clic en <em>Siguiente</em> para instalar la impresora en su ordenador.", //wprn_s1a
	"Las notificaciones por correo electrónico no están habilitadas.", //sl_alert_3
	"Tras configurar el router para DNS dinámico, puede abrir un navegador e ir a la URL de su dominio (por ejemplo, <code>http://www.midominio.info</code>), y el router intentará enviar la petición al puerto 80 de su LAN. Sin embargo, si hace esto desde un ordenador del lado LAN y no hay ningún servidor virtual definido en el puerto 80, el router volverá a la página de inicio de la configuración del router. Vaya a la página de configuración <a href='adv_virtual.asp'>Avanzado &rarr; Servidor virtual</a> para configurar un servidor virtual.", //help900
	"La dirección IP de la impresora y el nombre de la cola se muestran <a href='../Status/PS.shtml' onclick='return jump_if();'>aquí</a>.", //tps_foo2
	"Este parámetro debe permanecer en su valor predeterminado de  2.346 bytes.", //help182
	" -- La dirección IP debe estar en la subred de LAN.", //aa_alert_12
	"Para comprobar el firmware más reciente, haga clic en el botón [Compruebe ahora en línea...]. Si desea que se le avise cada vez que se distribuya nuevo firmware, marque la casilla junto a Notificación por correo electrónico de versión de firmware más reciente.", //tf_intro_FWCh
	"Guardar en la unidad de disco duro local", //ts_ss
	"Establezca la conexión con nombre de usuario y contraseña (PPTP)", //wwa_title_set_pptp
	"(p. ej.: me.midominio.net)", //_hostname_eg
	"Nota: Ha de introducir la misma contraseña como claves en este paso en sus clientes inalámbricos para habilitar la comunicación inalámbrica correcta.", //wwl_s4_note
	"Seleccione un filtro que controle el acceso tal como necesita este servidor virtual. Si no ve el filtro que necesita en la lista de filtros, vaya a la pantalla <a href='Inbound_Filter.asp'> Avanzado &rarr; Filtro entrante</a> y cree un nuevo filtro.", //help22
	"La contraseña de seguridad inalámbrica debe tener 13 caracteres alfanuméricos o 26 dígitos hexadecimales. Ha introducido", //wwl_alert_pv5_1
	"HNAP SetWLanSettings24 establece Habilitado %s, Difusión de SSID %s, Canal %d", //GW_PURE_SETWLANSETTINGS24
	"Especifique la dirección IP de LAN del ordenador de LAN en la que desee restringir la comunicación de Internet. Si este ordenador obtiene la dirección automáticamente utilizando DHCP, puede que desee hacer una reserva estática en la página <a href='adv_network.asp'>Configuración&rarr;Parámetros&nbsp;de red </a>, para que la dirección IP del equipo DMZ no cambie.", //help167
	"Se ha detectado xDSL u otra red Frame Relay", //at_DxDSL
	"El asistente de configuración de la impresora admite solo los sistemas operativos Windows XP/2000/98/ME . Su ordenador usa el sistema operativo <span id='wz_page_1_err_1_os'>&nbsp;</span>.", //wprn_bados2
	"El archivo de configuración que acaba de ejecutar mostrará una barra de progresión y le avisará en cuanto se haya completado la configuración. Entonces, haga clic en <em>Finalizar</em> para cerrar el asistente de configuración de la impresora.", //wprn_s3a
	"Si el ejecutable de configuración no se inicia automáticamente tras haberlo descargado en su ordenador, deberá abrir la carpeta en la que se encuentra el dichero que se ha descargado, usando el explorador, y hacer doble clic en el icono <em>Printer_Setup.exe.</em>", //wprn_tt10
	"Ping WAN <a href='Inbound_Filter.asp' onclick='return jump_if();'>Filtro entrante</a>", //bwn_IF
	"Tenga en cuenta que, no obstante, si en los parámetros del punto de acceso se especifica dirección «DHCP (dinámico)», y el servidor DHCP del router asigna un dominio al punto de acceso, este nombre de dominio anulará cualquier nombre que haya introducido aquí.", //_1044a
	"Intente concretar el problema con la impresora, luego haga clic en  <em>Actualizar</em> para actualizar el estado de la impresora.", //wprn_tt6
	"Seleccione un programa para los instantes en que esté vigente esta regla. Si no ve el programa que necesita en la lista de programas, vaya a la pantalla <a href='tools_schedules.asp'> Herramientas&nbsp;&rarr;&nbsp;Programas</a> y cree un nuevo programa.", //help72
	"Desconocido", //_sdi_s6
	"Seleccione una programación para cuando deba habilitarse el servicio. Si no ve la programación que necesita en la lista de programaciones, vaya a la pantalla <a href='tools_schedules.asp' onclick='return jump_if();'>Herramientas &rarr; Programaciones</a> y cree una nueva programación.", //hhpt_sch
	"Acti", //tps_enraw
	"Este registro se enviará a la dirección de correo electrónico", //sl_alert_2
	"10/100/1000 Mbps automático", //anet_wp_2
	"Restaurar todos los parámetros con sus valores por defecto.", //tss_RestAll
	"HNAP SetDeviceSettings establece el modo WAN en %S, %v/%v/%v", //GW_PURE_SETWANSETTINGS
	"Seleccione un programa para cuando esté vigente esta regla. Si no ve el programa que necesita en la lista de programas, vaya a la pantalla <a href='tools_schedules.asp'> Herramientas&nbsp;&rarr;&nbsp;Programas</a> y cree un nuevo programa.", //help53
	"Guarda la regla de filtro de entrada nueva o editada en la lista siguiente.", //help175
	"Si ha seleccionado la opción Según programación, seleccione una de las reglas de programación definidas. Si no ve la programación que necesita en la lista de programaciones, vaya a la pantalla <a href='tools_schedules.asp'>Herramientas &rarr; Programaciones</a> y cree una nueva programación", //help872
	"El estándar de transmisión utilizado por el cliente. Los valores son 11a, 11b, 11g y 11n para 802.11a, 802.11b, 802.11g o 802.11n, respectivamente.", //help785
	"Después de hacer clic en <em>Siguiente</em>, se le pedirá permiso para descargar un archivo ejecutable. Haga clic en <em>Ejecutar/abrir</em> para permitir que el ejecutable se ejecute en su ordenador. Si aparece una segunda ventana pidiéndole que verifique el editor, de nuevo haga clic en <em>Ejecutar</em>.", //wprn_s2b
	"El asistente lo guiará a través de los pasos siguientes. Haga clic en <em>Siguiente</em> para empezar.", //wprn_intro2
	"Seleccione un filtro", //GW_INET_ACL_NO_FILTER_SELECTED_INVALID
	"Si se activa esta opción, se enviará un mensaje de correo electrónico a la dirección configurada en la sección Correo electrónico cada vez que haya un nuevo firmware disponible. Para ello, es preciso activar la notificación por correo electrónico en la página <a href ='tools_email.asp'>Herramientas&rarr;Parámetros de&nbsp;Correo electrónico</a>.", //help890
	"La dirección IP y, cuando corresponda, el número de puerto de la aplicación local.", //help814
	"El intervalo de tiempo que la máquina puede estar inactiva antes de la que conexión PPTP se desconecte. El valor máximo del tiempo de inactividad solo lo usan los modos de reconexión «A demanda» y  «Manual».", //help283
	"Este protocolo de impresión está deshabilitado actualmente. Puede habilitarlo <a href='../Tools/PS.shtml' onclick='return jump_if();'>aquí</a>.", //sps_protdis
	"Select a filter that controls access as needed for this admin port. If you do not see the filter you need in the list of filters, go to the <a href ='Inbound_Filter.asp' onclick ='return jump_if();'>Advanced &rarr;&nbsp;Inbound&nbsp;Filter</a> screen an", //help831
	"Permiso insuficiente", //_cantapplysettings
	"Permite a los clientes H.323 (específicamente Microsoft NetMeeting) comunicarse a través de NAT. Tenga en cuenta que si desea que sus amigos le llamen, también deberá configurar un servidor virtual para NetMeeting. Consulte la página <a href='adv_virtual.asp'>Opciones avanzadas&nbsp;&rarr;&nbsp;Servidor&nbsp;virtual</a> para obtener información sobre cómo configurar un servidor virtual.", //help39
	"La configuración WCN se ha abortado debido a %s", //WCN_LOG_ABORT
	"(GMT+13:00) Nuku'alofa, Tonga", //up_tz_73
	"Los sitios web que figuran en la lista se usan cuando la opción de filtro web está habilitada en <a href='adv_access_control.asp'>Avanzado &rarr; Control de acceso</a>.", //help141_a
	"Los parámetros de firewall le permiten definir un único ordenador de su red en el otro lado del router.", //af_intro_x
	"Añadir/Actualizar regla de filtro de entrada", //help170
	"Para usar la impresora compartida desde este ordenador, ejecute el asistente de la impresora desde la página <a href='../Basic/Wizard.shtml' onclick='return jump_if();'> <i>Asistente</i></a>.", //tps_intro4
	"O bien, puede introducir un proveedor de servicios DNS dinámico manualmente.", //help893b
	"Servidor DHCP de inicio", //GW_DHCPSERVER_START
	"Algunas actualizaciones de firmware restablecen las opciones de configuración en los valores predeterminados de fábrica. Antes de realizar una actualización, asegúrese de guardar la configuración actual desde la pantalla <a href ='tools_system.asp'>Herramientas&rarr;Sistema</a>.", //help887
	"Permite a los servidores y clientes FTP transferir datos a través de NAT. Consulte la página <a href='adv_virtual.asp'>Opciones avanzadas&nbsp;&rarr;&nbsp;Servidor&nbsp;virtual</a> si desea alojar un servidor FTP.", //help38
	"SPI (\"inspección de paquetes de estado\" también conocido como \"filtrado dinámico de paquetes\") ayuda a evitar ataques por Internet al realizar el seguimiento de un númeror mayor de estados por sesión. Esto valida que el tráfico que pasa a través de esa sesión esté conforme con el protocolo.", //help164
	"Seleccione un filtro que restringe los hosts en internet que pueden acceder a este servidor virtual para hosts de confianza. Si no ve el filtro que necesita en la lista de filtros, vaya a la pantalla <a href='Inbound_Filter.asp' onclick='return jump_if();'> Avanzado &rarr; Filtro entrante</a> y cree un nuevo filtro.", //hhav_filt
	"HNAP AddPortMapping '%s' %v:%d<->%v:%d %S entra en conflicto con %dth entrada de servidor virtual '%s' %v:%d<->%v:%d %S", //GW_PURE_ADDPORTMAPPING_CONFLICT
	"HNAP SetRouterLanSettings establece RouterIPAddress %v, RouterSubnetMask %v, DHCPServerEnabled %s", //GW_PURE_SETROUTERLANSETTINGS
	"HNAP SetWLanSecurity establece Habilitado %s, Tipo %s", //GW_PURE_SETWLANSECURITY
	"El nombre de la política no puede estar vacío.", //aa_alert_9
	"El intervalo de tiempo que la máquina puede estar inactiva antes de la que conexión PPTP se desconecte. El valor máximo del tiempo de inactividad solo lo usan los modos de reconexión «A demanda» y  «Manual».", //help287
	"Admin remoto<a href='Inbound_Filter.asp' onclick='return jump_if();'>Filtro entrante</a>", //ta_RAIF
	"Este parámetro debe permanecer en su valor predeterminado de  2.346 bytes.", //help180
	"HNAP SetDeviceSettings ha cambiado DeviceName a '%s'", //GW_PURE_SETDEVICESETTINGS
	"Señal", //_rssi
	"Este asistente lo guiará a través de los pasos del proceso de configuración de su red inalámbrica y de hacerla segura.", //wwl_intro_wel
	"Haga clic aquí para acceder al firmware en línea.", //tf_ClickDL
	"DMZ es la sigla de Demilitarized Zone, zona desmilitarizada. Si una aplicación tiene problemas al ejecutarse detrás del router, puede exponer un ordenador en internet y ejecutar la aplicación en ese ordenador.", //help165
	"Otro", //_vs_other
	"Para usar la impresora compartida desde este ordenador, siga las instrucciones de configuración del <a href='../Help/Basic.shtml#PS' onclick='return jump_if();' style='white-space: nowrap;'>Ayuda -&gt; Inicio -&gt; Asistente de la impresora</a>.", //tps_intro5
	"Es posible que el archivo de firmware descargado no sea correcto. Puede que haya descargado un archivo que no está pensado para este dispositivo o el archivo descargado puede estar dañado.", //ub_intro_1
	"El intervalo de tiempo que la máquina puede estar inactiva antes de la que conexión PPTP se desconecte. El valor máximo del tiempo de inactividad solo lo usan los modos de reconexión «A demanda» y  «Manual».", //help277
	"Esta característica activa el direccionamiento de \"paquetes mágicos\" (es decir, paquetes de encendido con formato especial) desde la WAN a un ordenador de la LAN o a otro dispositivo con capacidad \"Wake on LAN\" (WOL). El dispositivo WOL se debe definir como tal en la página <a href='adv_virtual.asp'> Opciones avanzadas&nbsp;&rarr;&nbsp;Servidor&nbsp;virtual</a>. La dirección IP de LAN del servidor virtual se suele establecer en la dirección de difusión 192.168.0.255. Se encenderá el ordenador de la LAN cuya dirección MAC se incluya en el paquete mágico.", //help41
	"Servidor virtual", //VIRTUAL_SERVERS
	"Seleccione una programación para que se habilite el servidor virtual. Si no ve la programación que necesita en la lista de programaciones, vaya a la página <a href='tools_schedules.asp' onclick='return jump_if();'>Herramientas &rarr; Programaciones</a> y cree una nueva programación.", //hhav_sch
	"Restaurar los parámetros por defecto", //ts_rfd
	"Cuando ALG PPTP está habilitado, los ordenadores de la LAN pueden establecer conexiones VPN PPTP con el mismo servidor VPN o con servidores VPN diferentes. Cuando ALG PPTP ALG está deshabilitado, el router permite el funcionamiento VPN de una forma restringida: los ordenadores de la LAN pueden establecer túneles VPN hacia diferentes servidores de internet VPN, pero no hacia el mismo servidor. La ventaja de deshabilitar ALG PPTP es el aumento del rendimiento VPN. Al habilitar ALG PPTP también se permiten las conexiones VPN entrantes hacia un servidor VPN del lado LAN (vaya a <a href='adv_virtual.asp'>Avanzado &rarr; Servidor virtual</a>).", //help33b
	"Cargar desde el controlador del disco duro local", //ts_ls
	"HNAP DeletePortMapping %s:%d ha cambiado %dth entrada del servidor virtual '%s' %v:%d<->%v:%d %S por %S", //GW_PURE_DELETEPORTMAPPING_MODIFY
	"Después de hacer clic en <em>Siguiente</em>, se le pedirá permiso para descargar un archivo ejecutable. Haga clic en «OK» para descargar el archivo.<br/><br/>Para ejecutarlo, quizá tenga que abrir la carpeta que contiene el archivo descargando usando el explorador,  y hacer doble clic en el icono <em>Printer_Setup.exe</em>.", //wprn_s2c
	"Es posible que un ordenador o dispositivo manualmente configurado tenga una dirección que no se encuentra en este rango. En este caso, se debe reser", //help320
	"La página Sesiones de Internet muestra detalles completos de las sesiones de Internet activas a través del router. Una sesión de Internet es una conversación entre un programa o una aplicación en un ordenador del lado de la LAN y un programa o una aplicación en un ordenador del lado de la WAN. ", //help813
	"Seleccione un proveedor de servicios DNS dinámico de la lista desplegable o puede introducir manualmente un proveedor de servicios DNS dinámico.", //help893
	"Seleccione esta opción para guardar el registro del router en un archivo del ordenador.", //help803
	"Para buscar el firmware más reciente, haga clic en el botón <span class='button_ref'>Comprobar en línea ahora</span>.", //help877
	"(GMT+01:00) Belgrado, Bratislava, Liubliana", //up_tz_27
	"Con los valores del ejemplo anterior especificados y esta regla de juego activada, todo el tráfico TCP y UDP registrado desde el puerto 6159 al 6180 y en el puerto 99 pasará a través del router y se redirigirá a la dirección IP privada interna del servidor de juegos (192.168.0.50).", //help74
	"Cuando se ha seleccionado «APAGADO» , las direcciones MAC no se usan para controlar el acceso a la red. Cuando se ha seleccionado «PERMITIR», solo los ordenadores con direcciones MAC que figuren en la lista de direcciones MAC tienen garantizado el acceso a la red. Cuando se ha seleccionado «DENEGAR», a cualquier ordenador con una dirección MAC que figure en la lista de direcciones MAC se le deniega el acceso a la red.", //help155_2
	"Establecido: Estimación de frecuencia", //_sdi_s4
	"Varios", //MISC
	"Nota: Actualizando. El proceso tardará 1 minuto.", //tf_msg_Upping
	"Fallo al enviar el mensaje de correo del registro. Inténtelo de nuevo en %d minutos", //GW_LOG_EMAIL_FAILED
	"Conexiones TCP establecidas o cerrándose.", //help823_17
	"Acti", //IPV6_TEXT4
	"Esta página muestra todos los detalles de las sesiones activas del router.", //sa_intro
	"Al reiniciar, se desconectarán todas las sesiones en internet activas.", //up_rb_2
	"Seleccione una programación para habilitar el servicio. Si no ve la programación que necesita en la lista de programaciones, vaya a la pantalla <a href='tools_schedules.asp'> Herramientas &rarr; Programaciones</a> y cree una nueva programación.", //help23
	"Si IGMP está habilitado, esta área de la pantalla muestra grupos de multidifusión de los que algunos dispositivos LAN son miembros.", //_bln_title_IGMPMemberships_h
	"Consulte también <a href ='adv_virtual.asp'>Opciones avanzadas&rarr;Servidor&nbsp;virtual</a>, <a href ='adv_portforward.asp'>Opciones avanzadas&rarr;Direccionamiento&nbsp;de puertos </a>, <a href ='adv_appl.asp'>Opciones avanzadas&rarr;Reglas para las&nbsp;aplicaciones </a> y <a href ='adv_network.asp'>Opciones avanzadas&rarr;Red (UPnP) </a> para obtener información sobre opciones relacionadas.", //haf_intro_2
	"Si ha proporcionado información sobre el correo electrónico en la pantalla <a href='tools_email.asp'>Herramientas &rarr; Correo</a>, al hacer clic en el botón <span class='button_ref'>Enviar ahora</span> envía el registro del router a la dirección de correo electrónico configurada.", //help802
	"Haga clic en <em>Actualizar</em> para intentarlo de nuevo.", //wprn_tt5
	"También puede enviarle por correo el registro periódicamente. Vaya a <a href='tools_email.asp' onclick='return jump_if();'>Herramientas &rarr; Correo</a>.", //hhsl_lmail
	"Haga clic en el botón para continuar configurado el router si la página anterior no se restaura en <span id='show_sec'></span>&nbsp;segundos.", //ap_intro_noreboot
	"(GMT+01:00) Sarajevo, Skopje, Sofía, Vilna, Zagreb", //up_tz_29
	"HNAP SetMACFilters2", //GW_PURE_SETMACFILTERS2
	"HNAP Reiniciar", //GW_PURE_REBOOT
	"Si ha cambiado la dirección IP del router, tendrá que cambiar la dirección IP en su navegador antes de acceder de nuevo al sitio web de configuración.", //rb_change
	"La dirección IP y, cuando corresponda, el número de puerto de la aplicación en Internet.", //help816
	"HNAP DeletePortMapping %s:%d ha borrado %dth entrada de servidor virtual '%s' %v:%d<->%v:%d %S", //GW_PURE_DELETEPORTMAPPING_DELETE
	"Si el archivo cargado es correcto, es posible que el dispositivo esté demasiado ocupa para recibirlo correctamente ahora. En este caso, pruebe a cargarlo de nuevo. También es posible que usted haya accedido al sistema como «usuario» en vez de como «admin»; solo los administradores pueden cargar nuevo firmware.", //ub_intro_3
	"Las solicitudes se pueden redirigir a la página \"Prohibido\" si el acceso web para el equipo de la LAN está restringido por una regla de control de acceso. Añada la identidad del lado WAN (dirección IP del lado WAN del router o su nombre DNS dinámico) en la pantalla <a href='adv_filters_url.asp'> Opciones avanzadas&nbsp;&rarr;&nbsp;Filtro&nbsp;de web</a> para solucionar este problema.", //help30
	"La dirección IP de la LAN no es válida", //bln_alert_2
	"Se usa con <a href='adv_access_control.asp' onclick='return jump_if();'>Avanzado &rarr; Control de acceso</a>.", //hhwf_xref
	"Administración remota del gateway habilitada en puerto: %u", //GW_REMOTE_ADMINSTRATION
	"Una vez seleccionado su nivel de seguridad, necesitará establecer una contraseña de seguridad inalámbrica.", //wwl_s4_intro
	"Modo de seguridad", //sd_SecTyp
	"WAN dirección IPv6 AJUSTES", //IPV6_WAN_IP
	"Dirección IPv6", //IPV6_TEXT0
	"Acepte e instale el control ActiveX y vuelva a intentarlo.", //gw_wcn_alert_3
	"Clave de red no válida", //IPV6_TEXT2
	"Acti", //S473
	"Habilitar SPI", //af_ES
	"La selección ayuda a definir la escala de la zona de invitados.", //IPV6_TEXT5
	"Especifica si la zona de invitados estará habilitada o deshabilitada.", //IPV6_TEXT6
	"Suministre un nombre para la red inalámbrica de la zona de invitados.", //IPV6_TEXT7
	"Utilice esta sección para permitir el enrutamiento entre la zona de host y la zona de invitados; los clientes invitados no pueden acceder a los datos de clientes de host si la función no está habilitada.", //IPV6_TEXT8
	"Es importante hacer más segura su red inalámbrica ya que se utiliza para proteger la integridad de la información que se transmite a través de la red inalámbrica. El router admite 4 tipos de seguridad inalámbrica; WEP, Sólo WPA, Sólo WPA2 y WPA/WPA2 (detección automática).", //IPV6_TEXT9
	"El protocolo equivalente con cables (WEP) es un protocolo de seguridad inalámbrico para las redes de área local inalámbricas (WLAN). WEP proporciona seguridad mediante el cifrado de los datos que se envía a través de la WLAN. El router admite 2 niveles de cifrado WEP: 64 bits y 128 bits. El protocolo WEP está desactivado de manera predeterminada. La configuración de WEP se puede cambiar para adaptarla a una red inalámbrica existente o para personalizar su red inalámbrica.", //IPV6_TEXT10
	"La autenticación es un proceso mediante el cual el router comprueba la identidad de un dispositivo de red que está intentando unirse a la red inalámbrica. Al utilizar WEP, existen dos tipos de autenticación para este dispositivo.", //IPV6_TEXT11
	"Seleccione esta opción para permitir que todos los dispositivos inalámbricos se comuniquen con el router antes de que se les pida la clave de cifrado necesaria para acceder a la red.", //IPV6_TEXT12
	"Seleccione esta opción para solicitar a cualquier dispositivo inalámbrico que intente comunicar con el router la clave de cifrado necesaria para acceder a la red antes de que se les permita comunicarse con el %m.", //IPV6_TEXT13
	"Seleccione el nivel de cifrado WEP que desee utilizar en su red. Los dos niveles de cifrado WEP admitidos son 64 bits y 128 bits.", //IPV6_TEXT14
	"los tipos de clave que admite el %m son HEX (hexadecimal) y ASCII (American Standard Code for Information Interchange). El tipo de clave se puede cambiar para adaptarla a una red inalámbrica existente o para personalizar su red inalámbrica.", //IPV6_TEXT15
	"Claves", //IPV6_TEXT16
	"Las claves 1-4 permiten cambiar fácilmente la configuración de la codificación inalámbrica para mantener una red segura. Simplemente, seleccione la clave específica que se debe utilizar para codificar los datos inalámbricos en la red.", //IPV6_TEXT17
	"Tipo de clave", //IPV6_TEXT18
	"Cifrado WEP", //IPV6_TEXT19
	"El acceso protegido Wi-Fi autoriza y autentifica usuarios para acceder a la red inalámbrica. WPA utiliza una seguridad más potente que WEP y se basa en una clave que cambia automáticamente a intervalos regulares.", //IPV6_TEXT20
	"El %m admite dos tipos de cifrado diferentes cuando se utiliza WPA como tipo de seguridad. Estas dos opcioens son TKIP (Protocolo de integridad de clave temporal) y AES (Estándar de cifrado avanzado).", //IPV6_TEXT21
	"PSK/EAP", //IPV6_TEXT22
	"cuando está seleccionado PSK, los clientes inalámbricos deberán proporcionar una frase secreta para la autenticación. Cuando está seleccionado EAP, necesitará disponer de un servidor RADIUS en la red, que le permitirá manejar la autenticación de todos sus clientes inalámbricos.", //IPV6_TEXT23
	"CONTROL PATERNO", //DNS_TEXT0
	"Es lo que necesitarán todos sus clientes inalámbricos para comunicar con su %m, cuando está seleccionado PSK. Introduzca de 8 a 63 caracteres alfanuméricos. Asegúrese de escribir la frase secreta ya que necesitará introducirla en cualquiera de los dispositivos inalámbricos que intente añadir a la red.", //IPV6_TEXT25
	"Esto implica que la autenticación WPA se utiliza junto con un servidor RADIUS, que debe estar presente en la red. Introduzca la dirección IP, el puerto y el secreto compartido para los que está configurado el servidor RADIUS. También tiene la opción de introducir información para un segundo servidor RADIUS, en el caso de que su red disponga de dos, que esté utilizando para autentificar clientes inalámbricos.", //IPV6_TEXT26
	"El acceso protegido Wi-Fi 2 autoriza y autentifica usuarios para acceder a la red inalámbrica. WPA2 utiliza una seguridad más potente que WEP y se basa en una clave que cambia automáticamente a intervalos regulares.", //IPV6_TEXT27
	"Utilice esta sección para configurar su tipo de conexión IPv6. Si no está seguro del método de conexión, póngase en contacto con su proveedor de servicios de Internet.", //IPV6_TEXT28
	"TIPO DE CONEXIÓN IPv6", //IPV6_TEXT29
	"TIPO DE CONEXIÓN IPv6", //IPV6_TEXT29a
	"Elija el modo que va a utilizar el router para la conexión IPv6 a Internet.", //IPV6_TEXT30
	"Mi conexión IPv6 es", //IPV6_TEXT31
	"IPv6 estática", //IPV6_TEXT32
	"DHCPv6", //IPV6_TEXT33
	"PPPoE", //IPV6_TEXT34
	"IPv6 en túnel IPv4", //IPV6_TEXT35
	"6 a 4", //IPV6_TEXT36
	"Solo conectividad local", //IPV6_TEXT37
	"IPv6 en CONFIGURACIÓN DE TÚNEL IPv4", //IPV6_TEXT38
	"Introduzca el IPv6 en la información de túnel IPv4 suministrada por su proveedor de túnel.", //IPV6_TEXT39
	"Dirección IPv4 remota", //IPV6_TEXT40
	"Dirección IPv6 remota", //IPV6_TEXT41
	"Dirección IPv4 local", //IPV6_TEXT42
	"Dirección IPv6 local", //IPV6_TEXT43
	"CONFIGURACIÓN DE LA DIRECCIÓN IPv6 DE LAN", //IPV6_TEXT44
	"Utilice esta sección para configurar los parámetros de red interna de su router. Si cambia aquí la dirección IPv6 de LAN, puede que necesite ajustar los parámetros de red del PC para acceder de nuevo a la red.", //IPV6_TEXT45
	"Dirección IPv6 de LAN", //IPV6_TEXT46
	"Dirección de enlace local IPv6 de LAN", //IPV6_TEXT47
	"PARÁMETROS DE CONFIGURACIÓN AUTOMÁTICA DE LA DIRECCIÓN", //IPV6_TEXT48
	"Utilice esta sección para configurar la configuración automática de IPv6 a fin de que asigne las direcciones IP a los ordenadores de su red.", //IPV6_TEXT49
	"Active Búsqueda automática de canal para que el router pueda seleccionar el mejor canal posible para el funcionamiento de la red inalámbrica.", //TA11
	"Tipo de configuración automática", //IPV6_TEXT51
	"Sin estado", //IPV6_TEXT52
	"Con estado (DHCPv6)", //IPV6_TEXT53
	"Rango de dirección IPv6 (inicio)", //IPV6_TEXT54
	"Rango de dirección IPv6 (final)", //IPV6_TEXT55
	"Duración de la dirección IPv6", //IPV6_TEXT56
	"Duración del anuncio del router", //IPV6_TEXT57
	"Al configurar el router para acceder a la conexión IPv6 a Internet, asegúrese de elegir el tipo de conexión IPv6 a Internet correcto en el menú desplegable. Si no está seguro de la opción que debe elegir, póngase en contacto con su Proveedor de servicios de Internet (ISP).", //IPV6_TEXT58
	"Si tiene problemas para acceder a la conexión IPv6 a Internet a través del router, compruebe de nuevo los parámetros que ha introducido en esta página y verifíquelos con su ISP si es necesario.", //IPV6_TEXT59
	"PARÁMETROS 6 a 4", //IPV6_TEXT60
	"Introduzca la información de la dirección IPv6 suministrada por su proveedor de servicios de Internet (ISP).", //IPV6_TEXT61
	"Dirección 6 a 4", //IPV6_TEXT62
	"PARÁMETROS DE DNS IPv6", //IPV6_TEXT63
	"Obtenga automáticamente la dirección del servidor DNS", //IPV6_TEXT65
	"Obsceno", //_aa_bsecure_obscene
	"Utilice los siguientes servidores DNS de IPv6", //IPV6_TEXT66
	"Utilice esta sección para configurar los parámetros de red interna de su router.", //IPV6_TEXT67
	"Duración de la dirección", //IPV6_TEXT68
	"Duración del anuncio", //IPV6_TEXT69
	"Rango de dirección (inicio)", //IPV6_TEXT70
	"Rango de dirección (final)", //IPV6_TEXT71
	"Introduzca la información suministrada por su proveedor de servicios de Internet (ISP).", //IPV6_TEXT72
	"Tiempo de inactividad", //IPV6_TEXT73
	"Longitud del prefijo de subred", //IPV6_TEXT74
	"Puerta de enlace predeterminada de IPv6", //IPV6_TEXT75
	"La sección IPv6 (Protocolo de Internet versión 6) es donde se configura el tipo de conexión IPv6.", //IPV6_TEXT76
	"Existen", //IPV6_TEXT77
	"Modo de enlace local", //IPV6_TEXT78
	"Los nodos y routers utilizan la dirección de enlace local al comunicarse con nodos próximos en el mismo enlace. Este modo permite a los dispositivos preparados para IPv6 comunicarse entre sí en el lado de la LAN.", //IPV6_TEXT79
	"Modo de IPv6 estática", //IPV6_TEXT80
	"Se utiliza cuando su ISP le proporciona un conjunto de direcciones IPv6 que no cambia. La información de IPv6 se introduce manualmente en los parámetros de configuración IPv6. Debe introducir la dirección IPv6, la longitud del prefijo de subred, la puerta de enlace predeterminada, el servidor DNS primario y el servidor DNS secundario. Su ISP le proporciona toda esta información.", //IPV6_TEXT81
	"Modo DHCPv6", //IPV6_TEXT82
	"Método de conexión en el que el ISP asigna su dirección IPv6 cuando el router solicita una dirección al servidor del ISP. Algunos ISP necesitan que realice algunas configuraciones en su lado antes de que el router pueda conectar al IPv6 de Internet.", //IPV6_TEXT83
	"Modo de configuración automática sin estado", //IPV6_TEXT84
	"Método de conexión en el que el ISP asigna su dirección IPv6 cuando el router solicita una dirección de la puerta de enlace predeterminada. La configuración de la dirección IPv6 se basa en la recepción del mensaje de anuncio del router.", //IPV6_TEXT85
	"Seleccione esta opción si su ISP le pide que utilice una conexión PPPoE (Protocolo de punto a punto a través de Ethernet) al IPv6 de Internet. Normalmente, los proveedores de DSL utilizan esta opción.  Este método de conexión necesita que introduzca un <strong>Nombre de usuario</strong> y una <strong>Contraseña</strong> (suministrados por su proveedor de servicios de Internet) para acceder al IPv6 de Internet. Los protocolos de autenticación admitidos son PAP y CHAP.", //IPV6_TEXT86
	"Si los servidores del ISP asignan el direccionamiento WAN IPv6 del router al establecer la conexión, seleccione esta opción.", //IPV6_TEXT87
	"Si su ISP ha asignado una dirección IPv6 fija, seleccione esta opción. El ISP proporciona el valor de la <SPAN class=option>Dirección IPv6.</SPAN>", //IPV6_TEXT88
	"Intervalo de tiempo en el que el equipo puede estar inactivo antes de que se desconecte el enlace WAN. El valor de Tiempo de inactividad máximo sólo se utiliza para los modos 'A petición' y 'Manual' para volver a conectar.", //IPV6_TEXT89
	"Modo IPv6 en túnel IPv4", //IPV6_TEXT90
	"La tunelación de IPv6 en IPv4 es la encapsulación de los paquetes IPv6 en los paquetes IPv4, de modo que los paquetes IPv6 se puedan enviar a través de una infraestructura IPv4.", //IPV6_TEXT91
	"Modo 6 a 4", //IPV6_TEXT92
	"6 a 4 es una tecnología de asignación de dirección IPv6 y de tunelación automática que se utiliza para proporcionar conectividad IPv6 unidifusión entre los sitios IPv6 y los hosts en todo el IPv4 de Internet.", //IPV6_TEXT93
	"Servidor DNS primario, Servidor DNS secundario: introduzca las direcciones IPv6 de los servidores de DNS. Deje en blanco el campo para el servidor secundario si no se utiliza.", //IPV6_TEXT94
	"Estos son los parámetros de la interfaz IPv6 de LAN (red de área local) para el router. La dirección IPv6 de LAN del router se configura en función de la dirección y la subred de IPv6 asignadas por su ISP. (En la LAN se admite una subred con prefijo /64.)", //IPV6_TEXT95
	"Utilice esta sección para configurar la configuración automática de IPv6 a fin de que asigne la dirección IPv6 a los ordenadores de su red local. Se suministra un método de configuración automática sin estado y con estado.", //IPV6_TEXT96
	"Estos dos valores (desde y hasta) definen un rango de direcciones IPv6 que utiliza el servidor DHCPv6 al asignar direcciones a los ordenadores y dispositivos de su red de área local. Las direcciones que están fuera de este rango no serán gestionadas por el servidor DHCPv6; por lo tanto, éstas podrían utilizarse para los dispositivos configurados manualmente o para aquellos dispositivos que no puedan utilizar DHCPv6 para obtener automáticamente los detalles de la dirección de red.", //IPV6_TEXT97
	"Una vez seleccionado Con estado (DHCPv6), se muestran las opciones siguientes.", //IPV6_TEXT98
	"Los ordenadores (y otros dispositivos) conectados a la LAN necesitan también que su configuración TCP/IP se establezca en 'DHCPv6' o en 'Obtener automáticamente una dirección IPv6'.", //IPV6_TEXT99
	"Rango de dirección IPv6 (DHCPv6)", //IPV6_TEXT100
	"Un ordenador o un dispositivo configurado manualmente puede tener una dirección IPv6 residente dentro de su rango.", //IPV6_TEXT102
	"La cantidad de tiempo que un ordenador puede tener una dirección IPv6 antes de que necesite reno", //IPV6_TEXT103
	"Usar dirección de enlace local", //IPV6_TEXT104
	"Activar DHCP-PD automática en la LAN", //IPV6_TEXT108
	"SLAAC + Sin estado DHCPv6", //IPV6_TEXT106
	"Configuración automática (SLAAC/DHCPv6)", //IPV6_TEXT107
	"Activar configuración automática", //IPV6_TEXT50
	"Indique una contraseña para el usuario 'user', que tendrá acceso de sólo lectura a la interfaz de administración basada en la Web.", //help825
	"Asistente para la configuración de la conexión a Internet IPv6", //IPV6_TEXT110
	"Configuración manual de la conexión a Internet IPv6", //IPV6_TEXT111
	"Conexión a Internet IPv6", //IPV6_TEXT112
	"Existen dos formas de configurar la conexión a Internet IPv6. Se puede configurar manualmente o a través del Asistente para la configuración de la conexión a Internet IPv6 basado en web.", //IPV6_TEXT113
	"Este asistente le guiará a través de un proceso paso a paso para configurar una nueva conexión a Internet IPv6.", //IPV6_TEXT116
	"Paso 1: Configure la conexión a Internet IPv6", //IPV6_TEXT117
	"Paso 2: Guarde los parámetros y establezca la conexión", //IPV6_TEXT118
	"El router está detectando el tipo de conexión a Internet IPv6, espere ...", //IPV6_TEXT119
	"El router no puede detectar el tipo de conexión a Internet IPv6", //IPV6_TEXT120
	"Guíame por la configuración de IPv6", //IPV6_TEXT121
	"IPv6 sobre PPPoE", //IPV6_TEXT122
	"Elija esta opción si su conexión a Internet IPV6 requiere un nombre de usuario y una contraseña. La mayoría de los módems DSL utilizan este tipo de conexión.", //IPV6_TEXT123
	"Dirección IPv6 y ruta estáticas", //IPV6_TEXT124
	"Elija esta opción si el proveedor de servicios de Internet (ISP) le facilitó información de dirección IPv6 que se debe configurar manualmente.", //IPV6_TEXT125
	"Conexión de túnel (6rd)", //IPV6_TEXT126
	"Elija esta opción si el proveedor de servicios de Internet (ISP) le facilitó una conexión a Internet IPv6 a través de un mecanismo de tunelación automática 6rd.", //IPV6_TEXT127
	"Para establecer esta conexión, necesitará disponer del nombre de usuario y la contraseña facilitados por el proveedor de servicios de Internet. Si no tiene esta información, póngase en contacto con su ISP.", //IPV6_TEXT128
	"Compartir con IPv4", //IPV6_TEXT129
	"Para establecer esta conexión, necesitará disponer de una lista completa con información de IPv6 facilitada por el proveedor de servicios de Internet. Si tiene una conexión IPv6 estática y no dispone de esta información, póngase en contacto con su ISP.", //IPV6_TEXT130
	"Para establecer esta conexión de túnel 6rd, necesitará disponer de la siguiente información facilitada por el proveedor de servicios de Internet. Si no tiene esta información, póngase en contacto con su ISP.", //IPV6_TEXT131
	"Prefijo de IPv6 6rd", //IPV6_TEXT132
	"Prefijo de IPv6 asignado", //IPV6_TEXT133
	"Dirección IPv4 de relé 6rd de borde", //IPV6_TEXT134
	"Servidor DNS IPv6", //IPV6_TEXT135
	"El Asistente para la configuración de la conexión a Internet IPv6 se ha completado. Haga clic en el botón Conectar para guardar los parámetros y reiniciar el router.", //IPV6_TEXT136
	"Ipv6", //IPV6_TEXT137
	"Detección automática", //IPV6_TEXT138
	"6rd", //IPV6_TEXT139
	"DS-Lite", //IPV6_TEXT140
	"A través de ruta de tunelación Teredo", //IPV6_TEXT141
	"Configuración 6rd", //IPV6_TEXT142
	"Opción DHCPv4 6rd", //IPV6_TEXT143
	"Configuración manual", //IPV6_TEXT144
	"Dirección de enlace local de túnel", //IPV6_TEXT145
	"TIPO DE CONEXIÓN A INTERNET DE DIRECCIÓN AFTR", //IPV6_TEXT146
	"Activar el servidor DHCP", //bd_EDSv
	"Entre la dirección IP del ordenador al que quiere enviar el ping o escriba su nombre de dominio completo.", //htsc_pingt_h
	"Configuración de DS-Lite", //IPV6_TEXT149
	"Opción DHCPv6 de DS-Lite", //IPV6_TEXT150
	"Dirección IPv6 de AFTR", //IPV6_TEXT151
	"Dirección IPv4 B4", //IPV6_TEXT152
	"Puerta de enlace predeterminada de WAN IPv6", //IPV6_TEXT153
	"Seleccione uno de los métodos de configuración siguientes y haga clic en Siguiente para continuar.", //wps_KR37
	"Establecer conexión con dirección IPv6 estática", //IPV6_TEXT155
	"El Asistente para la configuración de la conexión a Internet IPv6 se ha completado. Haga clic en el botón Conectar para guardar los parámetros y reiniciar el router.", //IPV6_TEXT156
	"SLAAC + RDNSS", //IPV6_TEXT157
	"IP de destino/longitud del prefijo", //IPV6_TEXT158
	"El rango de dirección IPv4 B4 es de 192.0.0.2 a 192.0.0.7", //IPV6_TEXT159
	"Dirección AFTR", //IPV6_TEXT160
	"Cambie en primer lugar el protocolo de wan IPv4", //IPV6_TEXT161
	"6rd está utilizando la opción DHCPv4. Cambie en primer lugar el protocolo de WAN IPv6.", //IPV6_TEXT162
	"El tipo de WAN IPv6 debe ser SLAAC/DHCPv6, PPPoE, Modo de detección automática", //IPV6_TEXT163
	"También puede activar DHCP-PD para delegar los prefijos para el router en la LAN.", //IPV6_TEXT164
	"Aquí se muestran todos los detalles de la IPv6 de LAN.", //IPV6_TEXT165
	"Red IPv6 asignada por DHCP-PD", //IPV6_TEXT166
	"Paramétros para una regla de aplicación", //haar_p
	"Copia de seguridad opcional del servidor RADIUS", //bws_ORAD
	"OPCIONES DE SEGURIDAD", //DNS_TEXT2
	"DNS&#8482 avanzado", //DNS_TEXT3
	"DNS avanzado hace que la conexión a Internet sea más segura, rápida, inteligente y fiable. Bloquea los sitios web de suplantación de identidad para protegerle frente al robo de identidad.", //DNS_TEXT4
	"Los controles paternos de OpenDNS proporcionan un galardonado filtrado de contenidos web y, al mismo tiempo, hacen más segura, rápida, inteligente y fiable su conexión a Internet. Con más de 50 categorías de contenido entre las que elegir, resulta eficaz frente a contenidos para adultos, proxies, conexión a redes sociales, sitios de suplantación de identidad, con código malicioso y mucho más. Totalmente configurable desde cualquier lugar donde exista acceso a Internet.", //DNS_TEXT8
	"Bloquea automáticamente los sitios para adultos y de suplantación de identidad, al mismo tiempo que mejora la velocidad y fiabilidad de la conexión a Internet.", //DNS_TEXT6
	"FamilyShield&#8482 de OpenDNS&reg;", //DNS_TEXT5
	"Interconexión de Sistemas Abiertos es el modelo de referencia sobre cómo deberían viajar los datos entre dos dispositivos de una red", //help639
	"Ninguno: Obtener automáticamente del ISP o IP estática", //DNS_TEXT9
	"Utilice los servidores DNS facilitados por su ISP o introduzca sus servidores DNS preferidos.", //DNS_TEXT10
	"Aunque esté activada la característica DNS avanzado, la dirección IP de DNS de la estación de trabajo se podrá seguir modificando a la IP del servidor DNS que desee. Tenga en cuenta que el router no dicta la resolución de nombre DNS cuando la dirección IP de DNS se configura manualmente en la estación de trabajo.", //DNS_TEXT11
	"Si ha seleccionado esta opción y tiene una configuración de VPN o Intranet en la red, puede desactivar el servicio de DNS avanzado si tiene problemas con la conexión.", //DNS_TEXT12
	"TRENDNET | %m | Status | Device Information", //TEXT000
	"Configuración automática sin estado", //TEXT001
	"El nombre del servidor virtual %s no es válido. Incluye los caracteres no permitidos ',/,''\".", //TEXT002
	"Nombre de reglas '+ i +' no válido. Los caracteres legales no pueden introducir ',/,'''", //TEXT003
	"Nombre de host no válido. Los caracteres legales no pueden introducir ',/,'''", //TEXT004
	"Nombre de dominio local no válido. Los caracteres legales no pueden introducir ',/,'''", //TEXT005
	"Nombre de reglas '+ i +' no válido. Los caracteres legales no pueden introducir ',/,'''", //TEXT006
	"Nombre de direccionamiento de puerto '+ %s +' no válido. Los caracteres legales no pueden introducir ',/,'''", //TEXT007
	"Reglas'+i+' se configura igual que Reglas'+j+'.'", //TEXT008
	"obj_word + \" está en conflicto con otro puerto privado.\"", //TEXT010
	"Número de clientes inalámbricos", //sw_title_list
	"El otro tipo de protocolo no es válido'", //TEXT011
	"Elija un dispositivo inalámbrico con wps'", //TEXT012
	"El filtro interno debe ser inferior a '+ rule_max_num", //TEXT013
	"El nombre no se puede establecer igual que el nombre de filtro de entrada predeterminado 'Permitir todos' o 'Denegar todos'.'", //TEXT014
	"Reglas de programa está lleno. Elimine una entrada.'", //TEXT015
	"Primera página", //TEXT016
	"Última página", //TEXT017
	"Anterior", //TEXT018
	"Actividad del sistema", //TEXT019
	"Depurar información", //TEXT020
	"Ataques", //TEXT021
	"Paquetes interrumpidos", //TEXT022
	"No se ha cambiado nada, ¿desea guardar?", //LS3
	"No puede elegir la clave WEP 2, 3, 4 cuando está activado WPS.'", //TEXT024
	"No puede elegir la clave WPA-Personal/TKIP y AES cuando está activado WPS.'", //TEXT025
	"No puede elegir la clave WPA-Enterprise cuando está activado WPS.'", //TEXT026
	"No puede elegir la clave compartida cuando está activado WPS.'", //TEXT027
	"Active inalámbrica antes.'", //TEXT028
	"La función WPS está establecida actualmente en desacti", //TEXT029
	"El %s no puede permitir introducir IP de bucle o IP multicompartimental (127.x.x.x, 224.x.x.x ~ 239.x.x.x).", //TEXT030
	"El puerto %s introducido no es válido", //TEXT031
	"El secreto %s introducido no es válido'", //TEXT032
	"Dirección IP de reserva'", //TEXT033
	"Dirección IP de inicio'", //TEXT035
	"\"Dirección IP final\"", //TEXT036
	"La dirección IP de LAN y la dirección IP de inicio no están en la misma subred", //TEXT037
	"La dirección IP de LAN y la dirección IP final no están en la misma subred", //TEXT038
	"La dirección IP final debe ser superior a la dirección IP de inicio", //TEXT039
	"Se ha guardado la configuración.", //TEXT040
	"La clave ' + i + ' no es válida. La clave debe tener ' + wep_key_len + ' caracteres o ' + hex_len + 'números hexadecimales.'", //TEXT041
	"La clave ' + i + ' es incorrecta, los caracteres legales son 0~9, A~F o a~f.'", //TEXT042
	"%s La dirección IP de puerta de enlace %s debe estar dentro de la subred WAN.", //TEXT043
	"Este firmware es la última versión'", //TEXT045
	"Error al establecer contacto con el servidor, compruebe el estado de la conexión a Internet", //TEXT046
	"La dirección IP de WAN y LAN no se puede establecer en la misma subred.", //TEXT047
	"Introduzca una máquina.", //aa_alert_10
	"No ha logrado añadir el dispositivo inalámbrico a la red inalámbrica dentro del periodo de tiempo establecido, haga clic en el botón siguiente hacerlo de nuevo.", //TEXT049
	"\"La dirección IP '\"+ res_ip +\"' ya se ha utilizado.\"", //TEXT050
	"La contraseña confirmada no coincide con la nueva contraseña.", //TEXT051
	"TAMBIÉN DENOMINADA WCN 2.0 EN WINDOWS VISTA", //TEXT053
	"obj_word +  está en conflicto con el puerto de cortafuegos de la aplicación.", //TEXT055
	"obj_word + \" está en conflicto con otro puerto público.\"", //TEXT009
	"obj_word +  está en conflicto con el puerto de direccionamiento de puerto.", //TEXT054
	"Conflicto de puerto.", //TEXT057
	"Conflicto de puerto TCP.", //TEXT058
	"Conflicto de puerto UDP.", //TEXT059
	"El nombre de direccionamiento de puerto ya está en la lista", //TEXT060
	"¿Desea acti", //TEXT062
	"La regla se está utilizando en otra regla, no puede eliminarla", //TEXT063
	"El nombre del programa no es válido. Los caracteres válidos son 0~9, A~Z o a~z.", //TEXT064
	"El nombre del programa es el nombre predeterminado.", //TEXT065
	"El nombre del programa ya está en la lista", //TEXT066
	"La regla se está utilizando en otra regla, no puede editarla", //TEXT067
	"Red de Información de IPv6", //TEXT068
	"Toda su red de Internet IPv6 y detalles de conexión se muestran en esta página.", //TEXT069
	"IPv6 Connectcion Información", //TEXT070
	"WAN Dirección IPv6", //TEXT071
	"IPv6 LAN Computadoras", //TEXT072
	"Reintentar", //TEXT073
	"Siguiente", //TEXT074
	"Nombre de host o direcciones IPv6", //TEXT075
	"Inténtelo de nuevo", //TEXT076
	"Sesión PPPoE", //TEXT077
	"Crear una nueva sesión", //TEXT078
	"La 1ª dirección de %s debe ser un número entero.,", //MSG002
	"La 2ª dirección de %s debe ser un número entero.,", //MSG003
	"La 3ª dirección de %s debe ser un número entero.,", //MSG004
	"La 4ª dirección de %s debe ser un número entero.,", //MSG005
	"La %s es una dirección no válida.", //MSG006
	"El %s no puede ser cero.,", //MSG007
	"El secreto %s introducido no es válido,", //MSG008
	"El secreto %s introducido no es válido,", //MSG009
	"El %s no puede permitir introducir IP de bucle o IP multidifusión (127.x.x.x, 224.x.x.x ~ 239.x.x.x).", //MSG010
	"El valor de %s debe ser numérico,", //MSG013
	"El rango de %s es %1n ~ %2n.,", //MSG014
	"El rango de %s es %d ~ %d.,", //MSG014a
	"El valor de %s sólo es un número par,", //MSG015
	"La clave no es válida. La clave debe tener 5 caracteres o 10 números hexadecimales. Ha introducido", //MSG016
	"La clave no es válida. La clave debe tener 13 caracteres o 26 números hexadecimales. Ha introducido", //MSG017
	"La 1ª dirección de %s debe ser un valor hexadecimal.,", //MSG018
	"La 2ª dirección de %s debe ser un valor hexadecimal.,", //MSG019
	"La 3ª dirección de %s debe ser un valor hexadecimal.,", //MSG020
	"La 4ª dirección de %s debe ser un valor hexadecimal.,", //MSG021
	"La 5ª dirección de %s debe ser un valor hexadecimal.,", //MSG022
	"La 6ª dirección de %s debe ser un valor hexadecimal.,", //MSG023
	"La 7ª dirección de %s debe ser un valor hexadecimal.,", //MSG024
	"La 8ª dirección de %s debe ser un valor hexadecimal.,", //MSG025
	"El 1er rango de %s debe estar entre ,", //MSG026
	"El 2º rango de %s debe estar entre ,", //MSG027
	"El 3er rango de %s debe estar entre ,", //MSG028
	"El 4º rango de %s debe estar entre ,", //MSG029
	"El 5º rango de %s debe estar entre ,", //MSG030
	"El 6º rango de %s debe estar entre ,", //MSG031
	"El 7º rango de %s debe estar entre ,", //MSG032
	"El 8º rango de %s debe estar entre ,", //MSG033
	"El %s no puede permitir introducir IP de bucle ( ::1 ).,", //MSG034
	"El %s no puede permitir introducir IP multidifusión ( FFxx:0:0:0:0:0:0:2 or ffxx:0:0:0:0:0:0:2.", //MSG035
	"El sufijo de", //MSG036_1
	"La subred de", //MSG037_1
	" debe ser un valor hexadecimal.", //MSG038_1
	" es una dirección no válida.", //MSG039_1
	"El sufijo de '+tag +' debe ser un valor hexadecimal.", //MSG036
	"El sufijo de '+tag +' no es una dirección inválida.", //MSG037
	"La subred de '+tag +' debe ser un valor hexadecimal.", //MSG038
	"La subred de '+tag +' no es una dirección inválida.", //MSG039
	"El sufijo del rango de dirección IPv6 (inicio) debe ser superior al sufijo del rango de dirección IPv6 (final)", //MSG040
	"La dirección IPv6 sólo permite los dos puntos dobles una vez.", //MSG041
	"La dirección IPv6 es una dirección ilegal", //MSG042
	"Inválida Métrico", //MSG043
	"El modo exclusivo 802.11n no admite WEP.", //MSG044
	"El modo exclusivo 802.11n no admite TKIP.", //MSG045
	"El rango de %s va de %s a ", //MSG046
	"Prefijo ULA IPv6 no válido", //MSG047
	"El campo del prefijo ULA está en blanco, ¿desea utilizar el prefijo ULA predeterminado?", //MSG048
	"Los resultados de la búsqueda son gestionados por Yahoo. La función de búsqueda le proporciona una experiencia de exploración más fluida. Cuando no se logra llegar a un sitio o el sitio no existe, se ofrecen sugerencias de búsqueda en lugar del mensaje de error genérico que muestra su explorador. Asimismo, se corrigen automáticamente algunos de los errores de escritura habituales cometidos por los usuarios en la barra de direcciones. La característica de corrección de errores de escritura sólo funciona para los dominios de nivel superior que se han escrito mal, como .cmo y .ogr. En ocasiones, puede que se le dirija por error a la página de resultados de búsqueda. Si ha hecho clic en un enlace dentro de un correo electrónico de spam, puede que el sitio esté desactivado por cometer infracciones. Debido a que el sitio ya no existe, puede que reciba de vuelta nuestra página de búsqueda.", //ADV_DNS_DESC3
	"La página solicitada no está disponible.", //ERROR404
	"Sugerencias", //SUGGESTIONS
	"Asegúrese de que el cable de Internet está conectado de forma segura al puerto de Internet del router y que el LED de Internet parpadea en verde o azul.", //SUGGESTIONS_1
	"Confirme que los <a href='http://<% CmoGetCfg('lan_ipaddr',''); %>/'>Parámetros de Internet</a> del router están configurados correctamente como, por ejemplo, los parámetros de nombre de usuario/contraseña de PPPoE.", //SUGGESTIONS_2
	"(hora minuto)", //tsc_hrmin_1
	"DHCP-PD", //DHCP_PD
	"Activar DHCP-PD", //IPV6_TEXT147
	"Red IPv6 asignada <br>por DHCP-PD", //DHCP_PD_ASSIGNED
	"Relé 6 a 4", //_6to4RELAY
	"Consiga automáticamente la dirección del servidor DNS o introduzca una dirección específica del servidor DNS.", //IPV6_TEXT64
	"Utilice la siguiente dirección IPv6 de DNS", //IPV6_TEXT66_v6
	"Si se cambia el tipo de USB a un teléfono Windows Mobile, iPhone o Android, el dispositivo se reiniciará.", //usb_reboot
	"Si se cambia el tipo de USB a Windows Mobile o iPhone, el dispositivo se reiniciará y también cambiará la IP del dispositivo a 192.168.99.1.", //usb_reboot_chnip
	"Filipinas", //country_8
	"Seleccione el teléfono USB", //_select_phone
	"Seleccione el teléfono USB 3G que utilizó.", //_phone_info
	"Teléfono USB 3G", //usb_3g_phone
	"Windows Mobile 5", //usb_window_mobile_5
	"iPhone 3G(s)", //usb_iphone
	"Teléfono con Android", //android_phone
	"Muestra el estado actual de la conexión al servidor DDNS.", //help901
	"Nombre del dispositivo", //DEVICE_NAME
	"Se ha revocado la concesión %v.", //IPDHCPSERVER_LEASE_REVOKED2
	"Se ha eliminado la reserva de concesión %v.", //IPDHCPSERVER_LEASE_RESERVATION_DELETED
	"El cliente %m ha renovado la concesión %v", //IPDHCPSERVER_LEASE_RENEW
	"Wake on LAN", //help738
	"Red de Área Local Inalámbrica", //help759
	"La tecnología utilizada mayoritariamente en las redes de área local.", //help517
	"Bits por segundo", //help443
	"Caracteres A-Z y 0-9", //help414
	"Aceptar", //_ok
	"Valor predeterminado", //help486
	"DSL", //help503
	"La pérdida de intensidad de las señales digitales y analógicas. La pérdida es mayor cuando la señal se transmite a distancias largas.", //help426
	"Ancho de banda", //help432
	"Descomponer los datos en trozos más pequeños para que su almacenamiento resulte más sencillo", //help527
	"La opción Filtro de web permite configurar una lista de sitios web permitidos a los que pueden acceder varios usuarios. Si se activa esta opción, se bloquearán los sitios web que no estén incluidos en esta página. Para utilizar esta característica, debe marcar además la casilla \"Aplicar filtro web\" en la sección Control de acceso.", //awf_intro_WF
	"Protocolo de Oficina de Correo 3 se utiliza para recibir correo electrónico", //help652
	"CardBus", //help456
	"Interfaz gráfica de usuario", //help539
	"Base de datos", //help472
	"Servidor de archivos", //help520
	"VoIP", //help737
	"La primera capa del modelo OSI. Suministra los medios de hardware para la transmisión de señales eléctricas en una portadora de datos", //help646
	"Explorador Web", //help745
	"Usado para sincronizar los tiempos de comunicación entre los dispositivos de una red", //help659
	"USB", //help727
	"ISP inalámbrico", //help753
	"El método de transferencia de datos de un ordenador a otro en Internet", //help574
	"El Servicio Remoto de Llamada de Autenticación de Usuario permite a los usuarios remotos conectarse con un servidor central que les autenticará antes de poder acceder a los recursos de una red", //help663
	"Wi-Fi", //help748
	"Cree una lista de sitios web a los que desee permitir el acceso desde los dispositivos de la red.", //hhwf_intro
	"Diodo emisor de luz", //help598
	"xDSL", //help761
	"Dirección IP que ha sido asignada por un servidor DHCP y que puede cambiar. Los proveedores de Internet por cable utilizan normalmente este método para asignar direcciones IP a sus clientes.", //help510
	"IPsec", //help584
	"Utilidad que muestra la ruta seguida para llegar desde su ordenador a un destino específico", //help716
	"Velocidad de bits", //help440
	"Línea de abonado digital asimétrica", //help410
	"dBi", //help480
	"IEEE", //help559
	"Ethernet", //help516
	"Alfanumérico", //help413
	"Unidad de Transmisión Máxima es el paquete de mayor tamaño que se puede transmitir a través de una red basada en paquetes como Internet", //help619
	"Un ordenador de una red que almacena datos para que los demás equipos de la red puedan acceder a ellos", //help521
	"DSSS: técnica de modulación utilizada por dispositivos inalámbricos 802.11b", //help494
	"DNS (Domain Name System): Sistema que traduce nombres de dominio a direcciones IP.", //help498
	"Tarjeta de Interfaz de Red", //help628
	"Una clave de cifrado y descifrado que se genera para cada sesión de comunicación entre dos ordenadores", //help683
	"Gigabits por segundo", //help535
	"SPI", //help695
	"Red de Área Ancha", //help740
	"Los ISP proporcionan acceso a Internet a individuos o compañías", //help578
	"Emisión de señales (beacon)", //help438
	"El DNS dinámico lo proporcionan las compañías que permiten a usuarios con direcciones IP dinámicas obtener un nombre de dominio que siempre va a estar vinculado a su dirección IP cambiante. La dirección IP es actualizada por un programa cliente que se ejecuta en un ordenador o por un enrutador que admite DNS dinámico, siempre que cambie la dirección IP", //help508
	"ASCII", //help423
	"NetBIOS", //help625
	"Servidor", //help680
	"Cuando se habla de redes inalámbricas, es cuando los clientes inalámbricos utilizan un Punto de Acceso para acceder a la red", //help568
	"Multidifusión", //help620
	"Versión de Apple del UpnP, que permite a los dispositivos de una red descubrirse entre sí y estar conectados sin la necesidad de configurar ninguna opción", //help667
	"Una familia de especificaciones para las redes de área local inalámbricas (WLANs) elaboradas por un grupo de trabajo del Instituto de Ingenieros Eléctricos y Electrónicos (IEEE).", //help766
	"RADIUS", //help662
	"Inspección de estado completo", //help701
	"Semi duplex", //help542
	"Un sistema de redes mundiales que utilizan el protocolo TCP/IP para permitir que los ordenadores de todo el mundo accedan a los recursos disponibles", //help570
	"DMZ: un ordenador o grupo de ordenadores al que pueden acceder los usuarios de Internet y los usuarios de la red local, pero que no está protegido con la misma seguridad que la red local.", //help489
	"Instalar una versión más reciente de un producto de software o firmware", //help723
	"Kilobyte", //help593
	"Un período durante los procesos en el que algo hace que el proceso se ralentice o se detenga totalmente.", //help447
	"Registrador de datos del sistema: una interfaz de registros distribuidos para recoger en un único lugar los registros provenientes de diferentes fuentes. Escrito originalmente para UNIX, está disponible ahora para otros sistemas operativos, incluido Windows.", //help705
	"Conexión a una red de área local a través de uno de los estándares inalámbricos 802.11", //help755
	"H.323", //_H323
	"Para suministrar credenciales, como una contraseña, para verificar que la persona o el dispositivo son quiénes dicen ser", //help427
	"Convertir un mensaje cifrado en texto sencillo", //help485
	"Protocolo de configuración dinámica de host: utilizado para asignar automáticamente direcciones IP desde un conjunto predefinido de direcciones a ordenadores o dispositivos que las solicitan", //help490
	"El HTTP sobre SSL se utiliza para cifrar y descifrar transmisiones HTTP", //help555
	"Colisión", //help462
	"VPN: Un túnel seguro a través de Internet para conectar oficinas o usuarios remotos a las redes de sus compañías", //help732
	"Kbyte", //help592
	"Un dispositivo que le permite conectar un ordenador a un cable coaxial y recibir acceso a Internet desde su proveedor de cable.", //help455
	"La quinta capa del modelo OSI que coordina la conexión y la comunicación entre aplicaciones en ambos extremos", //help685
	"Muchos sitios web construyen páginas con imágenes y contenido de otros sitios web. El acceso se prohibirá si no habilita todos los sitios web utilizados para construir una página. Por ejemplo, para acceder a <code>my.yahoo.com</code>, debe habilitar el acceso a <code>yahoo.com</code>, <code>yimg.com</code> y <code>doubleclick.net</code>.", //help146
	"El Protocolo Punto a Punto se utiliza para que dos ordenadores se comuniquen entre sí mediante una interfaz serie, como una línea telefónica", //help655
	"Trama de datos emitida periódicamente por una de las estaciones de una red Wi-Fi  para difundir datos de control de red a otras estaciones inalámbricas.", //help439
	"Utilizada para transmitir y recibir señales RF.", //help416
	"El Localizador de Recursos Uniforme es una dirección única para archivos accesibles en Internet", //help726
	"SNMP", //help692
	"Host", //help550
	"La cantidad de datos que se pueden transferir en un período de tiempo determinado", //help714
	"Línea de abonado digital Conexión a Internet de elevado ancho de banda a través de las líneas telefónicas", //help504
	"Utiliza una clave de 56 bits seleccionada aleatoriamente que deben conocer el remitente y el receptor cuando se intercambian información", //help469
	"Una tarjeta instalada en un ordenador o incorporada en la placa madre que permite al ordenador conectarse a la red", //help629
	"Indicador LED", //help597
	"Una utilidad que le permite ver contenido e interactuar con toda la información de la World Wide Web", //help746
	"Fidelidad inalámbrica", //help749
	"La segunda capa del modelo OSI. Controla el movimiento de datos en el enlace físico de una red", //help471
	"Envío de información de voz a través de Internet en oposición a PSTN", //help736
	"La cantidad de tiempo que necesita un paquete para pasar de un punto a otro en una red. También se conoce como demora", //help596
	"Protocolo de Control de Transmisiones", //help706
	"Reiniciar", //help664
	"Función de los cortafuegos que supervisa el tráfico de salida y entrada para garantizar que, solamente, se permite el paso a través del cortafuegos  las respuestas válidas de las peticiones salientes", //help702
	"WISP", //help756
	"Protocolo de Internet", //help573
	"Un grupo de ordenadores de un edificio que normalmente acceden a archivos desde un servidor", //help601
	"Capa de sesión", //help684
	"RSA", //help678
	"Acceso Protegido Wi-Fi. Una mejora de la seguridad Wi-Fi que proporciona un cifrado mejorado de datos, relacionado con la WEP.", //help760
	"Gigabit Ethernet", //help536
	"Nombre de dominio", //help499
	"El Protocolo de Administración de Grupos de Internet se utiliza para asegurarse de que los ordenadores pueden informar de su pertenencia a grupos multidifusión a los enrutadores adyacentes", //help562
	"WCN", //help741
	"Un estándar que proporciona coherencia de transmisiones de audio y video y compatibilidad para los dispositivos de videoconferencias", //help541
	"Protocolo de Datagramas de Usuario", //help717
	"Protocolo de túnel de capa 2", //help604
	"Unidifusión", //help718
	"Ordenador en una red", //help551
	"Proveedor de servicios de Internet", //help577
	"Conversión de los datos en texto cifrado para que no se pueda leer fácilmente", //help515
	"Envío de datos de un dispositivo a", //help621
	"AES. Norma de cifrado gubernamental", //help412
	"Rendimiento", //help713
	"Utilizado para enviar y recibir correo electrónico", //help687
	"Infraestructura", //help567
	"El Cifrado de Punto a punto de Microsoft se utiliza para asegurar las transmisiones de datos a través de las conexiones PPTP", //help618
	"La cantidad de bits que pasan en una cantidad determinada de tiempo", //help441
	"Datos", //help466
	"SMTP", //gw_vs_5
	"DMZ", //help488
	"kilobits por segundo", //help591
	"AP. Dispositivo que permite a los clientes inalámbricos conectarse a él mismo y acceder a la red.", //help402
	"Calidad de servicio", //help661
	"DMZ", //help495
	"ISP", //help587
	"Preámbulo", //help658
	"Actualizar", //help722
	"Decibelios relativos a un milivatio", //help483
	"RIP", //help670
	"WPA", //help750
	"Explorador", //help452
	"Inspección de Paquetes de Estado completo", //help696
	"Repetidor", //help668
	"La cantidad máxima de bytes o bits por segundo que se pueden transmitir a y desde un dispositivo de red", //help433
	"Un ordenador de una red que proporciona servicios y recursos a otros ordenadores de la misma", //help681
	"Protocolo de Tiempo de Red", //help632
	"ADSL", //help409
	"802.11", //help765
	"Capa de aplicación", //help421
	"URL", //help725
	"Calidad de servicio", //help660
	"IPsec proporciona seguridad en la capa de procesamiento de paquetes de la comunicación en red", //help576
	"Una versión actualizada de seguridad para redes inalámbricas que proporciona autenticación además de cifrado", //help751
	"Protocolo de voz sobre IP", //help735
	"Punto de acceso", //help401
	"POP3", //gw_vs_6
	"Certificado digital:", //help491
	"Banda ancha", //help448
	"El Intercambio de Claves de Internet se utiliza para garantizar la seguridad de las conexiones VPN", //help566
	"Glosario de ayuda", //help398
	"Intercambio de Paquetes entre redes es un protocolo de interconexión desarrollado por Novel para que sus clientes y servidores Netware se puedan comunicar", //help586
	"Un protocolo TCP/IP para transmitir secuencias de datos de impresoras.", //help710
	"Protocolo Simple de Transferencia de Correo", //help686
	"Tecnología de transmisión que proporciona una velocidad de datos de 1 billón de bits por segundo", //help537
	"PPP", //help654
	"TCP/IP (Protocolo de control de transmisión/Protocolo Internet)", //help708
	"Código estándar americano para el intercambio de información. Este sistema de caracteres se utiliza con frecuencia para archivos de texto.", //help424
	"Dúplex", //help505
	"Un número de 32 bits, si hablamos sobre la versión 4 del Protocolo de Internet, que identifica cada ordenador que transmite datos en Internet o en una Intranet", //help583
	"Compatible con versiones anteriores", //help430
	"Descifrar", //help484
	"Módem de cable", //help454
	"Terminal", //help556
	"Capa de Enlace de datos", //help470
	"Dirige la administración y supervisión de los dispositivos de una red", //help689
	"Cookie", //help464
	"Un programa o usuario que solicita datos de un servidor", //help461
	"Nov", //tt_Nov
	"Trazado de ruta", //help715
	"Traducción de Dirección de Red permite que muchas direcciones IP privadas se conecten a Internet, u a otra red, mediante una única dirección IP", //help622
	"Red Privada virtual", //help731
	"ARP. Usado para relacionar direcciones MAC a direcciones IP de modo que las conversiones puedan hacerse en ambas direcciones.", //help408
	"Protocolo Simple de Administración de Redes", //help688
	"Información que se almacena en el disco duro de su ordenador que conserva preferencias para el sitio que proporcionó la cookie al ordenador", //help465
	"SuMáscara de subred", //help703
	"SSH", //help697
	"Dirección MAC", //help605
	"Acción efectuada por los paquetes de datos que se transmiten de un enrutador a otro", //help549
	"Trnamisiones en las que se envían y reciben datos al mismo tiempo", //help506
	"Secuencia de caracteres que se utiliza para autenticar solicitudes de recursos en una red", //help642
	"Direccionamiento IP privado automático", //help428
	"Clave de sesión", //help682
	"Un método electrónico para proporcionar credenciales a un servidor para tener acceso al mismo o a una red", //help492
	"Fragmentación", //help526
	"La tercera capa del modelo OSI que controla el enrutamiento de tráfico de una red", //help631
	"Un ID de hardware único asignado por el fabricante a cada adaptador de Ethernet.", //help606
	"Reiniciar un ordenador y recargar su software operativo o firmware desde un almacenamiento no volátil.", //help665
	"En la sección se enumeran los sitios web permitidos actualmente.", //help148
	"El cálculo de velocidad se ha anulado debido a la limitación de recursos", //RATE_ESTIMATOR_RESOURCE_ERROR
	"Un estándar que permite a los dispositivos de red descubrirse entre sí y configurarse para formar parte de la red", //help721
	"HTTPS", //gw_vs_2
	"UTP", //help729
	"Proveedor Inalámbrico de Servicios de Internet", //help757
	"Latencia", //help595
	"El Protocolo de Información de Enrutamiento se utiliza para sincronizar la tabla de enrutamiento de todos los enrutadores de una red", //help671
	"Wired Equivalent Privacy (Privacidad Equivalente Cableada) es un sistema de seguridad para las redes inalámbricas que se supone comparable a la de las redes cableadas", //help747
	"TCP/IP", //help707
	"Transmisión simultánea de datos en todas direcciones", //help451
	"El correo electrónico es un mensaje almacenado en el ordenador que se transmite a través de Internet", //help514
	"Protocolo de autenticación extensible", //help512
	"El método de conexión más utilizado para Ethernet", //help675
	"Lista de control de acceso", //help399
	"Sistema de Entrada y Salida Básico de Red", //help626
	"Antena", //help415
	"Un dispositivo que conecta su red a otra como Internet", //help533
	"Un explorador World Wide Web creado y suministrado por Microsoft", //help572
	"Un dispositivo de interconexión que conecta", //help557
	"Norma de cifrado de datos", //help468
	"Enviar una solicitud de un ordenador a otro para que se transmita un archivo desde el ordenador solicitante al otro", //help724
	"Programa que verifica que una determinada dirección de Internet existe y puede recibir mensajes. La utilidad envía un paquete de control a la dirección especificada y espera una respuesta.", //help648
	"Espere, por favor", //wt_title
	"El Protocolo de Túnel Punto a Punto se utiliza para crear túneles VPN a través de Internet entre dos redes", //help657
	"dBm", //help482
	"Algoritmo utilizado para el cifrado y la autenticación", //help679
	"La habilidad de los nuevos dispositivos para comunicarse e interactuar con otros dispositivos antiguos heredados con el fin de garantizar la interoperabilidad", //help431
	"Instituto de ingenieros eléctricos y electrónicos", //help560
	"Windows Connect Now. Un método de Microsoft para configurar y cargar automáticamente hardware de redes inalámbricas (puntos de acceso) y clientes inalámbricos, incluidos los PC y otros dispositivos.", //help742
	"Una banda ancha de frecuencias disponible para transmitir datos", //help449
	"IKE", //help565
	"O haga clic en <em>Siguiente</em> para seguir adelante y elegir después <em>No</em> cuando se le pida si quiere imprimir una página de prueba.", //wprn_tt7
	"Herencia", //help599
	"IPX", //help585
	"Envío y recepción simultánea de datos", //help530
	"NetBEUI", //help623
	"WLAN", //help758
	"NIC", //help634
	"La red más grande a la que está conectada su LAN, que puede ser la propia Internet o un red regional o corporativa", //help752
	"Protocolo de seguridad de Internet", //help575
	"Difusión", //help450
	"LA CONEXIÓN FÍSICA DEL PUERTO DE INTERNET ESTÁ DESCONECTADA", //ES_CABLELOST_bnr
	"Cuando dos dispositivos de la misma red Ethernet intentan y transmiten datos exactamente al mismo tiempo.", //help463
	"Protocolo de resolución de direcciones", //help407
	"Un programa que le permite acceder a los recursos de la Web y los suministra gráficamente", //help453
	"IGMP", //help561
	"Bit/seg", //help442
	"Un término genérico aplicable a la familia de tecnologías de línea de abonados digitales (DSL), tales como ADSL, HDSL, RADSL y SDSL.", //help762
	"Protocolo de transferencia de hipertexto utilizado para transferir archivos desde servidores HTTP (servidores web) a clientes HTTP (exploradores web)", //help553
	"Kbps", //help590
	"Megabits por segundo", //help608
	"Norma de cifrado avanzado", //help411
	"Direcciones", //gw_vs_4
	"Hexadecimal", //help546
	"Un extremo de canal lógico en una red. Un ordenador podría tener solamente un canal físico (su canal Ethernet) pero puede tener", //help653
	"Decibelios relacionados con el radiador isotrópico", //help481
	"Dúplex completo", //help529
	"Atenuación", //help425
	"ACL. Es una base de datos de los dispositivos de red que tienen permiso para acceder a los recursos de la red.", //help400
	"Dirección IP dinámica", //help509
	"DHCP", //_DHCP
	"TCP Raw", //help709
	"UPNP", //help720
	"USB", //help728
	"Información transformada a binaria para que se pueda procesar o mover a otro dispositivo", //help467
	"Comunicación entre un único remitente y un receptor", //help719
	"Red de área local", //help594
	"Un versión más reciente de la tarjeta PC Card o interfaz PCMCIA. Admite una ruta de datos de 32-bits, DMA, y consume menos tensión", //help457
	"Rendezvous", //help666
	"Secure Shell es una interfaz de línea de comandos que permite conexiones seguras con ordenadores remotos", //help698
	"GUI", //help538
	"Capa de red", //help630
	"7ª capa del modelo OSI. Proporciona servicios a las aplicaciones para garantizar que pueden comunicarse correctamente con otras aplicaciones en una red.", //help422
	"Espectro ensanchado de secuencia directa", //help493
	"Servicio DNS dinámico", //help507
	"Internet Explorer", //help571
	"El cálculo de velocidad se ha anulado porque no se pudieron conseguir las mediciones", //RATE_ESTIMATOR_CONVERGENCE_ERROR
	"Un valor u opción predeterminados que utiliza un programa cuando el usuario no especifica ningún dato para este valor o configuración", //help487
	"Interfaz de Usuario Extendida para NetBIOS es un protocolo de comunicaciones de red de área local. Es una versión actualizada de NetBIOS", //help624
	"No se pueden transmitir y recibir datos al mismo tiempo", //help543
	"Service Set Identifier (Identificador de Grupos de Servicios) es un nombre para la red inalámbrica", //help700
	"Cliente", //help460
	"Par Trenzado No apantallado", //help730
	"Enviar una solicitud de un ordenador a otro para que el segundo le transmita un archivo al ordenador solicitante", //help502
	"Correo electrónico", //help513
	"Protocolo de Inicio de Sesión. Un protocolo estándar para iniciar una sesión de usuario que incluye contenido multimedia, tal como voz o chat.", //help690
	"Mbps", //help607
	"Programa que se inserta en un dispositivo hardware que le indica cómo funcionar", //help525
	"Una compañía que proporciona una conexión a Internet de banda ancha mediante una conexión inalámbrica", //help754
	"MPPE", //help617
	"Un nombre que va asociado con una dirección IP", //help500
	"Protocolo de mensaje de control de Internet", //help558
	"APIPA. Una dirección IP que un ordenador Windows se asignará a sí mismo cuando esté configurado para obtener automáticamente una dirección IP pero en la red no exista un servidor DHCP disponible", //help429
	"EAP", //help511
	"Gbps", //help534
	"“Zona desmilitarizada”. Un ordenador ubicado lógicamente en 'tierra de nadie' entre la LAN y la WAN. El equipo DMZ pierde parte de la protección proporcionada por los mecanismos de seguridad del enrutador por la comodidad de ser direccionable directamente desde Internet.", //help496
	"Cuello de botella", //help446
	"Le permite encender un ordenador a través de su Tarjeta de Interfaz de Red", //help739
	"Determina qué parte de una dirección IP designa la Red y qué parte identifica al host", //help627
	"Sesiones activas", //_actsess
	"La prioridad 0 está reservada.", //help91a
	"Los flujos sin prioridad asignada por alguna regla reciben la prioridad más baja.", //help91b
	"Las opciones comunes se pueden seleccionar desde el menú desplegable.", //help92x1
	"Para especificar cualquier otro protocolo, introduzca el número correspondiente (<a href='http://www.iana.org/assignments/protocol-numbers' target='_blank'>según lo asignado por el IANA</a>) en el cuadro <span class='option'>Protocolo</span>.", //help92x2
	"Cuando una aplicación LAN que usa un protocolo distinto a UDP, TCP o ICMP inicia una sesión en internet, la NAT del router puede rastrearla, incluso aunque no reconozca el protocolo. Esta característica es útil porque habilita ciertas aplicaciones (lo que es más importante, una conexión VPN a un host remoto) sin necesitar un ALG.", //TA21
	"Tenga en cuenta que esta característica no se aplica al host DMS (si hay uno habilitado). El host DMZ siempre gestiona este tipo de sesiones.", //TA22
	"Son recomendados.[M4]", //help183
	"Marque esta casilla para permitir que el servidor DHCP ofrezca los parámetros de configuración NetBIOS a los hosts de la LAN.", //help400_b
	"Si los anuncios NetBIOS están activados, cambiar este parámetro hace que la información WINS pueda conocerse desde el lado WAN, si está disponible.", //help401_b
	"Configure la dirección IP del servidor WINS que prefiera.", //help402_b
	"ActiveX", //help403
	"Configure la dirección IP del servidor WINS de respaldo, si lo hay", //help403_b
	"Una especificación de Microsoft para la interacción de los componentes de software.", //help404
	"Este es un parámetro avanzado y suele dejarse en blanco. Permite configurar un nombre de «dominio» NetBIOS bajo el que funcionarán los hosts de la red.", //help404_b
	"Red Ad-hoc", //help405
	"Indica cómo están los hosts de la red para realizar el registro de nombre NetBIOS  y descubrirlos.", //help405_b
	"Error de configuración Peer %u", //WIFISC_AP_PEER_CFG_ERR
	"AppleTalk", //help417
	"Un conjunto de protocolos de red de área local desarrollados por Apple para sus sistemas informáticos", //help418
	"Protocolo de resolución de direcciones AppleTalk", //help419
	"AARP. Utilizado para asignar direcciones MAC de equipos Apple a sus direcciones de red AppleTalk para que se puedan realizar las conversiones en ambas direcciones.", //help420
	"Sistema de entrada y salida básico", //help434
	"BIOS. Un programa que utiliza el procesador de un ordenador para iniciar el sistema cuando se enciende", //help435
	"Baud", //help436
	"Velocidad de transmisión de datos", //help437
	"BOOTP", //help444
	"Protocolo Bootstrap. Permite que los ordenadores se inicien y se les a asigne una dirección IP sin intervención del usuario", //help445
	"CAT 5", //help458
	"Categoría 5. Utilizada para conexiones Ethernet de 10/100 Mbps ó 1Gbps", //help459
	"DB-25", //help474
	"Un conector macho de 25 pines para conectar módems externos o dispositivos serie RS-232", //help475
	"DB-9", //help476
	"Un conector de 9 pins para conexiones de RS-232", //help477
	"dBd", //help478
	"Decibelios asociados a la antena dipolo", //help479
	"Fibra óptica", //help518
	"Un modo de enviar datos por medio de impulsos luminosos a través de cable o fibra de vidrio o plástico", //help519
	"Compartir archivos", //help522
	"Permitir el acceso a los datos almacenados en los ordenadores de una red por parte de otros ordenadores de la red con diferentes niveles de derechos de acceso", //help523
	"Protocolo de transferencia de archivos. El modo más fácil de transferir archivos entre ordenadores en Internet", //help528
	"Ganancia", //help531
	"La cantidad que un amplificador incrementa la señal inalámbrica", //help532
	"Hashing", //help544
	"Trasformar una cadena de caracteres en una cadena más corta con una longitud predefinida", //help545
	"Salto", //help548
	"IIS", //help563
	"Internet Information Server es un servidor WEB y FTP suministrado por Microsoft", //help564
	"Intranet", //help579
	"Una red privada", //help580
	"Detección de intrusión", //help581
	"Un tipo de seguridad que examina una red para detectar ataques procedentes de dentro y fuera de la red", //help582
	"Java", //help588
	"Lenguaje de programación utilizado para crear programas y aplicaciones para las páginas Web", //help589
	"LPR/LPD", //help602
	"'Solicitante de impresora en línea'/'Demonio de impresora en línea'. Un protocolo TCP/IP para transmitir secuencias de datos de impresoras.", //help603
	"MDI", //help609
	"Interfaz Dependiente del Medio es un puerto Ethernet para conectar a un cable recto", //help610
	"MDIX", //help611
	"Cruce de Interfaz Dependiente del Medio es un puerto Ethernet para conectar a un cable de enlace", //help612
	"MIB", //help613
	"Base de datos de Información de Administración es un conjunto de objetos que se pueden administrar mediante SNMP", //help614
	"Módem", //help615
	"Dispositivo que modula señales digitales provenientes de un ordenador convirtiéndolas en señales analógicas para transmitirlas a través de las líneas telefónicas. También desmodula las señales analógicas que provienen de las líneas telefónicas convirtiéndolas en señales digitales utilizables por los ordenadores", //help616
	"Oct", //tt_Oct
	"Creador", //sa_Originator
	"Múltiplexación por División Ortogonal de Frecuencias es la técnica de modulación de 802.11a y 802.11g", //help637
	"Abrir Primero la Ruta más Corta es el protocolo de enrutamiento que se utiliza más que RIP en redes de mayor escala porque solamente los cambios ocurridos en la tabla de enrutamiento se envían a los demás enrutadores de la red en lugar de enviar la tabla de enrutamiento completa en intervalos regulares, que es el modo en el que RIP funciona", //help641
	"OSI", //help638
	"La configuración en modo abierto no es segura.", //msg_non_sec
	"Personal", //LW24
	"Interconexión de dispositivos de red en un radio de 10 metros", //help644
	"PoE", //help649
	"Power over Ethernet es el medio de transmitir electricidad a través de los pares no utilizados en un cable Ethernet de Categoría 5", //help650
	"RJ-11", //help672
	"El método de conexión más utilizado para los teléfonos", //help673
	"RS-232C", //help676
	"La interfaz para la comunicación serie entre ordenadores y otros dispositivos asociados", //help677
	"SOHO", //help693
	"Oficina pequeña/oficina en casa", //help694
	"TFTP", //help711
	"El Protocolo Trivial de Transferencia de Archivos es una utilidad empleada para transferir archivos que resulta más sencilla de usar que el FTP pero tienen menos funciones", //help712
	"VLAN", //help733
	"LAN virtual", //help734
	"WDS", //help743
	"Sistema de Distribución Inalámbrico. Un sistema que hace posible la interconexión de puntos de acceso de modo inalámbrico.", //help744
	"Antena Yagi", //help763
	"Una antena direccional utilizada para concentrar las señales inalámbricas sobre una dirección determinada", //help764
	"Tenga en cuenta que los mensajes de registro utilizan el idioma en uso en el momento del evento registrado. Si cambia de idioma puede que vea los mensajes de registro en diferentes idiomas.", //help795a
	"Interno", //sa_Internal
	"Externo", //sa_External
	"OpenDNS&reg; controles paternos&#8482", //DNS_TEXT7
	"Select a filter that controls access as needed for this admin port. If you do not see the filter you need in the list of filters, go to the <a href ='Inbound_Filter.asp' onclick ='return jump_if();'>Advanced &rarr;&nbsp;Inbound&nbsp;Filter</a> screen an", //help831_1
	"Opciones para mejorar la velocidad y fiabilidad de la conexión a Internet, para aplicar el filtrado de contenidos y protegerle de los sitios de suplantación de identidad. Elija entre los grupos preconfigurados o registre el router con OpenDNS&reg; para elegir entre 50 categorías de contenido y disponer de bloqueo personalizado.", //DNS_TEXT1
	"Agregar/editar regla de programación", //help191
	"Guarda la nueva o modificada regla de filtro entrante en la lista siguiente", //help198
	"Desconocido (espere, por favor...)", //_unknown_wait
	"Desconocido", //_unknown
	"N/A", //_na
	"Sin información del equipo.", //_sdi_nciy
	"Cliente DHCP", //_sdi_dhcpclient
	"Cliente BigPond", //_sdi_bpc
	"Dispositivos o tecnología más antiguos", //help600
	"No hay información sobre miembros del grupo de multidifusión", //_bln_nmgmy
	"Configuración incorrecta", //_sdi_s1
	" Cambio de estado (espere...)", //_sdi_s10
	" Sesión cerrada", //_sdi_s8
	" Fallo", //_sdi_s9
	"día(s),", //_sdi_days
	"(la desconexión se realizará en).", //_sdi_disconnectpending
	"unos segundos)", //_sdi_secs
	"Renovación DHCP", //sd_Renew
	"Versión DHCP", //sd_Release
	"Desconectar", //sd_Disconnect
	"Entrar a BigPond", //sd_bp_login
	"Salir de BigPond", //sd_bp_logout
	"Canal", //_channel
	"Registros del sistema", //sl_SLogs
	"Estado del servidor de impresión", //sps_intro2
	"las impresoras son", //sps_pare
	"Tabla de enrutamiento", //sr_RTable
	"El menú Estado de enrutamiento muestra información sobre las rutas habilitadas en el router. En la lista se mostrará la dirección IP de destino, la dirección IP de la puerta de enlace, la máscara de subred, la métrica y la interfaz de cada ruta.", //sr_intro
	"Estadísticas del tráfico de la red", //ss_title_stats
	"Lista de clientes inalámbricos asociados", //sw_title
	"Valor no válido para el tiempo de espera inactivo del administrador; debería estar en el rango (1..65535).", //ta_alert_1
	"Asegúrese de que el cable entre el módem ADSL/por cable y el router está conectado correctamente. El router volverá a intentar detectar su tipo de conexión a Internet.", //ES_CABLELOST_dsc1
	"Haga que las dos contraseñas sean iguales e inténtelo de nuevo", //_pwsame
	"'Puerto de administración remota no válido ''+data.wan_web_port+'', debería estar en el rango (1..65535)'", //ta_alert_3
	"No se admite el proveedor de servicios de DNS dinámico especificado", //_invalidddnsserver
	"La dirección del servidor especificado está en blanco", //_blankddnsserver
	"Cambie en primer lugar el protocolo de wan IPv6", //IPV6_TEXT1
	"El valor del tiempo de espera no puede ser cero.", //td_alert_2
	"El valor del tiempo de espera no puede mayor que 8760.", //td_alert_3
	"DNS dinámico (DDNS)", //td_DDNSDDNS
	"Seleccionar servidor DNS dinámico", //tt_SelDynDns
	"El Nombre de cuenta debe ser válido", //_emailaccnameisblank
	"La dirección de correo electrónico del remitente no puede quedar en blanco.", //_blankfromemailaddr
	"La dirección de correo electrónico del destinatario no puede quedar en blanco.", //_blanktomemailaddr
	"La dirección del servidor SMTP no puede quedar en blanco.", //_blanksmtpmailaddr
	"La dirección de correo electrónico'' + from_addr + ''no es válida.", //_badfromemailaddr
	"La dirección de correo electrónico  '' + to_addr + ''no es válida.", //_badtoemailaddr
	"La dirección del servidor SMTP '' + data.smtp_email_server_addr + ''no es válida.", //_invalidsmtpserveraddr
	"La dirección del servidor SMTP no está permitida", //_badsmtpserveraddr
	"Está disponible una versión de firmware más reciente.", //tf_NFWA
	"Se ha excedido el tiempo de espera de la sesión Web. Vuelva a reinciar sesión para acceder a esta página.", //tf_alert_1
	"Basado en el resultado de comprobación en línea, la versión más reciente de firmware es:", //tf_LFWVis
	"Comprobación de actualización de firmware en progreso.", //tf_FWCinP
	"Comprobando la disponibilidad del nuevo firmware", //tf_Ching_FW
	"Las notificaciones por correo electrónico no están habilitadas.", //tf_EM_not
	"Última versión de firmware", //tf_LFWV
	"Compruebe ahora en línea la última versión del firmware", //tf_FWChNow
	"Las actualizaciones de firmware se publican periódicamente para mejorar la funcionalidad de su router y para añadir características. Si tiene algún problema con una característica específica del router, visite nuestro sitio de soporte. Para ello, haga clic en el enlace <strong>Compruebe ahora en línea la última versión del firmware</strong> y consulte si existe firmware actualizado disponible para su router.", //TA17
	"Buscando impresoras...", //tps_sfp
	"Haga doble clic en un icono para instalar la impresora", //tps_dci
	"Configuración del servidor de impresión", //tps_intro2
	"'No se ha seleccionado día para la programación ''+(data.sched_table[i].sched_name)+'''", //tsc_alert_1
	"Hora no válida", //tsc_alert_2
	"\"El nombre del programa '\"+(data.sched_table[i].sched_name)+\"' está reservado y no se puede utilizar\"", //tsc_alert_3
	"'Este programación ya se usa '", //tsc_alert_6
	"'No hay espacio para más entradas'", //tsc_alert_9
	"Seleccionar día(s)", //tsc_SelDays
	"Periodo de tiempo", //tsc_TimeFr
	"'La dirección IP del servidor syslog no debe ser la mismo como la dirección IP del gateway'", //tsl_alert_3
	"'La dirección IP del servidor syslog está en la subred de la WAN, y debería estar en la subred de la LAN ('+lan_subnet+')'", //tsl_alert_1
	"'La dirección IP del servidor syslog debe estar dentro de la subred de la LAN ('+lan_subnet+ ')'", //tsl_alert_2
	"Una vez que su router esté configurado como usted desea, puede guardar los parámetros de configuración en un archivo de configuración.", //ZM18
	"milisegundos. TTL =", //tsc_pingt_msg9
	"NTP", //help635
	"La hora del gateway se ha actualizado", //tt_alert_tupdt
	"Semana", //TA24
	"Día de la semana", //TA25
	"Acceso prohibido", //fb_FbAc
	"El centinela ha bloqueado el acceso Web", //sentinel_1
	"El servicio centinela de su router ha bloqueado el acceso a este sitio web para este ordenador.", //sentinel_2
	"Póngase en contacto con el Administrador del servicio centinela para permitir el acceso a esta página.", //sentinal_3
	"Fallo[M7]", //fl_Failure
	"NO se han guardado los nuevos parámetros porque se ha producido un error.", //fl_text
	"Hay una nueva actualización de firmware disponible. El sistema le dirigirá a la página de actualización al iniciar sesión.", //li_newfw
	"Ahora se le redigirá a la página de inicio de sesión.", //rd_p_1
	"Si la página de inicio de sesión no aparece, haga clic en <a href='login.asp'>este vínculo</a>.", //rd_p_2
	"Restaurar parámetros", //rs_Restoring_Settings
	"El archivo de parámetros no es válido.", //reh
	"Restaurando configuración; espere, por favor.", //rs_RSPW
	"Datos locales convertidos", //rs_cld
	"Listo", //rs_Done
	"Datos locales desempaquetados", //rs_uld
	"Datos guardados desempaquetados", //rs_usd
	"Datos guardados convertidos", //rs_csd
	"Reempaquetado", //rs_Repacked
	"Convertido", //rs_Converted
	"Guardando", //rs_Saving
	"Se debe reiniciar el router para que los nuevos parámetros surtan efecto. Puede reiniciar el router en este momento con el siguiente botón, o bien, realizar otros cambios y utilizar el botón de reinicio de la página Herramientas/Sistema.", //sc_intro_rb
	"Volver a iniciar sesión", //_relogin
	"Máscara de subred WAN no válida.", //_badWANsub
	"Dirección IP de la puerta de enlace no válida.", //wwa_pv5_alert_4
	"La dirección IP del gateway no está en la subred de la WAN.", //wwa_pv5_alert_5
	"Debe especificar el servidor DNS primario", //wwa_pv5_alert_8
	"Dirección IP de DNS primario no válida.", //wwa_pv5_alert_6
	"Dirección IP de DNS secundario no válida.", //wwa_pv5_alert_7
	"El campo Nombre de usuario no puede quedar en blanco", //wwa_pv5_alert_21
	"La dirección IP del gateway PPTP no es válida", //_badPPTPgwip
	"Dirección de servidor PPTP no válida", //wwa_pv5_alert_15
	"La dirección IP del gateway L2TP no es válida", //_badL2TPgwip
	"Dirección del servidor L2TP no válida", //wwa_pv5_alert_20
	"Para proteger su red de piratas informáticos y usuarios no autorizados, se recomienda encarecidamente elegir uno de los parámetros de seguridad de red inalámbrica siguientes.", //wwl_intro_s3_1
	"Existen tres niveles de seguridad inalámbrica: Buena seguridad, Mejor seguridad y la mejor seguridad. El nivel que elija depende de las características de seguridad que admitan los adaptadores inalámbricos.", //wwl_intro_s3_2r
	"Clave de acceso de seguridad inalámbrica", //wwl_WSP_1
	"WPA-PSK/TKIP (también conocido como  WPA Personal)", //wwl_wpa
	"WPA2-PSK/AES (también llamada WPA2 Personal)", //wwl_wpa2
	"TELNET", //gw_vs_0
	"PC REMOTO", //gw_vs_8
	"Charla AIM", //gw_sa_0
	"Teléfono IP Calista", //gw_sa_2
	"ICQ", //gw_sa_3
	"MSN Messenger", //gw_sa_4
	"Charla PAL", //YM47
	"Seleccionar servidor de BigPond", //gw_SelBPS
	"Nombre1", //gw_bp_0
	"Nombre2", //gw_bp_1
	"Nombre3", //gw_bp_2
	"PlayStation2", //gw_gm_81
	"El control ActiveX WCN no está disponible. Compruebe la configuración de seguridad y actualice esta página para instalarla.", //gw_wcn_alert_4
	"WCN no admite índices de clave que no sean 1.", //gw_wcn_alert5
	"WCN no admite ahora el modo WPA2.", //gw_wcn_alert6
	"WCN no admite ahora la autenticación de empresa WPA.", //gw_wcn_alert7
	"La configuración inalámbrica se ha guardado correctamente.", //gw_wcn_err_ok
	"Código de error:", //gw_wcn_err_code
	"Esta versión del sistema operativo no admite WCN", //gw_wcn_err_os_version
	"Error al cargar el archivo de configuración inalámbrica. Ejecute el Asistente para instalación de la red inalámbrica de Windows para crear o volver a crear el archivo de configuración", //gw_wcn_err_load_config
	"Error al agregar el perfil inalámbrico. Asegúrese de que el nuevo SSID no entra en conflicto con algún perfil existente", //gw_wcn_err_provision
	"Error al escribir datos inalámbricos en el archivo de configuración. Compruebe el parámetro de seguridad.", //gw_wcn_err_io_write_config
	"Error al encriptar los datos inalámbricos", //gw_wcn_err_encryption
	"Error interno", //gw_wcn_err_exception
	"El control ActiveX de WCN no se ha registrado. Por favor, compruebe el parámetro de seguridad y actualice esta página para instalarlo.", //gw_wcn_err_com
	"Parámetros inalámbricos no vállidos. Compruebe los parámetros inalámbricos.", //gw_wcn_err_bad_wsetting_entry
	"No se puede crear el fichero XML de perfil inalámbrico", //gw_wcn_err_bad_wps_profile
	"El modo de seguridad de WPA no está habilitado. Por favor, compruebe los parámetros de seguridad.", //gw_wcn_err_unsupported_wsetting
	"El analizador del DOM de MSXML2 no ha podido analizar la cadena en formato XML.", //gw_wcn_err_dom_processing
	"Error inesperado", //gw_wcn_err_default
	"Todos permitidos", //adv_Everyone
	"Ninguno permitido", //adv_Noone
	"En cola", //psQueued
	"Iniciando", //psStarting
	"Cerrado", //psClosed
	"Inactivo", //psIdle
	"Preparado", //psReady
	"Recibida oferta para la sesión PPPoE %s, el servicio ofrecido es el %s de %s (%m)", //GW_PPPOE_EVENT_OFFER
	"Desconectado", //psUnplugged
	"Imprimiendo", //psPrinting
	"PAP envió respuesta de autenticación \'%s\' a punto remoto.", //IPPPPPAP_AUTH_RESULT
	"'La cadena '' + value + '' es demasiado larga\n(la longitud máxima es ' + length + ' caracteres).'", //up_gS_1
	"'El número '' + value + '' no es válido.'", //up_gIUH_1
	"'El número '' + value + '' debe ser positivo.'", //up_gIUH_2
	"'El número '' + value + '' debe estar entre '+ min + ' y ' + max + '.'", //up_gIUH_3
	"'La cadena hexadecimal '' + value + '' no es válida.'", //up_gH_1
	"No hay sitio para más entradas.", //up_ae_se_1
	"El campo %s no puede estar en blanco.", //up_ai_se_2
	"this.primary_key_name+' ''+ this.thearray[-1][this.primary_key] +'' ya se ha utilizado'", //up_ae_se_3
	"Hay cambios no guardados en la entrada que está editando.", //up_ae_wic_1
	"Pulse 'Aceptar' para renunciar a esos cambios y realizar la acción solicitada.", //up_ae_wic_2
	"Nota:<br />Si se activa DNS Relay junto con la característica DNS avanzado, las estaciones de trabajo de la red que reciban una dirección IP del servidor DHCP del router obtendrán la dirección 192.168.0.1 (la dirección IP del router). No obstante, el tráfico seguirá protegido.", //_Advanced_02
	"¿Desea abandonar todos los cambios realizados en este asistente?", //up_fm_dc_1
	"Error al restaurar la configuración", //up_fm_re_1
	"Pulse Aceptar para continuar", //up_fm_re_2
	"archivo de configuración defectuoso", //up_fm_dr_1
	"archivo de configuración defectuoso", //up_fm_dr_2
	"Los datos restaurados no son aceptables", //up_fm_dr_3
	"La acción no se puede completar porque la conexión de red parece que no funciona", //up_if_1
	"Reiniciar.", //up_rb_3
	"Restablecer las opciones predeterminadas de fábrica y reiniciar.", //up_rb_6
	"'La cadena del intervalo de puertos '+name+' ''+input_string+'' no es válida.'", //up_vp_1
	"'El puerto '+name+' ''+n+'' de la cadena del intervalo de puertos ''+input_string+'' debe estar entre 1 y 65535.'", //up_vp_2
	"'El rango de puertos '+name+' '+got2[0]+'' de la cadena del intervalo de puertos ''+input_string+'' debe ir de un puerto bajo a un puerto alto.'", //up_vp_3
	"'La cadena del intervalo de puertos '+name+' no puede estar vacía.'", //up_vp_0
	"Un campo de dirección MAC no puede estar vacío.", //up_vm_1
	"no es una dirección MAC válida.", //up_vm_2
	"'Se ha producido un error en esta página. La causa podría ser que\n'+ 'no se ha iniciado la sesión correctamente, por ejemplo, justo después de reiniciar.\n'", //up_he_1
	"'Pulse Aceptar para ir a la página de inicio de sesión, o Cancelar si desea ver\n'+ 'el mensaje de error.'", //up_he_2
	"'El error en la línea '+line+' de '+url+' es:\n\''+msg+'\'.'", //up_he_5
	"Charla PAL", //gw_sa_5
	"Se ha bloqueado el paquete de %v a %v recibido desde la interfaz de red incorrecta (spoofing de dirección IP).", //IPSTACK_REJECTED_SPOOFED_PACKET
	"El intento de asignación de concesión ha fallado: se ha detectado un host de LAN activo con la dirección %v y MAC de %m", //IPDHCPSERVER_HOST_IS_ACTIVE
	"Error en la autorización del servicio %S: el servicio no está registrado", //BSECURE_LOG_AUTH_FAIL_UNREG
	"La velocidad estimada de conexión es %d kbps", //RATE_ESTIMATOR_RATE_IS
	"Filtro - Denegadopaquete desde dirección IP %v, puerto %u, protocolo %u, a %v puerto %u", //GW_IPFILTER_DENY
	"No se puede establecer conexión con el servidor de correo electrónico", //GW_SMTP_EMAIL_CANNOT_CREATE_CONNECTION
	"Se ha eliminado paquete a un destino ilegal %v de %v", //IPNAT_ILLEGAL_DEST
	"Se ha desconectado el servidor de filtro %S: tiempo de espera excedido", //BSECURE_LOG_FLTR_DISCONNECTED_TIMEOUT
	"Al cliente %02x:%02x:%02x:%02x:%02x:%02x se le ha revocado su concesión (%v).", //IPDHCPSERVER_LEASE_REVOKED1
	"Mensaje anterior repetido una vez", //LOG_PREV_MSG_REPEATED_1_TIME
	"UPnP ha cambiado VS entrada %v <-> %v:%d <-> %v:%d %s por %s", //GW_UPNP_PORTMAP_VS_CHANGE
	"La concesión %v ha caducado", //IPDHCPSERVER_LEASE_EXPIRED
	"No se logró la autorización del servicio %S: error interno", //BSECURE_LOG_AUTH_FAIL_INTNL
	"Entrada UPnP eliminada %v <-> %v:%d %s", //GW_UPNP_PORTMAP_DEL
	"Imposible enviar correo electrónico porque \'%s\' no es una dirección \'To:\' válida", //GW_SMTP_EMAIL_INVALID_TO_ADDRESS
	"Se ha desconectado el servidor de filtros %S: cerrado", //BSECURE_LOG_FLTR_DISCONNECTED_CLOSED
	"La concesión ha caducado %v – ha sido reasignada porque un cliente solicitó específicamente esta dirección", //IPDHCPSERVER_LEASE_EXPIRED_SPECIFIC
	"Aprobada la autorización del servicio %S", //BSECURE_LOG_AUTH_PASS
	"Error en la autorización del servicio %S: el servidor de aut devolvió el error UNKNOWN", //BSECURE_LOG_AUTH_FAIL_UNKNW
	"Sólo PAP", //wwan_auth_pap
	"Error en la autorización del servicio %S: se tiene que reno", //BSECURE_LOG_AUTH_FAIL_RENEW
	"El cliente %m quería una dirección específica (%v) pero no está disponible", //IPDHCPSERVER_LEASE_DENIED
	"Imposible enviar correo electrónico (excedido el tiempo de espera de conexión)", //GW_SMTP_EMAIL_TIMEOUT
	"Error en la autorización del servicio %S: el servidor de aut devolvió error DB", //BSECURE_LOG_AUTH_FAIL_DB
	"Se ha actualizado el parámetro %u del servidor DHCP", //IPDHCPSERVER_PARAM_DB_UPDATED
	"Reglas de aplicación", //APP_RULES
	"Tabla de concesiones llena", //IPDHCPSERVER_LEASE_POOL_FULL
	"Error en la autenticación PAP, compruebe detalles del inicio de sesión.", //IPPPPPAP_AUTH_SUCCESS
	"Red avanzada", //ADVANCED_NETWORKS
	"Asignada nueva concesión %v al cliente %m", //IPDHCPSERVER_LEASE_ASSIGNED
	"Se ha conectado el servidor de filtros %S", //BSECURE_LOG_FLTR_CONNECTED
	"Se ha conectado el servidor de aut %S", //BSECURE_LOG_AUTH_CONNECTED
	"Error en la autorización del servicio %S: el paquete de respuesta aut está dañado", //BSECURE_LOG_AUTH_FAIL_PKT
	"El cliente SMTP no se ha conseguido conectar al servidor %v", //IPSMTPCLIENT_CONN_FAILED
	"Error en la autenticación PAP, compruebe detalles del inicio de sesión.", //IPPPPPAP_AUTH_FAIL
	"La última versión de firmware recuperada del servidor fue %d.%d", //GW_LOG_ON_LATEST_FIRMWARE_RETRIEVED
	"Imposible enviar correo electrónico (enviar estado %u)", //GW_SMTP_EMAIL_SEND_FAILURE
	"El cliente %m ha liberado la concesión %v", //IPDHCPSERVER_LEASE_RELEASED
	"Se ha agregado el parámetro %u del servidor DHCP a la base de datos de parámetros", //IPDHCPSERVER_PARAM_DB_ADDED
	"Se ha realizado con éxito la autenticación PAP.", //IPPPPPAP_AUTH_TIMEOUT
	"Entrada UPnP añadida %v <-> %v:%d <-> %v:%d %s tiempo de espera:%d '%s'", //GW_UPNP_PORTMAP_ADD
	"Imposible enviar correo electrónico porque se desconoce dirección IP de servidor", //GW_SMTP_EMAIL_NO_SERVER_IP_ADDRESS
	"Entrada renovación UPnP %v <-> %v:%d <-> %v:%d %s tiempo de espera:%d '%s'", //GW_UPNP_PORTMAP_REFRESH
	"Entrada UPnP finalizada  %v <-> %v:%d <-> %v%d %s '%s'", //GW_UPNP_PORTMAP_EXPIRE
	"Se ha eliminado el parámetro %u del servidor DHCP de la base de datos de parámetros", //IPDHCPSERVER_PARAM_DB_REMOVED
	"La concesión ha sido eliminada del grupo de servidores %v", //IPDHCPSERVER_LEASE_DELETED
	"UPnP entra en conflicto con la entrada existente %v <-> %v:%d <-> %v:%d %s '%s'", //GW_UPNP_PORTMAP_CONFLICT
	"No se han cargado todos los componentes necesarios; esta página se actualizará.", //TA1
	"no es una dirección IP válida", //aa_alert_11
	"Esta regla de control de acceso ya ha sido definida por la política  + data.access_ctrl_table[i].policy_name", //aa_alert_1
	"Hay '+ unsaved_policies + 'políticas que no se han guardado, ¿desea prescindir de estas políticas?", //aa_sched_conf_3
	"'La regla de filtro de puerto'' + data.access_ctrl_table[-1].port_filter_table[i].entry_name + ''está duplicada.'", //aa_alert_16
	"'La dirección IP inicio para el filtro de puerto = ''+data.access_ctrl_table[-1].port_filter_table[j].entry_name+'' no debe estar en la subred LAN ('+lan_subnet+')'", //aa_alert_2
	"'La dirección IP final para el filtro de puerto = ''+data.access_ctrl_table[-1].port_filter_table[j].entry_name+'' no debe estar en la subred LAN ('+lan_subnet+')'", //aa_alert_3
	"'El rango de la dirección IP de destino para el filtro de puerto no es válido = ''+data.access_ctrl_table[-1].port_filter_table[j].entry_name+'''", //aa_alert_4
	"'El rango del puerto de destino para el filtro de puerto no es válido = ''+data.access_ctrl_table[-1].port_filter_table[j].entry_name+'', debería estar en el rango (1..65535 ) '", //aa_alert_5
	"'El puerto inicio de destino para el filtro de puerto = ''+data.access_ctrl_table[-1].port_filter_table[j].entry_name+'' no debe ser mayor que el puerto final de destino'", //aa_alert_6
	"Otros Equipos", //_aa_other_machines
	"&copy; Copyright 2015 TRENDnet. All Rights Reserved.", //_copyright
	"El intervalo válido para el umbral de fragmentación es 256..65535", //aw_alert_1
	"El intervalo válido para el umbral RTS es 1..65535", //aw_alert_2
	"El intervalo válido para el período de baliza es 20..1000", //aw_alert_3
	"El intervalo válido para el intervalo DTM es 1..255", //aw_alert_4
	"'La dirección DMZ debe estar en la subred LAN ('+lan_subnet+')'", //af_alert_1
	"'La dirección DMZ no está permitida'", //af_alert_2
	"(se desactiva automáticamente si se activa UPnP)", //TA19
	"Este registro ''+ data.game_rules[j].entry_name + '' ya existe.", //ag_alert_4
	"Este registro de '+ data.game_rules[j].entry_name + ' es un duplicado de '' + data.game_rules[i].entry_name + ''.", //ag_alert_5
	"'Los puertos TCP ['+data.game_rules[i].tcp_ports_to_open+'] están en conflicto con '+data.game_rules[j].entry_name+' puertos TCP ['+data.game_rules[j].tcp_ports_to_open+']'", //ag_conflict10
	"'Los puertos UDP ['+data.game_rules[i].udp_ports_to_open+'] están en conflicto con '+data.game_rules[j].entry_name+' puertos UDP['+data.game_rules[j].udp_ports_to_open+']'", //ag_conflict20
	"Seleccione un programa para el registro ' + data.game_rules[i].entry_name + ''.'", //ag_conflict21
	"'La dirección IP para ''+data.game_rules[i].entry_name+'' debe estar en la subred LAN ('+lan_subnet+')'", //ag_alert_1
	"'La dirección IP para ''+data.game_rules[i].entry_name+'' no está permitida'", //ag_alert_3
	"Los campos 'Puertos TCP que se van a abrir' y 'Puertos UDP que se van a abrir' no pueden estar en blanco.", //ag_alert2
	"Puertos TCP", //_tcpports
	"Puertos UCP", //_udpports
	"Los puertos %s [%s] están en conflicto con el puerto de gestión remota", //ag_conflict4
	"'No puede cambiar el nombre de esta entrada porque ya se ha utilizado en la página '+used_page+'.'", //tsc_alert_7
	"'Rango de IP fuente no válido para ''+data.ingress_rules[i].ingress_filter_name+'''+'('+data.ingress_rules[i].ip_range_table[j].ip_start+','+data.ingress_rules[i].ip_range_table[j].ip_end+')'", //ai_alert_3
	"Habilitar por lo menos un rango de IP de origen para '%s'", //GW_FIREWALL_NO_IP_RANGE_INVALID
	"El rango de filtro de entrada '%s - %s' está duplicado.", //ai_alert_7
	"'El nombre de filtro entrante ''+(data.ingress_rules[i].ingress_filter_name)+'' está reservado y no se puede usar.'", //ai_alert_4
	"'La regla de filtro entrante '' + data.ingress_rules[-1].ingress_filter_name + ''está duplicada.'", //ai_alert_6
	"'No puede eliminar esta entrada porque ya se ha utilizado en la página '+x+'.'", //tsc_alert_5
	"Reglas de filtro entrante", //ai_title_2
	"Editar", //_edit
	"Intervalo IP de origen", //_srcip
	"Fuente de IP inicio", //ai_c2
	"Fuente de IP final", //ai_c3
	"La \"' + saved_records[i].mac_addr + '\" dirección MAC está duplicada.'", //amaf_alert_1
	"Denegar el acceso a todos los ordenadores excepto a los de la lista (sujeto a \'Filter Settings\'):", //am_cMT_deny
	"Permitir el acceso a todos los ordenadores excepto a los de la lista (sujeto a \'Filter Settings\'):", //am_cMT_Allow
	"Sin información de rutas", //_sr_nriy
	"Esta ruta internal ya se usa", //ar_alert_1
	"Esta ruta ya existe", //ar_alert_2
	"El valor métrico debe estar comprendido entre1 y 16", //ar_alert_3
	"El siguiente salto no está en la interfaz especificada", //ar_alert_4
	"Máscara de red no válida", //ar_alert_5
	"La opción de enrutamiento le permite definir rutas fijas a destinos definidos", //ar_RoutI
	"Ruta", //ar_Route
	"Lista de rutas", //ar_RoutesList
	"Eliminar", //_delete
	"Rutas existentes", //ar_ERTable
	"El nombre ' + saved_records[i].entry_name + ' de las reglas de aplicaciones está duplicado.", //ag_alert_duplicate_name
	"El nombre de las reglas de aplicaciones ' + saved_records[j].entry_name + ' es un duplicado de ' + saved_records[i].entry_name + '", //ag_alert_duplicate
	"Ya se ha utilizado esta regla", //ag_inuse
	"'El rango de puerto trigger '+protocols[ae.thearray[-1].trigger_ports.protocol]+' ['+ae.thearray[-1].trigger_ports.port_range+'] está en conflicto con '+saved_records[i].entry_name+':'+protocols[saved_records[i].trigger_ports.protocol]+' ['+saved_records[i].trigger_ports.port_range+']'", //_specapps_alert_2
	"Rango de puerto trigger", //_specapps_tpr
	"Entrar rango de puerto", //_specapps_ipr
	"Reglas de aplicaciones especiales", //as_title_SAR
	"Rango de puerto trigger", //as_TPRange
	"p. ej.,", //as_ex
	"Protocolo de activación", //as_TPR
	"Entrar rango de puerto", //as_IPR
	"Entrar protocolo", //as_IPrt
	"La velocidad de transmisión máxima debe estar entre 8 kbps y 10 Mbps, ambos valores inclusive.", //at_alert_1_1
	"El nombre no puede estar en blanco.", //at_alert_15
	"La prioridad '+data.qos_rules[i].priority+' de la regla ''+data.qos_rules[i].entry_name+'' debe estar entre 1 y 255, ambos incluidos.'", //at_alert_16
	"El protocolo de la regla ''+data.qos_rules[i].entry_name+'' no puede estar en blanco.'", //at_alert_17
	"El ''+data.qos_rules[i].source_ip_start+'' del rango de IP de origen de la regla ''+data.qos_rules[i].entry_name+'' no se debe incluir en la subred de LAN ('+lan_subnet+').'", //at_alert_2
	"El ''+data.qos_rules[i].source_ip_start+'' del rango de IP de origen de la regla ''+data.qos_rules[i].entry_name+'' no es válido.'", //at_alert_18
	"El ''+data.qos_rules[i].source_ip_end+'' del rango de IP de origen de la regla ''+data.qos_rules[i].entry_name+'' no se debe incluir en la subred de LAN ('+lan_subnet+').'", //at_alert_3
	"El ''+data.qos_rules[i].source_ip_end+'' del rango de IP de origen de la regla ''+data.qos_rules[i].entry_name+'' no es válido.'", //at_alert_19
	"El rango de IP de origen de la regla ''+data.qos_rules[i].entry_name+'' no es válido.'", //at_alert_4
	"El ''+data.qos_rules[i].dest_ip_start+'' del rango de IP de destino de la regla ''+data.qos_rules[i].entry_name+'' no se debe incluir en la subred de LAN ('+lan_subnet+').'", //at_alert_5
	"El ''+data.qos_rules[i].dest_ip_start+'' del rango de IP de destino de la regla ''+data.qos_rules[i].entry_name+'' no es válido.'", //at_alert_20
	"El ''+data.qos_rules[i].dest_ip_end+'' del rango de IP de destino de la regla ''+data.qos_rules[i].entry_name+'' no se debe incluir en la subred de LAN ('+lan_subnet+').'", //at_alert_6
	"El ''+data.qos_rules[i].dest_ip_end+'' del rango de IP de destino de la regla ''+data.qos_rules[i].entry_name+'' no es válido.'", //at_alert_21
	"El rango de IP de destino de la regla ''+data.qos_rules[i].entry_name+'' no es válido.'", //at_alert_8
	"El rango de puertos de origen de la regla ''+data.qos_rules[i].entry_name+'' debe estar entre 0 y 65535, ambos incluidos.'", //at_alert_7
	"El inicio de puerto de origen para la regla ''+data.qos_rules[i].entry_name+'' debe ser inferior al final de puerto de origen.'", //at_alert_10
	"El rango de puertos de destino de la regla ''+data.qos_rules[i].entry_name+'' debe estar entre 0 y 65535, ambos incluidos.'", //at_alert_9
	"El inicio de puerto de destino para la regla ''+data.qos_rules[i].entry_name+'' debe ser inferior al final de puerto de destino.'", //at_alert_11
	"El nombre ''+data.qos_rules[i].entry_name+'' ya está en uso.'", //at_alert_22
	"El rango de IP de origen/destino para ''+data.qos_rules[j].entry_name+'' se ha superpuesto con ''+data.qos_rules[i].entry_name+''.'", //at_alert_23
	"El rango de puerto/IP de origen/destino para ''+data.qos_rules[j].entry_name+'' se ha superpuesto con ''+data.qos_rules[i].entry_name+''.'", //at_alert_24
	"El protocolo \"CUALQUIERA\" incluye ICMP, por lo que los rangos de puertos están desactivados. Seleccione TCP o UDP si desea configurar los rangos de puertos.", //at_alert_14
	"Cualquiera", //at_Prot_0
	"Rango de puerto origen.", //_srcport
	"Rango de IP destino", //at_DIPR
	"Rango de puerto destino.", //at_DPR
	"'El registro ''+ data.virtual_servers[i].entry_name + '' está duplicado.'", //av_alert_11
	"El registro ' + data.virtual_servers[j].entry_name + ' es un duplicado de ' + data.virtual_servers[i].entry_name + '.", //av_alert_21
	"Seleccione un programa para el registro ' + data.virtual_servers[i].entry_name + '.", //av_alert_24
	"La dirección IP de ' + data.virtual_servers[i].entry_name + ' debe estar incluida en la subred de LAN ('+lan_subnet+')", //av_alert_1
	"'La dirección IP para ''+ data.virtual_servers[i].entry_name + '' no está permitida'", //av_alert_2
	"'Puerto privado para ''+ data.virtual_servers[i].entry_name + '' debe estar dentro de (1..65535)'", //av_alert_3
	"'Puerto público para ''+ data.virtual_servers[i].entry_name + '' debe estar dentro de (1..65535)'", //av_alert_4
	"'El puerto público no debe ser el mismo que el puerto de gestión remota'", //av_alert_12
	"'No se puede crear una entrada para ICMP ( protoco 1 ) porque ésta impedirá que el router funcione correctamente '", //av_alert_18
	"No se puede crear una entrada para IGMP (protocolo 2) ya que esto impedirá al router funcionar correctamente", //av_alert_23
	"'Por favor escoja TCP en lugar de protocolo 6 y especifique los detalles del puerto'", //av_alert_19
	"'Por favor escoja UDP en lugar de protocolo 17 y especifique los detalles del puerto'", //av_alert_20
	"'Otro protocolo para  ''+ data.virtual_servers[i].entry_name + '' debe estar dentro de ( 2..5,7..16 o 18..255 ) '", //av_alert_13
	"'Protocolo para ''+ data.virtual_servers[i].entry_name + '' se solapa con ''+ data.virtual_servers[j].entry_name+'''", //av_alert_17
	"'Puertos para ''+ data.virtual_servers[i].entry_name + '' se solapan con ''+ data.virtual_servers[j].entry_name+'''", //av_alert_5
	"'Puerto Privado para ''+ data.virtual_servers[i].entry_name + '' está en conflicto con ''+ data.virtual_servers[j].entry_name+'''", //av_alert_6
	"FTP ALG ha sido activado", //av_alert_7
	"PPTP ALG ha sido activado", //av_alert_8
	"Wake-On-LAN ALG ha sido activado", //av_alert_9
	"H.323 ALG ha sido activado", //av_alert_10
	"Público", //_public
	"Otro", //at_Prot__1
	"Privado", //_private
	"Sitio Web", //aa_WebSite
	"https es un protocolo no admitido.", //awf_alert_4
	"La dirección del sitio web '%s' ya está en uso.", //awf_alert_5
	"Las direcciones de sitio web: '' + invalid_wf_str + ''noson válidas.", //awf_alert_7
	"'La dirección de sitio web: '' + invalid_wf_str + ''no es válida.'", //awf_alert_8
	"Asistente de conexión a internet", //int_ConWz2
	"Opciones de conexión manual a internet", //int_WlsWz
	"Si usted no conoce bien la red y nunca ha configurado un router antes, haga clic en <strong>Asistente de configuración</strong> y el router le guiará por los sencillos pasos que le permitirán tener su red a punto y funcionando.", //hhbi_wiz
	"Si usted se considera un usuario avanzado y ha configurado un router antes, haga clic en <strong> Configuración manual </strong> para entrar todos los parámetros manualmente.", //hhbi_man
	"Todavía no se han detectado clientes dinámicos.", //bd_noneyet
	"El arrendamiento se ha revocado", //bd_revoked
	"La dirección IP de la LAN no es válida", //bln_alert_3
	"La subred LAN entra en conflicto con la subred WAN", //bd_alert_10
	"'El HASTA del rango de dirección DHCP no está en la subred de la LAN.'", //bd_alert_11
	"La dirección de DHCP DE ORIGEN no contiene un valor de inicio de host válido.", //bd_alert_1
	"El intervalo de direcciones DHCP debe ir desde una dirección baja a una dirección superior, no al revés", //bd_alert_3
	"El rango de dirección DHCP no debe incluir la dirección de broadcast de subred.", //bd_alert_13
	"El número de direcciones IP en el rango excede el límite de 256.", //bd_alert_12
	"El tiempo de validez de DHCP no puede ser 0", //bd_alert_5
	"'La dirección IP reservada para esta dirección MAC ('+ae.thearray[-1].mac_addr+') ya está asignada'", //bd_alert_6
	"'La dirección IP reservada para este nombre de ordenador ('+ae.thearray[-1].comp_name+') ya está fijada'", //bd_alert_7
	"Una reserva no puede ser igual a la dirección IP de LAN configurada.", //TA20
	"'La dirección IP reservada ha de estar dentro del rango DHCP configurado'", //bd_alert_8
	"Debe especificar el servidor DNS primario antes de indicar un servidor DNS secundario", //bd_alert_22
	"Dirección IP de DNS primario no válida", //bd_alert_23
	"Dirección IP de DNS secundario no válida", //bd_alert_24
	"La dirección IP de la WAN no es válida", //_badWANIP
	"La máscara de subred de la WAN no es válida", //bwn_alert_2
	"La dirección de gateway por defecto no está en la subred de la WAN", //bwn_alert_3
	"El DNS no está configurado. Los clientes no podrán resolver los nombres de dominio. Proceed ?", //bwn_alert_4
	"La subred de la WAN entra en conflicto con la subred de la LAN", //bwn_alert_5
	"Introduzca un número de puerto de activación,", //MSG000
	"El tiempo máximo de inactividad debe estar en el intervalo 0..600", //bwn_alert_8
	"La dirección IP PPPoE no es válida", //bwn_alert_12
	"La dirección IP PPTP no es válida", //_badPPTPip
	"La máscara de subred PPTP no es válida", //_badPPTPsub
	"La dirección IP de gateway PPTP no está en la subred PPTP", //_badPPTPipsub
	"La dirección IP del servidor PPTP no es válida", //bwn_alert_11
	"Dirección de L2TP no válida", //_badL2TP3
	"La máscara de subred L2TP no es válida", //_badL2TP
	"La dirección IP de gateway L2TP no está en la subred de L2TP", //_badL2TP2
	"Dirección IP del servidor L2TP no válida", //bwn_alert_17
	"El MTU debe pertenecer al intervalo 128..30000", //bwn_alert_21
	"Las claves WEP '+ wep_error_msg + ' no son válidas.", //bws_alert_15
	"La clave WEP '+ wep_error_msg + ' no es válida.", //bws_alert_16
	"No puede utilizar el canal 802.11b/g cuando el modo 802.11 es 802.11a", //bwl_alert_2
	"No puede utilizar el canal 802.11a cuando el modo 802.11 es 802.11b/g", //bwl_alert_3
	"El campo del puerto del servidor RADIUS no puede quedar vacío", //bwl_alert_15
	"El puerto del servidor RADIUS ' + data.wireless.radius_server_port + ' debe estar dentro de (1..65535).", //bwl_alert_16
	"No se pueden utilizar velocidades de transmisión 802.11b cuando el modo PHY es 802.11a", //bwl_alert_4
	"No se pueden utilizar velocidades de transmisión 802.11a/g cuando el modo PHY es 802.11b", //bwl_alert_5
	"El modo Static Turbo no está permitido con 802.11b.", //bwl_alert_6
	"No se permite el modo turbo dinámico con 802.11b", //bwl_alert_7
	"Para el modo Turbo 11g, se debe establecer el canal en 6", //bwl_alert_8
	"Para el Turbo estático 11a, se debe establecer el canal en 42, 50, 58, 152, ó 160.", //bwl_alert_9
	"Para el Turbo dinámico 11a, se debe establecer el canal en 40, 48, 56, 153 ó 161.", //bwl_alert_10
	"Longitud incorrecta de la clave, debe tener una longitud de 8 a 64 caracteres.", //bws_alert_2
	"El intervalo de actualización de la clave de grupo WPA debe estar comprendido entre 30 y 65535 segundos.", //bwl_alert_11
	"El tiempo de espera para la autentificación IEEE 802.1X debe estar comprendido entre 1 y 65535 minutos", //bwl_alert_12
	"La clave WEP' +(i+1)+' debe tener '+len+' caracteres de longitud", //bws_alert_3
	"Anule la selección de \"Selección automática de canal\" para el modo WDS.", //aw_alert_5_1
	"'La dirección IP '' + data.wireless.radius_server_address + ''no es válida.'", //bwl_alert_13
	"' La dirección IP '' + data.wireless.second_radius_server_address + ''no es válida.'", //bwl_alert_14
	"802.11g sólo", //bwl_Mode_2
	"Mezclado 802.11g y 802.11b", //bwl_Mode_3
	"802.11b sólo", //bwl_Mode_1
	"802.11n sólo", //bwl_Mode_8
	"Mezclado 802.11ng, 802.11g y 802.11b", //bwl_Mode_11
	"20 MHz", //bwl_ht20
	"Automática a 20/40 MHz", //bwl_ht2040
	"Mejor (automático)", //bwl_TxR_0
	"Cambiar el nombre de la red inalámbrica es el primer paso para asegurar su red inalámbrica. Cámbielo por un nombre que le resulte familiar pero que no contenga información personal.", //TA9
	"Active Búsqueda automática de canal para que el router pueda seleccionar el mejor canal posible para el funcionamiento de la red inalámbrica.", //YM124
	"Configurar Estado de visibilidad en Invisible es otra forma de asegurar su red. Con la visibilidad desactivada, ningún cliente inalámbrico podrá ver su red inalámbrica al explorar para ver lo que está disponible. Para que los dispositivos inalámbricos se conecten al router, necesitará introducir manualmente el nombre de red inalámbrica en cada dispositivo.", //TA12
	"Si ha activado la seguridad inalámbrica, asegúrese de que ha anotado la frase secreta configurada.", //TA14
	"Necesitará introducir esta información en cualquier dispositivo inalámbrico que conecte a su red inalámbrica.", //TA15
	"Asistente", //_wizard
	"Ejecutar el asistente de configuración de la conexión a internet", //bwz_LConWz
	"Asistente de configuración de la seguridad inalámbrica", //bwz_WlsWz
	"El asistente de configuración basado en web está diseñado para ayudarle a configurar su red inalámbrica. Este asistente le guiará a través de las instrucciones detalladas para que configure su red inalámbrica y lo haga de una forma segura.", //bwz_intro_WlsWz
	"Ejecutar el asistente de configuración de seguridad inalámbrica", //bwz_LWlsWz
	"Aplicaciones especiales", //_specapps
	"Juegos", //_gaming
	"Básico", //_basic
	"El nombre de la regla no puede estar vacío.", //ag_alert_empty_name
	"El nombre de regla ' + data.game_rules[j].entry_name + '' está duplicado.'", //ag_alert_duplicate_name2
	"El filtro de direcciones MAC no permite ningún equipo. No está permitido porque bloquea todos los equipos.", //amaf_alert_2
	"El nombre de regla ' + saved_records[i].entry_name + '' está duplicado.'", //specapps_alert_duplicate_name
	"\"La regla '\" + saved_records[j].entry_name + \"' es un duplicado de '\" + saved_records[i].entry_name + \"'.\"", //specapps_alert_duplicate1
	"El intervalo de puertos de activación de '+saved_records[i].entry_name+'' '+protocols[saved_records[i].trigger_ports.protocol]+' ['+saved_records[i].trigger_ports.port_range+'] está en conflicto con ''+saved_records[j].entry_name+'' '+protocols[saved_records[j].trigger_ports.protocol]+' ['+saved_records[j].trigger_ports.port_range+'].'", //specapps_alert_conflict1
	"Seleccione un programa para la regla ' + data.port_trigger_rules[i].entry_name + ''.'", //specapps_alert_empty_schedule
	"Configuración de modelación del tráfico", //at_title_TSSet
	"El protocolo ' + entry_1.user_protocol + ' de ' + entry_1.entry_name + ' está en conflicto con ' + entry_2.entry_name + '", //av_alert_35
	"El campo \"Nombre\" no puede estar en blanco.", //av_alert_empty_name
	"El nombre '%s' ya está en uso", //av_alert_16
	"Debe especificarse la dirección IP del WINS primario.", //bln_alert_lannbpri
	"La dirección IP del WINS secundario no es válida.", //bln_alert_lannbsec
	"DNS primario", //lan_dns
	"DNS secundario", //lan_dns2
	"Híbrido (punto a punto y difusión)", //bln_NetBIOSReg_H
	"Modo mixto (difusión y punto a punto)", //bln_NetBIOSReg_M
	"Punto a punto (sin difusión)", //bln_NetBIOSReg_P
	"Solo difusión (usar cuando no hay servidores WINS configurados)", //bln_NetBIOSReg_B
	"Ayuda", //_help
	"Cuando se habilita esta opción, el router restringe el tráfico de salida a fin de no exceder el ancho de banda del uplink WAN.", //help81ets
	"Las opciones de filtrado de punto final de la NAT controlan cómo la NAT del router gestionar las peticiones de conexión entrante a los puertos que ya se están usando.", //af_EFT_h4
	"Una vez que una aplicación del lado LAN ha establecido una conexión a través de un puerto específico, la NAT enviará peticiones de conexión entrante con el mismo puerto a la aplicación del lado independientemente de su origen. Esta es la opción menos restrictiva, por lo que da mayor conectividad y permite que algunas aplicaciones (aplicaciones P2P en particular) se comporten casi como si estuvieran directamente conectadas a internet.", //YM134
	"La NAT envía peticiones de conexión entrante a un host del lado LAN solo cuando provienen de la misma dirección IP con la que se ha establecido la conexión. Esto permite a la aplicación remota enviar datos a través de un puerto distinto al usado cuando se creó la sesión saliente.", //af_EFT_h1
	"La NAT no envía ninguna petición de conexión entrante con la misma dirección de puerto que una conexión ya establecida.", //af_EFT_h2
	"Tenga en cuenta que algunas de estas opciones pueden interactuar con otras restricciones de puerto. El filtrado independiente del punto final tiene prioridad sobre los filtros entrantes o las programaciones; por ello, es posible, para una petición de sesión entrante relacionada con una sesión saliente, entrar a través de un puerto en vez de a través de un filtro entrante de ese puerto. No obstante, los paquetes se recharazán cuando se envíen a puerto bloqueado (ya esté bloqueado por una programación o por un filtro entrante) para el que no hay sesiones activas. El filtrado restringido de direcciones y puertos garantiza que los filtros entrantes y las programaciones funcionan con precisión, pero impide un cierto nivel de conectividad, y, por consiguiente, puede ser necesario usar puertos triggers, servidores virtuales o direccionamiento de puerto para abrir los puertos que necesita la aplicación. El filtrado restringido de direcciones lleva a una posición de equilibrio, que evita los problemas de comunicación con determinados tipos de router NAT (las NAT simétricas en particular), pero permite que los filtros entrantes y el acceso programado funcionen como se espera.", //af_EFT_h5
	"Controla el filtrado de punto final para los paquetes del protocolo UDP.", //af_UEFT_h1
	"Controla el filtrado de punto final para paquetes de protocolo TCP.", //af_TEFT_h2
	"La máscara de subred de la red de área local.", //help309A
	"NetBIOS permite a los hosts de la  LAN que descubran otros ordenadores dentro de la red; por ejemplo, dentro del vecindario de la red.", //help400_1
	"Desactive este parámetro para la configuración manual.", //help401_1
	"Los servidores WINS guardan información sobre los hosts de la red, lo que permite que los hosts que «registren» a sí mismos y descubran otros hosts disponibles; por ejemplo, para usar en el vecindario de la red.", //help402_1
	"Este parámetro no es efectivo si «Conocer información NetBIOS desde la WAN» está activado.", //help402_2
	"H-Node es un estado híbrido de funcionamiento. Primero se prueban los servidores WINS, si hay alguno, y después se difunde por la red local. Este suele ser el modo favorito si ha configurado servidores WINS .", //help405_1
	"M-Node (por defecto) es un modo mixto de funcionamiento. Primero se realiza el funcionamiento de difusión para registrar hosts y descubrir otros; si el funcionamiento de multidifusión falla, se prueban los servidores WINS, si hay alguno. Este modo favorece el funcionamiento de difusión, que puede ser preferible si los servidores WINS son rechazados por un enlace de red lento y la mayoría de servicios de red, como servidores o impresoras, son locales a la LAN.", //help405_2
	"P-Node indica que SOLO se usan servidores WINS. Este parámetro es útil para forzar el funcionamiento NetBIOS a los servidores WINS configurados. Ha de haber configurado al menos la IP del servidor WINS primario par apuntar a un servidor WINS operativo.", //help405_3
	"B-Node indica que SOLO se usa la difusión de red local. Este parámetro es útil cuando no hay servidores WINS disponibles; sin embargo, es mejor que primero pruebe el funcionamiento M-Node.", //help405_4
	" Configuración incorrecta: compruebe los registros", //_sdi_s1a
	"Puerto de gestión remota segura no válido '+data.web_server_wan_port_https+'; debe estar incluido en el rango (1..65535)", //ta_alert_3b
	"El puerto de gestión remota segura y el puerto de gestión remota no pueden coincidir.", //ta_alert_3c
	"Debe activar un método de gestión.", //ta_alert_3d
	"Puerto de gestión no válido '+data.web_server_lan_port_http+'; debe estar incluido en el rango (1..65535)", //ta_alert_3e
	"Puerto de gestión segura no válido '+data.web_server_lan_port_https+'; debe estar incluido en el rango (1..65535)", //ta_alert_3f
	"El puerto de gestión segura y el puerto de gestión no pueden coincidir.", //ta_alert_3g
	"Habilitar impresión LPD/LPR", //tps_enlpd
	"Puerto de administrador", //ta_LMAP
	"Error de inicio de sesión", //fb_FailLogin
	"No se permite acceder a este dispositivo sin una contraseña correcta.", //fb_FailLogin_1
	"Abierto", //_open
	"Otro", //_other
	"Tiempo caducado", //_223
	"La dirección de puerta de enlace no está en la subred de LAN", //_225ap
	"El formato de la dirección IP o la máscara de subred no es correcto", //_226ap
	"Esta entrada es opcional. Introduzca un nombre de dominio para la red local. Su ordenador de LAN asumirá este nombre de dominio cuando obtenga una dirección del servidor DHCP incorporado del <span>rou</span><span>ter</span>. De este modo, por ejemplo, si introduce aquí <code>mired.net</code>, y dispone de un ordenador portátil del lado de LAN con un nombre de <code>chris</code>, ese ordenador portátil se conocerá como <code>chris.mired.net</code>.", //_1044wired
	"Tenga en cuenta, sin embargo, que el nombre de dominio introducido puede reemplazarse con el que proporciona el servidor DHCP de subida del <span>rou</span><span>ter</span>.", //_1044awired
	"Dirección IPv6", //TEXT0
	"Regenerar", //regenerate
	"Servicio DNS avanzado", //_title_AdvDns
	"DNS avanzado es una opción de seguridad gratuita que proporciona \"antiphishing\" para proteger contra fraudes su conexión a Internet, así como mejoras en la navegación, como la corrección automática de errores de escritura habituales en la URL.", //_desc_AdvDns
	"Activar Servicio DNS avanzado", //ta_EUPNP_dns
	"DNS avanzado", //_st_AdvDns
	"DNS avanzado", //_sp_title_AdvDNS
	"Cuando está activada la característica, el tráfico en Internet estará protegido mediante un servidor de seguridad preparado para DNS. Esta característica proporciona \"antiphishing\" para proteger la conexión a Internet frente a fraudes, además de mejoras en la navegación, tal como la corrección automática de errores de escritura habituales en direcciones URL.", //_sp_desc1_AdvDNS
	"Nota:<br />Si se activa DNS Relay junto con la característica DNS avanzado, las estaciones de trabajo de la red que reciban una dirección IP del servidor DHCP del router obtendrán la dirección 192.168.0.1 (la dirección IP del router). No obstante, el tráfico seguirá protegido.", //_sp_desc2_AdvDNS
	"Aunque esté activada la característica DNS avanzado, la dirección IP de DNS de la estación de trabajo se podrá seguir modificando a la IP del servidor DNS que desee. Tenga en cuenta que el router no dicta la resolución de nombre DNS cuando la dirección IP de DNS se configura en la estación de trabajo.", //_sp_desc3_AdvDNS
	"Si ha seleccionado esta opción y tiene configuración de VPN o Intranet en la red, puede desactivar el servicio de DNS avanzado si tiene problemas con la conexión.", //_sp_desc4_AdvDNS
	"La clave", //TEXT041_1
	"no válido. La clave debe tener", //TEXT041_2
	" caracteres o", //TEXT041_3
	"números hexadecimales.", //TEXT041_4
	"La clave", //TEXT042_1
	"no es correcta, los caracteres permitidos son 0~9, A~F o a~f.", //TEXT042_2
	"URL no válida.", //GW_URL_INVALID
	"Alcance de NetBIOS no válido.", //GW_LAN_NETBIOS_SCOPE_INVALID
	"debe estar en el rango DHCP configurado.", //GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID_a
	"DHCP Plus", //bwn_Mode_DHCPPLUS
	"Admite Net Sniper", //net_sniper_support
	"Opciones especiales del modo de marcado", //SEL_DIAL_MODE
	"Marcado normal (predeterminado)", //pppoe_dialmode_normal
	"Marcado especial 1", //pppoe_dialmode_sp1
	"Marcado especial 2", //pppoe_dialmode_sp2
	"Marcado especial 3", //pppoe_dialmode_sp3
	"Marcado especial 4", //pppoe_dialmode_sp4
	"Marcado especial 5", //pppoe_dialmode_sp5
	"Marcado especial 6", //pppoe_dialmode_sp6
	"Modo de aprendizaje", //pppoe_dialmode_learn
	"Aprendizaje", //bt_learn_text
	"Ataque para prevenir ARP", //box_ip_mac_binding
	"Activar Servicio DNS avanzado", //_en_AdvDns
	"Admite XKJS", //xkjs_support
	"Tipo de servicio", //ddns_serv_type
	"Dominio", //ddns_domain
	"Prueba de cuenta DDNS", //ddns_account
	"Puerto público no válido", //virtual_pub_port_err
	"Puerto privado no válido", //virtual_pri_port_err
	"Número de protocolo no válido", //virtual_proto_num_err
	"Configuración protegida Wi-Fi", //menu_wps
	"Rango de IP", //tc_iprange
	"Abrir o cerrar conexiones TCP", //help823_15
	"ancho de banda (kbps)", //tc_bw
	"Programación", //tc_schedule
	"Agregar", //tc_new_sch
	"garantizar ancho de banda mínimo", //tc_min_bw
	"garantizar ancho de banda máximo", //tc_max_bw
	"Admin", //_login_admin
	"Usuario", //_login_user
	"Admite PPPoE Plus", //pppoe_plus_dail
	"Nombre de usuario DHCP+ no válido", //GW_WAN_DHCPPLUS_USERNAME_INVALID
	"Contraseña DHCP+ no válida", //GW_WAN_DHCPPLUS_PASSWORD_INVALID
	"Puerto del servidor SMTP", //te_SMTPPort
	"Modo inalámbrico", //WLANMODE
	"Modo router", //ROUTER_MODE
	"Modo AP", //AP_MODE
	"Modo WDS+Router", //WDSROUTER_MODE
	"Modo WDS+AP", //WDSAP_MODE
	"Seguridad del modo Bridge", //BR_SET
	"Modo del dispositivo", //device_mode
	"Modo router", //router_mode
	"Modo AP", //ap_mode
	"Automático", //auto_mode
	"Habilitar WDS", //enable_WDS
	"El router está detectando su tipo de conexión a Internet. Espere hasta que el router proporcione los parámetros adecuados para su configuración.", //ES_AUTODECT
	"Tipo de teléfono", //_phone
	"Si no desea conectar a Internet, haga clic en el botón siguiente.", //ES_CABLELOST_dsc2
	"No necesito conectar a Internet", //ES_DONT_CONN_btn
	"CONFIGURACIÓN DE INTERNET ACTUALIZADA", //ES_UPDATE_SETTING_bnr
	"El router está detectando su tipo de conexión a Internet e intentando conectar a Internet.                                Espere hasta que se complete la detección.", //ES_UPDATE_SETTING_dsc
	"CONFIGURAR SU CONEXIÓN A INTERNET", //ES_CONFIG_INTERNET_bnr
	"Parece que el nombre de usuario y la contraseña son incorrectas. Compruébelo de nuevo y haga clic en \"Conectar\"", //ES_CONFIG_INTERNET_dsc2
	"Conexión a internet", //ES_INTERNET_CONN_dsc
	"(* es un campo obligatorio)", //ES_MUST_FIELD_dsc
	"HA FALLADO LA MARCACIÓN", //ES_DIALUP_ERROR_bnr
	"Configure sus parámetros WWAN.  Si no está seguro de los  parámetros, póngase en contacto con su proveedor de servicios de Internet (ISP).", //usb_config1
	"Configuración sencilla", //ES_NAME
	"Introduzca el nombre de usuario", //MSG011
	"¿Qué significa esto?", //ES_what_is_this
	"Servidor DNS primario", //ES_PRI_DNS
	"Servidor DNS secundario", //ES_SEC_DNS
	"Dirección de puerta de enlace", //ES_GW_ADDR
	"SuMáscara de subred", //ES_MASK
	"Dirección IP", //ES_IP_ADDR
	"CONFIGURACIÓN SENCILLA COMPLETA", //ES_complete
	"El proceso de Configuración sencilla se ha completado correctamente. Haga clic en el botón \"Guardar\" para que los parámetros surtan efecto. Se recomienda marcar la casilla “Guardar parámetros de red” para guardar los parámetros de red en el ordenador en el caso de haya más PC que necesiten conectarse al router de forma inalámbrica.<br><br> Después de hacer clic en el botón “Guardar”, debe suministrar el nombre de usuario y la contraseña para acceder al dispositivo la próxima vez que inicie sesión.", //ES_save_dsc
	"Estado", //ES_status
	"Conectado", //ES_connected
	"Desconectado", //ES_unconnected
	"Configuración inalámbrica", //ES_wlan_setting
	"Nombre de la red inalámbrica (SSID)", //ES_wlan_ssid
	"Seguridad", //ES_security
	"No seguro", //ES_unsecured
	"Sus parámetros de seguridad inalámbrica actuales no son seguros. Se recomienda configurar los parámetros inalámbricos.", //ES_unsecured_suggest
	"Guardar mis parámetros de red", //ES_save_mySetting
	"Establezca la contraseña del dispositivo en la clave de red inalámbrica", //ES_sync_pw
	"Guardar", //ES_save
	"Clave de red", //ES_network_key
	"Generar automáticamente la clave de red", //ES_autogen_key
	"Desactivar seguridad inalámbrica (no recomendado)", //ES_disable_wifi_sec
	"WPA/WPA2 AUTOMÁTICO (recomendado)", //ES_wifi_sec_recomm
	"A continuación se muestran los parámetros de red actuales y el estado de la conexión. Si desea volver a configurar sus parámetros inalámbricos, haga clic en el botón \"Configurar\". También puede acceder a los parámetros avanzados haciendo clic en \"Configuración manual\".", //ES_current_setting_dsc
	"CONFIGURACIÓN DE RED ACTUAL", //ES_current_setting
	"Configuración manual", //ES_manual_btn
	"Cancelar", //ES_cancel
	"CERRAR SESIÓN", //logout_caption
	"Sie sind nun abgemeldet.", //logout_desc
	"Volver a la página de inicio de sesión", //logout_return
	"Tiempo de conexión", //st_connected_time
	"Denegar acceso", //t_ctl_title
	"Actualmente NO está permitido acceder a Internet. <br>¿Está seguro de que desea utilizar el acceso de emergencia a Internet?", //t_ctl_note
	"Actualmente NO está permitido acceder a Internet. Preste atención al estudio.", //t_ctl_note1
	"TRENDnet Wireless N Home Router", //page_title
	"El rango de puerto se debe establecer entre 1 y 65535.", //ac_alert_invalid_port
	"Nombre duplicado:", //ac_alert_dup_name
	"Conflicto de puerto.", //ac_alert_port_conflit
	"La política no puede ser nula.", //ac_alert_policy_null
	"Consulte la dirección de servidor configurada", //tt_alert_checkdyndns
	"El router no puede acceder a Internet con la configuración de IP estática actual.", //ES_static_no_internet
	"No se puede acceder a Internet con la configuración actual. Compruebe la configuración.", //ES_static_no_internet_desc
	"Esta ventana se cerrará. ¿Está seguro?", //_CFM_close_window
	"GUARDAR RESULTADO DE LA CONFIGURACIÓN", //ES_save_result
	"Se ha guardado la configuración.", //ES_save_success
	"Confirmar", //ES_confirm_bt
	"Formato de hora", //sch_timeformat
	"12 horas", //sch_hourfmt_12
	"24 horas", //sch_hourfmt_24
	"Este firmware es la última versión'", //no_available_update
	"Eliminar paquete de idioma", //clear_lang_pack
	"Versión actual del paquete de idioma", //current_lang_pack_version
	"Fecha del paquete de idioma actual", //current_lang_pack_date
	"Actualización del paquete de idioma", //lang_package_info
	"La actualización del paquete de idioma cambiará el idioma mostrado en el sitio web.", //lang_package_note1
	"Para actualizar el paquete de idioma, localice el archivo de actualización en el disco duro local con el botón Examinar. Una vez que ha encontrado el archivo que va a utilizar, haga clic en el botón Actualizar abajo para comenzar la actualización del paquete de idioma.", //lang_package_note2
	"Última versión del paquete de idioma", //latest_lang_package_ver
	"Última fecha del paquete de idioma", //latest_lang_package_date
	"No hay ningún paquete de idioma.", //no_lang_pack
	"El nombre de direccionamiento de puerto no puede estar vacío.", //pf_name_empty
	"El nombre del servidor virtual no puede estar vacío.", //vs_name_empty
	"Error de suma de comprobación.", //fw_checksum_err
	"ID de hardware erróneo.", //fw_bad_hwid
	"Formato de archivo desconocido.", //fw_unknow_file_format
	"Actualización de firmware correcta.", //fw_fw_upgrade_success
	"Actualización de paquete de idioma correcta.", //fw_lp_upgrade_success
	"Actualización de configuración correcta.", //fw_cfg_upgrade_success
	"Establecer control del tiempo", //ES_timectrl_bnr
	"Control del tiempo", //ES_timectrl_btn
	"Control de web", //ES_webpolicy_btn
	"Parámetros de conexión de enrutamiento Gigabit verdadera", //HW_NAT_desc
	"Habilitar regulación del tráfico", //at_ETS
	"Cuando está activada la conexión de enrutamiento Gigabit verdadera, se desactivarán automáticamente SPI y QoS. ¿Desea continuar?", //alert_hw_nat_1
	"Cuando está activado QoS, se desactivará automáticamente la conexión de enrutamiento Gigabit verdadera. ¿Desea continuar?", //alert_hw_nat_2
	"Cuando está activado SPI, se desactivará automáticamente la conexión de enrutamiento Gigabit verdadera. ¿Desea continuar?", //alert_hw_nat_3
	"Cuando está activada esta opción, se desactivará automáticamente la conexión de enrutamiento Gigabit verdadera.", //help_auto_disable_hw_nat
	" y se desactivará automáticamente la conexión de enrutamiento Gigabit verdadera.", //help_auto_disable_hw_nat_1
	"Conexión de enrutamiento Gigabit verdadera:", //help_hw_nat
	"Cuando está activada esta opción, el router aumentará la velocidad de rendimiento de NAT/enrutamiento mediante un mecanismo de aceleración de hardware. El límite es que SPI y QoS se desactivarán automáticamente cuando se active la conexión de enrutamiento Gigabit verdadera.", //help_hw_nat_desc
	"Paso 2: Configurar la seguridad Wi-Fi", //ES_step_wifi_security
	"Haga coincidir las dos contraseñas de usuario y vuelva a intentarlo.", //_pwsame_user
	"Inténtelo de nuevo", //ES_btn_try_again
	"El router está detectando el tipo de conexión a Internet, espere…", //ES_auto_detect_desc
	"Los routers no pueden detectar el tipo de conexión a Internet.", //ES_auto_detect_failed_desc
	"Guíame por los parámetros de conexión a Internet", //ES_btn_guide_me
	"Guardar y conectar", //ES_btn_save_conn
	"Guardar", //ES_btn_save
	"Enrutamiento IPv6", //v6_routing
	"Tabla de enrutamiento IPv6", //v6_routing_table
	"El menú Estado de enrutamiento muestra información sobre las rutas habilitadas en el router. En la lista se mostrará la dirección IP de destino, la dirección IP de la puerta de enlace, la máscara de subred, la métrica y la interfaz de cada ruta.", //v6_routing_info
	"Ipv6", //ipv6
	"CORTAFUEGOS DE IPv6", //ipv6_firewall
	"Número de reglas de cortafuegos restantes que se pueden configurar:", //ipv6_firewall_info
	"PARÁMETROS 6RD", //_6rd_settings
	"Dirección IPv4", //ipv4_addr
	"Longitud de la máscara", //mask_len
	"Parámetros ULA IPv6", //IPV6_ULA_TEXT01
	"Activar conexión de enrutamiento Gigabit verdadera", //HW_NAT_enable
	"Utilizar el prefijo ULA predeterminado", //IPV6_ULA_TEXT03
	"Prefijo ULA", //IPV6_ULA_TEXT04
	"Parámetros ULA IPv6 actuales", //IPV6_ULA_TEXT05
	"Prefijo ULA actual", //IPV6_ULA_TEXT06
	"ULA IPv6 de LAN", //IPV6_ULA_TEXT07
	"Dirección local única IPv6 de LAN", //IPV6_ULA_TEXT08
	"Configuración manual de la conectividad local IPv6", //IPV6_ULA_TEXT09
	"Utilice esta sección para configurar los parámetros de las direcciones únicas de unidifusión IPv6 local (ULA) del router. ULA está diseñado para las comunicaciones locales y no está previsto que sea enrutable en Internet a nivel mundial.", //IPV6_ULA_TEXT11
	"PARÁMETROS DE CONECTIVIDAD LOCAL IPv6", //IPV6_ULA_TEXT12
	"ULA resulta útil para las comunicaciones IPv6 locales; si desea activarlo, haga clic en <b>Activar ULA</b>. De manera predeterminada, ULA está desactivado.", //IPV6_ULA_TEXT13
	"PARÁMETROS DE CONECTIVIDAD LOCAL IPv6 ", //IPV6_ULA_TEXT14
	"Dirección IPv6 de LAN para las comunicaciones IPv6 locales.", //IPv6_Local_Info
	"SEGURIDAD SENCILLA IPv6", //IPv6_Simple_Security
	"Activar secuencias de multidifusión IPv6", //anet_multicast_enable_v6
	"Configurar la conexión de túnel 6rd", //IPv6_Wizard_6rd_title
	"El nombre de la regla de cortafuegos no puede estar vacío.", //fr_name_empty
	"El nombre de enrutamiento IPv6 no puede estar vacío.", //r6_name_empty
	"Asigne un nombre a la red Wi-Fi.", //wwz_wwl_intro_s2_1
	"Nombre de red Wi-Fi (SSID)", //wwz_wwl_intro_s2_1_1
	"(Utilizando un máximo de 32 caracteres)", //wwz_wwl_intro_s2_1_2
	"Asigne una contraseña a la red Wi-Fi.", //wwz_wwl_intro_s2_2
	"Contraseña de Wi-Fi", //wwz_wwl_intro_s2_2_1
	"(Entre 8 y 63 caracteres)", //wwz_wwl_intro_s2_2_2
	"Paso 3: Establecer su contraseña", //ES_title_s3
	"Paso 4: Seleccionar su zona horaria", //ES_title_s4
	"Paso 5: Guardar los parámetros", //ES_title_s5
	"802.11n sólo", //bwl_Mode_n
	"802.11a sólo", //bwl_Mode_a
	"Mezcla de 802.11n y 802.11g", //bwl_Mode_5
	"El programa de la zona de invitados debe estar dentro del programa de la WLAN principal.", //MSG049
	"Cuando se apague la WLAN principal, se desactivará la WLAN de la zona de invitados. ¿Está seguro de que desea continuar?", //MSG050
	"Error de inicialización de hardware", //HWerr
	"Almacenamiento", //storage
	"El acceso a la web SharePort permite utilizar un explorador web para acceder a los archivos almacenados en un dispositivo de almacenamiento USB conectado al router. Para utilizar esta característica, marque la casilla de verificación <strong>Activar acceso a la web SharePort</strong> y, a continuación, cree cuentas de usuario para gestionar el acceso a los dispositivos de almacenamiento o utilice la cuenta de invitado (invitado/invitado) para acceder a la carpeta Invitado. Después de enchufar una unidad de almacenamiento USB, aparecerá el nuevo dispositivo en la lista con el enlace al mismo. Podrá utilizar este enlace para conectar con la unidad e iniciar sesión con una cuenta de usuario.", //sto_into
	"ACCESO A LA WEB SHAREPORT", //sto_http_0
	"Activar Responder al ping WAN", //bwn_RPing
	"Acti", //guestzone_enable
	"Puerto de acceso HTTP", //sto_http_3
	"Habilitar el servidor HTTPS", //LV2
	"Puerto de acceso HTTPS", //sto_http_5
	"10 -- Creación de usuarios", //sto_creat
	"Añadir/Editar", //_add_edit
	"Lista de usuarios", //sto_list
	"Modificar", //_modify
	"Ruta de acceso", //sto_path
	"El rendimiento mejora características como la ráfaga de paquetes, FastFrames y la compresión .", //help361
	"Servidor NTP usado", //tt_NTPSrvU
	"Dispositivo", //sto_dev
	"Espacio total", //_total_space
	"Espacio libre", //_free_space
	"ENLACE DE ACCESO A LA WEB SHAREPORT", //sto_link_0
	"Puede utilizar este enlace para conectar a la unidad de forma remota después de iniciar sesión con una cuenta de usuario.", //sto_link_1
	"http://&lt;DDNS&gt; o&lt;Dirección IP WAN&gt;:8185", //sto_link_2
	"Enviar correo electrónico ahora", //_email_now
	"La página Almacenamiento contiene información acerca de las unidades de almacenamiento USB o las tarjetas SD enchufadas actualmente al dispositivo.", //sto_help
	"Enlace del dispositivo", //_DevLink
	"Carpeta", //_folder
	"Explorador", //_browse
	"Adjuntar", //_append
	"El puerto de acceso remoto y el puerto HTTPS remoto están vacíos.", //sto_01
	"La contraseña confirmada no coincide con la nueva contraseña de usuario.", //sto_02
	"Solo lectura", //_readonly
	"Lectura/escritura", //_readwrite
	"Adjuntar nueva carpeta", //_AppendNewFolder
	"Pulse el botón de su dispositivo inalámbrico, y haga clic en el botón Conectar que figura más abajo.", //KR45
	"Esta cuenta ha alcanzado la regla máxima", //MSG052
	"Esta regla ya existe.", //MSG053
	"No se puede encontrar esta regla, pulse el botón Adjuntar", //MSG054
	"Añadir nueva carpeta", //_AddFolder
	"http://&lt;DDNS&gt; o &lt;Dirección IP WAN&gt;", //_StorageLink
	"Desactivar el método PIN WPS ", //LW6_1
	"El número máximo de usuarios", //MSG055
	"Paso 5: Confirmar los parámetros de WI-FI", //ES_title_s5_0
	"GUARDANDO LOS PARÁMETROS", //save_settings
	"Se están guardando los parámetros.", //save_wait
	"Idioma", //_Language
	"Adelphia PowerLink", //manul_conn_01
	"ALLTEL DSL", //manul_conn_02
	"Servicio DSL de AT&T", //manul_conn_03
	"Bell Sympatico", //manul_conn_04
	"Bellsouth", //manul_conn_05
	"Charter High-Speed", //manul_conn_06
	"Comcast", //manul_conn_07
	"Covad", //manul_conn_08
	"Cox Communications", //manul_conn_09
	"Earthlink por cable", //manul_conn_10
	"Earthlink DSL", //manul_conn_11
	"FrontierNet", //manul_conn_12
	"Opinión", //_aa_bsecure_opinion
	"RCN", //manul_conn_14
	"Road Runner", //manul_conn_15
	"Rogers Yahoo!", //manul_conn_16
	"SBC Yahoo! DSL", //manul_conn_17
	"Shaw", //manul_conn_18
	"Speakeasy", //manul_conn_19
	"Sprint FastConnect", //manul_conn_20
	"Telus", //manul_conn_21
	"Time Warner Cable", //manul_conn_22
	"US West / Qwest", //manul_conn_23
	"Verizon Online DSL", //manul_conn_24
	"XO Communications", //manul_conn_25
	"Establecer manualmente el nombre de red (SSID) de la banda 5 GHz", //manul_5g_ssid
	"El paquete de idioma permite cambiar el idioma de la interfaz de usuario en el ", //tf_intro_FWU4
	" Le sugerimos que actualice su paquete de idioma actual si actualiza el firmware. Esto garantiza que todos los cambios del firmware se muestren correctamente.", //tf_intro_FWU5
	"Actualización del firmware", //_firmwareUpdate
	"Fecha", //_date
	"Eliminar", //_remove
	"Al establecer seguridad WEP, EAP, tipo de cifrado es TKIP o Estado de visibilidad es Invisible, se desactivará WPS.", //notify_wps
	"Los puertos %s [%s] están en conflicto con otra configuración", //ag_conflict5
	"Desactivar", //_disable
	"Coexistencia de HT 20 y 40 MHz ", //coexi
	"Utilice la contraseña de seguridad inalámbrica en las bandas de 2,4 GHz y de 5 GHz.", //wwl_SSP
	"Asigne un nombre y una contraseña a la red Wi-Fi.", //wwz_wwl_intro_s0
	"Esta página muestra los detalles de las conexiones a Internet IPv6 y de red.", //STATUS_IPV6_DESC_0
	"IPv6 Connetcion Información", //STATUS_IPV6_DESC_1
	"La dirección IPv6 del ordenador conectado.", //STATUS_IPV6_DESC_6
	"La dirección de enlace local IPv6 de la LAN.", //STATUS_IPV6_DESC_5
	"La dirección MAC del ordenador conectado.", //STATUS_IPV6_DESC_4
	"El tipo de conexión IPv6.", //STATUS_IPV6_DESC_3
	"El nombre del ordenador conectado.", //STATUS_IPV6_DESC_2
	"La característica QoS ayuda a mejorar el rendimiento de la red al otorgar prioridad a las aplicaciones.\" ;", //ag_conflict6
	"Reglas", //TEXT008a
	"se configura igual que Reglas", //TEXT008b
	"Aviso", //TEXT023
	"Mbps", //at_mbps
	"Formato de PIN no válido. Siga este 0000 0000 o 0000-0004", //pin_f
	"Utilizar el cifrado WEP desactivará la WPS, ¿está seguro?", //msg_eap
	"Abierto", //open
	"Introduzca otro número de puerto privado", //PRIVATE_PORT_ERROR
	"La carpeta no se puede establecer como \"/\"", //MSG056
	"Utiliza la misma cuenta y contraseña.", //MSG057
	"IP de destino", //_DestIP
	"Tipo", //_type
	"No se ha detectado Internet, ¿desea reiniciar el asistente?", //mydlink_tx03
	"Comprobando la conexión WAN.", //mydlink_tx05
	"segundos restantes.", //sec_left
	"Rellene los campos obligatorios y haga clic en \"Conectar\"", //ES_CONN_dsc
	"Confirmar contraseña", //chk_pass
	"Apellido", //Lname
	"Nombre", //Fname
	"Inicio de sesión", //_login
	"Los puertos %s [%s] están en conflicto con el puerto HTTP de acceso remoto a almacenamiento", //ag_conflict22
	"Los puertos %s [%s] están en conflicto con el puerto HTTPS de acceso remoto a almacenamiento", //ag_conflict23
	"el host inalámbrico está desactivado, no se puede activar la zona de invitados inalámbrica.", //wifi_enable_chk
	"La dirección IPv6 no puede ser cero.", //ZERO_IPV6_ADDRESS
	"El rango del puerto IPv6 no puede estar en blanco.", //port_empty
	"Desactivar", //_disable_s
	"Seleccione el tipo de conexión a Internet IPv6", //IPV6_TEXT154
	"Registrarse", //_signup
	"(GMT+07:00) Novosibirsk", //up_tz_74
	"El campo Contraseña de seguridad inalámbrica introducido no es válido.", //wifi_pass_chk
	"Eliminar(Remove)", //_remove_multi
	"¿Realmente desea reprogramar el dispositivo utilizando el archivo de idioma?", //tf_really_langf
	"Primero debe introducir el nombre de un archivo de idioma.", //tf_langf
	"Es posible que el archivo de PAQUETE DE IDIOMA descargado no sea correcto. Puede que haya descargado un archivo que no está pensado para este dispositivo o el archivo descargado puede estar dañado.", //ub_intro_l1
	"Si el archivo cargado es correcto, es posible que el dispositivo esté demasiado ocupa para recibirlo correctamente ahora. En este caso, pruebe a cargarlo de nuevo. También es posible que usted haya accedido al sistema como «usuario» en vez de como «admin»; solo los administradores pueden cargar nuevo firmware.", //ub_intro_l3
	"Lo sentimos, la página solicitada no está disponible ", //err404_title
	"No se pudo detectar una conexión a Internet.", //err404_detect
	"Sugerencias:", //err404_sug
	"Asegúrese de que el cable de Internet está conectado de forma segura al puerto de Internet del router y que el LED de Internet parpadea en verde o azul. ", //err404_sug1
	"Confirme que los", //err404_sug2
	"\"Parámetros de Internet\"", //err404_sug3
	" del router están configurados correctamente como, por ejemplo, los parámetros de nombre de usuario/contraseña de PPPoE.", //err404_sug4
	"El servidor DNS puede estar desconectado en este momento, póngase en contacto con su ISP o vuelva a intentarlo más tarde.", //err404_sug5
	"Hora final", //tsc_end_time
	"Introduzca el valor de otro puerto de administración remoto", //remote_port_msg
	"Introduzca otro nombre,", //TEXT034
	"A estas funcionalidades solo puede acceder el administrador. Los botones están deshabilitados puesto que ahora no ha entrado en el sistema como administrador.", //LW39b
	"Por favor entre un nombre de usuario y vuelva a probarlo", //_nousername
	"Introduzca otra palabra clave", //metric_empty
	"Introduzca un número de puerto TCP o un número de puerto UDP.", //TEXT061
	"Póngase en contacto con su ISP para obtener el nombre de usuario/contraseña correctos", //ES_DIALUP_ERROR_dsc
	"Introduzca un número de puerto de cortafuegos", //MSG001
	"Seleccione \"Enlace del dispositivo\"", //MSG051
	"Introduzca otro valor %s.,", //MSG012
	"Seleccione un filtro", //aa_alert_13
	"Seleccione antes un nombre de ordenador,", //TEXT044
	"Introduzca otro nombre de usuario", //sto_03
	"No ha cambiado nada en esta página. ¿Desea guardarla de todas formas?", //up_nosave
	"Por favor, entre la misma clave de acceso en ambas casillas, para confirmarla.", //ta_msg_TW
	"Si desea \"Activar el acceso a los archivos web\", debe seleccionar \"Activar acceso remoto a almacenamiento HTTP\" o \"Activar acceso remoto a almacenamiento HTTPS\".", //sto_04
	"Activar concentrador y el modo Hablar", //IPV6_TEXT167
	"Esta página muestra los detalles de enrutamiento IPv6 configurados para el router.", //IPV6_TEXT170
	"Puede crear un nombre para cada regla y controlar la dirección del tráfico. También puede permitir o denegar un rango de direcciones IP, el protocolo y un rango de puertos. Para aplicar un programa a una regla de cortafuegos, primero debe definirlo en la página <a href=\"tools_schedules.asp\"> Herramientas &rarr; Programas</a>.", //help_171
	"El nombre de host no es válido.", //DDNS_HOST_ERROR
	"No.", //_item_no
	"No se pudo montar el dispositivo USB", //_usb_not_found
	"El nombre del servidor no puede estar vacío.", //srv_name_empty
	"Utilizar el cifrado WEP desactivará la WPS, ¿está seguro?", //msg_wps_sec_01
	"Utilizar el cifrado WPA/TKIP desactivará la WPS, ¿está seguro?", //msg_wps_sec_02
	"Ocultar SSID desactivará la WPS, ¿está seguro?", //msg_wps_sec_03
	"SharePort", //sh_port_tx_00a
	"Acceso móvil/web", //sh_port_tx_00b
	"Acceso Móvil/web SharePort&trade;", //sh_port_tx_00
	"El acceso Móvil/web SharePort&trade; es un acceso compartido fácil de utilizar desde cualquier ordenador o dispositivo móvil de su red doméstica a una unidad de almacenamiento externo USB conectado al router. Le permite a usted y a otros usuarios invitados acceder a los archivos almacenados en una unidad de almacenamiento USB a través de la cuenta de usuario que ha creado.", //sh_port_tx_01
	"Puede utilizar el asistente de configuración o configurar manualmente el acceso Móvil/web SharePort&trade;.", //sh_port_tx_02
	"Asistente para la configuración de Móvil SharePort&trade;", //sh_port_tx_03
	"Si desea utilizar nuestros sencillos asistentes basados en web para que le ayuden a configurar el servicio Móvil SharePort&trade;, haga clic en el botón siguiente.", //sh_port_tx_04
	"Configuración manual de Móvil SharePort&trade;", //sh_port_tx_05
	"Si desea configurar manualmente los parámetros del servicio de acceso Móvil/web SharePort&trade;, haga clic en el botón siguiente.", //sh_port_tx_06
	"Asegúrese de la unidad de almacenamiento USB está conectada al router.", //sh_port_tx_07
	"No hay almacenamiento USB. Asegúrese de que hay un dispositivo de almacenamiento conectado al router.", //sh_port_tx_08
	"Cree una cuenta de usuario para gestionar el acceso al almacenamiento.", //sh_port_tx_09
	"Seleccione/cree una carpeta en la unidad USB para acceder al contenido.", //sh_port_tx_10
	"Rellene la información de la cuenta del DNS dinámico para activar el servicio de acceso remoto. Si no tiene una cuenta DDNS, regístrese para obtener una en:", //sh_port_ddns_01
	"Parámetros del proceso", //sh_port_ddns_02
	"Espere mientras se comprueba el enlace de acceso a la web…", //sh_port_ddns_03
	"la configuración ha finalizado. Ahora puede utilizar el enlace siguiente para acceder a la unidad de almacenamiento USB a través de la cuenta de usuario que aparece a continuación.", //sh_port_tx_11
	"Acceso local", //sh_port_tx_12
	"Acceso remoto", //sh_port_tx_13
	"o bien", //sh_port_tx_16
	"<a href=\"http://FQDN:8181\">http://FQDN:8181</a>", //sh_port_tx_17
	"Los enlaces anteriores se activarán al guardar los parámetros y después de reiniciar el dispositivo.", //sh_port_tx_18
	"Nombre de usuario o clave", //sh_port_tx_19
	"Contraseña o clave", //sh_port_tx_20
	"Seleccionar", //sh_port_tx_21
	"El campo Nombre de cuenta no puede estar vacío.", //sh_port_msg_01
	"El campo Contraseña de cuenta no puede estar vacío.", //sh_port_msg_02
	"Las dos entradas de contraseña no coinciden.", //sh_port_msg_04
	"Seleccione una carpeta para la cuenta de usuario.", //sh_port_msg_05
	"El campo Nombre de host no puede estar vacío.", //sh_port_msg_06
	"El campo Nombre de usuario no puede estar vacío.", //sh_port_msg_07
	"El campo Contraseña no puede estar vacío.", //sh_port_msg_08
	"El DNS dinámico no puede establecer una conexión.", //sh_port_msg_09
	"Permitir acceso remoto", //sto_http_6
	"¿Está seguro de que desea eliminar este usuario?", //file_acc_del_user
	"¿Está seguro de que desea eliminar esta ruta?", //file_acc_del_path
	"¿Está seguro de que desea eliminar este archivo?", //file_acc_del_file
	"Vuelva a iniciar la sesión", //_login_a
	"DNS DINÁMICO PARA HOSTS CON IPv6", //IPv6_ddns_01
	"LISTA DE DNS DINÁMICOS DE IPv6", //IPv6_ddns_02
	"Configure a continuación el cortafuegos de IPv6:", //IPv6_fw_01
	"Desactivar el cortafuegos de IPv6", //IPv6_fw_02
	"Activar el cortafuegos de IPv6 y permitir las reglas enumeradas", //IPv6_fw_03
	"Activar el cortafuegos de IPv6 y denegar las reglas enumeradas", //IPv6_fw_04
	"Rango de direcciones IP", //IPv6_fw_ipr
	"Rango de puertos", //IPv6_fw_pr
	"Origen", //IPv6_fw_sr
	"Destino", //IPv6_fw_dest
	"El relé 6rd no puede estar vacío.", //IPv6_6rd_relay
	"Cambie en primer lugar el protocolo de WAN IPv4 al modo DHCP.", //IPv6_6rd_wan
	"El relé 6 a 4 no puede estar vacío.", //IPv6_6to4_relay
	"Rango de dirección (inicio)", //IPv6_addrSr
	"Rango de dirección (final)", //IPv6_addrEr
	"Al utilizar Solo WPA se desactivará la WPS, ¿está seguro?", //msg_wps_sec_04
	"Espere %d segundos.", //msg_wait_sec
	"Seleccione un archivo para eliminar", //file_acc_del_empty
	"Cambie en primer lugar el protocolo de wan IPv6", //IPV6_TEXT161a
	"Estadísticas inalámbricas 2.4GHZ", //ss_Wstats_2
	"Estadísticas inalámbricas 5GHZ", //ss_Wstats_5g
	"Servidor multimedia", //dlna_t
	"Activar servidor multimedia", //dlna_01
	"Nombre del servidor multimedia", //dlna_02
	"El nombre de servidor multimedia asignado no es válido", //dlna_03
	"PPTP para Rusia (acceso dual)", //rus_wan_pptp
	"PPTP para Rusia (acceso dual)", //rus_wan_pptp_01
	"L2TP para Rusia (acceso dual)", //rus_wan_l2tp
	"L2TP para Rusia (acceso dual)", //rus_wan_l2tp_01
	"PPPoE para Rusia (acceso dual)", //rus_wan_pppoe
	"PPPoE para Rusia (acceso dual)", //rus_wan_pppoe_02
	"Configuración de Wan física", //rus_wan_pppoe_03
	"Utilizar el cifrado WPA-Enterprise desactivará la WPS, ¿está seguro?", //msg_wps_sec_05
	"Inicio de sesión de acceso a archivos web", //webf_login
	"Inicie sesión en el servidor de acceso a archivos web", //webf_intro
	"Acceso a la web SharePort", //webf_title
	"Nueva carpeta", //webf_folder
	"Disco duro de mi dispositivo de acceso", //webf_hd
	"Crear carpeta", //webf_createfd
	"Introduzca un nombre de carpeta", //webf_fd_name
	"Cargar archivo", //webf_upload
	"Seleccione un archivo", //webf_file_sel
	"Si activa el uso compartido de contenido multimedia con los dispositivos, cualquier ordenador o dispositivo de la red podría reproducir la música, las imágenes y los vídeos compartidos.", //dlna_t1
	"<strong>NOTA:</strong> el contenido multimedia compartido puede no ser seguro. Solo se recomienda permitir su transmisión por parte de cualquier dispositivo en redes seguras.", //dlna_t2
	"Permitirá acceder a los archivos de un disco duro externo o miniatura de la unidad USB que esté enchufado al %m desde la red local o desde Internet, utilizando un explorador web o la aplicación Móvil SharePort<sup>TM</sup> del teléfono inteligente o la tableta. Puede crear usuarios para personalizar los derechos de acceso a los archivos en la unidad USB. Después de hacer los cambios, haga clic en el botón <strong>Guardar parámetros</strong>.", //help_stor1
	"Marque esta casilla de selección para permitir compartir los archivos almacenados en la unidad de almacenamiento USB conectada al %m.", //help_stor2
	"Introduzca un puerto que desee utilizar para el acceso web HTTP a los archivos (8181 es el valor predeterminado). Deberá añadir este puerto a la dirección IP del %m al conectar. Por ejemplo: http://192.168.0.1:8181", //help_stor3
	"Introduzca un puerto que desee utilizar para el acceso seguro HTTP a los archivos (4433 es el valor predeterminado). Deberá añadir este puerto a la dirección IP del %m al conectar. Por ejemplo: https://192.168.0.1:4433", //help_stor4
	"Márquelo para activar el acceso remoto al almacenamiento del router.", //help_stor5
	"Creación de usuarios", //help_stor6
	"Para crear un nuevo usuario, introduzca un nombre de usuario. Para editar un usuario existente, utilice la casilla desplegable de la derecha.", //help_stor7
	"Introduzca una contraseña que desee utilizar para la cuenta, vuelva a introducir la contraseña en el cuadro de texto <strong>Verificar contraseña</strong> y, a continuación, haga clic en <strong>Añadir/Editar</strong> para guardar los cambios.", //help_stor8
	"Esta sección muestra las cuentas de usuario existentes. De forma predeterminada, existen cuentas de <strong>administrador</strong> y de <strong>invitado</strong>.", //help_stor9
	"Esta característica permite compartir música, imágenes y vídeos con todos los dispositivos conectados a la red. Después de hacer los cambios, haga clic en el botón <strong>Guardar parámetros</strong>.", //help_dlna1
	"No se ha insertado ningún dispositivo de almacenamiento USB.", //webf_non_hd
	"Error de detección de DDNS!", //sh_port_tx_22
	"Error en el enlace de DDNS, inténtelo de nuevo y compruebe la información de la cuenta o haga clic en Siguiente para guardar los parámetros de DDNS de todas formas.", //sh_port_tx_23
	"Activar filtrado de entrada de IPv6", //IPv6_Ingress_Filtering_enable
	"Música", //share_title_1
	"Foto", //share_title_2
	"Película", //share_title_3
	"Documento", //share_title_4
	"Buscar canciones...", //share_ser_1
	"Buscar fotos...", //share_ser_2
	"Buscar película...", //share_ser_3
	"Buscar documentos...", //share_ser_4
	"Desconectando", //ddns_disconnecting
	"IP de reserva", //lan_reserveIP
	"Dirección IP final'", //end_ip
	"NINGUNA", //_NULL
	"dyndns.com (personalizado)", //ddns_sel2
	"dyndns.com (gratuito)", //ddns_sel3
	"Dirección IP remota", //_remoteipaddr
	"Atrás", //_back
	"Ha fallado el ping %s.", //_ping_fail
	"El ping %s se ha realizado correctamente.", //_ping_success
	"La función WPS está establecida actualmente en desactivar. Haga clic en \"Sí\" para activarla o en \"No\" para salir del asistente.", //_wz_disWPS
	"La contraseña de la cuenta debe tener más de seis caracteres", //limit_pass_msg
	"When WPS is enabled, security mode can not set WEP, EAP,and WPA only, or cipher type can not set TKIP.", //_gz_wps_enable
	"When security mode is WEP, EAP, ciphter type is TKIP, or WPA only, WPS can not be enabled.", //_gz_wps_deny
	"Automática a 20/40/80 MHz", //bwl_ht204080
	"Cerrado", //_supp_close
	"802.11ac sólo", //bwl_Mode_ac
	"Mezcla de 802.11ac y 802.11n", //bwl_Mode_acn
	"Mezclado 802.11acg, 802.11n y 802.11a", //bwl_Mode_acna
	"Inalámbrico 2.4GHz", //_wireless_2
	"Inalámbrico 5GHz", //_wireless_5
	"WPS", //_WPS
	"Lista de Emisoras", //_statlst
	"Wireless Security Setting", //_wifiser_title
	"Selecciona SSID", //_wifiser_title0
	"Selecciona SSID", //_wifiser_title1
	"WEP-OPEN", //_wifiser_mode0
	"WEP-SHARED", //_wifiser_mode1
	"WEP-AUTO", //_wifiser_mode2
	"WPA-PSK", //_wifiser_mode3
	"WPA2-PSK", //_wifiser_mode4
	"WPA2-PSK mixto", //_wifiser_mode5
	"WPA2", //_wifiser_mode6
	"WPA2-Empresa mixto", //_wifiser_mode7
	"Tipo de Encriptado", //_wifiser_mode8
	"If you choose WPA/WPA2-TKIP encryption, the wireless mode should be Non-HT 11n mode. This means you will NOT get high throughput performance due to the fact that is not supported by 11N specification.", //_wifiser_mode9
	"Clave predeterminada", //_wifiser_mode10
	"La clave", //_wifiser_mode11
	"HEXADECIMAL", //_wifiser_mode12
	"Cifra de WPA", //_wifiser_mode13
	"Intervalo de actualización de clave", //_wifiser_mode14
	"Período Cache PMK", //_wifiser_mode15
	"Pre-Autentificación", //_wifiser_mode16
	"802.1x WEP", //_wifiser_mode17
	"Servidor RADIUS", //_wifiser_mode18
	"Secreto compartido", //_wifiser_mode19
	"Tiempo de espera de la sesión", //_wifiser_mode20
	"Tiempo muerto de inactividad", //_wifiser_mode21
	"Filtro MAC de wireless", //_wifiser_mode22
	"Modo Filtro:", //_wifiser_mode23
	"Rechazar", //_wifiser_mode24
	"La dirección MAC no es válida.", //_wifiser_mode25
	"No es posible agregar más de 24 entradas en la lista de filtros MAC.", //_wifiser_mode26
	"Introduce una clave válida para el intervalo de renovación.", //_wifiser_mode27
	"El valor del intervalo para renovar clave debe ser mayor o igual a 60.", //_wifiser_mode28
	"Introduce una clave válida para el Período Cache PMK.", //_wifiser_mode29
	"Indique los 10 o 26 caracteres de la clave WEP", //_wifiser_mode30
	"Indique los 5 o 13 caracteres de la clave WEP", //_wifiser_mode31
	"Introduce la clave WEP", //_wifiser_mode32
	"Introduce el Período Cache PMK.", //_wifiser_mode33
	"Introduce menos de 63 caracteres ASCII para la Clave WPA-PSK!", //_wifiser_mode34
	"Introduce por lo menos 8 caracteres ASCII para la Clave WPA-PSK!", //_wifiser_mode35
	"Indique los 64 caracteres hexadecimales de la clave WPA-PSK", //_wifiser_mode36
	"Introduzca la clave de wpa-psk", //_wifiser_mode37
	"Si desea habilitar multi SSID y desea que la seguridad funcione correctamente, no olvide reiniciar el dispositivo cuando cambie cualquier opción.", //_wifiser_mode38
	"¿Está seguro de que no desea tener en cuenta los cambios?", //_wifiser_mode39
	"Lista de filtros MAC", //_wifiser_mode40
	"La Radio de Red wireless está APAGADA.", //_wifiser_mode41
	"Habilita Norma", //_adv_txt_00
	"Nombre de reglas", //_adv_txt_01
	"Nombre de la regla: %s indicado(a) no válido(a).", //_adv_txt_02
	"El Servidor Virtual puede definir un puerto público único para redireccionar hacia una IP y puerto internos.", //_adv_txt_03
	"Agrega un Servidor Virtual", //_adv_txt_04
	"Lista de Servidor Virtual", //_adv_txt_05
	"Juegos", //_adv_txt_06
	"That can open multiple ports or a range of ports in your router.", //_adv_txt_07
	"The formats including Single Port (ex: 80), Port Ranges (ex: 50-60).), Individual Ports (80, 68, 888), or Mixed (1020-5000, 689).", //_adv_txt_08
	"Add Port Range Rule", //_adv_txt_09
	"Port Range Rule List", //_adv_txt_10
	"Puertos TCP/UDP", //_adv_txt_11
	"Activador de Puerto", //_adv_txt_12
	"Port trigger is a way to automate port forwarding in which outbound traffic on predetermined ports ('triggering ports') causes inbound traffic to specific incoming ports to be dynamically forwarded to the initiating host, while the outbound ports are in use.", //_adv_txt_13
	"Please assign the port with below format:<br>1. Single Port (ex: 80)<br>2. Port Ranges (ex: 50-60)", //_adv_txt_14
	"Función de Activador de Puerto", //_adv_txt_15
	"Agrega Norma para Activar Puerto", //_adv_txt_16
	"Aplicar", //_adv_txt_17
	"Activación de Puertos", //_adv_txt_18
	"Lista de reglas", //_adv_txt_19
	"Coincidencia de Protocolo", //_adv_txt_20
	"Coincidencia de Puertos", //_adv_txt_21
	"Protocolo/Puertos", //_adv_txt_22
	"Red", //_network
	"Gestión", //_management
	"Carga el Firmware", //_upload_firm
	"Manejo de Ajustes", //_settings_management
	"Tiempo", //_time_cap
	"Registros del sistema", //_system_log
	"Estado de IPv6", //_ipv6_status
	"ALG", //_alg
	"Parámetros WAN", //_wan_setting
	"Parámetros de LAN", //_lan_setting
	"Parámetros de IPv6", //_ipv6_setting
	"arriba", //_top
	"Ayuda para la Red", //_network_help
	"Parámetros de calidad de servicio (QoS)", //_qos_help
	"Ayuda de wireless.", //_wireless_help
	"Ayuda del Administrador", //_administrator_help
	"Tipo de Conexión WAN", //_wan_conn_type
	"There are several connection types to choose from: Static IP, DHCP, PPPoE, PPTP, L2TP, and Russia PPTP. If you are unsure of your connection method, please contact your Internet Service Provider.", //_help_txt2
	"ESTÁTICO", //_static
	"Menú Ayuda", //_help_txt1
	"Your ISP provides a set IP address that does not change. The IP information is manually entered in your IP configuration settings. You must enter the IP address, Subnet Mask, Gateway, Primary DNS Server, and Secondary DNS Server. Your ISP provides you with all of this information.", //_help_txt4
	"A method of connection where the ISP assigns your IP address when your router requests one from the ISP's server.", //_help_txt6
	"<b>Host Name:</b> Some ISP's may check your computer's Host Name. The Host Name identifies your system to the ISP's server.", //_help_txt7
	"Select this option if your ISP requires you to use a PPPoE (Point to Point Protocol over Ethernet) connection. DSL providers typically use this option. This method of connection requires you to enter a <b>Username</b> and <b>Password</b> (provided by your Internet Service Provider) to gain access to the Internet.", //_help_txt9
	"<b>Modo de reconexión: </b>Las conexiones de PPPoE no siempre están activas. El router le permite establecer el modo de reconexión. Los parámetros son", //_help_txt10
	"<b>Siempre activado: </b>Siempre se está conectado a internet", //_help_txt11
	"<b>A petición: </b>Cuando se necesita, se establece la conexión a internet", //_help_txt12
	"<b>Manual: </b>Ha de abrir la interfaz de gestión basada en web y hacer clic sobre el botón Conectar cada vez que desee conectarse a internet.", //_help_txt13
	"<b>Tiempo máximo de inactividad: </b>Tiempo de inactividad máximo Intervalo de tiempo en el que el equipo puede estar inactivo antes de que se desconecte la conexión PPPoE. El valor de Tiempo de inactividad máximo sólo se utiliza para los modos \"A petición\" y \"Manual\" para volver a conectar.", //_help_txt14
	"L2TP (Layer Two Tunneling Protocol) usa una red privada virtual para conectar con el ISP. Este método de conexión requiere que usted introduzca un Nombre de usuario y una Clave de acceso (proporcionados por su proveedor de servicios internet) para obtener el acceso a internet.", //_help_txt16
	"<b>Dirección IP del servidor L2TP: </b>El ISP proporciona este parámetro, si es necesario. El valor puede ser igual que la dirección IP de gateway.", //_help_txt17
	"<b>Modo de reconexión: </b>Las conexiones de PPPoE no siempre están activas. El router le permite establecer el modo de reconexión. Los parámetros son", //_help_txt18
	"<b>Siempre activado: </b>Siempre se está conectado a internet", //_help_txt19
	"<b>A petición: </b>Cuando se necesita, se establece la conexión a internet", //_help_txt20
	"<b>Manual: </b>Ha de abrir la interfaz de gestión basada en web y hacer clic sobre el botón Conectar cada vez que desee conectarse a internet.", //_help_txt21
	"<b>Tiempo máximo de inactividad: </b>Tiempo de inactividad máximo Intervalo de tiempo en el que el equipo puede estar inactivo antes de que se desconecte la conexión PPPoE. El valor de Tiempo de inactividad máximo sólo se utiliza para los modos \"A petición\" y \"Manual\" para volver a conectar.", //_help_txt22
	"<b>Static:</b> If your ISP has assigned a fixed IP address, select this option. The ISP provides the values for the following fields for <b>WAN Interface IP Setting: IP Address, Subnet Mask , Default Gateway.</b>", //_help_txt24
	"<b>Dynamic:</b> If the ISP's servers assign the router's IP addressing upon establishing a connection, select this option.", //_help_txt25
	"PPTP (Point to Point Tunneling Protocol) usa una red privada virtual para conectarse a su ISP. Este método de conexión se usa, sobre todo, en Europa. Este método de conexión requiere que usted introduzca un Nombre de usuario</b> y una Clave de acceso</b> (proporcionados por su proveedor de servicios internet) para obtener el acceso a internet", //_help_txt27
	"<b>Dirección IP de servidor PPTP: </b>El ISP proporciona este parámetro, si es necesario. El valor puede ser igual que la dirección IP de gateway.", //_help_txt28
	"<b>Modo de reconexión: </b>Las conexiones de PPPoE no siempre están activas. El router le permite establecer el modo de reconexión. Los parámetros son", //_help_txt29
	"<b>Siempre activado: </b>Siempre se está conectado a internet", //_help_txt30
	"<b>A petición: </b>Cuando se necesita, se establece la conexión a internet", //_help_txt31
	"<b>Manual: </b>Ha de abrir la interfaz de gestión basada en web y hacer clic sobre el botón Conectar cada vez que desee conectarse a internet.", //_help_txt32
	"<b>Tiempo máximo de inactividad: </b>Tiempo de inactividad máximo Intervalo de tiempo en el que el equipo puede estar inactivo antes de que se desconecte la conexión PPPoE. El valor de Tiempo de inactividad máximo sólo se utiliza para los modos \"A petición\" y \"Manual\" para volver a conectar.", //_help_txt33
	"WAN Interface IP Type", //_help_txt34
	"<b>Static:</b> If your ISP has assigned a fixed IP address, select this option. The ISP provides the values for the following fields for <b>WAN Interface IP Setting: IP Address, Subnet Mask , Default Gateway</b>, and optional for <b>DNS Server</b>", //_help_txt35
	"<b>Dynamic:</b> If the ISP's servers assign the router's IP addressing upon establishing a connection, select this option.", //_help_txt36
	"WAN MTU Setting", //_help_txt37
	"The Maximum Transmission Unit (MTU) is a parameter that determines the largest packet size (in bytes) that the router will send to the WAN. If LAN devices send larger packets, the router will break them into smaller packets. Ideally, you should set this to match the MTU of the connection to your ISP. Typical values are 1500 bytes for an Ethernet connection and 1492 bytes for a PPPoE connection. If the router's MTU is set too high, packets will be fragmented downstream. If the router's MTU is set too low, the router will fragment packets unnecessarily and in extreme cases may be unable to establish some connections. In either case, network performance can suffer. t modes.", //_help_txt38
	"LAN Interface Setting", //_help_txt39
	"The IP address of the this device on the local area network. Assign any unused IP address in the range of IP addresses available for the LAN. For example, 192.168.10.101.", //_help_txt41
	"The subnet mask of the local area network.", //_help_txt43
	"DHCP stands for Dynamic Host Configuration Protocol. The DHCP section is where you configure the built-in DHCP Server to assign IP addresses to the computers and other devices on your local area network (LAN).", //_help_txt45
	"Once your router is properly configured and this option is enabled, the DHCP Server will manage the IP addresses and other network configuration information for computers and other devices connected to your Local Area Network. There is no need for you to do this yourself.", //_help_txt47
	"The computers (and other devices) connected to your LAN also need to have their TCP/IP configuration set to \"DHCP\" or \"Obtain an IP address automatically\". When you set <b>Enable DHCP Server</b>, the following options are displayed.", //_help_txt48
	"These two IP values (Start and End) define a range of IP addresses that the DHCP Server uses when assigning addresses to computers and devices on your Local Area Network. TAny addresses that are outside of this range are not managed by the DHCP Server; these could, therefore, be used for manually configured devices or devices that cannot use DHCP to obtain network address details automatically.", //_help_txt50
	"It is possible for a computer or device that is manually configured to have an address that does reside within this range. In this case the address should be reserved, so that the DHCP Server knows that this specific address can only be used by a specific computer or device.", //_help_txt51
	"Your router, by default, has a static IP address of 192.168.10.1. This means that addresses 192.168.10.2 to 192.168.10.254 can be made available for allocation by the DHCP Server.", //_help_txt52
	"The subnet mask of the local area network.", //_help_txt54
	"The IP address of the router on the local area network. For example, 192.168.10.1.", //_help_txt56
	"The amount of time that a computer may have an IP address before it is required to renew the lease. The lease functions just as a lease on an apartment would. The initial lease designates the amount of time before the lease expires. If the tenant wishes to retain the address when the lease is expired then a new lease is established. If the lease expires and the address is no longer needed than another tenant may use the address.", //_help_txt58
	"Añadir/modificar reserva de DHCP", //_help_txt59
	"This option lets you reserve IP addresses, and assign the same IP address to the network device with the specified MAC address any time it requests an IP address. This is almost the same as when a device has a static IP address except that the device must still request an IP address from the router. The router will provide the device the same IP address every time. DHCP Reservations are helpful for server computers on the local network that are hosting applications such as Web and FTP. Servers on your network should either use a static IP address or use this option.", //_help_txt60
	"You can assign a name for each computer that is given a reserved IP address. This may help you keep track of which computers are assigned this way. Example: <b>Game Server</b>.", //_help_txt62
	"La dirección LAN que quiere reser", //_help_txt64
	"To input the MAC address of your system, enter it in manually or connect to the router's Web-Management interface from the system and click the <b>Copy Your PC's MAC Address</b> button.", //_help_txt66
	"A MAC address is usually located on a sticker on the bottom of a network device. The MAC address is comprised of twelve digits. Each pair of hexadecimal digits are usually separated by dashes or colons such as 00-0D-88-11-22-33 or 00:0D:88:11:22:33. If your network device is a computer and the network card is already located inside the computer, you can connect to the router from the computer and click the <b>Copy Your PC's MAC Address</b> button to enter the MAC address.", //_help_txt67
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt69
	"This shows clients that you have specified to reserve DHCP addresses. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit DHCP Reservation\" section is activated for editing.", //_help_txt71
	"En esta sección puede ver los dispositivos de la LAN que actualmente tienen direcciones IP asignadas de forma temporal.", //_help_txt73
	"IPv6 can be configured with the following connection types: Stateless DHCPv6, Stateful DHCPv6, Link-Local, Static, PPPoE, 6to4 , IPv6 in IPv4 Tunnel, and 6rd (IPv6 Rapid Deployment).  Please consult with your local ISP (Internet Service Provider) to obtain information in regard to the IPv6 connection type.  Note: In order to avoid any software conflict, please be sure to remove or disable any PPPoE client software on your computer when using the PPPoE connection type.", //_help_txt85
	"Please select this connection type if your ISP provides you with a set of IPv6 static addresses.  Configuration settings, such as IPv6 address, Default Gateway, Primary DNS Server, and Secondary DNS Server, and Subnet Prefix Length are required and will be entered manually.  Please contact your local ISP for all relevant information.", //_help_txt87
	"Sin estado DHCPv6", //_help_txt82
	" Nodes on an IPv6 network can use the ICMPv6 and DHCPv6 server to obtain configuration information such as a list of DNS recursive name servers.  A Stateless DHCPv6 mode does not maintain any dynamic state for individual clients.", //_help_txt83
	"DHCPv6 (Con estado)", //_help_txt84
	"Hosts from DHCPv6 servers to obtain IP addresses and other configuration information.  Dynamic state information about each individual client is stored and centrally managed on the DHCPv6 server.", //_help_txt85
	"6to4 is provided as a transition for migrating from IPv4 to IPv6.  It allows IPv6 packets to be transmitted over an IPv4 network through the automatic tunneling technology, and routes traffic between 6to4 and IPv6 networks.", //_help_txt89
	"6in4", //_help_txt90
	"IPv6 in IPv4 tunneling has the capability to encapsulate IPv6 packets within IPv4 packets for transmission over an IPv4 infrastructure.", //_help_txt91
	"It is a mechanism used to facilitate IPv6 rapid deployment across current IPv4 infrastructures.", //_help_txt93
	"IPv6 DNS Server Setting", //_help_txt94
	"Enter the IPv6 addresses of the DNS Servers provided by your ISP.", //_help_txt95
	"LAN IPv6 IP Setting", //_help_txt96
	"The following settings will be applied to the LAN (Local Area Network) IPv6 interface.  You ISP will assign an IPv6 address and subnet (prefix /64 will be supported in LAN) to be configured in the LAN IPv6 Address Configuration section of this device.", //_help_txt97
	"Parámetros de la configuración automática de la dirección de LAN", //_help_txt98
	"Set up IPv6 Autoconfiguration in this section in order to have IPv6 addresses assigned to the clients on the local area network.", //_help_txt99
	"<b>Stateless Auto:</b> When connected to an IPv6 network utilizing ICMPv6 (Internet Control Message Protocol version 6) router discovery messages, IPv6 hosts will be configured automatically.", //_help_txt100
	"<b>Stateless DHCPv6:</b> A stateless DHCP server will only provide configuration information to the nodes and will rely on ICMPv6 (Internet Control Message Protocol version 6) router discovery messages to assign IPv6 addresses.", //_help_txt101
	"<b>DHCPv6(Stateful):</b> Dynamic Host Configuration Protocol for IPv6.  Stateless address autoconfiguration for IPv6 can be used to acquire access in an IPv6 network, however, it is generally recommended to use DHCPv6 instead to assign addresses, name servers and other configuration information to the clients.", //_help_txt102
	"<b>IPv6 Address Range (DHCPv6):</b> This device will manage IPv6 addresses and other configuration information for all clients connected to it as soon as it is properly configured with this option enabled.  However, users may also opt to use manual IPv6 configuration if they prefer as long as the address does not reside within the range specified here.", //_help_txt103
	"<b>IPv6 Address Lifetime:</b> The time duration in which a client is required to release and renew its IPv6 address.", //_help_txt104
	"Quality of Service Settings", //_help_txt105
	"QoS Setup", //_help_txt106
	"There are several Maximum upload bandwidth to choose or user defined.", //_help_txt107
	"QoS Group", //_help_txt108
	"There are several group of QoS rate and ceil upload bandwidth to setup.", //_help_txt109
	"Sólo Link-local", //_help_txt110
	"Los nodos y routers utilizan la dirección de enlace local al comunicarse con nodos próximos en el mismo enlace. Este modo permite a los dispositivos preparados para IPv6 comunicarse entre sí en el lado de la LAN.", //_help_txt111
	"Select this option if your ISP requires you to use a PPPoE (Point to Point Protocol over Ethernet) connection to IPv6 Internet. DSL providers typically use this option. This method of connection requires you to enter a <b>Username</b> and <b>Password</b> (provided by your Internet Service Provider) to gain access to the IPv6 Internet. ", //_help_txt113
	"<b>Auto:</b>Select this option if the ISP's servers assign the router's WAN IPv6 address upon establishing a connection.", //_help_txt114
	"<b>Static:</b>If your ISP has assigned a fixed IPv6 address, select this option. The ISP provides the value for the IPv6 Address.", //_help_txt115
	"Lista QoS", //_help_txt116
	"Sie können QoS für unterschiedliche Protokollanwendungen einrichten.", //_help_txt117
	"Encendido/Apagado de Radio:", //_help_txt121
	"This indicates the wireless operating status. The wireless can be turned on or off by the slide switch. When the radio is on, the following parameters are in effect.", //_help_txt122
	"If all of the wireless devices you want to connect with this router can connect in the same transmission mode, you can improve performance slightly by choosing the appropriate wireless mode. If you have some devices that use a different transmission mode, choose the appropriate wireless mode. ", //_help_txt123
	"There are many different configuration options available to choose from. Use the drop down list to select the wireless mode.", //_help_txt124
	"Note: One wireless mode can be selected can select at any one time. This means that you can only select one of the operating frequency at a time.", //_help_txt125
	"Opciones de Modo wireless", //_help_txt126
	"<b>2.4GHz 802.11b/g mixed mode</b> - This wireless mode works in the 2.4GHz frequency range and will allow both wireless b and wireless g client to connect and access the %m at 11Mbps for wireless b, at 54Mbps for wireless g and share access at the same time. Although the wireless b/g operates in the 2.4GHz frequency, it will allow the use of other 2.4GHz client devices (Wireless n/g @ 54Mbps) to connect and access at the same time.", //_help_txt127
	"<b>2.4GHz 802.11 n only</b> ??This wireless mode works in the 2.4GHz frequency range and will only allow the use of wireless n client devices to connect and access the %m. Although the wireless n operates in the 2.4GHz frequency, this mode will only permit wireless n client devices to work and will exclude any other wireless mode and devices that are not wireless n only.", //_help_txt128
	"<b>5GHz 802.11a only mode</b> - This wireless mode works in the 5GHz frequency range and will allow wireless a client to connect and access the %m at 54Mbps for wireless a only mode. Although the wireless a operates in the 5GHz frequency, this mode will only permit wireless a client devices to work and will exclude any other wireless mode and devices that are not wireless a only.", //_help_txt129
	"<b>5GHz 802.11a/n mixed mode</b> - This wireless mode works in the 5GHz frequency range and will only allow the use of wireless a/n dual band client devices to connect and access the %m*. Dual band wireless client devices that support both wireless a/n can connect and access the %m. Wireless a client devices can connect and access the %m but, will only connect up to 54Mbps, (this due to the legacy limitation of wireless a technology for that standard). Although the wireless a/n operate in the same 5GHz frequency, this mode will only permit wireless a/n client devices to work and will exclude any other wireless mode and devices that are not wireless a/n. (note: wireless b/g/n will not be able to connect at the same time to the %m with 5GHz wireless a/n mode enable).", //_help_txt130
	"<b>2.4 GHz 802.11b/g/n mixed mode</b> - This wireless mode works in the 2.4GHz frequency range and will only allow the use of wireless g client devices to connect and access the %m at 11Mbps for wireless b, 54Mbps for wireless g and up to 150Mbps* for wireless n and share access at the same time. Although the wireless b/g/n operates in the same 2.4GHz frequency, it will allow the use of other 2.4GHz client devices (Wireless b/g/n) to connect and access at the same time.", //_help_txt131
	"*Maximum wireless signal rates are referenced from IEEE 802.11 theoretical specifications. Actual data throughput and coverage will vary depending on interference, network traffic, building materials and other conditions.", //_help_txt132
	"When you are browsing for available wireless networks, this is the name that will appear in the list (unless Visibility Status is set to Invisible, see below). This name is also referred to as the SSID. For security purposes, it is highly recommended to change from the pre-configured network name. Add up to three additional SSIDs to create virtual wireless networks from one wireless Router Access Point device.", //_help_txt133
	"Agrega un Nombre de Red wireless Adicional (SSID)", //_help_txt134
	"To add additional wireless Network Names simply add the name to the Multiple SSID field and click on apply at the bottom of the page. When finished, go to the Security section in this Users Guide for wireless security configuration.", //_help_txt135
	"Frecuencia (Canal)", //_help_txt136
	"Una red wireless utiliza canales específicos en el espectro wireless para controlar la comunicación entre los clientes. Algunos canales de su zona puede tener interferencias de otros dispositivos electrónicos. Elija el canal más claro para ayudar a optimizar el rendimiento y la cobertura de su red wireless.", //_help_txt137
	"Sistema de Distribución de wireless (WDS)", //_help_txt138
	"When WDS is enabled, this access point functions as a wireless repeater and is able to wirelessly communicate with other APs via WDS links. A WDS link is bidirectional; so this AP must know the MAC Address (creates the WDS link) of the other AP, and the other AP must have a WDS link back to this AP. Each WDS APs need setting as same channel, encryption type. (Note that WDS security is incompatible with mixed mode, like WPAPSK+WPA2PSK mixed, WEP AUTO and 802.1x, both feature cannot be used at the same time).", //_help_txt139
	"Configurando WDS con", //_help_txt140
	"Enable the option for WDS and input the MAC Address of the wireless device that also supports WDS in to the blank fields. You can add up to four additional devices in the spaces provided. Click on apply at the bottom of the page, to apply your setting changes. Enable the security seeing in security page, each WDS APs need to use same security setting. (Note: WDS supports wireless g/n modes. The use multiple Access Point will reduces the overall network throughput to ½ the %m", //_help_txt141
	"When WDS is enabled, this access point functions as a wireless repeater and is able to wirelessly communicate with other APs via WDS links. A WDS link is bidirectional, so this AP must know the MAC Address (creates the WDS link) of the other AP, and the other AP must have a WDS link back to this AP. Make sure the APs are configured with same channel number, encryption type. (Note that WDS security is incompatible with mixed mode, like WPAPSK+WPA2PSK mixed, WEP AUTO and 802.1x, both feature cannot be used at the same time).", //_help_txt142
	"Input the MAC Address of the wireless device that also supports WDS link in to the blank fields. The other AP must also have the MAC address of this AP to create the WDS link back to this AP. Enter a MAC address for each of the other APs that you want to connect with WDS.", //_help_txt143
	"Modo Físico HT", //_help_txt144
	"En el modo físico HT (Alto Rendimiento), la configuración permite el control del entorno wireless 802.11n.", //_help_txt145
	"Modo de funcionamiento", //_help_txt146
	"Modo mixto", //_help_txt147
	"Green Field", //_help_txt148
	"In this mode packets are transmitted with a preamble compatible with the legacy 802.11a/g, the rest of the packet has a new format. In this mode the receiver shall be able to decode both the Mixed Mode packets and legacy packets.", //_help_txt149
	"In this mode high throughput packets are transmitted without a legacy compatible part.", //_help_txt150
	"Anchura de canal", //_help_txt151
	"Ajusta el ancho de canal de la radio wireless.", //_help_txt152
	"20 Ancho de Canal = 20 MHz", //_help_txt153
	"20/40 Ancho de Canal = 20/40 MHz", //_help_txt154
	"Intervalo de protección", //_help_txt155
	"Compatible con GI Corto/Largo. El objetivo del intervalo de guardia es brindar inmunidad a las demoras en propagación, ecos y reflejos, a los que los datos digitales son normalmente muy sensibles.", //_help_txt156
	"Largo", //_help_txt157
	"Intervalo de protección prolongada, 800 nsec", //_help_txt158
	"Intervalo de protección breve, 400 nsec", //_help_txt159
	"MCS", //_help_txt160
	"Die MCS Rate durch die HT Rate ersetzen.<br/>0-15<br/>Das Modulations- und Codeschema (MCS) ist ein Wert, der die Modulation, den Code und die Anzahl der dreidimensionalen Kanäle bestimmt.", //_help_txt161
	"Intervalo de emisión de señales", //_help_txt162
	"Beacons son paquetes que envía un router wireless para sincronizar dispositivos wireless. Especifique un valor de beacon period entre 20 y 1000. El valor por defecto es 100 milisegundos.", //_help_txt163
	"DTIM", //_help_txt164
	"Un DTIM es una cuenta atrás que advierte a los clientes de la siguiente ventana para que estén atentos a los mensajes de emisión y multidifusión. Cuando el router inalámbrico ha almacenado los mensajes de emisión y multidifusión, envía el siguiente DTIM con un valor de intervalo DTIM. Los clientes inalámbricos detectan las balizas y están a punto para recibir los mensajes de emisión y multidifusión. El valor por defecto es 1. Los parámetros válidos están comprendidos entre 1 y 255.", //_help_txt165
	"Umbral de fragmentación", //_help_txt166
	"Wireless frames can be divided into smaller units (fragments) to improve performance in the presence of RF interference and at the limits of RF coverage. Fragmentation will occur when frame size in bytes is greater than the Fragmentation Threshold. This setting should remain at its default value of 2346 bytes. Setting the Fragmentation value too low may result in poor performance.", //_help_txt167
	"When an excessive number of wireless packet collisions are occurring, wireless performance can be improved by using the RTS/CTS (Request to Send/Clear to Send) handshake protocol. The wireless transmitter will begin to send RTS frames (and wait for CTS) when data frame size in bytes is greater than the RTS Threshold. This setting should remain at its default value of 2346 bytes.", //_help_txt168
	"Preámbulo Corto y Franja", //_help_txt169
	"La utilización de un intervalo de protección corto (400 ns) puede mejorar el rendimiento. No obstante, también puede aumentar la tasa de errores en algunas instalaciones, debido a la mayor sensibilidad a las reflexiones de radiofrecuencia. Seleccione la o", //_help_txt170
	"TX Burst", //_help_txt171
	"Permite que el Ruteador wireless tenga un mejor rendimiento en el mismo período y en el mismo ambiente, de manera de aumentar la velocidad.", //_help_txt172
	"Pkt_Agregado", //_help_txt173
	"Increase efficiency by aggregating multiple packets of application data into a single transmission frame. In this way, 802.11n networks can send multiple data packets with the fixed overhead cost of just a single frame.", //_help_txt174
	"A menos que uno de estos modos de encriptación es seleccionada, las transmisiones inalámbricas desde y hacia la red inalámbrica puede ser fácilmente interceptado e interpretado por usuarios no autorizados.", //_help_txt175
	"Un método de encriptación de datos para la comunicación inalámbrica destinada a proporcionar el mismo nivel de privacidad como una red cableada. WEP no es tan seguro como el cifrado WPA. Para obtener acceso a una red WEP, debe conocer la clave. La clave es una cadena de caracteres que usted crea. Al utilizar WEP, debe determinar el nivel de cifrado. El tipo de cifrado determina la longitud de la clave. 128-bit de encriptación requiere una clave más larga que 64-bit de encriptación. Las claves se definen mediante la introducción de una serie en formato HEX (hexadecimal - el uso de caracteres 0-9, AF) o ASCII (Código Estándar Americano para Intercambio de Información - caracteres alfanuméricos) . Formato ASCII se proporciona para que pueda escribir una cadena que es más fácil de recordar. La cadena ASCII se convierte a HEX para su uso en la red. Cuatro claves pueden ser definidos de modo que usted puede cambiar las claves con facilidad. Una clave predeterminada se selecciona para su uso en la red.", //_help_txt176
	"Both of these options select some variant of Wi-Fi Protected Access (WPA) -- security standards published by the Wi-Fi Alliance. The WPA Mode further refines the variant that the router should employ.", //_help_txt177
	"WPA Mode: WPA is the older standard; select this option if the clients that will be used with the router only support the older standard. WPA2 is the newer implementation of the stronger IEEE 802.11i security standard. With the \"WPA2\" option, the router tries WPA2 first, but falls back to WPA if the client only supports WPA. With the \"WPA2 Only\" option, the router associates only with clients that also support WPA2 security.", //_help_txt178
	"Cipher Type: The encryption algorithm used to secure the data communication. TKIP (Temporal Key Integrity Protocol) provides per-packet key generation and is based on WEP. AES (Advanced Encryption Standard) is a very secure block based encryption. With the \"TKIP and AES\" option, the router negotiates the cipher type with the client, and uses AES when available.", //_help_txt179
	"<b>Intervalo de actualización de la clave de grupo:</b> Tiempo que transcurre antes de que se cambie la clave de grupo usada para la difusión y multidifusión de datos.", //_help_txt180
	"Esta opción utiliza Wi-Fi Protected Access con una clave pre-compartida (PSK).", //_help_txt181
	"Pre-Shared Key: La clave es una frase secreta de hasta 63 caracteres alfanuméricos en formato ASCII (American Standard Code for Information Interchange) a ambos extremos de la conexión inalámbrica. No puede ser inferior a ocho caracteres, aunque para más seguridad es necesario que tenga más caracteres y no debe ser una frase conocida. Esta frase se usada para generar claves de sesión que son únicas para cada cliente inalámbrico.", //_help_txt182
	"Esta opción funciona con un servidor RADIUS para autentificar clientes inalámbricos. Los clientes inalámbricos deben haber establecido las credenciales necesarias antes de intentar autentificar al servidor a través de este gateway. Además, puede ser necesario, para configurar el servidor RADIUS, permitir estea gateway  para autentificar usuarios.", //_help_txt183
	"Tiempo de espera para la autentificaciónT: iempo que transcurre antes de que se le pida a un cliente que se vuelva a autentificar.", //_help_txt184
	"Dirección IP del servidor RADIUS: La dirección IP del servidor de autenticación.", //_help_txt185
	"Puerto del servidor RADIUS: El número de puerto utilizado para conectarse al servidor de autenticación.", //_help_txt186
	"Secreto compartido del servidor RADIUS: Frase secreta que debe coincidir con el servidor de autentificación.", //_help_txt187
	"Wireless MAC Filtering", //_help_txt188
	"Choose the type of MAC filtering needed.", //_help_txt189
	"<b>Turn MAC Filtering Disable:</b> When \"Disable\" is selected, MAC addresses are not used to control network access.", //_help_txt190
	"Add MAC Filtering Rule", //_help_txt191
	"Use this section to add MAC addresses to the list below.", //_help_txt192
	"Enter the MAC address of a computer that you want to control with MAC filtering. Computers that have obtained an IP address from the router's DHCP server will be in the DHCP Client List. Select a device from the drop down menu.", //_help_txt193
	"Enable the WPS feature.", //_help_txt194
	"Locking the wireless security settings prevents the settings from being changed by any new external registrar using its PIN. Devices can still be added to the wireless network using WPS.", //_help_txt195
	"Un PIN es un número que se puede usar para añadir el router a una red existente o para crear una red. El PIN por defecto suele figurar en la parte superior del router. Para mayor seguridad, se puede generar un nuevo PIN. En cualquier momento, puede restaurar el PIN por defecto. Solo el administrador (cuenta «admin») puede cambiar o restablecer el PIN.", //_help_txt196
	"Muestra el valor actual del PIN del router.", //_help_txt197
	"Reset To WPS Default", //_help_txt198
	"Restaurar el PIN por defecto del router.", //_help_txt199
	"Cree un número aleatorio que sea un PIN válido. Este número será el PIN del router, que luego podrá copiar en el interfaz de usuario de registro.", //_help_txt200
	"You could monitor stations which associated to this AP here.", //_help_txt201
	"Enter a password for the user \"admin\", who will have full access to the Web-based management interface. ", //_help_txt202
	"The name of the router can be changed here. ", //_help_txt203
	"Habilite esta opción sólo si usted ha comprado su propio nombre de dominio y lo ha registrado con un proveedor de servicios de DNS dinámico. Los parámetros siguientes se muestran si la opción está habilitada.", //_help_txt204
	"Dynamic DNS Provider", //_help_txt205
	"Seleccione un proveedor de servicio DNS dinámico en la lista desplegable, o introduzca manualmente un proveedor de servicio DNS dinámico.", //_help_txt206
	"Entre su nombre de host completo; por ejemplo: <b>myhost.mydomain.net</b>.", //_help_txt207
	"Account", //_help_txt208
	"Enter the account provided by your service provider. If the Dynamic DNS provider supplies only a key, enter that key in all three fields. ", //_help_txt209
	"Enter the password provided by your service provider. If the Dynamic DNS provider supplies only a key, enter that key in all three fields. ", //_help_txt210
	"Una vez que disponga de la actualización del firmware en su ordenador, use esta opción para buscar el archivo y cargue la información en el router", //_help_txt211
	"Exporta Configuraciones", //_help_txt212
	"Esta opción te permite exportar y luego guardar la configuración del ruteador en un archivo en tu computadora. Asegúrate de guardar la configuración antes de realizar una actualización de firmware.", //_help_txt213
	"Configuraciones de Importación", //_help_txt214
	"Use esta opción para restaurar los parámetros de configuración del router previamente guardados.", //_help_txt215
	"Restablecer las configuraciones por defecto originales", //_help_txt216
	"This option restores all configuration settings back to the settings that were in effect at the time the router was shipped from the factory. Any settings that have not been saved will be lost. If you want to save your router configuration settings, use the<b> Export Settings</b> option above. ", //_help_txt217
	"Reinicio del Sistema", //_help_txt218
	"Esta opción reinicia el router. Resulta útil para reiniciar cuando no está cerca del dispositivo.", //_help_txt219
	"Muestra la hora actual del router. Si no es correcta, use las opciones siguientes para configurar la hora correctamente.", //_help_txt220
	"Seleccione su zona horaria en el menú desplegable", //_help_txt221
	"Selecciona esta opción si quieres sincronizar el reloj del ruteador con un Servidor de Tiempo de Red en la Internet. Si estás usando planificaciones o logs, esta es la mejor forma de asegurar que dichas planificaciones y logs se conserven con precisión. Observa que, aún cuando el Servidor NTP esté habilitado, deberás elegir una zona horaria y definir los parámetros del horario de verano.", //_help_txt222
	"Seleccione un servidor de hora de red para la sincronización. Usted puede escribir la dirección de un servidor de tiempo o seleccionar uno de la lista. Si tiene problemas para usar un servidor, pruebe con otro.", //_help_txt223
	"Si no está instalada la opción en el Servidor NTP, puedes configurar manualmente la hora en tu ruteador en este punto.", //_help_txt224
	"Esta sección muestra la información de estado de los dispositivos.", //_help_txt225
	"Parámetros de DMZ", //_help_txt226
	"DMZ es la sigla de Demilitarized Zone, zona desmilitarizada. Si una aplicación tiene problemas al ejecutarse detrás del router, puede exponer un ordenador en internet y ejecutar la aplicación en ese ordenador.", //_help_txt227
	"Cuando un host de la LAN está configurado como un host DMZ, se convierte en el destino para todos los paquetes entrantes que no coinciden con cualquier otra sesión o regla entrante. Si cualquiera otra regla entrante está en el lugar apropiado, se usará esta en lugar de enviar paquetes al host DMZ; por lo tanto, una sesión activa, un servidor virtual, un puerto trigger o una regla de direccionamiento de puerto tendrá prioridad al enviar un paquete al host DMZ. (La política de DMZ se parece a una regla de direccionamiento de puerto por defecto que direcciona cada puerto que no está específicamente enviado a ninguna otra parte.)", //_help_txt228
	"El router sólo proporciona protección de firewall o al host DMZ. El router no direcciona un paquete TCP que no coincide con una sesión DMZ activa, a menos que sea un paquete de establecimiento de conexión(SYN). Excepto por esta protección limitada, el host DMZ está efectivamente 'fuera del firewall '. Quien quiera usar un host DMZ debe tener en cuenta que, para disponer dde mayor protección, deberá disponer de un firewall en ese sistema de host DMZ.", //_help_txt229
	"Los paquetes recibidos por el host DMZ han traducido sus direcciones IP: de la dirección IP del router del lado WAN a la dirección IP del host DMZ del lado LAN. Sin embargo, los números de puerto no se traducen; así que las aplicaciones del host DMZ pueden depender de números de puerto específicos.", //_help_txt230
	"La capacidad de DMZ es una de las maneras de permitir solicitudes entrantes que pueden parecer no solicitadas a la NAT. Por lo general, el host DMZ debería usarse sólo si no hay otra alternativa, porque está mucho más expuesto a los ciberataques que ningún otro sistema de la LAN. Se pueden usar otras configuraciones: un servidor virtual, una regla de direccionamiento de puerto, o un puerto trigger. Los servidores virtuales abren un puerto para sesiones entrantes con destino a una aplicación específica (y también permiten el redireccionamiento de y el uso de ALG). El direccionamiento de puerto es más bien como un DMZ selectivo, en el que el tráfico entrante etiquetado en uno o más puertos es dirigido hacia un host específico de la LAN (sin exponer tales puertos como un host DMZ). El puerto trigger es una forma especial de direccionamiento de puerto, que es activado por el tráfico saliente, y para los puertos que solo se direccionan si el trigger está activo.", //_help_txt231
	"Pocas aplicaciones verdaderamente requieren el uso del host DMZ. Los siguientes ejemplos muestran cuándo podría requerirse un host DMZ.", //_help_txt232
	"‧ Un host necesita soportar", //_help_txt233
	"‧ Para administrar conexiones entrantes que usan un protocolo distinto a ICMP, TCP, UDP, y IGMP (tambi n GRE y ESP, cuando estos protocolos son habilitados por los ALG PPTP y IPSec).", //_help_txt234
	"Al poner un ordenador en la DMZ puede exponer a dicho ordenador a", //_help_txt235
	"Define la dirección IP de la LAN de la computadora en la que quieres tener comunicación irrestricta con Internet.", //_help_txt236
	"Agrega/Edita un Servidor Virtual", //_help_txt237
	"Define si la entrada estará activa o inactiva.", //_help_txt238
	"Assign a meaningful name to the virtual server, for example <b>Web Server</b>. Several well-known types of virtual server are available from the \"Application Name\" drop-down list. Selecting one of these entries fills some of the remaining parameters with standard values for that type of server.", //_help_txt239
	"La dirección IP del sistema en su red interna que proporcionará el servicio virtual, por ejemplo <b>192.168.0.50</b>.Usted puede escoger una computadora de la lista de clientes DHCP en el menú desplegable 'Nombre de ordenador'o puede entrar manualmente la dirección de IP del ordenador servidor.", //_help_txt240
	"Seleccione el protocolo utilizado por el servicio. Las opciones comunes, UDP, TCP y ambas, se pueden seleccionar desde un menú desplegable. Para especificar cualquier otro protocolo, seleccione \"Otros\" de la lista e introduzca a continuación el número de protocolo correspondiente ( según lo asignado por el IANA) en el cuadro <b>Protocolo</b>.", //_help_txt241
	"El puerto que se utilizará en su red interna.", //_help_txt242
	"El puerto al que se va acceder desde Internet.", //_help_txt243
	"Seleccione una programación para habilitar el servicio. Si no ve la programación que necesita en la lista de programaciones.", //_help_txt244
	"Reinicia esta área de la pantalla, descartando cualquier cambio que hayas hecho", //_help_txt245
	"Agrega/Edita Ruta", //_help_txt246
	"Agrega una nueva ruta a la tabla de rutas de IP o edita una ruta ya existente.", //_help_txt247
	"La dirección IP de los paquetes que han tomado está ruta.", //_help_txt248
	"Especifica el próximo salto que se ha de realizar si se usa esta ruta. Un gateway de 0.0.0.0 implica que no hay próximo salto, y la dirección IP que coincide es directamente conectada al router de la interfaz especificada: LAN o WAN.", //_help_txt249
	"La métrica de ruta es un valor comprendido entre 1 y 16 que indica el coste de usar esa ruta. Un valor de 1 es el coste más bajo, y 15 es el coste más alto. Un valor de 16 indica que el router no puede llegar a esa ruta. Al intentar llegar a un destino determinado, los ordenadores de la red seleccionan la mejor ruta e ignoran las que no son realizables.", //_help_txt250
	"Especifique la interfaz LAN o WAN que debe usar el paquete IP para salir del router, cuando se usa la ruta.", //_help_txt251
	"Reinicia esta área de la pantalla, descartando cualquier cambio que hayas hecho", //_help_txt252
	"The section shows the current routing table entries. Certain required routes are predefined and cannot be changed. Routes that you add can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Route\" section is activated for editing. Click the Enable checkbox at the left to directly activate or de-activate the entry.", //_help_txt253
	"Por defecto, la característica de control de acceso está deshabilitada. Si usted necesita control de acceso, marque esta opción.", //_help_txt254
	"<b>Nota:</b>Cuando el control de acceso está deshabilitado, cada dispositivo de la LAN tiene acceso ilimitado a internet. Sin embargo, si habilita el control de acceso, el acceso a internet queda restringido para aquellos dispositivos que tienen una política de control de acceso configurada. Todos los otros dispositivos tienen acceso ilimitado a internet.", //_help_txt255
	"By default, the ALG feature is enabled. ALG configuration allows users to disable some application service.", //_help_txt256
	"Add/Edit Port Trigger Rule", //_help_txt257
	"Specifies whether the entry will be active or inactive.", //_help_txt258
	"Enter a name for the Special Application Rule, for example <b>Game App</b>, which will help you identify the rule in the future. Alternatively, you can select from the <b>Application</b> list of common applications.", //_help_txt259
	"Select the protocol used by the service. The common choices -- UDP, TCP, and both UDP and TCP -- can be selected from the drop-down menu.", //_help_txt260
	"Enter the outgoing port range used by your application (for example <b>6500-6700</b>).", //_help_txt261
	"Select a schedule for when this rule is in effect.", //_help_txt262
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt263
	"This is a list of the defined application rules. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon.", //_help_txt264
	"Add/Edit Port Range Rule", //_help_txt265
	"Use this section to add a Port Range Rule to the following list or to edit a rule already in the list.", //_help_txt266
	"Specifies whether the entry will be active or inactive.", //_help_txt267
	"Give the rule a name that is meaningful to you, for example <b>Game Server</b>. You can also select from a list of popular games, and many of the remaining configuration values will be filled in accordingly. However, you should check whether the port values have changed since this list was created, and you must fill in the IP address field.", //_help_txt268
	"Enter the local network IP address of the system hosting the server, for example <b>192.168.10.50</b>. You can select a computer from the list of DHCP clients in the \"Computer Name\" drop-down menu, or you can manually enter the IP address of the server computer.", //_help_txt269
	"Puertos TCP a abrir", //_help_txt270
	"Introduzca los puertos TCP que se deben abrir (por ejemplo, <b>6159-6180, 99</b>).", //_help_txt271
	"Puertos UDP a abrir", //_help_txt272
	"Introduzca los puertos UDP que se deben abrir (por ejemplo, <b>6159-6180, 99</b>).", //_help_txt273
	"Seleccione un filtro que controle el acceso según lo establecido por esta regla.", //_help_txt274
	"Seleccione un programa para los instantes en que esté vigente esta regla.", //_help_txt275
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt276
	"This is a list of the defined Port Range Rules. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Port Forwarding Rule\" section is activated for editing.", //_help_txt277
	"Añadir/actualizar regla de filtro entrante", //_help_txt278
	"Aquí puede añadir entradas a la lista de reglas de filtro entrante que figura abajo", //_help_txt279
	"Indique un nombre para esta regla que signifique algo para usted.", //_help_txt280
	"La regla puede Permitir o Denegar mensajes.", //_help_txt281
	"Define the ranges of Internet addresses this rule applies to. For a single IP address, enter the same address in both the <b>Start</b> and <b>End</b> boxes. Up to eight ranges can be entered. The <b>Enable</b> checkbox allows you to turn on or off specific entries in the list of ranges.", //_help_txt282
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt283
	"The section lists the current Inbound Filter Rules. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Inbound Filter Rule\" section is activated for editing.", //_help_txt284
	"Además de los filtros que figuran en la lista, se dispone de dos filtros predefinidos que pueden aplicarse donde hay filtros entrantes:", //_help_txt285
	"Permitir a cualquier usuario WAN el acceso a la capacidad relacionada.", //_help_txt286
	"Impide a todos los usuarios de la WAN el acceso a dicha capacidad. (Los usuarios de la LAN no se ven afectados por las reglas de filtro entrante.)", //_help_txt287
	"Agregar/editar regla de programación", //_help_txt288
	"En esta sección puede añadir entradas a la lista de reglas de programación que figura abajo o modificar las entradas existentes.", //_help_txt289
	"Asigne un nombre a la programación que signifique algo para usted, como “regla semanal”.", //_help_txt290
	"Seleccione las casillas de verificación de los días que desee o, si quiere seleccionar los siete días de la semana, marque el botón de radio Toda la semana.", //_help_txt291
	"Seleccione esta opción si desea que se aplique esta programación todo el día durante el/los día(s) seleccionado(s)", //_help_txt292
	"Si no utiliza la opción Todo el día, indique aquí la hora. La hora de inicio se escribe en dos campos. El primer cuadro es para la hora y el segundo para los minutos. Los eventos de correo electrónico se desencadenan normalmente con la hora de inicio.", //_help_txt293
	"La hora de finalización se indica en el mismo formato que la hora de inicio. La hora se introduce en el primer cuadro y los minutos en el segundo. La hora de finalización se utiliza para la mayoría de las reglas, pero normalmente no se utiliza para los eventos de correo electrónico.", //_help_txt294
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt295
	"Esta sección muestra las reglas de programa definidas actualmente. Se puede cambiar una regla de programa haciendo clic en el icono Editar o borrarla haciendo clic en el icono Borrar. Al hacer clic en el icono Editar, se resalta el elemento y se activa la", //_help_txt296
	"By default, the UPnP feature is enabled. Universal Plug and Play (UPnP) is a set of networking protocols for primarily residential networks without enterprise class devices that permits networked devices, such as personal computers, printers, Internet gateways, Wi-Fi access points and mobile devices to seamlessly discover each other's presence on the network and establish functional network services for data sharing, communications, and entertainment.", //_help_txt297
	"By default, the WAN Ping Respond feature is disabled. Enable WAN Ping Respond will reply information of router to outside network.", //_help_txt298
	"The Inbound Filter controlling data received from the Internet. In this feature you can configure inbound data filtering rules that control data based on an IP address.", //_adv_txt_23
	"Añadir regla de filtro de entrada", //_adv_txt_24
	"Acciona la Norma", //_adv_txt_25
	"El nombre de %s: %s ya se encuentra en la lista", //_adv_txt_26
	"Lista de filtros de entrada", //_adv_txt_27
	"Parámetros de IPv6", //_net_ipv6_01
	"Esta sección le permite configurar sus opciones de conexión a Internet IPv6 y opciones LAN IPv6. Si no está seguro de sus opciones de conexión a Internet IPv6, póngase en contacto con su proveedor de servicios de Internet.", //_net_ipv6_02
	"Configuración IP de IPv6 de WAN", //_net_ipv6_03
	"Configuración automática sin estado", //_net_ipv6_04
	"Largo de Prefijo LAN.", //_net_ipv6_05
	"IPv6-to-IPv4-Einstellungen", //_net_ipv6_06
	"IPv6 a Dirección IPv4", //_net_ipv6_07
	"Configuración de PPPoE", //_net_ipv6_08
	"Usa los Ajustes MTU Predeterminados", //_net_ipv6_09
	"Configuración de MTU", //_net_ipv6_10
	"Configura DNS manualmente", //_net_ipv6_11
	"ESTÁTICO", //_net_ipv6_12
	"Configuraciones de Calidad del Servicio", //_qos_txt00
	"You may setup rules to provide Quality of Service guarantees for specific applications.", //_qos_txt01
	"Configuración QoS", //_qos_txt02
	"Calidad de servicio", //_qos_txt03
	"Ancho de banda de subida", //_qos_txt04
	"Usuario definido", //_qos_txt05
	"Bits por segundo", //_qos_txt06
	"Ancho de Banda de Descarga", //_qos_txt07
	"Carga Predeterminado", //_qos_txt08
	"El valor de ancho de banda de carga es demasiado pequeño, estás seguro?", //_qos_txt09
	"El valor de ancho de banda de carga es demasiado grande.", //_qos_txt10
	"Máximo ancho de banda de carga", //_qos_txt11
	"El formato de ancho de banda de carta no es correcto. (ej. \"10k\" \"20M\")", //_qos_txt12
	"Indique el ancho de banda para la carga.", //_qos_txt13
	"Puerto Src:", //_qos_txt14
	"Rango de Puerto Src:", //_qos_txt15
	"Categoría", //_qos_txt16
	"información", //_qos_txt17
	"Prio", //_qos_txt18
	"Carga : %s% como mínimo", //_qos_txt19
	"Atributo", //_qos_txt20
	"Grupo", //_qos_txt21
	"Configuración", //_qos_txt22
	"Avanzado", //_qos_txt23
	"Opciones de clasificador básicas", //_qos_txt24
	"Dirección IP final de destino", //_qos_txt25
	"Dirección IP de Origen", //_qos_txt26
	"longitud del paquete", //_qos_txt27
	"Ej.: 0-128 para paquetes pequeños", //_qos_txt28
	"DSCP", //_qos_txt29
	"Rango de Puerto de Destino", //_qos_txt30
	"Rango de Puerto Src:", //_qos_txt31
	"Señala DSCP como:", //_qos_txt32
	"Seleccione una aplicación.", //_qos_txt33
	"El rango de puerto de origen no es válido.", //_qos_txt34
	"Indique el número de puerto.", //_qos_txt35
	"El formato de la dirección MAC no es válido.", //_qos_txt36
	"Hay un caracter no válido en el nombre.", //_qos_txt37
	"Ingresa un nombre.", //_qos_txt38
	"Opciones avanzadas del clasificador", //_qos_txt39
	"El rango de puerto de destino no es válido.", //_qos_txt40
	"El rango de longitud de paquete no es válido.", //_qos_txt41
	"La longitud del paquete es muy pequeña.", //_qos_txt42
	"La longitud del paquete es muy grande.", //_qos_txt43
	"La longitud del paquete debe ser un número entero.", //_qos_txt44
	"Ingresa un rango para la longitud de paquete. (ej. 0-128 64-1024)", //_qos_txt45
	"Ingresa las clasificaciones.", //_qos_txt46
	"Configuraciones Básicas de wireless", //_basic_wireless_settings
	"Esta sección le permite configurar las opciones básicas requeridas para su red wireless, como el nombre de su red wireless (SSID) y su clave Wi-Fi.", //_desc_basic
	"Esta sección le permite hacer un seguimiento de los dispositivos cliente wireless que estén conectados a su router.", //_desc_station_list
	"Esta sección le permite activar WPS (configuración Wi-Fi protegida), lo cual le permite conectar fácilmente dispositivos cliente wireless compatibles con WPS a su router. El router ofrece tres maneras de conectar dispositivos cliente wireless mediante WPS: El botón de arranque (situado físicamente en el router), el botón de arranque virtual (PBC) o el PIN. WPS no se puede utilizar si está desactivada la función SSID Broadcast.", //_desc_wps
	"RED wireless", //_wireless_network
	"Sistema de Distribución de wireless (WDS)", //_wds_long
	"Configura WPS", //_wps_config
	"Resumen de WPS", //_wps_summary
	"Acción WPS", //_wps_action
	"Clientes DHCP", //_dhcp_clients
	"Please click Wireless Client Card and Router's WPS button in 120 seconds to complete this setting.", //_desc_wps_action
	"Encendido/Apagado de Radio:", //_lb_radio_onoff
	"Programación para Radio Apagada", //_lb_radio_off_sche
	"Nombre de la red wireless (SSID)", //_wmode_ssid
	"SSID1 múltiple", //_lb_multi_ssid_1
	"SSID2 múltiple", //_lb_multi_ssid_2
	"SSID3 múltiple", //_lb_multi_ssid_3
	"SSID4 múltiple", //_lb_multi_ssid_4
	"SSID5 múltiple", //_lb_multi_ssid_5
	"SSID6 múltiple", //_lb_multi_ssid_6
	"SSID7 múltiple", //_lb_multi_ssid_7
	"Nombre de la Red de Difusión (SSID):", //_lb_broadcast_ssid
	"Modo Phy", //_lb_phy_mode
	"Tipo de Encriptado", //_lb_enc_type
	"Verschlüsselungscode", //_lb_enc_key
	"Dirección MAC de AP Remota", //_lb_apmacaddr
	"Coexistencia HT20/40", //_lb_coexistence
	"Transferir en Dirección Contraria (RDG)", //_lb_rdg
	"MCS", //_lb_mcs
	"Canal de Extensión", //_lb_exten_channel
	"agregación MSDU(A-MSDU)", //_lb_a_msdu
	"Bloquear automáticamente ACK", //_lb_autoba
	"Rechazar solicitud BA", //_lb_declineba
	"intolerante a 40 Mhz", //_lb_forty_into
	"WiFi óptima", //_lb_wifi_opt
	"TxStream HT", //_lb_ht_txstream
	"RxStream HT", //_lb_ht_rxstream
	"Bloqueo WPS de registro externo", //_lb_wps_ext_reg_lock
	"Automática", //_sel_autoselect
	"Modo mixto", //_sel_mixed
	"Green Field", //_sel_greenfield
	"Largo", //_long
	"Encendido de Radio:", //_btn_radio_on
	"Apagado de Radio:", //_btn_radio_off
	"La Radio de Red wireless está APAGADA.", //_MSG_woff
	"Use the Advanced Setup page to make detailed settings for the Wireless. Advanced Setup includes items that are not available from the Basic Setup page, such as Beacon Interval, etc.", //_desc_advanced
	"Parámetros de calidad de servicio (QoS)", //_bx_advanced_2
	"Multimedia Wi-Fi", //_bx_advanced_3
	"Convertidor Multidifusión-a-Unidifusión", //_bx_advanced_4
	"Modo de protección BG", //_lb_bg_protection
	"(rango 10 - 100, predeterminado 100)", //_hint_beacon
	"(rango 1 - 255, predeterminado 1)", //_hint_dtim
	"Umbral de fragmentación", //_lb_frag_thres
	"(rango 256 - 2346, predeterminado 2346)", //_hint_frag_thres
	"(rango 1 - 2347, predeterminado 2347)", //_hint_rts_thres
	"TX Power", //_lb_txpower
	"Preámbulo corto", //_lb_short_preamble
	"Franja Corta", //_lb_short_slot
	"Tx Burst", //_lb_tx_burst
	"Pkt_Agregado", //_lb_pkt_aggregate
	"Admisión de IEEE 802.11H", //_lb_80211h_support
	"únicamente en la banda A", //_hint_only_a_band
	"código de país", //_lb_country_code
	"Capable WMM", //_lb_wmm_capable
	"Admite APSD", //_lb_apsd_capable
	"Admite DLS", //_lb_dls_capable
	"Parámetros WMM", //_lb_wmm_param
	"Configuración WMM", //_lb_wmm_config
	"Turbina de video", //_lb_video_turbine
	"Multidifusión-a-Unidifusión", //_lb_multi_uni
	"Expira en", //_lb_expire_in
	"Lleno", //_pwr_full
	"Mitad", //_pwr_half
	"Bajo", //_pwr_low
	"Opciones WMM wireless", //_tl_wmm_settings
	"Parámetros WMM de punto de acceso", //_lb_wmm_param_ap
	"Parámetros WMM de estación", //_lb_wmm_param_station
	"Mezclado 2.4GHz 802.11b/g", //m_bwl_Mode_3
	"Sólo 2.4GHz 802.11n", //m_bwl_Mode_8
	"Mezclado 2.4GHz 802.11b/g/n", //m_bwl_Mode_11
	"Sólo 5GHz 802.11a", //m_bwl_Mode5_1
	"Sólo 5GHz 802.11n", //m_bwl_Mode5_2
	"Mezclado 5GHz 802.11a/n", //m_bwl_Mode5_3
	"Señal", //_singal
	"BSSID", //_bssid
	"Estado Actual de WPS", //_wps_cur_state
	"WPS Configurada", //_wps_configed
	"WPS SSID", //_wps_ssid
	"Modo de Seguridad de WPS", //_wps_sec_mode
	"Tipo de Encriptado de WPS", //_wps_enc_type
	"Índice de Clave Predeterminada de WPS", //_wps_def_key_idx
	"HEXADECIMAL", //_hex
	"ASCII", //_ascii
	"Clave de WPS", //_wps_key
	"PIN AP", //_ap_pin
	"Puedes aquí monitorear clientes DHCP.", //_desc_dhcp_client_list
	"Setting wireless security.", //_wifiser_mode42
	"Procesando,", //_processing
	"Dirección de Estado de la Red", //_netwrk_status_addr
	"Información del Sistema", //_system_info
	"Horario del Sistema", //_system_time
	"Tiempo activ. del sistema", //_system_up_time
	"Configuraciones de Internet", //_internet_configs
	"Tipo de Conexión", //_connected_type
	"WAN Dirección IP", //_wan_ip_addr
	"Servidor del Nombre del Dominio Primario", //_pri_dns
	"Servidor del Nombre del Dominio Secundario", //_sec_dns
	"2.4GHz wireless", //_24Ghz_wireless
	"5GHz wireless", //_5Ghz_wireless
	"Esta sección muestra la información de apertura de sesión de dispositivos para fines de monitorización y resolución de problemas.", //_SYSLOG_DESC
	"Habilita un Log del Sistema", //_enable_system_log
	"Configuración de hora y fecha", //_time_setting
	"Esta sección le permite configurar la hora y la fecha del router.", //_TIME_DESC
	"Horario de Verano", //_daylight_saving_time
	"Configuraciones de NTP", //_ntp_settings
	"Servidor NTP", //_ntp_server
	"Sincronización NTP", //_ntp_sync
	"Configuraciones de Fecha y Hora", //_date_time_settings
	"Esta sección le permite hacer una copia de respaldo (exportar) o restablecer (importar) la configuración de su router. Esta página también le permite restablecer el router a las opciones por defecto de fábrica o reiniciarlo.", //_SETTINGS_MANAGER_DESC
	"Exporta", //_export
	"Localización de archivo de ajustes.", //_settings_file_location
	"Importa", //_import
	"FIRMWARE", //_upgrade_firmw
	"Puede comprobar el nuevo firmware disponible para su dispositivo en el sitio web de TRENDnet. La carga de firmware nuevo puede resolver problemas o aumentar la funcionalidad de su dispositivo. Es importante que compruebe las notas de la versión incluidas con la descarga de firmware, para ver si se ha atendido al problema o si se han agregado funciones que usted necesita antes de cargar una nueva versión de firmware. Tras descargar el archivo, extráigalo a su unidad de disco duro local. Haga clic en “Browse” (explorar) o “Choose File” (seleccionar archivo) para navegar hasta la ubicación del archivo de firmware extraído. Haga clic en Apply (aplicar) para cargar el firmware en su dispositivo.", //_FIRMW_DESC
	"Nota importante: No interrumpa el proceso de carga del firmware, ya que esto podría producir daños en su dispositivo. Espere hasta que la carga del firmware haya concluido y que el dispositivo se haya reiniciado completamente.", //_FIRMW_DESC_sub
	"Localización:", //_location
	"Aplicar", //_apply
	"Gerenciamiento del Sistema", //_system_management
	"You may configure administrator account and password.", //_SYS_MANGER_DESC
	"Máx.: %s caracteres", //_max_length_characters
	"Configuraciones de URL del Dispositivo", //_device_url_settings
	"URL del Dispositivo", //_device_url
	"Configuraciones de Nombre del Dispositivo", //_device_name_settings
	"Configuraciones de DDNS", //_ddns_settings
	"Administración remota", //_remote_management
	"Control Remoto (via Internet)", //_remote_control_via_wan
	"Puerto Remoto", //_remote_port
	"Reiniciar", //_reset
	"Si no está familiarizado con los parámetros inalámbricos avanzados, por favor lea la sección de ayuda antes de modificar estos parámetros.", //_ADV_NETWRK_DESC
	"Respuesta de Ping WAN", //_wan_ping_respond
	"Regla de programa", //_schedule_rules
	"Define schedule rules for various firewall features.", //_SCHEDULE_DESC
	"AÑADIR REGLA DE PROGRAMA", //_add_sche_rule
	"Todo el día, 24 horas", //_tsc_allday_24hr
	"Lista de Reglas de programación", //_schedule_rule_list
	"Registro de Horario", //_time_stamp
	"24 horas", //_24hr
	"Mezclado 5GHz 802.11a/n/ac", //m_bwl_Mode5_4
	"Routing entre zonas", //_routing_bet_zone
	"Clon de MAC:", //_mac_clone
	"Clon de Dirección MAC:", //_mac_addr_clone
	"Configuración del Servidor DNS", //_dns_server_setting
	"Configuración del DHCP", //_dhcp_setting
	"You may choose different connection type suitable for your environment. Besides, you may also configure parameters according to the selected connection type.", //_DHCP_DESC
	"Configuración de la Red de Área Ampliada (WAN)", //_wan_setting_l
	"(bytes) por defecto=%s bytes", //_mtu_default_byte
	"Configuración IP de Interfaz WAN", //_wan_if_ip_setting
	"Modo de funcionamiento", //_opeartion_mode
	"Mantener activo", //_keep_alive
	"Modo Vigente: Período para volver a intentar conectarse", //_keep_alive_mode_redial
	"Modo de demanda", //_on_demand_mode_idle_time
	"minutos", //_mintues_lower
	"Configuración L2TP", //_l2tp_setting
	"Configuración de PPTP", //_pptp_setting
	"dinámico", //_dynamic
	"Configuración de la Red de Área Local (LAN)", //_lan_setting_l
	"Esta sección le permite modificar las opciones de dirección IP del router. Por lo general, no es necesario cambiar las opciones de dirección IP del router. Además, esta página le permite configurar las opciones del servidor DHCP del router o las reservas de DHCP que las Direcciones IP automáticamente asignadas a sus dispositivos wireless y por cable que se conecten con su router.", //_LAN_DESC
	"Configuración del servidor DHCP", //_dhcp_server_setting
	"IP de Inicio del DHCP", //_dhcp_start_ip
	"IP de cierre del DHCP", //_dhcp_end_ip
	"Otras opciones", //_other_setting
	"Árbol de expansión 802.1d", //_8021d_spanning_tree
	"LLTD", //_lltd
	"Proxy IGMP", //_igmp_proxy
	"Relé PPPOE", //_pppoe_relay
	"Proxy DNS", //_dns_proxy
	"Añadir reserva DHCP", //_add_dhcp_reservation
	"Copiar la dirección MAC del PC", //_copy_pc_mac
	"Copiar", //_copy
	"Grupo Preparado de Reservas del DHCP", //_dhcp_reservation_ready_group
	"Editar la reservación DHCP", //_edit_dhcp_reservation
	"Borrar todo", //_delete_all
	"Borrar seleccionado", //_delete_selected
	"Iniciar PIN", //_config_via_pin
	"Iniciar botón de arranque", //_config_via_pbc
	"Configuración ALG (Application Level Gateway)", //_alg_config_l
	"ALG configuration allows users to disable some application service.", //_ALG_DESC
	"Descripción", //_description
	"Recepción de email", //_email_receiving
	"Protocolo Post Office: Versión 3 (POP3)", //_pop3_l
	"Protocolo Simple de Transferencia de Correo (SMTP)", //_smtp_l
	"Medio de Transmisión", //_streaming_media
	"Protocolo de Transporte en Tiempo Real (RTP)", //_rtp_l
	"Protocolo de Transmisión en Tiempo Real (RTSP)", //_rtsp_1
	"Protocolo del Servidor de Media de Microsoft (WMP/MMS)", //_mms_l
	"Medio-VolP de Transmisión", //_streaming_media_voip
	"Protocolo de Inicio de Sesión (SIP)", //_session_init_protocol_l
	"NetMeeting (H.323)", //_h323_l
	"Transferencia de Archivo", //_file_transfer
	"Protocolo de Transferencia de Archivo (FTP)", //_ftp_l
	"Protocolo de Transferencia de Archivo Trivial (TFTP)", //_tftp_l
	"Control Remoto", //_remote_control
	"Telnet", //_telnet
	"Mensajería Instantánea", //_instant_messaging
	"MSN Messenger", //_msn_messenger
	"IPSec VPN", //_ipsec
	"Guardar Estado", //_save_status
	"Parámetros de DMZ", //_dmz_settings
	"You may setup a De-militarized Zone(DMZ) to separate internal network and Internet.", //_DMZ_DESC
	"Access Control allows users to define the traffic type not-permitted to WAN port service.", //_AC_DESC
	"Add Port Range and Service Block Rule", //_add_port_block_rule
	"Habilita la Regulación", //_policy_enable
	"Nombre de directiva", //_policy_name
	"Client IP Address", //_client_ip_addr
	"Define Norma", //_rule_define
	"Servicio especial", //_special_service
	"Definición de Usuario", //_user_define
	"Puertos TCP", //_tcp_ports
	"Ej.: 21 o 300-500", //_ex_21_or_3_500
	"Puertos UCP", //_udp_ports
	"Servicio", //_service
	"Editar las reglas de servicios en bloque", //_edit_port_block_rule
	"Lista de reglas de bloqueo de servicios", //_port_block_rule
	"Agregar regla de bloqueo de todos los servicios", //_add_ip_block_rule
	"Editar las reglas de servicios en bloque", //_edit_ip_block_rule
	"Lista de reglas de bloqueo de todos los servicios", //_ip_block_rule_list
	"Agrega Norma para Filtro de URL de Webs", //_add_weburl_rule
	"Editar las reglas de filtración", //_edit_weburl_rule
	"Lista de filtros URL", //_weburl_rule_list
	"Envío de email", //_email_sending
	"Transferencia de Archivo", //_file_transfer_l
	"Servicio Telnet", //_telnet_service
	"Consulta DNS", //_dns_query
	"Protocolo TCP", //_tcp_protocol
	"Protocolo UDP", //_udp_protocol
	"WWW", //_www
	"Error de formato de la dirección IP.", //_err_ip_addr_format
	"Error de máscara IP", //_err_ip_mask
	"Error de formato de entrada", //_err_input_format
	"Error de dirección IP", //_err_ip_addr
	"Configuración de enrutamiento", //_static_routing_settings
	"Esta sección le permite definir manualmente rutas estáticas y habilitar o deshabilitar el uso de routing dinámico en el router.", //_ROUTING_DESC
	"Agrega una Ruta Estática", //_add_static_route
	"Dirección IP de destino", //_dest_ip_addr
	"Máscara de red de IP de Destino", //_dest_ip_mask
	"Puerto físico", //_physical_port
	"Habilita RIP", //_enable_rip
	"El modo RIP", //_rip_mode
	"Lista de rutas estáticas", //_static_route_list
	"¡Procesando! Por favor espere...", //_processing_plz_wait
	"Reiniciando, por favor espere.....", //_rebooting_plz_wait
	"Dirección IP de puerta de enlace L2TP", //_L2TPgw
	"Reintentar", //_retry
	"Omitir", //_skip
	"El router está comprobando la conectividad a Internet, espere.", //_chk_wanconn_msg_00
	"Asistente de configuración", //_tnw_01
	"Este asistente le guiará a través de un proceso paso a paso para configurar su conexión a Internet.", //_tnw_02
	"Comprobando la conexión a Internet", //_tnw_03
	"Information", //_tnw_04
	"SSID", //_ssid
	"tipo de autenticación.:", //_auth_type
	"Finalizar", //_finish
	"Configurar la conexión a Internet", //_tnw_05
	"Obtener IP automáticamente (cliente DHCP)", //_tnw_dhcp
	"Dirección IP fija", //_tnw_static
	"PPPoE", //_tnw_pppoe
	"PPTP", //_tnw_pptp
	"L2TP", //_tnw_l2tp
	"Establecer la Dirección IP dinámica", //_tnw_06
	"MAC", //_mac
	"Clonar dirección MAC", //_tnw_clone
	"Establecer la Dirección IP fija", //_tnw_07
	"WAN Dirección IP", //_wan_ipaddr
	"máscara subred de la WAN", //_wan_submask
	"dirección IP del gateway de la WAN", //_wan_gwaddr
	"Dirección del servidor DNS 1", //_dns_1
	"Dirección del servidor DNS 2", //_dns_2
	"%s Asistente de configuración: PPPoE", //_tnw_08
	"%s Asistente de configuración: PPTP", //_tnw_09
	"Mi IP", //_my_ip
	"servidor IP", //_server_ip
	"cuenta PPTP", //_pptp_account
	"Contraseña PPTP", //_pptp_password
	"Reescribir Contraseña PPTP", //_pptp_password_re
	"%s Asistente de configuración: L2TP", //_tnw_10
	"Cuenta L2TP", //_l2tp_account
	"Contraseña L2TP", //_l2tp_password
	"Reescribir Contraseña L2TP", //_l2tp_password_re
	"Los parámetros se guardan y surten efecto.", //_tnw_11
	"Espere", //_tnw_12
	"segundos.", //_tnw_13
	"Compruebe la conexión por cable entre el puerto de Internet y el módem.", //_tnw_14
	"Imprimir", //_print
	"No se aceptan espacios en la contraseña. Inténtelo de nuevo.", //_TAG00840
	"Autoconfiguración (SLAAC/DHCPv6)", //IPV6_TEXT171
	"Autoconfiguración (SLAAC/DHCPv6) + 6RD", //IPV6_TEXT172
	"Compartido", //_wps_shared
	"Abierto", //_wps_open
	"El nombre de regla '%s' está duplicado.", //_webfilterrule_dup
	"WPS 2.4GHz", //_wps_24g
	"WPS 5GHz", //_wps_5g
	"Nombre (SSID)", //_name_ssid
	"Registro de la garantía del producto", //_warranty
	"USB", //_usb
	"Servidor de archivos compartidos", //_samba_server
	"servidor FTP", //_ftp_server
	"Servidor de Impresión", //_print_server
	"Dispositivos conectados", //_connected_devices
	"Invitado de la red", //_guest_network
	"Esta sección le permite configurar las opciones de la red wireless de invitados.", //_guest_text1
	"Puente de red:", //_network_bridge
	"Acceso a Internet únicamente", //_inet_access_only
	"(Seguridad nula)", //_security_no
	"(Seguridad baja)", //_security_low
	"(Seguridad media)", //_security_middle
	"(Seguridad alta)", //_security_high
	"Control Paterno", //_parental_control
	"Conexión a internet", //_has_inet_connection
	"Internet desconectada", //_no_inet_connection
	"Red de invitados activada", //_guest_network_enabled
	"Red de invitados desactivada", //_guest_network_disabled
	"Dispositivos USB conectados", //_usb_connected
	"No hay dispositivos USB conectados", //_no_usb_connected
	"Acceso doméstico", //_household_access
	"Confirmar opciones", //_confirm_settings
	"Comprobar conexión", //_check_connection
	"Dirección", //_address
	"Lista de reglas de acceso", //_ha_rule_list
	"Agregar regla de acceso", //_add_ha_rule
	"Editar las reglas de acceso local", //_edit_ha_rule
	"No se puede cambiar el modo 802.11 a Sólo 802.11n mientras exista un SSID con seguridad WEP/WPA-TKIP.", //_wlan_11n_not_support_wep_wpa_tkip
	"Radio por programa", //_lb_radio_on_sche
	"No puede añadir más reglas porque la tabla está llena.", //_rule_full
	"No puedes habilitar WDS pues la seguridad actual no es compatible. ", //_wds_cant_enble
	"Los clientes deben deben emitir y actualizar la dirección IP; de lo contrario, se debe reiniciar el DUT.", //_LAN_CHK_REBOOT_MSG
	"Especifica URL del Dispositivo.", //_specify_url
	"La dirección IP '%s' ya está en uso.", //_ipaddr_used
	"La dirección MAC '%s' ya está en uso.", //_macaddr_used
	"No borres ninguna norma", //_lan_dr
	"Selecciona por lo menos una ruta para eliminar!!", //_adv_rtd
	"A-MPDU", //_lb_a_mpdu
	"Router wireless de banda dual  AC750", //PRODUCT_DESC_810
	"AC750 Wireless Travel Router", //PRODUCT_DESC_817
	"La dirección IP '%s' ya está en uso.", //_ipaddr_used
	"La dirección MAC '%s' ya está en uso.", //_macaddr_used
	"Internet no establecida", //no_wan_up
	"Modo AP ", //dev_mode_ap
	"Modo repetidor", //dev_mode_repeater
	"Modo WISP", //dev_mode_wisp
	"Cliente AP ", //ap_client
	"Extender SSID", //extend_ssid
	"Lista de clientes wireless", //wlan_client_list
	"Modo de punto de acceso; seleccione este modo para crear redes wireless de 2.4 GHz (802.11b/g/n) y de 5 GHz (802.11a/n/ac). Para agregar una red wireless en su red existente, conecte un cable de red al puerto LAN/Ethernet del %s y a su router/red.", //desc_ap
	"Seleccione este modo para extender una red wireless existente mediante el %s.", //desc_repeater
	"Proveedor de servicios de Internet wireless; seleccione este modo para conectarse a una red de un proveedor de servicios de Internet wireless (p. ej. servicios de Internet wireless de un hotel) para acceder a Internet y crear una red interna para sus dispositivos cliente mediante el %s.", //desc_wisp
	"Elija un emplazamiento al que desee conectarse y después haga clic en Siguiente.", //wiz_select_site
	"Haga clic en Refresh (actualizar) para actualizar la lista de sitios disponibles.", //wiz_refresh_site
	"No hay sitios disponibles.", //wiz_no_result
	"Veuillez sélectionner un SSID ou cliquez sur Manual.", //wiz_no_selected
	"¿Desea salir del asistente?", //wiz_quit
	"rango %d - %d", //custom_range
	"Parámetros de Internet", //_internet_setting
	"Configurar IPv6 estática", //desc_static_ipv6
	"Paquetes %s", //_s_packet
	"Bloqueo WPS", //_wps_lock
	"Communication PPTP", //pptp_passthrough
	"Communication L2TP", //l2tp_passthrough
	"Configurez les paramètres du  réseau local (LAN) et du DHCP.", //desc_ap_lan
	"Accédez au protocole IP", //attain_ip
	"Etat du périphérique", //dev_stat
	"La section de configuration des horaires sert à gérer les règles d’horaires du WiFi.", //desc_ap_sch
	"" //MAX
);
var _Advanced_01=0;
var _Advanced_03=1;
var _Advanced_04=2;
var bwn_ict_dns=3;
var bwn_msg_Modes_dns=4;
var aa_EAC=5;
var new_bwn_mici_usb=6;
var _tkip_11n=7;
var bln_title_guest_use_shareport=8;
var IPV6_TEXT3=9;
var bwl_Mode_10=10;
var IPV6_TEXT148=11;
var _regenerate=12;
var TEXT048=13;
var te_EnEmN=14;
var usb3g_titile=15;
var usb3g_apn_name=16;
var usb3g_dial_num=17;
var usb3g_reconnect_mode=18;
var usb3g_max_idle_time=19;
var usb_device=20;
var usb3g_manual=21;
var usb3g_stat_titile=22;
var bln_title_usb=23;
var usb_wcn=24;
var bwn_intro_usb=25;
var usb_network=26;
var usb_3g=27;
var wwan_dial_num=28;
var bwn_wwanICT=29;
var help862=30;
var wwan_auth_label=31;
var wwan_auth_auto=32;
var IPPPPPAP_AUTH_ISSUE=33;
var wwan_auth_chap=34;
var wwan_auth_mschap=35;
var usb_network_help=36;
var usb_3g_help=37;
var usb_3g_help_support_help=38;
var usb_wcn_help=39;
var bwn_mici_usb=40;
var _info_netowrk=41;
var anet_multicast_enable=42;
var bwn_usb_time=43;
var bwn_bytes_usb=44;
var _wps_albert_1=45;
var _wps_albert_2=46;
var usb_config2=47;
var ac_alert_choose_dev=48;
var usb_config3=49;
var usb_config4=50;
var usb_config5=51;
var usb_config6=52;
var bwn_msg_usb=53;
var _country=54;
var _select_country=55;
var _select_ISP=56;
var country_1=57;
var country_2=58;
var country_3=59;
var country_4=60;
var country_5=61;
var country_6=62;
var country_7=63;
var _aa_bsecure_personals=64;
var country_9=65;
var country_10=66;
var country_11=67;
var country_12=68;
var country_13=69;
var country_14=70;
var country_15=71;
var S500=72;
var S496=73;
var sto_http_2=74;
var logs_LW39b_email=75;
var LV3=76;
var GW_WIRELESS_DEVICE_LINK_UP=77;
var LT248=78;
var GW_PPPOE_EVENT_DISCOVERY_ATTEMPT=79;
var GW_WLAN_RADIO_1_NAME=80;
var te_SMTPSv_Port=81;
var GW_WLAN_CHANGING_PHY_MODE_TO_11NG_ONLY_INVALID=82;
var S558=83;
var KRL8=84;
var LY30=85;
var GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=86;
var GW_WIFISC_DISABLED_AUTOMATICALLY=87;
var _off=88;
var GW_WLAN_RADIO_0_NAME=89;
var GW_PPPOE_EVENT_DISCOVERY_REQUEST_ERROR=90;
var GW_WAN_PPPOE_SESSION_NAME_CONFLICT=91;
var S525=92;
var YM174=93;
var KR136=94;
var GW_PPPOE_EVENT_DISCONNECT=95;
var af_EFT_0=96;
var LY34=97;
var GW_WIRELESS_SHUT_DOWN=98;
var GW_WIRELESS_RESTART=99;
var S528=100;
var GW_PORT_FORWARD_TCP_PACKET_ALLOC_FAILURE=101;
var guestzone_Intro_1=102;
var GW_NAT_VIRTUAL_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=103;
var ta_ERM=104;
var te_SMTPSv_Port_alert=105;
var GW_WIRELESS_DEVICE_START_FAILED=106;
var GW_PORT_FORWARD_UDP_PACKET_ALLOC_FAILURE=107;
var GW_WIRELESS_DEVICE_DISCONNECT_ALL=108;
var GW_PPPOE_EVENT_OFFER_REQUEST=109;
var GW_ROUTES_ROUTERS_IP_ADDRESS_INVALID=110;
var GW_PORT_TRIGGER_UDP_PACKET_ALLOC_FAILURE=111;
var GW_WLAN_SETTING_SSID_SECURITY_TO_WEP_INVALID=112;
var GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT=113;
var GW_WLAN_STATION_TIMEOUT=114;
var GW_NAT_VIRTUAL_SERVER_IP_ADDRESS_CAN_NOT_MATCH_ROUTER=115;
var GW_NAT_VIRTUAL_SERVER_PROTO_CONFLICT_INVALID=116;
var LY28=117;
var GW_PPPOE_EVENT_CONNECT=118;
var GW_NAT_TRIGGER_PORT=119;
var tc_opmode=120;
var wwz_auto_assign_key3=121;
var LY292=122;
var LY293=123;
var bws_msg_WEP_4=124;
var GW_ROUTES_ON_LINK_DATALINK_CHECK_INVALID=125;
var wwa_dnsset=126;
var wireless_gu=127;
var add_gu_wps=128;
var wwl_band=129;
var _band=130;
var wwa_5G_nname=131;
var _guestzone=132;
var guestzone_title_1=133;
var _graph_auth=134;
var guestzone_inclw=135;
var guest=136;
var lower_wnt=137;
var equal_wnt=138;
var _lowest=139;
var ssid_lst=140;
var mult_ssid=141;
var add_ed_ssid=142;
var help75a=143;
var wpin_filter=144;
var tps_raw1=145;
var up_tz_52=146;
var _r_alert_new1=147;
var te_EmSt=148;
var IPNAT_BLOCKED_EGRESS=149;
var bws_WSMode=150;
var anet_wan_ping_1=151;
var help65=152;
var ta_upnp=153;
var bwl_TxR=154;
var GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED=155;
var tsc_pingt_msg106=156;
var tsc_AllDay=157;
var gw_gm_53=158;
var GW_WAN_RATE_ESTIMATOR_RESOURCE_ERROR=159;
var DHCP_CLIENT_LOST_LEASE=160;
var _aa_wiz_s3_msg=161;
var bwsAT_=162;
var hhtt_intro=163;
var gw_gm_20=164;
var help388=165;
var tt_StDT=166;
var psOffline=167;
var _status=168;
var up_ae_wic_3=169;
var sl_WtV=170;
var WIFISC_AP_PROXY_PROCESS_START=171;
var wprn_nopr2=172;
var help352=173;
var wwz_wwl_wnn=174;
var _ipaddr=175;
var GW_WLS_SCHEDULE_START=176;
var help820=177;
var help326=178;
var up_tz_54=179;
var help773=180;
var am_MACFILT=181;
var aa_alert_7_new1=182;
var help302=183;
var aa_intro=184;
var help348=185;
var haf_dmz_30=186;
var sl_Infrml=187;
var _wireless=188;
var bws_RIPA=189;
var KR108=190;
var help83=191;
var hhase_intro=192;
var RUNTIME_CONFIG_MAGIC_NUM_ERROR=193;
var _Sat=194;
var awf_title_WSFR=195;
var help18_a=196;
var dlink_wf_op_1=197;
var gw_gm_18=198;
var gw_gm_7=199;
var USB_LOG_STORAGE_TYPE=200;
var help346=201;
var up_rb_5=202;
var _WEP=203;
var IPMSCHAP_AUTH_FAIL_AND_NO_RETRY=204;
var gw_gm_82=205;
var bw_sap=206;
var bwn_msg_SWM=207;
var li_alert_2=208;
var help120=209;
var IGMP_HOST_LOW_RESOURCES=210;
var wwl_s4_intro_z3=211;
var help78=212;
var help339=213;
var IPv6_Simple_Security_enable=214;
var help51=215;
var GW_WAN_LAN_ADDRESS_CONFLICT_PPP=216;
var ss_Errors=217;
var help899=218;
var li_alert_4=219;
var haf_dmz_40=220;
var hhts_edit=221;
var wwl_wnn=222;
var WEB_FILTER_LOG_URL_ACCESSED_MAC=223;
var aw_WE=224;
var help201a=225;
var _bsecure_activate_trial=226;
var help896=227;
var help815=228;
var _netmask=229;
var _please_wait=230;
var help12=231;
var am_intro_1=232;
var IPPPPLCP_SET_LOCAL_AUTH=233;
var gw_gm_11=234;
var _dontsavesettings=235;
var wwl_s4_intro_za1=236;
var _308=237;
var aa_AT_1=238;
var IPL2TP_TUNNEL_ABORTING=239;
var help330=240;
var wwa_msg_l2tp=241;
var tt_time_5=242;
var help6=243;
var _time=244;
var at_xDSL=245;
var wprn_intro4=246;
var help296=247;
var _LAN=248;
var gw_gm_60=249;
var _aa_wiz_s4_msg=250;
var wwl_64bits=251;
var IPFAT_DISK_FULL=252;
var help341=253;
var aa_sched_conf_2=254;
var IPL2TP_SESSION_CONNECTING=255;
var NET_RTC_SYNCHRONIZATION_FAILED=256;
var tf_AutoCh=257;
var wprn_iderr2=258;
var help319=259;
var af_intro_2=260;
var help800=261;
var sd_title_Dev_Info=262;
var GW_INET_ACCESS_DROP_PORT_FILTER=263;
var _connow=264;
var IPSIPALG_REJECTED_PACKET=265;
var IPNAT_TCP_UNABLE_TO_MODIFY_OPTIONS=266;
var tt_SelNTPSrv=267;
var help812=268;
var _user=269;
var up_tz_59=270;
var SPECIAL_APP=271;
var wwl_NONE=272;
var GW_WAN_SERVICES_STARTED=273;
var fb_FbWbAc=274;
var help275=275;
var wprn_nopr=276;
var tt_TimeZ=277;
var wprn_tt=278;
var help841=279;
var aa_sched_new=280;
var tt_time_14=281;
var gw_vs_1=282;
var tsl_SLSt=283;
var IPH323ALG_REJECTED_PACKET=284;
var aa_wiz_s1_msg4=285;
var help336=286;
var ta_sn=287;
var help780=288;
var _interface=289;
var WEB_FILTER_LOG_URL_BLOCKED=290;
var vs_http_port=291;
var haf_intro_1=292;
var up_tz_07=293;
var aw_intro=294;
var wwa_gw=295;
var _sentinel_serv=296;
var wwa_msg_sipa=297;
var IPNAT_TCP_UNABLE_TO_HANDLE_HEADER=298;
var hhav_ip=299;
var haf_dmz_50=300;
var GW_INET_ACCESS_POLICY_END_MAC=301;
var tsc_intro_Sch=302;
var GW_WLAN_ACCESS_DENIED=303;
var _262=304;
var help79=305;
var GW_BIGPOND_CONFIG=306;
var aw_TP_0=307;
var _sdi_s3=308;
var tsc_pingr=309;
var tsc_pingt_v6=310;
var _WPApersonal=311;
var _email=312;
var PPPOE_EVENT_DISCOVERY_REQUEST=313;
var _firewall=314;
var wwa_wanmode_sipa=315;
var _syscheck=316;
var help784=317;
var UNKNOWN=318;
var help_upnp_1=319;
var gw_gm_61=320;
var _optional=321;
var help181=322;
var help569=323;
var anet_intro=324;
var _authword=325;
var IPNAT_TCP_BLOCKED_EGRESS_NOT_SYN=326;
var ta_GWN=327;
var wprn_tt3=328;
var help293=329;
var help265_2=330;
var IPNAT_UNABLE_TO_CREATE_CONNECTION=331;
var help270=332;
var aw_title_2=333;
var _firewalls=334;
var LW67=335;
var PPPOE_EVENT_UP=336;
var _protocol=337;
var help372=338;
var up_tz_32=339;
var at_kbps=340;
var at_Cable=341;
var anet_wp_1=342;
var help17=343;
var ta_intro_Adm2=344;
var tool_admin_check=345;
var IPPPPIPCP_PPP_LINK_UP=346;
var _stop=347;
var GW_SYSLOG_STATUS=348;
var bd_title_DHCPSSt=349;
var help827=350;
var tf_FWCheckInf=351;
var tf_FWInf=352;
var hhai_ipr=353;
var hhaw_1=354;
var help34=355;
var _network_usb_auto=356;
var help309=357;
var aa_alert_15=358;
var _savesettings=359;
var help193=360;
var help14_p=361;
var gw_gm_32=362;
var IPNAT_TCP_BLOCKED_INGRESS_SYN=363;
var anet_msg_wan_ping=364;
var ai_intro_2=365;
var help285=366;
var ss_LANStats=367;
var ta_alert_4=368;
var _clone=369;
var gw_gm_14=370;
var PPTP_ALG_GRE_UNABLE_TO_HANDLE_HEADER=371;
var _aa_block_some=372;
var help819_3=373;
var tt_time_24=374;
var help873=375;
var ss_Collisions=376;
var help863=377;
var help397=378;
var av_title_VSL=379;
var help636=380;
var tf_ENFA=381;
var help13=382;
var wwa_title_s3=383;
var ES_wwa_title_s1=384;
var GW_WAN_RATE_ESTIMATOR_CONVERGENCE_ERROR=385;
var wwa_wanmode_bigpond=386;
var help254=387;
var haf_dmz_70=388;
var GW_SCHED_ATTACH_FAILED=389;
var _badssid=390;
var RUNTIME_CONFIG_STORING_CONFIG_IN_NVRAM=391;
var FW_UPDATE_AVAILABLE=392;
var help891=393;
var help777=394;
var help393=395;
var bwn_ict=396;
var tt_Jun=397;
var IPL2TP_TUNNEL_CONNECTED=398;
var gw_gm_9=399;
var gw_gm_2=400;
var wwl_wl_wiz=401;
var network_dhcp_range=402;
var wprn_intro6=403;
var GW_BIGPOND_FAIL=404;
var af_EFT_1=405;
var _use_unicasting=406;
var _networkstate=407;
var tt_Year=408;
var IPASYNCFILEUSB_MOUNT_FAILED=409;
var af_UEFT=410;
var help356=411;
var help381=412;
var _inboundfilter=413;
var _aa_apply_port_filter=414;
var aa_FPR_c7=415;
var gw_gm_27=416;
var BIGPOND_NOT_PROPERLY_CFGD=417;
var help335=418;
var up_tz_58=419;
var _never=420;
var help801=421;
var tsc_pingt_msg105=422;
var li_WJS=423;
var te_ToEm=424;
var tt_time_1=425;
var help787=426;
var IPV6_TEXT65_v6=427;
var GW_EMAIL_SUBJ=428;
var IPPORTTRIGGERALG_UDP_PACKET_ALLOC_FAILURE=429;
var bi_wiz=430;
var _Out=431;
var hhpt_app=432;
var _dhcpconn=433;
var bln_title_Rtrset=434;
var _ps=435;
var _1044=436;
var wwl_text_best=437;
var wwa_pptp_svraddr=438;
var GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED=439;
var _LANComputers=440;
var hhte_intro=441;
var as_NM=442;
var wwa_setupwiz=443;
var help264=444;
var bw_WDUU_note=445;
var as_MMS=446;
var _srvname=447;
var help93=448;
var tt_Minute=449;
var sa_State=450;
var aw_dE=451;
var tsc_pingt_h=452;
var tsc_pingt_h_v6=453;
var ss_WStats=454;
var IPMSCHAP_AUTH_SEND_CHALLENGE=455;
var help889=456;
var as_H323=457;
var tool_admin_pfname=458;
var IPNAT_SESSION_ALREADY_EXISTS=459;
var wwa_title_set_bigpond=460;
var up_tz_16=461;
var GW_BIGPOND_STATUS=462;
var wwa_msg_set_bigpond=463;
var ai_alert_5=464;
var help848=465;
var gw_gm_41=466;
var _aa_pol_wiz=467;
var IP_FILTERS=468;
var gw_gm_50=469;
var wwa_intro_s3=470;
var IPSEC_ALG_ESP_ESTABLISH_ALREADY_PENDING=471;
var help59=472;
var wps_reboot_need=473;
var at_DF=474;
var help265_7=475;
var tt_alert_dstchkmonth=476;
var up_tz_23=477;
var _advanced=478;
var STATIC_IP_ADDRESS=479;
var wwl_title_s3=480;
var hhsw_intro=481;
var ish_menu=482;
var up_tz_33=483;
var GW_FW_NOTIFY_FIRMWARE_ERROR=484;
var _bsecure_more_info=485;
var tf_CFWV=486;
var tt_week_2=487;
var help3=488;
var _creator=489;
var bln_title_DNSRly=490;
var GW_INET_ACCESS_DROP_PORT_FILTER_MAC=491;
var ish_glossary=492;
var wwl_s4_intro_z4=493;
var help118=494;
var gw_gm_66=495;
var help312dr2=496;
var tsc_24hrs=497;
var hhag_10=498;
var help261=499;
var as_TPrt=500;
var help28=501;
var tt_time_12=502;
var ss_reload=503;
var EGRESS=504;
var sps_fp=505;
var gw_gm_57=506;
var wwa_msg_dhcp=507;
var aa_wiz_s1_msg1=508;
var MUST_BE_LOGGED_IN_AS_ADMIN=509;
var up_tz_64=510;
var GW_WLS_SCHEDULE_STOP=511;
var IPWOLALG_REJECTED_PACKET=512;
var WCN_LOG_UPDATE=513;
var help80=514;
var help171=515;
var _Mon=516;
var up_tz_66=517;
var wwl_title_s4_2=518;
var help196=519;
var PPPOE_EVENT_DISCOVERY_REQUEST_ERROR=520;
var li_Log_In=521;
var af_gss=522;
var _defgw=523;
var YM185=524;
var add_wireless_device=525;
var help8=526;
var help258=527;
var PPPOE_EVENT_TERMINATED=528;
var up_rb_1=529;
var help25_b=530;
var sl_saveLog=531;
var sl_intro=532;
var _aa_wiz_s4_help=533;
var GW_WAN_CARRIER_LOST=534;
var bwn_bytes=535;
var help890_1=536;
var help779=537;
var _macaddr=538;
var help823_13=539;
var ta_ELM=540;
var sto_http_4=541;
var anet_multicast_enable_v4=542;
var GW_DYNDNS_UPDATE_NEXT=543;
var help866=544;
var sl_RStat=545;
var gw_gm_78=546;
var help90=547;
var PPTP_EVENT_TUNNEL_DOWN=548;
var bwn_SWM=549;
var IPWEBFILTER_REJECTED_PACKET=550;
var GW_UPGRADE_FAILED=551;
var ag_intro=552;
var ta_intro_Adm=553;
var bwn_L2TPSIPA=554;
var GW_INET_ACCESS_UNRESTRICTED=555;
var up_tz_11=556;
var _disabled=557;
var GW_LOG_EMAIL_ON_LOG_FULL=558;
var tt_time_8=559;
var help43=560;
var ddns_connecting=561;
var _enable=562;
var help272=563;
var tt_Apr=564;
var tt_alert_invlddt=565;
var bwl_MS=566;
var tool_admin_portconflict=567;
var gw_SelVS=568;
var bwn_RM_0=569;
var hhai_edit=570;
var te_FromEm=571;
var wt_p_1=572;
var NET_RTC_REQUEST_TIME=573;
var help48=574;
var N_A=575;
var help279=576;
var tt_week_6=577;
var gw_gm_48=578;
var bwl_VS_1=579;
var help882=580;
var up_tz_41=581;
var RUNTIME_CONFIG_LOADED_CONFIG_FROM_NVRAM=582;
var li_alert_1=583;
var help307=584;
var help273=585;
var help194=586;
var up_rb_4=587;
var NEWER_FW_VERSION=588;
var bwn_PPTPICT=589;
var GW_UPGRADE_SUCCEEDED=590;
var bwl_AS=591;
var help96=592;
var _wchannel=593;
var wwz_manual_key=594;
var ap_intro_cont=595;
var tsl_EnLog=596;
var _L2TP=597;
var bd_DIPAR=598;
var _stats=599;
var wwl_s4_intro_za2=600;
var IPL2TP_SESSION_DOWN=601;
var bwn_DIAICT=602;
var help338=603;
var help859=604;
var _add=605;
var _acccon=606;
var tsc_pingt_msg4=607;
var ddns_disconnect=608;
var _verifypw=609;
var am_intro_2=610;
var _aa_pol_add=611;
var gw_gm_59=612;
var help11=613;
var _system=614;
var help261a=615;
var up_tz_02=616;
var hhtsc_pingt_intro=617;
var help5=618;
var help767s=619;
var gw_gm_45=620;
var wwa_wanmode_pppoe=621;
var GW_ROUTES_GATEWAY_SUBNET_SAME=622;
var haf_dmz_60=623;
var te_intro_Em=624;
var wwl_text_none=625;
var help895=626;
var GW_WAN_RECONNECT_ON_ACTIVE=627;
var aa_Machine=628;
var GW_WLS_SCHEDULE_INIT=629;
var _Wed=630;
var tt_time_20=631;
var aa_FPR_c3=632;
var help68=633;
var help150=634;
var te_Acct=635;
var IPSMTPCLIENT_MSG_SENT=636;
var gw_gm_38=637;
var help384=638;
var tt_time_2=639;
var at_AUS=640;
var hhts_del=641;
var help818=642;
var help886=643;
var _aa_wiz_s2_msg=644;
var help52=645;
var wps_KR46=646;
var wwz_wwl_intro_s3_1=647;
var gw_gm_19=648;
var td_intro_DDNS=649;
var up_tz_53=650;
var help845=651;
var wt_p_3=652;
var up_tz_51=653;
var wprn_s3d=654;
var IPPPPCHAP_AUTH_FAIL=655;
var gw_gm_52=656;
var IPNAT_TCP_BAD_FLAGS=657;
var _name=658;
var help66=659;
var IPNAT_UDP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=660;
var IPFTPALG_REJECTED_PACKET=661;
var fb_p_1=662;
var _contype=663;
var help829=664;
var _specappsr=665;
var help353=666;
var gw_gm_23=667;
var help325=668;
var bwn_RM=669;
var sl_LogOps=670;
var help772=671;
var _aa_method=672;
var sl_LogDet=673;
var help788=674;
var _continue=675;
var help804=676;
var _devinfo=677;
var _yes=678;
var help699=679;
var up_tz_62=680;
var help192=681;
var DHCP_PD_ENABLE=682;
var gw_gm_31=683;
var help271=684;
var help33=685;
var IPNAT_TCP_BLOCKED_INGRESS_BAD_ACK=686;
var htsc_pingt_p=687;
var tf_CKN=688;
var wprn_cps=689;
var up_tz_45=690;
var help84=691;
var GW_FW_NOTIFY_FIRMWARE_AVAIL=692;
var ss_RXPD=693;
var WEB_FILTER_LOG_URL_BLOCKED_MAC=694;
var IPPORTTRIGGERALG_TCP_PACKET_ALLOC_FAILURE=695;
var wwa_note_hostname=696;
var ai_Action=697;
var RUNTIME_CONFIG_RESET_CONFIG_TO_FACTORY_DEFAULTS=698;
var sps_nopr=699;
var gw_hours=700;
var _Fri=701;
var tps_lpd=702;
var tf_FWUg=703;
var anet_wp_0=704;
var gw_gm_4=705;
var help373=706;
var tt_dsoffs=707;
var wwz_auto_assign_key=708;
var gw_gm_15=709;
var wwl_s3_note_1=710;
var hhts_save=711;
var at_Auto=712;
var tsc_pingt_msg100=713;
var IPPPPIPCP_PPP_LINK_DOWN=714;
var aa_AT=715;
var gw_gm_71=716;
var aa_wiz_s1_msg3=717;
var BIGPOND_FAILED=718;
var help898=719;
var bwn_PPTPSIPA=720;
var _routing=721;
var hham_intro=722;
var WIFISC_IR_REGISTRATION_FAIL_3=723;
var ai_intro_1=724;
var wwa_title_s2=725;
var up_tz_69=726;
var IPMSCHAP_AUTH_RESULT=727;
var tss_intro2=728;
var help354=729;
var up_tz_19=730;
var ta_alert_5=731;
var bd_DAB=732;
var _WPAenterprise=733;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL_MAC=734;
var sps_pr=735;
var up_tz_34=736;
var _psk=737;
var _dyndns=738;
var _deny=739;
var IPNAT_TCP_BLOCKED_INGRESS_UNEXP_FLAGS=740;
var help276=741;
var _to=742;
var aa_AT_0=743;
var tt_Dec=744;
var GW_INET_ACCESS_POLICY_START_OTHERS=745;
var up_tz_75=746;
var up_tz_72=747;
var tsc_pingt_msg11=748;
var up_ae_de_1=749;
var help781=750;
var help161_2=751;
var tt_time_19=752;
var am_intro=753;
var help811=754;
var aw_TP_1=755;
var up_tz_24=756;
var IPMSCHAP_AUTH_SENT=757;
var sw_intro=758;
var tps_lpd1=759;
var help257=760;
var _upgintro=761;
var help819_8=762;
var bws_secs=763;
var IPNAT_ICMP_BLOCKED_EGRESS_PACKET=764;
var PORT_FORWARDING=765;
var bwn_Mode_DHCP=766;
var tt_Hour=767;
var help290a=768;
var BIGPOND_LOGGING_OUT=769;
var hhan_mc=770;
var _dns1=771;
var _dns1_v6=772;
var _tools=773;
var _sdi_s2=774;
var sps_usbport=775;
var GW_SCHED_ALLOC_FAILED=776;
var help179=777;
var help262=778;
var _allow=779;
var help798=780;
var DHCP_CLIENT_GOT_LEASE=781;
var anet_wan_phyrate=782;
var _note=783;
var aa_FPR_c6=784;
var help69=785;
var bd_DLT=786;
var ai_title_IFRL=787;
var GW_LAN_INTERFACE_UP=788;
var _logs=789;
var am_FM_2=790;
var GW_LOG_EMAIL_ON_USER_REQUEST=791;
var help21=792;
var bwl_Mode=793;
var bwn_AM=794;
var bwn_BPS=795;
var _ispinfo=796;
var _rate=797;
var up_tz_06=798;
var _success=799;
var _bsecure_parental_serv=800;
var wwa_set_l2tp_title=801;
var help342=802;
var help265=803;
var GW_SMTP_EMAIL_RESOLVED_DNS=804;
var tsc_pingt_msg102=805;
var bws_RSP=806;
var PPPOE_EVENT_CONNECT=807;
var tt_auto=808;
var PPTP_EVENT_LOW_RESOURCES_TO_QUEUE=809;
var IPL2TP_TUNNEL_UNEXPECTED_MESSAGE=810;
var gw_gm_34=811;
var tt_week_5=812;
var wwl_intro_end=813;
var aa_Policy_Table=814;
var tt_TimeConf=815;
var _none=816;
var _aa_wiz_s3_title=817;
var help392=818;
var GW_LOG_EMAIL_ON_SCHEDULE=819;
var wwa_intro_s2=820;
var _PPTPgw=821;
var WEB_FILTER_LOG_URL_ACCESSED=822;
var IPMMSALG_REJECTED_PACKET=823;
var _wirelesst=824;
var int_intro=825;
var GW_LAN_ACCESS_DENIED=826;
var gw_gm_26=827;
var PPTP_ALG_GRE_BLOCKED_INGRESS=828;
var up_tz_30=829;
var gw_gm_49=830;
var _sched=831;
var IPFAT_MOUNT_FAILED=832;
var gw_gm_75=833;
var help883=834;
var ta_alert_6=835;
var GW_INET_ACCESS_POLICY_START_IP=836;
var help841a=837;
var tt_time_23=838;
var ag_title_4=839;
var gw_gm_68=840;
var IPNAT_TCP_BLOCKED_EGRESS_UNEXP_FLAGS=841;
var help260=842;
var help819_4=843;
var help357=844;
var _TCP=845;
var IPMSCHAP_CHALLENGE_RECVD=846;
var anet_msg_upnp=847;
var help776=848;
var KR49=849;
var help32=850;
var gw_gm_3=851;
var help823=852;
var _L2TPip=853;
var _reboot=854;
var wps_p3_1=855;
var wprn_intro5=856;
var _bsecure_security_serv=857;
var tsc_pingt_msg8=858;
var gw_gm_56=859;
var tf_intro_FWU=860;
var up_tz_57=861;
var GW_FW_NOTIFY_RESOLVED_DNS=862;
var af_EFT_2=863;
var up_tz_00=864;
var hhts_intro=865;
var _auth=866;
var IPL2TP_TUNNEL_DISCONNECTING=867;
var NET_RTC_SYNCHRONIZATION_FAILED_AFTER_RETRIES=868;
var sd_FWV=869;
var tsc_SchRuLs=870;
var KR58_ww=871;
var YM98=872;
var ta_SavConf=873;
var wwa_sdns=874;
var help876=875;
var help380=876;
var _netfilt=877;
var gw_days=878;
var li_Login=879;
var WAN_ALREADY_CONNECTED=880;
var bws_WPAM_3=881;
var GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS=882;
var GW_DYNDNS_PASSWORD_INVALID=883;
var tool_admin_vsname=884;
var up_tz_50=885;
var static_PPPoE=886;
var tsc_StrTime=887;
var tsc_pingt_msg104=888;
var wprn_iderr=889;
var wps_KR42=890;
var td_Timeout=891;
var _aa_apply_web_filter=892;
var resetUnconfiged=893;
var GAMING=894;
var tt_time_9=895;
var IPNAT_BLOCKED_INGRESS=896;
var GW_WAN_INTERFACE_UP=897;
var _ripaddr=898;
var sa_TimeOut=899;
var IPNAT_TCP_BLOCKED_EGRESS_BAD_SEQ=900;
var GW_LAN_INTERFACE_DOWN=901;
var help778=902;
var sps_qname=903;
var _seconds=904;
var GW_LOGS_CLEARED=905;
var sl_Warning=906;
var aa_MAC=907;
var wps_KR51=908;
var help274=909;
var aw_sgi_h1=910;
var IPSTACK_REJECTED_SOURCE_ROUTED_PACKET=911;
var wwa_pdns=912;
var help834=913;
var _Sun=914;
var sto_no_dev=915;
var wwz_auto_assign_key2=916;
var bwl_NSS=917;
var up_tz_15=918;
var help880=919;
var IPL2TP_TUNNEL_CONNECTING=920;
var bwn_mici_guest_use_shareport=921;
var NET_RTC_SYNCHRONIZED=922;
var up_tz_10=923;
var _on=924;
var NOT_LOGGED_IN_PLEASE_REFRESH=925;
var IPSEC_ALG_ESP_BLOCKED_INGRESS=926;
var ub_continue=927;
var td_UNK=928;
var IPPMVM_MOUNT_FAILED=929;
var gw_gm_42=930;
var _1066=931;
var tsc_AllWk=932;
var _virtserv=933;
var help2=934;
var help869=935;
var IPPPPLCP_SET_LOCAL_OPTIONS=936;
var ts_rd=937;
var IPSEC_ALG_REJECTED_PACKET=938;
var tsc_pingt_msg3=939;
var GW_WIRELESS_DEVICE_DISCONNECTED=940;
var sd_WRadio=941;
var ALLOWED_WEB_SITES=942;
var gw_sa_1=943;
var _UDP=944;
var help166=945;
var help117=946;
var bwn_L2TPICT=947;
var help795=948;
var _no=949;
var up_tz_63=950;
var tf_FWF1=951;
var up_tz_65=952;
var _priority=953;
var WAN_ALREADY_DISCONNECTED=954;
var up_jt_1=955;
var GW_INET_ACCESS_INITIAL_OTHERS=956;
var hhai_ip=957;
var as_intro_SA=958;
var tsc_pingt_mesg=959;
var up_tz_44=960;
var help27=961;
var as_IPSec=962;
var _admin=963;
var gw_gm_65=964;
var tf_intro_FWChB=965;
var BLOCKED=966;
var wwa_msg_bigpond=967;
var help857=968;
var help819_5=969;
var aw_TP_2=970;
var help385=971;
var _setupdone=972;
var li_intro=973;
var IPSMTPCLIENT_MSG_FAILED=974;
var bwz_note_ConWz=975;
var gw_gm_64=976;
var help268=977;
var NONE_BLOCKED=978;
var tt_May=979;
var bwn_BPICT=980;
var tt_time_15=981;
var _Tue=982;
var ss_clear_stats=983;
var help197=984;
var ai_intro_3=985;
var GW_WAN_DISCONNECT_ON_INACTIVE=986;
var DHCP_CLIENT_RELEASED_LEASE=987;
var wwa_set_sipa_title=988;
var up_tz_71=989;
var hhaf_alg=990;
var help843=991;
var wprn_tt11=992;
var _tstats=993;
var IPPPPLCP_SET_REMOTE_OPTIONS=994;
var tf_COLF=995;
var up_tz_28=996;
var tt_Mar=997;
var _aa_allow_all=998;
var wwa_wanmode_l2tp=999;
var _dmzh=1000;
var GW_TIME_RESOLVED_DNS=1001;
var bws_EAPx=1002;
var aa_PolName=1003;
var wwa_set_sipa_msg=1004;
var _aa_wiz_s2_title=1005;
var PPTP_EVENT_TUNNEL_CONNECTED=1006;
var USB_LOG_STORAGE_NOT_FOUND=1007;
var GW_INIT_DONE=1008;
var carriertype_ct_0=1009;
var help305=1010;
var tps_raw=1011;
var av_PubP=1012;
var help374=1013;
var PPTP_EVENT_TUNNEL_CLEAR_DOWN_REQUEST=1014;
var hhac_delete=1015;
var IPL2TP_SESSION_CLEAR_DOWN_REQUEST=1016;
var aa_ACR_c2=1017;
var help29=1018;
var up_tz_01=1019;
var _app=1020;
var bln_alert_1=1021;
var GW_WAN_RATE_ESTIMATOR_STARTED_ON_WAN=1022;
var sl_FWandSec=1023;
var hhan_ping=1024;
var sa_NAT=1025;
var help828=1026;
var GW_SMTP_EMAIL_FAILED_DNS=1027;
var help810=1028;
var _WOL=1029;
var bwn_RM_1=1030;
var help819_1=1031;
var IPNAT_TCP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1032;
var up_tz_14=1033;
var gw_gm_51=1034;
var td_SvAd=1035;
var hhag_40=1036;
var help169=1037;
var help324=1038;
var htsc_intro=1039;
var KR4_ww=1040;
var help317=1041;
var anet_multicast=1042;
var anet_multicast_v4=1043;
var anet_multicast_v6=1044;
var _aa_wiz_s1_title=1045;
var IPL2TP_SHUTDOWN_COMPLETE=1046;
var help819_7=1047;
var help9=1048;
var help809=1049;
var GW_LAN_CARRIER_DETECTED=1050;
var sl_alert_1=1051;
var as_TPRange_b=1052;
var tt_week_1=1053;
var up_jt_3=1054;
var _clear=1055;
var PPPOE_EVENT_DISCONNECT=1056;
var WIFISC_IR_REGISTRATION_FAIL_2=1057;
var _sdi_staticip=1058;
var hhts_name=1059;
var WAN=1060;
var help824=1061;
var hham_add=1062;
var ss_WANStats=1063;
var GW_WAN_CONNECT_ON_ACTIVE=1064;
var aa_sched_conf_1=1065;
var GW_INET_ACCESS_POLICY_END_OTHERS=1066;
var bd_title_list=1067;
var _aa_logging=1068;
var IPNAT_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1069;
var _username=1070;
var gw_gm_67=1071;
var GW_TIME_FAILED_DNS=1072;
var wprn_tt1=1073;
var tt_time_22=1074;
var help256=1075;
var GW_INET_ACCESS_INITIAL_IP_FAIL=1076;
var _aa_details=1077;
var help36=1078;
var help817=1079;
var bwn_Mode_PPPoE=1080;
var _allowall=1081;
var awf_clearlist=1082;
var sc_intro_rb3=1083;
var help67=1084;
var gw_gm_37=1085;
var aa_AT_2=1086;
var wwa_title_s1=1087;
var tps_drname=1088;
var tt_CopyTime=1089;
var IPL2TP_SEQUENCING_ACTIVATED=1090;
var bd_Reserve=1091;
var IPMSNMESSENGERALG_REJECTED_PACKET=1092;
var help782=1093;
var gw_gm_16=1094;
var IPPORTFORWARDALG_UDP_PACKET_ALLOC_FAILURE=1095;
var wprn_mod=1096;
var help119=1097;
var gw_gm_46=1098;
var am_FM_3=1099;
var sps_lpd1=1100;
var tss_SysSt=1101;
var ta_ResConf=1102;
var WCN_LOG_SAVE=1103;
var as_FPrt=1104;
var help823_11=1105;
var tsc_EvDay=1106;
var ham_del=1107;
var _PPPoE=1108;
var wwa_intro_online1=1109;
var tt_dstend=1110;
var tsc_SchRu=1111;
var GW_AUTH_FAILED=1112;
var _scheds=1113;
var up_tz_56=1114;
var _dns2=1115;
var _dns2_v6=1116;
var tsc_pingt_msg2=1117;
var tps_apc1=1118;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL_WITH_PORT=1119;
var up_tz_48=1120;
var _password_admin=1121;
var bd_intro_=1122;
var help387=1123;
var GW_AUTH_SUCCEEDED=1124;
var IPPPPCHAP_AUTH_SENT=1125;
var _bsecure_parental_blurb=1126;
var _aa_wiz_s1_msg=1127;
var help807=1128;
var up_tz_61=1129;
var _L2TPgw=1130;
var IPMSCHAP_AUTH_FAIL=1131;
var help395=1132;
var help888=1133;
var gw_gm_29=1134;
var help95=1135;
var aw_BP=1136;
var GW_WAN_SERVICES_STOPPED=1137;
var gw_gm_79=1138;
var help850=1139;
var help4=1140;
var up_tz_18=1141;
var help168a=1142;
var PPTP_ALG_REJECTED_PACKET=1143;
var te_SMTPSv=1144;
var gw_gm_84=1145;
var IPL2TP_LOW_RESOURCES=1146;
var hhac_add=1147;
var anet_wp_auto2=1148;
var as_RTSP=1149;
var _authsecmodel=1150;
var bwn_MTU=1151;
var gw_gm_72=1152;
var _WAN=1153;
var anet_multicast_enhanced=1154;
var gw_gm_8=1155;
var _WPA=1156;
var help897=1157;
var IPNAT_TCP_BLOCKED_INGRESS_BAD_SEQ=1158;
var tsc_pingt_msg7=1159;
var tt_Jan=1160;
var gw_gm_5=1161;
var _adwwls=1162;
var tsc_pingt_msg101=1163;
var gw_gm_55=1164;
var anet_wan_ping=1165;
var GW_DHCP_SERVER_WINS_INCOMPATIBILITY_WARNING=1166;
var bws_RMAA=1167;
var aa_wiz_s1_msg2=1168;
var tt_time_7=1169;
var help822a=1170;
var gw_gm_1=1171;
var up_tz_37=1172;
var bws_SM=1173;
var up_tz_68=1174;
var wwl_s4_intro_za3=1175;
var _prev=1176;
var sto_http_1=1177;
var wprn_foo1=1178;
var help355=1179;
var aa_ACR_c6=1180;
var bws_2RSSS=1181;
var help391=1182;
var _PM=1183;
var help174=1184;
var PPPOE_EVENT_DISCOVERY_TIMEOUT=1185;
var WCN_LOG_NO_WSETTING=1186;
var psPaperError=1187;
var anet_wan_ping_2=1188;
var help878=1189;
var LOGGED=1190;
var bwn_RM_2=1191;
var bws_RSSs=1192;
var up_tz_43=1193;
var IPRTSPALG_REJECTED_PACKET=1194;
var GW_SCHEDULES_IN_USE_INVALID_s2=1195;
var help1=1196;
var gw_gm_73=1197;
var hhtsn_intro=1198;
var _ping=1199;
var at_UpSp=1200;
var aa_wiz_s1_msg6=1201;
var _PPTPip=1202;
var help185=1203;
var help799=1204;
var up_tz_17=1205;
var sd_intro=1206;
var tf_Upload=1207;
var tt_Second=1208;
var wps_lost=1209;
var help26=1210;
var up_tz_35=1211;
var bwn_intro_ICS=1212;
var bwn_intro_ICS_3G=1213;
var bwn_intro_ICS_v6=1214;
var help81=1215;
var help833=1216;
var ss_Sent=1217;
var help378=1218;
var gw_gm_80=1219;
var _uploadgood=1220;
var KR38=1221;
var wprn_s3c=1222;
var haf_dmz_20=1223;
var ss_Received=1224;
var help263=1225;
var _bsecure_free_trial=1226;
var tf_FUNO=1227;
var aw_sgi=1228;
var help386=1229;
var help254_ict=1230;
var help254_ict_3G=1231;
var _aa_wiz_s5_msg1=1232;
var td_VPWK=1233;
var gw_gm_33=1234;
var gw_gm_0=1235;
var _macfilt=1236;
var TA16=1237;
var bd_DAB_note=1238;
var help796=1239;
var tf_really_FWF=1240;
var up_tz_05=1241;
var tt_time_16=1242;
var help861=1243;
var help19=1244;
var bwn_DWM=1245;
var _ICMP=1246;
var gw_gm_22=1247;
var help868=1248;
var IPV6_TEXT24=1249;
var tt_time_6=1250;
var _501_12=1251;
var hhac_en=1252;
var int_LWlsWz=1253;
var at_STR=1254;
var tt_Aug=1255;
var am_FM_4=1256;
var aa_wiz_s1_msg5=1257;
var ACCESS_CONTROL=1258;
var GW_DYNDNS_HERROR=1259;
var sps_ports=1260;
var help851=1261;
var hhag_20=1262;
var aa_alert_7=1263;
var af_DI=1264;
var tf_ADS=1265;
var tsc_pingt=1266;
var sl_VLevs=1267;
var wwl_enc=1268;
var help151=1269;
var hhta_pt=1270;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL=1271;
var te_EnAuth=1272;
var WIFISC_AP_PROXY_PROCESS_CLOSE=1273;
var bd_CName=1274;
var help305rt=1275;
var li_alert_3=1276;
var GW_DYNDNS_UPDATE_TO=1277;
var tt_week_4=1278;
var tt_Day=1279;
var GW_LAN_CARRIER_LOST=1280;
var hhai_action=1281;
var help121=1282;
var wwa_msg_set_pppoe=1283;
var IPNAT_ICMP_BLOCKED_INGRESS_PACKET=1284;
var tf_intro_FWU2=1285;
var at_ESE=1286;
var _bsecure_security_blurb=1287;
var bd_DHCP=1288;
var help865=1289;
var wwl_s4_intro_z1=1290;
var help501=1291;
var help280=1292;
var help775=1293;
var _connect=1294;
var GW_BIGPOND_INIT=1295;
var _always=1296;
var _minutes=1297;
var as_IPR_b=1298;
var _aa_bsecure_employment=1299;
var GW_INET_ACCESS_DROP_BAD_PKT=1300;
var gw_gm_12=1301;
var gw_gm_25=1302;
var help846=1303;
var tt_alert_1only=1304;
var gw_gm_76=1305;
var GW_LOGS_VIEWED=1306;
var bws_msg_EAP=1307;
var WIFISC_IR_REGISTRATION_INPROGRESS=1308;
var hhsa_intro=1309;
var help856=1310;
var sa_Dir=1311;
var _bln_title_IGMPMemberships=1312;
var bwn_Mode_L2TP=1313;
var _Thu=1314;
var KR30=1315;
var help184=1316;
var _worksbest=1317;
var _unavailable=1318;
var IPFAT_INCOMPATIBLE_FILESYS=1319;
var IPNAT_TCP_BLOCKED_INGRESS_NOT_SYN=1320;
var up_tz_04=1321;
var sl_ApplySt=1322;
var IPPPPCHAP_CHALLENGE_RECVD=1323;
var help141=1324;
var bd_Revoke=1325;
var wprn_intro3=1326;
var _conuptime=1327;
var wprn_tt4=1328;
var help383=1329;
var tsc_pingt_msg6=1330;
var help821a=1331;
var PPPOE_EVENT_SESSION_OFFER_RECVD=1332;
var gw_gm_30=1333;
var bi_man=1334;
var help60=1335;
var ta_RAP=1336;
var bwn_Mode_BigPond=1337;
var wprn_cps2=1338;
var tt_dststart=1339;
var help164_1=1340;
var IPMSCHAP_AUTH_TIMEOUT=1341;
var sl_emailLog=1342;
var bwl_title_1=1343;
var bwn_BPP=1344;
var sl_reload=1345;
var wwl_title_s1=1346;
var IPDRIVE_MOUNT_FAILED=1347;
var int_ConWz=1348;
var sto_permi=1349;
var help329=1350;
var IPL2TP_TUNNEL_DISCONNECTED=1351;
var help830=1352;
var help294=1353;
var up_tz_21=1354;
var tf_LFWD=1355;
var GW_BIGPOND_SUCCESS=1356;
var _denyall=1357;
var at_AC=1358;
var bwl_VS=1359;
var help327=1360;
var wprn_s2a=1361;
var td_=1362;
var PPTP_EVENT_TUNNEL_WINDOW_TIMEOUT=1363;
var aw_TP=1364;
var bwn_SIAICT=1365;
var help57=1366;
var tt_dsen2=1367;
var _sdi_s5=1368;
var wprn_man=1369;
var tt_time_3=1370;
var up_tz_20=1371;
var RIP_LOW_RESOURCES=1372;
var help266=1373;
var CONNECTED=1374;
var help265_5=1375;
var tsc_Days=1376;
var up_tz_13=1377;
var sd_General=1378;
var hhan_upnp=1379;
var help35=1380;
var help18=1381;
var bwz_psw=1382;
var tt_DaT=1383;
var help190=1384;
var help819_2=1385;
var bwn_MIT=1386;
var hhai_name=1387;
var te__title_EmLog=1388;
var up_tz_47=1389;
var IPSMTPCLIENT_DIALOG_FAILED=1390;
var hham_del=1391;
var wwa_msg_ispnot=1392;
var help808=1393;
var PPTP_EVENT_TUNNEL_ESTABLISH_REQUEST=1394;
var help37=1395;
var WCN_LOG_REBOOT=1396;
var PPTP_EVENT_TUNNEL_CONNECT_FAIL=1397;
var bwl_CWM=1398;
var up_tz_12=1399;
var _cancel=1400;
var IPV6_ULA_TEXT02=1401;
var af_ED=1402;
var up_tz_38=1403;
var aw_DI=1404;
var up_tz_31=1405;
var hhai_delete=1406;
var av_intro_vs=1407;
var av_intro_if=1408;
var GW_WAN_RECONNECT_ALWAYS_ON=1409;
var wwl_WSP=1410;
var INGRESS=1411;
var RESTRICTED=1412;
var bwn_msg_DHCPDesc=1413;
var help390=1414;
var KR58=1415;
var help867=1416;
var GW_WAN_CONNECT_ALWAYS_ON=1417;
var IPRTSPALG_REJECTED_ODD_RTP_PACKET=1418;
var help60f=1419;
var gw_gm_10=1420;
var bwn_min=1421;
var tt_Month=1422;
var tf_CFWD=1423;
var _advnetwork=1424;
var bwn_PPPOEICT=1425;
var help389=1426;
var help844=1427;
var tt_time_17=1428;
var help284=1429;
var GW_WIRELESS_DEVICE_ASSOCIATED=1430;
var bws_2RMAA=1431;
var as_SIP=1432;
var help704=1433;
var WIFISC_IR_REGISTRATION_FAIL_1=1434;
var up_tz_25=1435;
var help55=1436;
var GW_WLAN_LINK_UP=1437;
var bln_EnDNSRelay=1438;
var ai_title_IFR=1439;
var _PPTP=1440;
var _both=1441;
var up_tz_40=1442;
var wprn_tt8=1443;
var tps_dsr=1444;
var at_Prot_1=1445;
var help875=1446;
var awsf_p=1447;
var wwl_s4_intro_z2=1448;
var wwa_set_l2tp_msg=1449;
var up_tz_42=1450;
var _error=1451;
var aa_FPR_c4=1452;
var tt_EnNTP=1453;
var network_dhcp_ip_in_server=1454;
var tf_msg_wired=1455;
var wwa_title_set_pppoe=1456;
var help10=1457;
var bwl_CWM_h2=1458;
var help884=1459;
var rb_Rebooting=1460;
var help819_6=1461;
var tt_time_10=1462;
var help199=1463;
var help259=1464;
var af_algconfig=1465;
var wwa_msg_pptp=1466;
var bws_2RIPA=1467;
var _aa_wiz_s4_title=1468;
var wwa_note_svcn=1469;
var help85=1470;
var GW_INET_ACCESS_DROP_PORT_FILTER_WITH_PORT=1471;
var sd_BPSt=1472;
var up_tz_49=1473;
var gw_gm_62=1474;
var BIGPOND_LOGGED_OUT=1475;
var tf_EmNew=1476;
var GW_INET_ACCESS_INITIAL_MAC_FAIL=1477;
var help303=1478;
var wwa_selectisp_not=1479;
var IPNAT_TCP_BLOCKED_EGRESS_BAD_ACK=1480;
var help94=1481;
var gw_gm_70=1482;
var IPNAT_ICMP_UNABLE_TO_HANDLE_HEADER=1483;
var _FTP=1484;
var _neft=1485;
var ta_A12n=1486;
var GW_BIGPOND_LOGOUT=1487;
var help46=1488;
var hhsl_intro=1489;
var help770=1490;
var wwa_msg_set_pptp=1491;
var GW_FW_NOTIFY_FAILED_DNS=1492;
var gw_gm_40=1493;
var bln_IGMP_title_h=1494;
var hhaw_11d=1495;
var up_jt_2=1496;
var GW_INET_ACCESS_POLICY_START_MAC=1497;
var wwa_msg_pppoe=1498;
var help323=1499;
var ta_intro1=1500;
var tt_week_3=1501;
var _dhcpsrv=1502;
var Dynamic_PPPoE=1503;
var help102=1504;
var GW_DHCP_SERVER_WINS_MODE_INVALID=1505;
var help107=1506;
var gw_gm_69=1507;
var aa_ACR_c5=1508;
var help345=1509;
var hhav_name=1510;
var av_PriP=1511;
var tsc_pingt_msg103=1512;
var help_upnp_2=1513;
var WAN_MODE_INCORRECT=1514;
var wwl_alert_pv5_2_5=1515;
var _aa_wiz_s5_title=1516;
var KR22_ww=1517;
var _aa_wiz_s7_help=1518;
var IPL2TP_SEQUENCING_DEACTIVATED=1519;
var tps_apc=1520;
var up_tz_09=1521;
var tt_Jul=1522;
var GW_WAN_INTERFACE_DOWN=1523;
var WCN_LOG_RESTORE=1524;
var gw_gm_17=1525;
var GW_INET_ACCESS_INITIAL_IP=1526;
var _wizquit=1527;
var tss_intro=1528;
var help318=1529;
var tsl_intro=1530;
var tt_time_4=1531;
var tt_time_21=1532;
var IPL2TP_SESSION_CONNECTED=1533;
var aw_FT=1534;
var _save=1535;
var at_NEst=1536;
var af_EFT_h0=1537;
var _firmware=1538;
var gw_gm_43=1539;
var wps_messgae1_1=1540;
var IPL2TP_SHUTDOWN_STARTED=1541;
var ss_TXPD=1542;
var up_tz_55=1543;
var wwa_intro_online2=1544;
var help50=1545;
var help70=1546;
var help188_wmm=1547;
var bd_title_SDC=1548;
var up_tz_60=1549;
var gw_gm_54=1550;
var help396=1551;
var GW_ADMIN_LOGOUT=1552;
var gw_gm_44=1553;
var ta_EUPNP=1554;
var igmp_e_h=1555;
var help806=1556;
var dlink_wf_op_0=1557;
var help49=1558;
var help367=1559;
var gw_gm_28=1560;
var help337=1561;
var ta_AdmSt=1562;
var _syslog=1563;
var up_tz_08=1564;
var help394=1565;
var _aa_wiz_s7_title=1566;
var tt_intro_Time=1567;
var GW_DYNDNS_SERROR=1568;
var IPV6_TEXT105=1569;
var sps_port=1570;
var help164_2=1571;
var help881=1572;
var _destip=1573;
var help840=1574;
var wwa_l2tp_svra=1575;
var tt_dsdates=1576;
var help34b=1577;
var tt_time_11=1578;
var td_EnDDNS=1579;
var help786=1580;
var bwn_UN=1581;
var aa_alert_8=1582;
var wprn_tt2=1583;
var IPPPPLCP_SET_REMOTE_AUTH=1584;
var IPL2TP_FATAL_TIMEOUT=1585;
var hhaf_ngss=1586;
var bln_title_NetSt=1587;
var av_traftype=1588;
var bwn_Mode_PPTP=1589;
var help140=1590;
var wprn_rppd=1591;
var hhsd_intro=1592;
var IPMSCHAP_AUTH_SUCCESS=1593;
var help63=1594;
var ES_cable_lost_desc=1595;
var ap_intro_sv=1596;
var _L2TPsubnet=1597;
var GW_LOG_EMAIL_BEFORE_REBOOT=1598;
var at_Any=1599;
var help288=1600;
var bws_SM_h1=1601;
var help177=1602;
var up_tz_46=1603;
var rb_wait=1604;
var bwl_NN=1605;
var IPL2TP_SESSION_CONNECT_FAIL=1606;
var gw_gm_21=1607;
var wwl_BEST=1608;
var _support=1609;
var aa_alert_14=1610;
var _cablestate=1611;
var help314=1612;
var wps_LW13=1613;
var sl_Critical=1614;
var sc_intro_sv=1615;
var SYSTEM_LOG_INACTIVE=1616;
var bwn_mici=1617;
var gw_mins=1618;
var help852=1619;
var _In=1620;
var help870=1621;
var gw_gm_74=1622;
var help797=1623;
var gw_gm_39=1624;
var wwl_alert_pv5_3_10=1625;
var help149=1626;
var hhpt_intro=1627;
var GW_WAN_CARRIER_DETECTED=1628;
var bwn_BPU=1629;
var help195=1630;
var help823_1=1631;
var _internetc=1632;
var tsc_pingt_msg5=1633;
var help189a=1634;
var _trigger=1635;
var help783=1636;
var ub_intro_2=1637;
var hhta_pw=1638;
var _aa_wiz_s8_title=1639;
var help173=1640;
var help771=1641;
var tsl_SLSIPA=1642;
var _aa_wiz_s7_msg=1643;
var tt_time_13=1644;
var up_tz_67=1645;
var help289a=1646;
var BIGPOND_LOGGED_IN=1647;
var haf_dmz_10=1648;
var help819=1649;
var wprn_s3b=1650;
var sps_tcpport=1651;
var dlink_wf_intro=1652;
var _websfilter=1653;
var sd_BPSN=1654;
var _password_user=1655;
var GW_INET_ACCESS_POLICY_END_IP=1656;
var bwn_msg_Modes=1657;
var up_gX_1=1658;
var _next=1659;
var _setup=1660;
var htsc_pingt_s=1661;
var EMAIL=1662;
var _mode=1663;
var tt_Feb=1664;
var sps_raw1=1665;
var GW_DYNDNS_SUCCESS=1666;
var IPPORTFORWARDALG_TCP_PACKET_ALLOC_FAILURE=1667;
var IGMP_ROUTER_LOW_RESOURCES=1668;
var bwl_CWM_h1=1669;
var up_tz_39=1670;
var help40=1671;
var _pf=1672;
var IPNAT_UDP_UNABLE_TO_HANDLE_HEADER=1673;
var GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS_WARNING=1674;
var GW_INET_ACCESS_INITIAL_MAC=1675;
var IPPPPCHAP_AUTH_SUCCESS=1676;
var help187=1677;
var _aa_block_all=1678;
var GW_WLAN_LINK_DOWN=1679;
var help379=1680;
var up_tz_70=1681;
var IPNAT_ICMP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1682;
var GW_SCHEDULES_IN_USE_INVALID_s1=1683;
var fb_p_2=1684;
var sps_ps=1685;
var help47=1686;
var wwa_title_s4=1687;
var tt_time_18=1688;
var help860=1689;
var GW_UPNP_IGD_PORTMAP_RELEASE=1690;
var wwa_intro_s4=1691;
var help267=1692;
var IPL2TP_SESSION_ABORTED=1693;
var help874=1694;
var tt_Sep=1695;
var IPSEC_ALG_ESP_UNABLE_TO_HANDLE_HEADER=1696;
var bws_GKUI=1697;
var help80b=1698;
var help168c=1699;
var BIGPOND_LOGGING_IN=1700;
var wwa_wanmode_pptp=1701;
var help58=1702;
var ddns_connected=1703;
var ub_Upload_Failed=1704;
var WIFISC_AP_PROXY_END_ON_MSG=1705;
var help278=1706;
var KR18=1707;
var hhts_def=1708;
var help255=1709;
var bws_2RSP=1710;
var help7=1711;
var bwl_VS_0=1712;
var af_TEFT=1713;
var help86=1714;
var sd_NNSSID=1715;
var wt_p_2=1716;
var _gateway=1717;
var tt_CurTime=1718;
var _AM=1719;
var DISCONNECTED=1720;
var gw_gm_47=1721;
var up_tz_22=1722;
var WIFISC_IR_REGISTRATION_SESSION_OVERLAP=1723;
var _pwsame_admin=1724;
var GW_DYNDNS_UPDATE_IP=1725;
var GW_DHCPSERVER_NEW_ASSIGNMENT=1726;
var as_WM=1727;
var up_tz_03=1728;
var KR43=1729;
var YM177=1730;
var help774=1731;
var hhac_edit=1732;
var up_tz_36=1733;
var _hostname=1734;
var GW_INET_ACCESS_INITIAL_FAIL=1735;
var GW_WEB_FILTER_INITIAL_FAIL=1736;
var te_OnFull=1737;
var wwl_title_s4=1738;
var help281=1739;
var gw_gm_77=1740;
var _clonemac=1741;
var hhss_intro=1742;
var at_MUS=1743;
var hhan_wans=1744;
var YM141=1745;
var help382=1746;
var tsc_hrmin=1747;
var tsc_hrmin1=1748;
var help82=1749;
var gw_gm_24=1750;
var gw_gm_13=1751;
var aw_RT=1752;
var help340=1753;
var sd_WLAN=1754;
var help864=1755;
var tf_intro_FWU1=1756;
var wprn_bados=1757;
var _metric=1758;
var INBOUND_FILTER=1759;
var IPNAT_UDP_BLOCKED_INGRESS=1760;
var help351=1761;
var wwz_manual_key2=1762;
var _PPTPsubnet=1763;
var help20=1764;
var gw_gm_6=1765;
var bws_WPAM=1766;
var wwl_GOOD=1767;
var gw_gm_36=1768;
var help894=1769;
var _subnet=1770;
var PPTP_EVENT_REMOTE_WINDOW_SIZE=1771;
var wps_KR35=1772;
var help329_rsv=1773;
var gw_gm_58=1774;
var GW_WAN_MODE_IS=1775;
var ns_intro_=1776;
var IPDNSRELAYALG_REJECTED_PACKET=1777;
var ss_intro=1778;
var KR112=1779;
var GW_WLAN_11A_CH_MID_BAND_WARN=1780;
var ip_mac_binding_desc=1781;
var LW50=1782;
var GW_NAT_CONFLICTING_CONNECTIONS_LOG=1783;
var KR111=1784;
var KR109=1785;
var GW_NAT_CONFLICTING_CONNECTIONS_WARNING=1786;
var GW_PURE_SETACCESSPOINTMODE=1787;
var GW_NAT_REJECTED_SPOOFED_PACKET=1788;
var KR110=1789;
var GW_ROUTES_ROUTE_GATEWAY_NOT_IN_SUBNET_WARNING=1790;
var KR107=1791;
var KR105=1792;
var IPSTACK_REJECTED_LAND_ATTACK=1793;
var LS321=1794;
var KR67=1795;
var YM71=1796;
var GW_FIREWALL_RANGE_DUPLICATED_INVALID=1797;
var LS422=1798;
var bwz_LWCNWz=1799;
var GW_WAN_WAN_GATEWAY_IP_ADDRESS_INVALID=1800;
var ta_wcn=1801;
var LW57=1802;
var _wepkey2=1803;
var tsc_pingt_msg109=1804;
var bd_NETBIOS_REG_TYPE=1805;
var wps_messgae1_2=1806;
var LW60=1807;
var _rs_failed=1808;
var KR62=1809;
var KR20=1810;
var at_intro_2=1811;
var bd_NETBIOS_ENABLE=1812;
var KR77=1813;
var help364=1814;
var _aa_bsecure_shopping=1815;
var _aa_bsecure_public_proxies=1816;
var wepkey1=1817;
var ZM11=1818;
var tsc_start_time=1819;
var YM69=1820;
var KR82=1821;
var ss_intro_user=1822;
var GW_SCHEDULES_NAME_RESERVED_INVALID=1823;
var LW12=1824;
var YM75=1825;
var GW_ROUTES_GATEWAY_IP_ADDRESS_INVALID=1826;
var GW_WLAN_WPA_REKEY_TIME_INVALID=1827;
var bws_msg_WEP_1=1828;
var YM125=1829;
var _aa_bsecure_gambling=1830;
var KR14=1831;
var GW_SMTP_FROM_ADDRESS_INVALID=1832;
var KR89=1833;
var help106=1834;
var LW35=1835;
var YM151=1836;
var YM2=1837;
var ta_wcn_note=1838;
var YM131=1839;
var GW_WEB_SERVER_SAME_PORT_LAN=1840;
var KR25=1841;
var YM3=1842;
var GW_NAT_WOL_ALG_ACTIVATED_WARNING=1843;
var YM20=1844;
var YM86=1845;
var GW_WAN_MAC_ADDRESS_INVALID=1846;
var IPSMTPCLIENT_MSG_WRONG_RECEPIENT_ADDR_FORMAT=1847;
var YM146=1848;
var LS151=1849;
var GW_QOS_RULES_NAME_INVALID=1850;
var GW_NAT_VS_PROTO_CONFLICT_INVALID=1851;
var GW_WISH_RULES_NAME_INVALID=1852;
var WIFISC_IR_REGISTRATION_FAIL=1853;
var r_rlist=1854;
var IPV6_TEXT109=1855;
var bws_WKL_1=1856;
var help473=1857;
var aw_erpe=1858;
var GW_NAT_PORT_FORWARD_RANGE_BOTH_EMPTY_INVALID=1859;
var GW_ROUTES_GATEWAY_IP_ADDRESS_IN_SUBNET_INVALID=1860;
var LW37=1861;
var tsc_pingdisallowed=1862;
var ZM20=1863;
var help376=1864;
var GW_FW_NOTIFY_EMAIL_DISABLED_INVALID=1865;
var YM122=1866;
var GW_NAT_DMZ_CONFLICT_WITH_LAN_IP_INVALID=1867;
var _sdi_s7=1868;
var at_title_SESet=1869;
var GW_INET_ACL_START_PORT_INVALID=1870;
var IPSMTPCLIENT_DATA_FAILED=1871;
var KR91=1872;
var KR971=1873;
var tss_RestAll_b=1874;
var GW_NAT_PORT_TRIGGER_CONFLICT_INVALID=1875;
var LW54=1876;
var TA7=1877;
var KR74=1878;
var bws_DFWK=1879;
var LW46=1880;
var IPSMTPCLIENT_RESOLVED_DNS=1881;
var help110=1882;
var YM107=1883;
var YM180=1884;
var GW_WAN_WAN_SUBNET_INVALID=1885;
var GW_NAT_DMZ_DISABLED_WARNING=1886;
var YM93=1887;
var GW_NAT_FTP_ALG_ACTIVATED_WARNING=1888;
var _aa_bsecure_free_host=1889;
var _r_alert2=1890;
var LS47=1891;
var GW_DHCP_SERVER_SUBNET_SIZE_INVALID=1892;
var GW_INET_ACCESS_POLICY_TOO_MANY_MAC_INVALID=1893;
var GW_FIREWALL_START_IP_ADDRESS_INVALID=1894;
var YM8=1895;
var GW_WISH_RULES_PRIORITY_RANGE=1896;
var _aa_bsecure_travel=1897;
var help113=1898;
var ZM6=1899;
var bws_length=1900;
var help836=1901;
var rs_intro_2=1902;
var GW_INET_ACL_IP_ADDRESS_DUPLICATION_INVALID=1903;
var KR7=1904;
var ZM1=1905;
var hhta_831=1906;
var LW30=1907;
var YM110=1908;
var bd_NETBIOS_REG_TYPE_P=1909;
var GW_LAN_SUBNET_MASK_INVALID=1910;
var YM88=1911;
var GW_DHCP_SERVER_NETBIOS_PRIMARY_WINS_INVALID=1912;
var YM187=1913;
var GW_NAT_NAME_UNDEFINED_INVALID=1914;
var GW_WIRELESS_RADAR_DETECTED=1915;
var LW25=1916;
var _rs_invalid=1917;
var YM113=1918;
var LW65=1919;
var KR41=1920;
var GW_WAN_DNS_SERVER_PRIMARY_INVALID=1921;
var KR21=1922;
var help643=1923;
var KR63=1924;
var LW31=1925;
var GW_WAN_DNS_SERVER_SECONDARY_INVALID=1926;
var YM55=1927;
var KR37=1928;
var KR80=1929;
var YM100=1930;
var _wakeonlan=1931;
var rs_intro_3=1932;
var gw_gm_35=1933;
var YM7=1934;
var YM124g=1935;
var GW_INET_ACL_MAC_ADDRESS_DUPLICATION_INVALID=1936;
var YM66=1937;
var manul_conn_13=1938;
var bd_NETBIOS=1939;
var sa_Target=1940;
var help56_a=1941;
var GW_DHCP_SERVER_RECONFIG_WARNING=1942;
var _wifisc_addfail=1943;
var GW_WLAN_BEACON_PERIOD_INVALID=1944;
var YM79=1945;
var YM32=1946;
var ta_intro_wcn=1947;
var wwl_text_better=1948;
var YM78=1949;
var sd_channel=1950;
var KR53=1951;
var LW16=1952;
var GW_NAT_TCP=1953;
var help202=1954;
var CRIT=1955;
var YM154=1956;
var help76=1957;
var GW_WISH_RULES_HOST1_PORT=1958;
var GW_WLAN_11G_TURBO_INVALID=1959;
var _aa_bsecure_entertainment=1960;
var YM165=1961;
var help172=1962;
var _aa_bsecure_lifestyles=1963;
var GW_NAT_DMZ_NOT_IN_SUBNET_INVALID=1964;
var sd_TMode=1965;
var GW_NAT_PORT_FORWARD_PORT_RANGE_INVALID=1966;
var GW_QOS_RULES_LOCAL_IP_END_SUBNET=1967;
var bws_CT_2=1968;
var _bsecure_parental_limits=1969;
var aw_64=1970;
var _aa_bsecure_humor=1971;
var KR92=1972;
var KR13=1973;
var GW_INET_ACL_POLICY_NAME_DUPLICATE_INVALID=1974;
var YM136=1975;
var TA3=1976;
var help360=1977;
var YM10=1978;
var GW_WAN_PPTP_SERVER_IP_ADDRESS_INVALID=1979;
var YM150=1980;
var GW_DHCP_SERVER_RESERVATION_IN_USE=1981;
var GW_NAT_INPUT_PORT=1982;
var WIFISC_AP_REBOOT_COMPLETE=1983;
var YM182=1984;
var LW3=1985;
var YM116=1986;
var LW22=1987;
var OOPS=1988;
var YM158=1989;
var ZM16=1990;
var _aa_bsecure_select_age=1991;
var GW_ROUTES_DESTINATION_IP_ADDRESS_INVALID=1992;
var WIFISC_AP_RESET_COMPLETE=1993;
var bd_NETBIOS_REG=1994;
var GW_LAN_GATEWAY_IP_ADDRESS_INVALID=1995;
var KR96=1996;
var GW_XML_CONFIG_GET_SUCCESS=1997;
var GW_UPNP_IGD_PORTMAP_REFRESH=1998;
var bws_msg_WPA_2=1999;
var GW_LAN_IP_ADDRESS_INVALID=2000;
var KR5=2001;
var help88c=2002;
var GW_INET_ACL_SCHEDULE_NAME_INVALID=2003;
var GW_QOS_RULES_REMOTE_PORT=2004;
var GW_NAT_IP_ADDRESS_INVALID=2005;
var help369=2006;
var help48a=2007;
var LW38=2008;
var GW_DYNDNS_USER_NAME_INVALID=2009;
var hhav_r_dest_ip=2010;
var YM175=2011;
var LY3=2012;
var GW_UPNP_IGD_PORTMAP_ADD=2013;
var GW_UPNP_IGD_PORTMAP_CONFLICT=2014;
var KRA1=2015;
var _vs_port=2016;
var GW_INET_ACL_RECONFIGURED_WARNING=2017;
var help186=2018;
var YM145=2019;
var WIFISC_AP_UNSET_SELECTED_REGISTRAR=2020;
var GW_WAN_DNS_SERVER_SECONDARY_WITHOUT_PRIMARY_INVALID=2021;
var YM72=2022;
var _hints=2023;
var GW_QOS_RULES_LOCAL_PORT=2024;
var YM52=2025;
var _aa_bsecure_chat=2026;
var help104=2027;
var help839=2028;
var YM99=2029;
var _aa_bsecure_byage=2030;
var GW_INET_ACL_NAME_DUPLICATE_INVALID=2031;
var GW_DHCP_SERVER_POOL_TO_INVALID=2032;
var KR26=2033;
var YM92=2034;
var GW_DHCP_SERVER_RESERVED_IP_INVALID=2035;
var help19x1=2036;
var _aa_bsecure_unstable=2037;
var GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID=2038;
var GW_FIREWALL_FILTER_NAME_INVALID=2039;
var ZM19=2040;
var YM80=2041;
var bd_NETBIOS_WINS_2=2042;
var KR57=2043;
var YM164=2044;
var _logsyslog_alert2=2045;
var YM149=2046;
var LT120=2047;
var KR48=2048;
var GW_WAN_RECONNECT_INTERVAL_INVALID=2049;
var YM139=2050;
var YM61=2051;
var GW_NAT_VIRTUAL_SERVER_TABLE_RECONFIGURED_WARNING=2052;
var YM1=2053;
var bws_WKL=2054;
var wps_p3_2=2055;
var KR102=2056;
var GW_QOS_RULES_LOCAL_IP_START_SUBNET=2057;
var GW_WAN_PPTP_IP_ADDRESS_INVALID=2058;
var _aa_bsecure_alcohol=2059;
var YM14=2060;
var GW_WLAN_11B_DYNAMIC_TURBO_INVALID=2061;
var GW_UPNP_IGD_PORTMAP_EXPIRE=2062;
var TA18=2063;
var aw_erpe_h2=2064;
var YM21=2065;
var YM147=2066;
var KR68=2067;
var LW61=2068;
var GW_WAN_L2TP_USERNAME_INVALID=2069;
var LT120z=2070;
var KR97=2071;
var GW_WAN_L2TP_SUBNET_INVALID=2072;
var help_ts_ss=2073;
var _aa_bsecure_automobile=2074;
var LW13=2075;
var sch_time=2076;
var bws_intro_WlsSec=2077;
var GW_WAN_PPPOE_PASSWORD_INVALID=2078;
var help211=2079;
var LS202=2080;
var tsc_EndTime=2081;
var KR34=2082;
var _wepkey3=2083;
var at_RePortR=2084;
var help640=2085;
var GW_SMTP_SERVER_ADDRESS_INVALID=2086;
var GW_WAN_L2TP_GATEWAY_IP_ADDRESS_INVALID=2087;
var LW58=2088;
var LW22usekey=2089;
var GW_WLAN_11B_STATIC_TURBO_INVALID=2090;
var YM67=2091;
var GW_WIFISC_CFG_CHANGED_WARNING=2092;
var ZM10=2093;
var GW_WLAN_11A_CHANNEL_INVALID=2094;
var at_title_SERules=2095;
var YM176=2096;
var KR81=2097;
var GW_NAT_TCP_PORT=2098;
var YM155=2099;
var help365=2100;
var bd_NETBIOS_SCOPE=2101;
var KR28=2102;
var _webfilter=2103;
var YM33=2104;
var YM76=2105;
var WIFISC_AP_SETUP_UNLOCKED=2106;
var GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=2107;
var LS313=2108;
var bwz_WCNWz=2109;
var ZM9=2110;
var GW_DHCP_SERVER_RESERVED_MAC_UNIQUENESS_INVALID=2111;
var LY5=2112;
var YM87=2113;
var GW_NAT_WAN_PING_FILTER_INVALID=2114;
var help835=2115;
var at_lowpriority=2116;
var YM49=2117;
var GW_INET_ACCESS_POLICY_TOO_MANY_IP_INVALID=2118;
var YM112=2119;
var KR90=2120;
var help838=2121;
var help892=2122;
var KR73=2123;
var wwl_intro_s3_2=2124;
var _r_alert5=2125;
var GW_NAT_WAN_PING_FILTER_WARNING=2126;
var YM53=2127;
var help215=2128;
var YM140=2129;
var GW_DHCPSERVER_REJECTED=2130;
var YM142=2131;
var GW_SMTP_PASSWORD_INVALID=2132;
var YM152=2133;
var LT119a=2134;
var LW36=2135;
var help377=2136;
var GW_NAT_PORT_TRIGGER_PORT_RANGE_INVALID=2137;
var YM121=2138;
var YM29=2139;
var YM159=2140;
var YM120=2141;
var wwl_BETTER=2142;
var hhaf_dmz=2143;
var YM106=2144;
var _aa_bsecure_block_unrated=2145;
var GW_WAN_BIGPOND_USERNAME_INVALID=2146;
var KR76=2147;
var GW_DHCPSERVER_EXHAUSTED=2148;
var GW_WAN_L2TP_SERVER_IP_ADDRESS_INVALID=2149;
var wwl_alert_pv5_2=2150;
var GW_ROUTES_SUBNET_INVALID=2151;
var _aa_bsecure_drugs=2152;
var LW1=2153;
var GW_DHCPSERVER_EXPIRED=2154;
var GW_INET_ACL_IP_ADDRESS_IN_LAN_SUBNET_INVALID=2155;
var bd_NETBIOS_REG_TYPE_B=2156;
var _aa_bsecure_financial=2157;
var YM135=2158;
var LT119=2159;
var _vs_public=2160;
var KR93=2161;
var GW_SECURE_REMOTE_ADMINSTRATION=2162;
var YM160=2163;
var LS423=2164;
var GW_WAN_L2TP_GATEWAY_IN_SUBNET_INVALID=2165;
var GW_WISH_RULES_HOST1_IP=2166;
var _vs_private=2167;
var KR86=2168;
var bd_NETBIOS_SEC_WINS=2169;
var GW_INET_ACL_START_IP_ADDRESS_INVALID=2170;
var auth=2171;
var KR24=2172;
var KR17=2173;
var YM84=2174;
var help88=2175;
var hhta_en=2176;
var YM103=2177;
var KR64=2178;
var GW_WLAN_11A_DFS_CHANNEL_INVALID=2179;
var LW4=2180;
var help645=2181;
var GW_WLAN_11A_STATIC_TURBO_INVALID=2182;
var help358=2183;
var YM6=2184;
var _aa_bsecure_categ_select=2185;
var YM58=2186;
var _aa_bsecure_age_youth=2187;
var LW17=2188;
var YM18=2189;
var LT210=2190;
var GW_WAN_IDLE_TIME_INVALID=2191;
var YM186=2192;
var _aa_bsecure_sports=2193;
var GW_QOS_RULES_NAME_ALREADY_USED=2194;
var bwz_intro_WCNWz=2195;
var GW_DHCP_SERVER_POOL_TO_IN_SUBNET_INVALID=2196;
var GW_NAT_H323_ALG_ACTIVATED_WARNING=2197;
var KR4=2198;
var LT120y=2199;
var KR103=2200;
var YM44=2201;
var LW47=2202;
var GW_XML_CONFIG_GET_FAILED=2203;
var WIFISC_AP_SET_APSETTINGS_COMPLETE=2204;
var wwl_WKL=2205;
var YM168=2206;
var GW_NAT_NAME_USED_INVALID=2207;
var GW_DYNDNS_SERVER_INDEX_VALUE_INVALID=2208;
var WARN=2209;
var LW23=2210;
var ADVANCED_NETWORK=2211;
var GW_WAN_PPTP_PASSWORD_INVALID=2212;
var LW59=2213;
var YM126=2214;
var _enabled=2215;
var _r_alert4=2216;
var LY10=2217;
var GW_DHCP_SERVER_POOL_FROM_INVALID=2218;
var WIFISC_AP_SETUP_LOCKED=2219;
var YM91=2220;
var WIFISC_AP_SET_SELECTED_REGISTRAR_FAIL=2221;
var _ask_nochange=2222;
var GW_NAT_UNKNOWN=2223;
var GW_WLAN_11A_DYNAMIC_TURBO_INVALID=2224;
var YM163=2225;
var YM181=2226;
var _cantapplysettings_1=2227;
var YM11=2228;
var wwl_wsp_chars_2=2229;
var bd_NETBIOS_PRI_WINS=2230;
var wwl_DWKL=2231;
var KR44=2232;
var TEXT056=2233;
var YM130=2234;
var KR99=2235;
var GW_DHCP_SERVER_PRIMARY_AND_SECONDARY_WINS_IP_INVALID=2236;
var KR106=2237;
var GW_NAT_VS_PROTOCOL_INVALID=2238;
var KR52=2239;
var KR33=2240;
var ZM23=2241;
var LW40=2242;
var LY4=2243;
var LW34=2244;
var YM25=2245;
var YM15=2246;
var bwl_SGM=2247;
var GW_WLAN_80211X_RADIUS_INVALID=2248;
var GW_WISH_RULES_PROTOCOL=2249;
var LS316=2250;
var ZM15=2251;
var GW_DHCP_SERVER_RESERVATION_DISABLED_IN_CONFLICT_WARNING=2252;
var GW_DYNDNS_HOST_NAME_INVALID=2253;
var LW42=2254;
var GW_WAN_PPTP_GATEWAY_IP_ADDRESS_INVALID=2255;
var rs_intro_4=2256;
var GW_QOS_RULES_REMOTE_IP_END_SUBNET=2257;
var _NA=2258;
var hhav_r_gateway=2259;
var INFO=2260;
var help112=2261;
var tf_msg_FWUgReset=2262;
var bd_NETBIOS_WAN=2263;
var aw_igslot=2264;
var ZM2=2265;
var LT7=2266;
var WIFISC_AP_SET_SELECTED_REGISTRAR=2267;
var help214=2268;
var at_Both=2269;
var ZM22=2270;
var help_ts_rfd=2271;
var help209=2272;
var YM70=2273;
var GW_UPNP_IGD_PORTMAP_VS_CHANGE=2274;
var help143s=2275;
var help363=2276;
var _aa_bsecure_web_newsgroup=2277;
var YM128=2278;
var GW_NAT_PORT_TRIGGER_PORT_RANGE_EMPTY_INVALID=2279;
var KR72=2280;
var td_PWK=2281;
var YM82=2282;
var YM119=2283;
var KR70=2284;
var YM161=2285;
var GW_DHCP_SERVER_POOL_SIZE_INVALID=2286;
var _sdi_s4b=2287;
var ZM8=2288;
var YM129=2289;
var help370=2290;
var LY29=2291;
var GW_XML_CONFIG_WRITE_WARN=2292;
var GW_FIREWALL_NAME_INVALID=2293;
var GW_WISH_RULES_HOST2_IP=2294;
var TA2=2295;
var LS314=2296;
var _vs_traffictype=2297;
var GW_DYNDNS_TIMEOUT_TOO_BIG_INVALID=2298;
var wps_p3_4=2299;
var KR51=2300;
var GW_WAN_PPTP_GATEWAY_IN_SUBNET_INVALID=2301;
var help837=2302;
var TEXT052=2303;
var OPEN=2304;
var _aa_bsecure_news=2305;
var YM34=2306;
var _advwls=2307;
var GW_DHCP_SERVER_RESERVATION_DISABLED_OUT_OF_POOL_WARNING=2308;
var GW_MAC_FILTER_ALL_LOCKED_OUT_INVALID=2309;
var _wepkey4=2310;
var LT124=2311;
var _aa_bsecure_search_engine=2312;
var KR47=2313;
var bws_msg_WEP_3=2314;
var GW_SMTP_LAN_ADDRESS_CONFLICT_WARNING=2315;
var GW_LAN_IP_MODE_INVALID=2316;
var GW_WAN_BIGPOND_SERVER_NOTSTD15=2317;
var GW_WLAN_FRAGMENT_THRESHOLD_INVALID=2318;
var GW_LAN_DOMAIN_NAME_INVALID=2319;
var GW_LAN_DEVICE_NAME_INVALID=2320;
var _wifisc_overlap=2321;
var LW62=2322;
var KR23=2323;
var _aa_bsecure_pornography=2324;
var GW_NAT_NAME_INVALID=2325;
var bd_title_clients=2326;
var YM108=2327;
var YM19=2328;
var WIFISC_AP_PROXY_PROCESS_COMPLETE=2329;
var GW_NAT_ENTRY_DUPLICATED_INVALID=2330;
var GW_NAT_PORT_FORWARD_CONFLICT_INVALID=2331;
var YM38=2332;
var tt_alert_nontp=2333;
var LY2=2334;
var KR29=2335;
var KR31=2336;
var _init_fail=2337;
var YM68=2338;
var sd_macaddr=2339;
var KR12=2340;
var help366=2341;
var WIFISC_AP_REGISTRATION_COMPLETE=2342;
var aw_TPC=2343;
var aw_WDSMAC=2344;
var YM62=2345;
var aw_erpe_h=2346;
var GW_WAN_RECONNECT_MODE_INVALID=2347;
var WIFISC_AP_DEL_APSETTINGS_COMPLETE=2348;
var LW15=2349;
var LW33=2350;
var KR27=2351;
var YM138=2352;
var GW_NAT_VS_PORT_CONFLICT_INVALID=2353;
var bd_NETBIOS_WINS_1=2354;
var _aa_wiz_s6_title=2355;
var YM77=2356;
var YM48=2357;
var YM89=2358;
var GW_WLAN_WPA_PSK_HEX_STRING_INVALID=2359;
var GW_WAN_WAN_IP_ADDRESS_INVALID=2360;
var LS4=2361;
var KR98=2362;
var YM148=2363;
var bws_WPAM_2=2364;
var help877a=2365;
var KR56=2366;
var LS424=2367;
var GW_DHCPSERVER_DECLINED=2368;
var GW_SCHEDULES_DAY_INVALID=2369;
var GW_NAT_UDP=2370;
var IPSMTPCLIENT_CANNOT_CREATE_CONNECTION=2371;
var _aa_check_all=2372;
var LS312=2373;
var KR2=2374;
var _vs_proto=2375;
var GW_SMTP_TO_ADDRESS_INVALID=2376;
var WIFISC_AP_REGISTRATION_FAIL=2377;
var GW_WISH_RULES_NAME_ALREADY_USED=2378;
var LW48=2379;
var YM54=2380;
var LW9=2381;
var LW41=2382;
var ebwl_AChan=2383;
var GW_WLAN_RTS_THRESHOLD_INVALID=2384;
var GW_WAN_L2TP_PASSWORD_INVALID=2385;
var YM12=2386;
var ZM14=2387;
var KR60=2388;
var YM28=2389;
var YM184=2390;
var int_intro_WCNWz7=2391;
var bws_Auth_2=2392;
var rs_intro_1=2393;
var help92=2394;
var GW_NAT_BOTH=2395;
var rs_success=2396;
var up_tz_29b=2397;
var day=2398;
var GW_DHCP_SERVER_DISABLED_WARNING=2399;
var _password=2400;
var GW_INET_ACCESS_POLICY_MAC_INVALID=2401;
var LW2=2402;
var KR75=2403;
var GW_XML_CONFIG_WRITE_FAILED=2404;
var YM73=2405;
var GW_WISH_RULES_NAME_USED_INVALID=2406;
var GW_DHCP_SERVER_POOL_SIZE_IN_SUBNET_INVALID=2407;
var aw_AS=2408;
var YM171=2409;
var GW_DHCP_SERVER_RESERVED_IP_NOT_LAN_IP_INVALID=2410;
var GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT=2411;
var hhav_r_netmask=2412;
var vs_vslist=2413;
var if_iflist=2414;
var YM137=2415;
var YM74=2416;
var GW_SYSLOG_ADDRESS_IN_SUBNET_INVALID=2417;
var help858=2418;
var GW_MAC_FILTER_MAC_UNIQUENESS_INVALID=2419;
var KR40=2420;
var GW_MAC_FILTER_NULL_MAC_INVALID=2421;
var aw_32=2422;
var GW_WAN_LAN_SUBNET_CONFLICT_INVALID=2423;
var LW66=2424;
var WIFISC_AP_DEL_APSETTINGS_FAIL=2425;
var wwl_wsp_chars_1=2426;
var KR85=2427;
var YM115=2428;
var YM83=2429;
var wwl_128bits=2430;
var LW51=2431;
var YM178=2432;
var _aa_bsecure_cults=2433;
var YM5=2434;
var KR65=2435;
var ZM17=2436;
var LW14=2437;
var ta_wcn_bv=2438;
var GW_NAT_VS_IP_ADDRESS_CAN_NOT_MATCH_ROUTER=2439;
var GW_SCHEDULES_IN_USE_INVALID=2440;
var wepkey3=2441;
var KR69=2442;
var YM43=2443;
var YM45=2444;
var GW_SMTP_USERNAME_INVALID=2445;
var help362=2446;
var tf_intro_FWChA=2447;
var _remotedesktop=2448;
var LW7=2449;
var help359=2450;
var KR84=2451;
var YM30=2452;
var at_LoPortR=2453;
var GW_DHCP_SERVER_POOL_FROM_IN_SUBNET_INVALID=2454;
var GW_MAC_FILTER_MULTICAST_MAC_INVALID=2455;
var GW_SMTP_INIT_FAILED_WARNING=2456;
var GW_DHCPSERVER_STOP=2457;
var help350=2458;
var GW_NAT_DMZ_NOT_ALLOWED_INVALID=2459;
var YM143=2460;
var GW_XML_CONFIG_SET_FAILED=2461;
var GW_NAT_PORT_DUP_INVALID=2462;
var KR46=2463;
var KR35=2464;
var GW_WAN_BIGPOND_PASSWORD_INVALID=2465;
var YM57=2466;
var KR104=2467;
var IPSMTPCLIENT_MSG_WRONG_SENDER_ADDR_FORMAT=2468;
var LS317=2469;
var YM102=2470;
var help188=2471;
var _logsyslog_alert1=2472;
var KR3=2473;
var _aa_bsecure_hate=2474;
var GW_WLAN_11BG_CHANNEL_INVALID=2475;
var RATE_ESTIMATOR_RATE_COMPLETED=2476;
var wwl_alert_pv5_3=2477;
var aw_aggr=2478;
var _wifisc_addstart=2479;
var help111=2480;
var GW_QOS_RULES_REMOTE_IP_START_SUBNET=2481;
var YM22=2482;
var GW_WLAN_WDS_MAC_ADDR_INVALID=2483;
var LW10=2484;
var LT291=2485;
var YM156=2486;
var _aa_bsecure_age_ado=2487;
var wwl_text_good=2488;
var GW_QOS_RULES_PRIORITY_RANGE=2489;
var te_OnSch=2490;
var _aa_bsecure_web_mail=2491;
var help188b=2492;
var GW_INET_ACL_START_IP_ADDRESS_IN_LAN_SUBNET_INVALID=2493;
var at_title_Traff=2494;
var help189=2495;
var GW_WIRELESS_SWITCH_CHANNEL=2496;
var GW_WAN_BIGPOND_SERVER_INVALID=2497;
var GW_XML_CONFIG_SET_PARSE=2498;
var hhaw_wmm=2499;
var LT290wifisc=2500;
var GW_FIREWALL_RULE_NAME_INVALID=2501;
var GW_NAT_SCHEDULE=2502;
var help109=2503;
var GW_LAN_RIP_MODE_INVALID=2504;
var LW52=2505;
var _aa_bsecure_popups=2506;
var GW_WLAN_WPA_WPA2_TKIP_INVALID=2507;
var KR16=2508;
var _vs_title=2509;
var _if_title=2510;
var GW_WAN_PPPOE_USERNAME_INVALID=2511;
var GW_WAN_PPTP_SUBNET_INVALID=2512;
var GW_DHCP_SERVER_NETBIOS_SCOPE_INVALID=2513;
var KR94=2514;
var YM63=2515;
var help108=2516;
var GW_SCHEDULES_DUPLICATED_INVALID=2517;
var bws_WPAM_1=2518;
var KR11=2519;
var LW45=2520;
var KR6=2521;
var GW_DHCP_SERVER_NETBIOS_TYPE_INVALID=2522;
var _aa_bsecure_games=2523;
var KR42=2524;
var YM104=2525;
var _aa_bsecure_tickets=2526;
var KR39=2527;
var bd_NETBIOS_REG_TYPE_M=2528;
var tsc_pingt_msg1=2529;
var GW_UPNP_IGD_PORTMAP_DEL=2530;
var YM111=2531;
var LS315=2532;
var GW_WLAN_WPA_PSK_LEN_INVALID=2533;
var help178=2534;
var YM167=2535;
var help371=2536;
var _aa_bsecure_anarchy=2537;
var YM4=2538;
var _aa_bsecure_criminal_skills=2539;
var YM188=2540;
var YM133=2541;
var YM59=2542;
var _aa_bsecure_manually=2543;
var YM169=2544;
var YM97=2545;
var _aa_bsecure_age_child=2546;
var help375=2547;
var GW_WEB_FILTER_WEBSITE_INVALID_INVALID=2548;
var ZM21=2549;
var YM157=2550;
var help213=2551;
var YM24=2552;
var wps_p3_3=2553;
var LW43=2554;
var help99_s=2555;
var YM90=2556;
var bws_CT_3=2557;
var help371_n=2558;
var GW_DHCP_SERVER_RESERVATION_RECONFIG_WARNING=2559;
var _r_alert3=2560;
var GW_LAN_RIP_METRIC_INVALID=2561;
var YM118=2562;
var YM127=2563;
var KR71=2564;
var aw_WDSEn=2565;
var KR32=2566;
var sa_Local=2567;
var GW_WEB_SERVER_IDLE_TIME=2568;
var KR59=2569;
var GW_WAN_WAN_GATEWAY_IN_SUBNET_INVALID=2570;
var at_LoIPR=2571;
var YM81=2572;
var aw_AP=2573;
var LT290=2574;
var YM162=2575;
var GW_XML_CONFIG_SET_PARSE_MIME=2576;
var GW_NAT_UDP_PORT=2577;
var YM9=2578;
var GW_WAN_MTU_INVALID=2579;
var LW63=2580;
var WIFISC_IR_REGISTRATION_SUCCESS=2581;
var help105=2582;
var GW_DHCPSERVER_RELEASED=2583;
var LW32=2584;
var WIFISC_AP_SET_APSETTINGS_FAIL=2585;
var KR8=2586;
var hhav_r_name=2587;
var bd_NETBIOS_REG_TYPE_H=2588;
var KR55=2589;
var GW_WAN_PPPOE_LAN_SUBNET_CONFLICT_INVALID=2590;
var GW_XML_CONFIG_SET_SUCCESS=2591;
var YM60=2592;
var KR100=2593;
var KR61=2594;
var bws_WKL_0=2595;
var bws_msg_WPA=2596;
var YM109=2597;
var WIFISC_AP_RESET_FAIL=2598;
var GW_WISH_RULES_HOST2_PORT=2599;
var help_ts_ls=2600;
var YM101=2601;
var KR50=2602;
var YM56=2603;
var aa_WebSite_Domain=2604;
var GW_QOS_RULES_MAX_TRANS=2605;
var GW_QOS_RULES_PROTOCOL=2606;
var GW_WEB_SERVER_NO_ACCESS=2607;
var KR87=2608;
var GW_WISH_RULES_DUPLICATED=2609;
var YM16=2610;
var GW_SCHEDULES_NAME_CONFLICT_INVALID=2611;
var wepkey4=2612;
var GW_WEB_SERVER_SAME_PORT_WAN=2613;
var YM65=2614;
var bln_title=2615;
var WIFISC_AP_PROXY_PROCESS_FAIL=2616;
var _more=2617;
var ZM12=2618;
var _aa_bsecure_banner_ad=2619;
var LY23=2620;
var help88b=2621;
var bwl_NSS_h1=2622;
var help203=2623;
var GW_INET_ACL_NO_MACHINE_IN_LAN_SUBNET_INVALID=2624;
var LW39c=2625;
var WIFISC_AP_SET_SELECTED_REGISTRAR_COMPLETE=2626;
var GW_DHCP_CLIENT_CLIENT_NAME_INVALID=2627;
var YM166=2628;
var WIFISC_AP_REBOOT_FAIL=2629;
var help91=2630;
var LW39=2631;
var YM173=2632;
var YM13=2633;
var YM172=2634;
var YM31=2635;
var _aa_wiz_s6_msg=2636;
var S493=2637;
var YM85=2638;
var GW_SCHEDULES_NAME_INVALID=2639;
var LS204=2640;
var aw_16=2641;
var aw_erpe_h3=2642;
var LW64=2643;
var _days=2644;
var help103=2645;
var YM183=2646;
var YM117=2647;
var KR54=2648;
var av_intro_r=2649;
var help368=2650;
var hhav_enable=2651;
var GW_WAN_DNS_SERVERS_INVALID=2652;
var _rs_succeeded=2653;
var GW_WAN_PPTP_USERNAME_INVALID=2654;
var GW_WAN_L2TP_IP_ADDRESS_INVALID=2655;
var GW_INET_ACL_NAME_INVALID=2656;
var days=2657;
var KR88=2658;
var GW_WAN_PPPOE_IP_ADDRESS_INVALID=2659;
var KR19=2660;
var RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED=2661;
var YM27=2662;
var LT291wifisc=2663;
var KR1=2664;
var YM51=2665;
var ZM13=2666;
var GW_LAN_PRIMARY_DNS_INVALID=2667;
var GW_WLAN_11A_DFS_TURBO_INVALID=2668;
var YM123=2669;
var TA8=2670;
var KR9=2671;
var KR79=2672;
var GW_QOS_RULES_REMOTE_IP=2673;
var _aa_bsecure_age_adult=2674;
var ZM7=2675;
var YM23=2676;
var tf_USSW=2677;
var LW55=2678;
var bwl_EW=2679;
var LS425=2680;
var wwl_WK=2681;
var LW11=2682;
var GW_NAT_PPTP_ALG_ACTIVATED_WARNING=2683;
var YM35=2684;
var tsc_sel_days=2685;
var sc_intro_rb4=2686;
var GW_SCHEDULES_TIME_INVALID=2687;
var GW_DHCP_SERVER_LEASE_TIME_INVALID=2688;
var IPSMTPCLIENT_NO_SERVER_IP_ADDRESS=2689;
var KR10=2690;
var GW_WEB_FILTER_HTTPS_NOT_SUPPORTED_INVALID=2691;
var KR22=2692;
var _vs_both=2693;
var wwl_alert_pv5_4=2694;
var GW_WIFISC_LOCK_VERIFY_ERR=2695;
var LW53=2696;
var GW_WEB_FILTER_WEB_SITE_IS_USED_INVALID=2697;
var YM64=2698;
var GW_ROUTES_INTERFACE_INVALID=2699;
var GW_LAN_SECONDARY_DNS_INVALID=2700;
var bd_NETBIOS_LEARN_FROM_WAN_ENABLE=2701;
var GW_NAT_PORT_FORWARDING_TABLE_RECONFIGURED_WARNING=2702;
var KR15=2703;
var WIFISC_AP_REGISTRATION_UNEXPECTED_EVENT=2704;
var GW_SYSLOG_ADDRESS_NOT_IN_SUBNET_WARNING=2705;
var GW_DHCP_SERVER_NETBIOS_SECONDARY_WINS_INVALID=2706;
var LW49=2707;
var KR95=2708;
var aw_8=2709;
var YM114=2710;
var bws_CT=2711;
var _aa_bsecure_rrated=2712;
var LW6=2713;
var bws_msg_WEP_2=2714;
var GW_QOS_RULES_LOCAL_IP=2715;
var GW_DHCP_SERVER_POOL_FROM_TO_ORIENTATION_INVALID=2716;
var bws_CT_1=2717;
var GW_XML_CONFIG_SET_LOCK=2718;
var GW_DHCP_SERVER_RESERVED_IP_UNIQUENESS_INVALID=2719;
var wepkey2=2720;
var LW28=2721;
var _wepkey1=2722;
var KR83=2723;
var GW_SYSLOG_ADDRESS_INVALID=2724;
var YM105=2725;
var ZM5=2726;
var help212=2727;
var wps_p3_5=2728;
var help19x2=2729;
var KR36=2730;
var GW_ROUTES_METRIC_INVALID=2731;
var GW_WLAN_SSID_INVALID=2732;
var LS46=2733;
var YM179=2734;
var KR78=2735;
var KR66=2736;
var _aa_bsecure_magazine=2737;
var KR101=2738;
var GW_WLAN_WPA_WPA_AES_INVALID=2739;
var GW_NAT_INBOUND_FILTER=2740;
var GW_INET_ACL_POLICY_NAME_INVALID=2741;
var sa_Internet=2742;
var help406=2743;
var YM153=2744;
var at_ReIPR=2745;
var GW_INET_ACCESS_RESTRICTED=2746;
var GW_WLAN_DTIM_INVALID=2747;
var YM144=2748;
var up_tz_26=2749;
var help71=2750;
var GW_PURE_ADDPORTMAPPING_MODIFY=2751;
var tsc_pingt_msg10=2752;
var tps_foo=2753;
var GW_PURE_ADDPORTMAPPING_CHG_PROTOCOL=2754;
var LOG_PREV_MSG_REPEATED_N_TIMES=2755;
var ca_intro=2756;
var GW_WAN_LAN_ADDRESS_CONFLICT_DHCP=2757;
var help176=2758;
var GW_PURE_ADDPORTMAPPING_CREATE=2759;
var hhag_30=2760;
var hhai_save=2761;
var ADMIN=2762;
var wprn_s1a=2763;
var sl_alert_3=2764;
var help900=2765;
var tps_foo2=2766;
var help182=2767;
var aa_alert_12=2768;
var tf_intro_FWCh=2769;
var ts_ss=2770;
var wwa_title_set_pptp=2771;
var _hostname_eg=2772;
var wwl_s4_note=2773;
var help22=2774;
var wwl_alert_pv5_1=2775;
var GW_PURE_SETWLANSETTINGS24=2776;
var help167=2777;
var at_DxDSL=2778;
var wprn_bados2=2779;
var wprn_s3a=2780;
var wprn_tt10=2781;
var bwn_IF=2782;
var _1044a=2783;
var wprn_tt6=2784;
var help72=2785;
var _sdi_s6=2786;
var hhpt_sch=2787;
var tps_enraw=2788;
var sl_alert_2=2789;
var anet_wp_2=2790;
var tss_RestAll=2791;
var GW_PURE_SETWANSETTINGS=2792;
var help53=2793;
var help175=2794;
var help872=2795;
var help785=2796;
var wprn_s2b=2797;
var wprn_intro2=2798;
var GW_INET_ACL_NO_FILTER_SELECTED_INVALID=2799;
var help890=2800;
var help814=2801;
var help283=2802;
var sps_protdis=2803;
var help831=2804;
var _cantapplysettings=2805;
var help39=2806;
var WCN_LOG_ABORT=2807;
var up_tz_73=2808;
var help141_a=2809;
var af_intro_x=2810;
var help170=2811;
var tps_intro4=2812;
var help893b=2813;
var GW_DHCPSERVER_START=2814;
var help887=2815;
var help38=2816;
var help164=2817;
var hhav_filt=2818;
var GW_PURE_ADDPORTMAPPING_CONFLICT=2819;
var GW_PURE_SETROUTERLANSETTINGS=2820;
var GW_PURE_SETWLANSECURITY=2821;
var aa_alert_9=2822;
var help287=2823;
var ta_RAIF=2824;
var help180=2825;
var GW_PURE_SETDEVICESETTINGS=2826;
var _rssi=2827;
var wwl_intro_wel=2828;
var tf_ClickDL=2829;
var help165=2830;
var _vs_other=2831;
var tps_intro5=2832;
var ub_intro_1=2833;
var help277=2834;
var help41=2835;
var VIRTUAL_SERVERS=2836;
var hhav_sch=2837;
var ts_rfd=2838;
var help33b=2839;
var ts_ls=2840;
var GW_PURE_DELETEPORTMAPPING_MODIFY=2841;
var wprn_s2c=2842;
var help320=2843;
var help813=2844;
var help893=2845;
var help803=2846;
var help877=2847;
var up_tz_27=2848;
var help74=2849;
var help155_2=2850;
var _sdi_s4=2851;
var MISC=2852;
var tf_msg_Upping=2853;
var GW_LOG_EMAIL_FAILED=2854;
var help823_17=2855;
var IPV6_TEXT4=2856;
var sa_intro=2857;
var up_rb_2=2858;
var help23=2859;
var _bln_title_IGMPMemberships_h=2860;
var haf_intro_2=2861;
var help802=2862;
var wprn_tt5=2863;
var hhsl_lmail=2864;
var ap_intro_noreboot=2865;
var up_tz_29=2866;
var GW_PURE_SETMACFILTERS2=2867;
var GW_PURE_REBOOT=2868;
var rb_change=2869;
var help816=2870;
var GW_PURE_DELETEPORTMAPPING_DELETE=2871;
var ub_intro_3=2872;
var help30=2873;
var bln_alert_2=2874;
var hhwf_xref=2875;
var GW_REMOTE_ADMINSTRATION=2876;
var wwl_s4_intro=2877;
var sd_SecTyp=2878;
var IPV6_WAN_IP=2879;
var IPV6_TEXT0=2880;
var gw_wcn_alert_3=2881;
var IPV6_TEXT2=2882;
var S473=2883;
var af_ES=2884;
var IPV6_TEXT5=2885;
var IPV6_TEXT6=2886;
var IPV6_TEXT7=2887;
var IPV6_TEXT8=2888;
var IPV6_TEXT9=2889;
var IPV6_TEXT10=2890;
var IPV6_TEXT11=2891;
var IPV6_TEXT12=2892;
var IPV6_TEXT13=2893;
var IPV6_TEXT14=2894;
var IPV6_TEXT15=2895;
var IPV6_TEXT16=2896;
var IPV6_TEXT17=2897;
var IPV6_TEXT18=2898;
var IPV6_TEXT19=2899;
var IPV6_TEXT20=2900;
var IPV6_TEXT21=2901;
var IPV6_TEXT22=2902;
var IPV6_TEXT23=2903;
var DNS_TEXT0=2904;
var IPV6_TEXT25=2905;
var IPV6_TEXT26=2906;
var IPV6_TEXT27=2907;
var IPV6_TEXT28=2908;
var IPV6_TEXT29=2909;
var IPV6_TEXT29a=2910;
var IPV6_TEXT30=2911;
var IPV6_TEXT31=2912;
var IPV6_TEXT32=2913;
var IPV6_TEXT33=2914;
var IPV6_TEXT34=2915;
var IPV6_TEXT35=2916;
var IPV6_TEXT36=2917;
var IPV6_TEXT37=2918;
var IPV6_TEXT38=2919;
var IPV6_TEXT39=2920;
var IPV6_TEXT40=2921;
var IPV6_TEXT41=2922;
var IPV6_TEXT42=2923;
var IPV6_TEXT43=2924;
var IPV6_TEXT44=2925;
var IPV6_TEXT45=2926;
var IPV6_TEXT46=2927;
var IPV6_TEXT47=2928;
var IPV6_TEXT48=2929;
var IPV6_TEXT49=2930;
var TA11=2931;
var IPV6_TEXT51=2932;
var IPV6_TEXT52=2933;
var IPV6_TEXT53=2934;
var IPV6_TEXT54=2935;
var IPV6_TEXT55=2936;
var IPV6_TEXT56=2937;
var IPV6_TEXT57=2938;
var IPV6_TEXT58=2939;
var IPV6_TEXT59=2940;
var IPV6_TEXT60=2941;
var IPV6_TEXT61=2942;
var IPV6_TEXT62=2943;
var IPV6_TEXT63=2944;
var IPV6_TEXT65=2945;
var _aa_bsecure_obscene=2946;
var IPV6_TEXT66=2947;
var IPV6_TEXT67=2948;
var IPV6_TEXT68=2949;
var IPV6_TEXT69=2950;
var IPV6_TEXT70=2951;
var IPV6_TEXT71=2952;
var IPV6_TEXT72=2953;
var IPV6_TEXT73=2954;
var IPV6_TEXT74=2955;
var IPV6_TEXT75=2956;
var IPV6_TEXT76=2957;
var IPV6_TEXT77=2958;
var IPV6_TEXT78=2959;
var IPV6_TEXT79=2960;
var IPV6_TEXT80=2961;
var IPV6_TEXT81=2962;
var IPV6_TEXT82=2963;
var IPV6_TEXT83=2964;
var IPV6_TEXT84=2965;
var IPV6_TEXT85=2966;
var IPV6_TEXT86=2967;
var IPV6_TEXT87=2968;
var IPV6_TEXT88=2969;
var IPV6_TEXT89=2970;
var IPV6_TEXT90=2971;
var IPV6_TEXT91=2972;
var IPV6_TEXT92=2973;
var IPV6_TEXT93=2974;
var IPV6_TEXT94=2975;
var IPV6_TEXT95=2976;
var IPV6_TEXT96=2977;
var IPV6_TEXT97=2978;
var IPV6_TEXT98=2979;
var IPV6_TEXT99=2980;
var IPV6_TEXT100=2981;
var IPV6_TEXT102=2982;
var IPV6_TEXT103=2983;
var IPV6_TEXT104=2984;
var IPV6_TEXT108=2985;
var IPV6_TEXT106=2986;
var IPV6_TEXT107=2987;
var IPV6_TEXT50=2988;
var help825=2989;
var IPV6_TEXT110=2990;
var IPV6_TEXT111=2991;
var IPV6_TEXT112=2992;
var IPV6_TEXT113=2993;
var IPV6_TEXT116=2994;
var IPV6_TEXT117=2995;
var IPV6_TEXT118=2996;
var IPV6_TEXT119=2997;
var IPV6_TEXT120=2998;
var IPV6_TEXT121=2999;
var IPV6_TEXT122=3000;
var IPV6_TEXT123=3001;
var IPV6_TEXT124=3002;
var IPV6_TEXT125=3003;
var IPV6_TEXT126=3004;
var IPV6_TEXT127=3005;
var IPV6_TEXT128=3006;
var IPV6_TEXT129=3007;
var IPV6_TEXT130=3008;
var IPV6_TEXT131=3009;
var IPV6_TEXT132=3010;
var IPV6_TEXT133=3011;
var IPV6_TEXT134=3012;
var IPV6_TEXT135=3013;
var IPV6_TEXT136=3014;
var IPV6_TEXT137=3015;
var IPV6_TEXT138=3016;
var IPV6_TEXT139=3017;
var IPV6_TEXT140=3018;
var IPV6_TEXT141=3019;
var IPV6_TEXT142=3020;
var IPV6_TEXT143=3021;
var IPV6_TEXT144=3022;
var IPV6_TEXT145=3023;
var IPV6_TEXT146=3024;
var bd_EDSv=3025;
var htsc_pingt_h=3026;
var IPV6_TEXT149=3027;
var IPV6_TEXT150=3028;
var IPV6_TEXT151=3029;
var IPV6_TEXT152=3030;
var IPV6_TEXT153=3031;
var wps_KR37=3032;
var IPV6_TEXT155=3033;
var IPV6_TEXT156=3034;
var IPV6_TEXT157=3035;
var IPV6_TEXT158=3036;
var IPV6_TEXT159=3037;
var IPV6_TEXT160=3038;
var IPV6_TEXT161=3039;
var IPV6_TEXT162=3040;
var IPV6_TEXT163=3041;
var IPV6_TEXT164=3042;
var IPV6_TEXT165=3043;
var IPV6_TEXT166=3044;
var haar_p=3045;
var bws_ORAD=3046;
var DNS_TEXT2=3047;
var DNS_TEXT3=3048;
var DNS_TEXT4=3049;
var DNS_TEXT8=3050;
var DNS_TEXT6=3051;
var DNS_TEXT5=3052;
var help639=3053;
var DNS_TEXT9=3054;
var DNS_TEXT10=3055;
var DNS_TEXT11=3056;
var DNS_TEXT12=3057;
var TEXT000=3058;
var TEXT001=3059;
var TEXT002=3060;
var TEXT003=3061;
var TEXT004=3062;
var TEXT005=3063;
var TEXT006=3064;
var TEXT007=3065;
var TEXT008=3066;
var TEXT010=3067;
var sw_title_list=3068;
var TEXT011=3069;
var TEXT012=3070;
var TEXT013=3071;
var TEXT014=3072;
var TEXT015=3073;
var TEXT016=3074;
var TEXT017=3075;
var TEXT018=3076;
var TEXT019=3077;
var TEXT020=3078;
var TEXT021=3079;
var TEXT022=3080;
var LS3=3081;
var TEXT024=3082;
var TEXT025=3083;
var TEXT026=3084;
var TEXT027=3085;
var TEXT028=3086;
var TEXT029=3087;
var TEXT030=3088;
var TEXT031=3089;
var TEXT032=3090;
var TEXT033=3091;
var TEXT035=3092;
var TEXT036=3093;
var TEXT037=3094;
var TEXT038=3095;
var TEXT039=3096;
var TEXT040=3097;
var TEXT041=3098;
var TEXT042=3099;
var TEXT043=3100;
var TEXT045=3101;
var TEXT046=3102;
var TEXT047=3103;
var aa_alert_10=3104;
var TEXT049=3105;
var TEXT050=3106;
var TEXT051=3107;
var TEXT053=3108;
var TEXT055=3109;
var TEXT009=3110;
var TEXT054=3111;
var TEXT057=3112;
var TEXT058=3113;
var TEXT059=3114;
var TEXT060=3115;
var TEXT062=3116;
var TEXT063=3117;
var TEXT064=3118;
var TEXT065=3119;
var TEXT066=3120;
var TEXT067=3121;
var TEXT068=3122;
var TEXT069=3123;
var TEXT070=3124;
var TEXT071=3125;
var TEXT072=3126;
var TEXT073=3127;
var TEXT074=3128;
var TEXT075=3129;
var TEXT076=3130;
var TEXT077=3131;
var TEXT078=3132;
var MSG002=3133;
var MSG003=3134;
var MSG004=3135;
var MSG005=3136;
var MSG006=3137;
var MSG007=3138;
var MSG008=3139;
var MSG009=3140;
var MSG010=3141;
var MSG013=3142;
var MSG014=3143;
var MSG014a=3144;
var MSG015=3145;
var MSG016=3146;
var MSG017=3147;
var MSG018=3148;
var MSG019=3149;
var MSG020=3150;
var MSG021=3151;
var MSG022=3152;
var MSG023=3153;
var MSG024=3154;
var MSG025=3155;
var MSG026=3156;
var MSG027=3157;
var MSG028=3158;
var MSG029=3159;
var MSG030=3160;
var MSG031=3161;
var MSG032=3162;
var MSG033=3163;
var MSG034=3164;
var MSG035=3165;
var MSG036_1=3166;
var MSG037_1=3167;
var MSG038_1=3168;
var MSG039_1=3169;
var MSG036=3170;
var MSG037=3171;
var MSG038=3172;
var MSG039=3173;
var MSG040=3174;
var MSG041=3175;
var MSG042=3176;
var MSG043=3177;
var MSG044=3178;
var MSG045=3179;
var MSG046=3180;
var MSG047=3181;
var MSG048=3182;
var ADV_DNS_DESC3=3183;
var ERROR404=3184;
var SUGGESTIONS=3185;
var SUGGESTIONS_1=3186;
var SUGGESTIONS_2=3187;
var tsc_hrmin_1=3188;
var DHCP_PD=3189;
var IPV6_TEXT147=3190;
var DHCP_PD_ASSIGNED=3191;
var _6to4RELAY=3192;
var IPV6_TEXT64=3193;
var IPV6_TEXT66_v6=3194;
var usb_reboot=3195;
var usb_reboot_chnip=3196;
var country_8=3197;
var _select_phone=3198;
var _phone_info=3199;
var usb_3g_phone=3200;
var usb_window_mobile_5=3201;
var usb_iphone=3202;
var android_phone=3203;
var help901=3204;
var DEVICE_NAME=3205;
var IPDHCPSERVER_LEASE_REVOKED2=3206;
var IPDHCPSERVER_LEASE_RESERVATION_DELETED=3207;
var IPDHCPSERVER_LEASE_RENEW=3208;
var help738=3209;
var help759=3210;
var help517=3211;
var help443=3212;
var help414=3213;
var _ok=3214;
var help486=3215;
var help503=3216;
var help426=3217;
var help432=3218;
var help527=3219;
var awf_intro_WF=3220;
var help652=3221;
var help456=3222;
var help539=3223;
var help472=3224;
var help520=3225;
var help737=3226;
var help646=3227;
var help745=3228;
var help659=3229;
var help727=3230;
var help753=3231;
var help574=3232;
var help663=3233;
var help748=3234;
var hhwf_intro=3235;
var help598=3236;
var help761=3237;
var help510=3238;
var help584=3239;
var help716=3240;
var help440=3241;
var help410=3242;
var help480=3243;
var help559=3244;
var help516=3245;
var help413=3246;
var help619=3247;
var help521=3248;
var help494=3249;
var help498=3250;
var help628=3251;
var help683=3252;
var help535=3253;
var help695=3254;
var help740=3255;
var help578=3256;
var help438=3257;
var help508=3258;
var help423=3259;
var help625=3260;
var help680=3261;
var help568=3262;
var help620=3263;
var help667=3264;
var help766=3265;
var help662=3266;
var help701=3267;
var help542=3268;
var help570=3269;
var help489=3270;
var help723=3271;
var help593=3272;
var help447=3273;
var help705=3274;
var help755=3275;
var _H323=3276;
var help427=3277;
var help485=3278;
var help490=3279;
var help555=3280;
var help462=3281;
var help732=3282;
var help592=3283;
var help455=3284;
var help685=3285;
var help146=3286;
var help655=3287;
var help439=3288;
var help416=3289;
var help726=3290;
var help692=3291;
var help550=3292;
var help714=3293;
var help504=3294;
var help469=3295;
var help629=3296;
var help597=3297;
var help746=3298;
var help749=3299;
var help471=3300;
var help736=3301;
var help596=3302;
var help706=3303;
var help664=3304;
var help702=3305;
var help756=3306;
var help573=3307;
var help601=3308;
var help684=3309;
var help678=3310;
var help760=3311;
var help536=3312;
var help499=3313;
var help562=3314;
var help741=3315;
var help541=3316;
var help717=3317;
var help604=3318;
var help718=3319;
var help551=3320;
var help577=3321;
var help515=3322;
var help621=3323;
var help412=3324;
var help713=3325;
var help687=3326;
var help567=3327;
var help618=3328;
var help441=3329;
var help466=3330;
var gw_vs_5=3331;
var help488=3332;
var help591=3333;
var help402=3334;
var help661=3335;
var help495=3336;
var help587=3337;
var help658=3338;
var help722=3339;
var help483=3340;
var help670=3341;
var help750=3342;
var help452=3343;
var help696=3344;
var help668=3345;
var help433=3346;
var help681=3347;
var help632=3348;
var help409=3349;
var help765=3350;
var help421=3351;
var help725=3352;
var help660=3353;
var help576=3354;
var help751=3355;
var help735=3356;
var help401=3357;
var gw_vs_6=3358;
var help491=3359;
var help448=3360;
var help566=3361;
var help398=3362;
var help586=3363;
var help710=3364;
var help686=3365;
var help537=3366;
var help654=3367;
var help708=3368;
var help424=3369;
var help505=3370;
var help583=3371;
var help430=3372;
var help484=3373;
var help454=3374;
var help556=3375;
var help470=3376;
var help689=3377;
var help464=3378;
var help461=3379;
var tt_Nov=3380;
var help715=3381;
var help622=3382;
var help731=3383;
var help408=3384;
var help688=3385;
var help465=3386;
var help703=3387;
var help697=3388;
var help605=3389;
var help549=3390;
var help506=3391;
var help642=3392;
var help428=3393;
var help682=3394;
var help492=3395;
var help526=3396;
var help631=3397;
var help606=3398;
var help665=3399;
var help148=3400;
var RATE_ESTIMATOR_RESOURCE_ERROR=3401;
var help721=3402;
var gw_vs_2=3403;
var help729=3404;
var help757=3405;
var help595=3406;
var help671=3407;
var help747=3408;
var help707=3409;
var help451=3410;
var help514=3411;
var help512=3412;
var help675=3413;
var help399=3414;
var help626=3415;
var help415=3416;
var help533=3417;
var help572=3418;
var help557=3419;
var help468=3420;
var help724=3421;
var help648=3422;
var wt_title=3423;
var help657=3424;
var help482=3425;
var help679=3426;
var help431=3427;
var help560=3428;
var help742=3429;
var help449=3430;
var help565=3431;
var wprn_tt7=3432;
var help599=3433;
var help585=3434;
var help530=3435;
var help623=3436;
var help758=3437;
var help634=3438;
var help752=3439;
var help575=3440;
var help450=3441;
var ES_CABLELOST_bnr=3442;
var help463=3443;
var help407=3444;
var help453=3445;
var help561=3446;
var help442=3447;
var help762=3448;
var help553=3449;
var help590=3450;
var help608=3451;
var help411=3452;
var gw_vs_4=3453;
var help546=3454;
var help653=3455;
var help481=3456;
var help529=3457;
var help425=3458;
var help400=3459;
var help509=3460;
var _DHCP=3461;
var help709=3462;
var help720=3463;
var help728=3464;
var help467=3465;
var help719=3466;
var help594=3467;
var help457=3468;
var help666=3469;
var help698=3470;
var help538=3471;
var help630=3472;
var help422=3473;
var help493=3474;
var help507=3475;
var help571=3476;
var RATE_ESTIMATOR_CONVERGENCE_ERROR=3477;
var help487=3478;
var help624=3479;
var help543=3480;
var help700=3481;
var help460=3482;
var help730=3483;
var help502=3484;
var help513=3485;
var help690=3486;
var help607=3487;
var help525=3488;
var help754=3489;
var help617=3490;
var help500=3491;
var help558=3492;
var help429=3493;
var help511=3494;
var help534=3495;
var help496=3496;
var help446=3497;
var help739=3498;
var help627=3499;
var _actsess=3500;
var help91a=3501;
var help91b=3502;
var help92x1=3503;
var help92x2=3504;
var TA21=3505;
var TA22=3506;
var help183=3507;
var help400_b=3508;
var help401_b=3509;
var help402_b=3510;
var help403=3511;
var help403_b=3512;
var help404=3513;
var help404_b=3514;
var help405=3515;
var help405_b=3516;
var WIFISC_AP_PEER_CFG_ERR=3517;
var help417=3518;
var help418=3519;
var help419=3520;
var help420=3521;
var help434=3522;
var help435=3523;
var help436=3524;
var help437=3525;
var help444=3526;
var help445=3527;
var help458=3528;
var help459=3529;
var help474=3530;
var help475=3531;
var help476=3532;
var help477=3533;
var help478=3534;
var help479=3535;
var help518=3536;
var help519=3537;
var help522=3538;
var help523=3539;
var help528=3540;
var help531=3541;
var help532=3542;
var help544=3543;
var help545=3544;
var help548=3545;
var help563=3546;
var help564=3547;
var help579=3548;
var help580=3549;
var help581=3550;
var help582=3551;
var help588=3552;
var help589=3553;
var help602=3554;
var help603=3555;
var help609=3556;
var help610=3557;
var help611=3558;
var help612=3559;
var help613=3560;
var help614=3561;
var help615=3562;
var help616=3563;
var tt_Oct=3564;
var sa_Originator=3565;
var help637=3566;
var help641=3567;
var help638=3568;
var msg_non_sec=3569;
var LW24=3570;
var help644=3571;
var help649=3572;
var help650=3573;
var help672=3574;
var help673=3575;
var help676=3576;
var help677=3577;
var help693=3578;
var help694=3579;
var help711=3580;
var help712=3581;
var help733=3582;
var help734=3583;
var help743=3584;
var help744=3585;
var help763=3586;
var help764=3587;
var help795a=3588;
var sa_Internal=3589;
var sa_External=3590;
var DNS_TEXT7=3591;
var help831_1=3592;
var DNS_TEXT1=3593;
var help191=3594;
var help198=3595;
var _unknown_wait=3596;
var _unknown=3597;
var _na=3598;
var _sdi_nciy=3599;
var _sdi_dhcpclient=3600;
var _sdi_bpc=3601;
var help600=3602;
var _bln_nmgmy=3603;
var _sdi_s1=3604;
var _sdi_s10=3605;
var _sdi_s8=3606;
var _sdi_s9=3607;
var _sdi_days=3608;
var _sdi_disconnectpending=3609;
var _sdi_secs=3610;
var sd_Renew=3611;
var sd_Release=3612;
var sd_Disconnect=3613;
var sd_bp_login=3614;
var sd_bp_logout=3615;
var _channel=3616;
var sl_SLogs=3617;
var sps_intro2=3618;
var sps_pare=3619;
var sr_RTable=3620;
var sr_intro=3621;
var ss_title_stats=3622;
var sw_title=3623;
var ta_alert_1=3624;
var ES_CABLELOST_dsc1=3625;
var _pwsame=3626;
var ta_alert_3=3627;
var _invalidddnsserver=3628;
var _blankddnsserver=3629;
var IPV6_TEXT1=3630;
var td_alert_2=3631;
var td_alert_3=3632;
var td_DDNSDDNS=3633;
var tt_SelDynDns=3634;
var _emailaccnameisblank=3635;
var _blankfromemailaddr=3636;
var _blanktomemailaddr=3637;
var _blanksmtpmailaddr=3638;
var _badfromemailaddr=3639;
var _badtoemailaddr=3640;
var _invalidsmtpserveraddr=3641;
var _badsmtpserveraddr=3642;
var tf_NFWA=3643;
var tf_alert_1=3644;
var tf_LFWVis=3645;
var tf_FWCinP=3646;
var tf_Ching_FW=3647;
var tf_EM_not=3648;
var tf_LFWV=3649;
var tf_FWChNow=3650;
var TA17=3651;
var tps_sfp=3652;
var tps_dci=3653;
var tps_intro2=3654;
var tsc_alert_1=3655;
var tsc_alert_2=3656;
var tsc_alert_3=3657;
var tsc_alert_6=3658;
var tsc_alert_9=3659;
var tsc_SelDays=3660;
var tsc_TimeFr=3661;
var tsl_alert_3=3662;
var tsl_alert_1=3663;
var tsl_alert_2=3664;
var ZM18=3665;
var tsc_pingt_msg9=3666;
var help635=3667;
var tt_alert_tupdt=3668;
var TA24=3669;
var TA25=3670;
var fb_FbAc=3671;
var sentinel_1=3672;
var sentinel_2=3673;
var sentinal_3=3674;
var fl_Failure=3675;
var fl_text=3676;
var li_newfw=3677;
var rd_p_1=3678;
var rd_p_2=3679;
var rs_Restoring_Settings=3680;
var reh=3681;
var rs_RSPW=3682;
var rs_cld=3683;
var rs_Done=3684;
var rs_uld=3685;
var rs_usd=3686;
var rs_csd=3687;
var rs_Repacked=3688;
var rs_Converted=3689;
var rs_Saving=3690;
var sc_intro_rb=3691;
var _relogin=3692;
var _badWANsub=3693;
var wwa_pv5_alert_4=3694;
var wwa_pv5_alert_5=3695;
var wwa_pv5_alert_8=3696;
var wwa_pv5_alert_6=3697;
var wwa_pv5_alert_7=3698;
var wwa_pv5_alert_21=3699;
var _badPPTPgwip=3700;
var wwa_pv5_alert_15=3701;
var _badL2TPgwip=3702;
var wwa_pv5_alert_20=3703;
var wwl_intro_s3_1=3704;
var wwl_intro_s3_2r=3705;
var wwl_WSP_1=3706;
var wwl_wpa=3707;
var wwl_wpa2=3708;
var gw_vs_0=3709;
var gw_vs_8=3710;
var gw_sa_0=3711;
var gw_sa_2=3712;
var gw_sa_3=3713;
var gw_sa_4=3714;
var YM47=3715;
var gw_SelBPS=3716;
var gw_bp_0=3717;
var gw_bp_1=3718;
var gw_bp_2=3719;
var gw_gm_81=3720;
var gw_wcn_alert_4=3721;
var gw_wcn_alert5=3722;
var gw_wcn_alert6=3723;
var gw_wcn_alert7=3724;
var gw_wcn_err_ok=3725;
var gw_wcn_err_code=3726;
var gw_wcn_err_os_version=3727;
var gw_wcn_err_load_config=3728;
var gw_wcn_err_provision=3729;
var gw_wcn_err_io_write_config=3730;
var gw_wcn_err_encryption=3731;
var gw_wcn_err_exception=3732;
var gw_wcn_err_com=3733;
var gw_wcn_err_bad_wsetting_entry=3734;
var gw_wcn_err_bad_wps_profile=3735;
var gw_wcn_err_unsupported_wsetting=3736;
var gw_wcn_err_dom_processing=3737;
var gw_wcn_err_default=3738;
var adv_Everyone=3739;
var adv_Noone=3740;
var psQueued=3741;
var psStarting=3742;
var psClosed=3743;
var psIdle=3744;
var psReady=3745;
var GW_PPPOE_EVENT_OFFER=3746;
var psUnplugged=3747;
var psPrinting=3748;
var IPPPPPAP_AUTH_RESULT=3749;
var up_gS_1=3750;
var up_gIUH_1=3751;
var up_gIUH_2=3752;
var up_gIUH_3=3753;
var up_gH_1=3754;
var up_ae_se_1=3755;
var up_ai_se_2=3756;
var up_ae_se_3=3757;
var up_ae_wic_1=3758;
var up_ae_wic_2=3759;
var _Advanced_02=3760;
var up_fm_dc_1=3761;
var up_fm_re_1=3762;
var up_fm_re_2=3763;
var up_fm_dr_1=3764;
var up_fm_dr_2=3765;
var up_fm_dr_3=3766;
var up_if_1=3767;
var up_rb_3=3768;
var up_rb_6=3769;
var up_vp_1=3770;
var up_vp_2=3771;
var up_vp_3=3772;
var up_vp_0=3773;
var up_vm_1=3774;
var up_vm_2=3775;
var up_he_1=3776;
var up_he_2=3777;
var up_he_5=3778;
var gw_sa_5=3779;
var IPSTACK_REJECTED_SPOOFED_PACKET=3780;
var IPDHCPSERVER_HOST_IS_ACTIVE=3781;
var BSECURE_LOG_AUTH_FAIL_UNREG=3782;
var RATE_ESTIMATOR_RATE_IS=3783;
var GW_IPFILTER_DENY=3784;
var GW_SMTP_EMAIL_CANNOT_CREATE_CONNECTION=3785;
var IPNAT_ILLEGAL_DEST=3786;
var BSECURE_LOG_FLTR_DISCONNECTED_TIMEOUT=3787;
var IPDHCPSERVER_LEASE_REVOKED1=3788;
var LOG_PREV_MSG_REPEATED_1_TIME=3789;
var GW_UPNP_PORTMAP_VS_CHANGE=3790;
var IPDHCPSERVER_LEASE_EXPIRED=3791;
var BSECURE_LOG_AUTH_FAIL_INTNL=3792;
var GW_UPNP_PORTMAP_DEL=3793;
var GW_SMTP_EMAIL_INVALID_TO_ADDRESS=3794;
var BSECURE_LOG_FLTR_DISCONNECTED_CLOSED=3795;
var IPDHCPSERVER_LEASE_EXPIRED_SPECIFIC=3796;
var BSECURE_LOG_AUTH_PASS=3797;
var BSECURE_LOG_AUTH_FAIL_UNKNW=3798;
var wwan_auth_pap=3799;
var BSECURE_LOG_AUTH_FAIL_RENEW=3800;
var IPDHCPSERVER_LEASE_DENIED=3801;
var GW_SMTP_EMAIL_TIMEOUT=3802;
var BSECURE_LOG_AUTH_FAIL_DB=3803;
var IPDHCPSERVER_PARAM_DB_UPDATED=3804;
var APP_RULES=3805;
var IPDHCPSERVER_LEASE_POOL_FULL=3806;
var IPPPPPAP_AUTH_SUCCESS=3807;
var ADVANCED_NETWORKS=3808;
var IPDHCPSERVER_LEASE_ASSIGNED=3809;
var BSECURE_LOG_FLTR_CONNECTED=3810;
var BSECURE_LOG_AUTH_CONNECTED=3811;
var BSECURE_LOG_AUTH_FAIL_PKT=3812;
var IPSMTPCLIENT_CONN_FAILED=3813;
var IPPPPPAP_AUTH_FAIL=3814;
var GW_LOG_ON_LATEST_FIRMWARE_RETRIEVED=3815;
var GW_SMTP_EMAIL_SEND_FAILURE=3816;
var IPDHCPSERVER_LEASE_RELEASED=3817;
var IPDHCPSERVER_PARAM_DB_ADDED=3818;
var IPPPPPAP_AUTH_TIMEOUT=3819;
var GW_UPNP_PORTMAP_ADD=3820;
var GW_SMTP_EMAIL_NO_SERVER_IP_ADDRESS=3821;
var GW_UPNP_PORTMAP_REFRESH=3822;
var GW_UPNP_PORTMAP_EXPIRE=3823;
var IPDHCPSERVER_PARAM_DB_REMOVED=3824;
var IPDHCPSERVER_LEASE_DELETED=3825;
var GW_UPNP_PORTMAP_CONFLICT=3826;
var TA1=3827;
var aa_alert_11=3828;
var aa_alert_1=3829;
var aa_sched_conf_3=3830;
var aa_alert_16=3831;
var aa_alert_2=3832;
var aa_alert_3=3833;
var aa_alert_4=3834;
var aa_alert_5=3835;
var aa_alert_6=3836;
var _aa_other_machines=3837;
var _copyright=3838;
var aw_alert_1=3839;
var aw_alert_2=3840;
var aw_alert_3=3841;
var aw_alert_4=3842;
var af_alert_1=3843;
var af_alert_2=3844;
var TA19=3845;
var ag_alert_4=3846;
var ag_alert_5=3847;
var ag_conflict10=3848;
var ag_conflict20=3849;
var ag_conflict21=3850;
var ag_alert_1=3851;
var ag_alert_3=3852;
var ag_alert2=3853;
var _tcpports=3854;
var _udpports=3855;
var ag_conflict4=3856;
var tsc_alert_7=3857;
var ai_alert_3=3858;
var GW_FIREWALL_NO_IP_RANGE_INVALID=3859;
var ai_alert_7=3860;
var ai_alert_4=3861;
var ai_alert_6=3862;
var tsc_alert_5=3863;
var ai_title_2=3864;
var _edit=3865;
var _srcip=3866;
var ai_c2=3867;
var ai_c3=3868;
var amaf_alert_1=3869;
var am_cMT_deny=3870;
var am_cMT_Allow=3871;
var _sr_nriy=3872;
var ar_alert_1=3873;
var ar_alert_2=3874;
var ar_alert_3=3875;
var ar_alert_4=3876;
var ar_alert_5=3877;
var ar_RoutI=3878;
var ar_Route=3879;
var ar_RoutesList=3880;
var _delete=3881;
var ar_ERTable=3882;
var ag_alert_duplicate_name=3883;
var ag_alert_duplicate=3884;
var ag_inuse=3885;
var _specapps_alert_2=3886;
var _specapps_tpr=3887;
var _specapps_ipr=3888;
var as_title_SAR=3889;
var as_TPRange=3890;
var as_ex=3891;
var as_TPR=3892;
var as_IPR=3893;
var as_IPrt=3894;
var at_alert_1_1=3895;
var at_alert_15=3896;
var at_alert_16=3897;
var at_alert_17=3898;
var at_alert_2=3899;
var at_alert_18=3900;
var at_alert_3=3901;
var at_alert_19=3902;
var at_alert_4=3903;
var at_alert_5=3904;
var at_alert_20=3905;
var at_alert_6=3906;
var at_alert_21=3907;
var at_alert_8=3908;
var at_alert_7=3909;
var at_alert_10=3910;
var at_alert_9=3911;
var at_alert_11=3912;
var at_alert_22=3913;
var at_alert_23=3914;
var at_alert_24=3915;
var at_alert_14=3916;
var at_Prot_0=3917;
var _srcport=3918;
var at_DIPR=3919;
var at_DPR=3920;
var av_alert_11=3921;
var av_alert_21=3922;
var av_alert_24=3923;
var av_alert_1=3924;
var av_alert_2=3925;
var av_alert_3=3926;
var av_alert_4=3927;
var av_alert_12=3928;
var av_alert_18=3929;
var av_alert_23=3930;
var av_alert_19=3931;
var av_alert_20=3932;
var av_alert_13=3933;
var av_alert_17=3934;
var av_alert_5=3935;
var av_alert_6=3936;
var av_alert_7=3937;
var av_alert_8=3938;
var av_alert_9=3939;
var av_alert_10=3940;
var _public=3941;
var at_Prot__1=3942;
var _private=3943;
var aa_WebSite=3944;
var awf_alert_4=3945;
var awf_alert_5=3946;
var awf_alert_7=3947;
var awf_alert_8=3948;
var int_ConWz2=3949;
var int_WlsWz=3950;
var hhbi_wiz=3951;
var hhbi_man=3952;
var bd_noneyet=3953;
var bd_revoked=3954;
var bln_alert_3=3955;
var bd_alert_10=3956;
var bd_alert_11=3957;
var bd_alert_1=3958;
var bd_alert_3=3959;
var bd_alert_13=3960;
var bd_alert_12=3961;
var bd_alert_5=3962;
var bd_alert_6=3963;
var bd_alert_7=3964;
var TA20=3965;
var bd_alert_8=3966;
var bd_alert_22=3967;
var bd_alert_23=3968;
var bd_alert_24=3969;
var _badWANIP=3970;
var bwn_alert_2=3971;
var bwn_alert_3=3972;
var bwn_alert_4=3973;
var bwn_alert_5=3974;
var MSG000=3975;
var bwn_alert_8=3976;
var bwn_alert_12=3977;
var _badPPTPip=3978;
var _badPPTPsub=3979;
var _badPPTPipsub=3980;
var bwn_alert_11=3981;
var _badL2TP3=3982;
var _badL2TP=3983;
var _badL2TP2=3984;
var bwn_alert_17=3985;
var bwn_alert_21=3986;
var bws_alert_15=3987;
var bws_alert_16=3988;
var bwl_alert_2=3989;
var bwl_alert_3=3990;
var bwl_alert_15=3991;
var bwl_alert_16=3992;
var bwl_alert_4=3993;
var bwl_alert_5=3994;
var bwl_alert_6=3995;
var bwl_alert_7=3996;
var bwl_alert_8=3997;
var bwl_alert_9=3998;
var bwl_alert_10=3999;
var bws_alert_2=4000;
var bwl_alert_11=4001;
var bwl_alert_12=4002;
var bws_alert_3=4003;
var aw_alert_5_1=4004;
var bwl_alert_13=4005;
var bwl_alert_14=4006;
var bwl_Mode_2=4007;
var bwl_Mode_3=4008;
var bwl_Mode_1=4009;
var bwl_Mode_8=4010;
var bwl_Mode_11=4011;
var bwl_ht20=4012;
var bwl_ht2040=4013;
var bwl_TxR_0=4014;
var TA9=4015;
var YM124=4016;
var TA12=4017;
var TA14=4018;
var TA15=4019;
var _wizard=4020;
var bwz_LConWz=4021;
var bwz_WlsWz=4022;
var bwz_intro_WlsWz=4023;
var bwz_LWlsWz=4024;
var _specapps=4025;
var _gaming=4026;
var _basic=4027;
var ag_alert_empty_name=4028;
var ag_alert_duplicate_name2=4029;
var amaf_alert_2=4030;
var specapps_alert_duplicate_name=4031;
var specapps_alert_duplicate1=4032;
var specapps_alert_conflict1=4033;
var specapps_alert_empty_schedule=4034;
var at_title_TSSet=4035;
var av_alert_35=4036;
var av_alert_empty_name=4037;
var av_alert_16=4038;
var bln_alert_lannbpri=4039;
var bln_alert_lannbsec=4040;
var lan_dns=4041;
var lan_dns2=4042;
var bln_NetBIOSReg_H=4043;
var bln_NetBIOSReg_M=4044;
var bln_NetBIOSReg_P=4045;
var bln_NetBIOSReg_B=4046;
var _help=4047;
var help81ets=4048;
var af_EFT_h4=4049;
var YM134=4050;
var af_EFT_h1=4051;
var af_EFT_h2=4052;
var af_EFT_h5=4053;
var af_UEFT_h1=4054;
var af_TEFT_h2=4055;
var help309A=4056;
var help400_1=4057;
var help401_1=4058;
var help402_1=4059;
var help402_2=4060;
var help405_1=4061;
var help405_2=4062;
var help405_3=4063;
var help405_4=4064;
var _sdi_s1a=4065;
var ta_alert_3b=4066;
var ta_alert_3c=4067;
var ta_alert_3d=4068;
var ta_alert_3e=4069;
var ta_alert_3f=4070;
var ta_alert_3g=4071;
var tps_enlpd=4072;
var ta_LMAP=4073;
var fb_FailLogin=4074;
var fb_FailLogin_1=4075;
var _open=4076;
var _other=4077;
var _223=4078;
var _225ap=4079;
var _226ap=4080;
var _1044wired=4081;
var _1044awired=4082;
var TEXT0=4083;
var regenerate=4084;
var _title_AdvDns=4085;
var _desc_AdvDns=4086;
var ta_EUPNP_dns=4087;
var _st_AdvDns=4088;
var _sp_title_AdvDNS=4089;
var _sp_desc1_AdvDNS=4090;
var _sp_desc2_AdvDNS=4091;
var _sp_desc3_AdvDNS=4092;
var _sp_desc4_AdvDNS=4093;
var TEXT041_1=4094;
var TEXT041_2=4095;
var TEXT041_3=4096;
var TEXT041_4=4097;
var TEXT042_1=4098;
var TEXT042_2=4099;
var GW_URL_INVALID=4100;
var GW_LAN_NETBIOS_SCOPE_INVALID=4101;
var GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID_a=4102;
var bwn_Mode_DHCPPLUS=4103;
var net_sniper_support=4104;
var SEL_DIAL_MODE=4105;
var pppoe_dialmode_normal=4106;
var pppoe_dialmode_sp1=4107;
var pppoe_dialmode_sp2=4108;
var pppoe_dialmode_sp3=4109;
var pppoe_dialmode_sp4=4110;
var pppoe_dialmode_sp5=4111;
var pppoe_dialmode_sp6=4112;
var pppoe_dialmode_learn=4113;
var bt_learn_text=4114;
var box_ip_mac_binding=4115;
var _en_AdvDns=4116;
var xkjs_support=4117;
var ddns_serv_type=4118;
var ddns_domain=4119;
var ddns_account=4120;
var virtual_pub_port_err=4121;
var virtual_pri_port_err=4122;
var virtual_proto_num_err=4123;
var menu_wps=4124;
var tc_iprange=4125;
var help823_15=4126;
var tc_bw=4127;
var tc_schedule=4128;
var tc_new_sch=4129;
var tc_min_bw=4130;
var tc_max_bw=4131;
var _login_admin=4132;
var _login_user=4133;
var pppoe_plus_dail=4134;
var GW_WAN_DHCPPLUS_USERNAME_INVALID=4135;
var GW_WAN_DHCPPLUS_PASSWORD_INVALID=4136;
var te_SMTPPort=4137;
var WLANMODE=4138;
var ROUTER_MODE=4139;
var AP_MODE=4140;
var WDSROUTER_MODE=4141;
var WDSAP_MODE=4142;
var BR_SET=4143;
var device_mode=4144;
var router_mode=4145;
var ap_mode=4146;
var auto_mode=4147;
var enable_WDS=4148;
var ES_AUTODECT=4149;
var _phone=4150;
var ES_CABLELOST_dsc2=4151;
var ES_DONT_CONN_btn=4152;
var ES_UPDATE_SETTING_bnr=4153;
var ES_UPDATE_SETTING_dsc=4154;
var ES_CONFIG_INTERNET_bnr=4155;
var ES_CONFIG_INTERNET_dsc2=4156;
var ES_INTERNET_CONN_dsc=4157;
var ES_MUST_FIELD_dsc=4158;
var ES_DIALUP_ERROR_bnr=4159;
var usb_config1=4160;
var ES_NAME=4161;
var MSG011=4162;
var ES_what_is_this=4163;
var ES_PRI_DNS=4164;
var ES_SEC_DNS=4165;
var ES_GW_ADDR=4166;
var ES_MASK=4167;
var ES_IP_ADDR=4168;
var ES_complete=4169;
var ES_save_dsc=4170;
var ES_status=4171;
var ES_connected=4172;
var ES_unconnected=4173;
var ES_wlan_setting=4174;
var ES_wlan_ssid=4175;
var ES_security=4176;
var ES_unsecured=4177;
var ES_unsecured_suggest=4178;
var ES_save_mySetting=4179;
var ES_sync_pw=4180;
var ES_save=4181;
var ES_network_key=4182;
var ES_autogen_key=4183;
var ES_disable_wifi_sec=4184;
var ES_wifi_sec_recomm=4185;
var ES_current_setting_dsc=4186;
var ES_current_setting=4187;
var ES_manual_btn=4188;
var ES_cancel=4189;
var logout_caption=4190;
var logout_desc=4191;
var logout_return=4192;
var st_connected_time=4193;
var t_ctl_title=4194;
var t_ctl_note=4195;
var t_ctl_note1=4196;
var page_title=4197;
var ac_alert_invalid_port=4198;
var ac_alert_dup_name=4199;
var ac_alert_port_conflit=4200;
var ac_alert_policy_null=4201;
var tt_alert_checkdyndns=4202;
var ES_static_no_internet=4203;
var ES_static_no_internet_desc=4204;
var _CFM_close_window=4205;
var ES_save_result=4206;
var ES_save_success=4207;
var ES_confirm_bt=4208;
var sch_timeformat=4209;
var sch_hourfmt_12=4210;
var sch_hourfmt_24=4211;
var no_available_update=4212;
var clear_lang_pack=4213;
var current_lang_pack_version=4214;
var current_lang_pack_date=4215;
var lang_package_info=4216;
var lang_package_note1=4217;
var lang_package_note2=4218;
var latest_lang_package_ver=4219;
var latest_lang_package_date=4220;
var no_lang_pack=4221;
var pf_name_empty=4222;
var vs_name_empty=4223;
var fw_checksum_err=4224;
var fw_bad_hwid=4225;
var fw_unknow_file_format=4226;
var fw_fw_upgrade_success=4227;
var fw_lp_upgrade_success=4228;
var fw_cfg_upgrade_success=4229;
var ES_timectrl_bnr=4230;
var ES_timectrl_btn=4231;
var ES_webpolicy_btn=4232;
var HW_NAT_desc=4233;
var at_ETS=4234;
var alert_hw_nat_1=4235;
var alert_hw_nat_2=4236;
var alert_hw_nat_3=4237;
var help_auto_disable_hw_nat=4238;
var help_auto_disable_hw_nat_1=4239;
var help_hw_nat=4240;
var help_hw_nat_desc=4241;
var ES_step_wifi_security=4242;
var _pwsame_user=4243;
var ES_btn_try_again=4244;
var ES_auto_detect_desc=4245;
var ES_auto_detect_failed_desc=4246;
var ES_btn_guide_me=4247;
var ES_btn_save_conn=4248;
var ES_btn_save=4249;
var v6_routing=4250;
var v6_routing_table=4251;
var v6_routing_info=4252;
var ipv6=4253;
var ipv6_firewall=4254;
var ipv6_firewall_info=4255;
var _6rd_settings=4256;
var ipv4_addr=4257;
var mask_len=4258;
var IPV6_ULA_TEXT01=4259;
var HW_NAT_enable=4260;
var IPV6_ULA_TEXT03=4261;
var IPV6_ULA_TEXT04=4262;
var IPV6_ULA_TEXT05=4263;
var IPV6_ULA_TEXT06=4264;
var IPV6_ULA_TEXT07=4265;
var IPV6_ULA_TEXT08=4266;
var IPV6_ULA_TEXT09=4267;
var IPV6_ULA_TEXT11=4268;
var IPV6_ULA_TEXT12=4269;
var IPV6_ULA_TEXT13=4270;
var IPV6_ULA_TEXT14=4271;
var IPv6_Local_Info=4272;
var IPv6_Simple_Security=4273;
var anet_multicast_enable_v6=4274;
var IPv6_Wizard_6rd_title=4275;
var fr_name_empty=4276;
var r6_name_empty=4277;
var wwz_wwl_intro_s2_1=4278;
var wwz_wwl_intro_s2_1_1=4279;
var wwz_wwl_intro_s2_1_2=4280;
var wwz_wwl_intro_s2_2=4281;
var wwz_wwl_intro_s2_2_1=4282;
var wwz_wwl_intro_s2_2_2=4283;
var ES_title_s3=4284;
var ES_title_s4=4285;
var ES_title_s5=4286;
var bwl_Mode_n=4287;
var bwl_Mode_a=4288;
var bwl_Mode_5=4289;
var MSG049=4290;
var MSG050=4291;
var HWerr=4292;
var storage=4293;
var sto_into=4294;
var sto_http_0=4295;
var bwn_RPing=4296;
var guestzone_enable=4297;
var sto_http_3=4298;
var LV2=4299;
var sto_http_5=4300;
var sto_creat=4301;
var _add_edit=4302;
var sto_list=4303;
var _modify=4304;
var sto_path=4305;
var help361=4306;
var tt_NTPSrvU=4307;
var sto_dev=4308;
var _total_space=4309;
var _free_space=4310;
var sto_link_0=4311;
var sto_link_1=4312;
var sto_link_2=4313;
var _email_now=4314;
var sto_help=4315;
var _DevLink=4316;
var _folder=4317;
var _browse=4318;
var _append=4319;
var sto_01=4320;
var sto_02=4321;
var _readonly=4322;
var _readwrite=4323;
var _AppendNewFolder=4324;
var KR45=4325;
var MSG052=4326;
var MSG053=4327;
var MSG054=4328;
var _AddFolder=4329;
var _StorageLink=4330;
var LW6_1=4331;
var MSG055=4332;
var ES_title_s5_0=4333;
var save_settings=4334;
var save_wait=4335;
var _Language=4336;
var manul_conn_01=4337;
var manul_conn_02=4338;
var manul_conn_03=4339;
var manul_conn_04=4340;
var manul_conn_05=4341;
var manul_conn_06=4342;
var manul_conn_07=4343;
var manul_conn_08=4344;
var manul_conn_09=4345;
var manul_conn_10=4346;
var manul_conn_11=4347;
var manul_conn_12=4348;
var _aa_bsecure_opinion=4349;
var manul_conn_14=4350;
var manul_conn_15=4351;
var manul_conn_16=4352;
var manul_conn_17=4353;
var manul_conn_18=4354;
var manul_conn_19=4355;
var manul_conn_20=4356;
var manul_conn_21=4357;
var manul_conn_22=4358;
var manul_conn_23=4359;
var manul_conn_24=4360;
var manul_conn_25=4361;
var manul_5g_ssid=4362;
var tf_intro_FWU4=4363;
var tf_intro_FWU5=4364;
var _firmwareUpdate=4365;
var _date=4366;
var _remove=4367;
var notify_wps=4368;
var ag_conflict5=4369;
var _disable=4370;
var coexi=4371;
var wwl_SSP=4372;
var wwz_wwl_intro_s0=4373;
var STATUS_IPV6_DESC_0=4374;
var STATUS_IPV6_DESC_1=4375;
var STATUS_IPV6_DESC_6=4376;
var STATUS_IPV6_DESC_5=4377;
var STATUS_IPV6_DESC_4=4378;
var STATUS_IPV6_DESC_3=4379;
var STATUS_IPV6_DESC_2=4380;
var ag_conflict6=4381;
var TEXT008a=4382;
var TEXT008b=4383;
var TEXT023=4384;
var at_mbps=4385;
var pin_f=4386;
var msg_eap=4387;
var open=4388;
var PRIVATE_PORT_ERROR=4389;
var MSG056=4390;
var MSG057=4391;
var _DestIP=4392;
var _type=4393;
var mydlink_tx03=4394;
var mydlink_tx05=4395;
var sec_left=4396;
var ES_CONN_dsc=4397;
var chk_pass=4398;
var Lname=4399;
var Fname=4400;
var _login=4401;
var ag_conflict22=4402;
var ag_conflict23=4403;
var wifi_enable_chk=4404;
var ZERO_IPV6_ADDRESS=4405;
var port_empty=4406;
var _disable_s=4407;
var IPV6_TEXT154=4408;
var _signup=4409;
var up_tz_74=4410;
var wifi_pass_chk=4411;
var _remove_multi=4412;
var tf_really_langf=4413;
var tf_langf=4414;
var ub_intro_l1=4415;
var ub_intro_l3=4416;
var err404_title=4417;
var err404_detect=4418;
var err404_sug=4419;
var err404_sug1=4420;
var err404_sug2=4421;
var err404_sug3=4422;
var err404_sug4=4423;
var err404_sug5=4424;
var tsc_end_time=4425;
var remote_port_msg=4426;
var TEXT034=4427;
var LW39b=4428;
var _nousername=4429;
var metric_empty=4430;
var TEXT061=4431;
var ES_DIALUP_ERROR_dsc=4432;
var MSG001=4433;
var MSG051=4434;
var MSG012=4435;
var aa_alert_13=4436;
var TEXT044=4437;
var sto_03=4438;
var up_nosave=4439;
var ta_msg_TW=4440;
var sto_04=4441;
var IPV6_TEXT167=4442;
var IPV6_TEXT170=4443;
var help_171=4444;
var DDNS_HOST_ERROR=4445;
var _item_no=4446;
var _usb_not_found=4447;
var srv_name_empty=4448;
var msg_wps_sec_01=4449;
var msg_wps_sec_02=4450;
var msg_wps_sec_03=4451;
var sh_port_tx_00a=4452;
var sh_port_tx_00b=4453;
var sh_port_tx_00=4454;
var sh_port_tx_01=4455;
var sh_port_tx_02=4456;
var sh_port_tx_03=4457;
var sh_port_tx_04=4458;
var sh_port_tx_05=4459;
var sh_port_tx_06=4460;
var sh_port_tx_07=4461;
var sh_port_tx_08=4462;
var sh_port_tx_09=4463;
var sh_port_tx_10=4464;
var sh_port_ddns_01=4465;
var sh_port_ddns_02=4466;
var sh_port_ddns_03=4467;
var sh_port_tx_11=4468;
var sh_port_tx_12=4469;
var sh_port_tx_13=4470;
var sh_port_tx_16=4471;
var sh_port_tx_17=4472;
var sh_port_tx_18=4473;
var sh_port_tx_19=4474;
var sh_port_tx_20=4475;
var sh_port_tx_21=4476;
var sh_port_msg_01=4477;
var sh_port_msg_02=4478;
var sh_port_msg_04=4479;
var sh_port_msg_05=4480;
var sh_port_msg_06=4481;
var sh_port_msg_07=4482;
var sh_port_msg_08=4483;
var sh_port_msg_09=4484;
var sto_http_6=4485;
var file_acc_del_user=4486;
var file_acc_del_path=4487;
var file_acc_del_file=4488;
var _login_a=4489;
var IPv6_ddns_01=4490;
var IPv6_ddns_02=4491;
var IPv6_fw_01=4492;
var IPv6_fw_02=4493;
var IPv6_fw_03=4494;
var IPv6_fw_04=4495;
var IPv6_fw_ipr=4496;
var IPv6_fw_pr=4497;
var IPv6_fw_sr=4498;
var IPv6_fw_dest=4499;
var IPv6_6rd_relay=4500;
var IPv6_6rd_wan=4501;
var IPv6_6to4_relay=4502;
var IPv6_addrSr=4503;
var IPv6_addrEr=4504;
var msg_wps_sec_04=4505;
var msg_wait_sec=4506;
var file_acc_del_empty=4507;
var IPV6_TEXT161a=4508;
var ss_Wstats_2=4509;
var ss_Wstats_5g=4510;
var dlna_t=4511;
var dlna_01=4512;
var dlna_02=4513;
var dlna_03=4514;
var rus_wan_pptp=4515;
var rus_wan_pptp_01=4516;
var rus_wan_l2tp=4517;
var rus_wan_l2tp_01=4518;
var rus_wan_pppoe=4519;
var rus_wan_pppoe_02=4520;
var rus_wan_pppoe_03=4521;
var msg_wps_sec_05=4522;
var webf_login=4523;
var webf_intro=4524;
var webf_title=4525;
var webf_folder=4526;
var webf_hd=4527;
var webf_createfd=4528;
var webf_fd_name=4529;
var webf_upload=4530;
var webf_file_sel=4531;
var dlna_t1=4532;
var dlna_t2=4533;
var help_stor1=4534;
var help_stor2=4535;
var help_stor3=4536;
var help_stor4=4537;
var help_stor5=4538;
var help_stor6=4539;
var help_stor7=4540;
var help_stor8=4541;
var help_stor9=4542;
var help_dlna1=4543;
var webf_non_hd=4544;
var sh_port_tx_22=4545;
var sh_port_tx_23=4546;
var IPv6_Ingress_Filtering_enable=4547;
var share_title_1=4548;
var share_title_2=4549;
var share_title_3=4550;
var share_title_4=4551;
var share_ser_1=4552;
var share_ser_2=4553;
var share_ser_3=4554;
var share_ser_4=4555;
var ddns_disconnecting=4556;
var lan_reserveIP=4557;
var end_ip=4558;
var _NULL=4559;
var ddns_sel2=4560;
var ddns_sel3=4561;
var _remoteipaddr=4562;
var _back=4563;
var _ping_fail=4564;
var _ping_success=4565;
var _wz_disWPS=4566;
var limit_pass_msg=4567;
var _gz_wps_enable=4568;
var _gz_wps_deny=4569;
var bwl_ht204080=4570;
var _supp_close=4571;
var bwl_Mode_ac=4572;
var bwl_Mode_acn=4573;
var bwl_Mode_acna=4574;
var _wireless_2=4575;
var _wireless_5=4576;
var _WPS=4577;
var _statlst=4578;
var _wifiser_title=4579;
var _wifiser_title0=4580;
var _wifiser_title1=4581;
var _wifiser_mode0=4582;
var _wifiser_mode1=4583;
var _wifiser_mode2=4584;
var _wifiser_mode3=4585;
var _wifiser_mode4=4586;
var _wifiser_mode5=4587;
var _wifiser_mode6=4588;
var _wifiser_mode7=4589;
var _wifiser_mode8=4590;
var _wifiser_mode9=4591;
var _wifiser_mode10=4592;
var _wifiser_mode11=4593;
var _wifiser_mode12=4594;
var _wifiser_mode13=4595;
var _wifiser_mode14=4596;
var _wifiser_mode15=4597;
var _wifiser_mode16=4598;
var _wifiser_mode17=4599;
var _wifiser_mode18=4600;
var _wifiser_mode19=4601;
var _wifiser_mode20=4602;
var _wifiser_mode21=4603;
var _wifiser_mode22=4604;
var _wifiser_mode23=4605;
var _wifiser_mode24=4606;
var _wifiser_mode25=4607;
var _wifiser_mode26=4608;
var _wifiser_mode27=4609;
var _wifiser_mode28=4610;
var _wifiser_mode29=4611;
var _wifiser_mode30=4612;
var _wifiser_mode31=4613;
var _wifiser_mode32=4614;
var _wifiser_mode33=4615;
var _wifiser_mode34=4616;
var _wifiser_mode35=4617;
var _wifiser_mode36=4618;
var _wifiser_mode37=4619;
var _wifiser_mode38=4620;
var _wifiser_mode39=4621;
var _wifiser_mode40=4622;
var _wifiser_mode41=4623;
var _adv_txt_00=4624;
var _adv_txt_01=4625;
var _adv_txt_02=4626;
var _adv_txt_03=4627;
var _adv_txt_04=4628;
var _adv_txt_05=4629;
var _adv_txt_06=4630;
var _adv_txt_07=4631;
var _adv_txt_08=4632;
var _adv_txt_09=4633;
var _adv_txt_10=4634;
var _adv_txt_11=4635;
var _adv_txt_12=4636;
var _adv_txt_13=4637;
var _adv_txt_14=4638;
var _adv_txt_15=4639;
var _adv_txt_16=4640;
var _adv_txt_17=4641;
var _adv_txt_18=4642;
var _adv_txt_19=4643;
var _adv_txt_20=4644;
var _adv_txt_21=4645;
var _adv_txt_22=4646;
var _network=4647;
var _management=4648;
var _upload_firm=4649;
var _settings_management=4650;
var _time_cap=4651;
var _system_log=4652;
var _ipv6_status=4653;
var _alg=4654;
var _wan_setting=4655;
var _lan_setting=4656;
var _ipv6_setting=4657;
var _top=4658;
var _network_help=4659;
var _qos_help=4660;
var _wireless_help=4661;
var _administrator_help=4662;
var _wan_conn_type=4663;
var _help_txt2=4664;
var _static=4665;
var _help_txt1=4666;
var _help_txt4=4667;
var _help_txt6=4668;
var _help_txt7=4669;
var _help_txt9=4670;
var _help_txt10=4671;
var _help_txt11=4672;
var _help_txt12=4673;
var _help_txt13=4674;
var _help_txt14=4675;
var _help_txt16=4676;
var _help_txt17=4677;
var _help_txt18=4678;
var _help_txt19=4679;
var _help_txt20=4680;
var _help_txt21=4681;
var _help_txt22=4682;
var _help_txt24=4683;
var _help_txt25=4684;
var _help_txt27=4685;
var _help_txt28=4686;
var _help_txt29=4687;
var _help_txt30=4688;
var _help_txt31=4689;
var _help_txt32=4690;
var _help_txt33=4691;
var _help_txt34=4692;
var _help_txt35=4693;
var _help_txt36=4694;
var _help_txt37=4695;
var _help_txt38=4696;
var _help_txt39=4697;
var _help_txt41=4698;
var _help_txt43=4699;
var _help_txt45=4700;
var _help_txt47=4701;
var _help_txt48=4702;
var _help_txt50=4703;
var _help_txt51=4704;
var _help_txt52=4705;
var _help_txt54=4706;
var _help_txt56=4707;
var _help_txt58=4708;
var _help_txt59=4709;
var _help_txt60=4710;
var _help_txt62=4711;
var _help_txt64=4712;
var _help_txt66=4713;
var _help_txt67=4714;
var _help_txt69=4715;
var _help_txt71=4716;
var _help_txt73=4717;
var _help_txt85=4718;
var _help_txt87=4719;
var _help_txt82=4720;
var _help_txt83=4721;
var _help_txt84=4722;
var _help_txt85=4723;
var _help_txt89=4724;
var _help_txt90=4725;
var _help_txt91=4726;
var _help_txt93=4727;
var _help_txt94=4728;
var _help_txt95=4729;
var _help_txt96=4730;
var _help_txt97=4731;
var _help_txt98=4732;
var _help_txt99=4733;
var _help_txt100=4734;
var _help_txt101=4735;
var _help_txt102=4736;
var _help_txt103=4737;
var _help_txt104=4738;
var _help_txt105=4739;
var _help_txt106=4740;
var _help_txt107=4741;
var _help_txt108=4742;
var _help_txt109=4743;
var _help_txt110=4744;
var _help_txt111=4745;
var _help_txt113=4746;
var _help_txt114=4747;
var _help_txt115=4748;
var _help_txt116=4749;
var _help_txt117=4750;
var _help_txt121=4751;
var _help_txt122=4752;
var _help_txt123=4753;
var _help_txt124=4754;
var _help_txt125=4755;
var _help_txt126=4756;
var _help_txt127=4757;
var _help_txt128=4758;
var _help_txt129=4759;
var _help_txt130=4760;
var _help_txt131=4761;
var _help_txt132=4762;
var _help_txt133=4763;
var _help_txt134=4764;
var _help_txt135=4765;
var _help_txt136=4766;
var _help_txt137=4767;
var _help_txt138=4768;
var _help_txt139=4769;
var _help_txt140=4770;
var _help_txt141=4771;
var _help_txt142=4772;
var _help_txt143=4773;
var _help_txt144=4774;
var _help_txt145=4775;
var _help_txt146=4776;
var _help_txt147=4777;
var _help_txt148=4778;
var _help_txt149=4779;
var _help_txt150=4780;
var _help_txt151=4781;
var _help_txt152=4782;
var _help_txt153=4783;
var _help_txt154=4784;
var _help_txt155=4785;
var _help_txt156=4786;
var _help_txt157=4787;
var _help_txt158=4788;
var _help_txt159=4789;
var _help_txt160=4790;
var _help_txt161=4791;
var _help_txt162=4792;
var _help_txt163=4793;
var _help_txt164=4794;
var _help_txt165=4795;
var _help_txt166=4796;
var _help_txt167=4797;
var _help_txt168=4798;
var _help_txt169=4799;
var _help_txt170=4800;
var _help_txt171=4801;
var _help_txt172=4802;
var _help_txt173=4803;
var _help_txt174=4804;
var _help_txt175=4805;
var _help_txt176=4806;
var _help_txt177=4807;
var _help_txt178=4808;
var _help_txt179=4809;
var _help_txt180=4810;
var _help_txt181=4811;
var _help_txt182=4812;
var _help_txt183=4813;
var _help_txt184=4814;
var _help_txt185=4815;
var _help_txt186=4816;
var _help_txt187=4817;
var _help_txt188=4818;
var _help_txt189=4819;
var _help_txt190=4820;
var _help_txt191=4821;
var _help_txt192=4822;
var _help_txt193=4823;
var _help_txt194=4824;
var _help_txt195=4825;
var _help_txt196=4826;
var _help_txt197=4827;
var _help_txt198=4828;
var _help_txt199=4829;
var _help_txt200=4830;
var _help_txt201=4831;
var _help_txt202=4832;
var _help_txt203=4833;
var _help_txt204=4834;
var _help_txt205=4835;
var _help_txt206=4836;
var _help_txt207=4837;
var _help_txt208=4838;
var _help_txt209=4839;
var _help_txt210=4840;
var _help_txt211=4841;
var _help_txt212=4842;
var _help_txt213=4843;
var _help_txt214=4844;
var _help_txt215=4845;
var _help_txt216=4846;
var _help_txt217=4847;
var _help_txt218=4848;
var _help_txt219=4849;
var _help_txt220=4850;
var _help_txt221=4851;
var _help_txt222=4852;
var _help_txt223=4853;
var _help_txt224=4854;
var _help_txt225=4855;
var _help_txt226=4856;
var _help_txt227=4857;
var _help_txt228=4858;
var _help_txt229=4859;
var _help_txt230=4860;
var _help_txt231=4861;
var _help_txt232=4862;
var _help_txt233=4863;
var _help_txt234=4864;
var _help_txt235=4865;
var _help_txt236=4866;
var _help_txt237=4867;
var _help_txt238=4868;
var _help_txt239=4869;
var _help_txt240=4870;
var _help_txt241=4871;
var _help_txt242=4872;
var _help_txt243=4873;
var _help_txt244=4874;
var _help_txt245=4875;
var _help_txt246=4876;
var _help_txt247=4877;
var _help_txt248=4878;
var _help_txt249=4879;
var _help_txt250=4880;
var _help_txt251=4881;
var _help_txt252=4882;
var _help_txt253=4883;
var _help_txt254=4884;
var _help_txt255=4885;
var _help_txt256=4886;
var _help_txt257=4887;
var _help_txt258=4888;
var _help_txt259=4889;
var _help_txt260=4890;
var _help_txt261=4891;
var _help_txt262=4892;
var _help_txt263=4893;
var _help_txt264=4894;
var _help_txt265=4895;
var _help_txt266=4896;
var _help_txt267=4897;
var _help_txt268=4898;
var _help_txt269=4899;
var _help_txt270=4900;
var _help_txt271=4901;
var _help_txt272=4902;
var _help_txt273=4903;
var _help_txt274=4904;
var _help_txt275=4905;
var _help_txt276=4906;
var _help_txt277=4907;
var _help_txt278=4908;
var _help_txt279=4909;
var _help_txt280=4910;
var _help_txt281=4911;
var _help_txt282=4912;
var _help_txt283=4913;
var _help_txt284=4914;
var _help_txt285=4915;
var _help_txt286=4916;
var _help_txt287=4917;
var _help_txt288=4918;
var _help_txt289=4919;
var _help_txt290=4920;
var _help_txt291=4921;
var _help_txt292=4922;
var _help_txt293=4923;
var _help_txt294=4924;
var _help_txt295=4925;
var _help_txt296=4926;
var _help_txt297=4927;
var _help_txt298=4928;
var _adv_txt_23=4929;
var _adv_txt_24=4930;
var _adv_txt_25=4931;
var _adv_txt_26=4932;
var _adv_txt_27=4933;
var _net_ipv6_01=4934;
var _net_ipv6_02=4935;
var _net_ipv6_03=4936;
var _net_ipv6_04=4937;
var _net_ipv6_05=4938;
var _net_ipv6_06=4939;
var _net_ipv6_07=4940;
var _net_ipv6_08=4941;
var _net_ipv6_09=4942;
var _net_ipv6_10=4943;
var _net_ipv6_11=4944;
var _net_ipv6_12=4945;
var _qos_txt00=4946;
var _qos_txt01=4947;
var _qos_txt02=4948;
var _qos_txt03=4949;
var _qos_txt04=4950;
var _qos_txt05=4951;
var _qos_txt06=4952;
var _qos_txt07=4953;
var _qos_txt08=4954;
var _qos_txt09=4955;
var _qos_txt10=4956;
var _qos_txt11=4957;
var _qos_txt12=4958;
var _qos_txt13=4959;
var _qos_txt14=4960;
var _qos_txt15=4961;
var _qos_txt16=4962;
var _qos_txt17=4963;
var _qos_txt18=4964;
var _qos_txt19=4965;
var _qos_txt20=4966;
var _qos_txt21=4967;
var _qos_txt22=4968;
var _qos_txt23=4969;
var _qos_txt24=4970;
var _qos_txt25=4971;
var _qos_txt26=4972;
var _qos_txt27=4973;
var _qos_txt28=4974;
var _qos_txt29=4975;
var _qos_txt30=4976;
var _qos_txt31=4977;
var _qos_txt32=4978;
var _qos_txt33=4979;
var _qos_txt34=4980;
var _qos_txt35=4981;
var _qos_txt36=4982;
var _qos_txt37=4983;
var _qos_txt38=4984;
var _qos_txt39=4985;
var _qos_txt40=4986;
var _qos_txt41=4987;
var _qos_txt42=4988;
var _qos_txt43=4989;
var _qos_txt44=4990;
var _qos_txt45=4991;
var _qos_txt46=4992;
var _basic_wireless_settings=4993;
var _desc_basic=4994;
var _desc_station_list=4995;
var _desc_wps=4996;
var _wireless_network=4997;
var _wds_long=4998;
var _wps_config=4999;
var _wps_summary=5000;
var _wps_action=5001;
var _dhcp_clients=5002;
var _desc_wps_action=5003;
var _lb_radio_onoff=5004;
var _lb_radio_off_sche=5005;
var _wmode_ssid=5006;
var _lb_multi_ssid_1=5007;
var _lb_multi_ssid_2=5008;
var _lb_multi_ssid_3=5009;
var _lb_multi_ssid_4=5010;
var _lb_multi_ssid_5=5011;
var _lb_multi_ssid_6=5012;
var _lb_multi_ssid_7=5013;
var _lb_broadcast_ssid=5014;
var _lb_phy_mode=5015;
var _lb_enc_type=5016;
var _lb_enc_key=5017;
var _lb_apmacaddr=5018;
var _lb_coexistence=5019;
var _lb_rdg=5020;
var _lb_mcs=5021;
var _lb_exten_channel=5022;
var _lb_a_msdu=5023;
var _lb_autoba=5024;
var _lb_declineba=5025;
var _lb_forty_into=5026;
var _lb_wifi_opt=5027;
var _lb_ht_txstream=5028;
var _lb_ht_rxstream=5029;
var _lb_wps_ext_reg_lock=5030;
var _sel_autoselect=5031;
var _sel_mixed=5032;
var _sel_greenfield=5033;
var _long=5034;
var _btn_radio_on=5035;
var _btn_radio_off=5036;
var _MSG_woff=5037;
var _desc_advanced=5038;
var _bx_advanced_2=5039;
var _bx_advanced_3=5040;
var _bx_advanced_4=5041;
var _lb_bg_protection=5042;
var _hint_beacon=5043;
var _hint_dtim=5044;
var _lb_frag_thres=5045;
var _hint_frag_thres=5046;
var _hint_rts_thres=5047;
var _lb_txpower=5048;
var _lb_short_preamble=5049;
var _lb_short_slot=5050;
var _lb_tx_burst=5051;
var _lb_pkt_aggregate=5052;
var _lb_80211h_support=5053;
var _hint_only_a_band=5054;
var _lb_country_code=5055;
var _lb_wmm_capable=5056;
var _lb_apsd_capable=5057;
var _lb_dls_capable=5058;
var _lb_wmm_param=5059;
var _lb_wmm_config=5060;
var _lb_video_turbine=5061;
var _lb_multi_uni=5062;
var _lb_expire_in=5063;
var _pwr_full=5064;
var _pwr_half=5065;
var _pwr_low=5066;
var _tl_wmm_settings=5067;
var _lb_wmm_param_ap=5068;
var _lb_wmm_param_station=5069;
var m_bwl_Mode_3=5070;
var m_bwl_Mode_8=5071;
var m_bwl_Mode_11=5072;
var m_bwl_Mode5_1=5073;
var m_bwl_Mode5_2=5074;
var m_bwl_Mode5_3=5075;
var _singal=5076;
var _bssid=5077;
var _wps_cur_state=5078;
var _wps_configed=5079;
var _wps_ssid=5080;
var _wps_sec_mode=5081;
var _wps_enc_type=5082;
var _wps_def_key_idx=5083;
var _hex=5084;
var _ascii=5085;
var _wps_key=5086;
var _ap_pin=5087;
var _desc_dhcp_client_list=5088;
var _wifiser_mode42=5089;
var _processing=5090;
var _netwrk_status_addr=5091;
var _system_info=5092;
var _system_time=5093;
var _system_up_time=5094;
var _internet_configs=5095;
var _connected_type=5096;
var _wan_ip_addr=5097;
var _pri_dns=5098;
var _sec_dns=5099;
var _24Ghz_wireless=5100;
var _5Ghz_wireless=5101;
var _SYSLOG_DESC=5102;
var _enable_system_log=5103;
var _time_setting=5104;
var _TIME_DESC=5105;
var _daylight_saving_time=5106;
var _ntp_settings=5107;
var _ntp_server=5108;
var _ntp_sync=5109;
var _date_time_settings=5110;
var _SETTINGS_MANAGER_DESC=5111;
var _export=5112;
var _settings_file_location=5113;
var _import=5114;
var _upgrade_firmw=5115;
var _FIRMW_DESC=5116;
var _FIRMW_DESC_sub=5117;
var _location=5118;
var _apply=5119;
var _system_management=5120;
var _SYS_MANGER_DESC=5121;
var _max_length_characters=5122;
var _device_url_settings=5123;
var _device_url=5124;
var _device_name_settings=5125;
var _ddns_settings=5126;
var _remote_management=5127;
var _remote_control_via_wan=5128;
var _remote_port=5129;
var _reset=5130;
var _ADV_NETWRK_DESC=5131;
var _wan_ping_respond=5132;
var _schedule_rules=5133;
var _SCHEDULE_DESC=5134;
var _add_sche_rule=5135;
var _tsc_allday_24hr=5136;
var _schedule_rule_list=5137;
var _time_stamp=5138;
var _24hr=5139;
var m_bwl_Mode5_4=5140;
var _routing_bet_zone=5141;
var _mac_clone=5142;
var _mac_addr_clone=5143;
var _dns_server_setting=5144;
var _dhcp_setting=5145;
var _DHCP_DESC=5146;
var _wan_setting_l=5147;
var _mtu_default_byte=5148;
var _wan_if_ip_setting=5149;
var _opeartion_mode=5150;
var _keep_alive=5151;
var _keep_alive_mode_redial=5152;
var _on_demand_mode_idle_time=5153;
var _mintues_lower=5154;
var _l2tp_setting=5155;
var _pptp_setting=5156;
var _dynamic=5157;
var _lan_setting_l=5158;
var _LAN_DESC=5159;
var _dhcp_server_setting=5160;
var _dhcp_start_ip=5161;
var _dhcp_end_ip=5162;
var _other_setting=5163;
var _8021d_spanning_tree=5164;
var _lltd=5165;
var _igmp_proxy=5166;
var _pppoe_relay=5167;
var _dns_proxy=5168;
var _add_dhcp_reservation=5169;
var _copy_pc_mac=5170;
var _copy=5171;
var _dhcp_reservation_ready_group=5172;
var _edit_dhcp_reservation=5173;
var _delete_all=5174;
var _delete_selected=5175;
var _config_via_pin=5176;
var _config_via_pbc=5177;
var _alg_config_l=5178;
var _ALG_DESC=5179;
var _description=5180;
var _email_receiving=5181;
var _pop3_l=5182;
var _smtp_l=5183;
var _streaming_media=5184;
var _rtp_l=5185;
var _rtsp_1=5186;
var _mms_l=5187;
var _streaming_media_voip=5188;
var _session_init_protocol_l=5189;
var _h323_l=5190;
var _file_transfer=5191;
var _ftp_l=5192;
var _tftp_l=5193;
var _remote_control=5194;
var _telnet=5195;
var _instant_messaging=5196;
var _msn_messenger=5197;
var _ipsec=5198;
var _save_status=5199;
var _dmz_settings=5200;
var _DMZ_DESC=5201;
var _AC_DESC=5202;
var _add_port_block_rule=5203;
var _policy_enable=5204;
var _policy_name=5205;
var _client_ip_addr=5206;
var _rule_define=5207;
var _special_service=5208;
var _user_define=5209;
var _tcp_ports=5210;
var _ex_21_or_3_500=5211;
var _udp_ports=5212;
var _service=5213;
var _edit_port_block_rule=5214;
var _port_block_rule=5215;
var _add_ip_block_rule=5216;
var _edit_ip_block_rule=5217;
var _ip_block_rule_list=5218;
var _add_weburl_rule=5219;
var _edit_weburl_rule=5220;
var _weburl_rule_list=5221;
var _email_sending=5222;
var _file_transfer_l=5223;
var _telnet_service=5224;
var _dns_query=5225;
var _tcp_protocol=5226;
var _udp_protocol=5227;
var _www=5228;
var _err_ip_addr_format=5229;
var _err_ip_mask=5230;
var _err_input_format=5231;
var _err_ip_addr=5232;
var _static_routing_settings=5233;
var _ROUTING_DESC=5234;
var _add_static_route=5235;
var _dest_ip_addr=5236;
var _dest_ip_mask=5237;
var _physical_port=5238;
var _enable_rip=5239;
var _rip_mode=5240;
var _static_route_list=5241;
var _processing_plz_wait=5242;
var _rebooting_plz_wait=5243;
var _L2TPgw=5244;
var _retry=5245;
var _skip=5246;
var _chk_wanconn_msg_00=5247;
var _tnw_01=5248;
var _tnw_02=5249;
var _tnw_03=5250;
var _tnw_04=5251;
var _ssid=5252;
var _auth_type=5253;
var _finish=5254;
var _tnw_05=5255;
var _tnw_dhcp=5256;
var _tnw_static=5257;
var _tnw_pppoe=5258;
var _tnw_pptp=5259;
var _tnw_l2tp=5260;
var _tnw_06=5261;
var _mac=5262;
var _tnw_clone=5263;
var _tnw_07=5264;
var _wan_ipaddr=5265;
var _wan_submask=5266;
var _wan_gwaddr=5267;
var _dns_1=5268;
var _dns_2=5269;
var _tnw_08=5270;
var _tnw_09=5271;
var _my_ip=5272;
var _server_ip=5273;
var _pptp_account=5274;
var _pptp_password=5275;
var _pptp_password_re=5276;
var _tnw_10=5277;
var _l2tp_account=5278;
var _l2tp_password=5279;
var _l2tp_password_re=5280;
var _tnw_11=5281;
var _tnw_12=5282;
var _tnw_13=5283;
var _tnw_14=5284;
var _print=5285;
var _TAG00840=5286;
var IPV6_TEXT171=5287;
var IPV6_TEXT172=5288;
var _wps_shared=5289;
var _wps_open=5290;
var _webfilterrule_dup=5291;
var _wps_24g=5292;
var _wps_5g=5293;
var _name_ssid=5294;
var _warranty=5295;
var _usb=5296;
var _samba_server=5297;
var _ftp_server=5298;
var _print_server=5299;
var _connected_devices=5300;
var _guest_network=5301;
var _guest_text1=5302;
var _network_bridge=5303;
var _inet_access_only=5304;
var _security_no=5305;
var _security_low=5306;
var _security_middle=5307;
var _security_high=5308;
var _parental_control=5309;
var _has_inet_connection=5310;
var _no_inet_connection=5311;
var _guest_network_enabled=5312;
var _guest_network_disabled=5313;
var _usb_connected=5314;
var _no_usb_connected=5315;
var _household_access=5316;
var _confirm_settings=5317;
var _check_connection=5318;
var _address=5319;
var _ha_rule_list=5320;
var _add_ha_rule=5321;
var _edit_ha_rule=5322;
var _wlan_11n_not_support_wep_wpa_tkip=5323;
var _lb_radio_on_sche=5324;
var _rule_full=5325;
var _wds_cant_enble=5326;
var _LAN_CHK_REBOOT_MSG=5327;
var _specify_url=5328;
var _ipaddr_used=5329;
var _macaddr_used=5330;
var _lan_dr=5331;
var _adv_rtd=5332;
var _lb_a_mpdu=5333;
var PRODUCT_DESC_810=5334;
var PRODUCT_DESC_817=5335;
var _ipaddr_used=5336;
var _macaddr_used=5337;
var no_wan_up=5338;
var dev_mode_ap=5339;
var dev_mode_repeater=5340;
var dev_mode_wisp=5341;
var ap_client=5342;
var extend_ssid=5343;
var wlan_client_list=5344;
var desc_ap=5345;
var desc_repeater=5346;
var desc_wisp=5347;
var wiz_select_site=5348;
var wiz_refresh_site=5349;
var wiz_no_result=5350;
var wiz_no_selected=5351;
var wiz_quit=5352;
var custom_range=5353;
var _internet_setting=5354;
var desc_static_ipv6=5355;
var _s_packet=5356;
var _wps_lock=5357;
var pptp_passthrough=5358;
var l2tp_passthrough=5359;
var desc_ap_lan=5360;
var attain_ip=5361;
var dev_stat=5362;
var desc_ap_sch=5363;
