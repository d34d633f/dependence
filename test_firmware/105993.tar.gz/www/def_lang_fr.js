//Version=1.01b01
//Language=FRENCH
//Date=Tue, 24, Feb, 2015
//Merged=FALSE
//Merged Fw=FALSE
var msg = new Array ( //
	"L'adresse IP entrée est incorrecte.", //INVALID_IP_ADDRESS
	"L'adresse IP ne peut pas être égale à zéro.", //ZERO_IP_ADDRESS
	"Adresse IP", //IP_ADDRESS_DESC
	"Le masque de sous-réseau entré est incorrect.", //INVALID_MASK_ADDRESS
	"Le masque de sous-réseau ne peut pas être égal à zéro.", //ZERO_MASK_ADDRESS
	"Masque de sous-réseau", //MASK_ADDRESS_DESC
	"L'adresse IP de passerelle saisie est incorrecte.", //INVALID_GATEWAY_ADDRESS
	"L'adresse IP de passerelle ne peut pas être égale à zéro.", //ZERO_GATEWAY_ADDRESS
	"Adresse IP de passerelle", //GATEWAY_ADDRESS_DESC
	"%s L'adresse IP de la passerelle %s doit se trouver dans le sous-réseau externe.", //NOT_SAME_DOMAIN
	"L'adresse IP de départ entrée est incorrecte (plage IP : 1~254)", //INVALID_START_IP
	"Veuillez saisir un autre serveur SMTP ou une autre adresse IP", //SMTP_SERVER_ERROR
	"Adresse IP de départ", //START_IP_DESC
	"L'adresse IP du réseau local et l'adresse IP de début ne sont pas dans le même sous-réseau", //START_INVALID_DOMAIN
	"L'adresse IP finale entrée est incorrecte.", //INVALID_END_IP
	"Veuillez entrer un autre domaine", //DOMAIN_ERROR
	"L'adresse IP du réseau local et l'adresse IP de fin ne sont pas dans le même sous-réseau", //END_INVALID_DOMAIN
	"L'adresse DNS principale entrée est incorrecte.", //INVALID_DNS_ADDRESS
	"L'adresse du DNS principal ne peut pas être nulle", //ZERO_DNS_ADDRESS
	"Adresse DNS primaire", //DNS_ADDRESS_DESC
	"Le champ SSID ne doit pas être vide.", //SSID_EMPTY_ERROR
	"Impossible de désactiver le WEP lorsque le type d'authentification est défini sur Clé partagée", //AUTH_TYPE_ERROR
	"Le mot de passe doit comporter au moins 8 caractères.", //PSK_LENGTH_ERROR
	"Le mot de passe confirmé ne correspond pas au nouveau.", //PSK_MATCH_ERROR
	"Le mot de passe confirmé ne correspond pas au nouveau mot de passe", //MATCH_PWD_ERROR
	"Le champ Clé WEP sélectionné ne peut pas être vierge", //WEP_KEY_EMPTY
	"Saisissez une autre Adresse IP.", //ZERO_STATIC_DHCP_IP
	"Quitter l'assistant de configuration et supprimer les paramètres ?", //QUIT_WIZARD
	"L'adresse MAC saisie est incorrecte.", //MAC_ADDRESS_ERROR
	"L'adresse IP de fin doit être supérieure à l'adresse IP de début", //IP_RANGE_ERROR
	"L'adresse DNS secondaire entrée est incorrecte.", //INVALID_SEC_DNS_ADDRESS
	"L'adresse DNS secondaire ne peut pas être égale à zéro ou vierge.", //ZERO_SEC_DNS_ADDRESS
	"Adresse DNS secondaire", //SEC_DNS_ADDRESS_DESC
	"Le mot de passe de confirmation ne correspond pas au nouveau mot de passe Admin", //ADMIN_PASS_ERROR
	"Le mot de passe de confirmation ne correspond pas au nouveau mot de passe Utilisateur", //USER_PASS_ERROR
	"Le nom d'hôte est incorrect !", //DDNS_HOST_ERROR
	"Saisissez une autre adresse IP de départ", //ZERO_START_IP
	"Voulez-vous vraiment réinitialiser le périphérique à ses paramètres d'usine par défaut ?\nTous les paramètres actuels seront perdus.", //RESTORE_DEFAULT
	"Voulez-vous vraiment redémarrer le périphérique ?\nLe redémarrage déconnectera toutes les sessions Internet actives.", //REBOOT_ROUTER
	"Charger les paramètres depuis un fichier de configuration enregistré ?", //LOAD_SETTING
	"Vous devez d'abord entrer le nom d'un fichier de configuration.", //LOAD_FILE_ERROR
	"Veuillez saisir au moins un domaine de contrôle", //CONTROL_DOMAIN_ERROR
	"Veuillez entrer un autre nom de serveur", //DDNS_SERVER_ERROR
	"Voulez-vous vraiment supprimer cette règle de serveur virtuel ?", //DEL_SERVER_MSG
	"Voulez-vous vraiment supprimer cette règle d'application ?", //DEL_APPLICATION_MSG
	"Voulez-vous vraiment supprimer ce filtre ?", //DEL_FILTER_MSG
	"Voulez-vous vraiment supprimer cette route ?", //DEL_ROUTE_MSG
	"Voulez-vous vraiment supprimer cette adresse  MAC ?", //DEL_MAC_MSG
	"Voulez-vous vraiment supprimer ce mot clé ?", //DEL_KEYWORD_MSG
	"Voulez-vous vraiment supprimer ce domaine ?", //DEL_DOMAIN_MSG
	"Voulez-vous vraiment supprimer cette entrée ?", //DEL_ENTRY_MSG
	"Voulez-vous vraiment supprimer cette réservation DHCP ?", //DEL_STATIC_DHCP_MSG
	"Veuillez entrer un autre numéro de port", //PORT_ERROR
	"Veuillez entrer un autre domaine autorisé", //PERMIT_DOMAIN_ERROR
	"Sélectionnez un fichier de microprogramme pour mettre à jour le routeur à", //FIRMWARE_UPGRADE_ERROR
	"Le mot clé saisi existe déjà dans la liste", //SAME_KEYWORD_ERROR
	"Saisissez une autre clé.", //WIZARD_KEY_EMPTY
	"Impossible d'ajouter un autre mot clé", //ADD_KEYWORD_ERROR
	"Commencez par sélectionner une machine.", //SELECT_MACHINE_ERROR
	"Le domaine saisi existe déjà dans la liste de domaines bloqués", //SAME_BLOCK_DOMAIN
	"Impossible d'ajouter un autre domaine bloqué", //ADD_BLOCK_DOMAIN_ERROR
	"Le domaine saisi existe déjà dans la liste de domaines autorisés", //SAME_PERMIT_DOMAIN
	"Saisissez un autre mot de passe", //DDNS_PASS_ERROR
	"Impossible d'ajouter un autre domaine autorisé", //ADD_PERMIT_DOMAIN_ERROR
	"Veuillez entrer un autre domaine bloqué", //BLOCK_DOMAIN_ERROR
	"Impossible d'ajouter d'autres domaines de contrôle", //ADD_CONTROL_DOMAIN_ERROR
	"Veuillez saisir un autre mot de passe de sécurité sans fil", //SECURITY_PWD_ERROR
	"L'adresse IP du serveur RADIUS 1 entrée est incorrecte.", //INVALID_RADIUS_SERVER1_IP
	"L'adresse  IP du serveur Radius 1 ne peut pas être égale à zéro ou vierge", //ZERO_RADIUS_SERVER1_IP
	"Adresse IP du Serveur Radius 1", //RADIUS_SERVER1_IP_DESC
	"L'adresse IP du serveur RADIUS 2 entrée est incorrecte.", //INVALID_RADIUS_SERVER2_IP
	"L'adresse  IP du serveur Radius 2 ne peut pas être égale à zéro ou vierge", //ZERO_RADIUS_SERVER2_IP
	"Adresse IP du Serveur Radius 2", //RADIUS_SERVER2_IP_DESC
	"L'adresse IP entrée est incorrecte (plage IP : 1~254)", //INVALID_STATIC_DHCP_IP
	"Veuillez saisir une autre adresse  IP de fin", //ZERO_END_IP
	"Veuillez entrer un autre nom", //NAME_ERROR
	"L'adresse IP du serveur entrée est incorrecte", //INVALID_SERVER_IP
	"L'adresse IP du serveur ne peut pas être égale à zéro ou vierge.", //ZERO_SERVER_IP
	"Adresse IP du serveur", //SERVER_IP_DESC
	"Les mots de passe saisis ne concordent pas", //MATCH_WIZARD_PWD_ERROR
	"L'adresse  IP source de départ entrée est incorrecte.", //INVALID_SOURCE_START_IP
	"L'adresse  IP source de départ ne peut pas être égale à zéro ou vierge", //ZERO_SOURCE_START_IP
	"Adresse IP source de départ", //SOURCE_START_IP_DESC
	"L'adresse  IP source de fin entrée est incorrecte", //INVALID_SOURCE_END_IP
	"L'adresse  IP source de fin ne peut pas être égale à zéro ou vierge", //ZERO_SOURCE_END_IP
	"Adresse IP source finale", //SOURCE_END_IP_DESC
	"L'adresse  IP cible de départ entrée est incorrecte", //INVALID_DEST_START_IP
	"L'adresse  IP cible de départ ne peut pas être égale à zéro ou vierge", //ZERO_DEST_START_IP
	"Adresse IP cible de départ", //DEST_START_IP_DESC
	"L'adresse  IP cible de fin entrée est incorrecte", //INVALID_DEST_END_IP
	"L'adresse  IP cible de fin ne peut pas être égale à zéro ou vierge", //ZERO_DEST_END_IP
	"Adresse IP cible de fin", //DEST_END_IP_DESC
	"Le mot de passe doit comporter entre 8 et 63 caractères.", //PSK_OVER_LEN
	"Réinitialiser JumpStart ?", //RESET_JUMPSTAR
	"Voulez-vous vraiment supprimer cette règle ?", //DEL_RULE_MSG
	"Voulez-vous vraiment supprimer ce calendrier ?", //DEL_SCHEDULE_MSG
	"Impossible d'ajouter un autre calendrier", //ADD_SCHEDULE_ERROR
	"Le nom de calendrier ne peut pas être vide", //SCHEDULE_NAME_ERROR
	"Le nom de calendrier ne peut pas contenir d'espaces", //SCHEDULE_NAME_SPACE_ERROR
	"L'heure de début saisie n'est pas valide", //START_TIME_ERROR
	"L'heure de fin saisie n'est pas valide", //END_TIME_ERROR
	"L'heure de départ ne peut pas être supérieure à l'heure de fin", //TIME_RANGE_ERROR
	"Sélectionnez un mot clé à supprimer", //DEL_KEYWORD_ERROR
	"Sélectionnez un domaine autorisé à supprimer", //DEL_PERMIT_DOMAIN_ERROR
	"Sélectionnez un domaine bloqué à supprimer", //DEL_BLOCK_DOMAIN_ERROR
	"La règle de contrôle parental saisie est déjà dans la liste.", //DUPLICATE_URL_ERROR
	"Erreur de nom de connexion", //LOGIN_NAME_ERROR
	"Erreur de mot de passe de connexion", //LOGIN_PASS_ERROR
	"La %s est en conflit avec l'adresse IP du réseau local, veuillez la ressaisir.", //THE_SAME_LAN_IP
	"Le PSK doit être hexadécimal.", //THE_PSK_IS_HEX
	"L'adresse IP et l'adresse IP de réservation ne se trouvent pas sur le même sous-réseau.", //SER_NOT_SAME_DOMAIN
	"Cette page comporte des données non enregistrées. Voulez-vous les annuler ?%s Si non, cliquez sur Annuler, puis cliquez sur Enregistrer les paramètres.%s Si oui, cliquez sur OK.", //IS_CHANGE_DATA
	"Le mot de passe de confirmation ne correspond pas au nouveau mot de passe utilisateur", //DDNS_PASS_ERROR_MARTH
	"Le nom de règle ne peut pas être une chaîne vide.", //INBOUND_NAME_ERROR
	"Le numéro de port final doit être supérieur au numéro de port de départ", //PORT_RANGE_ERROR
	"Voulez-vous vraiment activer/désactiver ?", //CHECK_ENABLE
	"Souhaitez-vous vraiment supprimer", //DEL_MSG
	"Vous devez annuler toutes les modifications pour définir un nouveau calendrier.\nCliquez sur OK pour annuler ces modifications et afficher la page Calendrier.\nSinon, cliquez sur Annuler.", //GO_SCHEDULE
	"Veuillez entrer un nom d'utilisateur", //PPP_USERNAME_EMPTY
	"Aucune modification n'a été apportée. Procéder quand même à l'enregistrement ?", //FORM_MODIFIED_CHECK
	"Commencez par sélectionner un nom d'application.", //SELECT_APPLICATION_ERROR
	"Commencez par sélectionner un nom d'ordinateur", //SELECT_COMPUTER_ERROR
	"Veuillez entrer un autre nom", //STATIC_DHCP_NAME
	"Sélectionnez un domaine de contrôle à supprimer", //DEL_CONTROL_DOMAIN_ERROR
	"Veuillez entrer un autre mot clé", //KEYWORD_ERROR
	"Saisissez une adresse IP privée.", //PRIVATE_IP_ERROR
	"Veuillez entrer un numéro de port de pare-feu", //PUBLIC_PORT_ERROR
	"Veuillez entrer un numéro de port de déclenchement", //TRIGGER_PORT_ERROR
	"Veuillez saisir une adresse électronique valide", //EMAIL_ADDRESS_ERROR
	"Saisissez un nom d'hôte ou une adresse IP", //PING_IP_ERROR
	"Seul le compte Admin peut télécharger les paramètres", //DOWNLOAD_SETTING_ERROR
	"Saisissez un autre nom d'utilisateur", //DDNS_USER_ERROR
	"Adresse IP de fin", //END_IP_DESC
	"" //MAX
);
var INVALID_IP_ADDRESS=0;
var ZERO_IP_ADDRESS=1;
var IP_ADDRESS_DESC=2;
var INVALID_MASK_ADDRESS=3;
var ZERO_MASK_ADDRESS=4;
var MASK_ADDRESS_DESC=5;
var INVALID_GATEWAY_ADDRESS=6;
var ZERO_GATEWAY_ADDRESS=7;
var GATEWAY_ADDRESS_DESC=8;
var NOT_SAME_DOMAIN=9;
var INVALID_START_IP=10;
var SMTP_SERVER_ERROR=11;
var START_IP_DESC=12;
var START_INVALID_DOMAIN=13;
var INVALID_END_IP=14;
var DOMAIN_ERROR=15;
var END_INVALID_DOMAIN=16;
var INVALID_DNS_ADDRESS=17;
var ZERO_DNS_ADDRESS=18;
var DNS_ADDRESS_DESC=19;
var SSID_EMPTY_ERROR=20;
var AUTH_TYPE_ERROR=21;
var PSK_LENGTH_ERROR=22;
var PSK_MATCH_ERROR=23;
var MATCH_PWD_ERROR=24;
var WEP_KEY_EMPTY=25;
var ZERO_STATIC_DHCP_IP=26;
var QUIT_WIZARD=27;
var MAC_ADDRESS_ERROR=28;
var IP_RANGE_ERROR=29;
var INVALID_SEC_DNS_ADDRESS=30;
var ZERO_SEC_DNS_ADDRESS=31;
var SEC_DNS_ADDRESS_DESC=32;
var ADMIN_PASS_ERROR=33;
var USER_PASS_ERROR=34;
var DDNS_HOST_ERROR=35;
var ZERO_START_IP=36;
var RESTORE_DEFAULT=37;
var REBOOT_ROUTER=38;
var LOAD_SETTING=39;
var LOAD_FILE_ERROR=40;
var CONTROL_DOMAIN_ERROR=41;
var DDNS_SERVER_ERROR=42;
var DEL_SERVER_MSG=43;
var DEL_APPLICATION_MSG=44;
var DEL_FILTER_MSG=45;
var DEL_ROUTE_MSG=46;
var DEL_MAC_MSG=47;
var DEL_KEYWORD_MSG=48;
var DEL_DOMAIN_MSG=49;
var DEL_ENTRY_MSG=50;
var DEL_STATIC_DHCP_MSG=51;
var PORT_ERROR=52;
var PERMIT_DOMAIN_ERROR=53;
var FIRMWARE_UPGRADE_ERROR=54;
var SAME_KEYWORD_ERROR=55;
var WIZARD_KEY_EMPTY=56;
var ADD_KEYWORD_ERROR=57;
var SELECT_MACHINE_ERROR=58;
var SAME_BLOCK_DOMAIN=59;
var ADD_BLOCK_DOMAIN_ERROR=60;
var SAME_PERMIT_DOMAIN=61;
var DDNS_PASS_ERROR=62;
var ADD_PERMIT_DOMAIN_ERROR=63;
var BLOCK_DOMAIN_ERROR=64;
var ADD_CONTROL_DOMAIN_ERROR=65;
var SECURITY_PWD_ERROR=66;
var INVALID_RADIUS_SERVER1_IP=67;
var ZERO_RADIUS_SERVER1_IP=68;
var RADIUS_SERVER1_IP_DESC=69;
var INVALID_RADIUS_SERVER2_IP=70;
var ZERO_RADIUS_SERVER2_IP=71;
var RADIUS_SERVER2_IP_DESC=72;
var INVALID_STATIC_DHCP_IP=73;
var ZERO_END_IP=74;
var NAME_ERROR=75;
var INVALID_SERVER_IP=76;
var ZERO_SERVER_IP=77;
var SERVER_IP_DESC=78;
var MATCH_WIZARD_PWD_ERROR=79;
var INVALID_SOURCE_START_IP=80;
var ZERO_SOURCE_START_IP=81;
var SOURCE_START_IP_DESC=82;
var INVALID_SOURCE_END_IP=83;
var ZERO_SOURCE_END_IP=84;
var SOURCE_END_IP_DESC=85;
var INVALID_DEST_START_IP=86;
var ZERO_DEST_START_IP=87;
var DEST_START_IP_DESC=88;
var INVALID_DEST_END_IP=89;
var ZERO_DEST_END_IP=90;
var DEST_END_IP_DESC=91;
var PSK_OVER_LEN=92;
var RESET_JUMPSTAR=93;
var DEL_RULE_MSG=94;
var DEL_SCHEDULE_MSG=95;
var ADD_SCHEDULE_ERROR=96;
var SCHEDULE_NAME_ERROR=97;
var SCHEDULE_NAME_SPACE_ERROR=98;
var START_TIME_ERROR=99;
var END_TIME_ERROR=100;
var TIME_RANGE_ERROR=101;
var DEL_KEYWORD_ERROR=102;
var DEL_PERMIT_DOMAIN_ERROR=103;
var DEL_BLOCK_DOMAIN_ERROR=104;
var DUPLICATE_URL_ERROR=105;
var LOGIN_NAME_ERROR=106;
var LOGIN_PASS_ERROR=107;
var THE_SAME_LAN_IP=108;
var THE_PSK_IS_HEX=109;
var SER_NOT_SAME_DOMAIN=110;
var IS_CHANGE_DATA=111;
var DDNS_PASS_ERROR_MARTH=112;
var INBOUND_NAME_ERROR=113;
var PORT_RANGE_ERROR=114;
var CHECK_ENABLE=115;
var DEL_MSG=116;
var GO_SCHEDULE=117;
var PPP_USERNAME_EMPTY=118;
var FORM_MODIFIED_CHECK=119;
var SELECT_APPLICATION_ERROR=120;
var SELECT_COMPUTER_ERROR=121;
var STATIC_DHCP_NAME=122;
var DEL_CONTROL_DOMAIN_ERROR=123;
var KEYWORD_ERROR=124;
var PRIVATE_IP_ERROR=125;
var PUBLIC_PORT_ERROR=126;
var TRIGGER_PORT_ERROR=127;
var EMAIL_ADDRESS_ERROR=128;
var PING_IP_ERROR=129;
var DOWNLOAD_SETTING_ERROR=130;
var DDNS_USER_ERROR=131;
var END_IP_DESC=132;

var which_lang = new Array ( //
	"Quand cette fonction est activée, le trafic Internet est protégé par un serveur DNS sécurisé. Cette fonction protège la connexion Internet contre la fraude au moyen d'un filtre antihameçonnage, et améliore la navigation, par exemple en corrigeant automatiquement les erreurs de saisie communes dans les URL.", //_Advanced_01
	"Bien que la fonction DNS avancé soit activée, vous pouvez modifier l'adresse IP DNS du poste de travail et lui attribuer celle de votre choix du serveur DNS. Notez que le routeur ne détermine pas la résolution DNS lorsque l'adresse IP DNS est configurée sur le poste de travail.", //_Advanced_03
	"Vous pouvez désactiver l'option DNS avancé si vous avez configuré un réseau privé virtuel ou un intranet sur votre réseau et que vous rencontrez des problèmes lorsque cette option est sélectionnée.", //_Advanced_04
	"Service DNS avancé", //bwn_ict_dns
	"Le service DNS avancé est une option de sécurité gratuite qui protège la connexion Internet contre la fraude au moyen d'un filtre antihameçonnage, et qui améliore la navigation, par exemple en corrigeant automatiquement les erreurs de saisie communes dans les URL.", //bwn_msg_Modes_dns
	"Activer le contrôle d'accès", //aa_EAC
	"Mon type d'USB est", //new_bwn_mici_usb
	"Impossible de choisir TKIP avec le mode 802.11n seulement !", //_tkip_11n
	"SharePort pour la zone invité", //bln_title_guest_use_shareport
	"Activer le routage entre les zones", //IPV6_TEXT3
	"802.11n et 802.11g", //bwl_Mode_10
	"Saisissez les informations concernant l'adresse EFTR fournies par votre fournisseur d'accès Internet (FAI).", //IPV6_TEXT148
	"Re-générer", //_regenerate
	"Veuillez entrer les paramètres suivants dans le périphérique que vous êtes en train d'ajouter au réseau sans fil et les noter pour toute référence ultérieure.", //TEXT048
	"Activer la Notification d’Email", //te_EnEmN
	"Paramètres USB 3.5G", //usb3g_titile
	"Nom APN", //usb3g_apn_name
	"Numéro à composer", //usb3g_dial_num
	"Mode de reconnexion (0 : toujours ; 1 : sur demande ; 2 : manuel)", //usb3g_reconnect_mode
	"TEMPS D'INACTIVITÉ", //usb3g_max_idle_time
	"PÉRIPHÉRIQUE USB (0 : modem 3G ; 1 : KCODE)", //usb_device
	"Manuel de l'USB 3.5G", //usb3g_manual
	"Statistiques de l'USB 3.5G", //usb3g_stat_titile
	"Paramètres USB", //bln_title_usb
	"Configuration WCN", //usb_wcn
	"Utilisez cette section pour configurer votre port USB. Vous pouvez choisir parmi plusieurs  configurations : USB réseau, Adaptateur USB 3G et WCN.", //bwn_intro_usb
	"Réseau par USB", //usb_network
	"Adaptateur 3G USB", //usb_3g
	"Numéro à composer", //wwan_dial_num
	"Type de connexion Internet WWAN", //bwn_wwanICT
	"Entrez l'adresse électronique à laquelle vous souhaitez envoyer le message électronique.", //help862
	"Protocole d'authentification", //wwan_auth_label
	"Auto(PAP+CHAP)", //wwan_auth_auto
	"Dépassement du délai d'authentification PAP, échec de l'authentification.", //IPPPPPAP_AUTH_ISSUE
	"CHAP seulement", //wwan_auth_chap
	"MS CHAP seulement", //wwan_auth_mschap
	"Indiquez si vous souhaitez partager une imprimante USB, un scanner ou un périphérique de stockage connecté au port USB derrière le routeur avec d'autres utilisateurs de votre réseau.", //usb_network_help
	"Sélectionnez Adaptateur 3G USB pour utiliser un adaptateur 3G afin de fournir un accès à Internet au moyen d'un signal cellulaire EV-DO. Il suffit de connecter un adaptateur 3G USB pour accéder à Internet (sous réserve d'un abonnement EV-DO tiers et de la disponibilité du signal).", //usb_3g_help
	"Si vous rencontrez des problèmes pour accéder à Internet par l'intermédiaire du routeur, vérifiez les paramètres que vous avez entrés sur cette page et contactez éventuellement votre fournisseur d'accès Internet (FAI).", //usb_3g_help_support_help
	"Indiquez si vous souhaitez configurer votre réseau sans fil à l'aide de Windows Connect Now (WCN). WCN vous permet de copier les paramètres sans fil du routeur sur une clé USB à mémoire flash et de les utiliser pour configurer automatiquement les paramètres sans fil sur le ou les ordinateurs ou d'autres périphériques compatibles WCN.", //usb_wcn_help
	"Mon connecteur USB est de type", //bwn_mici_usb
	"En configurant la durée de l'intervalle de détection du réseau par USB, le routeur détecte automatiquement le périphérique USB.", //_info_netowrk
	"Activer les flux multidiffusion", //anet_multicast_enable
	"Intervalle de détection du réseau USB", //bwn_usb_time
	"secondes (intervalle de 3 à 600 s)", //bwn_bytes_usb
	"Impossible de choisir la clé partagée lorsque le WPS est activé !", //_wps_albert_1
	"Impossible de choisir le mode WPA entreprise lorsque le WPS est activé !", //_wps_albert_2
	"Configurez les paramètres du type de connexion Internet.  Si vous n'êtes pas certain des paramètres, contactez votre fournisseur d'accès Internet (FAI).", //usb_config2
	"Choisissez un périphérique auquel appliquer la politique.", //ac_alert_choose_dev
	"Le type de connexion Internet ne correspond pas à une connexion Internet 3G.  Sélectionnez WWAN pour prendre en charge les connexions Internet 3G.", //usb_config3
	"Le type de connexion Internet correspond à une connexion Internet 3G, sélectionnez un autre type de connexion Internet.", //usb_config4
	"Le type de connexion Internet que vous avez sélectionné correspond à une connexion Internet 3G.  Les paramètres USB configurés sur Réseau par USB/WCN seront modifiés et configurés sur Adaptateur 3G USB.", //usb_config5
	"Le type de connexion Internet que vous avez sélectionné ne correspond pas à une connexion Internet 3G.  Les paramètres USB configurés sur Adaptateur 3G USB seront modifiés et configurés sur Réseau par USB.", //usb_config6
	"Choisissez le type de périphérique USB à connecter sur", //bwn_msg_usb
	"Pays", //_country
	"Sélectionnez votre pays", //_select_country
	"Sélectionnez votre FAI", //_select_ISP
	"Australie", //country_1
	"Italie", //country_2
	"Portugal", //country_3
	"Royaume-Uni", //country_4
	"Indonésie", //country_5
	"Malaisie", //country_6
	"Singapour", //country_7
	"Biens personnels", //_aa_bsecure_personals
	"Afrique du Sud", //country_9
	"Hong-Kong", //country_10
	"Taïwan", //country_11
	"Égypte", //country_12
	"République dominicaine", //country_13
	"Salvador", //country_14
	"Brésil", //country_15
	"Sélectionnez cette option si vous voulez ajouter un réseau invité", //S500
	"Type de réseau", //S496
	"Activer l'accès distant au stockage HTTP", //sto_http_2
	"courrier électronique,Le bouton Envoyer par courrier électronique maintenant est désactivé, car la notification par courrier électronique n'est pas activée à l'écran <a href='tools_email.asp' onclick='return jump_if();' shape='rect'>Outils &rarr; Courrier électronique</a>.", //logs_LW39b_email
	"Utiliser HTTPS", //LV3
	"%s%sSystème sans fil avec adresse MAC %m sécurisé et lié", //GW_WIRELESS_DEVICE_LINK_UP
	"Toutes les entrées du journal ont été effacées.", //LT248
	"Découverte des serveurs PPPoE pour la session PPPoE %s", //GW_PPPOE_EVENT_DISCOVERY_ATTEMPT
	"Bande des 5GHz", //GW_WLAN_RADIO_1_NAME
	"Port du serveur SMTP", //te_SMTPSv_Port
	"Impossible de passer du mode 802.11 au mode 802.11n seulement tant que le SSID est configuré avec une sécurité WEP.", //GW_WLAN_CHANGING_PHY_MODE_TO_11NG_ONLY_INVALID
	"Sélectionnez votre réseau sans fil", //S558
	"Sélectionnez le récepteur radio que vous voulez configurer", //KRL8
	"La sélection vous aide à définir l'échelle de la zone invité.", //LY30
	"Pour le serveur virtuel (%s), impossible d'utiliser le port d'administration WAN HTTPS du routeur (%u)", //GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"La configuration Wi-Fi protégée est désactivée, car la sécurité du SSID '%s' est définie sur WPA entreprise.", //GW_WIFISC_DISABLED_AUTOMATICALLY
	"Désactivé", //_off
	"Bande des 2,4GHz", //GW_WLAN_RADIO_0_NAME
	"Défaut de protocole de la session PPPoE %s. Échec de la tentative de connexion.", //GW_PPPOE_EVENT_DISCOVERY_REQUEST_ERROR
	"Le nom de la session PPPoE %s est en conflit avec un autre nom de session", //GW_WAN_PPPOE_SESSION_NAME_CONFLICT
	"Problème lors de la réception des journaux ! La mémoire est trop faible pour afficher les journaux ou bien il existe un problème de connexion.", //S525
	"Les champs d'entrée du mot de passe et de sa confirmation ne concordent pas. Confirmez à nouveau le mot de passe utilisateur.", //YM174
	"Examinez ces avertissements, car il est possible que certaines fonctions aient été désactivées ou modifiées.", //KR136
	"Fin de l'ID de session PPPoE %s %u", //GW_PPPOE_EVENT_DISCONNECT
	"Point limite Indépendant", //af_EFT_0
	"Cette section permet d'activer la redirection entre la zone hôte et la zone invité ; les clients invités ne peuvent pas accéder aux données des clients hôtes sans activer cette fonction.", //LY34
	"%sArrêt du mode sans fil", //GW_WIRELESS_SHUT_DOWN
	"%sRedémarrage du mode sans fil", //GW_WIRELESS_RESTART
	"Le délai d'attente d'inactivité d'administration doit être compris entre 1 et 65535.", //S528
	"La passerelle ALG de redirection de port n'a pas pu allouer de session au paquet TCP de %v:%u à %v:%u", //GW_PORT_FORWARD_TCP_PACKET_ALLOC_FAILURE
	"Cette section vous permet de configurer les paramètres de la zone invité de votre routeur. La zone invité est une zone réseau indépendante qui permet aux invités d'accéder à Internet.", //guestzone_Intro_1
	"Pour le serveur virtuel (%s), impossible d'utiliser le port d'administration WAN HTTPS du routeur (%u)", //GW_NAT_VIRTUAL_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"Activer la gestion à distance", //ta_ERM
	"Le port doit être dans l'intervalle (1 à 65535)", //te_SMTPSv_Port_alert
	"%sImpossible de démarrer le mode sans fil", //GW_WIRELESS_DEVICE_START_FAILED
	"La passerelle ALG de redirection de port n'a pas pu allouer de session au paquet UDP de %v:%u à %v:%u", //GW_PORT_FORWARD_UDP_PACKET_ALLOC_FAILURE
	"%sDéconnecter toutes les stations", //GW_WIRELESS_DEVICE_DISCONNECT_ALL
	"Émission d'une requête d'offre pour la session PPPoE %s", //GW_PPPOE_EVENT_OFFER_REQUEST
	"L'adresse IP %v du routeur doit être une adresse hôte valide", //GW_ROUTES_ROUTERS_IP_ADDRESS_INVALID
	"La passerelle ALG de déclenchement de port n'a pas pu allouer de session au paquet UDP de %v:%u à %v:%u", //GW_PORT_TRIGGER_UDP_PACKET_ALLOC_FAILURE
	"Impossible de définir la sécurité WEP pour le SSID tant que le mode 802.11 est le mode 802.11n seulement.", //GW_WLAN_SETTING_SSID_SECURITY_TO_WEP_INVALID
	"Le serveur virtuel %s ne peut pas utiliser le port d'administration WAN HTTP du routeur (%u)", //GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT
	"Expiration du délai, station quittée", //GW_WLAN_STATION_TIMEOUT
	"Le serveur virtuel %s ne peut pas utiliser l'adresse IP %v du routeur.", //GW_NAT_VIRTUAL_SERVER_IP_ADDRESS_CAN_NOT_MATCH_ROUTER
	"%s' [protocole:%u]->%v est en conflit avec '%s' [protocole:%u]->%v.", //GW_NAT_VIRTUAL_SERVER_PROTO_CONFLICT_INVALID
	"Indique si la zone invité va être activée ou désactivée.", //LY28
	"Tentative d'établissement de la connexion PPPoE %s", //GW_PPPOE_EVENT_CONNECT
	"Port déclencheur", //GW_NAT_TRIGGER_PORT
	"mode de fonctionnement", //tc_opmode
	"Attribuez automatiquement une clé de réseau pour les deux bandes de 2,4 GHz et 5 GHz (recommandé).", //wwz_auto_assign_key3
	"Nommez le réseau sans fil de la zone invité.", //LY292
	"Il est important de sécuriser votre réseau sans fil afin de protéger l'intégrité des informations qui y sont transmises. Le routeur accepte 4 types de sécurité sans fil : WEP, WPA seulement, WPA2 seulement et WPA/WPA2 (détection automatique).", //LY293
	"Si vous choisissez l'option de sécurité WEP, ce périphérique fonctionnera <strong>UNIQUEMENT</strong> en <strong>mode sans fil hérité (802.11B/G)</strong>. Vous N'obtiendrez <strong>PAS</strong> les performances 11N car WEP n'est pas pris en charge par la spécification  Draft 11N.", //bws_msg_WEP_4
	"La route de %v sur l'interface &s ne peut pas être créée ; seules les routes avec passerelles peuvent être créées sur cette interface.", //GW_ROUTES_ON_LINK_DATALINK_CHECK_INVALID
	"Paramètres DNS", //wwa_dnsset
	"Cet assistant est conçu pour vous aider à connecter votre périphérique invité sans fil au routeur sans fil. Il vous explique pas à pas la procédure de connexion de votre périphérique invité sans fil. Cliquez sur le bouton ci-dessous pour commencer.", //wireless_gu
	"Ajouter un invité sans fil avec WPS", //add_gu_wps
	"Bande de fréquence sans fil", //wwl_band
	"Bande", //_band
	"Définir manuellement le nom du réseau dans la bande 5 GHz", //wwa_5G_nname
	"ZONE INVITÉ", //_guestzone
	"Sélection de la zone invité", //guestzone_title_1
	"Activer l'authentification graphique", //_graph_auth
	"Inclure le mode sans fil", //guestzone_inclw
	"Invité", //guest
	"inférieure au réseau sans fil", //lower_wnt
	"égale au réseau sans fil", //equal_wnt
	"la plus basse", //_lowest
	"Liste des SSID", //ssid_lst
	"SSID multiples", //mult_ssid
	"Ajouter/Modifier un SSID", //add_ed_ssid
	"Activez ou désactivez les règles définies à l'aide des cases à cocher situées à gauche.", //help75a
	"Filtre entrant de commande ping pour le réseau étendu", //wpin_filter
	"Le protocole d’impression port TCP raw utilise une adresse IP fixe et le port TCP pour communiquer avec votre imprimante.", //tps_raw1
	"(GMT +06:30) Rangoon", //up_tz_52
	"Adresse IP de destination identique", //_r_alert_new1
	"Réglage d'email", //te_EmSt
	"Paquet sortant bloqué de %v à %v (protocole IP %u)", //IPNAT_BLOCKED_EGRESS
	"Mode de sécurité du réseau sans fil", //bws_WSMode
	"Faire un ping sur les Adresses IP WAN publique est une méthode courante employée par les hackers pour savoir si votre adresse IP WAN est valide.", //anet_wan_ping_1
	"Donnez à la règle un nom signicatif, par exemple <code> Serveur de jeu </code>. Vous pouvez également la choisir parmi une liste de jeux populaires, et beaucoup de paramètres de configuration seront complétés automatiquement. Cependant, il sera préférable de vérifier si les valeurs de ports ont changés depuis que cette liste a été créée, et vous devrez compléter le champ de l’adresse IP.", //help65
	"UPnP", //ta_upnp
	"Vitesse de transmission", //bwl_TxR
	"Test du débit de la liaison WAN effectué", //GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED
	"Temps de ping moyen (en millisecondes):", //tsc_pingt_msg106
	"Toute la journée", //tsc_AllDay
	"Tiger Woods 2004", //gw_gm_53
	"Test du débit de la liaison WAN non effectué, par manque de ressource", //GW_WAN_RATE_ESTIMATOR_RESOURCE_ERROR
	"Concession de l'adresse IP perdue.", //DHCP_CLIENT_LOST_LEASE
	"Choisissez un calendrier à appliquer à cette stratégie.", //_aa_wiz_s3_msg
	"Temporisation d'authentification", //bwsAT_
	"Un bon horaire est important pour les journaux et les règles programmées du firewall.", //hhtt_intro
	"Final Fantasy XI (PC)", //gw_gm_20
	"Adresse IP du serveur d'authentification.", //help388
	"Régler la Date et l’Heure manuellement", //tt_StDT
	"Hors connexion", //psOffline
	"État", //_status
	"Sinon, cliquez sur\"Annuler\".", //up_ae_wic_3
	"Rubriques à afficher", //sl_WtV
	"STA avec MAC (%m) nécessaire pour l'enregistrement WPS", //WIFISC_AP_PROXY_PROCESS_START
	"L'assistant de configuration n'a pas pu communiquer avec l'imprimante.", //wprn_nopr2
	"Quand vous êtes en train de rechercher les réseaux sans fil disponibles, c'est le nom qui apparaîtra dans la liste (à moins que le statut de visibilité soit réglé sur Invisible, voyez ci-dessous). Ce nom est aussi appelé SSID. Pour plus de sécurité, il est fortement recommandé de changer le nom de réseau préconfiguré.", //help352
	"Nom du réseau (SSID)", //wwz_wwl_wnn
	"Adresse IP", //_ipaddr
	"Programmation_sans-fil démarrée", //GW_WLS_SCHEDULE_START
	"La direction originale de la conversation :", //help820
	"Si tous les ordinateurs sur le réseau local obtiennent avec succès leurs adresses IP du serveur DHCP du routeur, cette option peut rester désactivée. Cependant, si un des ordinateurs sur le réseau local n'obtient pas une adresse IP du serveur DHCP du routeur, il peut avoir un ancien client DHCP. L’activation de cette option pourra régler ce problème, mais augmentera le trafic de diffusion sur le réseau local.", //help326
	"(GMT+08:00) Krasnoïarsk", //up_tz_54
	"Remarque : Certains navigateurs présentent certaines limitations qui rendent impossible toute actualisation de l'affichage de l'état du réseau étendu quand l'état change. Dan ce cas, c'est à vous d'actualiser l'affichage pour obtenir l'état mis à jour. En outre, certains navigateurs signalent une condition d'erreur quand vous essayez d'obtenir l'état du réseau étendu.", //help773
	"Règles de filtrage MAC", //am_MACFILT
	"sont des machines identiques.", //aa_alert_7_new1
	"Chaque adaptateur réseau possède son adresse MAC unique définie par le fabricant du matériel. Quelques FAI peuvent vérifier l’adresse MAC de votre ordinateur. Certains enregistrent l’adresse MAC de l'adapteur réseau de l'ordinateur ou du routeur utilisé pour se connecter initialement à leur service. Le FAI n’autorise alors l'accès d'Internet qu’à l’équippement ayant cette adresse MAC. Votre routeur a une adresse MAC différente que celle de l'ordinateur ou du routeur qui s’est reliée initialement à votre FAI.", //help302
	"L'option de contrôle d'accès vous permet de contrôler l'accès entrant et sortant de votre réseau. Utilisez cette fonction pour n’autoriser les accès que sur des sites approuvés, limiter l'accès du Web en fonction de l'heure ou des dates, et/ou bloquer l'accès à Internet pour des applications telles que des utilitaires ou des jeux de P2P.", //aa_intro
	"Ceci montre les clients que vous avez spécifiés pour avoir des adresses réservées DHCP. Une entrée peut être changée en cliquant l'icône Editer, ou être supprimée en cliquant l'icône Supprimer. Quand vous cliquez l'icône Editer, l'article est surligné, et la section ‘Editer la réservation DHCP’ est activée pour l'édition.", //help348
	"Les paquets reçus par l’hôte DMZ ont leurs adresses IP traduites de l'adresse IP WAN du routeur vers l'adresse IP LAN de l’hôte DMZ. Cependant, les numéros de port ne sont pas traduits; ainsi les applications sur l’hôte DMZ peuvent continuer d’utiliser leurs numéros de port spécifiques.", //haf_dmz_30
	"Informations", //sl_Infrml
	"Réseau sans fil", //_wireless
	"Adresse IP du Serveur RADIUS", //bws_RIPA
	"Cette option peut vous protéger contre certains types d'attaques par \"usurpation\". Mais vous devez la manipuler avec prudence. Avec certains modems, elle risque de couper la connexion au réseau étendu. Dans ce cas, il peut être nécessaire de modifier le sous-réseau local pour quelque chose d'autre que 192.168.0.x (192.168.2.x, par exemple) pour rétablir la connexion au réseau étendu.", //KR108
	"Si la vitesse automatique de liaison montante est désactivée, cette option vous permet de la régler manuellement. La vitesse de liaison montante est la vitesse à laquelle des données peuvent être transférées à partir du routeur vers votre FAI (Fournisseur d’Accès à Internet). Ceci est déterminé par votre FAI. La vitesse est souvent la indiquée comme une paire de liaison descendante/liaison montante ; par exemple, 1.5Mbps/284kbps. En suivant cet exemple, vous devrez saisir &quot;284&quot;. Vous pouvez aussi examiner la vitesse de liaison montante à l’aide d’un service comme <a href='http:www.dslreports.com'>www.dslreports.com</a>. Notez cependant que les sites tel DSL Reports, parce qu'ils ne gèrent pas tous les protocoles réseau, indiqueront généralement des vitesses légèrement inférieures à la vitesse mesurée réelle ou à la vitesse indiquée par le FAI.", //help83
	"Si la <strong> vitesse de liaison montante mesurée </strong> n’est pas correcte (c'est-à-dire, les performances ne sont pas optimales), désactivez <strong> vitesse de liaison montante automatique </strong> et saisissez <strong> la vitesse de liaison montante </strong>. Il sera peut être nécessaire de faire des tests de performance pour obtenir la valeur optimale.", //hhase_intro
	"Erreur lors du chargement de la configuration à partir de la mémoire non volatile (non-concordance du nombre magique). Restaurer les paramètres par défaut", //RUNTIME_CONFIG_MAGIC_NUM_ERROR
	"Sam", //_Sat
	"Règles de filtrage de site Web", //awf_title_WSFR
	"Vous pouvez choisir un ordinateur à partir de la liste de clients DHCP dans le menu déroulant &quot;Nom d’ordinateur &quot;, ou vous pouvez saisir manuellement l'adresse IP de l'ordinateur serveur.", //help18_a
	"AUTORISER l'accés à ces sites UNIQUEMENT", //dlink_wf_op_1
	"Far Cry", //gw_gm_18
	"Call of Duty", //gw_gm_7
	"Détection d'un stockage de masse USB avec protocole %u de sous-classe %u", //USB_LOG_STORAGE_TYPE
	"Serveur de jeu", //help346
	"Ceci entraînera la perte de tous les paramètres actuels.", //up_rb_5
	"WEP", //_WEP
	"MSCHAP envoi la réponse d'authentification (Erreur et pas d'autre tentative).", //IPMSCHAP_AUTH_FAIL_AND_NO_RETRY
	"SWAT 4", //gw_gm_82
	"Les protocoles d'authentification supportés sont PAP et CHAP.", //bw_sap
	"Saisissez l'information adresse statique fournie par votre Fournisseur d’Accès à Internet (FAI).", //bwn_msg_SWM
	"La connexion réseau semble hors service. Cliquez sur \'OK\' pour réessayer.", //li_alert_2
	"Quand le contrôle d'accès est désactivé, chaque machine sur le réseau local a un accès sans restriction à Internet. Cependant, si vous activez le contrôle d'accès, l'accès à Internet est restreint pour les machines à qui s’applique ce contrôle d'accès. Toutes les autres machines ont un accès sans restriction à Internet.", //help120
	"L’hôte IGMP a rejeté le groupe %v dû à des ressources système insuffisantes", //IGMP_HOST_LOW_RESOURCES
	"Soit 10 ou 26 caractères en utilisant 0-9 et A-F", //wwl_s4_intro_z3
	"Activez cette option pour de meilleures performances et une meilleure expérience avec les jeux en ligne et d’autres applications interactives, telles que la voix sur IP.", //help78
	"Windows 2000", //help339
	"Activer la sécurité simple IPv6", //IPv6_Simple_Security_enable
	"Saisissez la plage de ports que vous voulez ouvrir au trafic Internet (par ex. <code>6000-6200</code>).", //help51
	"L'ADRESSAGE INTERNET APPRIS VIA PPPoE EST INCOMPATIBLE AVEC L'ADRESSAGE SÉLECTIONNÉ POUR LE RÉSEAU LOCAL. LES COMMUNICATIONS SUR INTERNET SERONT DÉSACTIVÉES JUSQU'À CE QUE VOUS MODIFIIEZ L'ADRESSAGE DE RÉSEAU LOCAL POUR RÉSOUDRE LE PROBLÈME.", //GW_WAN_LAN_ADDRESS_CONFLICT_PPP
	"Erreurs", //ss_Errors
	"Si une mise à jour de DNS dynamique échoue pour n'importe quelle raison (par exemple, si des paramètres incorrectes sont entrés), le routeur désactive automatiquement le dispositif de DNS dynamique et enregistre l'échec dans le journal.", //help899
	"Veuillez saisir le code d'authentification graphique.", //li_alert_4
	"L'option DMZ (zone démilitarisée) vous permet de configurer un ordinateur de votre réseau « à l'extérieur » du routeur. Si vous avez un ordinateur qui ne peut pas utiliser correctement des applications Internet derrière le routeur, vous pouvez le placer dans la DMZ pour qu'il puisse accéder à Internet sans aucune restriction.", //haf_dmz_40
	"Cliquez sur l'icône Modifier pour modifier un calendrier existant.", //hhts_edit
	"Nom du réseau sans fil (SSID)", //wwl_wnn
	"Accès au site Web %S depuis %s", //WEB_FILTER_LOG_URL_ACCESSED_MAC
	"WMM Activé", //aw_WE
	"Régler l’aide", //help201a
	"Activez ici votre essai de 30 jours GRATUIT.", //_bsecure_activate_trial
	"Entrez le mot de passe ou la clé que vous a fourni votre fournisseur de service. Si le fournisseur de service de DNS dynamique vous fournit uniquement une clé, entrez cette clé dans les trois champs.", //help896
	"Le protocole de communication utilisé pour la conversation.", //help815
	"Masque de réseau ", //_netmask
	"veuillez patienter...", //_please_wait
	"Répétez ces étapes pour chaque règle de serveur virtuel que vous souhaitez ajouter. Quand la liste est complète, cliquez sur <span class='button_ref'>Enregistrer les paramètres</span> en haut de la page.", //help12
	"L'option de filtre d'adresse MAC est employée pour contrôler l'accès au réseau en fonction de l’adresse MAC de la carte réseau. Une adresse MAC est une identification unique assignée par le fabricant de la carte réseau. Cette option peut être utilisée pour PERMETTRE ou REFUSER l’accès au réseau/Internet.", //am_intro_1
	"Le protocole LCP définit l'authentification locale : %04x", //IPPPPLCP_SET_LOCAL_AUTH
	"Crimson Skies", //gw_gm_11
	"Ne pas sauvegarder les réglages", //_dontsavesettings
	"La clé WPA (Wi-Fi Protected Access) doit respecter la règle suivante", //wwl_s4_intro_za1
	"MTU par défaut =", //_308
	"MAC", //aa_AT_1
	"Tunnel local L2TP 0x%04X  abandonné.", //IPL2TP_TUNNEL_ABORTING
	"Ajouter/Editer une réservation DHCP", //help330
	"Client L2TP", //wwa_msg_l2tp
	"4:00 AM", //tt_time_5
	"Saisissez l'adresse IP de la machine sur votre réseau local (par ex. <code>192.168.0.50</code>)", //help6
	"HEURE", //_time
	"Réseau xDSL ou autre réseau à relais de trame", //at_xDSL
	"Étape 2 : Lancez l'exécutable de configuration sur votre ordinateur.", //wprn_intro4
	"Normalement, cette option est définie sur &quot;auto&quot;. Si vous rencontrez des problèmes lors de la connexion au réseau étendu, essayez d'autres paramètres.", //help296
	"Réseau local", //_LAN
	"Warcraft III", //gw_gm_60
	"Sélectionnez l'ordinateur auquel s'applique cette stratégie.", //_aa_wiz_s4_msg
	"64 bits", //wwl_64bits
	"Le disque est plein.", //IPFAT_DISK_FULL
	"Allez dans votre menu Démarrer, sélectionnez Tous les programmes, sélectionnez Accessoires, et sélectionnez Invite de commandes. Dans cette fenêtre, saisissez <code> ipconfig /all </code> et frappez la touche Retour. L'adresse physique affichée est l’adresse MAC.", //help341
	"Cliquez sur \'Ok\' pour annuler ces modifications et afficher la page de calendrier.", //aa_sched_conf_2
	"Tentative de démarrage de la session locale L2TP 0x%04X.", //IPL2TP_SESSION_CONNECTING
	"Échec de la synchronisation du temps (état %d).", //NET_RTC_SYNCHRONIZATION_FAILED
	"Vérifier en ligne automatiquement la disponibilité d'une nouvelle version de microprogramme", //tf_AutoCh
	"Il est impossible de déterminer le fabricant et/ou le modèle de l'imprimante, sans doute à cause d'un ID de périphérique non valide signalé par l'imprimante. L'assistant ne peut pas continuer sans cette information.", //wprn_iderr2
	"Ces deux valeurs d'IP (<i>de </i> et <i>à </i>) définissent une plage d’adresses IP que le serveur DHCP emploie lorsqu’il l’assigne aux ordinateurs et aux dispositifs de votre réseau local. Toutes les adresses en dehors de cette étendue ne sont pas contrôlées par le serveur DHCP ; elles peuvent donc être employées pour configurer manuellement des dispositifs ou pour des dispositifs qui ne peuvent pas employer de client DHCP automatique.", //help319
	"<b> Remarque: </b> La mise d'un ordinateur dans le DMZ peut l’exposer à une", //af_intro_2
	"Cliquez sur ce bouton pour actualiser l'affichage des entrées du journal. Il est possible que le journal contienne de nouveaux événements depuis votre dernière consultation.", //help800
	"Informations sur les périphériques", //sd_title_Dev_Info
	"Le filtre de port d'accès à Internet a rejeté les paquets %v à %v (protocole % u)", //GW_INET_ACCESS_DROP_PORT_FILTER
	"Windows Connect Now", //_connow
	"L’ALG SIP a rejeté le paquet de %v:%u à %v:%u", //IPSIPALG_REJECTED_PACKET
	"Paquet TCP rejeté de %v:%u à %v:%u car impossible de modifier les options d'en-tête.", //IPNAT_TCP_UNABLE_TO_MODIFY_OPTIONS
	"Sélectionner le Serveur NTP", //tt_SelNTPSrv
	"Un environnement de radiofréquence bruyant peut provoquer un taux d'erreur élevé sur le réseau local sans fil.", //help812
	"Utilisateur", //_user
	"(GMT+08:00) Taipei", //up_tz_59
	"Applications spéciales", //SPECIAL_APP
	"Sans sécurité", //wwl_NONE
	"Démarrage des services de réseau étendu", //GW_WAN_SERVICES_STARTED
	"Accès interdit au site Web", //fb_FbWbAc
	"Vous devez ouvrir l'interface de gestion du routeur et appuyez sur le bouton de connexion manuelle quand vous souhaitez vous connecter à Internet.", //help275
	"Aucune imprimante détectée", //wprn_nopr
	"Fuseau horaire", //tt_TimeZ
	"Conseils de dépannage", //wprn_tt
	"Sélectionnez votre fuseau horaire local à partir du menu déroulant.", //help841
	"Définir un nouveau calendrier", //aa_sched_new
	"1:00 PM", //tt_time_14
	"HTTP", //gw_vs_1
	"Réglage du Syslog", //tsl_SLSt
	"L’ALG H.323 a rejeté le paquet de %v:%u à %v:%u", //IPH323ALG_REJECTED_PACKET
	"Étape 4 - Sélectionnez la méthode de filtrage", //aa_wiz_s1_msg4
	"Windows 98", //help336
	"Nom du système", //ta_sn
	"Selon que vous soyez ou non actuellement connecté à BigPond, vous pouvez cliquer sur le bouton <span class='button_ref'>Connexion BigPond</span> pour essayer d'établir la connexion au réseau étendu ou sur le bouton <span class='button_ref'>Déconnexion BigPond</span> pour interrompre la connexion au réseau étendu.", //help780
	"Interface", //_interface
	"Site Web %S bloqué pour %v", //WEB_FILTER_LOG_URL_BLOCKED
	"Le port d'administration à distance est en conflit avec la partie serveur virtuel", //vs_http_port
	"Le routeur fournit un coupe-feu étanche en vertu des fonctionnements de NAT. Tant que vous ne configurez pas le routeur autrement, le NAT ne répond pas aux demandes non sollicitées entrantes quelque que soit le port, rendant votre réseau local invisible des cyberattaques d'Internet. Cependant, quelques applications de réseau ne peuvent pas fonctionner avec un coupe-feu étanche. Ces applications doivent ouvrir sélectivement des ports dans le coupe-feu pour fonctionner correctement. Les options sur cette page contrôlent plusieurs façons d’ouvrir le coupe-feu pour satisfaire les besoins spécifiques de ses applications.", //haf_intro_1
	"(GMT-06:00) Amérique centrale", //up_tz_07
	"Si vous n'êtes pas familier avec ces réglages sans fil avançés, veuillez lire la section d'aide avant d'essayer de les modifier.", //aw_intro
	"Adresse de passerelle", //wwa_gw
	"Services Sentinelle", //_sentinel_serv
	"Choisissez cette option si votre fournisseur d'accès Internet vous a fourni des informations relatives à l'adresse IP à configurer manuellement.", //wwa_msg_sipa
	"Paquet TCP rejeté de %v à %v car impossible de traiter l'en-tête de paquet.", //IPNAT_TCP_UNABLE_TO_HANDLE_HEADER
	"Vous pouvez choisir un ordinateur à partir de la liste de clients DHCP dans le menu déroulant <strong>Nom d’ordinateur</strong>, ou vous pouvez saisir manuellement l’adresse IP de l'ordinateur pour lequel vous voudriez ouvrir le port indiqué.", //hhav_ip
	"Peu d'applications exigent vraiment l'utilisation d’un hôte DMZ. Voir ci-dessous des exemples où un hôte DMZ pourrait être exigé :", //haf_dmz_50
	"La stratégie %s est arrêtée ; l'accès à Internet pour l'adresse MAC %m devient : %s", //GW_INET_ACCESS_POLICY_END_MAC
	"L'option de configuration du calendrier sert à gérer les règles de calendrier pour plusieurs pare-feux et fonctions de contrôle parental.", //tsc_intro_Sch
	"L'accès est refusé au système sans fil avec l'adresse MAC %m", //GW_WLAN_ACCESS_DENIED
	"Nom de domaine local", //_262
	"Cette option est activée par défaut de sorte que votre routeur puisse déterminer automatiquement quels programmes doivent avoir la priorité du réseau.", //help79
	"BigPond n'est pas configuré correctement.", //GW_BIGPOND_CONFIG
	"Haut", //aw_TP_0
	"Établissement (attendez svp…)", //_sdi_s3
	"Résultat du Ping", //tsc_pingr
	"Test de ping IPv6", //tsc_pingt_v6
	"WPA-Personnel", //_WPApersonal
	"Réglage d'email", //_email
	"Confirmation d'offre de session par PPPoE.", //PPPOE_EVENT_DISCOVERY_REQUEST
	"Pare-feu", //_firewall
	"Adresse IP statique de connexion", //wwa_wanmode_sipa
	"Contrôle général", //_syscheck
	"Adresse IP du client sur le réseau local.", //help784
	"Inconnu", //UNKNOWN
	"UPnP (Universal Plug and Play), est une architecture de gestion de réseau qui fournit une compatibilité parmi les équipements, les logiciels, et les périphériques de gestion de réseau. Ce routeur a des capacités facultatives d'UPnP, et peut travailler avec les autres dispositifs et logiciels d'UPnP.", //help_upnp_1
	"Wolfenstein: Enemy Territory", //gw_gm_61
	"(en option)", //_optional
	"Une valeur de fragmentation trop faible risque de diminuer les performances.", //help181
	"Internet", //help569
	"Si vous n'êtes pas au courant de ces réglages de réseau avançés, veuillez lire la section d'aide avant d'essayer de modifier ces réglages.", //anet_intro
	"Saisissez le mot de passe correcte ci-dessus, puis<br> saisissez les caractères que vous voyez dans<br> l'image au-dessous.", //_authword
	"Paquet TCP sortant bloqué de %v:%u à %v:%u car %s a été reçu mais il n’y a aucune connexion active", //IPNAT_TCP_BLOCKED_EGRESS_NOT_SYN
	"Nom de la passerelle", //ta_GWN
	"Si vous n'êtes pas autorisé à modifier la configuration du routeur, contactez l'administrateur de celui-ci.", //wprn_tt3
	"MTU", //help293
	"Si votre FAI affecte une adresse IP fixe, choisissez cette option. Le FAI fournit la valeur pour le", //help265_2
	"Paquet rejeté de %v à %v (protocole IP %u) car impossible de créer une nouvelle session.", //IPNAT_UNABLE_TO_CREATE_CONNECTION
	"Toujours activée", //help270
	"Paramètres sans fil avancés", //aw_title_2
	"Réglages du Firewall", //_firewalls
	"Activée/Non configurée", //LW67
	"Session PPPoE 0x%04X établie.", //PPPOE_EVENT_UP
	"Protocole", //_protocol
	"WPA-Personnel et WPA-Entreprise", //help372
	"(GMT+02:00) Bucarest", //up_tz_32
	"Kbit/s", //at_kbps
	"Câble ou autre réseau à relais de trame", //at_Cable
	"100 Mbit/s", //anet_wp_1
	"Donnez un nom signicatif au Serveur Virtuel, par exemple <code> Serveur Web </code>. Plusieurs types de Serveurs Virtuels connus sont fournis par la liste déroulante &quot;Nom d’application &quot;. Choisir l’un d’eux renseigne certains des paramètres avec des valeurs standards pour ce type de serveur.", //help17
	"Par défaut il n'y a aucun mot de passe de configuré. Il est sérieusement recommandé de créer un mot de passe pour sécuriser votre routeur.", //ta_intro_Adm2
	", vérifiez", //tool_admin_check
	"Réseau PPP en service avec adresse IP %v", //IPPPPIPCP_PPP_LINK_UP
	"Arrêt", //_stop
	"Serveur Syslog défini à l'adresse IP %v.", //GW_SYSLOG_STATUS
	"Configuration du serveur Dhcp", //bd_title_DHCPSSt
	"Le nom du routeur peut être changé ici.", //help827
	"Rechercher la dernière version du microprogramme", //tf_FWCheckInf
	"INFORMATIONS sur le MICROPROGRAMME et le PACK LINGUISTIQUE", //tf_FWInf
	"Jusqu'à huit plages d’adresses IP WAN peuvent être contrôlées par chaque règle. La case à cocher sur chaque plage d'IP permet de la désactiver.", //hhai_ipr
	"Il est recommandé que vous laissiez ces paramètres à leurs valeurs par défaut. Leur ajustement peut limiter la performance de votre réseau sans fil.", //hhaw_1
	"Permet à plusieurs clients VPN de se connecter à leurs réseaux d'entreprise, via IPSec. Certains clients VPN prennent en charge la NAT traversal d'IPSec via la NAT. Cette option peut interférer avec leur fonctionnement. Si vous avez des difficultés à vous connecter à votre réseau d'entreprise, essayez de la désactiver.", //help34
	"Activer la détection automatique du réseau par USB", //_network_usb_auto
	"La masque de sous-réseau de votre routeur sur le réseau local.", //help309
	"Vous ne pouvez pas ajouter de nouvelles adresses MAC.  Vous ne pouvez que réutiliser des adresses MAC des autres politiques.", //aa_alert_15
	"Enregistrer les paramètres", //_savesettings
	"Nommez le calendrier de façon significative, par exemple &quot;règle Jour de semaine&quot;.", //help193
	"Paramètres du Serveur Virtuel", //help14_p
	"Need for Speed: Hot Pursuit 2", //gw_gm_32
	"Requète de connexion TCP entrante bloquée de %v:%u à %v:%u", //IPNAT_TCP_BLOCKED_INGRESS_SYN
	"Si vous activez ce dispositif, le port WAN de votre routeur répondra aux demandes Ping provenant de l'Internet et envoyées à l’adresse IP WAN.", //anet_msg_wan_ping
	"Les filtres entrants peuvent être utilisés pour limiter l'accès vers un serveur de votre réseau à une ou quelques machines.", //ai_intro_2
	"Masque de sous-réseau L2TP", //help285
	"Statistiques du LAN", //ss_LANStats
	"Une restauration est déjà en cours.", //ta_alert_4
	"Copier l'adresse MAC de votre PC", //_clone
	"Diablo I et II", //gw_gm_14
	"Paquet GRE rejeté de %v à %v car impossible de traiter l'en-tête de paquet.", //PPTP_ALG_GRE_UNABLE_TO_HANDLE_HEADER
	"Bloquer certains accès", //_aa_block_some
	"Établi – la connexion transfère des données.", //help819_3
	"11:00 PM", //tt_time_24
	"Normalement l'email est envoyé à l'heure de planification définie, et l’heure de fin de planification n'est pas employée. Cependant, si le routeur est redémarré pendant la période de planification, des emails additionnels peuvent être envoyés.", //help873
	"Collisions", //ss_Collisions
	"Saisissez l'adresse du serveur SMTP pour envoyer l'email.", //help863
	"Cette option active la configuration d'un serveur de secours RADIUS facultatif. Le  serveur de secours RADIUS peut être utilisé comme une copie du serveur primaire RADIUS. Le serveur de secours RADIUS est consulté seulement si le serveur primaire n'est pas disponible ou ne répond pas.Les champs <span class='option'>Adresse IP du serveur de secours RADIUS</span>,<span class='option'> Port du serveur RADIUS </span>,<span class='option'> Secret partagé du serveur de secours RADIUS </span>,<span class='option'> Authentication de l’adresse MAC secondaire </span> fournissent les paramètres correspondants pour le serveur de secours RADIUS.", //help397
	"Liste des serveurs virtuels", //av_title_VSL
	"OFDM", //help636
	"M'envoyer un mail si un nouveau firmware est disponible", //tf_ENFA
	"Avec cette entrée de serveur virtuel, l'ensemble du trafic Internet passant par le port 8888 sera redirigé vers le serveur Web interne sur le port 80 à l'adresse IP 192.168.0.50.", //help13
	"Étape 3 : Configurer votre connexion Internet", //wwa_title_s3
	"Étape 1 : Configurez votre connexion Internet", //ES_wwa_title_s1
	"Test du débit de la liaison WAN stoppé, problème de convergence", //GW_WAN_RATE_ESTIMATOR_CONVERGENCE_ERROR
	"BigPond", //wwa_wanmode_bigpond
	"La section WAN (de réseau étendu) vous permez de configurer votre type de connexion à Internet.", //help254
	"Prendre en charge les connexions entrantes utilisant un protocole autre que ICMP (quand ces protocoles sont permis par les ALGs PPTP et IPSec).", //haf_dmz_70
	"Erreur système pendant l'ajout au calendrier %s.", //GW_SCHED_ATTACH_FAILED
	"Le champ SSID ne peut pas être vide.", //_badssid
	"Configuration stockée dans la mémoire non volatile.", //RUNTIME_CONFIG_STORING_CONFIG_IN_NVRAM
	"Une mise à jour du microprogramme est disponible.", //FW_UPDATE_AVAILABLE
	"Le dispositif DNS Dynamique vous permet d'héberger un serveur (Web, FTP, serveur de jeu, etc.) en utilisantant un Nom de domaine que vous avez acheté sur un service DNS avec votre adresse IP dynamiquement assignée. La plupart des fournisseurs d’accès Internet haut débit assignent des adresses IP dynamiques (changante). Quand vous employez un fournisseur de service de DNS dynamique, vos amis peuvent saisir votre nom d'hôte pour se relier à votre serveur, quoiqu’il arrive à votre adresse IP.", //help891
	"Connexions PPPoE, PPTP et L2TP", //help777
	"Authentification de l’adresse MAC", //help393
	"Type de connexion à Internet", //bwn_ict
	"Juin", //tt_Jun
	"Le tunnel local L2PT 0x%04X a été connecté à \'%s\'.", //IPL2TP_TUNNEL_CONNECTED
	"Command and Conquer Zero Hour", //gw_gm_9
	"Aliens vs. Predator", //gw_gm_2
	"Assistant Réseau sans fil", //wwl_wl_wiz
	"Plage DHCP incorrecte, DE doit être inférieur à A", //network_dhcp_range
	"Étape 4 : Imprimez une page de test.", //wprn_intro6
	"Échec de BigPond, état = %d avec erreur = %d, réponse du serveur = %s.", //GW_BIGPOND_FAIL
	"Adresse Restreinte", //af_EFT_1
	"Utiliser la diffusion individuelle", //_use_unicasting
	"Statut du réseau", //_networkstate
	"Année", //tt_Year
	"Échec du montage du périphérique USB", //IPASYNCFILEUSB_MOUNT_FAILED
	"Filtrage De Point limite UDP", //af_UEFT
	"Par défaut le taux de transmission le plus rapide possible sera choisi. Vous pouvez choisir la vitesse si besoin.", //help356
	"Clé Pré-Partagée", //help381
	"Filtre entrant", //_inboundfilter
	"Appliquez les Filtres de Ports Avançés", //_aa_apply_port_filter
	"Dest<br />Port<br /> Fin", //aa_FPR_c7
	"Jedi Knight III: Jedi Academy", //gw_gm_27
	"BigPond n'est pas configuré correctement.", //BIGPOND_NOT_PROPERLY_CFGD
	"Une autre solution consiste à localiser une adresse MAC dans un système d'exploitation spécifique en suivante les étapes ci-après :", //help335
	"(GMT+08:00) Perth", //up_tz_58
	"Jamais", //_never
	"Appuyez sur ce bouton pour supprimer toutes les entrées enregistrées.", //help801
	"Temps de ping le plus long (en millisecondes):", //tsc_pingt_msg105
	"ATTENTION : Les fonctionnalités JavaScript ne sont pas activées sur ce navigateur !", //li_WJS
	"À l'adresse électronique", //te_ToEm
	"12:00 AM", //tt_time_1
	"Signal", //help787
	"Obtenir une adresse de serveur DNS IPv6 automatiquement", //IPV6_TEXT65_v6
	"Journaux de passerelle", //GW_EMAIL_SUBJ
	"La passerelle ALG de déclenchement de port n'a pas pu allouer de session au paquet UDP de %v:%u à %v:%u", //IPPORTTRIGGERALG_UDP_PACKET_ALLOC_FAILURE
	"Si vous êtes nouveau dans la gestion d’un réseau et n'avez jamais configuré un routeur auparavant, veuillez appuyer sur et le routeur vous guidera en quelques étapes simples à mettre votre réseau en service.", //bi_wiz
	"Sortant", //_Out
	"Vérifiez le menu déroulant de<strong> Nom d’application </strong> pour une liste d'applications prédéfinies. Si vous choisissez une des applications prédéfinies, appuyez sur le bouton de flèche à côté du menu déroulant pour compléter le champ correspondant.", //hhpt_app
	"Connexion DHCP (adresse IP dynamique)", //_dhcpconn
	"Réglages du routeur", //bln_title_Rtrset
	"Serveur d'impression", //_ps
	"Cette option est facultative. Saisissez le nom de domaine du réseau local. Le serveur DHCP du PA attribue ce nom de domaine aux ordinateurs du réseau local sans fil. Ainsi, par exemple, si vous saisissez <code>mynetwork.net</code> ici et que le nom de votre ordinateur portable est <code>chris</code>, ce dernier sera désigné par <code>chris.mynetwork.net</code>.", //_1044
	"Choisissez cette option si vos adaptateurs sans fil supportent WPA2", //wwl_text_best
	"Adresse IP du serveur PPTP (peut être identique à celle de la passerelle)", //wwa_pptp_svraddr
	"Test du débit de la liaison WAN effectué. Le débit sortant est de %u kbps", //GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED
	"Ordinateurs du réseau local", //_LANComputers
	"Vous pouvez prendre les mêmes réglages d'email que ceux de votre programme d'email client.", //hhte_intro
	"H.323 (Netmeeting)", //as_NM
	"Assistant de configuration", //wwa_setupwiz
	"et", //help264
	"(compatibilité avec certains serveurs DHCP)", //bw_WDUU_note
	"MMS", //as_MMS
	"Nom du service", //_srvname
	"La règle s'applique au flux des messages dont l’adresse IP du réseau local est comprise dans la plage déterminée ici.", //help93
	"Minute", //tt_Minute
	"État", //sa_State
	"802.11d Activé", //aw_dE
	"Nom d'hôte ou adresse IP", //tsc_pingt_h
	"Nom d'hôte ou Adresse IPv6", //tsc_pingt_h_v6
	"Statistiques sans fil", //ss_WStats
	"L'authentificateur MSCHAP envoie le challenge.", //IPMSCHAP_AUTH_SEND_CHALLENGE
	"Quand cette option est activée, votre routeur vérifiera périodiquement en ligne pour voir si une nouvelle version firmware est disponible.", //help889
	"H.323 (Netmeeting)", //as_H323
	"Partie transfert de port", //tool_admin_pfname
	"Paquet rejeté de %v à %v (protocole %u) car la session existe déjà.", //IPNAT_SESSION_ALREADY_EXISTS
	"Définir la connexion câblée BigPond", //wwa_title_set_bigpond
	"(GMT-04:00) Santiago", //up_tz_16
	"État BigPond modifié, nouvel état = %d.", //GW_BIGPOND_STATUS
	"Pour établir cette connexion, vous devrez avoir un nom d’utilisateur et un mot de passe de votre Fournisseur d’accès Internet. Vous avez besoin également de l’adresse IP du serveur BigPond. Si vous n'avez pas cette information, entrez en contact avec votr", //wwa_msg_set_bigpond
	"Activez au moins une plage d'adresses IP source pour %s", //ai_alert_5
	"Choisissez cette option si vous voulez synchroniser l'horloge du routeur avec un serveur de temps sur Internet. Si vous employez des plannings ou des journaux, c'est le meilleur moyen de vous assurer que les plannings et les journaux sont à la bonne heure.", //help848
	"Return to Castle Wolfenstein", //gw_gm_41
	"Assistant Stratégie", //_aa_pol_wiz
	"Filtres IP", //IP_FILTERS
	"Starsiege Tribes", //gw_gm_50
	"Sélectionnez votre type de connexion Internet ci-dessous :", //wwa_intro_s3
	"Paquet ESP rejeté à partir de %v en raison d'une tentative de connexion déjà en cours de %v à %v.", //IPSEC_ALG_ESP_ESTABLISH_ALREADY_PENDING
	"Individuel (80, 68, 888)", //help59
	"Etes vous sûre de vouloir remettre le produit en configuration usine?", //wps_reboot_need
	"Fragmentation dynamique", //at_DF
	"Si les serveurs du FAI assignent l’adressage IP du routeur lors de l'établissement de la connexion, choisissez cette option.", //help265_7
	"Le mois de fin du DST doit être différent que le mois de début du DST", //tt_alert_dstchkmonth
	"(GMT-01:00) Îles du Cap-Vert", //up_tz_23
	"Avancé", //_advanced
	"Adresse IP statique", //STATIC_IP_ADDRESS
	"Étape 2 : Protéger votre réseau sans fil", //wwl_title_s3
	"C'est la liste de tous les clients sans fil qui sont actuellement reliés à votre routeur sans fil.", //hhsw_intro
	"Menu", //ish_menu
	"(GMT+02:00) Le Caire", //up_tz_33
	"Impossible de détecter un microprogramme mis à niveau", //GW_FW_NOTIFY_FIRMWARE_ERROR
	"En savoir plus...", //_bsecure_more_info
	"Version du microprogramme actuel", //tf_CFWV
	"2ème", //tt_week_2
	"Exemple:", //help3
	"Créateur", //_creator
	"Relais DNS", //bln_title_DNSRly
	"Le filtre du port d'accès à Internet a rejeté un paquet de %v:%u[%s] à %v:%u (protocole %u).", //GW_INET_ACCESS_DROP_PORT_FILTER_MAC
	"Glossaire", //ish_glossary
	"Une clé WEP longue est plus sûre qu'une courte", //wwl_s4_intro_z4
	"Par défaut, le dispositif de contrôle d'accès est désactivé. Si vous avez besoin du contrôle d'accès, vérifiez cette option.", //help118
	"Shareaza", //gw_gm_66
	"Quand l'option Relais DNS est activée, le routeur joue le rôle d'un serveur DNS. Les demandes DNS envoyées au routeur sont redirigées vers le serveur DNS du FAI. Ceci fournit une adresse DNS constante que les ordinateurs du réseau local peuvent utiliser, même si le routeur obtient une autre adresse de serveur DNS de la part du FAI lors du rétablissement de la connexion de réseau étendu. Vous devez désactiver cette option si vous mettez en oeuvre un serveur DNS de réseau local en tant que serveur virtuel.", //help312dr2
	"Toute la journée - 24 h", //tsc_24hrs
	"Vérifiez le menu déroulant de<strong> Nom d’application </strong> pour une liste d'applications prédéfinies. Si vous choisissez une des applications prédéfinies, appuyez sur le bouton de flèche à côté du menu déroulant pour compléter le champ correspondant.", //hhag_10
	"Certains FAI peuvent vérifier le nom d'hôte de votre ordinateur. Le nom d'hôte identifie votre système sur le serveur du FAI. De cette façon, ils savent que votre ordinateur est autorisé à recevoir une adresse IP. En d'autres termes, ils savent que vous payez pour leur service.", //help261
	"Type du trafic de déclenchement", //as_TPrt
	"Cela se produit si vous avez configuré une règle de contrôle d'accès pour cette machine LAN.", //help28
	"11:00 AM", //tt_time_12
	"Rafraichir les statistiques", //ss_reload
	"Sortant", //EGRESS
	"L'imprimante suivante <span id='status_text'> est </span> attaché à votre routeur.", //sps_fp
	"Unreal Tournament 2004", //gw_gm_57
	"Choisissez cette option si votre connexion Internet vous fournit automatiquement une adresse IP. La plupart des modems câblés utilisent ce type de connexion.", //wwa_msg_dhcp
	"Étape 1 - Attribuez un nom unique à votre stratégie", //aa_wiz_s1_msg1
	"Vous devez être connecté en tant qu'administrateur pour pouvoir effectuer cette action.", //MUST_BE_LOGGED_IN_AS_ADMIN
	"(GMT+09:30) Darwin", //up_tz_64
	"Programmation_sans-fil arrêtée", //GW_WLS_SCHEDULE_STOP
	"L’ALG Wake-on-LAN a rejeté le paquet de %v:%u à %v:%u", //IPWOLALG_REJECTED_PACKET
	"Mise à jour du périphérique dans wsetting.wfc", //WCN_LOG_UPDATE
	"Cette option doit être activée si votre connexion Internet est lente en liaison montante. Elle aide à réduire l’impact que peuvent avoir les paquets du réseau à basse priorité sur ceux plus urgents en divisant les gros paquets en plusieurs petits.", //help80
	"Ici vous pouvez ajouter des entrées à la liste des règles de filtres entrants ci-dessous ou éditer les entrées existantes.", //help171
	"Lun", //_Mon
	"(GMT+10:00) Canberra, Melbourne, Sydney", //up_tz_66
	"Étape 2 : Définissez votre mot de passe de sécurité sans fil", //wwl_title_s4_2
	"Si vous n'utilisez pas l'option Toute la journée, indiquez l'heure au moyen de cette option. L'heure de début est entrée au moyen de deux champs. Le premier permet de spécifier l'heure, tandis que le second sert à indiquer les minutes. Les événements par courrier électronique ne sont normalement déclenchés que par l'heure de début.", //help196
	"L'offre de session PPPoE avait des erreurs. Échec de la tentative de connexion.", //PPPOE_EVENT_DISCOVERY_REQUEST_ERROR
	"Connexion", //li_Log_In
	"Sessions LAN non UDP/TCP/ICMP", //af_gss
	"Passerelle par défaut", //_defgw
	"Le serveur NTP n'est pas configuré.", //YM185
	"Ajout d'un produit sans fil:", //add_wireless_device
	"Saisissez [8888] pour le port public.", //help8
	"Votre ISP vous fournit toutes les informations.", //help258
	"Session PPPoE 0x%04X terminée par le concentrateur d'accès.", //PPPOE_EVENT_TERMINATED
	"Voulez-vous vraiment redémarrer le périphérique ?", //up_rb_1
	"Employez les cases à cocher à gauche pour activer ou désactiver les entrées existantes de Serveurs Virtuels.", //help25_b
	"Sauvegarder le journal", //sl_saveLog
	"Employez cette option pour voir les journaux du routeur. Vous pouvez définir quels types d'événements vous voulez voir et les niveaux d'événement à regarder. Ce routeur supporte également un serveur syslog externe pour envoyer les dossiers journaux à un ordinateur sur votre réseau qui le supporte.", //sl_intro
	"Spécifiez un ordinateur par son adresse IP ou MAC, ou choisir « Autres Ordinateurs » pour les ordinateurs qui n'ont pas de stratégie.", //_aa_wiz_s4_help
	"Le câble wan a été débranché", //GW_WAN_CARRIER_LOST
	"(octets)", //bwn_bytes
	"S'enregistrer en ligne sur le service de notification par email pour être averti par mail d'une mise à jour firmware.", //help890_1
	"Connexion BigPond", //help779
	"Adresse MAC", //_macaddr
	"Réinitialiser ou fermer les connexions TCP. La connexion ne se ferme pas immédiatement de sorte que les paquets en attente puissent passer ou que la connexion puisse être rétablie.", //help823_13
	"Activer la gestion", //ta_ELM
	"Activer l'accès distant au stockage HTTPS", //sto_http_4
	"Activer les flux multidiffusion IPv4", //anet_multicast_enable_v4
	"Prochaine mise à jour DNS dynamique programmée pour %s.", //GW_DYNDNS_UPDATE_NEXT
	"Entrez le mot de passe associé à ce compte.", //help866
	"État du routeur", //sl_RStat
	"Roger Wilco", //gw_gm_78
	"Choisissez un nom significatif pour la règle.", //help90
	"L'ID 0x%04X du tunnel PPTP a été fermé.", //PPTP_EVENT_TUNNEL_DOWN
	"Mode WAN statique", //bwn_SWM
	"Filtre Web a rejeté le paquet de %v:%u à %v:%u", //IPWEBFILTER_REJECTED_PACKET
	"Image téléchargée de mise à niveau de microprogramme non valide ; abandon en cours.", //GW_UPGRADE_FAILED
	"Cette option est employée pour ouvrir de multiples ports ou une plage des ports dans votre routeur et pour réorienter les données de ces ports vers un ordinateur de votre réseau. Vous pouvez entrer des ports dans divers formats incluant, Plage de port (100-150), Ports individuels (80,68,888), ou mixtes (1020-5000, 689).", //ag_intro
	"L'option Admin permet de définir un mot de passe pour accéder à la gestion Web. Par défaut, aucun mot de passe n'est configuré. Il est vivement recommandé d'en créer un pour que votre nouveau routeur reste sécurisé.", //ta_intro_Adm
	"Adresse IP du serveur L2TP", //bwn_L2TPSIPA
	"Aucune stratégie d'accès à Internet n'est en vigueur. Quiconque peut accéder à Internet sans aucune restriction.", //GW_INET_ACCESS_UNRESTRICTED
	"(GMT-05:00) Bogota, Lima, Quito", //up_tz_11
	"Désactivé", //_disabled
	"Envoi d'un journal par courrier électronique car le journal est plein.", //GW_LOG_EMAIL_ON_LOG_FULL
	"7:00 AM", //tt_time_8
	"Permet à Windows Media Player, utilisant le protocole MMS, de recevoir des flux de diffusion d'Internet.", //help43
	"Connexion", //ddns_connecting
	"Activer", //_enable
	"Sur demande", //help272
	"Avr", //tt_Apr
	"Date ou heure non valide", //tt_alert_invlddt
	"(Mbit/s)", //bwl_MS
	"Le port d'administration à distance est en conflit avec", //tool_admin_portconflict
	"Nom d’application", //gw_SelVS
	"Toujours activée", //bwn_RM_0
	"Appuyez sur l'icône <strong>Editer</strong>dans la liste des règles pour changer une règle.", //hhai_edit
	"De l'adresse électronique", //te_FromEm
	"La passerelle est actuellement en train de mesurer votre connexion réseau.", //wt_p_1
	"Durée de requête à partir de %v.", //NET_RTC_REQUEST_TIME
	"Saisissez un nom pour la règle d'application spéciale, par exemple <code>App jeu</code> ; il vous permettra d'identifier la règle à l'avenir. Vous pouvez également choisir dans la liste d'applications courantes intitulée <span class='option'>Application</span>.", //help48
	"S/O", //N_A
	"Masque de sous-réseau PPTP", //help279
	"6ème", //tt_week_6
	"Soldier of Fortune II: Double Helix", //gw_gm_48
	"Invisible", //bwl_VS_1
	"Vérifiez la mise à jour du firmware sur la page statut.", //help882
	"(GMT+03:00) Téhéran", //up_tz_41
	"Configuration chargée à partir de la mémoire non volatile.", //RUNTIME_CONFIG_LOADED_CONFIG_FROM_NVRAM
	"Dépassement du délai d'attente de la session, veuillez réessayer.", //li_alert_1
	"L'adresse IP de votre routeur sur le réseau local. Vos réglages de réseau local sont basés sur l'adresse assignée ici. Par exemple 192.168.0.1.", //help307
	"La connexion à Internet est établie quand nécessaire.", //help273
	"Placez une coche dans les boîtes pour les jours désirés ou choisissez la case d’option Toute la semaine pour choisir tous les jours d’une semaine.", //help194
	"Voulez-vous vraiment restaurer les paramètres par défaut de ce périphérique ?", //up_rb_4
	"Une version plus récente %d.%d pour votre routeur %s %s est à présent disponible à", //NEWER_FW_VERSION
	"Type de connexionInternet : PPTP", //bwn_PPTPICT
	"Image de mise à niveau de microprogramme téléchargée avec succès ; installation en cours...", //GW_UPGRADE_SUCCEEDED
	"(adresses dans le sous-réseau local)", //bwl_AS
	"La règle s'applique au flux des messages dont le numéro de port du WAN est dans la plage déterminée ici.", //help96
	"Canal sans fil", //_wchannel
	"Saisir manuellement la clé réseau", //wwz_manual_key
	"Appuyez sur le bouton ci-dessous pour continuer à configurer le routeur.", //ap_intro_cont
	"Activez l'option de journalisation pour le Serveur Syslog", //tsl_EnLog
	"L2TP", //_L2TP
	"Plage d'adresses IP DHCP", //bd_DIPAR
	"Statistiques", //_stats
	"Entre 8 and 63 caractères (Une clé WPA longue sécurise mieux qu'une plus courte)", //wwl_s4_intro_za2
	"Session locale L2TP 0x%04X hors service.", //IPL2TP_SESSION_DOWN
	"Type de connexion Internet : IP dynamique (DHCP)", //bwn_DIAICT
	"Dans le menu Démarrer, sélectionnez Exécuter, tapez <code>winipcfg</code>, puis appuyez sur la touche Entrée. Une fenêtre s'affiche. Sélectionnez la carte appropriée dans le menu déroulant ; vous obtiendrez ainsi l'adresse de la carte. Il s'agit de l'adresse MAC du périphérique.", //help338
	"Saisissez l'adresse IP LAN du serveur Syslog.", //help859
	"Ajouter", //_add
	"Contrôle d'accès", //_acccon
	"Incapable de résoudre, vérifiez que le nom est correct.", //tsc_pingt_msg4
	"Déconnecter", //ddns_disconnect
	"Confirmer le mot de passe", //_verifypw
	"Configurer le filtrage MAC", //am_intro_2
	"Ajouter une règle", //_aa_pol_add
	"Warcraft II", //gw_gm_59
	"Cliquez sur <span class='button_ref'>Enregistrer</span> pour ajouter les paramètres à la liste des serveurs virtuels", //help11
	"Système", //_system
	"Cette option est normalement désactivée et doit le rester tant que le serveur DHCP du réseau étendu fournit correctement une adresse IP au routeur. Toutefois, si le routeur ne peut pas obtenir une adresse IP du serveur DHCP, il est possible que ce dernier fonctionne mieux avec des réponses de diffusion individuelle. Dans ce cas, activez l'option de diffusion individuelle et observez si le routeur peut obtenir une adresse IP. Dans ce mode, le routeur accepte des réponses de diffusion individuelle du serveur DHCP à la place de réponses de multidiffusion.", //help261a
	"(GMT-10:00) Hawaii", //up_tz_02
	"Le ‘Ping’ vérifie si un ordinateur sur Internet fonctionne et répond.", //hhtsc_pingt_intro
	"Nom du serveur virtuel (par ex. <code>Serveur Web</code>)", //help5
	"Menu Support", //help767s
	"Splinter Cell: Pandora Tomorrow", //gw_gm_45
	"Nom d''utilisateur/mot de passe de connexion (PPPoE)", //wwa_wanmode_pppoe
	"La destination et la passerelle ne peuvent pas être sur le même masque de sous réseau %v", //GW_ROUTES_GATEWAY_SUBNET_SAME
	"Un hôte peut supporter plusieurs applications qui pourraient nécessiter des ports d'entrée se chevauchant. Alors les deux règles de réacheminement de ports ne peuvent pas être employées parce qu'elles seraient potentiellement en conflit.", //haf_dmz_60
	"Le dispositif d'email peut être utilisé pour envoyer les dossiers journaux du système, les messages d’alerte du routeur, et la notification des mises à jour firmware sur votre adresse d’email.", //te_intro_Em
	"Choisissez cette option si vous ne voulez pas activer de dispositifs de sécurité", //wwl_text_none
	"Entrez le nom d'utilisateur ou la clé que vous a fourni votre fournisseur de service. Si le fournisseur de service de DNS dynamique vous fournit uniquement une clé, entrez cette clé dans les trois champs.", //help895
	"Tentative de reconnexion d'une connexion de réseau étendu sur demande.", //GW_WAN_RECONNECT_ON_ACTIVE
	"Ordinateur", //aa_Machine
	"Initialisation de la programmation_sans-fil", //GW_WLS_SCHEDULE_INIT
	"Mer", //_Wed
	"7:00 PM", //tt_time_20
	"IP de destination <br /> Début", //aa_FPR_c3
	"Entrez les ports TCP à ouvrir (par ex. <code>6159-6180, 99</code>).", //help68
	"Il est le plus utilisé pour empêcher les machines sans fil non autorisées de se connecter à votre réseau.", //help150
	"Nom du compte", //te_Acct
	"Le client SMTP a réussi à envoyer un message électronique.", //IPSMTPCLIENT_MSG_SENT
	"Quake 3", //gw_gm_38
	"Cette option travaille avec un serveur RADIUS pour authentifier les clients sans fil. Les clients sans fil doivent s’authentifier au serveur par l’intermédiaire de cette passerelle. En outre, il peut être nécessaire de configurer le serveur RADIUS pour autoriser cette passerelle d'authentifier des utilisateurs.", //help384
	"1:00 AM", //tt_time_2
	"Vitesse automatique de liaison montante", //at_AUS
	"Cliquez sur l'icône Supprimer pour supprimer définitivement un calendrier.", //hhts_del
	"La préférence est donnée aux paquets sortants de cette conversation par la logique QoS Engine. Des petits numéros représentent une priorité plus élevée.", //help818
	"La mise à niveau du microprogramme ne peut pas être réalisée à partir d'un périphérique sans fil. Pour réaliser une mise à niveau, veillez à utiliser un PC qui est physiquement connecté au routeur.", //help886
	"Choisissez un nom unique pour votre politique", //_aa_wiz_s2_msg
	"Sélectionnez le protocole utilisé par le trafic Internet revenant dans le routeur par le biais de la plage de ports ouverte (par ex. <code>Les deux</code>).", //help52
	"secondes ...", //wps_KR46
	"Attribuez un nom à votre réseau (32 caractères maximum).", //wwz_wwl_intro_s3_1
	"Ghost Recon", //gw_gm_19
	"Le dispositif DDNS vous permet d'héberger un serveur (Web, FTP, serveur de jeu, etc…) en employant un Nom de domaine que vous avez acheté (www.n’importequelnom.com) avec votre adresse IP dynamiquement assignée. La plupart des Fournisseurs d’accès Internet haut débit assignent des adresses IP dynamiques (changante). En utilisant un fournisseur de service DDNS, vos amis peuvent saisir votre nom d'hôte pour se relier à votre serveur de jeu quoi qu’il arrive à votre adresse IP .", //td_intro_DDNS
	"(GMT+07:00) Bangkok, Hanoï, Jakarta", //up_tz_53
	"Début DST et fin DST", //help845
	"Cette page va être actualisée sous peu.", //wt_p_3
	"(GMT+06:00) Sri Jayawardenepura", //up_tz_51
	"Alternativement, vous pouvez diriger l'exécutable d’installation vers un dossier sur votre ordinateur contenant un pilote d'impression que vous avez téléchargé du site Web du fabricant d'imprimante.", //wprn_s3d
	"Échec de l'authentification CHAP, veuillez vérifier les informations de connexion.", //IPPPPCHAP_AUTH_FAIL
	"Tiberian Sun", //gw_gm_52
	"Paquet TCP bloqué de %v:%u à %v:%u, la commande %s n’est pas valide", //IPNAT_TCP_BAD_FLAGS
	"Nom", //_name
	"Saisissez l'adresse IP du réseau local du système hébergeant le serveur (par ex. code>192.168.0.50</code>).", //help66
	"Message d'erreur d’ICMP entrant bloqué (type d’ICMP %u) de %v à %v , il n’y a aucune session UDP active entre %v:%u et %v:%u", //IPNAT_UDP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"L’ALG FTP a rejeté le paquet de %v:%u à %v:%u", //IPFTPALG_REJECTED_PACKET
	"Vous n'êtes pas autorisé à accéder à ce site Web à partir de cet ordinateur.", //fb_p_1
	"Type de connexion", //_contype
	"Le port que vous emploierez pour adresser l'interface de gestion à partir de l'Internet. Par exemple, si vous indiquez le port 1080 ici, alors, pour accéder au routeur de l'Internet, vous emploieriez un URL sous la forme : <code>http:mon.domaine.com:1080/</code>.", //help829
	"Règles d'application", //_specappsr
	"L'option invisible vous permet de cacher votre réseau sans fil. Quand cette option est réglée à Visible, votre nom de réseau sans fil est émis à tous ceux présent dans l’étendue de votre signal. Si vous n'employez pas le chiffrement alors ils pourraient se relier à votre réseau. Quand le mode invisible est activé, vous devez saisir le nom de réseau sans fil (SSID) manuellement sur le client pour se relier au réseau.", //help353
	"Halo: Combat Evolved", //gw_gm_23
	"Toujours diffusé", //help325
	"Mode de reconnexion", //bwn_RM
	"Options Journal", //sl_LogOps
	"Tous vos détails de connexions Internet et de réseau sont affichés sur la page d’info du dispositif. La version du logiciel est également affichée ici.", //help772
	"Méthode", //_aa_method
	"Détails du journal", //sl_LogDet
	"Mesure relative de la qualité du signal. La valeur est exprimée sous forme de pourcentage de la meilleure qualité théorique. La qualité du signal peut être réduite par la distance, par des interférences provoquées par d'autres sources de radiofréquences (comme les téléphones sans fil ou les réseaux sans fil du voisinage) et par des obstacles entre le routeur et le périphérique sans fil.", //help788
	"Continuer", //_continue
	"La page Statistiques affiche l'ensemble des statistiques relatives à la transmission et à la réception de paquets sur réseau local, étendu et sans fil.", //help804
	"Info de dispositif", //_devinfo
	"Oui", //_yes
	"SSID", //help699
	"(GMT+10:00) Iakutsk", //up_tz_62
	"Dans cette section, vous pouvez ajouter des entrées aux règles de planifications listées ou éditer les entrées existantes.", //help192
	"Activer le DHCP-PD", //DHCP_PD_ENABLE
	"Need for Speed", //gw_gm_31
	"La connexion à Internet est toujours maintenue.", //help271
	"permet à plusieurs machines du réseau local de se connecter à leurs réseaux d'entreprise, via le protocole PPTP.", //help33
	"Paquet TCP entrant est bloqué de %v:%u à %v:%u avec l'accusé de réception inattendu %lu (prévu %lu à %lu)", //IPNAT_TCP_BLOCKED_INGRESS_BAD_ACK
	"Commencer à envoyer des ping à l’hôte indiqué.", //htsc_pingt_p
	"Vérification en cours", //tf_CKN
	"Vérifiez l'état de l'imprimante", //wprn_cps
	"(GMT+06:00) Ekaterinbourg", //up_tz_45
	"Par défaut, le routeur détermine automatiquement si la connexion sous-jacente est de type réseau XDSL/à relais de trames ou autre (par exemple modem câble ou Ethernet), puis affiche le résultat sous la forme suivante : <span class='option'>Detected xDSL or Frame Relay Network</span> (Réseau xDSL ou à relais de trames détecté). Si votre connexion réseau n’est pas courante, par exemple que vous êtes connecté par xDSL mais que les paramètres Internet sont configurés sur \"Static\" ou \"DHCP\", sélectionnez <span class='option'>xDSL ou Other Frame Relay Network</span> (Autre réseau à relais de trames) pour que le routeur puisse reconnaître qu’il doit mettre en forme le trafic de façon légèrement différente afin d’obtenir les meilleures performances. Si vous choisissez <span class='option'>xDSL ou Other Frame Relay Network</span> (Autre réseau à relais de trame), la vitesse de connexion montante mesurée communiquée est légèrement inférieure par rapport à avant, mais offre de meilleurs résultats.", //help84
	"La dernière version de microprogramme %d.%d est disponible.", //GW_FW_NOTIFY_FIRMWARE_AVAIL
	"Paquets RX abandonnés", //ss_RXPD
	"Site Web %S bloqué pour %s", //WEB_FILTER_LOG_URL_BLOCKED_MAC
	"L’ALG de déclenchement de port n'a pas assigné de session pour le paquet TCP de %v:%u à %v:%u", //IPPORTTRIGGERALG_TCP_PACKET_ALLOC_FAILURE
	"Remarque : Vous devrez peut-être également fournir un nom d'hôte. Si vous ne possédez pas ces informations ou si vous ne les connaissez pas, contactez votre fournisseur d'accès Internet.", //wwa_note_hostname
	"Action", //ai_Action
	"Restaurer les paramètres par défaut", //RUNTIME_CONFIG_RESET_CONFIG_TO_FACTORY_DEFAULTS
	"Aucune imprimante détectée", //sps_nopr
	"Heures", //gw_hours
	"Ven", //_Fri
	"Impression LDP/LPR", //tps_lpd
	"Mise à jour du microprogramme", //tf_FWUg
	"10 Mbit/s", //anet_wp_0
	"Battlefield 1942", //gw_gm_4
	"Ces deux options permettent de sélectionner des variantes du WPA (Wi-Fi Protected Access), c'est-à-dire les normes de sécurité publiées par la Wi-Fi Alliance. L'option <span class='option'>Mode WPA</span> affine davantage la variante que le routeur doit utiliser.", //help373
	"Décalage heure été/heure d'hiver", //tt_dsoffs
	"Attribuer une clé de réseau automatiquement (recommandé)", //wwz_auto_assign_key
	"Doom 3", //gw_gm_15
	"Pour information sur le niveau de sécurité supporté par vos adaptateurs sans fil, référez vous à la documentation des adaptateurs.", //wwl_s3_note_1
	"Cliquez sur <strong>Enregistrer</strong> pour ajouter un calendrier complet à la liste ci-dessous.", //hhts_save
	"Détection automatique", //at_Auto
	"Pings envoyés:", //tsc_pingt_msg100
	"Réseau PPP hors service", //IPPPPIPCP_PPP_LINK_DOWN
	"Type d'adresse", //aa_AT
	"Ubi.com", //gw_gm_71
	"Étape 3 - Sélectionnez l'ordinateur auquel s'applique cette stratégie", //aa_wiz_s1_msg3
	"Échec de BigPond ; consultez le journal pour plus de détails.", //BIGPOND_FAILED
	"Le temps entre les mises à jour périodiques au DNS dynamique, si votre  adresse IP dynamique ne change pas. La période de temporisation est entrée en heures.", //help898
	"Adresse IP du serveur PPTP", //bwn_PPTPSIPA
	"Routage", //_routing
	"Créez une liste d'adresses MAC que vous utiliserez pour permettre ou refuser l'accès à votre réseau.", //hham_intro
	"L'enregistreur interne WPS n'a pas reçu de requête d'une station sans fil depuis 2 minutes et s'est arrêté.", //WIFISC_IR_REGISTRATION_FAIL_3
	"L'option de filtre entrant est une méthode avançée pour contrôler les données reçues de l’Internet. Avec ce dispositif vous pouvez configurer les règles de filtrage de données qui agissent en fonction de plage d'adresses IP.", //ai_intro_1
	"Étape 2 : Choisir votre fuseau horaire", //wwa_title_s2
	"(GMT+11:00) Vladivostok", //up_tz_69
	"MSCHAP a envoyé une réponse d'authentification au produit distant.", //IPMSCHAP_AUTH_RESULT
	"Les réglages systèmes actuels peuvent être sauvegardés dans un fichier sur votre disque dur local. Le fichier sauvegardé ou d’autres déjà sauvegardés peuvent être téléchargés dans le produit.", //tss_intro2
	"Si vous choisissez cette option, le routeur trouve automatiquement le canal avec le moins d’interférence et utilise ce canal pour la gestion de réseau sans fil. Si vous désactivez cette option, le routeur utilise le canal que vous indiquez dans l’option <span class='option'>Canal sans fil </span>.", //help354
	"(GMT-03:00) Buenos Aires, Georgetown", //up_tz_19
	"Vous devez d'abord entrer le nom d'un fichier de configuration.", //ta_alert_5
	"Toujours diffusé", //bd_DAB
	"WPA-Entreprise", //_WPAenterprise
	"Le contrôle d'accès à Internet a rejeté les paquets %v:%u[%s] à %v:%u (protocole %u)", //GW_INET_ACCESS_DROP_ACCESS_CONTROL_MAC
	"Imprimante", //sps_pr
	"(GMT+02:00) Harare, Pretoria", //up_tz_34
	"Clé Pré-Partagée", //_psk
	"DNS dynamique", //_dyndns
	"Refuser", //_deny
	"Paquet TCP entrant bloqué de %v:%u à %v:%u car %s n’est pas permis en l’état %s", //IPNAT_TCP_BLOCKED_INGRESS_UNEXP_FLAGS
	"Temps mort maximal", //help276
	"à", //_to
	"IP", //aa_AT_0
	"Déc", //tt_Dec
	"La stratégie %s est démarrée ; l'accès à Internet pour tous les systèmes non spécifiés devient : %s", //GW_INET_ACCESS_POLICY_START_OTHERS
	"(GMT+12:00) Magadan", //up_tz_75
	"(GMT+12:00) Fiji, Kamchatka, Îles Marshall", //up_tz_72
	"Aucune réponse de l’hôte, réessaye...", //tsc_pingt_msg11
	"Voulez-vous vraiment supprimer cette entrée ?", //up_ae_de_1
	"Cette partie d'écran est mise à jour continuellement pour afficher tous les ordinateurs et dispositifs clients DHCP qui sont reliés au LAN du routeur. La ‘plage’ de détection est limitée à la plage d'adresses configurée dans le serveur DHCP. Les ordinateurs qui ont une adresse en dehors de cette plage ne seront pas vus. Si le client DHCP (c.-à-d. un ordinateur configuré pour obtenir automatiquement une adresse) fournit un nom d'hôte, alors il sera également affiché. Tout ordinateur ou dispositif avec une adresse IP statique comprise dans la &quot;plage&quot; de détection peut être listé, mais pas son nom d'hôte.", //help781
	"Saisissez l’adresse MAC désirée.", //help161_2
	"6:00 PM", //tt_time_19
	"Utilisez l'adresse MAC du client pour autoriser l'accès au réseau via le point d'accès.", //am_intro
	"Les nombre d’échecs de transmission provoquant la perte d'un paquet.", //help811
	"Moyen", //aw_TP_1
	"(GMT) Casablanca, Monrovia", //up_tz_24
	"Les détails d'authentification MSCHAP ont été envoyés à l'authentificateur.", //IPMSCHAP_AUTH_SENT
	"Utilisez cette option pour voir les clients sans fil qui sont reliés à votre routeur sans fil.", //sw_intro
	"Le protocole d'impression LPD/LPR utilise une adresse IP fixe et un nom de file d’attente pour communiquer avec votre imprimante.", //tps_lpd1
	"et", //help257
	"Le routeur va maintenant être reprogrammé à l'aide du fichier de microprogramme téléchargé. Veuillez patienter <span id='show_sec'></span>&nbsp;secondes le temps que ce processus se termine. Vous pourrez ensuite à nouveau accéder à ces pages Web. Le fait de retourner à la page précédente ou d'actualiser la page en cours de votre navigateur peut entraîner l'échec de cette opération.", //_upgintro
	"Fermé – La connexion n'est plus active mais la session est dépistée au cas où il resterait des paquets retransmis en attente.", //help819_8
	"(secondes)", //bws_secs
	"Paquet ICMP sortant bloqué (type d’ICMP %u) de %v à %v", //IPNAT_ICMP_BLOCKED_EGRESS_PACKET
	"Redirection de port", //PORT_FORWARDING
	"IP dynamique (DHCP)", //bwn_Mode_DHCP
	"Heure", //tt_Hour
	"Saisissez les adresses IP des serveurs DNS. Laissez le champ pour le serveur secondaire vide si vous l’utilisez pas.", //help290a
	"Déconnexion BigPond.", //BIGPOND_LOGGING_OUT
	"Si vous avez des problèmes de réception du flux de données en multidiffusion, assurez-vous que l'option de flux de données en multidiffusion est validée.", //hhan_mc
	"Serveur DNS primaire", //_dns1
	"Serveur DNS IPv6 principal", //_dns1_v6
	"Outils", //_tools
	"Déconnecté", //_sdi_s2
	"Port USB", //sps_usbport
	"Erreur système pendant l'attribution du calendrier %s.", //GW_SCHED_ALLOC_FAILED
	"Empêchez tous les utilisateurs du WAN d'accéder à ces possibilitées. (Les utilisateurs du réseau local ne sont pas affectés par des règles de filtre entrant.)", //help179
	"Activez BigPond:", //help262
	"Autoriser", //_allow
	"Sélectionnez les niveaux des événements que vous voulez afficher.", //help798
	"Adresse IP obtenue via DHCP. L'adresse IP est %v.", //DHCP_CLIENT_GOT_LEASE
	"Vitesse du Port WAN", //anet_wan_phyrate
	"Remarque", //_note
	"Dest<br />Port<br /> Début", //aa_FPR_c6
	"Ports UDP à ouvrir", //help69
	"Le temps du bail DHCP", //bd_DLT
	"Liste des règles de filtre entrant", //ai_title_IFRL
	"L'interface de réseau local est en service.", //GW_LAN_INTERFACE_UP
	"ENREGISTREMENTS", //_logs
	"Désactivez le filtrage MAC", //am_FM_2
	"Envoi d'un journal par courrier électronique après requête de l'administrateur.", //GW_LOG_EMAIL_ON_USER_REQUEST
	"Il s'agit du port qui sera accessible depuis Internet.", //help21
	"Mode 802.11", //bwl_Mode
	"Mode adresse", //bwn_AM
	"Serveur BigPond", //bwn_BPS
	"Saisissez les informations fournies par votre fournisseur d'accès Internet (FAI).", //_ispinfo
	"Vitesse", //_rate
	"(GMT-07:00) Heure des Rocheuses (États-Unis/Canada)", //up_tz_06
	"Succès", //_success
	"Service sentinelle de contrôle parental", //_bsecure_parental_serv
	"Définir un nom d''utilisateur et un mot de passe de connexion (L2TP)", //wwa_set_l2tp_title
	"Mac OS X", //help342
	"Sélectionnez cette option si votre FAI vous demande d'utiliser une connexion PPPoE (Protocole Point à Point sur Ethernet). Les fournisseurs DSL utilisent généralement cette option. Elle exige que vous saisissiez un <span class='option'>nom d'utilisateur</span> et un <span class='option'>mot de passe</span> (fournis par votre fournisseur d'accès Internet) pour pouvoir accéder à Internet.", //help265
	"Le serveur SMTP (courrier électronique) %s est à l'adresse IP %v", //GW_SMTP_EMAIL_RESOLVED_DNS
	"Pings perdus:", //tsc_pingt_msg102
	"Port du serveur RADIUS", //bws_RSP
	"Tentative d'établissement d'une connexion PPPoE.", //PPPOE_EVENT_CONNECT
	"Configuration de temps automatique", //tt_auto
	"Le sous-système PPTP est faible en ressources. La connectivité peut être affectée.", //PPTP_EVENT_LOW_RESOURCES_TO_QUEUE
	"Le tunnel local L2TP 0x%04X a reçu un message de contrôle inattendu (ignoré).", //IPL2TP_TUNNEL_UNEXPECTED_MESSAGE
	"Neverwinter Nights", //gw_gm_34
	"5ème", //tt_week_5
	"Voici ci-dessous un résumé détaillé de vos réglages de sécurité sans fil. Veuillez imprimer cette page, ou écrire l'information sur un morceau de papier, ainsi vous pourrez configurer les mêmes réglages sur vos adaptateurs clients sans fil.", //wwl_intro_end
	"Tableau des stratégies", //aa_Policy_Table
	"Configuration de l’heure", //tt_TimeConf
	"Aucun", //_none
	"Étape 2 : Sélectionnez un calendrier", //_aa_wiz_s3_title
	"Une phrase qui doit correspondre à celle du le serveur d'authentification.", //help392
	"Envoi d'un journal par courrier électronique selon calendrier.", //GW_LOG_EMAIL_ON_SCHEDULE
	"Sélectionnez le fuseau horaire correspondant à votre zone. Vous aurez besoin de ces informations pour configurer les options du routeur qui sont basées sur le temps.", //wwa_intro_s2
	"Adresse IP de la passerelle PPTP", //_PPTPgw
	"Accès au site Web %S depuis %v", //WEB_FILTER_LOG_URL_ACCESSED
	"L’ALG MMS a rejeté le paquet de %v:%u à %v:%u", //IPMMSALG_REJECTED_PACKET
	"Paramètres sans fil", //_wirelesst
	" Il y a deux moyens pour établir votre connexion Internet : vous pouvez employer l’assistant d’installation Web, ou vous pouvez manuellement configurer la connexion.", //int_intro
	"L'accès est refusé au système de réseau local avec l'adresse MAC %m", //GW_LAN_ACCESS_DENIED
	"Jedi Knight II: Jedi Outcast", //gw_gm_26
	"Paquet GRE entrant bloqué de %v à %v.", //PPTP_ALG_GRE_BLOCKED_INGRESS
	"(GMT+01:00) Afrique centrale de l'Ouest", //up_tz_30
	"Starcraft", //gw_gm_49
	"Programmation", //_sched
	"Échec du montage du périphérique FAT", //IPFAT_MOUNT_FAILED
	"KALI", //gw_gm_75
	"Le numéro de version firmware actuellement installé sur votre routeur ainsi que la dernière version disponible sont affichées ici.", //help883
	"Veuillez patienter, téléchargement du fichier de configuration en cours...", //ta_alert_6
	"La stratégie %s est démarrée ; l'accès à Internet pour l'adresse IP %v devient : %s", //GW_INET_ACCESS_POLICY_START_IP
	"Il affiche l’heure actuelle du routeur. Si ce n'est pas correct, veuillez utiliser les options suivantes pour configurer l’heure correctement.", //help841a
	"10:00 PM", //tt_time_23
	"Règles de réacheminement de port", //ag_title_4
	"WinMX", //gw_gm_68
	"Paquet TCP sortant bloqué de %v:%u à %v:%u car %s n’est pas permis en l’état %s", //IPNAT_TCP_BLOCKED_EGRESS_UNEXP_FLAGS
	"Nom d'hôte", //help260
	"FIN Wait -- Le système du client a demandé que la connexion soit stoppée.", //help819_4
	"Si tous les dispositifs sans fil que vous voulez connecter à ce routeur peuvent utiliser un même mode de transmission, vous pouvez améliorer légèrement les performances en choisissant le mode &quot;Seulement&quot; approprié. Si vous avez certains dispositifs qui utilisent un mode de transmission différent, choisissez le mode &quot;Mixte&quot; approprié.", //help357
	"TCP", //_TCP
	"Challenge d'authentification MSCHAP reçu du produit distant.", //IPMSCHAP_CHALLENGE_RECVD
	"Universal Plug and Play (UPnP) permet aux produits réseau de supporter la fonctionnalité Plug & Play point à point.", //anet_msg_upnp
	"Appuyez sur le bouton  <span class='button_ref'> Mise à jour DHCP </span> pour ignorer l' adresse IP du routeur. Le routeur ne répondra plus aux messages IP du WAN jusqu'à ce que vous cliquiez sur le bouton <span class='button_ref'> Remplacement DHCP </span> ou que vous mettiez de nouveau le routeur sous tension. Appuyez sur le bouton <span class='button_ref'> Remplacement DHCP </span> implique que le routeur demande une nouvelle adresse IP au serveur du FAI.", //help776
	"Sélectionnez la méthode de configuration pour votre réseau sans fil.", //KR49
	"Ici, vous pouvez activer ou désactiver des ALG. Certains protocoles et applications nécessitent une manipulation spéciale des données IP utiles pour fonctionner avec la traduction d'adresses du réseau (NAT). Chaque ALG fournit une gestion spéciale d'un protocole ou d'une application donnés. Plusieurs ALG sont activées par défaut pour les applications courantes.", //help32
	"Asheron's Call", //gw_gm_3
	"Nombre de secondes d'inactivité avant que le routeur n'envisage de fermer la session.", //help823
	"Adresse IP de L2TP", //_L2TPip
	"Redémarrer le produit", //_reboot
	"Il y a deux façons d'ajouter des clients sans fil à votre réseau:", //wps_p3_1
	"Étape 3 : Le cas échéant, insérez le CD avec le pilote d'impression.", //wprn_intro5
	"Services sentinelle de Sécurité", //_bsecure_security_serv
	"Reçue dans", //tsc_pingt_msg8
	"Unreal Tournament", //gw_gm_56
	"La section de mise à niveau du microprogramme vous permet d'obtenir la dernière version du microprogramme en vue d'améliorer ses fonctionnalités et ses performances.", //tf_intro_FWU
	"(GMT+08:00) Kuala Lumpur, Singapour", //up_tz_57
	"Le serveur de mise à niveau du microprogramme %s se trouve à l'adresse IP %v.", //GW_FW_NOTIFY_RESOLVED_DNS
	"Port et adresse restreinte", //af_EFT_2
	"(GMT-12:00) Eniwetak, Kwajalein", //up_tz_00
	"Les planifications sont employées avec un certain nombre d'autres règles pour définir quand ces règless sont activées.", //hhts_intro
	"Authentification", //_auth
	"Le tunnel local L2TP 0x%04X est en cours de déconnexion.", //IPL2TP_TUNNEL_DISCONNECTING
	"Échec de la synchronisation du temps après nouvelles tentatives ; abandon en cours...", //NET_RTC_SYNCHRONIZATION_FAILED_AFTER_RETRIES
	"Version du microprogramme", //sd_FWV
	"Liste des règles de calendrier", //tsc_SchRuLs
	"Cette option évite que des clients sans fil associés ne communiquent entre eux.", //KR58_ww
	"(facultatif)", //YM98
	"Sauvegarder la Configuration", //ta_SavConf
	"Adresse DNS secondaire", //wwa_sdns
	"Cette option restaure les réglages de configuration usine. Tous les réglages qui n'ont pas été sauvegardés seront perdus. Si vous voulez sauvegarder vos réglages de configuration du routeur, appliquez l'option Sauvegarder les réglages ci-dessus.", //help876
	"Cette option utilise l’Accès protégé Wi-fi avec la clé pré-partagée (PSK).", //help380
	"Filtre de réseau", //_netfilt
	"Jours", //gw_days
	"Connexion", //li_Login
	"Le réseau étendu est déjà connecté.", //WAN_ALREADY_CONNECTED
	"WPA2 uniquement", //bws_WPAM_3
	"L'adresse de passerelle %v ne doit pas être l'adresse de l'interface prévue", //GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS
	"(mot de passe à indiquer)", //GW_DYNDNS_PASSWORD_INVALID
	"Partie serveur virtuel", //tool_admin_vsname
	"(GMT+06:00) Astana, Dhaka", //up_tz_50
	"Adresse IP statique", //static_PPPoE
	"Heure de début", //tsc_StrTime
	"Temps de ping le plus court (en millisecondes) :", //tsc_pingt_msg104
	"Erreur d'ID du périphérique d'impression", //wprn_iderr
	"Choisir cette option vous permet de voir les paramètres de configuration sans fil actuels afin de les changer manuellement", //wps_KR42
	"Temporisation", //td_Timeout
	"Appliquer un filtre Web", //_aa_apply_web_filter
	"Remettre en non configuré", //resetUnconfiged
	"Jeux", //GAMING
	"8:00 AM", //tt_time_9
	"Paquet entrant bloqué entre %v et %v (protocole IP %u)", //IPNAT_BLOCKED_INGRESS
	"L'interface de réseau étendu est en service. La connexion à Internet est établie avec l'adresse IP %v et la passerelle par défaut %v.", //GW_WAN_INTERFACE_UP
	"Adresse IP du routeur", //_ripaddr
	"Délais d’attente", //sa_TimeOut
	"Paquet TCP sortant bloqué de %v:%u à %v:%u avec la séquence inattendue %lu (prévue %lu à %lu)", //IPNAT_TCP_BLOCKED_EGRESS_BAD_SEQ
	"L'interface de réseau local est hors service.", //GW_LAN_INTERFACE_DOWN
	"En fonction de la connexion au réseau étendu actuellement établie, vous pouvez cliquer sur le bouton <span class='button_ref'>Connecter</span> pour essayer d'établir la connexion au réseau étendu ou sur le bouton <span class='button_ref'>Déconnecter</span> pour interrompre la connexion au réseau étendu.", //help778
	"Nom de file d’attente", //sps_qname
	"Secondes", //_seconds
	"Journal effacé par l'adresse IP %v.", //GW_LOGS_CLEARED
	"Alerte", //sl_Warning
	"Adresse de l'ordinateur", //aa_MAC
	"Choisir cette option si votre produit sans fil supporte le WPS (Wi-Fi Protected Setup)", //wps_KR51
	"Manuel", //help274
	"L’utilisation d’un intervalle de protection court (400ns) peut augmenter le débit. Cependant, elle peut également augmenter le taux d'erreur, en augmentant la sensibilité aux réflexions des fréquences radio.", //aw_sgi_h1
	"Paquet source-routé bloqué de %v à %v", //IPSTACK_REJECTED_SOURCE_ROUTED_PACKET
	"Adresse DNS principale", //wwa_pdns
	"Employez cette option pour restaurer des réglages sauvegardés de la configuration de routeur.", //help834
	"Dim", //_Sun
	"Nombre de périphériques", //sto_no_dev
	"Pour éviter l'intrusion sur votre réseau sans fil, le routeur va utiliser automatiquement une sécurité d'accès (autrement appelé clé WEP ou WPA).", //wwz_auto_assign_key2
	"Nombre de flux spatiaux", //bwl_NSS
	"(GMT-04:00) Caracas, La Paz", //up_tz_15
	"Une fois que vous avez trouvé le fichier à employer, veuillez appuyer sur le bouton <span class='button_ref'> Téléchargement </span> pour commencer le processus de mise à jour du firmware. Ceci peut prendre une ou plusieurs minutes.", //help880
	"Tentative de connexion au serveur L2TP.", //IPL2TP_TUNNEL_CONNECTING
	"Activer SharePort pour la zone invité", //bwn_mici_guest_use_shareport
	"Temps synchronisé", //NET_RTC_SYNCHRONIZED
	"(GMT-06:00) Saskatchewan", //up_tz_10
	"Activé", //_on
	"Vous n'êtes pas connecté, veuillez actualiser le navigateur.", //NOT_LOGGED_IN_PLEASE_REFRESH
	"Paquet GRE entrant bloqué de %v à %v.", //IPSEC_ALG_ESP_BLOCKED_INGRESS
	"Continuer", //ub_continue
	"Nom d'utilisateur ou clé", //td_UNK
	"Échec du montage du périphérique PV%d", //IPPMVM_MOUNT_FAILED
	"Rise of Nations", //gw_gm_42
	"Adresse de réseau local que vous voulez réserver.", //_1066
	"Semaine entière", //tsc_AllWk
	"Serveur virtuel", //_virtserv
	"L'option serveur virtuel permet aux Internautes d'accéder aux services de votre réseau local. Cette option est utile pour accueillir les services en ligne, comme les serveurs FTP, Web, ou de jeux. Pour chaque serveur virtuel, définissez un port public sur votre routeur afin de le rediriger vers une adresse IP du réseau local interne et un port du réseau local.", //help2
	"Sélectionnez cette option si vous voulez que le journal soit envoyé par courrier électronique dès qu'il est plein.", //help869
	"Le protocole LCP définit les options locales : ACCM : %lx, ACFC : %u, PFC : %u, MRU : %u", //IPPPPLCP_SET_LOCAL_OPTIONS
	"Redémarrer le produit", //ts_rd
	"L’ALG IPSec a rejeté le paquet de %v:%u à %v:%u", //IPSEC_ALG_REJECTED_PACKET
	"Veuillez attendre, résolution", //tsc_pingt_msg3
	"Système sans fil avec adresse MAC %m déconnecté pour la raison suivante : %s", //GW_WIRELESS_DEVICE_DISCONNECTED
	"Réseau sans fil", //sd_WRadio
	"Sites Web autorisés - %s%s, ports - %s.", //ALLOWED_WEB_SITES
	"BitTorrent", //gw_sa_1
	"UDP", //_UDP
	"Le fait de placer un ordinateur dans une zone DMZ l'expose à divers risques liés à la sécurité. Utilisez cette option uniquement si elle est recommandée en dernier recours.", //help166
	"La section de contrôle d'accès vous permet de contrôler l'accès entrant et sortant des machines de votre réseau. Utilisez ce moyen comme Contrôle Parental pour accorder seulement l'accès aux sites approuvés, limiter l'accès du Web en fonction de l'heure ou de la date, et/ou l'accès des applications telles que des utilitaires peer-2-peer ou des jeux.", //help117
	"Type de connexion Internet : L2TP", //bwn_L2TPICT
	"Le routeur enregistre automatiquement les événements intéressants dans sa mémoire interne. S'il n'y a pas assez de mémoire interne pour tous les événements, les événements les plus anciens seront supprimés, mais les derniers événements sont gardés. L'option Journaux vous permet de voir les journaux du routeur. Vous pouvez définir quels types d'événements vous voulez regarder et le niveau des événements à regarder. Ce routeur permet également d’utiliser un serveur syslog externe pour envoyer les évenements sur un ordinateur de votre réseau équippé d’un utilitaire Syslog.", //help795
	"Non", //_no
	"(GMT+09:30) Adélaïde", //up_tz_63
	"Vous devez d'abord entrer le nom d'un fichier de microprogramme.", //tf_FWF1
	"(GMT+10:00) Brisbane", //up_tz_65
	"Priorité", //_priority
	"Le réseau étendu est déjà déconnecté.", //WAN_ALREADY_DISCONNECTED
	"Cette page contient des données qui n'ont pas été enregistrées. Voulez-vous quand même la quitter ?", //up_jt_1
	"Accès Internet pour tous les systèmes non spécifiés défini sur : %s", //GW_INET_ACCESS_INITIAL_OTHERS
	"Les adresses IP de début et finales sont des adresses du côté réseau étendu.", //hhai_ip
	"Cette option est utilisée pour ouvrir un ou plusieurs ports sur votre routeur quand les données envoyées sur Internet utilisent un port ou une plage de ports de &quot;déclenchement&quot;. Les règles spéciales d'applications s’appliquent à tous les ordinateurs de votre réseau local.", //as_intro_SA
	"L'essai de Ping envoie des paquets ‘Ping’ pour tester un ordinateur sur l'Internet.", //tsc_pingt_mesg
	"(GMT+04:30) Kaboul", //up_tz_44
	"Vous pouvez rencontrer des problèmes d'accès au serveur virtuel en utilisant son identité publique (adresse IP côté réseau étendu de la passerelle ou son nom DNS dynamique) à partir de la machine sur le réseau local. Vos demandes ne peuvent pas se reboucler ou vous pouvez être redirigé vers la page \"interdite\".", //help27
	"IPSec (VPN)", //as_IPSec
	"Admin", //_admin
	"eDonkey", //gw_gm_65
	"Pour mettre à jour le firmware, se positionner sur le fichier correspondant sur votre disque dur en utilisant le bouton Parcourir. Cliquer ensuite sur le bouton Upload pour démarrer la mise à jour du firmware.", //tf_intro_FWChB
	"Bloqué", //BLOCKED
	"Câble BigPond (Australia)", //wwa_msg_bigpond
	"Activez l'option de journalisation pour le Serveur Syslog", //help857
	"Close Wait --le système du serveur a demandé que la connexion soit stoppée.", //help819_5
	"Bas", //aw_TP_2
	"Temporisation d'authentification", //help385
	"Réglage complet!", //_setupdone
	"Connexion au routeur", //li_intro
	"Le client SMTP n'a pas réussi à envoyer un message électronique.", //IPSMTPCLIENT_MSG_FAILED
	"Avant de lancer ces assistants, veuillez vous vous assurer d’avoir suivi toutes les étapes décrites dans le guide d'installation rapide inclus dans le paquet.", //bwz_note_ConWz
	"Gnutella", //gw_gm_64
	"Mode de reconnexion:", //help268
	"Aucun blocage", //NONE_BLOCKED
	"Mai", //tt_May
	"Type de connexion Internet : Big Pond", //bwn_BPICT
	"2:00 PM", //tt_time_15
	"Mar ", //_Tue
	"Effacer les statistiques", //ss_clear_stats
	"Entrez l'heure finale en utilisant le même format que celui de l'heure de début : l'heure dans le premier champ et les minutes dans le deuxième. L'heure finale est utilisée pour la plupart des autres règles, mais en général pas par les événements de courrier électronique.", //help197
	"Des règles de filtre peuvent être employées avec les fonctions Serveur virtuel, Réacheminement de port, ou Administration à distance.", //ai_intro_3
	"Connexion de réseau étendu inactive trop longtemps ; tentative de déconnexion en cours...", //GW_WAN_DISCONNECT_ON_INACTIVE
	"L'adresse DHCP %v est libérée par l'utilisateur.", //DHCP_CLIENT_RELEASED_LEASE
	"Définir la connexion de l''adresse IP statique", //wwa_set_sipa_title
	"(GMT+12:00) Auckland, Wellington", //up_tz_71
	"Les ALGs permettent la manipulation spéciale de la charge utile d'IP pour certains protocoles et applications et ainsi de les faire fonctionner avec la translation d'adresses de réseau (NAT). Si vous rencontrez des problèmes lors de l’utilisation d’une de ces applications, essayez d’activer et désactiver l’ALG correspondante.", //hhaf_alg
	"Vérifiez cette option si vous devez régler l’heure d’été/d’hiver.", //help843
	"Vérifiez qu'une imprimante est reliée au port USB du routeur.", //wprn_tt11
	"Statistiques sur le trafic", //_tstats
	"Le protocole LCP définit les options distantes : ACCM : %lx, ACFC : %u, PFC : %u, MRU : %u", //IPPPPLCP_SET_REMOTE_OPTIONS
	"Rechercher maintenant la dernière version du microprogramme et du pack linguistique en ligne", //tf_COLF
	"(GMT+01:00) Bruxelles, Copenhague, Madrid, Paris", //up_tz_28
	"Mars", //tt_Mar
	"Autoriser l’accès au Web uniquement", //_aa_allow_all
	"Nom d''utilisateur/mot de passe de connexion (L2TP)", //wwa_wanmode_l2tp
	"Hôte DMZ", //_dmzh
	"Le serveur de synchronisation %s est à l'adresse IP %v.", //GW_TIME_RESOLVED_DNS
	"EAP (802.1x)", //bws_EAPx
	"Nom de stratégie", //aa_PolName
	"Pour configurer cette connexion, vous devez posséder une liste complète des informations IP fournies par votre fournisseur d'accès Internet. Si vous possédez une connexion par adresse IP statique, mais que vous n'avez pas cette information, contactez votr", //wwa_set_sipa_msg
	"Étape 1 : Choisissez un nom de stratégie", //_aa_wiz_s2_title
	"PPTP connecté au serveur \'%s\' avec l'ID 0x%04X.", //PPTP_EVENT_TUNNEL_CONNECTED
	"Aucune interface de stockage de masse USB compatible WCN n'a été détectée.", //USB_LOG_STORAGE_NOT_FOUND
	"Périphérique initialisé", //GW_INIT_DONE
	"Adresse IP dynamique", //carriertype_ct_0
	"Ce sont les réglages de l'interface LAN (réseau local) du routeur. L’adresse IP et le masque de sous-réseau. Cette adresse IP est également utilisée pour accéder à l’interface de gestion du routeur.", //help305
	"Impression brute du port TCP", //tps_raw
	"Port public", //av_PubP
	"Mode WPA:", //help374
	"Le protocole PPTP a reçu de l'application une requête de libération du tunnel ; le tunnel va maintenant être fermé.", //PPTP_EVENT_TUNNEL_CLEAR_DOWN_REQUEST
	"Appuyez sur <strong>Supprimez l'icône </strong> pour enlever définitivement une règle.", //hhac_delete
	"La session locale L2TP 0x%04X est en cours de finalisation.", //IPL2TP_SESSION_CLEAR_DOWN_REQUEST
	"Stratégie", //aa_ACR_c2
	"Les demandes de la machine LAN ne se rebouclent pas si l'accès à Internet est bloqué au moment de l'accès. Pour résoudre ce problème, accéder à la machine LAN à l'aide de son identité côté réseau local.", //help29
	"(GMT-11:00) Îles Midway, Samoa", //up_tz_01
	"Application", //_app
	"Masque de sous-réseau LAN invalide.", //bln_alert_1
	"Estimation de la vitesse de l'interface de réseau étendu.", //GW_WAN_RATE_ESTIMATOR_STARTED_ON_WAN
	"Pare-feu &amp Sécurité", //sl_FWandSec
	"Pour une meilleure sécurité, il est recommandé de désactiver l’option de réponse au Ping WAN. Le Ping est souvent employé par des utilisateurs malveillants d'Internet pour localiser les réseaux actifs ou les PC.", //hhan_ping
	"NAT", //sa_NAT
	"L'activation de la gestion à distance vous permet de gérer le routeur depuis n'importe quel point sur Internet. Si vous désactivez cette option, vous ne pouvez gérer le routeur qu'à partir des ordinateurs de votre réseau local.", //help828
	"Impossible de détecter l'enregistrement DNS pour le serveur SMTP (de messagerie) %s.", //GW_SMTP_EMAIL_FAILED_DNS
	"Le nombre des paquets abandonnés dû aux collisions sur  Ethernet (deux dispositifs ou plus essaient d'utiliser un circuit d'Ethernet en même temps).", //help810
	"Réveil par le réseau", //_WOL
	"Sur demande", //bwn_RM_1
	"Aucun -- Cette entrée est disponible pour une future connexion.", //help819_1
	"Message d'erreur ICMP entrant bloqué (type d'ICMP %u) de %v à %v, il n’y a aucune connexion TCP active entre %v:%u et %v:%u", //IPNAT_TCP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"(GMT-04:00) Heure de l'Atlantique (Canada)", //up_tz_14
	"Star Trek: Elite Force II", //gw_gm_51
	"Adresse IP du serveur", //td_SvAd
	"Vous pouvez entrer des ports dans divers formats :", //hhag_40
	"Des filtres entrants peuvent être utilisés pour limiter l'accès d’un serveur sur votre réseau à un système ou à un groupe de systèmes. Des règles de filtre peuvent être employées avec le Serveur Virtuel, le jeu, ou les dispositifs d'administration à distance. Chaque filtre peut être utilisé pour plusieurs fonctions ; par exemple un filtre &quot; Clan de jeu &quot; pourrait permettre à tous les membres d'un groupe de jeu particulier de jouer plusieurs jeux différents pour lesquels des entrées de jeu ont été créées. En même temps un filtre &quot;Admin&quot; permet seulement à des systèmes de votre réseau de bureau d'accéder aux pages de WAN admin et un serveur FTP que vous utilisez à la maison. Si vous ajoutez une adresse IP à un filtre, le changement est effectué à tous les endroits où le filtre est utilisé.", //help169
	"Durée pendant laquelle un ordinateur bénéficie d'une adresse IP avant de devoir en renouveler la concession. La concession fonctionne exactement comme le bail de location d'un appartement. La concession initiale désigne la durée avant expiration de la concession. Si le bénéficiaire de la concession souhaite conserver l'adresse après l'expiration de la concession, alors une nouvelle concession est établie. Si la concession expire et que son bénéficiaire n'a plus besoin de l'adresse, alors celle-ci peut être concédée à une autre personne.", //help324
	"Ping est une fonction utilitaire Internet qui envoie une série de courts messages à un ordinateur cible et communique les résultats. Vous pouvez l'utiliser pour tester le fonctionnement d'un ordinateur et vous faire une idée de la qualité de sa connexion d'après la vitesse des réponses.", //htsc_intro
	"Partition du réseau local sans fil", //KR4_ww
	"Les paramètres TCP/IP des ordinateurs (et des autres périphériques) connectés à votre réseau local doivent également être configurés sur &quot;DHCP&quot; ou sur &quot;Obtenir une adresse IP automatiquement&quot;.", //help317
	"Flux de données en multidiffusion", //anet_multicast
	"Flux de multidiffusion IPv4", //anet_multicast_v4
	"Flux de multidiffusion IPv6", //anet_multicast_v6
	"Ajout d'une nouvelle stratégie", //_aa_wiz_s1_title
	"Le module RTE 0x%04X du tunnel local L2TP est éteint.", //IPL2TP_SHUTDOWN_COMPLETE
	"Dernier ACK -- Attendre pendant une courte période qu'une connexion en état Close Wait soit entièrement fermée.", //help819_7
	"Sélectionnez le protocole (par exemple <code>TCP</code>).", //help9
	"Le nombre des paquets abandonnés au lieu d’être reçus, dû aux erreurs, aux collisions, ou aux limitations de ressource du routeur.", //help809
	"Courant porteur Ethernet de réseau local détecté.", //GW_LAN_CARRIER_DETECTED
	"Voulez-vous vraiment effacer toutes les entrées du journal ?", //sl_alert_1
	"Port déclencheur", //as_TPRange_b
	"1ère", //tt_week_1
	"Si oui, cliquez sur OK.", //up_jt_3
	"Effacer", //_clear
	"Fin de la session PPPoE 0x%04X.", //PPPOE_EVENT_DISCONNECT
	"L'enregistreur interne WPS n'a pas pu ajouter la station sans fil %m, raison: %s, code_err %u.", //WIFISC_IR_REGISTRATION_FAIL_2
	"IP statique", //_sdi_staticip
	"Donnez à chaque planification un nom signicatif. Par exemple, une planification pour une période du lundi au vendredi de 15h à 21h, pourrait s'appeler ‘après école’.", //hhts_name
	"Réseau étendu", //WAN
	"Entrez un mot de passe pour l'utilisateur &quot;admin&quot;, qui pourra accéder sans aucune restriction à l'interface de gestion Web.", //help824
	"Les ordinateurs qui ont obtenu une adresse IP du serveur DHCP du routeur seront dans la liste des clients DHCP. Choisissez une machine à partir du menu déroulant, puis appuyez sur la flèche pour ajouter l'adresse MAC de ce dispositif à la liste.", //hham_add
	"Statistiques du WAN", //ss_WANStats
	"Tentative de démarrage d'une connexion de réseau étendu sur demande.", //GW_WAN_CONNECT_ON_ACTIVE
	"Vous devez annuler toutes les modifications afin de définir un nouveau calendrier.", //aa_sched_conf_1
	"La stratégie %s est arrêtée ; l'accès à Internet pour tous les systèmes non spécifiés devient : %s", //GW_INET_ACCESS_POLICY_END_OTHERS
	"Liste de réservations DHCP", //bd_title_list
	"Journal des accés Web", //_aa_logging
	"Message d'erreur de paquet entrant d’ICMP bloqué (type d’ICMP %u) de %v à %v car il n’y a aucune session active pour le protocole %u entre %v et %v", //IPNAT_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"Nom d’utilisateur", //_username
	"eMule", //gw_gm_67
	"Impossible de détecter l'enregistrement DNS pour le serveur de synchronisation %s.", //GW_TIME_FAILED_DNS
	"Consultez la documentation jointe à votre routeur pour obtenir des instructions de configuration d'imprimante spécifiques à votre système d'exploitation.", //wprn_tt1
	"9:00 PM", //tt_time_22
	"Adresse IP", //help256
	"Politique d'accès à Internet pour l’adresse IP %v ne peut pas être validée.", //GW_INET_ACCESS_INITIAL_IP_FAIL
	"Détails", //_aa_details
	"Permet aux applications qui utilisent le protocole de diffusion en temps réel de recevoir des médias en continu d'Internet. QuickTime et Real Player sont certaines des applications communes qui utilisent ce protocole.", //help36
	"Le numéro de port de l'application du LAN vu par l'application du WAN.", //help817
	"PPPoE (Nom d’utilisateur/Mot de passe)", //bwn_Mode_PPPoE
	"Tout autoriser", //_allowall
	"Effacer la liste ci-dessous...", //awf_clearlist
	"Le routeur doit être réinitialisé pour que les paramètres enregistrés à une page précédente prennent effet. Vous pouvez réinitialiser le routeur maintenant en cliquant sur le bouton &quot;Réinitialiser&quot; ci-dessous, ou bien cliquez sur le bouton &quot;Continuer&quot; et faites d'autres modifications.", //sc_intro_rb3
	"Ports TCP à ouvrir", //help67
	"Quake 2", //gw_gm_37
	"Autres", //aa_AT_2
	"Étape 1 : Régler votre mot de passe", //wwa_title_s1
	"Nom du pilote", //tps_drname
	"Copier les paramètres horaires de votre ordinateur", //tt_CopyTime
	"Le serveur de session L2TP a démarré en envoyant des nombres séquentiels pour la session locale 0x%04X.", //IPL2TP_SEQUENCING_ACTIVATED
	"Réserver", //bd_Reserve
	"L’ALG MSN Messenger a rejeté le paquet de %v:%u à %v:%u", //IPMSNMESSENGERALG_REJECTED_PACKET
	"La section sans fil vous permet de voir les clients sans fil connectés à votre routeur sans fil.", //help782
	"Dungeon Siege", //gw_gm_16
	"La passerelle ALG de redirection de port n'a pas pu allouer de session au paquet UDP de %v:%u à %v:%u", //IPPORTFORWARDALG_UDP_PACKET_ALLOC_FAILURE
	"Modèle", //wprn_mod
	"Remarque:", //help119
	"Silent Hunter II", //gw_gm_46
	"Activez le filtrage MAC et PERMETTEZ aux ordinateurs listés d’accéder au réseau", //am_FM_3
	"Employez cette information pour configurer votre ordinateur pour l'impression LPD/LPR.", //sps_lpd1
	"Paramètres du système", //tss_SysSt
	"Restaurer la configuration à partir du fichier", //ta_ResConf
	"Mise à jour flash pour configuration sans fil", //WCN_LOG_SAVE
	"Type du trafic du Firewall", //as_FPrt
	"Connexions UDP.", //help823_11
	"Tous les jours", //tsc_EvDay
	"Cliquez sur le bouton<span class='button_ref'>Enlever </span> pour enlever l'adresse MAC de la liste de filtrage MAC", //ham_del
	"PPPoE", //_PPPoE
	"Il semble que vous avez déjà connecté avec succès votre nouveau routeur sur Internet.", //wwa_intro_online1
	"Fin du DST", //tt_dstend
	"Règle calendrier", //tsc_SchRu
	"Échec de tentative d'authentification de configuration par l'adresse IP %v.", //GW_AUTH_FAILED
	"Calendriers", //_scheds
	"(GMT+09:00) Irkoutsk, Oulan-Bator", //up_tz_56
	"Serveur DNS secondaire", //_dns2
	"Serveur DNS IPv6 secondaire", //_dns2_v6
	"Vous devez saisir un nom d'hôte ou une adresse IP .", //tsc_pingt_msg2
	"Ces paramètres sont automatiquement configurés et ne devraient être modifiés que par des utilisateurs avancés.", //tps_apc1
	"Le contrôle d'accès Internet a bloqué les paquets de %v:%u à %v:%u (protocole %u)", //GW_INET_ACCESS_DROP_ACCESS_CONTROL_WITH_PORT
	"(GMT+05:45) Katmandou", //up_tz_48
	"Mot de passe Admin", //_password_admin
	"Employez cette section pour configurer le serveur DHCP intégré afin d’assigner des adresses IP aux ordinateurs de votre réseau.", //bd_intro_
	"Adresse IP du Serveur RADIUS :", //help387
	"Authentification de configuration autorisée par l'adresse IP %v.", //GW_AUTH_SUCCEEDED
	"Détails d'authentification CHAP envoyés au poste.", //IPPPPCHAP_AUTH_SENT
	"Le service Contrôle parental est un moyen simple et efficace de limiter l'accès à des sites Web choquants, illicites ou violents. Ce service est adapté pour tous les ordinateurs PC ou Apple reliés au routeur, et est constamment et automatiquement mis à jour en temps réel. Vous n'avez donc pas besoin de télécharger des sites ou d'en saisir manuellement le nom. C'est un service rapide qui ne ralentira en aucun cas la vitesse de votre réseau.", //_bsecure_parental_blurb
	"Cet assistant vous guidera via les étapes suivantes pour ajouter une nouvelle politique de contrôle d'accès.", //_aa_wiz_s1_msg
	"Nombre de paquets reçus par le routeur.", //help807
	"(GMT+09:00) Séoul", //up_tz_61
	"Adresse IP de passerelle L2TP", //_L2TPgw
	"Échec de l'authentification MSCHAP - contrôlez les données de connexion.", //IPMSCHAP_AUTH_FAIL
	"Avancé:", //help395
	"Une fois que vous avez une mise à jour firmware sur votre ordinateur, employez cette option pour rechercher le fichier et puis le télécharger dans le routeur.", //help888
	"Medal of Honor: Games", //gw_gm_29
	"La règle s'applique au flux des messages dont l'adresse IP WAN est dans la plage déterminée ici.", //help95
	"Période de balise", //aw_BP
	"Arrêt des services de réseau étendu", //GW_WAN_SERVICES_STOPPED
	"TeamSpeak", //gw_gm_79
	"Choisissez un serveur de temps réseau pour la synchronisation. Vous pouvez saisir l'adresse d'un serveur temporel ou en sélectionner une dans la liste. Si vous avez des problèmes avec un serveur,veuillez en choisir un autre.", //help850
	"Vous hébergez un serveur Web sur un PC dont l'adresse IP du réseau local est 192.168.0.50 et votre FAI bloque le port 80.", //help4
	"(GMT-03:00) Brasilia", //up_tz_18
	"Quand vous utilisez le Serveur Virtuel, le réacheminement de port, ou les dispositifs d'administration à distance pour ouvrir les ports spécifiques pour communiquer de l'Internet, vous augmentez l'exposition de votre réseau local aux cyberattaques de l'Internet.", //help168a
	"L’ALG PPTP a rejeté le paquet de %v:%u à %v:%u", //PPTP_ALG_REJECTED_PACKET
	"Adresse du serveur SMTP", //te_SMTPSv
	"Battlefield 2", //gw_gm_84
	"Le module RTE 0x%04X du tunnel local L2TP est faible en ressources.", //IPL2TP_LOW_RESOURCES
	"Appuyez sur <strong> Ajoutez la politique</strong>pour commencer le processus de création d’une régle. Vous pouvez annuler ce processus à tout moment. Quand la création de la règle est fini, elle est ajoutée à la<strong>Liste des politiques</strong>ci-dessous.", //hhac_add
	"Auto  10/100 Mbps", //anet_wp_auto2
	"RTSP", //as_RTSP
	"Authentification &amp; sécurité", //_authsecmodel
	"MTU", //bwn_MTU
	"Steam", //gw_gm_72
	"Réseau étendu", //_WAN
	"Proxy IGMP amélioré", //anet_multicast_enhanced
	"Command and Conquer Generals", //gw_gm_8
	"WPA", //_WPA
	"Tapez à nouveau le mot de passe ou la clé que vous a fourni votre fournisseur de service. Si le fournisseur de service de DNS dynamique vous fournit uniquement une clé, entrez cette clé dans les trois champs.", //help897
	"Paquet TCP entrant bloqué de %v:%u à %v:%u avec la séquence inattendue %lu (prévue %lu à %lu)", //IPNAT_TCP_BLOCKED_INGRESS_BAD_SEQ
	"Réponse de", //tsc_pingt_msg7
	"Jan.", //tt_Jan
	"Battlefield Vietnam", //gw_gm_5
	"Sans fil Avançé", //_adwwls
	"Pings reçus:", //tsc_pingt_msg101
	"Unreal", //gw_gm_55
	"PING DU RÉSEAU ÉTENDU", //anet_wan_ping
	"Les paramètres <warn>WINS/NetBIOS ne peuvent être récupérés sur Internet dans ce mode Internet - WINS ne fonctionne pas comme prévu.</warn>", //GW_DHCP_SERVER_WINS_INCOMPATIBILITY_WARNING
	"Authentification de l’adresse MAC", //bws_RMAA
	"Étape 2 - Sélectionnez un calendrier", //aa_wiz_s1_msg2
	"6:00 AM", //tt_time_7
	"Initié du WAN vers le LAN.", //help822a
	"America's Army", //gw_gm_1
	"(GMT+03:00) Bagdad", //up_tz_37
	"Mode de sécurité", //bws_SM
	"(GMT+10:00) Hobart", //up_tz_68
	"Exactement 64 caractères en utilisant 0-9 et A-Z", //wwl_s4_intro_za3
	"Préc.", //_prev
	"Activer l'accès Web à SharePort", //sto_http_1
	"L'Assistant Configuration de l'imprimante requiert le protocole d'impression TCP Raw. Ce protocole est actuellement désactivé sur le routeur.", //wprn_foo1
	"Un réseau sans fil utilise des canaux spécifiques dans le spectre sans fil pour gérer la communication entre les clients. Certains canaux autour de vous peuvent interférer avec d’autres dispositifs électroniques. Choisissez le canal le plus libre pour aider à optimiser la performance et la couverture de votre réseau sans fil.", //help355
	"Jounalisé", //aa_ACR_c6
	"Secret partagé du serveur RADIUS secondaire", //bws_2RSSS
	"Secret partagé du Serveur RADIUS:", //help391
	"Après-midi", //_PM
	"Définissez la plage des adresses Internet à laquelle cette règle s’applique. Pour une unique adresse IP, saisissez la même adresse dans les deux boîtes <span class='option'> de début </span> et <span class='option'> de fin </span>. Jusqu'à huit plages peuvent être entrées. La case à cocher <span class='option'> Activer </span> vous permet d’activer ou de désactiver des entrées spécifiques dans la liste des plages.", //help174
	"Dépassement du temps d'attente PPPoE pour la connexion. Échec de la tentative de connexion.", //PPPOE_EVENT_DISCOVERY_TIMEOUT
	"Périphérique %s, wsetting.wfc : fichier introuvable", //WCN_LOG_NO_WSETTING
	"Erreur de papier", //psPaperError
	"Si vous laissez cette option dévalidée, le routeur ignore les requètes <code> Ping </code> sur son adresse IP WAN.", //anet_wan_ping_2
	"Pour mettre à niveau le microprogramme, suivez les étapes ci-après :", //help878
	"Jounalisé", //LOGGED
	"Manuel", //bwn_RM_2
	"Secret partagé du Serveur RADIUS", //bws_RSSs
	"(GMT+04:00) Bakou, Tbilissi, Erevan", //up_tz_43
	"L’ALG RTSP a rejeté le paquet de %v:%u à %v:%u", //IPRTSPALG_REJECTED_PACKET
	"ne peut être effacé ou renommé parce qu'en cours d'utilisation.", //GW_SCHEDULES_IN_USE_INVALID_s2
	"Aide avancée", //help1
	"Zone de jeu MSN", //gw_gm_73
	"Cliquez sur l’un de liens ou boutons vous aiguillera sur un autre site Web pour de plus amples informations.", //hhtsn_intro
	"Ping", //_ping
	"Vitesse manuelle de liaison montante", //at_UpSp
	"Étape 6 - Configure le contrôle d’accès Web", //aa_wiz_s1_msg6
	"Adresse IP de PPTP", //_PPTPip
	"Un DTIM est un compte à rebours informant les clients la prochaine fenêtre pour écouter les messages de multidiffusion. Quand le routeur sans fil a mis en mémoire des messages de multidiffusion pour les clients associés, il envoie le prochain DTIM avec une valeur d'intervalle de DTIM. Les clients sans fil détectent les balises et se réveillent pour recevoir l'émission de multidiffusion. La valeur par défaut est 1. Les réglages valides sont entre 1 et 255.", //help185
	"Appuyez sur ce bouton après avoir changé les options du journal pour les rendre effectives et permanentes.", //help799
	"(GMT-03:30) Terre-Neuve", //up_tz_17
	"Tous les détails de votre connexion réseau et Internet sont affichés sur cette page. La version du microprogramme s'affiche également ici.", //sd_intro
	"Télécharger", //tf_Upload
	"Seconde", //tt_Second
	"Tous les paramètres sans fil vont être perdus.", //wps_lost
	"Remarque:", //help26
	"(GMT+02:00) Helsinki, Riga, Tallinn", //up_tz_35
	"Employez cette section pour configurer votre type de connexion à Internet. Il y a plusieurs types de connexion à choisir, dont : IP statique, DHCP, PPPoE, PPTP, L2TP. Si vous êtes incertain sur votre méthode de connexion, veuillez entrer en contact avec votre Fournisseur d’Accès à Internet.", //bwn_intro_ICS
	"Utilisez cette section pour configurer votre type de Connexion Internet. Vous pouvez choisir parmi plusieurs types de connexions : IP statique, DHCP, PPPoE, PPTP, L2TP et 3G USB. Si vous n'êtes pas sûr de votre méthode de connexion, contactez votre fournisseur d'accès Internet.", //bwn_intro_ICS_3G
	"Utilisez cette section pour configurer votre type de Connexion Internet. Vous pouvez choisir parmi plusieurs types de connexions : IP statique, DHCP, PPPoE, PPTP, L2TP et DS-Lite. Si vous n'êtes pas sûr de votre méthode de connexion, contactez votre fournisseur d'accès Internet.", //bwn_intro_ICS_v6
	"Lorsque cette option est activée, le routeur mesure automatiquement la largeur de bande montante utile à chaque fois que l'interface du réseau étendu est rétablie (après un redémarrage, par exemple).", //help81
	"Cette option vous permet de sauvegarder la configuration du routeur dans un fichier sur votre ordinateur. Assurez-vous que vous avez sauvegardé la configuration avant d'effectuer une mise à jour firmware.", //help833
	"Envoyé", //ss_Sent
	"Intervalle de mise à jour de clé du groupe:", //help378
	"Tribes of Vengeance", //gw_gm_80
	"Téléchargement réussi", //_uploadgood
	"BROCHE", //KR38
	"L’exécutable d’installation recherchera un pilote d’impression compatible sur votre ordinateur. S’il ne peut pas être trouvé, vous serez amené à insérer le CD des pilotes CD livré avec l'imprimante.", //wprn_s3c
	"Le routeur ne fournit qu’une protection limitée de coupe-feu pour l’hôte DMZ. Le routeur ne réachemine pas un paquet TCP qui ne correspond pas à une session DMZ active, à moins que ce soit un paquet d'établissement de connexion (Caractère de synchronisation SYN). Excepté cette protection limitée de l’hôte DMZ, il est effectivement &quot;en dehors du coupe-feu&quot;. Toute personne voulant  employer un hôte DMZ devrait également activer dessus un parefeu pour assurer une protection supplémentaire.", //haf_dmz_20
	"Reçu", //ss_Received
	"Vérifiez cette option pour vous connecter à Internet par le câble Telstra BigPond en Australie. Telstra BigPond fournit les valeurs pour", //help263
	"Essai de 30 jours GRATUIT", //_bsecure_free_trial
	"Options de notification de mise à niveau de microprogramme", //tf_FUNO
	"GI court", //aw_sgi
	"Durée du bail avant que le client ne doive se reauthentifier.", //help386
	"Il y a plusieurs types de connexion: IP statique, DHCP, PPPoE, PPTP, L2TP, et BigPond. Si vous n’êtes pas sûr sur votre méthode de connexion, consultez votre Fournisseur d’Accès à Internet. Remarque : Lorsque vous utilisez l'option PPPoE, vous devez vous assurer que tous les logiciels client PPPoE sur vos ordinateurs sont supprimés ou désactivés.", //help254_ict
	"Vous pouvez choisir parmi plusieurs types de connexions : IP statique, DHCP, PPPoE, PPTP, L2TP et 3G USB. Si vous n'êtes pas sûr de votre méthode de connexion, contactez votre fournisseur d'accès Internet. Remarque : Si vous utilisez l'option PPPoE, vous devez vous assurer que tous les logiciels clients PPPoE de vos ordinateurs sont désinstallés ou désactivés.", //help254_ict_3G
	"Choisissez la méthode pour le filtrage.", //_aa_wiz_s5_msg1
	"Confirmer le mot de passe ou la clé", //td_VPWK
	"Need for Speed 3", //gw_gm_33
	"Age of Empires", //gw_gm_0
	"Filtre d'adresses MAC", //_macfilt
	"Pour utiliser cette fonction, vous devez disposer d'un compte DNS dynamique auprès de lun des fournisseurs du menu déroulant.", //TA16
	"(compatibilité pour certains clients DHCP)", //bd_DAB_note
	"Sélectionnez les types d'événements que vous voulez afficher.", //help796
	"Voulez-vous vraiment reprogrammer le périphérique en utilisant le fichier de microprogramme ?", //tf_really_FWF
	"(GMT-07:00) Arizona", //up_tz_05
	"3:00 PM", //tt_time_16
	"Cette adresse email apparaîtra comme expéditeur quand vous recevrez un dossier journal ou la notification de mise à jour firmware par l'intermédiaire de l'email.", //help861
	"Sélectionnez le protocole utilisé par le service.", //help19
	"Mode WAN DHCP", //bwn_DWM
	"ICMP", //_ICMP
	"Half Life", //gw_gm_22
	"Envoyez le journal lorsqu'il est plein ou sur plage horaire.", //help868
	"Phrase de passe", //IPV6_TEXT24
	"5:00 AM", //tt_time_6
	"Cliquez sur ce bouton pour créer une nouvelle politique de contrôle d'accès.", //_501_12
	"Vérifiez <strong> Activez le contrôle d'accès </strong> si vous voulez imposer les règles qui limitent l'accès à Internet à des ordinateurs spécifiques du réseau local.", //hhac_en
	"Configuration manuelle", //int_LWlsWz
	"Sélectionnez la vitesse de transmission", //at_STR
	"Août", //tt_Aug
	"Activez le filtrage MAC et REFUSER aux ordinateurs listés d’accéder au réseau", //am_FM_4
	"Étape 5 - Choisir les filtres", //aa_wiz_s1_msg5
	"Contrôle d'accès", //ACCESS_CONTROL
	"Erreur pendant la mise à jour de l'entrée DNS dynamique %s. Vérifiez la configuration. Désactivation de DynDNS en cours.", //GW_DYNDNS_HERROR
	"Ports ouverts", //sps_ports
	"Si vous n'avez pas de serveur NTP actif, vous pouvez régler manuellement l’heure sur votre routeur, ou vous pouvez appuyer sur le bouton <span class='button_ref'> Copier les réglages horaires de votre ordinateur </span> pour copier l’heure à partir de l'ordinateur que vous utilisez. (Assurez-vous que l’horloge de l’ordinateur est réglé correctement.)", //help851
	"Vous pouvez choisir un ordinateur à partir de la liste des clients du serveur DHCP dans le menu déroulant <strong> Nom d'ordinateur</strong>, ou vous pouvez manuellement saisir l'adresse IP de l'ordinateur du réseau LAN auquel vous voudriez ouvrir le port indiqué.", //hhag_20
	"Cette règle de machine est déjà utilisée.", //aa_alert_7
	"Adresse IP de la zone DMZ", //af_DI
	"Site de téléchargement disponible", //tf_ADS
	"Test de ping", //tsc_pingt
	"Niveaux à afficher", //sl_VLevs
	"Cryptage", //wwl_enc
	"Une adresse MAC est une identification unique assignée par le fabricant de la carte réseau.", //help151
	"Choisissez un port pour ouvrir la gestion à distance.", //hhta_pt
	"Le contrôle d'accès à Internet a rejeté un paquet de %v:%u[%s] à %v:%u (protocole %u).", //GW_INET_ACCESS_DROP_ACCESS_CONTROL
	"Activer l'authentification", //te_EnAuth
	"Processus WPS STA avec MAC (%m) terminé", //WIFISC_AP_PROXY_PROCESS_CLOSE
	"Nom de l'ordinateur", //bd_CName
	"Il est recommandé d’employer les réglages par défaut si vous n'avez pas de réseau existant.", //help305rt
	"Mot de passe incorrect, veuillez réessayer.", //li_alert_3
	"Mise à jour d'une entrée DNS dynamique due à un dépassement de temps.", //GW_DYNDNS_UPDATE_TO
	"4ème", //tt_week_4
	"Jour", //tt_Day
	"Courant porteur Ethernet de réseau local perdu.", //GW_LAN_CARRIER_LOST
	"Chaque règle peut <strong>Autoriser</strong> ou <strong>Refuser</strong> l’accès au WAN.", //hhai_action
	"et comment le contrôle est réalisé. Vous pouvez configurer de multiples politiques. L’assistant des Politiques commence lorsque vous cliquez sur le bouton ci-dessous et également quand vous éditez une politique existante.", //help121
	"Pour configurer cette connexion, vous avez besoin d'un nom d'utilisateur et d'un mot de passe fournis par votre fournisseur d'accès Internet. Si vous ne possédez pas ces informations, contactez votre fournisseur d'accès Internet.", //wwa_msg_set_pppoe
	"Paquet ICMP entrant est bloqué (type d’ICMP %u) de %v à %v", //IPNAT_ICMP_BLOCKED_INGRESS_PACKET
	"pour augmenter fonctionnalité et performance.", //tf_intro_FWU2
	"Activez ou désactivez les règles définies avec les cases à cocher à gauche.", //at_ESE
	"Les services de sécurité représentent un formidable moyen de protection de tous vos PC grâce à une suite unifiée de services gérés à partir de n'importe quel navigateur Web. Ils comprennent un antivirus, un pare-feu, un détecteur d'intrusion, un filtre de contenus, un anti-spam et un outil de blocage des fenêtres &quot;pop-up&quot;. Vous pouvez choisir un ou plusieurs de ces services à un prix avantageux.", //_bsecure_security_blurb
	"Liste des Clients DHCP", //bd_DHCP
	"Entrez votre compte pour l'envoi du message électronique.", //help865
	"La clé WEP (Wired Equivalent Privacy) doit suivre l'une des directives suivantes:", //wwl_s4_intro_z1
	"Téléchargement", //help501
	"Le FAI fournit ce paramètre, si nécessaire. La valeur peut être identique que l’adresse IP de la passerelle.", //help280
	"Connexion DHCP", //help775
	"Connecter", //_connect
	"BigPond activé.", //GW_BIGPOND_INIT
	"Toujours", //_always
	"(minutes)", //_minutes
	"Port du firewall", //as_IPR_b
	"Emploi", //_aa_bsecure_employment
	"Le contrôle d'accès à Internet a rejeté un paquet erroné de %v à %v (protocole %u).", //GW_INET_ACCESS_DROP_BAD_PKT
	"Dark Reign 2", //gw_gm_12
	"Hexen II", //gw_gm_25
	"Choisissez le temps de début et de fin pour le changement d’heure. Par exemple, si pour la DST de début, vous sélectionnez Mois=’Oct’, Semaine= ‘Troisième’, Jour= ‘Dimanche’ et Heure =&quot;2am&quot;. Alors ‘L’heure d’hiver commence le troisième dimanche d'octobre à 2H du matin’.", //help846
	"Veuillez sélectionner soit le paramètre Automatique, soit le paramètre Manuel, mais pas les deux.", //tt_alert_1only
	"Gamespy Arcade", //gw_gm_76
	"Journal vu par l'adresse IP %v.", //GW_LOGS_VIEWED
	"Quand WPA-enterprise est activé, le routeur utilise EAP (802.1x) pour authentifier les clients par l'intermédiaire d'un serveur RADIUS externe.", //bws_msg_EAP
	"L'enregistreur WPS interne a démarré l'enregistrement de %s", //WIFISC_IR_REGISTRATION_INPROGRESS
	"C'est une liste de toutes les conversations actives entre les ordinateurs du WAN et les ordinateurs du LAN.", //hhsa_intro
	"Cette section vous permet d'archiver vos fichiers journaux sur un serveur Syslog.", //help856
	"Dir", //sa_Dir
	"Membres de Multidiffusion d'IGMP", //_bln_title_IGMPMemberships
	"L2TP(Nom d’utilisateur/Mot de passe)", //bwn_Mode_L2TP
	"Jeu", //_Thu
	"Non-concordance PIN (2e moitié) détectée", //KR30
	"Les balises sont des paquets envoyés par un routeur sans fil pour synchroniser les dispositifs sans fil. Indiquez une valeur d’Intervalle de balise entre 20 et 1000. La valeur par défaut est réglée à 100 millisecondes.", //help184
	"Choisissez l'option qui fonctionne le mieux pour votre installation.", //_worksbest
	"non disponible", //_unavailable
	"Le système de fichier détecté n'est pas compatible (FAT32, FAT16, FAT12)", //IPFAT_INCOMPATIBLE_FILESYS
	"Paquet TCP entrant bloqué de %v:%u à %v:%u car %s a été reçu mais il n’y a aucune connexion active", //IPNAT_TCP_BLOCKED_INGRESS_NOT_SYN
	"(GMT -08:00) Pacifique (USA/Canada), Tijuana ", //up_tz_04
	"Appliquer les paramètres du journal maintenant", //sl_ApplySt
	"Réclamation d'authentification CHAP reçue par le poste.", //IPPPPCHAP_CHALLENGE_RECVD
	"Cette section est celle où vous ajoutez les sites Web à employer pour le contrôle d'accès.", //help141
	"Annuler", //bd_Revoke
	"Étape 1 : Détectez l'imprimante.", //wprn_intro3
	"Durée d'activation de la connexion", //_conuptime
	"Vérifiez que l'imprimante est allumée.", //wprn_tt4
	"La technologie sans fil de gestion de réseau autorise une communication constante.", //help383
	"Aucune réponse au Ping du routeur, réessayera.", //tsc_pingt_msg6
	"Initié du LAN vers le WAN.", //help821a
	"Le protocole PPPoE a reçu une offre de session.", //PPPOE_EVENT_SESSION_OFFER_RECVD
	"Myth", //gw_gm_30
	"Si vous vous considérez comme un utilisateur avançé et avez configuré un routeur avant, veuillez appuyer sur <span class='button_ref'> Configuration Manuelle </span> pour réaliser tous les réglages manuellement.", //bi_man
	"Mixte (1020-5000, 689)", //help60
	"Port d’Admin à distance", //ta_RAP
	"BigPond (Australie)", //bwn_Mode_BigPond
	"L'état actuel de l'imprimante ne permettra pas d'imprimer la page de test au cours des étapes suivantes de la procédure.", //wprn_cps2
	"Début du DST", //tt_dststart
	"Quand le protocole est TCP, SPI vérifie que les numéros d’ordre des paquets sont dans la plage valide pour la session, jetant les paquets qui n'ont pas de numéro d'ordre valide.", //help164_1
	"Délai d'authentification MSCHAP dépassé - erreur d'authentification.", //IPMSCHAP_AUTH_TIMEOUT
	"Envoyer par courrier électronique maintenant", //sl_emailLog
	"Réglages du réseau sans fil", //bwl_title_1
	"Mot de passe BigPond", //bwn_BPP
	"Actualiser", //sl_reload
	"Étape 1 : Nommer votre réseau sans fil", //wwl_title_s1
	"Échec du montage du lecteur", //IPDRIVE_MOUNT_FAILED
	"Assistant de configuration de connexion à Internet", //int_ConWz
	"Permission", //sto_permi
	"L'option <code>Annuler</code> est disponible si la table de location devient pleine ou presque pleine, et que vous deviez récupérer de l'espace dans cette table pour de nouvelles entrées, sachant que certaines des assignations actuelles ne sont plus nécessaires. Appuyez sur <code>Révoquer </code> annule le bail pour un dispositif spécifique du réseau local et libère une entrée dans le tableau de location. Faites ceci seulement si le dispositif n'a plus besoin de l’adresse IP louée, par exemple, s’il n’existe plus sur le réseau.", //help329
	"Le tunnel local L2TP 0x%04X a été déconnecté.", //IPL2TP_TUNNEL_DISCONNECTED
	"Filtre entrant d’Admin à distance", //help830
	"L’Unité de transmission maximum(MTU) est un paramètre qui détermine la taille maximum des paquets (en octets) que le routeur enverra au WAN. Si les machines du LAN envoient de plus grands paquets, le routeur les fragmentera en plus petits paquets. Idéalement, vous devriez appliquer la valeur utilisée par votre FAI. Les valeurs typiques sont 1500 octets pour une connexion Ethernet et 1492 octets pour une connexion PPPoE. Si la MTU du routeur est réglée trop haute, des paquets seront fragmentés dans le sens descendant. Si elle est réglée trop basse, le routeur fragmentera des paquets inutilement et voir même ne pourra pas établir certaines connexions. Dans tous les cas, la performance de réseau peut en souffrir.", //help294
	"(GMT-02:00) Atlantique centrale", //up_tz_21
	"Date du dernier firmware", //tf_LFWD
	"BigPond connecté, état = %d, réponse du serveur = %s.", //GW_BIGPOND_SUCCESS
	"Tout refuser", //_denyall
	"Classification automatique", //at_AC
	"Statuts de visibilité", //bwl_VS
	"Dans cette section vous pouvez voir quels dispositifs du LAN louent actuellement des adresses IP dynamiques.", //help327
	"Pour terminer la procédure de configuration, l'assistant va à présent lancer un fichier exécutable sur votre ordinateur.", //wprn_s2a
	"(heures)", //td_
	"Le concentrateur d'accès PPTP distant tarde à répondre. Il est possible qu'il y ait des problèmes de connectivité.", //PPTP_EVENT_TUNNEL_WINDOW_TIMEOUT
	"Puissance de transmission", //aw_TP
	"Type de connexion Internet : adresse IP statique", //bwn_SIAICT
	"Certaines applications, par exemple les jeux en ligne, la vidéo conférence et la téléphonie par Internet, requièrent plusieurs connexions. Ces applications fonctionnent difficilement via la traduction d'adresses de réseau (NAT). Dans cette section, vous pouvez configurer l'ouverture de plusieurs ports ou d'une plage de ports du routeur, ainsi que la redirection des données via ces ports vers un PC du réseau. Vous pouvez entrer les ports dans divers formats", //help57
	"Activez l’Heure d’été/d’hiver", //tt_dsen2
	"Déconnexion en cours, veuillez patienter...", //_sdi_s5
	"Fabricant", //wprn_man
	"2:00 AM", //tt_time_3
	"(GMT-03:00) Groenland", //up_tz_20
	"RIP a rejeté la route %v du routeur distant %v du fait de  ressources système insuffisantes", //RIP_LOW_RESOURCES
	"Nom du service", //help266
	"Connecté", //CONNECTED
	"Si votre FAI a assigné une adresse IP fixe, choisissez cette option. Le FAI fournit les valeurs pour les champs suivants :", //help265_5
	"Jour(s)", //tsc_Days
	"(GMT-05:00) Indiana (Est)", //up_tz_13
	"Général", //sd_General
	"UPnP aide les autres produits UpnP du LAN à interopérer avec le routeur. Laissez l’option UPnP validée tant que des applications UpnP existent sur le LAN.", //hhan_upnp
	"Vérifiez si votre client VPN prend en charge la traversée NAT avec l'administrateur système de votre réseau d'entreprise.", //help35
	"L'adresse IP du système présent sur votre réseau interne et qui fournit le service virtuel (par ex. <code>192.168.0.50</code>).", //help18
	"Assistant d'installation de l'imprimante", //bwz_psw
	"Date et heure", //tt_DaT
	"Des planifications peuvent être créées pour un usage en fonction de règles. Par exemple, si vous voulez limiter l'accès du Web à Lundi-Vendredi de 15h à 20h, vous pouvez créer une plage horaire choisissant lundi, mardi, mercredi, jeudi et vendredi et un horaire commencant à 3pm et finissant à 8pm.", //help190
	"SYN envoyé -- Un des systèmes essaie de commencer une connexion.", //help819_2
	"Temps mort maximal", //bwn_MIT
	"Donnez à chaque règle un <strong>Nom</strong>signicatif pour vous.", //hhai_name
	"Envoyez le journal lorsqu'il est plein ou sur plage horaire", //te__title_EmLog
	"(GMT+05:30) Calcutta, Chennai, Mumbai, New Delhi", //up_tz_47
	"Échec SMTP pendant le dialogue expéditeur/destinataire", //IPSMTPCLIENT_DIALOG_FAILED
	"Appuyez sur le bouton <strong>Effacer</strong> pour enlever l’ adresse MAC de la liste du filtrage MAC.", //hham_del
	"Si votre fournisseur d'accès Internet n'est pas énuméré ou vous ne savez pas qui c'est, veuillez choisir le type de connexion Internet ci-dessous :", //wwa_msg_ispnot
	"Le nombre des paquets abandonnés au lieu d’être envoyés, dû aux erreurs, aux collisions, ou aux limitations de ressource du routeur.", //help808
	"Tentative d'établissement d'une connexion PPTP.", //PPTP_EVENT_TUNNEL_ESTABLISH_REQUEST
	"Prend en charge l'utilisation de Microsoft Windows Messenger (le client de messagerie Internet livré avec Microsoft Windows) et de MSN Messenger sur les ordinateurs du réseau local. L'ALG SIP doit également être activé lorsque l'ALG Windows Messenger est activé.", //help37
	"Réinitialisation demandée pour WCN", //WCN_LOG_REBOOT
	"Échec de tentative de connexion PPTP. Vérifiez les paramètres du serveur PPTP distant.", //PPTP_EVENT_TUNNEL_CONNECT_FAIL
	"Largeur de canal", //bwl_CWM
	"(GMT-05:00) Heure de l'Est (États-Unis/Canada)", //up_tz_12
	"Annuler", //_cancel
	"Activer ULA", //IPV6_ULA_TEXT02
	"Activez le DMZ", //af_ED
	"(GMT+03:00) Koweït, Riyad", //up_tz_38
	"Intervalle DTIM", //aw_DI
	"(GMT+02:00) Athènes, Istanbul, Minsk", //up_tz_31
	"Appuyez sur l'icône <strong>Supprimer</strong> dans la liste des règles pour supprimer une règle.", //hhai_delete
	"L'option de Serveur Virtuel vous permet de définir un unique port public sur votre routeur et de le réorienter vers une adresse IP interne du LAN et un port privé du LAN si nécessaire. Ce dispositif est utile pour héberger des services en ligne tels que des serveurs FTP ou Web.", //av_intro_vs
	"La section des règles du pare-feu affiche une fonction avancée servant à refuser ou autoriser le passage du trafic par le périphérique. Elles fonctionnent de la même façon que les filtres IP avec des paramètres supplémentaires. Vous pouvez créer plus de règles détaillées pour le périphérique.", //av_intro_if
	"Tentative de reconnexion d'une connexion de réseau étendu permanente.", //GW_WAN_RECONNECT_ALWAYS_ON
	"Mot de passe sans fil de sécurité", //wwl_WSP
	"En", //INGRESS
	"Limité", //RESTRICTED
	"Employez ce type de connexion à Internet si votre Fournisseur d’Accès à Internet (FAI) ne vous fourni pas d’information sur l’adresse IP et/ou un nom d’utilisateur et un mot de passe.", //bwn_msg_DHCPDesc
	"Numéro de port utilisé pour se connecter au serveur d'authentification.", //help390
	"L'activation de l'isolation L2 (Layer 2) évite que des clients sans fil associés ne communiquent entre eux.", //KR58
	"Confirmez le mot de passe associé à ce compte.", //help867
	"Tentative de démarrage d'une connexion de réseau étendu permanente.", //GW_WAN_CONNECT_ALWAYS_ON
	"L’ALG RTSP a rejeté le paquet de %v:%u à %v:%u avec le port RTP impair %u", //IPRTSPALG_REJECTED_ODD_RTP_PACKET
	"Champs de réacheminement de port", //help60f
	"Counter Strike", //gw_gm_10
	"(minutes, 0=infini)", //bwn_min
	"Mois", //tt_Month
	"Date du microprogramme actuel", //tf_CFWD
	"Réseau Avançé", //_advnetwork
	"Type de connexion Internet : PPPOE", //bwn_PPPOEICT
	"Port du serveur RADIUS:", //help389
	"Choisissez le temps de décalage, si vous devez régler l’heure d’été/d’hiver.", //help844
	"4:00 PM", //tt_time_17
	"L2TP (Layer Two Tunneling Protocol) utilise un réseau privé virtuel pour se connecter à votre FAI. Cette méthode de connexion nécessite de saisir un <span class='option'> Nom d’utilisateur </span> et <span class='option'> Mot de passe </span> (fourni par votre FAI) pour accéder à Internet.", //help284
	"Système sans fil avec adresse MAC %m associée.", //GW_WIRELESS_DEVICE_ASSOCIATED
	"Authentification de l’adresse MAC secondaire", //bws_2RMAA
	"SIP", //as_SIP
	"SysLog", //help704
	"L'enregistreur interne WPS n'a pu rajouter le nouveau client, raison %s", //WIFISC_IR_REGISTRATION_FAIL_1
	"(GMT) Heure de Greenwich : Dublin, Édimbourg, Lisbonne, Londres", //up_tz_25
	"Dans l'exemple de règle d'application activée ci-dessus, le routeur ouvre une plage de ports entre 6000 et 6200 pour le trafic entrant depuis Internet lorsqu'un ordinateur du réseau interne ouvre une application qui envoie des données sur Internet à l'aide d'un port situé dans la plage de 6500 à 6700.", //help55
	"Liaison sans fil en service.", //GW_WLAN_LINK_UP
	"Activez le relais DNS", //bln_EnDNSRelay
	"Règle de filtre entrant", //ai_title_IFR
	"PPTP", //_PPTP
	"Les deux", //_both
	"(GMT+03:00) Nairobi", //up_tz_40
	"Débranchez puis rebranchez le câble USB de l'imprimante.", //wprn_tt8
	"Désactiver le Redémarrage à chaud", //tps_dsr
	"Autres", //at_Prot_1
	"Redémarrage du routeur. C’est utile pour le redémarer quand vous n'êtes pas près du produit.", //help875
	"Paramètres de Filtre de site Web", //awsf_p
	"5 ou 13 caractères alphanumériques exactement.", //wwl_s4_intro_z2
	"Pour établir cette connexion, vous devrez avoir un nom d’utilisateur et un mot de passe de votre Fournisseur d’accès Internet. Vous avez besoin également de l’adresse IP L2TP. Si vous n'avez pas cette information, entrez en contact avec votre FAI.", //wwa_set_l2tp_msg
	"(GMT+04:00) Abou Dabi, Muscat", //up_tz_42
	"Erreur", //_error
	"IP de destination<br />Fin", //aa_FPR_c4
	"Activez le Serveur NTP", //tt_EnNTP
	"Adresse IP incorrecte, elle est dans la plage du serveur DHCP", //network_dhcp_ip_in_server
	"Pour mettre à jour le firmware, votre PC doit avoir une connexion filaire au routeur. Saisissez le nom du fichier de mise à jour du firmware, et appuyez sur le bouton de téléchargement.", //tf_msg_wired
	"Définir un nom d''utilisateur et un mot de passe de connexion (PPPoE)", //wwa_title_set_pppoe
	"Assurez-vous que la plage horaire est<code>Toujours </code>", //help10
	"Les autres options sont disponibles pour des circonstances spéciales.", //bwl_CWM_h2
	"Vérifier en ligne", //help884
	"Réinitialisation", //rb_Rebooting
	"Time Wait – Attendre pendant une courte période qu'une connexion en état FIN Wait soit entièrement fermée.", //help819_6
	"9:00 AM", //tt_time_10
	"Cette section montre les règles de plage horaire actuellement définies. Une règle peut être changée en cliquant sur l'icône Editer, ou être supprimée en cliquant sur l'icône Supprimer. Quand vous cliquez sur l'icône Editer, l'article est surlignée, et la section &quot;Editer la règle de planification&quot; est activée pour l'édition.", //help199
	"Méthode de connexion dans laquelle votre FAI vous attribue une adresse IP quand le routeur en fait la demande au serveur du FAI. Certains FAI vous demandent de configurer quelques paramètres de votre côté pour que votre routeur puisse se connecter à Internet.", //help259
	"Configuration de la passerelle de niveau application (ALG)", //af_algconfig
	"Client PPTP.", //wwa_msg_pptp
	"Adresse IP du serveur RADIUS secondaire", //bws_2RIPA
	"Étape 3 : Sélectionnez l'ordinateur", //_aa_wiz_s4_title
	"Remarque : Vous devrez également fournir un nom de service. Si vous ne l'avez pas ou ne le connaissez pas, entrez en contact avec votre FAI.", //wwa_note_svcn
	"Réseau xDLS ou réseau à relais de trame détecté", //help85
	"Le filtre de contrôle d'accès des ports à bloqué les paquets de %v:%u à %v:%u (protocole %u)", //GW_INET_ACCESS_DROP_PORT_FILTER_WITH_PORT
	"Statut du BigPond", //sd_BPSt
	"(GMT+06:00) Almaty", //up_tz_49
	"World of Warcraft", //gw_gm_62
	"BigPond déconnecté.", //BIGPOND_LOGGED_OUT
	"Notification par courrier électronique d'une nouvelle version de microprogramme", //tf_EmNew
	"La politique d'accès à Internet pour l'adresse MAC %m ne peut pas être configurée", //GW_INET_ACCESS_INITIAL_MAC_FAIL
	"Adresse MAC", //help303
	"Non listé ou Ne sais pas", //wwa_selectisp_not
	"Paquet TCP sortant bloqué de %v:%u à %v:%u avec accusé de réception inattendu %lu (%lu à %lu prévu)", //IPNAT_TCP_BLOCKED_EGRESS_BAD_ACK
	"La règle s'applique au flux des messages dont le numéro de port du réseau local est dans la plage déterminée ici.", //help94
	"Xbox Live", //gw_gm_70
	"Paquet ICMP rejeté de %v à %v car impossible de traiter l'en-tête de paquet.", //IPNAT_ICMP_UNABLE_TO_HANDLE_HEADER
	"FTP", //_FTP
	"Filtrage De Point limite NAT", //_neft
	"Administration", //ta_A12n
	"BigPond déconnecté.", //GW_BIGPOND_LOGOUT
	"Une règle d'application permet d'ouvrir un ou plusieurs ports de votre routeur lorsque celui-ci détecte des données envoyées vers Internet sur un port ou une plage de ports de \"déclenchement\". Une règle d'application s'applique à tous les ordinateurs de votre réseau interne.", //help46
	"Contrôlez régulièrement le journal pour détecter toute utilisation non autorisée du réseau.", //hhsl_intro
	"Aide - Outils", //help770
	"Pour configurer cette connexion, vous avez besoin d'un nom d'utilisateur et d'un mot de passe fournis par votre fournisseur d'accès Internet. Vous avez également besoin d'une adresse IP PPTP. Si vous ne possédez pas ces informations, contactez votre fourn", //wwa_msg_set_pptp
	"Impossible de détecter l'enregistrement DNS pour le serveur de mise à niveau du microprogramme %s.", //GW_FW_NOTIFY_FAILED_DNS
	"Rainbow Six: Raven Shield", //gw_gm_40
	"Le routeur emploie le protocole IGMP pour supporter la multidiffusion ou la transmission de contenu identique, tel que le multimédia, d'une source à un certain nombre de destinataires.", //bln_IGMP_title_h
	"Employez <strong> 802.11d </strong> seulement pour des pays où on l'exige.", //hhaw_11d
	"Sinon, appuyez sur le bouton ‘Annuler’ et puis appuyez sur le bouton ‘Sauvegarder les réglages’.", //up_jt_2
	"La stratégie %s est démarrée ; l'accès à Internet pour l'adresse MAC %m devient : %s", //GW_INET_ACCESS_POLICY_START_MAC
	"Choisissez cette option si votre connexion Internet requiert un nom d'utilisateur et un mot de passe. La plupart des modems DSL utilisent ce type de connexion.", //wwa_msg_pppoe
	"Supposez que vous configurez le serveur DHCP sur la plage d’adresses 192.168.0.100 - 192.168.0.199. Ceci signifie que 192.168.0.3 à 192.168.0.99 et 192.168.0.200 à 192.168.0.254 ne sont pas contrôlées par le serveur DHCP. Des ordinateurs ou des dispositifs avec des adresses dans ces plages doivent être configurés manuellement. Supposez que vous avez un serveur web qui a une adresse manuellement configurée de 192.168.0.100. Puisque cette adresse IP est dans ‘la plage contrôlée’ faites une réservation pour cette adresse et activez la(voir ci-dessous <a href='#Static_DHCP'>Static DHCP Client</a>)", //help323
	"Les comptes Admin peuvent accéder à l'interface de gestion. L'administrateur possède un accès en lecture et en écriture et peut changer les mots de passe.", //ta_intro1
	"3ème", //tt_week_3
	"Serveur DHCP", //_dhcpsrv
	"IP dynamique", //Dynamic_PPPoE
	"Activer :", //help102
	"WINS/NetBIOS peu ne pas fonctionner dans ce mode de connexion Internet.", //GW_DHCP_SERVER_WINS_MODE_INVALID
	"Un bit dans le masque spécifie quels bits de l'adresse IP doivent concorder.", //help107
	"Serveurs WON", //gw_gm_69
	"Filtrage", //aa_ACR_c5
	"Vous pouvez donner un nom à chaque ordinateur possédant une adresse IP réservée. Ceci peut vous aider à conserver la trace des ordinateurs dont l'adresse IP a été attribuée de cette façon.", //help345
	"Examiner le menu déroulant <strong>Nom d’application</strong> pour lister les types de serveurs prédéfinis. Si vous choisissez un des types de serveurs prédéfinis, appuyez sur le bouton à côté du menu déroulant pour compléter le champ correspondant.", //hhav_name
	"Port privé", //av_PriP
	"% perdu", //tsc_pingt_msg103
	"Si vous devez employer la fonctionnalité d'UPnP, vous pouvez l'activer ici.", //help_upnp_2
	"Mode de connectivité de réseau étendu incorrect.", //WAN_MODE_INCORRECT
	"Le mot de passe WEP doit être de 5 caractères alphanumériques exactement.", //wwl_alert_pv5_2_5
	"Étape 4 : Sélectionnez la méthode de filtrage", //_aa_wiz_s5_title
	"Code PIN incorrect.", //KR22_ww
	"Indiquez les règles pour interdire l'accès à des adresses IP et des ports spécifiques.", //_aa_wiz_s7_help
	"Le serveur de session L2TP s'est arrêté en envoyant des nombres séquentiels pour la session locale 0x%04X.", //IPL2TP_SEQUENCING_DEACTIVATED
	"Configuration avancée de l'imprimante", //tps_apc
	"(GMT-06:00) Mexico", //up_tz_09
	"Juil", //tt_Jul
	"L'interface de réseau étendu est hors service.", //GW_WAN_INTERFACE_DOWN
	"Restaurer les paramètres sans fil", //WCN_LOG_RESTORE
	"Everquest", //gw_gm_17
	"Accès Internet pour l'adresse IP %v configuré sur %s", //GW_INET_ACCESS_INITIAL_IP
	"Voulez-vous annuler tous les changements apportés à cet assistant ?", //_wizquit
	"La section Paramètres système permet de redémarrer le périphérique ou de restaurer les paramètres par défaut d'usine. La restauration des paramètres par défaut efface tous vos paramètres, y compris toutes les règles que vous avez créées.", //tss_intro
	"Lorsque vous réglez <span class='option'> Activez le serveur DHCP </span>, les options suivantes apparaissent.", //help318
	"Les options SysLog vous permettent d'envoyer l'information du journal sur un serveur SysLog.", //tsl_intro
	"3:00 AM", //tt_time_4
	"8:00 PM", //tt_time_21
	"Session locale L2TP 0x%04X connectée.", //IPL2TP_SESSION_CONNECTED
	"Seuil de fragmentation", //aw_FT
	"Enregistrer", //_save
	"Non estimés", //at_NEst
	"Lorsquune application côté LAN a créé une connexion via un port spécifique, la NAT transmet toutes les demandes de connexions entrantes avec le même port vers lapplication côté LAN, quelle que soit leur origine. Cest loption la moins restrictive, qui donne la meilleure connectivité et autorise certaines applications (les applications P2P en particulier) à fonctionner pratiquement comme étant directement connectées à Internet.", //af_EFT_h0
	"MICROPROGRAMME", //_firmware
	"Rogue Spear", //gw_gm_43
	"Lancez WPS sur le périphérique sans fil que vous êtes en train d'ajouter sur votre réseau sans fil dans les", //wps_messgae1_1
	"Le module RTE 0x%04X du tunnel local L2TP est en cours de fermeture.", //IPL2TP_SHUTDOWN_STARTED
	"Paquets TX abandonnés", //ss_TXPD
	"(GMT+08:00) Pékin, Chongqing, Hong Kong, Urumqi", //up_tz_55
	"Cliquez sur Suivant si vous voulez toujours sécuriser le routeur avec un mot de passe et définir le fuseau horaire.", //wwa_intro_online2
	"Sélectionnez le protocole sortant utilisé par votre application (par ex. <code>Les deux</code>).", //help50
	"Entrez les ports UDP à ouvrir (par ex. <code>6159-6180, 99</code>).", //help70
	"L'activation de WMM peut aider au contrôle de la latence et de la gigue lorsque vous transmettez du contenu multimédia par l'intermédiaire d'une connexion sans fil.", //help188_wmm
	"Réservation DHCP", //bd_title_SDC
	"(GMT+09:00) Osaka, Sapporo, Tokyo", //up_tz_60
	"Ultima", //gw_gm_54
	"Serveur RADIUS de secours facultatif", //help396
	"Déconnexion de l'administrateur", //GW_ADMIN_LOGOUT
	"Serious Sam II", //gw_gm_44
	"Activer UPnP", //ta_EUPNP
	"Cette option doit être activée si des applications sur le réseau local participent à un groupe de multidiffusion. Si vous avez sur le LAN une application de multimédia qui ne reçoit pas le contenu comme prévu,veuillez activer cette option.", //igmp_e_h
	"Nombre de paquets transmis par le routeur.", //help806
	"REFUSER l'accés à ces sites UNIQUEMENT", //dlink_wf_op_0
	"Saisissez la plage de ports sortants utilisée par votre application (par ex. <code>6500-6700</code>).", //help49
	"Exemple:", //help367
	"Liens", //gw_gm_28
	"Windows Me", //help337
	"Paramètres d'administrateur", //ta_AdmSt
	"SysLog", //_syslog
	"(GMT-06:00) Heure du Centre (États-Unis/Canada)", //up_tz_08
	"Si ceci est choisi, l'utilisateur doit se connecter à partir du même ordinateur quand il ouvre une session dans le réseau sans fil.", //help394
	"Étape 5:  Filtre de Port", //_aa_wiz_s7_title
	"L'option Configuration de l'heure vous permet de configurer, de mettre à jour et de gérer l'heure de l'horloge interne du système. Cette section vous permet également de définir le fuseau horaire ainsi que le serveur NTP (protocole horaire en réseau). Vous pouvez également configurer l'heure d'été pour que le changement s'effectue quand cela est nécessaire.", //tt_intro_Time
	"Erreur de mise à jour de l’entrée DNS: %s.  Réessayera plus tard", //GW_DYNDNS_SERROR
	"Activer l'affectation automatique d'adresse IPv6", //IPV6_TEXT105
	"Port", //sps_port
	"Que le SPI soit validé ou non, le routeur contrôle toujours l’état des connexions TCP et s'assure que les drapeaux de chaque paquet TCP sont valides pour l'état correspondant.", //help164_2
	"Patientez jusqu'à la réinitialisation du routeur. Celle-ci peut également durer quelques minutes.", //help881
	"IP de destination", //_destip
	"L'option Configuration du Temps vous permet de configurer, mettre à jour, et de garder la bonne heure sur l'horloge interne du routeur. A partir de cette section vous pouvez régler votre fuseau horaire et l’heure système. L'heure d’été/d’hiver peut également être configurée pour basculer  automatiquement l’heure.", //help840
	"Adresse IP du serveur L2TP (peut être identique à celle de la passerelle)", //wwa_l2tp_svra
	"Dates de changement d'heure", //tt_dsdates
	"Notez que les connexions VPN L2TP utilisent typiquement l’IPSec pour protéger le lien. Pour permettre de multiples VPN à travers NAT il est nécessaire d’activer l’ALG IPSec.", //help34b
	"10:00 AM", //tt_time_11
	"Activer DNS Dynamique", //td_EnDDNS
	"Vitesse de transmission réelle du client en mégabits par seconde.", //help786
	"Nom d'utilisateur", //bwn_UN
	"Ce nom de stratégie est déjà utilisé.", //aa_alert_8
	"Activer le moteur QoS", //wprn_tt2
	"Le protocole LCP définit l'authentification à distance : %04x", //IPPPPLCP_SET_REMOTE_AUTH
	"Dépassement du délai d'attente du module RTE 0x%04X du tunnel local L2TP ; le serveur distant ne répond pas.", //IPL2TP_FATAL_TIMEOUT
	"<strong>Sessions LAN non UDP/TCP/ICMP </strong> est normalement permis. Il facilite les connexions VPN simples pour un ordinateur hôte distant.", //hhaf_ngss
	"Réglages de réseau", //bln_title_NetSt
	"Type de trafic", //av_traftype
	"PPTP (Nom d’utilisateur/Mot de passe)", //bwn_Mode_PPTP
	"Cette section montre les politiques de contrôle d'accès existantes. Une politique peut être changée en cliquant sur l'icône Editer, ou être supprimée en cliquant sur l'icône Supprimer. Cliquez sur l'icône Editer, et l’assistant des Politiques commence et vous guide par l’intermédiaire du processus de changement d’une politique. Vous pouvez activer ou désactiver des politiques spécifiques présentes dans la liste en cliquant sur le bouton &quot;Activer&quot;.", //help140
	"Un protocole d'impression nécessaire est désactivé.", //wprn_rppd
	"Tous vos détails de connexion WAN et LAN sont montrés ici.", //hhsd_intro
	"Authentification MSCHAP réussi.", //IPMSCHAP_AUTH_SUCCESS
	"Supposez que vous hébergez un serveur de jeux en ligne fonctionnant sur PC et dont l'adresse IP privée est 192.168.0.50. Ce jeu nécessite que vous ouvriez plusieurs ports (6159-6180, 99) sur le routeur afin que les utilisateurs Internet puissent se connecter.", //help63
	"Branchez une extrémité du câble Ethernet joint au routeur dans le port étiqueté INTERNET à l'arrière du routeur. Branchez l’autre extrémité de ce câble au port Ethernet de votre modem.", //ES_cable_lost_desc
	"Les nouveaux paramètres ont été appliqués.", //ap_intro_sv
	"Masque du sous-réseau L2TP", //_L2TPsubnet
	"Envoi d’un e-mail de connexion avant réinitialisation", //GW_LOG_EMAIL_BEFORE_REBOOT
	"Peu importe", //at_Any
	"Les options suivantes s'appliquent à tous les modes WAN.", //help288
	"À moins qu'un de ces modes de chiffrement soit choisi, des transmissions sans fil vers et à partir de votre réseau sans fil peuvent être facilement interceptées et interprétées par des utilisateurs non autorisés.", //bws_SM_h1
	"En plus des filtres listés ici, deux filtres prédéfinis sont disponibles partout où des filtres entrants peuvent être appliqués :", //help177
	"(GMT+05:00) Islamabad, Karachi, Tachkent", //up_tz_46
	"Veuillez patienter <span id ='show_sec'></span>&nbsp;secondes.", //rb_wait
	"Nom du réseau sans fil", //bwl_NN
	"Échec de la tentative de connexion de la session locale L2TP 0x%04X.", //IPL2TP_SESSION_CONNECT_FAIL
	"Final Fantasy XI (PS2)", //gw_gm_21
	"Sécurité haute", //wwl_BEST
	"Assistance", //_support
	"Vous ne pouvez pas ajouter de nouvelles adresses IP. Vous ne pouvez que réutiliser des adresses IP des autres politiques.", //aa_alert_14
	"Statut du câble", //_cablestate
	"DHCP est le protocole de configuration dynamique d’Hôte. La section DHCP vous permet de configurez le serveur DHCP intégré pour assigner des adresses IP aux ordinateurs et aux autres dispositifs sur votre réseau local (LAN).", //help314
	"Ajout de produit sans fil avec l'utilitaire WPS (WI-FI PROTECTED SETUP)", //wps_LW13
	"Critique", //sl_Critical
	"Les nouveaux réglages ont été sauvegardés.", //sc_intro_sv
	"JOURNAL système inactif.", //SYSTEM_LOG_INACTIVE
	"Ma connexion Internet est", //bwn_mici
	"Minutes", //gw_mins
	"Si pour une quelconque raison le routeur n'était plus alimenté, son horloge arrêterait de fonctionner et sa date et son heure ne seraient plus correctement réglées lors de sa remise sous tension. Pour maintenir la date et l'heure à jour pour les calendriers et les journaux, procédez au réglage de la date et de l'heure après le redémarrage du routeur ou activez l'option Serveur NTP.", //help852
	"En", //_In
	"Sélectionnez cette option si vous voulez que le journal soit envoyé par courrier électronique selon un calendrier.", //help870
	"Zone de jeu MSN (DX)", //gw_gm_74
	"Pare-feu et sécurité", //help797
	"Rainbow Six", //gw_gm_39
	"La clé WEP doit être exactement de 10 caractères hexadécimaux (0 à 9 ou A à F).", //wwl_alert_pv5_3_10
	"La section filtre d’adresses MAC peut être employée pour filtrer l'accès réseau par machine en fonction de l’adresse MAC unique de leur carte réseau.", //help149
	"Employez ce dispositif si vous essayez d'exécuter une des applications réseau listées et et qu’elle ne communique pas comme prévu.", //hhpt_intro
	"Le câble WAN a été branché", //GW_WAN_CARRIER_DETECTED
	"Nom d'utilisateur BigPond", //bwn_BPU
	"Sélectionnez cette option si vous voulez que ce calendrier soit effectif toute la journée des jours sélectionnés.", //help195
	"La valeur initiale d'Expiration du délai dépend du type de connexion et de son état.", //help823_1
	"Connexion à Internet", //_internetc
	"Résolu à", //tsc_pingt_msg5
	"Entrez une adresse MAC pour chacun des autres points daccès à connecter avec WDS.", //help189a
	"Déclenchement", //_trigger
	"ID Ethernet (adresse MAC) du client sans fil.", //help783
	"La passerelle ne sera pas reprogrammée.", //ub_intro_2
	"Pour des raisons de sécurité, Il est recommandé que vous changiez le mot de passe pour les comptes Admin. Assurez-vous que vous avez noté le nouveau mot de passe pour éviter de réinitialiser le routeur au cas où il serait oublié.", //hhta_pw
	"Étape 6: Configure le contrôle d’accès Web", //_aa_wiz_s8_title
	"La règle peut autoriser ou refuser les messages.", //help173
	"Aide - État", //help771
	"Adresse IP du serveur SysLog", //tsl_SLSIPA
	"Ajoutez les Règles de Filtres de Ports.", //_aa_wiz_s7_msg
	"12:00 PM", //tt_time_13
	"(GMT+10:00) Guam, Port Moresby", //up_tz_67
	"Serveur DNS primaire,Serveur DNS secondaire", //help289a
	"BigPond connecté", //BIGPOND_LOGGED_IN
	"Quand un hôte du réseau local est configuré comme un hôte DMZ, il devient la destination pour tous les paquets entrants qui ne correspondent pas à d’autres sessions ou règles entrantes. Si n'importe quelle autre règle d'entrée existe, elle sera employée au lieu d’envoyer les paquets sur l’hôte DMZ; ainsi, une session active, un Serveur Virtuel, un port de déclenchement actif, ou une règle de réacheminement de port auront la priorité sur l’hôte DMZ. (La politique de DMZ ressemble à une règle de réacheminement de port par défaut qui réachemine chaque port qui n'est pas spécifiquement envoyé à un aure endroit )", //haf_dmz_10
	"État des sessions utilisant le protocole TCP.", //help819
	"Si la barre de progression n'apparait pas, l'exécutable d’installation n'a pas été lancé et l'installation n'est pas encore terminée. Référez-vous à la section de dépannage ci-dessous.", //wprn_s3b
	"Port TCP", //sps_tcpport
	"Configurer le filtre site Web ci-dessous", //dlink_wf_intro
	"Filtre de site Web", //_websfilter
	"Nom du Serveur BigPond", //sd_BPSN
	"Mot de passe d'utilisateur", //_password_user
	"La stratégie %s est arrêtée ; l'accès à Internet pour l'adresse IP %v devient : %s", //GW_INET_ACCESS_POLICY_END_IP
	"Choisissez le mode à utiliser par le routeur pour se connecter à Internet.", //bwn_msg_Modes
	"L'adresse IP ' + mf.dmz_address.value + ' n'est pas valide.", //up_gX_1
	"Suivant", //_next
	"Configuration", //_setup
	"L’hôte reçoie des ping jusqu’à ce que vous appuyiez sur ce bouton.", //htsc_pingt_s
	"Courrier électronique", //EMAIL
	"Mode", //_mode
	"Fév", //tt_Feb
	"Utilisez cette information pour configurer votre ordinateur pour des impressions port TCP raw.", //sps_raw1
	"Entrée DNS dynamique mise à jour avec succès pour %s.", //GW_DYNDNS_SUCCESS
	"La passerelle ALG de redirection de port n'a pas pu allouer de session au paquet TCP de %v:%u à %v:%u", //IPPORTFORWARDALG_TCP_PACKET_ALLOC_FAILURE
	"Le routeur IGMP a rejeté le groupe %v par manque de ressources système", //IGMP_ROUTER_LOW_RESOURCES
	"L'option &quot;Auto 20/40 MHz&quot; est habituellement la meilleure.", //bwl_CWM_h1
	"(GMT+04:00) Moscou, St Petersburg, Volgograd", //up_tz_39
	"Permet aux périphériques et applications utilisant la voix sur IP de communiquer via la NAT. Certains d'entre eux peuvent détecter les périphériques NAT et travailler autour d'eux. Cette ALG peut interférer avec leur fonctionnement. Si vous avez des difficultés à passer des appels par voix sur IP, tentez de la désactiver.", //help40
	"Redirection de port", //_pf
	"Paquet UDP rejeté de %v à %v car impossible de traiter l'en-tête de paquet.", //IPNAT_UDP_UNABLE_TO_HANDLE_HEADER
	"<warn>Passerelle IP de Route %v identique à l'adresse de l'interface prévue et va être dévalidée.</warn>", //GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS_WARNING
	"L'accès à Internet pour l'adresse MAC %m est configuré sur %s", //GW_INET_ACCESS_INITIAL_MAC
	"Authentification CHAP réussie.", //IPPPPCHAP_AUTH_SUCCESS
	"Normalement l'émetteur sans fil fonctionne 100% de puissance. Dans certaines circonstances, cependant, il peut être nécessaire d’isoler des fréquences spécifiques dans un plus petit secteur. En réduisant la puissance de la radio, vous pouvez empêcher des transmissions d’aller au delà de la limite de votre bureau /maison ou du secteur sans fil indiqué.", //help187
	"Bloquer tous les accès", //_aa_block_all
	"Liaison sans fil hors service.", //GW_WLAN_LINK_DOWN
	"La durée avant que la clé du groupe utilisée pour la diffusion des données de multidiffusion soit changée.", //help379
	"(GMT+11:00) Îles Salomon, Nouvelle-Calédonie", //up_tz_70
	"Message d'erreur ICMP entrant bloqué (type d' ICMP %u) de %v à %v comme il n'y a aucune session d’ICMP active entre %v et %v", //IPNAT_ICMP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"Programmation", //GW_SCHEDULES_IN_USE_INVALID_s1
	"Cette page ne figure pas dans la liste des sites Web autorisés du routeur.", //fb_p_2
	"État de l'imprimante", //sps_ps
	"Vous devez configurer votre routeur pour permettre à une application logicielle de fonctionner sur n'importe quel ordinateur du réseau afin qu'un serveur Web ou un autre utilisateur Internet puisse s'y connecter.", //help47
	"Étape 4 : Sauvegarder réglages et Connexion", //wwa_title_s4
	"5:00 PM", //tt_time_18
	"Quand cette option est activée, les journaux des activités du routeur ou les notifications des mises à jour firmware peuvent être envoyés à une adresse email indiquée, et les paramètres suivants sont affichés.", //help860
	"UPnP a supprimé l'entrée %v <-> %v:%d <-> %v%d %s '%s' (adresse client libérée)", //GW_UPNP_IGD_PORTMAP_RELEASE
	"Les tâches de l'assistant de configuration de connexion Internet sont terminées. Cliquez sur Enregistrer pour enregistrer vos paramètres et redémarrer le routeur.", //wwa_intro_s4
	"Certains FAI peuvent vous demander de saisir un nom de service. Veuillez ne saisir un nom de service que si votre FAI l’exige.", //help267
	"Session locale L2TP 0x%04X abandonnée.", //IPL2TP_SESSION_ABORTED
	"Cette section vous permet de contrôler les réglages de la configuration du routeur, de redémarrer le routeur, et de restaurer les réglages usines du routeur. La restauration des réglages par défaut effacera tous les paramétrages, y compris toutes les règles que vous avez créées.", //help874
	"Sep.", //tt_Sep
	"Paquet ESP rejeté de %v à %v car impossible de traiter l'en-tête de paquet.", //IPSEC_ALG_ESP_UNABLE_TO_HANDLE_HEADER
	"Intervalle de mise à jour de clé du groupe", //bws_GKUI
	"Permet au routeur d'identifier certains flux audio et vidéo générés par un PC Windows Media Center et de leur donner la priorité. Ces flux sont utilisés par les systèmes basés sur les technologies Windows Media Extenders (par exemple, Xbox 360).", //help80b
	"Dans ces cas là, vous pouvez utiliser les filtres entrants pour limiter cette exposition en indiquant les adresses IP des hôtes Internet auxquels vous faites confiance pour accéder à votre réseau local par l’intermédiaire des ports que vous avez ouverts. Vous pourriez, par exemple, permettre seulement l'accès à un serveur de jeu sur votre réseau local à la maison aux ordinateurs des amis que vous avez invités à jouer sur ce serveur.", //help168c
	"Connexion BigPond", //BIGPOND_LOGGING_IN
	"Nom d''utilisateur/mot de passe de connexion (PPTP)", //wwa_wanmode_pptp
	"Plage (50 à 100)", //help58
	"Connecté", //ddns_connected
	"Échec du téléchargement", //ub_Upload_Failed
	"WPS a terminé pour STA avec MAC (%m) par msg: %s", //WIFISC_AP_PROXY_END_ON_MSG
	"PPTP (Point to Point Tunneling Protocol) utilisee un réseau privé virtuel pour se connecter à votre FAI. Cette méthode de connexion est principalement employée en Europe. Elle exige de saisir un <span class='option'> Nom d’utilisateur </span> et <span class='option'> Mot de passe </span> (fourni par votre FAI) pour accéder à Internet.", //help278
	"Saisissez un mot de passe alphanumérique comportant entre 8 et 63 caractères. Plus il est long et original, plus la sécurité est accrue.", //KR18
	"Un système enregistreur (syslog) est un serveur qui collecte les journaux provenant de différentes sources. Si le réseau local inclut un serveur syslog, vous pouvez utiliser cette option pour envoyer les journaux du routeur vers ce serveur.", //hhts_def
	"Utilisé quand votre ISP vous fournit une adresse IP qui ne change pas. L'information IP est saisie manuellement dans vos réglages de configuration IP. Vous devez saisir le", //help255
	"Port du serveur RADIUS secondaire", //bws_2RSP
	"Saisissez [80] pour le port public.", //help7
	"Visible", //bwl_VS_0
	"Filtrage De Point limite TCP", //af_TEFT
	"Lorsque <span class='option'>Type de connexion</span> est réglé sur <span class='option'> Détection automatique</span>, le type de connexion détecté automatiquement s'affiche ici.", //help86
	"Nom du réseau (SSID)", //sd_NNSSID
	"Le fait d'accéder à cette page Web peut avoir un effet sur la mesure.", //wt_p_2
	"Passerelle", //_gateway
	"Heure actuelle du routeur", //tt_CurTime
	"Matin", //_AM
	"Déconnecté", //DISCONNECTED
	"Soldier of Fortune", //gw_gm_47
	"(GMT-01:00) Açores", //up_tz_22
	"L'enregistreur interne WPS a détecté une session qui chevauche entre %m et %m", //WIFISC_IR_REGISTRATION_SESSION_OVERLAP
	"Veuillez faire correspondre les deux mots de passe admin et réessayer", //_pwsame_admin
	"IP de réseau étendu changée à %v ; mise à jour auprès du fournisseur de DNS dynamique.", //GW_DYNDNS_UPDATE_IP
	"Un ordinateur réseau (%s) utilise déjà l'adresse IP de %v.", //GW_DHCPSERVER_NEW_ASSIGNMENT
	"Windows/MSN Messenger", //as_WM
	"(GMT-09:00) Alaska", //up_tz_03
	"Entrez le PIN de votre périphérique sans fil, puis cliquez sur le bouton de connexion ci-dessous.", //KR43
	"Les mots de passe ne concordent pas. Recommencez.", //YM177
	"Selon le type de connexion au réseau étendu, vous pouvez prendre l'une des mesures suivantes :", //help774
	"Appuyez sur <strong> Editez l’icône</strong> pour modifier une règle existante en utilisant l’assistant de politique.", //hhac_edit
	"(GMT+02:00) Jérusalem", //up_tz_36
	"Nom d'hôte", //_hostname
	"L’initialisation du contrôle d'accès à Internet a échouée", //GW_INET_ACCESS_INITIAL_FAIL
	"L’initialisation du filtre Web a échouée", //GW_WEB_FILTER_INITIAL_FAIL
	"Quand le journal est plein", //te_OnFull
	"Étape 3 : Définissez votre mot de passe de sécurité sans fil", //wwl_title_s4
	"Mode de reconnexion:", //help281
	"Gamespy Tunnel", //gw_gm_77
	"Cloner l'adresse MAC de votre PC", //_clonemac
	"C'est un résumé du nombre de paquets qui sont passé entre le WAN et le LAN depuis que le routeur a été initialisé pour la dernière fois.", //hhss_intro
	"Vitesse de liaison montante mesurée", //at_MUS
	"La vitesse du WAN est habituellement détectée automatiquement. Si vous avez des problèmes pour la connexion au WAN, essayez de fixer la vitesse manuellement.", //hhan_wans
	"Activez cette option si vous souhaitez autoriser WISH à définir des priorités pour le trafic sans fil.", //YM141
	"La clé est saisie comme une phrase d’un maximum de 63 caractères alphanumériques dans le format ASCII (American Standard Code for Information Interchange) aux deux extrémités du raccordement sans fil. Elle ne peut pas être plus courte que huit caractères, bien que pour une meilleure sécurité, elle doit atteindre une longueur suffisante et ne devrait pas être une phase généralement connue. Cette phase est employée pour générer des clés de session qui sont uniques pour chaque client sans fil.", //help382
	"(heure:minute, sur 12 heures)", //tsc_hrmin
	"(heure:minute, sur 24 heures)", //tsc_hrmin1
	"Vitesse de liaison montante mesurée lorsque l'interface du réseau étendu a été rétablie pour la dernière fois. La valeur peut être inférieure à celle communiquée par le FAI car elle n'inclut pas tous les temps système des protocoles réseau associés au réseau de votre FAI. En général, ce chiffre se situe entre 87 % et 91 % de la vitesse de liaison montante indiquée pour les connexion xDSL et avoisine les 5 kits/s en moins pour les connexions réseau câblées.", //help82
	"Heretic II", //gw_gm_24
	"Delta Force", //gw_gm_13
	"Seuil RTS", //aw_RT
	"Windows XP", //help340
	"Réseau local sans fil", //sd_WLAN
	"Si votre serveur SMTP requiert une authentification, cochez cette case.", //help864
	"Il y a peut être un nouveau firmware de disponible", //tf_intro_FWU1
	"Système d'exploitation non pris en charge.", //wprn_bados
	"Métrique", //_metric
	"Filtre entrant", //INBOUND_FILTER
	"Paquet UDP entrant bloqué entre %v%u et %v%u", //IPNAT_UDP_BLOCKED_INGRESS
	"Cette option active et désactive le dispositif de connexion sans fil du routeur. Quand vous réglez cette option, les paramètres suivants sont effectifs.", //help351
	"Utiliser cette option pour saisir manuellement sa clé.", //wwz_manual_key2
	"Masque de sous-réseau PPTP", //_PPTPsubnet
	"Le port utilisé sur votre réseau interne.", //help20
	"Noir et blanc", //gw_gm_6
	"Mode WPA", //bws_WPAM
	"Sécurité basse", //wwl_GOOD
	"Postal 2: Share the Pain", //gw_gm_36
	"Saisissez votre nom d'hôte, entièrement qualifié ; par exemple : <code>monhôte.mondomaine.net</code>.", //help894
	"Masque de sous-réseau", //_subnet
	"La fenêtre de transmission PPTP est %u", //PPTP_EVENT_REMOTE_WINDOW_SIZE
	"Étape 1 : Sélectionnez la méthode de configuration du réseau sans fil", //wps_KR35
	"L'option <code>Réserver </code> convertit cette attribution dynamique d'IP en réservation DHCP et ajoute l'entrée correspondante à la liste de réservations DHCP.", //help329_rsv
	"Vietcong", //gw_gm_58
	"Mise en fonction du réseau étendu à l'aide de %s.", //GW_WAN_MODE_IS
	"Utilisez cette section pour configurer les paramètres du réseau interne de votre PA et le serveur DHCP intégré afin d'attribuer des adresses IP aux ordinateurs de votre réseau. L'adresse IP qui est configurée ici est l'adresse IP que vous utilisez pour accéder à l'interface de gestion Web. Si vous changez l'adresse IP, vous devrez peut-être ajuster les paramètres réseau de votre PC pour accéder de nouveau au réseau.", //ns_intro_
	"L’ALG Relais DNS a rejeté le paquet de %v:%u à %v:%u", //IPDNSRELAYALG_REJECTED_PACKET
	"L'écran Statistiques sur le trafic reçoit et envoie les paquets qui passent par votre routeur.", //ss_intro
	"Vous devriez consulter ces warnings, certaines fonctions peuvent être dévalidées", //KR112
	"<warn>Certains matériels ne peuvent utiliser les canaux 100-140. Changez le canal si une station ne peut se connecter.</warn>", //GW_WLAN_11A_CH_MID_BAND_WARN
	"Activer l'attaque anti-ARP", //ip_mac_binding_desc
	"L'activation de cette option (paramétrage par défaut) permet celle des connexions VPN uniques à un hôte distant. (Toutefois, pour plusieurs connexions VPN, la passerelle VPN ALG appropriée doit être utilisée.) La désactivation de cette option permet uniquement celle du VPN si la passerelle VPN ALG appropriée est également désactivée.", //LW50
	"La règle %s est en conflit avec une connexion existante (%v:%u (public %v:%u)--->%v:%u). Cette règle peut être affectée tant que cette connexion sera active.", //GW_NAT_CONFLICTING_CONNECTIONS_LOG
	"Les Warnings sont crées lors des changements de configuration.", //KR111
	"Entrées Log", //KR109
	"<warn>La règle %s est en conflit avec une connexion existante (%v:%u (public %v:%u)--->%v:%u). Cette règle peut être affectée tant que cette connexion sera active.</warn>", //GW_NAT_CONFLICTING_CONNECTIONS_WARNING
	"HNAP SetAccessPointMode %s retourne %s, %s", //GW_PURE_SETACCESSPOINTMODE
	"Paquet bloqué de %v à %v reçu sur la mauvaise interface réseau (Spoofing d'adresse IP)", //GW_NAT_REJECTED_SPOOFED_PACKET
	"Message", //KR110
	"<warn>La passerelle de routage IP %v n'est pas dans le bon subnet (%v/%v) et sera dévalidée.</warn>", //GW_ROUTES_ROUTE_GATEWAY_NOT_IN_SUBNET_WARNING
	"Quand cette option est validée, le routeur restreint le flux du trafic sortant afin de ne pas dépasser le débit du lien WAN.", //KR107
	"Contrôle anti-spoof", //KR105
	"Paquet bloqué de %v à %v (Attaque LAND)", //IPSTACK_REJECTED_LAND_ATTACK
	"WEP", //LS321
	"E-mails de notification", //KR67
	"pour le port cible, le numéro de fin doit être compris entre 0 et 65535 (inclus).", //YM71
	"La plage d'adresses IP source %v-%v est en double.", //GW_FIREWALL_RANGE_DUPLICATED_INVALID
	"Adresse matérielle", //LS422
	"Utiliser Windows Connect Now", //bwz_LWCNWz
	"Adresse IP de la passerelle WAN incorrecte : %v", //GW_WAN_WAN_GATEWAY_IP_ADDRESS_INVALID
	"Enregistrer la configuration dans l'assistant de configuration du réseau sans fil", //ta_wcn
	"Un code PIN est un numéro unique destiné à ajouter le routeur à un réseau existant ou à créer un réseau. Celui par défaut peut figurer en bas du routeur. Pour davantage de sécurité, vous pouvez obtenir un autre code PIN. Vous êtes également en mesure de restaurer le numéro par défaut à tout moment. En revanche, seul l'administrateur peut modifier ou réinitialiser le code PIN.", //LW57
	"Clé WEP 2", //_wepkey2
	"Saut", //tsc_pingt_msg109
	"Type de noeud NetBIOS", //bd_NETBIOS_REG_TYPE
	"Merci d'appuyer sur le bouton-poussoir (physique ou virtuel) du produit que vous ajoutez à votre réseau sans fil", //wps_messgae1_2
	"Créez de manière aléatoire un code PIN valide associé au routeur. Si nécessaire, copiez-le dans l'interface utilisateur du registre.", //LW60
	"Échec de la restauration", //_rs_failed
	"Sélectionnez cette option si le périphérique est connecté à un réseau local en aval d'un autre routeur. Sous ce mode, le système fonctionne comme un pont entre son réseau WAN et ses périphériques LAN, y compris ceux connectés sans fil.", //KR62
	"Le champ du code PIN du périphérique sans fil ne peut pas être laissé en blanc.", //KR20
	"Pour obtenir des performances optimales, utilisez loption de hiérarchisation automatique des applications.", //at_intro_2
	"Annonce NetBIOS", //bd_NETBIOS_ENABLE
	"Masque de sous-réseau du réseau local.", //KR77
	"Super G avec turbo dynamique", //help364
	"Achats", //_aa_bsecure_shopping
	"Proxies publics", //_aa_bsecure_public_proxies
	"Clé WEP 1", //wepkey1
	"Envoyer/Recevoir l'autorisation", //ZM11
	"Heure de début", //tsc_start_time
	"Pour le port source, le numéro de fin doit être compris entre 0 et 65535 (inclus).", //YM69
	"Le cas échéant, l'activation de la fonction d'annonce NetBIOS entraîne l'obtention d'éventuelles informations WINS côté WAN.", //KR82
	"Seul l'administrateur peut effacer les statistiques. Le bouton d'effacement des statistiques est désactivé car vous n'êtes pas connecté en tant qu'administrateur.", //ss_intro_user
	"Le nom de programmation %s est réservé. Il ne peut pas être utilisé.", //GW_SCHEDULES_NAME_RESERVED_INVALID
	"Ajouter une station sans fil", //LW12
	"Windows Media Center", //YM75
	"L'adresse IP de la passerelle d'acheminement %v est incorrecte.", //GW_ROUTES_GATEWAY_IP_ADDRESS_INVALID
	"L'intervalle de mise à jour de la clé de groupe WPA doit se situer entre 30 et 65535 secondes.", //GW_WLAN_WPA_REKEY_TIME_INVALID
	"WEP est la norme de chiffrement sans fil. Pour l'utiliser, vous devez définir la même clé sur le routeur et les stations sans fil. Pour les clés de 64 bits, vous devez entrer 10 chiffres hexadécimaux dans chacun de leur champ. Pour les clés de 128 bits, vous devez entrer 26 chiffres hexadécimaux dans chacun de leur champ. Un chiffre hexadécimal est soit un chiffre compris entre 0 et 9, soit une lettre comprise entre A et F. Pour une sécurité maximale de la fonction WEP alors activée, définissez le type d'authentification comme clé partagée.", //bws_msg_WEP_1
	"Pour protéger votre réseau, il est également possible d'activer le mode de masquage. Lorsque cette option est activée, aucun client sans fil ne peut voir votre réseau sans fil lors d'une recherche d'éléments disponibles. Pour permettre aux périphériques sans fil de se connecter à votre routeur, vous devez saisir manuellement le nom du réseau sans fil sur chacun dentre eux.", //YM125
	"Jeux d'argent", //_aa_bsecure_gambling
	"Mode pont", //KR14
	"L'adresse de l'expéditeur fournie (%s) est incorrecte.", //GW_SMTP_FROM_ADDRESS_INVALID
	"Indique la façon dont les hôtes réseau doivent exécuter l'enregistrement et la recherche de noms NetBIOS.", //KR89
	"Masque de réseau :", //help106
	"Lors de la configuration de l'accès Internet du routeur, veillez à sélectionner le <strong>type de connexion Internet</strong> approprié dans le menu déroulant. Si vous n'êtes pas sûr de l'option à sélectionner, contactez votre <strong>fournisseur d'accès Internet (FAI)</strong>.", //LW35
	"Voix (le plus urgent).", //YM151
	"Vos modifications ont été enregistrées. Le routeur doit être réinitialisé pour que les modifications prennent effet. Vous pouvez redémarrer maintenant ou continuer à réaliser des modifications et redémarrer plus tard.", //YM2
	"Remarque : pour connaître les limitations possibles de cette fonction, reportez-vous à l'<a href='../Help/Tools.shtml#wcn' onclick='return jump_if();' style='white-space: nowrap;'>aide (-&gt; partie outils)</a>.", //ta_wcn_note
	"La configuration du routeur a été modifiée par autre chose pendant l'assistant.\nLa fonction d'assistant va être annulée ; veuillez réessayer.", //YM131
	"HTTP et HTTPS ne peuvent pas utiliser le même port LAN.", //GW_WEB_SERVER_SAME_PORT_LAN
	"Délai d'attente de la session", //KR25
	"Réinitialiser maintenant", //YM3
	"% %La passerelle Wake-On-LAN ALG a été automatiquement activée car elle est requise pour l'entrée de serveur virtuel créée.<warn>", //GW_NAT_WOL_ALG_ACTIVATED_WARNING
	"Plage d'adresses IP cible incorrecte pour le filtre de port", //YM20
	"Activez cette option si vous souhaitez autoriser WISH à définir des priorités pour le trafic sans fil.", //YM86
	"Adresse MAC de réseau étendu %m incorrecte", //GW_WAN_MAC_ADDRESS_INVALID
	"format de l'adresse électronique du destinataire incorrect", //IPSMTPCLIENT_MSG_WRONG_RECEPIENT_ADDR_FORMAT
	"WISH prend en charge la simultanéité de règles. Si plusieurs règles correspondent à un flux de messages spécifique, la règle de priorité plus élevée est utilisée.", //YM146
	"Avertissements relatifs à la configuration", //LS151
	"Le nom ne peut pas être une chaîne vide.", //GW_QOS_RULES_NAME_INVALID
	"%s [protocole : %d] -> %v est en conflit avec %s [protocole : %d] -> %v.", //GW_NAT_VS_PROTO_CONFLICT_INVALID
	"Le nom ne peut pas être une chaîne vide.", //GW_WISH_RULES_NAME_INVALID
	"Le poste sans fil %s n'a pas pu être ajouté, motif %s, err_code %u", //WIFISC_IR_REGISTRATION_FAIL
	"LISTE D'ACHEMINEMENT", //r_rlist
	"Saisir une adresse de serveur DNS spécifique.", //IPV6_TEXT109
	"128 bits (26 chiffres hexadécimaux)", //bws_WKL_1
	"Organise les informations pour qu'elles puissent être gérées, actualisées et facilement accessibles par des utilisateurs ou des applications.", //help473
	"Protection sans fil supplémentaire", //aw_erpe
	"Impossible de ne pas renseigner les deux plages de port.", //GW_NAT_PORT_FORWARD_RANGE_BOTH_EMPTY_INVALID
	"L'adresse IP de la passerelle d'acheminement %v n'est pas dans le sous-réseau d'interface.", //GW_ROUTES_GATEWAY_IP_ADDRESS_IN_SUBNET_INVALID
	"Assistant sans fil", //LW37
	"Cette fonction est désactivée si vous êtes connecté en tant qu'utilisateur", //tsc_pingdisallowed
	"Pour enregistrer la configuration, cliquez sur le bouton <strong>correspondant</strong>.", //ZM20
	"Type de chiffrement :", //help376
	"La fonction de notification par courrier électronique n'est pas activée dans la page des outils (partie paramètres de messagerie). Toutefois, la fonction de notification par courrier électronique d'une nouvelle version de firmware est activée dans la page des outils (partie firmware).", //GW_FW_NOTIFY_EMAIL_DISABLED_INVALID
	"Clé WEP incorrecte", //YM122
	"L'adresse DMZ %v ne peut pas être la même que l'adresse IP LAN.", //GW_NAT_DMZ_CONFLICT_WITH_LAN_IP_INVALID
	"Configuration erronée - voir journaux", //_sdi_s7
	"Configuration du moteur QoS", //at_title_SESet
	"Pour le port, le numéro de début doit être inférieur à celui de fin : %d-%d.", //GW_INET_ACL_START_PORT_INVALID
	"(échec de l'envoi des données de courrier électronique)", //IPSMTPCLIENT_DATA_FAILED
	"M-Node (valeur par défaut)  indique un mode de fonctionnement mixte. Une opération de diffusion est exécutée pour enregistrer les hôtes et en rechercher d'autres (en cas d'échec, les éventuels serveurs WINS sont testés). Sous ce mode, elle est susceptible d'être préférée, notamment si une connexion réseau lente permet d'atteindre les serveurs WINS et si les services réseau, tels que les serveurs et les imprimantes, sont généralement internes au LAN.", //KR91
	"Bande de fréquences d'exploitation. Choisissez 2,4 GHz pour garantir la visibilité des périphériques d'ancienne génération et pour obtenir un plus grand intervalle. Choisissez 5 GHz pour réduire au maximum perturbations ; celles-ci peuvent en effet altérer les performances.", //KR971
	"Restaurer les valeurs par défaut", //tss_RestAll_b
	"%s de %s [%s:%s] -> %s est en conflit avec %s [%s:%s] -> %s.", //GW_NAT_PORT_TRIGGER_CONFLICT_INVALID
	"La fragmentation se produit lorsque la taille de trame en octets dépasse le seuil de fragmentation.", //LW54
	"Si vous disposez déjà d'un serveur DHCP sur votre réseau ou utilisez des adresses IP statiques sur tous les périphériques du réseau, désélectionnez la case d'<strong>activation du serveur DHCP</strong>.", //TA7
	"Adresse IP de ce périphérique du réseau local.", //KR74
	"Clé WEP par défaut", //bws_DFWK
	"Si vous débutez dans la gestion de réseau sans fil et dans la configuration d'un routeur sans fil, accédez à l'<strong>assistant Réseau sans fil</strong> pour que le routeur vous aide à mettre votre réseau en service en quelques étapes simples.", //LW46
	"Le serveur SMTP (courrier électronique) %s est à l'adresse IP %v", //IPSMTPCLIENT_RESOLVED_DNS
	"Interface", //help110
	"Adresse IP de la passerelle PPTP incorrecte", //YM107
	"La valeur du délai d'attente ne peut pas dépasser 8760.", //YM180
	"Masque de sous-réseau WAN %v incorrect", //GW_WAN_WAN_SUBNET_INVALID
	"<warn>La zone DMZ est désactivée en raison de la modification du sous-réseau LAN.</warn>", //GW_NAT_DMZ_DISABLED_WARNING
	"Souhaitez-vous désactiver l'entrée de réservation DHCP pour l'adresse IP", //YM93
	"<warn>La passerelle FTP ALG a été automatiquement activée car elle est requise pour l'entrée de serveur virtuel créée.</warn>", //GW_NAT_FTP_ALG_ACTIVATED_WARNING
	"Hôte libre", //_aa_bsecure_free_host
	"Masque de réseau incorrect pour l'acheminement", //_r_alert2
	"Adresse MAC incorrecte", //LS47
	"Le masque de sous-réseau LAN ne laisse au serveur DHCP aucune adresse à utiliser.", //GW_DHCP_SERVER_SUBNET_SIZE_INVALID
	"Vous ne pouvez pas ajouter la nouvelle adresse MAC %m. Vous pouvez uniquement réutiliser les adresses MAC d'autres règles.", //GW_INET_ACCESS_POLICY_TOO_MANY_MAC_INVALID
	"La valeur de l'adresse IP de début doit être inférieure à celle de fin : %v-%v", //GW_FIREWALL_START_IP_ADDRESS_INVALID
	"secondes.", //YM8
	"%s : la priorité %u doit être comprise entre 0 et 7.", //GW_WISH_RULES_PRIORITY_RANGE
	"Voyages", //_aa_bsecure_travel
	"Pour évaluer le coût d'utilisation d'un acheminement, une valeur comprise entre 1 et 16 sert d'indicateur. La valeur 1 correspond au coût le plus faible et 15 au coût le plus élevé. Quant au nombre 16, il indique que l'acheminement est impossible depuis ce routeur. Pour tenter d'atteindre une destination particulière, les ordinateurs de votre réseau ignorent cette valeur et sélectionnent le meilleur acheminement.", //help113
	"Client BigPond", //ZM6
	"(la longueur sapplique à toutes les clés)", //bws_length
	"L'option du contrôle ActiveX WCN fournit le lien WCN nécessaire entre le routeur et le PC via le navigateur. Le navigateur va chercher à télécharger le contrôle ActiveX WCN, si celui-ci n'est pas déjà disponible sur votre PC. Pour que cette action réussisse, la connexion WAN doit être établie et le réglage de sécurité Internet du navigateur doit être moyen ou inférieur (sélectionnez Outils &rarr; Options Internet &rarr; Sécurité &rarr; Personnaliser le niveau &rarr; Moyen).", //help836
	"Réessayez la restauration à l'aide d'un fichier de configuration valide.", //rs_intro_2
	"L'adresse IP %v existe déjà.", //GW_INET_ACL_IP_ADDRESS_DUPLICATION_INVALID
	"Vous devez être connecté en tant qu'Administrateur pour utiliser ces fonctions.", //KR7
	"(Également appelée SSID)", //ZM1
	"Sélectionnez un filtre qui contrôle l'accès selon les besoins pour ce port admin. Si le filtre souhaité n'apparaît pas dans la liste des filtres, allez à l'écran <a href=\"Inbound_Filter.asp\" onclick=\"return jump_if();\">Avancé → Filtre entrant</a>, puis créez un nouveau filtre.", //hhta_831
	"Configuration de la connexion Internet manuelle", //LW30
	"Masque de sous-réseau L2TP incorrect", //YM110
	"Point à point (pas de diffusion)", //bd_NETBIOS_REG_TYPE_P
	"Le masque de sous-réseau LAN est incorrect.", //GW_LAN_SUBNET_MASK_INVALID
	"Impossible de créer davantage de réservations", //YM88
	"Principale adresse IP de serveur WINS incorrecte", //GW_DHCP_SERVER_NETBIOS_PRIMARY_WINS_INVALID
	"Nom (le cas échéant)", //YM187
	"%s  Nom %s de %s non défini.", //GW_NAT_NAME_UNDEFINED_INVALID
	"Radar sans fil détecté sur le canal %d", //GW_WIRELESS_RADAR_DETECTED
	"Clé Pré-Partagée", //LW25
	"Restauration incorrecte", //_rs_invalid
	"Principale adresse IP de serveur DNS incorrecte", //YM113
	"Configuration sécurisée du Wifi", //LW65
	"Sélectionnez cette option si votre périphérique sans fil prend en charge les boutons de commande", //KR41
	"Principale adresse IP de serveur DNS incorrecte : %v", //GW_WAN_DNS_SERVER_PRIMARY_INVALID
	"Code PIN du périphérique sans fil incorrect", //KR21
	"Réseau personnel", //help643
	"Dans le champ ci-dessous, indiquez l'<span class='option'>adresse IP du routeur</span>. Définissez en outre la % %passerelle<span class='option'> sur l'adresse IP du routeur en amont. Les deux adresses doivent figurer dans le sous-réseau LAN selon les indications du </span>masque de sous réseau<span class='option'>.", //KR63
	"Lassistant suivant est conçu pour la configuration Web d'une imprimante. Il va vous guider tout au long de la procédure détaillée.", //LW31
	"Adresse IP de serveur DNS secondaire incorrecte : %v", //GW_WAN_DNS_SERVER_SECONDARY_INVALID
	"Valeur de fin incorrecte pour l'adresse IP distante.", //YM55
	"Pour obtenir des informations sur la méthode de configuration prise en charge par vos périphériques sans fil, veuillez vous reporter à la documentation de l'adaptateur.", //KR37
	"Sélectionnez cette case pour permettre au serveur DHCP de mettre à disposition des hôtes LAN les paramètres de configuration NetBIOS.", //KR80
	"Masque de sous-réseau WAN incorrect", //YM100
	"Réveil par le réseau", //_wakeonlan
	"L'actuel problème de réception peut s'expliquer par une charge trop importante du périphérique. Réessayez la restauration. Le problème peut également s'expliquer par une connexion utilisateur et non administrateur (seul ce dernier est autorisé à restaurer le fichier de configuration). Dans le journal système, recherchez toute erreur.", //rs_intro_3
	"PainKiller", //gw_gm_35
	"Vous allez être redirigé vers la page de connexion dans", //YM7
	"Si vous n'utilisez pas le mode Super G avec turbo dynamique pour améliorer le débit, activez la fonction d'analyse automatique des canaux. Ainsi, le routeur peut sélectionner le meilleur canal pour votre réseau sans fil.", //YM124g
	"L'adresse MAC %m existe déjà.", //GW_INET_ACL_MAC_ADDRESS_DUPLICATION_INVALID
	"(valeur de début incorrecte pour l'adresse IP cible).", //YM66
	"Optimum Online", //manul_conn_13
	"Annonce NetBIOS", //bd_NETBIOS
	"Cible", //sa_Target
	"Cette section est la zone dans laquelle vous définissez les règles d'application.", //help56_a
	"<warn>Le serveur DHCP est reconfiguré car le sous-réseau LAN n'est pas adapté. Veillez à toujours disposer de paramètres de serveur corrects.</warn>", //GW_DHCP_SERVER_RECONFIG_WARNING
	"Échec", //_wifisc_addfail
	"La période de balise doit être comprise entre 100 et 1000.", //GW_WLAN_BEACON_PERIOD_INVALID
	"Optimum", //YM79
	"Taille maximum d'agrégation incorrecte", //YM32
	"Ainsi, vous passez par la technologie Windows Connect Now pour enregistrer l'actuelle configuration sans fil du routeur sur l'ordinateur et par l'assistant Réseau sans fil de Microsoft pour autoriser la propagation à venir des paramètres.", //ta_intro_wcn
	"Sélectionnez cette option si les adaptateurs sans fil PRENNENT EN CHARGE WPA", //wwl_text_better
	"Arrière-plan", //YM78
	"Canal", //sd_channel
	"Remarque : par risque de contradiction, il est impossible d'associer différents ordinateurs LAN à des règles de redirection basées sur des ports en commun.", //KR53
	"Une fois tous les périphériques réseau sans fil configurés, <strong>verrouillez les paramètres de sécurité sans fil</strong>.", //LW16
	"TCP", //GW_NAT_TCP
	"Ce routeur est équipé d'un port USB. Si vous disposez d'un port USB et de Windows XP SP2 minimum sur le PC, vous pouvez donc échanger des données de configuration sans fil entre l'ordinateur et le routeur à l'aide d'un lecteur flash. Ouvrez le panneau de configuration Windows et sélectionnez l'assistant Réseau sans fil. L'assistant Réseau sans fil vous propose les options suivantes : Utiliser un lecteur flash USB et Configurer un réseau manuellement. Sélectionnez Utiliser un lecteur flash USB.", //help202
	"[CRIT]", //CRIT
	"La règle s'applique à un flux de messages pour lequel l'adresse IP de l'autre ordinateur est comprise dans la plage définie ici.", //YM154
	"La fonction Moteur QoS permet d'améliorer les performances de votre réseau en accordant la priorité aux débits de données des applications en réseau.", //help76
	"%s : pour le port de l'hôte 1, le numéro de début (%u) doit être inférieur à celui de fin (%u)", //GW_WISH_RULES_HOST1_PORT
	"En mode turbo (11g), le canal doit être défini sur 6.", //GW_WLAN_11G_TURBO_INVALID
	"Divertissements", //_aa_bsecure_entertainment
	"Inactivité", //YM165
	"Nommez la règle de façon significative.", //help172
	"Styles de vie", //_aa_bsecure_lifestyles
	"L'adresse DMZ doit figurer dans le sous-réseau LAN (%v).", //GW_NAT_DMZ_NOT_IN_SUBNET_INVALID
	"Mode turbo", //sd_TMode
	"%s  Plage de ports %s de %s incorrecte.", //GW_NAT_PORT_FORWARD_PORT_RANGE_INVALID
	"%s : pour l'adresse IP locale, la valeur de fin %v ne figure pas dans le sous-réseau LAN", //GW_QOS_RULES_LOCAL_IP_END_SUBNET
	"AES", //bws_CT_2
	"Remarque : il est impossible de contrôler l'accès aux sites Web dont l'URL se présente sous la forme <code>https:...</code>.", //_bsecure_parental_limits
	"64 Ko", //aw_64
	"Humour", //_aa_bsecure_humor
	"P-Node  indique que SEULS les serveurs WINS sont à utiliser. Ce paramètre permet de forcer toutes les opérations NetBIOS sur les serveurs WINS configurés. Vous devez avoir configuré au moins la principale adresse IP du serveur WINS pour qu'elle pointe vers un serveur WINS actif.", //KR92
	"Mode routeur", //KR13
	"Impossible d'avoir un nom de règle en double : %s.", //GW_INET_ACL_POLICY_NAME_DUPLICATE_INVALID
	"Le NAT ne transmet pas de requêtes de connexions entrantes si la même adresse de port est utilisée pour une connexion déjà établie.", //YM136
	"Version matérielle", //TA3
	"Super G sans turbo :", //help360
	"Avertissements", //YM10
	"Adresse IP du serveur PPTP incorrecte : %v", //GW_WAN_PPTP_SERVER_IP_ADDRESS_INVALID
	"Vidéo.", //YM150
	"Un périphérique utilise l'adresse IP %v. Annulez l'attribution et réinitialisez les paramètres réseau.", //GW_DHCP_SERVER_RESERVATION_IN_USE
	"Port du firewall", //GW_NAT_INPUT_PORT
	"Réinitialisation par %s terminée", //WIFISC_AP_REBOOT_COMPLETE
	"Dernière version de firmware", //YM182
	"1 000 Mbits/s", //LW3
	"La clé WPA Personal doit comporter au moins 8 caractères.", //YM116
	"Clé WEP", //LW22
	"Oups !", //OOPS
	"Sessions WISH", //YM158
	"Échec de l'envoi/de la réception d'instances", //ZM16
	"Sélectionner la catégorie d'âge", //_aa_bsecure_select_age
	"Adresse IP cible %s incorrecte pour l'acheminement", //GW_ROUTES_DESTINATION_IP_ADDRESS_INVALID
	"Réinitialisation par %s terminée", //WIFISC_AP_RESET_COMPLETE
	"Mode d'enregistrement NetBIOS", //bd_NETBIOS_REG
	"L'adresse IP de la passerelle LAN est incorrecte.", //GW_LAN_GATEWAY_IP_ADDRESS_INVALID
	"Enregistrez la règle de programmation créée ou modifiée.", //KR96
	"Fichier de configuration exporté", //GW_XML_CONFIG_GET_SUCCESS
	"Délai d'attente : %d %s pour le renouvellement de lentrée UPnP %v <-> %v:%d <-> %v:%d %s", //GW_UPNP_IGD_PORTMAP_REFRESH
	"Pour obtenir des performances optimales sans fil, utilisez le mode de sécurité <strong>WPA2 uniquement</strong> ou, en d'autres termes, le chiffrement AES.", //bws_msg_WPA_2
	"L'adresse IP LAN est incorrecte.", //GW_LAN_IP_ADDRESS_INVALID
	"IP distante de départ", //KR5
	"Le moteur QoS prend en charge les chevauchements entre les règles, où plus d'une règle peut correspondre à un flux de messages spécifiques. Si plusieurs règles correspondent, celle qui présente la priorité la plus élevée est utilisée.", //help88c
	"Le nom de programmation %s n'est pas défini.", //GW_INET_ACL_SCHEDULE_NAME_INVALID
	"%s : pour le port distant, le numéro de début (%u) doit être inférieur à celui de fin (%u)", //GW_QOS_RULES_REMOTE_PORT
	"L'adresse IP pour %s doit figurer dans le sous-réseau LAN (%v).", //GW_NAT_IP_ADDRESS_INVALID
	"Les clés hexadécimales de 128 bits comportent 26 caractères exactement. (456FBCDF123400122225271730 est une chaîne correcte de 26 caractères pour un chiffrement sur 128 bits.)", //help369
	"Au lieu d'entrer le nom de la règle d'une application particulière, vous pouvez le sélectionner dans cette liste d'applications courantes. Les autres valeurs de configuration sont renseignées en conséquence.", //help48a
	"Paramètres sans fil", //LW38
	"compte utilisateur à indiquer", //GW_DYNDNS_USER_NAME_INVALID
	"L'adresse IP cible est celle de l'hôte ou du réseau à atteindre.", //hhav_r_dest_ip
	"Le numéro de port d'administration distant est incorrect.", //YM175
	"Grâce à Wi-Fi Protected Setup, vous pouvez ajouter facilement des périphériques à un réseau en utilisant un code PIN ou en cliquant sur un bouton. Les périphériques doivent prendre en charge cette méthode pour pouvoir être configurés selon elle.", //LY3
	"Délai d'attente : %d %s pour l'ajout de l'entrée UPnP %v <-> %v:%d <-> %v:%d %s", //GW_UPNP_IGD_PORTMAP_ADD
	"Conflit UPnP avec entrée existante %v <-> %v:%d <-> %v:%d %s %s", //GW_UPNP_IGD_PORTMAP_CONFLICT
	"Message", //KRA1
	"Port", //_vs_port
	"<warn>La table de contrôle d'accès est en cours de reconfiguration en raison de la modification du sous-réseau LAN.</warn>", //GW_INET_ACL_RECONFIGURED_WARNING
	"Activez l'opération 802.11d. 802.11d est une spécification sans fil s’appliquant pour dans des domaines de normalisation supplémentaires. Ce supplément aux spécifications 802.11 définit les conditions de couche physique (découpage en canaux, canaux virtuels indépendants et sans interférence, nouvelles valeurs pour des attributs MIB actuels, et d’autres conditions d’extension du WLAN 802.11 aux nouveaux domaines de normalisation (pays). Ce supplément ajoute les conditions et les définitions nécessaires pour permettre à l’équipement WLAN 802.11 de fonctionner sur les marchés non servis par la norme actuelle. Activez cette option si vous opérez dans un de ces &quot; domaines de normalisation supplémentaire &quot;.", //help186
	"Pour la plupart des applications, les éléments de classification assurent les bonnes priorités et il n'est pas nécessaire d'utiliser des règles WISH spécifiques.", //YM145
	"Annuler la définition du registre sélectionné", //WIFISC_AP_UNSET_SELECTED_REGISTRAR
	"Il est impossible d'indiquer un DNS secondaire sans spécifier également un DNS principal.", //GW_WAN_DNS_SERVER_SECONDARY_WITHOUT_PRIMARY_INVALID
	"WISH (Wireless Intelligent Stream Handling) définit la priorité du trafic de différentes applications sans fil.", //YM72
	"Astuces", //_hints
	"%s : pour le port local, le numéro de début (%u) doit être inférieur à celui de fin (%u)", //GW_QOS_RULES_LOCAL_PORT
	"Pour l'adresse IP locale, la valeur de début est incorrecte.", //YM52
	"Discussion en ligne", //_aa_bsecure_chat
	"IP de destination", //help104
	"Remarque : dans la mise en Suvre WCN actuelle de Microsoft, vous ne pouvez pas enregistrer les paramètres sans fil si un profil du même nom existe déjà. Pour contourner cette limitation, supprimez les profils existants ou modifiez le SSID lorsque vous changez les paramètres sans fil. Une fois les nouveaux paramètres enregistrés, un profil est créé.", //help839
	"Adresse IP WAN incorrecte", //YM99
	"Par âge", //_aa_bsecure_byage
	"Le nom %s existe déjà.", //GW_INET_ACL_NAME_DUPLICATE_INVALID
	"Pour l'adresse du serveur DHCP, la valeur de fin %v est incorrecte dans le sous-réseau LAN %v.", //GW_DHCP_SERVER_POOL_TO_INVALID
	"En cours", //KR26
	"Souhaitez-vous activer l'entrée de réservation DHCP pour l'adresse IP", //YM92
	"Adresse IP réservée %v incorrecte", //GW_DHCP_SERVER_RESERVED_IP_INVALID
	"Les protocoles courants -- UDP, TCP et UDP plus TCP -- peuvent être sélectionnés dans le menu déroulant.", //help19x1
	"Instabilité", //_aa_bsecure_unstable
	"L'adresse IP réservée %v doit figurer dans la plage DHCP configurée.", //GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID
	"La règle de filtre %s ne peut pas être supprimée ou renommée car elle est utilisée.", //GW_FIREWALL_FILTER_NAME_INVALID
	"Vous pouvez avoir besoin de ce fichier pour charger votre configuration ultérieurement si les paramètres par défaut du routeur sont restaurés.", //ZM19
	"Vidéo", //YM80
	"Adresse IP du serveur WINS secondaire", //bd_NETBIOS_WINS_2
	"Réinitialise la zone d'ajout/de mise à jour de l'écran : efface tout changement susceptible d'avoir été effectué avant l'activation du bouton d'ajout/de mise à jour.", //KR57
	"Activité", //YM164
	"L'adresse IP est interdite.", //_logsyslog_alert2
	"Optimum.", //YM149
	"Temps d'attribution du serveur DHCP incorrect", //LT120
	"Auto (WPA ou WPA2) - Personnel", //KR48
	"Intervalle de reconnexion incorrecte : %u (doit être compris entre 20 et 180)", //GW_WAN_RECONNECT_INTERVAL_INVALID
	"Contrôle le filtrage des points d'extrémité pour les paquets du protocole TCP.", //YM139
	"Pour le port distant, le numéro de début doit être compris entre 0 et 65535 inclus.", //YM61
	"<warn>La table de serveur virtuel est reconfigurée car le sous-réseau LAN a été modifié.</warn>", //GW_NAT_VIRTUAL_SERVER_TABLE_RECONFIGURED_WARNING
	"Réinitialisation nécessaire", //YM1
	"Longueur de la clé WEP", //bws_WKL
	"PIN (numéro d'identification personnel)", //wps_p3_2
	"Paramètres enregistrés", //KR102
	"%s : pour l'adresse IP locale, le numéro de début %v ne figure pas dans le sous-réseau LAN", //GW_QOS_RULES_LOCAL_IP_START_SUBNET
	"Adresse IP PPTP incorrecte : %v", //GW_WAN_PPTP_IP_ADDRESS_INVALID
	"Alcool", //_aa_bsecure_alcohol
	"Les noms de règles de filtrage de port ne peuvent pas être en double.", //YM14
	"Le mode turbo dynamique n'est pas autorisé avec 802.11b.", //GW_WLAN_11B_DYNAMIC_TURBO_INVALID
	"Expiration de l'entrée UPnP %v <-> %v:%d <-> %v%d %s %s", //GW_UPNP_IGD_PORTMAP_EXPIRE
	"Une fois le routeur configuré comme vous le souhaitez, vous pouvez enregistrer les paramètres de configuration dans un fichier de configuration. Vous aurez peut-être besoin de ce fichier pour charger votre configuration ultérieurement, en cas de restauration des paramètres par défaut de votre routeur. Pour enregistrer la configuration, cliquez sur le bouton <strong>Enregistrer la configuration</strong>.", //TA18
	"Cette option est disponible uniquement lorsque le <span class='option'>mode 802.11</span> est défini sur <span class='option'>802.11ng uniquement</span>.", //aw_erpe_h2
	"Numéro de début incorrect pour le filtre de port cible", //YM21
	"La priorité du flux de messages est entrée ici. Quatre priorités sont définies :", //YM147
	"En cas d'activation de l'option correspondante, les e-mails de notification sont envoyés vers Internet à l'aide du routeur en amont.", //KR68
	"Cet assistant vous aide à ajouter des périphériques au réseau sans fil.", //LW61
	"Un nom d'utilisateur L2TP DOIT être indiqué", //GW_WAN_L2TP_USERNAME_INVALID
	"Adresse IP WINS secondaire incorrecte", //LT120z
	"WPA/WPA2", //KR97
	"Masque de sous-réseau L2TP %v incorrect", //GW_WAN_L2TP_SUBNET_INVALID
	"Enregistrer les paramètres sur le disque dur local", //help_ts_ss
	"Automobile", //_aa_bsecure_automobile
	"Ajouter un périphérique sans fil avec WPS", //LW13
	"Intervalle de temps", //sch_time
	"Pour préserver votre confidentialité, vous pouvez configurer des fonctions de sécurité sans fil. Ce périphérique prend en charge trois modes de sécurité sans fil dont WEP, WPA-Personal et WPA-Enterprise. WEP est la norme d'origine pour le chiffrement sans fil. WPA fournit un niveau plus élevé de sécurité. WPA-Personal ne nécessite pas de serveur d'authentification. L'option WPA-Enterprise nécessite un serveur RADIUS externe.", //bws_intro_WlsSec
	"Un mot de passe PPPoE DOIT être indiqué", //GW_WAN_PPPOE_PASSWORD_INVALID
	"Avant de pouvoir utiliser l'assistant WCN du routeur, vous devez exécuter l'assistant de configuration réseau sans fil sur votre PC. Si nécessaire, sélectionnez l'assistant Réseau sans fil dans le panneau de configuration Windows. Lorsque cet assistant vous en donne le choix, préférez Configurer un réseau manuellement à Utiliser un lecteur flash USB. (En réalité, vous n'aurez pas à réaliser la configuration manuellement. L'opération sera effectuée à l'aide du contrôle ActiveX WCN.)", //help211
	"Masque de sous-réseau incorrect", //LS202
	"Heure de fin", //tsc_EndTime
	"Cet assistant vous guide tout au long de la procédure d'ajout de votre dispositif sans fil à votre réseau sans fil.", //KR34
	"Clé WEP 3", //_wepkey3
	"Plage de ports distants", //at_RePortR
	"OSPF", //help640
	"Adresse de serveur fournie (%s) incorrecte", //GW_SMTP_SERVER_ADDRESS_INVALID
	"Adresse IP de la passerelle L2TP incorrecte : %v", //GW_WAN_L2TP_GATEWAY_IP_ADDRESS_INVALID
	"Affiche la valeur du code PIN du routeur.", //LW58
	"Clé utilisée", //LW22usekey
	"Le mode turbo statique n'est pas autorisé avec la norme 802.11b", //GW_WLAN_11B_STATIC_TURBO_INVALID
	"(valeur de fin incorrecte pour l'adresse IP cible).", //YM67
	"<warn>La modification des paramètres de sécurité sans fil peut amener Wi-Fi Protected Setup à ne pas fonctionner comme prévu.</warn>", //GW_WIFISC_CFG_CHANGED_WARNING
	"Redémarrer pendant la requête DNS", //ZM10
	"Impossible d'utiliser le canal 802.11b/g en mode 802.11a.", //GW_WLAN_11A_CHANNEL_INVALID
	"Règles du moteur QoS", //at_title_SERules
	"Le port admin. distant doit être compris entre 1 et 65535.", //YM176
	"NetBIOS autorise les hôtes LAN à rechercher tous les autres ordinateurs du réseau (par exemple, dans Voisinage réseau).", //KR81
	"Port TCP", //GW_NAT_TCP_PORT
	"La règle s'applique à un flux de messages pour lequel le numéro de port de l'hôte 2 figure dans la plage définie ici.", //YM155
	"Ce mode est rétrocompatible avec les périphériques non turbo (hérités). Il doit être activé lorsque certains périphériques du réseau sans fil ne sont pas des systèmes turbo mais prennent en charge les autres fonctions Super G mentionnées ci-dessus.", //help365
	"Portée NetBIOS", //bd_NETBIOS_SCOPE
	"Session abandonnée", //KR28
	"Filtre Web", //_webfilter
	"Paquets avec numéros d'agrégation incorrects", //YM33
	"Automatique", //YM76
	"Déverrouiller la configuration du point d'accès", //WIFISC_AP_SETUP_UNLOCKED
	"Pour le serveur virtuel (%s), impossible d'utiliser le port d'administration WAN HTTPS du routeur (%u)", //GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"Libérer", //LS313
	"Assistant Microsoft Windows Connect Now", //bwz_WCNWz
	"Serveur de connexion pour la recherche DNS", //ZM9
	"L'adresse IP réservée pour cette adresse MAC (%m) est déjà définie.", //GW_DHCP_SERVER_RESERVED_MAC_UNIQUENESS_INVALID
	"Paramètres de code PIN", //LY5
	"Pour la plupart des applications, les classificateurs de priorité garantissent que les priorités sont adaptées et aucune règle WISH spécifique n'est requise.", //YM87
	"Nom de filtre Ping WAN %s inexistant", //GW_NAT_WAN_PING_FILTER_INVALID
	"Si vous disposez de Windows XP SP2 minimum et d'Internet Explorer, vous pouvez utiliser cette option pour enregistrer les principales sections des paramètres de sécurité sans fil actuels du routeur sur votre PC avec la technologie Windows Connect Now (WCN). Ces paramètres sont ensuite disponibles pour la propagation vers d'autres périphériques sans fil.", //help835
	"(1..255)", //at_lowpriority
	"Nom requis pour le numéro %d de règle", //YM49
	"Vous ne pouvez pas ajouter une nouvelle adresse IP %v. Vous pouvez uniquement réutiliser les adresses IP des autres règles.", //GW_INET_ACCESS_POLICY_TOO_MANY_IP_INVALID
	"Adresse IP du serveur L2TP incorrecte", //YM112
	"H-Node  indique un état de fonctionnement hybride. Les éventuels serveurs WINS sont testés, puis la diffusion est effectuée sur le réseau local. Il s'agit généralement du mode privilégié si vous disposez de serveurs WINS configurés.", //KR90
	"Remarque : WCN enregistre uniquement quelques-uns des paramètres de sécurité sans fil. Lorsque vous utilisez WCN pour propager les paramètres vers d'autres périphériques sans fil, vous pouvez avoir à définir d'autres paramètres manuellement sur ces périphériques.", //help838
	"Activez seulement cette option si vous avez acheté votre propre Nom de domaine et vous êtes inscrits sur un fournisseur de service de DNS dynamique. Les paramètres suivants sont affichés quand l'option est activée.", //help892
	"Lorsque vous utilisez l'option PPPoE, vous devez enlever ou désactiver tous les logiciels client PPPoE sur vos ordinateurs.", //KR73
	"Il existe plusieurs niveaux de sécurité sans fil. Le niveau sélectionné dépend des fonctions de sécurité prises en charge par vos adaptateurs sans fil.", //wwl_intro_s3_2
	"Mesure incorrecte pour la route", //_r_alert5
	"<warn>Le nom de filtre Ping WAN %s n'existe plus. Le PING WAN va être désactivé.</warn>", //GW_NAT_WAN_PING_FILTER_WARNING
	"La valeur de fin est incorrecte pour l'adresse IP locale.", //YM53
	"Remarque : WCN définit uniquement quelques-unes des options sans fil. Vous devez accéder à la page des <a href='wireless.asp'>paramètres sans fil</a> pour définir d'autres options sans fil telles que le mode Super G et le débit de transmission.", //help215
	"WISH est l'abréviation de Wireless Intelligent Stream Handling, une technologie développée pour améliorer l'utilisation d'un réseau sans fil à l'aide de priorités définies pour le trafic des différentes applications.", //YM140
	"Le périphérique réseau a rejeté l'adresse du serveur DHCP %v. La présence de plusieurs serveurs DHCP sur un réseau peut provoquer des conflits d'adresse IP.", //GW_DHCPSERVER_REJECTED
	"Autorise le router à reconnaître les transferts HTTP pour un grand nombre des flux audio et vidéo courants et définit des priorités pour ces flux au-dessus des autres trafics. En général, les lecteurs multimédias numériques utilisent ces flux.", //YM142
	"Mot de passe incorrect", //GW_SMTP_PASSWORD_INVALID
	"La règle s'applique à un flux de messages pour lequel l'adresse IP d'un ordinateur figure dans la plage définie ici.", //YM152
	"Valeur de fin incorrecte pour la plage d'adresses IP du serveur DHCP", //LT119a
	"Si vous rencontrez des difficultés pour accéder à Internet via le routeur, revérifiez les paramètres définis sur cette page et, si nécessaire, contactez votre FAI.", //LW36
	"Algorithme de chiffrement utilisé pour sécuriser la communication des données. Le protocole TKIP (Temporal Key Integrity Protocol) fournit une méthode de génération de clés par paquet, basée sur le protocole WEP. La fonction AES (Advanced Encryption Standard) est une méthode de chiffrement hautement sécurisée qui utilise des blocs. Avec TKIP et AES, le routeur négocie le type de chiffrement avec le client et utilise AES en cas de disponibilité.", //help377
	"%s %s est incorrect(e).", //GW_NAT_PORT_TRIGGER_PORT_RANGE_INVALID
	"Clés WEP incorrectes", //YM121
	"Seuil de fragmentation incorrect", //YM29
	"La page de sessions WISH affiche tous les détails des sessions sans fil locales actives via le routeur (en cas d'activation de WISH). Une session WISH est une communication entre un programme ou une application sur un ordinateur à connexion sans fil côté LAN et un autre ordinateur quel que soit son mode de connexion.", //YM159
	"Numéro de port incorrect.", //YM120
	"SUPÉRIEUR", //wwl_BETTER
	"N'activez l'option DMZ qu'en dernier ressort. Si vous rencontrez des difficultés pour utiliser une application sur un ordinateur placé derrière le routeur, commencez par essayer douvrir les ports associés à lapplication dans les sections de <a href='adv_virtual.asp' onclick='return jump_if();'>serveur virtuel</a> ou <a href='adv_portforward.asp' onclick='return jump_if();'>redirection de port</a>.", //hhaf_dmz
	"Masque de sous-réseau PPTP incorrect", //YM106
	"Bloquer les sites non classés", //_aa_bsecure_block_unrated
	"Nom d'utilisateur Big Pond À indiquer", //GW_WAN_BIGPOND_USERNAME_INVALID
	"Par exemple, 192.168.0.101.", //KR76
	"Le serveur DHCP ne peut pas offrir davantage d'adresses car toutes les adresses disponibles sont utilisées. Augmentez le nombre d'adresses IP disponibles dans la configuration du serveur DHCP.", //GW_DHCPSERVER_EXHAUSTED
	"Adresse IP du serveur L2TP incorrecte : %v", //GW_WAN_L2TP_SERVER_IP_ADDRESS_INVALID
	"Le mot de passe WEP doit être de 13 caractères alphanumériques exactement.", //wwl_alert_pv5_2
	"Sous-réseau d'acheminement %v incorrect", //GW_ROUTES_SUBNET_INVALID
	"Médicaments", //_aa_bsecure_drugs
	"L'adresse IP ne peut pas être identique à l'adresse IP de réseau local du routeur.", //LW1
	"Un ordinateur du réseau n'a jamais renouvelé son attribution de %v et a perdu ses droits à utiliser cette adresse. Si le périphérique continue à utiliser cette adresse, il risque de provoquer des conflits d'adresse IP.", //GW_DHCPSERVER_EXPIRED
	"L'adresse IP %v doit figurer dans le sous-réseau LAN (%v).", //GW_INET_ACL_IP_ADDRESS_IN_LAN_SUBNET_INVALID
	"Diffusion uniquement (à utiliser si aucun serveur WINS n'est configuré)", //bd_NETBIOS_REG_TYPE_B
	"Finances", //_aa_bsecure_financial
	"La NAT transmet les demandes de connexions entrantes à un hôte côté LAN uniquement lorsque ces demandes viennent de l'adresse IP avec laquelle une connexion a été établie. Ainsi, l'application distante peut renvoyer les données via un port différent de celui utilisé lorsque la session sortante a été créée.", //YM135
	"Plage d'adresses IP de départ du serveur DHCP incorrecte", //LT119
	"Public", //_vs_public
	"B-Node  indique que SEULE la diffusion sur le réseau local est à utiliser. Ce paramètre est utile si aucun serveur WINS n'est disponible. Cependant, il est préférable d'essayer l'opération M-Node au préalable.", //KR93
	"Administration à distance de passerelle activée sur le port : %u", //GW_SECURE_REMOTE_ADMINSTRATION
	"Adresse IP et, le cas échéant, numéro de port de l'ordinateur qui a émis une connexion réseau.", //YM160
	"Adresse IP assignée", //LS423
	"L'adresse IP de passerelle L2TP %v doit figurer dans le sous-réseau WAN.", //GW_WAN_L2TP_GATEWAY_IN_SUBNET_INVALID
	"%s : pour l'adresse IP de l'hôte 1, la valeur de début (%v) doit être inférieure à la valeur de fin (%v)", //GW_WISH_RULES_HOST1_IP
	"Privé", //_vs_private
	"Ce paramètre n'a pas d'effet si l'option d'apprentissage des informations NetBIOS du WAN est activée.", //KR86
	"Adresse IP de serveur WINS secondaire", //bd_NETBIOS_SEC_WINS
	"pour l'adresse IP, la valeur de début doit être inférieure à celle de fin : %v-%v.", //GW_INET_ACL_START_IP_ADDRESS_INVALID
	"Authentification", //auth
	"Impossible d'arrêter le processus", //KR24
	"5 GHz", //KR17
	"Plage d'adresses IP de l'hôte 2", //YM84
	"Une règle de moteur QoS identifie un flux de messages spécifique et lui attribue une priorité.", //help88
	"L’activation de la gestion à distance vous permet ou à d’autres personnes de changer la configuration du routeur à partir d'un ordinateur sur l'Internet.", //hhta_en
	"Adresse IP PPPoE incorrecte", //YM103
	"En mode pont, le périphérique prend en charge plusieurs fonctions non disponibles sur les ponts ordinaires -- fonctions qui impliquent le côté WAN du routeur en amont.", //KR64
	"Conformément à la réglementation, vous ne pouvez pas utiliser les canaux 52-140 sans activer la détection radar.", //GW_WLAN_11A_DFS_CHANNEL_INVALID
	"Configuration sécurisée du Wifi", //LW4
	"Couche physique", //help645
	"En mode turbo 11a statique, le canal doit être défini sur l'une des valeurs suivantes : 42, 50, 58, 152 ou 160.", //GW_WLAN_11A_STATIC_TURBO_INVALID
	"Mode Super G™", //help358
	"Vous ne possédez pas les droits pour effectuer l'action indiquée.", //YM6
	"Sélection de catégories", //_aa_bsecure_categ_select
	"La priorité doit être un nombre compris entre 1 et 255 (inclus).", //YM58
	"Jeunesse (13-17)", //_aa_bsecure_age_youth
	"Cliquez sur l'<strong>assistant d'ajout de périphériques sans fil</strong> au réseau correspondant pour utiliser Wi-Fi Protected Setup à cette fin.", //LW17
	"Adresse IP cible finale incorrecte pour le filtrage de port", //YM18
	"WPA2-PSK/AES (ou WPA2 Personal)", //LT210
	"Temps d'inactivité incorrect (plage autorisée : %u-%u)", //GW_WAN_IDLE_TIME_INVALID
	"Adresse de groupe multidiffusion", //YM186
	"Sports", //_aa_bsecure_sports
	"Le nom '%s' est déjà utilisé.", //GW_QOS_RULES_NAME_ALREADY_USED
	"L'assistant suivant utilise la technologie Windows Connect Now de Microsoft pour configurer automatiquement les paramètres de votre routeur. Vérifiez l'exécution correcte de l'assistant Réseau sans fil de Microsoft sur votre ordinateur avant d'utiliser cette fonction.", //bwz_intro_WCNWz
	"Le groupe de serveurs DHCP DESTINÉ À %v ne figure pas dans le sous-réseau LAN %v.", //GW_DHCP_SERVER_POOL_TO_IN_SUBNET_INVALID
	"<warn>Le protocole H.323 a été automatiquement activé car une entrée de serveur virtuel créée le nécessite.</warn>", //GW_NAT_H323_ALG_ACTIVATED_WARNING
	"Isolement L2", //KR4
	"Principale adresse IP de serveur WINS incorrecte", //LT120y
	"Les paramètres réseau Wi-Fi Protected Setup ont été enregistrés.", //KR103
	"Téléphone IP Calista", //YM44
	"Si vous êtes un utilisateur avancé et si vous avez déjà configuré un routeur sans fil, cliquez sur l'option de <strong>configuration réseau sans fil manuelle</strong> pour entrer tous les paramètres.", //LW47
	"Échec de l'exportation du fichier de configuration WIFISC_AP_SET_APSETTINGS_COMPLETE,Définition des paramètres de point d'accès terminée (%s)", //GW_XML_CONFIG_GET_FAILED
	"Définition des paramètres du point d'accès par (%s) terminée", //WIFISC_AP_SET_APSETTINGS_COMPLETE
	"Longueur de la clé WEP", //wwl_WKL
	"Échec de la communication avec le routeur", //YM168
	"Le nom '%s' est déjà utilisé.", //GW_NAT_NAME_USED_INVALID
	"(valeur d'index de serveur incorrecte : %d)", //GW_DYNDNS_SERVER_INDEX_VALUE_INVALID
	"[AVERT]", //WARN
	"Entreprise", //LW23
	"Réseau Avançé", //ADVANCED_NETWORK
	"Un mot de passe PPTP DOIT être indiqué", //GW_WAN_PPTP_PASSWORD_INVALID
	"Restaurez le code PIN par défaut du routeur.", //LW59
	"Si vous avez activé la sécurité sans fil, notez soigneusement la clé ou la phrase secrète configurée. En effet, il sera nécessaire dentrer ces informations sur chaque périphérique sans fil à connecter à votre réseau sans fil.", //YM126
	"Activée", //_enabled
	"Interface incorrecte pour l'acheminement", //_r_alert4
	"Ajouter une station sans fil", //LY10
	"Pour l'adresse du serveur DHCP, la valeur de début (%v) est incorrecte pour le sous-réseau LAN (%v).", //GW_DHCP_SERVER_POOL_FROM_INVALID
	"Verrouiller la configuration du point d'accès", //WIFISC_AP_SETUP_LOCKED
	"Voulez-vous abandonner les modifications apportées à l'entrée de réservation ?", //YM91
	"Échec de l'activation du registre sélectionné. Raison : %s (code_err %u).", //WIFISC_AP_SET_SELECTED_REGISTRAR_FAIL
	"Aucune modification n'a été apportée. Procéder quand même à l'enregistrement ?", //_ask_nochange
	"Inconnu", //GW_NAT_UNKNOWN
	"En mode turbo dynamique 11a, le canal doit être défini sur l'une des valeurs suivantes : 40, 48, 56, 153 ou 161.", //GW_WLAN_11A_DYNAMIC_TURBO_INVALID
	"Remarque : même si un serveur NTP est activé, vous devez malgré tout choisir un fuseau horaire et définir les paramètres de l'heure d'été.", //YM163
	"Pour utiliser cette fonction, vous devez disposer d'un compte DNS dynamique auprès de lun des fournisseurs du menu déroulant.", //YM181
	"Droits insuffisants", //_cantapplysettings_1
	"Avertissements", //YM11
	"(8 à 63 caractères)", //wwl_wsp_chars_2
	"Principale adresse IP de serveur WINS", //bd_NETBIOS_PRI_WINS
	"Clé WEP par défaut à utiliser", //wwl_DWKL
	"Code PIN de périphérique sans fil", //KR44
	"obj_word + ' est en conflit avec un port de serveur virtuel.'", //TEXT056
	"Adresse IP de serveur incorrecte", //YM130
	"Sélectionner le serveur DNS dynamique", //KR99
	"La principale adresse IP de serveur WINS doit être indiquée si une adresse secondaire est indiquée.", //GW_DHCP_SERVER_PRIMARY_AND_SECONDARY_WINS_IP_INVALID
	"Valider le contrôle anti-spoof", //KR106
	"Le numéro de protocole du serveur virtuel %s, %d, doit être défini sur 0 ou compris entre 3 et 255.", //GW_NAT_VS_PROTOCOL_INVALID
	"Sélectionnez cette option pour configurer votre réseau manuellement", //KR52
	"Bienvenue dans l'assistant d'ajout de périphériques sans fil", //KR33
	"Vous devez être connecté en tant qu'admin. pour exécuter cette action.", //ZM23
	"Cet assistant va vous aider à connecter votre périphérique sans fil à votre routeur. Il vous guidera progressivement tout au long du processus de connexion de votre périphérique sans fil. Pour commencer, cliquez sur le bouton ci-dessous.", //LW40
	"Verrouiller les paramètres de sécurité sans fil", //LY4
	"Si vous êtes un utilisateur avancé et si vous avez déjà configuré un routeur, cliquez sur l'option de <strong>configuration de connexion Internet manuelle</strong> pour entrer tous les paramètres.", //LW34
	"Souhaitez-vous vraiment supprimer", //YM25
	"Adresse IP cible de départ incorrecte pour le filtrage de port", //YM15
	"Super G &trade; partie mode", //bwl_SGM
	"L'adresse du serveur Radius est incorrecte.", //GW_WLAN_80211X_RADIUS_INVALID
	"%s : le protocole, %u, doit être compris entre 0 et 257", //GW_WISH_RULES_PROTOCOL
	"Connexion", //LS316
	"Utilisateur déconnecté", //ZM15
	"<warn>Une réservation DHCP est désactivée car elle est en conflit avec l'adresse IP LAN des routeurs.</warn>", //GW_DHCP_SERVER_RESERVATION_DISABLED_IN_CONFLICT_WARNING
	"hôte à indiquer", //GW_DYNDNS_HOST_NAME_INVALID
	"Configuration du réseau sans fil manuelle", //LW42
	"L'adresse IP de la passerelle PPTP est incorrecte : %v", //GW_WAN_PPTP_GATEWAY_IP_ADDRESS_INVALID
	"Le fichier de configuration restauré est téléchargé vers le serveur.", //rs_intro_4
	"%s : pour l'adresse IP distante, la valeur de fin %v figure dans le sous-réseau LAN", //GW_QOS_RULES_REMOTE_IP_END_SUBNET
	"S/O", //_NA
	"L'adresse IP de la passerelle est, le cas échéant, l'adresse IP du routeur utilisée pour atteindre la cible indiquée.", //hhav_r_gateway
	"[INFO]", //INFO
	"Métrique", //help112
	"Remarque : Certaines mises à jour de microprogramme restaurent les options de configuration par défaut. Avant d'effectuer une mise à jour, assurez-vous de sauvegarder la configuration actuelle depuis l'écran.\n Souhaitez-vous toujours procéder à la mise à niveau ?", //tf_msg_FWUgReset
	"Apprendre les informations NetBIOS du WAN", //bd_NETBIOS_WAN
	"Forcer l'intervalle court pour les clients 11N", //aw_igslot
	"(par défaut en l'absence de correspondance)", //ZM2
	"Vous n'avez pas les droits nécessaires pour exécuter l'action indiquée.", //LT7
	"Définir le registrar sélectionné", //WIFISC_AP_SET_SELECTED_REGISTRAR
	"Lorsque les préparations nécessaires sont terminées, la technologie WCN propage les paramètres de réseau sans fil du PC vers le routeur. Ensuite, vous devez réinitialiser le routeur pour que les paramètres soient pris en compte.", //help214
	"Les deux", //at_Both
	"Jour de la semaine", //ZM22
	"Restaurer les paramètres par défaut", //help_ts_rfd
	"Si vous disposez de Windows XP SP2 minimum et d'Internet Explorer, vous pouvez utiliser la technologie Windows Connect Now (WCN) pour configurer les paramètres de sécurité sans fil du routeur.", //help209
	"pour le port cible, la valeur de début doit être comprise entre 0 et 65535 (inclus).", //YM70
	"UPnP a changé l'entrée VS %v <-> %v:%d <-> %v:%d %s en %s", //GW_UPNP_IGD_PORTMAP_VS_CHANGE
	"La partie filtre Web est l'une des deux méthodes destinées à indiquer les sites Web à autoriser. Vous pouvez également utiliser le service de contrôle parental Sentinel pour indiquer de grandes catégories de sites Web et éviter d'entrer chacune des URL des sites Web autorisés. Pour davantage d'informations sur le service Sentinel, reportez vous aux <a href='../Tools/Sentinel.shtml'>outils &rarr; partie Sentinel</a>.", //help143s
	"Ce mode n'est pas rétrocompatible avec les périphériques non turbo (hérités). Il doit uniquement être activé lorsque tous les périphériques du réseau sans fil sont de type turbo statique.", //help363
	"Forum Web", //_aa_bsecure_web_newsgroup
	"Principale adresse de serveur DNS incorrecte", //YM128
	"%s de %s ne peut pas être vide.", //GW_NAT_PORT_TRIGGER_PORT_RANGE_EMPTY_INVALID
	"La technologie StreamEngine&trade; s'applique aux supports multimédia qui passent entre le côté réseau étendu du routeur en amont et les clients du pont.", //KR72
	"Mot de passe ou clé", //td_PWK
	"Plage d'adresses IP de l'hôte 1", //YM82
	"Délai d'authentification incorrect.", //YM119
	"Le pont a toujours la capacité à analyser le trafic sur le côté WAN du routeur en amont de façon à déterminer la vitesse de sa connexion WAN.", //KR70
	"L'adresse IP et, si approprié, le numéro de port de l'ordinateur avec lequel une connexion réseau a été établie.", //YM161
	"La taille du groupe de serveurs DHCP est trop grande (elle ne doit pas dépasser 256 adresses).", //GW_DHCP_SERVER_POOL_SIZE_INVALID
	"Établi", //_sdi_s4b
	"Recherche DNS  Serveur d'authentification", //ZM8
	"Adresse DNS secondaire incorrecte", //YM129
	"Les touches ASCII 64 bits ont 5 caractères de long (DMODE est une chaîne valide de 5 caractères pour le chiffrement 64 bits).", //help370
	"Le verrouillage des paramètres de sécurité sans fil empêche toute modification des paramètres par tout nouveau registre externe utilisant son PIN. Les périphériques peuvent toujours être ajoutés au réseau sans fil à l'aide de WPS. Il est toujours possible de modifier les paramètres réseau sans fil avec la <a href='wireless.asp' shape='rect'>configuration manuelle du réseau sans fil</a>, l'<a href='wizard_wlan.asp' shape='rect'>assistant de configuration de réseau sans fil</a> ou un registre externe pour l'administration des réseaux locaux sans fil (WLAN).", //LY29
	"Attention pendant l'écriture du fichier de configuration : %s", //GW_XML_CONFIG_WRITE_WARN
	"Le nom %s est déjà utilisé.", //GW_FIREWALL_NAME_INVALID
	"%s : La valeur de début de l'adresse IP de l'hôte 2 (%v) doit être inférieure à celle de fin (%v)", //GW_WISH_RULES_HOST2_IP
	"Page de produits", //TA2
	"Connecter", //LS314
	"Type de trafic", //_vs_traffictype
	"La valeur du délai d'attente ne peut pas dépasser 8760.", //GW_DYNDNS_TIMEOUT_TOO_BIG_INVALID
	"Entrez le PIN du périphérique sans fil, puis cliquez sur le bouton Connecter ci-dessous.", //wps_p3_4
	"Sélectionnez cette option si le périphérique sans fil prend en charge la fonction WPS.", //KR51
	"L'adresse IP de passerelle PPTP %v doit se situer dans le sous-réseau WAN.", //GW_WAN_PPTP_GATEWAY_IN_SUBNET_INVALID
	"Cliquez sur le bouton d'% %enregistrement dans Windows Connect Now% % et la technologie WCN va capturer les paramètres réseau sans fil à partir de votre routeur et les enregistrer sur votre PC.", //help837
	"Commencez par sélectionner un nom d'application.", //TEXT052
	"Ouvert", //OPEN
	"Actualités", //_aa_bsecure_news
	"Mettre à jour", //YM34
	"Sans fil Avançé", //_advwls
	"La <warn>réservation DHCP %v a été désactivée parce que le groupe DHCP est trop petit.</warn>", //GW_DHCP_SERVER_RESERVATION_DISABLED_OUT_OF_POOL_WARNING
	"Les paramètres de filtre MAC vont bloquer toutes les machines. Cela n'est pas autorisé.", //GW_MAC_FILTER_ALL_LOCKED_OUT_INVALID
	"Clé WEP 4", //_wepkey4
	"facultatif", //LT124
	"Moteur de recherche", //_aa_bsecure_search_engine
	"WPA uniquement", //KR47
	"Si vous choisissez l'option de sécurité WEP, ce périphérique fonctionnera <strong>UNIQUEMENT</strong> en <strong>mode sans fil hérité (802.11B/G)</strong>. Vous N'obtiendrez <strong>PAS</strong> les performances 11N car WEP n'est pas pris en charge par la spécification  Draft 11N.", //bws_msg_WEP_3
	"<warn>L'adresse de serveur d'e-mail est en conflit avec l'adresse LAN du routeur  l'e-mail va être désactivé.</warn>", //GW_SMTP_LAN_ADDRESS_CONFLICT_WARNING
	"Le mode IP LAN est incorrect.", //GW_LAN_IP_MODE_INVALID
	"Le serveur Big Pond spécifié n'est pas un nom de domaine correct ou une adresse IP correcte.", //GW_WAN_BIGPOND_SERVER_NOTSTD15
	"Le seuil de fragmentation doit se situer entre 256 et 2346.", //GW_WLAN_FRAGMENT_THRESHOLD_INVALID
	"Nom de domaine incorrect", //GW_LAN_DOMAIN_NAME_INVALID
	"Nom de périphérique incorrect", //GW_LAN_DEVICE_NAME_INVALID
	"Chevauchement de session détecté", //_wifisc_overlap
	"L'assistant va afficher les paramètres du réseau sans fil pour vous guider à travers la configuration manuelle, vous inviter à entrer le PIN du périphérique ou vous demander d'appuyer sur le bouton de configuration sur votre périphérique. Si le périphérique prend en charge WPS (Wi-Fi Protected Setup) et est équipé d'un bouton de configuration, vous pouvez l'ajouter au réseau en appuyant sur ce bouton, puis sur le routeur dans les 60 secondes. Si le périphérique a été ajouté au réseau, le voyant d'état du routeur clignote trois fois.", //LW62
	"Processus arrêté. Vous pouvez cliquer sur le bouton d'annulation ci-dessous pour revenir au début de la page de l'assistant et redémarrer le processus.", //KR23
	"Pornographie", //_aa_bsecure_pornography
	"Le nom ne peut pas être une chaîne vide.", //GW_NAT_NAME_INVALID
	"Nombre de clients dynamiques DHCP", //bd_title_clients
	"Adresse IP du serveur PPTP incorrecte", //YM108
	"L'adresse IP cible de fin ne doit pas être dans le sous-réseau LAN", //YM19
	"Enregistrement de STA avec MAC (%m) dans", //WIFISC_AP_PROXY_PROCESS_COMPLETE
	"L'enregistrement %s est un double de %s.", //GW_NAT_ENTRY_DUPLICATED_INVALID
	"%s [%s:%s] est en conflit avec %s [%s:%s] sur différentes adresses IP.", //GW_NAT_PORT_FORWARD_CONFLICT_INVALID
	"Voulez-vous vraiment mettre à jour", //YM38
	"Serveur NTP non configuré", //tt_alert_nontp
	"Configuration sécurisée du Wifi", //LY2
	"Non-concordance PIN (1re moitié) détectée", //KR29
	"Session terminée", //KR31
	"Échec d'initialisation", //_init_fail
	"(la valeur de début du port source doit se situer entre 0 et 65535 inclus).", //YM68
	"Adresse MAC", //sd_macaddr
	"Mode port WAN", //KR12
	"Le protocole WEP est une méthode de chiffrement des données pour les communications sans fil, visant à fournir le même niveau de protection qu'un réseau câblé. Le WEP n'est pas aussi sûr que le chiffrement WPA. Pour pouvoir accéder à un réseau WEP, vous devez connaître la clé. La clé est une chaîne de caractères créée par vos soins. Quand vous utilisez le WEP, vous devez déterminer le niveau de chiffrement. C' est lui qui détermine la longueur de la clé. Un chiffrement sur 128  bits requiert une clé plus longue qu'un chiffrement sur 64  bits. Les clés sont définies en saisissant une chaîne au format hexadécimal (caractère 0 à 9 et A à F) ou au format ASCII (American Standard Code for Information Interchange, caractères alphanumériques). Le format ASCII vous permet de saisir une chaîne plus facile à mémoriser. Cette chaîne ASCII est ensuite convertie au format hexadécimal pour être utilisée sur le réseau. Vous pouvez définir jusqu'à quatre clés, ce qui vous permet d'en changer facilement. Une clé définie par défaut est sélectionnée et utilisée sur le réseau.", //help366
	"Point d'accès enregistré dans le registre (%s) via %s", //WIFISC_AP_REGISTRATION_COMPLETE
	"Gain maximum TPC", //aw_TPC
	"Adresse MAC du point d'accès WDS", //aw_WDSMAC
	"La valeur de fin du port distant doit se situer entre 0 et 65535 (inclus).", //YM62
	"Protection supplémentaire pour les réseaux sans fil 11b de voisinage. Désactivez cette option pour réduire l'impact négatif des réseaux sans fil hérités sur les performances 802.11ng.", //aw_erpe_h
	"Mode de reconnexion incorrect", //GW_WAN_RECONNECT_MODE_INVALID
	"Suppression des paramètres de point d'accès terminée (%s)", //WIFISC_AP_DEL_APSETTINGS_COMPLETE
	"Seuls les comptes admin. peuvent modifier les paramètres de sécurité.", //LW15
	"Si vous êtes débutant en matière de gestion de réseau sans fil et si vous n'avez jamais configuré de routeur, cliquez sur l'<strong>assistant de configuration de connexion Internet</strong> pour que le routeur vous aide à mettre votre réseau en service en quelques étapes simples.", //LW33
	"Exécuté. Pour ajouter un autre périphérique, cliquez sur le bouton d'annulation ci-dessous ou sur le bouton de vérification de l'état sans fil.", //KR27
	"Contrôle le filtrage des points d'extrémité pour les paquets du protocole UDP.", //YM138
	"%s [%s:%d] -> %v/%d en conflit avec %s [%s:%d] -> %v:%d.", //GW_NAT_VS_PORT_CONFLICT_INVALID
	"Principale adresse IP de serveur WINS", //bd_NETBIOS_WINS_1
	"Étape 5 : catégories Sentinel", //_aa_wiz_s6_title
	"Règles WISH", //YM77
	"Moteur QoS", //YM48
	"Adresse IP de réservation incorrecte", //YM89
	"La clé prépartagée doit être totalement en caractères HEX si la longueur est de 64.", //GW_WLAN_WPA_PSK_HEX_STRING_INVALID
	"Adresse IP WAN incorrecte : %v", //GW_WAN_WAN_IP_ADDRESS_INVALID
	"Voulez-vous annuler toutes les modifications apportées à cette page ?", //LS4
	"Le fournisseur du service DNS dynamique spécifié n'est pas pris en charge.", //KR98
	"Arrière-plan (le moins urgent).", //YM148
	"Auto (WPA ou WPA2)", //bws_WPAM_2
	"Si vous souhaitez être averti au moment de la publication de firmware, cochez la case en regard de l'option correspondante de <span class='option'>notification par e-mail</span>.", //help877a
	"Ajouter/Mettre à jour", //KR56
	"Nom d'hôte", //LS424
	"L'adresse de serveur DHCP %v a été refusée par le périphérique réseau. Vérifiez si votre réseau présente des conflits d'adresse IP.", //GW_DHCPSERVER_DECLINED
	"Aucun jour n'est sélectionné.", //GW_SCHEDULES_DAY_INVALID
	"UDP", //GW_NAT_UDP
	"Impossible d'établir une connexion avec le serveur d'e-mail.", //IPSMTPCLIENT_CANNOT_CREATE_CONNECTION
	"Tout vérifier", //_aa_check_all
	"Renouveler", //LS312
	"Adresse IP incorrecte", //KR2
	"Protocole", //_vs_proto
	"L'adresse cible fournie (%s) est incorrecte.", //GW_SMTP_TO_ADDRESS_INVALID
	"Échec d'enregistrement du point d'accès dans le registre (%s) via %s. Raison : %s (code_err %u)", //WIFISC_AP_REGISTRATION_FAIL
	"Le nom '%s' est déjà utilisé.", //GW_WISH_RULES_NAME_ALREADY_USED
	"Lorsqu'une application LAN qui utilise un protocole autre qu'UDP, TCP ou ICMP initie une session Internet, la NAT du routeur peut suivre une telle session même si elle ne reconnaît pas le protocole. Cette fonction est utile parce qu'elle autorise certaines applications (et plus important une connexion VPN unique à un système hôte distant) sans nécessiter de passerelle ALG.", //LW48
	"Valeur de début incorrecte pour l'adresse IP distante.", //YM54
	"PIN actuel", //LW9
	"Cet assistant vous aide à configurer votre réseau sans fil. Il vous guide tout au long de la procédure de configuration et de sécurisation de votre réseau sans fil.", //LW41
	"Activez le balayage automatique du canal", //ebwl_AChan
	"Le seuil RTS doit se situer entre 1 et 2347.", //GW_WLAN_RTS_THRESHOLD_INVALID
	"Un mot de passe L2TP DOIT être spécifié.", //GW_WAN_L2TP_PASSWORD_INVALID
	"Certaines modifications de la configuration influent sur d'autres paramètres du système. Ces modifications peuvent avoir des conséquences négatives et générer des avertissements dont vous devez avoir connaissance. Un avertissement peut indiquer qu'une fonction a été modifiée, voire désactivée, pour s'adapter aux nouvelles conditions de fonctionnement.", //YM12
	"Lutilisateur se déconnecte.", //ZM14
	"Dans ce cas, le terme &quot;port&quot; fait référence aux connecteurs Ethernet sur le périphérique.", //KR60
	"Seuil RTS incorrect", //YM28
	"La programmation nest pas correcte.", //YM184
	"Pour configurer la technologie Windows Connect Now de Microsoft à l'aide de nos assistants Web, cliquez sur le bouton d'aide à la configuration ci-dessous.", //int_intro_WCNWz7
	"Clé partagée", //bws_Auth_2
	"Le fichier de configuration restauré nest pas correct. Vous avez peut-être restauré un fichier non destiné à ce périphérique ou le fichier restauré est peut-être corrompu.", //rs_intro_1
	"Protocole utilisé par les messages.", //help92
	"Les deux", //GW_NAT_BOTH
	"Restauration effectuée", //rs_success
	"(GMT+01:00) Budapest, Vienne, Prague, Varsovie", //up_tz_29b
	"Jour", //day
	"<warn>Désactivation du serveur DHCP car le sous réseau LAN nest pas adapté</warn>", //GW_DHCP_SERVER_DISABLED_WARNING
	"Mot de passe", //_password
	"Adresse MAC %m incorrecte.", //GW_INET_ACCESS_POLICY_MAC_INVALID
	"Configuration sécurisée du Wifi", //LW2
	"Assigner toute adresse IP non utilisée dans la plage des adresses IP disponibles pour le LAN.", //KR75
	"Échec décriture du fichier de configuration : %s", //GW_XML_CONFIG_WRITE_FAILED
	"Activer WISH", //YM73
	"Le nom '%s' est déjà utilisé.", //GW_WISH_RULES_NAME_USED_INVALID
	"La taille du groupe de serveurs DHCP est trop grande pour le sous-réseau LAN %v.", //GW_DHCP_SERVER_POOL_SIZE_IN_SUBNET_INVALID
	"Taille maximum dagrégation", //aw_AS
	"Il sagit de la liste de toutes les communications actives impliquant des clients sans fil sur le réseau local.", //YM171
	"IP réservée %v en conflit avec ladresse IP LAN configurée.", //GW_DHCP_SERVER_RESERVED_IP_NOT_LAN_IP_INVALID
	"Le serveur virtuel %s ne peut pas utiliser le port d'administration WAN HTTP du routeur (%u)", //GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT
	"Le champ du masque réseau identifie la portion de ladresse IP cible utilisée.", //hhav_r_netmask
	"LISTE DES SERVEURS VIRTUELS", //vs_vslist
	"PARE-FEU IPV6", //if_iflist
	"Notez que certaines de ces options peuvent interagir avec dautres restrictions de ports. Le filtrage indépendant de point d'extrémité a la priorité sur les filtres entrants ou les programmations. En conséquence, il est possible quune demande de session entrante liée à une session sortante entre via un port en dépit dun filtre entrant actif sur ce port. Cependant, les paquets seront rejetés comme prévu s'ils sont envoyés vers des ports bloqués (que ces ports soient bloqués par une programmation ou par un filtre entrant) pour lesquels il nexiste pas de session active. Avec le filtrage restreint de port et dadresse, les filtres entrants et les programmations fonctionnent de façon précise mais empêchent un certain niveau de connectivité. Ce filtrage peut donc nécessiter lutilisation de déclencheurs de ports, de serveurs virtuels ou de redirection de port afin d'ouvrir les ports nécessaires à lapplication. Le filtrage restreint dadresse offre un compromis qui évite les problèmes lors de la communication avec certains autres types de routeurs NAT (routeurs NAT symétriques en particulier) mais laisse les filtres entrants et laccès programmé fonctionner comme prévu.", //YM137
	"Éléments de classification de priorité", //YM74
	"L'adresse IP du serveur Syslog %v nest pas dans le sous-réseau LAN.", //GW_SYSLOG_ADDRESS_IN_SUBNET_INVALID
	"Activez cette option si vous avez un serveur syslog qui fonctionne actuellement sur votre réseau local et que vous souhaitez lui envoyer les messages des journaux.", //help858
	"L'adresse MAC est déjà utilisée : %s", //GW_MAC_FILTER_MAC_UNIQUENESS_INVALID
	"Bouton de commande", //KR40
	"Le filtre d'adresse MAC ne peut pas être l'adresse NULL : %m", //GW_MAC_FILTER_NULL_MAC_INVALID
	"32 Ko", //aw_32
	"Le sous-réseau WAN est en conflit avec le sous-réseau LAN.", //GW_WAN_LAN_SUBNET_CONFLICT_INVALID
	"Activée/Configurée", //LW66
	"Échec de suppression des paramètres de points d'accès (%s). Raison %s (code_err %u).", //WIFISC_AP_DEL_APSETTINGS_FAIL
	"(13 caractères ou 26 chiffres hexadécimaux)", //wwl_wsp_chars_1
	"Les serveurs WINS stockent les informations sur les hôtes réseau ainsi autorisés à s'enregistrer ainsi qu'à en rechercher d'autres disponibles (par exemple, pour l'utilisation dans Voisinage réseau).", //KR85
	"Taille MTU incorrecte", //YM115
	"Plage de ports de l'hôte 1", //YM83
	"128 bit", //wwl_128bits
	"Lorsque des conflits de paquets sans fil sont en nombre excessif, les performances sans fil peuvent être améliorées à l'aide du protocole RTS/CTS (Request to Send/Clear to Send).", //LW51
	"Vous devez entrer une valeur numérique située entre 0 et 8760 (inclus).", //YM178
	"Cultes", //_aa_bsecure_cults
	"Interdit", //YM5
	"Vérifications de mise à jour de firmware", //KR65
	"Des mises à jour de firmware paraissent régulièrement pour améliorer les performances de votre routeur et y ajouter de nouvelles fonctions. Si vous rencontrez un problème avec une fonction spécifique du routeur, vérifiez si un firmware mis à jour est disponible pour votre routeur.", //ZM17
	"Procédez à l'<strong>activation</strong> si d'autres périphériques sans fil à inclure dans le réseau local prennent en charge Wi-Fi Protected Setup.", //LW14
	"Enregistrer dans Windows Connect Now", //ta_wcn_bv
	"Le serveur virtuel %s ne peut pas utiliser l'adresse IP %v du routeur.", //GW_NAT_VS_IP_ADDRESS_CAN_NOT_MATCH_ROUTER
	"Le calendrier « %s » ne peut pas être supprimé ni renommé car il est en cours d'utilisation.", //GW_SCHEDULES_IN_USE_INVALID
	"Clé WEP 3", //wepkey3
	"Estimation de débit Internet", //KR69
	"Discussion sur AIM", //YM43
	"ICQ", //YM45
	"Le nom d'utilisateur est incorrect.", //GW_SMTP_USERNAME_INVALID
	"Super G avec turbo statique", //help362
	"Si vous souhaitez être averti au moment de la publication de firmware, cochez la case en regard de l'option correspondante de notification par e-mail.", //tf_intro_FWChA
	"ORDINATEUR DE BUREAU DISTANT", //_remotedesktop
	"Paramètres de code PIN", //LW7
	"Les modes Super G turbo doivent utiliser le canal 6 pour la communication. Pour Super G avec turbo statique, le <span class='option'>mode 802.11</span> doit être défini sur 802.11g. Pour un fonctionnement correct, le seuil RTS et le seuil de fragmentation sur la page des paramètres <a href='adv_wlan_perform.asp'>avancés &rarr; partie sans fil</a> doivent avoir leur valeur par défaut.", //help359
	"Configurez l'adresse IP du serveur WINS préféré.", //KR84
	"DTIM doit se situer entre 1 et 255.", //YM30
	"Plage de ports locaux", //at_LoPortR
	"Le groupe de serveurs DHCP DE %v n'est pas dans le sous-réseau LAN %v.", //GW_DHCP_SERVER_POOL_FROM_IN_SUBNET_INVALID
	"Le filtre d'adresse MAC ne peut pas être au format d'adresse multidiffusion : %m", //GW_MAC_FILTER_MULTICAST_MAC_INVALID
	"<warn>Échec d'initialisation e-mail</warn>", //GW_SMTP_INIT_FAILED_WARNING
	"Serveur DHCP arrêté", //GW_DHCPSERVER_STOP
	"Pour protéger votre confidentialité, configurez les fonctions de sécurité sans fil avec le mode de sécurité sans fil. Ce périphérique prend en charge trois modes de sécurité sans fil dont : WEP, WPA-Personal et WPA-Enterprise. WEP est la norme d'origine pour le chiffrement sans fil. WPA fournit un niveau plus élevé de sécurité. WPA-Personal ne nécessite pas de serveur d'authentification. L'option WPA-Enterprise nécessite un serveur d'authentification RADIUS.", //help350
	"L'adresse DMZ %v n'est pas autorisée.", //GW_NAT_DMZ_NOT_ALLOWED_INVALID
	"Lorsque cette option est activée, le routeur cherche automatiquement à définir des priorités pour les flux de trafic qu'il ne reconnaît pas selon le fonctionnement de ces flux. Cela a pour effet d'annuler la priorité des flux présentant des caractéristiques de transfert de masse tels que les transferts de fichiers et de laisser le trafic interactif tel que les jeux ou la voix sur IP (VoIP) s'exécuter selon une priorité normale.", //YM143
	"Échec d'importation du fichier de configuration numéro %u.", //GW_XML_CONFIG_SET_FAILED
	"%s %s de %s ne doit pas contenir de nombres en double.", //GW_NAT_PORT_DUP_INVALID
	"secondes pour connecter votre périphérique sans fil. Si vous voulez arrêter le processus, cliquez sur le bouton Annuler ci-dessous.", //KR46
	"Étape 1 : Sélectionnez la méthode de configuration du réseau sans fil", //KR35
	"Un mot de passe Big Pond DOIT être spécifié.", //GW_WAN_BIGPOND_PASSWORD_INVALID
	"Le protocole doit être spécifié.", //YM57
	"Pour appliquer ces modifications, vous devez redémarrer le routeur. Vous pouvez réinitialiser maintenant ou apporter d'autres modifications et réinitialiser plus tard.", //KR104
	"L'adresse e-mail de l'émetteur est de format incorrect.", //IPSMTPCLIENT_MSG_WRONG_SENDER_ADDR_FORMAT
	"FERMER LA SESSION", //LS317
	"Les mots de passe entrés ne concordent pas.", //YM102
	"Lorsque WDS est activé, ce point d'accès fonctionne comme un répétiteur sans fil qui peut communiquer sans fil avec d'autres PA via les liens WDS. Notez que le WDS n'est pas compatible avec le WPA ; les deux fonctions ne peuvent pas être utilisées en même temps. Un lien WDS est bidirectionnel. Donc, ce PA doit connaître l'adresse MAC (crée le lien WDS) de l'autre PA et ce dernier doit posséder un lien WDS redirigé vers le premier PA.", //help188
	"L'adresse IP n'est pas correcte.", //_logsyslog_alert1
	"Adresse MAC incorrecte", //KR3
	"Haine", //_aa_bsecure_hate
	"Impossible d'utiliser le canal 802.11a en mode 802.11b/g.", //GW_WLAN_11BG_CHANNEL_INVALID
	"Estimation du débit terminée", //RATE_ESTIMATOR_RATE_COMPLETED
	"La clé WEP doit être exactement de 26 caractères hexadécimaux (0 à 9 ou A à F).", //wwl_alert_pv5_3
	"Limite dagrégation", //aw_aggr
	"Démarré", //_wifisc_addstart
	"Spécifie linterface -- LAN ou WAN -- que le paquet IP doit utiliser pour transiter hors du routeur lorsque cet acheminement est utilisé.", //help111
	"%s : la valeur de début de l'adresse IP distante %v est dans le sous-réseau LAN", //GW_QOS_RULES_REMOTE_IP_START_SUBNET
	"Valeur de fin incorrecte pour le filtre du port cible", //YM22
	"Impossible dutiliser une adresse MAC multidiffusion dans WDS.", //GW_WLAN_WDS_MAC_ADDR_INVALID
	"Réinitialiser le PIN sur la valeur par défaut", //LW10
	"Cette zone de lécran reflète les paramètres de configuration de la page de <a href='wireless.asp'>configuration &rarr; partie paramètres sans fil</a>. L<span class='option'>adresse MAC</span> est lidentificateur assigné par défaut de la carte sans fil.", //LT291
	"Dans cette section, vous pouvez définir les règles WISH.", //YM156
	"Adolescents (9-12)", //_aa_bsecure_age_ado
	"Sélectionnez cette option si vos adaptateurs sans fil ne prennent pas en charge WPA", //wwl_text_good
	"%s : la priorité, %d, doit se situer entre 1 et 255.", //GW_QOS_RULES_PRIORITY_RANGE
	"Selon calendrier", //te_OnSch
	"Web Mail", //_aa_bsecure_web_mail
	"Vérifiez que les points d'accès sont configurés avec le même numéro de canal.", //help188b
	"L'adresse IP de début (%v) de %s ne doit pas se situer dans le sous-réseau LAN (%v).", //GW_INET_ACL_START_IP_ADDRESS_IN_LAN_SUBNET_INVALID
	"Mise en forme du trafic WAN", //at_title_Traff
	"Spécifie une moitié du lien WDS. Lautre point d'accès doit également avoir ladresse MAC de ce point d'accès pour créer le lien WDS de retour vers ce point d'accès.", //help189
	"Radar sans fil détecté  Passage au canal %d", //GW_WIRELESS_SWITCH_CHANNEL
	"Un serveur Big Pond DOIT être spécifié.", //GW_WAN_BIGPOND_SERVER_INVALID
	"Erreur danalyse du fichier de configuration autour de la ligne %u caractère %u.", //GW_XML_CONFIG_SET_PARSE
	"Activez <strong> WMM </strong> peut aider à contrôler la latence et le vacillement lors de la transmission de contenu multimédia à travers une connexion sans fil.", //hhaw_wmm
	"Cette zone de l'écran affiche les paramètres de configuration depuis la page <a href=\"wireless.asp\">Configuration &rarr; Paramètres sans fil</a>, la page <a href=\"adv_wish.asp\">Avancé&rarr; WISH</a> et la page <a href=\"../Advanced/Protected_Setup.shtml\">Avancé &rarr; WPS</a>. L'<span class=\"option\">adresse MAC</span> correspond à l'identifiant attribué en usine à votre carte sans fil.", //LT290wifisc
	"Le nom de règle ne peut pas être une chaîne vide.", //GW_FIREWALL_RULE_NAME_INVALID
	"Programmation", //GW_NAT_SCHEDULE
	"Spécifie le prochain saut si cet acheminement est utilisé. Une passerelle de 0.0.0.0 implique quil nexiste pas de prochain saut et ladresse IP qui concorde est directement associée au routeur sur linterface spécifiée : LAN ou WAN.", //help109
	"Le mode RIP est incorrect.", //GW_LAN_RIP_MODE_INVALID
	"Lémetteur sans fil va commencer à envoyer des trames RTS (et attendre pour les trames CTS) lorsque la taille de trame de données en octets est supérieure au seuil RTS.", //LW52
	"Fenêtres contextuelles", //_aa_bsecure_popups
	"Le mode WPA2 uniquement ne prend pas en charge TKIP.", //GW_WLAN_WPA_WPA2_TKIP_INVALID
	"2.4 GHz", //KR16
	"Serveur virtuel", //_vs_title
	"PARE-FEU IPv6", //_if_title
	"Un nom d'utilisateur PPPoE DOIT être spécifié.", //GW_WAN_PPPOE_USERNAME_INVALID
	"Masque de sous-réseau PPTP %v incorrect.", //GW_WAN_PPTP_SUBNET_INVALID
	"Le format de la portée NetBIOS est incorrect.", //GW_DHCP_SERVER_NETBIOS_SCOPE_INVALID
	"Le mode adresse IP statique est encore activé. Pour cette raison, aucun bouton daction nest disponible.", //KR94
	"WISH", //YM63
	"Passerelle", //help108
	"Cette programmation est déjà utilisée dans %s.", //GW_SCHEDULES_DUPLICATED_INVALID
	"WPA uniquement", //bws_WPAM_1
	"Le port public doit se trouver dans la plage (1-65535) du serveur virtuel", //KR11
	"Si vous disposez déjà d'un serveur DHCP sur votre réseau ou utilisez des adresses IP statiques sur tous les périphériques du réseau, désélectionnez la case d'<strong>activation du serveur DHCP</strong>.", //LW45
	"IP distante finale", //KR6
	"Type denregistrement NetBIOS incorrect", //GW_DHCP_SERVER_NETBIOS_TYPE_INVALID
	"Jeux", //_aa_bsecure_games
	"Sélectionnez cette option pour configurer votre périphérique sans fil manuellement.", //KR42
	"Temps dinactivité incorrect.", //YM104
	"Tickets", //_aa_bsecure_tickets
	"Sélectionnez cette option si votre périphérique sans fil prend en charge les codes PIN", //KR39
	"Mode mixte (diffusion puis point à point)", //bd_NETBIOS_REG_TYPE_M
	"Saisissez un nom d'hôte ou une adresse IP ci-dessus et cliquez sur 'Ping'", //tsc_pingt_msg1
	"Suppression de l'entrée UPnP %v <-> %v:%d %s", //GW_UPNP_IGD_PORTMAP_DEL
	"Adresse IP de la passerelle L2TP incorrecte", //YM111
	"Déconnecter", //LS315
	"Longueur de clé incorrecte. Elle doit avoir entre 8 et 64 caractères.", //GW_WLAN_WPA_PSK_LEN_INVALID
	"Autoriser n'importe quel utilisateur du réseau étendu à accéder à la fonction apparentée.", //help178
	"Obtention de la liste des sessions actives. Veuillez patienter...", //YM167
	"Les touches ASCII 128 bits ont 13 caractères de long (2002HALOSWIN1 est une chaîne valide de 13 caractères pour le chiffrement 128 bits).", //help371
	"Anarchie", //_aa_bsecure_anarchy
	"Redémarrer plus tard", //YM4
	"Criminalité", //_aa_bsecure_criminal_skills
	"Des avertissements ont été déclenchés du fait des changements de configuration.\n Le système est incapable de générer une liste de ces avertissements immédiatement, mais va réessayer.", //YM188
	"Les options de filtrage de point d'extrémité NAT contrôlent la façon dont la NAT du routeur gère les demandes de connexions entrantes aux ports déjà utilisés.", //YM133
	"La valeur de début du port local doit se situer entre 0 et 65535 (inclus).", //YM59
	"Manuellement", //_aa_bsecure_manually
	"Ladresse e-mail nest pas configurée.", //YM169
	"À l'aide de cette section, vous pouvez configurer les paramètres réseau internes de votre routeur. L'adresse IP configurée ici est celle que vous utilisez pour accéder à l'interface de gestion Web. Si vous la modifiez, il sera peut-être nécessaire d'ajuster les paramètres réseau de votre PC pour pouvoir accéder à nouveau au réseau.", //YM97
	"Enfants (0-8)", //_aa_bsecure_age_child
	"WPA correspond à un ancien standard. Sélectionnez cette option si les clients à utiliser avec le routeur prennent uniquement en charge lancien standard. WPA2 est la nouvelle mise en oeuvre du standard de sécurité plus puissant IEEE 802.11i. Avec WPA2, le routeur essaie WPA2, puis revient à WPA si le client prend uniquement en charge WPA. Avec WPA2 uniquement, le routeur sassocie uniquement aux clients qui prennent en charge la sécurité WPA2.", //help375
	"Ladresse du site Web %s est incorrecte.", //GW_WEB_FILTER_WEBSITE_INVALID_INVALID
	"Semaine", //ZM21
	"Sessions Internet", //YM157
	"Le contrôle ActiveX WCN fournit le lien WCN entre votre PC et le routeur via le navigateur qui communique les données de configuration sans fil sans utiliser de lecteur flash USB. Le navigateur va chercher à télécharger le contrôle ActiveX WCN, s'il n'est pas déjà disponible sur votre PC. Pour que cette action réussisse, la connexion WAN doit être établie et le réglage de sécurité Internet du navigateur doit être inférieur ou moyen (sélectionnez Outils &rarr; Options Internet &rarr; Sécurité &rarr; Personnaliser le niveau &rarr; Moyen).", //help213
	"Voulez-vous vraiment activer/désactiver ?", //YM24
	"PBC (configuration par bouton-poussoir)", //wps_p3_3
	"Si votre réseau sans fil est déjà configuré avec Wi-Fi Protected Setup, la configuration manuelle du réseau sans fil va détruire le réseau sans fil existant.", //LW43
	"Dans cette section, vous pouvez définir les règles du moteur QoS.", //help99_s
	"Adresse MAC de réservation incorrecte", //YM90
	"TKIP et AES", //bws_CT_3
	"Notez que, si vous entrez moins de caractères que requis, la clé WEP est automatiquement complétée par des zéros.", //help371_n
	"<warn>Une réservation DHCP%v a été reconfigurée en %v. Vérifiez si cette valeur correspond aux spécifications de votre réseau.</warn>", //GW_DHCP_SERVER_RESERVATION_RECONFIG_WARNING
	"Passerelle incorrecte pour la route", //_r_alert3
	"La mesure RIP est incorrecte.", //GW_LAN_RIP_METRIC_INVALID
	"L'intervalle de mise à jour de la clé de groupe WPA doit se situer entre 30 et 65535 secondes.", //YM118
	"Adresse de passerelle incorrecte", //YM127
	"Moteur de diffusion", //KR71
	"WDS  Activation", //aw_WDSEn
	"Réception dun message inconnu", //KR32
	"Local", //sa_Local
	"Le temps dinactivité ne peut pas être zéro.", //GW_WEB_SERVER_IDLE_TIME
	"Cette option contrôle la façon dont le périphérique réagit au trafic sur le connecteur WAN.", //KR59
	"L'adresse IP de passerelle WAN %v doit se situer dans le sous-réseau WAN.", //GW_WAN_WAN_GATEWAY_IN_SUBNET_INVALID
	"Plage d'adresses IP locales", //at_LoIPR
	"Voix", //YM81
	"Paquets avec numéros dagrégation", //aw_AP
	"Cette zone de l'écran affiche les paramètres de configuration depuis les pages <a href=\"wireless.asp\">Configuration &rarr; Paramètres sans fil</a> et <a href=\"adv_wish.asp\">Avancé&rarr; WISH</a>. L'<span class=\"option\">adresse MAC</span> correspond à l'identifiant attribué en usine à votre carte sans fil.", //LT290
	"Priorité donnée aux paquets envoyés en mode sans fil par rapport à la communication via la logique WISH. Les priorités sont :", //YM162
	"Erreur danalyse du fichier de configuration (MIME)", //GW_XML_CONFIG_SET_PARSE_MIME
	"Port UDP", //GW_NAT_UDP_PORT
	"Réussi", //YM9
	"La taille MTU est incorrecte (la plage permise va de %u à %u)", //GW_WAN_MTU_INVALID
	"Il existe plusieurs façons dajouter un périphérique sans fil à votre réseau. Laccès au réseau sans fil est contrôlé par un registre. Un registre autorise uniquement les périphériques sur le réseau sans fil si vous avez entré le PIN ou appuyé sur un bouton Wi-Fi Protected Setup sur le périphérique. Le routeur agit en tant que registre pour le réseau, bien que dautres périphériques puissent également agir en tant que registres.", //LW63
	"Station %s ajoutée (%m)", //WIFISC_IR_REGISTRATION_SUCCESS
	"Adresse IP des paquets utilisant cet acheminement.", //help105
	"Ladresse %v du serveur DHCP a été libérée par le périphérique réseau  le périphérique réseau na plus besoin de lutiliser.", //GW_DHCPSERVER_RELEASED
	"Lancer lassistant de configuration de l'imprimante", //LW32
	"Échec de définition des paramètres de point d'accès (%s). Raison %s (code_err %u).", //WIFISC_AP_SET_APSETTINGS_FAIL
	"Adresse IP incorrecte pour le cheminement", //KR8
	"Le champ du nom vous permet d'identifier cet acheminement (par exemple, Réseau2)", //hhav_r_name
	"Hybride (point à point puis diffusion)", //bd_NETBIOS_REG_TYPE_H
	"Bien quil ne sagisse pas dun mappage parfait, des correspondances générales suivantes entre la classification de &quot;cônes&quot; et les modes de &quot;filtrage de point d'extrémité&quot; peuvent être établies : si ce routeur est configuré pour le filtrage indépendant de point d'extrémité, il met en oeuvre le fonctionnement de cône complet. Le filtrage restreint dadresse met en oeuvre le fonctionnement de cône restrictif et le filtrage restreint de port et dadresse utilise le fonctionnement de cône restrictif de port.", //KR55
	"Adresse IP PPPoE %v en conflit avec le sous-réseau LAN", //GW_WAN_PPPOE_LAN_SUBNET_CONFLICT_INVALID
	"Le fichier de configuration a été importé.", //GW_XML_CONFIG_SET_SUCCESS
	"Le numéro de fin du port local doit se situer entre 0 et 65535 inclus.", //YM60
	"Échec denregistrement des paramètres", //KR100
	"Sélectionnez cette option si le port WAN est connecté à Internet. Le périphérique fonctionne en tant que routeur NAT.", //KR61
	"64 bits (10 chiffres hexadécimaux)", //bws_WKL_0
	"Utilisez le mode <strong>WPA ou WPA2</strong> pour obtenir le meilleur compromis entre sécurité et compatibilité. Ce mode utilise le WPA avec les anciens clients tout en maintenant un niveau de sécurité plus élevé avec les stations compatibles avec le WPA2. Par ailleurs, le chiffrement utilisé est toujours le plus élevé pris en charge par le client. Pour une sécurité optimale, utilisez le mode <strong>WPA2 uniquement</strong>. Ce mode utilise le protocole de chiffrement AES (CCMP). L'accès est refusé aux anciennes stations compatibles uniquement avec le WPA. Pour une compatibilité maximale, utilisez <strong>WPA uniquement</strong>. Ce mode utilise le protocole de chiffrement TKIP. Certains périphériques de jeux ou d'ancienne génération ne fonctionnent que dans ce mode.", //bws_msg_WPA
	"Adresse IP L2TP incorrecte", //YM109
	"Échec de réinitialisation (%s). Raison %s (code_err %u).", //WIFISC_AP_RESET_FAIL
	"%s : pour le port 2 de l'hôte, le numéro de début (%u) doit être inférieur à celui de fin (%u)", //GW_WISH_RULES_HOST2_PORT
	"Charger les paramètres depuis le disque dur local", //help_ts_ls
	"Adresse IP de la passerelle WAN incorrecte", //YM101
	"Auto", //KR50
	"Le protocole doit être un nombre.", //YM56
	"URL/Domaine du site Web", //aa_WebSite_Domain
	"Le débit de transmission maximum doit se situer entre 8 Kbps et 100 Mbps (inclus).", //GW_QOS_RULES_MAX_TRANS
	"%s : le protocole, %d, doit se situer entre 0 et 257.", //GW_QOS_RULES_PROTOCOL
	"Vous devez avoir au moins HTTP ou HTTPS activé.", //GW_WEB_SERVER_NO_ACCESS
	"Configurez l'adresse IP du serveur WINS de secours (le cas échéant).", //KR87
	"%s est un double de %s.", //GW_WISH_RULES_DUPLICATED
	"L'adresse IP cible de départ ne doit pas être sur le sous-réseau local", //YM16
	"Le nom '%s' est déjà utilisé.", //GW_SCHEDULES_NAME_CONFLICT_INVALID
	"Clé WEP 4", //wepkey4
	"HTTP et HTTPS ne peuvent pas occuper le même port WAN.", //GW_WEB_SERVER_SAME_PORT_WAN
	"(la valeur de fin de l'adresse IP source est incorrecte).", //YM65
	"Réglages de réseau", //bln_title
	"Échec d'enregistrement de STA avec adresse MAC (%m). Raison %s (code_err %u).", //WIFISC_AP_PROXY_PROCESS_FAIL
	"Plus", //_more
	"Envoyer/Recevoir des données de connexion", //ZM12
	"Bannière publicitaire", //_aa_bsecure_banner_ad
	"État sans fil", //LY23
	"Pour la plupart des applications, la classification automatique est adéquate et il n'est pas nécessaire d'utiliser de règles spécifiques du moteur QoS.", //help88b
	"Sélectionner plusieurs flux spatiaux peut augmenter le débit mais peut, dans certains cas, diminuer la qualité du signal.", //bwl_NSS_h1
	"Remarque : Ne connectez pas plus d'un lecteur flash USB au routeur, même avec un hub USB.", //help203
	"l nexiste pas de machine définie dans la règle %s.", //GW_INET_ACL_NO_MACHINE_IN_LAN_SUBNET_INVALID
	"Avant de lancer ces assistants, veuillez vous vous assurer d’avoir suivi toutes les étapes décrites dans le guide d'installation rapide inclus dans le paquet.", //LW39c
	"Définition du registre sélectionné terminée", //WIFISC_AP_SET_SELECTED_REGISTRAR_COMPLETE
	"Nom du client DHCP incorrect", //GW_DHCP_CLIENT_CLIENT_NAME_INVALID
	"Échec de récupération de la liste des sessions actives. Nouvelle tentative.", //YM166
	"Échec de redémarrage (%s). Raison %s (code_err %u).", //WIFISC_AP_REBOOT_FAIL
	"La priorité du flux de message est entrée ici -- 1 reçoit la priorité la plus élevée (le plus urgent) et 255 reçoit la priorité la plus faible (le moins urgent).", //help91
	"Les assistants Web suivants ont été conçus pour vous aider à configurer votre réseau sans fil et à connecter votre périphérique sans fil.", //LW39
	"Les champs destinés à entrer le mot de passe et à le confirmer ne concordent pas. Confirmez à nouveau le mot de passe admin.", //YM173
	"Un nom de règle de filtrage de port ne peut pas être vide.", //YM13
	"Votre navigateur Web est trop ancien pour utiliser ce site. Mettez-le à niveau.", //YM172
	"Gain maximum TPC incorrect", //YM31
	"Sélectionnez les catégories Sentinel à filtrer.", //_aa_wiz_s6_msg
	"Le mot de passe peut contenir uniquement des caractères imprimables.", //S493
	"Plage de ports de l'hôte 2", //YM85
	"Le champ Nom ne peut pas être vide.", //GW_SCHEDULES_NAME_INVALID
	"Passerelle incorrecte", //LS204
	"16 Ko", //aw_16
	"(Reportez-vous à la page de <a href='wireless.asp'>configuration &rarr; partie paramètres sans fil &rarr; sous-partie configuration manuelle du réseau sans fil</a>.)", //aw_erpe_h3
	"Démarrez lassistant.", //LW64
	"Jour(s)", //_days
	"Spécifie si lentrée sera activée ou désactivée.", //help103
	"-", //YM183
	"Intervalle de mise à jour de clé de groupe incorrect.", //YM117
	"Précédemment, les termes &quot;cône complet&quot;, &quot;cône restrictif&quot;, &quot;cône restrictif de port&quot; et &quot;symétrique&quot; se référaient à différents types de NAT. Ces termes ne sont pas utilisés ici à dessein car ils ne décrivent pas complètement le fonctionnement de la NAT de ce routeur.", //KR54
	"La page de routage permet de personnaliser l'acheminement déterminant la façon dont les données réseau sont déplacées.", //av_intro_r
	"Les clés hexadécimales de 64 bits comportent très exactement 10 caractères. (12345678FA est une chaîne valide de 10 caractères pour un chiffrement sur 64 bits.)", //help368
	"Une case à cocher, en regard de chaque acheminement, permet d'activer cet acheminement.", //hhav_enable
	"Les serveurs DNS doivent être configurés.", //GW_WAN_DNS_SERVERS_INVALID
	"Restauration exécutée", //_rs_succeeded
	"Un nom d'utilisateur PPTP DOIT être spécifié.", //GW_WAN_PPTP_USERNAME_INVALID
	"Adresse IP L2TP %v incorrecte", //GW_WAN_L2TP_IP_ADDRESS_INVALID
	"Le nom ne peut pas être une chaîne vide.", //GW_INET_ACL_NAME_INVALID
	"Jours", //days
	"Il sagit dun paramètre avancé qui est normalement laissé en blanc. Il permet la configuration dun nom de domaine NetBIOS sous lequel fonctionnent les hôtes réseau.", //KR88
	"Adresse IP PPPoE incorrecte : %v", //GW_WAN_PPPOE_IP_ADDRESS_INVALID
	"Pour une bonne sécurité, la longueur doit être suffisante et la phrase ne doit pas être courante.", //KR19
	"Estimation du débit terminée. Vitesse de liaison montante : %u kbit/s", //RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED
	"Période de balise incorrecte", //YM27
	"Cette zone de l'écran affiche les paramètres de configuration depuis les pages <a href=\"wireless.asp\">Configuration &rarr; Paramètres sans fil</a> et <a href=\"../Advanced/Protected_Setup.shtml\">Avancé&rarr; WPS</a>. L'<span class=\"option\">adresse MAC</span> correspond à l'identifiant attribué en usine à votre carte sans fil.", //LT291wifisc
	"Nom du filtrage de port", //KR1
	"Règle \'", //YM51
	"Envoyer/Recevoir une pulsation", //ZM13
	"Le DNS principal est incorrect.", //GW_LAN_PRIMARY_DNS_INVALID
	"Impossible dutiliser la fonction turbo en mode 11a.", //GW_WLAN_11A_DFS_TURBO_INVALID
	"Pour sécuriser votre réseau sans fil, la première étape consiste à en modifier le nom. Changez-le pour un nom familier ne contenant aucune information personnelle.", //YM123
	"Si votre réseau comporte des périphériques dont ladresse IP doit être fixe, ajoutez une <strong>réservation DHCP</strong> à chacun de ces appareils.", //TA8
	"Adresse IP incorrecte pour le serveur virtuel", //KR9
	"Exemple : 192.168.0.1.", //KR79
	"L'IP distante de départ du %s, '%v', doit être inférieure à l'IP distante de fin, '%v'", //GW_QOS_RULES_REMOTE_IP
	"Adultes (18 minimum)", //_aa_bsecure_age_adult
	"Non initialisé", //ZM7
	"Le port cible de départ ne doit pas être supérieur au port cible final pour le filtre de port", //YM23
	"Remarque : Certaines mises à jour de firmware réinitialisent les options de configuration du routeur sur leur valeur par défaut.\n Avant d_x0019_exécuter une mise à niveau, enregistrez la configuration en cours dans la page des outils (partie système).\n Souhaitez-vous toujours procéder à la mise à niveau ?", //tf_USSW
	"Activez la fonction Wi-Fi Protected Setup.", //LW55
	"Activer le réseau sans fil", //bwl_EW
	"Expire", //LS425
	"Clé WEP", //wwl_WK
	"Générer un nouveau PIN", //LW11
	"% %La passerelle ALG PPTP a été automatiquement activée parce qu'une entrée de serveur virtuel créée le nécessite.<warn>", //GW_NAT_PPTP_ALG_ACTIVATED_WARNING
	"Souhaitez-vous vraiment supprimer", //YM35
	"Sélectionner le(s) jour(s)", //tsc_sel_days
	"Pour que la restauration des paramètres prenne effet, vous devez redémarrer le routeur. Vous pouvez réinitialiser maintenant ou apporter d'autres modifications et réinitialiser plus tard.", //sc_intro_rb4
	"Heure pour le nom programmation incorrecte : %s", //GW_SCHEDULES_TIME_INVALID
	"Le temps dutilisation est incorrect (il doit se situer entre 1 et 65535)", //GW_DHCP_SERVER_LEASE_TIME_INVALID
	"Impossible denvoyer le-mail car ladresse IP du serveur ne peut pas être résolue.", //IPSMTPCLIENT_NO_SERVER_IP_ADDRESS
	"Le port privé doit se trouver dans la plage (1-65535) du serveur virtuel", //KR10
	"https nest pas un protocole pris en charge.", //GW_WEB_FILTER_HTTPS_NOT_SUPPORTED_INVALID
	"Le PIN du périphérique sans fil doit comporter 4 ou 8 chiffres", //KR22
	"Les deux", //_vs_both
	"Le mot de passe de sécurité sans fil doit être dau moins 8 caractères.", //wwl_alert_pv5_4
	"Le point daccès ne doit pas être verrouillé avant configuration.", //GW_WIFISC_LOCK_VERIFY_ERR
	"Les trames sans fil peuvent être divisées en unités plus petites (fragments) pour améliorer les performances en présence dinterférences RF et aux limites de la couverture RF.", //LW53
	"Ladresse du site Web %s est déjà utilisée.", //GW_WEB_FILTER_WEB_SITE_IS_USED_INVALID
	"(la valeur de début de l'adresse IP source est incorrecte).", //YM64
	"Interface d'acheminement incorrecte", //GW_ROUTES_INTERFACE_INVALID
	"DNS secondaire incorrect.", //GW_LAN_SECONDARY_DNS_INVALID
	"Apprendre NetBIOS du WAN", //bd_NETBIOS_LEARN_FROM_WAN_ENABLE
	"<warn>La table de redirection de port est reconfigurée parce que le sous-réseau LAN a été modifié.</warn>", //GW_NAT_PORT_FORWARDING_TABLE_RECONFIGURED_WARNING
	"Bande 802.11", //KR15
	"Échec d'enregistrement du point d'accès dans le registre (%s) via %s, imprévu (%s), à l'état (%s)", //WIFISC_AP_REGISTRATION_UNEXPECTED_EVENT
	"<warn>Ladresse IP du serveur Syslog nest plus dans le sous-réseau LAN. Cela peut nécessiter une reconfiguration.</warn>", //GW_SYSLOG_ADDRESS_NOT_IN_SUBNET_WARNING
	"Adresse IP secondaire incorrecte pour le serveur WINS", //GW_DHCP_SERVER_NETBIOS_SECONDARY_WINS_INVALID
	"Notez que cette fonction ne sapplique pas à l'hôte DMZ (en cas d'activation). L'hôte DMZ gère toujours ces types de session.", //LW49
	"Ajouter/Mettre à jour une règle de calendrier", //KR95
	"8 Ko", //aw_8
	"Adresse IP secondaire incorrecte pour le serveur DNS", //YM114
	"Type de chiffrement ", //bws_CT
	"Classé R", //_aa_bsecure_rrated
	"Verrouiller les paramètres de sécurité sans fil", //LW6
	"Vous pouvez aussi saisir n'importe quelle chaîne de texte dans le champ de la clé WEP, auquel cas les valeurs ASCII des caractères sont converties en valeurs hexadécimales. Vous pouvez saisir 5 caractères de texte pour les clés de 64 bits et 13 caractères pour les clés de 128 bits.", //bws_msg_WEP_2
	"L'IP locale de départ du %s, '%v', doit être inférieure à l'IP locale de fin, '%v'", //GW_QOS_RULES_LOCAL_IP
	"Pour ladresse IP de groupe, la valeur de DE ne doit pas être supérieure à celle de A.", //GW_DHCP_SERVER_POOL_FROM_TO_ORIENTATION_INVALID
	"TKIP", //bws_CT_1
	"Échec de verrouillage de la base de données de configuration numéro %u", //GW_XML_CONFIG_SET_LOCK
	"Adresse IP réservée %v en conflit avec une autre réservation", //GW_DHCP_SERVER_RESERVED_IP_UNIQUENESS_INVALID
	"Clé WEP 2", //wepkey2
	"Options de connexion manuelle à Internet", //LW28
	"Clé WEP 1", //_wepkey1
	"Désactivez ce paramètre pour procéder à la configuration manuelle.", //KR83
	"Adresse IP du serveur Syslog incorrecte.", //GW_SYSLOG_ADDRESS_INVALID
	"Adresse IP PPTP incorrecte", //YM105
	"Client DHCP", //ZM5
	"Contrôle ActiveX WCN", //help212
	"Appuyez sur le bouton-poussoir du périphérique sans fil, puis cliquez sur le bouton Connecter ci-dessous dans un délai de 120 secondes.", //wps_p3_5
	"Pour spécifier tout autre protocole, sélectionnez Autres dans la liste, puis entrez le numéro de protocole correspondant (<a href='http:www.iana.org/assignments/protocol-numbers' target='_blank'>assigné par IANA</a>) dans la zone du <span class='option'>protocole</span>.", //help19x2
	"Étape 2 : connectez votre périphérique sans fil", //KR36
	"La mesure d'acheminement %u est incorrecte. Elle doit se situer entre 1 et 16.", //GW_ROUTES_METRIC_INVALID
	"Le champ SSID ne doit pas être vide.", //GW_WLAN_SSID_INVALID
	"Adresse IP incorrecte.", //LS46
	"La valeur du délai d'attente ne peut pas être inférieure ou égale à zéro.", //YM179
	"Adresse IP du routeur du réseau local (par ex. 192.168.0.1).", //KR78
	"Le pont permet de rechercher les mises à jour sur le site de support à l'aide du routeur en amont.", //KR66
	"Magazine", //_aa_bsecure_magazine
	"Le périphérique est peut-être trop occupé pour en recevoir correctement pour le moment. Essayez d'enregistrer de nouveau les paramètres.", //KR101
	"Le mode WPA uniquement ne prend pas en charge AES.", //GW_WLAN_WPA_WPA_AES_INVALID
	"Filtre entrant", //GW_NAT_INBOUND_FILTER
	"Le nom de règle ne doit pas être vide.", //GW_INET_ACL_POLICY_NAME_INVALID
	"Internet", //sa_Internet
	"Réseau poste à poste entre clients sans fil.", //help406
	"La règle s'applique à un flux de messages pour lequel le numéro de port de l'hôte 1 se situe dans la plage définie ici.", //YM153
	"Plage d'adresses IP distantes", //at_ReIPR
	"Une ou plusieurs stratégies d'accès à Internet sont en vigueur. L'accès à Internet sera restreint conformément à ces stratégies.", //GW_INET_ACCESS_RESTRICTED
	"DTIM doit se situer entre 1 et 255.", //GW_WLAN_DTIM_INVALID
	"Une règle WISH identifie un flux de message spécifique et lui assigne une priorité.", //YM144
	"(GMT+01:00) Amsterdam, Berlin, Berne, Rome, Stockholm", //up_tz_26
	"Sélectionnez un filtre qui contrôle l'accès selon les besoins pour cette règle. Si le filtre souhaité n'apparaît pas dans la liste, allez à l'écran <a href='Inbound_Filter.asp'> Avancé&nbsp;&rarr;&nbsp;Filtre&nbsp;entrant</a>, puis créez un nouveau filtre.", //help71
	"HNAP AddPortMapping a changé l'entrée de serveur virtuel %d de %s %v:%d <-> %v:%d %S à %s %v:%d <-> %v:%d %S", //GW_PURE_ADDPORTMAPPING_MODIFY
	"Utilisateur arrêté", //tsc_pingt_msg10
	"Ladresse IP de limprimante et le numéro de port TCP sont indiqués <a href='../Status/PS.shtml' onclick='return jump_if();'>ici</a>.", //tps_foo
	"HNAP AddPortMapping a changé l'entrée de serveur virtuel %d de %s %v:%d <-> %v:%d %S à %S", //GW_PURE_ADDPORTMAPPING_CHG_PROTOCOL
	"Message ci-dessus répété %d fois", //LOG_PREV_MSG_REPEATED_N_TIMES
	"Le <strong>Mot de passe</strong> sert à vérifier que vous êtes autorisé à apporter des modifications à un périphérique. Il est imprimé sur l'étiquette au dos du périphérique.", //ca_intro
	"Lapprentissage pour l'adressage côté Internet s'effectue via les conflits DHCP avec ladressage sélectionné côté LAN. Les communications Internet sont désactivées jusquà la modification de ladressage côté LAN afin de résoudre le problème.", //GW_WAN_LAN_ADDRESS_CONFLICT_DHCP
	"La section répertorie les règles de filtre entrant en vigueur. Le cas échéant, cliquez sur licône de modification ou de suppression d'une règle de filtre entrant. Lorsque vous cliquez sur licône de modification, lélément se met en surbrillance et la section de mise à jour de règle de filtre entrant devient modifiable.", //help176
	"HNAP AddPortMapping a créé l'entrée de serveur virtuel %d %s %v:%d <-> %v:%d %S", //GW_PURE_ADDPORTMAPPING_CREATE
	"Sélectionnez une programmation pour définir le moment d'activation de la règle. Si la programmation nécessaire ne s'affiche pas dans la liste, accédez à la page des <a href='tools_schedules.asp' onclick='return jump_if();'>outils &rarr; partie programmation </a> et créez-en une.", //hhag_30
	"Cliquez sur le bouton <strong>Ajouter</strong> ou <strong>Mettre à jour</strong> pour stocker une règle finie dans la liste des règles ci-dessous.", //hhai_save
	"Administrateur", //ADMIN
	"Limprimante suivante a été détectée. Cliquez sur l'option de <em>continuation</em> pour installer limprimante sur votre ordinateur.", //wprn_s1a
	"La notification par e-mail nest pas activée.", //sl_alert_3
	"Après configuration du moteur pour DNS dynamique, vous pouvez ouvrir un navigateur et accédez à lURL de votre domaine (par exemple, <code>http:www.mondomaine.info</code>) et le routeur cherchera à transmettre la requête au port 80 de votre LAN. Si vous effectuez cette opération sur un ordinateur côté LAN et sil nexiste pas de serveur virtuel défini pour le port 80, le routeur renvoie la page daccueil de configuration du routeur. Si nécessaire, reportez-vous à la page de configuration des <a href='adv_virtual.asp'>paramètres avancés &rarr; partie serveur virtuel</a>.", //help900
	"Ladresse IP de limprimante et le nom de la file d'attente sont indiqués <a href='../Status/PS.shtml' onclick='return jump_if();'>ici</a>.", //tps_foo2
	"Ce paramètre doit rester à sa valeur par défaut, soit 2 346 octets.", //help182
	" -- L'adresse IP doit se trouver sur le sous-réseau du réseau local.", //aa_alert_12
	"Pour rechercher le tout dernier microprogramme, cliquez sur le bouton [Contrôle en ligne maintenant...]. Pour être averti de la diffusion d'un nouveau microprogramme, cochez la case en regard de Notification par courrier électronique des nouvelles versions du microprogramme.", //tf_intro_FWCh
	"Enregistrer sur le disque dur local", //ts_ss
	"Définir un nom d''utilisateur et un mot de passe de connexion (PPTP)", //wwa_title_set_pptp
	"(par ex. : moi.mondomaine.net)", //_hostname_eg
	"Remarque : vous devez entrer le même mot de passe que celui des clés à cette étape dans vos clients sans fil afin dactiver la communication sans fil appropriée.", //wwl_s4_note
	"Sélectionnez un filtre qui contrôle l'accès selon les conditions requises pour ce serveur virtuel. Si le filtre nécessaire ne s'affiche pas dans la liste, accédez à la page des <a href='Inbound_Filter.asp'>paramètres avancés &rarr;  partie filtre entrant</a> et créez-en un.", //help22
	"Le mot de passe de sécurité sans fil doit être de 13 caractères alphanumériques ou de 26 chiffres hexadécimaux. Vous avez entré", //wwl_alert_pv5_1
	"HNAP SetWLanSettings24 activé (%s). Diffusion SSID (%s). Canal (%d).", //GW_PURE_SETWLANSETTINGS24
	"Précisez l’adresse IP du réseau local de l’ordinateur du réseau local dont vous ne voulez plus restreindre la communication Internet. Si cet ordinateur obtient son adresse IP automatiquement via DHCP, vous pouvez créer une réservation statique dans la page <a href='adv_network.asp'>Configuration&rarr;Paramètres&nbsp;réseau </a> afin que l’adresse IP de l'ordinateur DMZ ne change pas.", //help167
	"xDSL ou autre réseau de relais de trame détecté", //at_DxDSL
	"Lassistant de configuration de l'imprimante prend uniquement en charge les systèmes dexploitation Windows XP/2000/98/ME. Votre ordinateur utilise le système dexploitation <span id='wz_page_1_err_1_os'> </span>.", //wprn_bados2
	"Lexécutable de configuration que vous venez de lancer va afficher une barre de progression et vous prévenir lorsque la configuration sera terminée. Une fois cette configuration exécutée, cliquez sur l'option de <em>fin</em> ci-dessous pour fermer lassistant de configuration de l'imprimante.", //wprn_s3a
	"Si lexécutable de configuration ne sest pas lancé automatiquement après téléchargement sur votre ordinateur, vous devez ouvrir le dossier de téléchargement de fichiers en utilisant un explorateur de fichiers et double-cliquer sur licône <em>Configuration_Imprimante.exe.</em>", //wprn_tt10
	"Ping WAN - <a href='Inbound_Filter.asp' onclick='return jump_if();'>Filtre entrant</a>", //bwn_IF
	"Notez cependant que, si les paramètres du point d'accès définissent une adresse DHCP (dynamique) et si le serveur DHCP du routeur attribue un nom de domaine au point d'accès, ce nom de domaine remplacera toute autre donnée saisie dans ce champ.", //_1044a
	"Tentez de résoudre le problème avec limprimante, puis cliquez sur l'option de <em>rafraîchissement</em> pour mettre à jour le statut de limprimante.", //wprn_tt6
	"Sélectionnez un calendrier pour indiquer quand cette règle est en vigueur. Si le calendrier souhaité n'apparaît pas dans la liste, allez à l'écran <a href='tools_schedules.asp'> Outils&nbsp;&rarr;&nbsp;Calendriers</a>, puis créez un nouveau calendrier.", //help72
	"Inconnu", //_sdi_s6
	"Sélectionnez un calendrier d'activation du service. Si le calendrier souhaité n'apparaît pas dans la liste, allez à l'écran <a href=\"tools_schedules.asp\" onclick=\"return jump_if();\">Outils --> Calendriers</a>, puis créez un nouveau calendrier.", //hhpt_sch
	"Activez ou désactivez ce SSID. Lorsque vous l'activez, les paramètres suivants sont effectifs.", //tps_enraw
	"Ce journal a été envoyé à votre adresse électronique", //sl_alert_2
	"Auto  10/100/1000 Mbps", //anet_wp_2
	"Restaurez tous les paramètres par défaut.", //tss_RestAll
	"HNAP SetDeviceSettings a défini le mode Wan sur %S, %v/%v/%v", //GW_PURE_SETWANSETTINGS
	"Sélectionnez un calendrier pour indiquer quand cette règle est en vigueur. Si le calendrier souhaité n'apparaît pas dans la liste, allez à l'écran <a href='tools_schedules.asp'> Outils&nbsp;&rarr;&nbsp;Calendriers</a>, puis créez un nouveau calendrier.", //help53
	"Enregistre la nouvelle règle de filtre entrant ou la règle modifiée dans la liste suivante.", //help175
	"Si vous sélectionnez loption de programmation à l'heure prévue, sélectionnez lune des règles définies. Si la programmation nécessaire ne s'affiche pas dans la liste, accédez à la page des <a href='tools_schedules.asp'>outils &rarr; partie programmation </a> et créez-en une.", //help872
	"Norme de transmission utilisée par le client. Les valeurs sont respectivement 11a, 11b, 11g ou 11n pour 802.11a, 802.11b, 802.11g ou 802.11n.", //help785
	"Après avoir cliqué sur l'option de <em>continuation</em>, vous êtes invité à autoriser le téléchargement d'un exécutable. Cliquez sur l'option d'<em>exécution/ouverture</em> pour autoriser lexécutable à sexécuter sur votre ordinateur. Si une autre fenêtre vous invite à vérifier lémetteur, cliquez de nouveau sur l'option d'<em>exécution</em>.", //wprn_s2b
	"Lassistant va vous guider tout au long des étapes suivantes. Cliquez sur l'option de <em>continuation</em> pour commencer.", //wprn_intro2
	"Sélectionnez un filtre.", //GW_INET_ACL_NO_FILTER_SELECTED_INVALID
	"Lorsque cette option est activée, un courrier électronique est envoyé à l'adresse configurée dans la section Courrier électronique pour prévenir de la mise à disposition de tout nouveau microprogramme. La notification par courrier électronique doit être activée à la page <a href='tools_email.asp'>Outils&rarr;Paramètres&nbsp;de courrier électronique</a>", //help890
	"Adresse IP et numéro de port (le cas échéant) de l'application locale.", //help814
	"Intervalle de temps pendant lequel la machine peut être inactive avant la déconnexion PPTP. Le temps dinactivité maximum est uniquement utilisé pour les modes de reconnexion &quot;à la demande&quot; et &quot;manuelle&quot;.", //help283
	"Ce protocole dimpression est actuellement désactivé. Vous pouvez lactiver <a href='../Tools/PS.shtml' onclick='return jump_if();'>ici</a>.", //sps_protdis
	"Select a filter that controls access as needed for this admin port. If you do not see the filter you need in the list of filters, go to the <a href ='Inbound_Filter.asp' onclick ='return jump_if();'>Avancé &rarr;&nbsp;Filtre&nbsp;entrant</a> screen an", //help831
	"Droits insuffisants", //_cantapplysettings
	"cette option permet aux clients H.323 (comme Microsoft NetMeeting) de communiquer à travers la NAT. Notez que si vous voulez que vos amis vous appellent, vous devez également configurer un serveur virtuel pour NetMeeting. Reportez-vous à la page <a href='adv_virtual.asp'>Avancé&nbsp;&rarr;&nbsp;Serveur&nbsp;virtuel</a> pour obtenir des informations sur la configuration d'un serveur virtuel.", //help39
	"Abandon de la configuration WCN dû à %s", //WCN_LOG_ABORT
	"(GMT+13:00) Nuku'alofa, Tonga", //up_tz_73
	"Les sites Web répertoriés ici sont utilisés lorsque loption de filtre Web est activée dans les <a href='adv_access_control.asp'>paramètres avancés &rarr; partie contrôle daccès</a>.", //help141_a
	"Les paramètres de firewall vous permettent de définir un seul ordinateur sur votre réseau en dehors du routeur.", //af_intro_x
	"Ajouter/Mettre à jour la règle de filtre entrant", //help170
	"Pour utiliser limprimante partagée à partir de cet ordinateur, lancez lassistant de l'imprimante à partir de la page de l'<a href='../Basic/Wizard.shtml' onclick='return jump_if();'><i>assistant</i>.", //tps_intro4
	"Vous pouvez aussi saisir un fournisseur de service DNS dynamique manuellement.", //help893b
	"Démarrer le serveur DHCP", //GW_DHCPSERVER_START
	"Certaines mises à jour de microprogramme rétablissent les valeurs par défaut des options de configuration. Avant d'effectuer la mise à jour, assurez-vous d'enregistrer la configuration actuelle depuis l'écran <a href ='tools_system.asp'>Outils&rarr;Système</a> screen.", //help887
	"Permet aux clients et serveurs FTP de transférer des données à travers la NAT. Reportez-vous à la page <a href='adv_virtual.asp'>Avancé&nbsp;&rarr;&nbsp;Serveur&nbsp;virtuel</a> si vous souhaitez héberger un serveur FTP.", //help38
	"SPI (\"Stateful Packet Inspection\", également appelée \"filtrage de paquets dynamique\") permet d'éviter les attaques Internet en suivant davantage d'états par session. Il atteste que le trafic passant par la session est conforme au protocole.", //help164
	"Sélectionnez un filtre qui restreint l'accès des hôtes Internet à ce serveur virtuel en fonction d'un niveau de confiance. Si le filtre nécessaire ne s'affiche pas dans la liste, accédez à la page des <a href='Inbound_Filter.asp' onclick='return jump_if();'>paramètres avancés &rarr;  partie filtre entrant</a> et créez-en un.", //hhav_filt
	"HNAP AddPortMapping %s %v:%d <-> %v:%d %S est en conflit avec l'entrée de serveur virtuel %d %s %v:%d <-> %v:%d %S", //GW_PURE_ADDPORTMAPPING_CONFLICT
	"HNAP SetRouterLanSettings a défini l'adresse IP de routeur %v, le masque de sous-réseau du routeur %v et le serveur DHCP activé %s", //GW_PURE_SETROUTERLANSETTINGS
	"HNAP SetWLanSecurity a activé %s. Type %s.", //GW_PURE_SETWLANSECURITY
	"Le nom de règle ne doit pas être vide.", //aa_alert_9
	"Intervalle de temps pendant lequel la machine peut être inactive avant la déconnexion L2TP. Le temps dinactivité maximum est utilisé pour les modes de reconnexion &quot;à la demande&quot; et &quot;manuelle&quot;.", //help287
	"Administrateur distant  <a href='Inbound_Filter.asp' onclick='return jump_if();'>Filtre entrant</a>", //ta_RAIF
	"Ce paramètre doit rester à sa valeur par défaut, soit 2 346 octets.", //help180
	"HNAP SetDeviceSettings a changé le nom de périphérique en %s", //GW_PURE_SETDEVICESETTINGS
	"Signal (%)", //_rssi
	"Cet assistant vous guidera tout au long de la procédure de configuration et de sécurisation de votre réseau sans fil.", //wwl_intro_wel
	"Cliquez ici pour accéder au microprogramme en ligne.", //tf_ClickDL
	"DMZ signifie &quot;DeMilitarized Zone&quot;. Si une application a des problèmes à travailler derrière le routeur, vous pouvez exposer un seul ordinateur à Internet et exécuter lapplication sur cet ordinateur.", //help165
	"Autres", //_vs_other
	"Pour utiliser limprimante partagée à partir de cet ordinateur, suivez les instructions de l'<a href='../Help/Basic.shtml#PS' onclick='return jump_if();' style='white-space: nowrap;'>aide -&gt; partie accueil -&gt; sous-partie assistant de l'imprimante</a>.", //tps_intro5
	"Le fichier de microprogramme téléchargé sur le périphérique n'est peut-être pas le bon. Il est possible que le fichier téléchargé sur la passerelle soit inadapté ou corrompu.", //ub_intro_1
	"Intervalle de temps pendant lequel la machine peut être inactive avant la déconnexion PPPoE. Le temps dinactivité maximum est uniquement utilisé pour les modes de reconnexion &quot;à la demande&quot; et &quot;manuelle&quot;.", //help277
	"Cette fonction permet la redirection de \"paquets magiques\" (paquets de réveil formatés spécialement) du réseau étendu vers un ordinateur du réseau local ou tout autre périphérique possédant la fonction \"Wake on LAN\" (WOL). Le périphérique WOL doit être défini en tant que tel sur la page <a href='adv_virtual.asp'> Avancé&nbsp;&rarr;&nbsp;Serveur&nbsp;virtuel</a>. L'adresse IP du réseau local du serveur virtuel est généralement définie sur l'adresse de diffusion 192.168.0.255. L'ordinateur situé sur le réseau local et dont l'adresse MAC figure dans le paquet magique sera réveillé.", //help41
	"Serveur virtuel", //VIRTUAL_SERVERS
	"Sélectionnez une programmation pour définir le moment d'activation du serveur virtuel. Si la programmation nécessaire ne s'affiche pas dans la liste, accédez à la page des <a href='tools_schedules.asp' onclick='return jump_if();'>outils &rarr; partie programmation </a> et créez-en une.", //hhav_sch
	"Restaurer les paramètres par défaut", //ts_rfd
	"Si la passerelle PPTP ALG est activée, les ordinateurs LAN peuvent établir des connexions PPTP soit avec le même serveur VPN, soit avec des serveurs VPN différents. Dans le cas contraire, le routeur autorise lopération VPN de façon restreinte -- les ordinateurs du LAN sont généralement capables détablir des tunnels VPN vers différents serveurs Internet VPN mais pas vers le même serveur. Désactiver la passerelle PPTP ALG permet d'accroître les performances VPN. Activer la passerelle PPTP ALG autorise les connexions VPN entrantes vers un serveur VPN côté LAN (reportez-vous à la page des <a href='adv_virtual.asp'>paramètres avancés &rarr; partie serveur virtuel</a>).", //help33b
	"Charger depuis le disque dur local", //ts_ls
	"HNAP DeletePortMapping %s:%d a modifié l'entrée de serveur virtuel %d %s %v:%d <-> %v:%d %S en %S", //GW_PURE_DELETEPORTMAPPING_MODIFY
	"Après avoir cliqué sur l'option de <em>continuation</em>, vous êtes invité à autoriser le téléchargement d'un exécutable. Cliquez sur l'option d'acceptation pour télécharger le fichier.<br/><br/>Pour lancer l'exécutable, vous pouvez avoir besoin d'ouvrir le dossier de téléchargement de fichier avec un explorateur de fichiers et de double-cliquer sur l'icône <em>Configuration_imprimante.exe</em>.", //wprn_s2c
	"Un ordinateur ou un périphérique qui est configuré manuellement peut avoir une adresse qui réside dans cette plage. Dans ce cas, l'adresse doit être réservée (voir la section <a href=\"#Static_DHCP\">Réservation DHCP</a> ci-dessous) afin que le serveur DHCP sache qu'elle ne peut qu'être utilisée par un ordinateur ou un périphérique spécifique.", //help320
	"La page Internet Sessions Internet affiche des informations détaillées sur les sessions Internet actives via le routeur. Une session Internet est une conversation entre un programme ou une application sur un ordinateur du côté du réseau local et un programme ou une application sur un ordinateur du côté du réseau étendu.", //help813
	"Sélectionnez un fournisseur de service DNS dynamique dans la liste déroulante ou saisissez son nom manuellement.", //help893
	"Sélectionnez cette option pour enregistrer le journal de routeur dans un fichier sur votre ordinateur.", //help803
	"Pour rechercher le dernier firmware, cliquez sur le bouton <span class='button_ref'>vérification en ligne à effectuer maintenant</span>.", //help877
	"(GMT+01:00) Belgrade, Bratislava, Ljubljana", //up_tz_27
	"Dans l'exemple précédent, où les valeurs sont renseignées et la règle de jeu activée, tout le trafic TCP et UDP passant par les ports 6159 à 6180 et par le port 99 sont dirigés à travers le routeur, puis est redirigé vers l'adresse IP privée interne de votre serveur de jeu sur 192.168.0.50.", //help74
	"En cas de désactivation, les adresses MAC ne sont pas utilisées pour contrôler laccès réseau. En cas d'autorisation, seuls les ordinateurs ayant les adresses MAC répertoriées dans la liste des adresses MAC ont accès au réseau. En cas de refus, tout ordinateur ayant une adresse MAC répertoriée dans la liste des adresses MAC se voit refuser l'accès au réseau.", //help155_2
	"Établi : Estimation du débit", //_sdi_s4
	"Divers", //MISC
	"Remarque : téléchargement en cours. Le téléchargement peut prendre jusquà 1 minute.", //tf_msg_Upping
	"Échec denvoi de-mail de notification  réessayez dans %d minutes", //GW_LOG_EMAIL_FAILED
	"Connexions TCP établies ou en cours de fermeture.", //help823_17
	"Activer le SSID", //IPV6_TEXT4
	"Cette page affiche les détails complets des sessions actives passant par votre routeur.", //sa_intro
	"Réinitialiser va déconnecter toutes les sessions Internet actives.", //up_rb_2
	"Sélectionnez une programmation pour définir le moment d'activation du service. Si la programmation nécessaire ne s'affiche pas dans la liste, accédez à la page des <a href='tools_schedules.asp'>outils &rarr; partie programmation </a> et créez-en une.", //help23
	"Si GMP est activé, cette zone de lécran affiche tous les groupes multidiffusions dont les périphériques LAN sont membres.", //_bln_title_IGMPMemberships_h
	"Voir aussi <a href ='adv_virtual.asp'>Avancé&rarr;Serveur&nbsp;virtuel</a>, <a href ='adv_portforward.asp'>Avancé&rarr;Redirection&nbsp;de port </a>, <a href ='adv_appl.asp'>Avancé&rarr;Règles&nbsp;d'application </a>, et <a href ='adv_network.asp'>Avancé&rarr;Réseau (UPnP) </a> pour les options connexes.", //haf_intro_2
	"Si vous avez fourni des informations de-mail dans la page des <a href='tools_email.asp'>outils &rarr; partie e-mail</a>, le bouton <span class='button_ref'>d'utilisation d'e-mail maintenant</span> envoie le journal de routeur vers ladresse e-mail configurée.", //help802
	"Cliquez sur l'option de <em>rafraîchissement</em> pour recommencer.", //wprn_tt5
	"Le journal peut également vous être envoyé par e-mail périodiquement. Reportez-vous à la page des <a href='tools_email.asp' onclick='return jump_if();'>outils &rarr; partie e-mail</a>.", //hhsl_lmail
	"Appuyez sur le bouton ci-dessous pour continuer à configurer le routeur si la page précédente n'est pas restaurée en <span id='show_sec'></span> secondes.", //ap_intro_noreboot
	"(GMT+01:00) Sarajevo, Skopje, Sofia, Vilnius, Zagreb", //up_tz_29
	"HNAP SetMACFilters2", //GW_PURE_SETMACFILTERS2
	"Redémarrage HNAP", //GW_PURE_REBOOT
	"Si vous avez modifié ladresse IP du routeur, vous devrez reporter cette modification dans votre navigateur pour pouvoir de nouveau accéder au site Web de configuration.", //rb_change
	"Adresse IP et numéro de port (le cas échéant) de l'application sur Internet.", //help816
	"HNAP DeletePortMapping %s:%d a supprimé l'entrée de serveur virtuel %d %s %v:%d <-> %v:%d %S", //GW_PURE_DELETEPORTMAPPING_DELETE
	"Si le fichier téléchargé vers le serveur est correct, le périphérique est peut-être trop occupé pour le recevoir immédiatement. Dans ce cas, essayez de le télécharger de nouveau. (Autre possibilité.) Vous êtes connecté en tant qu'utilisateur et non en tant qu'admin. - seuls les administrateurs peuvent télécharger un nouveau firmware.", //ub_intro_3
	"Les demandes peuvent être redirigées vers la page \"interdite\" si l'accès Web de la machine LAN est limité par une règle de contrôle d'accès. Ajoutez l'identité côté réseau étendu (adresse IP côté réseau étendu du routeur ou son nom DNS dynamique) dans l'écran <a href='adv_filters_url.asp'> Avancé&nbsp;&rarr;&nbsp;Filtre&nbsp;Web</a> pour résoudre ce problème.", //help30
	"Adresse IP LAN incorrecte", //bln_alert_2
	"À utiliser avec la page des <a href='adv_access_control.asp' onclick='return jump_if();'>paramètres avancés &rarr; partie contrôle daccès</a>.", //hhwf_xref
	"Administration à distance de passerelle activée sur le port : %u", //GW_REMOTE_ADMINSTRATION
	"Après avoir sélectionné votre niveau de sécurité, vous devrez définir un mot de passe de sécurité sans fil.", //wwl_s4_intro
	"Mode de sécurité", //sd_SecTyp
	"PARAMÈTRES DE L’ADRESSE IPv6 DU RÉSEAU ÉTENDU", //IPV6_WAN_IP
	"Adresse IPv6", //IPV6_TEXT0
	"Acceptez et installer le contrôle ActiveX, puis réessayez.", //gw_wcn_alert_3
	"Clé de réseau incorrecte !", //IPV6_TEXT2
	"Activer le routage entre les zones", //S473
	"Activez le SPI", //af_ES
	"Cette sélection vous aide à définir l'échelle de la zone invité.", //IPV6_TEXT5
	"Indique si la zone invité va être activée ou désactivée.", //IPV6_TEXT6
	"Nommez le réseau sans fil de la zone invité.", //IPV6_TEXT7
	"Cette section permet d'activer la redirection entre la zone hôte et la zone invité ; les clients invités ne peuvent pas accéder aux données des clients hôtes sans activer cette fonction.", //IPV6_TEXT8
	"Il est important de sécuriser votre réseau sans fil afin de protéger l'intégrité des informations qui y sont transmises. Le routeur accepte 4 types de sécurité sans fil : WEP, WPA seulement, WPA2 seulement et WPA/WPA2 (détection automatique).", //IPV6_TEXT9
	"Le WEP (Wired Equivalent Protocol) est un protocole de sécurité sans fil pour les réseaux locaux sans fil (WLAN). Le WEP vise à fournir une sécurité en chiffrant les données qui sont envoyées sur le WLAN. Le routeur prend en charge 2 niveaux de chiffrement WEP : 64 bits et 128 bits. Le WEP est désactivé par défaut. Le paramètre WEP peut être modifié pour s'adapter à un réseau sans fil existant ou pour personnaliser votre réseau sans fil.", //IPV6_TEXT10
	"L'authentification est un processus par lequel le routeur vérifie l'identité d'un périphérique réseau qui tente de joindre le réseau sans fil. Il existe deux types d'authentification pour ce périphérique lorsque vous utilisez le WEP.", //IPV6_TEXT11
	"Sélectionnez cette option pour autoriser tous les périphériques réseaux à communiquer avec le routeur sans devoir fournir la clé de chiffrement pour pouvoir accéder au réseau ne leur soit demandée.", //IPV6_TEXT12
	"Sélectionnez cette option si vous voulez que tous les périphériques réseaux tentant de communiquer avec le routeur fournissent la clé de chiffrement nécessaire pour accéder au réseau avant qu'ils ne soient autorisés à communiquer avec le %m.", //IPV6_TEXT13
	"Sélectionnez le niveau de chiffrement WEP que vous souhaiteriez utiliser sur votre réseau. Les deux niveaux pris en charge sont 64 bits et 128 bits.", //IPV6_TEXT14
	"Les types de clé qui sont pris en charge par le %m sont les formats HEX (hexadécimal) et ASCII (American Standard Code for Information Interchange). Le type de clé peut être modifié pour s'adapter à un réseau sans fil existant ou pour personnaliser votre réseau sans fil.", //IPV6_TEXT15
	"Clés", //IPV6_TEXT16
	"Les clés 1 à 4 vous permettent de modifier facilement les paramètres de chiffrement sans fil pour maintenir un réseau sécurisé. Sélectionnez simplement la clé spécifique à utiliser pour chiffrer les données sans fil sur le réseau.", //IPV6_TEXT17
	"Type de clé", //IPV6_TEXT18
	"Chiffrement WEP", //IPV6_TEXT19
	"Le WPA (Wi-Fi Protected Access) permet d'autoriser et d'authentifier les utilisateurs entrant sur le réseau sans fil. Le WPA est plus sécurisé que le WEP et repose sur une clé qui change automatiquement à intervalles réguliers.", //IPV6_TEXT20
	"Le %m prend en charge deux types de chiffrement différents lorsque le WPA est utilisé comme le type de sécurité. Ces deux options sont le TKIP (Temporal Key Integrity Protocol) et l'AES (Advanced Encryption Standard).", //IPV6_TEXT21
	"PSK/EAP", //IPV6_TEXT22
	"Si vous sélectionnez le mode PSK, les clients sans fil devront fournir une phrase de passe à titre d'authentification. Si vous sélectionnez le mode EAP, vous devrez disposer d'un serveur RADIUS sur votre réseau pour gérer l'authentification de tous les clients sans fil.", //IPV6_TEXT23
	"CONTRÔLE PARENTAL", //DNS_TEXT0
	"Vos clients sans fil en auront besoin pour communiquer avec votre %m, lorsque le mode PSK est sélectionné. Entrez 8 à 63 caractères alphanumériques. Veillez à noter cette phrase de passe étant donné que vous aurez besoin de l'entrer sur tout autre périphérique réseau que vous tentez d'ajouter à votre réseau.", //IPV6_TEXT25
	"Cela signifie que l'authentification WPA est utilisée conjointement avec un serveur RADIUS qui doit être présent sur votre réseau. Entrez l'adresse IP, le port, et le secret partagé utilisés pour configurer le RADIUS. Vous pouvez également entrer des informations pour un deuxième serveur RADIUS s'il y en a deux sur votre réseau que vous utilisez pour authentifier les clients sans fil.", //IPV6_TEXT26
	"Le WPA (Wi-Fi Protected Access) 2 permet d'autoriser et d'authentifier les utilisateurs sur le réseau sans fil. Le WPA2 est plus sécurisé que le WEP et repose sur une clé qui change automatiquement à intervalles réguliers.", //IPV6_TEXT27
	"Utilisez cette section pour configurer votre type de connexion IPv6. Si vous n'êtes pas sûr de votre méthode de connexion, contactez votre fournisseur d'accès Internet.", //IPV6_TEXT28
	"TYPE DE CONNEXION IPv6", //IPV6_TEXT29
	"TYPE DE CONNEXION IPv6", //IPV6_TEXT29a
	"Choisissez le mode que le routeur doit utiliser sur l'Internet IPv6.", //IPV6_TEXT30
	"Ma connexion IPv6 est", //IPV6_TEXT31
	"IPv6 statique", //IPV6_TEXT32
	"DHCPv6", //IPV6_TEXT33
	"PPPoE", //IPV6_TEXT34
	"Tunnel IPv6 en IPv4", //IPV6_TEXT35
	"6to4", //IPV6_TEXT36
	"Connectivité locale uniquement", //IPV6_TEXT37
	"PARAMÈTRES DU TUNNEL IPv6 dans IPv4", //IPV6_TEXT38
	"Entrez les informations relatives au tunnel IPv6 dans IPv4 fournies par votre mandataire de tunnel.", //IPV6_TEXT39
	"Adresse IPv4 distante", //IPV6_TEXT40
	"Adresse IPv6 distante", //IPV6_TEXT41
	"Adresse IPv4 locale", //IPV6_TEXT42
	"Adresse IPv6 locale", //IPV6_TEXT43
	"PARAMÈTRES DE L'ADRESSE IPV6 DU RÉSEAU LOCAL", //IPV6_TEXT44
	"Cette section permet de configurer les paramètres du réseau interne du routeur. Si vous changez l'adresse IPv6 du réseau local ici, vous devrez peut être ajuster les paramètres réseau de votre PC pour accéder de nouveau au réseau.", //IPV6_TEXT45
	"Adresse IPv6 du réseau local", //IPV6_TEXT46
	"Adresse de lien local du réseau local IPv6", //IPV6_TEXT47
	"PARAMÈTRES D'AUTOCONFIGURATION D'ADRESSE", //IPV6_TEXT48
	"Cette section vous permet de paramétrer l'autoconfiguration IPv6 afin d'attribuer des adresses IP aux ordinateurs de votre réseau.", //IPV6_TEXT49
	"Activez l'option Balayage automatique du canal pour que le routeur puisse sélectionner le meilleur canal pour le fonctionnement de votre réseau sans fil.", //TA11
	"Type d'autoconfiguration", //IPV6_TEXT51
	"Sans état", //IPV6_TEXT52
	"DHCPv6 à état", //IPV6_TEXT53
	"Plage d'adresses IPv6 (début)", //IPV6_TEXT54
	"Plage d'adresses IPv6 (fin)", //IPV6_TEXT55
	"Durée de vie de l'adresse IPv6", //IPV6_TEXT56
	"Durée de vie de l'annonce de routeur", //IPV6_TEXT57
	"Lorsque vous configurez le routeur pour accéder à l'Internet IPv6, choisissez l'option Type de connexion IPv6 appropriée dans le menu déroulant. Si vous n'êtes pas sûr de l'option à choisir, contactez votre fournisseur d'accès Internet (FAI).", //IPV6_TEXT58
	"Si vous rencontrez des problèmes pour accéder à l'Internet IPv6 via le routeur, examinez  les paramètres que vous avez entrés et, le cas échéant, vérifiez-les avec votre FAI.", //IPV6_TEXT59
	"PARAMÈTRES 6to4", //IPV6_TEXT60
	"Entrez les informations relatives à l'adresse IPv6 fournies par votre fournisseur d'accès Internet (FAI).", //IPV6_TEXT61
	"Adresse 6to4", //IPV6_TEXT62
	"PARAMÈTRES DNS IPv6", //IPV6_TEXT63
	"Obtenir automatiquement une adresse de serveur DNS", //IPV6_TEXT65
	"Obscène", //_aa_bsecure_obscene
	"Utiliser les serveurs DNS IPv6 suivants", //IPV6_TEXT66
	"Cette section vous permet de configurer les paramètres du réseau interne de votre routeur.", //IPV6_TEXT67
	"Durée de vie de l'adresse", //IPV6_TEXT68
	"Durée de vie de l'annonce", //IPV6_TEXT69
	"Plage d'adresses (début)", //IPV6_TEXT70
	"Plage d'adresses (fin)", //IPV6_TEXT71
	"Saisissez les informations fournies par votre fournisseur d'accès Internet (FAI).", //IPV6_TEXT72
	"TEMPS D'INACTIVITÉ", //IPV6_TEXT73
	"Longueur du préfixe de sous-réseau", //IPV6_TEXT74
	"Passerelle IPv6 par défaut", //IPV6_TEXT75
	"La section IPv6 (Protocole Internet version 6) sert à configurer votre type de connexion IPv6.", //IPV6_TEXT76
	"Vous pouvez choisir parmi plusieurs types de connexions : Lien local, IPv6 statique, DHCPv6, autoconfiguration sans état, PPPoE, tunnel IPv6 dans IPv4 et 6to4. Si vous n'êtes pas sûr de votre méthode de connexion, contactez votre fournisseur d'accès Internet IPv6. Remarque : Si vous utilisez l'option PPPoE, vous devrez vous assurer que tous les logiciels clients PPPoE de vos ordinateurs soient désinstallés ou désactivés.", //IPV6_TEXT77
	"Mode lien local", //IPV6_TEXT78
	"L'adresse lien-local est utilisée par des nœuds et des routeurs lorsqu'ils communiquent avec des nœuds voisins sur le même lien. Ce mode active les périphériques compatibles IPv6 pour qu'ils communiquent les uns avec les autres côté réseau local.", //IPV6_TEXT79
	"Mode IPv6 statique", //IPV6_TEXT80
	"Ce mode est utilisé lorsque votre FAI vous fournit une adresse IPv6 définie qui ne change pas. Les informations IPv6 sont entrées manuellement dans vos paramètres de configuration IPv6. Vous devez entrer l'adresse IPv6, la longueur du préfixe de sous-réseau, la passerelle par défaut, le serveur DNS primaire, et le serveur DNS secondaire. Votre FAI vous fournit toutes ces informations.", //IPV6_TEXT81
	"Mode DHCPv6", //IPV6_TEXT82
	"Il s'agit d'une méthode de connexion où le FAI vous attribue votre adresse IPv6 lorsque votre routeur en demande une au serveur du FAI. Certains FAI vous demandent de procéder à certains paramétrages de votre côté avant que votre routeur ne puisse se connecter à l'Internet IPv6.", //IPV6_TEXT83
	"Mode autoconfiguration sans état", //IPV6_TEXT84
	"Méthode de connexion où le FAI vous attribue votre adresse IPv6 lorsque votre routeur en demande une à la passerelle par défaut. La configuration de l'adresse IPv6 repose sur la réception d'un message d'annonce de routeur.", //IPV6_TEXT85
	"Sélectionnez cette option si votre FAI vous demande d'utiliser une connexion PPPoE (Protocole Point à Point sur Ethernet) sur l'Internet IPv6. Les fournisseurs DSL utilisent généralement cette option.  Cette méthode de connexion vous demande d'entrer un <strong>Nom d'utilisateur</strong> et un <strong>Mot de passe</strong> (fournis par votre fournisseur d'accès Internet) pour pouvoir accéder à l'Internet IPv6. Les protocoles d'authentification pris en charge sont les protocoles PAP et CHAP.", //IPV6_TEXT86
	"Sélectionnez cette option si les serveurs du FAI attribuent l'adresse IPv6 de réseau étendu du routeur au moment de l'établissement d'une connexion, .", //IPV6_TEXT87
	"Si votre FAI a attribué une adresse IPv6 fixe, sélectionnez cette option. Le FAI fournit la valeur pour l'<SPAN class=option>adresse IPv6.</SPAN>", //IPV6_TEXT88
	"L'intervalle de temps pendant lequel la machine peut être inactive avant que la connexion au réseau étendu ne soit coupée. La valeur du temps d'inactivité maximum est uniquement utilisée pour les reconnexions \"à la demande\" et \"manuelle\".", //IPV6_TEXT89
	"Mode tunnel IPv6 dans IPv4", //IPV6_TEXT90
	"Le tunnelage IPv6 dans IPv4 est l'encapsulation de paquets IPv6 dans des paquets IPv4 de sorte que les paquets IPv6 puissent être envoyés sur une infrastructure IPv4.", //IPV6_TEXT91
	"Mode 6to4", //IPV6_TEXT92
	"6to4 est une attribution d'adresse IPv6 et une technologie de tunnelage automatique qui est utilisée pour fournir une connectivité IPv6 monodiffusion entre des sites et des hôtes IPv6 sur le réseau Internet IPv4.", //IPV6_TEXT93
	"Serveur DNS primaire, serveur DNS secondaire : Saisissez les adresses IPv6 des serveurs DNS. Laissez le champ vide pour le serveur secondaire s'il n'est pas utilisé.", //IPV6_TEXT94
	"Ces paramètres permettent de configurer l'interface IPv6 de réseau local du routeur. La configuration de l'adresse IPv6 de réseau local du routeur est basée sur l'adresse et le sous-réseau IPv6 attribués par votre FAI. (Un sous-réseau avec un préfixe /64 est pris en charge dans le réseau local.)", //IPV6_TEXT95
	"Utilisez cette section pour paramétrer l'autoconfiguration IPv6 afin d'attribuer une adresse IPv6 aux ordinateurs de votre réseau. Une méthode d'autoconfiguration sans état et une méthode d'autoconfiguration à état sont fournies.", //IPV6_TEXT96
	"Ces deux valeurs (De et À) définissent une plage d'adresses IPv6 que le serveur DHCPv6 utilise quand il attribue des adresses aux ordinateurs et aux périphériques de votre réseau local. Toutes les adresses qui se trouvent hors de cette plage ne sont pas gérées par le serveur DHCPv6. Toutefois, elles peuvent être utilisées pour les périphériques configurés manuellement ou pour les périphériques qui n'utilisent pas le protocole DHCP pour obtenir automatiquement des adresses réseau.", //IPV6_TEXT97
	"Lorsque vous sélectionnez À état (DHCPv6), les options suivantes s'affichent.", //IPV6_TEXT98
	"Les paramètres TCP/IP des ordinateurs (et des autres périphériques) connectés à votre réseau local doivent également être configurés sur \"DHCPv6\" ou sur \"Obtenir une adresse IPv6 automatiquement\".", //IPV6_TEXT99
	"Plage d'adresses IPv6 (DHCPv6)", //IPV6_TEXT100
	"Un ordinateur ou un périphérique qui est configuré manuellement peut avoir une adresse IPv6 qui réside dans cette plage.", //IPV6_TEXT102
	"Durée pendant laquelle un ordinateur bénéficie d'une adresse IPv6 avant de devoir en renouveler la concession.", //IPV6_TEXT103
	"Utiliser l'adresse lien-local", //IPV6_TEXT104
	"Activer le DHCP-PD automatique sur le réseau local", //IPV6_TEXT108
	"SLAAC + DHCPv6 sans état", //IPV6_TEXT106
	"Autoconfiguration (SLAAC/DHCPv6)", //IPV6_TEXT107
	"Activez l'autoconfiguration", //IPV6_TEXT50
	"Entrez un mot de passe pour l'utilisateur &quot;utilisateur&quot;, qui bénéficiera d'un accès en lecture seule à l'interface de gestion Web.", //help825
	"Assistant de configuration de connexion Internet IPv6", //IPV6_TEXT110
	"Configuration manuelle de connexion Internet IPv6", //IPV6_TEXT111
	"Connexion Internet IPv6", //IPV6_TEXT112
	"Vous pouvez configurer votre connexion Internet IPv6 de deux manières. Vous pouvez utiliser l'Assistant de configuration de connexion Internet IPv6 ou configurer la connexion manuellement.", //IPV6_TEXT113
	"Cet assistant vous guidera étape par étape pour configurer votre nouvelle connexion à Internet IPv6.", //IPV6_TEXT116
	"Étape 1 : Configurez votre connexion Internet IPv6", //IPV6_TEXT117
	"Étape 2 : Enregistrez les paramètres et connectez-vous", //IPV6_TEXT118
	"Le routeur est en train de détecter votre type de connexion Internet IPv6, veuillez patienter...", //IPV6_TEXT119
	"Le routeur ne parvient pas à détecter votre type de connexion Internet IPv6", //IPV6_TEXT120
	"Guidez-moi tout au long de la configuration IPv6", //IPV6_TEXT121
	"IPv6 sur PPPoE", //IPV6_TEXT122
	"Choisissez cette option si votre connexion Internet IPv6 requiert un nom d'utilisateur et un mot de passe. La plupart des modems DSL utilisent ce type de connexion.", //IPV6_TEXT123
	"Adresse IPv6 statique et acheminement", //IPV6_TEXT124
	"Choisissez cette option si votre fournisseur d'accès Internet (FAI) vous a fourni des informations sur l'adresse IPv6 à configurer manuellement.", //IPV6_TEXT125
	"Connexion par tunnels (6rd)", //IPV6_TEXT126
	"Choisissez cette option si votre fournisseur d'accès Internet (FAI) vous a fourni une connexion Internet IPv6 en utilisant le mécanisme de tunnels automatique 6rd.", //IPV6_TEXT127
	"Pour configurer cette connexion, vous avez besoin d'un nom d'utilisateur et d'un mot de passe fournis par votre fournisseur d'accès Internet IPv6. Si vous ne possédez pas ces informations, contactez votre fournisseur d'accès Internet.", //IPV6_TEXT128
	"Partager avec IPv4", //IPV6_TEXT129
	"Pour configurer cette connexion, vous devez posséder une liste complète des informations IPv6 fournies par votre fournisseur d'accès Internet IPv6. Si vous disposez d'une connexion IPv6 statique, mais pas de ces informations, contactez votre FAI.", //IPV6_TEXT130
	"Pour configurer cette connexion par tunnels 6rd, vous avez besoin des informations suivantes, fournies par votre fournisseur d'accès Internet IPv6. Si vous ne possédez pas ces informations, contactez votre fournisseur d'accès Internet.", //IPV6_TEXT131
	"Préfixe IPv6 en 6rd", //IPV6_TEXT132
	"Préfixe IPv6 attribué", //IPV6_TEXT133
	"Adresse IPv4 du relais 6rd en bordure du réseau", //IPV6_TEXT134
	"Serveur DNS IPv6", //IPV6_TEXT135
	"Les tâches de l'Assistant de configuration de connexion Internet IPv6 sont terminées. Cliquez sur le bouton Connecter pour enregistrer vos paramètres et réinitialiser le routeur.", //IPV6_TEXT136
	"Ipv6", //IPV6_TEXT137
	"Détection automatique", //IPV6_TEXT138
	"6rd", //IPV6_TEXT139
	"DS-Lite", //IPV6_TEXT140
	"Passage de tunnels Teredo", //IPV6_TEXT141
	"Configuration 6rd", //IPV6_TEXT142
	"Option DHCPv4 en 6rd", //IPV6_TEXT143
	"Configuration manuelle", //IPV6_TEXT144
	"Adresse lien-local du tunnel", //IPV6_TEXT145
	"CONNEXION INTERNET DE TYPE ADRESSE AFTR", //IPV6_TEXT146
	"Activer le serveur DHCP", //bd_EDSv
	"Saisissez l'adresse IP de l'ordinateur cible ou saisissez son nom de domaine complètement qualifié.", //htsc_pingt_h
	"Configuration de DS-Lite", //IPV6_TEXT149
	"Option DHCPv6 de DS-Lite", //IPV6_TEXT150
	"Adresse IPv6 en AFTR", //IPV6_TEXT151
	"Adresse IPv4 en B4", //IPV6_TEXT152
	"IPv6 WAN Default Gateway (Passerelle IPv6 par défaut du réseau étendu) :", //IPV6_TEXT153
	"Sélectionnez l'une des méthodes de configuration suivantes puis cliquez sur Suivant pour continuer.", //wps_KR37
	"Définition la connexion par adresse IPv6 statique", //IPV6_TEXT155
	"Les tâches de l'Assistant de configuration de connexion Internet IPv6 sont terminées. Cliquez sur le bouton Connecter pour enregistrer vos paramètres et réinitialiser le routeur.", //IPV6_TEXT156
	"SLAAC + RDNSS", //IPV6_TEXT157
	"IP cible/Longueur de préfixe", //IPV6_TEXT158
	"La plage d'adresses IPv4 en B4 s'étend de 192.0.0.2 à 192.0.0.7", //IPV6_TEXT159
	"Adresse AFTR", //IPV6_TEXT160
	"PPPoE IPv6 est partagée avec PPPoE IPv4. Veuillez d'abord modifier le protocole IPv4 du réseau étendu !", //IPV6_TEXT161
	"6rd utilise l'option DHCPv4. Veuillez d'abord modifier le protocole IPv6 du réseau étendu !", //IPV6_TEXT162
	"Le type de réseau étendu IPv6 doit être SLAAC/DHCPv6, PPPoE ou Mode détection automatique", //IPV6_TEXT163
	"Vous pouvez aussi activer le DHCP-PD pour déléguer les préfixes du routeur sur votre réseau local.", //IPV6_TEXT164
	"Tous les détails de réseau local IPv6 sont affichés ici.", //IPV6_TEXT165
	"Réseau IPv6 attribuée par DHCP-PD", //IPV6_TEXT166
	"Paramètres pour une Règle d’application", //haar_p
	"Serveur RADIUS de secours facultatif", //bws_ORAD
	"OPTIONS DE SÉCURITÉ", //DNS_TEXT2
	"DNS avancé&#8482", //DNS_TEXT3
	"Grâce au DNS avancé, votre connexion Internet est plus sûre, plus rapide, plus intelligente et plus fiable. Elle bloque les sites Web de hameçonnage pour vous prémunir du vol d'identité.", //DNS_TEXT4
	"Les contrôles parentaux OpenDNS disposent d'un filtrage de contenu Web primé qui rend votre connexion Internet plus sûre, plus rapide, plus intelligente et plus fiable. Avec plus de 50 catégories de contenu parmi lesquelles choisir, l'efficacité contre le contenu pour adultes, les proxies, les réseaux sociaux, les sites de hameçonnage, les logiciels malveillants, etc. est assurée. Entièrement configurable partout où un accès Internet est possible.", //DNS_TEXT8
	"Bloque automatiquement les sites Web pour adultes et de hameçonnage tout en améliorant la vitesse et la fiabilité de votre connexion Internet.", //DNS_TEXT6
	"OpenDNS&reg; FamilyShield&#8482", //DNS_TEXT5
	"De l'anglais <i>Open Systems Interconnection</i> : interconnexion de système ouvert. Il s'agit du modèle de référence qui gère le transfert de données entre deux périphériques d'un réseau.", //help639
	"Aucun : IP statique ou Obtenir automatiquement auprès du FAI", //DNS_TEXT9
	"Utilisez les serveurs DNS fournis par votre FAI ou saisissez vos propres serveurs DNS privilégiés.", //DNS_TEXT10
	"Bien que la fonction DNS avancé soit activée, vous pouvez modifier l'adresse IP DNS du poste de travail et lui attribuer celle de votre choix du serveur DNS. Notez que le routeur ne détermine pas la résolution DNS lorsque l'adresse IP DNS est configurée manuellement sur le poste de travail.", //DNS_TEXT11
	"Vous pouvez désactiver l'option DNS avancé si vous avez configuré un réseau privé virtuel ou un intranet sur votre réseau et que vous rencontrez des problèmes lorsque cette option est sélectionnée.", //DNS_TEXT12
	"TRENDNET | %m | Status | Device Information", //TEXT000
	"Autoconfiguration sans état", //TEXT001
	"Nom de serveur virtuel %s non valide. Caractère incompatible ',/,''\"", //TEXT002
	"Nom de règle '+ i +' incorrect. Caractère incompatible ',/,''", //TEXT003
	"Nom d'hôte incorrect. Caractère incompatible ',/,''", //TEXT004
	"Nom de domaine local non valide. Caractère incompatible ',/,'", //TEXT005
	"Nom de règle '+ i +' incorrect. Caractère incompatible ',/,''", //TEXT006
	"Nom de redirection de port '+ %s +' non valide. Caractère incompatible ',/,''", //TEXT007
	"Les règles '+i+' sont configurées en tant que règles '+j+'.", //TEXT008
	"obj_word + \" est en conflit avec un autre port privé.\"", //TEXT010
	"Nombre de clients sans fil", //sw_title_list
	"L'autre type de protocole n'est pas valide", //TEXT011
	"Veuillez choisir un périphérique sans fil avec wps !", //TEXT012
	"Le filtre entrant doit être inférieur à + rule_max_num", //TEXT013
	"Le nom ne peut pas être configuré sur le même que le nom de filtre entrant par défaut « Tout autoriser » ou « Tout refuser ».", //TEXT014
	"Règles de calendrier complètes ! Veuillez supprimer une entrée.", //TEXT015
	"Première page", //TEXT016
	"Dernière page", //TEXT017
	"Page précédente", //TEXT018
	"Activité du système", //TEXT019
	"Informations de débogage", //TEXT020
	"Attaques", //TEXT021
	"Paquets rejetés", //TEXT022
	"Aucune modification n'a été apportée. Procéder quand même à l'enregistrement ?", //LS3
	"Impossible de choisir la clé WEP 2, 3, 4 lorsque le WPS est activé !", //TEXT024
	"Impossible de choisir les modes WPA personnel/TKIP et AES lorsque la fonction WPS n'est pas activée !", //TEXT025
	"Impossible de choisir le mode WPA-Enterprise lorsque le WPS est activé !", //TEXT026
	"Impossible de choisir une clé partagée lorsque le WPS est activé !", //TEXT027
	"Veuillez d'abord activer le mode sans fil.", //TEXT028
	"La fonction WPS est déjà réglée sur Désactivé. Veuillez cliquer sur \"Oui\" pour l'activer ou sur \"Non\" pour quitter l'assistant.", //TEXT029
	"Les %s ne peuvent pas autoriser l'entrée d'IP de rebouclage ou d'IP multicast (127.x.x.x, 224.x.x.x à 239.x.x.x).", //TEXT030
	"Le port %s entré n'est pas valide.", //TEXT031
	"Le secret %s entré n'est pas valide.", //TEXT032
	"Adresse IP réservée", //TEXT033
	"Adresse IP de départ", //TEXT035
	"\"Adresse IP de fin\"", //TEXT036
	"L'adresse IP du réseau local et l'adresse IP de début ne sont pas dans le même sous-réseau", //TEXT037
	"L'adresse IP du réseau local et l'adresse IP de fin ne sont pas dans le même sous-réseau", //TEXT038
	"L'adresse IP de fin doit être supérieure à l'adresse IP de début", //TEXT039
	"Le paramètre a été enregistré.", //TEXT040
	"La clé ' + i + ' n'est pas valide. La clé doit être de ' + wep_key_len + ' caractères ou de ' + hex_len + ' caractères hexadécimaux.", //TEXT041
	"La clé ' + i + ' est fausse, les caractères valides sont 0 à 9, A à F, ou a à f.", //TEXT042
	"%s L'adresse IP de la passerelle %s doit se trouver dans le sous-réseau externe.", //TEXT043
	"Ce microprogramme est la dernière version.", //TEXT045
	"Erreur lors du contact du serveur, veuillez vérifier l'état de connexion Internet.", //TEXT046
	"Les adresse IP des réseaux étendu et local ne peuvent pas se trouver sur le même sous-réseau.", //TEXT047
	"Entrez une valeur pour une machine.", //aa_alert_10
	"Vous n'avez pas réussi à ajouter le périphérique sans fil au réseau sans fil dans le délai indiqué, veuillez cliquer sur le bouton ci-dessous pour recommencer.", //TEXT049
	"\"L'adresse IP \"+ res_ip +\"' est déjà utilisée.\"", //TEXT050
	"Le mot de passe confirmé ne correspond pas au nouveau mot de passe", //TEXT051
	"ÉGALEMENT APPELÉ WCN 2.0 DANS WINDOWS VISTA", //TEXT053
	"obj_word + ' est en conflit avec un port de pare-feu d'application.'", //TEXT055
	"obj_word + \" est en conflit avec un autre port public.\"", //TEXT009
	"obj_word + ' est en conflit avec un port de redirection de port.'", //TEXT054
	"Conflit de port.", //TEXT057
	"Conflit de port TCP.", //TEXT058
	"Conflit de port UDP.", //TEXT059
	"Le nom de redirection de port se trouve déjà dans la liste", //TEXT060
	"Voulez-vous activer l'entrée réservation DHCP pour l'adresse IP ' + DataArray[idx].IP", //TEXT062
	"La règle est utilisée par une autre règle et ne peut pas être supprimée.", //TEXT063
	"Le nom du calendrier n'est pas valide. Les caractères autorisés sont 0~9, A~Z ou a~z.", //TEXT064
	"Le nom de calendrier correspond au nom par défaut.", //TEXT065
	"Le nom de calendrier se trouve déjà dans la liste", //TEXT066
	"La règle est utilisée par une autre règle et ne peut pas être modifiée.", //TEXT067
	"Informations sur le réseau IPv6", //TEXT068
	"Tous les détails de votre connexion réseau et Internet IPv6 sont affichés sur cette page.", //TEXT069
	"Informations sur la connexion IPv6", //TEXT070
	"Paramètres de l’adresse IPv6", //TEXT071
	"Ordinateurs IPv6 du réseau local", //TEXT072
	"Réessayer", //TEXT073
	"Suivante", //TEXT074
	"Nom d'hôte ou Adresse IPv6", //TEXT075
	"Veuillez réessayer", //TEXT076
	"Session PPPoE", //TEXT077
	"Créer une nouvelle session", //TEXT078
	"La première adresse de %s doit être un entier.", //MSG002
	"La deuxième adresse de %s doit être un entier.", //MSG003
	"La troisième adresse de %s doit être un entier.", //MSG004
	"La quatrième adresse de %s doit être un entier.", //MSG005
	"Le %s est une adresse non valide.", //MSG006
	"Le %s ne peut pas être zéro.", //MSG007
	"Le secret %s entré n'est pas valide", //MSG008
	"Le secret %s entré n'est pas valide", //MSG009
	"Les %s ne peuvent pas autoriser l'entrée d'IP de rebouclage ou d'IP de multidiffusion (127.x.x.x, 224.x.x.x à 239.x.x.x).", //MSG010
	"La valeur de %s doit être numérique !", //MSG013
	"La plage de %s est %1n à %2n.", //MSG014
	"La plage de %s est %d à %d.", //MSG014a
	"La valeur de %s doit être un nombre pair.", //MSG015
	"La clé n'est pas valide. La clé doit comporter 5 ou 10 caractères hexadécimaux. Entrés par vous-même ", //MSG016
	"La clé n'est pas valide. La clé doit comporter 13 ou 26 caractères hexadécimaux. Entrés par vous-même ", //MSG017
	"La première adresse de %s doit être un hexadécimal.", //MSG018
	"La deuxième adresse de %s doit être un hexadécimal.", //MSG019
	"La troisième adresse de %s doit être un hexadécimal.", //MSG020
	"La quatrième adresse de %s doit être un hexadécimal.", //MSG021
	"La cinquième adresse de %s doit être un hexadécimal.", //MSG022
	"La sixième adresse de %s doit être un hexadécimal.", //MSG023
	"La septième adresse de %s doit être un hexadécimal.", //MSG024
	"La huitième adresse de %s doit être un hexadécimal.", //MSG025
	"La première plage de %s doit être comprise entre", //MSG026
	"La deuxième plage de %s doit être comprise entre", //MSG027
	"La troisième plage de %s doit être comprise entre", //MSG028
	"La quatrième plage de %s doit être comprise entre", //MSG029
	"La cinquième plage de %s doit être comprise entre", //MSG030
	"La sixième plage de %s doit être comprise entre", //MSG031
	"La septième plage de %s doit être comprise entre", //MSG032
	"La huitième plage de %s doit être comprise entre", //MSG033
	"Le %s ne peut pas autoriser l'entrée d'IP de rebouclage ( ::1 ).", //MSG034
	"Le %s ne peut pas autoriser l'entrée d'IP de multidiffusion ( FFxx:0:0:0:0:0:0:2 ou ffxx:0:0:0:0:0:0:2.", //MSG035
	"Le suffixe de", //MSG036_1
	"Le sous-réseau de", //MSG037_1
	" doit être au format hexadécimal.", //MSG038_1
	" n'est pas une adresse valide.", //MSG039_1
	"Le suffixe de '+tag +' doit être un hexadécimal.", //MSG036
	"Le suffixe de '+tag+' est une adresse non valide.", //MSG037
	"Le sous-réseau de '+tag +' doit être un hexadécimal.", //MSG038
	"Le sous-réseau de '+tag+' est une adresse non valide.", //MSG039
	"Le suffixe de la plage d'adresses IPv6 (début) plus que le suffixe de la plage d'adresses IPv6 (fin)", //MSG040
	"L'adresse IPv6 autorise deux fois deux points une fois uniquement.", //MSG041
	"L'adresse IPv6 n'est pas valide", //MSG042
	"Mesure non valide", //MSG043
	"Le mode 802.11n pur ne prend pas en charge le WEP.", //MSG044
	"Le mode 802.11n pur ne prend pas en charge le TKIP.", //MSG045
	"La plage de %s est comprise entre %s et ", //MSG046
	"Préfixe ULA IPv6 incorrect", //MSG047
	"Le champ du préfixe ULA est vide, utiliser le préfixe ULA par défaut ?", //MSG048
	"Vos résultats de recherche sont générés par Yahoo. La fonction de recherche vous permet de fluidifier considérablement votre navigation. Lorsqu'un site est inaccessible ou inexistant, nous émettons des suggestions de recherche plutôt que de laisser votre navigateur afficher un message d'erreur général. Nous corrigeons également automatiquement certaines fautes d'orthographe courantes introduites par l'utilisateur dans la barre d'adresse. La fonction de correction orthographique ne fonctionne que pour les domaines très connus (par ex. .cmo et .ogr). Vous serez peut-être parfois redirigés vers une page de résultats de recherche inappropriée. Si vous avez cliqué sur un lien contenu dans un spam, il est possible que le site ait été désactivé pour cause d'abus. Ce site n'existant plus, vous recevrez peut-être notre page de recherche.", //ADV_DNS_DESC3
	"La page demandée n'est pas disponible.", //ERROR404
	"Suggestions", //SUGGESTIONS
	"Assurez-vous que votre câble Internet soit correctement connecté au port Internet sur votre routeur et que votre voyant Internet clignote en vert ou bleu.", //SUGGESTIONS_1
	"Vérifiez que les <a href='http://<% CmoGetCfg('lan_ipaddr',''); %>/'>paramètres Internet</a> de votre routeur sont correctement définis, notamment vos paramètres de nom d'utilisateur/mot de passe PPPoE.", //SUGGESTIONS_2
	"(heure minute)", //tsc_hrmin_1
	"DHCP-PD", //DHCP_PD
	"Activer le DHCP-PD", //IPV6_TEXT147
	"Réseau IPv6 attribuée <br>par DHCP-PD", //DHCP_PD_ASSIGNED
	"Relais 6to4", //_6to4RELAY
	"Obtenir une adresse de serveur DNS automatiquement ou entrer une adresse de serveur DNS spécifique.", //IPV6_TEXT64
	"Utiliser l'adresse DNS IPv6 suivante", //IPV6_TEXT66_v6
	"Le passage du type usb à Windows Mobile, iPhone ou un téléphone androïde redémarre le périphérique.", //usb_reboot
	"Le passage du type usb à Windows Mobile ou iPhone redémarre le périphérique et remplace son adresse IP par 102.168.99.1.", //usb_reboot_chnip
	"Philippine", //country_8
	"Sélectionnez un téléphone usb", //_select_phone
	"Sélectionnez le téléphone 3G USB utilisé.", //_phone_info
	"Téléphone 3G USB", //usb_3g_phone
	"Windows Mobile 5", //usb_window_mobile_5
	"iPhone 3G(s)", //usb_iphone
	"Téléphone androïde", //android_phone
	"Affiche l'état actuel de la connexion au serveur DDNS.", //help901
	"Nom du périphérique", //DEVICE_NAME
	"La concession %v a été révoquée.", //IPDHCPSERVER_LEASE_REVOKED2
	"La réservation de concession %v a été supprimée.", //IPDHCPSERVER_LEASE_RESERVATION_DELETED
	"La concession %v a été renouvelée par le client %m", //IPDHCPSERVER_LEASE_RENEW
	"Réveil par le réseau", //help738
	"LAN (Réseau local)", //help759
	"Technologie la plus couramment utilisée pour les réseaux locaux.", //help517
	"Bits par seconde.", //help443
	"Caractères de A à Z et de 0 à 9.", //help414
	"Ok", //_ok
	"Valeur par défaut", //help486
	"DSL", //help503
	"Perte de puissance des signaux numériques et analogiques. Plus la distance de transmission du signal est grande, plus la perte est importante.", //help426
	"Bande passante", //help432
	"Division des données en blocs plus petits pour faciliter leur stockage.", //help527
	"Les filtres Web sont utilisés pour vous permettre d’établir une liste de sites Web autorisés qui peuvent être utilisés par plusieurs utilisateurs. Lorsque le filtrage Web est activé, tous les sites Web non répertoriés sur cette page sont bloqués. Pour utiliser cette fonction, vous devez également cocher la case \"Appliquer le filtre Web\" dans la section Contrôle d'accès.", //awf_intro_WF
	"De l'anglais <i>Post Office Protocol 3</i> : protocole de messagerie électronique version 3, utilisé pour recevoir des messages électroniques.", //help652
	"CardBus", //help456
	"Interface utilisateur graphique", //help539
	"Base de données", //help472
	"Serveur de fichiers", //help520
	"VoIP", //help737
	"Première couche du modèle OSI. Elle fournit les moyens matériels pour transmettre les signaux électriques sur un support de données.", //help646
	"Navigateur Web", //help745
	"Le préambule sert à synchroniser les communications entre les périphériques d'un réseau.", //help659
	"USB", //help727
	"FAI sans fil", //help753
	"De l'anglais <i>Internet Protocol</i>. Méthode de transfert de données d'un ordinateur à un autre sur Internet.", //help574
	"De l'anglais <i>Remote Authentication Dial-In User Service</i> : service d'authentification distant des utilisateurs entrants, qui permet aux utilisateurs distants d'entrer dans un serveur central et d'être identifiés pour accéder aux ressources d'un réseau.", //help663
	"Wi-Fi", //help748
	"Créez une liste de sites Web auxquels vous souhaitez que les périphériques puissent accéder sur votre réseau.", //hhwf_intro
	"Diode électroluminescente.", //help598
	"xDSL", //help761
	"Adresse IP qui est attribuée par un serveur DHCP et qui peut changer. Les fournisseurs d'accès à Internet par le câble utilisent généralement cette méthode pour attribuer des adresses IP à leurs clients.", //help510
	"IPsec", //help584
	"Utilitaire qui affiche les routes entre votre ordinateur et une destination donnée.", //help716
	"Débit binaire", //help440
	"Ligne de souscripteur numérique asymétrique", //help410
	"dBi", //help480
	"IEEE", //help559
	"Ethernet", //help516
	"Alphanumérique", //help413
	"De l'anglais <i>Maximum Transmission Unit</i> : unité de transmission maximale, qui correspond au plus grand paquet qui peut être transmis sur un réseau orienté paquets comme Internet.", //help619
	"Ordinateur sur un réseau qui stocke des données pour que les autres ordinateurs du réseau puissent y accéder.", //help521
	"De l'anglais <i>Direct Sequence Spread Spectrum</i>. Technique de modulation utilisée par les périphériques sans fil 802.11b.", //help494
	"Système de nom de domaine : Traduit des noms de domaine en adresses IP", //help498
	"Carte réseau", //help628
	"Clé de cryptage et de décryptage générée pour toutes les sessions de communication entre deux ordinateurs.", //help683
	"Gigabits par seconde", //help535
	"SPI :", //help695
	"De l'anglais <i>Wide Area Network</i> : réseau étendu.", //help740
	"Un FAI fournit un accès à Internet aux entreprises et aux particuliers.", //help578
	"Balise", //help438
	"Le service DNS dynamique est prévu par les entreprises pour permettre aux utilisateurs ayant des adresses IP dynamiques d'obtenir un nom de domaine qui sera toujours lié à leur adresse IP temporaire. Dès que l'adresse IP change, elle est mise à jour par le logiciel client exécuté sur un ordinateur ou par un routeur qui gère le service DNS dynamique.", //help508
	"ASCII", //help423
	"NetBIOS", //help625
	"Serveur", //help680
	"Dans le cadre d'un réseau sans fil, ce terme désigne des clients sans fil qui utilisent un point d'accès pour obtenir un accès au réseau.", //help568
	"Multidiffusion", //help620
	"Version Apple du service UPnP, qui permet aux périphériques d'un réseau de se découvrir les uns les autres et de se connecter sans besoin de configurer aucun paramètre.", //help667
	"Famille de spécifications pour les réseaux locaux sans fil (WLAN) développée par un groupe de travail de l'IEEE (Institut de l'ingénierie électrique et électronique).", //help766
	"RADIUS", //help662
	"Stateful inspection", //help701
	"Semi-duplex", //help542
	"Système de réseaux mondiaux qui utilise le protocole TCP/IP pour rendre des ressources accessibles à des ordinateurs du monde entier.", //help570
	"Ordinateur ou groupe d'ordinateurs qui sont accessibles à la fois par des internautes et par des utilisateurs du réseau local, mais qui ne sont pas protégés par les mêmes règles de sécurité que celles du réseau local.", //help489
	"Installer une version plus récente d'un logiciel ou d'un microprogramme.", //help723
	"Kilo-octet", //help593
	"Période durant laquelle quelque chose provoque le ralentissement des processus ou leur arrêt simultané.", //help447
	"De l'anglais <i>System Logger</i> : journal de marche. Une interface de journalisation distribuée pour rassembler en un même endroit les journaux provenant de différentes sources. Initialement développé pour UNIX, il est à présent disponible pour d'autres systèmes d'exploitation, dont Windows.", //help705
	"Connexion à un réseau local via l'une des normes sans fil 802.11.", //help755
	"H.323", //_H323
	"Présentation de données d'accréditation, comme un mot de passe, pour vérifier que la personne ou le périphérique est réellement celui ou celle qu'il ou elle prétend être.", //help427
	"Opération qui consiste à désembrouiller un message crypté pour obtenir un message en clair.", //help485
	"DHCP, de l'anglais <i>Dynamic Host Configuration Protocol</i> : protocole de configuration dynamique de l'hôte, utilisé pour attribuer automatiquement des adresses IP aux ordinateurs ou aux périphériques qui en font la demande, à partir d'une réserve prédéfinie d'adresses.", //help490
	"HTTP sur SSL est un protocole utilisé pour crypter et décrypter les transmissions HTTP.", //help555
	"Collision", //help462
	"De l'anglais <i>Virtual Private Network</i>. Tunnel sécurisé sur Internet pour connecter des bureaux ou des utilisateurs distants au réseau de leur entreprise.", //help732
	"Koctet", //help592
	"Périphérique qui permet de se connecter à un ordinateur via un câble coaxial et de bénéficier d'un accès à Internet fourni par un câblo-opérateur.", //help455
	"Cinquième couche du modèle OSI, qui coordonne la connexion et la communication entre des applications situées aux deux extrémités.", //help685
	"De nombreux sites Web créent des pages avec des images et du contenu d'autres sites Web. L'accès sera interdit si vous n'activez pas tous les sites Web utilisés pour créer une page. Par exemple, pour accéder à <code>my.yahoo.com</code>, vous devez activer l'accès à <code>yahoo.com</code>, à <code>yimg.com</code> et à <code>doubleclick.net</code>.", //help146
	"De l'anglais <i>Point-to-Point Protocol</i> : protocole point à point, utilisé par deux ordinateurs pour communiquer ensemble via une interface série, comme une ligne téléphonique.", //help655
	"Trame d'information grâce à laquelle l'une des stations d'un réseau Wi-Fi diffuse périodiquement des données de contrôle de réseau aux autres stations.", //help439
	"Dispositif permettant de transmettre et de recevoir des signaux de radiofréquence.", //help416
	"De l'anglais <i>Uniform Resource Locator</i> : identificateur uniforme de ressource. L'adresse URL est une adresse unique des fichiers accessible sur Internet.", //help726
	"SNMP", //help692
	"Hôte", //help550
	"La quantité de données qui peuvent être transférées au cours d'une période donnée.", //help714
	"De l'anglais <i>Digital Subscriber Line</i> : ligne d'abonné numérique. Connexion Internet à large bande passante sur les lignes téléphoniques.", //help504
	"Norme qui utilise une clé de 56 bits sélectionnés de façon aléatoire, qui doit être connue de l'expéditeur et du destinataire lors d'un échange d'informations.", //help469
	"Carte installée dans un ordinateur ou intégrée à la carte mère, et qui permet à l'ordinateur de se connecter à un réseau.", //help629
	"Voyant lumineux", //help597
	"Utilitaire qui vous permet d'afficher du contenu et d'interagir avec l'ensemble des informations du Web.", //help746
	"Wi-Fi", //help749
	"Deuxième couche du modèle OSI. Elle contrôle le mouvement des données sur la liaison physique d'un réseau.", //help471
	"Envoi d'informations de voix sur Internet, par opposition au RTC.", //help736
	"Durée nécessaire à un paquet pour aller d'un point à un autre sur un réseau. Ce terme désigne également le temps d'attente.", //help596
	"Protocole TCP", //help706
	"Réinitialiser", //help664
	"Architecture d'un pare-feu qui surveille le trafic sortant et entrant pour garantir que seules les réponses valides aux demandes sortantes sont autorisées à passer par le pare-feu.", //help702
	"WISP", //help756
	"Protocole IP", //help573
	"Groupe d'ordinateurs d'un même local qui accèdent habituellement à des fichiers à partir d'un serveur.", //help601
	"Couche session", //help684
	"RSA", //help678
	"De l'anglais <i>Wi-Fi Protected Access</i> : accès protégé Wi-Fi. Évolution de la norme Wi-Fi qui améliore le cryptage des données, qui se rapporte au protocole WEP.", //help760
	"Gigabit Ethernet", //help536
	"Nom de domaine", //help499
	"De l'anglais <i>Internet Group Management Protocol</i> : protocole de gestion de groupe sur Internet, utilisé pour s'assurer que les ordinateurs peuvent signaler aux routeurs adjacents leur appartenance au groupe de multidiffusion.", //help562
	"WCN", //help741
	"Norme qui offre une constance des transmissions voix et vidéo et une compatibilité des périphériques de visioconférence.", //help541
	"Protocole UDP", //help717
	"Protocole L2TP", //help604
	"Diffusion individuelle", //help718
	"Ordinateur sur un réseau.", //help551
	"Fournisseur d'accès à Internet (FAI)", //help577
	"Conversion de données en cryptogramme pour rendre difficile leur lecture.", //help515
	"Envoi de données d'un périphérique à plusieurs autres sur un réseau.", //help621
	"De l'anglais <i>Advanced Encryption Standard</i>. Norme de cryptage gouvernementale.", //help412
	"Débit", //help713
	"De l'anglais <i>Simple Mail Transfer Protocol</i> : protocole simple de transfert de courrier, utilisé pour envoyer et recevoir du courrier électronique.", //help687
	"Infrastructure", //help567
	"De l'anglais <i>Microsoft Point-to-Point Encryption</i> : cryptage point à point Microsoft. Méthode de cryptage utilisée pour sécuriser les transmissions de données sur des connexions PPTP.", //help618
	"Nombre de bits transmis pendant une période donnée.", //help441
	"Donnée", //help466
	"SMTP", //gw_vs_5
	"Zone démilitarisée", //help488
	"Kilobit par seconde", //help591
	"Périphérique qui permet aux clients sans fil de se connecter au réseau et d'y accéder.", //help402
	"Qualité de service", //help661
	"Zone démilitarisée", //help495
	"FAI", //help587
	"Préambule", //help658
	"Mettre à niveau", //help722
	"Décibels par rapport à un milliwatt.", //help483
	"RIP", //help670
	"WPA", //help750
	"Navigateur", //help452
	"Filtre de paquets dynamique", //help696
	"Répéteur", //help668
	"Nombre maximal d'octets ou bits par seconde qui peuvent être transmis depuis et vers un périphérique réseau.", //help433
	"Ordinateur sur un réseau qui fournit des services et des ressources aux autres ordinateurs du réseau.", //help681
	"Protocole NTP", //help632
	"ADSL", //help409
	"802.11", //help765
	"Couche application", //help421
	"URL", //help725
	"QS", //help660
	"L'IPSec sécurise la couche de traitement des paquets d'un réseau de communication.", //help576
	"Version actualisée d'une norme de sécurité pour réseaux sans fil, qui offre des fonctions d'authentification et de cryptage.", //help751
	"Voix sur IP", //help735
	"Point d'accès", //help401
	"POP3", //gw_vs_6
	"Certificat numérique", //help491
	"Large bande", //help448
	"De l'anglais <i>Internet Key Exchange</i> : échange de clé sur Internet. Ce protocole est utilisé pour garantir la sécurité des connexions VPN.", //help566
	"Aide - Glossaire", //help398
	"De l'anglais <i>Internetwork Packet Exchange</i> : échange de paquets sur Internet. Le protocole IPX est un protocole réseau développé par Novel pour autoriser ses clients et serveurs Netware à communiquer.", //help586
	"Protocole TCP/IP pour transmettre des flux de données d'imprimante.", //help710
	"Protocole SMTP", //help686
	"Technologie de transmission qui offre un débit de 1 milliard de bits par seconde.", //help537
	"PPP", //help654
	"Protocole TCP/IP", //help708
	"De l'anglais <i>American Standard Code for Information Interchange</i> : code américain standard pour l'échange d'informations. Ce système de caractères est le plus couramment utilisé pour les fichiers texte.", //help424
	"     Duplex", //help505
	"Dans le cas de la version 4 du protocole IP, numéro de 32 bits qui identifie chaque ordinateur transmettant des données sur Internet ou un Intranet.", //help583
	"Rétrocompatible", //help430
	"Décryptage", //help484
	"Modem câble", //help454
	"Concentrateur", //help556
	"Couche liaison de données", //help470
	"De l'anglais <i>Simple Network Management Protocol</i> : protocole simple de gestion des réseaux, qui gère et surveille les périphériques réseau.", //help689
	"Cookie", //help464
	"Programme ou utilisateur qui demande des données à un serveur.", //help461
	"Nov.", //tt_Nov
	"Traceroute", //help715
	"De l'anglais <i>Network Address Translation</i> : traduction d'adresses de réseau, qui permet à plusieurs adresses IP privées de se connecter à Internet ou à un autre réseau par le biais d'une seule adresse IP.", //help622
	"Réseau privé virtuel (VPN)", //help731
	"ARP. Utilisé pour lier des adresses MAC à des adresses IP de sorte que les conversions puissent être faites dans les deux directions.", //help408
	"Protocole SNMP", //help688
	"Information qui est stockée sur le disque dur de votre ordinateur et qui conserve vos préférences vis-à-vis du site qui en est à l'origine.", //help465
	"Masque de sous-réseau", //help703
	"SSH", //help697
	"Adresse MAC", //help605
	"Action consistant à transmettre des paquets de données d'un routeur à un autre.", //help549
	"Envoi et réception simultanés de transmissions de données.", //help506
	"Séquence de caractères utilisée pour authentifier les demandes de ressources sur un réseau.", //help642
	"Adresse IP privée automatique (APIPA)", //help428
	"Clé de session", //help682
	"Méthode électronique pour fournir des données d'accréditation à un serveur afin de pouvoir accéder à un réseau ou à ce serveur.", //help492
	"Fragmentation ", //help526
	"Troisième couche du modèle OSI qui gère le routage du trafic sur un réseau.", //help631
	"Identifiant matériel unique attribué à chaque carte Ethernet par son fabricant.", //help606
	"Redémarrer un ordinateur et recharger son système d'exploitation ou son microprogramme à partir de sa mémoire non volatile.", //help665
	"La section répertorie les sites Web actuellement autorisés.", //help148
	"Estimation du débit annulée car manque de ressources", //RATE_ESTIMATOR_RESOURCE_ERROR
	"Norme qui permet à des périphériques réseau de se découvrir l'un l'autre et de se configurer automatiquement pour faire partie du réseau.", //help721
	"HTTPS", //gw_vs_2
	"UTP", //help729
	"De l'anglais <i>Wireless ISP</i> : FAI sans fil.", //help757
	"Latence", //help595
	"De l'anglais <i>Routing Information Protocol</i> : protocole d'information de routage, utilisé pour synchroniser la table de routage de tous les routeurs d'un réseau.", //help671
	"De l'anglais <i>Wired Equivalent Privacy</i> : &quot;intimité équivalente à celle d'un câble&quot;. Protocole de sécurité pour les réseaux sans fil, supposé comparable à la sécurité d'un réseau câblé.", //help747
	"TCP/IP", //help707
	"Transmission des données dans toutes les directions à la fois.", //help451
	"Message stocké sur ordinateur transmis via Internet.", //help514
	"Protocole d'authentification extensible", //help512
	"Mode de connexion le plus couramment utilisé pour Ethernet.", //help675
	"Liste des contrôles d'accès (LCA)", //help399
	"Système d'entrée/sortie de base du réseau", //help626
	"Antenne", //help415
	"Périphérique qui connecte votre réseau à un autre réseau, par exemple Internet.", //help533
	"Navigateur Web développé et fourni par Microsoft.", //help572
	"Périphérique réseau qui permet de connecter plusieurs périphériques ensemble.", //help557
	"Norme de cryptage des données", //help468
	"Envoi d'une requête d'un ordinateur vers un autre ordinateur pour obtenir le transfert d'un fichier de l'ordinateur à l'origine de la demande vers l'autre ordinateur.", //help724
	"Programme utilitaire qui vérifie qu'une adresse Internet donnée existe et qu'elle peut recevoir des messages. L'utilitaire envoie un paquet de contrôle à l'adresse donnée et attend une réponse.", //help648
	"Veuillez patienter", //wt_title
	"De l'anglais <i>Point-to-Point Tunneling Protocol</i> : protocole de tunnellisation point à point, utilisé pour créer des tunnels VPN sur Internet entre deux réseaux.", //help657
	"dBm", //help482
	"Algorithme utilisé pour le cryptage et l'authentification.", //help679
	"Capacité des nouveaux périphériques à communiquer et à interagir avec des périphériques patrimoniaux plus anciens pour garantir une interopérabilité.", //help431
	"Institute of Electrical and Electronics Engineers", //help560
	"De l'anglais <i>Windows Connect Now</i>. Méthode mise au point par Microsoft pour configurer et amorcer le matériel réseau sans fil (points d'accès) et les clients sans fil, dont les PC et autres périphériques.", //help742
	"Large bande de fréquences disponibles pour transmettre des données.", //help449
	"IKE", //help565
	"(Autre possibilité.) Cliquez sur l'option de <em>continuation</em> pour choisir ultérieurement l'option de <em>refus</em> lorsquil vous est demandé d'imprimer une page de test.", //wprn_tt7
	"Héritage", //help599
	"IPX", //help585
	"Envoi et réception simultanés de données.", //help530
	"NetBEUI", //help623
	"WLAN (Réseau local sans fil)", //help758
	"CR", //help634
	"Réseau plus étendu auquel est connecté votre réseau local, qui peut être Internet ou un réseau régional ou professionnel.", //help752
	"Association de sécurité IPSec", //help575
	"Diffusion", //help450
	"CONNEXION PHYSIQUE DU PORT INTERNET COUPÉE", //ES_CABLELOST_bnr
	"Quand deux périphériques du même réseau Ethernet essayent de transmettre ou transmettent des données exactement au même instant.", //help463
	"Protocole de résolution d'adresse (ARP)", //help407
	"Programme qui vous permet d'accéder à l'ensemble des ressources disponibles sur le Web et qui les affiche sous forme graphique.", //help453
	"IGMP", //help561
	"Bit/s", //help442
	"Terme générique qui désigne les technologies de ligne d'abonné numérique (DSL), comme l'ADSL, l'HDSL, le RADSL et le SDSL.", //help762
	"De l'anglais <i>Hypertext Transfer Protocol</i> : protocole de transfert hypertexte, utilisé pour transférer des fichiers de serveurs HTTP (serveurs Web) à des clients HTTP (navigateurs Web).", //help553
	"Kbit/s", //help590
	"Mégabit par seconde", //help608
	"Norme de cryptage avancé (AES)", //help411
	"DNS", //gw_vs_4
	"Hexadécimal", //help546
	"Point limite de canal logique dans un réseau. Un ordinateur ne devrait avoir qu'un seul canal physique (son canal Ethernet), mais il peut avoir plusieurs ports (canaux logiques), chacun d'entre eux étant identifié par un numéro.", //help653
	"Décibels par rapport au radiateur isotropique", //help481
	"Duplex intégral", //help529
	"Affaiblissement", //help425
	"Base de données de périphériques réseau autorisés à accéder à des ressources du réseau.", //help400
	"Adresse IP dynamique", //help509
	"DHCP", //_DHCP
	"TCP brut", //help709
	"UPnP", //help720
	"USB", //help728
	"Information qui a été convertie en binaire pour pouvoir être traitée ou déplacée par un autre périphérique.", //help467
	"Communication entre un expéditeur et un destinataire.", //help719
	"Réseau local.", //help594
	"Nouvelle version de l'interface Carte PC ou PCMCIA. Elle gère les chemins de données de 32 bits et les accès directs à la mémoire, et requiert une tension moindre.", //help457
	"Rendezvous", //help666
	"De l'anglais <i>Secure Shell</i> : interpréteur de commandes sécurisé. Interface de ligne de commande qui permet d'établir des connexions sécurisées avec des ordinateurs distants.", //help698
	"IUG", //help538
	"Couche réseau", //help630
	"Septième couche du modèle OSI. Elle fournit des services aux applications pour garantir qu'elles puissent communiquer de façon appropriée avec d'autres applications d'un réseau.", //help422
	"Modulation à spectre étalé à séquence directe (DSSS)", //help493
	"Service DNS dynamique", //help507
	"Internet Explorer", //help571
	"Estimation du débit annulée car les mesures n'ont pas convergé", //RATE_ESTIMATOR_CONVERGENCE_ERROR
	"Valeur ou paramètre prédéterminé utilisé par un programme quand aucune modification n'a été apportée par l'utilisateur à cette valeur ou ce paramètre.", //help487
	"De l'anglais <i>NetBIOS Extended User Interface</i> : interface utilisateur étendue de NetBIOS. Protocole de communication sur un réseau local. Il s'agit d'une version actualisée de NetBIOS.", //help624
	"Les données ne peuvent pas être transmises et reçues en même temps.", //help543
	"De l'anglais <i>Service Set Identifier</i> : identifiant d'ensembles de services. Il s'agit d'un nom d'un réseau sans fil.", //help700
	"Client", //help460
	"UTP", //help730
	"Envoi d'une requête d'un ordinateur à un autre ordinateur pour obtenir le transfert d'un fichier vers l'ordinateur à l'origine de la demande.", //help502
	"Courrier électronique", //help513
	"De l'anglais <i>Session Initiation Protocol</i> : protocole d'ouverture de session. Il s'agit d'un protocole standard  pour ouvrir une session d'utilisateur qui fait intervenir du contenu multimédia, comme la voix ou les conversations en ligne.", //help690
	"Mbit/s", //help607
	"Programme qui est intégré à un périphérique matériel et qui lui indique comment fonctionner.", //help525
	"Entreprise qui offre une connexion à Internet à large bande par une connexion sans fil.", //help754
	"MPPE", //help617
	"Nom associé à une adresse IP.", //help500
	"Protocole ICMP", //help558
	"Adresse IP qu'un ordinateur sous Windows attribue lui-même quand il est configuré pour obtenir automatiquement une adresse IP, mais qu'aucun serveur DHCP n'est disponible sur le réseau.", //help429
	"EAP", //help511
	"Gbit/s", //help534
	"&quot;Zone démilitarisée&quot;. Ordinateur qui se trouve logiquement dans un &quot;no-man's land&quot; entre le réseau local et le réseau étendu. Un ordinateur DMZ échange une partie de la protection des mécanismes de sécurité du routeur contre l'avantage d'être directement adressable depuis Internet.", //help496
	"Goulot d'étranglement", //help446
	"Permet de mettre sous tension un ordinateur par le biais de sa carte réseau.", //help739
	"Le masque de réseau détermine la portion d'une adresse IP qui désigne le réseau et celle qui désigne l'hôte.", //help627
	"Sessions actives", //_actsess
	"La priorité 0 est réservée", //help91a
	"Les flux auxquels aucune règle n'a attribué de priorité reçoivent une priorité basse.", //help91b
	"Les choix courants peuvent être sélectionnés dans le menu déroulant.", //help92x1
	"Pour définir un autre protocole, saisissez le numéro de protocole correspondant (<a href='http://www.iana.org/assignments/protocol-numbers' target='_blank'> attribué par IANA</a>) dans la zone <span class='option'>Protocole</span>.", //help92x2
	"Lorsqu'une application LAN qui utilise un protocole autre qu'UDP, TCP ou ICMP initie une session Internet, la NAT du routeur peut suivre une telle session même si elle ne reconnaît pas le protocole. Cette fonction est utile parce qu'elle autorise certaines applications (et plus important une connexion VPN unique à un système hôte distant) sans nécessiter de passerelle ALG.", //TA21
	"Notez que cette fonction ne sapplique pas à l'hôte DMZ (en cas d'activation). L'hôte DMZ gère toujours ces types de session.", //TA22
	"sont recommandées.", //help183
	"Sélectionnez cette case pour permettre au serveur DHCP de mettre à disposition des hôtes LAN les paramètres de configuration NetBIOS.", //help400_b
	"Le cas échéant, l'activation de la fonction d'annonce NetBIOS entraîne l'obtention d'éventuelles informations WINS côté WAN.", //help401_b
	"Configurez l'adresse IP du serveur WINS préféré.", //help402_b
	"ActiveX", //help403
	"Configurez l'adresse IP du serveur WINS de secours (le cas échéant).", //help403_b
	"Spécification Microsoft pour l'interaction de composants logiciels.", //help404
	"Il sagit dun paramètre avancé qui est normalement laissé en blanc. Il permet la configuration dun nom de domaine NetBIOS sous lequel fonctionnent les hôtes réseau.", //help404_b
	"Réseau ad-hoc", //help405
	"Indique la façon dont les hôtes réseau doivent exécuter l'enregistrement et la recherche de noms NetBIOS.", //help405_b
	"Erreur de configuration poste %u", //WIFISC_AP_PEER_CFG_ERR
	"AppleTalk", //help417
	"Ensemble de protocoles de réseau local développé par Apple pour ses systèmes informatiques.", //help418
	"Protocole de résolution d'adresse AppleTalk (AARP)", //help419
	"Protocole utilisé pour établir une correspondance entre les adresses MAC d'ordinateurs Apple et leurs adresses réseau AppleTalk, pour que les conversions puissent être réalisées dans les deux sens.", //help420
	"BIOS", //help434
	"De l'anglais <i>Basic Input/Output System</i> : système de base d'entrée/sortie. Programme que le processeur d'un ordinateur utilise pour démarrer le système une fois qu'il est allumé.", //help435
	"Baud", //help436
	"Vitesse de transmission des données.", //help437
	"BOOTP", //help444
	"Protocole Bootstrap. Il permet aux ordinateurs d'être amorcés et d'obtenir une adresse IP sans intervention de l'utilisateur.", //help445
	"CAT 5", //help458
	"Catégorie 5. Utilisée pour les connexions Ethernet 10/100 Mbit/s ou 1 Gbit/s.", //help459
	"DB-25", //help474
	"Connecteur mâle à 25 broches pour connecter les modems externes ou les périphériques série RS-232.", //help475
	"DB-9", //help476
	"Un connecteur 9 broches pour les connexions RS-232", //help477
	"dBd", //help478
	"Décibels par rapport au doublet.", //help479
	"Fibre optique", //help518
	"Moyen d'envoi de données via des impulsions de lumière sur des fils ou des fibres de verre ou de plastique.", //help519
	"Partage de fichiers", //help522
	"Le partage de fichiers permet à des données présentes sur des ordinateurs d'un réseau d'être accessibles à d'autres ordinateurs de ce même réseau avec différents niveaux de droits d'accès.", //help523
	"De l'anglais <i>File Transfer Protocol</i> : protocole de transfert de fichiers. Il s'agit du moyen le plus simple de transférer des fichiers d'un ordinateur à un autre sur Internet.", //help528
	"Gain", //help531
	"Degré de renforcement du signal sans fil par un amplificateur.", //help532
	"Hachage", //help544
	"Transformation d'une chaîne de caractères en une chaîne plus courte de longueur prédéfinie.", //help545
	"Saut", //help548
	"IIS", //help563
	"De l'anglais <i>Internet Information Server</i> : serveur d'information sur Internet. L'ISS consiste en un serveur Web et un serveur FTP fournis par Microsoft.", //help564
	"Intranet", //help579
	"Réseau privé.", //help580
	"Détection d'intrusion", //help581
	"Type de sécurité qui analyse un réseau pour détecter d'éventuelles attaques dont l'origine est intérieure ou extérieure au réseau.", //help582
	"Java", //help588
	"Langage de programmation utilisé pour créer des programmes et des applets pour des pages Web.", //help589
	"LPR/LPD", //help602
	"De l'anglais <i>Line Printer Requestor/Line Printer Daemon</i> : demandeur d'imprimante par ligne/démon d'imprimante par ligne. Protocole TCP/IP pour transmettre des flux de données d'imprimante.", //help603
	"MDI", //help609
	"De l'anglais <i>Medium Dependent Interface</i> : interface dépendant du support. Port Ethernet destiné à être connecté à un câble droit.", //help610
	"MDIX", //help611
	"De l'anglais <i>Medium Dependent Interface Crossover</i> : interface croisée dépendant du support. Port Ethernet destiné à être connecté à un câble inverseur.", //help612
	"MIB", //help613
	"De l'anglais <i> Management Information Base</i> : base d'informations de gestion. Il s'agit d'un ensemble d'objets qui peut être géré via le protocole SNMP.", //help614
	"Modem", //help615
	"Périphérique qui module les signaux numériques émis par un ordinateur en signaux analogiques afin de les transmettre via les lignes téléphoniques. De même, il démodule les signaux analogiques provenant des lignes téléphoniques en signaux numériques pour votre ordinateur.", //help616
	"Oct.", //tt_Oct
	"Émetteur", //sa_Originator
	"De l'anglais <i>Orthogonal Frequency-Division Multiplexing</i> : multiplexage par répartition orthogonale de la fréquence. Technique de modulation pour les normes 802.11a et 802.11g.", //help637
	"De l'anglais <i>Open Shortest Path First</i> : &quot;ouvrir le chemin le plus court d'abord&quot;. Il s'agit d'un protocole de routage, plus souvent utilisé que le protocole RIP dans les grands réseaux car seules les modifications apportées à la table de routage sont envoyées à tous les autres routeurs du réseau, au contraire des fonctions RIP qui envoient la totalité de la table de routage à intervalle régulier.", //help641
	"OSI", //help638
	"La configuration en mode ouvert n'est pas sûre.", //msg_non_sec
	"Personnel", //LW24
	"L'interconnexion de périphériques réseau dans un rayon de 10 mètres.", //help644
	"PoE", //help649
	"De l'anglais <i>Power over Ethernet</i> : alimentation électrique par câble Ethernet. Il s'agit d'un moyen de transmission d'électricité par les paires inutilisées d'un câble Ethernet de catégorie 5.", //help650
	"RJ-11", //help672
	"Mode de connexion le plus couramment utilisé pour les téléphones.", //help673
	"RS-232C", //help676
	"Interface pour les communications en série entre ordinateurs et autres périphériques connexes.", //help677
	"SOHO", //help693
	"Petite entreprise/entreprise à domicile", //help694
	"TFTP", //help711
	"De l'anglais <i>Trivial File Transfer Protocol</i> : protocole simplifié de transfert de fichiers. Le protocole TFTP est un utilitaire de transfert de fichiers, plus simple à utiliser que le protocole FTP mais moins riche en fonctions.", //help712
	"Réseau local virtuel", //help733
	"De l'anglais <i>Virtual Local Area Network</i> : réseau local virtuel.", //help734
	"WDS", //help743
	"De l'anglais <i>Wireless Distribution System</i> : système de distribution sans fil. Système qui permet l'interconnexion sans fil de points d'accès.", //help744
	"Antenne Yagi", //help763
	"Antenne directionnelle utilisée pour concentrer les signaux sans fil à un endroit précis.", //help764
	"Notez que le message de connexion utilise la langue en vigueur au moment de l'événement connecté. Si vous changez de langue, il est possible que tous les messages de journalisation ne soient pas affichés dans la même langue.", //help795a
	"Interne", //sa_Internal
	"Externe", //sa_External
	"OpenDNS&reg; Contrôles parentaux&#8482", //DNS_TEXT7
	"Select a filter that controls access as needed for this admin port. If you do not see the filter you need in the list of filters, go to the <a href ='Inbound_Filter.asp' onclick ='return jump_if();'>Advanced &rarr;&nbsp;Inbound&nbsp;Filter</a> screen an", //help831_1
	"Options permettant d'améliorer la vitesse et la fiabilité de votre connexion Internet, d'appliquer un filtrage au contenu et de vous protéger des sites de hameçonnage. Choisissez parmi des faisceaux pré-configurés ou enregistrez votre routeur auprès d'OpenDNS&reg; pour choisir parmi 50 catégories de contenu et effectuer un blocage personnalisé.", //DNS_TEXT1
	"Ajouter/Modifier une règle de calendrier", //help191
	"Enregistre la règle nouvelle ou modifiée de filtre entrant dans la liste suivante.", //help198
	"Inconnu, veuillez patienter...", //_unknown_wait
	"Inconnu", //_unknown
	"S/O", //_na
	"Aucune information relative à un ordinateur n'a encore été fournie.", //_sdi_nciy
	"Client DHCP", //_sdi_dhcpclient
	"Client BigPond", //_sdi_bpc
	"Anciens périphériques ou technologies.", //help600
	"Aucune information de membres du groupe de multidiffusion.", //_bln_nmgmy
	"Configuration incorrecte", //_sdi_s1
	" Changement d'état (veuillez patienter...)", //_sdi_s10
	" Déconnecté", //_sdi_s8
	" Échec", //_sdi_s9
	"jour(s),", //_sdi_days
	"(déconnexion dans", //_sdi_disconnectpending
	"secondes)", //_sdi_secs
	"Renouveler DHCP", //sd_Renew
	"Libérer DHCP", //sd_Release
	"Déconnecter", //sd_Disconnect
	"Ouverture de session BigPond", //sd_bp_login
	"Fermeture de session BigPond", //sd_bp_logout
	"Canal", //_channel
	"Journaux système", //sl_SLogs
	"Statut du Serveur d’impression", //sps_intro2
	"les imprimantes sont", //sps_pare
	"Table de routage", //sr_RTable
	"Le menu État de redirection affiche les données relatives aux voies activées sur votre routeur. La liste affiche l'adresse IP cible, l'adresse IP de passerelle, le masque de sous-réseau, la mesure et l'interface de chaque voie.", //sr_intro
	"Stat du trafic de réseau", //ss_title_stats
	"Liste de clients sans fil associés", //sw_title
	"Valeur non valide pour le dépassement de temps mort Admin, elle doit être comprise entre 1 et 65535.", //ta_alert_1
	"Vérifiez que le câble reliant le modem ADSL/câblé et le routeur est correctement connecté. Le routeur tentera de nouveau de détecter votre type de connexion Internet.", //ES_CABLELOST_dsc1
	"Saisissez deux mots de passe identiques et réessayez", //_pwsame
	"Port de gestion à distance ''+data.wan_web_port+'' non valide, il doit être compris entre 1 et 65535.", //ta_alert_3
	"Le fournisseur de service DNS dynamique indiqué n'est pas pris en charge", //_invalidddnsserver
	"L'adresse de serveur indiquée est vierge", //_blankddnsserver
	"Veuillez d'abord modifier le protocole IPv6 du réseau étendu !", //IPV6_TEXT1
	"La valeur du temps de dépassement ne peut pas être égale à zéro.", //td_alert_2
	"La valeur du temps de dépassement ne peut pas être supérieure à 8760.", //td_alert_3
	"DNS Dynamique (DDNS)", //td_DDNSDDNS
	"Sélectionner le serveur DNS dynamique", //tt_SelDynDns
	"Le nom de compte doit être valide.", //_emailaccnameisblank
	"L’address email émettrice ne doit pas être vide.", //_blankfromemailaddr
	"L’address email de destination ne doit pas être vide.", //_blanktomemailaddr
	"L’adresse du Serveur SMTP ne doit pas être vide.", //_blanksmtpmailaddr
	"L’adresse Email '' + from_addr + '' est invalide.", //_badfromemailaddr
	"L’adresse Email '' + to_addr + '' est invalide.", //_badtoemailaddr
	"L’adresse du Serveur SMTP '' + data.smtp_email_server_addr + '' est invalide.", //_invalidsmtpserveraddr
	"L\'adresse du serveur SMTP n\'est pas autorisée.", //_badsmtpserveraddr
	"Une nouvelle version du microprogramme est disponible.", //tf_NFWA
	"Le délai de la session Web est dépassé. Veuillez vous connecter à nouveau pour accéder à cette page.", //tf_alert_1
	"D\'après le résultat de la vérification en ligne, la dernière version de microprogramme est :", //tf_LFWVis
	"La vérification de la disponibilité d\'une mise à jour du microprogramme est en cours.", //tf_FWCinP
	"Vérification de la disponibilité d\'un nouveau microprogramme", //tf_Ching_FW
	"La notification par e-mail nest pas activée.", //tf_EM_not
	"Dernière version de firmware", //tf_LFWV
	"Rechercher maintenant la dernière version du microprogramme en ligne", //tf_FWChNow
	"Des mises à jour du microprogramme sont lancées régulièrement pour améliorer les fonctions de votre routeur et ajouter des fonctions. Si vous rencontrez un problème avec une fonction spécifique du routeur, consultez notre site de support en cliquant sur lien <strong>Rechercher maintenant la dernière version du microprogramme en ligne</strong> et vérifiez si un microprogramme mis à jour est disponible pour votre routeur.", //TA17
	"Recherche des imprimantes", //tps_sfp
	"Double-clic sur une icône pour installer l'imprimante", //tps_dci
	"Configuration du serveur d'impression", //tps_intro2
	"Aucun jour n'est sélectionné pour le calendrier ''+(data.sched_table[i].sched_name)+''.", //tsc_alert_1
	"Date non valide", //tsc_alert_2
	"\"Le nom de calendrier '\"+(data.sched_table[i].sched_name)+\"' est réservé et ne peut pas être utilisé\"", //tsc_alert_3
	"Cette planification est déjà utilisée", //tsc_alert_6
	"Il n'y a plus de place pour d’autres entrées", //tsc_alert_9
	"Sélectionner le(s) jour(s)", //tsc_SelDays
	"Intervalle de temps", //tsc_TimeFr
	"L'adresse IP du serveur Syslog ne doit pas être identique à celle de l’adresse IP de passerelle.", //tsl_alert_3
	"L'adresse IP du serveur Syslog est dans le sous-réseau du WAN, il doit être dans le sous-réseau du LAN ('+lan_subnet+')", //tsl_alert_1
	"L'adresse IP du serveur Syslog doit être dans le sous-réseau du LAN ('+lan_subnet+')", //tsl_alert_2
	"Une fois votre routeur configuré, vous pouvez enregistrer ses paramètres dans un fichier de configuration.", //ZM18
	"millisecondes. TTL =", //tsc_pingt_msg9
	"NTP", //help635
	"Le temps de la passerelle a été mis à jour", //tt_alert_tupdt
	"Semaine", //TA24
	"Jour de la semaine", //TA25
	"Accès interdit", //fb_FbAc
	"La sentinelle a bloqué l'accès au Web", //sentinel_1
	"L’accès à ce site Web a été bloqué sur cet ordinateur par le service sentinelle de votre routeur.", //sentinel_2
	"Contactez l'administrateur de votre service sentinelle pour autoriser l'accès à cette page.", //sentinal_3
	"Echec", //fl_Failure
	"Les nouveaux réglages n'ont pas été sauvegardés parce qu'une erreur s'est produite.", //fl_text
	"Une nouvelle mise à jour du microprogramme est disponible. Vous allez être redirigé vers la page de mise à jour lors de votre connexion.", //li_newfw
	"Vous allez maintenant être redirigé vers la page de connexion.", //rd_p_1
	"Si la page de connexion ne s'affiche pas, cliquez sur <a href='login.asp'>ce lien</a>.", //rd_p_2
	"Restauration des réglages", //rs_Restoring_Settings
	"Le fichier de configuration est invalide.", //reh
	"Restauration des paramètres en cours, veuillez patienter...", //rs_RSPW
	"Données locales converties", //rs_cld
	"Terminé", //rs_Done
	"Données locales décompactées", //rs_uld
	"Données enregistrées décompactées", //rs_usd
	"Données enregistrées converties", //rs_csd
	"Recompactées", //rs_Repacked
	"Converties", //rs_Converted
	"Enregistrement", //rs_Saving
	"Le routeur doit être redémarré pour appliquer les nouveaux paramètres. Vous pouvez le redémarrer maintenant à l'aide du bouton ci-dessous ou apporter d'autres changements, puis utiliser le bouton de redémarrage sur la page Outils/Système.", //sc_intro_rb
	"Reconnexion", //_relogin
	"Masque de sous-réseau étendu non valide.", //_badWANsub
	"Adresse IP de passerelle non valide.", //wwa_pv5_alert_4
	"L'adresse IP de la passerelle n'est pas dans le sous-réseau du WAN", //wwa_pv5_alert_5
	"Vous devez indiquer le serveur DNS primaire", //wwa_pv5_alert_8
	"Adresse IP DNS primaire non valide.", //wwa_pv5_alert_6
	"Adresse IP DNS secondaire non valide.", //wwa_pv5_alert_7
	"La zone d\'identification de l\'utilisateur ne peut pas être vide", //wwa_pv5_alert_21
	"Adresse IP de la passerelle PPTP incorrecte", //_badPPTPgwip
	"Adresse du Serveur PPTP inavalide", //wwa_pv5_alert_15
	"Adresse IP de la passerelle L2TP incorrecte", //_badL2TPgwip
	"Adresse du serveur L2TP incorrecte", //wwa_pv5_alert_20
	"Pour protéger votre réseau des pirates et des utilisateurs non autorisés, il est vivement recommandé de choisir l'un des paramètres de sécurité de réseau sans fil suivants.", //wwl_intro_s3_1
	"Il existe trois niveaux de sécurité sans fil : bonne sécurité, sécurité améliorée ET sécurité optimale. Le niveau choisi dépend des fonctions de sécurité que vos adaptateurs sans fil prennent en charge.", //wwl_intro_s3_2r
	"Mot de passe sans fil de sécurité", //wwl_WSP_1
	"WPA-PSK/TKIP (également connu comme WPA personnel )", //wwl_wpa
	"WPA2-PSK/AES (ou WPA2 Personal)", //wwl_wpa2
	"TELNET", //gw_vs_0
	"ORDINATEUR DE BUREAU DISTANT", //gw_vs_8
	"Discussion sur AIM", //gw_sa_0
	"Téléphone IP Calista", //gw_sa_2
	"ICQ", //gw_sa_3
	"MSN Messenger", //gw_sa_4
	"PalTalk", //YM47
	"Sélectionner un serveur BigPond", //gw_SelBPS
	"Nom1", //gw_bp_0
	"Nom2", //gw_bp_1
	"Nom3", //gw_bp_2
	"PlayStation2", //gw_gm_81
	"Le contrôle ActiveX WCN n\'est pas disponible. Vérifiez le paramètre de sécurité et actualisez cette page pour l\'installer.", //gw_wcn_alert_4
	"WCN ne gère pas les index de clés différents de 1 pour le moment.", //gw_wcn_alert5
	"WCN ne gère pas le mode WPA2 pour le moment.", //gw_wcn_alert6
	"WCN ne gère pas l\'authentification WPA pour le moment.", //gw_wcn_alert7
	"Paramètres sans fil enregistrés avec succès.", //gw_wcn_err_ok
	"Code d\'erreur :", //gw_wcn_err_code
	"Cette version du système d\'exploitation ne gère pas la technologie WCN.", //gw_wcn_err_os_version
	"Échec du chargement du fichier de configuration sans fil. Exécutez l\'Assistant Réseau sans fil de Windows pour créer/recréer le fichier de configuration.", //gw_wcn_err_load_config
	"Échec de l\'ajout du profil sans fil. Assurez-vous que le nouveau SSID n\'est pas incompatible avec un profil existant.", //gw_wcn_err_provision
	"Impossible d’écrire les données sans fil dans le fichier de configuration. Veuillez vérifier le réglage de sécurité", //gw_wcn_err_io_write_config
	"Impossible de chiffrer les données sans fil.", //gw_wcn_err_encryption
	"Une exception interne s\'est produite", //gw_wcn_err_exception
	"Le contrôle WCN ActiveX n\'est pas enregistré. Veuillez vérifier le réglage de sécurité et régénérer cette page pour l\'installer.", //gw_wcn_err_com
	"Réglages sans fil invalides. Veuillez vérifier les réglages sans fil", //gw_wcn_err_bad_wsetting_entry
	"Impossible de créer le profile sans fil xml", //gw_wcn_err_bad_wps_profile
	"Le mode de sécurité WPA n\'est pas validé. Veuillez vérifier les réglages de sécurité WPA", //gw_wcn_err_unsupported_wsetting
	"L\'analyseur MSXML2 DOM à échoué à analyser la chaîne au format XML", //gw_wcn_err_dom_processing
	"Erreur inattendue", //gw_wcn_err_default
	"Autoriser à quiconque", //adv_Everyone
	"N'autoriser à personne", //adv_Noone
	"Placé dans la file d\'attente", //psQueued
	"Démarrage", //psStarting
	"Fermé", //psClosed
	"Inactif", //psIdle
	"Prêt", //psReady
	"Offre reçue pour la session PPPoE %s ; le service offert est %s à partir de %s (%m)", //GW_PPPOE_EVENT_OFFER
	"Débranché", //psUnplugged
	"Impression en cours", //psPrinting
	"Le protocole PAP a envoyé une réponse d'authentification \'%s\' au poste distant.", //IPPPPPAP_AUTH_RESULT
	"'La chaîne '' + value + '' est trop longue\n(sa longueur maximale est de ' + length + ' caractères).'", //up_gS_1
	"'La valeur '' + value + '' n\'est pas valide.'", //up_gIUH_1
	"'La valeur '' + value + '' doit être positive.'", //up_gIUH_2
	"'La valeur '' + value + '' doit être comprise entre '+ min + ' et ' + max + '.'", //up_gIUH_3
	"'La chaîne hexadécimale '' + value + '' n\'est pas valide.'", //up_gH_1
	"Il n\'y plus de place pour des entrées supplémentaires.", //up_ae_se_1
	"Le champ %s ne peut pas être vide.", //up_ai_se_2
	"this.primary_key_name+' ''+ this.thearray[-1][this.primary_key] +'' est déjà utilisé.'", //up_ae_se_3
	"Les modifications apportées à l'entrée en cours de modification ne sont pas enregistrées.", //up_ae_wic_1
	"Cliquez sur \'Ok\' pour annuler ces modifications et effectuer l'action demandée.", //up_ae_wic_2
	"Remarque :<br />Quand le relais DNS est activé conjointement avec la fonction DNS avancé, les postes de travail du réseau configurés pour obtenir une adresse IP du serveur DHCP du routeur se verront attribuer l'adresse 192.168.0.1 (adresse IP du routeur). Toutefois, le trafic sera toujours protégé.", //_Advanced_02
	"Voulez-vous annuler tous les changements apportés à cet assistant ?", //up_fm_dc_1
	"La restauration des paramètres a échoué.", //up_fm_re_1
	"Cliquez sur OK pour continuer.", //up_fm_re_2
	"mauvais fichier de paramètres", //up_fm_dr_1
	"mauvais fichier de paramètres", //up_fm_dr_2
	"Les données restaurées ne sont pas acceptables.", //up_fm_dr_3
	"L'action ne peut pas se terminer car la connexion réseau semble hors service.", //up_if_1
	"Réinitialisation.", //up_rb_3
	"Restauration des paramètres par défaut et réinitialisation.", //up_rb_6
	"'La chaîne ''+input_string+'' de l'intervalle de ports '+name+' n'est pas valide.'", //up_vp_1
	"'Le port '+name+' ''+n+'' dans la chaîne d'intervalle de ports ''+input_string+'' doit être compris entre 1 et 65535.'", //up_vp_2
	"'L'intervalle de ports ''+got2[0]+'' '+name+' dans la chaîne d'intervalle de ports ''+input_string+'' doit aller du port le plus petit au port le plus grand.'", //up_vp_3
	"'La chaîne d'intervalle de ports '+name+' ne peut pas être vide.'", //up_vp_0
	"Un champ d'adresse MAC ne peut pas être vide.", //up_vm_1
	"n'est pas une adresse MAC valide.", //up_vm_2
	"Une erreur est survenue sur cette page, sans doute parce que\n+ vous n'êtes pas connecté comme il convient, par exemple juste après une réinitialisation.\n", //up_he_1
	"Cliquez sur OK pour atteindre la page de connexion ou\n+ sur annuler pour afficher le message d'erreur.", //up_he_2
	"L'erreur à la ligne '+line+' de '+url+' est :\n\''+msg+'\'.", //up_he_5
	"PalTalk", //gw_sa_5
	"Paquet bloqué de %v à %v reçu sur la mauvaise interface réseau (Spoofing d'adresse IP)", //IPSTACK_REJECTED_SPOOFED_PACKET
	"La tentative d'attribution de concession a échoué - un hôte de réseau local actif avec adresse %v et MAC %m a été détecté", //IPDHCPSERVER_HOST_IS_ACTIVE
	"L'autorisation du service %S a échoué : le service n'est pas enregistré.", //BSECURE_LOG_AUTH_FAIL_UNREG
	"Le débit estimé de la liaison est de %d kbit/s.", //RATE_ESTIMATOR_RATE_IS
	"Filtre ; paquet refusé de l'adresse IP %v du port %u, protocole %u, à l'adresse IP %v du port %u.", //GW_IPFILTER_DENY
	"Impossible d'établir une connexion avec le serveur d'e-mail.", //GW_SMTP_EMAIL_CANNOT_CREATE_CONNECTION
	"Paquet rejeté vers destination illégale %v à partir de %v.", //IPNAT_ILLEGAL_DEST
	"Serveur de filtre %S déconnecté : dépassement du délai d'attente", //BSECURE_LOG_FLTR_DISCONNECTED_TIMEOUT
	"Le client %02x:%02x:%02x:%02x:%02x:%02x a sa concession (%v) révoquée.", //IPDHCPSERVER_LEASE_REVOKED1
	"Message précédent répété une fois.", //LOG_PREV_MSG_REPEATED_1_TIME
	"UPnP a changé l'entrée VS %v <-> %v:%d <-> %v:%d %s en %s", //GW_UPNP_PORTMAP_VS_CHANGE
	"Concession %v expirée.", //IPDHCPSERVER_LEASE_EXPIRED
	"L'autorisation du service %S a échoué : erreur interne", //BSECURE_LOG_AUTH_FAIL_INTNL
	"Suppression de l'entrée UPnP %v <-> %v:%d %s", //GW_UPNP_PORTMAP_DEL
	"Impossible d'envoyer un message électronique car \'%s\' n'est pas une adresse \'À:\' valide.", //GW_SMTP_EMAIL_INVALID_TO_ADDRESS
	"Serveur de filtre %S déconnecté : fermé", //BSECURE_LOG_FLTR_DISCONNECTED_CLOSED
	"Concession expirée ; %v a été réattribuée car un client a expressément demandé cette adresse.", //IPDHCPSERVER_LEASE_EXPIRED_SPECIFIC
	"L'autorisation du service %S a réussi", //BSECURE_LOG_AUTH_PASS
	"L'autorisation du service %S a échoué : le serveur d'authentification a renvoyé une erreur de type INCONNU", //BSECURE_LOG_AUTH_FAIL_UNKNW
	"PAP seulement", //wwan_auth_pap
	"L'autorisation du service %S a échoué : le service a besoin d'un renouvellement", //BSECURE_LOG_AUTH_FAIL_RENEW
	"Le client %m voulait l'adresse spécifique (%v) mais elle n'est pas disponible", //IPDHCPSERVER_LEASE_DENIED
	"Impossible d'envoyer un message électronique (délai de connexion dépassé)", //GW_SMTP_EMAIL_TIMEOUT
	"L'autorisation du service %S a échoué : le serveur d'authentification a renvoyé une erreur de base de données", //BSECURE_LOG_AUTH_FAIL_DB
	"Le paramètre %u du serveur DHCP a été mis à jour.", //IPDHCPSERVER_PARAM_DB_UPDATED
	"Règles d'application", //APP_RULES
	"Tableau de concession plein.", //IPDHCPSERVER_LEASE_POOL_FULL
	"Échec de l'authentification PAP, veuillez vérifier les informations de connexion.", //IPPPPPAP_AUTH_SUCCESS
	"Réseau Avançé", //ADVANCED_NETWORKS
	"Une nouvelle concession %v a été attribuée au client %m", //IPDHCPSERVER_LEASE_ASSIGNED
	"Serveur de filtre %S connecté", //BSECURE_LOG_FLTR_CONNECTED
	"Serveur d'authentification %S connecté", //BSECURE_LOG_AUTH_CONNECTED
	"L'autorisation du service %S a échoué : paquet de réponse d'authentification corrompu", //BSECURE_LOG_AUTH_FAIL_PKT
	"Échec de la connexion du client SMTP au serveur %v.", //IPSMTPCLIENT_CONN_FAILED
	"Échec de l'authentification PAP, veuillez vérifier les informations de connexion.", //IPPPPPAP_AUTH_FAIL
	"La dernière version de progiciel récupérée du serveur était %d.%d", //GW_LOG_ON_LATEST_FIRMWARE_RETRIEVED
	"Impossible d'envoyer un message électronique (état d'envoi %u).", //GW_SMTP_EMAIL_SEND_FAILURE
	"La concession %v a été libérée par le client %m", //IPDHCPSERVER_LEASE_RELEASED
	"Le paramètre %u du serveur DHCP a été ajouté à la base de données des paramètres.", //IPDHCPSERVER_PARAM_DB_ADDED
	"Authentification PAP réussie.", //IPPPPPAP_AUTH_TIMEOUT
	"Délai d'attente : %d %s pour l'ajout de l'entrée UPnP %v <-> %v:%d <-> %v:%d %s", //GW_UPNP_PORTMAP_ADD
	"Impossible d'envoyer un message électronique car l'adresse IP du serveur est inconnue.", //GW_SMTP_EMAIL_NO_SERVER_IP_ADDRESS
	"Délai d'attente : %d %s pour le renouvellement de lentrée UPnP %v <-> %v:%d <-> %v:%d %s", //GW_UPNP_PORTMAP_REFRESH
	"Expiration de l'entrée UPnP %v <-> %v:%d <-> %v%d %s %s", //GW_UPNP_PORTMAP_EXPIRE
	"Le paramètre %u du serveur DHCP a été supprimé de la base de données des paramètres.", //IPDHCPSERVER_PARAM_DB_REMOVED
	"La concession a été supprimée de la file d'attente du regroupement de serveurs %v.", //IPDHCPSERVER_LEASE_DELETED
	"Conflit UPnP avec entrée existante %v <-> %v:%d <-> %v:%d %s %s", //GW_UPNP_PORTMAP_CONFLICT
	"Certains composants requis n'ont pas été chargés ; cette page va être actualisée.", //TA1
	"n'est pas une adresse IP valide", //aa_alert_11
	"Cette règle de contrôle d'accès est déjà définie par la politique + data.access_ctrl_table[i].policy_name", //aa_alert_1
	"Il y a des politiques non sauvegardées ' + unsaved_policies +', voulez-vous abandonner ces politiques.", //aa_sched_conf_3
	"'La règle de filtre port '' + data.access_ctrl_table[-1].port_filter_table[i].entry_name + '' est reproduite.'", //aa_alert_16
	"La première adresse IP de destination pour le Filtre de Port = ''+data.access_ctrl_table[-1].port_filter_table[j].entry_name+'' ne doit pas être dans le sous-réseau du réseau local  ('+lan_subnet+')", //aa_alert_2
	"La dernière adresse IP de destination pour le Filtre de Port = ''+data.access_ctrl_table[-1].port_filter_table[j].entry_name+''  ne doit pas être dans le sous-réseau du réseau local  ('+lan_subnet+')", //aa_alert_3
	"Champ d’adresses IP de destination invalide pour le Filtre de Port = ''+data.access_ctrl_table[-1].port_filter_table[j].entry_name+''", //aa_alert_4
	"Champ des ports de destination invalide pour le Filtre de Port =''+data.access_ctrl_table[-1].port_filter_table[j].entry_name+'' 'doit être dans l’étendue (1,,65535)", //aa_alert_5
	"Le premier port de destination pour le Filtre de Port= ''+data.access_ctrl_table[-1].port_filter_table[j].entry_name+'' ne doit pas être plus grand que le dernier", //aa_alert_6
	"Autres ordinateurs", //_aa_other_machines
	"&copy; Copyright 2015 TRENDnet. All Rights Reserved.", //_copyright
	"L'intervalle valide du seuil de fragmentation est compris entre 256 et 65535.", //aw_alert_1
	"L'intervalle valide du seuil RTS est compris entre 1 et 65535.", //aw_alert_2
	"L'intervalle de balisage valide est compris entre 20 et 1000.", //aw_alert_3
	"L'intervalle DTIM valide est compris entre 1 et 255.", //aw_alert_4
	"L'adresse de la zone DMZ doit être dans le sous-réseau local ('+lan_subnet+').", //af_alert_1
	"Adresse DMZ est interdite", //af_alert_2
	"(désactivé automatiquement si le service UPnP est activé)", //TA19
	"Cet enregistrement ’''+ data.game_rules[j].entry_name + '' est déjà présent.", //ag_alert_4
	"Cet enregistrement '+ data.game_rules[j].entry_name + ' est un doublon de '' + data.game_rules[i].entry_name + ''.", //ag_alert_5
	"'Ports TCP['+data.game_rules[i].tcp_ports_to_open+']sont en conflit avec  '+data.game_rules[j].entry_name+' Ports TCP['+data.game_rules[j].tcp_ports_to_open+']'", //ag_conflict10
	"'Ports UDP['+data.game_rules[i].udp_ports_to_open+'] sont en conflit avec '+data.game_rules[j].entry_name+' Ports UDP['+data.game_rules[j].udp_ports_to_open+']'", //ag_conflict20
	"Veuillez sélectionner un calendrier pour l'enregistrement ' + data.game_rules[i].entry_name + ''.'", //ag_conflict21
	"L'adresse IP de ''+data.game_rules[i].entry_name+'' doit être dans le sous-réseau local ('+lan_subnet+').", //ag_alert_1
	"L'adresse IP de ''+data.game_rules[i].entry_name+'' n'est pas autorisée.", //ag_alert_3
	"L'un ou l'autre des champs \'Ports TCP à ouvrir\' et \'Ports UDP à ouvrir\' doit être rempli.", //ag_alert2
	"Ports TCP", //_tcpports
	"Ports UDP", //_udpports
	"%s ports[%s] est en conflit avec le port de gestion à distance", //ag_conflict4
	"Vous ne pouvez pas renommer cette entrée car elle est utilisée dans la page '+used_page+'.", //tsc_alert_7
	"'Plage de source IP invalide pour ''+data.ingress_rules[i].ingress_filter_name+'''+' ('+data.ingress_rules[i].ip_range_table[j].ip_start+','+data.ingress_rules[i].ip_range_table[j].ip_end+')'", //ai_alert_3
	"Activer au moins une plage d'adresses IP source pour %s", //GW_FIREWALL_NO_IP_RANGE_INVALID
	"La plage de filtres entrants '%s - %s' est en double.", //ai_alert_7
	"'Le nom du filtre entrant ''+(data.ingress_rules[i].ingress_filter_name)+'' est réservé et ne peut pas être employé'", //ai_alert_4
	"'La règle de filtre entrant  '' + data.ingress_rules[-1].ingress_filter_name + '' est reproduite. '", //ai_alert_6
	"'Vous ne pouvez pas supprimer cette entrée car elle est utilisée dans la page '+x+'.'", //tsc_alert_5
	"Règles de filtre entrant", //ai_title_2
	"Modifier", //_edit
	"Intervalle IP source", //_srcip
	"Début de la source IP", //ai_c2
	"Fin de la source IP", //ai_c3
	"\"' + saved_records[i].mac_addr + '\" Adresse MAC en double.'", //amaf_alert_1
	"Refusez l'accès à tous excepté les machines dans cette liste (sujet à \'Réglages de filtre\'):", //am_cMT_deny
	"Permettez l'accès à tous excepté les machines dans cette liste (sujet à \'Réglages de filtre\'):", //am_cMT_Allow
	"Aucune information sur les routes.", //_sr_nriy
	"Cette route interne est déjà utilisée", //ar_alert_1
	"Cette route existe déjà", //ar_alert_2
	"La valeur métrique doit être entre 1 et 16.", //ar_alert_3
	"Next Hop n’est pas sur l'interface indiquée", //ar_alert_4
	"Masque de sous réseau invalide.", //ar_alert_5
	"L'option de routage vous permet de définir des routes précises pour des destinations précises.", //ar_RoutI
	"Voie", //ar_Route
	"Liste des routes", //ar_RoutesList
	"Supprimer", //_delete
	"Routes existantes", //ar_ERTable
	"Le nom des règles d'application ' + saved_records[i].entry_name + ' est en double.", //ag_alert_duplicate_name
	"Le nom des règles d'application ' + saved_records[j].entry_name + ' est un doublon de ' + saved_records[i].entry_name + '", //ag_alert_duplicate
	"Cette règle est déjà utilisée.", //ag_inuse
	"'La plage des ports de déclenchement  '+protocols[ae.thearray[-1].trigger_ports.protocol]+' ['+ae.thearray[-1].trigger_ports.port_range+'] est conflictuelle avec '+saved_records[i].entry_name+':'+protocols[saved_records[i].trigger_ports.protocol]+' ['+saved_records[i].trigger_ports.port_range+']'", //_specapps_alert_2
	"Plage des ports de déclenchement", //_specapps_tpr
	"Plage des ports d’entrée", //_specapps_ipr
	"Règles spéciales d'applications", //as_title_SAR
	"Plage des ports de déclenchement", //as_TPRange
	"exemple :", //as_ex
	"Protocole de déclenchement", //as_TPR
	"Plage des ports d’entrée", //as_IPR
	"Protocole d’entrée", //as_IPrt
	"La vitesse de transmission maximale doit être comprise entre 8 kbit/s et 10 Mbit/s.", //at_alert_1_1
	"Le nom ne peut pas être vide.", //at_alert_15
	"La priorité '+data.qos_rules[i].priority+' de la règle ''+data.qos_rules[i].entry_name+'' doit être comprise entre 1 et 255.'", //at_alert_16
	"Le protocole correspondant à la règle ''+data.qos_rules[i].entry_name+'' ne peut pas être vierge.'", //at_alert_17
	"La plage d'adresses IP source ''+data.qos_rules[i].source_ip_start+'' correspondant à la règle ''+data.qos_rules[i].entry_name+'' doit se trouver sur le sous-réseau du réseau local ('+lan_subnet+').'", //at_alert_2
	"La plage d'adresses IP source ''+data.qos_rules[i].source_ip_start+'' correspondant à la règle ''+data.qos_rules[i].entry_name+'' n'est pas valide.'", //at_alert_18
	"La plage d'adresses IP source ''+data.qos_rules[i].source_ip_end+'' correspondant à la règle ''+data.qos_rules[i].entry_name+'' doit se trouver sur le sous-réseau du réseau local ('+lan_subnet+').'", //at_alert_3
	"La plage d'adresses IP source ''+data.qos_rules[i].source_ip_end+'' correspondant à la règle ''+data.qos_rules[i].entry_name+'' n'est pas valide.'", //at_alert_19
	"La plage d'adresses IP source correspondant à la règle ''+data.qos_rules[i].entry_name+'' n'est pas valide.'", //at_alert_4
	"La plage d'adresses IP cible ''+data.qos_rules[i].dest_ip_start+'' correspondant à la règle ''+data.qos_rules[i].entry_name+'' ne doit pas se trouver sur le sous-réseau du réseau local ('+lan_subnet+').'", //at_alert_5
	"La plage d'adresses IP cible ''+data.qos_rules[i].dest_ip_start+'' correspondant à la règle ''+data.qos_rules[i].entry_name+'' n'est pas valide.'", //at_alert_20
	"La plage d'adresses IP cible ''+data.qos_rules[i].dest_ip_end+'' correspondant à la règle ''+data.qos_rules[i].entry_name+'' ne doit pas se trouver sur le sous-réseau du réseau local ('+lan_subnet+').';", //at_alert_6
	"La plage d'adresses IP cible ''+data.qos_rules[i].dest_ip_end+'' correspondant à la règle ''+data.qos_rules[i].entry_name+'' n'est pas valide.'", //at_alert_21
	"La plage d'adresses IP cible correspondant à la règle ''+data.qos_rules[i].entry_name+'' n'est pas valide.'", //at_alert_8
	"La plage de ports source correspondant à la règle ''+data.qos_rules[i].entry_name+'' doit être comprise entre 0 et 65535.'", //at_alert_7
	"Le port source de départ correspondant à la règle ''+data.qos_rules[i].entry_name+'' doit être inférieur au port source de fin.'", //at_alert_10
	"La plage de ports cible correspondant à la règle ''+data.qos_rules[i].entry_name+'' doit être comprise entre 0 et 65535.'", //at_alert_9
	"Le port cible de départ correspondant à la règle ''+data.qos_rules[i].entry_name+'' doit être inférieur au port cible de fin.'", //at_alert_11
	"Le nom ''+data.qos_rules[i].entry_name+'' est déjà utilisé.'", //at_alert_22
	"La plage d'adresses IP source/cible correspondant à ''+data.qos_rules[j].entry_name+'' chevauche ''+data.qos_rules[i].entry_name+''.'", //at_alert_23
	"La plage d'adresses IP/ports source/cible correspondant à ''+data.qos_rules[j].entry_name+'' chevauche ''+data.qos_rules[i].entry_name+''.'", //at_alert_24
	"Le protocole \"PEU IMPORTE\" inclut ICMP ; les plages de ports sont donc désactivées. Sélectionnez TCP ou UDP pour configurer des plages de ports.", //at_alert_14
	"Peu importe", //at_Prot_0
	"Plage de ports source", //_srcport
	"Plage IP de destination", //at_DIPR
	"Plage de ports de destination", //at_DPR
	"'L’enregistrement '' + data.virtual_servers[i].entry_name + '' est dupliqué.'", //av_alert_11
	"L'enregistrement ' + data.virtual_servers[j].entry_name + ' est un doublon de ' + data.virtual_servers[i].entry_name + '.", //av_alert_21
	"Veuillez sélectionner un calendrier pour l'enregistrement ' + data.virtual_servers[i].entry_name + '.", //av_alert_24
	"L'adresse IP de ' + data.virtual_servers[i].entry_name + ' doit se situer sur le sous-réseau local ('+lan_subnet+')", //av_alert_1
	"' Adresse IP pour '' + data.virtual_servers[i].entry_name + '' n’est pas autorisé'", //av_alert_2
	"'Port privé pour '' + data.virtual_servers[i].entry_name + '' doit être dans la plage (1..65535)'", //av_alert_3
	"'Port public pour '' + data.virtual_servers[i].entry_name + '' doit être dans la plage (1..65535)'", //av_alert_4
	"'Le port public ne doit pas le même que le port de gestion à distance'", //av_alert_12
	"'Création d’entrée pour ICMP (protocole 1) impossibe car ceci empêchera le routeur de travailler correctement'", //av_alert_18
	"Impossible de créer une entrée pour IGMP (protocole 2) car cela empêchera le routeur de fonctionner correctement", //av_alert_23
	"'Veuillez choisir TCP au lieu de protocole 6 et indiquez les détails du port'", //av_alert_19
	"'Veuillez choisir UDP au lieu de protocole 17 et indiquez les détails du port'", //av_alert_20
	"'Un autre protocole pour '' + data.virtual_servers[i].entry_name + '' doit être dans la plage (2..5, 7..16 ou 18..255)'", //av_alert_13
	"'Protocole pour '' + data.virtual_servers[i].entry_name + ' se recouvre avec '' + data.virtual_servers[j].entry_name+'''", //av_alert_17
	"'Ports pour '' + data.virtual_servers[i].entry_name + '' se recouvrent avec '' + data.virtual_servers[j].entry_name+'''", //av_alert_5
	"'Port privé pour '' + data.virtual_servers[i].entry_name + '' est en conflit avec '' + data.virtual_servers[j].entry_name+'''", //av_alert_6
	"ALG FTP est activé", //av_alert_7
	"ALG PPTP est activé", //av_alert_8
	"ALG Wake-On-LAN est activé", //av_alert_9
	"ALG H.323 est activé", //av_alert_10
	"Public", //_public
	"Autres", //at_Prot__1
	"Privé", //_private
	"Site Web", //aa_WebSite
	"https nest pas un protocole pris en charge.", //awf_alert_4
	"Ladresse du site Web %s est déjà utilisée.", //awf_alert_5
	"Les adresses de site Web : '' + invalid_wf_str + '' ne sont pas valides.", //awf_alert_7
	"'L\'adresse de site Web : '' + invalid_wf_str + '' n’est pas valide.'", //awf_alert_8
	"Assistant de connexion à Internet", //int_ConWz2
	"Options de connexion manuelle à Internet", //int_WlsWz
	"Si vous n’êtes pas familié dans la gestion d’un réseau et n'avez jamais configuré un routeur auparavant, appuyez sur <strong>Assistant d’installation </strong> et le routeur vous guidera par quelques étapes simples à mettre votre réseau en service.", //hhbi_wiz
	"Si vous vous considérez comme un utilisateur confirmé et avez déjà configuré un routeur, appuyez sur <strong>Configuration Manuelle </strong> pour entrer tous les réglages manuellement.", //hhbi_man
	"Aucun client dynamique détecté pour l'instant.", //bd_noneyet
	"Le bail a été annulée", //bd_revoked
	"Adresse IP LAN incorrecte", //bln_alert_3
	"Le sous-réseau local n'est pas compatible avec le sous-réseau étendu.", //bd_alert_10
	"La plage d'adresses DHCP A n'est pas dans le sous-réseau du LAN .", //bd_alert_11
	"L'adresse DHCP DE ne contient pas de valeur de départ de l'hôte valide.", //bd_alert_1
	"L'intervalle d'adresses DHCP doit aller de la plus petite adresse à la plus grande, pas de la plus grande à la plus petite.", //bd_alert_3
	"La plage d'adresses DHCP ne doit pas comprendre l'adresse de diffusion générale du sous-réseau.", //bd_alert_13
	"Le nombre d'adresses IP dans la plage dépasse de limite de 256.", //bd_alert_12
	"Le temps du bail DHCP ne peut pas être 0", //bd_alert_5
	"'Une adresse IP réservée pour cette adresse MAC ('+ae.thearray[-1].mac_addr+') est déjà définie.'", //bd_alert_6
	"'Une adresse IP réservée pour ce nom d'ordinateur ('+ae.thearray[-1].comp_name+') est déjà définie.'", //bd_alert_7
	"Une réservation ne peut pas être identique à l'adresse IP du réseau local configurée.", //TA20
	"L'adresse IP réservée doit être dans la plage DHCP configurée.", //bd_alert_8
	"Un serveur DNS principal doit être indiqué avant de fournir un serveur DNS secondaire", //bd_alert_22
	"Adresse IP du DNS primaire invalide", //bd_alert_23
	"Adresse IP du serveur DNS secondaire incorrecte", //bd_alert_24
	"Adresse IP WAN incorrecte", //_badWANIP
	"Masque de sous-réseau WAN incorrect", //bwn_alert_2
	"L'adresse de passerelle par défaut n'est pas dans le sous-réseau du WAN", //bwn_alert_3
	"Les DNS ne sont pas configurés. Les clients ne pourront pas résoudre les noms de domaine. Continuer ?", //bwn_alert_4
	"Le sous-réseau WAN est en conflit avec le sous-réseau LAN.", //bwn_alert_5
	"Veuillez entrer un numéro de port de déclenchement", //MSG000
	"Le temps mort maximal doit être compris entre 0 et 600.", //bwn_alert_8
	"Adresse IP PPPoE incorrecte", //bwn_alert_12
	"Adresse IP PPTP incorrecte", //_badPPTPip
	"Masque de sous-réseau PPTP incorrect", //_badPPTPsub
	"L'adresse de passerelle PPTP n'est pas dans le sous-réseau du PPTP", //_badPPTPipsub
	"Adresse IP du serveur PPTP incorrecte", //bwn_alert_11
	"Adresse L2TP incorrecte", //_badL2TP3
	"Masque de sous-réseau L2TP incorrect", //_badL2TP
	"L'adresse IP de passerelle de L2TP n'est pas dans le sous-réseau de L2TP", //_badL2TP2
	"Adresse IP du serveur L2TP incorrecte", //bwn_alert_17
	"La MTU doit être comprise entre 128 et 30000.", //bwn_alert_21
	"Les clés WEP '+ wep_error_msg + ' ne sont pas valides.", //bws_alert_15
	"La clé WEP '+ wep_error_msg + ' n'est pas valide.", //bws_alert_16
	"Impossible d'utiliser le canal 802.11b/g lorsque le mode 802.11 est  défini sur 802.11a", //bwl_alert_2
	"Impossible d'utiliser le canal 802.11a lorsque le mode 802.11 est  défini sur 802.11b/g", //bwl_alert_3
	"Le champ du port du serveur RADIUS ne peut pas être vide.", //bwl_alert_15
	"Le port du serveur RADIUS ' + data.wireless.radius_server_port + ' doit être dans la plage (1..65535).", //bwl_alert_16
	"Impossible d\'utiliser les vitesses de transmission 802.11b lorsque le mode PHY est 802.11a.", //bwl_alert_4
	"Impossible d\'utiliser les vitesses de transmission 802.11a/g lorsque le mode PHY est 802.11b.", //bwl_alert_5
	"Le mode turbo statique n'est pas autorisé avec 802.11b.", //bwl_alert_6
	"Le mode turbo dynamique n'est pas autorisé avec la norme 802.11b", //bwl_alert_7
	"Pour le mode Turbo 11g, le canal doit être défini sur 6.", //bwl_alert_8
	"Pour le mode Turbo statique 11a, le canal doit être défini sur 42, 50, 58, 152 ou 160.", //bwl_alert_9
	"Pour le mode Turbo dynamique 11a, le canal doit être défini sur 40, 48, 56, 153 ou 161.", //bwl_alert_10
	"La longueur de la clé n'est pas valide ; elle doit avoir de 8 à 64 caractères.", //bws_alert_2
	"L'intervalle de mise à jour de la clé de groupe WPA doit se situer entre 30 et 65535 secondes.", //bwl_alert_11
	"La temporisation d'authentification IEEE 802.1X doit entre 1 et 65535 minutes", //bwl_alert_12
	"La clé WEP ' +(i+1)+' doit comporter '+len+' caractères", //bws_alert_3
	"Décochez \"Sélection automatique du canal\" pour le mode WDS.", //aw_alert_5_1
	"'L’adresse IP '' + data.wireless.radius_server_address + '' est invalide.'", //bwl_alert_13
	"'L’adresse IP '' + data.wireless.second_radius_server_address + '' est invalide.'", //bwl_alert_14
	"Seulement 802.11g", //bwl_Mode_2
	"802.11g et 802.11b", //bwl_Mode_3
	"Seulement 802.11b", //bwl_Mode_1
	"Seulement 802.11n", //bwl_Mode_8
	"802.11n, 802.11g et 802.11b", //bwl_Mode_11
	"20 MHz", //bwl_ht20
	"2 0/40 MHz auto", //bwl_ht2040
	"Le meilleur (automatique)", //bwl_TxR_0
	"Pour sécuriser votre réseau sans fil, la première étape consiste à en modifier le nom. Changez-le pour un nom familier ne contenant aucune information personnelle.", //TA9
	"Activez l'option Balayage automatique du canal pour que le routeur puisse sélectionner le meilleur canal pour le fonctionnement de votre réseau sans fil.", //YM124
	"Configurer État de visibilité sur Invisible est un autre moyen de sécuriser votre réseau. Lorsque l'option de visibilité est désactivée, aucun client sans fil ne peut voir votre réseau sans fil lorsque de dernier est balayé pour voir ce qui est disponible. Pour pouvoir connecter vos périphériques sans fil à votre routeur, vous devez alors saisir manuellement le nom du réseau sans fil sur chacun d'eux.", //TA12
	"Si vous avez activé la sécurité sans fil, pensez à bien notez la phrase de passe que vous avez configurée.", //TA14
	"Vous devrez la saisir sur tous les périphériques sans fil que vous connecterez à votre réseau sans fil.", //TA15
	"Assistant", //_wizard
	"Lancement de l’assistant d'installation de la connexion à Internet", //bwz_LConWz
	"Assistant d’installation de la sécurité du réseau sans fil", //bwz_WlsWz
	"L’assistant d’installation Web suivant est conçu pour vous aider dans l’installation de votre réseau sans fil. Il vous guidera par des instructions étape-par-étape sur la façon de configurer votre réseau sans fil et de le sécuriser.", //bwz_intro_WlsWz
	"Lancement de l’assistant d’installation de la sécurité du réseau sans fil", //bwz_LWlsWz
	"Applications spéciales", //_specapps
	"Jeux", //_gaming
	"Basique", //_basic
	"Le nom de règle ne peut pas être vide.", //ag_alert_empty_name
	"Le nom de règle ' + data.game_rules[j].entry_name + '' est en double.'", //ag_alert_duplicate_name2
	"Le filtre d'adresses MAC n'autorise aucune machine. Cette option est interdite car elle verrouille toutes les machines.", //amaf_alert_2
	"Le nom de règle ' + saved_records[i].entry_name + '' est en double.'", //specapps_alert_duplicate_name
	"\"La règle '\" + saved_records[j].entry_name + \"'est un doublon de '\" + saved_records[i].entry_name + \"'.\"", //specapps_alert_duplicate1
	"La plage de ports déclencheurs de '+saved_records[i].entry_name+'' '+protocols[saved_records[i].trigger_ports.protocol]+' ['+saved_records[i].trigger_ports.port_range+'] est en conflit avec ''+saved_records[j].entry_name+'' '+protocols[saved_records[j].trigger_ports.protocol]+' ['+saved_records[j].trigger_ports.port_range+'].'", //specapps_alert_conflict1
	"Veuillez sélectionner un calendrier pour la règle ' + data.port_trigger_rules[i].entry_name + ''.'", //specapps_alert_empty_schedule
	"Configuration de la mise en forme du trafic", //at_title_TSSet
	"Le protocole ' + entry_1.user_protocol + ' de ' + entry_1.entry_name + ' est en conflit avec ' + entry_2.entry_name + '", //av_alert_35
	"Le champ Nom ne peut pas être vide.", //av_alert_empty_name
	"Le nom '%s' est déjà utilisé.", //av_alert_16
	"L'adresse IP du WINS principal doit être indiquée.", //bln_alert_lannbpri
	"L'adresse IP du WINS secondaire n'est pas valide.", //bln_alert_lannbsec
	"DNS principal", //lan_dns
	"DNS secondaire", //lan_dns2
	"Hybride (point à point puis diffusion)", //bln_NetBIOSReg_H
	"Mode mixte (diffusion puis point à point)", //bln_NetBIOSReg_M
	"Point à point (pas de diffusion)", //bln_NetBIOSReg_P
	"Diffusion uniquement (à utiliser si aucun serveur WINS n'est configuré)", //bln_NetBIOSReg_B
	"Aide", //_help
	"Quand cette option est validée, le routeur restreint le flux du trafic sortant afin de ne pas dépasser le débit du lien WAN.", //help81ets
	"Les options de filtrage de point d'extrémité NAT contrôlent la façon dont la NAT du routeur gère les demandes de connexions entrantes aux ports déjà utilisés.", //af_EFT_h4
	"Lorsquune application côté LAN a créé une connexion via un port spécifique, la NAT transmet toutes les demandes de connexions entrantes avec le même port vers lapplication côté LAN, quelle que soit leur origine. Cest loption la moins restrictive, qui donne la meilleure connectivité et autorise certaines applications (les applications P2P en particulier) à fonctionner pratiquement comme étant directement connectées à Internet.", //YM134
	"La NAT transmet les demandes de connexions entrantes à un hôte côté LAN uniquement lorsque ces demandes viennent de l'adresse IP avec laquelle une connexion a été établie. Ainsi, l'application distante peut renvoyer les données via un port différent de celui utilisé lorsque la session sortante a été créée.", //af_EFT_h1
	"Le NAT ne transmet pas de requêtes de connexions entrantes si la même adresse de port est utilisée pour une connexion déjà établie.", //af_EFT_h2
	"Notez que certaines de ces options peuvent interagir avec dautres restrictions de ports. Le filtrage indépendant de point d'extrémité a la priorité sur les filtres entrants ou les programmations. En conséquence, il est possible quune demande de session entrante liée à une session sortante entre via un port en dépit dun filtre entrant actif sur ce port. Cependant, les paquets seront rejetés comme prévu s'ils sont envoyés vers des ports bloqués (que ces ports soient bloqués par une programmation ou par un filtre entrant) pour lesquels il nexiste pas de session active. Avec le filtrage restreint de port et dadresse, les filtres entrants et les programmations fonctionnent de façon précise mais empêchent un certain niveau de connectivité. Ce filtrage peut donc nécessiter lutilisation de déclencheurs de ports, de serveurs virtuels ou de redirection de port afin d'ouvrir les ports nécessaires à lapplication. Le filtrage restreint dadresse offre un compromis qui évite les problèmes lors de la communication avec certains autres types de routeurs NAT (routeurs NAT symétriques en particulier) mais laisse les filtres entrants et laccès programmé fonctionner comme prévu.", //af_EFT_h5
	"Contrôle le filtrage des points d'extrémité pour les paquets du protocole UDP.", //af_UEFT_h1
	"Contrôle le filtrage des points d'extrémité pour les paquets du protocole TCP.", //af_TEFT_h2
	"Masque de sous-réseau du réseau local.", //help309A
	"NetBIOS autorise les hôtes LAN à rechercher tous les autres ordinateurs du réseau (par exemple, dans Voisinage réseau).", //help400_1
	"Désactivez ce paramètre pour procéder à la configuration manuelle.", //help401_1
	"Les serveurs WINS stockent les informations sur les hôtes réseau ainsi autorisés à s'enregistrer ainsi qu'à en rechercher d'autres disponibles (par exemple, pour l'utilisation dans Voisinage réseau).", //help402_1
	"Ce paramètre n'a pas d'effet si l'option d'apprentissage des informations NetBIOS du WAN est activée.", //help402_2
	"H-Node  indique un état de fonctionnement hybride. Les éventuels serveurs WINS sont testés, puis la diffusion est effectuée sur le réseau local. Il s'agit généralement du mode privilégié si vous disposez de serveurs WINS configurés.", //help405_1
	"M-Node (valeur par défaut)  indique un mode de fonctionnement mixte. Une opération de diffusion est exécutée pour enregistrer les hôtes et en rechercher d'autres (en cas d'échec, les éventuels serveurs WINS sont testés). Sous ce mode, elle est susceptible d'être préférée, notamment si une connexion réseau lente permet d'atteindre les serveurs WINS et si les services réseau, tels que les serveurs et les imprimantes, sont généralement internes au LAN.", //help405_2
	"P-Node  indique que SEULS les serveurs WINS sont à utiliser. Ce paramètre permet de forcer toutes les opérations NetBIOS sur les serveurs WINS configurés. Vous devez avoir configuré au moins la principale adresse IP du serveur WINS pour qu'elle pointe vers un serveur WINS actif.", //help405_3
	"B-Node  indique que SEULE la diffusion sur le réseau local est à utiliser. Ce paramètre est utile si aucun serveur WINS n'est disponible. Cependant, il est préférable d'essayer l'opération M-Node au préalable.", //help405_4
	" Configuration erronée - voir journaux", //_sdi_s1a
	"Port de gestion sécurisée distant incorrect '+data.web_server_wan_port_https+', doit être dans l'intervalle (1 à 65535)", //ta_alert_3b
	"Le port de gestion sécurisé distant et le port de gestion distant ne peuvent pas être identiques.", //ta_alert_3c
	"Vous devez activer une méthode de gestion.", //ta_alert_3d
	"Port de gestion incorrect '+data.web_server_lan_port_http+', doit être dans l'intervalle (1 à 65535)", //ta_alert_3e
	"Port de gestion sécurisée incorrect '+data.web_server_lan_port_https+', doit être dans l'intervalle (1 à 65535)", //ta_alert_3f
	"Le port de gestion sécurisé et le port de gestion ne peuvent pas être identiques.", //ta_alert_3g
	"Activer l’impression LPD/LPR", //tps_enlpd
	"Port admin", //ta_LMAP
	"La connexion a échoué", //fb_FailLogin
	"L'accès à ce périphérique n'est pas autorisé sans mot de passe correct.", //fb_FailLogin_1
	"Ouvert", //_open
	"Autres", //_other
	"Date d'expiration", //_223
	"L'adresse de passerelle ne se trouve pas sur le sous-réseau du réseau local", //_225ap
	"L'adresse IP ou le masque de sous-réseau sont mal formatés", //_226ap
	"Cette option est facultative. Saisissez le nom de domaine du réseau local. L'ordinateur du réseau local tiendra compte de ce nom de domaine lorsque le serveur DHCP intégré au <span>rou</span><span>teur</span> lui enverra une adresse. Ainsi, par exemple, si vous saisissez <code>mynetwork.net</code> ici et que le nom de votre ordinateur portable côté réseau local est <code>chris</code>, ce dernier sera désigné par <code>chris.mynetwork.net</code>.", //_1044wired
	"Notez toutefois que le nom de domaine saisi peut être remplacé par celui envoyé par le serveur DHCP montant du <span>rou</span><span>teur</span>.", //_1044awired
	"Adresse IPv6", //TEXT0
	"Re-générer", //regenerate
	"Service DNS avancé", //_title_AdvDns
	"Le service DNS avancé est une option de sécurité gratuite qui protège la connexion Internet contre la fraude au moyen d'un filtre antihameçonnage, et qui améliore la navigation, par exemple en corrigeant automatiquement les erreurs de saisie communes dans les URL.", //_desc_AdvDns
	"Activer le service DNS avancé", //ta_EUPNP_dns
	"DNS avancé", //_st_AdvDns
	"DNS avancé", //_sp_title_AdvDNS
	"Quand cette fonction est activée, le trafic Internet est protégé par un serveur DNS sécurisé. Cette fonction protège la connexion Internet contre la fraude au moyen d'un filtre antihameçonnage, et améliore la navigation, par exemple en corrigeant automatiquement les erreurs de saisie communes dans les URL.", //_sp_desc1_AdvDNS
	"Remarque :<br />Quand le relais DNS est activé conjointement avec la fonction DNS avancé, les postes de travail du réseau configurés pour obtenir une adresse IP du serveur DHCP du routeur se verront attribuer l'adresse 192.168.0.1 (adresse IP du routeur). Toutefois, le trafic sera toujours protégé.", //_sp_desc2_AdvDNS
	"Bien que la fonction DNS avancé soit activée, vous pouvez modifier l'adresse IP DNS du poste de travail et lui attribuer celle de votre choix du serveur DNS. Notez que le routeur ne détermine pas la résolution DNS lorsque l'adresse IP DNS est configurée sur le poste de travail.", //_sp_desc3_AdvDNS
	"Vous pouvez désactiver l'option DNS avancé si vous avez configuré un réseau privé virtuel ou un intranet sur votre réseau et que vous rencontrez des problèmes lorsque cette option est sélectionnée.", //_sp_desc4_AdvDNS
	"La clé", //TEXT041_1
	"n'est pas valide. La clé doit comporter", //TEXT041_2
	" caractères ou", //TEXT041_3
	"caractères hexadécimaux.", //TEXT041_4
	"La clé", //TEXT042_1
	" n'est pas valide, les caractères valides sont 0~9, A~F ou a~f.", //TEXT042_2
	"URL incorrecte.", //GW_URL_INVALID
	"Portée NetBIOS incorrecte.", //GW_LAN_NETBIOS_SCOPE_INVALID
	"doit se trouver dans la plage DHCP configurée.", //GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID_a
	"DHCP Plus", //bwn_Mode_DHCPPLUS
	"Net Sniper pris en charge", //net_sniper_support
	"Options spéciales du mode de numérotation", //SEL_DIAL_MODE
	"Numérotation normale (par défaut)", //pppoe_dialmode_normal
	"Numérotation spéciale 1", //pppoe_dialmode_sp1
	"Numérotation spéciale 2", //pppoe_dialmode_sp2
	"Numérotation spéciale 3", //pppoe_dialmode_sp3
	"Numérotation spéciale 4", //pppoe_dialmode_sp4
	"Numérotation spéciale 5", //pppoe_dialmode_sp5
	"Numérotation spéciale 6", //pppoe_dialmode_sp6
	"Mode d'apprentissage", //pppoe_dialmode_learn
	"Apprentissage", //bt_learn_text
	"Attaque anti-ARP", //box_ip_mac_binding
	"Activer le service DNS avancé", //_en_AdvDns
	"XKJS pris en charge", //xkjs_support
	"Type de service", //ddns_serv_type
	"Domaine", //ddns_domain
	"Test du compte DDNS", //ddns_account
	"Port public incorrect", //virtual_pub_port_err
	"Port privé incorrect", //virtual_pri_port_err
	"Numéro de protocole incorrect", //virtual_proto_num_err
	"Configuration sécurisée du Wifi", //menu_wps
	"Plage d'adresses IP", //tc_iprange
	"Ouvrant et fermant les connexions TCP.", //help823_15
	"largeur de bande (kbits/s)", //tc_bw
	"Programmation", //tc_schedule
	"Ajouter", //tc_new_sch
	"l‎argeur de bande minimale garantie", //tc_min_bw
	"largeur de bande maximale garantie", //tc_max_bw
	"Admin", //_login_admin
	"Utilisateur", //_login_user
	"PPPoE Plus pris en charge", //pppoe_plus_dail
	"Nom d'utilisateur DHCP+ incorrect", //GW_WAN_DHCPPLUS_USERNAME_INVALID
	"Mot de passe DHCP+ incorrect", //GW_WAN_DHCPPLUS_PASSWORD_INVALID
	"Port du serveur SMTP", //te_SMTPPort
	"Mode sans fil", //WLANMODE
	"Mode routeur", //ROUTER_MODE
	"Mode PA", //AP_MODE
	"Mode WDS+Routeur", //WDSROUTER_MODE
	"Mode WDS+PA", //WDSAP_MODE
	"Sécurité du pont", //BR_SET
	"Mode périphérique", //device_mode
	"Mode routeur", //router_mode
	"Mode PA", //ap_mode
	"Automatique", //auto_mode
	"WDS  Activation", //enable_WDS
	"Le routeur est en train de détecter votre type de connexion Internet. Patientez jusqu'à ce qu'il fournisse les paramètres correspondant à votre configuration.", //ES_AUTODECT
	"Type de téléphone", //_phone
	"Si vous ne voulez pas vous connecter à Internet, cliquez sur le bouton ci-dessous.", //ES_CABLELOST_dsc2
	"Je n'ai pas besoin de me connecter à Internet", //ES_DONT_CONN_btn
	"CONFIGURATION INTERNET MISE À JOUR", //ES_UPDATE_SETTING_bnr
	"Le routeur est en train de détecter votre type de connexion et tente de se connecter à Internet.                                Patientez jusqu'à ce que la détection soit terminée.", //ES_UPDATE_SETTING_dsc
	"CONFIGUREZ VOTRE CONNEXION INTERNET", //ES_CONFIG_INTERNET_bnr
	"Il semble que votre nom d'utilisateur et votre mot de passe soient incorrects. Recontrôlez et cliquez sur « Connecter ».", //ES_CONFIG_INTERNET_dsc2
	"Connexion à Internet", //ES_INTERNET_CONN_dsc
	"(* indique un champ obligatoire)", //ES_MUST_FIELD_dsc
	"ÉCHEC DE LA NUMÉROTATION", //ES_DIALUP_ERROR_bnr
	"Configurez vos paramètres WWAN.  Si vous n'êtes pas certain des paramètres, contactez votre fournisseur d'accès Internet (FAI).", //usb_config1
	"Configuration simple", //ES_NAME
	"Veuillez entrer un nom d'utilisateur", //MSG011
	"Définition", //ES_what_is_this
	"Serveur DNS primaire", //ES_PRI_DNS
	"Serveur DNS secondaire", //ES_SEC_DNS
	"Adresse de la passerelle", //ES_GW_ADDR
	"Masque de sous-réseau", //ES_MASK
	"Adresse IP", //ES_IP_ADDR
	"CONFIGURATION SIMPLE TERMINÉE", //ES_complete
	"La configuration simple est terminée. Cliquez sur le bouton « Enregistrer » pour appliquer vos paramètres. Si d'autres ordinateurs doivent se connecter à votre routeur en sans fil, nous recommandons de cliquer sur « Enregistrer les paramètres réseau » pour enregistrer les paramètres du réseau sans fil sur votre ordinateur.<br><br> Après avoir cliqué sur le bouton « Enregistrer », vous devez indiquer votre nom d'utilisateur et votre mot de passe pour accéder au périphérique à la prochaine connexion.", //ES_save_dsc
	"État", //ES_status
	"Connecté", //ES_connected
	"Déconnecté", //ES_unconnected
	"Paramètres sans fil", //ES_wlan_setting
	"Nom du réseau sans fil (SSID)", //ES_wlan_ssid
	"Sécurité", //ES_security
	"Non sécurisé", //ES_unsecured
	"Les paramètres de sécurité de votre réseau sans fil ne sont pas sécurisés. Nous vous recommandons de les configurer.", //ES_unsecured_suggest
	"Enregistrer mes paramètres de réseau", //ES_save_mySetting
	"Définir le mot de passe du périphérique sur la clé de réseau sans fil", //ES_sync_pw
	"Enregistrer", //ES_save
	"Clé de réseau", //ES_network_key
	"Génération automatique de clé de réseau", //ES_autogen_key
	"Désactiver la sécurité sans fil (déconseillé)", //ES_disable_wifi_sec
	"AUTO-WPA/WPA2(Recommandé)", //ES_wifi_sec_recomm
	"Les paramètres réseau actuels et l'état de la connexion s'affichent ci-dessous. Pour reconfigurer vos paramètres sans fil, cliquez sur le bouton « Configurer ». Vous pouvez également saisir des paramètres avancés en cliquant sur « Configuration manuelle ».", //ES_current_setting_dsc
	"CONFIGURATION RÉSEAU ACTUELLE", //ES_current_setting
	"Configuration manuelle", //ES_manual_btn
	"Annuler", //ES_cancel
	"FERMER LA SESSION", //logout_caption
	"Ha cerrado la sesión satisfactoriamente", //logout_desc
	"Revenir à la page d'ouverture de session", //logout_return
	"Heure de connexion", //st_connected_time
	"Refuser l'accès", //t_ctl_title
	"Pour l'instant, vous ne pouvez PAS accéder à Internet. <br>Voulez-vous vraiment utiliser l'accès Internet d'urgence ?", //t_ctl_note
	"Pour l'instant, vous ne pouvez PAS accéder à Internet. Veuillez prêter attention à l'étude.", //t_ctl_note1
	"TRENDnet Wireless N Home Router", //page_title
	"La plage de ports doit se situer entre 1 et 65535.", //ac_alert_invalid_port
	"Nom en double :", //ac_alert_dup_name
	"Conflit de port.", //ac_alert_port_conflit
	"La politique ne peut pas être vierge.", //ac_alert_policy_null
	"Veuillez contrôler l'adresse de serveur configurée", //tt_alert_checkdyndns
	"Le routeur ne parvient pas à accéder à Internet avec la configuration IP statique actuelle.", //ES_static_no_internet
	"Impossible d'accéder à Internet avec la configuration actuelle. Vérifiez votre configuration !", //ES_static_no_internet_desc
	"Cette fenêtre va fermer. Êtes-vous  sûr(e) ?", //_CFM_close_window
	"ENREGISTRER LE RÉSULTAT DE LA CONFIGURATION", //ES_save_result
	"La configuration a été enregistrée.", //ES_save_success
	"Confirmer", //ES_confirm_bt
	"Format horaire", //sch_timeformat
	"12 heures", //sch_hourfmt_12
	"24 heures", //sch_hourfmt_24
	"Ce microprogramme est la dernière version.", //no_available_update
	"Enlever le pack linguistique", //clear_lang_pack
	"Version actuelle du pack linguistique", //current_lang_pack_version
	"Date du pack linguistique actuel", //current_lang_pack_date
	"Mise à jour du pack linguistique", //lang_package_info
	"La mise à jour du pack linguistique modifiera la langue affichée sur le site Web.", //lang_package_note1
	"Pour mettre à jour le pack linguistique, localisez le fichier de mise à jour sur le disque dur local à l'aide du bouton Browse (Parcourir). Une fois le fichier à utiliser localisé, cliquez sur le bouton Upload (Télécharger) pour lancer la mise à jour du pack linguistique.", //lang_package_note2
	"Dernière version du pack linguistique", //latest_lang_package_ver
	"Date du dernier pack linguistique", //latest_lang_package_date
	"Il n'y a pas de pack linguistique.", //no_lang_pack
	"Le nom de redirection de port ne peut pas être vide.", //pf_name_empty
	"Le nom du serveur virtuel ne peut pas être vide.", //vs_name_empty
	"Erreur de somme de contrôle.", //fw_checksum_err
	"ID matériel erroné.", //fw_bad_hwid
	"Format de fichier inconnu.", //fw_unknow_file_format
	"Mise à jour du microprogramme réussie.", //fw_fw_upgrade_success
	"Pack linguistique mis à jour avec succès.", //fw_lp_upgrade_success
	"Mise à jour de la configuration réussie.", //fw_cfg_upgrade_success
	"Définir le contrôle horaire", //ES_timectrl_bnr
	"Contrôle horaire", //ES_timectrl_btn
	"Contrôle Web", //ES_webpolicy_btn
	"Réglage de la Véritable connectivité de routage Gigabit", //HW_NAT_desc
	"Activer la mise en forme du trafic", //at_ETS
	"Lorsque la véritable connectivité de redirection Gigabit est activée, le SPI et le moteur QoS se désactivent automatiquement. Voulez-vous continuer ?", //alert_hw_nat_1
	"Lorsque le moteur QoS est activé, la véritable connectivité de redirection Gigabit se désactive automatiquement. Voulez-vous continuer ?", //alert_hw_nat_2
	"Lorsque le SPI est activé, la véritable connectivité de redirection Gigabit se désactive automatiquement. Voulez-vous continuer ?", //alert_hw_nat_3
	"Lorsque cette option est activée, la véritable connectivité de redirection Gigabit se désactive automatiquement.", //help_auto_disable_hw_nat
	" et la véritable connectivité de redirection Gigabit sera désactivée automatiquement.", //help_auto_disable_hw_nat_1
	"Véritable connectivité de redirection Gigabit :", //help_hw_nat
	"Lorsque cette option est activée, le routeur accélérera les performances en mode NAT/Routage par un mécanisme de d'accélération matérielle. La limitation tient au fait que le pare-feu SPI et le moteur QoS seront tous deux automatiquement désactivés lorsque la Véritable connectivité de routage Gigabit est activée.", //help_hw_nat_desc
	"Étape 2 : Configurez votre sécurité Wi-Fi", //ES_step_wifi_security
	"Les deux mots de passe Utilisateur ne sont pas identiques ; corrigez-les puis réessayez.", //_pwsame_user
	"Veuillez réessayer", //ES_btn_try_again
	"Le routeur est en train de détecter votre type de connexion Internet, veuillez patienter…", //ES_auto_detect_desc
	"Le routeur ne parvient pas à détecter votre type de connexion Internet.", //ES_auto_detect_failed_desc
	"Guidez-moi tout au long de la configuration de la connexion Internet", //ES_btn_guide_me
	"Enregistrer et connecter", //ES_btn_save_conn
	"Enregistrer", //ES_btn_save
	"Acheminement IPv6", //v6_routing
	"Table de redirection IPv6", //v6_routing_table
	"Le menu État de redirection affiche les données relatives aux voies activées sur votre routeur. La liste affiche l'adresse IP cible, l'adresse IP de passerelle, le masque de sous-réseau, la mesure et l'interface de chaque voie.", //v6_routing_info
	"Ipv6", //ipv6
	"PARE-FEU IPv6", //ipv6_firewall
	"Nombre de règles de pare-feu restantes qui peuvent être configurées:", //ipv6_firewall_info
	"PARAMÈTRES 6RD", //_6rd_settings
	"Adresse IPv4", //ipv4_addr
	"Longueur de masque", //mask_len
	"Paramètres ULA IPv6", //IPV6_ULA_TEXT01
	"Activez la Véritable connectivité de routage Gigabit", //HW_NAT_enable
	"Utiliser le préfixe ULA par défaut", //IPV6_ULA_TEXT03
	"Préfixe ULA", //IPV6_ULA_TEXT04
	"Paramètres ULA IPv6 actuels", //IPV6_ULA_TEXT05
	"Préfixe ULA actuel ", //IPV6_ULA_TEXT06
	"ULA IPv6 du réseau local", //IPV6_ULA_TEXT07
	"Adresse locale unique IPv6 du réseau local", //IPV6_ULA_TEXT08
	"Configuration manuelle de la connectivité locale IPv6", //IPV6_ULA_TEXT09
	"Utilisez cette section pour configurer les paramètres des adresses locales uniques (ULA) IPv6 de monodiffusion de votre routeur. Une adresse ULA est destinée aux communications locales et il n'est pas prévu qu'elle soit routable sur l'Internet mondial.", //IPV6_ULA_TEXT11
	"PARAMÈTRES DE CONNECTIVITÉ LOCALE IPv6", //IPV6_ULA_TEXT12
	"Une adresse ULA est utile pour les communications locales IPv6 ; si vous souhaitez l'activer, cliquez sur <b>Activer ULA</b>. L'adresse ULA est désactivée par défaut.", //IPV6_ULA_TEXT13
	"PARAMÈTRES DE CONNECTIVITÉ LOCALE IPv6 ", //IPV6_ULA_TEXT14
	"Adresse IPv6 du réseau local pour les communications locales IPv6.", //IPv6_Local_Info
	"SÉCURITÉ SIMPLE IPv6", //IPv6_Simple_Security
	"Activer les flux multidiffusion IPv6", //anet_multicast_enable_v6
	"Définir la connexion par tunnels 6rd", //IPv6_Wizard_6rd_title
	"Le nom de la règle du pare-feu ne peut pas être vide.", //fr_name_empty
	"Le nom de redirection IPv6 ne peut pas être vide.", //r6_name_empty
	"Attribuez un nom au réseau Wi-Fi.", //wwz_wwl_intro_s2_1
	"Nom du réseau Wi-Fi (SSID)", //wwz_wwl_intro_s2_1_1
	"(Jusqu'à 32 caractères autorisés)", //wwz_wwl_intro_s2_1_2
	"Attribuez un mot de passe au réseau Wi-Fi.", //wwz_wwl_intro_s2_2
	"Mot de passe Wi-Fi", //wwz_wwl_intro_s2_2_1
	"(Entre 8 et 63 caractères)", //wwz_wwl_intro_s2_2_2
	"Étape 3 : Définissez votre mot de passe", //ES_title_s3
	"Étape 4 : Sélectionnez votre fuseau horaire", //ES_title_s4
	"Étape 5 : Enregistrez les paramètres", //ES_title_s5
	"Seulement 802.11n", //bwl_Mode_n
	"Seulement 802.11a", //bwl_Mode_a
	"802.11n et 802.11g", //bwl_Mode_5
	"Le calendrier de la zone invité doit se situer dans le calendrier du réseau local sans fil principal.", //MSG049
	"Le réseau local sans fil de la zone invité sera désactivé lorsque vous couperez le réseau local sans fil principal. Voulez-vous vraiment continuer ?", //MSG050
	"Erreur d'initialisation matérielle", //HWerr
	"Stockage", //storage
	"L'accès Web à SharePort vous permet d'utiliser un navigateur web pour accéder aux fichiers stockés sur un disque de stockage USB connecté au routeur. Pour utiliser cette fonction, cochez la case <strong>Activer SharePort Web Access</strong>, puis créez des comptes utilisateur pour gérer l'accès à vos périphériques de stockage ou utilisez le compte invité (guest/guest) pour accéder au dossier invité. Après le branchement d'un disque de stockage USB, le nouveau périphérique apparaîtra dans la liste avec un lien vers lui. Vous pouvez ensuite utiliser ce lien pour connecter le disque et vous connecter avec un compte utilisateur.", //sto_into
	"SHAREPORT WEB ACCESS", //sto_http_0
	"Activer la réponse aux requêtes ping du réseau étendu", //bwn_RPing
	"Activer la zone invité", //guestzone_enable
	"Port d'accès HTTP", //sto_http_3
	"Activer le serveur HTTPS", //LV2
	"Port d'accès HTTPS", //sto_http_5
	"10 -- Création d'utilisateur", //sto_creat
	"Ajouter/Modifier", //_add_edit
	"User List (Liste des utilisateurs)", //sto_list
	"Modifier", //_modify
	"Chemin d'accès", //sto_path
	"Fonctions d'optimisation des performances telles que l'envoi de paquets en rafales, FastFrames et la compression.", //help361
	"Serveur NTP utilisé", //tt_NTPSrvU
	"Périphérique", //sto_dev
	"Espace total", //_total_space
	"Espace libre", //_free_space
	"LIEN SHAREPORT WEB ACCESS", //sto_link_0
	"Vous pouvez utiliser ce lien pour vous connecter au disque à distance après vous être connecté avec un compte utilisateur.", //sto_link_1
	"http://&lt;DDNS&gt; ou&lt;Adresse IP du réseau étendu&gt;:8186", //sto_link_2
	"Envoyer par courrier électronique maintenant", //_email_now
	"La page Stockage contient des informations sur les disques de stockage USB ou cartes SD actuellement connectés au périphérique.", //sto_help
	"Connexion du périphérique", //_DevLink
	"Folder (Dossier)", //_folder
	"Navigateur", //_browse
	"Ajouter ", //_append
	"Le port d'accès distant et le port HTTPS distant sont vides !", //sto_01
	"Le mot de passe de confirmation ne correspond pas au nouveau mot de passe utilisateur", //sto_02
	"Lect seule", //_readonly
	"Lect/Écrit", //_readwrite
	"Ajouter nouveau dossier", //_AppendNewFolder
	"Appuyez sur le bouton de commande de votre périphérique sans fil, puis cliquez sur le bouton de connexion ci-dessous.", //KR45
	"Ce compte a atteint le nombre de règles maximum", //MSG052
	"Cette règle existe déjà.", //MSG053
	"Règle introuvable, cliquez sur le bouton Ajouter", //MSG054
	"Ajouter dossier", //_AddFolder
	"http://&lt;DDNS&gt; ou &lt;Adresse IP du réseau étendu&gt;", //_StorageLink
	"Désactiver la méthode WPS-PIN ", //LW6_1
	"Le nombre maximum d'utilisateurs", //MSG055
	"Étape 5 : Confirmez les paramètres Wi-Fi", //ES_title_s5_0
	"ENREGISTREMENT DES PARAMÈTRES", //save_settings
	"Vos paramètres sont en cours d'enregistrement.", //save_wait
	"Langue", //_Language
	"Adelphia Powerlink", //manul_conn_01
	"ALLTEL DSL", //manul_conn_02
	"Service DSL ATAT", //manul_conn_03
	"Bell Sympatico", //manul_conn_04
	"Bellsouth", //manul_conn_05
	"Haut débit Charter", //manul_conn_06
	"Comcast", //manul_conn_07
	"Covad", //manul_conn_08
	"Cox Communications", //manul_conn_09
	"Câble Earthlink", //manul_conn_10
	"DSL Earthlink", //manul_conn_11
	"FrontierNet", //manul_conn_12
	"Avis", //_aa_bsecure_opinion
	"RCN", //manul_conn_14
	"Road Runner", //manul_conn_15
	"Rogers Yahoo!", //manul_conn_16
	"SBC Yahoo! DSL", //manul_conn_17
	"Shaw", //manul_conn_18
	"Speakeasy", //manul_conn_19
	"Sprint FastConnect", //manul_conn_20
	"Telus", //manul_conn_21
	"Time Warner Cable", //manul_conn_22
	"US West / Qwest", //manul_conn_23
	"Verizon Online DSL", //manul_conn_24
	"XO Communications", //manul_conn_25
	"Définir manuellement le nom du réseau dans la bande 5 GHz (SSID)", //manul_5g_ssid
	"Le pack linguistique vous permet de modifier la langue de l'interface utilisateur du ", //tf_intro_FWU4
	" Nous suggérons de mettre à jour votre pack linguistique actuel si vous actualisez le microprogramme. Cela garantit que les modifications du microprogramme s'affichent correctement.", //tf_intro_FWU5
	"Mise à jour du microprogramme", //_firmwareUpdate
	"Date", //_date
	"Supprimer", //_remove
	"Lorsque vous définissez la sécurité WEP ou EAP, le type de chiffrement est TKIP, l'état de visibilité est Invisible et le WPS est désactivé.", //notify_wps
	"%s ports[%s] est en conflit avec un autre paramètre", //ag_conflict5
	"Désactiver", //_disable
	"Coexistence HT20/40 MHz ", //coexi
	"Utilisez le même mot de passe de sécurité sans fil pour les bandes de 2,4 GHz et 5 GHz.", //wwl_SSP
	"Attribuez un nom et un mot de passe au réseau Wi-Fi.", //wwz_wwl_intro_s0
	"Cette page affiche les détails de votre connexion Internet et réseau IPv6.", //STATUS_IPV6_DESC_0
	"Informations sur la connexion IPv6", //STATUS_IPV6_DESC_1
	"Adresse IPv6 de l'ordinateur connecté.", //STATUS_IPV6_DESC_6
	"Adresse lien-local IPv6 du réseau local.", //STATUS_IPV6_DESC_5
	"Adresse MAC de l'ordinateur connecté.", //STATUS_IPV6_DESC_4
	"Type de connexion IPv6.", //STATUS_IPV6_DESC_3
	"Nom de l'ordinateur connecté.", //STATUS_IPV6_DESC_2
	"La fonction Moteur QoS vous aide à améliorer les performances de votre réseau en affectant des priorités aux applications.\" ;", //ag_conflict6
	"Rules", //TEXT008a
	"possède le même paramètre que les règles", //TEXT008b
	"Avertir", //TEXT023
	"Mbit/s", //at_mbps
	"Format de code PIN incorrect. Utilisez le format 0000 0000 ou 0000-0000", //pin_f
	"Utiliser le chiffrement WEP désactivera le WPS, voulez-vous vraiment continuer ?", //msg_eap
	"Ouvert", //open
	"Veuillez saisir un autre numéro de port privé", //PRIVATE_PORT_ERROR
	"Impossible de définir le dossier comme « / »", //MSG056
	"Vous utilisez les mêmes compte et mot de passe !", //MSG057
	"IP de destination", //_DestIP
	"Type", //_type
	"Internet non détecté, redémarrer l'assistant ?", //mydlink_tx03
	"Contrôle de connectivité du réseau étendu.", //mydlink_tx05
	"secondes restant.", //sec_left
	"Remplissez les champs obligatoires, puis cliquez sur « Connecter »", //ES_CONN_dsc
	"Confirmer le mot de passe", //chk_pass
	"Nom", //Lname
	"Prénom", //Fname
	"Connexion", //_login
	"%s ports[%s] est en conflit avec le port http d'accès distant au stockage", //ag_conflict22
	"%s ports[%s] est en conflit avec le port https d'accès distant au stockage", //ag_conflict23
	"l'hôte sans fil est désactivé, impossible d'activer la zone invité sans fil.", //wifi_enable_chk
	"L'adresse  IPv6 ne peut pas être égale à zéro.", //ZERO_IPV6_ADDRESS
	"La plage de ports IPv6 ne peut pas être vide.", //port_empty
	"Désactiver", //_disable_s
	"Sélectionnez votre type de connexion Internet IPv6", //IPV6_TEXT154
	"Connexion", //_signup
	"(GMT+07:00) Novossibirsk", //up_tz_74
	"The Wireless Security Password field entered is invalid.", //wifi_pass_chk
	"Supprimer(Remove)", //_remove_multi
	"Voulez-vous vraiment reprogrammer le périphérique à l'aide du fichier de langue", //tf_really_langf
	"Vous devez d’abord saisir le nom d'un fichier de langue.", //tf_langf
	"Le fichier de  le PACK LINGUISTIQUE téléchargé sur le périphérique n'est peut-être pas le bon. Il est possible que le fichier téléchargé sur la passerelle soit inadapté ou corrompu.", //ub_intro_l1
	"Si le fichier téléchargé vers le serveur est correct, le périphérique est peut-être trop occupé pour le recevoir immédiatement. Dans ce cas, essayez de le télécharger de nouveau. (Autre possibilité.) Vous êtes connecté en tant qu'utilisateur et non en tant qu'admin. - seuls les administrateurs peuvent télécharger un nouveau firmware.", //ub_intro_l3
	"Désolé, la page demandée n'est pas disponible.", //err404_title
	"Impossible de détecter une connexion Internet.", //err404_detect
	"Suggestions :", //err404_sug
	"Assurez-vous que votre câble Internet est correctement connecté au port Internet de votre routeur et que votre voyant Internet clignote en vert ou bleu. ", //err404_sug1
	"Vérifiez que les", //err404_sug2
	" « Paramètres Internet »", //err404_sug3
	"de votre routeur sont définis correctement, notamment le nom d'utilisateur et le mot de passe PPPoE.", //err404_sug4
	"Le serveur DNS est inaccessible pour l'instant, veuillez contacter votre FAI ou réessayer plus tard.", //err404_sug5
	"Heure de fin", //tsc_end_time
	"Saisissez une autre valeur de port admin distant", //remote_port_msg
	"Veuillez entrer un autre nom", //TEXT034
	"Seul l'administrateur a accès à ces fonctions. Les boutons sont désactivés car vous n'êtes pas connecté en tant qu'administrateur.", //LW39b
	"Veuillez saisir un nom d\'utilisateur et essayez encore une fois", //_nousername
	"Veuillez entrer un autre mot clé", //metric_empty
	"Veuillez entrer un numéro de port TCP ou un numéro de port UDP.", //TEXT061
	"Veuillez contacter votre FAI pour obtenir le nom d'utilisateur/mot de passe correct", //ES_DIALUP_ERROR_dsc
	"Veuillez entrer un numéro de port de pare-feu", //MSG001
	"Sélectionnez \"Lien périphérique\"", //MSG051
	"Veuillez entrer une autre valeur %s.", //MSG012
	"Sélectionnez un filtre.", //aa_alert_13
	"Commencez par sélectionner un nom d'ordinateur", //TEXT044
	"Saisissez un autre nom d'utilisateur", //sto_03
	"Aucun paramètre de cette page n'a été modifié. Voulez-vous quand même enregistrer ?", //up_nosave
	"Veuillez saisir le même mot de passe dans les deux boîtes, pour confirmation.", //ta_msg_TW
	"Si vous voulez utiliser Activer l'accès aux fichiers Web, sélectionnez Activer l'accès distant au stockage HTTP ou Activer l'accès distant au stockage HTTPS.", //sto_04
	"Activez le mode Système et réseau en étoile", //IPV6_TEXT167
	"Cette page affiche les données de l'acheminement IPv6 de votre routeur.", //IPV6_TEXT170
	"Pour chaque règle vous pouvez créer un nom et contrôler la direction du trafic. Vous pouvez aussi autoriser ou refuser une plage d'adresses IP, le protocole et une plage de ports. Pour appliquer un calendrier à une règle de pare-feu, vous devez commencer par définir un calendrier sur la page <a href=\"tools_schedules.asp\"> Outils &rarr; Calendriers</a>.", //help_171
	"Le nom d'hôte est incorrect !", //DDNS_HOST_ERROR
	"No.", //_item_no
	"Échec du montage du périphérique USB", //_usb_not_found
	"Le nom du serveur ne peut pas être vide.", //srv_name_empty
	"Utiliser le chiffrement WEP désactivera le WPS, voulez-vous vraiment continuer ?", //msg_wps_sec_01
	"Utiliser le chiffrement WPA/TKIP désactivera le WPS, voulez-vous vraiment continuer ?", //msg_wps_sec_02
	"Masquer le SSID désactivera le WPS, voulez-vous vraiment continuer ?", //msg_wps_sec_03
	"SharePort", //sh_port_tx_00a
	"Accès Mobile/Web", //sh_port_tx_00b
	"Accès SharePort&trade; Mobile/Web", //sh_port_tx_00
	"L'accès SharePort&trade; Mobile/Web est un accès partagé facile à utiliser, qui permet à n'importe quel ordinateur ou périphérique mobile de votre réseau à domicile d'accéder à un périphérique de stockage USB externe connecté à votre routeur. Il vous permet, ainsi qu'à d'autres utilisateurs invités, d'accéder aux fichiers stockés sur un périphérique de stockage USB grâce au compte utilisateur que vous créez.", //sh_port_tx_01
	"Vous pouvez utiliser l'assistant de configuration ou configurer l'accès SharePort&trade; Mobile/Web manuellement.", //sh_port_tx_02
	"Assistant de configuration de SharePort&trade; Mobile", //sh_port_tx_03
	"Pour utiliser nos assistants Web conviviaux pour vous aider à configurer le service SharePort&trade; Mobile, cliquez sur le bouton ci-dessous.", //sh_port_tx_04
	"Configuration manuelle de SharePort&trade; Mobile", //sh_port_tx_05
	"Pour configurer les paramètres du service d'accès SharePort&trade; Mobile/Web manuellement, cliquez sur le bouton ci-dessous.", //sh_port_tx_06
	"Assurez-vous que votre périphérique de stockage USB est connecté au routeur.", //sh_port_tx_07
	"Pas de périphérique de stockage USB ! Vérifiez qu'un périphérique de stockage est branché au routeur.", //sh_port_tx_08
	"Créez un compte utilisateur pour gérer l'accès au périphérique de stockage.", //sh_port_tx_09
	"Sélectionnez/Créez un dossier sur le disque USB pour accéder au contenu.", //sh_port_tx_10
	"Saisissez les données du compte DNS dynamique pour activer le service d'accès à distance. Si vous ne possédez pas de compte DDNS, créez-en un ici :", //sh_port_ddns_01
	"Paramètres de traitement", //sh_port_ddns_02
	"Attendez le contrôle du lien d'accès Web...", //sh_port_ddns_03
	"configuration terminée ! Vous pouvez maintenant utiliser le lien ci-dessous pour accéder à votre périphérique de stockage USB par le biais du compte utilisateur.", //sh_port_tx_11
	"Accès local", //sh_port_tx_12
	"Accès distant", //sh_port_tx_13
	"ou", //sh_port_tx_16
	"<a href=\"http://FQDN:8181\">http://FQDN:8181</a>", //sh_port_tx_17
	"Les liens ci-dessus s'activent lorsque les paramètres sont enregistrés et après le redémarrage du périphérique.", //sh_port_tx_18
	"Nom d'utilisateur ou clé", //sh_port_tx_19
	"Mot de passe ou clé", //sh_port_tx_20
	"Sélectionner", //sh_port_tx_21
	"Le champ Nom du compte ne peut pas être vide.", //sh_port_msg_01
	"Le champ Mot de passe du compte ne peut pas être vide.", //sh_port_msg_02
	"Les deux mots de passe ne concordent pas.", //sh_port_msg_04
	"Sélectionnez un dossier pour votre compte utilisateur.", //sh_port_msg_05
	"Le champ Nom d'hôte ne peut pas être vide.", //sh_port_msg_06
	"Le champ Nom d'utilisateur ne peut pas être vide.", //sh_port_msg_07
	"Le champ Mot de passe ne peut pas être vide.", //sh_port_msg_08
	"Le DNS dynamique ne parvient pas à établir de connexion.", //sh_port_msg_09
	"Autoriser l'accès distant", //sto_http_6
	"Voulez-vous vraiment supprimer cet utilisateur ?", //file_acc_del_user
	"Voulez-vous vraiment supprimer ce chemin d'accès ?", //file_acc_del_path
	"Voulez-vous vraiment supprimer ce fichier ?", //file_acc_del_file
	"Se connecter à nouveau", //_login_a
	"DNS DYNAMIQUE POUR HÔTES IPv6", //IPv6_ddns_01
	"LISTE DES DNS DYNAMIQUES IPv6", //IPv6_ddns_02
	"Configurez le pare-feu IPv6 ci-dessous :", //IPv6_fw_01
	"DÉSACTIVER le pare-feu IPv6", //IPv6_fw_02
	"ACTIVER le pare-feu IPv6 et AUTORISER les règles énumérées", //IPv6_fw_03
	"ACTIVER le pare-feu IPv6 et REFUSER les règles énumérées", //IPv6_fw_04
	"Plage d'adresses  IP", //IPv6_fw_ipr
	"Plage de ports", //IPv6_fw_pr
	"Source", //IPv6_fw_sr
	"Cible", //IPv6_fw_dest
	"Le relai 6rd ne peut pas être vide.", //IPv6_6rd_relay
	"Changez d'abord le protocole IPv4 du réseau étendu en mode DHCP.", //IPv6_6rd_wan
	"Le relai 6to4 ne peut pas être vide.", //IPv6_6to4_relay
	"Plage d'adresses (début)", //IPv6_addrSr
	"Plage d'adresses (fin)", //IPv6_addrEr
	"Utiliser WPA uniquement désactive le WPS, voulez-vous vraiment continuer ?", //msg_wps_sec_04
	"Veuillez patienter %d secondes.", //msg_wait_sec
	"Sélectionnez un fichier à supprimer", //file_acc_del_empty
	"PPPoE IPv6 est partagée avec PPPoE IPv4. Veuillez d'abord modifier le protocole IPv6 du réseau étendu !", //IPV6_TEXT161a
	"Statistiques sans fil 2.4GHZ", //ss_Wstats_2
	"Statistiques sans fil 5GHZ", //ss_Wstats_5g
	"Serveur multimédia", //dlna_t
	"Activer le serveur multimédia", //dlna_01
	"Nom du serveur multimédia", //dlna_02
	"Le nom de serveur multimédia indiqué n'est pas valide", //dlna_03
	"PPTP Russie (double accès)", //rus_wan_pptp
	"Type de connexion Internet PPTP Russie (double accès)", //rus_wan_pptp_01
	"L2TP Russie (double accès)", //rus_wan_l2tp
	"Type de connexion Internet L2TP Russie (double accès)", //rus_wan_l2tp_01
	"PPPoE Russie (double accès)", //rus_wan_pppoe
	"Type de connexion Internet PPPoE Russie (double accès)", //rus_wan_pppoe_02
	"Configuration physique du réseau étendu", //rus_wan_pppoe_03
	"Utiliser le chiffrement WPA-Enterprise uniquement désactive le WPS, voulez-vous vraiment continuer ?", //msg_wps_sec_05
	"Connexion à Web File Access", //webf_login
	"Connectez-vous au serveur d'accès aux fichiers Web", //webf_intro
	"Accès Web à SharePort", //webf_title
	"Nouveau dossier", //webf_folder
	"Mon accès au disque dur du périphérique", //webf_hd
	"Créer un dossier", //webf_createfd
	"Veuillez saisir un nom de dossier", //webf_fd_name
	"Télécharger un fichier sur le périphérique", //webf_upload
	"Sélectionnez un fichier", //webf_file_sel
	"Si vous partagez le contenu multimédia avec les périphériques, tout ordinateur ou périphérique connecté à votre réseau peut lire votre musique, vos images et vos vidéos partagées.", //dlna_t1
	"<strong>REMARQUE :</strong> Le contenu multimédia partagé n'est peut-être pas sécurisé. Il est recommandé d'autoriser les périphériques à diffuser uniquement sur des réseaux sécurisés.", //dlna_t2
	"Vous permet d'accéder aux fichiers stockés sur un disque dur externe USB ou une clé USB connecté au %m, via votre réseau local ou Internet, à l'aide d'un navigateur Web ou de l'application SharePort<sup>TM</sup> Mobile pour votre smartphone ou votre tablette. Vous pouvez créer des utilisateurs afin de personnaliser les droits d'accès aux fichiers stockés sur le disque USB. Après avoir effectué les modifications, cliquez sur le bouton <strong>Enregistrer les paramètres</strong>.", //help_stor1
	"Cochez cette case pour activer le partage des fichiers stockés sur un disque de stockage USB connecté au %m.", //help_stor2
	"Saisissez un port pour utiliser l'accès Web HTTP à vos fichiers (8181 est la valeur par défaut). Vous devez ajouter ce port à l'adresse IP du %m lors de la connexion. Par exemple : http://192.168.0.1:8181", //help_stor3
	"Saisissez un port pour utiliser l'accès sécurisé HTTPS à vos fichiers (4433 est la valeur par défaut). Vous devez ajouter ce port à l'adresse IP du %m lors de la connexion. Par exemple : https://192.168.0.1:4433", //help_stor4
	"Cochez cette case pour permettre un accès distant à l'espace de stockage de votre routeur.", //help_stor5
	"Création d'utilisateur", //help_stor6
	"Pour créer un nouvel utilisateur, saisissez un nom d'utilisateur. Pour modifier un utilisateur existant, utilisez la zone déroulante à droite.", //help_stor7
	"Saisissez un mot de passe pour le compte, ressaisissez-le dans la zone de texte <strong>Vérifier le mot de passe</strong>, puis cliquez sur <strong>Ajouter/Modifier</strong> pour enregistrer vos modifications.", //help_stor8
	"Cette section affiche les comptes utilisateur existants. Les comptes <strong>admin</strong> et <strong>guest</strong> (invité) sont créés par défaut.", //help_stor9
	"Cette fonction vous permet de partager de la musique, des photos et des vidéos avec tous les périphériques connectés à votre réseau. Après avoir effectué les modifications, cliquez sur le bouton <strong>Enregistrer les paramètres</strong>.", //help_dlna1
	"Aucun périphérique USB inséré.", //webf_non_hd
	"La détection du DDNS a échoué!", //sh_port_tx_22
	"Le lien vers le DDNS a échoué. Réessayez et contrôlez les données de votre compte ou cliquez sur Suivant pour enregistrer vos paramètres DDNS quand même.", //sh_port_tx_23
	"Activer le filtrage d'entrée IPv6", //IPv6_Ingress_Filtering_enable
	"Musique", //share_title_1
	"Photo", //share_title_2
	"Films", //share_title_3
	"Document", //share_title_4
	"Recherche de musiques...", //share_ser_1
	"Recherche de photos...", //share_ser_2
	"Recherche de films...", //share_ser_3
	"Recherche de documents...", //share_ser_4
	"Déconnexion en cours", //ddns_disconnecting
	"IP de réservation ", //lan_reserveIP
	"Adresse IP finale", //end_ip
	"Sans sécurité", //_NULL
	"dyndns.com(personnalisé)", //ddns_sel2
	"dyndns.com(gratuit)", //ddns_sel3
	"Adresse IP distante", //_remoteipaddr
	"Retour", //_back
	"Échec du ping %s.", //_ping_fail
	"Ping %s réussi.", //_ping_success
	"La fonction WPS est déjà désactivée. Cliquez sur Oui pour l'activer ou sur Non pour quitter l'assistant.", //_wz_disWPS
	"Le mot de passe du compte doit comporter plus de six caractères.", //limit_pass_msg
	"When WPS is enabled, security mode can not set WEP, EAP,and WPA only, or cipher type can not set TKIP.", //_gz_wps_enable
	"When security mode is WEP, EAP, ciphter type is TKIP, or WPA only, WPS can not be enabled.", //_gz_wps_deny
	"2 0/40/80 MHz auto", //bwl_ht204080
	"Fermé", //_supp_close
	"Seulement 802.11ac", //bwl_Mode_ac
	"802.11ac et 802.11n", //bwl_Mode_acn
	"802.11ac, 802.11n et 802.11a", //bwl_Mode_acna
	"Réseau sans fil 2.4GHz", //_wireless_2
	"Réseau sans fil 5GHz", //_wireless_5
	"WPS", //_WPS
	"Liste de stations", //_statlst
	"Wireless Security Setting", //_wifiser_title
	"Sélectionnez le SSID", //_wifiser_title0
	"Sélectionnez le SSID", //_wifiser_title1
	"WEP-OUVERT", //_wifiser_mode0
	"WEP PARTAGE", //_wifiser_mode1
	"WEP AUTOMATIQUE", //_wifiser_mode2
	"WPA-PSK", //_wifiser_mode3
	"WPA2-PSK", //_wifiser_mode4
	"WPA2-PSK Mixte", //_wifiser_mode5
	"WPA2", //_wifiser_mode6
	"WPA2-Entreprise Mixte", //_wifiser_mode7
	"Crypter type", //_wifiser_mode8
	"If you choose WPA/WPA2-TKIP encryption, the wireless mode should be Non-HT 11n mode. This means you will NOT get high throughput performance due to the fact that is not supported by 11N specification.", //_wifiser_mode9
	"Clé par défaut", //_wifiser_mode10
	"Clé", //_wifiser_mode11
	"HEXADÉCIMAL", //_wifiser_mode12
	"Chiffrement WPA", //_wifiser_mode13
	"Intervalles de mise à jour de la clé", //_wifiser_mode14
	"Période cache PMK", //_wifiser_mode15
	"Pré-authentification", //_wifiser_mode16
	"802.1x WEP", //_wifiser_mode17
	"Serveur RADIUS", //_wifiser_mode18
	"Secret partagé", //_wifiser_mode19
	"Délai d'attente de la session", //_wifiser_mode20
	"Délai d'inactivité:", //_wifiser_mode21
	"Filtre MAC sans fil", //_wifiser_mode22
	"Mode filtre:", //_wifiser_mode23
	"Rejeter", //_wifiser_mode24
	"L'adresse MAC est incorrecte.", //_wifiser_mode25
	"Vous ne pouvez ajouter plus de 24 entrées à la liste de filtrage MAC.", //_wifiser_mode26
	"Veuillez entrer un intervalle de renouvellement de clé valide.", //_wifiser_mode27
	"La valeur de l'intervalle de renouvellement de clé doit être plus grande ou égale à 60.", //_wifiser_mode28
	"Veuillez entrer une période cache PMK de clé valide.", //_wifiser_mode29
	"Veuillez indiquer les 10 ou 26 caractères de la clé WEP", //_wifiser_mode30
	"Veuillez indiquer les 5 ou 13 caractères de la clé WEP", //_wifiser_mode31
	"Veuillez entrer la clé WEP", //_wifiser_mode32
	"Veuillez entrer la période cache PMK.", //_wifiser_mode33
	"Veuillez entrer moins de 63 caractères ASCII pour la clé WPA-PSK!", //_wifiser_mode34
	"Veuillez entrer au moins 8 caractères ASCII pour la clé WPA-PSK!", //_wifiser_mode35
	"Veuillez indiquer les 64 caractères hexadécimaux de la clé WPA-PSK !", //_wifiser_mode36
	"Veuillez saisir la clé WPA-PSK !", //_wifiser_mode37
	"Si vous désirez supporter plusieurs SSID et que la sécurisation fonctionne correctement, veuillez ne pas oublier de redémarrer le périphérique lorsque vous modifiez quelque paramètre que ce soit.", //_wifiser_mode38
	"Etes-vous certain de vouloir ignorer ces modifications ?", //_wifiser_mode39
	"Liste des filtres MAC", //_wifiser_mode40
	"Le bouton radio Réseau sans fil est désactivé.", //_wifiser_mode41
	"Activer règle", //_adv_txt_00
	"Nom de règles", //_adv_txt_01
	"Nom de la règle : %s saisi est incorrect.", //_adv_txt_02
	"Le serveur virtuel peut définir un port unique public pour la redirection vers une IP interne ou port.", //_adv_txt_03
	"Ajouter Serveur Virtuel", //_adv_txt_04
	"Liste de serveur virtuel", //_adv_txt_05
	"Jeux", //_adv_txt_06
	"That can open multiple ports or a range of ports in your router.", //_adv_txt_07
	"The formats including Single Port (ex: 80), Port Ranges (ex: 50-60).), Individual Ports (80, 68, 888), or Mixed (1020-5000, 689).", //_adv_txt_08
	"Add Port Range Rule", //_adv_txt_09
	"Port Range Rule List", //_adv_txt_10
	"Ports TCP/UDP", //_adv_txt_11
	"Déclenchement de port", //_adv_txt_12
	"Port trigger is a way to automate port forwarding in which outbound traffic on predetermined ports ('triggering ports') causes inbound traffic to specific incoming ports to be dynamically forwarded to the initiating host, while the outbound ports are in use.", //_adv_txt_13
	"Please assign the port with below format:<br>1. Single Port (ex: 80)<br>2. Port Ranges (ex: 50-60)", //_adv_txt_14
	"Fonction déclenchement de port", //_adv_txt_15
	"Ajouter Règle de redirection de port", //_adv_txt_16
	"Appliquer", //_adv_txt_17
	"Déclenchement de port", //_adv_txt_18
	"Liste des règles", //_adv_txt_19
	"Protocole de correspondance", //_adv_txt_20
	"Port de correspondance", //_adv_txt_21
	"Protocole/Ports", //_adv_txt_22
	"Réseau", //_network
	"Gestion", //_management
	"Télécharger micrologiciel", //_upload_firm
	"Paramétrages de gestion", //_settings_management
	"Durée", //_time_cap
	"Journaux système", //_system_log
	"Statut IPv6", //_ipv6_status
	"ALG", //_alg
	"Paramètres du réseau étendu", //_wan_setting
	"Paramètres du réseau local", //_lan_setting
	"Paramètres du réseau IPv6", //_ipv6_setting
	"Haut", //_top
	"Aide réseau", //_network_help
	"Paramètres de qualité de service", //_qos_help
	"Aide sans fil", //_wireless_help
	"Aide administrateur", //_administrator_help
	"Type de connexion WAN", //_wan_conn_type
	"There are several connection types to choose from: Static IP, DHCP, PPPoE, PPTP, L2TP, and Russia PPTP. If you are unsure of your connection method, please contact your Internet Service Provider.", //_help_txt2
	"STATIQUE", //_static
	"Menu Aide", //_help_txt1
	"Your ISP provides a set IP address that does not change. The IP information is manually entered in your IP configuration settings. You must enter the IP address, Subnet Mask, Gateway, Primary DNS Server, and Secondary DNS Server. Your ISP provides you with all of this information.", //_help_txt4
	"A method of connection where the ISP assigns your IP address when your router requests one from the ISP's server.", //_help_txt6
	"<b>Host Name:</b> Some ISP's may check your computer's Host Name. The Host Name identifies your system to the ISP's server.", //_help_txt7
	"Select this option if your ISP requires you to use a PPPoE (Point to Point Protocol over Ethernet) connection. DSL providers typically use this option. This method of connection requires you to enter a <b>Username</b> and <b>Password</b> (provided by your Internet Service Provider) to gain access to the Internet.", //_help_txt9
	"<b>Mode de reconnexion: </b>Typiquement les connexions PPPoE ne sont pas toujours activées. Le routeur vous permet de régler le mode de reconnexion. Les réglages sont", //_help_txt10
	"<b>Toujours activée: </b>La connexion à Internet est toujours maintenue.", //_help_txt11
	"<b>Sur demande: </b>La connexion à Internet est établie quand nécessaire.", //_help_txt12
	"<b>Manuel: </b>Vous devez ouvrir l'interface de gestion du routeur et appuyez sur le bouton de connexion manuelle quand vous souhaitez vous connecter à Internet.", //_help_txt13
	"<b>Temps mort maximal: </b>Temps d'inactivité maximum Intervalle de temps pendant lequel la machine peut être inactive avant que la connexion PPPoE ne soit interrompue. La valeur du temps d'inactivité maximum est uniquement utilisée pour les reconnexions « à la demande » et « manuelle ».", //_help_txt14
	"L2TP (Layer Two Tunneling Protocol) utilise un réseau privé virtuel pour se connecter à votre FAI. Cette méthode de connexion nécessite de saisir un  Nom d’utilisateur  et  Mot de passe  (fourni par votre FAI) pour accéder à Internet.", //_help_txt16
	"<b>Adresse IP du serveur L2TP: </b>Le FAI fournit ce paramètre, si nécessaire. La valeur peut être identique que l’adresse IP de la passerelle.", //_help_txt17
	"<b>Mode de reconnexion: </b>Typiquement les connexions PPPoE ne sont pas toujours activées. Le routeu vous permet de régler le mode de reconnexion. Les réglages sont", //_help_txt18
	"<b>Toujours activée: </b>La connexion à Internet est toujours maintenue.", //_help_txt19
	"<b>Sur demande: </b>La connexion à Internet est établie quand nécessaire.", //_help_txt20
	"<b>Manuel: </b>Vous devez ouvrir l'interface de gestion du routeur et appuyez sur le bouton de connexion manuelle quand vous souhaitez vous connecter à Internet.", //_help_txt21
	"<b>Temps mort maximal: </b>Temps d'inactivité maximum Intervalle de temps pendant lequel la machine peut être inactive avant que la connexion PPPoE ne soit interrompue. La valeur du temps d'inactivité maximum est uniquement utilisée pour les reconnexions « à la demande » et « manuelle ».", //_help_txt22
	"<b>Static:</b> If your ISP has assigned a fixed IP address, select this option. The ISP provides the values for the following fields for <b>WAN Interface IP Setting: IP Address, Subnet Mask , Default Gateway.</b>", //_help_txt24
	"<b>Dynamic:</b> If the ISP's servers assign the router's IP addressing upon establishing a connection, select this option.", //_help_txt25
	"PPTP (Point to Point Tunneling Protocol) utilisee un réseau privé virtuel pour se connecter à votre FAI. Cette méthode de connexion est principalement employée en Europe. Elle exige de saisir un  Nom d’utilisateur </b> et  Mot de passe </b> (fourni par votre FAI) pour accéder à Internet.", //_help_txt27
	"<b>Adresse IP du serveur PPTP: </b>Le FAI fournit ce paramètre, si nécessaire. La valeur peut être identique que l’adresse IP de la passerelle.", //_help_txt28
	"<b>Mode de reconnexion: </b>Typiquement les connexions PPPoE ne sont pas toujours activées. Le routeur vous permet de régler le mode de reconnexion. Les réglages sont", //_help_txt29
	"<b>Toujours activée: </b>La connexion à Internet est toujours maintenue.", //_help_txt30
	"<b>Sur demande: </b>La connexion à Internet est établie quand nécessaire.", //_help_txt31
	"<b>Manuel: </b>Vous devez ouvrir l'interface de gestion du routeur et appuyez sur le bouton de connexion manuelle quand vous souhaitez vous connecter à Internet.", //_help_txt32
	"<b>Temps mort maximal: </b>Temps d'inactivité maximum Intervalle de temps pendant lequel la machine peut être inactive avant que la connexion PPPoE ne soit interrompue. La valeur du temps d'inactivité maximum est uniquement utilisée pour les reconnexions « à la demande » et « manuelle ».", //_help_txt33
	"WAN Interface IP Type", //_help_txt34
	"<b>Static:</b> If your ISP has assigned a fixed IP address, select this option. The ISP provides the values for the following fields for <b>WAN Interface IP Setting: IP Address, Subnet Mask , Default Gateway</b>, and optional for <b>DNS Server</b>", //_help_txt35
	"<b>Dynamic:</b> If the ISP's servers assign the router's IP addressing upon establishing a connection, select this option.", //_help_txt36
	"WAN MTU Setting", //_help_txt37
	"The Maximum Transmission Unit (MTU) is a parameter that determines the largest packet size (in bytes) that the router will send to the WAN. If LAN devices send larger packets, the router will break them into smaller packets. Ideally, you should set this to match the MTU of the connection to your ISP. Typical values are 1500 bytes for an Ethernet connection and 1492 bytes for a PPPoE connection. If the router's MTU is set too high, packets will be fragmented downstream. If the router's MTU is set too low, the router will fragment packets unnecessarily and in extreme cases may be unable to establish some connections. In either case, network performance can suffer. t modes.", //_help_txt38
	"LAN Interface Setting", //_help_txt39
	"The IP address of the this device on the local area network. Assign any unused IP address in the range of IP addresses available for the LAN. For example, 192.168.10.101.", //_help_txt41
	"The subnet mask of the local area network.", //_help_txt43
	"DHCP stands for Dynamic Host Configuration Protocol. The DHCP section is where you configure the built-in DHCP Server to assign IP addresses to the computers and other devices on your local area network (LAN).", //_help_txt45
	"Once your router is properly configured and this option is enabled, the DHCP Server will manage the IP addresses and other network configuration information for computers and other devices connected to your Local Area Network. There is no need for you to do this yourself.", //_help_txt47
	"The computers (and other devices) connected to your LAN also need to have their TCP/IP configuration set to \"DHCP\" or \"Obtain an IP address automatically\". When you set <b>Enable DHCP Server</b>, the following options are displayed.", //_help_txt48
	"These two IP values (Start and End) define a range of IP addresses that the DHCP Server uses when assigning addresses to computers and devices on your Local Area Network. TAny addresses that are outside of this range are not managed by the DHCP Server; these could, therefore, be used for manually configured devices or devices that cannot use DHCP to obtain network address details automatically.", //_help_txt50
	"It is possible for a computer or device that is manually configured to have an address that does reside within this range. In this case the address should be reserved, so that the DHCP Server knows that this specific address can only be used by a specific computer or device.", //_help_txt51
	"Your router, by default, has a static IP address of 192.168.10.1. This means that addresses 192.168.10.2 to 192.168.10.254 can be made available for allocation by the DHCP Server.", //_help_txt52
	"The subnet mask of the local area network.", //_help_txt54
	"The IP address of the router on the local area network. For example, 192.168.10.1.", //_help_txt56
	"The amount of time that a computer may have an IP address before it is required to renew the lease. The lease functions just as a lease on an apartment would. The initial lease designates the amount of time before the lease expires. If the tenant wishes to retain the address when the lease is expired then a new lease is established. If the lease expires and the address is no longer needed than another tenant may use the address.", //_help_txt58
	"Ajouter/Editer une réservation DHCP", //_help_txt59
	"This option lets you reserve IP addresses, and assign the same IP address to the network device with the specified MAC address any time it requests an IP address. This is almost the same as when a device has a static IP address except that the device must still request an IP address from the router. The router will provide the device the same IP address every time. DHCP Reservations are helpful for server computers on the local network that are hosting applications such as Web and FTP. Servers on your network should either use a static IP address or use this option.", //_help_txt60
	"You can assign a name for each computer that is given a reserved IP address. This may help you keep track of which computers are assigned this way. Example: <b>Game Server</b>.", //_help_txt62
	"Adresse de réseau local que vous voulez réserver.", //_help_txt64
	"To input the MAC address of your system, enter it in manually or connect to the router's Web-Management interface from the system and click the <b>Copy Your PC's MAC Address</b> button.", //_help_txt66
	"A MAC address is usually located on a sticker on the bottom of a network device. The MAC address is comprised of twelve digits. Each pair of hexadecimal digits are usually separated by dashes or colons such as 00-0D-88-11-22-33 or 00:0D:88:11:22:33. If your network device is a computer and the network card is already located inside the computer, you can connect to the router from the computer and click the <b>Copy Your PC's MAC Address</b> button to enter the MAC address.", //_help_txt67
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt69
	"This shows clients that you have specified to reserve DHCP addresses. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit DHCP Reservation\" section is activated for editing.", //_help_txt71
	"Dans cette section vous pouvez voir quels dispositifs du LAN louent actuellement des adresses IP dynamiques.", //_help_txt73
	"IPv6 can be configured with the following connection types: Stateless DHCPv6, Stateful DHCPv6, Link-Local, Static, PPPoE, 6to4 , IPv6 in IPv4 Tunnel, and 6rd (IPv6 Rapid Deployment).  Please consult with your local ISP (Internet Service Provider) to obtain information in regard to the IPv6 connection type.  Note: In order to avoid any software conflict, please be sure to remove or disable any PPPoE client software on your computer when using the PPPoE connection type.", //_help_txt85
	"Please select this connection type if your ISP provides you with a set of IPv6 static addresses.  Configuration settings, such as IPv6 address, Default Gateway, Primary DNS Server, and Secondary DNS Server, and Subnet Prefix Length are required and will be entered manually.  Please contact your local ISP for all relevant information.", //_help_txt87
	"DHCPv6 sans état", //_help_txt82
	" Nodes on an IPv6 network can use the ICMPv6 and DHCPv6 server to obtain configuration information such as a list of DNS recursive name servers.  A Stateless DHCPv6 mode does not maintain any dynamic state for individual clients.", //_help_txt83
	"DHCPv6 (avec état)", //_help_txt84
	"Hosts from DHCPv6 servers to obtain IP addresses and other configuration information.  Dynamic state information about each individual client is stored and centrally managed on the DHCPv6 server.", //_help_txt85
	"6to4 is provided as a transition for migrating from IPv4 to IPv6.  It allows IPv6 packets to be transmitted over an IPv4 network through the automatic tunneling technology, and routes traffic between 6to4 and IPv6 networks.", //_help_txt89
	"6in4", //_help_txt90
	"IPv6 in IPv4 tunneling has the capability to encapsulate IPv6 packets within IPv4 packets for transmission over an IPv4 infrastructure.", //_help_txt91
	"It is a mechanism used to facilitate IPv6 rapid deployment across current IPv4 infrastructures.", //_help_txt93
	"IPv6 DNS Server Setting", //_help_txt94
	"Enter the IPv6 addresses of the DNS Servers provided by your ISP.", //_help_txt95
	"LAN IPv6 IP Setting", //_help_txt96
	"The following settings will be applied to the LAN (Local Area Network) IPv6 interface.  You ISP will assign an IPv6 address and subnet (prefix /64 will be supported in LAN) to be configured in the LAN IPv6 Address Configuration section of this device.", //_help_txt97
	"Paramètres de configuration automatique de l'adresse du réseau local", //_help_txt98
	"Set up IPv6 Autoconfiguration in this section in order to have IPv6 addresses assigned to the clients on the local area network.", //_help_txt99
	"<b>Stateless Auto:</b> When connected to an IPv6 network utilizing ICMPv6 (Internet Control Message Protocol version 6) router discovery messages, IPv6 hosts will be configured automatically.", //_help_txt100
	"<b>Stateless DHCPv6:</b> A stateless DHCP server will only provide configuration information to the nodes and will rely on ICMPv6 (Internet Control Message Protocol version 6) router discovery messages to assign IPv6 addresses.", //_help_txt101
	"<b>DHCPv6(Stateful):</b> Dynamic Host Configuration Protocol for IPv6.  Stateless address autoconfiguration for IPv6 can be used to acquire access in an IPv6 network, however, it is generally recommended to use DHCPv6 instead to assign addresses, name servers and other configuration information to the clients.", //_help_txt102
	"<b>IPv6 Address Range (DHCPv6):</b> This device will manage IPv6 addresses and other configuration information for all clients connected to it as soon as it is properly configured with this option enabled.  However, users may also opt to use manual IPv6 configuration if they prefer as long as the address does not reside within the range specified here.", //_help_txt103
	"<b>IPv6 Address Lifetime:</b> The time duration in which a client is required to release and renew its IPv6 address.", //_help_txt104
	"Quality of Service Settings", //_help_txt105
	"QoS Setup", //_help_txt106
	"There are several Maximum upload bandwidth to choose or user defined.", //_help_txt107
	"QoS Group", //_help_txt108
	"There are several group of QoS rate and ceil upload bandwidth to setup.", //_help_txt109
	"Lien-local uniquement", //_help_txt110
	"L'adresse lien-local est utilisée par des nœuds et des routeurs lorsqu'ils communiquent avec des nœuds voisins sur le même lien. Ce mode active les périphériques compatibles IPv6 pour qu'ils communiquent les uns avec les autres côté réseau local.", //_help_txt111
	"Select this option if your ISP requires you to use a PPPoE (Point to Point Protocol over Ethernet) connection to IPv6 Internet. DSL providers typically use this option. This method of connection requires you to enter a <b>Username</b> and <b>Password</b> (provided by your Internet Service Provider) to gain access to the IPv6 Internet. ", //_help_txt113
	"<b>Auto:</b>Select this option if the ISP's servers assign the router's WAN IPv6 address upon establishing a connection.", //_help_txt114
	"<b>Static:</b>If your ISP has assigned a fixed IPv6 address, select this option. The ISP provides the value for the IPv6 Address.", //_help_txt115
	"Liste QoS", //_help_txt116
	"Puedes configurar QoS para diferentes Aplicaciones de protocolo.", //_help_txt117
	"Radio Activée/Désactivée:", //_help_txt121
	"This indicates the wireless operating status. The wireless can be turned on or off by the slide switch. When the radio is on, the following parameters are in effect.", //_help_txt122
	"If all of the wireless devices you want to connect with this router can connect in the same transmission mode, you can improve performance slightly by choosing the appropriate wireless mode. If you have some devices that use a different transmission mode, choose the appropriate wireless mode. ", //_help_txt123
	"There are many different configuration options available to choose from. Use the drop down list to select the wireless mode.", //_help_txt124
	"Note: One wireless mode can be selected can select at any one time. This means that you can only select one of the operating frequency at a time.", //_help_txt125
	"Options de mode sans fil", //_help_txt126
	"<b>2.4GHz 802.11b/g mixed mode</b> - This wireless mode works in the 2.4GHz frequency range and will allow both wireless b and wireless g client to connect and access the %m at 11Mbps for wireless b, at 54Mbps for wireless g and share access at the same time. Although the wireless b/g operates in the 2.4GHz frequency, it will allow the use of other 2.4GHz client devices (Wireless n/g @ 54Mbps) to connect and access at the same time.", //_help_txt127
	"<b>2.4GHz 802.11 n only</b> ??This wireless mode works in the 2.4GHz frequency range and will only allow the use of wireless n client devices to connect and access the %m. Although the wireless n operates in the 2.4GHz frequency, this mode will only permit wireless n client devices to work and will exclude any other wireless mode and devices that are not wireless n only.", //_help_txt128
	"<b>5GHz 802.11a only mode</b> - This wireless mode works in the 5GHz frequency range and will allow wireless a client to connect and access the %m at 54Mbps for wireless a only mode. Although the wireless a operates in the 5GHz frequency, this mode will only permit wireless a client devices to work and will exclude any other wireless mode and devices that are not wireless a only.", //_help_txt129
	"<b>5GHz 802.11a/n mixed mode</b> - This wireless mode works in the 5GHz frequency range and will only allow the use of wireless a/n dual band client devices to connect and access the %m*. Dual band wireless client devices that support both wireless a/n can connect and access the %m. Wireless a client devices can connect and access the %m but, will only connect up to 54Mbps, (this due to the legacy limitation of wireless a technology for that standard). Although the wireless a/n operate in the same 5GHz frequency, this mode will only permit wireless a/n client devices to work and will exclude any other wireless mode and devices that are not wireless a/n. (note: wireless b/g/n will not be able to connect at the same time to the %m with 5GHz wireless a/n mode enable).", //_help_txt130
	"<b>2.4 GHz 802.11b/g/n mixed mode</b> - This wireless mode works in the 2.4GHz frequency range and will only allow the use of wireless g client devices to connect and access the %m at 11Mbps for wireless b, 54Mbps for wireless g and up to 150Mbps* for wireless n and share access at the same time. Although the wireless b/g/n operates in the same 2.4GHz frequency, it will allow the use of other 2.4GHz client devices (Wireless b/g/n) to connect and access at the same time.", //_help_txt131
	"*Maximum wireless signal rates are referenced from IEEE 802.11 theoretical specifications. Actual data throughput and coverage will vary depending on interference, network traffic, building materials and other conditions.", //_help_txt132
	"When you are browsing for available wireless networks, this is the name that will appear in the list (unless Visibility Status is set to Invisible, see below). This name is also referred to as the SSID. For security purposes, it is highly recommended to change from the pre-configured network name. Add up to three additional SSIDs to create virtual wireless networks from one wireless Router Access Point device.", //_help_txt133
	"Ajouter Nom de Réseau Sans fil Supplémentaire (SSID)", //_help_txt134
	"To add additional wireless Network Names simply add the name to the Multiple SSID field and click on apply at the bottom of the page. When finished, go to the Security section in this Users Guide for wireless security configuration.", //_help_txt135
	"Fréquence (Canal)", //_help_txt136
	"Un réseau sans fil utilise des canaux spécifiques du spectre sans fil pour gérer la communication entre les clients. Certains canaux de votre zone peuvent être soumis à des perturbations provoquées par d'autres périphériques électroniques. Choisissez le canal le plus net pour optimiser les performances et la couverture de votre réseau sans fil.", //_help_txt137
	"Système de distribution sans fil (WDS)", //_help_txt138
	"When WDS is enabled, this access point functions as a wireless repeater and is able to wirelessly communicate with other APs via WDS links. A WDS link is bidirectional; so this AP must know the MAC Address (creates the WDS link) of the other AP, and the other AP must have a WDS link back to this AP. Each WDS APs need setting as same channel, encryption type. (Note that WDS security is incompatible with mixed mode, like WPAPSK+WPA2PSK mixed, WEP AUTO and 802.1x, both feature cannot be used at the same time).", //_help_txt139
	"Configuration du WDS avec", //_help_txt140
	"Enable the option for WDS and input the MAC Address of the wireless device that also supports WDS in to the blank fields. You can add up to four additional devices in the spaces provided. Click on apply at the bottom of the page, to apply your setting changes. Enable the security seeing in security page, each WDS APs need to use same security setting. (Note: WDS supports wireless g/n modes. The use multiple Access Point will reduces the overall network throughput to ½ the %m", //_help_txt141
	"When WDS is enabled, this access point functions as a wireless repeater and is able to wirelessly communicate with other APs via WDS links. A WDS link is bidirectional, so this AP must know the MAC Address (creates the WDS link) of the other AP, and the other AP must have a WDS link back to this AP. Make sure the APs are configured with same channel number, encryption type. (Note that WDS security is incompatible with mixed mode, like WPAPSK+WPA2PSK mixed, WEP AUTO and 802.1x, both feature cannot be used at the same time).", //_help_txt142
	"Input the MAC Address of the wireless device that also supports WDS link in to the blank fields. The other AP must also have the MAC address of this AP to create the WDS link back to this AP. Enter a MAC address for each of the other APs that you want to connect with WDS.", //_help_txt143
	"Mode Physique HT", //_help_txt144
	"Le paramétrage en mode physique HT (encours élevé) permet le contrôle de l'environnement sans fil 802.11n.", //_help_txt145
	"Mode de fonctionnement", //_help_txt146
	"Mode mixte", //_help_txt147
	"Green Field", //_help_txt148
	"In this mode packets are transmitted with a preamble compatible with the legacy 802.11a/g, the rest of the packet has a new format. In this mode the receiver shall be able to decode both the Mixed Mode packets and legacy packets.", //_help_txt149
	"In this mode high throughput packets are transmitted without a legacy compatible part.", //_help_txt150
	"Largeur de canal", //_help_txt151
	"Définissez la largeur de canal de radio sans fil", //_help_txt152
	"largeur de canal 20 = 20 MHz", //_help_txt153
	"largeur de canal 20/40 = 20/40 MHz", //_help_txt154
	"Intervalle de garde", //_help_txt155
	"Prise en charge GI (intervalle de garde) court/long, le but de l'intervalle de garde est d'introduire l'immunité aux délais de propagation, échos et réflets, pour lesquels les données numériques sont normalement très sensibles.", //_help_txt156
	"Long", //_help_txt157
	"Long intervalle de garde, 800 nsec", //_help_txt158
	"Court intervalle de garde, 400 nsec", //_help_txt159
	"MCS", //_help_txt160
	"Define el rango de MCS para rango de HT.<br/>􀂃 0-15<br/>El Esquema de Modulación y Codificación (MCS) es un valor que determina la modulación, la codificación y el número de canales espaciales.", //_help_txt161
	"Intervalle de balise", //_help_txt162
	"Les balises sont des paquets envoyés par un routeur sans fil pour synchroniser les dispositifs sans fil. Indiquez une valeur d’Intervalle de balise entre 20 et 1000. La valeur par défaut est réglée à 100 millisecondes.", //_help_txt163
	"DTIM", //_help_txt164
	"Un DTIM est un compte à rebours informant les clients la prochaine fenêtre pour écouter les messages de multidiffusion. Quand le routeur sans fil a mis en mémoire des messages de multidiffusion pour les clients associés, il envoie le prochain DTIM avec une valeur d'intervalle de DTIM. Les clients sans fil détectent les balises et se réveillent pour recevoir l'émission de multidiffusion. La valeur par défaut est 1. Les réglages valides sont entre 1 et 255.", //_help_txt165
	"Seuil de fragmentation", //_help_txt166
	"Wireless frames can be divided into smaller units (fragments) to improve performance in the presence of RF interference and at the limits of RF coverage. Fragmentation will occur when frame size in bytes is greater than the Fragmentation Threshold. This setting should remain at its default value of 2346 bytes. Setting the Fragmentation value too low may result in poor performance.", //_help_txt167
	"When an excessive number of wireless packet collisions are occurring, wireless performance can be improved by using the RTS/CTS (Request to Send/Clear to Send) handshake protocol. The wireless transmitter will begin to send RTS frames (and wait for CTS) when data frame size in bytes is greater than the RTS Threshold. This setting should remain at its default value of 2346 bytes.", //_help_txt168
	"Préalable court et Slot", //_help_txt169
	"L'utilisation d'un intervalle de garde court (400 ns) peut augmenter le débit. Cependant, il peut aussi augmenter le nombre d'erreurs sur certaines installations en raison de la sensibilité accrue aux réflexions de radiofréquence. Sélectionnez l'option la", //_help_txt170
	"TX Burst", //_help_txt171
	"Permet au routeur sans fil de fournir un meilleur débit dans la même période et environnement dans le but d'augmenter la vitesse.", //_help_txt172
	"Pkt_Aggregate", //_help_txt173
	"Increase efficiency by aggregating multiple packets of application data into a single transmission frame. In this way, 802.11n networks can send multiple data packets with the fixed overhead cost of just a single frame.", //_help_txt174
	"Les transmissions sans fil vers et à partir de votre réseau sans fil peuvent être facilement interceptées et interprétées par des utilisateurs non autorisés, sauf si vous choisissez l'un des modes de chiffrement disponibles.", //_help_txt175
	"Le protocole WEP est une méthode de chiffrement des données pour les communications sans fil, visant à fournir le même niveau de protection qu'un réseau câblé. Le WEP n'est pas aussi sûr que le chiffrement WPA. Pour pouvoir accéder à un réseau WEP, vous devez connaître la clé. La clé est une chaîne de caractères créée par vos soins. Quand vous utilisez le WEP, vous devez déterminer le niveau de chiffrement. C’est lui qui détermine la longueur de la clé. Un chiffrement sur 128 bits requiert une clé plus longue qu'un chiffrement sur 64 bits. Les clés sont définies en saisissant une chaîne au format hexadécimal (caractère 0 à 9 et A à F) ou au format ASCII (American Standard Code for Information Interchange, caractères alphanumériques). Le format ASCII vous permet de saisir une chaîne plus facile à mémoriser. Cette chaîne ASCII est ensuite convertie au format hexadécimal pour être utilisée sur le réseau. Vous pouvez définir jusqu'à quatre clés, ce qui vous permet d'en changer facilement. Une clé définie par défaut est sélectionnée et utilisée sur le réseau.", //_help_txt176
	"Both of these options select some variant of Wi-Fi Protected Access (WPA) -- security standards published by the Wi-Fi Alliance. The WPA Mode further refines the variant that the router should employ.", //_help_txt177
	"WPA Mode: WPA is the older standard; select this option if the clients that will be used with the router only support the older standard. WPA2 is the newer implementation of the stronger IEEE 802.11i security standard. With the \"WPA2\" option, the router tries WPA2 first, but falls back to WPA if the client only supports WPA. With the \"WPA2 Only\" option, the router associates only with clients that also support WPA2 security.", //_help_txt178
	"Cipher Type: The encryption algorithm used to secure the data communication. TKIP (Temporal Key Integrity Protocol) provides per-packet key generation and is based on WEP. AES (Advanced Encryption Standard) is a very secure block based encryption. With the \"TKIP and AES\" option, the router negotiates the cipher type with the client, and uses AES when available.", //_help_txt179
	"<b>Intervalle de mise à jour de clé du groupe:</b> La durée avant que la clé du groupe utilisée pour la diffusion des données de multidiffusion soit changée.", //_help_txt180
	"Cette option utilise le WPA et une clé pré-partagée (PSK).", //_help_txt181
	"Clé pré-partagée: La clé est saisie comme une phrase d’un maximum de 63 caractères alphanumériques dans le format ASCII (American Standard Code for Information Interchange) aux deux extrémités du raccordement sans fil. Elle ne peut pas être plus courte que huit caractères, bien que pour une meilleure sécurité, elle doit atteindre une longueur suffisante et ne devrait pas être une phase généralement connue. Cette phase est employée pour générer des clés de session qui sont uniques pour chaque client sans fil.", //_help_txt182
	"Cette option travaille avec un serveur RADIUS pour authentifier les clients sans fil. Les clients sans fil doivent s’authentifier au serveur par l’intermédiaire de cette passerelle. En outre, il peut être nécessaire de configurer le serveur RADIUS pour autoriser cette passerelle d'authentifier des utilisateurs.", //_help_txt183
	"Temporisation d'authentification: urée du bail avant que le client ne doive se reauthentifier.", //_help_txt184
	"Adresse IP du Serveur RADIUS: Adresse IP du serveur d'authentification.", //_help_txt185
	"Port du serveur RADIUS: Numéro de port utilisé pour se connecter au serveur d'authentification.", //_help_txt186
	"Secret partagé du Serveur RADIUS: Une phrase qui doit correspondre à celle du le serveur d'authentification.", //_help_txt187
	"Wireless MAC Filtering", //_help_txt188
	"Choose the type of MAC filtering needed.", //_help_txt189
	"<b>Turn MAC Filtering Disable:</b> When \"Disable\" is selected, MAC addresses are not used to control network access.", //_help_txt190
	"Add MAC Filtering Rule", //_help_txt191
	"Use this section to add MAC addresses to the list below.", //_help_txt192
	"Enter the MAC address of a computer that you want to control with MAC filtering. Computers that have obtained an IP address from the router's DHCP server will be in the DHCP Client List. Select a device from the drop down menu.", //_help_txt193
	"Enable the WPS feature.", //_help_txt194
	"Locking the wireless security settings prevents the settings from being changed by any new external registrar using its PIN. Devices can still be added to the wireless network using WPS.", //_help_txt195
	"Un code PIN est un numéro unique destiné à ajouter le routeur à un réseau existant ou à créer un réseau. Celui par défaut peut figurer en bas du routeur. Pour davantage de sécurité, vous pouvez obtenir un autre code PIN. Vous êtes également en mesure de restaurer le numéro par défaut à tout moment. En revanche, seul l'administrateur peut modifier ou réinitialiser le code PIN.", //_help_txt196
	"Affiche la valeur du code PIN du routeur.", //_help_txt197
	"Reset To WPS Default", //_help_txt198
	"Restaurez le code PIN par défaut du routeur.", //_help_txt199
	"Créez de manière aléatoire un code PIN valide associé au routeur. Si nécessaire, copiez-le dans l'interface utilisateur du registre.", //_help_txt200
	"You could monitor stations which associated to this AP here.", //_help_txt201
	"Enter a password for the user \"admin\", who will have full access to the Web-based management interface. ", //_help_txt202
	"The name of the router can be changed here. ", //_help_txt203
	"Activez seulement cette option si vous avez acheté votre propre Nom de domaine et vous êtes inscrits sur un fournisseur de service de DNS dynamique. Les paramètres suivants sont affichés quand l'option est activée.", //_help_txt204
	"Dynamic DNS Provider", //_help_txt205
	"Sélectionnez un fournisseur de service DNS dynamique dans la liste déroulante ou entrez un fournisseur de service DNS dynamique manuellement.", //_help_txt206
	"Saisissez votre nom d'hôte, entièrement qualifié ; par exemple : <b>monhôte.mondomaine.net</b>.", //_help_txt207
	"Account", //_help_txt208
	"Enter the account provided by your service provider. If the Dynamic DNS provider supplies only a key, enter that key in all three fields. ", //_help_txt209
	"Enter the password provided by your service provider. If the Dynamic DNS provider supplies only a key, enter that key in all three fields. ", //_help_txt210
	"Une fois que vous avez une mise à jour firmware sur votre ordinateur, employez cette option pour rechercher le fichier et puis le télécharger dans le routeur.", //_help_txt211
	"Exporter paramétrages", //_help_txt212
	"Cette option vous permet d'exporter et puis de sauvegarder la configuration du routeur dans un fichier sur votre rodinateur. Assurez-vous de sauvegarder la configuration avant de faire une mise à niveau de micrologiciel.", //_help_txt213
	"Importer paramétrages", //_help_txt214
	"Employez cette option pour restaurer des réglages sauvegardés de la configuration de routeur.", //_help_txt215
	"Restauration des paramètres d’usine par défaut", //_help_txt216
	"This option restores all configuration settings back to the settings that were in effect at the time the router was shipped from the factory. Any settings that have not been saved will be lost. If you want to save your router configuration settings, use the<b> Export Settings</b> option above. ", //_help_txt217
	"Redémarrage système", //_help_txt218
	"Redémarrage du routeur. C’est utile pour le redémarer quand vous n'êtes pas près du produit.", //_help_txt219
	"Il affiche l’heure actuelle du routeur. Si ce n'est pas correct, veuillez utiliser les options suivantes pour configurer l’heure correctement.", //_help_txt220
	"Sélectionnez votre fuseau horaire local à partir du menu déroulant.", //_help_txt221
	"Sélectionnez cette option si vous voulez synchroniser l'horloge du routeur avec le serveur d'heure réseu à travers Internet. Si vous utilisez des calendriers ou logs, c'est la meilleure façon de s'assurer que les calendriers et logs restent précis.Notez que, même lorsque le serveur NTP est activé, vous devez continuer à choisir un fuseau horaire et définir les paramètres de l'heure d'été.", //_help_txt222
	"Sélectionnez un serveur de temps réseau pour effectuer la synchronisation. Vous pouvez saisir l’adresse d’un serveur de temps ou en choisir un dans la liste. Si vous rencontrez des problèmes avec un serveur, essayez-en un autre.", //_help_txt223
	"Si vous n'avez pas d'option de serveur NTP active, vous pouvez soit définir manuellement l'heure pour votre routeur ici.", //_help_txt224
	"Cette section affiche les informations relatives au statut du périphérique.", //_help_txt225
	"Paramètres DMZ", //_help_txt226
	"DMZ signifie &quot;DeMilitarized Zone&quot;. Si une application a des problèmes à travailler derrière le routeur, vous pouvez exposer un seul ordinateur à Internet et exécuter lapplication sur cet ordinateur.", //_help_txt227
	"Quand un hôte du réseau local est configuré comme un hôte DMZ, il devient la destination pour tous les paquets entrants qui ne correspondent pas à d’autres sessions ou règles entrantes. Si n'importe quelle autre règle d'entrée existe, elle sera employée au lieu d’envoyer les paquets sur l’hôte DMZ; ainsi, une session active, un Serveur Virtuel, un port de déclenchement actif, ou une règle de réacheminement de port auront la priorité sur l’hôte DMZ. (La politique de DMZ ressemble à une règle de réacheminement de port par défaut qui réachemine chaque port qui n'est pas spécifiquement envoyé à un aure endroit )", //_help_txt228
	"Le routeur ne fournit qu’une protection limitée de coupe-feu pour l’hôte DMZ. Le routeur ne réachemine pas un paquet TCP qui ne correspond pas à une session DMZ active, à moins que ce soit un paquet d'établissement de connexion (Caractère de synchronisation SYN). Excepté cette protection limitée de l’hôte DMZ, il est effectivement &quot;en dehors du coupe-feu&quot;. Toute personne voulant  employer un hôte DMZ devrait également activer dessus un parefeu pour assurer une protection supplémentaire.", //_help_txt229
	"Les paquets reçus par l’hôte DMZ ont leurs adresses IP traduites de l'adresse IP WAN du routeur vers l'adresse IP LAN de l’hôte DMZ. Cependant, les numéros de port ne sont pas traduits; ainsi les applications sur l’hôte DMZ peuvent continuer d’utiliser leurs numéros de port spécifiques.", //_help_txt230
	"La fonction DMZ est juste un des moyens pour autoriser les demandes entrantes que le NAT refuserait. En général l’hôte DMZ ne doit être utilisé que s'il n'y a aucune autre solution de rechange, parce qu'il est exposé aux cyberattaques beaucoup plus que les autres systèmes sur le réseau local. Il faut d’abord penser à employer d’autres configurations telles : un Serveur Virtuel, une règle de réacheminement de port, ou un port de déclenchement. Les serveurs virtuels ouvrent un port pour des sessions entrantes restreintes à une application spécifique (et permet également la réorientation de ports et l'utilisation des ALGs). Le réacheminement de port est plutôt un DMZ sélectif, où le trafic entrant d’un ou plusieurs ports est réacheminé à un hôte LAN spécifique (donc moins de ports sont exposés comparé à un hôte DMZ). Port de déclenchement est une forme spéciale de réacheminement de port, qui est activé par le trafic sortant, et pour lequel les ports ne sont réacheminés que lorsque le déclenchement est actif.", //_help_txt231
	"Peu d'applications exigent vraiment l'utilisation d’un hôte DMZ. Voir ci-dessous des exemples où un hôte DMZ pourrait être exigé :", //_help_txt232
	"‧ Un hôte peut supporter plusieurs applications qui pourraient nécessiter des ports d'entrée se chevauchant. Alors les deux règles de réacheminement de ports ne peuvent pas être employées parce qu'elles seraient potentiellement en conflit.", //_help_txt233
	"‧ Prendre en charge les connexions entrantes utilisant un protocole autre que ICMP (quand ces protocoles sont permis par les ALGs PPTP et IPSec).", //_help_txt234
	"Le fait de placer un ordinateur dans une zone DMZ l'expose à divers risques liés à la sécurité. Utilisez cette option uniquement si elle est recommandée en dernier recours.", //_help_txt235
	"Spécifiez l'adresse IP LAN de l'ordinateur LAN pour lequel vous voulez qu'il  ait une communication Internet illimitée.", //_help_txt236
	"Ajouter/Editer Serveur Virtuel", //_help_txt237
	"Spécifie si l'entrée sera active ou inactive.", //_help_txt238
	"Assign a meaningful name to the virtual server, for example <b>Web Server</b>. Several well-known types of virtual server are available from the \"Application Name\" drop-down list. Selecting one of these entries fills some of the remaining parameters with standard values for that type of server.", //_help_txt239
	"L'adresse IP du système présent sur votre réseau interne et qui fournit le service virtuel (par ex. <b>192.168.0.50</b>).Vous pouvez choisir un ordinateur à partir de la liste de clients DHCP dans le menu déroulant &quot;Nom d’ordinateur &quot;, ou vous pouvez saisir manuellement l'adresse IP de l'ordinateur serveur.", //_help_txt240
	"Sélectionnez le protocole utilisé par le service. Les choix courants (UDP, TCP et UDP plus TCP) peuvent être sélectionnés dans le menu déroulant. Pour définir un autre protocole, sélectionnez \"Autre\" dans la liste, puis saisissez le numéro de protocole correspondant ( attribué par IANA) dans la zone <b>Protocole</b>.", //_help_txt241
	"Le port utilisé sur votre réseau interne.", //_help_txt242
	"Il s'agit du port qui sera accessible depuis Internet.", //_help_txt243
	"Sélectionnez une programmation pour définir le moment d'activation du service. Si la programmation nécessaire ne s'affiche pas dans la liste.", //_help_txt244
	"Réinitialisez cette zone de l'écran, annulant toutes les modifications que vous avez faites.", //_help_txt245
	"Ajouter/Editer Route", //_help_txt246
	"Ajoute une nouvelle route à la table de routage IP ou édite une route existante.", //_help_txt247
	"Adresse IP des paquets utilisant cet acheminement.", //_help_txt248
	"Spécifie le prochain saut si cet acheminement est utilisé. Une passerelle de 0.0.0.0 implique quil nexiste pas de prochain saut et ladresse IP qui concorde est directement associée au routeur sur linterface spécifiée : LAN ou WAN.", //_help_txt249
	"Pour évaluer le coût d'utilisation d'un acheminement, une valeur comprise entre 1 et 16 sert d'indicateur. La valeur 1 correspond au coût le plus faible et 15 au coût le plus élevé. Quant au nombre 16, il indique que l'acheminement est impossible depuis ce routeur. Pour tenter d'atteindre une destination particulière, les ordinateurs de votre réseau ignorent cette valeur et sélectionnent le meilleur acheminement.", //_help_txt250
	"Spécifie linterface -- LAN ou WAN -- que le paquet IP doit utiliser pour transiter hors du routeur lorsque cet acheminement est utilisé.", //_help_txt251
	"Réinitialisez cette zone de l'écran, annulant toutes les modifications que vous avez faites.", //_help_txt252
	"The section shows the current routing table entries. Certain required routes are predefined and cannot be changed. Routes that you add can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Route\" section is activated for editing. Click the Enable checkbox at the left to directly activate or de-activate the entry.", //_help_txt253
	"Par défaut, le dispositif de contrôle d'accès est désactivé. Si vous avez besoin du contrôle d'accès, vérifiez cette option.", //_help_txt254
	"<b>Remarque:</b>Quand le contrôle d'accès est désactivé, chaque machine sur le réseau local a un accès sans restriction à Internet. Cependant, si vous activez le contrôle d'accès, l'accès à Internet est restreint pour les machines à qui s’applique ce contrôle d'accès. Toutes les autres machines ont un accès sans restriction à Internet.", //_help_txt255
	"By default, the ALG feature is enabled. ALG configuration allows users to disable some application service.", //_help_txt256
	"Add/Edit Port Trigger Rule", //_help_txt257
	"Specifies whether the entry will be active or inactive.", //_help_txt258
	"Enter a name for the Special Application Rule, for example <b>Game App</b>, which will help you identify the rule in the future. Alternatively, you can select from the <b>Application</b> list of common applications.", //_help_txt259
	"Select the protocol used by the service. The common choices -- UDP, TCP, and both UDP and TCP -- can be selected from the drop-down menu.", //_help_txt260
	"Enter the outgoing port range used by your application (for example <b>6500-6700</b>).", //_help_txt261
	"Select a schedule for when this rule is in effect.", //_help_txt262
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt263
	"This is a list of the defined application rules. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon.", //_help_txt264
	"Add/Edit Port Range Rule", //_help_txt265
	"Use this section to add a Port Range Rule to the following list or to edit a rule already in the list.", //_help_txt266
	"Specifies whether the entry will be active or inactive.", //_help_txt267
	"Give the rule a name that is meaningful to you, for example <b>Game Server</b>. You can also select from a list of popular games, and many of the remaining configuration values will be filled in accordingly. However, you should check whether the port values have changed since this list was created, and you must fill in the IP address field.", //_help_txt268
	"Enter the local network IP address of the system hosting the server, for example <b>192.168.10.50</b>. You can select a computer from the list of DHCP clients in the \"Computer Name\" drop-down menu, or you can manually enter the IP address of the server computer.", //_help_txt269
	"Ports TCP à ouvrir", //_help_txt270
	"Entrez les ports TCP à ouvrir (par ex. <b>6159-6180, 99</b>).", //_help_txt271
	"Ports UDP à ouvrir", //_help_txt272
	"Entrez les ports UDP à ouvrir (par ex. <b>6159-6180, 99</b>).", //_help_txt273
	"Sélectionnez un filtre qui contrôle l'accès selon les besoins pour cette règle.", //_help_txt274
	"Sélectionnez un calendrier pour indiquer quand cette règle est en vigueur.", //_help_txt275
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt276
	"This is a list of the defined Port Range Rules. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Port Forwarding Rule\" section is activated for editing.", //_help_txt277
	"Ajouter/Mettre à jour une règle de filtre entrant", //_help_txt278
	"Ici vous pouvez ajouter des entrées à la liste des règles de filtres entrants ci-dessous ou éditer les entrées existantes.", //_help_txt279
	"Nommez la règle de façon significative.", //_help_txt280
	"La règle peut autoriser ou refuser les messages.", //_help_txt281
	"Define the ranges of Internet addresses this rule applies to. For a single IP address, enter the same address in both the <b>Start</b> and <b>End</b> boxes. Up to eight ranges can be entered. The <b>Enable</b> checkbox allows you to turn on or off specific entries in the list of ranges.", //_help_txt282
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt283
	"The section lists the current Inbound Filter Rules. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Inbound Filter Rule\" section is activated for editing.", //_help_txt284
	"En plus des filtres listés ici, deux filtres prédéfinis sont disponibles partout où des filtres entrants peuvent être appliqués :", //_help_txt285
	"Autoriser n'importe quel utilisateur du réseau étendu à accéder à la fonction apparentée.", //_help_txt286
	"Empêchez tous les utilisateurs du WAN d'accéder à ces possibilitées. (Les utilisateurs du réseau local ne sont pas affectés par des règles de filtre entrant.)", //_help_txt287
	"Ajouter/Modifier une règle de calendrier", //_help_txt288
	"Dans cette section, vous pouvez ajouter des entrées aux règles de planifications listées ou éditer les entrées existantes.", //_help_txt289
	"Nommez le calendrier de façon significative, par exemple &quot;règle Jour de semaine&quot;.", //_help_txt290
	"Placez une coche dans les boîtes pour les jours désirés ou choisissez la case d’option Toute la semaine pour choisir tous les jours d’une semaine.", //_help_txt291
	"Sélectionnez cette option si vous voulez que ce calendrier soit effectif toute la journée des jours sélectionnés.", //_help_txt292
	"Si vous n'utilisez pas l'option Toute la journée, indiquez l'heure au moyen de cette option. L'heure de début est entrée au moyen de deux champs. Le premier permet de spécifier l'heure, tandis que le second sert à indiquer les minutes. Les événements par courrier électronique ne sont normalement déclenchés que par l'heure de début.", //_help_txt293
	"Entrez l'heure finale en utilisant le même format que celui de l'heure de début : l'heure dans le premier champ et les minutes dans le deuxième. L'heure finale est utilisée pour la plupart des autres règles, mais en général pas par les événements de courrier électronique.", //_help_txt294
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt295
	"Cette section affiche les règles de calendrier actuellement définies. Pour modifier ou supprimer une règle de calendrier, cliquez respectivement sur le bouton Modifier ou Supprimer. Quand vous cliquez sur le bouton Modifier, l'élément apparaît en surbrill", //_help_txt296
	"By default, the UPnP feature is enabled. Universal Plug and Play (UPnP) is a set of networking protocols for primarily residential networks without enterprise class devices that permits networked devices, such as personal computers, printers, Internet gateways, Wi-Fi access points and mobile devices to seamlessly discover each other's presence on the network and establish functional network services for data sharing, communications, and entertainment.", //_help_txt297
	"By default, the WAN Ping Respond feature is disabled. Enable WAN Ping Respond will reply information of router to outside network.", //_help_txt298
	"The Inbound Filter controlling data received from the Internet. In this feature you can configure inbound data filtering rules that control data based on an IP address.", //_adv_txt_23
	"Ajouter une règle de filtre entrant", //_adv_txt_24
	"Action de règle", //_adv_txt_25
	"Le nom de %s : %s est déjà dans la liste", //_adv_txt_26
	"Liste de filtrage entrante", //_adv_txt_27
	"Paramètres du réseau IPv6", //_net_ipv6_01
	"Cette section vous permet de configurer les paramètres IPv6 de votre connexion Internet et les paramètres IPv6 LAN. Si vous n’êtes pas certain des paramètres Ipv6 de votre connexion Internet, veuillez contacter votre fournisseur d’accès Internet (FAI).", //_net_ipv6_02
	"Paramétrage IP IPv6 WAN", //_net_ipv6_03
	"Autoconfiguration sans état", //_net_ipv6_04
	"Longueur de préfixe LAN", //_net_ipv6_05
	"IPv6 a Configuraciones IPv4", //_net_ipv6_06
	"Adresse IPv6 vers IPv4", //_net_ipv6_07
	"Paramétrage PPPoE", //_net_ipv6_08
	"Utilisez le paramétrage MTU par défaut", //_net_ipv6_09
	"Paramétrage MTU", //_net_ipv6_10
	"Configurer manuellement DNS", //_net_ipv6_11
	"STATIQUE", //_net_ipv6_12
	"Paramétrages de Qualité de Service", //_qos_txt00
	"You may setup rules to provide Quality of Service guarantees for specific applications.", //_qos_txt01
	"Configuration QoS", //_qos_txt02
	"Qualité de service", //_qos_txt03
	"Transmission de la largeur de bande", //_qos_txt04
	"Défini par l'utilisateur", //_qos_txt05
	"Bits par seconde.", //_qos_txt06
	"Largeur de bande de téléchargement", //_qos_txt07
	"Charger par défaut", //_qos_txt08
	"La valeur de largeur de bande de téléchargement est trop petite, êtes-vous sûr?", //_qos_txt09
	"La valeur de largeur de bande de téléchargement est trop grande.", //_qos_txt10
	"La largeur de bande de téléchargement maximum", //_qos_txt11
	"Le format de largeur de bande de téléchargement est mauvais. (ex. \"10k\" \"20M\")", //_qos_txt12
	"Veuillez indiquer la largeur de bande de téléchargement entrant.", //_qos_txt13
	"Port Src:", //_qos_txt14
	"Plage de port Src:", //_qos_txt15
	"Catégorie", //_qos_txt16
	"Info.", //_qos_txt17
	"Prio", //_qos_txt18
	"Téléchargement de fichiers %s% au minimum", //_qos_txt19
	"Attribuer", //_qos_txt20
	"Groupe", //_qos_txt21
	"Paramètres", //_qos_txt22
	"Avancé", //_qos_txt23
	"Paramètres basiques de classement", //_qos_txt24
	"Adresse IP cible finale", //_qos_txt25
	"Adresse IP source", //_qos_txt26
	"longueur de paquet", //_qos_txt27
	"Ex. : 0-128 pour les petits paquets", //_qos_txt28
	"DSCP", //_qos_txt29
	"Port Range de Destination", //_qos_txt30
	"Plage de port Src:", //_qos_txt31
	"Remarquer DSCP comme:", //_qos_txt32
	"Veuillez sélectionner une application", //_qos_txt33
	"La plage de port source est invalide.", //_qos_txt34
	"Veuillez indiquer le numéro du port.", //_qos_txt35
	"Le format d'adresse MAC est invalide.", //_qos_txt36
	"Il y un caractère illégal dans le nom.", //_qos_txt37
	"Veuillez entrer un nom.", //_qos_txt38
	"Paramètres de classement avancés", //_qos_txt39
	"La plage du port de destination est invalide.", //_qos_txt40
	"La plage de longueur de paquet est invalide.", //_qos_txt41
	"La longueur du paquet est trop petite.", //_qos_txt42
	"La longueur du paquet est trop grande.", //_qos_txt43
	"La longueur de paquet doit être un nombre entier!", //_qos_txt44
	"Veuillez entrer une plage pour la longueur de paquet. (ex:0-128 64-1024)", //_qos_txt45
	"Veuillez entrer les classifications.", //_qos_txt46
	"Paramètres sans fil basiques", //_basic_wireless_settings
	"Cette section vous perme de configurer les paramètres de base nécessaires à votre réseau sans fil comme le nom de réseau sans fil (SSID) et la clé Wifi.", //_desc_basic
	"Cette section vous permet de surveiller les périphériques clients sans fil actuellement connectés à votre routeur.", //_desc_station_list
	"Cette section vous permet d’activer le WPS (Wi-Fi Protected Setup) qui vous permet de connecter simplement les périphériques clients sans fil compatibles WPS à votre routeur. Le routeur offre trois options de connecter les périphériques client sans fil en utilisant le WPS : le bouton matériel (situé physiquement sur le routeur), le bouton virtuel (PBC), ou le PIN. LE WPS ne peut être utilisé si les fonctions SSID Broadcast sont désactivées.", //_desc_wps
	"RÉSEAU SANS FIL", //_wireless_network
	"Système de distribution sans fil (WDS)", //_wds_long
	"Config WPS", //_wps_config
	"Résumé WPS", //_wps_summary
	"Action WPS", //_wps_action
	"Clients DHCP", //_dhcp_clients
	"Please click Wireless Client Card and Router's WPS button in 120 seconds to complete this setting.", //_desc_wps_action
	"Radio Activée/Désactivée:", //_lb_radio_onoff
	"Radio désactivé de calendrier", //_lb_radio_off_sche
	"Nom du réseau sans fil (SSID)", //_wmode_ssid
	"SSID1 multiples", //_lb_multi_ssid_1
	"SSID2 multiples", //_lb_multi_ssid_2
	"SSID3 multiples", //_lb_multi_ssid_3
	"SSID4 multiples", //_lb_multi_ssid_4
	"SSID5 multiples", //_lb_multi_ssid_5
	"SSID6 multiples", //_lb_multi_ssid_6
	"SSID7 multiples", //_lb_multi_ssid_7
	"Nom de réseau de diffusion (SSID):", //_lb_broadcast_ssid
	"Mode Phy", //_lb_phy_mode
	"Crypter type", //_lb_enc_type
	"Clave  de Encriptación", //_lb_enc_key
	"Adresse MAC d'AP distante", //_lb_apmacaddr
	"Coexistence HT20/40", //_lb_coexistence
	"Répartition avec autorisation en sens inverse (RDG)", //_lb_rdg
	"MCS", //_lb_mcs
	"Canal d'extension", //_lb_exten_channel
	"agrégation MSDU(A-MSDU)", //_lb_a_msdu
	"Blocage AK automatique", //_lb_autoba
	"Décliner la demande BA", //_lb_declineba
	"Ne supporte pas le 40 Mhz", //_lb_forty_into
	"Wifi Optimum", //_lb_wifi_opt
	"FluxTx HT", //_lb_ht_txstream
	"FluxRx HT", //_lb_ht_rxstream
	"Registrar lock (protection contre les transferts) WPS externe", //_lb_wps_ext_reg_lock
	"Auto", //_sel_autoselect
	"Mode mixte", //_sel_mixed
	"Green Field", //_sel_greenfield
	"Long", //_long
	"Radio Activée:", //_btn_radio_on
	"Radio Désactivée:", //_btn_radio_off
	"Le bouton radio Réseau sans fil est désactivé.", //_MSG_woff
	"Use the Advanced Setup page to make detailed settings for the Wireless. Advanced Setup includes items that are not available from the Basic Setup page, such as Beacon Interval, etc.", //_desc_advanced
	"Paramètres de qualité de service", //_bx_advanced_2
	"Wifi Multimédia", //_bx_advanced_3
	"Convertisseur Multicast-vers-Unicast", //_bx_advanced_4
	"Mode protection BG", //_lb_bg_protection
	"(Plage 10 - 100, par défaut 100)", //_hint_beacon
	"(Plage 1 - 255, par défaut 1)", //_hint_dtim
	"Seuil de fragmentation", //_lb_frag_thres
	"(Plage 256 - 2346, par défaut 2346)", //_hint_frag_thres
	"(Plage 1 - 2347, par défaut 2347)", //_hint_rts_thres
	"TX Alimentation", //_lb_txpower
	"Préambule court", //_lb_short_preamble
	"Slot court", //_lb_short_slot
	"Tx Burst", //_lb_tx_burst
	"Pkt_Aggregate", //_lb_pkt_aggregate
	"Compatible IEEE 802.11H", //_lb_80211h_support
	"uniquement sur la bande A", //_hint_only_a_band
	"code pays", //_lb_country_code
	"Fonctionnalité WMM", //_lb_wmm_capable
	"Compatibilité APSD", //_lb_apsd_capable
	"Compatible DLS", //_lb_dls_capable
	"Paramètres WMM", //_lb_wmm_param
	"Configuration WMM", //_lb_wmm_config
	"Turbine vidéo", //_lb_video_turbine
	"Multicast-vers-Unicast", //_lb_multi_uni
	"Expire dans", //_lb_expire_in
	"Entier", //_pwr_full
	"Moitié", //_pwr_half
	"Bas", //_pwr_low
	"Paramétrage WMM sans fil", //_tl_wmm_settings
	"Paramètres WMM du point d’accès", //_lb_wmm_param_ap
	"Paramètres WMM de la station", //_lb_wmm_param_station
	"2.4GHz 802.11b/g", //m_bwl_Mode_3
	"2.4GHz 802.11n seulement", //m_bwl_Mode_8
	"2.4GHz 802.11b/g/n", //m_bwl_Mode_11
	"5GHz 802.11a seulement", //m_bwl_Mode5_1
	"5GHz 802.11n seulement", //m_bwl_Mode5_2
	"5GHz 802.11a/n", //m_bwl_Mode5_3
	"Signal", //_singal
	"BSSID", //_bssid
	"Statut courant WPS", //_wps_cur_state
	"WPS configuré", //_wps_configed
	"WPS SSID", //_wps_ssid
	"Mode de sécurité WPS", //_wps_sec_mode
	"Type de cryptage WPS", //_wps_enc_type
	"Index de clé par défaut WPS", //_wps_def_key_idx
	"HEXADÉCIMAL", //_hex
	"ASCII", //_ascii
	"Clé WPS", //_wps_key
	"AP PIN", //_ap_pin
	"Vous pouvez superviser ici les clients DHCP.", //_desc_dhcp_client_list
	"Setting wireless security.", //_wifiser_mode42
	"Traitement en cours", //_processing
	"Adresse de statut de réseau", //_netwrk_status_addr
	"Info système", //_system_info
	"Heure système", //_system_time
	"Durée de connexion", //_system_up_time
	"Configuration Internet", //_internet_configs
	"Type connecté", //_connected_type
	"Paramètres de l’adresse IP", //_wan_ip_addr
	"Serveur de nom de domaine primaire", //_pri_dns
	"Serveur de nom de domaine secondaire", //_sec_dns
	"Sans fil 2.4GHz", //_24Ghz_wireless
	"Sans fil 5GHz", //_5Ghz_wireless
	"Cette section affiche les informations du journal à des fins de surveillance et de dépannage.", //_SYSLOG_DESC
	"Activer Log système", //_enable_system_log
	"Configuration de l'heure et de la date", //_time_setting
	"Cette section vous permet de configurer l’heure et la date de votre routeur.", //_TIME_DESC
	"Heure d'été", //_daylight_saving_time
	"Paramétrages NTP", //_ntp_settings
	"Serveur NTP", //_ntp_server
	"Synchronisation NTP", //_ntp_sync
	"Réglages de la Date et de l'Heure", //_date_time_settings
	"Cette section vous permet de sauvegarder (exporter) ou de restaurer (importer) la configuration de votre routeur. Cette page vous permet également de restaurer les paramètres par défaut de votre routeur ou de le redémarrer.", //_SETTINGS_MANAGER_DESC
	"Exporter", //_export
	"Paramétrages d'emplacement de fichier", //_settings_file_location
	"Importer", //_import
	"MICROPROGRAMME", //_upgrade_firmw
	"Vous pouvez rechercher sur le site de TRENDnet afin de trouver un firmware plus récent pour votre périphérique. Le téléchargement d’un firmware plus récent peut résoudre les problèmes ou améliorer le fonctionnement de votre périphérique. Il est important de vérifier les notes de publication téléchargées avec le firmware afin de savoir si un problème que vous avez rencontré est résolu ou peut être résolu ou s’il est possible de disposer de fonctions améliorées que vous désireriez ajouter avant de télécharger la nouvelle version d’un firmware. Après avoir téléchargé le fichier, copiez-le sur votre disque dur local. Cliquez sur le bouton “Naviguer” ou “Choisir fichier” afin de vous rendre à l’endroit où se trouve le fichier du firmware copié. Clique sur Appliquer pour télécharger le firmware sur votre périphérique.", //_FIRMW_DESC
	"Remarque importante : N’interrompez pas le processus de téléchargement du firmware car cela peut endommager votre périphérique. Veuillez attendre que le téléchargement du firmware soit entièrement terminé et que le périphérique ait correctement redémarré.", //_FIRMW_DESC_sub
	"Emplacement:", //_location
	"Appliquer", //_apply
	"Gestion système", //_system_management
	"You may configure administrator account and password.", //_SYS_MANGER_DESC
	"Max : %s caractères", //_max_length_characters
	"Paramètres d'URL de périphérique", //_device_url_settings
	"URL du périphérique", //_device_url
	"Paramètres du nom de périphérique", //_device_name_settings
	"Paramètres DDNS", //_ddns_settings
	"Gestion distante", //_remote_management
	"Contrôle distant (via Internet)", //_remote_control_via_wan
	"Port distant", //_remote_port
	"Réinitialiser", //_reset
	"Si vous n'êtes pas au courant de ces réglages de réseau avançés, veuillez lire la section d'aide avant d'essayer de modifier ces réglages.", //_ADV_NETWRK_DESC
	"Réponse de ping WAN", //_wan_ping_respond
	"Règle calendrier", //_schedule_rules
	"Define schedule rules for various firewall features.", //_SCHEDULE_DESC
	"AJOUTER UNE RÈGLE DE CALENDRIER", //_add_sche_rule
	"Toute la journée - 24 h", //_tsc_allday_24hr
	"Liste des règles de calendrier", //_schedule_rule_list
	"Horodatage", //_time_stamp
	"24 heures", //_24hr
	"5GHz 802.11a/n/ac", //m_bwl_Mode5_4
	"Routage entre zones", //_routing_bet_zone
	"Clone MAC", //_mac_clone
	"Clone d'adresse MAC", //_mac_addr_clone
	"Paramétrage de serveur DNS", //_dns_server_setting
	"Configuration du  Dhcp", //_dhcp_setting
	"You may choose different connection type suitable for your environment. Besides, you may also configure parameters according to the selected connection type.", //_DHCP_DESC
	"Paramétrages de réseau étendu (WAN)", //_wan_setting_l
	"(octets) par défaut =%s octets", //_mtu_default_byte
	"Paramétrage IP d'interface WAN", //_wan_if_ip_setting
	"Mode de fonctionnement", //_opeartion_mode
	"Maintenir actif", //_keep_alive
	"Mode de maintien actif: période de renumérotation", //_keep_alive_mode_redial
	"Mode Sur demande", //_on_demand_mode_idle_time
	"minutes", //_mintues_lower
	"Paramétrage L2TP", //_l2tp_setting
	"Paramétrage PPTP", //_pptp_setting
	"dynamique", //_dynamic
	"Paramétrages Réseau Local (LAN)", //_lan_setting_l
	"Cette section vous permet de modifier les paramètres de l’adresse IP du routeur. Normalement, les paramètres de l’adresse IP du routeur ne doivent pas être modifiés. En outre, cette page vous permet de configurer les paramètres du serveur DHCP du routeur ou les réservations DHCP qui adressent automatiquement des adresses IP à vos périphériques filaires et sans fil se connectant à votre routeur.", //_LAN_DESC
	"Configuration du serveur Dhcp", //_dhcp_server_setting
	"IP de début DHCP", //_dhcp_start_ip
	"IP de fin DHCP", //_dhcp_end_ip
	"Autres paramètres", //_other_setting
	"Arbre couvrant (Spanning Tree) 802.1d", //_8021d_spanning_tree
	"LLTD", //_lltd
	"Proxy IGMP", //_igmp_proxy
	"Relais PPPOE", //_pppoe_relay
	"Proxy DNS", //_dns_proxy
	"Ajouter une réservation DHCP", //_add_dhcp_reservation
	"Copier l'adresse MAC de votre PC", //_copy_pc_mac
	"Copiez", //_copy
	"Groupe Ready de Réservation DHCP", //_dhcp_reservation_ready_group
	"Modifier réservation DHCP", //_edit_dhcp_reservation
	"Tout supprimer", //_delete_all
	"Supprimer les éléments sélectionnés", //_delete_selected
	"Début PIN", //_config_via_pin
	"Démarrer Push Button", //_config_via_pbc
	"Configuration de la passerelle de niveau application (ALG)", //_alg_config_l
	"ALG configuration allows users to disable some application service.", //_ALG_DESC
	"Description", //_description
	"Courriel en cours de réception", //_email_receiving
	"Protocole POP3 – Version 3", //_pop3_l
	"Protocole SMTP", //_smtp_l
	"Streaming Média", //_streaming_media
	"Protocole de Transport en temps réel (RTP)", //_rtp_l
	"Protocole de streaming en temps réel (RTSP)", //_rtsp_1
	"Protocole de serveur de média Microsoft (WMP/MMS)", //_mms_l
	"Streaming Média-VoIP", //_streaming_media_voip
	"protocole d'ouverture de session (SIP)", //_session_init_protocol_l
	"NetMeeting (H.323)", //_h323_l
	"Transfert de fichier", //_file_transfer
	"Protocle de transfert de fichier (FTP)", //_ftp_l
	"Protocole de transfers de fichier trivial (TFTP)", //_tftp_l
	"Contrôle distant", //_remote_control
	"Telnet", //_telnet
	"Messagerie instantanée", //_instant_messaging
	"MSN Messenger", //_msn_messenger
	"IPSec VPN", //_ipsec
	"Sauvegarder statut", //_save_status
	"Paramètres DMZ", //_dmz_settings
	"You may setup a De-militarized Zone(DMZ) to separate internal network and Internet.", //_DMZ_DESC
	"Access Control allows users to define the traffic type not-permitted to WAN port service.", //_AC_DESC
	"Add Port Range and Service Block Rule", //_add_port_block_rule
	"Politique activée", //_policy_enable
	"Nom de stratégie", //_policy_name
	"Client IP Address", //_client_ip_addr
	"Définir règle", //_rule_define
	"Service spécial", //_special_service
	"Défini par l'utilisateur", //_user_define
	"Ports TCP", //_tcp_ports
	"Ex. : 21 ou 300-500", //_ex_21_or_3_500
	"Ports UDP", //_udp_ports
	"Service", //_service
	"Modifier les services Bloquer l'article", //_edit_port_block_rule
	"Liste des règles de blocage de service", //_port_block_rule
	"Ajouter toutes les règles de blocage de service", //_add_ip_block_rule
	"Modifier les services Bloquer l'article", //_edit_ip_block_rule
	"Toute la liste des règles de blocage de service", //_ip_block_rule_list
	"Ajouter Règle de filtre d'URL Web", //_add_weburl_rule
	"Modifier la règle de filtrage URL Web  action de filtrage", //_edit_weburl_rule
	"Liste des filtres sur les URL", //_weburl_rule_list
	"Courriel en cours d'expédition", //_email_sending
	"Transfert de fichier", //_file_transfer_l
	"Service Telnet", //_telnet_service
	"Requête DNS", //_dns_query
	"Protocole TCP", //_tcp_protocol
	"Protocole UDP", //_udp_protocol
	"WWW", //_www
	"Erreur de format d'adresse IP.", //_err_ip_addr_format
	"Erreur de masque IP", //_err_ip_mask
	"Indiquer l’erreur de format", //_err_input_format
	"Erreur dans l’adresse IP", //_err_ip_addr
	"Paramètres de routage", //_static_routing_settings
	"Cette section vous permet de définir manuellement les routes statiques et d’activer ou de désactiver l’utilisation du routage dynamique de votre routeur.", //_ROUTING_DESC
	"Ajouter Route statique", //_add_static_route
	"Adresse IP cible", //_dest_ip_addr
	"Masque de sous-réseau d'IP de destination", //_dest_ip_mask
	"Port physique", //_physical_port
	"Activer RIP", //_enable_rip
	"Le mode RIP", //_rip_mode
	"Liste des routes statiques", //_static_route_list
	"En cours de traitement ! Veuillez patienter...", //_processing_plz_wait
	"Redémarrage en cours, Veuillez patienter ……", //_rebooting_plz_wait
	"Adresse IP de la passerelle L2TP", //_L2TPgw
	"Réessayer", //_retry
	"Ignorer", //_skip
	"Le routeur est en train de contrôler la connectivité Internet, veuillez patienter.", //_chk_wanconn_msg_00
	"Assistant de configuration", //_tnw_01
	"Cet assistant vous guidera via un processus pas à pas et vous permettra de configurer votre connexion Internet.", //_tnw_02
	"Vérification de la connexion Internet", //_tnw_03
	"Information", //_tnw_04
	"SSID", //_ssid
	"Type d`authentification", //_auth_type
	"Terminer", //_finish
	"Configurez votre connexion Internet", //_tnw_05
	"Obtention automatique de l’IP (client DHCP)", //_tnw_dhcp
	"Adresse IP fixe", //_tnw_static
	"PPPoE", //_tnw_pppoe
	"PPTP", //_tnw_pptp
	"L2TP", //_tnw_l2tp
	"Configurer l'adresse IP dynamique", //_tnw_06
	"MAC", //_mac
	"Cloner l'adresse MAC", //_tnw_clone
	"Configurer l'adresse IP fixe", //_tnw_07
	"Paramètres de l’adresse IP", //_wan_ipaddr
	"Masque de sous-réseau WAN", //_wan_submask
	"adresse IP de passerelle WAN", //_wan_gwaddr
	"Adresse 1 Serveur DNS", //_dns_1
	"Adresse 2 Serveur DNS", //_dns_2
	"%s Assistant de configuration: PPPoE", //_tnw_08
	"%s Assistant de configuration: PPTP", //_tnw_09
	"Mon IP", //_my_ip
	"Serveur IP", //_server_ip
	"Compte PPTP", //_pptp_account
	"mot de passe PPTP", //_pptp_password
	"Retaper mot de passe  PPTP", //_pptp_password_re
	"%s Assistant de configuration: L2TP", //_tnw_10
	"Compte L2TP", //_l2tp_account
	"Mot de passe L2TP", //_l2tp_password
	"Retaper mot de passe  L2TP", //_l2tp_password_re
	"Les paramètres sont en cours d'enregistrement et d'application.", //_tnw_11
	"Veuillez patienter", //_tnw_12
	"secondes.", //_tnw_13
	"Veuillez vérifier la connexion câble entre le port Internet et le modem.", //_tnw_14
	"Imprimer", //_print
	"Le mot de passe ne peut pas contenir d'espaces. Réessayez !", //_TAG00840
	"Autoconfiguration (SLAAC/DHCPv6)", //IPV6_TEXT171
	"Autoconfiguration (SLAAC/DHCPv6) + 6RD", //IPV6_TEXT172
	"Partagé", //_wps_shared
	"Ouvert", //_wps_open
	"Le nom de règle '%s' est en double.", //_webfilterrule_dup
	"WPS 2.4GHz", //_wps_24g
	"WPS 5GHz", //_wps_5g
	"Nom (SSID)", //_name_ssid
	"Enregistrement de la garantie produit", //_warranty
	"USB", //_usb
	"Serveur de partage de fichiers", //_samba_server
	"serveur FTP", //_ftp_server
	"Serveur d'impression", //_print_server
	"Périphériques connectés", //_connected_devices
	"Réseau invités", //_guest_network
	"Cette section vous permet de paramétrer et de configurer les paramètres du réseau sans fil Invités .", //_guest_text1
	"Pont réseau:", //_network_bridge
	"Accès à Internet uniquement", //_inet_access_only
	"(Aucune sécurité)", //_security_no
	"(Faible sécurité)", //_security_low
	"(Sécurité moyenne)", //_security_middle
	"(Sécurité haute)", //_security_high
	"Contrôle Parental", //_parental_control
	"Connexion à Internet", //_has_inet_connection
	"Internet déconnecté", //_no_inet_connection
	"Réseau invités activé", //_guest_network_enabled
	"Réseau invités désactivé", //_guest_network_disabled
	"Périphériques USB connectés", //_usb_connected
	"Aucun périphérique USB connecté", //_no_usb_connected
	"Accès Ménage", //_household_access
	"Confirmez les paramètres", //_confirm_settings
	"Vérifier la connexion", //_check_connection
	"Adresse", //_address
	"Liste des règles d’accès", //_ha_rule_list
	"Ajouter une règle d’accès", //_add_ha_rule
	"Modifier la règle de l'accès des ménages", //_edit_ha_rule
	"Impossible de passer du mode 802.11 au mode 802.11n seulement tant que le SSID est configuré avec une sécurité WEP/WPA-TKIP.", //_wlan_11n_not_support_wep_wpa_tkip
	"Programmation radio", //_lb_radio_on_sche
	"Vous ne pouvez plus ajouter de règles, car le tableau est plein.", //_rule_full
	"Vous ne pouvez pas activer WDS car la sécurité courante n'est pas prise en charge. ", //_wds_cant_enble
	"Les clients doivent libérer et renouveler l’adresse IP ou le DUT doit être redémarré.", //_LAN_CHK_REBOOT_MSG
	"Veuillez spécifier l'URL de périphérique.", //_specify_url
	"L’adresse IP '%s' est déjà utilisée.", //_ipaddr_used
	"L’adresse MAC '%s' est déjà utilisée.", //_macaddr_used
	"Ne pas supprimer de règle", //_lan_dr
	"Veuillez sélectionner au moins une route à supprimer!", //_adv_rtd
	"A-MPDU", //_lb_a_mpdu
	"Routeur sans fil dual band AC750", //PRODUCT_DESC_810
	"AC750 Wireless Travel Router", //PRODUCT_DESC_817
	"L’adresse IP '%s' est déjà utilisée.", //_ipaddr_used
	"L’adresse MAC '%s' est déjà utilisée.", //_macaddr_used
	"Internet non établi", //no_wan_up
	"Mode PA", //dev_mode_ap
	"Mode répétiteur", //dev_mode_repeater
	"Mode WISP", //dev_mode_wisp
	"Client PA", //ap_client
	"SSID étendu", //extend_ssid
	"Liste des clients WiFi", //wlan_client_list
	"Mode point d’accès; sélectionnez ce mode pour créer les deux réseaux WiFi 2,4 GHz (802.11b/g/n) et 5 GHz (802.11a/n/ac). Pour ajouter un réseau WiFi à votre réseau actuel, connectez un câble réseau au port LAN/Ethernet du %s et à votre routeur/réseau.", //desc_ap
	"Sélectionnez ce mode pour étendre un réseau WiFi existant en utilisant le %s.", //desc_repeater
	"Fournisseur d’accès Intenrnet WiFi; sélectionnez ce mode lors de la connexion à un réseau d’un fournisseur d’accès Intenret WiFi (p. ex. aux services WiFi d’un hôtel) pour un accès à Intenret et créez un réseau interne pour vos périphériques client en utilisant le %s.", //desc_wisp
	"Sélectionnez un site auquel vous désirez vous connecter et cliquez ensuite sur Next (Suivant).", //wiz_select_site
	"Cliquez sur Refresh (Actualiser) pour mettre à jour la liste des sites disponibles.", //wiz_refresh_site
	"Pas de site disponible.", //wiz_no_result
	"Veuillez sélectionner un SSID ou cliquez sur Manual.", //wiz_no_selected
	"Désirez-vous quitter l’assistant ?", //wiz_quit
	"Plage %d - %d", //custom_range
	"Paramètres Internet", //_internet_setting
	"Configurez IPv6 statique", //desc_static_ipv6
	"Paquets %s", //_s_packet
	"Lock WPS", //_wps_lock
	"Passthrough PPTP", //pptp_passthrough
	"Passthrough L2TP", //l2tp_passthrough
	"Configuración de opciones de red de área local (LAN) y DHCP", //desc_ap_lan
	"Adquirir el protocolo IP", //attain_ip
	"Estado del dispositivo", //dev_stat
	"La sección de configuración de programación se utiliza para administrar las normas de horarios para la red wireless.", //desc_ap_sch
	"" //MAX
);
var _Advanced_01=0;
var _Advanced_03=1;
var _Advanced_04=2;
var bwn_ict_dns=3;
var bwn_msg_Modes_dns=4;
var aa_EAC=5;
var new_bwn_mici_usb=6;
var _tkip_11n=7;
var bln_title_guest_use_shareport=8;
var IPV6_TEXT3=9;
var bwl_Mode_10=10;
var IPV6_TEXT148=11;
var _regenerate=12;
var TEXT048=13;
var te_EnEmN=14;
var usb3g_titile=15;
var usb3g_apn_name=16;
var usb3g_dial_num=17;
var usb3g_reconnect_mode=18;
var usb3g_max_idle_time=19;
var usb_device=20;
var usb3g_manual=21;
var usb3g_stat_titile=22;
var bln_title_usb=23;
var usb_wcn=24;
var bwn_intro_usb=25;
var usb_network=26;
var usb_3g=27;
var wwan_dial_num=28;
var bwn_wwanICT=29;
var help862=30;
var wwan_auth_label=31;
var wwan_auth_auto=32;
var IPPPPPAP_AUTH_ISSUE=33;
var wwan_auth_chap=34;
var wwan_auth_mschap=35;
var usb_network_help=36;
var usb_3g_help=37;
var usb_3g_help_support_help=38;
var usb_wcn_help=39;
var bwn_mici_usb=40;
var _info_netowrk=41;
var anet_multicast_enable=42;
var bwn_usb_time=43;
var bwn_bytes_usb=44;
var _wps_albert_1=45;
var _wps_albert_2=46;
var usb_config2=47;
var ac_alert_choose_dev=48;
var usb_config3=49;
var usb_config4=50;
var usb_config5=51;
var usb_config6=52;
var bwn_msg_usb=53;
var _country=54;
var _select_country=55;
var _select_ISP=56;
var country_1=57;
var country_2=58;
var country_3=59;
var country_4=60;
var country_5=61;
var country_6=62;
var country_7=63;
var _aa_bsecure_personals=64;
var country_9=65;
var country_10=66;
var country_11=67;
var country_12=68;
var country_13=69;
var country_14=70;
var country_15=71;
var S500=72;
var S496=73;
var sto_http_2=74;
var logs_LW39b_email=75;
var LV3=76;
var GW_WIRELESS_DEVICE_LINK_UP=77;
var LT248=78;
var GW_PPPOE_EVENT_DISCOVERY_ATTEMPT=79;
var GW_WLAN_RADIO_1_NAME=80;
var te_SMTPSv_Port=81;
var GW_WLAN_CHANGING_PHY_MODE_TO_11NG_ONLY_INVALID=82;
var S558=83;
var KRL8=84;
var LY30=85;
var GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=86;
var GW_WIFISC_DISABLED_AUTOMATICALLY=87;
var _off=88;
var GW_WLAN_RADIO_0_NAME=89;
var GW_PPPOE_EVENT_DISCOVERY_REQUEST_ERROR=90;
var GW_WAN_PPPOE_SESSION_NAME_CONFLICT=91;
var S525=92;
var YM174=93;
var KR136=94;
var GW_PPPOE_EVENT_DISCONNECT=95;
var af_EFT_0=96;
var LY34=97;
var GW_WIRELESS_SHUT_DOWN=98;
var GW_WIRELESS_RESTART=99;
var S528=100;
var GW_PORT_FORWARD_TCP_PACKET_ALLOC_FAILURE=101;
var guestzone_Intro_1=102;
var GW_NAT_VIRTUAL_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=103;
var ta_ERM=104;
var te_SMTPSv_Port_alert=105;
var GW_WIRELESS_DEVICE_START_FAILED=106;
var GW_PORT_FORWARD_UDP_PACKET_ALLOC_FAILURE=107;
var GW_WIRELESS_DEVICE_DISCONNECT_ALL=108;
var GW_PPPOE_EVENT_OFFER_REQUEST=109;
var GW_ROUTES_ROUTERS_IP_ADDRESS_INVALID=110;
var GW_PORT_TRIGGER_UDP_PACKET_ALLOC_FAILURE=111;
var GW_WLAN_SETTING_SSID_SECURITY_TO_WEP_INVALID=112;
var GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT=113;
var GW_WLAN_STATION_TIMEOUT=114;
var GW_NAT_VIRTUAL_SERVER_IP_ADDRESS_CAN_NOT_MATCH_ROUTER=115;
var GW_NAT_VIRTUAL_SERVER_PROTO_CONFLICT_INVALID=116;
var LY28=117;
var GW_PPPOE_EVENT_CONNECT=118;
var GW_NAT_TRIGGER_PORT=119;
var tc_opmode=120;
var wwz_auto_assign_key3=121;
var LY292=122;
var LY293=123;
var bws_msg_WEP_4=124;
var GW_ROUTES_ON_LINK_DATALINK_CHECK_INVALID=125;
var wwa_dnsset=126;
var wireless_gu=127;
var add_gu_wps=128;
var wwl_band=129;
var _band=130;
var wwa_5G_nname=131;
var _guestzone=132;
var guestzone_title_1=133;
var _graph_auth=134;
var guestzone_inclw=135;
var guest=136;
var lower_wnt=137;
var equal_wnt=138;
var _lowest=139;
var ssid_lst=140;
var mult_ssid=141;
var add_ed_ssid=142;
var help75a=143;
var wpin_filter=144;
var tps_raw1=145;
var up_tz_52=146;
var _r_alert_new1=147;
var te_EmSt=148;
var IPNAT_BLOCKED_EGRESS=149;
var bws_WSMode=150;
var anet_wan_ping_1=151;
var help65=152;
var ta_upnp=153;
var bwl_TxR=154;
var GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED=155;
var tsc_pingt_msg106=156;
var tsc_AllDay=157;
var gw_gm_53=158;
var GW_WAN_RATE_ESTIMATOR_RESOURCE_ERROR=159;
var DHCP_CLIENT_LOST_LEASE=160;
var _aa_wiz_s3_msg=161;
var bwsAT_=162;
var hhtt_intro=163;
var gw_gm_20=164;
var help388=165;
var tt_StDT=166;
var psOffline=167;
var _status=168;
var up_ae_wic_3=169;
var sl_WtV=170;
var WIFISC_AP_PROXY_PROCESS_START=171;
var wprn_nopr2=172;
var help352=173;
var wwz_wwl_wnn=174;
var _ipaddr=175;
var GW_WLS_SCHEDULE_START=176;
var help820=177;
var help326=178;
var up_tz_54=179;
var help773=180;
var am_MACFILT=181;
var aa_alert_7_new1=182;
var help302=183;
var aa_intro=184;
var help348=185;
var haf_dmz_30=186;
var sl_Infrml=187;
var _wireless=188;
var bws_RIPA=189;
var KR108=190;
var help83=191;
var hhase_intro=192;
var RUNTIME_CONFIG_MAGIC_NUM_ERROR=193;
var _Sat=194;
var awf_title_WSFR=195;
var help18_a=196;
var dlink_wf_op_1=197;
var gw_gm_18=198;
var gw_gm_7=199;
var USB_LOG_STORAGE_TYPE=200;
var help346=201;
var up_rb_5=202;
var _WEP=203;
var IPMSCHAP_AUTH_FAIL_AND_NO_RETRY=204;
var gw_gm_82=205;
var bw_sap=206;
var bwn_msg_SWM=207;
var li_alert_2=208;
var help120=209;
var IGMP_HOST_LOW_RESOURCES=210;
var wwl_s4_intro_z3=211;
var help78=212;
var help339=213;
var IPv6_Simple_Security_enable=214;
var help51=215;
var GW_WAN_LAN_ADDRESS_CONFLICT_PPP=216;
var ss_Errors=217;
var help899=218;
var li_alert_4=219;
var haf_dmz_40=220;
var hhts_edit=221;
var wwl_wnn=222;
var WEB_FILTER_LOG_URL_ACCESSED_MAC=223;
var aw_WE=224;
var help201a=225;
var _bsecure_activate_trial=226;
var help896=227;
var help815=228;
var _netmask=229;
var _please_wait=230;
var help12=231;
var am_intro_1=232;
var IPPPPLCP_SET_LOCAL_AUTH=233;
var gw_gm_11=234;
var _dontsavesettings=235;
var wwl_s4_intro_za1=236;
var _308=237;
var aa_AT_1=238;
var IPL2TP_TUNNEL_ABORTING=239;
var help330=240;
var wwa_msg_l2tp=241;
var tt_time_5=242;
var help6=243;
var _time=244;
var at_xDSL=245;
var wprn_intro4=246;
var help296=247;
var _LAN=248;
var gw_gm_60=249;
var _aa_wiz_s4_msg=250;
var wwl_64bits=251;
var IPFAT_DISK_FULL=252;
var help341=253;
var aa_sched_conf_2=254;
var IPL2TP_SESSION_CONNECTING=255;
var NET_RTC_SYNCHRONIZATION_FAILED=256;
var tf_AutoCh=257;
var wprn_iderr2=258;
var help319=259;
var af_intro_2=260;
var help800=261;
var sd_title_Dev_Info=262;
var GW_INET_ACCESS_DROP_PORT_FILTER=263;
var _connow=264;
var IPSIPALG_REJECTED_PACKET=265;
var IPNAT_TCP_UNABLE_TO_MODIFY_OPTIONS=266;
var tt_SelNTPSrv=267;
var help812=268;
var _user=269;
var up_tz_59=270;
var SPECIAL_APP=271;
var wwl_NONE=272;
var GW_WAN_SERVICES_STARTED=273;
var fb_FbWbAc=274;
var help275=275;
var wprn_nopr=276;
var tt_TimeZ=277;
var wprn_tt=278;
var help841=279;
var aa_sched_new=280;
var tt_time_14=281;
var gw_vs_1=282;
var tsl_SLSt=283;
var IPH323ALG_REJECTED_PACKET=284;
var aa_wiz_s1_msg4=285;
var help336=286;
var ta_sn=287;
var help780=288;
var _interface=289;
var WEB_FILTER_LOG_URL_BLOCKED=290;
var vs_http_port=291;
var haf_intro_1=292;
var up_tz_07=293;
var aw_intro=294;
var wwa_gw=295;
var _sentinel_serv=296;
var wwa_msg_sipa=297;
var IPNAT_TCP_UNABLE_TO_HANDLE_HEADER=298;
var hhav_ip=299;
var haf_dmz_50=300;
var GW_INET_ACCESS_POLICY_END_MAC=301;
var tsc_intro_Sch=302;
var GW_WLAN_ACCESS_DENIED=303;
var _262=304;
var help79=305;
var GW_BIGPOND_CONFIG=306;
var aw_TP_0=307;
var _sdi_s3=308;
var tsc_pingr=309;
var tsc_pingt_v6=310;
var _WPApersonal=311;
var _email=312;
var PPPOE_EVENT_DISCOVERY_REQUEST=313;
var _firewall=314;
var wwa_wanmode_sipa=315;
var _syscheck=316;
var help784=317;
var UNKNOWN=318;
var help_upnp_1=319;
var gw_gm_61=320;
var _optional=321;
var help181=322;
var help569=323;
var anet_intro=324;
var _authword=325;
var IPNAT_TCP_BLOCKED_EGRESS_NOT_SYN=326;
var ta_GWN=327;
var wprn_tt3=328;
var help293=329;
var help265_2=330;
var IPNAT_UNABLE_TO_CREATE_CONNECTION=331;
var help270=332;
var aw_title_2=333;
var _firewalls=334;
var LW67=335;
var PPPOE_EVENT_UP=336;
var _protocol=337;
var help372=338;
var up_tz_32=339;
var at_kbps=340;
var at_Cable=341;
var anet_wp_1=342;
var help17=343;
var ta_intro_Adm2=344;
var tool_admin_check=345;
var IPPPPIPCP_PPP_LINK_UP=346;
var _stop=347;
var GW_SYSLOG_STATUS=348;
var bd_title_DHCPSSt=349;
var help827=350;
var tf_FWCheckInf=351;
var tf_FWInf=352;
var hhai_ipr=353;
var hhaw_1=354;
var help34=355;
var _network_usb_auto=356;
var help309=357;
var aa_alert_15=358;
var _savesettings=359;
var help193=360;
var help14_p=361;
var gw_gm_32=362;
var IPNAT_TCP_BLOCKED_INGRESS_SYN=363;
var anet_msg_wan_ping=364;
var ai_intro_2=365;
var help285=366;
var ss_LANStats=367;
var ta_alert_4=368;
var _clone=369;
var gw_gm_14=370;
var PPTP_ALG_GRE_UNABLE_TO_HANDLE_HEADER=371;
var _aa_block_some=372;
var help819_3=373;
var tt_time_24=374;
var help873=375;
var ss_Collisions=376;
var help863=377;
var help397=378;
var av_title_VSL=379;
var help636=380;
var tf_ENFA=381;
var help13=382;
var wwa_title_s3=383;
var ES_wwa_title_s1=384;
var GW_WAN_RATE_ESTIMATOR_CONVERGENCE_ERROR=385;
var wwa_wanmode_bigpond=386;
var help254=387;
var haf_dmz_70=388;
var GW_SCHED_ATTACH_FAILED=389;
var _badssid=390;
var RUNTIME_CONFIG_STORING_CONFIG_IN_NVRAM=391;
var FW_UPDATE_AVAILABLE=392;
var help891=393;
var help777=394;
var help393=395;
var bwn_ict=396;
var tt_Jun=397;
var IPL2TP_TUNNEL_CONNECTED=398;
var gw_gm_9=399;
var gw_gm_2=400;
var wwl_wl_wiz=401;
var network_dhcp_range=402;
var wprn_intro6=403;
var GW_BIGPOND_FAIL=404;
var af_EFT_1=405;
var _use_unicasting=406;
var _networkstate=407;
var tt_Year=408;
var IPASYNCFILEUSB_MOUNT_FAILED=409;
var af_UEFT=410;
var help356=411;
var help381=412;
var _inboundfilter=413;
var _aa_apply_port_filter=414;
var aa_FPR_c7=415;
var gw_gm_27=416;
var BIGPOND_NOT_PROPERLY_CFGD=417;
var help335=418;
var up_tz_58=419;
var _never=420;
var help801=421;
var tsc_pingt_msg105=422;
var li_WJS=423;
var te_ToEm=424;
var tt_time_1=425;
var help787=426;
var IPV6_TEXT65_v6=427;
var GW_EMAIL_SUBJ=428;
var IPPORTTRIGGERALG_UDP_PACKET_ALLOC_FAILURE=429;
var bi_wiz=430;
var _Out=431;
var hhpt_app=432;
var _dhcpconn=433;
var bln_title_Rtrset=434;
var _ps=435;
var _1044=436;
var wwl_text_best=437;
var wwa_pptp_svraddr=438;
var GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED=439;
var _LANComputers=440;
var hhte_intro=441;
var as_NM=442;
var wwa_setupwiz=443;
var help264=444;
var bw_WDUU_note=445;
var as_MMS=446;
var _srvname=447;
var help93=448;
var tt_Minute=449;
var sa_State=450;
var aw_dE=451;
var tsc_pingt_h=452;
var tsc_pingt_h_v6=453;
var ss_WStats=454;
var IPMSCHAP_AUTH_SEND_CHALLENGE=455;
var help889=456;
var as_H323=457;
var tool_admin_pfname=458;
var IPNAT_SESSION_ALREADY_EXISTS=459;
var wwa_title_set_bigpond=460;
var up_tz_16=461;
var GW_BIGPOND_STATUS=462;
var wwa_msg_set_bigpond=463;
var ai_alert_5=464;
var help848=465;
var gw_gm_41=466;
var _aa_pol_wiz=467;
var IP_FILTERS=468;
var gw_gm_50=469;
var wwa_intro_s3=470;
var IPSEC_ALG_ESP_ESTABLISH_ALREADY_PENDING=471;
var help59=472;
var wps_reboot_need=473;
var at_DF=474;
var help265_7=475;
var tt_alert_dstchkmonth=476;
var up_tz_23=477;
var _advanced=478;
var STATIC_IP_ADDRESS=479;
var wwl_title_s3=480;
var hhsw_intro=481;
var ish_menu=482;
var up_tz_33=483;
var GW_FW_NOTIFY_FIRMWARE_ERROR=484;
var _bsecure_more_info=485;
var tf_CFWV=486;
var tt_week_2=487;
var help3=488;
var _creator=489;
var bln_title_DNSRly=490;
var GW_INET_ACCESS_DROP_PORT_FILTER_MAC=491;
var ish_glossary=492;
var wwl_s4_intro_z4=493;
var help118=494;
var gw_gm_66=495;
var help312dr2=496;
var tsc_24hrs=497;
var hhag_10=498;
var help261=499;
var as_TPrt=500;
var help28=501;
var tt_time_12=502;
var ss_reload=503;
var EGRESS=504;
var sps_fp=505;
var gw_gm_57=506;
var wwa_msg_dhcp=507;
var aa_wiz_s1_msg1=508;
var MUST_BE_LOGGED_IN_AS_ADMIN=509;
var up_tz_64=510;
var GW_WLS_SCHEDULE_STOP=511;
var IPWOLALG_REJECTED_PACKET=512;
var WCN_LOG_UPDATE=513;
var help80=514;
var help171=515;
var _Mon=516;
var up_tz_66=517;
var wwl_title_s4_2=518;
var help196=519;
var PPPOE_EVENT_DISCOVERY_REQUEST_ERROR=520;
var li_Log_In=521;
var af_gss=522;
var _defgw=523;
var YM185=524;
var add_wireless_device=525;
var help8=526;
var help258=527;
var PPPOE_EVENT_TERMINATED=528;
var up_rb_1=529;
var help25_b=530;
var sl_saveLog=531;
var sl_intro=532;
var _aa_wiz_s4_help=533;
var GW_WAN_CARRIER_LOST=534;
var bwn_bytes=535;
var help890_1=536;
var help779=537;
var _macaddr=538;
var help823_13=539;
var ta_ELM=540;
var sto_http_4=541;
var anet_multicast_enable_v4=542;
var GW_DYNDNS_UPDATE_NEXT=543;
var help866=544;
var sl_RStat=545;
var gw_gm_78=546;
var help90=547;
var PPTP_EVENT_TUNNEL_DOWN=548;
var bwn_SWM=549;
var IPWEBFILTER_REJECTED_PACKET=550;
var GW_UPGRADE_FAILED=551;
var ag_intro=552;
var ta_intro_Adm=553;
var bwn_L2TPSIPA=554;
var GW_INET_ACCESS_UNRESTRICTED=555;
var up_tz_11=556;
var _disabled=557;
var GW_LOG_EMAIL_ON_LOG_FULL=558;
var tt_time_8=559;
var help43=560;
var ddns_connecting=561;
var _enable=562;
var help272=563;
var tt_Apr=564;
var tt_alert_invlddt=565;
var bwl_MS=566;
var tool_admin_portconflict=567;
var gw_SelVS=568;
var bwn_RM_0=569;
var hhai_edit=570;
var te_FromEm=571;
var wt_p_1=572;
var NET_RTC_REQUEST_TIME=573;
var help48=574;
var N_A=575;
var help279=576;
var tt_week_6=577;
var gw_gm_48=578;
var bwl_VS_1=579;
var help882=580;
var up_tz_41=581;
var RUNTIME_CONFIG_LOADED_CONFIG_FROM_NVRAM=582;
var li_alert_1=583;
var help307=584;
var help273=585;
var help194=586;
var up_rb_4=587;
var NEWER_FW_VERSION=588;
var bwn_PPTPICT=589;
var GW_UPGRADE_SUCCEEDED=590;
var bwl_AS=591;
var help96=592;
var _wchannel=593;
var wwz_manual_key=594;
var ap_intro_cont=595;
var tsl_EnLog=596;
var _L2TP=597;
var bd_DIPAR=598;
var _stats=599;
var wwl_s4_intro_za2=600;
var IPL2TP_SESSION_DOWN=601;
var bwn_DIAICT=602;
var help338=603;
var help859=604;
var _add=605;
var _acccon=606;
var tsc_pingt_msg4=607;
var ddns_disconnect=608;
var _verifypw=609;
var am_intro_2=610;
var _aa_pol_add=611;
var gw_gm_59=612;
var help11=613;
var _system=614;
var help261a=615;
var up_tz_02=616;
var hhtsc_pingt_intro=617;
var help5=618;
var help767s=619;
var gw_gm_45=620;
var wwa_wanmode_pppoe=621;
var GW_ROUTES_GATEWAY_SUBNET_SAME=622;
var haf_dmz_60=623;
var te_intro_Em=624;
var wwl_text_none=625;
var help895=626;
var GW_WAN_RECONNECT_ON_ACTIVE=627;
var aa_Machine=628;
var GW_WLS_SCHEDULE_INIT=629;
var _Wed=630;
var tt_time_20=631;
var aa_FPR_c3=632;
var help68=633;
var help150=634;
var te_Acct=635;
var IPSMTPCLIENT_MSG_SENT=636;
var gw_gm_38=637;
var help384=638;
var tt_time_2=639;
var at_AUS=640;
var hhts_del=641;
var help818=642;
var help886=643;
var _aa_wiz_s2_msg=644;
var help52=645;
var wps_KR46=646;
var wwz_wwl_intro_s3_1=647;
var gw_gm_19=648;
var td_intro_DDNS=649;
var up_tz_53=650;
var help845=651;
var wt_p_3=652;
var up_tz_51=653;
var wprn_s3d=654;
var IPPPPCHAP_AUTH_FAIL=655;
var gw_gm_52=656;
var IPNAT_TCP_BAD_FLAGS=657;
var _name=658;
var help66=659;
var IPNAT_UDP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=660;
var IPFTPALG_REJECTED_PACKET=661;
var fb_p_1=662;
var _contype=663;
var help829=664;
var _specappsr=665;
var help353=666;
var gw_gm_23=667;
var help325=668;
var bwn_RM=669;
var sl_LogOps=670;
var help772=671;
var _aa_method=672;
var sl_LogDet=673;
var help788=674;
var _continue=675;
var help804=676;
var _devinfo=677;
var _yes=678;
var help699=679;
var up_tz_62=680;
var help192=681;
var DHCP_PD_ENABLE=682;
var gw_gm_31=683;
var help271=684;
var help33=685;
var IPNAT_TCP_BLOCKED_INGRESS_BAD_ACK=686;
var htsc_pingt_p=687;
var tf_CKN=688;
var wprn_cps=689;
var up_tz_45=690;
var help84=691;
var GW_FW_NOTIFY_FIRMWARE_AVAIL=692;
var ss_RXPD=693;
var WEB_FILTER_LOG_URL_BLOCKED_MAC=694;
var IPPORTTRIGGERALG_TCP_PACKET_ALLOC_FAILURE=695;
var wwa_note_hostname=696;
var ai_Action=697;
var RUNTIME_CONFIG_RESET_CONFIG_TO_FACTORY_DEFAULTS=698;
var sps_nopr=699;
var gw_hours=700;
var _Fri=701;
var tps_lpd=702;
var tf_FWUg=703;
var anet_wp_0=704;
var gw_gm_4=705;
var help373=706;
var tt_dsoffs=707;
var wwz_auto_assign_key=708;
var gw_gm_15=709;
var wwl_s3_note_1=710;
var hhts_save=711;
var at_Auto=712;
var tsc_pingt_msg100=713;
var IPPPPIPCP_PPP_LINK_DOWN=714;
var aa_AT=715;
var gw_gm_71=716;
var aa_wiz_s1_msg3=717;
var BIGPOND_FAILED=718;
var help898=719;
var bwn_PPTPSIPA=720;
var _routing=721;
var hham_intro=722;
var WIFISC_IR_REGISTRATION_FAIL_3=723;
var ai_intro_1=724;
var wwa_title_s2=725;
var up_tz_69=726;
var IPMSCHAP_AUTH_RESULT=727;
var tss_intro2=728;
var help354=729;
var up_tz_19=730;
var ta_alert_5=731;
var bd_DAB=732;
var _WPAenterprise=733;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL_MAC=734;
var sps_pr=735;
var up_tz_34=736;
var _psk=737;
var _dyndns=738;
var _deny=739;
var IPNAT_TCP_BLOCKED_INGRESS_UNEXP_FLAGS=740;
var help276=741;
var _to=742;
var aa_AT_0=743;
var tt_Dec=744;
var GW_INET_ACCESS_POLICY_START_OTHERS=745;
var up_tz_75=746;
var up_tz_72=747;
var tsc_pingt_msg11=748;
var up_ae_de_1=749;
var help781=750;
var help161_2=751;
var tt_time_19=752;
var am_intro=753;
var help811=754;
var aw_TP_1=755;
var up_tz_24=756;
var IPMSCHAP_AUTH_SENT=757;
var sw_intro=758;
var tps_lpd1=759;
var help257=760;
var _upgintro=761;
var help819_8=762;
var bws_secs=763;
var IPNAT_ICMP_BLOCKED_EGRESS_PACKET=764;
var PORT_FORWARDING=765;
var bwn_Mode_DHCP=766;
var tt_Hour=767;
var help290a=768;
var BIGPOND_LOGGING_OUT=769;
var hhan_mc=770;
var _dns1=771;
var _dns1_v6=772;
var _tools=773;
var _sdi_s2=774;
var sps_usbport=775;
var GW_SCHED_ALLOC_FAILED=776;
var help179=777;
var help262=778;
var _allow=779;
var help798=780;
var DHCP_CLIENT_GOT_LEASE=781;
var anet_wan_phyrate=782;
var _note=783;
var aa_FPR_c6=784;
var help69=785;
var bd_DLT=786;
var ai_title_IFRL=787;
var GW_LAN_INTERFACE_UP=788;
var _logs=789;
var am_FM_2=790;
var GW_LOG_EMAIL_ON_USER_REQUEST=791;
var help21=792;
var bwl_Mode=793;
var bwn_AM=794;
var bwn_BPS=795;
var _ispinfo=796;
var _rate=797;
var up_tz_06=798;
var _success=799;
var _bsecure_parental_serv=800;
var wwa_set_l2tp_title=801;
var help342=802;
var help265=803;
var GW_SMTP_EMAIL_RESOLVED_DNS=804;
var tsc_pingt_msg102=805;
var bws_RSP=806;
var PPPOE_EVENT_CONNECT=807;
var tt_auto=808;
var PPTP_EVENT_LOW_RESOURCES_TO_QUEUE=809;
var IPL2TP_TUNNEL_UNEXPECTED_MESSAGE=810;
var gw_gm_34=811;
var tt_week_5=812;
var wwl_intro_end=813;
var aa_Policy_Table=814;
var tt_TimeConf=815;
var _none=816;
var _aa_wiz_s3_title=817;
var help392=818;
var GW_LOG_EMAIL_ON_SCHEDULE=819;
var wwa_intro_s2=820;
var _PPTPgw=821;
var WEB_FILTER_LOG_URL_ACCESSED=822;
var IPMMSALG_REJECTED_PACKET=823;
var _wirelesst=824;
var int_intro=825;
var GW_LAN_ACCESS_DENIED=826;
var gw_gm_26=827;
var PPTP_ALG_GRE_BLOCKED_INGRESS=828;
var up_tz_30=829;
var gw_gm_49=830;
var _sched=831;
var IPFAT_MOUNT_FAILED=832;
var gw_gm_75=833;
var help883=834;
var ta_alert_6=835;
var GW_INET_ACCESS_POLICY_START_IP=836;
var help841a=837;
var tt_time_23=838;
var ag_title_4=839;
var gw_gm_68=840;
var IPNAT_TCP_BLOCKED_EGRESS_UNEXP_FLAGS=841;
var help260=842;
var help819_4=843;
var help357=844;
var _TCP=845;
var IPMSCHAP_CHALLENGE_RECVD=846;
var anet_msg_upnp=847;
var help776=848;
var KR49=849;
var help32=850;
var gw_gm_3=851;
var help823=852;
var _L2TPip=853;
var _reboot=854;
var wps_p3_1=855;
var wprn_intro5=856;
var _bsecure_security_serv=857;
var tsc_pingt_msg8=858;
var gw_gm_56=859;
var tf_intro_FWU=860;
var up_tz_57=861;
var GW_FW_NOTIFY_RESOLVED_DNS=862;
var af_EFT_2=863;
var up_tz_00=864;
var hhts_intro=865;
var _auth=866;
var IPL2TP_TUNNEL_DISCONNECTING=867;
var NET_RTC_SYNCHRONIZATION_FAILED_AFTER_RETRIES=868;
var sd_FWV=869;
var tsc_SchRuLs=870;
var KR58_ww=871;
var YM98=872;
var ta_SavConf=873;
var wwa_sdns=874;
var help876=875;
var help380=876;
var _netfilt=877;
var gw_days=878;
var li_Login=879;
var WAN_ALREADY_CONNECTED=880;
var bws_WPAM_3=881;
var GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS=882;
var GW_DYNDNS_PASSWORD_INVALID=883;
var tool_admin_vsname=884;
var up_tz_50=885;
var static_PPPoE=886;
var tsc_StrTime=887;
var tsc_pingt_msg104=888;
var wprn_iderr=889;
var wps_KR42=890;
var td_Timeout=891;
var _aa_apply_web_filter=892;
var resetUnconfiged=893;
var GAMING=894;
var tt_time_9=895;
var IPNAT_BLOCKED_INGRESS=896;
var GW_WAN_INTERFACE_UP=897;
var _ripaddr=898;
var sa_TimeOut=899;
var IPNAT_TCP_BLOCKED_EGRESS_BAD_SEQ=900;
var GW_LAN_INTERFACE_DOWN=901;
var help778=902;
var sps_qname=903;
var _seconds=904;
var GW_LOGS_CLEARED=905;
var sl_Warning=906;
var aa_MAC=907;
var wps_KR51=908;
var help274=909;
var aw_sgi_h1=910;
var IPSTACK_REJECTED_SOURCE_ROUTED_PACKET=911;
var wwa_pdns=912;
var help834=913;
var _Sun=914;
var sto_no_dev=915;
var wwz_auto_assign_key2=916;
var bwl_NSS=917;
var up_tz_15=918;
var help880=919;
var IPL2TP_TUNNEL_CONNECTING=920;
var bwn_mici_guest_use_shareport=921;
var NET_RTC_SYNCHRONIZED=922;
var up_tz_10=923;
var _on=924;
var NOT_LOGGED_IN_PLEASE_REFRESH=925;
var IPSEC_ALG_ESP_BLOCKED_INGRESS=926;
var ub_continue=927;
var td_UNK=928;
var IPPMVM_MOUNT_FAILED=929;
var gw_gm_42=930;
var _1066=931;
var tsc_AllWk=932;
var _virtserv=933;
var help2=934;
var help869=935;
var IPPPPLCP_SET_LOCAL_OPTIONS=936;
var ts_rd=937;
var IPSEC_ALG_REJECTED_PACKET=938;
var tsc_pingt_msg3=939;
var GW_WIRELESS_DEVICE_DISCONNECTED=940;
var sd_WRadio=941;
var ALLOWED_WEB_SITES=942;
var gw_sa_1=943;
var _UDP=944;
var help166=945;
var help117=946;
var bwn_L2TPICT=947;
var help795=948;
var _no=949;
var up_tz_63=950;
var tf_FWF1=951;
var up_tz_65=952;
var _priority=953;
var WAN_ALREADY_DISCONNECTED=954;
var up_jt_1=955;
var GW_INET_ACCESS_INITIAL_OTHERS=956;
var hhai_ip=957;
var as_intro_SA=958;
var tsc_pingt_mesg=959;
var up_tz_44=960;
var help27=961;
var as_IPSec=962;
var _admin=963;
var gw_gm_65=964;
var tf_intro_FWChB=965;
var BLOCKED=966;
var wwa_msg_bigpond=967;
var help857=968;
var help819_5=969;
var aw_TP_2=970;
var help385=971;
var _setupdone=972;
var li_intro=973;
var IPSMTPCLIENT_MSG_FAILED=974;
var bwz_note_ConWz=975;
var gw_gm_64=976;
var help268=977;
var NONE_BLOCKED=978;
var tt_May=979;
var bwn_BPICT=980;
var tt_time_15=981;
var _Tue=982;
var ss_clear_stats=983;
var help197=984;
var ai_intro_3=985;
var GW_WAN_DISCONNECT_ON_INACTIVE=986;
var DHCP_CLIENT_RELEASED_LEASE=987;
var wwa_set_sipa_title=988;
var up_tz_71=989;
var hhaf_alg=990;
var help843=991;
var wprn_tt11=992;
var _tstats=993;
var IPPPPLCP_SET_REMOTE_OPTIONS=994;
var tf_COLF=995;
var up_tz_28=996;
var tt_Mar=997;
var _aa_allow_all=998;
var wwa_wanmode_l2tp=999;
var _dmzh=1000;
var GW_TIME_RESOLVED_DNS=1001;
var bws_EAPx=1002;
var aa_PolName=1003;
var wwa_set_sipa_msg=1004;
var _aa_wiz_s2_title=1005;
var PPTP_EVENT_TUNNEL_CONNECTED=1006;
var USB_LOG_STORAGE_NOT_FOUND=1007;
var GW_INIT_DONE=1008;
var carriertype_ct_0=1009;
var help305=1010;
var tps_raw=1011;
var av_PubP=1012;
var help374=1013;
var PPTP_EVENT_TUNNEL_CLEAR_DOWN_REQUEST=1014;
var hhac_delete=1015;
var IPL2TP_SESSION_CLEAR_DOWN_REQUEST=1016;
var aa_ACR_c2=1017;
var help29=1018;
var up_tz_01=1019;
var _app=1020;
var bln_alert_1=1021;
var GW_WAN_RATE_ESTIMATOR_STARTED_ON_WAN=1022;
var sl_FWandSec=1023;
var hhan_ping=1024;
var sa_NAT=1025;
var help828=1026;
var GW_SMTP_EMAIL_FAILED_DNS=1027;
var help810=1028;
var _WOL=1029;
var bwn_RM_1=1030;
var help819_1=1031;
var IPNAT_TCP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1032;
var up_tz_14=1033;
var gw_gm_51=1034;
var td_SvAd=1035;
var hhag_40=1036;
var help169=1037;
var help324=1038;
var htsc_intro=1039;
var KR4_ww=1040;
var help317=1041;
var anet_multicast=1042;
var anet_multicast_v4=1043;
var anet_multicast_v6=1044;
var _aa_wiz_s1_title=1045;
var IPL2TP_SHUTDOWN_COMPLETE=1046;
var help819_7=1047;
var help9=1048;
var help809=1049;
var GW_LAN_CARRIER_DETECTED=1050;
var sl_alert_1=1051;
var as_TPRange_b=1052;
var tt_week_1=1053;
var up_jt_3=1054;
var _clear=1055;
var PPPOE_EVENT_DISCONNECT=1056;
var WIFISC_IR_REGISTRATION_FAIL_2=1057;
var _sdi_staticip=1058;
var hhts_name=1059;
var WAN=1060;
var help824=1061;
var hham_add=1062;
var ss_WANStats=1063;
var GW_WAN_CONNECT_ON_ACTIVE=1064;
var aa_sched_conf_1=1065;
var GW_INET_ACCESS_POLICY_END_OTHERS=1066;
var bd_title_list=1067;
var _aa_logging=1068;
var IPNAT_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1069;
var _username=1070;
var gw_gm_67=1071;
var GW_TIME_FAILED_DNS=1072;
var wprn_tt1=1073;
var tt_time_22=1074;
var help256=1075;
var GW_INET_ACCESS_INITIAL_IP_FAIL=1076;
var _aa_details=1077;
var help36=1078;
var help817=1079;
var bwn_Mode_PPPoE=1080;
var _allowall=1081;
var awf_clearlist=1082;
var sc_intro_rb3=1083;
var help67=1084;
var gw_gm_37=1085;
var aa_AT_2=1086;
var wwa_title_s1=1087;
var tps_drname=1088;
var tt_CopyTime=1089;
var IPL2TP_SEQUENCING_ACTIVATED=1090;
var bd_Reserve=1091;
var IPMSNMESSENGERALG_REJECTED_PACKET=1092;
var help782=1093;
var gw_gm_16=1094;
var IPPORTFORWARDALG_UDP_PACKET_ALLOC_FAILURE=1095;
var wprn_mod=1096;
var help119=1097;
var gw_gm_46=1098;
var am_FM_3=1099;
var sps_lpd1=1100;
var tss_SysSt=1101;
var ta_ResConf=1102;
var WCN_LOG_SAVE=1103;
var as_FPrt=1104;
var help823_11=1105;
var tsc_EvDay=1106;
var ham_del=1107;
var _PPPoE=1108;
var wwa_intro_online1=1109;
var tt_dstend=1110;
var tsc_SchRu=1111;
var GW_AUTH_FAILED=1112;
var _scheds=1113;
var up_tz_56=1114;
var _dns2=1115;
var _dns2_v6=1116;
var tsc_pingt_msg2=1117;
var tps_apc1=1118;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL_WITH_PORT=1119;
var up_tz_48=1120;
var _password_admin=1121;
var bd_intro_=1122;
var help387=1123;
var GW_AUTH_SUCCEEDED=1124;
var IPPPPCHAP_AUTH_SENT=1125;
var _bsecure_parental_blurb=1126;
var _aa_wiz_s1_msg=1127;
var help807=1128;
var up_tz_61=1129;
var _L2TPgw=1130;
var IPMSCHAP_AUTH_FAIL=1131;
var help395=1132;
var help888=1133;
var gw_gm_29=1134;
var help95=1135;
var aw_BP=1136;
var GW_WAN_SERVICES_STOPPED=1137;
var gw_gm_79=1138;
var help850=1139;
var help4=1140;
var up_tz_18=1141;
var help168a=1142;
var PPTP_ALG_REJECTED_PACKET=1143;
var te_SMTPSv=1144;
var gw_gm_84=1145;
var IPL2TP_LOW_RESOURCES=1146;
var hhac_add=1147;
var anet_wp_auto2=1148;
var as_RTSP=1149;
var _authsecmodel=1150;
var bwn_MTU=1151;
var gw_gm_72=1152;
var _WAN=1153;
var anet_multicast_enhanced=1154;
var gw_gm_8=1155;
var _WPA=1156;
var help897=1157;
var IPNAT_TCP_BLOCKED_INGRESS_BAD_SEQ=1158;
var tsc_pingt_msg7=1159;
var tt_Jan=1160;
var gw_gm_5=1161;
var _adwwls=1162;
var tsc_pingt_msg101=1163;
var gw_gm_55=1164;
var anet_wan_ping=1165;
var GW_DHCP_SERVER_WINS_INCOMPATIBILITY_WARNING=1166;
var bws_RMAA=1167;
var aa_wiz_s1_msg2=1168;
var tt_time_7=1169;
var help822a=1170;
var gw_gm_1=1171;
var up_tz_37=1172;
var bws_SM=1173;
var up_tz_68=1174;
var wwl_s4_intro_za3=1175;
var _prev=1176;
var sto_http_1=1177;
var wprn_foo1=1178;
var help355=1179;
var aa_ACR_c6=1180;
var bws_2RSSS=1181;
var help391=1182;
var _PM=1183;
var help174=1184;
var PPPOE_EVENT_DISCOVERY_TIMEOUT=1185;
var WCN_LOG_NO_WSETTING=1186;
var psPaperError=1187;
var anet_wan_ping_2=1188;
var help878=1189;
var LOGGED=1190;
var bwn_RM_2=1191;
var bws_RSSs=1192;
var up_tz_43=1193;
var IPRTSPALG_REJECTED_PACKET=1194;
var GW_SCHEDULES_IN_USE_INVALID_s2=1195;
var help1=1196;
var gw_gm_73=1197;
var hhtsn_intro=1198;
var _ping=1199;
var at_UpSp=1200;
var aa_wiz_s1_msg6=1201;
var _PPTPip=1202;
var help185=1203;
var help799=1204;
var up_tz_17=1205;
var sd_intro=1206;
var tf_Upload=1207;
var tt_Second=1208;
var wps_lost=1209;
var help26=1210;
var up_tz_35=1211;
var bwn_intro_ICS=1212;
var bwn_intro_ICS_3G=1213;
var bwn_intro_ICS_v6=1214;
var help81=1215;
var help833=1216;
var ss_Sent=1217;
var help378=1218;
var gw_gm_80=1219;
var _uploadgood=1220;
var KR38=1221;
var wprn_s3c=1222;
var haf_dmz_20=1223;
var ss_Received=1224;
var help263=1225;
var _bsecure_free_trial=1226;
var tf_FUNO=1227;
var aw_sgi=1228;
var help386=1229;
var help254_ict=1230;
var help254_ict_3G=1231;
var _aa_wiz_s5_msg1=1232;
var td_VPWK=1233;
var gw_gm_33=1234;
var gw_gm_0=1235;
var _macfilt=1236;
var TA16=1237;
var bd_DAB_note=1238;
var help796=1239;
var tf_really_FWF=1240;
var up_tz_05=1241;
var tt_time_16=1242;
var help861=1243;
var help19=1244;
var bwn_DWM=1245;
var _ICMP=1246;
var gw_gm_22=1247;
var help868=1248;
var IPV6_TEXT24=1249;
var tt_time_6=1250;
var _501_12=1251;
var hhac_en=1252;
var int_LWlsWz=1253;
var at_STR=1254;
var tt_Aug=1255;
var am_FM_4=1256;
var aa_wiz_s1_msg5=1257;
var ACCESS_CONTROL=1258;
var GW_DYNDNS_HERROR=1259;
var sps_ports=1260;
var help851=1261;
var hhag_20=1262;
var aa_alert_7=1263;
var af_DI=1264;
var tf_ADS=1265;
var tsc_pingt=1266;
var sl_VLevs=1267;
var wwl_enc=1268;
var help151=1269;
var hhta_pt=1270;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL=1271;
var te_EnAuth=1272;
var WIFISC_AP_PROXY_PROCESS_CLOSE=1273;
var bd_CName=1274;
var help305rt=1275;
var li_alert_3=1276;
var GW_DYNDNS_UPDATE_TO=1277;
var tt_week_4=1278;
var tt_Day=1279;
var GW_LAN_CARRIER_LOST=1280;
var hhai_action=1281;
var help121=1282;
var wwa_msg_set_pppoe=1283;
var IPNAT_ICMP_BLOCKED_INGRESS_PACKET=1284;
var tf_intro_FWU2=1285;
var at_ESE=1286;
var _bsecure_security_blurb=1287;
var bd_DHCP=1288;
var help865=1289;
var wwl_s4_intro_z1=1290;
var help501=1291;
var help280=1292;
var help775=1293;
var _connect=1294;
var GW_BIGPOND_INIT=1295;
var _always=1296;
var _minutes=1297;
var as_IPR_b=1298;
var _aa_bsecure_employment=1299;
var GW_INET_ACCESS_DROP_BAD_PKT=1300;
var gw_gm_12=1301;
var gw_gm_25=1302;
var help846=1303;
var tt_alert_1only=1304;
var gw_gm_76=1305;
var GW_LOGS_VIEWED=1306;
var bws_msg_EAP=1307;
var WIFISC_IR_REGISTRATION_INPROGRESS=1308;
var hhsa_intro=1309;
var help856=1310;
var sa_Dir=1311;
var _bln_title_IGMPMemberships=1312;
var bwn_Mode_L2TP=1313;
var _Thu=1314;
var KR30=1315;
var help184=1316;
var _worksbest=1317;
var _unavailable=1318;
var IPFAT_INCOMPATIBLE_FILESYS=1319;
var IPNAT_TCP_BLOCKED_INGRESS_NOT_SYN=1320;
var up_tz_04=1321;
var sl_ApplySt=1322;
var IPPPPCHAP_CHALLENGE_RECVD=1323;
var help141=1324;
var bd_Revoke=1325;
var wprn_intro3=1326;
var _conuptime=1327;
var wprn_tt4=1328;
var help383=1329;
var tsc_pingt_msg6=1330;
var help821a=1331;
var PPPOE_EVENT_SESSION_OFFER_RECVD=1332;
var gw_gm_30=1333;
var bi_man=1334;
var help60=1335;
var ta_RAP=1336;
var bwn_Mode_BigPond=1337;
var wprn_cps2=1338;
var tt_dststart=1339;
var help164_1=1340;
var IPMSCHAP_AUTH_TIMEOUT=1341;
var sl_emailLog=1342;
var bwl_title_1=1343;
var bwn_BPP=1344;
var sl_reload=1345;
var wwl_title_s1=1346;
var IPDRIVE_MOUNT_FAILED=1347;
var int_ConWz=1348;
var sto_permi=1349;
var help329=1350;
var IPL2TP_TUNNEL_DISCONNECTED=1351;
var help830=1352;
var help294=1353;
var up_tz_21=1354;
var tf_LFWD=1355;
var GW_BIGPOND_SUCCESS=1356;
var _denyall=1357;
var at_AC=1358;
var bwl_VS=1359;
var help327=1360;
var wprn_s2a=1361;
var td_=1362;
var PPTP_EVENT_TUNNEL_WINDOW_TIMEOUT=1363;
var aw_TP=1364;
var bwn_SIAICT=1365;
var help57=1366;
var tt_dsen2=1367;
var _sdi_s5=1368;
var wprn_man=1369;
var tt_time_3=1370;
var up_tz_20=1371;
var RIP_LOW_RESOURCES=1372;
var help266=1373;
var CONNECTED=1374;
var help265_5=1375;
var tsc_Days=1376;
var up_tz_13=1377;
var sd_General=1378;
var hhan_upnp=1379;
var help35=1380;
var help18=1381;
var bwz_psw=1382;
var tt_DaT=1383;
var help190=1384;
var help819_2=1385;
var bwn_MIT=1386;
var hhai_name=1387;
var te__title_EmLog=1388;
var up_tz_47=1389;
var IPSMTPCLIENT_DIALOG_FAILED=1390;
var hham_del=1391;
var wwa_msg_ispnot=1392;
var help808=1393;
var PPTP_EVENT_TUNNEL_ESTABLISH_REQUEST=1394;
var help37=1395;
var WCN_LOG_REBOOT=1396;
var PPTP_EVENT_TUNNEL_CONNECT_FAIL=1397;
var bwl_CWM=1398;
var up_tz_12=1399;
var _cancel=1400;
var IPV6_ULA_TEXT02=1401;
var af_ED=1402;
var up_tz_38=1403;
var aw_DI=1404;
var up_tz_31=1405;
var hhai_delete=1406;
var av_intro_vs=1407;
var av_intro_if=1408;
var GW_WAN_RECONNECT_ALWAYS_ON=1409;
var wwl_WSP=1410;
var INGRESS=1411;
var RESTRICTED=1412;
var bwn_msg_DHCPDesc=1413;
var help390=1414;
var KR58=1415;
var help867=1416;
var GW_WAN_CONNECT_ALWAYS_ON=1417;
var IPRTSPALG_REJECTED_ODD_RTP_PACKET=1418;
var help60f=1419;
var gw_gm_10=1420;
var bwn_min=1421;
var tt_Month=1422;
var tf_CFWD=1423;
var _advnetwork=1424;
var bwn_PPPOEICT=1425;
var help389=1426;
var help844=1427;
var tt_time_17=1428;
var help284=1429;
var GW_WIRELESS_DEVICE_ASSOCIATED=1430;
var bws_2RMAA=1431;
var as_SIP=1432;
var help704=1433;
var WIFISC_IR_REGISTRATION_FAIL_1=1434;
var up_tz_25=1435;
var help55=1436;
var GW_WLAN_LINK_UP=1437;
var bln_EnDNSRelay=1438;
var ai_title_IFR=1439;
var _PPTP=1440;
var _both=1441;
var up_tz_40=1442;
var wprn_tt8=1443;
var tps_dsr=1444;
var at_Prot_1=1445;
var help875=1446;
var awsf_p=1447;
var wwl_s4_intro_z2=1448;
var wwa_set_l2tp_msg=1449;
var up_tz_42=1450;
var _error=1451;
var aa_FPR_c4=1452;
var tt_EnNTP=1453;
var network_dhcp_ip_in_server=1454;
var tf_msg_wired=1455;
var wwa_title_set_pppoe=1456;
var help10=1457;
var bwl_CWM_h2=1458;
var help884=1459;
var rb_Rebooting=1460;
var help819_6=1461;
var tt_time_10=1462;
var help199=1463;
var help259=1464;
var af_algconfig=1465;
var wwa_msg_pptp=1466;
var bws_2RIPA=1467;
var _aa_wiz_s4_title=1468;
var wwa_note_svcn=1469;
var help85=1470;
var GW_INET_ACCESS_DROP_PORT_FILTER_WITH_PORT=1471;
var sd_BPSt=1472;
var up_tz_49=1473;
var gw_gm_62=1474;
var BIGPOND_LOGGED_OUT=1475;
var tf_EmNew=1476;
var GW_INET_ACCESS_INITIAL_MAC_FAIL=1477;
var help303=1478;
var wwa_selectisp_not=1479;
var IPNAT_TCP_BLOCKED_EGRESS_BAD_ACK=1480;
var help94=1481;
var gw_gm_70=1482;
var IPNAT_ICMP_UNABLE_TO_HANDLE_HEADER=1483;
var _FTP=1484;
var _neft=1485;
var ta_A12n=1486;
var GW_BIGPOND_LOGOUT=1487;
var help46=1488;
var hhsl_intro=1489;
var help770=1490;
var wwa_msg_set_pptp=1491;
var GW_FW_NOTIFY_FAILED_DNS=1492;
var gw_gm_40=1493;
var bln_IGMP_title_h=1494;
var hhaw_11d=1495;
var up_jt_2=1496;
var GW_INET_ACCESS_POLICY_START_MAC=1497;
var wwa_msg_pppoe=1498;
var help323=1499;
var ta_intro1=1500;
var tt_week_3=1501;
var _dhcpsrv=1502;
var Dynamic_PPPoE=1503;
var help102=1504;
var GW_DHCP_SERVER_WINS_MODE_INVALID=1505;
var help107=1506;
var gw_gm_69=1507;
var aa_ACR_c5=1508;
var help345=1509;
var hhav_name=1510;
var av_PriP=1511;
var tsc_pingt_msg103=1512;
var help_upnp_2=1513;
var WAN_MODE_INCORRECT=1514;
var wwl_alert_pv5_2_5=1515;
var _aa_wiz_s5_title=1516;
var KR22_ww=1517;
var _aa_wiz_s7_help=1518;
var IPL2TP_SEQUENCING_DEACTIVATED=1519;
var tps_apc=1520;
var up_tz_09=1521;
var tt_Jul=1522;
var GW_WAN_INTERFACE_DOWN=1523;
var WCN_LOG_RESTORE=1524;
var gw_gm_17=1525;
var GW_INET_ACCESS_INITIAL_IP=1526;
var _wizquit=1527;
var tss_intro=1528;
var help318=1529;
var tsl_intro=1530;
var tt_time_4=1531;
var tt_time_21=1532;
var IPL2TP_SESSION_CONNECTED=1533;
var aw_FT=1534;
var _save=1535;
var at_NEst=1536;
var af_EFT_h0=1537;
var _firmware=1538;
var gw_gm_43=1539;
var wps_messgae1_1=1540;
var IPL2TP_SHUTDOWN_STARTED=1541;
var ss_TXPD=1542;
var up_tz_55=1543;
var wwa_intro_online2=1544;
var help50=1545;
var help70=1546;
var help188_wmm=1547;
var bd_title_SDC=1548;
var up_tz_60=1549;
var gw_gm_54=1550;
var help396=1551;
var GW_ADMIN_LOGOUT=1552;
var gw_gm_44=1553;
var ta_EUPNP=1554;
var igmp_e_h=1555;
var help806=1556;
var dlink_wf_op_0=1557;
var help49=1558;
var help367=1559;
var gw_gm_28=1560;
var help337=1561;
var ta_AdmSt=1562;
var _syslog=1563;
var up_tz_08=1564;
var help394=1565;
var _aa_wiz_s7_title=1566;
var tt_intro_Time=1567;
var GW_DYNDNS_SERROR=1568;
var IPV6_TEXT105=1569;
var sps_port=1570;
var help164_2=1571;
var help881=1572;
var _destip=1573;
var help840=1574;
var wwa_l2tp_svra=1575;
var tt_dsdates=1576;
var help34b=1577;
var tt_time_11=1578;
var td_EnDDNS=1579;
var help786=1580;
var bwn_UN=1581;
var aa_alert_8=1582;
var wprn_tt2=1583;
var IPPPPLCP_SET_REMOTE_AUTH=1584;
var IPL2TP_FATAL_TIMEOUT=1585;
var hhaf_ngss=1586;
var bln_title_NetSt=1587;
var av_traftype=1588;
var bwn_Mode_PPTP=1589;
var help140=1590;
var wprn_rppd=1591;
var hhsd_intro=1592;
var IPMSCHAP_AUTH_SUCCESS=1593;
var help63=1594;
var ES_cable_lost_desc=1595;
var ap_intro_sv=1596;
var _L2TPsubnet=1597;
var GW_LOG_EMAIL_BEFORE_REBOOT=1598;
var at_Any=1599;
var help288=1600;
var bws_SM_h1=1601;
var help177=1602;
var up_tz_46=1603;
var rb_wait=1604;
var bwl_NN=1605;
var IPL2TP_SESSION_CONNECT_FAIL=1606;
var gw_gm_21=1607;
var wwl_BEST=1608;
var _support=1609;
var aa_alert_14=1610;
var _cablestate=1611;
var help314=1612;
var wps_LW13=1613;
var sl_Critical=1614;
var sc_intro_sv=1615;
var SYSTEM_LOG_INACTIVE=1616;
var bwn_mici=1617;
var gw_mins=1618;
var help852=1619;
var _In=1620;
var help870=1621;
var gw_gm_74=1622;
var help797=1623;
var gw_gm_39=1624;
var wwl_alert_pv5_3_10=1625;
var help149=1626;
var hhpt_intro=1627;
var GW_WAN_CARRIER_DETECTED=1628;
var bwn_BPU=1629;
var help195=1630;
var help823_1=1631;
var _internetc=1632;
var tsc_pingt_msg5=1633;
var help189a=1634;
var _trigger=1635;
var help783=1636;
var ub_intro_2=1637;
var hhta_pw=1638;
var _aa_wiz_s8_title=1639;
var help173=1640;
var help771=1641;
var tsl_SLSIPA=1642;
var _aa_wiz_s7_msg=1643;
var tt_time_13=1644;
var up_tz_67=1645;
var help289a=1646;
var BIGPOND_LOGGED_IN=1647;
var haf_dmz_10=1648;
var help819=1649;
var wprn_s3b=1650;
var sps_tcpport=1651;
var dlink_wf_intro=1652;
var _websfilter=1653;
var sd_BPSN=1654;
var _password_user=1655;
var GW_INET_ACCESS_POLICY_END_IP=1656;
var bwn_msg_Modes=1657;
var up_gX_1=1658;
var _next=1659;
var _setup=1660;
var htsc_pingt_s=1661;
var EMAIL=1662;
var _mode=1663;
var tt_Feb=1664;
var sps_raw1=1665;
var GW_DYNDNS_SUCCESS=1666;
var IPPORTFORWARDALG_TCP_PACKET_ALLOC_FAILURE=1667;
var IGMP_ROUTER_LOW_RESOURCES=1668;
var bwl_CWM_h1=1669;
var up_tz_39=1670;
var help40=1671;
var _pf=1672;
var IPNAT_UDP_UNABLE_TO_HANDLE_HEADER=1673;
var GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS_WARNING=1674;
var GW_INET_ACCESS_INITIAL_MAC=1675;
var IPPPPCHAP_AUTH_SUCCESS=1676;
var help187=1677;
var _aa_block_all=1678;
var GW_WLAN_LINK_DOWN=1679;
var help379=1680;
var up_tz_70=1681;
var IPNAT_ICMP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1682;
var GW_SCHEDULES_IN_USE_INVALID_s1=1683;
var fb_p_2=1684;
var sps_ps=1685;
var help47=1686;
var wwa_title_s4=1687;
var tt_time_18=1688;
var help860=1689;
var GW_UPNP_IGD_PORTMAP_RELEASE=1690;
var wwa_intro_s4=1691;
var help267=1692;
var IPL2TP_SESSION_ABORTED=1693;
var help874=1694;
var tt_Sep=1695;
var IPSEC_ALG_ESP_UNABLE_TO_HANDLE_HEADER=1696;
var bws_GKUI=1697;
var help80b=1698;
var help168c=1699;
var BIGPOND_LOGGING_IN=1700;
var wwa_wanmode_pptp=1701;
var help58=1702;
var ddns_connected=1703;
var ub_Upload_Failed=1704;
var WIFISC_AP_PROXY_END_ON_MSG=1705;
var help278=1706;
var KR18=1707;
var hhts_def=1708;
var help255=1709;
var bws_2RSP=1710;
var help7=1711;
var bwl_VS_0=1712;
var af_TEFT=1713;
var help86=1714;
var sd_NNSSID=1715;
var wt_p_2=1716;
var _gateway=1717;
var tt_CurTime=1718;
var _AM=1719;
var DISCONNECTED=1720;
var gw_gm_47=1721;
var up_tz_22=1722;
var WIFISC_IR_REGISTRATION_SESSION_OVERLAP=1723;
var _pwsame_admin=1724;
var GW_DYNDNS_UPDATE_IP=1725;
var GW_DHCPSERVER_NEW_ASSIGNMENT=1726;
var as_WM=1727;
var up_tz_03=1728;
var KR43=1729;
var YM177=1730;
var help774=1731;
var hhac_edit=1732;
var up_tz_36=1733;
var _hostname=1734;
var GW_INET_ACCESS_INITIAL_FAIL=1735;
var GW_WEB_FILTER_INITIAL_FAIL=1736;
var te_OnFull=1737;
var wwl_title_s4=1738;
var help281=1739;
var gw_gm_77=1740;
var _clonemac=1741;
var hhss_intro=1742;
var at_MUS=1743;
var hhan_wans=1744;
var YM141=1745;
var help382=1746;
var tsc_hrmin=1747;
var tsc_hrmin1=1748;
var help82=1749;
var gw_gm_24=1750;
var gw_gm_13=1751;
var aw_RT=1752;
var help340=1753;
var sd_WLAN=1754;
var help864=1755;
var tf_intro_FWU1=1756;
var wprn_bados=1757;
var _metric=1758;
var INBOUND_FILTER=1759;
var IPNAT_UDP_BLOCKED_INGRESS=1760;
var help351=1761;
var wwz_manual_key2=1762;
var _PPTPsubnet=1763;
var help20=1764;
var gw_gm_6=1765;
var bws_WPAM=1766;
var wwl_GOOD=1767;
var gw_gm_36=1768;
var help894=1769;
var _subnet=1770;
var PPTP_EVENT_REMOTE_WINDOW_SIZE=1771;
var wps_KR35=1772;
var help329_rsv=1773;
var gw_gm_58=1774;
var GW_WAN_MODE_IS=1775;
var ns_intro_=1776;
var IPDNSRELAYALG_REJECTED_PACKET=1777;
var ss_intro=1778;
var KR112=1779;
var GW_WLAN_11A_CH_MID_BAND_WARN=1780;
var ip_mac_binding_desc=1781;
var LW50=1782;
var GW_NAT_CONFLICTING_CONNECTIONS_LOG=1783;
var KR111=1784;
var KR109=1785;
var GW_NAT_CONFLICTING_CONNECTIONS_WARNING=1786;
var GW_PURE_SETACCESSPOINTMODE=1787;
var GW_NAT_REJECTED_SPOOFED_PACKET=1788;
var KR110=1789;
var GW_ROUTES_ROUTE_GATEWAY_NOT_IN_SUBNET_WARNING=1790;
var KR107=1791;
var KR105=1792;
var IPSTACK_REJECTED_LAND_ATTACK=1793;
var LS321=1794;
var KR67=1795;
var YM71=1796;
var GW_FIREWALL_RANGE_DUPLICATED_INVALID=1797;
var LS422=1798;
var bwz_LWCNWz=1799;
var GW_WAN_WAN_GATEWAY_IP_ADDRESS_INVALID=1800;
var ta_wcn=1801;
var LW57=1802;
var _wepkey2=1803;
var tsc_pingt_msg109=1804;
var bd_NETBIOS_REG_TYPE=1805;
var wps_messgae1_2=1806;
var LW60=1807;
var _rs_failed=1808;
var KR62=1809;
var KR20=1810;
var at_intro_2=1811;
var bd_NETBIOS_ENABLE=1812;
var KR77=1813;
var help364=1814;
var _aa_bsecure_shopping=1815;
var _aa_bsecure_public_proxies=1816;
var wepkey1=1817;
var ZM11=1818;
var tsc_start_time=1819;
var YM69=1820;
var KR82=1821;
var ss_intro_user=1822;
var GW_SCHEDULES_NAME_RESERVED_INVALID=1823;
var LW12=1824;
var YM75=1825;
var GW_ROUTES_GATEWAY_IP_ADDRESS_INVALID=1826;
var GW_WLAN_WPA_REKEY_TIME_INVALID=1827;
var bws_msg_WEP_1=1828;
var YM125=1829;
var _aa_bsecure_gambling=1830;
var KR14=1831;
var GW_SMTP_FROM_ADDRESS_INVALID=1832;
var KR89=1833;
var help106=1834;
var LW35=1835;
var YM151=1836;
var YM2=1837;
var ta_wcn_note=1838;
var YM131=1839;
var GW_WEB_SERVER_SAME_PORT_LAN=1840;
var KR25=1841;
var YM3=1842;
var GW_NAT_WOL_ALG_ACTIVATED_WARNING=1843;
var YM20=1844;
var YM86=1845;
var GW_WAN_MAC_ADDRESS_INVALID=1846;
var IPSMTPCLIENT_MSG_WRONG_RECEPIENT_ADDR_FORMAT=1847;
var YM146=1848;
var LS151=1849;
var GW_QOS_RULES_NAME_INVALID=1850;
var GW_NAT_VS_PROTO_CONFLICT_INVALID=1851;
var GW_WISH_RULES_NAME_INVALID=1852;
var WIFISC_IR_REGISTRATION_FAIL=1853;
var r_rlist=1854;
var IPV6_TEXT109=1855;
var bws_WKL_1=1856;
var help473=1857;
var aw_erpe=1858;
var GW_NAT_PORT_FORWARD_RANGE_BOTH_EMPTY_INVALID=1859;
var GW_ROUTES_GATEWAY_IP_ADDRESS_IN_SUBNET_INVALID=1860;
var LW37=1861;
var tsc_pingdisallowed=1862;
var ZM20=1863;
var help376=1864;
var GW_FW_NOTIFY_EMAIL_DISABLED_INVALID=1865;
var YM122=1866;
var GW_NAT_DMZ_CONFLICT_WITH_LAN_IP_INVALID=1867;
var _sdi_s7=1868;
var at_title_SESet=1869;
var GW_INET_ACL_START_PORT_INVALID=1870;
var IPSMTPCLIENT_DATA_FAILED=1871;
var KR91=1872;
var KR971=1873;
var tss_RestAll_b=1874;
var GW_NAT_PORT_TRIGGER_CONFLICT_INVALID=1875;
var LW54=1876;
var TA7=1877;
var KR74=1878;
var bws_DFWK=1879;
var LW46=1880;
var IPSMTPCLIENT_RESOLVED_DNS=1881;
var help110=1882;
var YM107=1883;
var YM180=1884;
var GW_WAN_WAN_SUBNET_INVALID=1885;
var GW_NAT_DMZ_DISABLED_WARNING=1886;
var YM93=1887;
var GW_NAT_FTP_ALG_ACTIVATED_WARNING=1888;
var _aa_bsecure_free_host=1889;
var _r_alert2=1890;
var LS47=1891;
var GW_DHCP_SERVER_SUBNET_SIZE_INVALID=1892;
var GW_INET_ACCESS_POLICY_TOO_MANY_MAC_INVALID=1893;
var GW_FIREWALL_START_IP_ADDRESS_INVALID=1894;
var YM8=1895;
var GW_WISH_RULES_PRIORITY_RANGE=1896;
var _aa_bsecure_travel=1897;
var help113=1898;
var ZM6=1899;
var bws_length=1900;
var help836=1901;
var rs_intro_2=1902;
var GW_INET_ACL_IP_ADDRESS_DUPLICATION_INVALID=1903;
var KR7=1904;
var ZM1=1905;
var hhta_831=1906;
var LW30=1907;
var YM110=1908;
var bd_NETBIOS_REG_TYPE_P=1909;
var GW_LAN_SUBNET_MASK_INVALID=1910;
var YM88=1911;
var GW_DHCP_SERVER_NETBIOS_PRIMARY_WINS_INVALID=1912;
var YM187=1913;
var GW_NAT_NAME_UNDEFINED_INVALID=1914;
var GW_WIRELESS_RADAR_DETECTED=1915;
var LW25=1916;
var _rs_invalid=1917;
var YM113=1918;
var LW65=1919;
var KR41=1920;
var GW_WAN_DNS_SERVER_PRIMARY_INVALID=1921;
var KR21=1922;
var help643=1923;
var KR63=1924;
var LW31=1925;
var GW_WAN_DNS_SERVER_SECONDARY_INVALID=1926;
var YM55=1927;
var KR37=1928;
var KR80=1929;
var YM100=1930;
var _wakeonlan=1931;
var rs_intro_3=1932;
var gw_gm_35=1933;
var YM7=1934;
var YM124g=1935;
var GW_INET_ACL_MAC_ADDRESS_DUPLICATION_INVALID=1936;
var YM66=1937;
var manul_conn_13=1938;
var bd_NETBIOS=1939;
var sa_Target=1940;
var help56_a=1941;
var GW_DHCP_SERVER_RECONFIG_WARNING=1942;
var _wifisc_addfail=1943;
var GW_WLAN_BEACON_PERIOD_INVALID=1944;
var YM79=1945;
var YM32=1946;
var ta_intro_wcn=1947;
var wwl_text_better=1948;
var YM78=1949;
var sd_channel=1950;
var KR53=1951;
var LW16=1952;
var GW_NAT_TCP=1953;
var help202=1954;
var CRIT=1955;
var YM154=1956;
var help76=1957;
var GW_WISH_RULES_HOST1_PORT=1958;
var GW_WLAN_11G_TURBO_INVALID=1959;
var _aa_bsecure_entertainment=1960;
var YM165=1961;
var help172=1962;
var _aa_bsecure_lifestyles=1963;
var GW_NAT_DMZ_NOT_IN_SUBNET_INVALID=1964;
var sd_TMode=1965;
var GW_NAT_PORT_FORWARD_PORT_RANGE_INVALID=1966;
var GW_QOS_RULES_LOCAL_IP_END_SUBNET=1967;
var bws_CT_2=1968;
var _bsecure_parental_limits=1969;
var aw_64=1970;
var _aa_bsecure_humor=1971;
var KR92=1972;
var KR13=1973;
var GW_INET_ACL_POLICY_NAME_DUPLICATE_INVALID=1974;
var YM136=1975;
var TA3=1976;
var help360=1977;
var YM10=1978;
var GW_WAN_PPTP_SERVER_IP_ADDRESS_INVALID=1979;
var YM150=1980;
var GW_DHCP_SERVER_RESERVATION_IN_USE=1981;
var GW_NAT_INPUT_PORT=1982;
var WIFISC_AP_REBOOT_COMPLETE=1983;
var YM182=1984;
var LW3=1985;
var YM116=1986;
var LW22=1987;
var OOPS=1988;
var YM158=1989;
var ZM16=1990;
var _aa_bsecure_select_age=1991;
var GW_ROUTES_DESTINATION_IP_ADDRESS_INVALID=1992;
var WIFISC_AP_RESET_COMPLETE=1993;
var bd_NETBIOS_REG=1994;
var GW_LAN_GATEWAY_IP_ADDRESS_INVALID=1995;
var KR96=1996;
var GW_XML_CONFIG_GET_SUCCESS=1997;
var GW_UPNP_IGD_PORTMAP_REFRESH=1998;
var bws_msg_WPA_2=1999;
var GW_LAN_IP_ADDRESS_INVALID=2000;
var KR5=2001;
var help88c=2002;
var GW_INET_ACL_SCHEDULE_NAME_INVALID=2003;
var GW_QOS_RULES_REMOTE_PORT=2004;
var GW_NAT_IP_ADDRESS_INVALID=2005;
var help369=2006;
var help48a=2007;
var LW38=2008;
var GW_DYNDNS_USER_NAME_INVALID=2009;
var hhav_r_dest_ip=2010;
var YM175=2011;
var LY3=2012;
var GW_UPNP_IGD_PORTMAP_ADD=2013;
var GW_UPNP_IGD_PORTMAP_CONFLICT=2014;
var KRA1=2015;
var _vs_port=2016;
var GW_INET_ACL_RECONFIGURED_WARNING=2017;
var help186=2018;
var YM145=2019;
var WIFISC_AP_UNSET_SELECTED_REGISTRAR=2020;
var GW_WAN_DNS_SERVER_SECONDARY_WITHOUT_PRIMARY_INVALID=2021;
var YM72=2022;
var _hints=2023;
var GW_QOS_RULES_LOCAL_PORT=2024;
var YM52=2025;
var _aa_bsecure_chat=2026;
var help104=2027;
var help839=2028;
var YM99=2029;
var _aa_bsecure_byage=2030;
var GW_INET_ACL_NAME_DUPLICATE_INVALID=2031;
var GW_DHCP_SERVER_POOL_TO_INVALID=2032;
var KR26=2033;
var YM92=2034;
var GW_DHCP_SERVER_RESERVED_IP_INVALID=2035;
var help19x1=2036;
var _aa_bsecure_unstable=2037;
var GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID=2038;
var GW_FIREWALL_FILTER_NAME_INVALID=2039;
var ZM19=2040;
var YM80=2041;
var bd_NETBIOS_WINS_2=2042;
var KR57=2043;
var YM164=2044;
var _logsyslog_alert2=2045;
var YM149=2046;
var LT120=2047;
var KR48=2048;
var GW_WAN_RECONNECT_INTERVAL_INVALID=2049;
var YM139=2050;
var YM61=2051;
var GW_NAT_VIRTUAL_SERVER_TABLE_RECONFIGURED_WARNING=2052;
var YM1=2053;
var bws_WKL=2054;
var wps_p3_2=2055;
var KR102=2056;
var GW_QOS_RULES_LOCAL_IP_START_SUBNET=2057;
var GW_WAN_PPTP_IP_ADDRESS_INVALID=2058;
var _aa_bsecure_alcohol=2059;
var YM14=2060;
var GW_WLAN_11B_DYNAMIC_TURBO_INVALID=2061;
var GW_UPNP_IGD_PORTMAP_EXPIRE=2062;
var TA18=2063;
var aw_erpe_h2=2064;
var YM21=2065;
var YM147=2066;
var KR68=2067;
var LW61=2068;
var GW_WAN_L2TP_USERNAME_INVALID=2069;
var LT120z=2070;
var KR97=2071;
var GW_WAN_L2TP_SUBNET_INVALID=2072;
var help_ts_ss=2073;
var _aa_bsecure_automobile=2074;
var LW13=2075;
var sch_time=2076;
var bws_intro_WlsSec=2077;
var GW_WAN_PPPOE_PASSWORD_INVALID=2078;
var help211=2079;
var LS202=2080;
var tsc_EndTime=2081;
var KR34=2082;
var _wepkey3=2083;
var at_RePortR=2084;
var help640=2085;
var GW_SMTP_SERVER_ADDRESS_INVALID=2086;
var GW_WAN_L2TP_GATEWAY_IP_ADDRESS_INVALID=2087;
var LW58=2088;
var LW22usekey=2089;
var GW_WLAN_11B_STATIC_TURBO_INVALID=2090;
var YM67=2091;
var GW_WIFISC_CFG_CHANGED_WARNING=2092;
var ZM10=2093;
var GW_WLAN_11A_CHANNEL_INVALID=2094;
var at_title_SERules=2095;
var YM176=2096;
var KR81=2097;
var GW_NAT_TCP_PORT=2098;
var YM155=2099;
var help365=2100;
var bd_NETBIOS_SCOPE=2101;
var KR28=2102;
var _webfilter=2103;
var YM33=2104;
var YM76=2105;
var WIFISC_AP_SETUP_UNLOCKED=2106;
var GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=2107;
var LS313=2108;
var bwz_WCNWz=2109;
var ZM9=2110;
var GW_DHCP_SERVER_RESERVED_MAC_UNIQUENESS_INVALID=2111;
var LY5=2112;
var YM87=2113;
var GW_NAT_WAN_PING_FILTER_INVALID=2114;
var help835=2115;
var at_lowpriority=2116;
var YM49=2117;
var GW_INET_ACCESS_POLICY_TOO_MANY_IP_INVALID=2118;
var YM112=2119;
var KR90=2120;
var help838=2121;
var help892=2122;
var KR73=2123;
var wwl_intro_s3_2=2124;
var _r_alert5=2125;
var GW_NAT_WAN_PING_FILTER_WARNING=2126;
var YM53=2127;
var help215=2128;
var YM140=2129;
var GW_DHCPSERVER_REJECTED=2130;
var YM142=2131;
var GW_SMTP_PASSWORD_INVALID=2132;
var YM152=2133;
var LT119a=2134;
var LW36=2135;
var help377=2136;
var GW_NAT_PORT_TRIGGER_PORT_RANGE_INVALID=2137;
var YM121=2138;
var YM29=2139;
var YM159=2140;
var YM120=2141;
var wwl_BETTER=2142;
var hhaf_dmz=2143;
var YM106=2144;
var _aa_bsecure_block_unrated=2145;
var GW_WAN_BIGPOND_USERNAME_INVALID=2146;
var KR76=2147;
var GW_DHCPSERVER_EXHAUSTED=2148;
var GW_WAN_L2TP_SERVER_IP_ADDRESS_INVALID=2149;
var wwl_alert_pv5_2=2150;
var GW_ROUTES_SUBNET_INVALID=2151;
var _aa_bsecure_drugs=2152;
var LW1=2153;
var GW_DHCPSERVER_EXPIRED=2154;
var GW_INET_ACL_IP_ADDRESS_IN_LAN_SUBNET_INVALID=2155;
var bd_NETBIOS_REG_TYPE_B=2156;
var _aa_bsecure_financial=2157;
var YM135=2158;
var LT119=2159;
var _vs_public=2160;
var KR93=2161;
var GW_SECURE_REMOTE_ADMINSTRATION=2162;
var YM160=2163;
var LS423=2164;
var GW_WAN_L2TP_GATEWAY_IN_SUBNET_INVALID=2165;
var GW_WISH_RULES_HOST1_IP=2166;
var _vs_private=2167;
var KR86=2168;
var bd_NETBIOS_SEC_WINS=2169;
var GW_INET_ACL_START_IP_ADDRESS_INVALID=2170;
var auth=2171;
var KR24=2172;
var KR17=2173;
var YM84=2174;
var help88=2175;
var hhta_en=2176;
var YM103=2177;
var KR64=2178;
var GW_WLAN_11A_DFS_CHANNEL_INVALID=2179;
var LW4=2180;
var help645=2181;
var GW_WLAN_11A_STATIC_TURBO_INVALID=2182;
var help358=2183;
var YM6=2184;
var _aa_bsecure_categ_select=2185;
var YM58=2186;
var _aa_bsecure_age_youth=2187;
var LW17=2188;
var YM18=2189;
var LT210=2190;
var GW_WAN_IDLE_TIME_INVALID=2191;
var YM186=2192;
var _aa_bsecure_sports=2193;
var GW_QOS_RULES_NAME_ALREADY_USED=2194;
var bwz_intro_WCNWz=2195;
var GW_DHCP_SERVER_POOL_TO_IN_SUBNET_INVALID=2196;
var GW_NAT_H323_ALG_ACTIVATED_WARNING=2197;
var KR4=2198;
var LT120y=2199;
var KR103=2200;
var YM44=2201;
var LW47=2202;
var GW_XML_CONFIG_GET_FAILED=2203;
var WIFISC_AP_SET_APSETTINGS_COMPLETE=2204;
var wwl_WKL=2205;
var YM168=2206;
var GW_NAT_NAME_USED_INVALID=2207;
var GW_DYNDNS_SERVER_INDEX_VALUE_INVALID=2208;
var WARN=2209;
var LW23=2210;
var ADVANCED_NETWORK=2211;
var GW_WAN_PPTP_PASSWORD_INVALID=2212;
var LW59=2213;
var YM126=2214;
var _enabled=2215;
var _r_alert4=2216;
var LY10=2217;
var GW_DHCP_SERVER_POOL_FROM_INVALID=2218;
var WIFISC_AP_SETUP_LOCKED=2219;
var YM91=2220;
var WIFISC_AP_SET_SELECTED_REGISTRAR_FAIL=2221;
var _ask_nochange=2222;
var GW_NAT_UNKNOWN=2223;
var GW_WLAN_11A_DYNAMIC_TURBO_INVALID=2224;
var YM163=2225;
var YM181=2226;
var _cantapplysettings_1=2227;
var YM11=2228;
var wwl_wsp_chars_2=2229;
var bd_NETBIOS_PRI_WINS=2230;
var wwl_DWKL=2231;
var KR44=2232;
var TEXT056=2233;
var YM130=2234;
var KR99=2235;
var GW_DHCP_SERVER_PRIMARY_AND_SECONDARY_WINS_IP_INVALID=2236;
var KR106=2237;
var GW_NAT_VS_PROTOCOL_INVALID=2238;
var KR52=2239;
var KR33=2240;
var ZM23=2241;
var LW40=2242;
var LY4=2243;
var LW34=2244;
var YM25=2245;
var YM15=2246;
var bwl_SGM=2247;
var GW_WLAN_80211X_RADIUS_INVALID=2248;
var GW_WISH_RULES_PROTOCOL=2249;
var LS316=2250;
var ZM15=2251;
var GW_DHCP_SERVER_RESERVATION_DISABLED_IN_CONFLICT_WARNING=2252;
var GW_DYNDNS_HOST_NAME_INVALID=2253;
var LW42=2254;
var GW_WAN_PPTP_GATEWAY_IP_ADDRESS_INVALID=2255;
var rs_intro_4=2256;
var GW_QOS_RULES_REMOTE_IP_END_SUBNET=2257;
var _NA=2258;
var hhav_r_gateway=2259;
var INFO=2260;
var help112=2261;
var tf_msg_FWUgReset=2262;
var bd_NETBIOS_WAN=2263;
var aw_igslot=2264;
var ZM2=2265;
var LT7=2266;
var WIFISC_AP_SET_SELECTED_REGISTRAR=2267;
var help214=2268;
var at_Both=2269;
var ZM22=2270;
var help_ts_rfd=2271;
var help209=2272;
var YM70=2273;
var GW_UPNP_IGD_PORTMAP_VS_CHANGE=2274;
var help143s=2275;
var help363=2276;
var _aa_bsecure_web_newsgroup=2277;
var YM128=2278;
var GW_NAT_PORT_TRIGGER_PORT_RANGE_EMPTY_INVALID=2279;
var KR72=2280;
var td_PWK=2281;
var YM82=2282;
var YM119=2283;
var KR70=2284;
var YM161=2285;
var GW_DHCP_SERVER_POOL_SIZE_INVALID=2286;
var _sdi_s4b=2287;
var ZM8=2288;
var YM129=2289;
var help370=2290;
var LY29=2291;
var GW_XML_CONFIG_WRITE_WARN=2292;
var GW_FIREWALL_NAME_INVALID=2293;
var GW_WISH_RULES_HOST2_IP=2294;
var TA2=2295;
var LS314=2296;
var _vs_traffictype=2297;
var GW_DYNDNS_TIMEOUT_TOO_BIG_INVALID=2298;
var wps_p3_4=2299;
var KR51=2300;
var GW_WAN_PPTP_GATEWAY_IN_SUBNET_INVALID=2301;
var help837=2302;
var TEXT052=2303;
var OPEN=2304;
var _aa_bsecure_news=2305;
var YM34=2306;
var _advwls=2307;
var GW_DHCP_SERVER_RESERVATION_DISABLED_OUT_OF_POOL_WARNING=2308;
var GW_MAC_FILTER_ALL_LOCKED_OUT_INVALID=2309;
var _wepkey4=2310;
var LT124=2311;
var _aa_bsecure_search_engine=2312;
var KR47=2313;
var bws_msg_WEP_3=2314;
var GW_SMTP_LAN_ADDRESS_CONFLICT_WARNING=2315;
var GW_LAN_IP_MODE_INVALID=2316;
var GW_WAN_BIGPOND_SERVER_NOTSTD15=2317;
var GW_WLAN_FRAGMENT_THRESHOLD_INVALID=2318;
var GW_LAN_DOMAIN_NAME_INVALID=2319;
var GW_LAN_DEVICE_NAME_INVALID=2320;
var _wifisc_overlap=2321;
var LW62=2322;
var KR23=2323;
var _aa_bsecure_pornography=2324;
var GW_NAT_NAME_INVALID=2325;
var bd_title_clients=2326;
var YM108=2327;
var YM19=2328;
var WIFISC_AP_PROXY_PROCESS_COMPLETE=2329;
var GW_NAT_ENTRY_DUPLICATED_INVALID=2330;
var GW_NAT_PORT_FORWARD_CONFLICT_INVALID=2331;
var YM38=2332;
var tt_alert_nontp=2333;
var LY2=2334;
var KR29=2335;
var KR31=2336;
var _init_fail=2337;
var YM68=2338;
var sd_macaddr=2339;
var KR12=2340;
var help366=2341;
var WIFISC_AP_REGISTRATION_COMPLETE=2342;
var aw_TPC=2343;
var aw_WDSMAC=2344;
var YM62=2345;
var aw_erpe_h=2346;
var GW_WAN_RECONNECT_MODE_INVALID=2347;
var WIFISC_AP_DEL_APSETTINGS_COMPLETE=2348;
var LW15=2349;
var LW33=2350;
var KR27=2351;
var YM138=2352;
var GW_NAT_VS_PORT_CONFLICT_INVALID=2353;
var bd_NETBIOS_WINS_1=2354;
var _aa_wiz_s6_title=2355;
var YM77=2356;
var YM48=2357;
var YM89=2358;
var GW_WLAN_WPA_PSK_HEX_STRING_INVALID=2359;
var GW_WAN_WAN_IP_ADDRESS_INVALID=2360;
var LS4=2361;
var KR98=2362;
var YM148=2363;
var bws_WPAM_2=2364;
var help877a=2365;
var KR56=2366;
var LS424=2367;
var GW_DHCPSERVER_DECLINED=2368;
var GW_SCHEDULES_DAY_INVALID=2369;
var GW_NAT_UDP=2370;
var IPSMTPCLIENT_CANNOT_CREATE_CONNECTION=2371;
var _aa_check_all=2372;
var LS312=2373;
var KR2=2374;
var _vs_proto=2375;
var GW_SMTP_TO_ADDRESS_INVALID=2376;
var WIFISC_AP_REGISTRATION_FAIL=2377;
var GW_WISH_RULES_NAME_ALREADY_USED=2378;
var LW48=2379;
var YM54=2380;
var LW9=2381;
var LW41=2382;
var ebwl_AChan=2383;
var GW_WLAN_RTS_THRESHOLD_INVALID=2384;
var GW_WAN_L2TP_PASSWORD_INVALID=2385;
var YM12=2386;
var ZM14=2387;
var KR60=2388;
var YM28=2389;
var YM184=2390;
var int_intro_WCNWz7=2391;
var bws_Auth_2=2392;
var rs_intro_1=2393;
var help92=2394;
var GW_NAT_BOTH=2395;
var rs_success=2396;
var up_tz_29b=2397;
var day=2398;
var GW_DHCP_SERVER_DISABLED_WARNING=2399;
var _password=2400;
var GW_INET_ACCESS_POLICY_MAC_INVALID=2401;
var LW2=2402;
var KR75=2403;
var GW_XML_CONFIG_WRITE_FAILED=2404;
var YM73=2405;
var GW_WISH_RULES_NAME_USED_INVALID=2406;
var GW_DHCP_SERVER_POOL_SIZE_IN_SUBNET_INVALID=2407;
var aw_AS=2408;
var YM171=2409;
var GW_DHCP_SERVER_RESERVED_IP_NOT_LAN_IP_INVALID=2410;
var GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT=2411;
var hhav_r_netmask=2412;
var vs_vslist=2413;
var if_iflist=2414;
var YM137=2415;
var YM74=2416;
var GW_SYSLOG_ADDRESS_IN_SUBNET_INVALID=2417;
var help858=2418;
var GW_MAC_FILTER_MAC_UNIQUENESS_INVALID=2419;
var KR40=2420;
var GW_MAC_FILTER_NULL_MAC_INVALID=2421;
var aw_32=2422;
var GW_WAN_LAN_SUBNET_CONFLICT_INVALID=2423;
var LW66=2424;
var WIFISC_AP_DEL_APSETTINGS_FAIL=2425;
var wwl_wsp_chars_1=2426;
var KR85=2427;
var YM115=2428;
var YM83=2429;
var wwl_128bits=2430;
var LW51=2431;
var YM178=2432;
var _aa_bsecure_cults=2433;
var YM5=2434;
var KR65=2435;
var ZM17=2436;
var LW14=2437;
var ta_wcn_bv=2438;
var GW_NAT_VS_IP_ADDRESS_CAN_NOT_MATCH_ROUTER=2439;
var GW_SCHEDULES_IN_USE_INVALID=2440;
var wepkey3=2441;
var KR69=2442;
var YM43=2443;
var YM45=2444;
var GW_SMTP_USERNAME_INVALID=2445;
var help362=2446;
var tf_intro_FWChA=2447;
var _remotedesktop=2448;
var LW7=2449;
var help359=2450;
var KR84=2451;
var YM30=2452;
var at_LoPortR=2453;
var GW_DHCP_SERVER_POOL_FROM_IN_SUBNET_INVALID=2454;
var GW_MAC_FILTER_MULTICAST_MAC_INVALID=2455;
var GW_SMTP_INIT_FAILED_WARNING=2456;
var GW_DHCPSERVER_STOP=2457;
var help350=2458;
var GW_NAT_DMZ_NOT_ALLOWED_INVALID=2459;
var YM143=2460;
var GW_XML_CONFIG_SET_FAILED=2461;
var GW_NAT_PORT_DUP_INVALID=2462;
var KR46=2463;
var KR35=2464;
var GW_WAN_BIGPOND_PASSWORD_INVALID=2465;
var YM57=2466;
var KR104=2467;
var IPSMTPCLIENT_MSG_WRONG_SENDER_ADDR_FORMAT=2468;
var LS317=2469;
var YM102=2470;
var help188=2471;
var _logsyslog_alert1=2472;
var KR3=2473;
var _aa_bsecure_hate=2474;
var GW_WLAN_11BG_CHANNEL_INVALID=2475;
var RATE_ESTIMATOR_RATE_COMPLETED=2476;
var wwl_alert_pv5_3=2477;
var aw_aggr=2478;
var _wifisc_addstart=2479;
var help111=2480;
var GW_QOS_RULES_REMOTE_IP_START_SUBNET=2481;
var YM22=2482;
var GW_WLAN_WDS_MAC_ADDR_INVALID=2483;
var LW10=2484;
var LT291=2485;
var YM156=2486;
var _aa_bsecure_age_ado=2487;
var wwl_text_good=2488;
var GW_QOS_RULES_PRIORITY_RANGE=2489;
var te_OnSch=2490;
var _aa_bsecure_web_mail=2491;
var help188b=2492;
var GW_INET_ACL_START_IP_ADDRESS_IN_LAN_SUBNET_INVALID=2493;
var at_title_Traff=2494;
var help189=2495;
var GW_WIRELESS_SWITCH_CHANNEL=2496;
var GW_WAN_BIGPOND_SERVER_INVALID=2497;
var GW_XML_CONFIG_SET_PARSE=2498;
var hhaw_wmm=2499;
var LT290wifisc=2500;
var GW_FIREWALL_RULE_NAME_INVALID=2501;
var GW_NAT_SCHEDULE=2502;
var help109=2503;
var GW_LAN_RIP_MODE_INVALID=2504;
var LW52=2505;
var _aa_bsecure_popups=2506;
var GW_WLAN_WPA_WPA2_TKIP_INVALID=2507;
var KR16=2508;
var _vs_title=2509;
var _if_title=2510;
var GW_WAN_PPPOE_USERNAME_INVALID=2511;
var GW_WAN_PPTP_SUBNET_INVALID=2512;
var GW_DHCP_SERVER_NETBIOS_SCOPE_INVALID=2513;
var KR94=2514;
var YM63=2515;
var help108=2516;
var GW_SCHEDULES_DUPLICATED_INVALID=2517;
var bws_WPAM_1=2518;
var KR11=2519;
var LW45=2520;
var KR6=2521;
var GW_DHCP_SERVER_NETBIOS_TYPE_INVALID=2522;
var _aa_bsecure_games=2523;
var KR42=2524;
var YM104=2525;
var _aa_bsecure_tickets=2526;
var KR39=2527;
var bd_NETBIOS_REG_TYPE_M=2528;
var tsc_pingt_msg1=2529;
var GW_UPNP_IGD_PORTMAP_DEL=2530;
var YM111=2531;
var LS315=2532;
var GW_WLAN_WPA_PSK_LEN_INVALID=2533;
var help178=2534;
var YM167=2535;
var help371=2536;
var _aa_bsecure_anarchy=2537;
var YM4=2538;
var _aa_bsecure_criminal_skills=2539;
var YM188=2540;
var YM133=2541;
var YM59=2542;
var _aa_bsecure_manually=2543;
var YM169=2544;
var YM97=2545;
var _aa_bsecure_age_child=2546;
var help375=2547;
var GW_WEB_FILTER_WEBSITE_INVALID_INVALID=2548;
var ZM21=2549;
var YM157=2550;
var help213=2551;
var YM24=2552;
var wps_p3_3=2553;
var LW43=2554;
var help99_s=2555;
var YM90=2556;
var bws_CT_3=2557;
var help371_n=2558;
var GW_DHCP_SERVER_RESERVATION_RECONFIG_WARNING=2559;
var _r_alert3=2560;
var GW_LAN_RIP_METRIC_INVALID=2561;
var YM118=2562;
var YM127=2563;
var KR71=2564;
var aw_WDSEn=2565;
var KR32=2566;
var sa_Local=2567;
var GW_WEB_SERVER_IDLE_TIME=2568;
var KR59=2569;
var GW_WAN_WAN_GATEWAY_IN_SUBNET_INVALID=2570;
var at_LoIPR=2571;
var YM81=2572;
var aw_AP=2573;
var LT290=2574;
var YM162=2575;
var GW_XML_CONFIG_SET_PARSE_MIME=2576;
var GW_NAT_UDP_PORT=2577;
var YM9=2578;
var GW_WAN_MTU_INVALID=2579;
var LW63=2580;
var WIFISC_IR_REGISTRATION_SUCCESS=2581;
var help105=2582;
var GW_DHCPSERVER_RELEASED=2583;
var LW32=2584;
var WIFISC_AP_SET_APSETTINGS_FAIL=2585;
var KR8=2586;
var hhav_r_name=2587;
var bd_NETBIOS_REG_TYPE_H=2588;
var KR55=2589;
var GW_WAN_PPPOE_LAN_SUBNET_CONFLICT_INVALID=2590;
var GW_XML_CONFIG_SET_SUCCESS=2591;
var YM60=2592;
var KR100=2593;
var KR61=2594;
var bws_WKL_0=2595;
var bws_msg_WPA=2596;
var YM109=2597;
var WIFISC_AP_RESET_FAIL=2598;
var GW_WISH_RULES_HOST2_PORT=2599;
var help_ts_ls=2600;
var YM101=2601;
var KR50=2602;
var YM56=2603;
var aa_WebSite_Domain=2604;
var GW_QOS_RULES_MAX_TRANS=2605;
var GW_QOS_RULES_PROTOCOL=2606;
var GW_WEB_SERVER_NO_ACCESS=2607;
var KR87=2608;
var GW_WISH_RULES_DUPLICATED=2609;
var YM16=2610;
var GW_SCHEDULES_NAME_CONFLICT_INVALID=2611;
var wepkey4=2612;
var GW_WEB_SERVER_SAME_PORT_WAN=2613;
var YM65=2614;
var bln_title=2615;
var WIFISC_AP_PROXY_PROCESS_FAIL=2616;
var _more=2617;
var ZM12=2618;
var _aa_bsecure_banner_ad=2619;
var LY23=2620;
var help88b=2621;
var bwl_NSS_h1=2622;
var help203=2623;
var GW_INET_ACL_NO_MACHINE_IN_LAN_SUBNET_INVALID=2624;
var LW39c=2625;
var WIFISC_AP_SET_SELECTED_REGISTRAR_COMPLETE=2626;
var GW_DHCP_CLIENT_CLIENT_NAME_INVALID=2627;
var YM166=2628;
var WIFISC_AP_REBOOT_FAIL=2629;
var help91=2630;
var LW39=2631;
var YM173=2632;
var YM13=2633;
var YM172=2634;
var YM31=2635;
var _aa_wiz_s6_msg=2636;
var S493=2637;
var YM85=2638;
var GW_SCHEDULES_NAME_INVALID=2639;
var LS204=2640;
var aw_16=2641;
var aw_erpe_h3=2642;
var LW64=2643;
var _days=2644;
var help103=2645;
var YM183=2646;
var YM117=2647;
var KR54=2648;
var av_intro_r=2649;
var help368=2650;
var hhav_enable=2651;
var GW_WAN_DNS_SERVERS_INVALID=2652;
var _rs_succeeded=2653;
var GW_WAN_PPTP_USERNAME_INVALID=2654;
var GW_WAN_L2TP_IP_ADDRESS_INVALID=2655;
var GW_INET_ACL_NAME_INVALID=2656;
var days=2657;
var KR88=2658;
var GW_WAN_PPPOE_IP_ADDRESS_INVALID=2659;
var KR19=2660;
var RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED=2661;
var YM27=2662;
var LT291wifisc=2663;
var KR1=2664;
var YM51=2665;
var ZM13=2666;
var GW_LAN_PRIMARY_DNS_INVALID=2667;
var GW_WLAN_11A_DFS_TURBO_INVALID=2668;
var YM123=2669;
var TA8=2670;
var KR9=2671;
var KR79=2672;
var GW_QOS_RULES_REMOTE_IP=2673;
var _aa_bsecure_age_adult=2674;
var ZM7=2675;
var YM23=2676;
var tf_USSW=2677;
var LW55=2678;
var bwl_EW=2679;
var LS425=2680;
var wwl_WK=2681;
var LW11=2682;
var GW_NAT_PPTP_ALG_ACTIVATED_WARNING=2683;
var YM35=2684;
var tsc_sel_days=2685;
var sc_intro_rb4=2686;
var GW_SCHEDULES_TIME_INVALID=2687;
var GW_DHCP_SERVER_LEASE_TIME_INVALID=2688;
var IPSMTPCLIENT_NO_SERVER_IP_ADDRESS=2689;
var KR10=2690;
var GW_WEB_FILTER_HTTPS_NOT_SUPPORTED_INVALID=2691;
var KR22=2692;
var _vs_both=2693;
var wwl_alert_pv5_4=2694;
var GW_WIFISC_LOCK_VERIFY_ERR=2695;
var LW53=2696;
var GW_WEB_FILTER_WEB_SITE_IS_USED_INVALID=2697;
var YM64=2698;
var GW_ROUTES_INTERFACE_INVALID=2699;
var GW_LAN_SECONDARY_DNS_INVALID=2700;
var bd_NETBIOS_LEARN_FROM_WAN_ENABLE=2701;
var GW_NAT_PORT_FORWARDING_TABLE_RECONFIGURED_WARNING=2702;
var KR15=2703;
var WIFISC_AP_REGISTRATION_UNEXPECTED_EVENT=2704;
var GW_SYSLOG_ADDRESS_NOT_IN_SUBNET_WARNING=2705;
var GW_DHCP_SERVER_NETBIOS_SECONDARY_WINS_INVALID=2706;
var LW49=2707;
var KR95=2708;
var aw_8=2709;
var YM114=2710;
var bws_CT=2711;
var _aa_bsecure_rrated=2712;
var LW6=2713;
var bws_msg_WEP_2=2714;
var GW_QOS_RULES_LOCAL_IP=2715;
var GW_DHCP_SERVER_POOL_FROM_TO_ORIENTATION_INVALID=2716;
var bws_CT_1=2717;
var GW_XML_CONFIG_SET_LOCK=2718;
var GW_DHCP_SERVER_RESERVED_IP_UNIQUENESS_INVALID=2719;
var wepkey2=2720;
var LW28=2721;
var _wepkey1=2722;
var KR83=2723;
var GW_SYSLOG_ADDRESS_INVALID=2724;
var YM105=2725;
var ZM5=2726;
var help212=2727;
var wps_p3_5=2728;
var help19x2=2729;
var KR36=2730;
var GW_ROUTES_METRIC_INVALID=2731;
var GW_WLAN_SSID_INVALID=2732;
var LS46=2733;
var YM179=2734;
var KR78=2735;
var KR66=2736;
var _aa_bsecure_magazine=2737;
var KR101=2738;
var GW_WLAN_WPA_WPA_AES_INVALID=2739;
var GW_NAT_INBOUND_FILTER=2740;
var GW_INET_ACL_POLICY_NAME_INVALID=2741;
var sa_Internet=2742;
var help406=2743;
var YM153=2744;
var at_ReIPR=2745;
var GW_INET_ACCESS_RESTRICTED=2746;
var GW_WLAN_DTIM_INVALID=2747;
var YM144=2748;
var up_tz_26=2749;
var help71=2750;
var GW_PURE_ADDPORTMAPPING_MODIFY=2751;
var tsc_pingt_msg10=2752;
var tps_foo=2753;
var GW_PURE_ADDPORTMAPPING_CHG_PROTOCOL=2754;
var LOG_PREV_MSG_REPEATED_N_TIMES=2755;
var ca_intro=2756;
var GW_WAN_LAN_ADDRESS_CONFLICT_DHCP=2757;
var help176=2758;
var GW_PURE_ADDPORTMAPPING_CREATE=2759;
var hhag_30=2760;
var hhai_save=2761;
var ADMIN=2762;
var wprn_s1a=2763;
var sl_alert_3=2764;
var help900=2765;
var tps_foo2=2766;
var help182=2767;
var aa_alert_12=2768;
var tf_intro_FWCh=2769;
var ts_ss=2770;
var wwa_title_set_pptp=2771;
var _hostname_eg=2772;
var wwl_s4_note=2773;
var help22=2774;
var wwl_alert_pv5_1=2775;
var GW_PURE_SETWLANSETTINGS24=2776;
var help167=2777;
var at_DxDSL=2778;
var wprn_bados2=2779;
var wprn_s3a=2780;
var wprn_tt10=2781;
var bwn_IF=2782;
var _1044a=2783;
var wprn_tt6=2784;
var help72=2785;
var _sdi_s6=2786;
var hhpt_sch=2787;
var tps_enraw=2788;
var sl_alert_2=2789;
var anet_wp_2=2790;
var tss_RestAll=2791;
var GW_PURE_SETWANSETTINGS=2792;
var help53=2793;
var help175=2794;
var help872=2795;
var help785=2796;
var wprn_s2b=2797;
var wprn_intro2=2798;
var GW_INET_ACL_NO_FILTER_SELECTED_INVALID=2799;
var help890=2800;
var help814=2801;
var help283=2802;
var sps_protdis=2803;
var help831=2804;
var _cantapplysettings=2805;
var help39=2806;
var WCN_LOG_ABORT=2807;
var up_tz_73=2808;
var help141_a=2809;
var af_intro_x=2810;
var help170=2811;
var tps_intro4=2812;
var help893b=2813;
var GW_DHCPSERVER_START=2814;
var help887=2815;
var help38=2816;
var help164=2817;
var hhav_filt=2818;
var GW_PURE_ADDPORTMAPPING_CONFLICT=2819;
var GW_PURE_SETROUTERLANSETTINGS=2820;
var GW_PURE_SETWLANSECURITY=2821;
var aa_alert_9=2822;
var help287=2823;
var ta_RAIF=2824;
var help180=2825;
var GW_PURE_SETDEVICESETTINGS=2826;
var _rssi=2827;
var wwl_intro_wel=2828;
var tf_ClickDL=2829;
var help165=2830;
var _vs_other=2831;
var tps_intro5=2832;
var ub_intro_1=2833;
var help277=2834;
var help41=2835;
var VIRTUAL_SERVERS=2836;
var hhav_sch=2837;
var ts_rfd=2838;
var help33b=2839;
var ts_ls=2840;
var GW_PURE_DELETEPORTMAPPING_MODIFY=2841;
var wprn_s2c=2842;
var help320=2843;
var help813=2844;
var help893=2845;
var help803=2846;
var help877=2847;
var up_tz_27=2848;
var help74=2849;
var help155_2=2850;
var _sdi_s4=2851;
var MISC=2852;
var tf_msg_Upping=2853;
var GW_LOG_EMAIL_FAILED=2854;
var help823_17=2855;
var IPV6_TEXT4=2856;
var sa_intro=2857;
var up_rb_2=2858;
var help23=2859;
var _bln_title_IGMPMemberships_h=2860;
var haf_intro_2=2861;
var help802=2862;
var wprn_tt5=2863;
var hhsl_lmail=2864;
var ap_intro_noreboot=2865;
var up_tz_29=2866;
var GW_PURE_SETMACFILTERS2=2867;
var GW_PURE_REBOOT=2868;
var rb_change=2869;
var help816=2870;
var GW_PURE_DELETEPORTMAPPING_DELETE=2871;
var ub_intro_3=2872;
var help30=2873;
var bln_alert_2=2874;
var hhwf_xref=2875;
var GW_REMOTE_ADMINSTRATION=2876;
var wwl_s4_intro=2877;
var sd_SecTyp=2878;
var IPV6_WAN_IP=2879;
var IPV6_TEXT0=2880;
var gw_wcn_alert_3=2881;
var IPV6_TEXT2=2882;
var S473=2883;
var af_ES=2884;
var IPV6_TEXT5=2885;
var IPV6_TEXT6=2886;
var IPV6_TEXT7=2887;
var IPV6_TEXT8=2888;
var IPV6_TEXT9=2889;
var IPV6_TEXT10=2890;
var IPV6_TEXT11=2891;
var IPV6_TEXT12=2892;
var IPV6_TEXT13=2893;
var IPV6_TEXT14=2894;
var IPV6_TEXT15=2895;
var IPV6_TEXT16=2896;
var IPV6_TEXT17=2897;
var IPV6_TEXT18=2898;
var IPV6_TEXT19=2899;
var IPV6_TEXT20=2900;
var IPV6_TEXT21=2901;
var IPV6_TEXT22=2902;
var IPV6_TEXT23=2903;
var DNS_TEXT0=2904;
var IPV6_TEXT25=2905;
var IPV6_TEXT26=2906;
var IPV6_TEXT27=2907;
var IPV6_TEXT28=2908;
var IPV6_TEXT29=2909;
var IPV6_TEXT29a=2910;
var IPV6_TEXT30=2911;
var IPV6_TEXT31=2912;
var IPV6_TEXT32=2913;
var IPV6_TEXT33=2914;
var IPV6_TEXT34=2915;
var IPV6_TEXT35=2916;
var IPV6_TEXT36=2917;
var IPV6_TEXT37=2918;
var IPV6_TEXT38=2919;
var IPV6_TEXT39=2920;
var IPV6_TEXT40=2921;
var IPV6_TEXT41=2922;
var IPV6_TEXT42=2923;
var IPV6_TEXT43=2924;
var IPV6_TEXT44=2925;
var IPV6_TEXT45=2926;
var IPV6_TEXT46=2927;
var IPV6_TEXT47=2928;
var IPV6_TEXT48=2929;
var IPV6_TEXT49=2930;
var TA11=2931;
var IPV6_TEXT51=2932;
var IPV6_TEXT52=2933;
var IPV6_TEXT53=2934;
var IPV6_TEXT54=2935;
var IPV6_TEXT55=2936;
var IPV6_TEXT56=2937;
var IPV6_TEXT57=2938;
var IPV6_TEXT58=2939;
var IPV6_TEXT59=2940;
var IPV6_TEXT60=2941;
var IPV6_TEXT61=2942;
var IPV6_TEXT62=2943;
var IPV6_TEXT63=2944;
var IPV6_TEXT65=2945;
var _aa_bsecure_obscene=2946;
var IPV6_TEXT66=2947;
var IPV6_TEXT67=2948;
var IPV6_TEXT68=2949;
var IPV6_TEXT69=2950;
var IPV6_TEXT70=2951;
var IPV6_TEXT71=2952;
var IPV6_TEXT72=2953;
var IPV6_TEXT73=2954;
var IPV6_TEXT74=2955;
var IPV6_TEXT75=2956;
var IPV6_TEXT76=2957;
var IPV6_TEXT77=2958;
var IPV6_TEXT78=2959;
var IPV6_TEXT79=2960;
var IPV6_TEXT80=2961;
var IPV6_TEXT81=2962;
var IPV6_TEXT82=2963;
var IPV6_TEXT83=2964;
var IPV6_TEXT84=2965;
var IPV6_TEXT85=2966;
var IPV6_TEXT86=2967;
var IPV6_TEXT87=2968;
var IPV6_TEXT88=2969;
var IPV6_TEXT89=2970;
var IPV6_TEXT90=2971;
var IPV6_TEXT91=2972;
var IPV6_TEXT92=2973;
var IPV6_TEXT93=2974;
var IPV6_TEXT94=2975;
var IPV6_TEXT95=2976;
var IPV6_TEXT96=2977;
var IPV6_TEXT97=2978;
var IPV6_TEXT98=2979;
var IPV6_TEXT99=2980;
var IPV6_TEXT100=2981;
var IPV6_TEXT102=2982;
var IPV6_TEXT103=2983;
var IPV6_TEXT104=2984;
var IPV6_TEXT108=2985;
var IPV6_TEXT106=2986;
var IPV6_TEXT107=2987;
var IPV6_TEXT50=2988;
var help825=2989;
var IPV6_TEXT110=2990;
var IPV6_TEXT111=2991;
var IPV6_TEXT112=2992;
var IPV6_TEXT113=2993;
var IPV6_TEXT116=2994;
var IPV6_TEXT117=2995;
var IPV6_TEXT118=2996;
var IPV6_TEXT119=2997;
var IPV6_TEXT120=2998;
var IPV6_TEXT121=2999;
var IPV6_TEXT122=3000;
var IPV6_TEXT123=3001;
var IPV6_TEXT124=3002;
var IPV6_TEXT125=3003;
var IPV6_TEXT126=3004;
var IPV6_TEXT127=3005;
var IPV6_TEXT128=3006;
var IPV6_TEXT129=3007;
var IPV6_TEXT130=3008;
var IPV6_TEXT131=3009;
var IPV6_TEXT132=3010;
var IPV6_TEXT133=3011;
var IPV6_TEXT134=3012;
var IPV6_TEXT135=3013;
var IPV6_TEXT136=3014;
var IPV6_TEXT137=3015;
var IPV6_TEXT138=3016;
var IPV6_TEXT139=3017;
var IPV6_TEXT140=3018;
var IPV6_TEXT141=3019;
var IPV6_TEXT142=3020;
var IPV6_TEXT143=3021;
var IPV6_TEXT144=3022;
var IPV6_TEXT145=3023;
var IPV6_TEXT146=3024;
var bd_EDSv=3025;
var htsc_pingt_h=3026;
var IPV6_TEXT149=3027;
var IPV6_TEXT150=3028;
var IPV6_TEXT151=3029;
var IPV6_TEXT152=3030;
var IPV6_TEXT153=3031;
var wps_KR37=3032;
var IPV6_TEXT155=3033;
var IPV6_TEXT156=3034;
var IPV6_TEXT157=3035;
var IPV6_TEXT158=3036;
var IPV6_TEXT159=3037;
var IPV6_TEXT160=3038;
var IPV6_TEXT161=3039;
var IPV6_TEXT162=3040;
var IPV6_TEXT163=3041;
var IPV6_TEXT164=3042;
var IPV6_TEXT165=3043;
var IPV6_TEXT166=3044;
var haar_p=3045;
var bws_ORAD=3046;
var DNS_TEXT2=3047;
var DNS_TEXT3=3048;
var DNS_TEXT4=3049;
var DNS_TEXT8=3050;
var DNS_TEXT6=3051;
var DNS_TEXT5=3052;
var help639=3053;
var DNS_TEXT9=3054;
var DNS_TEXT10=3055;
var DNS_TEXT11=3056;
var DNS_TEXT12=3057;
var TEXT000=3058;
var TEXT001=3059;
var TEXT002=3060;
var TEXT003=3061;
var TEXT004=3062;
var TEXT005=3063;
var TEXT006=3064;
var TEXT007=3065;
var TEXT008=3066;
var TEXT010=3067;
var sw_title_list=3068;
var TEXT011=3069;
var TEXT012=3070;
var TEXT013=3071;
var TEXT014=3072;
var TEXT015=3073;
var TEXT016=3074;
var TEXT017=3075;
var TEXT018=3076;
var TEXT019=3077;
var TEXT020=3078;
var TEXT021=3079;
var TEXT022=3080;
var LS3=3081;
var TEXT024=3082;
var TEXT025=3083;
var TEXT026=3084;
var TEXT027=3085;
var TEXT028=3086;
var TEXT029=3087;
var TEXT030=3088;
var TEXT031=3089;
var TEXT032=3090;
var TEXT033=3091;
var TEXT035=3092;
var TEXT036=3093;
var TEXT037=3094;
var TEXT038=3095;
var TEXT039=3096;
var TEXT040=3097;
var TEXT041=3098;
var TEXT042=3099;
var TEXT043=3100;
var TEXT045=3101;
var TEXT046=3102;
var TEXT047=3103;
var aa_alert_10=3104;
var TEXT049=3105;
var TEXT050=3106;
var TEXT051=3107;
var TEXT053=3108;
var TEXT055=3109;
var TEXT009=3110;
var TEXT054=3111;
var TEXT057=3112;
var TEXT058=3113;
var TEXT059=3114;
var TEXT060=3115;
var TEXT062=3116;
var TEXT063=3117;
var TEXT064=3118;
var TEXT065=3119;
var TEXT066=3120;
var TEXT067=3121;
var TEXT068=3122;
var TEXT069=3123;
var TEXT070=3124;
var TEXT071=3125;
var TEXT072=3126;
var TEXT073=3127;
var TEXT074=3128;
var TEXT075=3129;
var TEXT076=3130;
var TEXT077=3131;
var TEXT078=3132;
var MSG002=3133;
var MSG003=3134;
var MSG004=3135;
var MSG005=3136;
var MSG006=3137;
var MSG007=3138;
var MSG008=3139;
var MSG009=3140;
var MSG010=3141;
var MSG013=3142;
var MSG014=3143;
var MSG014a=3144;
var MSG015=3145;
var MSG016=3146;
var MSG017=3147;
var MSG018=3148;
var MSG019=3149;
var MSG020=3150;
var MSG021=3151;
var MSG022=3152;
var MSG023=3153;
var MSG024=3154;
var MSG025=3155;
var MSG026=3156;
var MSG027=3157;
var MSG028=3158;
var MSG029=3159;
var MSG030=3160;
var MSG031=3161;
var MSG032=3162;
var MSG033=3163;
var MSG034=3164;
var MSG035=3165;
var MSG036_1=3166;
var MSG037_1=3167;
var MSG038_1=3168;
var MSG039_1=3169;
var MSG036=3170;
var MSG037=3171;
var MSG038=3172;
var MSG039=3173;
var MSG040=3174;
var MSG041=3175;
var MSG042=3176;
var MSG043=3177;
var MSG044=3178;
var MSG045=3179;
var MSG046=3180;
var MSG047=3181;
var MSG048=3182;
var ADV_DNS_DESC3=3183;
var ERROR404=3184;
var SUGGESTIONS=3185;
var SUGGESTIONS_1=3186;
var SUGGESTIONS_2=3187;
var tsc_hrmin_1=3188;
var DHCP_PD=3189;
var IPV6_TEXT147=3190;
var DHCP_PD_ASSIGNED=3191;
var _6to4RELAY=3192;
var IPV6_TEXT64=3193;
var IPV6_TEXT66_v6=3194;
var usb_reboot=3195;
var usb_reboot_chnip=3196;
var country_8=3197;
var _select_phone=3198;
var _phone_info=3199;
var usb_3g_phone=3200;
var usb_window_mobile_5=3201;
var usb_iphone=3202;
var android_phone=3203;
var help901=3204;
var DEVICE_NAME=3205;
var IPDHCPSERVER_LEASE_REVOKED2=3206;
var IPDHCPSERVER_LEASE_RESERVATION_DELETED=3207;
var IPDHCPSERVER_LEASE_RENEW=3208;
var help738=3209;
var help759=3210;
var help517=3211;
var help443=3212;
var help414=3213;
var _ok=3214;
var help486=3215;
var help503=3216;
var help426=3217;
var help432=3218;
var help527=3219;
var awf_intro_WF=3220;
var help652=3221;
var help456=3222;
var help539=3223;
var help472=3224;
var help520=3225;
var help737=3226;
var help646=3227;
var help745=3228;
var help659=3229;
var help727=3230;
var help753=3231;
var help574=3232;
var help663=3233;
var help748=3234;
var hhwf_intro=3235;
var help598=3236;
var help761=3237;
var help510=3238;
var help584=3239;
var help716=3240;
var help440=3241;
var help410=3242;
var help480=3243;
var help559=3244;
var help516=3245;
var help413=3246;
var help619=3247;
var help521=3248;
var help494=3249;
var help498=3250;
var help628=3251;
var help683=3252;
var help535=3253;
var help695=3254;
var help740=3255;
var help578=3256;
var help438=3257;
var help508=3258;
var help423=3259;
var help625=3260;
var help680=3261;
var help568=3262;
var help620=3263;
var help667=3264;
var help766=3265;
var help662=3266;
var help701=3267;
var help542=3268;
var help570=3269;
var help489=3270;
var help723=3271;
var help593=3272;
var help447=3273;
var help705=3274;
var help755=3275;
var _H323=3276;
var help427=3277;
var help485=3278;
var help490=3279;
var help555=3280;
var help462=3281;
var help732=3282;
var help592=3283;
var help455=3284;
var help685=3285;
var help146=3286;
var help655=3287;
var help439=3288;
var help416=3289;
var help726=3290;
var help692=3291;
var help550=3292;
var help714=3293;
var help504=3294;
var help469=3295;
var help629=3296;
var help597=3297;
var help746=3298;
var help749=3299;
var help471=3300;
var help736=3301;
var help596=3302;
var help706=3303;
var help664=3304;
var help702=3305;
var help756=3306;
var help573=3307;
var help601=3308;
var help684=3309;
var help678=3310;
var help760=3311;
var help536=3312;
var help499=3313;
var help562=3314;
var help741=3315;
var help541=3316;
var help717=3317;
var help604=3318;
var help718=3319;
var help551=3320;
var help577=3321;
var help515=3322;
var help621=3323;
var help412=3324;
var help713=3325;
var help687=3326;
var help567=3327;
var help618=3328;
var help441=3329;
var help466=3330;
var gw_vs_5=3331;
var help488=3332;
var help591=3333;
var help402=3334;
var help661=3335;
var help495=3336;
var help587=3337;
var help658=3338;
var help722=3339;
var help483=3340;
var help670=3341;
var help750=3342;
var help452=3343;
var help696=3344;
var help668=3345;
var help433=3346;
var help681=3347;
var help632=3348;
var help409=3349;
var help765=3350;
var help421=3351;
var help725=3352;
var help660=3353;
var help576=3354;
var help751=3355;
var help735=3356;
var help401=3357;
var gw_vs_6=3358;
var help491=3359;
var help448=3360;
var help566=3361;
var help398=3362;
var help586=3363;
var help710=3364;
var help686=3365;
var help537=3366;
var help654=3367;
var help708=3368;
var help424=3369;
var help505=3370;
var help583=3371;
var help430=3372;
var help484=3373;
var help454=3374;
var help556=3375;
var help470=3376;
var help689=3377;
var help464=3378;
var help461=3379;
var tt_Nov=3380;
var help715=3381;
var help622=3382;
var help731=3383;
var help408=3384;
var help688=3385;
var help465=3386;
var help703=3387;
var help697=3388;
var help605=3389;
var help549=3390;
var help506=3391;
var help642=3392;
var help428=3393;
var help682=3394;
var help492=3395;
var help526=3396;
var help631=3397;
var help606=3398;
var help665=3399;
var help148=3400;
var RATE_ESTIMATOR_RESOURCE_ERROR=3401;
var help721=3402;
var gw_vs_2=3403;
var help729=3404;
var help757=3405;
var help595=3406;
var help671=3407;
var help747=3408;
var help707=3409;
var help451=3410;
var help514=3411;
var help512=3412;
var help675=3413;
var help399=3414;
var help626=3415;
var help415=3416;
var help533=3417;
var help572=3418;
var help557=3419;
var help468=3420;
var help724=3421;
var help648=3422;
var wt_title=3423;
var help657=3424;
var help482=3425;
var help679=3426;
var help431=3427;
var help560=3428;
var help742=3429;
var help449=3430;
var help565=3431;
var wprn_tt7=3432;
var help599=3433;
var help585=3434;
var help530=3435;
var help623=3436;
var help758=3437;
var help634=3438;
var help752=3439;
var help575=3440;
var help450=3441;
var ES_CABLELOST_bnr=3442;
var help463=3443;
var help407=3444;
var help453=3445;
var help561=3446;
var help442=3447;
var help762=3448;
var help553=3449;
var help590=3450;
var help608=3451;
var help411=3452;
var gw_vs_4=3453;
var help546=3454;
var help653=3455;
var help481=3456;
var help529=3457;
var help425=3458;
var help400=3459;
var help509=3460;
var _DHCP=3461;
var help709=3462;
var help720=3463;
var help728=3464;
var help467=3465;
var help719=3466;
var help594=3467;
var help457=3468;
var help666=3469;
var help698=3470;
var help538=3471;
var help630=3472;
var help422=3473;
var help493=3474;
var help507=3475;
var help571=3476;
var RATE_ESTIMATOR_CONVERGENCE_ERROR=3477;
var help487=3478;
var help624=3479;
var help543=3480;
var help700=3481;
var help460=3482;
var help730=3483;
var help502=3484;
var help513=3485;
var help690=3486;
var help607=3487;
var help525=3488;
var help754=3489;
var help617=3490;
var help500=3491;
var help558=3492;
var help429=3493;
var help511=3494;
var help534=3495;
var help496=3496;
var help446=3497;
var help739=3498;
var help627=3499;
var _actsess=3500;
var help91a=3501;
var help91b=3502;
var help92x1=3503;
var help92x2=3504;
var TA21=3505;
var TA22=3506;
var help183=3507;
var help400_b=3508;
var help401_b=3509;
var help402_b=3510;
var help403=3511;
var help403_b=3512;
var help404=3513;
var help404_b=3514;
var help405=3515;
var help405_b=3516;
var WIFISC_AP_PEER_CFG_ERR=3517;
var help417=3518;
var help418=3519;
var help419=3520;
var help420=3521;
var help434=3522;
var help435=3523;
var help436=3524;
var help437=3525;
var help444=3526;
var help445=3527;
var help458=3528;
var help459=3529;
var help474=3530;
var help475=3531;
var help476=3532;
var help477=3533;
var help478=3534;
var help479=3535;
var help518=3536;
var help519=3537;
var help522=3538;
var help523=3539;
var help528=3540;
var help531=3541;
var help532=3542;
var help544=3543;
var help545=3544;
var help548=3545;
var help563=3546;
var help564=3547;
var help579=3548;
var help580=3549;
var help581=3550;
var help582=3551;
var help588=3552;
var help589=3553;
var help602=3554;
var help603=3555;
var help609=3556;
var help610=3557;
var help611=3558;
var help612=3559;
var help613=3560;
var help614=3561;
var help615=3562;
var help616=3563;
var tt_Oct=3564;
var sa_Originator=3565;
var help637=3566;
var help641=3567;
var help638=3568;
var msg_non_sec=3569;
var LW24=3570;
var help644=3571;
var help649=3572;
var help650=3573;
var help672=3574;
var help673=3575;
var help676=3576;
var help677=3577;
var help693=3578;
var help694=3579;
var help711=3580;
var help712=3581;
var help733=3582;
var help734=3583;
var help743=3584;
var help744=3585;
var help763=3586;
var help764=3587;
var help795a=3588;
var sa_Internal=3589;
var sa_External=3590;
var DNS_TEXT7=3591;
var help831_1=3592;
var DNS_TEXT1=3593;
var help191=3594;
var help198=3595;
var _unknown_wait=3596;
var _unknown=3597;
var _na=3598;
var _sdi_nciy=3599;
var _sdi_dhcpclient=3600;
var _sdi_bpc=3601;
var help600=3602;
var _bln_nmgmy=3603;
var _sdi_s1=3604;
var _sdi_s10=3605;
var _sdi_s8=3606;
var _sdi_s9=3607;
var _sdi_days=3608;
var _sdi_disconnectpending=3609;
var _sdi_secs=3610;
var sd_Renew=3611;
var sd_Release=3612;
var sd_Disconnect=3613;
var sd_bp_login=3614;
var sd_bp_logout=3615;
var _channel=3616;
var sl_SLogs=3617;
var sps_intro2=3618;
var sps_pare=3619;
var sr_RTable=3620;
var sr_intro=3621;
var ss_title_stats=3622;
var sw_title=3623;
var ta_alert_1=3624;
var ES_CABLELOST_dsc1=3625;
var _pwsame=3626;
var ta_alert_3=3627;
var _invalidddnsserver=3628;
var _blankddnsserver=3629;
var IPV6_TEXT1=3630;
var td_alert_2=3631;
var td_alert_3=3632;
var td_DDNSDDNS=3633;
var tt_SelDynDns=3634;
var _emailaccnameisblank=3635;
var _blankfromemailaddr=3636;
var _blanktomemailaddr=3637;
var _blanksmtpmailaddr=3638;
var _badfromemailaddr=3639;
var _badtoemailaddr=3640;
var _invalidsmtpserveraddr=3641;
var _badsmtpserveraddr=3642;
var tf_NFWA=3643;
var tf_alert_1=3644;
var tf_LFWVis=3645;
var tf_FWCinP=3646;
var tf_Ching_FW=3647;
var tf_EM_not=3648;
var tf_LFWV=3649;
var tf_FWChNow=3650;
var TA17=3651;
var tps_sfp=3652;
var tps_dci=3653;
var tps_intro2=3654;
var tsc_alert_1=3655;
var tsc_alert_2=3656;
var tsc_alert_3=3657;
var tsc_alert_6=3658;
var tsc_alert_9=3659;
var tsc_SelDays=3660;
var tsc_TimeFr=3661;
var tsl_alert_3=3662;
var tsl_alert_1=3663;
var tsl_alert_2=3664;
var ZM18=3665;
var tsc_pingt_msg9=3666;
var help635=3667;
var tt_alert_tupdt=3668;
var TA24=3669;
var TA25=3670;
var fb_FbAc=3671;
var sentinel_1=3672;
var sentinel_2=3673;
var sentinal_3=3674;
var fl_Failure=3675;
var fl_text=3676;
var li_newfw=3677;
var rd_p_1=3678;
var rd_p_2=3679;
var rs_Restoring_Settings=3680;
var reh=3681;
var rs_RSPW=3682;
var rs_cld=3683;
var rs_Done=3684;
var rs_uld=3685;
var rs_usd=3686;
var rs_csd=3687;
var rs_Repacked=3688;
var rs_Converted=3689;
var rs_Saving=3690;
var sc_intro_rb=3691;
var _relogin=3692;
var _badWANsub=3693;
var wwa_pv5_alert_4=3694;
var wwa_pv5_alert_5=3695;
var wwa_pv5_alert_8=3696;
var wwa_pv5_alert_6=3697;
var wwa_pv5_alert_7=3698;
var wwa_pv5_alert_21=3699;
var _badPPTPgwip=3700;
var wwa_pv5_alert_15=3701;
var _badL2TPgwip=3702;
var wwa_pv5_alert_20=3703;
var wwl_intro_s3_1=3704;
var wwl_intro_s3_2r=3705;
var wwl_WSP_1=3706;
var wwl_wpa=3707;
var wwl_wpa2=3708;
var gw_vs_0=3709;
var gw_vs_8=3710;
var gw_sa_0=3711;
var gw_sa_2=3712;
var gw_sa_3=3713;
var gw_sa_4=3714;
var YM47=3715;
var gw_SelBPS=3716;
var gw_bp_0=3717;
var gw_bp_1=3718;
var gw_bp_2=3719;
var gw_gm_81=3720;
var gw_wcn_alert_4=3721;
var gw_wcn_alert5=3722;
var gw_wcn_alert6=3723;
var gw_wcn_alert7=3724;
var gw_wcn_err_ok=3725;
var gw_wcn_err_code=3726;
var gw_wcn_err_os_version=3727;
var gw_wcn_err_load_config=3728;
var gw_wcn_err_provision=3729;
var gw_wcn_err_io_write_config=3730;
var gw_wcn_err_encryption=3731;
var gw_wcn_err_exception=3732;
var gw_wcn_err_com=3733;
var gw_wcn_err_bad_wsetting_entry=3734;
var gw_wcn_err_bad_wps_profile=3735;
var gw_wcn_err_unsupported_wsetting=3736;
var gw_wcn_err_dom_processing=3737;
var gw_wcn_err_default=3738;
var adv_Everyone=3739;
var adv_Noone=3740;
var psQueued=3741;
var psStarting=3742;
var psClosed=3743;
var psIdle=3744;
var psReady=3745;
var GW_PPPOE_EVENT_OFFER=3746;
var psUnplugged=3747;
var psPrinting=3748;
var IPPPPPAP_AUTH_RESULT=3749;
var up_gS_1=3750;
var up_gIUH_1=3751;
var up_gIUH_2=3752;
var up_gIUH_3=3753;
var up_gH_1=3754;
var up_ae_se_1=3755;
var up_ai_se_2=3756;
var up_ae_se_3=3757;
var up_ae_wic_1=3758;
var up_ae_wic_2=3759;
var _Advanced_02=3760;
var up_fm_dc_1=3761;
var up_fm_re_1=3762;
var up_fm_re_2=3763;
var up_fm_dr_1=3764;
var up_fm_dr_2=3765;
var up_fm_dr_3=3766;
var up_if_1=3767;
var up_rb_3=3768;
var up_rb_6=3769;
var up_vp_1=3770;
var up_vp_2=3771;
var up_vp_3=3772;
var up_vp_0=3773;
var up_vm_1=3774;
var up_vm_2=3775;
var up_he_1=3776;
var up_he_2=3777;
var up_he_5=3778;
var gw_sa_5=3779;
var IPSTACK_REJECTED_SPOOFED_PACKET=3780;
var IPDHCPSERVER_HOST_IS_ACTIVE=3781;
var BSECURE_LOG_AUTH_FAIL_UNREG=3782;
var RATE_ESTIMATOR_RATE_IS=3783;
var GW_IPFILTER_DENY=3784;
var GW_SMTP_EMAIL_CANNOT_CREATE_CONNECTION=3785;
var IPNAT_ILLEGAL_DEST=3786;
var BSECURE_LOG_FLTR_DISCONNECTED_TIMEOUT=3787;
var IPDHCPSERVER_LEASE_REVOKED1=3788;
var LOG_PREV_MSG_REPEATED_1_TIME=3789;
var GW_UPNP_PORTMAP_VS_CHANGE=3790;
var IPDHCPSERVER_LEASE_EXPIRED=3791;
var BSECURE_LOG_AUTH_FAIL_INTNL=3792;
var GW_UPNP_PORTMAP_DEL=3793;
var GW_SMTP_EMAIL_INVALID_TO_ADDRESS=3794;
var BSECURE_LOG_FLTR_DISCONNECTED_CLOSED=3795;
var IPDHCPSERVER_LEASE_EXPIRED_SPECIFIC=3796;
var BSECURE_LOG_AUTH_PASS=3797;
var BSECURE_LOG_AUTH_FAIL_UNKNW=3798;
var wwan_auth_pap=3799;
var BSECURE_LOG_AUTH_FAIL_RENEW=3800;
var IPDHCPSERVER_LEASE_DENIED=3801;
var GW_SMTP_EMAIL_TIMEOUT=3802;
var BSECURE_LOG_AUTH_FAIL_DB=3803;
var IPDHCPSERVER_PARAM_DB_UPDATED=3804;
var APP_RULES=3805;
var IPDHCPSERVER_LEASE_POOL_FULL=3806;
var IPPPPPAP_AUTH_SUCCESS=3807;
var ADVANCED_NETWORKS=3808;
var IPDHCPSERVER_LEASE_ASSIGNED=3809;
var BSECURE_LOG_FLTR_CONNECTED=3810;
var BSECURE_LOG_AUTH_CONNECTED=3811;
var BSECURE_LOG_AUTH_FAIL_PKT=3812;
var IPSMTPCLIENT_CONN_FAILED=3813;
var IPPPPPAP_AUTH_FAIL=3814;
var GW_LOG_ON_LATEST_FIRMWARE_RETRIEVED=3815;
var GW_SMTP_EMAIL_SEND_FAILURE=3816;
var IPDHCPSERVER_LEASE_RELEASED=3817;
var IPDHCPSERVER_PARAM_DB_ADDED=3818;
var IPPPPPAP_AUTH_TIMEOUT=3819;
var GW_UPNP_PORTMAP_ADD=3820;
var GW_SMTP_EMAIL_NO_SERVER_IP_ADDRESS=3821;
var GW_UPNP_PORTMAP_REFRESH=3822;
var GW_UPNP_PORTMAP_EXPIRE=3823;
var IPDHCPSERVER_PARAM_DB_REMOVED=3824;
var IPDHCPSERVER_LEASE_DELETED=3825;
var GW_UPNP_PORTMAP_CONFLICT=3826;
var TA1=3827;
var aa_alert_11=3828;
var aa_alert_1=3829;
var aa_sched_conf_3=3830;
var aa_alert_16=3831;
var aa_alert_2=3832;
var aa_alert_3=3833;
var aa_alert_4=3834;
var aa_alert_5=3835;
var aa_alert_6=3836;
var _aa_other_machines=3837;
var _copyright=3838;
var aw_alert_1=3839;
var aw_alert_2=3840;
var aw_alert_3=3841;
var aw_alert_4=3842;
var af_alert_1=3843;
var af_alert_2=3844;
var TA19=3845;
var ag_alert_4=3846;
var ag_alert_5=3847;
var ag_conflict10=3848;
var ag_conflict20=3849;
var ag_conflict21=3850;
var ag_alert_1=3851;
var ag_alert_3=3852;
var ag_alert2=3853;
var _tcpports=3854;
var _udpports=3855;
var ag_conflict4=3856;
var tsc_alert_7=3857;
var ai_alert_3=3858;
var GW_FIREWALL_NO_IP_RANGE_INVALID=3859;
var ai_alert_7=3860;
var ai_alert_4=3861;
var ai_alert_6=3862;
var tsc_alert_5=3863;
var ai_title_2=3864;
var _edit=3865;
var _srcip=3866;
var ai_c2=3867;
var ai_c3=3868;
var amaf_alert_1=3869;
var am_cMT_deny=3870;
var am_cMT_Allow=3871;
var _sr_nriy=3872;
var ar_alert_1=3873;
var ar_alert_2=3874;
var ar_alert_3=3875;
var ar_alert_4=3876;
var ar_alert_5=3877;
var ar_RoutI=3878;
var ar_Route=3879;
var ar_RoutesList=3880;
var _delete=3881;
var ar_ERTable=3882;
var ag_alert_duplicate_name=3883;
var ag_alert_duplicate=3884;
var ag_inuse=3885;
var _specapps_alert_2=3886;
var _specapps_tpr=3887;
var _specapps_ipr=3888;
var as_title_SAR=3889;
var as_TPRange=3890;
var as_ex=3891;
var as_TPR=3892;
var as_IPR=3893;
var as_IPrt=3894;
var at_alert_1_1=3895;
var at_alert_15=3896;
var at_alert_16=3897;
var at_alert_17=3898;
var at_alert_2=3899;
var at_alert_18=3900;
var at_alert_3=3901;
var at_alert_19=3902;
var at_alert_4=3903;
var at_alert_5=3904;
var at_alert_20=3905;
var at_alert_6=3906;
var at_alert_21=3907;
var at_alert_8=3908;
var at_alert_7=3909;
var at_alert_10=3910;
var at_alert_9=3911;
var at_alert_11=3912;
var at_alert_22=3913;
var at_alert_23=3914;
var at_alert_24=3915;
var at_alert_14=3916;
var at_Prot_0=3917;
var _srcport=3918;
var at_DIPR=3919;
var at_DPR=3920;
var av_alert_11=3921;
var av_alert_21=3922;
var av_alert_24=3923;
var av_alert_1=3924;
var av_alert_2=3925;
var av_alert_3=3926;
var av_alert_4=3927;
var av_alert_12=3928;
var av_alert_18=3929;
var av_alert_23=3930;
var av_alert_19=3931;
var av_alert_20=3932;
var av_alert_13=3933;
var av_alert_17=3934;
var av_alert_5=3935;
var av_alert_6=3936;
var av_alert_7=3937;
var av_alert_8=3938;
var av_alert_9=3939;
var av_alert_10=3940;
var _public=3941;
var at_Prot__1=3942;
var _private=3943;
var aa_WebSite=3944;
var awf_alert_4=3945;
var awf_alert_5=3946;
var awf_alert_7=3947;
var awf_alert_8=3948;
var int_ConWz2=3949;
var int_WlsWz=3950;
var hhbi_wiz=3951;
var hhbi_man=3952;
var bd_noneyet=3953;
var bd_revoked=3954;
var bln_alert_3=3955;
var bd_alert_10=3956;
var bd_alert_11=3957;
var bd_alert_1=3958;
var bd_alert_3=3959;
var bd_alert_13=3960;
var bd_alert_12=3961;
var bd_alert_5=3962;
var bd_alert_6=3963;
var bd_alert_7=3964;
var TA20=3965;
var bd_alert_8=3966;
var bd_alert_22=3967;
var bd_alert_23=3968;
var bd_alert_24=3969;
var _badWANIP=3970;
var bwn_alert_2=3971;
var bwn_alert_3=3972;
var bwn_alert_4=3973;
var bwn_alert_5=3974;
var MSG000=3975;
var bwn_alert_8=3976;
var bwn_alert_12=3977;
var _badPPTPip=3978;
var _badPPTPsub=3979;
var _badPPTPipsub=3980;
var bwn_alert_11=3981;
var _badL2TP3=3982;
var _badL2TP=3983;
var _badL2TP2=3984;
var bwn_alert_17=3985;
var bwn_alert_21=3986;
var bws_alert_15=3987;
var bws_alert_16=3988;
var bwl_alert_2=3989;
var bwl_alert_3=3990;
var bwl_alert_15=3991;
var bwl_alert_16=3992;
var bwl_alert_4=3993;
var bwl_alert_5=3994;
var bwl_alert_6=3995;
var bwl_alert_7=3996;
var bwl_alert_8=3997;
var bwl_alert_9=3998;
var bwl_alert_10=3999;
var bws_alert_2=4000;
var bwl_alert_11=4001;
var bwl_alert_12=4002;
var bws_alert_3=4003;
var aw_alert_5_1=4004;
var bwl_alert_13=4005;
var bwl_alert_14=4006;
var bwl_Mode_2=4007;
var bwl_Mode_3=4008;
var bwl_Mode_1=4009;
var bwl_Mode_8=4010;
var bwl_Mode_11=4011;
var bwl_ht20=4012;
var bwl_ht2040=4013;
var bwl_TxR_0=4014;
var TA9=4015;
var YM124=4016;
var TA12=4017;
var TA14=4018;
var TA15=4019;
var _wizard=4020;
var bwz_LConWz=4021;
var bwz_WlsWz=4022;
var bwz_intro_WlsWz=4023;
var bwz_LWlsWz=4024;
var _specapps=4025;
var _gaming=4026;
var _basic=4027;
var ag_alert_empty_name=4028;
var ag_alert_duplicate_name2=4029;
var amaf_alert_2=4030;
var specapps_alert_duplicate_name=4031;
var specapps_alert_duplicate1=4032;
var specapps_alert_conflict1=4033;
var specapps_alert_empty_schedule=4034;
var at_title_TSSet=4035;
var av_alert_35=4036;
var av_alert_empty_name=4037;
var av_alert_16=4038;
var bln_alert_lannbpri=4039;
var bln_alert_lannbsec=4040;
var lan_dns=4041;
var lan_dns2=4042;
var bln_NetBIOSReg_H=4043;
var bln_NetBIOSReg_M=4044;
var bln_NetBIOSReg_P=4045;
var bln_NetBIOSReg_B=4046;
var _help=4047;
var help81ets=4048;
var af_EFT_h4=4049;
var YM134=4050;
var af_EFT_h1=4051;
var af_EFT_h2=4052;
var af_EFT_h5=4053;
var af_UEFT_h1=4054;
var af_TEFT_h2=4055;
var help309A=4056;
var help400_1=4057;
var help401_1=4058;
var help402_1=4059;
var help402_2=4060;
var help405_1=4061;
var help405_2=4062;
var help405_3=4063;
var help405_4=4064;
var _sdi_s1a=4065;
var ta_alert_3b=4066;
var ta_alert_3c=4067;
var ta_alert_3d=4068;
var ta_alert_3e=4069;
var ta_alert_3f=4070;
var ta_alert_3g=4071;
var tps_enlpd=4072;
var ta_LMAP=4073;
var fb_FailLogin=4074;
var fb_FailLogin_1=4075;
var _open=4076;
var _other=4077;
var _223=4078;
var _225ap=4079;
var _226ap=4080;
var _1044wired=4081;
var _1044awired=4082;
var TEXT0=4083;
var regenerate=4084;
var _title_AdvDns=4085;
var _desc_AdvDns=4086;
var ta_EUPNP_dns=4087;
var _st_AdvDns=4088;
var _sp_title_AdvDNS=4089;
var _sp_desc1_AdvDNS=4090;
var _sp_desc2_AdvDNS=4091;
var _sp_desc3_AdvDNS=4092;
var _sp_desc4_AdvDNS=4093;
var TEXT041_1=4094;
var TEXT041_2=4095;
var TEXT041_3=4096;
var TEXT041_4=4097;
var TEXT042_1=4098;
var TEXT042_2=4099;
var GW_URL_INVALID=4100;
var GW_LAN_NETBIOS_SCOPE_INVALID=4101;
var GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID_a=4102;
var bwn_Mode_DHCPPLUS=4103;
var net_sniper_support=4104;
var SEL_DIAL_MODE=4105;
var pppoe_dialmode_normal=4106;
var pppoe_dialmode_sp1=4107;
var pppoe_dialmode_sp2=4108;
var pppoe_dialmode_sp3=4109;
var pppoe_dialmode_sp4=4110;
var pppoe_dialmode_sp5=4111;
var pppoe_dialmode_sp6=4112;
var pppoe_dialmode_learn=4113;
var bt_learn_text=4114;
var box_ip_mac_binding=4115;
var _en_AdvDns=4116;
var xkjs_support=4117;
var ddns_serv_type=4118;
var ddns_domain=4119;
var ddns_account=4120;
var virtual_pub_port_err=4121;
var virtual_pri_port_err=4122;
var virtual_proto_num_err=4123;
var menu_wps=4124;
var tc_iprange=4125;
var help823_15=4126;
var tc_bw=4127;
var tc_schedule=4128;
var tc_new_sch=4129;
var tc_min_bw=4130;
var tc_max_bw=4131;
var _login_admin=4132;
var _login_user=4133;
var pppoe_plus_dail=4134;
var GW_WAN_DHCPPLUS_USERNAME_INVALID=4135;
var GW_WAN_DHCPPLUS_PASSWORD_INVALID=4136;
var te_SMTPPort=4137;
var WLANMODE=4138;
var ROUTER_MODE=4139;
var AP_MODE=4140;
var WDSROUTER_MODE=4141;
var WDSAP_MODE=4142;
var BR_SET=4143;
var device_mode=4144;
var router_mode=4145;
var ap_mode=4146;
var auto_mode=4147;
var enable_WDS=4148;
var ES_AUTODECT=4149;
var _phone=4150;
var ES_CABLELOST_dsc2=4151;
var ES_DONT_CONN_btn=4152;
var ES_UPDATE_SETTING_bnr=4153;
var ES_UPDATE_SETTING_dsc=4154;
var ES_CONFIG_INTERNET_bnr=4155;
var ES_CONFIG_INTERNET_dsc2=4156;
var ES_INTERNET_CONN_dsc=4157;
var ES_MUST_FIELD_dsc=4158;
var ES_DIALUP_ERROR_bnr=4159;
var usb_config1=4160;
var ES_NAME=4161;
var MSG011=4162;
var ES_what_is_this=4163;
var ES_PRI_DNS=4164;
var ES_SEC_DNS=4165;
var ES_GW_ADDR=4166;
var ES_MASK=4167;
var ES_IP_ADDR=4168;
var ES_complete=4169;
var ES_save_dsc=4170;
var ES_status=4171;
var ES_connected=4172;
var ES_unconnected=4173;
var ES_wlan_setting=4174;
var ES_wlan_ssid=4175;
var ES_security=4176;
var ES_unsecured=4177;
var ES_unsecured_suggest=4178;
var ES_save_mySetting=4179;
var ES_sync_pw=4180;
var ES_save=4181;
var ES_network_key=4182;
var ES_autogen_key=4183;
var ES_disable_wifi_sec=4184;
var ES_wifi_sec_recomm=4185;
var ES_current_setting_dsc=4186;
var ES_current_setting=4187;
var ES_manual_btn=4188;
var ES_cancel=4189;
var logout_caption=4190;
var logout_desc=4191;
var logout_return=4192;
var st_connected_time=4193;
var t_ctl_title=4194;
var t_ctl_note=4195;
var t_ctl_note1=4196;
var page_title=4197;
var ac_alert_invalid_port=4198;
var ac_alert_dup_name=4199;
var ac_alert_port_conflit=4200;
var ac_alert_policy_null=4201;
var tt_alert_checkdyndns=4202;
var ES_static_no_internet=4203;
var ES_static_no_internet_desc=4204;
var _CFM_close_window=4205;
var ES_save_result=4206;
var ES_save_success=4207;
var ES_confirm_bt=4208;
var sch_timeformat=4209;
var sch_hourfmt_12=4210;
var sch_hourfmt_24=4211;
var no_available_update=4212;
var clear_lang_pack=4213;
var current_lang_pack_version=4214;
var current_lang_pack_date=4215;
var lang_package_info=4216;
var lang_package_note1=4217;
var lang_package_note2=4218;
var latest_lang_package_ver=4219;
var latest_lang_package_date=4220;
var no_lang_pack=4221;
var pf_name_empty=4222;
var vs_name_empty=4223;
var fw_checksum_err=4224;
var fw_bad_hwid=4225;
var fw_unknow_file_format=4226;
var fw_fw_upgrade_success=4227;
var fw_lp_upgrade_success=4228;
var fw_cfg_upgrade_success=4229;
var ES_timectrl_bnr=4230;
var ES_timectrl_btn=4231;
var ES_webpolicy_btn=4232;
var HW_NAT_desc=4233;
var at_ETS=4234;
var alert_hw_nat_1=4235;
var alert_hw_nat_2=4236;
var alert_hw_nat_3=4237;
var help_auto_disable_hw_nat=4238;
var help_auto_disable_hw_nat_1=4239;
var help_hw_nat=4240;
var help_hw_nat_desc=4241;
var ES_step_wifi_security=4242;
var _pwsame_user=4243;
var ES_btn_try_again=4244;
var ES_auto_detect_desc=4245;
var ES_auto_detect_failed_desc=4246;
var ES_btn_guide_me=4247;
var ES_btn_save_conn=4248;
var ES_btn_save=4249;
var v6_routing=4250;
var v6_routing_table=4251;
var v6_routing_info=4252;
var ipv6=4253;
var ipv6_firewall=4254;
var ipv6_firewall_info=4255;
var _6rd_settings=4256;
var ipv4_addr=4257;
var mask_len=4258;
var IPV6_ULA_TEXT01=4259;
var HW_NAT_enable=4260;
var IPV6_ULA_TEXT03=4261;
var IPV6_ULA_TEXT04=4262;
var IPV6_ULA_TEXT05=4263;
var IPV6_ULA_TEXT06=4264;
var IPV6_ULA_TEXT07=4265;
var IPV6_ULA_TEXT08=4266;
var IPV6_ULA_TEXT09=4267;
var IPV6_ULA_TEXT11=4268;
var IPV6_ULA_TEXT12=4269;
var IPV6_ULA_TEXT13=4270;
var IPV6_ULA_TEXT14=4271;
var IPv6_Local_Info=4272;
var IPv6_Simple_Security=4273;
var anet_multicast_enable_v6=4274;
var IPv6_Wizard_6rd_title=4275;
var fr_name_empty=4276;
var r6_name_empty=4277;
var wwz_wwl_intro_s2_1=4278;
var wwz_wwl_intro_s2_1_1=4279;
var wwz_wwl_intro_s2_1_2=4280;
var wwz_wwl_intro_s2_2=4281;
var wwz_wwl_intro_s2_2_1=4282;
var wwz_wwl_intro_s2_2_2=4283;
var ES_title_s3=4284;
var ES_title_s4=4285;
var ES_title_s5=4286;
var bwl_Mode_n=4287;
var bwl_Mode_a=4288;
var bwl_Mode_5=4289;
var MSG049=4290;
var MSG050=4291;
var HWerr=4292;
var storage=4293;
var sto_into=4294;
var sto_http_0=4295;
var bwn_RPing=4296;
var guestzone_enable=4297;
var sto_http_3=4298;
var LV2=4299;
var sto_http_5=4300;
var sto_creat=4301;
var _add_edit=4302;
var sto_list=4303;
var _modify=4304;
var sto_path=4305;
var help361=4306;
var tt_NTPSrvU=4307;
var sto_dev=4308;
var _total_space=4309;
var _free_space=4310;
var sto_link_0=4311;
var sto_link_1=4312;
var sto_link_2=4313;
var _email_now=4314;
var sto_help=4315;
var _DevLink=4316;
var _folder=4317;
var _browse=4318;
var _append=4319;
var sto_01=4320;
var sto_02=4321;
var _readonly=4322;
var _readwrite=4323;
var _AppendNewFolder=4324;
var KR45=4325;
var MSG052=4326;
var MSG053=4327;
var MSG054=4328;
var _AddFolder=4329;
var _StorageLink=4330;
var LW6_1=4331;
var MSG055=4332;
var ES_title_s5_0=4333;
var save_settings=4334;
var save_wait=4335;
var _Language=4336;
var manul_conn_01=4337;
var manul_conn_02=4338;
var manul_conn_03=4339;
var manul_conn_04=4340;
var manul_conn_05=4341;
var manul_conn_06=4342;
var manul_conn_07=4343;
var manul_conn_08=4344;
var manul_conn_09=4345;
var manul_conn_10=4346;
var manul_conn_11=4347;
var manul_conn_12=4348;
var _aa_bsecure_opinion=4349;
var manul_conn_14=4350;
var manul_conn_15=4351;
var manul_conn_16=4352;
var manul_conn_17=4353;
var manul_conn_18=4354;
var manul_conn_19=4355;
var manul_conn_20=4356;
var manul_conn_21=4357;
var manul_conn_22=4358;
var manul_conn_23=4359;
var manul_conn_24=4360;
var manul_conn_25=4361;
var manul_5g_ssid=4362;
var tf_intro_FWU4=4363;
var tf_intro_FWU5=4364;
var _firmwareUpdate=4365;
var _date=4366;
var _remove=4367;
var notify_wps=4368;
var ag_conflict5=4369;
var _disable=4370;
var coexi=4371;
var wwl_SSP=4372;
var wwz_wwl_intro_s0=4373;
var STATUS_IPV6_DESC_0=4374;
var STATUS_IPV6_DESC_1=4375;
var STATUS_IPV6_DESC_6=4376;
var STATUS_IPV6_DESC_5=4377;
var STATUS_IPV6_DESC_4=4378;
var STATUS_IPV6_DESC_3=4379;
var STATUS_IPV6_DESC_2=4380;
var ag_conflict6=4381;
var TEXT008a=4382;
var TEXT008b=4383;
var TEXT023=4384;
var at_mbps=4385;
var pin_f=4386;
var msg_eap=4387;
var open=4388;
var PRIVATE_PORT_ERROR=4389;
var MSG056=4390;
var MSG057=4391;
var _DestIP=4392;
var _type=4393;
var mydlink_tx03=4394;
var mydlink_tx05=4395;
var sec_left=4396;
var ES_CONN_dsc=4397;
var chk_pass=4398;
var Lname=4399;
var Fname=4400;
var _login=4401;
var ag_conflict22=4402;
var ag_conflict23=4403;
var wifi_enable_chk=4404;
var ZERO_IPV6_ADDRESS=4405;
var port_empty=4406;
var _disable_s=4407;
var IPV6_TEXT154=4408;
var _signup=4409;
var up_tz_74=4410;
var wifi_pass_chk=4411;
var _remove_multi=4412;
var tf_really_langf=4413;
var tf_langf=4414;
var ub_intro_l1=4415;
var ub_intro_l3=4416;
var err404_title=4417;
var err404_detect=4418;
var err404_sug=4419;
var err404_sug1=4420;
var err404_sug2=4421;
var err404_sug3=4422;
var err404_sug4=4423;
var err404_sug5=4424;
var tsc_end_time=4425;
var remote_port_msg=4426;
var TEXT034=4427;
var LW39b=4428;
var _nousername=4429;
var metric_empty=4430;
var TEXT061=4431;
var ES_DIALUP_ERROR_dsc=4432;
var MSG001=4433;
var MSG051=4434;
var MSG012=4435;
var aa_alert_13=4436;
var TEXT044=4437;
var sto_03=4438;
var up_nosave=4439;
var ta_msg_TW=4440;
var sto_04=4441;
var IPV6_TEXT167=4442;
var IPV6_TEXT170=4443;
var help_171=4444;
var DDNS_HOST_ERROR=4445;
var _item_no=4446;
var _usb_not_found=4447;
var srv_name_empty=4448;
var msg_wps_sec_01=4449;
var msg_wps_sec_02=4450;
var msg_wps_sec_03=4451;
var sh_port_tx_00a=4452;
var sh_port_tx_00b=4453;
var sh_port_tx_00=4454;
var sh_port_tx_01=4455;
var sh_port_tx_02=4456;
var sh_port_tx_03=4457;
var sh_port_tx_04=4458;
var sh_port_tx_05=4459;
var sh_port_tx_06=4460;
var sh_port_tx_07=4461;
var sh_port_tx_08=4462;
var sh_port_tx_09=4463;
var sh_port_tx_10=4464;
var sh_port_ddns_01=4465;
var sh_port_ddns_02=4466;
var sh_port_ddns_03=4467;
var sh_port_tx_11=4468;
var sh_port_tx_12=4469;
var sh_port_tx_13=4470;
var sh_port_tx_16=4471;
var sh_port_tx_17=4472;
var sh_port_tx_18=4473;
var sh_port_tx_19=4474;
var sh_port_tx_20=4475;
var sh_port_tx_21=4476;
var sh_port_msg_01=4477;
var sh_port_msg_02=4478;
var sh_port_msg_04=4479;
var sh_port_msg_05=4480;
var sh_port_msg_06=4481;
var sh_port_msg_07=4482;
var sh_port_msg_08=4483;
var sh_port_msg_09=4484;
var sto_http_6=4485;
var file_acc_del_user=4486;
var file_acc_del_path=4487;
var file_acc_del_file=4488;
var _login_a=4489;
var IPv6_ddns_01=4490;
var IPv6_ddns_02=4491;
var IPv6_fw_01=4492;
var IPv6_fw_02=4493;
var IPv6_fw_03=4494;
var IPv6_fw_04=4495;
var IPv6_fw_ipr=4496;
var IPv6_fw_pr=4497;
var IPv6_fw_sr=4498;
var IPv6_fw_dest=4499;
var IPv6_6rd_relay=4500;
var IPv6_6rd_wan=4501;
var IPv6_6to4_relay=4502;
var IPv6_addrSr=4503;
var IPv6_addrEr=4504;
var msg_wps_sec_04=4505;
var msg_wait_sec=4506;
var file_acc_del_empty=4507;
var IPV6_TEXT161a=4508;
var ss_Wstats_2=4509;
var ss_Wstats_5g=4510;
var dlna_t=4511;
var dlna_01=4512;
var dlna_02=4513;
var dlna_03=4514;
var rus_wan_pptp=4515;
var rus_wan_pptp_01=4516;
var rus_wan_l2tp=4517;
var rus_wan_l2tp_01=4518;
var rus_wan_pppoe=4519;
var rus_wan_pppoe_02=4520;
var rus_wan_pppoe_03=4521;
var msg_wps_sec_05=4522;
var webf_login=4523;
var webf_intro=4524;
var webf_title=4525;
var webf_folder=4526;
var webf_hd=4527;
var webf_createfd=4528;
var webf_fd_name=4529;
var webf_upload=4530;
var webf_file_sel=4531;
var dlna_t1=4532;
var dlna_t2=4533;
var help_stor1=4534;
var help_stor2=4535;
var help_stor3=4536;
var help_stor4=4537;
var help_stor5=4538;
var help_stor6=4539;
var help_stor7=4540;
var help_stor8=4541;
var help_stor9=4542;
var help_dlna1=4543;
var webf_non_hd=4544;
var sh_port_tx_22=4545;
var sh_port_tx_23=4546;
var IPv6_Ingress_Filtering_enable=4547;
var share_title_1=4548;
var share_title_2=4549;
var share_title_3=4550;
var share_title_4=4551;
var share_ser_1=4552;
var share_ser_2=4553;
var share_ser_3=4554;
var share_ser_4=4555;
var ddns_disconnecting=4556;
var lan_reserveIP=4557;
var end_ip=4558;
var _NULL=4559;
var ddns_sel2=4560;
var ddns_sel3=4561;
var _remoteipaddr=4562;
var _back=4563;
var _ping_fail=4564;
var _ping_success=4565;
var _wz_disWPS=4566;
var limit_pass_msg=4567;
var _gz_wps_enable=4568;
var _gz_wps_deny=4569;
var bwl_ht204080=4570;
var _supp_close=4571;
var bwl_Mode_ac=4572;
var bwl_Mode_acn=4573;
var bwl_Mode_acna=4574;
var _wireless_2=4575;
var _wireless_5=4576;
var _WPS=4577;
var _statlst=4578;
var _wifiser_title=4579;
var _wifiser_title0=4580;
var _wifiser_title1=4581;
var _wifiser_mode0=4582;
var _wifiser_mode1=4583;
var _wifiser_mode2=4584;
var _wifiser_mode3=4585;
var _wifiser_mode4=4586;
var _wifiser_mode5=4587;
var _wifiser_mode6=4588;
var _wifiser_mode7=4589;
var _wifiser_mode8=4590;
var _wifiser_mode9=4591;
var _wifiser_mode10=4592;
var _wifiser_mode11=4593;
var _wifiser_mode12=4594;
var _wifiser_mode13=4595;
var _wifiser_mode14=4596;
var _wifiser_mode15=4597;
var _wifiser_mode16=4598;
var _wifiser_mode17=4599;
var _wifiser_mode18=4600;
var _wifiser_mode19=4601;
var _wifiser_mode20=4602;
var _wifiser_mode21=4603;
var _wifiser_mode22=4604;
var _wifiser_mode23=4605;
var _wifiser_mode24=4606;
var _wifiser_mode25=4607;
var _wifiser_mode26=4608;
var _wifiser_mode27=4609;
var _wifiser_mode28=4610;
var _wifiser_mode29=4611;
var _wifiser_mode30=4612;
var _wifiser_mode31=4613;
var _wifiser_mode32=4614;
var _wifiser_mode33=4615;
var _wifiser_mode34=4616;
var _wifiser_mode35=4617;
var _wifiser_mode36=4618;
var _wifiser_mode37=4619;
var _wifiser_mode38=4620;
var _wifiser_mode39=4621;
var _wifiser_mode40=4622;
var _wifiser_mode41=4623;
var _adv_txt_00=4624;
var _adv_txt_01=4625;
var _adv_txt_02=4626;
var _adv_txt_03=4627;
var _adv_txt_04=4628;
var _adv_txt_05=4629;
var _adv_txt_06=4630;
var _adv_txt_07=4631;
var _adv_txt_08=4632;
var _adv_txt_09=4633;
var _adv_txt_10=4634;
var _adv_txt_11=4635;
var _adv_txt_12=4636;
var _adv_txt_13=4637;
var _adv_txt_14=4638;
var _adv_txt_15=4639;
var _adv_txt_16=4640;
var _adv_txt_17=4641;
var _adv_txt_18=4642;
var _adv_txt_19=4643;
var _adv_txt_20=4644;
var _adv_txt_21=4645;
var _adv_txt_22=4646;
var _network=4647;
var _management=4648;
var _upload_firm=4649;
var _settings_management=4650;
var _time_cap=4651;
var _system_log=4652;
var _ipv6_status=4653;
var _alg=4654;
var _wan_setting=4655;
var _lan_setting=4656;
var _ipv6_setting=4657;
var _top=4658;
var _network_help=4659;
var _qos_help=4660;
var _wireless_help=4661;
var _administrator_help=4662;
var _wan_conn_type=4663;
var _help_txt2=4664;
var _static=4665;
var _help_txt1=4666;
var _help_txt4=4667;
var _help_txt6=4668;
var _help_txt7=4669;
var _help_txt9=4670;
var _help_txt10=4671;
var _help_txt11=4672;
var _help_txt12=4673;
var _help_txt13=4674;
var _help_txt14=4675;
var _help_txt16=4676;
var _help_txt17=4677;
var _help_txt18=4678;
var _help_txt19=4679;
var _help_txt20=4680;
var _help_txt21=4681;
var _help_txt22=4682;
var _help_txt24=4683;
var _help_txt25=4684;
var _help_txt27=4685;
var _help_txt28=4686;
var _help_txt29=4687;
var _help_txt30=4688;
var _help_txt31=4689;
var _help_txt32=4690;
var _help_txt33=4691;
var _help_txt34=4692;
var _help_txt35=4693;
var _help_txt36=4694;
var _help_txt37=4695;
var _help_txt38=4696;
var _help_txt39=4697;
var _help_txt41=4698;
var _help_txt43=4699;
var _help_txt45=4700;
var _help_txt47=4701;
var _help_txt48=4702;
var _help_txt50=4703;
var _help_txt51=4704;
var _help_txt52=4705;
var _help_txt54=4706;
var _help_txt56=4707;
var _help_txt58=4708;
var _help_txt59=4709;
var _help_txt60=4710;
var _help_txt62=4711;
var _help_txt64=4712;
var _help_txt66=4713;
var _help_txt67=4714;
var _help_txt69=4715;
var _help_txt71=4716;
var _help_txt73=4717;
var _help_txt85=4718;
var _help_txt87=4719;
var _help_txt82=4720;
var _help_txt83=4721;
var _help_txt84=4722;
var _help_txt85=4723;
var _help_txt89=4724;
var _help_txt90=4725;
var _help_txt91=4726;
var _help_txt93=4727;
var _help_txt94=4728;
var _help_txt95=4729;
var _help_txt96=4730;
var _help_txt97=4731;
var _help_txt98=4732;
var _help_txt99=4733;
var _help_txt100=4734;
var _help_txt101=4735;
var _help_txt102=4736;
var _help_txt103=4737;
var _help_txt104=4738;
var _help_txt105=4739;
var _help_txt106=4740;
var _help_txt107=4741;
var _help_txt108=4742;
var _help_txt109=4743;
var _help_txt110=4744;
var _help_txt111=4745;
var _help_txt113=4746;
var _help_txt114=4747;
var _help_txt115=4748;
var _help_txt116=4749;
var _help_txt117=4750;
var _help_txt121=4751;
var _help_txt122=4752;
var _help_txt123=4753;
var _help_txt124=4754;
var _help_txt125=4755;
var _help_txt126=4756;
var _help_txt127=4757;
var _help_txt128=4758;
var _help_txt129=4759;
var _help_txt130=4760;
var _help_txt131=4761;
var _help_txt132=4762;
var _help_txt133=4763;
var _help_txt134=4764;
var _help_txt135=4765;
var _help_txt136=4766;
var _help_txt137=4767;
var _help_txt138=4768;
var _help_txt139=4769;
var _help_txt140=4770;
var _help_txt141=4771;
var _help_txt142=4772;
var _help_txt143=4773;
var _help_txt144=4774;
var _help_txt145=4775;
var _help_txt146=4776;
var _help_txt147=4777;
var _help_txt148=4778;
var _help_txt149=4779;
var _help_txt150=4780;
var _help_txt151=4781;
var _help_txt152=4782;
var _help_txt153=4783;
var _help_txt154=4784;
var _help_txt155=4785;
var _help_txt156=4786;
var _help_txt157=4787;
var _help_txt158=4788;
var _help_txt159=4789;
var _help_txt160=4790;
var _help_txt161=4791;
var _help_txt162=4792;
var _help_txt163=4793;
var _help_txt164=4794;
var _help_txt165=4795;
var _help_txt166=4796;
var _help_txt167=4797;
var _help_txt168=4798;
var _help_txt169=4799;
var _help_txt170=4800;
var _help_txt171=4801;
var _help_txt172=4802;
var _help_txt173=4803;
var _help_txt174=4804;
var _help_txt175=4805;
var _help_txt176=4806;
var _help_txt177=4807;
var _help_txt178=4808;
var _help_txt179=4809;
var _help_txt180=4810;
var _help_txt181=4811;
var _help_txt182=4812;
var _help_txt183=4813;
var _help_txt184=4814;
var _help_txt185=4815;
var _help_txt186=4816;
var _help_txt187=4817;
var _help_txt188=4818;
var _help_txt189=4819;
var _help_txt190=4820;
var _help_txt191=4821;
var _help_txt192=4822;
var _help_txt193=4823;
var _help_txt194=4824;
var _help_txt195=4825;
var _help_txt196=4826;
var _help_txt197=4827;
var _help_txt198=4828;
var _help_txt199=4829;
var _help_txt200=4830;
var _help_txt201=4831;
var _help_txt202=4832;
var _help_txt203=4833;
var _help_txt204=4834;
var _help_txt205=4835;
var _help_txt206=4836;
var _help_txt207=4837;
var _help_txt208=4838;
var _help_txt209=4839;
var _help_txt210=4840;
var _help_txt211=4841;
var _help_txt212=4842;
var _help_txt213=4843;
var _help_txt214=4844;
var _help_txt215=4845;
var _help_txt216=4846;
var _help_txt217=4847;
var _help_txt218=4848;
var _help_txt219=4849;
var _help_txt220=4850;
var _help_txt221=4851;
var _help_txt222=4852;
var _help_txt223=4853;
var _help_txt224=4854;
var _help_txt225=4855;
var _help_txt226=4856;
var _help_txt227=4857;
var _help_txt228=4858;
var _help_txt229=4859;
var _help_txt230=4860;
var _help_txt231=4861;
var _help_txt232=4862;
var _help_txt233=4863;
var _help_txt234=4864;
var _help_txt235=4865;
var _help_txt236=4866;
var _help_txt237=4867;
var _help_txt238=4868;
var _help_txt239=4869;
var _help_txt240=4870;
var _help_txt241=4871;
var _help_txt242=4872;
var _help_txt243=4873;
var _help_txt244=4874;
var _help_txt245=4875;
var _help_txt246=4876;
var _help_txt247=4877;
var _help_txt248=4878;
var _help_txt249=4879;
var _help_txt250=4880;
var _help_txt251=4881;
var _help_txt252=4882;
var _help_txt253=4883;
var _help_txt254=4884;
var _help_txt255=4885;
var _help_txt256=4886;
var _help_txt257=4887;
var _help_txt258=4888;
var _help_txt259=4889;
var _help_txt260=4890;
var _help_txt261=4891;
var _help_txt262=4892;
var _help_txt263=4893;
var _help_txt264=4894;
var _help_txt265=4895;
var _help_txt266=4896;
var _help_txt267=4897;
var _help_txt268=4898;
var _help_txt269=4899;
var _help_txt270=4900;
var _help_txt271=4901;
var _help_txt272=4902;
var _help_txt273=4903;
var _help_txt274=4904;
var _help_txt275=4905;
var _help_txt276=4906;
var _help_txt277=4907;
var _help_txt278=4908;
var _help_txt279=4909;
var _help_txt280=4910;
var _help_txt281=4911;
var _help_txt282=4912;
var _help_txt283=4913;
var _help_txt284=4914;
var _help_txt285=4915;
var _help_txt286=4916;
var _help_txt287=4917;
var _help_txt288=4918;
var _help_txt289=4919;
var _help_txt290=4920;
var _help_txt291=4921;
var _help_txt292=4922;
var _help_txt293=4923;
var _help_txt294=4924;
var _help_txt295=4925;
var _help_txt296=4926;
var _help_txt297=4927;
var _help_txt298=4928;
var _adv_txt_23=4929;
var _adv_txt_24=4930;
var _adv_txt_25=4931;
var _adv_txt_26=4932;
var _adv_txt_27=4933;
var _net_ipv6_01=4934;
var _net_ipv6_02=4935;
var _net_ipv6_03=4936;
var _net_ipv6_04=4937;
var _net_ipv6_05=4938;
var _net_ipv6_06=4939;
var _net_ipv6_07=4940;
var _net_ipv6_08=4941;
var _net_ipv6_09=4942;
var _net_ipv6_10=4943;
var _net_ipv6_11=4944;
var _net_ipv6_12=4945;
var _qos_txt00=4946;
var _qos_txt01=4947;
var _qos_txt02=4948;
var _qos_txt03=4949;
var _qos_txt04=4950;
var _qos_txt05=4951;
var _qos_txt06=4952;
var _qos_txt07=4953;
var _qos_txt08=4954;
var _qos_txt09=4955;
var _qos_txt10=4956;
var _qos_txt11=4957;
var _qos_txt12=4958;
var _qos_txt13=4959;
var _qos_txt14=4960;
var _qos_txt15=4961;
var _qos_txt16=4962;
var _qos_txt17=4963;
var _qos_txt18=4964;
var _qos_txt19=4965;
var _qos_txt20=4966;
var _qos_txt21=4967;
var _qos_txt22=4968;
var _qos_txt23=4969;
var _qos_txt24=4970;
var _qos_txt25=4971;
var _qos_txt26=4972;
var _qos_txt27=4973;
var _qos_txt28=4974;
var _qos_txt29=4975;
var _qos_txt30=4976;
var _qos_txt31=4977;
var _qos_txt32=4978;
var _qos_txt33=4979;
var _qos_txt34=4980;
var _qos_txt35=4981;
var _qos_txt36=4982;
var _qos_txt37=4983;
var _qos_txt38=4984;
var _qos_txt39=4985;
var _qos_txt40=4986;
var _qos_txt41=4987;
var _qos_txt42=4988;
var _qos_txt43=4989;
var _qos_txt44=4990;
var _qos_txt45=4991;
var _qos_txt46=4992;
var _basic_wireless_settings=4993;
var _desc_basic=4994;
var _desc_station_list=4995;
var _desc_wps=4996;
var _wireless_network=4997;
var _wds_long=4998;
var _wps_config=4999;
var _wps_summary=5000;
var _wps_action=5001;
var _dhcp_clients=5002;
var _desc_wps_action=5003;
var _lb_radio_onoff=5004;
var _lb_radio_off_sche=5005;
var _wmode_ssid=5006;
var _lb_multi_ssid_1=5007;
var _lb_multi_ssid_2=5008;
var _lb_multi_ssid_3=5009;
var _lb_multi_ssid_4=5010;
var _lb_multi_ssid_5=5011;
var _lb_multi_ssid_6=5012;
var _lb_multi_ssid_7=5013;
var _lb_broadcast_ssid=5014;
var _lb_phy_mode=5015;
var _lb_enc_type=5016;
var _lb_enc_key=5017;
var _lb_apmacaddr=5018;
var _lb_coexistence=5019;
var _lb_rdg=5020;
var _lb_mcs=5021;
var _lb_exten_channel=5022;
var _lb_a_msdu=5023;
var _lb_autoba=5024;
var _lb_declineba=5025;
var _lb_forty_into=5026;
var _lb_wifi_opt=5027;
var _lb_ht_txstream=5028;
var _lb_ht_rxstream=5029;
var _lb_wps_ext_reg_lock=5030;
var _sel_autoselect=5031;
var _sel_mixed=5032;
var _sel_greenfield=5033;
var _long=5034;
var _btn_radio_on=5035;
var _btn_radio_off=5036;
var _MSG_woff=5037;
var _desc_advanced=5038;
var _bx_advanced_2=5039;
var _bx_advanced_3=5040;
var _bx_advanced_4=5041;
var _lb_bg_protection=5042;
var _hint_beacon=5043;
var _hint_dtim=5044;
var _lb_frag_thres=5045;
var _hint_frag_thres=5046;
var _hint_rts_thres=5047;
var _lb_txpower=5048;
var _lb_short_preamble=5049;
var _lb_short_slot=5050;
var _lb_tx_burst=5051;
var _lb_pkt_aggregate=5052;
var _lb_80211h_support=5053;
var _hint_only_a_band=5054;
var _lb_country_code=5055;
var _lb_wmm_capable=5056;
var _lb_apsd_capable=5057;
var _lb_dls_capable=5058;
var _lb_wmm_param=5059;
var _lb_wmm_config=5060;
var _lb_video_turbine=5061;
var _lb_multi_uni=5062;
var _lb_expire_in=5063;
var _pwr_full=5064;
var _pwr_half=5065;
var _pwr_low=5066;
var _tl_wmm_settings=5067;
var _lb_wmm_param_ap=5068;
var _lb_wmm_param_station=5069;
var m_bwl_Mode_3=5070;
var m_bwl_Mode_8=5071;
var m_bwl_Mode_11=5072;
var m_bwl_Mode5_1=5073;
var m_bwl_Mode5_2=5074;
var m_bwl_Mode5_3=5075;
var _singal=5076;
var _bssid=5077;
var _wps_cur_state=5078;
var _wps_configed=5079;
var _wps_ssid=5080;
var _wps_sec_mode=5081;
var _wps_enc_type=5082;
var _wps_def_key_idx=5083;
var _hex=5084;
var _ascii=5085;
var _wps_key=5086;
var _ap_pin=5087;
var _desc_dhcp_client_list=5088;
var _wifiser_mode42=5089;
var _processing=5090;
var _netwrk_status_addr=5091;
var _system_info=5092;
var _system_time=5093;
var _system_up_time=5094;
var _internet_configs=5095;
var _connected_type=5096;
var _wan_ip_addr=5097;
var _pri_dns=5098;
var _sec_dns=5099;
var _24Ghz_wireless=5100;
var _5Ghz_wireless=5101;
var _SYSLOG_DESC=5102;
var _enable_system_log=5103;
var _time_setting=5104;
var _TIME_DESC=5105;
var _daylight_saving_time=5106;
var _ntp_settings=5107;
var _ntp_server=5108;
var _ntp_sync=5109;
var _date_time_settings=5110;
var _SETTINGS_MANAGER_DESC=5111;
var _export=5112;
var _settings_file_location=5113;
var _import=5114;
var _upgrade_firmw=5115;
var _FIRMW_DESC=5116;
var _FIRMW_DESC_sub=5117;
var _location=5118;
var _apply=5119;
var _system_management=5120;
var _SYS_MANGER_DESC=5121;
var _max_length_characters=5122;
var _device_url_settings=5123;
var _device_url=5124;
var _device_name_settings=5125;
var _ddns_settings=5126;
var _remote_management=5127;
var _remote_control_via_wan=5128;
var _remote_port=5129;
var _reset=5130;
var _ADV_NETWRK_DESC=5131;
var _wan_ping_respond=5132;
var _schedule_rules=5133;
var _SCHEDULE_DESC=5134;
var _add_sche_rule=5135;
var _tsc_allday_24hr=5136;
var _schedule_rule_list=5137;
var _time_stamp=5138;
var _24hr=5139;
var m_bwl_Mode5_4=5140;
var _routing_bet_zone=5141;
var _mac_clone=5142;
var _mac_addr_clone=5143;
var _dns_server_setting=5144;
var _dhcp_setting=5145;
var _DHCP_DESC=5146;
var _wan_setting_l=5147;
var _mtu_default_byte=5148;
var _wan_if_ip_setting=5149;
var _opeartion_mode=5150;
var _keep_alive=5151;
var _keep_alive_mode_redial=5152;
var _on_demand_mode_idle_time=5153;
var _mintues_lower=5154;
var _l2tp_setting=5155;
var _pptp_setting=5156;
var _dynamic=5157;
var _lan_setting_l=5158;
var _LAN_DESC=5159;
var _dhcp_server_setting=5160;
var _dhcp_start_ip=5161;
var _dhcp_end_ip=5162;
var _other_setting=5163;
var _8021d_spanning_tree=5164;
var _lltd=5165;
var _igmp_proxy=5166;
var _pppoe_relay=5167;
var _dns_proxy=5168;
var _add_dhcp_reservation=5169;
var _copy_pc_mac=5170;
var _copy=5171;
var _dhcp_reservation_ready_group=5172;
var _edit_dhcp_reservation=5173;
var _delete_all=5174;
var _delete_selected=5175;
var _config_via_pin=5176;
var _config_via_pbc=5177;
var _alg_config_l=5178;
var _ALG_DESC=5179;
var _description=5180;
var _email_receiving=5181;
var _pop3_l=5182;
var _smtp_l=5183;
var _streaming_media=5184;
var _rtp_l=5185;
var _rtsp_1=5186;
var _mms_l=5187;
var _streaming_media_voip=5188;
var _session_init_protocol_l=5189;
var _h323_l=5190;
var _file_transfer=5191;
var _ftp_l=5192;
var _tftp_l=5193;
var _remote_control=5194;
var _telnet=5195;
var _instant_messaging=5196;
var _msn_messenger=5197;
var _ipsec=5198;
var _save_status=5199;
var _dmz_settings=5200;
var _DMZ_DESC=5201;
var _AC_DESC=5202;
var _add_port_block_rule=5203;
var _policy_enable=5204;
var _policy_name=5205;
var _client_ip_addr=5206;
var _rule_define=5207;
var _special_service=5208;
var _user_define=5209;
var _tcp_ports=5210;
var _ex_21_or_3_500=5211;
var _udp_ports=5212;
var _service=5213;
var _edit_port_block_rule=5214;
var _port_block_rule=5215;
var _add_ip_block_rule=5216;
var _edit_ip_block_rule=5217;
var _ip_block_rule_list=5218;
var _add_weburl_rule=5219;
var _edit_weburl_rule=5220;
var _weburl_rule_list=5221;
var _email_sending=5222;
var _file_transfer_l=5223;
var _telnet_service=5224;
var _dns_query=5225;
var _tcp_protocol=5226;
var _udp_protocol=5227;
var _www=5228;
var _err_ip_addr_format=5229;
var _err_ip_mask=5230;
var _err_input_format=5231;
var _err_ip_addr=5232;
var _static_routing_settings=5233;
var _ROUTING_DESC=5234;
var _add_static_route=5235;
var _dest_ip_addr=5236;
var _dest_ip_mask=5237;
var _physical_port=5238;
var _enable_rip=5239;
var _rip_mode=5240;
var _static_route_list=5241;
var _processing_plz_wait=5242;
var _rebooting_plz_wait=5243;
var _L2TPgw=5244;
var _retry=5245;
var _skip=5246;
var _chk_wanconn_msg_00=5247;
var _tnw_01=5248;
var _tnw_02=5249;
var _tnw_03=5250;
var _tnw_04=5251;
var _ssid=5252;
var _auth_type=5253;
var _finish=5254;
var _tnw_05=5255;
var _tnw_dhcp=5256;
var _tnw_static=5257;
var _tnw_pppoe=5258;
var _tnw_pptp=5259;
var _tnw_l2tp=5260;
var _tnw_06=5261;
var _mac=5262;
var _tnw_clone=5263;
var _tnw_07=5264;
var _wan_ipaddr=5265;
var _wan_submask=5266;
var _wan_gwaddr=5267;
var _dns_1=5268;
var _dns_2=5269;
var _tnw_08=5270;
var _tnw_09=5271;
var _my_ip=5272;
var _server_ip=5273;
var _pptp_account=5274;
var _pptp_password=5275;
var _pptp_password_re=5276;
var _tnw_10=5277;
var _l2tp_account=5278;
var _l2tp_password=5279;
var _l2tp_password_re=5280;
var _tnw_11=5281;
var _tnw_12=5282;
var _tnw_13=5283;
var _tnw_14=5284;
var _print=5285;
var _TAG00840=5286;
var IPV6_TEXT171=5287;
var IPV6_TEXT172=5288;
var _wps_shared=5289;
var _wps_open=5290;
var _webfilterrule_dup=5291;
var _wps_24g=5292;
var _wps_5g=5293;
var _name_ssid=5294;
var _warranty=5295;
var _usb=5296;
var _samba_server=5297;
var _ftp_server=5298;
var _print_server=5299;
var _connected_devices=5300;
var _guest_network=5301;
var _guest_text1=5302;
var _network_bridge=5303;
var _inet_access_only=5304;
var _security_no=5305;
var _security_low=5306;
var _security_middle=5307;
var _security_high=5308;
var _parental_control=5309;
var _has_inet_connection=5310;
var _no_inet_connection=5311;
var _guest_network_enabled=5312;
var _guest_network_disabled=5313;
var _usb_connected=5314;
var _no_usb_connected=5315;
var _household_access=5316;
var _confirm_settings=5317;
var _check_connection=5318;
var _address=5319;
var _ha_rule_list=5320;
var _add_ha_rule=5321;
var _edit_ha_rule=5322;
var _wlan_11n_not_support_wep_wpa_tkip=5323;
var _lb_radio_on_sche=5324;
var _rule_full=5325;
var _wds_cant_enble=5326;
var _LAN_CHK_REBOOT_MSG=5327;
var _specify_url=5328;
var _ipaddr_used=5329;
var _macaddr_used=5330;
var _lan_dr=5331;
var _adv_rtd=5332;
var _lb_a_mpdu=5333;
var PRODUCT_DESC_810=5334;
var PRODUCT_DESC_817=5335;
var _ipaddr_used=5336;
var _macaddr_used=5337;
var no_wan_up=5338;
var dev_mode_ap=5339;
var dev_mode_repeater=5340;
var dev_mode_wisp=5341;
var ap_client=5342;
var extend_ssid=5343;
var wlan_client_list=5344;
var desc_ap=5345;
var desc_repeater=5346;
var desc_wisp=5347;
var wiz_select_site=5348;
var wiz_refresh_site=5349;
var wiz_no_result=5350;
var wiz_no_selected=5351;
var wiz_quit=5352;
var custom_range=5353;
var _internet_setting=5354;
var desc_static_ipv6=5355;
var _s_packet=5356;
var _wps_lock=5357;
var pptp_passthrough=5358;
var l2tp_passthrough=5359;
var desc_ap_lan=5360;
var attain_ip=5361;
var dev_stat=5362;
var desc_ap_sch=5363;
