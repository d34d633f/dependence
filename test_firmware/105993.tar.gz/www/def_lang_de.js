//Version=1.01b01
//Language=GERMAN
//Date=Tue, 24, Feb, 2015
//Merged=FALSE
//Merged Fw=FALSE
var msg = new Array ( //
	"Die eingegebene IP-Adresse ist ungültig.", //INVALID_IP_ADDRESS
	"Die IP-Adresse darf nicht Null sein", //ZERO_IP_ADDRESS
	"IP-Adresse", //IP_ADDRESS_DESC
	"Die eingegebene Subnetzmaske ist ungültig.", //INVALID_MASK_ADDRESS
	"Die Subnetzmaske darf nicht \"Null\" lauten.", //ZERO_MASK_ADDRESS
	"Subnetzmaske", //MASK_ADDRESS_DESC
	"Die eingegebene Gateway-IP-Adresse ist ungültig", //INVALID_GATEWAY_ADDRESS
	"Die Gateway-IP-Adresse darf nicht Null sein", //ZERO_GATEWAY_ADDRESS
	"Gateway-IP-Adresse", //GATEWAY_ADDRESS_DESC
	"%s Gateway IP-Adresse %s muss innerhalb des WAN-Subnetzes sein.", //NOT_SAME_DOMAIN
	"Die eingegebene IP-Startadresse ist ungültig (IP-Adressbereich: 1~254)", //INVALID_START_IP
	"Geben Sie einen anderen SMTP-Server oder eine IP-Adresse ein", //SMTP_SERVER_ERROR
	"IP-Startadresse", //START_IP_DESC
	"Die LAN-IP-Adresse und die Start-IP-Adresse sind nicht im gleichen Subnetz", //START_INVALID_DOMAIN
	"Die eingegebene End-IP-Adresse ist ungültig.", //INVALID_END_IP
	"Geben Sie eine andere Domäne ein", //DOMAIN_ERROR
	"Die LAN-IP-Adresse und die End-IP-Adresse sind nicht im gleichen Subnetz", //END_INVALID_DOMAIN
	"Die eingegebene primäre DNS-Adresse ist ungültig.", //INVALID_DNS_ADDRESS
	"Die primäre DNS-Adresse darf nicht Null sein", //ZERO_DNS_ADDRESS
	"Primäre DNS-Adresse", //DNS_ADDRESS_DESC
	"Das SSID-Feld darf nicht leer sein.", //SSID_EMPTY_ERROR
	"Die primäre DNS-Adresse darf nicht Null sein", //AUTH_TYPE_ERROR
	"Der Kennwortsatz muss mindestens 8 Zeichen lang sein.", //PSK_LENGTH_ERROR
	"Der bestätigte Kennwortsatz stimmt nicht mit dem Kennwortsatz überein.", //PSK_MATCH_ERROR
	"Das bestätigte Kennwort stimmt nicht mit dem neuen Kennwort überein", //MATCH_PWD_ERROR
	"Im ausgewählten WEP-Schlüsselfeld muss eine Eingabe gemacht werden.", //WEP_KEY_EMPTY
	"Geben Sie eine andere IP-Adresse ein", //ZERO_STATIC_DHCP_IP
	"Setup-Assistenten beenden und Einstellungen verwerfen?", //QUIT_WIZARD
	"Die eingegebene Mac-Adresse ist ungültig.", //MAC_ADDRESS_ERROR
	"Die End-IP-Adresse muss größer sein als die Start-IP-Adresse.", //IP_RANGE_ERROR
	"Die eingegebene sekundäre DNS-Adresse ist ungültig.", //INVALID_SEC_DNS_ADDRESS
	"Die sekundäre DNS-Adresse darf nicht Null lauten oder ohne Angabe sein.", //ZERO_SEC_DNS_ADDRESS
	"Sekundäre DNS-Adresse", //SEC_DNS_ADDRESS_DESC
	"Das eingegebene Kennwort stimmt nicht mit dem neuen Admin-Kennwort überein", //ADMIN_PASS_ERROR
	"Das eingegebene Kennwort stimmt nicht mit dem neuen Benutzerkennwort überein", //USER_PASS_ERROR
	"Der Host-Name ist ungültig.", //DDNS_HOST_ERROR
	"Geben Sie eine andere IP-Startadresse ein", //ZERO_START_IP
	"Möchten Sie das Gerät wirklich das Gerät auf die Werkseinstellungen zurücksetzen?\nDadurch gehen alle aktuellen Einstellungen verloren.", //RESTORE_DEFAULT
	"Möchten Sie wirklich einen Neustart des Geräts durchführen?\nEin Neustart bricht alle aktiven Internetsitzungen ab.", //REBOOT_ROUTER
	"Einstellungen von einer gespeicherten Konfigurationsdatei laden?", //LOAD_SETTING
	"Sie müssen zuerst den Namen einer Konfigurationsdatei eingeben.", //LOAD_FILE_ERROR
	"Geben Sie mindestens eine Steuerungsdomäne ein.", //CONTROL_DOMAIN_ERROR
	"Geben Sie einen anderen Servernamen ein", //DDNS_SERVER_ERROR
	"Möchten Sie diese Regel für den virtuellen Server wirklich löschen?", //DEL_SERVER_MSG
	"Möchten Sie diese Anwendungsregel wirklich löschen?", //DEL_APPLICATION_MSG
	"Möchten Sie diesen Filter wirklich löschen?", //DEL_FILTER_MSG
	"Möchten Sie diese Route wirklich löschen?", //DEL_ROUTE_MSG
	"Möchten Sie diese MAC-Adresse wirklich löschen?", //DEL_MAC_MSG
	"Möchten Sie dieses Schlüsselwort wirklich löschen?", //DEL_KEYWORD_MSG
	"Möchten Sie diese Domäne wirklich löschen?", //DEL_DOMAIN_MSG
	"Möchten Sie diesen Eintrag wirklich löschen?", //DEL_ENTRY_MSG
	"Möchten Sie diese DHCP-Reservierung wirklich löschen?", //DEL_STATIC_DHCP_MSG
	"Geben Sie bitte eine andere Portnummer ein.", //PORT_ERROR
	"Geben Sie eine andere zulässige Domäne ein", //PERMIT_DOMAIN_ERROR
	"Wählen Sie für das Router-Upgrade eine Firmware-Datei.", //FIRMWARE_UPGRADE_ERROR
	"Das eingegebene Schlüsselwort existiert bereits in der Liste", //SAME_KEYWORD_ERROR
	"Bitte geben Sie einen anderen Schlüssel ein", //WIZARD_KEY_EMPTY
	"Ein anderes Schlüsselwort kann nicht hinzugefügt werden", //ADD_KEYWORD_ERROR
	"Wählen Sie bitte erst einen Rechner", //SELECT_MACHINE_ERROR
	"Die eingegebene Domäne ist bereits in der Liste der gesperrten Domänen", //SAME_BLOCK_DOMAIN
	"Eine weitere gesperrte Domäne kann nicht hinzugefügt werden", //ADD_BLOCK_DOMAIN_ERROR
	"Die eingegebene Domäne ist bereits in der Liste der zulässigen Domänen", //SAME_PERMIT_DOMAIN
	"Geben Sie ein anderes Kennwort ein.", //DDNS_PASS_ERROR
	"Eine weitere zulässige Domäne kann nicht hinzugefügt werden", //ADD_PERMIT_DOMAIN_ERROR
	"Geben Sie eine weitere gesperrte Domäne ein", //BLOCK_DOMAIN_ERROR
	"Eine weitere zulässige Domäne kann nicht hinzugefügt werden", //ADD_CONTROL_DOMAIN_ERROR
	"Geben Sie bitte ein anderes Kennwort für die Funksicherheit ein.", //SECURITY_PWD_ERROR
	"Die eingegebene IP-Adresse des RADIUS-Servers 1 ist ungültig.", //INVALID_RADIUS_SERVER1_IP
	"Die IP-Adresse des Radius Servers 1 darf nicht Null oder ohne Angabe sein", //ZERO_RADIUS_SERVER1_IP
	"IP-Adresse des Radius-Servers 1", //RADIUS_SERVER1_IP_DESC
	"Die eingegebene IP-Adresse des RADIUS-Servers 2 ist ungültig.", //INVALID_RADIUS_SERVER2_IP
	"Die IP-Adresse des Radius Servers 2 darf nicht Null oder ohne Angabe sein", //ZERO_RADIUS_SERVER2_IP
	"IP-Adresse des Radius-Servers 2", //RADIUS_SERVER2_IP_DESC
	"Die eingegebene IP-Adresse ist ungültig (IP-Bereich: 1~254)", //INVALID_STATIC_DHCP_IP
	"Geben Sie eine andere IP-Endadresse ein", //ZERO_END_IP
	"Geben Sie einen anderen Namen ein", //NAME_ERROR
	"Die eingegebene IP-Adresse des Servers ist ungültig", //INVALID_SERVER_IP
	"Die Server-IP-Adresse darf nicht Null lauten oder ohne Angabe sein.", //ZERO_SERVER_IP
	"Server-IP-Adresse", //SERVER_IP_DESC
	"Die eingegebenen Kennwörter stimmen nicht überein", //MATCH_WIZARD_PWD_ERROR
	"Die eingegebene Start-IP-Adresse der Quelle ist ungültig", //INVALID_SOURCE_START_IP
	"Die Server-IP-Adresse darf nicht Null lauten oder ohne Angabe sein.", //ZERO_SOURCE_START_IP
	"IP-Startadresse der Quelle", //SOURCE_START_IP_DESC
	"Die eingegebene IP-Startadresse der Quelle ist ungültig", //INVALID_SOURCE_END_IP
	"Die IP-Endadresse der Quelle darf nicht Null oder ohne Angabe sein", //ZERO_SOURCE_END_IP
	"IP-Endadresse der Quelle", //SOURCE_END_IP_DESC
	"Die eingegebene IP-Startadresse des Ziels ist ungültig.", //INVALID_DEST_START_IP
	"Die IP-Startadresse des Ziels darf nicht Null lauten oder ohne Angabe sein.", //ZERO_DEST_START_IP
	"IP-Startadresse des Ziels", //DEST_START_IP_DESC
	"Die eingegebene IP-Endadresse des Ziels ist ungültig.", //INVALID_DEST_END_IP
	"Die IP-Endadresse des Ziels darf nicht Null lauten oder ohne Angabe sein.", //ZERO_DEST_END_IP
	"IP-Endadresse des Ziels", //DEST_END_IP_DESC
	"Der Kennwortsatz muss zwischen 8 und 63 Zeichen lang sein", //PSK_OVER_LEN
	"JumpStart zurücksetzen?", //RESET_JUMPSTAR
	"Möchten Sie diese Regel wirklich löschen?", //DEL_RULE_MSG
	"Möchten Sie diesen Zeitplan wirklich löschen?", //DEL_SCHEDULE_MSG
	"Ein weiterer Zeitplan kann nicht hinzugefügt werden", //ADD_SCHEDULE_ERROR
	"Ein Name für den Zeitplan muss vergeben werden", //SCHEDULE_NAME_ERROR
	"Eingabe des Zeitplannamens ist so nicht zulässig", //SCHEDULE_NAME_SPACE_ERROR
	"Die eingegebene Startzeit ist ungültig", //START_TIME_ERROR
	"Die eingegebene Endzeit ist ungültig", //END_TIME_ERROR
	"Die Startzeit kann nicht später sein als die Endzeit", //TIME_RANGE_ERROR
	"Wählen Sie das zu löschende Schlüsselwort aus", //DEL_KEYWORD_ERROR
	"Wählen Sie die zu löschende zulässige Domäne aus", //DEL_PERMIT_DOMAIN_ERROR
	"Wählen Sie die zu löschende gesperrte Domäne aus", //DEL_BLOCK_DOMAIN_ERROR
	"Die eingegebene Kinderschutzregel ist bereits in der Liste.", //DUPLICATE_URL_ERROR
	"Fehler im Anmeldenamen", //LOGIN_NAME_ERROR
	"Kennwort-Anmeldefehler", //LOGIN_PASS_ERROR
	"%s ist mit der LAN IP-Adresse im Konflikt. Geben Sie sie bitte erneut ein.", //THE_SAME_LAN_IP
	"PSK sollte Hex sein.", //THE_PSK_IS_HEX
	"Die IP-Adresse und die IP-Reservierungsadresse sind nicht im gleichen Subnetz.", //SER_NOT_SAME_DOMAIN
	"Auf dieser Seite befinden sich ungespeicherte Daten. Möchten Sie die Änderungen verwerfen?%s Wenn nicht, klicken Sie auf 'Abbrechen' und dann auf 'Einstellungen speichern'.%s Wenn ja, klicken Sie auf 'OK'.", //IS_CHANGE_DATA
	"Das eingegebene Kennwort stimmt nicht mit dem neuen Benutzerkennwort überein", //DDNS_PASS_ERROR_MARTH
	"Der Regelname darf nicht leer sein.", //INBOUND_NAME_ERROR
	"Die End-Portnummer muss größer sein als die Start-Portnummer.", //PORT_RANGE_ERROR
	"Möchten Sie wirklich aktivieren/deaktivieren?", //CHECK_ENABLE
	"Sind Sie sicher, dass Sie diesen Löschvorgang durchführen möchten?", //DEL_MSG
	"Sie müssen Ihre Änderungen alle verwerfen, um einen neuen Zeitplan festzulegen.\n Klicken Sie auf OK, um diese Änderungen zu verwerfen und die Zeitplanseite anzuzeigen.\n Klicken Sie sonst auf 'Abbrechen'.", //GO_SCHEDULE
	"Geben Sie den Benutzernamen ein", //PPP_USERNAME_EMPTY
	"Es liegen keine Änderungen vor. Trotzdem speichern?", //FORM_MODIFIED_CHECK
	"Wählen Sie zuerst einen Anwendungsnamen aus.", //SELECT_APPLICATION_ERROR
	"Wählen Sie bitte erst einen Computernamen aus.", //SELECT_COMPUTER_ERROR
	"Geben Sie einen anderen Namen ein", //STATIC_DHCP_NAME
	"Wählen Sie die zu löschende Steuerungsdomäne aus", //DEL_CONTROL_DOMAIN_ERROR
	"Geben Sie bitte ein anderes Schlüsselwort ein", //KEYWORD_ERROR
	"Geben Sie eine private IP-Adresse ein.", //PRIVATE_IP_ERROR
	"Geben Sie bitte eine Firewall-Portnummer ein", //PUBLIC_PORT_ERROR
	"Geben Sie bitte eine Trigger-Portnummer ein", //TRIGGER_PORT_ERROR
	"Geben Sie eine gültige E-Mail-Adresse ein", //EMAIL_ADDRESS_ERROR
	"Bitte geben Sie einen Hostnamen oder eine IP-Adresse ein", //PING_IP_ERROR
	"Nur das Admin-Konto kann die Einstellungen herunterladen.", //DOWNLOAD_SETTING_ERROR
	"Geben Sie einen anderen Benutzernamen ein", //DDNS_USER_ERROR
	"IP-Endadresse", //END_IP_DESC
	"" //MAX
);
var INVALID_IP_ADDRESS=0;
var ZERO_IP_ADDRESS=1;
var IP_ADDRESS_DESC=2;
var INVALID_MASK_ADDRESS=3;
var ZERO_MASK_ADDRESS=4;
var MASK_ADDRESS_DESC=5;
var INVALID_GATEWAY_ADDRESS=6;
var ZERO_GATEWAY_ADDRESS=7;
var GATEWAY_ADDRESS_DESC=8;
var NOT_SAME_DOMAIN=9;
var INVALID_START_IP=10;
var SMTP_SERVER_ERROR=11;
var START_IP_DESC=12;
var START_INVALID_DOMAIN=13;
var INVALID_END_IP=14;
var DOMAIN_ERROR=15;
var END_INVALID_DOMAIN=16;
var INVALID_DNS_ADDRESS=17;
var ZERO_DNS_ADDRESS=18;
var DNS_ADDRESS_DESC=19;
var SSID_EMPTY_ERROR=20;
var AUTH_TYPE_ERROR=21;
var PSK_LENGTH_ERROR=22;
var PSK_MATCH_ERROR=23;
var MATCH_PWD_ERROR=24;
var WEP_KEY_EMPTY=25;
var ZERO_STATIC_DHCP_IP=26;
var QUIT_WIZARD=27;
var MAC_ADDRESS_ERROR=28;
var IP_RANGE_ERROR=29;
var INVALID_SEC_DNS_ADDRESS=30;
var ZERO_SEC_DNS_ADDRESS=31;
var SEC_DNS_ADDRESS_DESC=32;
var ADMIN_PASS_ERROR=33;
var USER_PASS_ERROR=34;
var DDNS_HOST_ERROR=35;
var ZERO_START_IP=36;
var RESTORE_DEFAULT=37;
var REBOOT_ROUTER=38;
var LOAD_SETTING=39;
var LOAD_FILE_ERROR=40;
var CONTROL_DOMAIN_ERROR=41;
var DDNS_SERVER_ERROR=42;
var DEL_SERVER_MSG=43;
var DEL_APPLICATION_MSG=44;
var DEL_FILTER_MSG=45;
var DEL_ROUTE_MSG=46;
var DEL_MAC_MSG=47;
var DEL_KEYWORD_MSG=48;
var DEL_DOMAIN_MSG=49;
var DEL_ENTRY_MSG=50;
var DEL_STATIC_DHCP_MSG=51;
var PORT_ERROR=52;
var PERMIT_DOMAIN_ERROR=53;
var FIRMWARE_UPGRADE_ERROR=54;
var SAME_KEYWORD_ERROR=55;
var WIZARD_KEY_EMPTY=56;
var ADD_KEYWORD_ERROR=57;
var SELECT_MACHINE_ERROR=58;
var SAME_BLOCK_DOMAIN=59;
var ADD_BLOCK_DOMAIN_ERROR=60;
var SAME_PERMIT_DOMAIN=61;
var DDNS_PASS_ERROR=62;
var ADD_PERMIT_DOMAIN_ERROR=63;
var BLOCK_DOMAIN_ERROR=64;
var ADD_CONTROL_DOMAIN_ERROR=65;
var SECURITY_PWD_ERROR=66;
var INVALID_RADIUS_SERVER1_IP=67;
var ZERO_RADIUS_SERVER1_IP=68;
var RADIUS_SERVER1_IP_DESC=69;
var INVALID_RADIUS_SERVER2_IP=70;
var ZERO_RADIUS_SERVER2_IP=71;
var RADIUS_SERVER2_IP_DESC=72;
var INVALID_STATIC_DHCP_IP=73;
var ZERO_END_IP=74;
var NAME_ERROR=75;
var INVALID_SERVER_IP=76;
var ZERO_SERVER_IP=77;
var SERVER_IP_DESC=78;
var MATCH_WIZARD_PWD_ERROR=79;
var INVALID_SOURCE_START_IP=80;
var ZERO_SOURCE_START_IP=81;
var SOURCE_START_IP_DESC=82;
var INVALID_SOURCE_END_IP=83;
var ZERO_SOURCE_END_IP=84;
var SOURCE_END_IP_DESC=85;
var INVALID_DEST_START_IP=86;
var ZERO_DEST_START_IP=87;
var DEST_START_IP_DESC=88;
var INVALID_DEST_END_IP=89;
var ZERO_DEST_END_IP=90;
var DEST_END_IP_DESC=91;
var PSK_OVER_LEN=92;
var RESET_JUMPSTAR=93;
var DEL_RULE_MSG=94;
var DEL_SCHEDULE_MSG=95;
var ADD_SCHEDULE_ERROR=96;
var SCHEDULE_NAME_ERROR=97;
var SCHEDULE_NAME_SPACE_ERROR=98;
var START_TIME_ERROR=99;
var END_TIME_ERROR=100;
var TIME_RANGE_ERROR=101;
var DEL_KEYWORD_ERROR=102;
var DEL_PERMIT_DOMAIN_ERROR=103;
var DEL_BLOCK_DOMAIN_ERROR=104;
var DUPLICATE_URL_ERROR=105;
var LOGIN_NAME_ERROR=106;
var LOGIN_PASS_ERROR=107;
var THE_SAME_LAN_IP=108;
var THE_PSK_IS_HEX=109;
var SER_NOT_SAME_DOMAIN=110;
var IS_CHANGE_DATA=111;
var DDNS_PASS_ERROR_MARTH=112;
var INBOUND_NAME_ERROR=113;
var PORT_RANGE_ERROR=114;
var CHECK_ENABLE=115;
var DEL_MSG=116;
var GO_SCHEDULE=117;
var PPP_USERNAME_EMPTY=118;
var FORM_MODIFIED_CHECK=119;
var SELECT_APPLICATION_ERROR=120;
var SELECT_COMPUTER_ERROR=121;
var STATIC_DHCP_NAME=122;
var DEL_CONTROL_DOMAIN_ERROR=123;
var KEYWORD_ERROR=124;
var PRIVATE_IP_ERROR=125;
var PUBLIC_PORT_ERROR=126;
var TRIGGER_PORT_ERROR=127;
var EMAIL_ADDRESS_ERROR=128;
var PING_IP_ERROR=129;
var DOWNLOAD_SETTING_ERROR=130;
var DDNS_USER_ERROR=131;
var END_IP_DESC=132;

var which_lang = new Array ( //
	"Wenn die Funktion aktiviert ist, wird Ihr Internet-Datenverkehr von einem auf Sicherheit ausgelegten DNS-Server geschützt. Diese Funktion bietet Anti-Phishing zum Schutz Ihrer Internetverbindung vor betrügerischen Absichten und Navigationsverbesserungen wie die automatische Korrektur häufiger URL-Eingabefehler.", //_Advanced_01
	"Obwohl die Funktion 'Advanced DNS' aktiviert ist, kann die DNS IP-Adresse Ihres Arbeitsplatzrechners nach Bedarf immer noch auf die DNS Server IP-Adresse geändert werden. Beachten Sie bitte, dass der Router die DNS-Namensauflösung nicht vorschreibt, wenn die DNS IP-Adresse auf dem Arbeitsplatzrechner konfiguriert ist.", //_Advanced_03
	"Wenn Sie diese Option gewählt haben und in Ihrem Netz ist ein virtuelles privates Netz (VPN) oder ein Intranet eingerichtet, können Sie den 'Advanced DNS-Dienst' deaktivieren, falls Sie Schwierigkeiten mit der Verbindung haben.", //_Advanced_04
	"Advanced DNS Service", //bwn_ict_dns
	"Mit dem erweiterten DNS Service (Advanced DNS) handelt es sich um eine kostenlose Sicherheitsoption, die Anti-Phishing zum Schutz Ihrer Internetverbindung vor betrügerischen Absichten bereitstellt und Navigationsverbesserungen wie die automatische Korrektur häufiger URL-Eingabefehler bietet.", //bwn_msg_Modes_dns
	"Zugriffssteuerung aktivieren", //aa_EAC
	"Mein USB-Typ ist", //new_bwn_mici_usb
	"TKIP kann nicht gewählt werden, wenn nur 802.11n genutzt wird!", //_tkip_11n
	"SharePort für Gastzone", //bln_title_guest_use_shareport
	"Kommunikation zwischen Netzen erlauben", //IPV6_TEXT3
	"Mischbetrieb (802.11g und 802.11n)", //bwl_Mode_10
	"Geben Sie die Informationen zur AFTR-Adresse ein, die Sie von Ihrem Internetdienstanbieter erhalten haben.", //IPV6_TEXT148
	"Erneut erstellen", //_regenerate
	"Geben Sie die folgenden Einstellungen für das drahtlose Gerät ein, das Sie Ihrem drahtlosen Netzwerk hinzufügen, und notieren Sie sich diese Einstellungen für die spätere Verwendung.", //TEXT048
	"Email-Benachrichtigung aktivieren", //te_EnEmN
	"USB 3.5G Einstellungen", //usb3g_titile
	"APN-Name", //usb3g_apn_name
	"Nummer wählen", //usb3g_dial_num
	"Wiederverbindungsmodus (0:Immer/1:NachBedarf/2:Manuell)", //usb3g_reconnect_mode
	"LEERLAUFZEIT", //usb3g_max_idle_time
	"USB-EINHEIT (0:3G Modem/1:KCODE)", //usb_device
	"USB 3.5G Handbuch", //usb3g_manual
	"USB 3.5G Statistik", //usb3g_stat_titile
	"USB-Einstellungen", //bln_title_usb
	"WCN-Konfiguration", //usb_wcn
	"Verwenden Sie diesen Abschnitt, um Ihren USB-Port zu konfigurieren. Mehrere Konfigurationen stehen zur Auswahl: Netzwerk-USB, 3G USB-Adapter und WCN-Konfiguration.", //bwn_intro_usb
	"Netzwerk-USB", //usb_network
	"3G USB-Adapter", //usb_3g
	"Nummer wählen", //wwan_dial_num
	"WWAN Internet-Verbindungstyp", //bwn_wwanICT
	"Geben Sie hier die E-Mail-Adresse an, an die die E-Mails gesendet werden sollen.", //help862
	"Authentifizierungsprotokoll", //wwan_auth_label
	"Auto(PAP+CHAP)", //wwan_auth_auto
	"Zeitüberschreitung bei PAP-Authentifizierung. Authentifizierung fehlgeschlagen.", //IPPPPPAP_AUTH_ISSUE
	"Nur CHAP", //wwan_auth_chap
	"Nur MS CHAP", //wwan_auth_mschap
	"Nutzen Sie einen USB-Drucker, Scanner oder ein Speichergerät, die mit dem USB-Port hinter dem Router verbunden sind, gemeinsam mit mehreren Anwendern in Ihrem Netz.", //usb_network_help
	"Wählen Sie 3G USB-Adapter zur Verwendung eines 3G Adapters, um Zugang zum Internet mithilfe eines EV-DO Cellular Signals bereitzustellen. Schließen Sie einfach einen 3G USB-Adapter zum Zugang zum Internet an (EV-DO Lizenz eines Drittanbieters und verfügbares Signal erforderlich).", //usb_3g_help
	"Sollten Sie Probleme haben durch den Router auf das Internet zuzugreifen,  überprüfen Sie die auf dieser Seite eingegebenen Einstellungen und verifizieren Sie sie, falls nötig, mit Ihrem Internetdienstanbieter.", //usb_3g_help_support_help
	"Konfigurieren Sie Ihr Funknetz mithilfe von Windows Connect Now (WCN). WCN ermöglicht es Ihnen, Ihre Funkeinstellungen von dem Router auf ein USB-Flash-Laufwerk zu kopieren und zu nutzen, um die Funkeinstellungen auf Ihrem/n Rechner/n oder anderen WCN-kompatiblen Geräten automatisch zu konfigurieren.", //usb_wcn_help
	"Mein Anschluss des USB-Typs ist", //bwn_mici_usb
	"Geben Sie bitte das Netzwerk-USB-Erkennungsintervall an. Der Router wird die USB-Einheit automatisch erkennen.", //_info_netowrk
	"Multicast-Streams aktivieren", //anet_multicast_enable
	"Netzwerk USB-Erkennungsintervall", //bwn_usb_time
	"Sek (Bereich:3 - 600 Sek.)", //bwn_bytes_usb
	"Die Wahl von Shared Key ist nicht möglich, wenn WPS aktiviert ist.", //_wps_albert_1
	"Die Wahl von WPA-Enterprise ist nicht möglich, wenn WPS aktiviert ist.", //_wps_albert_2
	"Konfigurieren Sie die Einstellungen Ihres Internetverbindungstyps.  Wenn Sie nicht sicher ist, welche Einstellungen Sie wählen sollen, wenden Sie sich an Ihren Internetdienstanbieter.", //usb_config2
	"Wählen Sie eine für dieses Gerät geltende Richtlinie.", //ac_alert_choose_dev
	"Der Internetverbindungstyp ist nicht für eine 3G-Internetverbindung.  Wählen Sie WWAN zur Unterstützung der 3G Internetverbindung.", //usb_config3
	"Der Internetverbindungstyp ist nicht für eine 3G-Internetverbindung. Wählen Sie bitte einen anderen Internetverbindungstyp.", //usb_config4
	"Der Internetverbindungstyp, den Sie gewählt haben, ist für eine 3G-Internetverbindung.  Die USB-Einstellungen werden von Netzwerk USB/WCN auf 3G USB-Adapter geändert.", //usb_config5
	"Der Internetverbindungstyp, den Sie gewählt haben, ist nicht für eine 3G-Internetverbindung.  Die USB-Einstellungen werden von 3G USB-Adapter auf Netzwerk USB geändert.", //usb_config6
	"Wählen Sie die Art des USB-Gerätes aus, das Sie anschliessen möchten", //bwn_msg_usb
	"Land", //_country
	"Wählen Sie Ihr Land", //_select_country
	"Wählen Sie Ihren Internetdienstanbieter", //_select_ISP
	"Australien", //country_1
	"Italien", //country_2
	"Portugal", //country_3
	"Großbritannien", //country_4
	"Indonesien", //country_5
	"Malaysia", //country_6
	"Singapur", //country_7
	"Persönliche Angaben", //_aa_bsecure_personals
	"Südafrika", //country_9
	"HongKong", //country_10
	"Taiwan", //country_11
	"Ägypten", //country_12
	"Dominikanische Republik", //country_13
	"El Salvador", //country_14
	"Brasilien", //country_15
	"Wählen Sie diese Option, wenn Sie ein Gastnetzwerk hinzufügen möchten.", //S500
	"Netzwerktyp", //S496
	"HTTP Storage - Fernzugriff aktivieren", //sto_http_2
	"E-Mail: Die Schaltfläche 'E-Mail jetzt' ist deaktiviert, weil die E-Mail-Benachrichtigungsfunktion im Fenster <a href='tools_email.asp' onclick='return jump_if();' shape='rect'>Extras &rarr; E-Mail</a> nicht aktiviert ist.", //logs_LW39b_email
	"HTTPS verwenden", //LV3
	"%s%sDrahtloses System mit MAC-Adresse %m gesichert und verknüpft", //GW_WIRELESS_DEVICE_LINK_UP
	"Alle Protokolleinträge wurden gelöscht.", //LT248
	"PPPoE Server für %s PPPoE-Sitzung erkennen", //GW_PPPOE_EVENT_DISCOVERY_ATTEMPT
	"5 GHz Band", //GW_WLAN_RADIO_1_NAME
	"SMTP-Server-Port", //te_SMTPSv_Port
	"Der 802.11 Modus kann nicht auf 802.11n Only geändert werden, so lange eine SSID mit WEP-Sicherung vorliegt.", //GW_WLAN_CHANGING_PHY_MODE_TO_11NG_ONLY_INVALID
	"Wählen Sie Ihr Funknetz", //S558
	"Wählen Sie den Funkbetrieb, den Sie konfigurieren möchten", //KRL8
	"Die Auswahl hilft Ihnen bei der Angabe der Gastzonenskala.", //LY30
	"Der virtueller Server '%s' kann den HTTPS WAN-Administrator-Port %u des Routers nicht verwenden", //GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"Das Wi-Fi gesicherte Setup ist deaktiviert, weil die Sicherheit des SSID '%s' auf WPA-Enterprise gesetzt ist.", //GW_WIFISC_DISABLED_AUTOMATICALLY
	"Aus", //_off
	"2.4 GHz Band", //GW_WLAN_RADIO_0_NAME
	"%s PPPoE-Sitzungsprotokollfehler. Der Verbindungsversuch ist fehlgeschlagen.", //GW_PPPOE_EVENT_DISCOVERY_REQUEST_ERROR
	"Der PPPoE-Sitzungsname %s ist im Konflikt mit einem anderen Sitzungsnamen", //GW_WAN_PPPOE_SESSION_NAME_CONFLICT
	"Problem beim Empfang von Protokollen. Der Speicherplatz reicht nicht, um die Protokolle anzuzeigen oder es liegt ein Problem mit der Verbindung vor.", //S525
	"Das Kennwort und das bestätigte Kennwort stimmen nicht überein. Bestätigen Sie das Benutzer-Kennwort.", //YM174
	"Sie sollten diese Warnungen untersuchen. Einige Funktionen sind möglicherweise deaktiviert oder wurden geändert.", //KR136
	"Die %s PPPoE-Sitzungskennung %u wird beendet", //GW_PPPOE_EVENT_DISCONNECT
	"Endpunkt unabhängig", //af_EFT_0
	"Verwenden Sie diesen Teil dazu, um das Routing der Daten zwischen der Host- und der Gastzone zu ermöglichen. Gast-Clients können nicht ohne Aktivierung dieser Funktion auf die Daten von Host-Clients zugreifen.", //LY34
	"%sFunkbetriebende", //GW_WIRELESS_SHUT_DOWN
	"%sFunkbetriebneustart", //GW_WIRELESS_RESTART
	"Die Administrationsleerlaufzeit muss im Bereich 1 bis 65535 liegen.", //S528
	"Port Forwarding ALG konnte die Sitzung für das TCP-Paket nicht von %v:%u auf %v:%u zuweisen", //GW_PORT_FORWARD_TCP_PACKET_ALLOC_FAILURE
	"In diesem Abschnitt können Sie die Einstellungen der Gastzone Ihres Routers konfigurieren. Sie bietet einen gesonderten Netzwerkbereich für einen Gast zum Zugriff auf das Internet.", //guestzone_Intro_1
	"Der virtueller Server '%s' kann den HTTPS WAN-Administrator-Port %u des Routers nicht verwenden", //GW_NAT_VIRTUAL_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"Remote-Management aktivieren", //ta_ERM
	"Port muss im Bereich (1..65535) sein", //te_SMTPSv_Port_alert
	"%sFunkbetrieb konnte nicht gestartet werden", //GW_WIRELESS_DEVICE_START_FAILED
	"Port Forwarding ALG konnte die Sitzung für das UDP-Paket nicht von %v:%u auf %v:%u zuweisen", //GW_PORT_FORWARD_UDP_PACKET_ALLOC_FAILURE
	"%sVerbindung mit allen Funkstationen trennen", //GW_WIRELESS_DEVICE_DISCONNECT_ALL
	"Anfrage für %s PPPoE-Sitzungsangebot ausgeben", //GW_PPPOE_EVENT_OFFER_REQUEST
	"Router IP %v muss eine gültige Host-Adresse sein", //GW_ROUTES_ROUTERS_IP_ADDRESS_INVALID
	"Port Trigger ALG konnte die Sitzung für das UDP-Paket nicht von %v:%u auf %v:%u zuweisen", //GW_PORT_TRIGGER_UDP_PACKET_ALLOC_FAILURE
	"WEP-Sicherheit kann nicht für eine SSID eingerichtet werden, solange der 802.11 Modus '802.11n only' ist.", //GW_WLAN_SETTING_SSID_SECURITY_TO_WEP_INVALID
	"Der virtuelle Server %s' kann den HTTP-WAN-Administrationsport des Routers %u nicht verwenden.", //GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT
	"Timeout, Station inaktiv", //GW_WLAN_STATION_TIMEOUT
	"Der virtuelle Server %s' kann die IP-Adresse des Routers %v nicht verwenden.", //GW_NAT_VIRTUAL_SERVER_IP_ADDRESS_CAN_NOT_MATCH_ROUTER
	"%s' [protocol:%u]->%v ist im Konflikt mit '%s' [protocol:%u]->%v.", //GW_NAT_VIRTUAL_SERVER_PROTO_CONFLICT_INVALID
	"Gibt an, ob die Gastzone aktiviert oder deaktiviert wird.", //LY28
	"Es wird versucht, die %s PPPoE-Verbindung herzustellen", //GW_PPPOE_EVENT_CONNECT
	"Trigger-Port", //GW_NAT_TRIGGER_PORT
	"Betriebsmodus", //tc_opmode
	"Automatische Zuweisung eines Netzwerkschlüssels für das 2,4 GHz und 5 GHz Band (Empfohlen).", //wwz_auto_assign_key3
	"Geben Sie einen Namen für die Gastzone des Funknetzes an.", //LY292
	"Es ist wichtig, dass Sie Ihr drahtloses Netz sichern. Nur so kann die Integrität von Datenübertragungen in Ihrem Drahtlosnetz gewährleistet werden. Der Router bietet 4 Verschlüsselungsstandards für Ihr drahtloses Netz: WEP, WPA only, WPA2 only und WPA/WPA2 (auto-detect).", //LY293
	"Bei Verwendung der WEP-Sicherheitsoption arbeitet dieses Gerät <strong>AUSSCHLIESSLICH</strong> im <strong>Standard-Drahtlosmodus (802.11B/G)</strong>. Leistungen nach IEEE 802.11n können <strong>NICHT</strong> erreicht werden, da WEP nicht durch die Draft 11n-Technologie unterstützt wird.", //bws_msg_WEP_4
	"Die Route für %v auf der Schnittstelle %s kann möglicherweise nicht erstellt werden. Auf dieser Schnittstelle können nur Routen über Gateways erstellt werden.", //GW_ROUTES_ON_LINK_DATALINK_CHECK_INVALID
	"DNS-Einstellungen", //wwa_dnsset
	"Dieser Assistent dient als Hilfe bei der Erstellung einer Verbindung Ihres drahtlosen Gastgeräts mit Ihrem drahtlosen Router. Er weist Sie Schritt für Schritt an, wie Sie diese Verbindung herstellen. Um zu beginnen, klicken Sie auf die Schaltfläche unten.", //wireless_gu
	"WLAN-Gastzugang mit WPS hinzufügen", //add_gu_wps
	"Funkband", //wwl_band
	"Band", //_band
	"5 GHz Band-Netzwerkname manuell einrichten", //wwa_5G_nname
	"GASTZONE", //_guestzone
	"Wahl der Gastzone", //guestzone_title_1
	"Grafische Authentifizierung aktivieren", //_graph_auth
	"Funk einbeziehen", //guestzone_inclw
	"Gast", //guest
	"niedriger als drahtloses Netz", //lower_wnt
	"gleich dem drahtlosen Netz", //equal_wnt
	"Niedrigste", //_lowest
	"SSID-Liste", //ssid_lst
	"Multi SSID", //mult_ssid
	"SSID hinzufügen/bearbeiten", //add_ed_ssid
	"Aktivieren oder deaktivieren Sie definierte Regeln mithilfe der Kontrollkästchen links.", //help75a
	"WAN Ping-Eingangsfilter", //wpin_filter
	"Das RAW TCP Port Druck Protokoll verwendet eine feste IP-Adresse und einen TCP Port um mit Ihrem Drucker zu kommunizieren.", //tps_raw1
	"(GMT+06:30) Rangun", //up_tz_52
	"Die Ziel-IP-Adressen sind gleich.", //_r_alert_new1
	"Email-Einstellungen", //te_EmSt
	"Blockiertes ausgehendes Paket von %v nach %v (IP Protokoll %u)", //IPNAT_BLOCKED_EGRESS
	"Wireless Sicherheitsmodus", //bws_WSMode
	"Öffentliche WAN IP-Adressen zu pingen ist eine normale Methode, die von den Hackern verwendet wird, um zu prüfen, ob Ihre WAN IP-Adresse aktiv ist.", //anet_wan_ping_1
	"Geben Sie der Regel einen für Sie sinnvollen Namen, z.B. <code>GameServer</code>. Sie können auch von einer Liste populärer Spiele eine Auswahl treffen und viele der restlichen Einstellungen werden dementsprechend ausgefüllt. Jedoch sollten Sie überprüfen, ob die Portwerte seit Erstellung dieser Liste geändert wurden und Sie müssen auch die IP Adresse eintragen.", //help65
	"UPNP", //ta_upnp
	"Übertragungsrate", //bwl_TxR
	"Überprüfung der WAN-Schnittstellengeschwindigkeit abgeschlossen", //GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED
	"Durchschnittliche Ping Zeit (in Millisekunde):", //tsc_pingt_msg106
	"Ganzer Tag", //tsc_AllDay
	"Tiger Woods 2K4", //gw_gm_53
	"Überprüfung der WAN-Schnittstellengeschwindigkeit nicht gestartet, da nicht genügend Ressourcen zur Verfügung stehen", //GW_WAN_RATE_ESTIMATOR_RESOURCE_ERROR
	"Lease für IP-Adresse verloren", //DHCP_CLIENT_LOST_LEASE
	"Legen Sie einen Zeitplan für diese Richtlinie fest.", //_aa_wiz_s3_msg
	"Authentifizierung Zeitüberschreitung", //bwsAT_
	"Die Systemzeit Ihres Routers ist wichtig für Firewall Regeln und deren zeitsgeteuerte Umsetzung.", //hhtt_intro
	"Final Fantasy XI (PS2)", //gw_gm_20
	"Die IP-Adresse des Authentifizierungsservers.", //help388
	"Setze Datum und Zeit manuell", //tt_StDT
	"Offline", //psOffline
	"Status", //_status
	"Andernfalls klicken Sie auf 'Abbrechen'.", //up_ae_wic_3
	"Was soll angezeigt werden", //sl_WtV
	"STA mit MAC (%m) für WPS-Registrierung erforderlich", //WIFISC_AP_PROXY_PROCESS_START
	"Der Setup-Assistent konnte die Kommunikation zum Drucker nicht herstellen.", //wprn_nopr2
	"Wenn Sie nach vorhandenen drahtlosen Netzwerken suchen, ist dies der Name, der in der Liste erscheint (es sei denn der Status Sichtbar wurde auf Unsichtbar umgestellt, siehe unten). Dieser Name wird auch als SSID bezeichnet. Für eine erhöhte Sicherheit ist es empfehlenswert, den vorkonfigurierten Netzwerknamen zu ändern.", //help352
	"Netzwerkname (SSID)", //wwz_wwl_wnn
	"IP-Adresse", //_ipaddr
	"Beginn von gw_wireless_schedule", //GW_WLS_SCHEDULE_START
	"Die Anleitung zur Einleitung eines Gespräches:", //help820
	"Wenn alle Computer im LAN wie erwartet ihre IP-Adresse erfolgreich vom DHCP-Server des Routers bezogen haben, kann diese Einstellung auf Deaktiviert gestellt bleiben. Sollte einer der Computer im LAN die IP-Adresse nicht vom DHCP-Server des Routers bezogen haben, hat dieser möglicherweise einen alten DHCP-Klienten, welcher das Broadcast Flag der DHCP-Pakete fälschlicherweise abschaltet. Die Aktivierung dieser Option bewirkt, daß der Router immer seine Antworten zu den Klienten sendet, wodurch das Problem umgangen wird, allerdings auf Kosten von erhöhtem Broadcast-Verkehr im LAN.", //help326
	"(GMT+08:00) Krasnojarsk", //up_tz_54
	"Hinweis: Einige Browser unterliegen Einschränkungen, die es unmöglich machen, die Anzeige des WAN-Status bei Statusänderungen zu aktualisieren. Bei einigen Browsern muss die Anzeige aktualisiert werden, damit der aktuelle Status angezeigt wird. Manche Browser melden einen Fehler wenn versucht wird, den WAN-Status abzurufen.", //help773
	"MAC Filter Regeln", //am_MACFILT
	"sind das gleiche Gerät.", //aa_alert_7_new1
	"Jede Netzwerk-Gerät hat ab Werk seine eigene eindeutige MAC-Adresse. Einige Internetdienstanbieter könnten die MAC-Adresse Ihres Computers überprüfen um diese als die Adresse zu speichern, die sich zuerst mit dem Internetdienst verbunden hat. Der Internetdienstanbieter bewilligt dann nur Internet-Zugriff von einem Computer oder von einem Router mit dieser bestimmten MAC-Adresse. Dieser Router hat eine andere MAC-Adresse als der Computer oder Router, der sich zuerst an den  Internetdienst angeschlossen hat.", //help302
	"Die Zugriffssteuerung erlaubt Ihnen, Zugriffe in und aus Ihrem Netzwerk zu steuern. Verwenden Sie die Funktion als Zugriffssteuerung, um Zugang zu nur zugelassenen Seiten zu erlauben. Begrenzen Sie den Netzzugang zeit- oder datumbasiert und/oder blockieren Sie den Internetzugang für Anwendungen wie P2P Programme oder Spiele.", //aa_intro
	"Hier wird angezeigt, welche Klienten von Ihnen festgelegt wurden, um reservierte DHCP-Adressen zu beziehen. Ein Eintrag kann durch Anklicken des Symbols Bearbeiten verändert, bzw. durch Anklicken des Symbols Löschen entfernt werden. Durch das Anklicken des Symbols Bearbeiten wird das Objekt markiert und der Abschnitt &quot;DHCP-Reservierung bearbeiten&quot; wird zum Vornehmen von Änderungen aktiviert.", //help348
	"Die IP-Adressen der Pakete, die vom DMZ Host empfangen werden, sind von der WAN IP-Adresse des Routers zum LAN IP-Adresse des DMZ Hosts übersetzt worden. Die IP-Portnummern werden jedoch nicht übersetzt, damit Anwendungen auf dem DMZ Host mit den speziellen Portnummern verbunden sind.", //haf_dmz_30
	"Information", //sl_Infrml
	"Drahtlos", //_wireless
	"Radius-Server IP-Adresse", //bws_RIPA
	"Ein Aktivieren dieser Option kann Schutz vor bestimmten Arten von \"Spoofing\"-Angriffen bieten. Diese Option sollte jedoch mit der nötigen Vorsicht aktiviert werden. Bei einigen Modems kann die WAN-Verbindung verlorengehen, wenn sie aktiviert wird. In dem Fall kann es erforderlich sein, für das LAN-Subnetz eine andere Adresse als 192.168.0.x anzugeben (z. B. 192.168.2.x), um die WAN-Verbindung wieder herzustellen.", //KR108
	"Wenn automatische Uplink Geschwindigkeit deaktiviert ist, kann diese manuell eingestellt werden. Uplink Geschwindigkeit ist die Geschwindigkeit, mit der Daten vom Router an Ihren Internetdienstanbieter übertragen werden können. Sie wird durch Ihr Internetdienstanbieter festgelegt. Internetdienstanbieter spezifizieren häufig Geschwindigkeit als Downlink/Uplink Paar; z.B. 1.5Mbit/s zu 284Kbit/s. Für dieses Beispiel würden Sie „284“ eintragen. Alternativ können Sie Ihre Uplink Geschwindigkeit mit einem Service wie <a href='http://www.dslreports.com'>www.dslreports.com</a> testen. Beachten Sie jedoch, dass Seiten wie DSL-Reports, weil sie Netzwerksprotokoll Overhead nicht berücksichtigen, im Allgemeinen etwas niedrigere Werte messen, als die Internetdienstanbieter angeben.", //help83
	"Wenn die <strong>Gemessene Uplink Geschwindigkeit</strong> falsch ist (das heißt, sie produziert zu geringe Leistung), deaktivieren Sie <strong>Automatische Uplink Geschwindigkeit</strong> und geben Sie die <strong>Manuelle Uplink Geschwindigkeit</strong> ein. Ein paar Experimente und Leistungsmessungen können nötigt sein, um die optimale Einstellung zu finden.", //hhase_intro
	"Fehler beim Laden der Konfiguration aus permanentem Speicher (Magic Number stimmt nicht überein). Konfiguration auf Herstellerstandards zurücksetzen", //RUNTIME_CONFIG_MAGIC_NUM_ERROR
	"Sa", //_Sat
	"Webseiten Filter Regeln", //awf_title_WSFR
	"Sie können einen Computer von der Liste der DHCP Clients im „Computer Name“ Pulldown-Menü auswählen, oder Sie können die IP-Adresse des Server Computers manuell eingeben.", //help18_a
	"Zugriff NUR auf diese Websites ERLAUBEN", //dlink_wf_op_1
	"Far Cry", //gw_gm_18
	"Call of Duty", //gw_gm_7
	"USB-Massenspeicher mit Teilklasse %u und Protokoll %u gefunden", //USB_LOG_STORAGE_TYPE
	"Game-Server", //help346
	"Alle aktuellen Einstellungen gehen dadurch verloren.", //up_rb_5
	"WEP", //_WEP
	"MS-CHAP-Authentifizierungsantwort senden (Keine Wiederholung nach Fehler)", //IPMSCHAP_AUTH_FAIL_AND_NO_RETRY
	"SWAT 4", //gw_gm_82
	"Die unterstützten Authentifizierungs-Protokolle sind PAP und CHAP.", //bw_sap
	"Geben Sie die statischen Adressinformationen ein, welche Sie von Ihrem Internetdienstanbieter (ISP) erhalten haben.", //bwn_msg_SWM
	"Die Netzwerkverbindung ist offenbar ausgefallen. Klicken Sie auf 'Ok' und versuchen Sie es erneut.", //li_alert_2
	"Wenn Zugriffskontrolle deaktiviert ist, hat jedes Gerät im LAN uneingeschränkten Zugriff zum Internet. Bei eingeschalteter Zugriffskontrolle  ist Internet-Zugriff für die Geräte eingeschränkt, für die eine Zugriffskontroll-Regel gilt. Alle anderen Geräte haben weiterhin uneingeschränkten Zugriff zum Internet.", //help120
	"IGMP Host hat die Gruppe %v wegen  zu niedriger System Reserven abgelehnt", //IGMP_HOST_LOW_RESOURCES
	"- Genau 10 oder 26 Zeichen (Zahlen 0-9 und/oder Buchstaben A-F)", //wwl_s4_intro_z3
	"Aktivieren Sie diese Option zur Leistungssteigerung und um Ihnen einen höheren Erlebniswert bei Online-Spielen und anderen interaktiven Anwendungen, wie z. B. VoIP, zu verschaffen.", //help78
	"Windows 2000", //help339
	"IPv6 Simple Security aktivieren", //IPv6_Simple_Security_enable
	"Geben Sie den Portbereich ein, den Sie für den Internetdatenverkehr öffnen möchten (z. B. <code>6000-6200</code>).", //help51
	"DIE ADRESSIERUNG DER INTERNETSEITE ERFUHR VON PPPoE-KONFLIKTEN MIT DER FÜR DIE LAN-SEITE GEWÄHLTEN ADRESSIERUNG. DIE INTERNETKOMMUNIKATION WIRD DEAKTIVIERT, BIS DIE ADRESSIERUNG DER LAN-SEITE GEÄNDERT UND DAS PROBLEM BEHOBEN WURDE.", //GW_WAN_LAN_ADDRESS_CONFLICT_PPP
	"Fehler", //ss_Errors
	"Wenn ein dynamisches DNS-Update aus irgendeinem Grund ausfällt (zum Beispiel, wenn falsche Parameter eingetragen wurden), sperrt der Router automatisch die dynamische DNS-Funktion und notiert den Ausfall im Log.", //help899
	"Geben Sie bitte den grafischen Authentifizierungskode ein.", //li_alert_4
	"Die Option DMZ ermöglicht Ihnen, einen einzelnen Computer in Ihrem Netzwerk außerhalb des Routers zu stellen. Wenn Sie einen Computer haben, auf dem Internet-Anwendungen hinter dem Router nicht erfolgreich ausgeführt werden, können Sie den Computer für uneingeschränkten Internet-Zugriff in der DMZ platzieren.", //haf_dmz_40
	"Klicken Sie auf das Symbol \"Bearbeiten\", um einen vorhandenen Zeitplan zu ändern.", //hhts_edit
	"Name des drahtlosen Netzwerks (SSID)", //wwl_wnn
	"Website %S aufgerufen von %s", //WEB_FILTER_LOG_URL_ACCESSED_MAC
	"WMM aktivieren", //aw_WE
	"Installieren Hilfe", //help201a
	"Aktivieren Sie hier Ihre KOSTENLOSE 30 Tage-Testversion", //_bsecure_activate_trial
	"Geben Sie das Kennwort oder den Schlüssel ein, das/den Sie von Ihrem Internetdienstanbieter erhalten haben. Hat Ihnen Ihr Internetdienstanbieter nur einen Schlüssel bereitgestellt, geben Sie diesen Schlüssel in alle drei Felder ein.", //help896
	"Das Kommunikationsprotokoll wird für die Unterhaltung verwendet.", //help815
	"Netzmaske", //_netmask
	"bitte warten...", //_please_wait
	"Wiederholen Sie diese Schritte für jede virtuelle Serverregel, die Sie hinzufügen möchten. Klicken Sie nach Fertigstellung der Liste im oberen Bereich der Seite auf <span class='button_ref'>Einstellungen speichern</span>.", //help12
	"Der MAC-Adressen-Filter (Media Access Controller) wird verwendet, um den Netzwerkzugang auf der MAC-Adresse basierend zu steuern. Eine MAC-Adresse ist eine einzigartige Identifikation, die vom Hersteller des Netzwerkadapters vergeben wird. Diese Eigenschaft kann genutzt werden, um Netzwerk-/Internetzugang ZU ERLAUBEN oder ZU VERWEIGERN.", //am_intro_1
	"LCP legt lokale Authentifizierung fest: %04x", //IPPPPLCP_SET_LOCAL_AUTH
	"Crimson Skies", //gw_gm_11
	"Einstellungen nicht übernehmen", //_dontsavesettings
	"Der WPA-Schlüssel (Wi-Fi Protected Access) muss die folgenden Richtlinien erfüllen", //wwl_s4_intro_za1
	"MTU-Standard =", //_308
	"MAC", //aa_AT_1
	"Lokaler L2TP-Tunnel 0x%04X abgebrochen", //IPL2TP_TUNNEL_ABORTING
	"DHCP-Reservierung Hinzufügen/Bearbeiten", //help330
	"L2TP Klient.", //wwa_msg_l2tp
	"4:00 AM", //tt_time_5
	"Geben Sie die IP-Adresse des Rechners in Ihrem LAN ein (z. B.: <code>192.168.0.50</code>).", //help6
	"ZEIT", //_time
	"xDSL- oder Anderes Frame Relay-Netzwerk", //at_xDSL
	"Schritt 2: Setup-Programm auf dem Rechner starten", //wprn_intro4
	"Normalerweise wird dieses auf „Auto“ eingestellt. Wenn Sie mit dem WAN Anschluss Probleme haben, versuchen Sie die anderen Einstellungen.", //help296
	"LAN", //_LAN
	"Warcraft III", //gw_gm_60
	"Legen Sie fest, für welches Gerät diese Richtlinie gelten soll.", //_aa_wiz_s4_msg
	"64 Bit", //wwl_64bits
	"Datenträger ist voll", //IPFAT_DISK_FULL
	"Klicken Sie auf Start, Programme, Zubehör und wählen Sie die Eingabeaufforderung aus. In die Eingabeaufforderung schreiben Sie <code>ipconfig /all</code> und drücken die Enter Taste. Die MAC-Adresse ist die angezeigte physikalische Adresse der Netzwerkkarte, welche am Router angeschlossen ist.", //help341
	"Zum Verwerfen der Änderungen und Anzeigen der Zeitplan-Seite auf 'Ok' klicken.", //aa_sched_conf_2
	"Versuch, lokale L2TP-Sitzung 0x%04X zu starten", //IPL2TP_SESSION_CONNECTING
	"Zeitsynchronisierung fehlgeschlagen (Status %d)", //NET_RTC_SYNCHRONIZATION_FAILED
	"Automatisch online nach neuester Firmware-Version suchen", //tf_AutoCh
	"Der Druckerhersteller und/oder das Modell konnte nicht gefunden werden. Grund hierfür ist wahrscheinlich eine ungültige ID des Druckers. Der Assistent kann ohne diese Informationen nicht fortfahren.", //wprn_iderr2
	"Diese zwei IP Werte (<i>von</i> und <i>bis</i>) definieren einen Bereich von IP-Adressen, die der DHCP Server verwendet, wenn er an Computer und Geräte in Ihrem lokalen Netzwerk Adressen zuweist. Adressen außerhalb dieses Bereiches werden nicht durch den DHCP Server verwaltet; diese können für manuell konfigurierte Geräte oder für Geräte, die die Adresse nicht automatisch über DHCP beziehen können, verwendet werden.", //help319
	"Wird ein Rechner in die DMZ gesetzt, ist dieser Rechner ggf. zahlreichen Sicherheitsrisiken ausgesetzt. Diese Option sollte daher nur als sekundäre Möglichkeit genutzt werden.", //af_intro_2
	"Durch Anklicken dieser Schaltfläche wird die Anzeige der Protokolleinträge aktualisiert. Seit dem letzten Anzeigen des Protokolls sind möglicherweise neue Ereignisse aufgetreten.", //help800
	"Geräteinformationen", //sd_title_Dev_Info
	"Filter des Internetzugangs-Ports hat Datenpakete von %v bis %v (Protokoll %u) verworfen", //GW_INET_ACCESS_DROP_PORT_FILTER
	"Windows Connect Now", //_connow
	"SIP ALG lehnte Paket von %v:%u nach %v:%u ab", //IPSIPALG_REJECTED_PACKET
	"TCP-Paket von %v:%u bis %v:%u fallengelassen, da Änderung der Header-Optionen nicht möglich", //IPNAT_TCP_UNABLE_TO_MODIFY_OPTIONS
	"NTP-Server auswählen", //tt_SelNTPSrv
	"Eine rauschende Funkfrequenz kann eine hohe Fehlerrate im Wireless LAN verursachen.", //help812
	"Benutzer", //_user
	"(GMT+08:00) Taipeh", //up_tz_59
	"Spezialanwendungen", //SPECIAL_APP
	"Keine", //wwl_NONE
	"WAN-Dienste werden gestartet", //GW_WAN_SERVICES_STARTED
	"Unzulässiger Webzugriff", //fb_FbWbAc
	"Sie öffnen die webbasierte Benutzeroberfläche und klicken jedesmal manuell die Verbindungstaste, wenn Sie eine Verbindung zum Internet herstellen möchten.", //help275
	"Kein Drucker gefunden", //wprn_nopr
	"Zeitzone", //tt_TimeZ
	"Tipps für die Fehlersuche", //wprn_tt
	"Wählen Sie Ihre lokale Zeitzone aus dem Klappmenü aus.", //help841
	"Neuen Zeitplan festlegen", //aa_sched_new
	"1:00 PM", //tt_time_14
	"HTTP", //gw_vs_1
	"Einstellungen SysLog", //tsl_SLSt
	"H.323 ALG lehnte Paket von %v:%u nach %v:%u ab", //IPH323ALG_REJECTED_PACKET
	"Schritt 4 - Festlegen der Filtermethode", //aa_wiz_s1_msg4
	"Windows 98", //help336
	"Systemname", //ta_sn
	"Je nachdem, ob Sie aktuell bei BigPond angemeldet sind oder nicht, können Sie entweder auf <span class='button_ref'>BigPond Login</span> klicken, um zu versuchen, eine WAN-Verbindung herzustellen, oder auf <span class='button_ref'>BigPond Logout</span> klicken, um die WAN-Verbindung zu trennen.", //help780
	"Schnittstelle", //_interface
	"Website %S für %v gesperrt", //WEB_FILTER_LOG_URL_BLOCKED
	"Der Port für Remote-Administration steht im Konflikt mit dem virtuellen Server.", //vs_http_port
	"Der Router stellt eine strenge Firewall, die wie NAT arbeitet, zur Verfügung. Auch wenn Sie den Router anders konfigurieren, reagiert NAT nicht auf ungebetene ankommende Anfragen auf einem beliebigen Port. Dadurch bleibt Ihr LAN für Angreifer aus dem Internet unsichtbar. Für Netzwerk-Anwendungen, die nicht mit dieser strengen Firewall arbeiten, müssen Ports in der Firewall selektiv geöffnet werden. Die Optionen auf dieser Seite steuern einige Methoden des Öffnens der Firewall, um die Erfordernisse spezieller Anwendungs-Typen zu erfüllen.", //haf_intro_1
	"(GMT-06:00) Mittelamerika", //up_tz_07
	"Wenn Sie mit diesen erweiterten Wireless-Einstellungen nicht vertraut sind, lesen Sie bitte die Hilfe bevor Sie diese Einstellungen ändern.", //aw_intro
	"Gateway-Adresse", //wwa_gw
	"Sentinel Service", //_sentinel_serv
	"Wählen Sie diese Option, wenn Ihr Internetdienstanbieter Ihnen IP-Adressinformationen gegeben hat, die manuell eingerichtet werden müssen.", //wwa_msg_sipa
	"TCP-Paket von %v bis %v fallengelassen, da Paketheader nicht verarbeitbar", //IPNAT_TCP_UNABLE_TO_HANDLE_HEADER
	"Sie können einen Computer aus der Liste der DHCP Clients im <strong>Computer Name</strong> Pulldown-Menü auswählen, oder Sie können die IP-Adresse des Computers manuell eingeben, auf dem Sie den spezifizierten Port öffnen möchten.", //hhav_ip
	"Nur wenige Anwendungen benötigen wirklich einen DMZ Host. Für folgende Beispiele könnte ein DMZ Host benötigt werden:", //haf_dmz_50
	"Richtlinie %s wurde angehalten; Der Internetzugriff wurde für MAC-Adresse %m geändert auf: %s", //GW_INET_ACCESS_POLICY_END_MAC
	"Die Option Zeitplankonfiguration wird verwendet, um Zeitplanregeln für verschiedene Firewall- und Jugendschutzfilter-Funktionen zu verwalten.", //tsc_intro_Sch
	"Zugang verweigert für drahtloses System mit MAC-Adresse %m ", //GW_WLAN_ACCESS_DENIED
	"Lokaler Domain Name", //_262
	"Diese Option ist standardmäßig aktiviert, damit Ihr Router automatisch feststellen kann, welche Programme eine Netzwerkpriorität haben sollten.", //help79
	"BigPond nicht richtig konfiguriert", //GW_BIGPOND_CONFIG
	"Hoch", //aw_TP_0
	"Verbindungsaufbau (warten Sie bitte…)", //_sdi_s3
	"Ping-Resultat", //tsc_pingr
	"IPv6 Ping-Test", //tsc_pingt_v6
	"WPA-Personal", //_WPApersonal
	"Email-Einstellungen", //_email
	"PPPoE Sitzungsangebot wird bestätigt", //PPPOE_EVENT_DISCOVERY_REQUEST
	"Firewall", //_firewall
	"Verbindung mit statischer IP-Adresse", //wwa_wanmode_sipa
	"Systemprüfung", //_syscheck
	"Die LAN-seitige IP-Adresse des Clients.", //help784
	"Unbekannt", //UNKNOWN
	"UPnP, kurz für Universal Plug-and-Play, ist eine Vernetzungs-Architektur, die Kompatibilität zwischen Netzwerk-Geräten, -Software und -Peripherie herstellt. Dieser Router hat UPnP-Fähigkeit und kann mit anderen UPnP- Geräten und -Software zusammenarbeiten.", //help_upnp_1
	"Wolfenstein: Enemy Territory", //gw_gm_61
	"(optional)", //_optional
	"Wird ein zu geringer Fragmentierungswert eingestellt, führt dies zu einer schlechten Leistung.", //help181
	"Internet", //help569
	"Wenn Sie mit diesen erweiterten Netzwerkeinstellungen nicht vertraut sind, lesen Sie bitte zuerst die Hilfe dazu, bevor Sie versuchen, diese Einstellungen zu ändern.", //anet_intro
	"Geben Sie oben das korrekte Kennwort ein<br> und geben Sie dann die Zeichen, die Sie im<br> Bild unten sehen, ein.", //_authword
	"Blockiertes ausgehendes TCP Paket von %v:%u nach %v:%u, %s hat zwar empfangen, aber es gibt keine aktive Verbindung", //IPNAT_TCP_BLOCKED_EGRESS_NOT_SYN
	"Gateway-Name", //ta_GWN
	"Falls Sie nicht die erforderliche Berechtigung zur Änderung der Routerkonfiguration besitzen, wenden Sie sich an Ihren Administrator.", //wprn_tt3
	"MTU", //help293
	"Wählen Sie diese Option, wenn Ihnen Ihr ISP eine feste IP-Adresse zugewiesen hat. Der ISP liefert den Wert für", //help265_2
	"Paket von %v bis %v (IP-Protokoll %u) fallengelassen, da keine neue Sitzung hergestellt werden kann", //IPNAT_UNABLE_TO_CREATE_CONNECTION
	"Immer aktiv", //help270
	"Erweiterte Drahtlos-Einstellungen", //aw_title_2
	"Firewall-Einstellungen", //_firewalls
	"Aktiviert/Nicht konfiguriert", //LW67
	"PPPoE-Sitzung 0x%04X hergestellt", //PPPOE_EVENT_UP
	"Protokoll", //_protocol
	"WPA-Personal und WPA-Enterprise", //help372
	"(GMT+02:00) Bukarest", //up_tz_32
	"KBit/s", //at_kbps
	"Kabel- oder Anderes Breitbandnetzwerk", //at_Cable
	"100Mbit/s", //anet_wp_1
	"Ordnen Sie dem Virtuellen Server einen sinnvollen Namen zu, z.B. <code>Webserver</code>. Einige bekannte Virtuelle Server-Typen sind  bereits in der „Anwendungs-Name“ Dropdown-Liste. Die Wahl einer dieser Einträge ergänzt auch einige der restlichen Parameter mit Standardwerten für diesen Server-Typ.", //help17
	"Standardmäßig wird kein Passwort verwendet. Es wird empfohlen ein Passwort zu verwenden, um den Router zu schützen.", //ta_intro_Adm2
	"Bitte überprüfen", //tool_admin_check
	"PPP-Netzwerk mit IP-Adresse %v ist aktiv", //IPPPPIPCP_PPP_LINK_UP
	"Stopp", //_stop
	"Syslog-Server eingestellt als IP-Adresse %v", //GW_SYSLOG_STATUS
	"DHCP-Servereinstellung", //bd_title_DHCPSSt
	"Der Name des Routers kann hier geändert werden.", //help827
	"Aktuelle Firmware-Version prüfen", //tf_FWCheckInf
	"FIRMWARE- und SPRACHPAKET-INFORMATIONEN", //tf_FWInf
	"Bis zu acht Bereiche von WAN IP-Adressen können mit jeder Regel gesteuert werden. Das Auswahlfeld zu jedem IP-Bereich kann benutzt werden, um die bereits definierten Bereiche zu sperren.", //hhai_ipr
	"Es wird empfohlen, diese Parameter auf ihren vorgegebenen Wert zu belassen. Veränderungen könnten die Leistung Ihres drahtlosen Netzwerks beeinträchtigen.", //hhaw_1
	"Ermöglicht mehreren VPN-Clients sich mithilfe von IPSec mit ihren Firmennetzwerken zu verbinden. Einige VPN-Clients unterstützen die Traversierung von IPSec durch NAT. Diese Option behindert möglicherweise den Betrieb solcher VPN-Clients. Wenn Sie Probleme mit der Verbindung zu Ihrem Firmennetzwerk haben, versuchen Sie, diese Option zu deaktivieren.", //help34
	"Netzwerk USB Autom. Erkennung", //_network_usb_auto
	"Die Subnetzmaske von Ihrem Router im lokalen Netzwerk.", //help309
	"Sie können neue MAC-Adressen nicht hinzufügen. Sie können MAC-Adressen nur von anderen Regeln übernehmen.", //aa_alert_15
	"Einstellungen speichern", //_savesettings
	"Geben Sie dem Zeitplan einen beschreibenden Namen, wie z. B. &quot;Wochenregel&quot;.", //help193
	"Virtuelle Server Einstellungen", //help14_p
	"Need for Speed: Hot Pursuit 2", //gw_gm_32
	"Blockierte ankommende TCP Verbindungsaufforderung  von %v:%u nach %v:%u", //IPNAT_TCP_BLOCKED_INGRESS_SYN
	"Wenn Sie diese Funktion aktivieren, antwortet der WAN Port Ihres Routers auf Ping-Anfragen vom Internet, die zur WAN IP-Adresse gesendet werden.", //anet_msg_wan_ping
	"Eingangs-Filter können für die Begrenzung des Zugriffs auf einen Server in Ihrem Netzwerk, zu einem System oder zu einer Gruppe von Systemen verwendet werden.", //ai_intro_2
	"L2TP Subnetzmaske", //help285
	"Statistiken LAN", //ss_LANStats
	"Die Wiederherstellung wird bereits ausgeführt.", //ta_alert_4
	"MAC-Adresse des PCs kopieren", //_clone
	"Diablo I und II", //gw_gm_14
	"GRE-Paket von %v bis %v fallengelassen, da Paketheader nicht verarbeitbar", //PPTP_ALG_GRE_UNABLE_TO_HANDLE_HEADER
	"Bestimmte Zugriffe blockieren", //_aa_block_some
	"Hergestellt -- die Verbindung übermittelt Daten.", //help819_3
	"11:00 PM", //tt_time_24
	"Normalerweise wird eine E-mail zum Start eines Zeitplanes gesendet. Die Endzeit wird nicht verwendet. Jedoch veranlaßt das Neu-Starten des Routers auch während eines Zeitplans das Versenden weiterer E-mails.", //help873
	"Kollisionen", //ss_Collisions
	"Geben Sie zum Senden der Email die SMTP-Server Adresse ein.", //help863
	"Diese Option ermöglicht die Konfiguration eines optionalen zweiten RADIUS-Servers. Ein zweiter RADIUS-Server kann als Sicherung für den primären RADIUS-Server verwendet werden. Der zweite RADIUS-Server wird nur hinzugezogen, wenn der primäre Server nicht vorhanden ist oder nicht reagiert. Die Felder <span class='option'>Zweite RADIUS-Server IP-Adresse</span>, <span class='option'>RADIUS-Server Port</span>, <span class='option'>Zweiter RADIUS-Server Shared Secret</span>, <span class='option'>Zweite MAC-Adressen Authentifikation</span> stelle die entsprechenden Parameter für den zweiten RADIUS-Server zur Verfügung.", //help397
	"Liste der virtuellen Server", //av_title_VSL
	"OFDM", //help636
	"Benachrichtigung per E-Mail senden, sobald eine neuere Firmware zur Verfügung steht", //tf_ENFA
	"Mit diesem Virtueller Server-Eintrag wird der gesamte Internet-Traffic an Port 8888 weitergeleitet an Ihren internen Webserver auf Port 80 mit der IP-Adresse 192.168.0.50.", //help13
	"Schritt 3: Richten Sie Ihre Internetverbindung ein", //wwa_title_s3
	"Schritt 1: Konfigurieren Sie Ihre Internetverbindung", //ES_wwa_title_s1
	"Überprüfung der WAN-Schnittstellengeschwindigkeit abgebrochen, da kein Grenzwert erreicht wurde", //GW_WAN_RATE_ESTIMATOR_CONVERGENCE_ERROR
	"BigPond", //wwa_wanmode_bigpond
	"Im WAN Kapitel (Wide Area Network) konfigurieren Sie den Internet-Verbindungstyp.", //help254
	"Um ankommende Verbindungen zu verarbeiten, die ein anderes Protokoll als ICMP, TCP, UDP und IGMP verwenden (auch GRE und ESP, wenn diese Protokolle durch die PPTP und IPSec ALGs aktiviert werden).", //haf_dmz_70
	"Systemfehler beim Zuordnen zu Plan %s aufgetreten", //GW_SCHED_ATTACH_FAILED
	"Das SSID-Feld darf nicht leer sein", //_badssid
	"Konfiguration wurde in permanentem Speicher gespeichert", //RUNTIME_CONFIG_STORING_CONFIG_IN_NVRAM
	"Firmware-Update verfügbar", //FW_UPDATE_AVAILABLE
	"Die Funktion Dynamic DNS erlaubt Ihnen einen Server (Web, FTP, Game etc.) mit Ihrer eigenen Internet-Domain (z.b. www.ihrname.eu) auch bei einer dynamischen Zuordnung der IP-Adresse zu betreiben. Die meisten Internet Service Provider verwenden dynamische IP-Adressen.", //help891
	"PPPoE-, PPTP-, L2TP-Verbindung", //help777
	"MAC-Adresse Authentifizierung", //help393
	"Internet-Verbindungstyp", //bwn_ict
	"Jun.", //tt_Jun
	"Lokaler L2TP-Tunnel 0x%04X wurde verbunden mit \'%s\'", //IPL2TP_TUNNEL_CONNECTED
	"Command and Conquer Zero Hour", //gw_gm_9
	"Aliens vs. Predator", //gw_gm_2
	"Drahtlosnetzwerkinstallations-Assistent", //wwl_wl_wiz
	"DHCP-Bereich ungültig, der Anfangswert darf nicht größer sein als der Endwert", //network_dhcp_range
	"Schritt 4: Testseite drucken", //wprn_intro6
	"BigPond fehlgeschlagen, Status=%d mit Fehler=%d, Serverantwort=%s", //GW_BIGPOND_FAIL
	"Adresse beschränkt", //af_EFT_1
	"Unicasting verwenden", //_use_unicasting
	"Netzwerk-Status", //_networkstate
	"Jahr", //tt_Year
	"Einrichten von USB-Gerät ist fehlgeschlagen", //IPASYNCFILEUSB_MOUNT_FAILED
	"UDP Endpunkt Filterung", //af_UEFT
	"Standardmäßig wird die schnellstmögliche Übertragungsrate ausgewählt. Sie haben die Möglichkeit, die Geschwindigkeit auszuwählen,falls dies nötig sein sollte.", //help356
	"Vorinstallierter Schlüssel", //help381
	"Eingehender Filter", //_inboundfilter
	"Erweiterte Portfilter verwenden", //_aa_apply_port_filter
	"Ziel<br />Port<br />Ende", //aa_FPR_c7
	"Jedi Knight III: Jedi Academy", //gw_gm_27
	"BigPond nicht richtig konfiguriert", //BIGPOND_NOT_PROPERLY_CFGD
	"Alternativ dazu können Sie eine MAC-Adresse bei bestimmten Betriebssystemen auch wie nachfolgend beschrieben ausfindig machen:", //help335
	"(GMT+08:00) Perth", //up_tz_58
	"Nie", //_never
	"Klicken Sie diese Taste an, um alle Log-Einträge zu löschen.", //help801
	"Längste Pingzeit (in Millisekunden):", //tsc_pingt_msg105
	"WARNUNG: JavaScript steht für diesen Browser nicht zur Verfügung!", //li_WJS
	"An E-Mail-Adresse", //te_ToEm
	"12:00 AM", //tt_time_1
	"Signal", //help787
	"IPv6 DNS-Server-Adresse automatisch beziehen", //IPV6_TEXT65_v6
	"Gateway-Protokolle", //GW_EMAIL_SUBJ
	"Port Trigger ALG konnte die Sitzung für das UDP-Paket nicht von %v:%u auf %v:%u zuweisen", //IPPORTTRIGGERALG_UDP_PACKET_ALLOC_FAILURE
	"Wenn Sie zum ersten Mal einen Router im Netzwerk konfigurieren, klicken Sie <span class=\"button_ref\">Setup-Assistent</span> an und der Router wird Sie durch einige einfache Schritte führen, um Ihr Netzwerk in Betrieb zu nehmen.", //bi_wiz
	"Aus", //_Out
	"Im <strong>Anwendungs- Name</strong>Pulldown-Menü finden Sie eine Liste der vorkonfigurierten Anwendungen. Um eine der vorkonfigurierten Anwendungen auszuwählen, klicken Sie die Pfeiltaste beim  Pulldown-Menü, um den entsprechenden Bereich zu markieren.", //hhpt_app
	"DHCP-Verbindung (Dynamische IP-Adresse)", //_dhcpconn
	"Router-Einstellungen", //bln_title_Rtrset
	"Druckserver", //_ps
	"Dieser Eintrag ist optional. Geben Sie einen Domain-Namen für das lokale Netzwerk ein. Der DHCP-Server des Access Point sendet diesen Domain-Namen an die Computer im WLAN. Wenn Sie hier beispielsweise <code>meinnetzwerk.net</code> eingeben und Sie haben einen drahtlosen Laptop mit einem Namen wie z. B.<code>Franz</code>, wird der Laptop als <code>franz.meinnetzwerk.net</code> bezeichnet.", //_1044
	"Wählen Sie diese Option, wenn Ihre Wireless-Netzwerkkarte WPA2 unterstützt", //wwl_text_best
	"PPTP-Server-IP-Adresse (kann gleich dem Gateway sein)", //wwa_pptp_svraddr
	"Überprüfung der WAN-Schnittstellengeschwindigkeit abgeschlossen. Die Upstream-Geschwindigkeit beträgt %u kbit/s.", //GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED
	"LAN-Rechner", //_LANComputers
	"Es empfiehlt sich, die Email Einstellungen an die Einstellungen Ihres Email-Client-Programms anzupassen.", //hhte_intro
	"H.323 (NetMeeting)", //as_NM
	"Setup-Assistent", //wwa_setupwiz
	"und", //help264
	"(kompatibel mit einigen DHCP-Servern)", //bw_WDUU_note
	"MMS", //as_MMS
	"Dienstname", //_srvname
	"Die Regel wird auf jeglichen Datenfluss angewendet, dessen LAN-seitige IP-Adresse in den hier festgelegten Bereich fällt.", //help93
	"Minute", //tt_Minute
	"Stand", //sa_State
	"802.11d aktivieren", //aw_dE
	"Host-Name oder IP-Adresse", //tsc_pingt_h
	"Hostname oder IPv6-Adresse", //tsc_pingt_h_v6
	"Statistiken Wireless", //ss_WStats
	"MS-CHAP-Authentifikator-Sendeanforderung", //IPMSCHAP_AUTH_SEND_CHALLENGE
	"Wenn diese Option aktiviert ist, überprüft Ihr Router regelmäßig im Internet, ob eine neuere Firmware-Version verfügbar ist.", //help889
	"H.323 (NetMeeting)", //as_H323
	"Portweiterleitung", //tool_admin_pfname
	"Paket von %v bis %v (Protokoll %u) fallengelassen, da Sitzung bereits vorhanden", //IPNAT_SESSION_ALREADY_EXISTS
	"BigPond-Kabelverbindung einrichten", //wwa_title_set_bigpond
	"(GMT-04:00) Santiago", //up_tz_16
	"BigPond Status hat sich geändert. Neuer Status=%d", //GW_BIGPOND_STATUS
	"Um diese Verbindung zu konfigurieren brauchen Sie einen Benutzernamen und ein Passwort von Ihrem Internetdienstanbieter. Sie benötigen auch die BigPond Server IP-Adresse. Wenn Sie diese Informationen nicht haben, setzen Sie sich bitte mit Ihrem Internetdi", //wwa_msg_set_bigpond
	"Aktivieren Sie mindestens einen Remote-IP-Bereich für %s", //ai_alert_5
	"Wählen Sie diese Option aus, wenn Sie Router Zeit mit einem Network-Time-Server (NTP) im Internet synchronisieren möchten. Wenn Sie Zeitpläne oder Log-Dateien benutzen, ist dieses die beste Methode, um die verwendete Zeit stets aktuell zu halten.", //help848
	"Return to Castle Wolfenstein", //gw_gm_41
	"Richtlinien-Assistent", //_aa_pol_wiz
	"IP Filter", //IP_FILTERS
	"Starsiege Tribes", //gw_gm_50
	"Wählen Sie bitte unten Ihren Internet-Verbindungstyp:", //wwa_intro_s3
	"ESP-Paket ab %v fallengelassen, da Verbindungsversuch von %v bis %v bereits ausstehend", //IPSEC_ALG_ESP_ESTABLISH_ALREADY_PENDING
	"Einzel (80, 68, 888)", //help59
	"Möchten Sie die Konfigurierung des Gerätes wirklich zurücksetzen?", //wps_reboot_need
	"Dynamische Fragmentierung", //at_DF
	"Falls die Server des Internet Service Providers nach dem Herstellen einer Verbindung die IP-Adresse zuweisen, wählen Sie diese Einstellung.", //help265_7
	"DST Endmonat muss unterschiedlich sein zu DST Anfangsmonat.", //tt_alert_dstchkmonth
	"(GMT-01:00) Kapverdische Inseln", //up_tz_23
	"Erweitert", //_advanced
	"Statische IP-Adresse", //STATIC_IP_ADDRESS
	"Schritt 2: Sichern Sie Ihr Wireless-Netzwerk", //wwl_title_s3
	"Dies ist eine Liste aller Drahtlosnetzwerke, die gegenwärtig mit dem Router verbunden sind.", //hhsw_intro
	"MENÜ", //ish_menu
	"(GMT+02:00) Kairo", //up_tz_33
	"Suchen nach neuer Firmware fehlgeschlagen", //GW_FW_NOTIFY_FIRMWARE_ERROR
	"Weitere Informationen...", //_bsecure_more_info
	"Aktuelle Firmware-Version", //tf_CFWV
	"2", //tt_week_2
	"Beispiel:", //help3
	"Autor", //_creator
	"DNS-Relais", //bln_title_DNSRly
	"Portfilter für Internetzugriff hat Paket verloren von %v:%u[%s] bis %v:%u (Protokoll %u)", //GW_INET_ACCESS_DROP_PORT_FILTER_MAC
	"Glossar", //ish_glossary
	"Ein längerer WEP-Schlüssel ist sicherer als ein kurzer", //wwl_s4_intro_z4
	"Standardmäßig ist die Zugriffskontroll-Funktion deaktiviert. Wenn Sie Zugriffskontrolle benötigen, überprüfen Sie diese Option.", //help118
	"Shareaza", //gw_gm_66
	"Ist die Option DNS-Relais aktiviert, übernimmt der Router die Rolle eines DNS-Servers. DNS-Anfragen, die an den Router gesendet werden, werden an den DNS-Server des Internetdienstanbieters weitergeleitet. Dieser stellt eine permanente DNS-Adresse bereit, welche die Rechner im LAN selbst dann nutzen können, wenn der Router nach einer erneuten Herstellung der WAN-Verbindung eine andere DNS-Serveradresse vom Internetdienstanbieter zugewiesen erhält. Deaktivieren Sie die Option DNS-Relais, wenn Sie einen LAN-seitigen DNS-Server als virtuellen Server implementieren.", //help312dr2
	"Ganzer Tag – 24 Stunden", //tsc_24hrs
	"Im <strong>Anwendungs- Name</strong>Pulldown-Menü finden Sie eine Liste der vorkonfigurierten Anwendungen. Um eine der vorkonfigurierten Anwendungen auszuwählen, klicken Sie die Pfeiltaste beim  Pulldown-Menü, um den entsprechenden Bereich zu markieren.", //hhag_10
	"Einige ISP's überprüfen den Host-Namen Ihres Computers. Der Host-Name kennzeichnet Ihr System zum Server des ISP's. Dadurch weiß Ihr ISP, daß Ihr Computer berechtigt ist, eine IP-Adresse zu empfangen und daß Sie für diesen Service zahlen.", //help261
	"Auslöser Verkehrs-Typ", //as_TPrt
	"Das geschieht, wenn für diesen Rechner im LAN eine Zugriffssteuerungsregel konfiguriert wurde.", //help28
	"11:00 AM", //tt_time_12
	"Statistiken aktualisieren", //ss_reload
	"Aus", //EGRESS
	"Der folgende <span id='status_text'>Drucker is</span> ist mit Ihrem Router verbunden.", //sps_fp
	"Unreal Tournament 2004", //gw_gm_57
	"Wählen Sie diese Option, wenn Ihre Internetverbindung Ihnen automatisch eine IP-Adresse zur Verfügung stellt. Die meisten Kabelmodems verwenden diesen Verbindungstyp.", //wwa_msg_dhcp
	"Schritt 1 - Festlegen eines eindeutigen Namens für die Richtlinie", //aa_wiz_s1_msg1
	"Sie müssen als 'Administrator'angemeldet sein, um diese Aktion ausführen zu können", //MUST_BE_LOGGED_IN_AS_ADMIN
	"(GMT+09:30) Darwin", //up_tz_64
	"Ende von gw_wireless_schedule", //GW_WLS_SCHEDULE_STOP
	"Wake-on-LAN ALG lehnte Paket von %v:%u nach %v:%u ab", //IPWOLALG_REJECTED_PACKET
	"Gerät auf wsetting.wfc aktualisieren", //WCN_LOG_UPDATE
	"Diese Option sollte aktiviert sein, wenn Sie eine langsame Internetverbindung haben. Sie hilft die möglichen Auswirkungen von großen Netzwerkpaketen mit niedriger Priorität gegenüber dringenderen Datenpaketen zu reduzieren, indem die große Pakete in mehrere kleinere Pakete geteilt werden.", //help80
	"Hier können Sie Einträge zur Inbound Filterliste hinzufügen oder bereits existierende Einträge bearbeiten.", //help171
	"Mo", //_Mon
	"(GMT+10:00) Canberra, Melbourne, Sydney", //up_tz_66
	"Schritt 2: Legen Sie das Kennwort für Ihr drahtloses Netzwerk fest", //wwl_title_s4_2
	"Falls Sie nicht die Option Ganzer Tag wählen, geben Sie hier die gewünschte Zeit ein. Die Startzeit wird in zwei Feldern eingegeben. Das erste Feld dient zur Eingabe der Stunden, das zweite Feld zur Eingabe der Minuten. E-Mail-Ereignisse werden normalerweise nur durch die Startzeit ausgelöst.", //help196
	"PPPoE-Sitzungsangebot enthält Fehler. Verbindungsversuch ist fehlgeschlagen.", //PPPOE_EVENT_DISCOVERY_REQUEST_ERROR
	"Anmelden", //li_Log_In
	"Nicht-UDP/TCP/ICMP LAN Verbindungen", //af_gss
	"Standardgateway", //_defgw
	"Der NTP-Server ist nicht konfiguriert.", //YM185
	"WLAN-Gerät wird hinzugefügt:", //add_wireless_device
	"Geben Sie den öffentlichen Port als [8888] ein", //help8
	"Ihr Internetdienstanbieter (ISP) vermittelt Ihnen all diese Informationen.", //help258
	"PPPoE-Sitzung 0x%04X durch Zugriffskonzentrator beendet", //PPPOE_EVENT_TERMINATED
	"Möchten Sie wirklich einen Neustart des Geräts durchführen?", //up_rb_1
	"Benutzen Sie die Ankreuzfelder links, um fertige Virtuelle Server Einträge zu aktivieren oder zu deaktivieren.", //help25_b
	"Log Speichern", //sl_saveLog
	"Verwenden Sie diese Option um die Logs des Routers einzusehen. Sie können definieren, welche Art von Ereignissen und Ereignisebenen Sie angezeigt haben möchten. Dieser Router besitzt ebenfalls eine Syslog-Option, mit der Sie das Log auf einen sich im Netzwerk befindenden Rechner verschicken lassen können, auf dem ein Syslog Dienstprogramm läuft.", //sl_intro
	"Legen Sie einen Rechner mit dessen IP- bzw. MAC-Adresse fest, oder wählen Sie die Option &quot;Sonstige&quot; für Rechner, für welche keine Richtlinie festgelegt wurde.", //_aa_wiz_s4_help
	"WAN Schnittstellenkabel ist getrennt worden", //GW_WAN_CARRIER_LOST
	"(Byte)", //bwn_bytes
	"Registrieren Sie sich online, wenn Sie per E-Mail über neuere Firmware-Versionen benachrichtigt werden möchten.", //help890_1
	"BigPond-Verbindung", //help779
	"MAC-Adresse", //_macaddr
	"Zurückgesetzte oder geschlossene TCP-Verbindungen. Der Anschluß schließt nicht sofort, damit fortbestehende Pakete weitergegeben werden oder die Verbindung wiederhergestellt werden kann.", //help823_13
	"Management aktivieren", //ta_ELM
	"HTTPS Storage - Fernzugriff aktivieren", //sto_http_4
	"IPv4 Multicast-Streams aktivieren", //anet_multicast_enable_v4
	"Nächste dynamische DNS-Aktualisierung geplant für %s", //GW_DYNDNS_UPDATE_NEXT
	"Geben Sie das Kennwort für das Konto ein.", //help866
	"Routerstatus", //sl_RStat
	"Roger Wilco", //gw_gm_78
	"Vergeben Sie einen sinnvollen Namen für die Regel.", //help90
	"PPTP-Tunnel mit ID 0x%04X wurde geschlossen", //PPTP_EVENT_TUNNEL_DOWN
	"Statischer WAN-Modus", //bwn_SWM
	"Web-Filter lehnte Paket von %v:%u nach %v:%u ab", //IPWEBFILTER_REJECTED_PACKET
	"Ungültiges Firmware-Aktualisierungsabbild geladen – wird verworfen", //GW_UPGRADE_FAILED
	"Diese Option wird verwendet, um mehrere Ports oder einen Port-Bereich in Ihrem Router zu öffnen und Daten durch jene Ports zu einem einzelnen PC in Ihrem Netzwerk weiterzuleiten. Diese Funktion erlaubt Ihnen, Ports in  verschiedenen Formaten einzugeben,  einschließlich Port-Bereiche (100-150), einzelne Ports (80, 68, 888), oder gemischt (1020-5000, 689).", //ag_intro
	"Die Admin-Option wird verwendet, um ein Kennwort für den Zugriff auf die webbasierte Verwaltung festzulegen. Standardmäßig ist kein Kennwort konfiguriert. Es wird dringend empfohlen, ein Kennwort zu erstellen, um Ihren neuen Router zu sichern.", //ta_intro_Adm
	"L2TP-Server-IP-Adresse", //bwn_L2TPSIPA
	"Es ist keine Richtlinie für den Internetzugriff aktiv. Jeder besitzt uneingeschränkten Internetzugriff", //GW_INET_ACCESS_UNRESTRICTED
	"(GMT-05:00) Bogota, Lima, Quito", //up_tz_11
	"Deaktiviert", //_disabled
	"Senden der Protokoll-E-Mail, wenn Protokoll voll", //GW_LOG_EMAIL_ON_LOG_FULL
	"7:00 AM", //tt_time_8
	"Ermöglicht dem Windows Media Player, unter Verwendung des MMS-Protokolls, Streaming Media vom Internet zu empfangen.", //help43
	"Verbindung wird hergestellt", //ddns_connecting
	"Aktivieren", //_enable
	"Auf Verlangen", //help272
	"Apr.", //tt_Apr
	"Datum/Zeit ungültig", //tt_alert_invlddt
	"(Mbit/s)", //bwl_MS
	"Der Port für die Remote-Administration steht im Konflikt mit", //tool_admin_portconflict
	"Anwendungs-Name", //gw_SelVS
	"Immer aktiv", //bwn_RM_0
	"Klicken Sie auf das <strong>Bearbeiten</strong> Symbol in der Regelliste, um eine Regel zu ändern.", //hhai_edit
	"Von E-Mail-Adresse", //te_FromEm
	"Der Gateway prüft derzeit Ihre Netzwerkverbindung.", //wt_p_1
	"Zeit wird abgefragt von %v", //NET_RTC_REQUEST_TIME
	"Geben Sie einen Namen für die Spezielle Anwendungsregel als Hilfe zur zukünftigen Identifizierung der Regel ein, beispielsweise <code>Spieleanwendung</code>. Als Alternative dazu können Sie auch aus der <span class='option'>Applikationsliste</span> gebräuchlicher Anwendungen und Applikationen eine auswählen.", //help48
	"nicht verfügbar", //N_A
	"PPTP-Subnetzmaske", //help279
	"6", //tt_week_6
	"Soldier of Fortune II: Double Helix", //gw_gm_48
	"Unsichtbar", //bwl_VS_1
	"Bestätigen Sie die aktualisierte Firmware-Änderung auf der Seite Status.", //help882
	"(GMT+03:00) Teheran", //up_tz_41
	"Konfiguration wurde aus permanentem Speicher geladen", //RUNTIME_CONFIG_LOADED_CONFIG_FROM_NVRAM
	"Sitzungszeitüberschreitung, bitte versuchen Sie es erneut.", //li_alert_1
	"Die IP-Adresse Ihres Routers im lokalen Netzwerk. Ihre LAN Einstellungen basieren auf der Adresse, die hier zugewiesen wird. Zum Beispiel 192.168.0.1.", //help307
	"Eine Verbindung zum Internet wird bei Bedarf hergestellt.", //help273
	"Setzen Sie ein Häkchen in das Kästchen für die gewünschten Tage oder wählen Sie den Auswahlknopf für die ganze Woche, um alle sieben Tage der Woche auszuwählen.", //help194
	"Möchten Sie das Gerät wirklich auf die Herstellerstandardeinstellungen zurücksetzen?", //up_rb_4
	"Neuere Firmware-Version %d.%d für Ihren %s %s –Router ist jetzt verfügbar unter", //NEWER_FW_VERSION
	"PPTP Internet Verbindungstyp", //bwn_PPTPICT
	"Firmware-Aktualisierungsabbild erfolgreich hochgeladen – wird installiert", //GW_UPGRADE_SUCCEEDED
	"(Adressen innerhalb des LAN-Subnetzes)", //bwl_AS
	"Die Regel wird auf jeglichen Datenfluss angewendet, dessen WAN-seitige Port Nummer in dem hier festgelegten Bereich fällt.", //help96
	"Drahtlos Kanal", //_wchannel
	"Manuelles Zuweisen eines Netzwerkschlüssels", //wwz_manual_key
	"Bitte klicken Sie auf die Schaltfläche unten, um mit der Konfiguration des Routers fortzufahren.", //ap_intro_cont
	"Protokollierung zum Syslog-Server aktivieren", //tsl_EnLog
	"L2TP", //_L2TP
	"DHCP-IP-Adressbereich", //bd_DIPAR
	"Statistiken", //_stats
	"- Zwischen 8 und 63 Zeichen (Ein längerer WPA-Schlüssel bietet höhere Sicherheit.)", //wwl_s4_intro_za2
	"Lokale L2TP-Sitzung 0x%04X ausgefallen", //IPL2TP_SESSION_DOWN
	"Dynamische IP (DHCP) Internet-Verbindungstyp", //bwn_DIAICT
	"Gehen Sie in das Startmenü, klicken Sie auf Ausführen, geben Sie die Zeichenfolge <code>winipcfg</code> ein und drücken Sie die Enter-Taste. Daraufhin wird ein Popup-Fenster eingeblendet. Wählen Sie aus dem Pulldown-Menü den entsprechenden Adapter. Nun wird die Adresse dieses Adapters eingeblendet. Dies ist die MAC-Adresse des Gerätes.", //help338
	"Geben Sie die LAN IP-Adresse des Syslog-Servers ein.", //help859
	"Hinzufügen", //_add
	"Zugriffssteuerung", //_acccon
	"Kann Namen nicht auflösen, bitte überprüfen Sie ob Ihre Angaben korrekt sind.", //tsc_pingt_msg4
	"Trennen", //ddns_disconnect
	"Kennwort bestätigen", //_verifypw
	"MAC Filter Konfiguration", //am_intro_2
	"Richtlinie hinzufügen", //_aa_pol_add
	"Warcraft II", //gw_gm_59
	"Klicken Sie auf <span class='button_ref'>Speichern</span>, um die Einstellungen der Liste virtueller Server hinzuzufügen", //help11
	"System", //_system
	"Diese Option ist normalerweise deaktiviert und sollte deaktiviert bleiben, solange der WAN-seitige DHCP-Server dem Router ohne Probleme eine IP-Adresse zuweist. Kann der Router jedoch keine IP-Adresse vom DHCP-Server beziehen, handelt es sich wahrscheinlich um einen DHCP-Server, der mit Unicast-Antworten besser funktioniert. Aktivieren Sie in diesem Fall die Unicast-Option und prüfen Sie, ob der Router nun eine IP-Adresse beziehen kann. In diesem Modus akzeptiert der Router anstelle von Broadcast-Antworten vom DHCP-Server übertragene Unicast-Antworten.", //help261a
	"(GMT-10:00) Hawaii", //up_tz_02
	"„Ping“ überprüft, ob ein Verbindung zu einem Computer, Lokal oder im Internet, hergestellt werden kann oder nicht.", //hhtsc_pingt_intro
	"Name des virtuellen Servers (z. B.:  <code>Webserver</code>) angeben", //help5
	"Hilfemenü", //help767s
	"Splinter Cell: Pandora Tomorrow", //gw_gm_45
	"Benutzername- / Kennwortverbindung (PPPoE)", //wwa_wanmode_pppoe
	"Ziel und Gateway dürfen sich nicht im gleichen Subnetz %v befinden.", //GW_ROUTES_GATEWAY_SUBNET_SAME
	"Ein Computer muss einige Applikationen unterstützen, die überlappende Eingangs-Ports benutzen könnten, so dass zwei Portweiterleitungsregeln nicht verwendet werden könnten, weil sie sich möglicherweise widersprechen würden.", //haf_dmz_60
	"Die Email-Funktion kann zum Senden von System Log-Dateien, Router-Warnmeldungen und Firmware Update-Benachrichtigungen zu Ihrer Email Adresse verwendet werden.", //te_intro_Em
	"Wählen Sie diese Option, wenn Sie keine Sicherheitsfunktionen aktivieren möchten", //wwl_text_none
	"Geben Sie den Benutzernahmen oder Schlüssel ein, den Sie von Ihrem Internetdienstanbieter erhalten haben. Hat Ihnen Ihr Internetdienstanbieter nur einen Schlüssel bereitgestellt, geben Sie diesen Schlüssel in alle drei Felder ein.", //help895
	"Es wird versucht, die WAN-Verbindung auf Anfrage neu zu starten", //GW_WAN_RECONNECT_ON_ACTIVE
	"Gerät", //aa_Machine
	"Init von gw_wireless_schedule", //GW_WLS_SCHEDULE_INIT
	"Mi", //_Wed
	"7:00 PM", //tt_time_20
	"Ziel-IP <br /> Start", //aa_FPR_c3
	"Geben Sie die TCP-Ports ein, die geöffnet werden sollen (z. B. <code>6159-6180, 99</code>).", //help68
	"Es ist sehr sinnvoll, den Zugang von nicht autorisierten Wireless-Geräten auf Ihr Netzwerk zu verhindern.", //help150
	"Kontoname", //te_Acct
	"E-Mail von SMTP-Client erfolgreich gesendet", //IPSMTPCLIENT_MSG_SENT
	"Quake 3", //gw_gm_38
	"Dieser Bereich arbeitet mit einem RADIUS-Server zur Authentifizierung von Wireless-Klienten. Wireless-Klienten sollten die erforderlichen Berechtigungen besitzen, bevor sie versuchen, sich durch diesen Gateway auf dem Server zu authentifizieren. Ausserdem kann es erforderlich sein, den RADIUS-Server so zu konfigurieren, daß dieser dem Gateway die Benutzerauthentifizierung gestattet.", //help384
	"1:00 AM", //tt_time_2
	"Automatische Uplink-Geschwindigkeit", //at_AUS
	"Klicken Sie auf das Symbol \"Löschen\", um einen Zeitplan endgültig zu löschen.", //hhts_del
	"Durch die QoS Engine Logik erhalten ausgehende Pakete dieses Gespräches den Vorrang. Kleinere Zahlen stellen eine höhere Priorität dar.", //help818
	"Die Firmware-Aktualisierung kann nicht von Drahtlosgeräten aus durchgeführt werden. Um eine Aktualisierung auszuführen, stellen Sie sicher, dass Sie einen Rechner verwenden, der über Kabel mit dem Router verbunden ist.", //help886
	"Wählen Sie einen eindeutigen Namen für Ihre Richtlinie.", //_aa_wiz_s2_msg
	"Wählen Sie das Protokoll, das vom Internetdatenverkehr verwendet wird, der über den geöffneten Portbereich zurück in den Router kommt (z. B. <code>Beide</code>).", //help52
	"Sekunden ...", //wps_KR46
	"Geben Sie Ihrem Netzwerk einen aus bis zu 32 Zeichen bestehenden Namen.", //wwz_wwl_intro_s3_1
	"Ghost Recon", //gw_gm_19
	"Die Funktion Dynamic DNS erlaubt Ihnen einen Server (Web, FTP, Game etc.) mit Ihrer eigenen Internet-Domain (z.b. www.ihrname.eu) auch bei einer dynamischen Zuordnung der IP-Adresse zu betreiben. Die meisten Internet Service Provider verwenden dynamische IP-Adressen.", //td_intro_DDNS
	"(GMT+07:00) Bangkok, Hanoi, Jakarta", //up_tz_53
	"DST Start und DST Ende", //help845
	"Diese Seite wird in kurzer Zeit aktualisiert.", //wt_p_3
	"(GMT+06:00) Sri Jayawardenepura", //up_tz_51
	"Alternativ dazu können Sie das Setup auf einen Druckertreiber verweisen, der sich in einem Ordner auf Ihrem Rechner befindet, welchen Sie zuvor von der Webseite des Druckerherstellers heruntergeladen haben.", //wprn_s3d
	"CHAP-Authentifizierung fehlgeschlagen. Prüfen Sie die Anmeldeinformationen.", //IPPPPCHAP_AUTH_FAIL
	"Tiberian Sun", //gw_gm_52
	"Blockiertes TCP Paket von %v:%u nach %v:%u, da Markierung %s ungültig ist", //IPNAT_TCP_BAD_FLAGS
	"Name", //_name
	"Geben Sie die LAN-IP-Adresse des Systems ein, das den Server als Host bereitstellt, z. B. <code>192.168.0.50</code>.", //help66
	"Ankommende ICMP Fehlermeldung (ICMP Typ %u) von %v nach %v blockiert, da es keine UDP Session gibt, die  zwischen %v:%u und %v:%u aktiv ist", //IPNAT_UDP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"FTP ALG lehnte Paket von %v:%u nach %v:%u ab", //IPFTPALG_REJECTED_PACKET
	"Der Zugriff auf diese Website ist von diesem Rechner aus nicht zulässig.", //fb_p_1
	"Verbindungstyp", //_contype
	"Der Port, den Sie verwenden, um die Managementoberfläche vom Internet aus anzusprechen. Wenn Sie hier z.B. Port 1080 festlegen, um den Router vom Internet aus zugänglich zu machen, würden Sie eine URL in dieser Form benutzen: <code>http://meine.domain.com:1080/</code>.", //help829
	"Regeln für Anwendungen", //_specappsr
	"Die Option &quot;Unsichtbar&quot; erlaubt es Ihnen, Ihr drahtloses Netzwerk zu verstecken. Wenn diese Option auf &quot;Sichtbar&quot; eingestellt ist, wird Ihr Wireless Netzwerkname an jeden Wireless-Klienten, der sich im Bereich innerhalb Ihres Signals befindet, gesendet. Wenn Sie keine Verschlüsselung verwenden, können Sie sich mit Ihrem Netzwerk verbinden. Wenn der Modus &quot;Unsichtbar&quot; aktiviert ist, müssen Sie den Wireless Netzwerknamen (SSID) auf dem Klienten manuell eintragen, um sich mit dem Netzwerk zu verbinden.", //help353
	"Halo: Combat Evolved", //gw_gm_23
	"Immer senden", //help325
	"Wiedereinwahlmodus", //bwn_RM
	"Log-Optionen", //sl_LogOps
	"Alle Details Ihrer Internet- und Netzwerkverbindungen werden auf der Geräte-Infoseite dargestellt. Die Firmware-Version wird hier ebenfalls angezeigt.", //help772
	"Methode", //_aa_method
	"Log-Details", //sl_LogDet
	"Hierbei handelt es sich um eine relative Messung der Signalqualität. Der Wert wird als Prozentsatz einer theoretisch besten Qualität ausgedrückt. Die Signalqualität kann durch lange Distanzen, Interferenzen von anderen Funkquellen (wie z. B. schnurlosen Telefonen oder Drahtlosnetzwerken in der Nachbarschaft) sowie durch Hindernisse zwischen dem Router und dem Drahtlosgerät herabgesetzt werden.", //help788
	"Fortsetzen", //_continue
	"Die Statistik-Seite zeigt alle Statistiken zu LAN, WAN, Drahtlos-Paketübertragung und Drahtlos-Paketempfang.", //help804
	"Geräte Info", //_devinfo
	"Ja", //_yes
	"SSID", //help699
	"(GMT+10:00) Jakutsk", //up_tz_62
	"In diesem Abschnitt können Sie Einträge zu der Zeitplan Regelliste hinzufügen oder bereits vorhandene Einträge bearbeiten.", //help192
	"DHCP-PD aktivieren", //DHCP_PD_ENABLE
	"Need for Speed", //gw_gm_31
	"Eine Verbindung zum Internet wird immer aufrecht erhalten.", //help271
	"Ermöglicht mehreren Computern im LAN sich über das PPTP-Protokoll mit ihren Firmennetzwerken zu verbinden.", //help33
	"Blockiertes ankommendes TCP Paket von %v:%u nach %v:%u mit unerwarteter Bestätigung %lu (erwartet %lu nach %lu)", //IPNAT_TCP_BLOCKED_INGRESS_BAD_ACK
	"Prüfe Erreichbarkeit des angegebenen Rechners (Ping)", //htsc_pingt_p
	"Jetzt überprüfen", //tf_CKN
	"Überprüfen Sie den Druckerstatus", //wprn_cps
	"(GMT+06:00) Jekaterinburg", //up_tz_45
	"Der Router bestimmt automatisch, ob es sich bei der zugrundeliegenden Verbindung um ein xDSL/Frame-Relay-Netz oder einen anderen Verbindungstypen (wie Kabelmodem oder Ethernet) handelt, und zeigt das Ergebnis unter <span class='option'>Erkannte xDSL oder Frame Relay-Netz</span> an. Verfügen Sie über eine ungewöhnliche Netzwerkverbindung, bei der Sie zwar über xDSL angeschlossen sind, für die Sie aber entweder \"Static\" oder \"DHCP\" in den WAN-Einstellungen angegeben haben, stellen Sie durch Eingabe dieser Option auf <span class='option'>xDSL or Other Frame Relay Network' (xDSL oder anderes Frame-Relay-Netz)</span> sicher, dass der Router erkennt, dass er den Datenverkehr etwas anders strukturieren muss, damit die beste Leistung erzielt wird. Die Wahl von <span class='option'>xDSL oder einem anderen Frame Relay-Netzwerk</span> bewirkt, dass die gemessene Uplink-Geschwindigkeit als etwas niedriger als vorher unter solchen Verbindungen gemeldet wird. Die Leistungsstärke ist dabei aber höher.", //help84
	"Neueste Firmware-Version %d.%d ist verfügbar", //GW_FW_NOTIFY_FIRMWARE_AVAIL
	"RX Pakete verworfen", //ss_RXPD
	"Website %S blockiert für %s", //WEB_FILTER_LOG_URL_BLOCKED_MAC
	"Der Portauslöser des ALG  konnte keine Session für TCP Paket von %v:%u nach %v:%u zuordnen", //IPPORTTRIGGERALG_TCP_PACKET_ALLOC_FAILURE
	"Hinweis: Sie müssen möglicherweise auch einen Hostnamen angeben. Wenn Sie diese Informationen nicht haben oder wissen, kontaktieren Sie bitte Ihren Internetdienstanbieter.", //wwa_note_hostname
	"Aktion", //ai_Action
	"Konfiguration auf Herstellerstandards zurücksetzen", //RUNTIME_CONFIG_RESET_CONFIG_TO_FACTORY_DEFAULTS
	"Kein Drucker gefunden", //sps_nopr
	"Stunden", //gw_hours
	"Fr", //_Fri
	"LPD/LPR-Druck", //tps_lpd
	"Firmware-Upgrade", //tf_FWUg
	"10Mbit/s", //anet_wp_0
	"Battlefield 1942", //gw_gm_4
	"Diese beiden Optionen wählen eine Variante des Wi-Fi-geschützten Zugriffs (Wi-Fi Protected Access - WPA) -- von der Wi-Fi Alliance veröffentlichte Sicherheitsstandards. Der <span class='option'>WPA-Modus</span> verfeinert die Variante weiter, die der Router verwenden sollte.", //help373
	"Zeitunterschied bei Sommerzeit", //tt_dsoffs
	"Netzwerkschlüssel automatisch zuweisen (empfohlen)", //wwz_auto_assign_key
	"Doom 3", //gw_gm_15
	"Für Informationen, welche Sicherheitsfunktionen Ihre Wireless-Netzwerkkarte unterstützt, beziehen Sie sich bitte auf dessen Unterlagen.", //wwl_s3_note_1
	"Klicken Sie auf <strong>Speichern</strong>, um der Liste unten einen fertiggestellten Zeitplan hinzuzufügen.", //hhts_save
	"Automatische Erkennung", //at_Auto
	"Pings gesendet:", //tsc_pingt_msg100
	"PPP-Netzwerk ausgefallen", //IPPPPIPCP_PPP_LINK_DOWN
	"Adresstyp", //aa_AT
	"Ubi.com", //gw_gm_71
	"Schritt 3 - Festlegen des Geräts, für das diese Richtlinie übernommen werden soll", //aa_wiz_s1_msg3
	"BigPond fehlgeschlagen, siehe Protokoll für Details", //BIGPOND_FAILED
	"Die Zeit zwischen regelmäßigen Updates zum dynamischen DNS, wenn Ihre dynamische IP-Adresse sich nicht geändert hat. Die Zeitüberschreitungsdauer wird in Stunden eingegeben.", //help898
	"PPTP-Server-IP-Adresse", //bwn_PPTPSIPA
	"Routing", //_routing
	"Erstellen Sie eine Liste der MAC-Adressen, denen Sie entweder den Zugriff zu Ihrem Netzwerk erlauben oder verweigern möchten.", //hham_intro
	"Der interne WPS-Registrar (Wi-Fi Protected Setup) hat zwei Minuten lang keine Anfrage von einer WLAN-Station erhalten und wurde angehalten.", //WIFISC_IR_REGISTRATION_FAIL_3
	"Die Inbound Filter-Option ist eine erweiterte Methode um empfangene Daten aus dem Internet zu kontrollieren. Mit dieser Funktion können Sie Filter Regeln für eingehende Daten einrichten, welche auf einem IP-Adress Bereich basieren, kontrollieren.", //ai_intro_1
	"Schritt 2: Wählen Sie Ihre Zeitzone aus", //wwa_title_s2
	"(GMT+11:00) Wladiwostok", //up_tz_69
	"MS-CHAP-Authentifizierungsantwort an Peer gesendet", //IPMSCHAP_AUTH_RESULT
	"Die aktuellen System Einstellungen können als Datei auf ein lokales Festplattenlaufwerk gespeichert werden. Die gespeicherte Datei können zum wiederherstellen der System Einstellungen verwendet werden.", //tss_intro2
	"Wenn Sie diese Option auswählen, findet der Router automatisch den Kanal mit den geringsten Störungen und verwendet ihn für die drahtlose Vernetzung. Wenn Sie diese Option deaktivieren, benutzt der Router den Kanal, den Sie mit der folgenden <span class='option'>Drahtlos Kanal</span> Option angeben.", //help354
	"(GMT-03:00) Buenos Aires, Georgetown", //up_tz_19
	"Sie müssen zuerst den Namen einer Konfigurationsdatei eingeben.", //ta_alert_5
	"Immer senden", //bd_DAB
	"WPA-Enterprise", //_WPAenterprise
	"Die Internetzugangssteuerung hat Datenpakete von %v:%u[%s] bis %v:%u (Protokoll %u) verworfen", //GW_INET_ACCESS_DROP_ACCESS_CONTROL_MAC
	"Drucker", //sps_pr
	"(GMT+02:00) Harare, Pretoria", //up_tz_34
	"Vorinstallierter Schlüssel", //_psk
	"Dynamischer DNS", //_dyndns
	"Verweigern", //_deny
	"Blockiertes ankommendes TCP Paket von %v:%u nach %v:%u, da %s im Status %s nicht erlaubt ist", //IPNAT_TCP_BLOCKED_INGRESS_UNEXP_FLAGS
	"Maximale Leerlaufzeit", //help276
	"bis", //_to
	"IP", //aa_AT_0
	"Dez.", //tt_Dec
	"Richtlinie %s wurde gestartet; Der Internetzugriff wurde für alle nicht festgelegten Systeme geändert auf: %s", //GW_INET_ACCESS_POLICY_START_OTHERS
	"(GMT+12:00) Magadan", //up_tz_75
	"(GMT+12:00) Fidschi, Kamschatka, Marshall-Inseln", //up_tz_72
	"Keine Antwort von dem Computernamen oder IP-Adresse, erneuter versuch …", //tsc_pingt_msg11
	"Möchten Sie diesen Eintrag wirklich löschen?", //up_ae_de_1
	"Dieser Bildschirmbereich wird ständig aktualisiert und zeigt alle DHCP-fähigen Rechner und Geräte an, die an die LAN-Seite Ihres Routers angeschlossen sind. Der &quot;Erkennungsbereich&quot; ist beschränkt auf den Adressenbereich, der für den DHCP-Server konfiguriert ist. Rechner, deren Adressen außerhalb dieses Bereichs liegen, werden nicht angezeigt. Besitzt ein DHCP-Klient (d.h. ein Rechner, für den die Einstellung Adresse automatisch beziehen aktiviert ist) einen Hostnamen, so wird auch dieser angezeigt. Jeder Rechner bzw. jedes Gerät, der/das eine statische IP-Adresse innerhalb des Erkennungsbereichs besitzt, wird angezeigt; der zugehörige Hostname wird jedoch nicht angezeigt.", //help781
	"Geben Sie die gewünschte MAC-Adresse ein.", //help161_2
	"6:00 PM", //tt_time_19
	"Verwenden Sie die MAC-Adresse des Clients, um den Netzwerkzugang über den Access Point zu autorisieren.", //am_intro
	"Die Anzahl an Übertragungsfehlern, die den Verlust eines Pakets verursachen.", //help811
	"Mittel", //aw_TP_1
	"(GMT) Casablanca, Monrovia", //up_tz_24
	"MS-CHAP-Authentifizierungsdetails an Authentifikator gesendet", //IPMSCHAP_AUTH_SENT
	"Verwenden Sie diese Option, um alle Wireless-Klienten, welche mit Ihrem Wireless Router verbunden sind, anzuzeigen.", //sw_intro
	"Das Druckprotokoll LPD/LPR verwendet eine festgelegte IP-Adresse und einen namen für die Warteschlange, um mit Ihren Drucker zu kommunizieren.", //tps_lpd1
	"und", //help257
	"Der Router wird nun mit Hilfe der hochgeladenen Firmware-Datei neu programmiert. Bitte warten Sie <span id='show_sec'></span>&nbsp;Sekunden,bis dieser Vorgang abgeschlossen ist. Anschließend können Sie wieder auf diese Internetseiten zugreifen. Das Neuladen der Seite sowie das Anklicken des Zurück-Symbols im Browser führt zum Fehlschlag dieses Vorgangs.", //_upgintro
	"Geschlossen -- die Verbindung ist nicht mehr aktiv, aber die Sitzung wird verfolgt, falls es noch anhängende zu übertragende Pakete gibt.", //help819_8
	"(Sekunden)", //bws_secs
	"Blockiertes ausgehendes ICMP Paket (ICMP Typ %u) von %v nach %v", //IPNAT_ICMP_BLOCKED_EGRESS_PACKET
	"Port-Weiterleitung", //PORT_FORWARDING
	"Dynamische IP (DHCP)", //bwn_Mode_DHCP
	"Stunde", //tt_Hour
	"Geben Sie die IP-Adressen der DNS Server ein. Lassen Sie den Bereich für den sekundären Server leer, wenn er nicht verwendet wird.", //help290a
	"BigPond wird abgemeldet", //BIGPOND_LOGGING_OUT
	"Wenn Sie Probleme mit dem Multicast-Empang aus dem Internet haben, stellen Sie sicher, dass die Muticast Option aktiviert ist.", //hhan_mc
	"Primärer DNS-Server", //_dns1
	"Primärer IPv6 DNS-Server", //_dns1_v6
	"Extras", //_tools
	"Verbindung getrennt", //_sdi_s2
	"USB-Port", //sps_usbport
	"Systemfehler beim Zuordnen des Plans %s aufgetreten", //GW_SCHED_ALLOC_FAILED
	"Unterbindet allen WAN-Benutzern den Zugriff zu ähnlichen Leistungsmerkmalen. (LAN Benutzer sind nicht von Inbound Filtern betroffen.)", //help179
	"BigPond aktivieren:", //help262
	"Zulassen", //_allow
	"Wählen Sie die Ereignisstufen, die Sie anzeigen möchten.", //help798
	"IP-Adresse über DHCP bezogen. IP-Adressen lautet %v", //DHCP_CLIENT_GOT_LEASE
	"Geschwindigkeit WAN-Port", //anet_wan_phyrate
	"Hinweis", //_note
	"Ziel <br />Port<br />Start", //aa_FPR_c6
	"Zu öffnende UDP-Ports", //help69
	"Gültigkeitsdauer DHCP", //bd_DLT
	"Inbound Filter Regelliste", //ai_title_IFRL
	"LAN-Schnittstelle ist aktiv", //GW_LAN_INTERFACE_UP
	"PROTOKOLLE", //_logs
	"Deaktivieren Sie die MAC Filterung", //am_FM_2
	"Protokoll-E-Mail nach Administratoranfrage senden", //GW_LOG_EMAIL_ON_USER_REQUEST
	"Der Port, auf den über das Internet zugegriffen wird.", //help21
	"802.11-Modus", //bwl_Mode
	"Adressmodus", //bwn_AM
	"BigPond Server", //bwn_BPS
	"Geben Sie die Informationen ein, die Sie von Ihrem Internetdienstanbieter erhalten haben.", //_ispinfo
	"Rate", //_rate
	"(GMT-07:00) Mountain Time (USA/Kanada)", //up_tz_06
	"Erfolg", //_success
	"Sentinel Altersfreigabe Service", //_bsecure_parental_serv
	"Benutzername- und Kennwortverbindung einrichten (L2TP)", //wwa_set_l2tp_title
	"Mac OS X", //help342
	"Wählen Sie diese Option, wenn Ihr Internetdienstanbieter von Ihnen die Verwendung einer PPPoE-Verbindung (Point to Point Protocol over Ethernet) fordert. Diese Option wird in der Regel von DSL-Anbietern verwendet. Bei dieser Verbindungsmethode müssen Sie einen <span class='option'>Benutzernamen</span> und ein <span class='option'>Kennwort</span> eingeben, damit der Zugang zum Internet gewährt wird (Sie erhalten diese Informationen von Ihrem Internetdienstanbieter).", //help265
	"SMTP (E-Mail)-Server %s liegt auf  der IP-Adresse %v", //GW_SMTP_EMAIL_RESOLVED_DNS
	"Pings verloren:", //tsc_pingt_msg102
	"Radius Server-Port", //bws_RSP
	"Es wird versucht, eine PPPoE-Verbindung herzustellen", //PPPOE_EVENT_CONNECT
	"Automatische Zeitkonfiguration", //tt_auto
	"Das PPTP-Teilsystem verfügt nicht über ausreichende Ressourcen. Die Verbindung wird möglicherweise beeinträchtigt.", //PPTP_EVENT_LOW_RESOURCES_TO_QUEUE
	"Lokaler L2TP-Tunnel 0x%04X hat eine unerwartete Kontrollmeldung empfangen (ignoriert)", //IPL2TP_TUNNEL_UNEXPECTED_MESSAGE
	"Neverwinter Nights", //gw_gm_34
	"5", //tt_week_5
	"Unten finden Sie eine ausführliche Zusammenfassung Ihrer Wireless-Sicherheitseinstellungen. Drucken Sie bitte diese Seite aus oder schreiben Sie die Informationen auf ein Stück Papier, damit Sie diese Einstellungen auf Ihren Wireless-Netzwerkkarten vorneh", //wwl_intro_end
	"Richtlinientabelle", //aa_Policy_Table
	"Zeitkonfiguration", //tt_TimeConf
	"keine", //_none
	"Schritt 2: Festlegen des Zeitplans", //_aa_wiz_s3_title
	"Eine Pass-Phrase, welche mit dem Authentifizierungsserver zusammenpassen muß.", //help392
	"Protokoll-E-Mail nach Plan senden", //GW_LOG_EMAIL_ON_SCHEDULE
	"Wählen Sie die passende Zeitzone für Ihren Standort. Diese Information ist erforderlich, um die zeitbasierten Optionen des Routers zu konfigurieren.", //wwa_intro_s2
	"PPTP-Gateway-IP-Adresse", //_PPTPgw
	"Website %S aufgerufen von %v", //WEB_FILTER_LOG_URL_ACCESSED
	"MMS ALG lehnte Paket von %v:%u nach %v:%u ab", //IPMMSALG_REJECTED_PACKET
	"Wireless Einstellungen", //_wirelesst
	" Es gibt zwei Möglichkeiten, Ihre Internet Verbindung einzurichten: Sie können den Web-basierten Installations-Assistenten verwenden, oder die Verbindung manuell konfigurieren.", //int_intro
	"Zugang verweigert für LAN-System mit MAC-Adresse %m ", //GW_LAN_ACCESS_DENIED
	"Jedi Knight II: Jedi Outcast", //gw_gm_26
	"Eingehendes GRE-Paket blockiert von %v bis %v", //PPTP_ALG_GRE_BLOCKED_INGRESS
	"(GMT+01:00) West-Zentralafrika", //up_tz_30
	"Starcraft", //gw_gm_49
	"Zeitplan", //_sched
	"Einrichten von FAT-Gerät ist fehlgeschlagen", //IPFAT_MOUNT_FAILED
	"KALI", //gw_gm_75
	"Hier werden die Versionsnummern der Firmware angezeigt, die zurzeit auf Ihrem Router installiert sind und das neueste Update, das verfügbar ist.", //help883
	"Die Konfigurationsdatei wird hochgeladen, bitte warten", //ta_alert_6
	"Richtlinie %s wurde gestartet; Der Internetzugriff wurde für IP-Adresse %v geändert auf: %s", //GW_INET_ACCESS_POLICY_START_IP
	"Zeigt die Zeit an, die aktuell durch den Router verwendet wird. Wenn diese nicht korrekt ist, verwenden Sie die folgenden Optionen, um die Zeit richtig einzustellen", //help841a
	"10:00 PM", //tt_time_23
	"Port Weiterleitungs-Regeln", //ag_title_4
	"WinMX", //gw_gm_68
	"Blockiertes ausgehendes TCP Paket von %v:%u nach %v:%u, da %s nicht im Zustand %s erlaubt ist", //IPNAT_TCP_BLOCKED_EGRESS_UNEXP_FLAGS
	"Hostname", //help260
	"FIN-Wait -- Das Klientensystem hat verlangt, daß die Verbindung gestoppt wird.", //help819_4
	"Wenn alle drahtlosen Geräte, die Sie an diesen Router anschließen möchten, im gleichen Übertragungsmodus arbeiten, können Sie die Leistung verbessern, indem Sie den passenden „Nur“ Modus wählen. Wenn Sie einige Geräte haben, die einen anderen Übertragungsmodus verwenden, wählen Sie den passenden „Gemischt“ Modus.", //help357
	"TCP", //_TCP
	"MS-CHAP-Authentifizierungsanforderung von Peer empfangen", //IPMSCHAP_CHALLENGE_RECVD
	"Universal Plug and Play (UPnP) unterstützt Peer-to-Peer Plug and Play Funktionalität für Geräte im Netzwerk.", //anet_msg_upnp
	"Durch Anklicken der Schaltfläche <span class='button_ref'>DHCP Freigabe</span> wird die Zuweisung der IP-Adresse des Routers aufgehoben. Der Router reagiert dann nicht mehr auf WAN-seitige IP-Meldungen, bis Sie die Schaltfläche <span class='button_ref'>DHCP-Aktualisierung</span> anklicken oder den Router neu starten. Durch Anklicken der Schaltfläche <span class='button_ref'>DHCP-Aktualisierung</span> fordert der Router eine neue IP-Adresse vom Server des Internetdienstanbieters an.", //help776
	"Bitte wählen Sie die Konfigurationsmethode aus, um Ihr drahtloses Netzwerk einzurichten", //KR49
	"Hier können Sie ALGs aktivieren bzw. deaktivieren. Einige Protokolle und Anwendungen erfordern besondere Vorsicht bei den IP-Nutzdaten, damit diese mit der Network Address Translation (NAT) verwendet werden können. Jedes ALG bietet einen besonderen Umgang für ein spezifisches Protokoll oder Anwendung. Eine Reihe von ALGs für allgemeine Anwendungen ist standardmäßig aktiviert.", //help32
	"Asheron's Call", //gw_gm_3
	"Die Zeit der Inaktivität in Sekunden, bis der Router die Sitzung als beendet ansieht.", //help823
	"L2TP-IP-Adresse", //_L2TPip
	"Neustart des Geräts", //_reboot
	"Es gibt zwei Möglichkeiten, ein drahtloses Gerät mit Ihrem drahtlosen Netzwerk zu verbinden:", //wps_p3_1
	"Schritt 3: Druckertreiber-CD nach Aufforderung einlegen", //wprn_intro5
	"Sentinel Sicherheits Service", //_bsecure_security_serv
	"Empfangen", //tsc_pingt_msg8
	"Unreal Tournament", //gw_gm_56
	"Der Abschnitt für das Firmware-Upgrade kann verwendet werden, um das Gerät mit der neuesten Firmware zu aktualisieren und die Funktionalität und Leistung zu verbessern.", //tf_intro_FWU
	"(GMT+08:00) Kuala Lumpur, Singapur", //up_tz_57
	"Firmware-Aktualisierungsserver %s besitzt die IP-Adresse %v", //GW_FW_NOTIFY_RESOLVED_DNS
	"Port und Adresse beschränkt", //af_EFT_2
	"(GMT-12:00) Eniwetok, Kwajalein", //up_tz_00
	"Zeitpläne werden mit anderen Funktionen kombiniert (z.B Firewall Regeln) damit diese Kraft treten können.", //hhts_intro
	"Authentifizierung", //_auth
	"Lokaler L2TP-Tunnel 0x%04X Verbindung wird getrennt", //IPL2TP_TUNNEL_DISCONNECTING
	"Zeitsynchronisierung fehlgeschlagen, aufgegeben nach ... Versuchen", //NET_RTC_SYNCHRONIZATION_FAILED_AFTER_RETRIES
	"Firmware-Version", //sd_FWV
	"Liste der Zeitplanregeln", //tsc_SchRuLs
	"Die Aktivierung der WLAN Partition verhindert, dass einander zugeordnete drahtlose Clients miteinander kommunizieren.", //KR58_ww
	"optionaler", //YM98
	"Konfiguration Übernehmen", //ta_SavConf
	"Sekundäre DNS-Adresse", //wwa_sdns
	"Diese Option setzt die Einstellungen des Routers zurück auf die Einstellungen, welche bei erstmaliger Auslieferung nach Produktion im Werk verwendet werden. Wenn Sie Ihre spezifischen Einstellungen speichern möchten, verwenden Sie die Option Speichern Einstellungen", //help876
	"Diese Option verwendet Wi-Fi Protected Access mit einem Pre-Shared Key (PSK).", //help380
	"Netzwerk-Filter", //_netfilt
	"Tage", //gw_days
	"Anmeldung", //li_Login
	"WAN ist bereits verbunden", //WAN_ALREADY_CONNECTED
	"Nur WPA2", //bws_WPAM_3
	"Gateway-Adresse %v darf nicht mit der Adresse der verwendeten Schnittstelle übereinstimmen", //GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS
	"Es muss ein Kennwort angegeben werden", //GW_DYNDNS_PASSWORD_INVALID
	"Virtueller Server", //tool_admin_vsname
	"(GMT+06:00) Astana, Dhaka", //up_tz_50
	"Statische IP-Adresse", //static_PPPoE
	"Startzeit", //tsc_StrTime
	"Kürzeste Pingzeit (in Millisekunden):", //tsc_pingt_msg104
	"Druckerkennungsfehler", //wprn_iderr
	"Bei Auswahl dieser Option werden Ihnen die aktuellen WLAN-Einstellungen angezeigt, die Sie benötigen, um das drahtlose Gerät manuell zu konfigurieren.", //wps_KR42
	"Zeitüberschreitung", //td_Timeout
	"Web-Schutzfilter aktivieren", //_aa_apply_web_filter
	"Auf Unkonfiguriert zurücksetzen", //resetUnconfiged
	"Spiele", //GAMING
	"8:00 AM", //tt_time_9
	"Eingehendes Paket von %v nach %v (IP-Protokoll %u) gesperrt", //IPNAT_BLOCKED_INGRESS
	"WAN-Schnittstelle ist aktiv. Verbindung zum Internet hergestellt mit IP-Adresse %v und Standard-Gateway %v", //GW_WAN_INTERFACE_UP
	"Router IP-Adresse", //_ripaddr
	"Zeitüberschreitung", //sa_TimeOut
	"Blockiertes ausgehendes TCP Paket von %v:%u nach %v:%u mit unerwarteter Reihenfolge %lu (erwartet %lu nach %lu)", //IPNAT_TCP_BLOCKED_EGRESS_BAD_SEQ
	"LAN-Schnittstelle ist ausgefallen", //GW_LAN_INTERFACE_DOWN
	"Je nachdem, ob aktuell eine WAN-Verbindung hergestellt ist, können Sie entweder auf <span class='button_ref'>Verbinden</span> klicken, um zu versuchen, eine WAN-Verbindung herzustellen, oder auf <span class='button_ref'>Verbindung trennen</span> klicken, um die WAN-Verbindung zu trennen.", //help778
	"Name Warteschlange", //sps_qname
	"Sekunden", //_seconds
	"Protokoll gelöscht von IP-Adresse %v", //GW_LOGS_CLEARED
	"Warnung", //sl_Warning
	"Geräteadresse", //aa_MAC
	"Wählen Sie diese Option aus, wenn Ihr drahtloses Gerät WPS (Wi-Fi Protected Setup) unterstützt.", //wps_KR51
	"Manuell", //help274
	"Das Verwenden eines kurzen (400ns) „Guard“ Intervalls kann den Durchsatz erhöhen. Die Fehlerhäufigkeit kann aber wegen der erhöhten Empfindlichkeit für Hochfrequenzreflexionen in manchen Installationen etwas zunehmen.", //aw_sgi_h1
	"Blockiertes Source-Route Paket von %v nach %v", //IPSTACK_REJECTED_SOURCE_ROUTED_PACKET
	"Primäre DNS-Adresse", //wwa_pdns
	"Verwenden Sie diese Option, um eine vorher gesicherte Routerkonfiguration wiederherzustellen.", //help834
	"So", //_Sun
	"Anzahl der Geräte", //sto_no_dev
	"Um zu vermeiden, dass Außenstehende auf Ihr Netzwerk zugreifen, wird vom Router automatisch ein Schutz (WEP- oder WPA-Schlüssel) eingerichtet.", //wwz_auto_assign_key2
	"Anzahl der lokalen Datenströme", //bwl_NSS
	"(GMT-04:00) Caracas, La Paz", //up_tz_15
	"Sobald Sie die zu verwendende Datei gefunden haben, klicken Sie unten die Taste <span class='button_ref'>Hochladen</span> an, um die Aktualisierung der Firmware zu starten. Dies kann eine Minute oder länger dauern.", //help880
	"Es wird versucht, eine Verbindung zum L2TP-Server herzustellen", //IPL2TP_TUNNEL_CONNECTING
	"SharePort für Gastzone aktivieren", //bwn_mici_guest_use_shareport
	"Zeit synchronisiert", //NET_RTC_SYNCHRONIZED
	"(GMT-06:00) Saskatchewan", //up_tz_10
	"Ein", //_on
	"Sie sind nicht angemeldet. Bitte aktualisieren Sie den Browser.", //NOT_LOGGED_IN_PLEASE_REFRESH
	"Eingehendes GRE-Paket blockiert von %v bis %v", //IPSEC_ALG_ESP_BLOCKED_INGRESS
	"Fortsetzen", //ub_continue
	"Benutzername oder Schlüssel", //td_UNK
	"Einrichten von Gerät PV%d ist fehlgeschlagen", //IPPMVM_MOUNT_FAILED
	"Rise of Nations", //gw_gm_42
	"Die LAN Adresse, die Sie reservieren möchten.", //_1066
	"Ganze Woche", //tsc_AllWk
	"Virtueller Server", //_virtserv
	"Mithilfe der virtuellen Serveroption können Internetbenutzer auf Dienste in Ihrem LAN zugreifen. Sie dient dazu, Online-Dienste wie FTP, Web- oder Spieleserver als Host bereitzustellen. Dazu legen Sie für jeden virtuellen Server einen öffentlichen (Public) Port auf Ihrem Router zur Weiterleitung an eine interne LAN-IP-Adresse und einen LAN-Port fest.", //help2
	"Wählen Sie diese Option, wenn Protokolle dann per E-Mail versendet werden sollen, wenn das Protokoll voll ist.", //help869
	"LCP legt lokale Optionen fest: ACCM: %lx, ACFC: %u, PFC: %u, MRU: %u", //IPPPPLCP_SET_LOCAL_OPTIONS
	"Neustart des Geräts", //ts_rd
	"IPSec ALG lehnte Paket von %v:%u nach %v:%u ab", //IPSEC_ALG_REJECTED_PACKET
	"Bitte warten Sie, Ihre Anfrage wird bearbeitet", //tsc_pingt_msg3
	"Drahtlossystem mit MAC-Adresse %m Verbindung getrennt aufgrund: %s", //GW_WIRELESS_DEVICE_DISCONNECTED
	"Funkbetrieb", //sd_WRadio
	"Zulässig, Websites - %s%s, Ports - %s", //ALLOWED_WEB_SITES
	"BitTorrent", //gw_sa_1
	"UDP", //_UDP
	"Wird ein Rechner in die DMZ gesetzt, ist dieser Rechner ggf. zahlreichen Sicherheitsrisiken ausgesetzt. Diese Option sollte daher nur als letzter Ausweg genutzt werden.", //help166
	"Der Abschnitt Zugriffskontrolle ermöglicht die Steuerung des Zugriffs von und zu Geräten in Ihrem Netzwerk. Nutzen Sie diese Funktion als Altersfreigabe, um nur Zugriff auf zulässige Seiten zu gestatten, den Internetzugriff basierend auf Uhrzeit- oder Datumsangaben zu beschränken und/oder den Zugriff von Anwendungen, wie z. B. Peer-to-Peer-Dienstprogramme oder Spiele zu blockieren.", //help117
	"L2TP Internet Verbindungstyp", //bwn_L2TPICT
	"Der Router protokolliert (speichert) interessante Ereignisse automatisch in seinem internen Speicher. Steht nicht ausreichend interner Speicherplatz für alle Ereignisse zur Verfügung, werden die Protokolle älterer Ereignisse gelöscht, die Protokolle der jüngsten Ereignisse jedoch beibehalten. Die Log-Option erlaubt das Anzeigen der Routerprotokolle. Hierbei können Sie festlegen, welche Ereignistypen und Ereignisstufen angezeigt werden sollen. Dieser Router besitzt ebenfalls eine Syslog Option, mit der Sie das Log auf einen sich im Netzwerk befindenden Rechner verschicken lassen können, auf dem ein Syslog Diesnstprogramm läuft.", //help795
	"Nein", //_no
	"(GMT+09:30) Adelaide", //up_tz_63
	"Sie müssen zuerst den Namen einer Firmwaredatei eingeben.", //tf_FWF1
	"(GMT+10:00) Brisbane", //up_tz_65
	"Priorität", //_priority
	"Verbindung zum WAN ist bereits getrennt", //WAN_ALREADY_DISCONNECTED
	"Auf dieser Seite befinden sich nicht gespeicherte Daten. Möchten Sie diese verwerfen?", //up_jt_1
	"Der Internetzugriff wurde für alle nicht festgelegten Systeme festgelegt auf: %s", //GW_INET_ACCESS_INITIAL_OTHERS
	"Die Start- und End-IP-Adressen sind WAN-seitige Adressen.", //hhai_ip
	"Diese Option wird verwendet, um die einzelne oder mehrere Ports auf Ihrem Router zu öffnen, wenn der Router Daten erkennt, die zum Internet über einen „Auslöser“-Port oder einem -Portbereich gesendet werden. Die speziellen Anwendungs-Regeln gelten für  alle Computer in Ihrem internen Netzwerk.", //as_intro_SA
	"Der Ping-Test sendet Pakete, um die Verbindung zu einem Computer im Internet zu testen.", //tsc_pingt_mesg
	"(GMT+04:30) Kabul", //up_tz_44
	"Möglicherweise haben Sie Schwierigkeiten auf einen virtuellen Server mithilfe seiner öffentlichen Identität (WAN-seitige IP-Adresse des Gateway oder sein DDNS-Name) von einem Rechner im LAN zuzugreifen. Ihre Anfragen werden möglicherweise nicht zurückgeführt oder an die Seite \"Forbidden\" weitergeleitet.", //help27
	"IPSec (VPN)", //as_IPSec
	"VERWALTUNG", //_admin
	"eDonkey", //gw_gm_65
	"Um die Firmware zu aktualisieren, klicken Sie auf „Durchsuchen“, und suchen Sie die Aktualisierungsdatei auf der lokalen Festplatte. Wenn Sie die Datei gefunden haben, klicken Sie auf die Schaltfläche „Hochladen“, um mit der Aktualisierung der Firmware zu beginnen.", //tf_intro_FWChB
	"Gesperrt", //BLOCKED
	"BigPond Kabel (Australien)", //wwa_msg_bigpond
	"Protokollierung zum Syslog-Server aktivieren", //help857
	"Close-Wait -- Das Serversystem hat verlangt, daß die Verbindung gestoppt wird.", //help819_5
	"Tief", //aw_TP_2
	"Authentifizierung Zeitüberschreitung", //help385
	"Setup vollständig!", //_setupdone
	"Am Router anmelden", //li_intro
	"Senden der E-Mail durch SMTP-Client fehlgeschlagen", //IPSMTPCLIENT_MSG_FAILED
	"Bevor Sie diese Assistenten starten, überprüfen Sie bitte, ob Sie alle beschriebenen Schritte aus der im Paket beiliegenden Schnellinstallationsanleitung durchgeführt haben.", //bwz_note_ConWz
	"Gnutella", //gw_gm_64
	"Wiedereinwahlmodus:", //help268
	"Keine blockiert", //NONE_BLOCKED
	"Mai.", //tt_May
	"BigPond Internet Verbindungstyp", //bwn_BPICT
	"2:00 PM", //tt_time_15
	"Di", //_Tue
	"Statistik entfernen", //ss_clear_stats
	"Die Endzeit wird im gleiche Format eingegeben wie die Startzeit, d. h. die Stunden werden im ersten Feld, die Minuten im zweiten Feld eingegeben. Die Endzeit wird bei den meisten Regeln verwendet, jedoch normalerweise nicht bei E-Mail-Ereignisse.", //help197
	"Filterregeln können mit Virtuellen Server-, Portweiterleitungs- oder Fernwartungs-Funktionen verwendet werden.", //ai_intro_3
	"WAN-Verbindung zu lange inaktiv, die Verbindung wird getrennt", //GW_WAN_DISCONNECT_ON_INACTIVE
	"Die DHCP-Adresse %v wird vom Benutzer freigegeben", //DHCP_CLIENT_RELEASED_LEASE
	"Verbindung mit statischer IP-Adresse einrichten", //wwa_set_sipa_title
	"(GMT+12:00) Auckland, Wellington", //up_tz_71
	"ALGs stellen spezielle Behandlung der IP Nutzdaten für einige Protokolle und Anwendungen zur Verfügung, um sie mit der Netzwerk-Adressübersetzung zu ermöglichen (NAT). Wenn Sie Probleme mit solchen Anwendungen haben, versuchen Sie, das entsprechende ALG zu aktivieren oder zu deaktivieren.", //hhaf_alg
	"Überprüfen Sie diese Option, wenn Ihr Standort Sommer-/Winterzeit beachtet.", //help843
	"Stellen Sie sicher, dass ein Drucker an den USB-Port des Routers angeschlossen ist.", //wprn_tt11
	"Verbindungs-Statistiken", //_tstats
	"LCP legt Remoteeinstellungen fest: ACCM: %lx, ACFC: %u, PFC: %u, MRU: %u", //IPPPPLCP_SET_REMOTE_OPTIONS
	"Jetzt online nach aktueller Firmware- und Sprachpaket-Version suchen", //tf_COLF
	"(GMT+01:00) Brüssel, Kopenhagen, Madrid, Paris", //up_tz_28
	"Mrz.", //tt_Mar
	"Nur Web Access protokollieren", //_aa_allow_all
	"Benutzername- / Kennwortverbindung (L2TP)", //wwa_wanmode_l2tp
	"DMZ-Host", //_dmzh
	"Zeitserver %s besitzt die IP-Adresse %v", //GW_TIME_RESOLVED_DNS
	"EAP (802.1x)", //bws_EAPx
	"Richtlinienname", //aa_PolName
	"Um diese Verbindung einzurichten, benötigen Sie eine vollständige Liste der IP-Informationen von Ihrem Internetdienstanbieter. Wenden Sie sich bitte an Ihren Internetdienstanbieter, wenn Sie über eine statische IP-Verbindung verfügen, aber Ihnen diese Inf", //wwa_set_sipa_msg
	"Schritt 1: Festlegen des Richtliniennamens", //_aa_wiz_s2_title
	"PPTP verbunden mit Server \%s\ mit ID 0x%04X", //PPTP_EVENT_TUNNEL_CONNECTED
	"Es wurde keine WCN-kompatible USB-Massenspeicher-Schnittstelle gefunden", //USB_LOG_STORAGE_NOT_FOUND
	"Gerät wurde initialisiert", //GW_INIT_DONE
	"Dynamische IP-Adresse", //carriertype_ct_0
	"Dies sind die Einstellungen des LAN- (Lokales Netzwerk) Anschlusses des Routers. Die lokalen Netzwerk (LAN) Einstellungen des Routers werden auf der Basis der hier angegebenen IP-Adresse und der Subnetz Maske konfiguriert. Die IP-Adresse wird auch für diese Web-basierte Verwaltung verwendet.", //help305
	"Raw TCP Port-Druck (raw-tcp)", //tps_raw
	"Öffentlicher Port", //av_PubP
	"WPA-Modus:", //help374
	"PPTP hat eine Tunnel-Abbauanfrage von der Anwendung erhalten. Der Tunnel wird geschlossen.", //PPTP_EVENT_TUNNEL_CLEAR_DOWN_REQUEST
	"Wählen Sie <strong>Löschen</strong> aus, um eine Regel dauerhaft zu löschen.", //hhac_delete
	"Lokale L2TP-Sitzung 0x%04X wird beendet", //IPL2TP_SESSION_CLEAR_DOWN_REQUEST
	"Richtlinie", //aa_ACR_c2
	"Für die Anfragen vom LAN-Rechner erfolgt keine Schleifenschaltung (Loopback), wenn der Internetzugang zum Zugriffszeitpunkt gesperrt ist. Um dieses Problem zu umgehen, greifen Sie auf den LAN-Rechner unter Verwendung seiner LAN-seitigen Identität zu.", //help29
	"(GMT-11:00) Midway Island, Samoa", //up_tz_01
	"Anwendung", //_app
	"Ungültige LAN-Subnetzmaske.", //bln_alert_1
	"Geschwindigkeit der WAN-Schnittstelle wird geschätzt", //GW_WAN_RATE_ESTIMATOR_STARTED_ON_WAN
	"Firewall und Sicherheit", //sl_FWandSec
	"Für höhere Sicherheit wird empfohlen, dass Sie die WAN Ping-Antwort Option abschalten. Ping wird oft durch böswillige Internet-Teilnehmer genutzt, um aktive Netzwerke oder PCs zu lokalisieren.", //hhan_ping
	"NAT", //sa_NAT
	"Wird die Option Fernverwaltung aktiviert, kann der Router von jedem beliebigen Standort aus über Internet verwaltet werden. Wird die Option Fernverwaltung deaktiviert, kann der Router nur von Rechnern innerhalb des LANs verwaltet werden.", //help828
	"DNS-Eintrag für SMTP- (E-Mail-) Server %s wurde nicht gefunden", //GW_SMTP_EMAIL_FAILED_DNS
	"Die Anzahl an Paketen, die durch Ethernet-Kollisionen fallengelassen wurden (zwei oder mehr Geräte versuchen eine Ethernet-Schaltung zur gleichen Zeit zu verwenden).", //help810
	"WOL (Wake on LAN)", //_WOL
	"Auf Verlangen", //bwn_RM_1
	"Keiner -- Dieser Eintrag wird als Platzhalter für eine zukünftige Verbindung verwendet, die vorkommen kann.", //help819_1
	"Blockierte ankommende ICMP Fehlermeldung (ICMP Typ %u) von %v nach %v, da es keine TCP Verbindung gibt, die zwischen %v:%u und %v:%u aktiv ist", //IPNAT_TCP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"(GMT-04:00) Atlantic Time (Kanada)", //up_tz_14
	"Star Trek: Elite Force II", //gw_gm_51
	"Server-IP-Adresse", //td_SvAd
	"Sie können Ports in verschiedenen Formaten eingeben:", //hhag_40
	"Inbound Filter können für das Begrenzen des Zuganges zu einem Server in Ihrem Netzwerk, zu einem oder einer Gruppe von Computern verwendet werden. Filterregeln können mit virtuellen Servern, Gaming oder Remote Administrationsfunktionen verwendet werden. Jeder Filter kann für verschiedene Funktionen genutzt werden, z.B. ein Spiel Clan-Filter könnte allen Mitgliedern der jeweiligen Spielgruppe erlauben, mehrere verschiedene Spiele zu spielen, für die Spieleinträge erstellt wurden. Gleichzeitig erlaubt ein 'Admin'-Filter ausschließlich Rechnern von Ihrem Firmennetzwerk aus den Zugriff auf die Administrationsseiten oder einen FTP-Server, den Sie zu Hause bereitstellen. Wenn Sie eine IP-Adresse zu einem Filter hinzufügen, wird die Änderung an allen Stellen wirksam, an denen der Filter benutzt wird.", //help169
	"Die Zeitspanne, für die ein Rechner über eine IP-Adresse verfügen kann, bevor die Lease erneuert werden muss. Die Lease, also ein 'Mietvertrag', funktioniert genau so wie ein Mietvertrag für eine Wohnung. Die ursprüngliche Lease bezeichnet dabei die Zeitdauer, für welche der 'Mietvertrag' gültig ist. Möchte der Mieter die Adresse nach Ablauf der Lease weiter nutzen, so wird ein neuer 'Mietvertrag' ausgestellt. Läuft die Lease ab, und der Mieter möchte die Adresse nicht weiter nutzen, so wird diese Adresse für einen anderen 'Mieter' bzw. Nutzer zur Verfügung gestellt.", //help324
	"Ping ist eine Internethilfsfunktion, mit der eine Reihe von kurzen Meldungen an einen Zielcomputer gesendet und die Ergebnisse angezeigt werden. Mit diesem Diagnosewerkzeug können Sie prüfen, ob ein Computer läuft und Sie können auf Grundlage der Geschwindigkeit der Antwort auf das gesendete Signal die Qualität der Verbindung zu diesem Computer bestimmen.", //htsc_intro
	"WLAN-Partition", //KR4_ww
	"Bei den Rechnern (und anderen Geräten), die an Ihr LAN angeschlossen sind, muss die TCP/IP-Konfiguration entsprechend auf &quot;DHCP&quot; oder &quot;IP-Adresse automatisch beziehen&quot; eingestellt sein.", //help317
	"Multicast-Streams", //anet_multicast
	"IPv4-Multicast-Streams", //anet_multicast_v4
	"IPv6-Multicast-Streams", //anet_multicast_v6
	"Neue Richtlinie hinzufügen", //_aa_wiz_s1_title
	"Lokaler L2TP-Tunnel 0x%04X RTE-Modul wurde heruntergefahren.", //IPL2TP_SHUTDOWN_COMPLETE
	"Letzter ACK -- Eine kurze Zeit warten, während eine Close Wait Verbindung völlig geschlossen wird.", //help819_7
	"Wählen Sie das Protokoll (z. B. <code>TCP</code>).", //help9
	"Die Anzahl an Paketen, die beim Empfangen fallengelassen wurden wegen Störungen, Kollisionen oder wegen begrenzten Ressourcen des Routers.", //help809
	"LAN-Ethernet-Carrier erkannt", //GW_LAN_CARRIER_DETECTED
	"Möchten Sie die Protokolleinträge wirklich löschen?", //sl_alert_1
	"Trigger-Port", //as_TPRange_b
	"1", //tt_week_1
	"Falls ja, klicken Sie auf Ok.", //up_jt_3
	"Entfernen", //_clear
	"PPPoE-Sitzung 0x%04X wird beendet", //PPPOE_EVENT_DISCONNECT
	"Der interne WPS-Registrar konnte die WLAN-Station %m nicht hinzufügen. Ursache: %s, err_code %u.", //WIFISC_IR_REGISTRATION_FAIL_2
	"Statische IP", //_sdi_staticip
	"Geben Sie jedem Zeitplan einen Namen, der Sinnvoll ist. Z.B. könnte ein Zeitplan von Montag bis Freitag von 17:00 Uhr bis 23:00 Uhr als &quot;Freizeit&quot; benannt werden.", //hhts_name
	"WAN", //WAN
	"Geben Sie ein Kennwort für den Benutzer Administrator ein, der uneingeschränkten Zugriff auf die webbasierte Verwaltungsschnittstelle erhält.", //help824
	"Computer, die eine IP-Adresse vom DHCP-Server des Routers bekommen haben, erscheinen in der DHCP Client Liste. Wählen Sie ein Gerät über das Pulldown-Menü, dann klicken Sie auf den Pfeil, um die MAC-Adresse dieses Gerätes in die Liste hinzuzufügen.", //hham_add
	"Statistiken WAN", //ss_WANStats
	"Es wird versucht, eine WAN-Verbindung bei Bedarf zu starten", //GW_WAN_CONNECT_ON_ACTIVE
	"Alle Änderungen müssen vor dem Festlegen eines neuen Zeitplans verworfen werden.", //aa_sched_conf_1
	"Richtlinie %s wurde angehalten; Der Internetzugriff wurde für alle nicht festgelegten Systeme geändert auf: %s", //GW_INET_ACCESS_POLICY_END_OTHERS
	"Liste der DHCP-Reservierungen", //bd_title_list
	"Web Access-Protokoll", //_aa_logging
	"Blockierte ankommende ICMP Fehlermeldung (ICMP Typ %u) von %v nach %v, da es für Protokoll %u zwischen %v und %v keine aktive Session gibt", //IPNAT_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"Benutzername", //_username
	"eMule", //gw_gm_67
	"DNS-Eintrag für Zeitserver %s wurde nicht gefunden", //GW_TIME_FAILED_DNS
	"Die für Ihr Betriebssystem geltenden Anleitungen zum Einrichten des Druckers finden Sie in der im Lieferumfang des Routers enthaltenen Dokumentation.", //wprn_tt1
	"9:00 PM", //tt_time_22
	"IP-Adresse", //help256
	"Internet-Zugriffs-Regel für IP-Adresse %v kann nicht eingestellt werden", //GW_INET_ACCESS_INITIAL_IP_FAIL
	"Details", //_aa_details
	"Erlaubt Anwendungen, welche das Real Time Streaming Protokoll verwenden, um Streaming Medien aus dem Internet zu empfangen. Quick Time und Real Player sind einige von den üblichen Anwendungen, die dieses Protokoll verwenden.", //help36
	"Die Portnummer der LAN-seitigen Anwendung wird durch die WAN-seitige Anwendung betrachtet.", //help817
	"PPPoE (Benutzername/Kennwort)", //bwn_Mode_PPPoE
	"Alle zulassen", //_allowall
	"Listeninhalt unten entfernen...", //awf_clearlist
	"Der Router muss neu gestartet werden, bevor die auf einer vorhergehenden Seite gespeicherten Einstellungen übernommen werden. Sie können den Router durch Drücken der Schaltfläche 'Neustart' jetzt neu starten oder die Schaltfläche 'Weiter' drücken, um weitere Änderungen vorzunehmen.", //sc_intro_rb3
	"Zu öffnende TCP-Ports", //help67
	"Quake 2", //gw_gm_37
	"Weitere Optionen", //aa_AT_2
	"Schritt 1: Vergeben Sie Ihr Kennwort", //wwa_title_s1
	"Treibername", //tps_drname
	"Zeiteinstellungen des Computers kopieren", //tt_CopyTime
	"L2TP-Sitzungserver hat mit dem Senden von Sequenznummern für die lokale Sitzung 0x%04X begonnen", //IPL2TP_SEQUENCING_ACTIVATED
	"Reservieren", //bd_Reserve
	"MSN Messenger ALG lehnte Paket von %v:%u nach %v:%u ab", //IPMSNMESSENGERALG_REJECTED_PACKET
	"Der Abschnitt Wireless erlaubt die Anzeige von Informationen über die Wireless-Klienten, die an Ihren Router angeschlossen sind.", //help782
	"Dungeon Siege", //gw_gm_16
	"Port Forwarding ALG konnte die Sitzung für das UDP-Paket nicht von %v:%u auf %v:%u zuweisen", //IPPORTFORWARDALG_UDP_PACKET_ALLOC_FAILURE
	"Modell", //wprn_mod
	"Anmerkung:", //help119
	"Silent Hunter II", //gw_gm_46
	"Aktivieren Sie die MAC Filterung und ERLAUBEN Sie den Computern in der Liste auf das Netzwerk zuzugreifen", //am_FM_3
	"Verwenden Sie diese Funktion um Ihren Computer für LPD/LPR drucken zu konfigurieren.", //sps_lpd1
	"Systemeinstellungen", //tss_SysSt
	"Konfiguration aus Datei wiederherstellen", //ta_ResConf
	"Flash auf Drahtlos-Konfiguration aktualisieren", //WCN_LOG_SAVE
	"Firewall Verkehrs-Typ", //as_FPrt
	"UDP-Verbindungen.", //help823_11
	"Jeden Tag", //tsc_EvDay
	"Klicken Sie die <span class='button_ref'>Löschen</span> Taste an, um die MAC-Adresse von der MAC Filterliste zu entfernen.", //ham_del
	"PPPoE", //_PPPoE
	"Es scheint, dass Sie bereits erfolgreich Ihren neuen Router an das Internet verbunden haben.", //wwa_intro_online1
	"Ende der Sommerzeit", //tt_dstend
	"Zeitplanregel", //tsc_SchRu
	"Fehlgeschlagener Konfigurations-Authentifizierungsversuch von IP-Adresse %v", //GW_AUTH_FAILED
	"Zeitpläne", //_scheds
	"(GMT+09:00) Irkutsk, Ulaan Bataar", //up_tz_56
	"Sekundärer DNS-Server", //_dns2
	"Sekundärer IPv6 DNS-Server", //_dns2_v6
	"Sie müssen einen Computernamen oder eine IP-Adresse eingeben.", //tsc_pingt_msg2
	"Diese Einstellungen werden automatisch konfiguriert und sollten nur durch erfahrene Benutzer verändert werden.", //tps_apc1
	"Die Internet-Zugriffskontrolle hat ein Paket von %v:%u an %v:%u (Protokoll %u) verworfen.", //GW_INET_ACCESS_DROP_ACCESS_CONTROL_WITH_PORT
	"(GMT+05:45) Kathmandu", //up_tz_48
	"Admin Passwort", //_password_admin
	"Benutzen Sie diesen Abschnitt, um den integrierten DHCP-Server einzurichten und den Computern in Ihrem Netzwerk IP-Adressen zuzuweisen.", //bd_intro_
	"Radius-Server IP-Adresse:", //help387
	"Zulässige Konfigurations-Authentifizierung von IP-Adresse %v", //GW_AUTH_SUCCEEDED
	"CHAP-Authentifizierungsinformationen wurden an Peer übertragen.", //IPPPPCHAP_AUTH_SENT
	"Der Altersfreigabe-Service ist eine einfache und trotzdem effektive Methode, den Zugriff auf anstößige, illegale und extremistische Websites zu beschränken. Der Service erstreckt sich auf alle an Ihrem Router angeschlossenen Rechner und Apple-Computer und wird laufend auf den neuesten Stand gebracht. (Sie brauchen keine Downloads durchzuführen oder Seiten von Hand einzugeben.) Der Service ist schnell und beeinträchtigt Ihr Netzwerk nicht.", //_bsecure_parental_blurb
	"Dieser Assistent führt Sie durch die nächsten Schritte, um eine neue Richtlinie zur Zugriffssteuerung hinzuzufügen.", //_aa_wiz_s1_msg
	"Zeigt die Anzahl der Pakete an, die vom Router empfangen wurden.", //help807
	"(GMT+09:00) Seoul", //up_tz_61
	"L2TP-Gateway-IP-Adresse", //_L2TPgw
	"MSCHAP-Authentifizierung fehlgeschlagen - Anmeldedetails prüfen.", //IPMSCHAP_AUTH_FAIL
	"Erweitert:", //help395
	"Haben Sie eine Firmware lokal auf Ihrem Computer, dann verwenden Sie diese Option, um den Computer nach der Datei zu durchsuchen und anschließend die Informationen hochzuladen.", //help888
	"Medal of Honor: Games", //gw_gm_29
	"Die Regel wird auf jeglichen Datenfluss angewendet, dessen WAN-seitige IP-Adresse in dem hier festgelegten Bereich fällt.", //help95
	"Signalisierungsintervall (Beacon Period)", //aw_BP
	"WAN-Dienste werden angehalten", //GW_WAN_SERVICES_STOPPED
	"TeamSpeak", //gw_gm_79
	"Wählen Sie einen Zeit-Server im Netzwerk zur Synchronisation. Sie können die Adresse eines Zeit-Servers eingeben oder einen von der Liste auswählen. Wenn Sie Probleme mit einem Server haben, wählen Sie einen anderen.", //help850
	"Sie sind Host für einen Webserver auf einem PC, der die LAN IP-Adresse 192.168.0.50 aufweist. Ihr Internetdienstanbieter sperrt Port 80.", //help4
	"(GMT-03:00) Brasilia", //up_tz_18
	"Wenn Sie Virtuelle Server, die Portweiterleitung oder Remote Verwaltungs- Funktionen benutzen, um spezielle Ports für Verkehr vom Internet zu öffnen, erhöht sich das Risiko, dass Ihr LAN aus dem Internet angegriffen werden kann.", //help168a
	"PPTP ALG lehnte das Paket von %v:%u nach %v:%u ab", //PPTP_ALG_REJECTED_PACKET
	"SMTP-Serveradresse", //te_SMTPSv
	"Battlefield 2", //gw_gm_84
	"Lokaler L2TP-Tunnel 0x%04X RTE-Modul verfügt nicht über ausreichende Ressourcen.", //IPL2TP_LOW_RESOURCES
	"Wählen Sie <strong>Regel hinzufügen</strong> aus, um mit dem  Erstellen einer Regel zu beginnen. Sie können den Prozess jederzeit beenden. Wenn Sie das Erstellen einer Regel abschliessen, wird sie in die <strong>Regel-Tabelle</strong> unten hinzugefügt.", //hhac_add
	"Auto 10/100 Mbit/s", //anet_wp_auto2
	"RTSP", //as_RTSP
	"Authentifizierung &amp; Sicherheit", //_authsecmodel
	"MTU", //bwn_MTU
	"Stream", //gw_gm_72
	"WAN", //_WAN
	"Erweiterter IGMP Proxy", //anet_multicast_enhanced
	"Command and Conquer: Generäle", //gw_gm_8
	"WPA", //_WPA
	"Wiederholen Sie die Eingabe des Kennworts oder Schlüssels ein, das/den Sie von Ihrem Internetdienstanbieter erhalten haben. Hat Ihnen Ihr Internetdienstanbieter nur einen Schlüssel bereitgestellt, geben Sie diesen Schlüssel in alle drei Felder ein.", //help897
	"Blockiertes ankommendes TCP Paket von %v:%u nach %v:%u mit unerwarteter Reihenfolge %lu (erwartet %lu nach %lu)", //IPNAT_TCP_BLOCKED_INGRESS_BAD_SEQ
	"Antwort von", //tsc_pingt_msg7
	"Jan.", //tt_Jan
	"Battlefield Vietnam", //gw_gm_5
	"Erweitert Wireless", //_adwwls
	"Pings empfangen:", //tsc_pingt_msg101
	"Unreal", //gw_gm_55
	"WAN-PING", //anet_wan_ping
	"<warn>In diesem Internetmodus können die WINS/NetBIOS-Einstellungen nicht über das Internet abgerufen werden. WINS wird daher nicht ordnungsgemäß funktionieren.</warn>", //GW_DHCP_SERVER_WINS_INCOMPATIBILITY_WARNING
	"MAC-Adresse Authentifizierung", //bws_RMAA
	"Schritt 2 - Festlegen eines Zeitplans", //aa_wiz_s1_msg2
	"6:00 AM", //tt_time_7
	"Initialisiert von WAN zu LAN.", //help822a
	"America's Army", //gw_gm_1
	"(GMT+03:00) Bagdad", //up_tz_37
	"Sicherheitsmodus", //bws_SM
	"(GMT+10:00) Hobart", //up_tz_68
	"- Genau 64 Zeichen (Zahlen 0-9 und/oder Buchstaben A-Z)", //wwl_s4_intro_za3
	"Zurück", //_prev
	"SharePort Web Access aktivieren", //sto_http_1
	"Der Drucker-Setup-Assistent erfordert das Raw-TCP-Port-Druckprotokoll. Dieses Protokoll ist derzeit auf Ihrem Router deaktiviert.", //wprn_foo1
	"Ein drahtloses Netzwerk benutzt bestimmte Kanäle im Frequenz- Spektrum, um Kommunikation zwischen Clients zu ermöglichen. Einige Kanäle in Ihrer Umgebung können Störung von anderen elektronischen Geräten haben. Wählen Sie den saubersten Kanal, um die Leistung und die Reichweite Ihres drahtlosen Netzes zu optimieren.", //help355
	"Protokolliert", //aa_ACR_c6
	"Sekundärer RADIUS-Server Shared Secret", //bws_2RSSS
	"Radius-Server Shared Secret:", //help391
	"Nachmittags", //_PM
	"Legen Sie den Bereich der anzuwendenen Internetadressen fest. Für eine einzelne IP-Adresse geben Sie diese jeweils in die Felder <span class='option'>Start</span> und <span class='option'>Ende</span> ein. Bis zu acht Bereiche können festgelegt werden. Mit dem Kontrollkästchen <span class='option'>Aktivieren</span> ermöglichen Sie das Ein- oder Abschalten der einzelnen Einträge in der Liste.", //help174
	"PPPoE Zeitüberschreitung bei Warten auf Verbindung. Verbindungsversuch ist fehlgeschlagen.", //PPPOE_EVENT_DISCOVERY_TIMEOUT
	"Gerät %s, wsetting.wfc: Datei wurde nicht gefunden", //WCN_LOG_NO_WSETTING
	"Papierstau", //psPaperError
	"Wenn Sie diese Option unmarkiert lassen, wird der Router <code>Ping</code> Befehle für die öffentliche WAN IP-Adresse des Routers ignorieren.", //anet_wan_ping_2
	"Um die Firmware zu aktualisieren, gehen Sie wie folgt vor:", //help878
	"Protokolliert", //LOGGED
	"Manuell", //bwn_RM_2
	"Radius-Server Shared Secret", //bws_RSSs
	"(GMT+04:00) Baku, Tiflis, Eriwan", //up_tz_43
	"RTSP ALG lehnte Paket von %v:%u nach %v:%u ab", //IPRTSPALG_REJECTED_PACKET
	"kann nicht gelöscht oder umbenannt werden, da gerade in Verwendung.", //GW_SCHEDULES_IN_USE_INVALID_s2
	"Erweiterte Hilfe", //help1
	"MSN Game Zone", //gw_gm_73
	"Das Anklicken der Links oder Icons leitet Sie zu einer Webseite weiter unter der Sie mehr Informationen bekommen.", //hhtsn_intro
	"Ping", //_ping
	"Manuelle Uplink Geschwindigkeit", //at_UpSp
	"Schritt 6 - Web Zugriffsprotokollierung konfigurieren", //aa_wiz_s1_msg6
	"PPTP-IP-Adresse", //_PPTPip
	"Bei einem DTIM handelt es sich um einen Countdown, der die Klienten über das Fenster zur nächsten Übertragung oder Multicast-Übertragung informiert. Hat der Wireless Router Übertragungen oder Multicast-Übertragungen für zugehörige Klienten im Pufferspeicher gesichert, sendet er den nächsten DTIM mit einem DTIM-Intervallwert. Wireless-Klienten erkennen diese Signale und wechseln in den aktiven Zustand, um die Übertragung und Multicast-Übertragung zu empfangen. Der Standardwert beträgt 1. Gültige Einstellungen liegen zwischen 1 und 255.", //help185
	"Klicken Sie diese Taste nach dem Ändern der Log-Einstellungen an, um diese wirksam und dauerhaft zu übernehmen.", //help799
	"(GMT-03:30) Neufundland", //up_tz_17
	"Auf dieser Seite werden alle Details zur Internet- und Netzwerkverbindung angezeigt. Auch die Firmware-Version wird hier angezeigt.", //sd_intro
	"Hochladen", //tf_Upload
	"Sekunde", //tt_Second
	"Diese Aktion führt zum Verlust sämtlicher WLAN-Einstellungen.", //wps_lost
	"Anmerkung:", //help26
	"(GMT+02:00) Helsinki, Riga, Tallinn", //up_tz_35
	"Benutzen Sie diesen Abschnitt, um Ihren Internet-Verbindungstyp zu konfigurieren. Es stehen verschiedene Verbindungstypen zur Auswahl: Statische IP, DHCP, PPPoE, PPTP, L2TP. Wenn Sie unsicher sind was Ihren Verbindungstyp betrifft, treten Sie bitte mit Ihrem Internetdienstanbieter (ISP) in Verbindung.", //bwn_intro_ICS
	"In diesem Abschnitt können Sie Ihren Internetverbindungstyp konfigurieren. Mehrere Verbindungstypen stehen zur Auswahl: Statische IP, DHCP, PPPoE, PPTP, L2TP und 3G USB. Wenn Sie nicht sicher sind, welche Verbindungsmethode Sie verwenden sollen, wenden Sie sich bitte an Ihren Internetdienstanbieter.", //bwn_intro_ICS_3G
	"In diesem Abschnitt können Sie Ihren Internetverbindungstyp konfigurieren. Mehrere Verbindungstypen stehen zur Auswahl: Statische IP, DHCP, PPPoE, PPTP, L2TP und DS-Lite. Wenn Sie nicht sicher sind, welche Verbindungsmethode Sie haben, wenden Sie sich bitte an Ihren Internetdienstanbieter.", //bwn_intro_ICS_v6
	"Diese Option bewirkt bei Aktivierung, dass der Router automatisch bei jedem erneuten Aufbau der WAN-Schnittstelle (z. B. nach einem Neustart) die Uplink-Bandbreite erfasst.", //help81
	"Diese Option erlaubt Ihnen, die Konfiguration des Routers als Datei auf Ihrem Computer zu speichern. Speichern Sie die Konfiguration, bevor Sie eine Aktualisierung der Firmware durchführen.", //help833
	"Gesendet", //ss_Sent
	"Gruppenschlüssel Aktualisierungsintervall:", //help378
	"Tribes of Vengeance", //gw_gm_80
	"Hochladen erfolgreich", //_uploadgood
	"PIN", //KR38
	"Die Setup-Datei wird nach einem kompatiblen Druckertreiber auf Ihrem Rechner suchen. Sollte keiner gefunden werden, erscheint eine Aufforderung, die mit dem Drucker ausgelieferte Treiber CD einzulegen.", //wprn_s3c
	"Der Router stellt nur begrenzten Firewallschutz für den DMZ Host zur Verfügung. Der Router sendet ein TCP-Paket nicht weiter, das nicht zu einer aktiven DMZ Session passt, es sei denn es ist ein Verbindungseinrichtungspaket (SYN). Abgesehen von diesem begrenzten Schutz ist der DMZ Host effektiv „außerhalb der Firewall“. Jeder, der einen DMZ Host verwenden möchte, sollte deshalb eine Firewall auf dem DMZ Hostsystem verwenden, um zusätzlichen Schutz zu gewährleisten.", //haf_dmz_20
	"Empfangen", //ss_Received
	"Wählen Sie diese Option, um über Telstra BigPond Cable Broadband in Australien eine Verbindung mit dem Internet herzustellen. Telstra BigPond liefert die Werte für", //help263
	"KOSTENLOSE 30 Tage-Testversion", //_bsecure_free_trial
	"Optionen zur Benachrichtigung über Firmware-Aktualisierungen", //tf_FUNO
	"Kurzes GI", //aw_sgi
	"Die Länge der Zeit bevor ein Klient zur erneuten Authentifizierung aufgefordert wird.", //help386
	"Es stehen mehrere Verbindungstypen zur Auswahl: Statische IP, DHCP, PPPoE, PPTP, L2TP und BigPond. Wenn Sie in der Wahl Ihrer Verbindungsmethode unsicher sind, fragen Sie bitte bei Ihrem Internetdienstleister nach. Anmerkung: Wenn Sie die PPPoE Option verwenden, müssen Sie sicherstellen, dass jede PPPoE Client Software auf Ihren Computern deinstalliert oder deaktiviert wird.", //help254_ict
	"Sie können unter mehreren Verbindungstypen auswählen: Statische IP, DHCP, PPPoE, PPTP, L2TP und 3G USB. Wenn Sie nicht genau wissen, welche Verbindungsmethode verwendet wird, wenden Sie sich an Ihren Internetdienstanbieter. Hinweis: Bei Verwendung von PPPoE müssen Sie sicherstellen, dass jegliche PPPoE-Client-Software auf den Computern entfernt oder deaktiviert wurde.", //help254_ict_3G
	"Wählen Sie die Art der Filterung.", //_aa_wiz_s5_msg1
	"Kennwort oder Schlüssel bestätigen", //td_VPWK
	"Need for Speed 3", //gw_gm_33
	"Age of Empires", //gw_gm_0
	"MAC-Adressfilter", //_macfilt
	"Um diese Funktion nutzen zu können, benötigen Sie ein dynamisches DNS-Konto bei einem der Anbieter aus dem Dropdown-Menü.", //TA16
	"(Kompatibilität für einige DHCP-Klienten herstellen)", //bd_DAB_note
	"Wählen Sie die Ereignistypen, die Sie anzeigen möchten.", //help796
	"Möchten Sie das Gerät wirklich mit der Firmware-Datei neu programmieren", //tf_really_FWF
	"(GMT-07:00) Arizona", //up_tz_05
	"3:00 PM", //tt_time_16
	"Diese Email-Adresse erscheint als Absender, wenn Sie eine Log-Datei oder Firmware Upgrade-Benachrichtigung per Email empfangen.", //help861
	"Wählen Sie das von dem Dienst verwendete Protokoll.", //help19
	"DHCP WAN-Modus", //bwn_DWM
	"ICMP", //_ICMP
	"Half Life", //gw_gm_22
	"Email Log wenn VOLL oder auf dem Zeitplan", //help868
	"Kennwortsatz", //IPV6_TEXT24
	"5:00 AM", //tt_time_6
	"Klicken Sie diese Taste, um eine neue Zugriffskontroll-Richtlinie zu erstellen.", //_501_12
	"Wählen Sie <strong> Zugriffskontrolle aktivieren </strong> aus, wenn Sie Regeln einschalten möchten, die den Internet-Zugriff auf bestimmten LAN Computern begrenzen.", //hhac_en
	"Manuell Konfigurieren", //int_LWlsWz
	"Übertragungsrate auswählen", //at_STR
	"Aug.", //tt_Aug
	"Aktivieren Sie die MAC Filterung und VERWEIGERN Sie den Computern in der Liste auf das Netzwerk zuzugreifen.", //am_FM_4
	"Schritt 5 - Filter auswählen", //aa_wiz_s1_msg5
	"Zugriffssteuerung", //ACCESS_CONTROL
	"Fehler beim Aktualisieren des dynamischen DNS-Eintrags: %s. Überprüfen Sie die Konfiguration. DynDNS wird deaktiviert", //GW_DYNDNS_HERROR
	"Zu öffnende Ports", //sps_ports
	"Wenn Sie nicht die NTP-Server Option verwenden möchten, können Sie entweder die Zeit für Ihren Router hier manuell einstellen, oder Sie klicken die Taste <span class='button_ref'>Einstellungen zum Kopieren der Zeit des Computers</span> an, um die Zeitangabe vom Computer, den Sie benutzen, zu kopieren. (Überprüfen Sie, daß die Zeit des Computer richtig eingestellt ist.)", //help851
	"Sie können einen Computer aus der Liste der DHCP-Teilnehmer im <strong>Computer Name</strong> Pulldown-Menü auswählen, oder Sie können die IP-Adresse des LAN Computers manuell eingeben, zu dem Sie den bestimmten Port öffnen möchten.", //hhag_20
	"Diese Geräteregel wird bereits verwendet.", //aa_alert_7
	"DMZ-IP-Adresse", //af_DI
	"Verfügbarer Download-Ort", //tf_ADS
	"Ping-Test", //tsc_pingt
	"Stufen anzeigen", //sl_VLevs
	"Verschlüsselung", //wwl_enc
	"Eine MAC-Adresse ist eine einmalige ID, die vom Hersteller des Netzwerkadapters zugewiesen wurde.", //help151
	"Wählen Sie einen Port, um die Fernwartung zu aktivieren.", //hhta_pt
	"Die Internetzugriffssteuerung hat Paket verloren von %v:%u[%s] bis %v:%u (Protokoll %u)", //GW_INET_ACCESS_DROP_ACCESS_CONTROL
	"Authentifizierung aktivieren", //te_EnAuth
	"STA mit MAC (%m) WPS-Vorgang beendet", //WIFISC_AP_PROXY_PROCESS_CLOSE
	"Computername", //bd_CName
	"Es wird empfohlen, die Standardeinstellungen zu verwenden, wenn Sie kein Netzwerk haben.", //help305rt
	"Kennwort ungültig, bitte versuchen Sie es erneut.", //li_alert_3
	"Dynamischer DNS-Eintrag wird aufgrund Zeitüberschreitung aktualisiert", //GW_DYNDNS_UPDATE_TO
	"4", //tt_week_4
	"Tag", //tt_Day
	"LAN-Ethernet-Carrier verloren", //GW_LAN_CARRIER_LOST
	"Jede Regel kann entweder den Zugriff vom WAN <strong>erlauben</strong> oder <strong>verweigern</strong>.", //hhai_action
	"Der Richtlinien-Assistent führt Sie durch die erforderlichen Schritte zur Einrichtung jeglicher Zugriffsrichtlinie. Eine Richtlinie definiert, wer / was / wann und wie Zugriff erlangt. Dies bezieht sich z.B. darauf, welche Computer von der Zugriffssteuerung betroffen sind, welche Internetadressen kontrolliert werden, wann die Zugriffssteuerung eintritt und wie diese Steuerung umgesetzt werden soll. Es können mehrere Richtlinien eingerichtet werden. Der Richtlinien-Assistent startet, wenn Sie die Taste unten anklicken, aber auch beim Bearbeiten einer vorhandenen Richtlinie.", //help121
	"Um diese Verbindung einzurichten, benötigen Sie einen Benutzernamen und ein Kennwort von Ihrem Internetdienstanbieter. Wenn Sie diese Informationen nicht haben, kontaktieren Sie bitte Ihren Internetdienstanbieter.", //wwa_msg_set_pppoe
	"Blockiertes ankommendes ICMP Paket (ICMP Typ %u) von %v nach %v", //IPNAT_ICMP_BLOCKED_INGRESS_PACKET
	"um Funktionalität und Leistung zu verbessern.", //tf_intro_FWU2
	"Aktivieren Sie oder sperren Sie definierte Regeln mit Hilfe der Ankreuzfelder links.", //at_ESE
	"Die Sicherheits-Services schützen Ihre Rechner durch eine einheitliche Servicesuite. Die Einstellungen der Suite können mit jedem Browser verwaltet werden. Die Servicesuite beinhaltet Leistungen wie Virenschutz, Firewall, Eindringungserkennung, Inhaltsfilterung, Spam-Filterung und Pop-Up-Blocker, die einzeln oder im Paket zu einem geringen Preis erworben werden können.", //_bsecure_security_blurb
	"DHCP-Client-Liste", //bd_DHCP
	"Geben Sie hier Ihr Konto für das Versenden von E-Mails ein.", //help865
	"Der WEP (Wired Equivalent Privacy)-Schlüssel muss einer der folgenden Richtlinien entsprechen:", //wwl_s4_intro_z1
	"Herunterladen", //help501
	"Das ISP liefert, wenn erforderlich, diesen Parameter. Dieser Wert kann derselbe wie die IP-Adresse des Gateways sein.", //help280
	"DHCP-Verbindung", //help775
	"Verbinden", //_connect
	"BigPond aktiviert", //GW_BIGPOND_INIT
	"Immer", //_always
	"(Minuten)", //_minutes
	"Firewall-Port", //as_IPR_b
	"Jobs", //_aa_bsecure_employment
	"Die Internetzugriffssteuerung hat Paket verloren von %v bis %v (Protokoll %u)", //GW_INET_ACCESS_DROP_BAD_PKT
	"Dark Reign 2", //gw_gm_12
	"Hexen II", //gw_gm_25
	"Wählen Sie die Start- und Endwochen für die Umstellung von der Sommerzeit auf die Winterzeit. Nehmen wir einmal an, der Termin für den Start der Winterzeit lautet Monat=\"Okt\"; Woche=\"3\"; Day=\"So\" and Time=\"2 Uhr\". Dies bedeutet in anderen Worten ausgedrückt: \";Die Winterzeit beginnt am dritten Sonntag im Monat Oktober um 2 Uhr.", //help846
	"Bitte wählen Sie entweder die Automatische oder die Manuelle Zeiteinstellung. Nicht beides", //tt_alert_1only
	"Gamespy Arcade", //gw_gm_76
	"Protokoll angezeigt von IP-Adresse %v", //GW_LOGS_VIEWED
	"Wenn WPA-Enterprise aktiviert ist, verwendet der Router EAP (802.1x) um Klienten per RADIUS-Server zu authentifizieren.", //bws_msg_EAP
	"Interner WPS-Registrar hat mit der Registrierung von %s begonnen", //WIFISC_IR_REGISTRATION_INPROGRESS
	"Dieses ist eine Liste aller aktiven Verbindungen zwischen WAN Computern und LAN Computern.", //hhsa_intro
	"Dieser Abschnitt erlaubt es Ihnen, Ihre Logfiles auf einem Syslog-Server zu archivieren.", //help856
	"Richtung", //sa_Dir
	"IGMP Multicast Mitgliedschaft", //_bln_title_IGMPMemberships
	"L2TP (Benutzername/Kennwort)", //bwn_Mode_L2TP
	"Do", //_Thu
	"Ungültige PIN (2. Hälfte) erkannt", //KR30
	"Beacons sind Pakete, die von einem Wireless Router zur Synchronisierung an Wireless-Geräte gesendet werden. Geben Sie ein Beacon-Intervall zwischen 20 und 1000 Millisekunden an. Der Standardwert beträgt 100 Millisekunden.", //help184
	"Wählen Sie die Option aus, die in Ihrer Installation am besten funktioniert.", //_worksbest
	"nicht verfügbar", //_unavailable
	"Erkanntes Dateisystem ist nicht kompatibel (FAT32,FAT16,FAT12)", //IPFAT_INCOMPATIBLE_FILESYS
	"Blockiertes ankommendes TCP Paket von %v:%u nach %v:%u, %s hat zwar empfangen, aber es gab keine aktive Verbindung", //IPNAT_TCP_BLOCKED_INGRESS_NOT_SYN
	"(GMT-08:00) Pacific Time (USA/Kanada), Tijuana", //up_tz_04
	"Protokolleinstellungen jetzt übernehmen", //sl_ApplySt
	"CHAP-Authentifizierungsanforderung von Peer empfangen.", //IPPPPCHAP_CHALLENGE_RECVD
	"Dieses Kapitel dient der Eingabe der Web-Adressen für Zugriffskontrolle.", //help141
	"Aufheben", //bd_Revoke
	"Schritt 1: Drucker erkennen", //wprn_intro3
	"Verbindungsbetriebszeit", //_conuptime
	"Stellen Sie sicher, dass der Drucker eingeschaltet ist.", //wprn_tt4
	"Drahtlose Netzwerktechnologie ermöglicht allgegenwärtige Kommunikation", //help383
	"Keine Antwort zum Ping vom Router, erneuter Versuch.", //tsc_pingt_msg6
	"Initialisiert von LAN zu WAN.", //help821a
	"PPPoE Sitzungsangebot empfangen", //PPPOE_EVENT_SESSION_OFFER_RECVD
	"Myth", //gw_gm_30
	"Wenn Sie bereits Vorkenntnisse in der Routerkonfiguration haben, klicken Sie <span class='button_ref'>Manuell konfigurieren</span> an, um alle Einstellungen manuell einzugeben.", //bi_man
	"Gemischt (1020-5000, 689)", //help60
	"Ferner Admin-Port", //ta_RAP
	"BigPond (Australien)", //bwn_Mode_BigPond
	"Der aktuelle Druckerstatus wird dazu führen, dass die Testseite später im Setup-Prozess nicht gedruckt werden kann.", //wprn_cps2
	"Beginn der Sommerzeit", //tt_dststart
	"Wenn das Protokoll TCP ist, prüft SPI, ob Paket-Reihenfolgenummern innerhalb des gültigen Bereiches für diese Session sind, und verwirft Pakete, die keine gültige Reihenfolgenummer haben.", //help164_1
	"Zeitüberschreitung bei MS-CHAP-Authentifizierung – Authentifizierung fehlgeschlagen", //IPMSCHAP_AUTH_TIMEOUT
	"Jetzt E-Mail senden", //sl_emailLog
	"Wireless Netzwerkeinstellungen", //bwl_title_1
	"BigPond-Kennwort", //bwn_BPP
	"Aktualisieren", //sl_reload
	"Schritt 1: Name Ihres Wireless-Netzwerkes", //wwl_title_s1
	"Einrichten des Laufwerks ist fehlgeschlagen", //IPDRIVE_MOUNT_FAILED
	"Assistent für die Einrichtung des Internetzugangs", //int_ConWz
	"Berechtigung", //sto_permi
	"Die Option <code>Aufheben</code> wird in der Situation benötigt, wenn die Vergabetabelle voll oder nahezu voll ist, Sie Platz für neue Einträge in der Liste oder einige der gegenwärtig zugeteilten Vergaben nicht länger benötigen. Wenn Sie auf <code>Aufheben</code> klicken, wird die Vergabe für das bestimmte LAN-Gerät aufgehoben und leert den Eintrag in der Vergabetabelle. Machen Sie dies nur dann, wenn das Gerät nicht länger die vergebene IP-Adresse benötigt, weil dieses sonst z.B. aus dem Netzwerk entfernt wird.", //help329
	"Lokaler L2TP-Tunnel 0x%04X: Verbindung wurde getrennt", //IPL2TP_TUNNEL_DISCONNECTED
	"Remote-Admin-Eingangsfilter", //help830
	"Die Maximum Transmission Unit (MTU) ist ein Wert, der die maximale Paketgröße (in Bytes) angibt, welche der Router in das WAN sendet. Falls die LAN-Geräte größere Pakete senden, zerlegt der Router diese in kleinere Pakete. Idealerweise sollten Sie die MTU nach Vorgabe Ihres ISP einstellen. Typische Werte sind 1500 Bytes für eine Ethernet- und 1492 Bytes für eine PPPoE-Verbindung. Wird die MTU des Routers zu hoch eingestellt, werden Pakete im Downstream zersplittet. Ist die MTU des Routers zu klein, zersplittet der Router die Pakete unnötigerweise und im Extremfall kann dies der Grund für das Nichtzustandekommen einer Verbindung sein. In beiden Fällen leidet die Netzwerkgeschwindigkeit.", //help294
	"(GMT-02:00) Mittelatlantik", //up_tz_21
	"Datum der neuesten Firmware-Version", //tf_LFWD
	"BigPond angemeldet, Status=%d, Serverantwort=%s", //GW_BIGPOND_SUCCESS
	"Alle verweigern", //_denyall
	"Automatische Klassifizierung", //at_AC
	"Sichtbarkeitsstatus", //bwl_VS
	"In diesem Bereich können Sie sehen, welche LAN-Geräte momentan IP-Adressen bezogen haben.", //help327
	"Um den Setup-Prozess abzuschließen, startet der Assistent nun eine ausführbare Datei auf Ihrem Rechner.", //wprn_s2a
	"(Stunden)", //td_
	"Der PPTP-Remotezugriffskonzentrator reagiert langsam. Es bestehen möglicherweise Verbindungsprobleme.", //PPTP_EVENT_TUNNEL_WINDOW_TIMEOUT
	"Übertragungsleistung", //aw_TP
	"Statische IP-Adresse Internet-Verbindungstyp", //bwn_SIAICT
	"Bestimmte Anwendungen, wie z. B. Internetspiele, Videokonferenzen, Internettelefonie und weitere Anwendungen, erfordern mehrere Verbindungen. Diese Anwendungen funktionieren u. U. nicht richtig über NAT (Network Address Translation). In diesem Abschnitt können Sie mehrere Ports oder Portbereiche im Router öffnen und Daten über diese Ports an einen einzelnen Rechner im Netzwerk weiterleiten. Sie können Ports in verschiedenen Konstellationen eingeben", //help57
	"Sommer-/Winterzeit aktivieren", //tt_dsen2
	"Verbindung wird getrennt (bitte warten...)", //_sdi_s5
	"Hersteller", //wprn_man
	"2:00 AM", //tt_time_3
	"(GMT-03:00) Grönland", //up_tz_20
	"RIP hat die Route %v von Router %v wegen zu niedriger System-Reserven abgelehnt", //RIP_LOW_RESOURCES
	"Dienstname", //help266
	"Verbunden", //CONNECTED
	"Wenn Ihnen Ihr ISP eine feste IP-Adresse zugewiesen hat, wählen Sie diese Option. Der ISP stellt die Werte für die folgenden Felder zur Verfügung:", //help265_5
	"Tag(e)", //tsc_Days
	"(GMT-05:00) Indiana (Ost)", //up_tz_13
	"Allgemein", //sd_General
	"UPnP hilft anderem UPnP Computern im LAN, mit dem Router zusammenzuarbeiten. Lassen Sie die UPnP Option aktiviert, wenn im LAN andere UPnP Applikationen vorhanden sind.", //hhan_upnp
	"Prüfen Sie mit dem Systemadministrator Ihres Firmennetzwerks, ob Ihr VPN-Client NAT-Traversal unterstützt.", //help35
	"Die IP-Adresse des Systems in Ihrem internen Netzwerk, das den virtuellen Dienst liefert. Die Adresse könnte z. B. <code>192.168.0.50</code> sein.", //help18
	"Drucker Setup-Assistent", //bwz_psw
	"Datum und Uhrzeit", //tt_DaT
	"Zeitpläne definieren die Zeiten, zu denen andere Regeln aktiv sind. Soll beispielsweise der Webzugriff auf die Zeiten Mo-Fr von 15-20 Uhr beschränkt werden, muss ein Zeitplan erstellt werden, in dem die Tage Mo, Di, Mi, Do und Fr ausgewählt werden, sowie die Startzeit 15 Uhr und die Endzeit 20 Uhr eingegeben wird.", //help190
	"SYN gesendet -- eins der Systeme versucht eine Verbindung zu starten.", //help819_2
	"Maximale Leerlaufzeit", //bwn_MIT
	"Geben Sie jeder Regel einen <strong>Namen</strong>, der für Sie sinnvoll ist.", //hhai_name
	"Email Log wenn VOLL oder auf dem Zeitplan", //te__title_EmLog
	"(GMT+05:30) Kalkutta, Chennai, Mumbai, Neu-Delhi", //up_tz_47
	"SMTP bei Sender-/Empfänger-Dialog fehlgeschlagen", //IPSMTPCLIENT_DIALOG_FAILED
	"Klicken Sie auf die <strong>Entfernen</strong> Taste, um die MAC-Adresse von der MAC-Filterungsliste zu entfernen.", //hham_del
	"Ist Ihr Internetdienstanbieter nicht aufgelistet oder Sie wissen nicht, wer es ist, wählen Sie den Internetverbindungstyp unten:", //wwa_msg_ispnot
	"Die Anzahl an Paketen, die beim Versenden fallengelassen wurden wegen Störungen, Kollisionen oder wegen begrenzten Ressourcen des Routers.", //help808
	"Herstellung einer PPTP-Verbindung wird versucht.", //PPTP_EVENT_TUNNEL_ESTABLISH_REQUEST
	"Unterstützt die Verwendung auf LAN-Computern des Microsoft Windows Messenger (der Internet-Messaging-Client, der zusammen mit Microsoft Windows ausgeliefert wird) und MSN Messenger. Das SIP ALG muss ebenfalls aktiviert werden, wenn das Windows Messenger ALG aktiviert ist.", //help37
	"Neustart für WCN wurde angefordert", //WCN_LOG_REBOOT
	"Der Versuch, eine PPTP-Verbindung herzustellen, ist fehlgeschlagen. Siehe Details zum Remote-PPTP-server.", //PPTP_EVENT_TUNNEL_CONNECT_FAIL
	"Kanalbreite", //bwl_CWM
	"(GMT-05:00) Eastern Time (USA/Kanada)", //up_tz_12
	"Abbrechen", //_cancel
	"ULA aktivieren", //IPV6_ULA_TEXT02
	"DMZ aktivieren", //af_ED
	"(GMT+03:00) Kuwait, Riad", //up_tz_38
	"DTIM-Intervall", //aw_DI
	"(GMT+02:00) Athen, Istanbul, Minsk", //up_tz_31
	"Klicken Sie auf das <strong>Löschen</strong> Symbol in der Regelliste, um eine Regel dauerhaft zu löschen.", //hhai_delete
	"Die &quot;Virtueller Server&quot;-Option erlaubt es Ihnen, einen einzelnen öffentlichen Port auf Ihrem Router zu einer internen LAN-IP-Adresse und einem privaten Port, wenn erforderlich, umzuleiten. Diese Funktion ist für das Bereitstellen von Online-Services wie FTP- oder Web-Server nützlich.", //av_intro_vs
	"Die Firewall-Einstellungen stellen eine erweiterte Funktion dar, mit der Sie den Datenverkehr durch das Gerät zulassen oder verweigern können. Das ist die gleiche Funktionsweise wie bei IP-Filtern mit zusätzlichen Einstellungen. Sie können detailliertere Regeln für das Gerät erstellen.", //av_intro_if
	"Es wird versucht, eine permanente WAN-Verbindung neu zu starten", //GW_WAN_RECONNECT_ALWAYS_ON
	"Wireless-Sicherheitskennwort", //wwl_WSP
	"Ein", //INGRESS
	"Eingeschränkt", //RESTRICTED
	"Benutzen Sie diesen Internet-Verbindungstyp, wenn Ihr Internet Service Unternehmen (ISP) Ihnen keine IP-Adressen Information und/oder einen Benutzernamen und ein Kennwort genannt hat.", //bwn_msg_DHCPDesc
	"Die Portnummer, die für den Anschluss des Authentifizierungsservers genutzt wird.", //help390
	"Die Aktivierung der L2 (Layer 2) Isolation verhindert, dass einander zugeordnete drahtlose Clients miteinander kommunizieren.", //KR58
	"Wiederholen Sie die Eingabe des Kennworts für das Konto.", //help867
	"Es wird versucht, eine permanente WAN-Verbindung zu starten", //GW_WAN_CONNECT_ALWAYS_ON
	"RTSP ALG lehnte Paket von %v:%u nach %v:%u mit ungeradem RTP Port %u ab", //IPRTSPALG_REJECTED_ODD_RTP_PACKET
	"Port Weiterleitungs-Einträge", //help60f
	"Counter Strike", //gw_gm_10
	"(Minuten, 0=unendlich)", //bwn_min
	"Monat", //tt_Month
	"Aktuelles Firmware-Datum", //tf_CFWD
	"Erweitertes Netzwerk", //_advnetwork
	"PPPOE Internet Verbindungstyp", //bwn_PPPOEICT
	"Radius Server-Port:", //help389
	"Wählen Sie diesen Zeitausgleich, wenn Ihr Standort Sommer-/Winterzeit beachtet.", //help844
	"4:00 PM", //tt_time_17
	"L2TP (Layer Two Tunneling Protocol) verwendet ein Virtuelles Privates Netzwerk zur Verbindung mit Ihrem ISP. Es benötigt die Eingabe von <span class='option'>Benutzername</span> und <span class='option'>Passwort</span> (von Ihrem Internetdienstanbieter zugewiesen), um die Internetverbindung herzustellen.", //help284
	"Drahtlossystem mit zugehöriger MAC-Adresse %m", //GW_WIRELESS_DEVICE_ASSOCIATED
	"Sekundäre MAC-Adressen Authentifizierung", //bws_2RMAA
	"SIP", //as_SIP
	"SysLog", //help704
	"Interner WPS-Registrar konnte keine neue Station hinzufügen. Ursache: %s", //WIFISC_IR_REGISTRATION_FAIL_1
	"(GMT) Greenwich Time: Dublin, Edinburgh, Lissabon, London", //up_tz_25
	"Ist die im obigen Beispiel angegebene Anwendungsregel aktiviert, öffnet der Router jedes Mal einen Portbereich von 6000 bis 6200 für eingehenden Datenverkehr vom Internet, wenn ein Computer im internen Netz eine Anwendung öffnet, die Daten unter Verwendung eines Ports im Bereich zwischen 6500 und 6700 in das Internet sendet.", //help55
	"Drahtlose Verbindung ist aktiv", //GW_WLAN_LINK_UP
	"DNS-Relay aktivieren", //bln_EnDNSRelay
	"Eingangsfilterregel", //ai_title_IFR
	"PPTP", //_PPTP
	"Beides", //_both
	"(GMT+03:00) Nairobi", //up_tz_40
	"Stecken Sie das USB-Kabel des Druckers aus und wieder ein.", //wprn_tt8
	"Soft Reset deaktivieren", //tps_dsr
	"Weitere", //at_Prot_1
	"Dies startet den Router neu. Das ist nützlich, wenn Sie sich nicht in der Nähe des Gerätes befinden.", //help875
	"Webseiten Filter-Einstellungen", //awsf_p
	"genau 5 oder 13 alphanumerischen Zeichen bestehen.", //wwl_s4_intro_z2
	"Um diesen Anschluß einzurichten, benötigen Sie einen Benutzernamen und ein Kennwort von Ihrem Internetdienstanbieter (ISP). Zusätzlich benötigen Sie L2TP IP-Adressen. Wenn Sie diesen nicht wissen oder diese Informationen nicht haben, fragen Sie bitte Ihre", //wwa_set_l2tp_msg
	"(GMT+04:00) Abu Dhabi, Muscat", //up_tz_42
	"Fehler", //_error
	"Ziel-IP d<br />Ende", //aa_FPR_c4
	"NTP-Server aktivieren", //tt_EnNTP
	"Ungültige LAN-IP-Adresse, IP-Adresse im DHCP-Server-Bereich", //network_dhcp_ip_in_server
	"Um die Firmware zu aktualisieren, muss Ihr PC eine kabelgebundene Verbindung zum Router haben. Geben Sie den Namen der Firmware-Datei ein und klicken Sie auf &quot;Upload&quot;.", //tf_msg_wired
	"Benutzername- und Kennwortverbindung einrichten (PPPoE)", //wwa_title_set_pppoe
	"Stellen Sie sicher, dass der Zeitplan eingestellt ist auf <code>Immer</code>", //help10
	"Die anderen Optionen sind für spezielle Umstände vorgesehen.", //bwl_CWM_h2
	"Online überprüfen", //help884
	"Neustart", //rb_Rebooting
	"Wartezeit -- Wartet für eine kurze Zeit bis eine Verbindung, welche sich in einem &quot;FIN Wait&quot; befindet, vollständig geschlossen ist.", //help819_6
	"9:00 AM", //tt_time_10
	"Diese Sektion zeigt die gegenwärtig definierten Ablaufregeln (Zeitpläne). Eine Regel kann durch Anklicken der Taste „Ändern/Edit“ geändert werden   bzw. gelöscht durch Drücken der Taste „Löschen“.", //help199
	"Ein Verbindungsverfahren, bei dem Ihr Internetdienstanbieter eine IP-Adresse zuweist, wenn der Router eine IP-Adresse vom Server des Internetdienstanbieters anfordert. Bei einigen Internetdienstanbietern ist es erforderlich, zunächst Einstellungsänderungen an den eigenen Geräten vorzunehmen, bevor der Router eine Verbindung zum Internet herstellen kann.", //help259
	"Application Level Gateway (ALG) Konfiguration", //af_algconfig
	"PPTP-Client.", //wwa_msg_pptp
	"Sekundäre RADIUS-Server IP-Adresse", //bws_2RIPA
	"Schritt 3: Festlegen des Geräts", //_aa_wiz_s4_title
	"Anmerkung: Sie müssen, falls notwendig, einen Service-Namen angeben. Wenn Sie diesen nicht wissen oder diese Informationen nicht haben, fragen Sie bitte Ihren ISP.", //wwa_note_svcn
	"Erkannte xDSL oder Frame Relay-Netz", //help85
	"Der Portfilter für den Internetzugriff hat ein Paket von %v:%u an %v:%u (Protokoll %u) abgelehnt.", //GW_INET_ACCESS_DROP_PORT_FILTER_WITH_PORT
	"BigPond-Status", //sd_BPSt
	"(GMT+06:00) Almaty", //up_tz_49
	"World of Warcraft", //gw_gm_62
	"BigPond abgemeldet", //BIGPOND_LOGGED_OUT
	"E-Mail-Benachrichtigung über neuere Firmware-Versionen", //tf_EmNew
	"Internetzugangsrichtlinie für MAC-Adresse %m kann nicht gesetzt werden", //GW_INET_ACCESS_INITIAL_MAC_FAIL
	"MAC-Adresse", //help303
	"Nicht in der Liste oder Weiß nicht", //wwa_selectisp_not
	"Blockiertes ausgehendes TCP Paket von %v:%u bis %v:%u mit unerwarteter Bestätigung %lu (erwartete %lu bis %lu)", //IPNAT_TCP_BLOCKED_EGRESS_BAD_ACK
	"Die Regel wird auf jeglichen Datenfluss angewendet, dessen LAN-seitige Port Nummer in dem hier festgelegten Bereich fällt.", //help94
	"Xbox Live", //gw_gm_70
	"ICMP-Paket von %v bis %v fallengelassen, da Paketheader nicht verarbeitbar", //IPNAT_ICMP_UNABLE_TO_HANDLE_HEADER
	"FTP", //_FTP
	"NAT Endpunkt Filterung", //_neft
	"Verwaltung", //ta_A12n
	"BigPond abgemeldet", //GW_BIGPOND_LOGOUT
	"Eine Anwendungsregel wird verwendet, um einzelne oder mehrere Ports auf Ihrem Router zu öffnen, wenn der Router erkennt, dass Daten auf einem \"Trigger\"-Port oder einem Portbereich ins Internet gesendet werden. Eine Anwendungsregel wird auf alle Computer in Ihrem internen Netzwerk angewendet.", //help46
	"Überprüfen Sie das Protokoll regelmäßig, um unautorisierte Netzwerknutzung aufzudecken.", //hhsl_intro
	"Hilfe zu den Tools", //help770
	"Um diese Verbindung einzurichten, benötigen Sie einen Benutzernamen und ein Kennwort von Ihrem Internetdienstanbieter. Sie benötigen zudem die PPTP-IP-Adresse. Wenn Sie diese Informationen nicht haben, kontaktieren Sie bitte Ihren Internetdienstanbieter.", //wwa_msg_set_pptp
	"DNS-Eintrag für Firmware-Aktualisierungsserver %s wurde nicht gefunden", //GW_FW_NOTIFY_FAILED_DNS
	"Rainbow Six: Raven Shield", //gw_gm_40
	"Der Router verwendet das IGMP Protokoll für leistungsfähige Multicast-Dienste -- Übertragung des identischen Inhalts, wie Multimedia, von einer Quelle zu einer Vielzahl von Empfängern.", //bln_IGMP_title_h
	"Benutzen Sie <strong>802.11d</strong> nur in Ländern, in denen es vorgeschrieben ist.", //hhaw_11d
	"Wenn nicht, klicken Sie auf Abbrechen und anschließend auf Einstellungen speichern.", //up_jt_2
	"Richtlinie %s wurde gestartet; Der Internetzugriff wurde für MAC-Adresse %m geändert auf: %s", //GW_INET_ACCESS_POLICY_START_MAC
	"Wählen Sie diese Option, wenn Ihre Internetverbindung einen Benutzernamen und ein Kennwort erfordert, um online zu gehen. Die meisten DSL-Modems verwenden diesen Verbindungstyp.", //wwa_msg_pppoe
	"Nehmen Sie an, dass Sie den DHCP Server so konfigurieren, dass Adressen von 192.168.0.100 bis 192.168.0.199 verwendet werden. Das heißt, dass 192.168.0.3 bis 192.168.0.99 und 192.168.0.200 bis 192.168.0.254 NICHT durch den DHCP Server verwendet werden. Computer oder Geräte, welche Adressen ausserhalb des DHCP Adressraums verwenden, müssen manuell mit ihrer IP-Adresse konfiguriert werden. (Sehen Sie<a href='#Static_DHCP'>Statische DHCP Client</a> unten).", //help323
	"Das 'admin'-Konto kann auf die Verwaltungsschnittstelle zugreifen. Der Administrator hat Lese-/Schreibzugriff und kann Kennwörter ändern.", //ta_intro1
	"3", //tt_week_3
	"DHCP-Server", //_dhcpsrv
	"Dynamische IP", //Dynamic_PPPoE
	"Aktivieren:", //help102
	"WINS/NetBIOS funktioniert aufgrund der Einstellungen für Ihre Internetverbindung in diesem Modus nicht.", //GW_DHCP_SERVER_WINS_MODE_INVALID
	"Ein-Bit in der Maske geben an, welche Bit der IP-Adresse übereinstimmen müssen.", //help107
	"WON Server", //gw_gm_69
	"Filterung", //aa_ACR_c5
	"Sie können jedem Rechner, dem eine reservierte IP-Adresse zugewiesen wurde, einen Namen zuordnen. Dadurch können Sie besser nachkontrollieren, welche Rechner auf diese Weise verwaltet werden.", //help345
	"Wählen Sie das <strong>Anwendungs- Name</strong> Pulldown-Menü für eine Liste der vorkonfigurierten Server Typen. Wenn Sie einen der vorkonfigurierten Server Typen auswählen, klicken Sie die Pfeiltaste beim Pulldown-Menü, um den entsprechenden Bereich zu markieren.", //hhav_name
	"Privater Port", //av_PriP
	"%Verlust", //tsc_pingt_msg103
	"Wenn Sie die UPnP Funktionalität verwenden wollen, können Sie sie hier aktivieren.", //help_upnp_2
	"Ungültiger WAN-Verbindungsmodus", //WAN_MODE_INCORRECT
	"Das WEP-Kennwort muss aus genau 5 alphanumerischen Zeichen bestehen.", //wwl_alert_pv5_2_5
	"Schritt 4: Festlegen der Filtermethode", //_aa_wiz_s5_title
	"Ungültige PIN-Nummer.", //KR22_ww
	"Erstellen Sie Regeln, um den Zugriff auf spezielle IP-Adressen und Ports zu verbieten.", //_aa_wiz_s7_help
	"L2TP-Sitzungserver hat das Senden von Sequenznummern für die lokale Sitzung 0x%04X gestoppt", //IPL2TP_SEQUENCING_DEACTIVATED
	"Erweiterte Druckerkonfiguration", //tps_apc
	"(GMT-06:00) Mexico City", //up_tz_09
	"Jul.", //tt_Jul
	"WAN-Schnittstelle ist ausgefallen", //GW_WAN_INTERFACE_DOWN
	"Drahtloseinstellungen wiederherstellen", //WCN_LOG_RESTORE
	"Everquest", //gw_gm_17
	"Internetzugang für IP-Adresse %v auf %s gesetzt", //GW_INET_ACCESS_INITIAL_IP
	"Möchten Sie alle Änderungen verwerfen, die Sie in diesem Assistenten vorgenommen haben?", //_wizquit
	"Im Abschnitt für Systemeinstellungen können Sie das Gerät neu starten oder die werkseitigen Einstellungen des Routers wiederherstellen. Wenn die Einheit auf die Werkseinstellungen zurückgesetzt wird, werden alle Einstellungen, einschließlich aller von Ihnen erstellten Regeln, gelöscht.", //tss_intro
	"Wenn Sie <span class='option'>DHCP-Server aktivieren</span> einstellen, werden die folgenden Optionen angezeigt.", //help318
	"Die SysLog-Option erlaubt es Ihnen, Log-Informationen zu einem SysLog Server zu senden.", //tsl_intro
	"3:00 AM", //tt_time_4
	"8:00 PM", //tt_time_21
	"Lokale L2TP-Sitzung 0x%04X verbunden", //IPL2TP_SESSION_CONNECTED
	"Fragmentierungsschwellenwert", //aw_FT
	"Speichern", //_save
	"Nicht geschätzt", //at_NEst
	"Wenn eine Anwendung auf der LAN-Seite über einen bestimmten Port verbunden ist, werden durch den NAT alle an den gleichen Port gerichteten eingehenden Verbindungsanfragen an diese Anwendung weitergeleitet. Der Ausgangspunkt der Anfragen spielt dabei keine Rolle. Bei dieser Option sind die Beschränkungen am geringsten. Die Verbindung ist am schnellsten, und einige Anwendungen (v. a. P2P-Anwendungen) funktionieren fast wie bei direkter Internetverbindung.", //af_EFT_h0
	"FIRMWARE", //_firmware
	"Rogue Spear", //gw_gm_43
	"Starten Sie WPS für das Wireless-Gerät, das Sie Ihrem Wireless-Netzwerk hinzufügen, innerhalb von", //wps_messgae1_1
	"Lokaler L2TP-Tunnel 0x%04X RTE-Modul wird heruntergefahren.", //IPL2TP_SHUTDOWN_STARTED
	"TX Pakete verworfen", //ss_TXPD
	"(GMT+08:00) Peking, Chongqing, Hongkong, Urumqi", //up_tz_55
	"Klicken Sie auf 'Weiter', wenn Sie den Router mithilfe eines Kennworts schützen und die Zeitzone einrichten möchten.", //wwa_intro_online2
	"Wählen Sie das von Ihrer Anwendung verwendete Protokoll für ausgehenden Datenverkehr (z. B. <code>Beide</code>).", //help50
	"Geben Sie die UDP-Ports ein, die geöffnet werden sollen (z. B. <code>6159-6180, 99</code>).", //help70
	"Das Aktivieren von WMM dient zur Kontrolle von Latenz und Störungen bei der Übertragung von Multimedia-Inhalten über eine drahtlose Verbindung.", //help188_wmm
	"DHCP Reservierung", //bd_title_SDC
	"(GMT+09:00) Osaka, Sapporo, Tokio", //up_tz_60
	"Ultima", //gw_gm_54
	"Optionaler Backup RADIUS-Server", //help396
	"Administratorabmeldung", //GW_ADMIN_LOGOUT
	"Serious Sam II", //gw_gm_44
	"UPnP aktivieren", //ta_EUPNP
	"Diese Option muss aktiviert werden, wenn Anwendungen auf dem LAN an einer Multicast Gruppe teilnehmen. Wenn Sie eine Multimedia LAN Anwendung haben, die den Inhalt nicht wie erwartet empfängt, versuchen Sie diese Option zu aktivieren.", //igmp_e_h
	"Zeigt die Anzahl der Pakete an, die vom Router gesendet wurden.", //help806
	"Zugriff NUR auf diese Websites SPERREN", //dlink_wf_op_0
	"Geben Sie den von Ihrer Anwendung verwendeten Portbereich für ausgehenden Datenverkehr ein (z. B. code>6500-6700</code>).", //help49
	"Beispiel:", //help367
	"Links", //gw_gm_28
	"Windows Me", //help337
	"Administratoreinstellungen", //ta_AdmSt
	"SysLog", //_syslog
	"(GMT-06:00) Central Time (USA/Kanada)", //up_tz_08
	"Wenn diese Option ausgewählt ist, muss sich der Benutzer immer vom gleichen Computer aus mit dem drahtlosen Netzwerk verbinden.", //help394
	"Schritt 5: Portfilter", //_aa_wiz_s7_title
	"Mit der Option \"Zeitkonfiguration\" können Sie die richtige Zeit der internen Systemuhr konfigurieren, aktualisieren und beibehalten. In diesem Abschnitt können Sie Ihre Zeitzone und den NTP-Server (Network Time Protocol = Netzwerkzeitprotokoll) einstellen. Auch die Sommerzeit kann konfiguriert werden, um die Zeit bei Bedarf anzupassen.", //tt_intro_Time
	"Fehler bei der Aktualisierung des dynamischen DNS: %s. Es wird später wieder versucht.", //GW_DYNDNS_SERROR
	"Automatische IPv6-Adresszuweisung aktivieren", //IPV6_TEXT105
	"Port", //sps_port
	"Egal ob SPI aktiviert wird oder nicht, verfolgt der Router immer den TCP Verbindungs-Status und stellt so sicher, dass die Markierungen jedes TCP- Paketes für den gegenwärtigen Zustand gelten.", //help164_2
	"Warten Sie, bis der Router neu gestartet wurde. Dieser Vorgang kann einige Minuten in Anspruch nehmen.", //help881
	"Ziel-IP", //_destip
	"Die Zeitkonfigurationsoption erlaubt Ihnen, auf der internen Systemuhr die korrekte Zeit zu konfigurieren, zu aktualisieren und beizubehalten. Von diesem Abschnitt können Sie die Zeitzone einstellen, in der Sie sich befinden und den NTP-Server (Network Time Protocol) einstellen. Sommer-/Winterzeit kann ebenfalls eingerichtet werden, um die Zeit automatisch einzustellen, wenn sie benötigt wird.", //help840
	"L2TP-Server-IP-Adresse (kann gleich dem Gateway sein)", //wwa_l2tp_svra
	"Termine für Sommerzeit", //tt_dsdates
	"Beachten Sie, dass L2TP VPN Verbindungen typischerweise IPSec verwenden, um die Verbindung zu sichern. Um mehrere gleichzeitige VPN Tunnel zu erreichen, muss dazu das IPSec ALG aktiviert werden.", //help34b
	"10:00 AM", //tt_time_11
	"Dynamisches DNS aktivieren", //td_EnDDNS
	"Die aktuelle Übertragungsrate des Clients in Megabits pro Sekunde.", //help786
	"Benutzername", //bwn_UN
	"Dieser Richtlinienname wird bereits verwendet.", //aa_alert_8
	"QoS-Engine aktivieren", //wprn_tt2
	"LCP legt Remote-Authentifizierung fest: %04x", //IPPPPLCP_SET_REMOTE_AUTH
	"Lokaler L2TP-Tunnel 0x%04X schwerer Zeitüberschreitungsfehler des RTE-Moduls – Remote-Server antwortet nicht.", //IPL2TP_FATAL_TIMEOUT
	"<strong>Nicht-UDP/TCP/ICMP LAN Verbindungen</strong> wird normalerweise aktiviert. Es erleichtert einzelne VPN Verbindungen zu einem entfernten Hostrechner.", //hhaf_ngss
	"Netzwerk-Einstellungen", //bln_title_NetSt
	"Protokoll-Typ", //av_traftype
	"PPTP (Benutzername/Kennwort)", //bwn_Mode_PPTP
	"Dieser Abschnitt zeigt die aktuellen Zugriffskontroll-Richtlinien. Regeln können durch Anklicken des Symbols Bearbeiten verändert werden, bzw. durch Anklicken des Symbols Löschen entfernt werden. Wenn Sie auf das Symbol Bearbeiten klicken, startet der Richtlinien Assistent und führt Sie durch den Vorgang um eine Richtlinie zu ändern. Sie können in der Liste eine bestimmte Richtlinie durch Anklicken des &quot;Aktivieren&quot; Kontrollkästchen aktivieren oder deaktivieren.", //help140
	"Ein erforderliches Druckerprotokoll ist deaktiviert", //wprn_rppd
	"Alle Ihre WAN- und LAN-Verbindungsdetails werden hier angezeigt.", //hhsd_intro
	"MS-CHAP-Authentifizierung erfolgreich", //IPMSCHAP_AUTH_SUCCESS
	"Angenommen Sie fungieren als Host eines Online-Game-Servers, der auf einem PC mit der privaten IP-Adresse 192.168.0.50 ausgeführt wird. Dieses Spiel erfordert es, dass Sie mehrere Ports (6159-6180, 99) auf dem Router öffnen, damit Benutzer im Internet eine Verbindung aufbauen können.", //help63
	"Stecken Sie das eine Ende des im Lieferumfang Ihres Routers enthaltenen Ethernet-Kabels in den mit INTERNET gekennzeichneten Port auf der Rückseite des Routers. Stecken Sie das andere Ende dieses Kabels in den Ethernet-Port Ihres Modems.", //ES_cable_lost_desc
	"Die neuen Einstellungen wurden übernommen.", //ap_intro_sv
	"L2TP-Subnetzmaske", //_L2TPsubnet
	"Senden der Protokoll-Email vor Neustart", //GW_LOG_EMAIL_BEFORE_REBOOT
	"Beliebig", //at_Any
	"Die folgenden Optionen treffen auf alle WAN Modi zu.", //help288
	"Wenn keiner dieser Verschlüsselungmethoden ausgewählt ist, können drahtlose Übertragungen zu und von Ihrem drahtlosen Netzwerk von nicht autorisierten Benutzern leicht abgefangen und gelesen werden.", //bws_SM_h1
	"Zusätzlich zu den hier aufgelisteten Filterregeln sind überall da, wo Inbound Filter angewendet werden können, zwei vordefinierte Filter möglich:", //help177
	"(GMT+05:00) Islamabad, Karatschi, Taschkent", //up_tz_46
	"Warten Sie bitte <span id ='show_sec'></span>&nbsp;Sekunden.", //rb_wait
	"Wireless Netzwerkname", //bwl_NN
	"Lokale L2TP-Sitzung 0x%04X Verbindungsversuch fehlgeschlagen", //IPL2TP_SESSION_CONNECT_FAIL
	"Final Fantasy XI (PS2)", //gw_gm_21
	"BESTE", //wwl_BEST
	"Unterstützung", //_support
	"Sie können neue IP-Adressen nicht hinzufügen. Sie können IP-Adressen nur von anderen Regeln übernehmen.", //aa_alert_14
	"Kabel-Status", //_cablestate
	"DHCP steht für Dynamic Host Configuration Protocol. Der DHCP-Bereich wird zum Einrichten des integrierten DHCP-Servers verwendet, um den Computern und anderen Geräten in Ihrem lokalen Netzwerk (LAN) IP-Adressen zuzuweisen.", //help314
	"Assistent zum Hinzufügen drahtloser Geräte MIT WPS (WI-FI PROTECTED SETUP)", //wps_LW13
	"Kritisch", //sl_Critical
	"Die neuen Einstellungen wurden gespeichert.", //sc_intro_sv
	"System-LOG inaktiv", //SYSTEM_LOG_INACTIVE
	"Meine Internet-Verbindung ist", //bwn_mici
	"Minuten", //gw_mins
	"Tritt am Router ein Stromausfall aus, so läuft auch die Routeruhr nicht weiter, und der Router verfügt beim Neustart nicht über die korrekte Zeit. Um die korrekte Zeit für Zeitpläne und Protokolle sicherzustellen, müssen Sie entweder nach Neustart des Routers die korrekte Zeit manuell eingeben, oder Sie müssen die Option NTP-Server aktivieren.", //help852
	"Ein", //_In
	"Wählen Sie diese Option, wenn Protokolle nach einem festen Zeitplan per E-Mail versendet werden sollen.", //help870
	"MSN Game Zone (DX)", //gw_gm_74
	"Firewall und Sicherheit", //help797
	"Rainbow Six", //gw_gm_39
	"Der WEP-Schlüssel muss genau 10 Hexadezimalzeichen (0-9 oder A-F) enthalten.", //wwl_alert_pv5_3_10
	"Der MAC-Adressenfilter kann zum Filtern von Netzwerkzugriffen von Rechnern verwendet werden, welcher auf der einzigartigen MAC-Adresse Ihrer Netzwerkkarte basiert.", //help149
	"Benutzen Sie diese Funktion, wenn Sie versuchen, eine der aufgeführten Netzwerk Anwendungen auszuführen und sie nicht wie erwartet arbeitet.", //hhpt_intro
	"WAN Schnittstellenkabel ist angeschlossen worden", //GW_WAN_CARRIER_DETECTED
	"BigPond-Benutzerkennung", //bwn_BPU
	"Wählen Sie diese Option, wenn dieser Zeitplan an dem/den ausgewählten Tag(en) den ganzen Tag über aktiv sein soll.", //help195
	"Der anfängliche Wert des 'Time Out' hängt vom Typ und Status der Verbindung ab.", //help823_1
	"Internet Verbindung", //_internetc
	"Anfrage aufgelöst zu", //tsc_pingt_msg5
	"Geben Sie für jeden weiteren AP, den Sie mit WDS verbinden möchten, eine MAC-Adresse ein.", //help189a
	"Auslöser", //_trigger
	"Die Ethernet-ID (MAC-Adresse) des Drahtlos-Clients.", //help783
	"Der Gateway wird nicht neu programmiert.", //ub_intro_2
	"Aus Sicherheitsgründen wird empfohlen das Passwort für die Nutzer ´admin´  zu ändern. Stellen Sie sicher, dass Sie sich an Ihre Passwörter erinnern.", //hhta_pw
	"Schritt 6: Konfiguration Webzugriff", //_aa_wiz_s8_title
	"Bei der Regel kann es sich entweder um Zulassen- oder um Verweigern-Meldungen handeln.", //help173
	"Statushilfe", //help771
	"SysLog-Server-IP-Adresse", //tsl_SLSIPA
	"Portfilterregel hinzufügen.", //_aa_wiz_s7_msg
	"12:00 PM", //tt_time_13
	"(GMT+10:00) Guam, Port Moresby", //up_tz_67
	"Primärer DNS-Server, Sekundärer DNS-Server", //help289a
	"BigPond angemeldet", //BIGPOND_LOGGED_IN
	"Wenn ein LAN Computer als DMZ Host konfiguriert wird, wird er zum Ziel für alle ankommenden Pakete, die keiner anderen ankommenden Session oder Regel entsprechen. Wenn eine beliebige Eingangsregel existiert wird immer diese angewendet, statt die Pakete zum DMZ Host zu senden; Deshalb haben aktive Sessions, Virtuelle Server, ein aktiver Portauslöser oder eine Portweiterleitungsregel immer höhere Priorität vor dem Senden eines Pakets zum DMZ Host. (Die DMZ-Regel ähnelt einer Standard-Portweiterleitungsregel, die jeden Port weiterleitet, der nicht anderweitig definiert ist.)", //haf_dmz_10
	"Status oder Zustand für Sitzungen, die das TCP-Protokoll verwenden.", //help819
	"Wenn der Fortschrittsbalken nicht erscheint, wurde die Setup-Datei nicht gestartet oder das Setup ist noch unvollständig. Beachten Sie unten den Abschnitt mit den tipps zum Troubleshooting.", //wprn_s3b
	"TCP-Port", //sps_tcpport
	"Folgende Website-Filter konfigurieren", //dlink_wf_intro
	"Webseiten-Filter", //_websfilter
	"BigPond-Servername", //sd_BPSN
	"Benutzer- Passwort", //_password_user
	"Richtlinie %s wurde angehalten; Der Internetzugriff wurde für IP-Adresse %v geändert auf: %s", //GW_INET_ACCESS_POLICY_END_IP
	"Wählen Sie den WAN-Modus aus, welcher von dem Router verwendet werden soll, um eine Verbindung zum Internet herzustellen.", //bwn_msg_Modes
	"Die IP-Adresse ' + mf.dmz_address.value + ' ist ungültig.", //up_gX_1
	"Weiter", //_next
	"Setup", //_setup
	"Der Rechner wird wiederholt versucht zu erreichen. Stop durch drücken dieser Taste.", //htsc_pingt_s
	"E-Mail", //EMAIL
	"Modus", //_mode
	"Feb.", //tt_Feb
	"Verwenden Sie diese Informationen, um Ihren Computer für RAW TCP Port drucken einzurichten.", //sps_raw1
	"Dynamischer DNS-Eintrag erfolgreich aktualisiert für %s", //GW_DYNDNS_SUCCESS
	"Port Forwarding ALG konnte die Sitzung für das TCP-Paket nicht von %v:%u auf %v:%u zuweisen", //IPPORTFORWARDALG_TCP_PACKET_ALLOC_FAILURE
	"IGMP Router hat die Gruppe %v wegen niedriger System-Reserven abgelehnt", //IGMP_ROUTER_LOW_RESOURCES
	"Die „Auto 20/40 MHz“ Option ist normalerweise am besten.", //bwl_CWM_h1
	"(GMT+04:00) Moskau, St. Petersburg, Wolgograd", //up_tz_39
	"Ermöglicht Geräten und Anwendungen mit VoIP (Voice over IP) über NAT zu kommunizieren. Einige VoIP-Anwendungen und –Geräte können NAT-Geräte erkennen und umgehen diese. Dieses ALG kann den Betrieb solcher Geräte behindern. Wenn Sie Probleme beim Aufbau von VoIP-Anrufen haben, versuchen Sie, das ALG auszuschalten.", //help40
	"Port-Weiterleitung", //_pf
	"UDP-Paket von %v bis %v fallengelassen, da Paketheader nicht verarbeitbar", //IPNAT_UDP_UNABLE_TO_HANDLE_HEADER
	"<warn>Die Gateway-IP-Adresse %v der Route stimmt mit der Adresse der verwendeten Schnittstelle überein und wird deaktviert.</warn>", //GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS_WARNING
	"Internetzugang für MAC-Adresse %sm auf %s gesetzt", //GW_INET_ACCESS_INITIAL_MAC
	"CHAP-Authentifizierung erfolgreich.", //IPPPPCHAP_AUTH_SUCCESS
	"Normalerweise läuft der Wireless-Transmitter mit einer Leistung von 100%. Unter bestimmten Umständen kann es jedoch erforderlich sein, spezifische Frequenzen auf einen kleineren Bereich zu beschränken. Durch Reduzieren der Funkleistung kann verhindert werden, dass Übertragungen über Ihr Firmen-/Hausnetz oder dem bestimmten Funkbereich hinausreichen.", //help187
	"Alle Zugriffe verweigern", //_aa_block_all
	"Drahtlose Verbindung ist ausgefallen", //GW_WLAN_LINK_DOWN
	"Die Länge der Zeit, bevor der Gruppenschlüssel, der für Broadcast- und Multicast-Daten verwendet wird, geändert wird.", //help379
	"(GMT+11:00) Salomoninseln, Neukaledonien", //up_tz_70
	"Blockierte ankommende ICMP Fehlermeldung (ICMP Typ %u) von %v nach %v, da es keine ICMP Session gibt, die  zwischen %v und %v aktiv ist", //IPNAT_ICMP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"Zeitplan", //GW_SCHEDULES_IN_USE_INVALID_s1
	"Diese Seite befindet sich nicht in der Liste erlaubten Websites des Routers.", //fb_p_2
	"Druckerstatus", //sps_ps
	"Sie müssen Ihren Router konfigurieren, um es einer Software-Anwendung auf einem beliebigen Computer in Ihrem Netz zu ermöglichen, eine Verbindung mit einem Web-basierten Server oder anderen Benutzer im Internet herzustellen.", //help47
	"Schritt 4: Einstellungen speichern und verbinden", //wwa_title_s4
	"5:00 PM", //tt_time_18
	"Wenn diese Option aktiviert ist, können Router-Aktivitäten, -Logs oder Benachrichtigungen über Firmware-Aktualisierungen einer bestimmten Email-Adresse zugesendet werden und die folgenden Parameter werden angezeigt.", //help860
	"Gelöschter UpnP-Eintrag %v <-> %v:%d <-> %v%d %s '%s' (vom Client freigegebene Adresse)", //GW_UPNP_IGD_PORTMAP_RELEASE
	"Der Setup-Assistent für die Internetverbindung ist beendet. Klicken Sie auf 'Speichern', um Ihre Einstellungen zu speichern und den Router neu zu starten.", //wwa_intro_s4
	"Einige ISP's verlangen, daß Sie einen Service-Namen eintragen. Tragen Sie nur dann einen Service-Namen ein, wenn Ihr ISP es verlangt.", //help267
	"Lokale L2TP-Sitzung 0x%04X abgebrochen", //IPL2TP_SESSION_ABORTED
	"Diese Einstellungen erlauben die Veränderung der Router Konfiguration, ein Neustarten und Rücksetzen auf Werkseinstellungen des Routers. Das Rücksetzen löscht alle bisherigen Einstellungen, einschließlich definierter Regeln und Filter.", //help874
	"Sep.", //tt_Sep
	"ESP-Paket von %v bis %v fallengelassen, da Paketheader nicht verarbeitbar", //IPSEC_ALG_ESP_UNABLE_TO_HANDLE_HEADER
	"Gruppenschlüssel Aktualisierungsintervall", //bws_GKUI
	"Ermöglicht dem Router, bestimmte Audio- und Video-Streams, die von einem Windows Media Center-PC generiert wurden, zu erkennen und diesen Priorität über anderen Datenverkehr zu verleihen. Derartige Streams werden von Systemen verwendet, die als Windows Media Extenders bekannt sind, z. B. die Xbox 360.", //help80b
	"In diesen Fällen können Sie Eingangs-Filter benutzen, um das Risiko zu begrenzen, indem Sie die IP-Adressen der Internet-Hosts angeben, denen Sie den Zugriff auf Ihr LAN über diese Ports erlauben. Sie könnten z.B. den Zugriff zu einem Game Server in Ihrem LAN nur für Computer der Freunde erlauben, die Sie zum Spielen eingeladen haben.", //help168c
	"BigPond wird angemeldet", //BIGPOND_LOGGING_IN
	"Benutzername- / Kennwortverbindung (PPTP)", //wwa_wanmode_pptp
	"Bereich (50-100)", //help58
	"Verbunden", //ddns_connected
	"Hochladen fehlgeschlagen", //ub_Upload_Failed
	"Ende von WPS für STA mit MAC (%m) mit der Nachricht: %s", //WIFISC_AP_PROXY_END_ON_MSG
	"PPTP (Point to Point Tunneling Protocol) verwendet ein Virtuelles Privates Netzwerk zur Verbindung mit Ihrem ISP. Diese Verbindungsart wird hauptsächlich in Österreich verwendet. Sie benötigt die Eingabe von <span class='option'>Benutzername</span> und <span class='option'>Passwort</span> (von Ihrem Internetdienstanbieter zugewiesen), um die Internetverbindung herzustellen.", //help278
	"Geben Sie einen aus 8 bis 63 Zeichen bestehende Passphrase (Kennsatz oder Kennwortsatz) ein. Zur Gewährleistung höchster Sicherheit sollte dieser ausreichend lang sein und kein allgemein bekannter oder gebräuchlicher Ausdruck oder Satz sein.", //KR18
	"Ein System Logger (Syslog) ist ein Server, der in einem Ort die Protokolle von den unterschiedlichen Quellen sammelt. Wenn Sie in Ihrem Netzwerk einen Syslog Server haben, können Sie diese Option verwenden, um die Routerprotokolle zu diesem Server zu senden.", //hhts_def
	"Zu verwenden, wenn Ihr ISP Ihnen eine IP-Adresse zuweist, die sich nicht ändert. Die IP-Informationen sind manuell in Ihre IP-Konfigurationseinstellung einzutragen. Eingeben müssen Sie die", //help255
	"Sekundärer RADIUS-Server Port", //bws_2RSP
	"Geben Sie den privaten Port als [80] ein", //help7
	"Sichtbar", //bwl_VS_0
	"TCP Endpunkt Filterung", //af_TEFT
	"Wenn für den <span class='option'>Verbindungstypen</span> <span class='option'>Automatische Erkennung</span> angegeben wurde, wird hier der automatisch erkannte Verbindungstyp angezeigt.", //help86
	"Netzwerkname (SSID)", //sd_NNSSID
	"Das Zugreifen auf diese Webseite kann sich negativ auf die Prüfung auswirken.", //wt_p_2
	"Gateway", //_gateway
	"Aktuelle Router Zeit", //tt_CurTime
	"Vormittags", //_AM
	"Verbindung getrennt", //DISCONNECTED
	"Soldier of Fortune", //gw_gm_47
	"(GMT-01:00) Azoren", //up_tz_22
	"Interner WPS-Registrar hat eine Sitzungsüberschneidung zwischen %m und %m erkannt", //WIFISC_IR_REGISTRATION_SESSION_OVERLAP
	"Die beiden Admin-Kennwörter müssen übereinstimmen. Geben Sie sie noch einmal ein.", //_pwsame_admin
	"WAN-IP geändert auf %v, DynDNS-Dienstanbieter wird aktualisiert", //GW_DYNDNS_UPDATE_IP
	"Einem Netzwerkcomputer (%s) wurde die IP-Adresse von %v zugewiesen.", //GW_DHCPSERVER_NEW_ASSIGNMENT
	"Windows/MSN Messenger", //as_WM
	"(GMT-09:00) Alaska", //up_tz_03
	"Bitte geben Sie die PIN Ihres drahtlosen Geräts ein und klicken Sie dann unten auf die Schaltfläche 'Verbinden'.", //KR43
	"Kennwörter stimmen nicht überein; bitte erneut eingeben", //YM177
	"Je nach Typ der WAN-Verbindung können Sie wie folgt vorgehen:", //help774
	"Wählen Sie <strong>Bearbeiten</strong> aus, um eine vorhandene Regel mit dem Regel-Assistenten zu ändern.", //hhac_edit
	"(GMT+02:00) Jerusalem", //up_tz_36
	"Hostname", //_hostname
	"Initialisierung der Internet-Zugriffskontrolle fehlgeschlagen", //GW_INET_ACCESS_INITIAL_FAIL
	"Web-Filter Initialisierung fehlgeschlagen", //GW_WEB_FILTER_INITIAL_FAIL
	"Wenn Protokoll voll", //te_OnFull
	"Schritt 3: Legen Sie das Kennwort für Ihr drahtloses Netzwerk fest", //wwl_title_s4
	"Wiedereinwahlmodus:", //help281
	"GameSpy Tunnel", //gw_gm_77
	"MAC-Adresse Ihres PC klonen", //_clonemac
	"Dies ist die Zusammenfassung aller Datenpakete, die seit der letzten Initialisierung des Routers zwischen dem WAN und LAN gesendet wurden.", //hhss_intro
	"Gemessene Uplink-Geschwindigkeit", //at_MUS
	"Die WAN Geschwindigkeit wird normalerweise automatisch erkannt. Wenn Sie Probleme mit der WAN-Verbindung haben, versuchen Sie die Geschwindigkeit manuell einzustellen.", //hhan_wans
	"Aktivieren Sie diese Option, wenn Sie eine Bevorzugung Ihres drahtlosen Datenverkehrs durch WISH zulassen möchten.", //YM141
	"Der Schlüssel wird als Pass-Phrase von bis zu 63 alphanumerischen Zeichen im ASCII-Format (American Standard Code for Information Interchange) an beiden Enden der drahtlosen Verbindung eingetragen. Er darf nicht kürzer als 8 Zeichen sein. Für eine angemessene Sicherheit sollte er von ausreichender Länge und kein allgemein bekannter Ausdruck sein. Dieser Ausdruck wird verwendet, um Sitzungsschlüssel zu erzeugen, die für jeden Wireless-Klienten einzigartig sind.", //help382
	"(Stunde:Minute, 12-Stunden-Format)", //tsc_hrmin
	"(Stunde:Minute, 24-Stunden-Format)", //tsc_hrmin1
	"Dies ist die gemessene Uplink-Geschwindigkeit, als die WAN-Schnittstelle zuletzt neu aufgebaut wurde. Der Wert kann niedriger als von Ihrem Internetdienstanbieter angegeben sein, weil er nicht alle Netzwerkprotokoll-Overheads miteinbezieht, wie sie mit dem Netzwerk Ihres Internetdienstanbieters assoziiert sind. Diese Zahl liegt in der Regel zwischen 87 % und 91 % der angegebenen Uplink-Geschwindigkeit für xDSL-Verbindungen und sind etwa 5 KB/s niedriger für kabelgebundene Netzwerkverbindungen.", //help82
	"Heretic II", //gw_gm_24
	"Delta Force", //gw_gm_13
	"RTS-Schwellenwert", //aw_RT
	"Windows XP", //help340
	"WLAN", //sd_WLAN
	"Wählen Sie diese Option, wenn Ihr SMTP-Server Authentifizierung erfordert.", //help864
	"Möglicherweise steht eine neue Firmware bereit für den", //tf_intro_FWU1
	"Nicht unterstütztes Betriebssystem", //wprn_bados
	"Metrik", //_metric
	"Eingehender Filter", //INBOUND_FILTER
	"Eingehendes UDP-Paket von %v%u nach %v%u gesperrt", //IPNAT_UDP_BLOCKED_INGRESS
	"Diese Option schaltet den drahtlosen Anschluss des Routers ein und aus. Wenn Sie diese Option einschalten, sind die folgenden Einstellungen in Kraft.", //help351
	"Mit dieser Option können Sie einen eigenen Schlüssel erstellen.", //wwz_manual_key2
	"PPTP-Subnetzmaske", //_PPTPsubnet
	"Der Port, der in Ihrem internen Netzwerk verwendet werden soll.", //help20
	"Schwarz und Weiß", //gw_gm_6
	"WPA-Modus", //bws_WPAM
	"GUT", //wwl_GOOD
	"Postal 2: Share the Pain", //gw_gm_36
	"Geben Sie den vollständigen Namen Ihres Servers ein, z.B.: <code>myhost.mydomain.net</code>", //help894
	"Subnetzmaske", //_subnet
	"Das PPTP-Übertragungsfenster beträgt %u.", //PPTP_EVENT_REMOTE_WINDOW_SIZE
	"Schritt 1: Wählen Sie die Konfigurationsmethode für Ihr drahtloses Netzwerk.", //wps_KR35
	"Die <code> Reservierungs </code> Option wandelt diese dynamische IP Zuordnung in eine DHCP Reservierung um und fügt den entsprechenden Eintrag zu der DHCP Adressliste hinzu.", //help329_rsv
	"Vietcong", //gw_gm_58
	"Aufrufen des WAN über %s", //GW_WAN_MODE_IS
	"In diesem Abschnitt konfigurieren Sie die internen Netzwerkeinstellungen Ihres AP und richten den integrierten DHCP-Server so ein, dass er den Computern im Netzwerk IP-Adressen zuweist. Die hier konfigurierte IP-Adresse wird auch für den Zugriff auf die webbasierte Verwaltungsschnittstelle genutzt. Wenn Sie die IP-Adresse hier ändern, müssen Sie Ihre PC-Netzwerkeinstellungen möglicherweise anpassen, um wieder auf das Netzwerk zugreifen zu können.", //ns_intro_
	"DNS Relais ALG lehnte Paket von %v:%u nach %v:%u ab", //IPDNSRELAYALG_REJECTED_PACKET
	"Datenverkehrstatistiken zeigen empfangene und übertragene Datenpakete an, die Ihren Router passieren.", //ss_intro
	"Sie sollten diese Hinweise gründlich lesen, da einige Funktionen deaktiviert sein könnten.", //KR112
	"<warn>Nicht alle Geräte sind in der Lage,  auf den Kanälen 100-140 betrieben zu werden. Bitte wechseln Sie den Kanal, sollte sich das von Ihnen eingesetze Gerät nicht verbinden.</warn>", //GW_WLAN_11A_CH_MID_BAND_WARN
	"Anti-ARP-Angriff aktivieren", //ip_mac_binding_desc
	"Das Aktivieren dieser Option (Standardeinstellung) aktiviert Single-VPN-Verbindungen zu einem Remote-Host. (Bei mehreren VPN-Verbindungen muss jedoch das korrekte VPN-ALG verwendet werden.) Die Deaktivierung dieser Option deaktiviert jedoch VPN nur dann, wenn das passende VPN-ALG auch deaktiviert ist.", //LW50
	"Die Regel %s verursacht einen Konflikt mit einer bestehenden Verbindung (%v:%u (public %v:%u)--->%v:%u). Es kann zu Problemen mit dieser Regel kommen solange diese Verbindung besteht.", //GW_NAT_CONFLICTING_CONNECTIONS_LOG
	"Die Änderung der bestehenden Konfiguration hat zu Warnhinweisen geführt.", //KR111
	"Log Einträge", //KR109
	"<warn>Die Regel %s verursacht einen Konflikt mit einer bestehenden Verbindung (%v:%u (public %v:%u)--->%v:%u). Es kann zu Problemen mit dieser Regel kommen, solange diese Verbindung besteht.</warn>", //GW_NAT_CONFLICTING_CONNECTIONS_WARNING
	"HNAP SetAccessPointMode %s gibt %s, %s zurück", //GW_PURE_SETACCESSPOINTMODE
	"Das blockierte Packet von %v zu %v wurde von einem falschen Netzwerk-Interface erhalten (IP Adress Spoofing)", //GW_NAT_REJECTED_SPOOFED_PACKET
	"Nachricht", //KR110
	"<warn>Die Gateway IP %v gehört nicht zum Subnetz (%v/%v) und wird deaktiviert.</warn>", //GW_ROUTES_ROUTE_GATEWAY_NOT_IN_SUBNET_WARNING
	"Wenn diese Option aktiviert ist, wird der ausgehende Datenverkehr eingeschränkt, so dass der ausgehende Datenverkehr nicht die maximal mögliche Uplink-Bandbreite überschreitet.", //KR107
	"Anti-Spoofing Überprüfung", //KR105
	"Blockiertes Paket von %v bis %v (LAND Attack)", //IPSTACK_REJECTED_LAND_ATTACK
	"WEP", //LS321
	"Protokoll-E-Mails", //KR67
	"Letzter Ziel-Port sollte zwischen 0 und 65535 einschließlich liegen.", //YM71
	"Der Quell-IP-Bereich '%v-%v' wurde dupliziert.", //GW_FIREWALL_RANGE_DUPLICATED_INVALID
	"Hardware-Adresse", //LS422
	"Verwenden Sie Windows Connect Now", //bwz_LWCNWz
	"Ungültige WAN-Gateway-IP-Adresse: %v", //GW_WAN_WAN_GATEWAY_IP_ADDRESS_INVALID
	"Konfiguration im Setup-Assistenten für drahtlose Netzwerke speichern", //ta_wcn
	"Eine PIN ist eine einzigartige Zahl, die verwendet werden kann, um den Router einem vorhandenen Netzwerk hinzuzufügen oder um ein neues Netzwerk zu erstellen. Die Standard-PIN ist möglicherweise auf der Unterseite des Routers aufgedruckt. Für mehr Sicherheit kann eine neue PIN generiert werden. Sie können die Standard-PIN jederzeit wiederherstellen. Nur der Administrator ('Admin'-Konto) kann die PIN ändern oder zurücksetzen.", //LW57
	"WEP-Schlüssel 2", //_wepkey2
	"Hop", //tsc_pingt_msg109
	"NetBIOS-Knotentyp", //bd_NETBIOS_REG_TYPE
	"Drücken Sie die Taste (bzw. Schaltfläche) auf dem drahtlosen Gerät, das Sie Ihrem drahtlosen Netzwerk hinzufügen möchten, innerhalb von", //wps_messgae1_2
	"Erstellen Sie eine zufällige Nummer, die eine gültige PIN ist. Dies wird die PIN des Routers. Sie können dann diese PIN in die Benutzeroberfläche des Registrators kopieren.", //LW60
	"Wiederherstellung fehlgeschlagen", //_rs_failed
	"Wählen Sie diese Option aus, wenn das Gerät mit einem lokalen Netzwerk-Downstream von einem anderen Router verbunden ist. In diesem Modus dient das Gerät als eine Brücke zwischen dem Netzwerk an seinem WAN-Port und den Geräten an seinem LAN-Port sowie denjenigen, die drahtlos damit verbunden sind.", //KR62
	"Das Feld 'PIN des drahtlosen Geräts' darf nicht leer sein.", //KR20
	"Um eine bestmögliche Leistung zu erhalten, verwenden Sie die Option 'Automatische Klassifizierung'. So werden Ihren Anwendungen automatisch Prioritäten zugeteilt.", //at_intro_2
	"NetBIOS-Weitermeldung", //bd_NETBIOS_ENABLE
	"Die Subnetzmaske des lokalen Netzwerks.", //KR77
	"Super G mit dynamischem Turbo", //help364
	"Shopping", //_aa_bsecure_shopping
	"Öffentliche Proxy-Server", //_aa_bsecure_public_proxies
	"WEP-Schlüssel 1", //wepkey1
	"Versand-/Empfangsberechtigung", //ZM11
	"Startzeit", //tsc_start_time
	"Der letzte Quell-Port sollte zwischen 0 und 65535 einschließlich liegen.", //YM69
	"Wenn die NetBIOS-Anzeige aktiviert ist, sorgt die Aktivierung dieser Einstellung dafür, dass WINS-Informationen (sofern verfügbar) von der WAN-Seite abgerufen werden können.", //KR82
	"Die Statistik kann nur vom Administrator gelöscht werden. Die Schaltfläche 'Statistik löschen' ist deaktiviert, da Sie momentan nicht als Administrator angemeldet sind.", //ss_intro_user
	"Der Zeitplanname '%s' ist reserviert und kann nicht verwendet werden.", //GW_SCHEDULES_NAME_RESERVED_INVALID
	"Drahtlose Station hinzufügen", //LW12
	"Windows Media Center", //YM75
	"Route-Gateway-IP %v ist ungültig", //GW_ROUTES_GATEWAY_IP_ADDRESS_INVALID
	"Das Aktualisierungsintervall für WPA-Gruppenschlüssel muss zwischen 30 und 65535 Sekunden liegen.", //GW_WLAN_WPA_REKEY_TIME_INVALID
	"WEP ist der Verschlüsselungsstandard für drahtlose Verbindungen. Um diese Verschlüsselung zu verwenden, müssen Sie denselben bzw. dieselben Schlüssel für den Router und die drahtlosen Stationen angeben. Für Schlüssel mit einer Länge von 64 Bit müssen in jedes Feld 10 Hexadezimalzeichen eingegeben werden. Für Schlüssel mit einer Länge von 128 Bit müssen in jedes Feld 26 Hexadezimalzeichen eingegeben werden. Eine Hexadezimalzahlstelle ist entweder eine Zahl zwischen 0 und 9 oder ein Buchstabe von A bis F. Die größtmögliche Sicherheit mit WEP erhalten Sie, wenn Sie den Authentifizierungstyp 'Gemeinsamer Schlüssel' wählen.", //bws_msg_WEP_1
	"Eine weitere Möglichkeit zur Sicherung Ihres Netzwerks besteht darin, den verborgenen Modus zu aktivieren. Wenn diese Option aktiviert ist, können drahtlose Clients, die nach verfügbaren Netzwerken suchen, Ihr verborgenes Netzwerk nicht erkennen. Um die drahtlosen Geräte mit Ihrem Router zu verbinden, müssen Sie den Namen des Netzwerks für jedes Gerät manuell eingeben.", //YM125
	"Glücksspiele", //_aa_bsecure_gambling
	"Bridge-Modus", //KR14
	"Die angegebene Absender-Adresse (%s) ist ungültig", //GW_SMTP_FROM_ADDRESS_INVALID
	"Gibt an, wie Netzwerk-Hosts die NetBIOS-Namensregistrierung und -erkennung ausführen sollen.", //KR89
	"Netzmaske:", //help106
	"Wählen Sie bei der Konfiguration des Routers für den Internetzugang im Dropdown-Menü den richtigen <strong>Internet-verbindungstyp</strong>. Wenn Sie unsicher sind, welche Option Sie wählen sollen, wenden Sie sich an Ihren <strong>Internet-Diensteanbieter</strong>.", //LW35
	"Sprache (besonders dringlich).", //YM151
	"Ihre Änderungen wurden gespeichert. Damit die neuen Einstellungen übernommen werden können, müssen Sie den Router neu starten. Sie können jetzt einen Neustart durchführen oder weitere Änderungen vornehmen und den Neustart später durchführen.", //YM2
	"Hinweis: Mögliche Einschränkungen bezüglich dieser Funktion finden Sie in <a href='../Help/Tools.shtml#wcn' onclick='return jump_if();' style='white-space: nowrap;'>Hilfe -&gt; Extras</a>.", //ta_wcn_note
	"Die Routerkonfiguration wurde während der Ausführung des Assistenten durch etwas anderes geändert.\nDer Assistent wird abgebrochen; bitte versuchen Sie es erneut.", //YM131
	"HTTP und HTTPS können nicht den gleichen LAN-Port belegen.", //GW_WEB_SERVER_SAME_PORT_LAN
	"Sitzungstimeout", //KR25
	"Jetzt neu starten", //YM3
	"<warn>Der Wake-On-LAN-ALG wurde automatisch aktiviert, da ein von Ihnen erstellter virtueller Servereintrag dies benötigt.</warn>", //GW_NAT_WOL_ALG_ACTIVATED_WARNING
	"Ungültiger Ziel-IP-Bereich für den Portfilter", //YM20
	"Aktivieren Sie diese Option, wenn Sie eine Bevorzugung Ihres drahtlosen Datenverkehrs durch WISH zulassen möchten.", //YM86
	"Ungültige WAN MAC-Adresse %m", //GW_WAN_MAC_ADDRESS_INVALID
	"das Format der Empfänger-E-Mail-Adresse ist falsch", //IPSMTPCLIENT_MSG_WRONG_RECEPIENT_ADDR_FORMAT
	"WISH unterstützt Überlagerungen zwischen Regeln. Wenn mehr als eine Regel einem bestimmten Nachrichtenfluss entspricht, wird die Regel mit der höchsten Priorität verwendet.", //YM146
	"Wichtige Konfigurationshinweise", //LS151
	"Der Name darf keine leere Zeichenfolge sein.", //GW_QOS_RULES_NAME_INVALID
	"'%s' [protocol:%d]->%v steht in Konflikt mit '%s' [protocol:%d]->%v.", //GW_NAT_VS_PROTO_CONFLICT_INVALID
	"Der Name darf keine leere Zeichenfolge sein.", //GW_WISH_RULES_NAME_INVALID
	"Das Hinzufügen der drahtlosen Station %s ist fehlgeschlagen; Grund: %s, err_code %u", //WIFISC_IR_REGISTRATION_FAIL
	"ROUTEN-LISTE", //r_rlist
	"Geben Sie eine spezifische DNS-Serveradresse ein.", //IPV6_TEXT109
	"128 Bit (26 Hexadezimalzahlen)", //bws_WKL_1
	"Organisiert Informationen in einer Form, in der diese einfach verwaltet, aktualisiert sowie von Benutzern oder Anwendungen abgerufen werden können.", //help473
	"Zusätzliche Sicherheit in Drahtlosnetzen", //aw_erpe
	"Die Portbereiche dürfen nicht beide leer sein.", //GW_NAT_PORT_FORWARD_RANGE_BOTH_EMPTY_INVALID
	"Die Routen-Gateway-IP %v liegt nicht im Schnittstellen-Subnetz.", //GW_ROUTES_GATEWAY_IP_ADDRESS_IN_SUBNET_INVALID
	"Drahtlosassistent", //LW37
	"Diese Funktion ist deaktiviert, wenn Sie als Benutzer angemeldet sind.", //tsc_pingdisallowed
	"Um die Einstellungen zu speichern, klicken Sie auf die Schaltfläche <strong>Konfiguration speichern</strong>.", //ZM20
	"Verschlüsselungstyp:", //help376
	"E-Mail-Benachrichtigung' ist auf der Seite 'Extras' -> 'E-Mail-Einstellungen' nicht aktiviert, aber 'E-Mail-Benachrichtigung bei neuer Firmware-Version' ist unter 'Extras' -> 'Firmware' aktiviert.", //GW_FW_NOTIFY_EMAIL_DISABLED_INVALID
	"Ungültiger WEP-Schlüssel", //YM122
	"DMZ-Adresse %v darf nicht der LAN-IP-Adresse entsprechen.", //GW_NAT_DMZ_CONFLICT_WITH_LAN_IP_INVALID
	"Falsch konfiguriert - Protokolle prüfen", //_sdi_s7
	"QoS-Engine-Setup", //at_title_SESet
	"Der Anfangsport muss niedriger sein als der Endport: %d-%d.", //GW_INET_ACL_START_PORT_INVALID
	"Senden der E-Mail-Daten fehlgeschlagen", //IPSMTPCLIENT_DATA_FAILED
	"M-Knoten (Standard); gibt einen gemischten Betriebsmodus an. Die erste Broadcast-Aktion wird zum Registrieren von Hosts und Erkennen anderer Hosts ausgeführt; wenn die Broadcast-Aktion fehlschlägt, werden bei Bedarf WINS-Server getestet. Dieser Modus favorisiert Broadcast-Aktionen, die bevorzugt werden können, wenn WINS-Server über eine langsame Netzwerkverknüpfung erreichbar sind und die Mehrzahl der Netzwerkdienste wie Dienst und Drucker im LAN lokal sind.", //KR91
	"Betriebsfrequenzband. Wählen Sie 2,4 GHz für die Sichtbarkeit von Altgeräten und für eine größere Abdeckung. Wählen Sie 5 GHz für weniger Interferenzen. Diese können die Leistung beeinträchtigen.", //KR971
	"Auf Werkseinstellungen zurücksetzen", //tss_RestAll_b
	"%s von '%s' [%s:%s]->%s steht im Konflikt mit '%s' [%s:%s]->%s.", //GW_NAT_PORT_TRIGGER_CONFLICT_INVALID
	"Fragmentierung tritt auf, wenn die Rahmengröße in Bytes größer als die Fragmentierungsschwelle ist.", //LW54
	"Wenn sich in Ihrem Netzwerk bereits ein DHCP-Server befindet oder Sie für alle Geräte im Netzwerk statische IP-Adressen verwenden, deaktivieren Sie das Kontrollkästchen für die Option <strong>DHCP-Server aktivieren </strong>.", //TA7
	"Die IP-Adresse dieses Geräts im lokalen Netzwerk.", //KR74
	"Standard-WEP-Schlüssel", //bws_DFWK
	"Wenn Sie mit der drahtlosen Netzwerk- und Routerkonfiguration noch nicht vertraut sind, klicken Sie auf <strong>Drahtlosnetzwerkinstallations-Assistent</strong>. Mit Hilfe des Assistenten können Sie Schritt für Schritt Ihr drahtloses Netzwerk auf einfache Weise betriebsbereit machen.", //LW46
	"SMTP (E-Mail)-Server %s liegt auf  der IP-Adresse %v", //IPSMTPCLIENT_RESOLVED_DNS
	"Schnittstelle", //help110
	"Ungültige PPTP-Gateway-IP-Adresse", //YM107
	"Der Timeout-Wert darf nicht größer als 8760 sein.", //YM180
	"Ungültige WAN-Subnetzmaske %v", //GW_WAN_WAN_SUBNET_INVALID
	"<warn>DMZ ist deaktiviert, weil das LAN-Subnetz geändert wurde.</warn>", //GW_NAT_DMZ_DISABLED_WARNING
	"Möchten Sie den DHCP-Reservierungseintrag für die IP-Adresse wirklich deaktivieren", //YM93
	"<warn>Der FTP-ALG wurde automatisch aktiviert, da ein von Ihnen erstellter virtueller Servereintrag dies benötigt.</warn>", //GW_NAT_FTP_ALG_ACTIVATED_WARNING
	"Freier Host", //_aa_bsecure_free_host
	"Ungültige Netzwerkmaske für Route", //_r_alert2
	"Ungültige MAC-Adresse", //LS47
	"LAN-Subnetzmaske lässt dem DHCP-Server keine Adressen zur Nutzung übrig.", //GW_DHCP_SERVER_SUBNET_SIZE_INVALID
	"Sie können keine neue MAC-Adresse %m hinzufügen. Sie können nur MAC-Adressen anderer Richtlinien wiederverwenden.", //GW_INET_ACCESS_POLICY_TOO_MANY_MAC_INVALID
	"Die Anfangs-IP-Adresse muss niedriger als die End-IP-Adresse sein: %v-%v", //GW_FIREWALL_START_IP_ADDRESS_INVALID
	"Sekunden.", //YM8
	"'%s': Priorität, %u, muss zwischen 0 und 7 liegen", //GW_WISH_RULES_PRIORITY_RANGE
	"Routenkosten", //_aa_bsecure_travel
	"Die Routenmetrik ist ein Wert zwischen 1 und 16, der die Kosten der Verwendung dieser Route angibt. Ein Wert von 1 steht für die niedrigsten Kosten, 15 für die höchsten Kosten. Der Wert 16 gibt an, dass die Route über diesen Router nicht erreichbar ist. Wenn versucht wird, ein bestimmtes Ziel zu erreichen, wählen die Computer in Ihrem Netzwerk die beste Route aus und ignorieren nicht erreichbare Routen.", //help113
	"BigPond-Client", //ZM6
	"(Die Länge gilt für alle Schlüssel)", //bws_length
	"Das WCN ActiveX-Steuerelement liefert den notwendigen WCN-Link zwischen dem Router und Ihrem PC über den Browser. Der Browser versucht, das WCN ActiveX-Steuerelement herunterzuladen, wenn das Programm noch nicht auf Ihrem PC vorhanden ist. Damit diese Aktion erfolgreich sein kann, muss die WAN-Verbindung aufgebaut sein und die Internetsicherheitseinstellungen des Browsers müssen 'Mittel' oder niedriger sein (wählen Sie Extras &rarr; Internetoptionen &rarr; Sicherheit &rarr; Benutzerdefinierte Ebene &rarr; Mittel).", //help836
	"Versuchen Sie eine Wiederherstellung mit einer gültigen Wiederherstellungskonfigurationsdatei.", //rs_intro_2
	"Die IP-Adresse %v besteht bereits.", //GW_INET_ACL_IP_ADDRESS_DUPLICATION_INVALID
	"Sie müssen als Administrator angemeldet sein, um diese Funktionen zu verwenden.", //KR7
	"(Auch SSID genannt)", //ZM1
	"Wählen Sie einen Filter, der den für diesen Admin-Port benötigten Zugriff steuert. Finden Sie den gewünschten Filter nicht in der entsprechenden Liste mit Filtern, rufen Sie <a href=\"Inbound_Filter.asp\" onclick=\"return jump_if();\">Erweitert → Eingangsfilter</a> auf und erstellen Sie einen neuen.", //hhta_831
	"Manuelles Einrichten der Internetverbindung", //LW30
	"Ungültige L2TP-Subnetzmaske", //YM110
	"Point-to-Point (kein Broadcast)", //bd_NETBIOS_REG_TYPE_P
	"Die LAN-Subnetzmaske ist ungültig.", //GW_LAN_SUBNET_MASK_INVALID
	"Es dürfen keine weiteren Reservierungen erstellt werden", //YM88
	"Ungültige primäre WINS-IP-Adresse", //GW_DHCP_SERVER_NETBIOS_PRIMARY_WINS_INVALID
	"Name (ggf.)", //YM187
	"%s Name %s von '%s' ist nicht definiert.", //GW_NAT_NAME_UNDEFINED_INVALID
	"Drahtlosradar auf Kanal %d entdeckt", //GW_WIRELESS_RADAR_DETECTED
	"Vorinstallierter Schlüssel", //LW25
	"Ungültig wiederherstellen", //_rs_invalid
	"Ungültige primäre DNS-Server-IP-Adresse", //YM113
	"WPS (Wi-Fi Protected Setup)", //LW65
	"Wählen Sie diese Option, wenn Ihr drahtloses Gerät die Auswahltaste unterstützt", //KR41
	"Ungültige primäre DNS-Server-IP-Adresse: %v", //GW_WAN_DNS_SERVER_PRIMARY_INVALID
	"Die PIN des drahtlosen Geräts ist ungültig", //KR21
	"PAN (Personal Area Network)", //help643
	"Das Feld <span class='option'>Router-IP-Adresse</span> unten muss auf die IP-Adresse dieses Geräts gesetzt werden. Das <span class='option'>Gateway</span> muss auf die IP-Adresse des Upstream-Routers eingestellt werden. Die beiden Adressen müssen gemäß der Angaben in der <span class='option'>Subnetzmaske</span> im LAN-Subnetz liegen.", //KR63
	"Dieser webbasierte Setup-Assistent hilft Ihnen bei der Einrichtung des Druckers. Der Setup-Assistent gibt Ihnen zum Einrichten Ihres Druckers Schritt für Schritt Anweisungen.", //LW31
	"Ungültige sekundäre DNS-Server-IP-Adresse: %v", //GW_WAN_DNS_SERVER_SECONDARY_INVALID
	"Ungültige Remote-End-IP-Adresse.", //YM55
	"Informationen dazu, welche Konfigurationsmethode Ihr drahtloses Gerät unterstützt, finden Sie in der Dokumentation der Adapter.", //KR37
	"Aktivieren Sie dieses Kontrollkästchen, damit der DHCP-Server den LAN-Hosts die NetBIOS-Konfigurationseinstellungen bereitstellt.", //KR80
	"Ungültige WAN-Subnetzmaske", //YM100
	"WOL (Wake on LAN)", //_wakeonlan
	"Das Gerät ist möglicherweise ausgelastet. Der Empfang ist derzeit nicht möglich. Bitte wiederholen Sie den Wiederherstellungsvorgang. Außerdem ist es möglich, dass Sie als 'Benutzer' angemeldet sind und nicht als 'Admin' - nur Administratoren können die Konfigurationsdatei wiederherstellen.  Bitte überprüfen Sie das Systemprotokoll auf mögliche Fehler.", //rs_intro_3
	"PainKiller", //gw_gm_35
	"Sie werden an die Anmeldeseite weitergeleitet", //YM7
	"Sofern Sie nicht die Funktion 'Super G' mit dynamischem Turbo für eine höhere Routergeschwindigkeit verwenden, müssen Sie die automatische Kanalerkennung aktivieren, so dass der Router den optimalen Kanal für Ihr Drahtlosnetzwerk auswählen kann.", //YM124g
	"MAC-Adresse %m existiert bereits.", //GW_INET_ACL_MAC_ADDRESS_DUPLICATION_INVALID
	"ungültige Ziel-Start-IP-Adresse.", //YM66
	"Optimum Online", //manul_conn_13
	"NetBIOS-Anzeige", //bd_NETBIOS
	"Ziel", //sa_Target
	"In diesem Abschnitt definieren Sie die Anwendungsregeln.", //help56_a
	"<warn>DHCP-Server wird neu konfiguriert, weil das LAN-Subnetz nicht passend ist; bitte achten Sie darauf, dass Ihr Server korrekt bleibt.</warn>", //GW_DHCP_SERVER_RECONFIG_WARNING
	"Fehlgeschlagen", //_wifisc_addfail
	"Das Beacon-Intervall sollte zwischen 100 und 1000 liegen.", //GW_WLAN_BEACON_PERIOD_INVALID
	"Bestmöglich(BM)", //YM79
	"Ungültige maximale Bündelungsgröße", //YM32
	"Dies speichert die aktuelle drahtlose Konfiguration vom Router zu Ihrem Computer über Microsofts Windows Connect Now-Technologie und ermöglicht die zukünftige Übertragung der Einstellung über den Installationsassistenten für drahtlose Netzwerke von Microsoft.", //ta_intro_wcn
	"Wählen Sie diese Option, wenn Ihre drahtlosen Adapter WPA UNTERSTÜTZEN", //wwl_text_better
	"Hintergrund (BK)", //YM78
	"Kanal", //sd_channel
	"Beachten Sie, dass es nicht möglich ist, verschiedene LAN-Computer über Portweiterleitungsregeln, die gemeinsame Ports enthalten, zu verbinden; derartige Regeln würden sich gegenseitig widersprechen.", //KR53
	"<strong>Sperren Sie die Einstellungen für WLAN-Sicherheit</strong>, nachdem alle Netzwerkgeräte konfiguriert wurden.", //LW16
	"TCP", //GW_NAT_TCP
	"Dieser Router verfügt über einen USB-Port. Wenn Sie ein USB-Flash-Laufwerk oder einen USB-Port an Ihrem PC besitzen und auf Ihrem PC Windows XP Service Pack 2 (SP2) oder höher läuft, können Sie die Daten der drahtlosen Konfiguration zwischen Ihrem PC und dem Router mit dem USB-Flash-Laufwerk übertragen. Gehen Sie in die Systemsteuerung von Windows und wählen Sie den 'Assistent für die Einrichtung drahtloser Netzwerke'. Der Assistent für die Einrichtung drahtloser Netzwerke bietet Ihnen die folgenden Auswahlmöglichkeiten: 'USB-Flash-Laufwerk verwenden' und 'Ein Netzwerk manuell einrichten'. Wählen Sie 'USB-Flash-Laufwerk verwenden'.", //help202
	"[KRIT]", //CRIT
	"Die Regel gilt für einen Nachrichtenfluss, für den die IP-Adresse des anderen Computers innerhalb des hier eingestellten Bereichs liegt.", //YM154
	"Die QoS Engine-Funktion hilft Ihnen, die Leistungsstärke im Netz zu verbessern, indem sie den Datenfluss der Netzwerkanwendungen priorisiert.", //help76
	"'%s': Erster Host 1-Port %u muss niedriger als der letzte Host 1-Port sein, %u", //GW_WISH_RULES_HOST1_PORT
	"Im 11g Turbo-Modus muss der Kanal auf 6 eingestellt sein.", //GW_WLAN_11G_TURBO_INVALID
	"Unterhaltung", //_aa_bsecure_entertainment
	"Inaktiv", //YM165
	"Geben Sie einen beschreibenden Namen für die Regel ein.", //help172
	"Lifestyle", //_aa_bsecure_lifestyles
	"Die DMZ-Adresse sollte innerhalb des LAN-Subnetzes (%v) liegen.", //GW_NAT_DMZ_NOT_IN_SUBNET_INVALID
	"Turbo-Modus", //sd_TMode
	"%s Portbereich '%s von '%s' ist ungültig.", //GW_NAT_PORT_FORWARD_PORT_RANGE_INVALID
	"'%s': Die letzte lokale IP '%v' liegt nicht im LAN-Subnetz", //GW_QOS_RULES_LOCAL_IP_END_SUBNET
	"AES", //bws_CT_2
	"Bitte beachten Sie, dass es nicht möglich ist, den Zugriff auf Webseiten zu verwalten, die das sichere HTTP-Protokoll verwenden, d. h. URLs in der Form <code>https://...</code>.", //_bsecure_parental_limits
	"64 KB", //aw_64
	"Humor", //_aa_bsecure_humor
	"P-Knoten; dies gibt an, dass NUR WINS-Server verwendet werden dürfen. Diese Einstellung ist hilfreich, um den gesamten NetBIOS-Betrieb auf die konfigurierten WINS-Server zu zwingen. Sie müssen mindestens die primäre WINS-Server-IP konfiguriert haben, um auf einen funktionierenden WINS-Server zu verweisen.", //KR92
	"Router-Modus", //KR13
	"Der Richtlinienname kann nicht dupliziert werden: %s.", //GW_INET_ACL_POLICY_NAME_DUPLICATE_INVALID
	"Der NAT leitet keine eingehenden Verbindungsanfragen weiter, wenn für diese bereits eine Verbindung besteht.", //YM136
	"Hardware-Version", //TA3
	"Super G ohne Turbo:", //help360
	"Warnungen", //YM10
	"PPTP-Server-IP-Adresse ungültig: %v", //GW_WAN_PPTP_SERVER_IP_ADDRESS_INVALID
	"Video.", //YM150
	"Die IP-Adresse %v wird bereits verwendet; Sie müssen die Adresse freigeben und die Netzwerkeinstellungen des Geräts, das sie verwendet, zurücksetzen.", //GW_DHCP_SERVER_RESERVATION_IN_USE
	"Firewall-Port", //GW_NAT_INPUT_PORT
	"Neustart durch %s abgeschlossen", //WIFISC_AP_REBOOT_COMPLETE
	"Neuste Firmware-Version", //YM182
	"1000 Mbit/s", //LW3
	"Der persönliche WPA-Schlüssel muss aus mindestens 8 Zeichen bestehen.", //YM116
	"WEP-Schlüssel", //LW22
	"Ooops!", //OOPS
	"WISH-Sitzungen", //YM158
	"Versand-/Empfangsinstanzfehler", //ZM16
	"Speicherzeit auswählen", //_aa_bsecure_select_age
	"Routen-Ziel-IP %s ist ungültig", //GW_ROUTES_DESTINATION_IP_ADDRESS_INVALID
	"Zurücksetzen durch %s abgeschlossen", //WIFISC_AP_RESET_COMPLETE
	"NetBIOS-Registrierungsmodus", //bd_NETBIOS_REG
	"LAN-Gateway-IP-Adresse ist ungültig.", //GW_LAN_GATEWAY_IP_ADDRESS_INVALID
	"Speichert die neue oder bearbeitete Regel für Zeitpläne.", //KR96
	"Erfolgreich exportierte Konfigurationsdatei", //GW_XML_CONFIG_GET_SUCCESS
	"UPnP erneuert Eintrag %v <-> %v:%d <-> %v:%d %s Timeout:%d '%s'", //GW_UPNP_IGD_PORTMAP_REFRESH
	"Für bessere drahtlose Leistungen verwenden Sie den Sicherheitsmodus <strong>Nur WPA2</strong> (also die AES-Verschlüsselung).", //bws_msg_WPA_2
	"LAN-IP-Adresse ist ungültig.", //GW_LAN_IP_ADDRESS_INVALID
	"Remote-IP-Start", //KR5
	"Die QoS Engine unterstützt Überschneidungen zwischen Regeln, wobei mehr als eine Regel einem bestimmten Nachrichtenfluss entsprechen kann. Wenn mehr als eine Regel für einen bestimmten Nachrichtenfluss passt, wird die Regel mit der höchsten Priorität verwendet.", //help88c
	"Der Zeitplanname %s ist nicht definiert.", //GW_INET_ACL_SCHEDULE_NAME_INVALID
	"'%s': Erster Remote-Port %u muss niedriger als der letzte Remote-Port %u sein", //GW_QOS_RULES_REMOTE_PORT
	"Die IP-Adresse für '%s' sollte innerhalb des LAN-Subnetzes (%v) liegen.", //GW_NAT_IP_ADDRESS_INVALID
	"128-Bit-Hexadezimalschlüssel haben eine Länge von genau 26 Zeichen. (456FBCDF123400122225271730 ist eine gültige Zeichenfolge aus 26 Zeichen für eine 128-Bit-Verschlüsselung.)", //help369
	"Anstatt einen Namen für die Spezialanwendungsregel einzugeben, können Sie aus dieser Liste der gebräuchlichen Anwendungen eine Auswahl treffen; die übrigen Konfigurationswerte werden entsprechen eingefügt.", //help48a
	"Wireless Einstellungen", //LW38
	"Das Benutzerkonto muss angegeben werden", //GW_DYNDNS_USER_NAME_INVALID
	"Die Ziel-IP-Adresse ist die Adresse des Hosts oder des Netzwerks, den/das Sie erreichen möchten.", //hhav_r_dest_ip
	"Die Portnummer der Remoteverwaltung ist ungültig.", //YM175
	"Wi-Fi Protected Setup wird verwendet, um einem Netzwerk auf einfache Weise Geräte über eine PIN oder einen Tastendruck hinzuzufügen. Die Geräte müssen Wi-Fi Protected Setup unterstützen, damit sie mit Hilfe dieser Methode konfiguriert werden können.", //LY3
	"UPnP hat Eintrag %v <-> %v:%d <-> %v:%d %s hinzugefügt; Timeout:%d '%s'", //GW_UPNP_IGD_PORTMAP_ADD
	"UPnP-Konflikt mit vorhandenem Eintrag %v <-> %v:%d <-> %v:%d %s '%s'", //GW_UPNP_IGD_PORTMAP_CONFLICT
	"Nachricht", //KRA1
	"Port", //_vs_port
	"<warn>Die Zugriffskontrolltabelle wird neu konfiguriert, da das LAN-Subnetz geändert wurde.</warn>", //GW_INET_ACL_RECONFIGURED_WARNING
	"Aktiviert den 802.11d Betrieb. 802.11d ist eine Wireless-Spezifikation für den Betrieb in zusätzlichen regulatorischen Gebieten. Diese Ergänzung zur 802.11-Spezifikation definiert die physikalische Ebenen-Bedingungen (Kanalisierung, wechselnde Bitmuster, neue Werte für aktuelle MIB Eigenschaften und andere Bedingungen zur Erweiterung des Betriebs von 802.11 WLANs zu neuen regulatorischen Gebieten (Ländern)). Der derzeitige Standard 802.11 definiert lediglich den Betrieb von wenigen regulatorischen Gebieten (Ländern). Diese Ergänzung fügt den 802.11 WLAN-Geräten die erforderlichen Anforderungen und Definitionen zu, um sie in nicht dem Standard unterliegenden Umgebungen zu betreiben. Aktivieren Sie diese Funktion wenn Sie sich in einen dieser &quot;zusätzlichen regulatorischen Domänen&quot; befinden.", //help186
	"Bei den meisten Anwendungen sichern die Prioritätenzuweisungsfunktionen die richtigen Prioritäten; es werden keine speziellen WISH-Regeln benötigt.", //YM145
	"Einstellungen des ausgewählten Registrators aufheben", //WIFISC_AP_UNSET_SELECTED_REGISTRAR
	"Bei Angabe einer sekundären DNS muss auch eine primäre DNS angegeben werden.", //GW_WAN_DNS_SERVER_SECONDARY_WITHOUT_PRIMARY_INVALID
	"WISH (Wireless Intelligent Stream Handling) bevorzugt den Datenverkehr verschiedener drahtloser Anwendungen.", //YM72
	"Nützliche Hinweise", //_hints
	"'%s': Erster lokaler Port %u muss niedriger als der letzte lokale Port %u sein", //GW_QOS_RULES_LOCAL_PORT
	"Ungültige lokale Start-IP-Adresse.", //YM52
	"Chat", //_aa_bsecure_chat
	"Ziel-IP", //help104
	"Beachten Sie, dass Sie in der aktuellen Windows-Implementierung von WCN die drahtlosen Einstellungen nicht speichern können, wenn es bereits ein Profil mit dem gleichen Namen gibt. Um diese Beschränkung zu umgehen, können Sie entweder das vorhandene Profil löschen oder die SSID ändern, wenn Sie die WLAN-Einstellungen ändern; dann wird beim Speichern der neuen Einstellungen ein neues Profil erstellt.", //help839
	"Ungültige WAN-IP-Adresse", //YM99
	"Nach Speicherzeit", //_aa_bsecure_byage
	"Name '%s' existiert bereits.", //GW_INET_ACL_NAME_DUPLICATE_INVALID
	"Die letzte DHCP-Serveradresse %v ist im LAN-Subnetz %v nicht gültig.", //GW_DHCP_SERVER_POOL_TO_INVALID
	"Wird bearbeitet ...", //KR26
	"Möchten Sie den DHCP-Reservierungseintrag für die IP-Adresse aktivieren", //YM92
	"Reservierte IP %v ist ungültig", //GW_DHCP_SERVER_RESERVED_IP_INVALID
	"Eine gebräuchliche Auswahl (UDP, TCP und UDP und TCP) können im Dropdown-Menü getroffen werden.", //help19x1
	"Instabil", //_aa_bsecure_unstable
	"Die reservierte IP-Adresse %v sollte innerhalb des konfigurierten DHCP-Bereichs liegen.", //GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID
	"Die Filterregel '%s' kann nicht gelöscht oder umbenannt werden, da sie gerade verwendet wird.", //GW_FIREWALL_FILTER_NAME_INVALID
	"Falls einmal die Standardeinstellungen des Routers wiederhergestellt werden, können Sie Ihre Einstellungen wieder aus dieser Datei laden.", //ZM19
	"Video(VI)", //YM80
	"Sekundäre WINS-Server-IP-Adresse", //bd_NETBIOS_WINS_2
	"Reinitialisiert den Bereich 'Hinzufügen/Aktualisieren' des Bildschirms und löscht dabei etwaige Änderungen, die Sie vor dem Klicken auf die Schaltfläche 'Hinzufügen/Aktualisieren' gemacht haben.", //KR57
	"Aktiv", //YM164
	"IP-Adresse ist nicht zulässig", //_logsyslog_alert2
	"Bestmöglich.", //YM149
	"Ungültige DHCP-Server-Ablaufzeit", //LT120
	"Auto (WPA oder WPA2) – Personal", //KR48
	"Ungültiges Intervall für den Verbindungswiederaufbau: %u (muss zwischen 20 und 180 liegen)", //GW_WAN_RECONNECT_INTERVAL_INVALID
	"Kontrolle für die Endpunktfilterung von TCP-Protokollpaketen.", //YM139
	"Erster Remote-Port sollte zwischen 0 und 65535 einschließlich liegen.", //YM61
	"<warn>Die virtuelle Servertabelle wird neu konfiguriert, da das LAN-Subnetz geändert wurde.</warn>", //GW_NAT_VIRTUAL_SERVER_TABLE_RECONFIGURED_WARNING
	"Neustart erforderlich", //YM1
	"WEP-Schlüssellänge", //bws_WKL
	"PIN (Persönliche Identifikationsnummer)", //wps_p3_2
	"Speichern der Einstellungen erfolgreich", //KR102
	"'%s': Der erste lokale IP '%v' liegt nicht im LAN-Subnetz", //GW_QOS_RULES_LOCAL_IP_START_SUBNET
	"PPTP-IP-Adresse ungültig: %v", //GW_WAN_PPTP_IP_ADDRESS_INVALID
	"Alkohol", //_aa_bsecure_alcohol
	"Namen für die Port-Filterregeln dürfen nicht doppelt sein.", //YM14
	"Der Modus 'Dynamischer Turbo' ist bei 802.11b nicht zulässig.", //GW_WLAN_11B_DYNAMIC_TURBO_INVALID
	"Abgelaufener UpnP-Eintrag %v <-> %v:%d <-> %v%d %s '%s'", //GW_UPNP_IGD_PORTMAP_EXPIRE
	"Sobald Ihr Router wie gewünscht konfiguriert ist, können Sie die Konfigurationseinstellungen in einer Konfigurationsdatei speichern. Sie benötigen diese Datei möglicherweise, damit Sie Ihre Konfiguration später laden können, falls die Standardeinstellungen des Routers wiederhergestellt wurden. Um die Konfiguration zu speichern, klicken Sie auf <strong>Konfiguration speichern</strong>.", //TA18
	"Diese Option ist nur verfügbar, wenn der Modus <span class='option'>802.11</span> auf <span class='option'>nur 802.11ng</span> eingestellt ist.", //aw_erpe_h2
	"Ungültiger erster Zielport für Portfilter", //YM21
	"Hier wird die Priorität des Nachrichtenflusses eingetragen. Es gibt vier Prioritäten:", //YM147
	"Wenn die Option 'Protokoll-E-Mail' aktiviert ist, werden Protokoll-E-Mails über den Upstream-Router ans Internet gesendet.", //KR68
	"Dieser Assistent hilft Ihnen dabei, dem Drahtlosnetzwerk drahtlose Geräte hinzuzufügen.", //LW61
	"Es MUSS ein L2TP-Benutzername angegeben werden", //GW_WAN_L2TP_USERNAME_INVALID
	"Ungültige sekundäre WINS-IP", //LT120z
	"WPA/WPA2", //KR97
	"Ungültige L2TP-Subnetzmaske %v", //GW_WAN_L2TP_SUBNET_INVALID
	"Einstellungen auf lokaler Festplatte speichern", //help_ts_ss
	"Automobil", //_aa_bsecure_automobile
	"Drahtloses Gerät mit WPS hinzufügen", //LW13
	"Zeitraum", //sch_time
	"Zum Schutz Ihrer Privatsphäre können Sie verschiedene Sicherheitsfunktionen für das Drahtlosnetzwerk konfigurieren. Dieses Gerät unterstützt drei Sicherheitsmodi für drahtlose Netzwerke, darunter WEP, WPA-Personal und WPA-Enterprise. WEP ist der Originalverschlüsselungsstandard für Drahtlosverbindungen. Mit WPA erreichen Sie einen höheren Sicherheitsstandard. WPA-Personal kann ohne Authentifizierungsserver verwendet werden. Zur Verwendung von WPA-Enterprise ist ein externer RADIUS-Server notwendig.", //bws_intro_WlsSec
	"Es MUSS ein PPPoE-Kennwort angegeben werden.", //GW_WAN_PPPOE_PASSWORD_INVALID
	"Bevor Sie den WCN-Assistenten des Routers verwenden, müssen Sie zuerst den 'Assistent für die Einrichtung von Drahtlosnetzwerken' auf Ihrem PC ausführen. Sofern Sie dies noch nicht getan haben, gehen Sie in die Systemsteuerung von Windows und wählen Sie den &quot;Assistent für die Einrichtung von Drahtlosnetzwerken&quot;. Wenn der 'Assistent für die Einrichtung von Drahtlosnetzwerken' Ihnen die Möglichkeiten 'USB-Flash-Laufwerk verwenden' oder 'Netzwerk manuell einrichten' bietet, wählen Sie letztere aus. (Tatsächlich müssen Sie das Setup nicht manuell ausführen; dies geschieht automatisch über das WCN-ActiveX-Steuerelement.", //help211
	"Ungültige Subnetzmaske", //LS202
	"Endzeit", //tsc_EndTime
	"Dieser Assistent führt Sie Schritt für Schritt durch das Hinzufügen eines drahtlosen Geräts zu Ihrem drahtlosen Netzwerk.", //KR34
	"WEP-Schlüssel 3", //_wepkey3
	"Remote-Portbereich", //at_RePortR
	"OSPF", //help640
	"Die angegebene Serveradresse (%s) ist ungültig", //GW_SMTP_SERVER_ADDRESS_INVALID
	"Ungültige L2TP-Gateway-IP-Adresse: %v", //GW_WAN_L2TP_GATEWAY_IP_ADDRESS_INVALID
	"Zeigt den aktuellen PIN-Wert des Routers an.", //LW58
	"Schlüssel wird verwendet", //LW22usekey
	"Die Verwendung des 'Statischen Turbo'-Modus ist mit 802.11b zulässig", //GW_WLAN_11B_STATIC_TURBO_INVALID
	"ungültige Ziel-End-IP-Adresse.", //YM67
	"<warn>Das Ändern der Einstellungen der WLAN-Sicherheit kann dazu führen, dass Wi-Fi Protected Setup nicht wie erwartet funktioniert.</warn>", //GW_WIFISC_CFG_CHANGED_WARNING
	"Neustart während der DNS-Abfrage", //ZM10
	"Kann den 802.11b/g-Kanal im Modus 802.11a nicht verwenden.", //GW_WLAN_11A_CHANNEL_INVALID
	"Regeln für die QoS Engine", //at_title_SERules
	"Der Remote-Verwaltungsport muss im Bereich 1 bis 65535 liegen.", //YM176
	"NetBIOS ermöglicht es LAN-Hosts, alle anderen Computer innerhalb des Netzwerks, z. B. innerhalb der Netzwerkumgebung, zu erkennen.", //KR81
	"TCP-Port", //GW_NAT_TCP_PORT
	"Die Regel gilt für einen Nachrichtenfluss, für den die Portnummer von Host 2 innerhalb des hier eingestellten Bereichs liegt.", //YM155
	"Dieser Modus ist abwärtskompatibel mit Nicht-Turbo-Geräten (älteren Geräten). Dieser Modus muss aktiviert sein, wenn einige Geräte im Drahtlosnetzwerk nicht Turbo-fähig sind, sondern andere der oben genannten Super G-Funktionen unterstützen.", //help365
	"NetBIOS-Bereich", //bd_NETBIOS_SCOPE
	"Sitzung wurde abgebrochen", //KR28
	"Webfilter", //_webfilter
	"Ungültige Bündelungsnummernpakete", //YM33
	"Automatisch", //YM76
	"AP-Setup entsperren", //WIFISC_AP_SETUP_UNLOCKED
	"Der virtueller Server '%s' kann den HTTPS WAN-Administrator-Port %u des Routers nicht verwenden", //GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"Ausgabe", //LS313
	"Assistent für Microsoft Windows Connect Now", //bwz_WCNWz
	"DNS Lookup-Anmeldeserver", //ZM9
	"Die reservierte IP-Adresse für diese MAC-Adresse (%m) ist bereits eingestellt.", //GW_DHCP_SERVER_RESERVED_MAC_UNIQUENESS_INVALID
	"PIN-Einstellungen", //LY5
	"Bei den meisten Anwendungen gewährleisten die Prioritätsklassifizierer die richtigen Prioritäten und es sind keine spezifischen WISH-Regeln erforderlich.", //YM87
	"Der WAN-PING-Filtername %s existiert nicht", //GW_NAT_WAN_PING_FILTER_INVALID
	"Wenn das Betriebssystem auf Ihrem PC Windows XP Service Pack 2 (SP2) oder höher ist und Sie den Windows Internet Explorer (IE) als Ihren Browser verwenden, können Sie diese Option nutzen, um Schlüsselbestandteile der aktuellen Einstellungen der WLAN-Sicherheit des Router über die Windows Connect Now (WCN)-Technologie auf Ihrem PC zu speichern. Die Einstellungen sind dann zur Weitergabe an andere drahtlose Geräte verfügbar.", //help835
	"(1..255)", //at_lowpriority
	"Für die Regel nummer %d wird ein Name benötigt", //YM49
	"Sie können keine neue IP-Adresse %v hinzufügen. Sie können nur IP-Adressen anderer Richtlinien wiederverwenden.", //GW_INET_ACCESS_POLICY_TOO_MANY_IP_INVALID
	"Ungültige L2TP Server IP-Adresse", //YM112
	"H-Knoten; gibt einen Hybrid-Betriebsstatus an. Zuerst werden möglicherweise vorhandene WINS-Server getestet, danach lokale Netzwerk-Broadcasts. Dies ist normalerweise der bevorzugte Modus, wenn Sie WINS-Server konfiguriert haben.", //KR90
	"Beachten Sie, dass WCN nur einige der WLAN-Sicherheitseinstellungen speichert. Wenn Sie WCN nutzen, um Einstellungen an andere drahtlose Geräte zu verbreiten, müssen Sie möglicherweise einige Zusatzeinstellungen dieser Geräte manuell durchführen.", //help838
	"Aktivieren Sie diese Option nur, wenn Sie Ihren eigenen Domainnamen beantragt und bei einem Dynamischen DNS-Dienstanbieter registriert haben. Die folgenden Parameter werden angezeigt, wenn diese Option aktiviert ist.", //help892
	"Wenn Sie PPPoE verwenden, müssen Sie jede Software zur PPPoE-Einwahl von Ihrem Computer entfernen oder deaktivieren.", //KR73
	"Es gibt verschiedene Stufen der WLAN-Sicherheit. Die von Ihnen gewählte Sicherheitsstufe hängt von den Sicherheitsfunktionen ab, die Ihr drahtloser Adapter unterstützt.", //wwl_intro_s3_2
	"Ungültige Metrik für Route", //_r_alert5
	"<warn>Der WAN Ping-Filtername %s existiert nicht länger; WAN PING wird deaktiviert.</warn>", //GW_NAT_WAN_PING_FILTER_WARNING
	"Ungültige letzte IP-Adresse.", //YM53
	"Beachten Sie, dass WCN nur einige der drahtlosen Optionen einstellt. Sie müssen immer noch auf die Seite <a href='wireless.asp'>WLAN-Einstellungen</a> gehen, um andere drahtlose Optionen wie den Super G-Modus und die Übertragungsrate einzustellen.", //help215
	"WISH ist die Kurzform für Wireless Intelligent Stream Handling, einer Technologie, die zum Verbessern Ihrer Erfahrungen bei der Verwendung eines Drahtlosnetzwerkes entwickelt wurde, um den Datenverkehr verschiedener Anwendungen zu bevorzugen.", //YM140
	"Die DHCP-Serveradresse %v wurde von dem Netzwerkgerät abgelehnt. Wenn es in Ihrem Netzwerk mehr als einen DHCP-Server gibt, kann dies zu IP-Adresskonflikten führen.", //GW_DHCPSERVER_REJECTED
	"Ermöglicht es dem Router, HTTP-Übertragungen häufig verwendeter Audio- und Videostreams zu erkennen und ihnen anderem Datenverkehr gegenüber eine höhere Priorität zuzuweisen. Solche Streams werden regelmäßig von digitalen Media Playern verwendet.", //YM142
	"Ungültiges Kennwort", //GW_SMTP_PASSWORD_INVALID
	"Die Regel gilt für einen Nachrichtenfluss, für den die IP-Adresse eines Computers innerhalb des hier eingestellten Bereichs liegt.", //YM152
	"Ungültiger letzter DHCP-Server-IP-Bereich", //LT119a
	"Wenn Sie Schwierigkeiten haben, über den Router eine Internetverbindung aufzubauen, überprüfen Sie nochmals alle vorgenommenen Einstellungen auf dieser Seite. Lassen Sie diese ggf. auch durch Ihren Internetdiensteanbieter überprüfen.", //LW36
	"Der zur Sicherung der Datenübertragung verwendete Verschlüsselungsalgorithmus. Mit TKIP (Temporal Key Integrity Protocol) wird ein Schlüssel für jedes Datenpaket erstellt. Es beruht auf WEP. AES (Advanced Encryption Standard) ist ein Blockalgorithmus für die Datenverschlüsselung, der sehr hohe Sicherheit bietet. Über die Option 'TKIP und AES' verhandelt der Router den Verschlüsselungstyp mit dem Client und verwendet AES, wenn dies verfügbar ist.", //help377
	"%s '%s' ist ungültig.", //GW_NAT_PORT_TRIGGER_PORT_RANGE_INVALID
	"Ungültige WEP-Schlüssel", //YM121
	"Ungültige Fragmentierungsschwelle", //YM29
	"Die WISH-Sitzungsseite zeigt die vollständigen Details aktiver lokaler drahtloser Sitzungen über Ihren Router an, wenn WISH aktiviert wurde. Eine WISH-Sitzung ist eine Konversation zwischen einem Programm oder einer Anwendung auf drahtlos verbundener LAN-Seite und einem anderen Computer, unabhängig davon, wie dieser verbunden ist.", //YM159
	"Portnummer ungültig.", //YM120
	"BESSER", //wwl_BETTER
	"Aktivieren Sie die Option 'DMZ' nur als letzten Ausweg. Wenn Sie Schwierigkeiten haben, eine Anwendung von einem Computer hinter dem Router auszuführen, versuchen Sie zunächst, die entsprechenden Ports für die Anwendung in den Abschnitten <a href='adv_virtual.asp' onclick='return jump_if();'>Virtueller Server</a> oder <a href='adv_portforward.asp' onclick='return jump_if();'>Portweiterleitung</a> zu öffnen.", //hhaf_dmz
	"Ungültige PPTP-Subnetzmaske", //YM106
	"Unbewertete Seiten blockieren", //_aa_bsecure_block_unrated
	"Ein Big Pond-Benutzername MUSS angegeben werden", //GW_WAN_BIGPOND_USERNAME_INVALID
	"Zum Beispiel: 192.168.0.101.", //KR76
	"Der DHCP-Server kann keine weiteren IP-Adressen mehr anbieten, da alle verfügbaren Adressen bereits verwendet werden. Steigern Sie die Anzahl der verfügbaren IP-Adressen in der DHCP-Serverkonfiguration.", //GW_DHCPSERVER_EXHAUSTED
	"Ungültige L2TP-Server-IP-Adresse: %v", //GW_WAN_L2TP_SERVER_IP_ADDRESS_INVALID
	"Das WEP-Kennwort muss aus genau 13 alphanumerischen Zeichen bestehen.", //wwl_alert_pv5_2
	"Das Routensubnetz %v ist ungültig", //GW_ROUTES_SUBNET_INVALID
	"Medikamente", //_aa_bsecure_drugs
	"IP-Adresse darf nicht die gleiche sein wie die LAN-IP-Adresse des Routers.", //LW1
	"Ein Netzwerkcomputer hat nie seine Laufzeit' für %v erneuert und hat sein Recht darauf, diese Adresse zu verwenden, verloren. Wenn das Gerät weiterhin diese Adresse verwendet, kann diese Adresse zu IP-Adresskonflikten führen.'", //GW_DHCPSERVER_EXPIRED
	"Die IP-Adresse %v sollte innerhalb des LAN-Subnetzes (%v) liegen.", //GW_INET_ACL_IP_ADDRESS_IN_LAN_SUBNET_INVALID
	"Nur Broadcast (wird verwendet, wenn keine WINS-Server konfiguriert sind)", //bd_NETBIOS_REG_TYPE_B
	"Finanziell", //_aa_bsecure_financial
	"Der NAT leitet eingehende Verbindungsanfragen nur dann an den Host auf der LAN-Seite weiter, wenn diese von der IP-Adresse gesendet wurden, mit der eine Verbindung hergestellt wurde. Dadurch kann für die Datenrücksendung durch die Remoteanwendung ein anderer Port genutzt werden als bei der Datenzusendung.", //YM135
	"Ungültiger IP-Startbereich für DHCP-Server", //LT119
	"Öffentlich", //_vs_public
	"B-Knoten; gibt an, dass NUR lokale Netzwerk-Broadcasts verwendet werden dürfen. Diese Einstellung ist nützlich, wenn keine anderen WINS-Server verfügbar sind; es ist jedoch empfehlenswert, dass Sie den M-Knoten-Betrieb zuerst überprüfen.", //KR93
	"Die Remote-Verwaltung des Gateways wurde an folgendem Port aktiviert: %u", //GW_SECURE_REMOTE_ADMINSTRATION
	"Die IP-Adresse und ggf. die Portnummer des Computers, der eine Netzwerkverbindung gestartet hat.", //YM160
	"Zugewiesene IP", //LS423
	"Die L2TP Gateway-IP-Adresse %v muss innerhalb des WAN-Subnetzes liegen", //GW_WAN_L2TP_GATEWAY_IN_SUBNET_INVALID
	"'%s': Erste Host 1-IP %v muss niedriger als die letzte Host 1-IP %v sein", //GW_WISH_RULES_HOST1_IP
	"Privat", //_vs_private
	"Diese Einstellung hat keine Auswirkungen, wenn die Option 'NetBIOS-Informationen vom WAN abrufen' aktiviert ist.", //KR86
	"Sekundäre WINS-IP-Adresse", //bd_NETBIOS_SEC_WINS
	"Die Anfangs-IP-Adresse muss niedriger als die End-IP-Adresse sein: %v-%v.", //GW_INET_ACL_START_IP_ADDRESS_INVALID
	"Authentifizierung", //auth
	"Der Prozess kann nicht angehalten werden", //KR24
	"5 GHz", //KR17
	"Host 2 IP-Bereich", //YM84
	"Eine QoS-Engine-Regel identifiziert einen bestimmten Nachrichtenfluss und weist diesem Fluss eine Priorität zu.", //help88
	"Das Aktivieren der Fernwartung (Remote Management) erlaubt die Konfiguration Ihres Routers von einem entfernten Computer.", //hhta_en
	"Ungültige PPPoE-IP-Adresse", //YM103
	"Im Bridge-Modus unterstützt das Gerät immer noch verschiedene Funktionen, die nicht in gewöhnlichen Bridges verfügbar sind - Funktionen, welche die WAN-Seite des Upstream-Routers einbeziehen.", //KR64
	"Bei jeder Regel-Anfrage muss für die Verwendung der Kanäle 52-140 die Radarerkennung aktiviert sein.", //GW_WLAN_11A_DFS_CHANNEL_INVALID
	"WPS (Wi-Fi Protected Setup)", //LW4
	"Physische Schicht", //help645
	"Für den statischen 11a-Turbomodus sollte der Kanal auf 42, 50, 58, 152 oder 160 gesetzt sein.", //GW_WLAN_11A_STATIC_TURBO_INVALID
	"Super G™-Modus", //help358
	"Sie haben keine Berechtigungen für die Durchführung der angegebenen Aktion.", //YM6
	"Kategorieauswahl", //_aa_bsecure_categ_select
	"Die Priorität muss eine Zahl zwischen 1 und 255 einschließlich sein.", //YM58
	"Jugend (13-17)", //_aa_bsecure_age_youth
	"Klicken Sie auf <strong>Assistent zum Hinzufügen drahtloser Geräte</strong>, um die Funktion 'Wi-Fi Protected Setup' zum Hinzufügen von drahtlosen Geräten zum Drahtlosnetzwerk zu verwenden.", //LW17
	"Ungültige Ziel-IP-Endadresse für Portfilter", //YM18
	"WPA-PSK/AES (auch als WPA2 Personal bezeichnet)", //LT210
	"Ungültige Leerlaufzeit (der zugelassene Bereich liegt zwischen %u und %u)", //GW_WAN_IDLE_TIME_INVALID
	"Multicast-Gruppenadresse", //YM186
	"Sport", //_aa_bsecure_sports
	"Der Name '%s' wird bereits verwendet.", //GW_QOS_RULES_NAME_ALREADY_USED
	"Der folgende Assistent verwendet Microsofts Windows Connect Now-Technologie, um die WLAN-Einstellungen Ihres Routers automatisch zu konfigurieren. Stellen Sie sicher, dass Sie den Microsoft-Installationsassistenten für drahtlose Netzwerke erfolgreich auf Ihrem Computer ausgeführt haben, bevor Sie diese Funktion nutzen.", //bwz_intro_WCNWz
	"DHCP-Serverpool TO %v befindet sich nicht im LAN-Subnetz %v.", //GW_DHCP_SERVER_POOL_TO_IN_SUBNET_INVALID
	"<warn>Das H.323 wurde automatisch aktiviert, da ein von Ihnen erstellter virtueller Servereintrag dies benötigt.</warn>", //GW_NAT_H323_ALG_ACTIVATED_WARNING
	"L2 Isolation", //KR4
	"Ungültige primäre WINS-IP", //LT120y
	"Die Netzwerkeinstellungen für Wi-Fi Protected Setup wurden erfolgreich gespeichert.", //KR103
	"Calista IP-Telefon", //YM44
	"Wenn Sie sich als einen erfahrenen Anwender einstufen und bereits einen Drahtlosrouter konfiguriert haben, können Sie die Option <strong>Manuelle Einrichtung von Drahtlosnetzwerken</strong> auswählen und alle Einstellungen manuell vornehmen.", //LW47
	"Export der Konfigurationsdatei WIFISC_AP_SET_APSETTINGS_COMPLETE,SetAPSettings durch (%s) abgeschlossen", //GW_XML_CONFIG_GET_FAILED
	"SetAPSettings von (%s) abgeschlossen", //WIFISC_AP_SET_APSETTINGS_COMPLETE
	"WEP-Schlüssellänge", //wwl_WKL
	"Kommunikation mit Router fehlgeschlagen", //YM168
	"Der Name '%s' wird bereits verwendet.", //GW_NAT_NAME_USED_INVALID
	"Ungültiger Serverindexwert: %d", //GW_DYNDNS_SERVER_INDEX_VALUE_INVALID
	"[WARN]", //WARN
	"Enterprise", //LW23
	"Erweitertes Netzwerk", //ADVANCED_NETWORK
	"Es MUSS ein PPTP-Kennwort angegeben werden.", //GW_WAN_PPTP_PASSWORD_INVALID
	"Stellen Sie die Standard-PIN des Routers wieder her.", //LW59
	"Wenn Sie die Option 'WLAN-Sicherheit' aktiviert haben, notieren Sie sich unbedingt den konfigurierten WEP-Schlüssel bzw. das Kennwort. Sie müssen diese Informationen an jedem drahtlosen Gerät eingeben, das Sie mit Ihrem drahtlosen Netzwerk verbinden möchten.", //YM126
	"Aktiviert", //_enabled
	"Ungültige Routenschnittstelle", //_r_alert4
	"Drahtlose Station hinzufügen", //LY10
	"Die erste DHCP-Serveradresse %v ist im LAN-Subnetz %v nicht gültig.", //GW_DHCP_SERVER_POOL_FROM_INVALID
	"AP-Setup sperren", //WIFISC_AP_SETUP_LOCKED
	"Möchten Sie die Änderungen an der Reservierung verwerfen?", //YM91
	"Einstellen des ausgewählten Registrators ist fehlgeschlagen, Grund (%s), err_code (%u)", //WIFISC_AP_SET_SELECTED_REGISTRAR_FAIL
	"Es liegen keine Änderungen vor. Trotzdem speichern?", //_ask_nochange
	"Unbekannt", //GW_NAT_UNKNOWN
	"Für den dynamischen 11a-Turbomodus sollte der Kanal auf 40, 48, 56, 153 oder 161 gesetzt sein.", //GW_WLAN_11A_DYNAMIC_TURBO_INVALID
	"Beachten Sie, dass Sie auch bei Aktivierung von NTP Server noch eine Zeitzone auswählen und die Zeitumstellungsparameter einstellen müssen.", //YM163
	"Um diese Funktion nutzen zu können, benötigen Sie ein dynamisches DNS-Konto bei einem der Anbieter aus dem Dropdown-Menü.", //YM181
	"Unzureichende Berechtigung", //_cantapplysettings_1
	"Warnungen", //YM11
	"(8 bis 63 Zeichen)", //wwl_wsp_chars_2
	"Primäre WINS-IP-Adresse", //bd_NETBIOS_PRI_WINS
	"Zu verwendender Standard-WEP-Schlüssel", //wwl_DWKL
	"PIN des drahtlosen Geräts", //KR44
	"obj_word + ' Konflikt mit virtuellem Server-Port.'", //TEXT056
	"Ungültige Server-IP-Adresse", //YM130
	"Dynamischen DNS-Server auswählen", //KR99
	"Bei Angabe einer sekundären WINS-IP-Adresse muss auch die Primäre WINS-IP-Adresse angegeben werden.", //GW_DHCP_SERVER_PRIMARY_AND_SECONDARY_WINS_IP_INVALID
	"Aktivierung der Anti-Spoofing-Überprüfung", //KR106
	"Protokollnummer des virtuellen Servers '%s', %d, muss 0 sein oder zwischen 3 und 255 liegen.", //GW_NAT_VS_PROTOCOL_INVALID
	"Wählen Sie diese Option aus, wenn Sie Ihr Netzwerk manuell einrichten möchten", //KR52
	"Willkommen beim Assistenten zum Hinzufügen eines drahtlosen Geräts", //KR33
	"Sie müssen als 'Admin' angemeldet sein, um diese Aktion durchzuführen.", //ZM23
	"Dieser Assistent wurde dazu entworfen, Sie beim Verbinden Ihres drahtlosen Geräts an Ihren Router zu unterstützen. Er führt Sie Schritt für Schritt durch den Verbindungsvorgang Ihres drahtlosen Geräts. Klicken Sie auf die unten stehende Schaltfläche, um mit der Einrichtung zu beginnen.", //LW40
	"Einstellungen für WLAN-Sicherheit sperren", //LY4
	"Wenn Sie sich als einen erfahrenen Anwender einstufen und bereits einen Drahtlosrouter konfiguriert haben, können Sie die Option <strong>Manuelle Einrichtung der Internetverbindung</strong> auswählen und alle Einstellungen manuell vornehmen.", //LW34
	"Sind Sie sicher, dass Sie diesen Löschvorgang durchführen möchten?", //YM25
	"Ungültige Ziel-IP-Startadresse für Portfilter", //YM15
	"Super G&trade;-Modus", //bwl_SGM
	"Radius-Serveradresse ist nicht gültig.", //GW_WLAN_80211X_RADIUS_INVALID
	"'%s': Protokoll %u muss zwischen 0 und 257 liegen", //GW_WISH_RULES_PROTOCOL
	"Anmeldung", //LS316
	"Benutzer hat sich abgemeldet", //ZM15
	"<warn>Eine DHCP-Reservierung wurde deaktiviert, da sie mit der eigenen LAN-IP des Routers im Konflikt steht.</warn>", //GW_DHCP_SERVER_RESERVATION_DISABLED_IN_CONFLICT_WARNING
	"Es muss ein Host angegeben werden", //GW_DYNDNS_HOST_NAME_INVALID
	"Manuelle Einrichtung von Drahtlosnetzwerken", //LW42
	"Ungültige PPTP-Gateway-IP-Adresse: %v", //GW_WAN_PPTP_GATEWAY_IP_ADDRESS_INVALID
	"Die wiederhergestellte Konfigurationsdatei wurde erfolgreich hochgeladen.", //rs_intro_4
	"'%s': Die Remote-End-IP '%v' liegt im LAN-Subnetz", //GW_QOS_RULES_REMOTE_IP_END_SUBNET
	"nicht verfügbar", //_NA
	"Die Gateway-IP-Adresse ist die IP-Adresse des Routers, sofern vorhanden, der zum Erreichen des angegebenen Ziels verwendet wird.", //hhav_r_gateway
	"[INFO]", //INFO
	"Metrik", //help112
	"Hinweis: Durch manche Firmware-Aktualisierungen werden die Konfigurationsoptionen auf die werkseitigen Standardeinstellungen zurückgesetzt. Bevor Sie eine Aktualisierung durchführen, sollten Sie deshalb die aktuelle Konfiguration auf dem Bildschirm.\nMöchten Sie die Aktualisierung wirklich durchführen?", //tf_msg_FWUgReset
	"NetBIOS-Informationen aus WAN abrufen", //bd_NETBIOS_WAN
	"Short Slot für 11N-Clients erzwingen", //aw_igslot
	"(Standard, wenn nichts anderes passt)", //ZM2
	"Sie sind nicht berechtigt, die angegebene Aktion auszuführen.", //LT7
	"Ausgewählten Registrar angeben", //WIFISC_AP_SET_SELECTED_REGISTRAR
	"Wenn die benötigten Vorbereitungen abgeschlossen sind, überträgt die WCN-Technologie die WLAN-Einstellungen von Ihrem PC an den Router. Sie müssen danach den Router neu starten, damit die Einstellungen in Kraft treten.", //help214
	"Beides", //at_Both
	"Wochentag", //ZM22
	"Auf Werkseinstellungen zurücksetzen", //help_ts_rfd
	"Wenn das Betriebssystem auf Ihrem PC Windows XP Service Pack 2 (SP2) oder höher ist und Sie den Windows Internet Explorer (IE) als Ihren Browser verwenden, können Sie diese Windows Connect Now (WCN)-Technologie verwenden, um die WLAN-Sicherheitseinstellungen des Routers zu konfigurieren.", //help209
	"Ziel-Start-Port sollte zwischen 0 und 65535 einschließlich liegen.", //YM70
	"UPnP hat den VS-Eintrag %v <-> %v:%d <-> %v::%d %s in %s geändert", //GW_UPNP_IGD_PORTMAP_VS_CHANGE
	"Der Abschnitt 'Webfilter' ist eine der beiden Möglichkeiten, über die Sie die Webseiten, die Sie zulassen möchten, angeben können. Außerdem können Sie den Dienst 'Sentinel Parental Controls' verwenden, der Ihnen die Angabe von groben Kategorien von Webseiten ermöglicht und Ihnen die Eingabe von speziellen Website-URLs erspart. Weitere Informationen über den Sentinel-Dienst finden Sie unter <a href='../Tools/Sentinel.shtml'>Extras &rarr; Sentinel</a>.", //help143s
	"Dieser Modus ist nicht abwärtskompatibel mit Nicht-Turbo-Geräten (älteren Geräten). Dieser Modus sollte nur aktiviert sein, wenn für alle Geräte im drahtlosen Netzwerk der statische Turbo aktiviert ist.", //help363
	"Web-Newsgroup", //_aa_bsecure_web_newsgroup
	"Ungültige primäre DNS-Adresse", //YM128
	"%s von '%s' kann nicht leer sein.", //GW_NAT_PORT_TRIGGER_PORT_RANGE_EMPTY_INVALID
	"StreamEngine&trade;-Technologie wird auf Medien-Streams angewandt, die zwischen der WAN-Seite des Upstream-Routers und Clients der Bridge übertragen werden.", //KR72
	"Kennwort oder Schlüssel", //td_PWK
	"Host 1 IP-Bereich", //YM82
	"Ungültiges Authentifizierungstimeout.", //YM119
	"Die Bridge kann noch immer den Datenverkehr auf der WAN-Seite des Upstream-Routers analysieren, um die Geschwindigkeit der WAN-Verbindung zu bestimmen.", //KR70
	"Die IP-Adresse und ggf. die Portnummer des Computers, mit dem eine Netzwerkverbindung aufgebaut wurde.", //YM161
	"Der DHCP-Serverpool ist zu groß (darf nicht mehr als 256 Adressen enthalten).", //GW_DHCP_SERVER_POOL_SIZE_INVALID
	"Aufgebaut", //_sdi_s4b
	"DNS Lookup-Authentifizierungsserver", //ZM8
	"Ungültige sekundäre DNS-Adresse", //YM129
	"64-Bit-ASCII-Schlüssel bestehen aus bis zu 5 Zeichen (DMODE ist eine gültige Folge aus 5 Zeichen für eine 64-Bit-Verschlüsselung.)", //help370
	"Ein Sperren der WLAN-Sicherheitseinstellungen verhindert, dass ein neuer externer Registrator die Einstellungen über die PIN ändert. Es können immer noch Geräte über Wi-Fi Protected Setup zum drahtlosen Netzwerk hinzugefügt werden. Die drahtlosen Sicherheitseinstellungen können immer noch über <a href='wireless.asp' shape='rect'>Manuelles Einrichten von Drahtlosnetzwerken</a>, <a href='wizard_wlan.asp' shape='rect'>Assistent für die Einrichtung von Drahtlosnetzwerken</a> oder einen vorhandenen externen WLAN Manager-Registrator geändert werden.", //LY29
	"Warnung beim Schreiben der Konfigurationsdatei: %s", //GW_XML_CONFIG_WRITE_WARN
	"Der Name '%s' wird bereits verwendet", //GW_FIREWALL_NAME_INVALID
	"'%s': Erste Host 2-IP %v muss niedriger als die letzte Host 2-IP %v sein", //GW_WISH_RULES_HOST2_IP
	"Produktseite", //TA2
	"Verbinden", //LS314
	"Protokoll-Typ", //_vs_traffictype
	"Der Timeout-Wert darf nicht größer als 8760 sein.", //GW_DYNDNS_TIMEOUT_TOO_BIG_INVALID
	"Geben Sie die PIN Ihres drahtlosen Geräts ein und klicken Sie unten auf die Schaltfläche \"Verbinden\".", //wps_p3_4
	"Wählen Sie diese Option, wenn Ihr drahtloses Gerät WPS (Wi-Fi Protected Setup) unterstützt.", //KR51
	"Die PPTP Gateway-IP-Adresse %v muss innerhalb des WAN-Subnetzes liegen.", //GW_WAN_PPTP_GATEWAY_IN_SUBNET_INVALID
	"Klicken Sie auf die Schaltfläche <span class='button_ref'>In Windows Connect Now speichern</span>, und die WCN-Technologie ruft die Einstellungen des drahtlosen Netzwerks von Ihrem Router ab und speichert Sie auf Ihrem PC.", //help837
	"Wählen Sie zuerst einen Anwendungsnamen aus.", //TEXT052
	"Öffnen", //OPEN
	"Aktuelles", //_aa_bsecure_news
	"Aktualisieren", //YM34
	"Erweitert Wireless", //_advwls
	"<warn>DHCP-Reservierung %v wurde deaktiviert, weil der DHCP-Pool zu klein ist.</warn>", //GW_DHCP_SERVER_RESERVATION_DISABLED_OUT_OF_POOL_WARNING
	"MAC-Filtereinstellungen sperrt alle Computer aus. Dies ist nicht zulässig.", //GW_MAC_FILTER_ALL_LOCKED_OUT_INVALID
	"WEP-Schlüssel 4", //_wepkey4
	"optionaler", //LT124
	"Suchmaschine", //_aa_bsecure_search_engine
	"'Nur WPA'", //KR47
	"Bei Verwendung der WEP-Sicherheitsoption arbeitet dieses Gerät <strong>AUSSCHLIESSLICH</strong> im <strong>Standard-Drahtlosmodus (802.11B/G)</strong>. Leistungen nach IEEE 802.11n können <strong>NICHT</strong> erreicht werden, da WEP nicht durch die Draft 11n-Technologie unterstützt wird.", //bws_msg_WEP_3
	"<warn>Die E-Mail-Serveradresse steht im Konflikt mit der Router-LAN-Adresse; die E-Mail wird deaktivert.</warn>", //GW_SMTP_LAN_ADDRESS_CONFLICT_WARNING
	"LAN-IP-Modus ist ungültig.", //GW_LAN_IP_MODE_INVALID
	"Der angegebene Big Pond-Server ist kein korrekter Domänenname oder keine korrekte IP-Adresse.", //GW_WAN_BIGPOND_SERVER_NOTSTD15
	"Das Fragmentierungsschwelle sollte zwischen 256 und 2346 liegen.", //GW_WLAN_FRAGMENT_THRESHOLD_INVALID
	"Der verliehene Domänenname ist ungültig", //GW_LAN_DOMAIN_NAME_INVALID
	"Angegebener Gerätename ist ungültig", //GW_LAN_DEVICE_NAME_INVALID
	"Sitzungsüberlagerung erkannt", //_wifisc_overlap
	"Der Assistent zeigt entweder die Einstellungen des drahtlosen Netzwerks an, um Sie durch die manuelle Konfiguration zu führen, fordert Sie zur Eingabe der PIN für das Gerät auf oder bittet Sie, auf die Konfigurationstaste auf dem Gerät zu drücken. Wenn das Gerät Wi-Fi Protected Setup unterstützt und eine Konfigurationstaste besitzt, können Sie es dem Netzwerk hinzufügen, indem Sie erst auf die Konfigurationstaste auf dem Gerät und dann 60 Sekunden lang auf die des Routers drücken. Die Status-LED-Anzeige des Routers blinkt dreimal, wenn das Gerät erfolgreich dem Netzwerk hinzugefügt wurde.", //LW62
	"Der Vorgang wurde abgebrochen. Klicken Sie auf die Schaltfläche 'Abbrechen', um zum Seitenanfang des Assistenten zurückzukehren und den Vorgang zu wiederholen.", //KR23
	"Pornografie", //_aa_bsecure_pornography
	"Der Name darf keine leere Zeichenfolge sein.", //GW_NAT_NAME_INVALID
	"Anzahl an dynamischen DHCP-Klienten", //bd_title_clients
	"Ungültige PPTP Server-IP-Adresse", //YM108
	"Die Ziel-End-IP-Adresse darf nicht im LAN-Subnetz liegen.", //YM19
	"STA mit MAC (%m) registriert in", //WIFISC_AP_PROXY_PROCESS_COMPLETE
	"Aufzeichnung %s' ist ein Duplikat von %s'.", //GW_NAT_ENTRY_DUPLICATED_INVALID
	"Konflikt zwischen %s' [%s:%s] und %s'[%s:%s] durch abweichende IP-Adressen", //GW_NAT_PORT_FORWARD_CONFLICT_INVALID
	"Möchten Sie die Aktualisierung wirklich durchführen", //YM38
	"Der NTP-Server ist nicht konfiguriert.", //tt_alert_nontp
	"WPS (Wi-Fi Protected Setup)", //LY2
	"Ungültige PIN (1. Hälfte) erkannt", //KR29
	"Sitzung beendet", //KR31
	"Init fehlgeschlagen", //_init_fail
	"Der Wert für den Quell-Start-Port muss zwischen 0 und einschließlich 65535 liegen.", //YM68
	"MAC-Adresse", //sd_macaddr
	"WAN-Port-Modus", //KR12
	"Ein Verfahren zur Verschlüsselung von Daten in der drahtlosen Kommunikation, das den gleichen Grad an Datenschutz bieten soll wie in einem herkömmlichen kabelgebundenen Netzwerk. Die WEP-Verschlüsselung ist weniger sicher als die WPA-Verschlüsselung. Um Zugriff auf ein WEP-Netzwerk zu erhalten, muss der Schlüssel bekannt sein. Bei dem Schlüssel handelt es sich um eine Zeichenfolge, die Sie selbst erstellen. Bei der Verwendung von WEP müssen Sie die Verschlüsselungsstufe selbst angeben. Der Verschlüsselungstyp bestimmt dabei die Länge des Schlüssels. Eine 128-Bit-Verschlüsselung erfordert demzufolge einen längeren Schlüssel als eine 64-Bit-Verschlüsselung. Die Schlüssel werden durch Eingabe einer Zeichenfolge im HEX-Format (hexadezimal – die Zeichen 0-9 und A-F) oder im ASCII-Format (American Standard Code for Information Interchange – alphanumerische Zeichen) festgelegt. Das ASCII-Format ermöglicht hier die Eingabe einer Zeichenfolge, die sich einfacher merken lässt. Für die Verwendung im Netzwerk wird die eingegebene ASCII-Zeichenfolge in das HEX-Format konvertiert. Es können bis zu vier Schlüssel angegeben werden, so dass die Schlüssel schnell und einfach geändert werden können. Für die Verwendung im Netzwerk wird ein Standardschlüssel ausgewählt.", //help366
	"AP wurde beim Registrator (%s) über %s registriert", //WIFISC_AP_REGISTRATION_COMPLETE
	"TPC Max. Verstärkung", //aw_TPC
	"WDS AP-MAC-Adresse", //aw_WDSMAC
	"Der Wert für den Remote-End-Port muss zwischen 0 und einschließlich 65535 liegen.", //YM62
	"Besonderer Schutz für benachbarte drahtlose Netzwerke, die nach dem Standard 802.11b arbeiten. Deaktivieren Sie diese Funktion, um negative Einflüsse älterer drahtloser Netzwerke auf die Leistung der nach 802.11ng arbeitenden Netzwerke zu verringern.", //aw_erpe_h
	"Ungültiger Wiederverbindungsmodus", //GW_WAN_RECONNECT_MODE_INVALID
	"DelAPSettings durch (%s) abgeschlossen", //WIFISC_AP_DEL_APSETTINGS_COMPLETE
	"Die Sicherheitseinstellungen können nur über das Konto 'Administrator' geändert werden.", //LW15
	"Wenn Sie mit der Netzwerk- und Routerkonfiguration noch nicht vertraut sind, klicken Sie auf die Schaltfläche <strong>Assistent für die Einrichtung des Internetzugangs</strong>. Mit Hilfe des Assistenten können Sie Ihr Netzwerk Schritt für Schritt auf einfache Weise betriebsbereit machen.", //LW33
	"Der Vorgang wurde erfolgreich ausgeführt. Um ein weiteres Gerät hinzuzufügen, klicken Sie unten auf die Schaltfläche 'Abbrechen. Klicken Sie auf die Schaltfläche 'WLAN-Status, um den Status der drahtlosen Verbindung zu überprüfen.", //KR27
	"Überprüfung der Endpunktfilterung von UDP-Protokolldaten", //YM138
	"Konflikt zwischen %s' [%s:%d]->%v/%d und %s' [%s:%d]->%v:%d.", //GW_NAT_VS_PORT_CONFLICT_INVALID
	"Primäre IP-Adresse des WINS-Servers", //bd_NETBIOS_WINS_1
	"Schritt 5: Sentinel-Kategorien", //_aa_wiz_s6_title
	"WISH-Regeln", //YM77
	"QoS-Engine", //YM48
	"Ungültige IP-Adresse für Reservierung", //YM89
	"Der vorinstallierte Schlüssel darf bei einer Länge von 64 Zeichen ausschließlich aus Hexadezimalzeichen bestehen.", //GW_WLAN_WPA_PSK_HEX_STRING_INVALID
	"Ungültige WAN-IP-Adresse: %v", //GW_WAN_WAN_IP_ADDRESS_INVALID
	"Möchten Sie alle auf dieser Seite vorgenommenen Änderungen verwerfen?", //LS4
	"Der angegebene Anbieter der dynamischen DNS wird nicht unterstützt.", //KR98
	"Hintergrund (geringe Dringlichkeit).", //YM148
	"Auto (WPA oder WPA2)", //bws_WPAM_2
	"Wenn Sie bei Freigabe einer neuen Firmware eine Benachrichtigung erhalten möchten, aktivieren Sie das Kontrollkästchen <span class='option'>E-Mail-Benachrichtigung bei neuer Firmware-Version</span>.", //help877a
	"Hinzufügen/Aktualisieren", //KR56
	"Hostname", //LS424
	"Die DHCP-Server-Adresse %v wurde vom Netzwerkgerät abgelehnt. Überprüfen Sie, ob in Ihrem Netzwerk ein IP-Adressenkonflikt vorliegt.", //GW_DHCPSERVER_DECLINED
	"Es wurde kein Tag ausgewählt", //GW_SCHEDULES_DAY_INVALID
	"UDP", //GW_NAT_UDP
	"Es kann keine Verbindung zum E-Mail-Server aufgebaut werden", //IPSMTPCLIENT_CANNOT_CREATE_CONNECTION
	"Alle überprüfen", //_aa_check_all
	"Aktualisieren", //LS312
	"Ungültige IP-Adresse", //KR2
	"Protokoll", //_vs_proto
	"Die angegebene TO-Adresse (%s) ist ungültig", //GW_SMTP_TO_ADDRESS_INVALID
	"Der AP konnte vom Registrator (%s) nicht über %s registriert werden, Ursache (%s), Fehlercode (%u)", //WIFISC_AP_REGISTRATION_FAIL
	"Der Name '%s' wird bereits verwendet.", //GW_WISH_RULES_NAME_ALREADY_USED
	"Wenn eine Internetsitzung durch eine LAN-Anwendung gestartet wird, die ein anderes Protokoll als UDP, TCP oder ICMP verwendet, vermittelt der Router-NAT die Sitzung, auch wenn das Protokoll von ihm nicht erkannt wird. Diese Funktion ist für die Aktivierung bestimmter Anwendungen nützlich (hauptsächlich eine einfache VPN-Verbindung zu einem Remote-Host), ohne dass ein ALG benötigt wird.", //LW48
	"Ungültige Remote-Start-IP-Adresse.", //YM54
	"Aktuelle PIN", //LW9
	"Mit Hilfe dieses Assistenten können Sie Ihr drahtloses Netzwerk einrichten. Der Assistent gibt Ihnen Schritt für Schritt Anweisungen zur Einrichtung und Sicherung des drahtlosen Netzwerks.", //LW41
	"Aktivieren Sie Auto Kanal Suche", //ebwl_AChan
	"Die RTS-Schwelle muss zwischen 1 und 2347 liegen.", //GW_WLAN_RTS_THRESHOLD_INVALID
	"Ein L2TP-Kennwort MUSS angegeben werden", //GW_WAN_L2TP_PASSWORD_INVALID
	"Einige Konfigurationsänderungen wirken sich auf andere Systemeinstellungen aus. Diese Änderungen könnten negative Auswirkungen haben und Warnungen auslösen, über die Sie informiert werden müssen. Eine Warnung kann darauf hindeuten, das eine Funktion geändert oder sogar deaktiviert wurde, um neuen Betriebsbedingungen zu entsprechen.", //YM12
	"Der Benutzer wird abgemeldet", //ZM14
	"In diesem Fall bezieht sich der Begriff 'Port' auf die Ethernet-Anschlüsse des Geräts.", //KR60
	"Ungültige RTS-Schwelle", //YM28
	"Der Zeitplan ist ungültig.", //YM184
	"Wenn Sie den webbasierten Assistenten nutzen möchten, um die Microsoft Windows Connect Now-Technologie zu konfigurieren, klicken Sie unten auf die Schaltfläche 'Setup-Assistent'.", //int_intro_WCNWz7
	"Gemeinsamer Schlüssel", //bws_Auth_2
	"Die wiederhergestellte Konfigurationsdatei ist ungültig. Die wiederhergestellte Datei ist möglicherweise beschädigt oder nicht für dieses Gerät vorgesehen.", //rs_intro_1
	"Das von den Nachrichten verwendete Protokoll.", //help92
	"Beides", //GW_NAT_BOTH
	"Erfolgreiche Wiederherstellung", //rs_success
	"(GMT+01:00) Budapest, Wien, Prag, Warschau", //up_tz_29b
	"Tag", //day
	"<warn>Der DHCP-Server wird deaktiviert, da das LAN-Subnetz nicht geeignet ist</warn>", //GW_DHCP_SERVER_DISABLED_WARNING
	"Kennwort", //_password
	"Ungültige MAC-Adresse %m.", //GW_INET_ACCESS_POLICY_MAC_INVALID
	"WPS (Wi-Fi Protected Setup)", //LW2
	"Weisen Sie eine noch nicht verwendete IP-Adresse zu, die im Bereich der für das LAN verfügbaren IP-Adressen liegt.", //KR75
	"Die Konfigurationsdatei konnte nicht erstellt werden: %s", //GW_XML_CONFIG_WRITE_FAILED
	"WISH aktivieren", //YM73
	"Der Name '%s' wird bereits verwendet.", //GW_WISH_RULES_NAME_USED_INVALID
	"Der DHCP-Serverpool ist zu groß für das LAN-Subnetz %v.", //GW_DHCP_SERVER_POOL_SIZE_IN_SUBNET_INVALID
	"Maximale Größe der Bündelung", //aw_AS
	"Dies ist eine Liste aller aktiven Verbindungen über drahtlose Clients im lokalen Netzwerk.", //YM171
	"Konflikt zwischen reservierter IP %v und konfigurierter LAN-IP-Adresse", //GW_DHCP_SERVER_RESERVED_IP_NOT_LAN_IP_INVALID
	"Der virtuelle Server %s' kann den HTTP-WAN-Administrationsport des Routers %u nicht verwenden.", //GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT
	"Das Feld 'Netzmaske' dient der Identifizierung des Anteils der verwendeten Ziel-IP-Adressen.", //hhav_r_netmask
	"LISTE DER VIRTUELLEN SERVER", //vs_vslist
	"IPv6-FIREWALL", //if_iflist
	"Beachten Sie, dass die Verwendung einiger dieser Optionen Auswirkungen auf andere Portbeschränkungen haben kann. Die endpunktunabhängige Filterung hat Vorrang vor Filtern oder Zeitplänen für eingehende Daten. Der Eingang von abgefragten Datenpaketen kann deshalb direkt über einen Port statt über einen vorgeschalteten aktiven Filter für eingehenden Verkehr erfolgen. Datenpakete an Ports, die durch einen Zeitplan oder einen Filter für eingehenden Verkehr gesperrt sind, werden jedoch zurückgewiesen. Die port- und adressenbeschränkte Filterung stellt sicher, dass Filter für eingehenden Datenverkehr und Zeitpläne genau funktionieren. Allerdings wirkt sich ihre Verwendung auf die Verbindung aus, weshalb mit Hilfe von Porttriggern, virtuellen Servern oder Portweiterleitungen die von der Anwendung benötigten Ports geöffnet werden müssen. Mit der adressenbeschränkten Filterung werden Kommunikationsprobleme mit verschiedenen anderen NAT-Routertypen, besonders den symmetrischen, vermieden. Gleichzeitig wird kontrolliert, dass die Filter für eingehenden Verkehr und Zeitpläne wie vorgesehen funktionieren.", //YM137
	"Prioritäts-Zuweisungsfunktionen", //YM74
	"Die IP-Adresse %v des Syslog-Servers liegt nicht im LAN-Subnetz.", //GW_SYSLOG_ADDRESS_IN_SUBNET_INVALID
	"Aktivieren Sie diese Option, wenn Sie einen Syslog Server im LAN verwenden und die Log-Dateien auf diesem speichern möchten.", //help858
	"Diese MAC-Adresse wird bereits verwendet: %s", //GW_MAC_FILTER_MAC_UNIQUENESS_INVALID
	"Taste", //KR40
	"Der Filter für MAC-Adressen darf keine Nulladresse sein: %m", //GW_MAC_FILTER_NULL_MAC_INVALID
	"32 KB", //aw_32
	"Konflikt zwischen WAN-Subnetz und LAN-Subnetz", //GW_WAN_LAN_SUBNET_CONFLICT_INVALID
	"Aktiviert/Konfiguriert", //LW66
	"DelAPSettings durch (%s) fehlgeschlagen, Ursache (%s), Fehlercode (%u)", //WIFISC_AP_DEL_APSETTINGS_FAIL
	"(13 Zeichen oder 26 Hexadezimalzeichen)", //wwl_wsp_chars_1
	"WINS-Server speichern Daten bezüglich Netzwerk-Hosts und ermöglichen diesen, sich selbst zu registrieren und andere verfügbare Hosts (z. B. für die Verwendung in Netzwerkumgebungen) zu erkennen.", //KR85
	"Ungültige MTU-Größe", //YM115
	"Portbereich von Host 1", //YM83
	"128 Bits", //wwl_128bits
	"Wenn zu viele Kollisionen von WLAN-Datenpaketen auftreten, kann die Leistung des drahtlosen Netzwerks mit Hilfe des RTS/CTS (Request to Send/Clear to Send)-Handshake-Protokolls erhöht werden.", //LW51
	"Sie müssen einen Wert zwischen 0 und einschließlich 8760 eingeben.", //YM178
	"Sekten", //_aa_bsecure_cults
	"Nicht zulässig", //YM5
	"Suche nach Firmware-Aktualisierungen", //KR65
	"Es sind regelmäßig Firmware-Aktualisierungen verfügbar. Durch sie wird die Funktionalität des Routers verbessert, und es können zusätzliche Funktionen hinzugefügt werden. Wenn ein Problem mit einer bestimmten Funktion des Routers auftritt, überprüfen Sie, ob eine aktualisierte Firmware für Ihren Router verfügbar ist.", //ZM17
	"<strong>Aktivieren</strong>, wenn andere drahtlose Geräte, die Sie an Ihr lokales Netzwerk anschließen möchten, Wi-Fi Protected Setup unterstützen.", //LW14
	"In Windows Connect Now speichern", //ta_wcn_bv
	"Der virtuelle Server %s' kann die IP-Adresse des Routers %v nicht verwenden.", //GW_NAT_VS_IP_ADDRESS_CAN_NOT_MATCH_ROUTER
	"Der Zeitplan '%s' kann nicht nicht gelöscht oder umbenannt werden, weil er verwendet wird.", //GW_SCHEDULES_IN_USE_INVALID
	"WEP-Schlüssel 3", //wepkey3
	"Schätzung der Internet-Übertragungsrate", //KR69
	"AIM Talk", //YM43
	"ICQ", //YM45
	"Ungültiger Benutzername", //GW_SMTP_USERNAME_INVALID
	"Super-G mit statischem Turbo", //help362
	"Wenn Sie bei Freigabe einer neuen Firmware eine Benachrichtigung erhalten möchten, aktivieren Sie das Kontrollkästchen 'E-Mail-Benachrichtigung bei neuer Firmware-Version'.", //tf_intro_FWChA
	"REMOTE-DESKTOP", //_remotedesktop
	"PIN-Einstellungen", //LW7
	"Bei Super-G-Turbo-Modi muss Kanal 6 zur Kommunikation verwendet werden. Für Super-G mit statischem Turbo muss der <span class='option'>802.11-Modus</span> auf 802.11g eingestellt sein. Für einen ordnungsgemäßen Betrieb sollten sowohl für die RTS-Schwelle als auch für die Fragmentierungsschwelle auf dem Bildschirm <a href='adv_wlan_perform.asp'>Erweitert &rarr; Erweitertes WLAN</a> die jeweiligen Standardwerte eingestellt sein.", //help359
	"Konfigurieren Sie die IP-Adresse des gewünschten WINS-Servers.", //KR84
	"Der DTIM-Wert sollte zwischen 1 und 255 liegen.", //YM30
	"Lokaler Portbereich", //at_LoPortR
	"Der DHCP-Serverpool von %v liegt nicht im LAN-Subnetz %v.", //GW_DHCP_SERVER_POOL_FROM_IN_SUBNET_INVALID
	"Der Filter für MAC-Adressen darf kein Multicast-Adressformat haben: %m", //GW_MAC_FILTER_MULTICAST_MAC_INVALID
	"<warn>E-Mail-Initialisierung fehlgeschlagen</warn>", //GW_SMTP_INIT_FAILED_WARNING
	"DHCP-Server wurde angehalten", //GW_DHCPSERVER_STOP
	"Zum Schutz Ihrer Privatsphäre können Sie die Sicherheitsfunktionen für das drahtlose Netzwerk mit Hilfe des WLAN-Sicherheitsmodus konfigurieren. Dieses Gerät unterstützt die folgenden Sicherheitsmodi für drahtlose Netzwerke: WEP, WPA-Personal und WPA-Enterprise. WEP ist der ursprüngliche Verschlüsselungsstandard für drahtlose Verbindungen. Mit WPA erreichen Sie einen höheren Sicherheitsstandard. WPA-Personal kann ohne Authentifizierungsserver verwendet werden. Zur Verwendung von WPA-Enterprise ist ein RADIUS-Authentifizierungsserver notwendig.", //help350
	"Die DMZ-Adresse %v ist unzulässig.", //GW_NAT_DMZ_NOT_ALLOWED_INVALID
	"Wenn diese Option aktiviert ist, versucht der Router automatisch, Datenverkehrsströme zu bevorzugen, die er anderenfalls nicht erkennt. Dies erfolgt auf Basis des jeweiligen Datenstromverhaltens. Dies dient zum abwerten von Datenströmen, die Blockübertragungseigenschaften aufweisen, wie z. B. Dateiübertragungen, während interaktiver Datenverkehr wie z. B. Spiele oder VoIP mit normaler Priorität laufen.", //YM143
	"Import der Konfigurationsdatei GW_NAT_PORT_DUP_INVALID,%s '%s' von '%s' darf keine doppelten Zahlen enthalten.", //GW_XML_CONFIG_SET_FAILED
	"%s '%s' von '%s' sollte keine duplizierten Zahlen enthalten.", //GW_NAT_PORT_DUP_INVALID
	"Sekunden für die Verbindung Ihres drahtlosen Geräts. Wenn Sie den Vorgang stoppen möchten, klicken Sie unten auf 'Abbrechen'.", //KR46
	"Schritt 1: Wählen Sie die Konfigurationsmethode für Ihr drahtloses Netzwerk.", //KR35
	"Legen Sie ein Big Pond-Kennwort fest.", //GW_WAN_BIGPOND_PASSWORD_INVALID
	"Legen Sie das Protokoll fest.", //YM57
	"Starten Sie den Router neu, damit die neuen Einstellungen übernommen werden. Sie können entweder jetzt neu starten oder weitere Änderungen durchführen und später neu starten.", //KR104
	"das Format der Absender-E-Mail-Adresse ist falsch", //IPSMTPCLIENT_MSG_WRONG_SENDER_ADDR_FORMAT
	"ABMELDEN", //LS317
	"Die eingegebenen Kennwörter stimmen nicht überein.", //YM102
	"Wenn WDS (Wireless Distribution System) aktiviert ist, fungiert dieser AP (Access Point) als drahtloser Repeater und ist in der Lage, mit anderen APs drahtlos über WDS-Links zu kommunizieren. Zu beachten ist, dass WDS nicht mit WPA kompatibel ist - es können nicht beide Funktionen gleichzeitig verwendet werden. Ein WDS-Link ist bidirektional; dieser AP muss also die MAC-Adresse (sie erstellt den WDS-Link) des anderen AP kennen und der andere AP muss über einen WDS-Link zurück zu diesem AP verfügen.", //help188
	"Ungültige IP-Adresse", //_logsyslog_alert1
	"Ungültige MAC-Adresse", //KR3
	"Hass", //_aa_bsecure_hate
	"Kann den 802.11a-Kanal im Modus 802.11b/g nicht verwenden.", //GW_WLAN_11BG_CHANNEL_INVALID
	"Ratenschätzung abgeschlossen", //RATE_ESTIMATOR_RATE_COMPLETED
	"Der WEP-Schlüssel muss genau 26 Hexadezimalzeichen (0-9 oder A-F) enthalten.", //wwl_alert_pv5_3
	"Bündelungsgrenze", //aw_aggr
	"Der Vorgang wurde gestartet", //_wifisc_addstart
	"Legt die Schnittstelle (LAN oder WAN) fest, die das IP-Paket verwenden muss, um bei Verwendung dieser Route den Router zu verlassen.", //help111
	"%s': Die Remote-Start-IP '%v' liegt im LAN-Subnetz", //GW_QOS_RULES_REMOTE_IP_START_SUBNET
	"Ungültiger letzter Zielport für Portfilter", //YM22
	"Es kann keine Multicast-MAC-Adresse für WDS verwendet werden.", //GW_WLAN_WDS_MAC_ADDR_INVALID
	"PIN auf Standardwert zurücksetzen", //LW10
	"In diesem Bereich des Bildschirms werden die Konfigurationseinstellungen der Seite <a href='wireless.asp'>Setup &rarr; WLAN-Einstellungen</a> angezeigt. Die <span class='option'>MAC-Adresse</span> ist die Anbieter-Kennung der WLAN-Karte.", //LT291
	"In diesem Bereich können Sie die WISH-Regeln festlegen.", //YM156
	"Jugendliche (9-12)", //_aa_bsecure_age_ado
	"Wählen Sie diese Option, wenn Ihre drahtlosen Adapter WPA nicht unterstützen.", //wwl_text_good
	"%s': die Priorität %d muss zwischen 1 und 255 liegen", //GW_QOS_RULES_PRIORITY_RANGE
	"Nach Zeitplan", //te_OnSch
	"Webmail", //_aa_bsecure_web_mail
	"Stellen Sie sicher, dass die APs mit derselben Kanalnummer konfiguriert werden.", //help188b
	"Die Start-IP-Adresse (%v) von '%s' darf nicht innerhalb des LAN-Subnetzes (%v) liegen.", //GW_INET_ACL_START_IP_ADDRESS_IN_LAN_SUBNET_INVALID
	"WAN-Traffic-Shaping", //at_title_Traff
	"Legt eine Hälfte der WDS-Verbindung fest. Der andere AP muss dieselbe MAC-Adresse haben wie dieser AP, um wiederum eine WDS-Verbindung zurück zu diesem AP herstellen zu können.", //help189
	"Es wurde ein drahtloser Radar erkannt; wechseln Sie zum Kanal %d.", //GW_WIRELESS_SWITCH_CHANNEL
	"Legen Sie einen Big Pond-Server fest.", //GW_WAN_BIGPOND_SERVER_INVALID
	"Syntaxfehler der Konfigurationsdatei bei Verbindung %u, Zeichen %u", //GW_XML_CONFIG_SET_PARSE
	"Das Aktivieren von <strong>WMM</strong> kann bei der Einstellung von Unterbrechungen und dem Flimmern helfen, wenn Multimediainhalte über eine drahtlose Verbindung übertragen werden.", //hhaw_wmm
	"Dieser Bildschirmbereich spiegelt die Konfigurationseinstellungen von der Seite <a href=\"wireless.asp\">Setup &rarr; Einstellungen für drahtlose Netzwerke </a> und <a href=\"adv_wish.asp\">Erweitert &rarr; WISH</a> und der Seite <a href=\"../Advanced/Protected_Setup.shtml\">Erweitert &rarr; Wi-Fi Protected Setup</a> wieder. Die <span class=\"option\">MAC-Adresse</span> ist die werkseitig zugewiesene ID der Funkkarte.", //LT290wifisc
	"Der Regelname darf nicht leer sein.", //GW_FIREWALL_RULE_NAME_INVALID
	"Zeitplan", //GW_NAT_SCHEDULE
	"Gibt den nächsten Punkt (Hop) an, der bei Verwendung dieser Route angesprungen wird. Wenn die Adresse 0.0.0.0 als Gateway verwendet wird, bedeutet dies, dass es keinen nächsten Hop gibt und die passende IP-Adresse direkt mit dem Router auf der angegebenen Schnittstelle verbunden ist: LAN oder WAN.", //help109
	"Ungültiger RIP-Modus", //GW_LAN_RIP_MODE_INVALID
	"Der drahtlose Sender sendet RTS-Frames (und wartet auf CTS), wenn die Größe des Daten-Frames in Byte größer ist als die der RTS-Schwelle.", //LW52
	"Popups", //_aa_bsecure_popups
	"Der Modus &quot;Nur WPA2&quot; unterstützt kein TKIP.", //GW_WLAN_WPA_WPA2_TKIP_INVALID
	"2.4 GHz", //KR16
	"Virtueller Server", //_vs_title
	"IPv6 FIREWALL", //_if_title
	"Legen Sie einen PPPoE-Benutzernamen fest.", //GW_WAN_PPPOE_USERNAME_INVALID
	"Ungültige PPTP-Subnetzmaske %v", //GW_WAN_PPTP_SUBNET_INVALID
	"Das Format des NetBIOS-Bereichs ist ungültig", //GW_DHCP_SERVER_NETBIOS_SCOPE_INVALID
	"Da der Modus 'Statische IP' immer aktiviert ist, gibt es keine Aktivierungstaste.", //KR94
	"WISH", //YM63
	"Gateway", //help108
	"Dieser Zeitplan wird bereits für %s' verwendet.", //GW_SCHEDULES_DUPLICATED_INVALID
	"Nur WPA", //bws_WPAM_1
	"Öffentlicher Port muss für virtuellen Server im Bereich (1..65535) sein", //KR11
	"Wenn sich in Ihrem Netzwerk bereits ein DHCP-Server befindet oder Sie für alle Geräte im Netzwerk statische IP-Adressen verwenden, deaktivieren Sie das Kontrollkästchen für die Option <strong>DHCP-Server aktivieren </strong>.", //LW45
	"Remote-IP-Ende", //KR6
	"Ungültige NetBIOS-Registrierungsart", //GW_DHCP_SERVER_NETBIOS_TYPE_INVALID
	"Spiele", //_aa_bsecure_games
	"Wählen Sie diese Option, wenn Sie Ihr drahtloses Gerät manuell konfigurieren möchten", //KR42
	"Ungültige Leerlaufzeit", //YM104
	"Tickets", //_aa_bsecure_tickets
	"Wählen Sie diese Option, wenn Ihr drahtloses Gerät PIN unterstützt", //KR39
	"Gemischter Modus (Broadcast, anschließend Point-to-Point)", //bd_NETBIOS_REG_TYPE_M
	"Geben Sie einen Hostnamen oder eine IP-Adresse oben ein und klicken Sie auf 'Ping'.", //tsc_pingt_msg1
	"Der Eintrag %v <-> %v:%d %s wurde von UPnP gelöscht", //GW_UPNP_IGD_PORTMAP_DEL
	"Ungültige L2TP-Gateway-IP-Adresse", //YM111
	"Trennen", //LS315
	"Ungültige Schlüssellänge; der Schlüssel muss aus 8 bis 64 Zeichen bestehen.", //GW_WLAN_WPA_PSK_LEN_INVALID
	"Allen WAN-Nutzern Zugriff auf die zugehörigen Funktionen genehmigen.", //help178
	"Die Liste der aktiven Sitzungen wird abgerufen. Bitte haben Sie einen Moment Geduld", //YM167
	"128-Bit-ASCII-Schlüssel bestehen aus bis zu 13 Zeichen (2002HALOSWIN1ist eine gültige Folge aus 13 Zeichen für eine 128-Bit-Verschlüsselung.)", //help371
	"Anarchie", //_aa_bsecure_anarchy
	"Später neu starten", //YM4
	"Kriminelle Methoden", //_aa_bsecure_criminal_skills
	"Es wurden Warnmeldungen ausgegeben aufgrund von Konfigurationsänderungen.\nDas System kann momentan keine Liste dieser Warnmeldungen erstellen und wiederholt den Vorgang.", //YM188
	"Über die Endpunktfilteroptionen für den NAT (Netzwerkadressübersetzer) wird kontrolliert, wie der Router-NAT mit Verbindungsanfragen an belegte Anschlüsse verfährt.", //YM133
	"Der Wert für den ersten lokalen Port muss zwischen 0 und einschließlich 65535 liegen.", //YM59
	"Manuell", //_aa_bsecure_manually
	"Die E-Mail-Adresse ist nicht konfiguriert.", //YM169
	"In diesem Abschnitt können Sie die Router-Einstellungen für das interne Netzwerk vornehmen. Mit der hier eingerichteten IP-Adresse greifen Sie auf das webbasierte Verwaltungsprogramm zu. Wenn Sie diese IP-Adresse ändern, müssen Sie unter Umständen die Netzwerkeinstellungen der PCs anpassen, um weiterhin auf das Netzwerk zuzugreifen.", //YM97
	"Kinder (0-8)", //_aa_bsecure_age_child
	"WPA ist der ältere Standard. Wählen Sie diese Option, wenn die zusammen mit dem Router verwendeten Clients nur diesen Standard unterstützen. WPA2 ist die neueste Version des höheren Sicherheitsstandards IEEE 802.11i. Bei der Option 'WPA2' wählt der Router zunächst WPA2. Wird dieser Standard nicht vom Client unterstützt, wird automatisch WPA verwendet. Bei der Option 'Nur WPA2' stellt der Router nur Verbindungen zu Clients her, die WPA2 unterstützen.", //help375
	"Die Website-Adresse %s' ist ungültig.", //GW_WEB_FILTER_WEBSITE_INVALID_INVALID
	"Woche", //ZM21
	"Internet-Sitzungen", //YM157
	"Das WCN ActiveX-Steuerelement aktiviert die WCN-Verbindung zwischen Ihrem PC und dem Router. Dies erfolgt über den Browser, der drahtlose Konfigurationsdaten ohne USB-Flash-Laufwerk überträgt. Der Browser versucht, das WCN ActiveX-Steuerelement herunterzuladen, wenn das Programm noch nicht auf Ihrem PC vorhanden ist. Um diesen Vorgang erfolgreich durchzuführen, müssen Sie über eine WAN-Verbindung verfügen und die Sicherheitseinstellungen Ihres Internet-Browsers auf &quot;Mittel&quot; oder niedriger stellen (Wählen Sie Extras &rarr; Internetoptionen &rarr; Sicherheit &rarr; Standardstufe &rarr; Mittel).", //help213
	"Möchten Sie wirklich aktivieren/deaktivieren?", //YM24
	"PBC (Push Button Configuration, Tastenkonfiguration)", //wps_p3_3
	"Wenn Ihr drahtloses Netzwerk mit Wi-Fi Protected Setup eingerichtet wurde, führt eine manuelle Konfiguration des drahtlosen Netzwerks zu Beschädigungen Ihres bestehenden drahtlosen Netzwerks.", //LW43
	"In diesem Bereich können Sie die QoS-Engine-Regeln festlegen.", //help99_s
	"Ungültige Reservierungs-MAC-Adresse", //YM90
	"TKIP und AES", //bws_CT_3
	"Beachten Sie, dass bei Eingabe von weniger Zeichen als für den WEP-Schlüssel erforderlich für alle verbleibenden Stellen automatisch Nullen festgelegt werden.", //help371_n
	"<warn>Eine DHCP-Reservierung %v wurde zu %v neu konfiguriert. Überprüfen Sie, ob dies den Anforderungen Ihres Netzwerks entspricht.</warn>", //GW_DHCP_SERVER_RESERVATION_RECONFIG_WARNING
	"Ungültiger Gateway für Route", //_r_alert3
	"Ungültiger RIP-Metrikwert", //GW_LAN_RIP_METRIC_INVALID
	"Das Aktualisierungsintervall für WPA-Gruppenschlüssel muss zwischen 30 und 65535 Sekunden liegen.", //YM118
	"Ungültige Gateway-Adresse", //YM127
	"StreamEngine", //KR71
	"WDS aktivieren", //aw_WDSEn
	"Unbekannte Nachricht empfangen", //KR32
	"Lokal", //sa_Local
	"Die Leerlaufzeit darf nicht Null sein.", //GW_WEB_SERVER_IDLE_TIME
	"Über diese Option wird überprüft, wie das Gerät auf Datenverkehr am WAN-Anschluss reagiert.", //KR59
	"Die WAN-Gateway-IP-Adresse %v muss innerhalb des WAN-Subnetzes liegen.", //GW_WAN_WAN_GATEWAY_IN_SUBNET_INVALID
	"Lokaler IP-Bereich", //at_LoIPR
	"Sprache (VO)", //YM81
	"Pakete mit Bündelungsnummern", //aw_AP
	"Dieser Bildschirmbereich spiegelt die Konfigurationseinstellungen von der Seite <a href=\"wireless.asp\">Setup &rarr; Einstellungen für drahtlose Netzwerke </a> und <a href ='adv_wish.asp'>Erweitert &rarr; WISH</a> wieder. Die <span class=\"option\">MAC-Adresse</span> ist die werkseitig zugewiesene ID der Funkkarte.", //LT290
	"Die Priorität, die Paketen zugewiesen wurde, die mit Hilfe der WISH-Logik drahtlos über diese Verbindung gesendet wurden. Die Prioritäten lauten:", //YM162
	"Syntaxfehler der Konfigurationsdatei (MIME)", //GW_XML_CONFIG_SET_PARSE_MIME
	"UDP-Port", //GW_NAT_UDP_PORT
	"Erfolgreich", //YM9
	"Ungültige MTU-Größe; der zugelassene Bereich liegt zwischen %u und %u", //GW_WAN_MTU_INVALID
	"Es gibt mehrere Möglichkeiten, ein drahtloses Gerät mit Ihrem Netzwerk zu verbinden. Der Zugang zum drahtlosen Netzwerk wird von einem 'Registrator' kontrolliert. Der Registrator stellt sicher, dass ein Gerät nur dann Zugang zum drahtlosen Netzwerk erhält, wenn Sie die PIN eingegeben haben oder eine spezielle Taste für Wi-Fi Protected Setup auf dem Gerät gedrückt haben. Der Router agiert als Registrator für das Netzwerk, jedoch könne auch andere Geräte diese Funktion übernehmen.", //LW63
	"Das Gerät %s (%m) wurde erfolgreich hinzugefügt.", //WIFISC_IR_REGISTRATION_SUCCESS
	"IP-Adresse der Pakete, die diese Route verwenden", //help105
	"Die DHCP-Server-Adresse %v wurde vom Netzwerkgerät freigegeben, da sie von diesem nicht mehr verwendet wird.", //GW_DHCPSERVER_RELEASED
	"Setup-Assistenten für den Drucker starten", //LW32
	"SetAPSettings durch (%s) fehlgeschlagen, Ursache (%s), err_code (%u)", //WIFISC_AP_SET_APSETTINGS_FAIL
	"Ungültige IP-Adresse für Route", //KR8
	"Im Feld 'Name' können Sie einen Namen für die Identifizierung dieser Route (z. B. 'Netzwerk 2') festlegen.", //hhav_r_name
	"Gemischter Modus (Point-to-Point , anschließend Broadcast)", //bd_NETBIOS_REG_TYPE_H
	"Solange keine eindeutige Zuordnung erfolgt, werden folgende Zusammenhänge zwischen der 'Cone'-Klassifizierung und den 'Endpunktfilterungs'-Modi hergestellt: Wenn dieser Router für die endpunktunabhängige Filterung konfiguriert ist, implementiert er das Cone-Verhalten vollständig. Die adressenbeschränkte Filterung implementiert beschränktes Cone-Verhalten. Die port- und adressenbeschränkte Filterung implementiert portbeschränktes Cone-Verhalten.", //KR55
	"Konflikt zwischen PPPoE-IP-Adresse %v und LAN-Subnetz", //GW_WAN_PPPOE_LAN_SUBNET_CONFLICT_INVALID
	"Die Konfigurationsdatei wurde erfolgreich importiert.", //GW_XML_CONFIG_SET_SUCCESS
	"Der Wert für den letzten lokalen Port muss zwischen 0 und einschließlich 65535 liegen.", //YM60
	"Speichern der Einstellungen fehlgeschlagen", //KR100
	"Wählen Sie diese Option, wenn der WAN-Port mit dem Internet verbunden ist. Das Gerät fungiert als NAT-Router.", //KR61
	"64 Bit (10 Hexadezimalzahlen)", //bws_WKL_0
	"Verwenden Sie den Modus <strong>WPA oder WPA2</strong>, um ein ausgewogenes Verhältnis zwischen hoher Sicherheit und optimaler Kompatibilität zu erreichen. Dieser Modus verwendet WPA für Legacy-Clients und gewährleistet höhere Sicherheit bei WPA2-fähigen Stationen. Zudem wird der wirksamste vom Client unterstützte Verschlüsselungstyp verwendet. Wählen Sie <strong>WPA2 Only</strong> zur höchsten Sicherheit. Dieser Modus nutzt den Verschlüsselungstyp AES (CCMP), und Legacy-Clients erhalten mit dem WPA-Sicherheitsmodus keinen Zugang. Wählen Sie <strong>WPA2 Only</strong> für eine bestmögliche Kompatibilität. Dieser Modus nutzt den TKIP-Verschlüsselungstyp. Manche Spiele- und Legacy-Geräte funktionieren nur in diesem Modus.", //bws_msg_WPA
	"Ungültige L2TP-IP-Adresse", //YM109
	"Zurücksetzen durch %s fehlgeschlagen, Ursache (%s), err_code (%u)", //WIFISC_AP_RESET_FAIL
	"'%s': Host 2-Start-Port %u muss niedriger als der Host 2-End-Port %u sein", //GW_WISH_RULES_HOST2_PORT
	"Einstellungen von lokaler Festplatte laden", //help_ts_ls
	"Ungültige WAN-Gateway-IP-Adresse", //YM101
	"Auto", //KR50
	"Protokoll muss eine Zahl sein.", //YM56
	"Website-URL/-Domäne", //aa_WebSite_Domain
	"Die maximale Übertragungsrate muss zwischen 8 kbit/s und einschließlich 100 Mbit/s liegen.", //GW_QOS_RULES_MAX_TRANS
	"'%s': Protokoll %d muss zwischen 0 und 257 liegen.", //GW_QOS_RULES_PROTOCOL
	"Mindestens eines der beiden Protokolle (HTTP und HTTPS) muss aktiviert sein.", //GW_WEB_SERVER_NO_ACCESS
	"Konfigurieren Sie die IP-Adresse des Backup-WINS-Servers, falls Sie einen solchen verwenden.", //KR87
	"'%s' ist ein Duplikat von '%s'", //GW_WISH_RULES_DUPLICATED
	"Die Ziel-IP-Start-Adresse sollte nicht im LAN-Subnetz sein", //YM16
	"Der Name '%s' wird bereits verwendet", //GW_SCHEDULES_NAME_CONFLICT_INVALID
	"WEP-Schlüssel 4", //wepkey4
	"HTTP und HTTPS können nicht denselben WAN-Port verwenden.", //GW_WEB_SERVER_SAME_PORT_WAN
	"Ungültige letzte Quell-IP-Adresse", //YM65
	"Netzwerk-Einstellungen", //bln_title
	"Registrierung von STA mit MAC (%m) fehlgeschlagen, Ursache (%s), err_code (%u)", //WIFISC_AP_PROXY_PROCESS_FAIL
	"Mehr", //_more
	"Anmeldung senden/empfangen", //ZM12
	"Banneranzeige", //_aa_bsecure_banner_ad
	"WLAN-Status", //LY23
	"Für die meisten Anwendungen ist die automatische Klassifizierung geeignet; spezielle QoS-Engine-Regeln sind nicht erforderlich.", //help88b
	"Indem mehrere lokale Datenströme gewählt werden, wird der Durchsatz erhöht, die Signalqualität jedoch möglicherweise verringert.", //bwl_NSS_h1
	"Hinweis: Schließen Sie maximal ein USB-Flash-Laufwerk an den Router an, auch bei Verwendung eines USB-Hub.", //help203
	"Für die Richtlinie %s wurde kein Gerät festgelegt.", //GW_INET_ACL_NO_MACHINE_IN_LAN_SUBNET_INVALID
	"Bevor Sie diese Assistenten starten, überprüfen Sie bitte, ob Sie alle beschriebenen Schritte aus der im Paket beiliegenden Schnellinstallationsanleitung durchgeführt haben.", //LW39c
	"Einrichtung des gewünschten Registrators abgeschlossen", //WIFISC_AP_SET_SELECTED_REGISTRAR_COMPLETE
	"Ungültiger DHCP-Client-Name", //GW_DHCP_CLIENT_CLIENT_NAME_INVALID
	"Abrufen der Liste mit aktiven Sitzungen fehlgeschlagen. Der Vorgang wird wiederholt", //YM166
	"Neustart durch %s fehlgeschlagen, Ursache (%s), err_code (%u)", //WIFISC_AP_REBOOT_FAIL
	"Die Priorität des Datenstroms wir hier eingetragen. 1 bedeutet höchste Priorität (besondere Dringlichkeit), 255 steht für die niedrigste Prioritätsstufe (geringe Dringlichkeit).", //help91
	"Die folgenden webbasierten Assistenten sollen Ihnen beim Einrichten Ihres drahtlosen Netzwerks und der Verbindung der drahtlosen Geräte behilflich sein.", //LW39
	"Das Kennwort und das bestätigte Kennwort stimmen nicht überein. Bestätigen Sie das Administrator-Kennwort.", //YM173
	"Es muss eine Name für die Port-Filterregel angegeben werden.", //YM13
	"Ihr Webbrowser ist nicht aktuell genug, um diese Website zu verwenden. Aktualisieren Sie Ihren Browser.", //YM172
	"Unzulässige maximale TPC-Verstärkung", //YM31
	"Wählen Sie die Überwachungskategorien für die Filterung.", //_aa_wiz_s6_msg
	"Kennwort darf nur druckbare Zeichen enthalten.", //S493
	"Portbereich von Host 2", //YM85
	"Das Feld \"Name\" darf nicht leer sein.", //GW_SCHEDULES_NAME_INVALID
	"Ungültiger Gateway", //LS204
	"16 KB", //aw_16
	"(Weitere Informationen finden Sie auf der Seite <a href='wireless.asp'> Setup &rarr; WLAN-Einstellungen &rarr; Manuelle Einrichtung von Drahtlosnetzwerken</a>.)", //aw_erpe_h3
	"Starten Sie den Assistenten.", //LW64
	"Tag(e)", //_days
	"Gibt an, ob der Eintrag aktiviert oder deaktiviert sein soll.", //help103
	"-", //YM183
	"Ungültiges Aktualisierungsintervall für Gruppenschlüssel", //YM117
	"Ursprünglich bezeichneten die Begriffe 'Full Cone', 'Restricted Cone', 'Port Restricted Cone' und 'Symmetric' die verschiedenen NAT-Typen. Diese Begriffe werden hier absichtlich nicht verwendet, da sie das NAT-Verhalten dieses Routers nicht vollständig wiedergeben.", //KR54
	"Auf dieser Routing-Seite können Sie benutzerdefinierte Routen festlegen, über die die Art der Datenübertragung in Ihrem Netzwerk bestimmt wird.", //av_intro_r
	"64-Bit-Hexadezimalschlüssel haben eine Länge von genau 10 Zeichen. (12345678FA ist ein gültiger String aus 10 Zeichen für eine 64-Bit-Verschlüsselung.)", //help368
	"Durch Aktivierung eines der Kontrollkästchen neben den Routen können Sie die entsprechende Route aktivieren.", //hhav_enable
	"Die DNS-Server müssen konfiguriert sein.", //GW_WAN_DNS_SERVERS_INVALID
	"Wiederherstellung erfolgreich", //_rs_succeeded
	"Ein PPTP-Benutzername MUSS festgelegt werden", //GW_WAN_PPTP_USERNAME_INVALID
	"Ungültige L2TP-IP-Adresse %v", //GW_WAN_L2TP_IP_ADDRESS_INVALID
	"Der Name darf keine leere Zeichenfolge sein.", //GW_INET_ACL_NAME_INVALID
	"Tage", //days
	"Das Feld steht für eine erweiterte Einstellung und bleibt normalerweise leer. Hier kann ein NetBIOS-'Domänenname' konfiguriert werden, unter dem Netzwerk-Hosts arbeiten.", //KR88
	"Ungültige PPPoE-IP-Adresse: %v", //GW_WAN_PPPOE_IP_ADDRESS_INVALID
	"Aus Sicherheitsgründen sollte der Name eine umfangreiche Länge haben und nicht zu gebräuchlich sein.", //KR19
	"Ratenschätzung abgeschlossen. Upstream-Geschwindigkeit ist %u KB/s", //RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED
	"Ungültiges Beacon-Intervall", //YM27
	"Dieser Bildschirmbereich spiegelt die Konfigurationseinstellungen der Seite <a href=\"wireless.asp\">Setup &rarr; Einstellungen für drahtlose Netzwerke </a> und <a href=\"../Advanced/Protected_Setup.shtml\">Erweitert &rarr; Wi-Fi Protected Setup</a> wieder. Die <span class=\"option\">MAC-Adresse</span> ist die werkseitig zugewiesene ID der Funkkarte.", //LT291wifisc
	"Port-Filtername", //KR1
	"Regel \'", //YM51
	"Heartbeat senden/empfangen", //ZM13
	"Ungültige primäre DNS", //GW_LAN_PRIMARY_DNS_INVALID
	"Turbo kann nicht im 11a-Modus verwendet werden.", //GW_WLAN_11A_DFS_TURBO_INVALID
	"Der erste Schritt zur Sicherung Ihres drahtlosen Netzwerks besteht darin, den Namen Ihres drahtlosen Netzwerks zu ändern. Wählen Sie einen geläufigen Namen, der keinerlei persönliche Informationen enthält.", //YM123
	"Wenn sich in Ihrem Netzwerk Geräte befinden, die eine feste IP-Adresse benötigen, fügen Sie für jedes dieser Geräte eine <strong>DHCP-Reservierung </strong> hinzu.", //TA8
	"Ungültige IP-Adresse für virtuellen Server", //KR9
	"Zum Beispiel: 192.168.0.1.", //KR79
	"%s' Ferne IP-Startadresse, '%v', Wert muss niedriger sein als die ferne IP-Endadresse, '%v'", //GW_QOS_RULES_REMOTE_IP
	"Erwachsene (über 18)", //_aa_bsecure_age_adult
	"Nicht initialisiert", //ZM7
	"Ziel-Port-Start sollte nicht größer sein als Ziel-Port-Ende für den Portfilter", //YM23
	"Hinweis: Einige Firmware-Aktualisierungen setzen die Konfigurationsoptionen des Routers auf die Werkseinstellungen zurück.\nSpeichern Sie daher die aktuelle Konfiguration auf dem Bildschirm Tools > System, bevor Sie eine Aktualisierung durchführen.\nMöchten Sie die Aktualisierung wirklich durchführen?", //tf_USSW
	"Aktivieren Sie die Funktion 'Wi-Fi Protected Setup'.", //LW55
	"Drahtlos aktivieren", //bwl_EW
	"Läuft ab", //LS425
	"WEP-Schlüssel", //wwl_WK
	"Neue PIN generieren", //LW11
	"<warn>Der PPTP-ALG wurde automatisch aktiviert, da ein von Ihnen erstellter virtueller Servereintrag dies benötigt.</warn>", //GW_NAT_PPTP_ALG_ACTIVATED_WARNING
	"Sind Sie sicher, dass Sie diesen Löschvorgang durchführen möchten", //YM35
	"Tag(e) wählen", //tsc_sel_days
	"Starten Sie den Router neu, damit die wiederhergestellten Einstellungen übernommen werden. Sie können entweder jetzt neu starten oder weitere Änderungen durchführen und später neu starten.", //sc_intro_rb4
	"Ungültige Zeit für Zeitplan-Name: '%s'", //GW_SCHEDULES_TIME_INVALID
	"Ungültige Ablaufzeit (Die Ablaufzeit muss zwischen 1 und 65535 liegen).", //GW_DHCP_SERVER_LEASE_TIME_INVALID
	"Die E-Mail konnte nicht gesendet werden, da die IP-Adresse des Servers nicht aufgelöst werden konnte.", //IPSMTPCLIENT_NO_SERVER_IP_ADDRESS
	"Privater Port muss für virtuellen Server im Bereich (1..65535) sein", //KR10
	"Das Protokoll HTTPS wird nicht unterstützt.", //GW_WEB_FILTER_HTTPS_NOT_SUPPORTED_INVALID
	"Die PIN des drahtlosen Geräts sollte aus entweder 4 oder 8 Ziffern bestehen", //KR22
	"Beides", //_vs_both
	"Das WLAN-Sicherheitskennwort muss aus mindestens 8 Zeichen bestehen.", //wwl_alert_pv5_4
	"Der AP darf vor der Konfiguration nicht gesperrt sein.", //GW_WIFISC_LOCK_VERIFY_ERR
	"Drahtlose Frames können in kleinere Einheiten (Fragmente) unterteilt werden, um die Leistung bei Funkstörungen sowie an den Grenzbereichen der Funkreichweite zu verbessern.", //LW53
	"Die Website-Adresse %s' wird bereits verwendet.", //GW_WEB_FILTER_WEB_SITE_IS_USED_INVALID
	"Ungültige erste Quell-IP-Adresse.", //YM64
	"Ungültige Schnittstelle für die Route", //GW_ROUTES_INTERFACE_INVALID
	"Ungültige sekundäre DNS.", //GW_LAN_SECONDARY_DNS_INVALID
	"NetBIOS über WAN abrufen", //bd_NETBIOS_LEARN_FROM_WAN_ENABLE
	"<warn>Die Portweiterleitungs-Tabelle wird neu konfiguriert, da das LAN-Subnetz geändert wurde.</warn>", //GW_NAT_PORT_FORWARDING_TABLE_RECONFIGURED_WARNING
	"802.11 Band", //KR15
	"Der AP konnte vom Registrator (%s) nicht über %s registriert werden, unerwartetes (%s), Status (%s).", //WIFISC_AP_REGISTRATION_UNEXPECTED_EVENT
	"<warn>Die IP-Adresse des Syslog-Servers liegt nicht mehr im LAN-Subnetz und muss eventuell neu konfiguriert werden.</warn>", //GW_SYSLOG_ADDRESS_NOT_IN_SUBNET_WARNING
	"Ungültige sekundäre WINS-IP-Adresse", //GW_DHCP_SERVER_NETBIOS_SECONDARY_WINS_INVALID
	"Beachten Sie, dass diese Funktion nicht bei DMZ-Hosts (sofern aktiviert) verfügbar ist. Der DMZ-Host behandelt stets diese Sitzungsart.", //LW49
	"Zeitplanregel hinzufügen/aktualisieren", //KR95
	"8 KB", //aw_8
	"Ungültige sekundäre DNS-Server-IP-Adresse", //YM114
	"Verschlüsselungstyp", //bws_CT
	"R-bewertet", //_aa_bsecure_rrated
	"Einstellungen für WLAN-Sicherheit sperren", //LW6
	"Sie können auch eine beliebige Textzeichenfolge in ein WEP-Schlüsselfeld eingeben. Diese wird anschließend mithilfe der ASCII-Werte der einzelnen Zeichen in einen Hexadezimalschlüssel umgewandelt. Für 64-Bit-Schlüssel können 5 Textzeichen eingegeben werden, für 128-Bit-Schlüssel 13 Zeichen.", //bws_msg_WEP_2
	"%s' Lokale IP-Startadresse, '%v', Wert muss niedriger sein als die lokale IP-Endadresse, '%v'", //GW_QOS_RULES_LOCAL_IP
	"Die Absender-Pool-IP-Adresse darf nicht größer sein als die Empfänger-Pool-IP-Adresse.", //GW_DHCP_SERVER_POOL_FROM_TO_ORIENTATION_INVALID
	"TKIP", //bws_CT_1
	"Sperren der Konfigurationsdatenbank fehlgeschlagen.", //GW_XML_CONFIG_SET_LOCK
	"Konflikt zwischen reservierter IP %v und einer anderen Reservierung", //GW_DHCP_SERVER_RESERVED_IP_UNIQUENESS_INVALID
	"WEP-Schlüssel 2", //wepkey2
	"Manuelles Einrichten der Internetverbindungsoptionen", //LW28
	"WEP-Schlüssel 1", //_wepkey1
	"Deaktivieren Sie diese Einstellung, um eine manuelle Konfiguration vorzunehmen.", //KR83
	"Ungültige IP-Adresse des Syslog-Servers.", //GW_SYSLOG_ADDRESS_INVALID
	"Ungültige PPTP-IP-Adresse", //YM105
	"DHCP-Client", //ZM5
	"WCN ActiveX-Steuerelement", //help212
	"Drücken Sie auf die Taste auf Ihrem drahtlosen Gerät und klicken Sie innerhalb von 120 Sekunden unten auf die Schaltfläche \"Verbinden\".", //wps_p3_5
	"Um ein weiteres Protokoll anzugeben, wählen Sie in der Liste die Option 'Andere'. Geben Sie anschließend die entsprechende Protokollnummer (<a href='http://www.iana.org/assignments/protocol-numbers' target='_blank'> wie von IANA zugewiesen</a>) in das Feld <span class='option'>Protokoll</span> ein.", //help19x2
	"Schritt 2: Drahtloses Gerät anschließen", //KR36
	"Ungültige Routen-Metrik %u. Die Routen-Metrik muss zwischen 1 und 16 liegen.", //GW_ROUTES_METRIC_INVALID
	"Das SSID-Feld darf nicht leer sein.", //GW_WLAN_SSID_INVALID
	"Ungültige IP-Adresse", //LS46
	"Der Timeout-Wert muss größer als Null sein.", //YM179
	"Die IP-Adresse des Routers im lokalen Netzwerk. Beispiel: 192.168.0.1", //KR78
	"Die Bridge sucht mit Hilfe des Upstream-Routers auf der Supportwebsite nach Aktualisierungen.", //KR66
	"Zeitschrift", //_aa_bsecure_magazine
	"Das Gerät ist möglicherweise ausgelastet. Der Empfang ist derzeit nicht möglich. Versuchen Sie erneut, die Einstellungen zu speichern.", //KR101
	"Der Modus 'Nur WPA unterstützt kein AES.'", //GW_WLAN_WPA_WPA_AES_INVALID
	"Eingehender Filter", //GW_NAT_INBOUND_FILTER
	"Das Feld 'Richtlinien-Name' darf nicht leer sein.", //GW_INET_ACL_POLICY_NAME_INVALID
	"Internet", //sa_Internet
	"Peer-to-Peer-Netzwerk zwischen Drahtlos-Clients.", //help406
	"Die Regel gilt für einen Nachrichtenfluss, für den die Portnummer von Host 1 innerhalb des hier eingestellten Bereichs liegt.", //YM153
	"Remote-IP-Bereich", //at_ReIPR
	"Ein oder mehrere Richtlinien für den Internetzugriff sind aktiv. Der Internetzugriff wird gemäß dieser Richtlinien eingeschränkt", //GW_INET_ACCESS_RESTRICTED
	"Der DTIM-Wert sollte zwischen 1 und 255 liegen.", //GW_WLAN_DTIM_INVALID
	"Eine WISH-Regel erkennt bestimmte Nachrichtenflüsse und weist diesen Prioritäten zu.", //YM144
	"(GMT+01:00) Amsterdam, Berlin, Bern, Rom, Stockholm", //up_tz_26
	"Wählen Sie einen Filter, der den für diese Regel benötigten Zugriff steuert. Finden Sie den gewünschten Filter nicht in der entsprechenden Liste mit Filtern, rufen Sie <a href='Inbound_Filter.asp'> Erweitert&nbsp;&rarr;&nbsp;Eingangsfilter</a> auf und erstellen Sie einen neuen.", //help71
	"Durch HNAP AddPortMapping wurde der %d. Eintrag für virtuellen Server von '%s' %v:%d<->%v:%d %S zu '%s' %v:%d<->%v:%d %S geändert.", //GW_PURE_ADDPORTMAPPING_MODIFY
	"Von Benutzer gestoppt", //tsc_pingt_msg10
	"Die IP-Adresse des Druckers und die TCP-Portnummer werden <a href='../Status/PS.shtml' onclick='return jump_if();'>hier</a> angezeigt.", //tps_foo
	"Durch HNAP AddPortMapping wurde der %d. Eintrag für virtuellen Server von '%s' %v:%d<->%v:%d %S zu %S geändert.", //GW_PURE_ADDPORTMAPPING_CHG_PROTOCOL
	"Nachricht oben %d Mal wiederholt", //LOG_PREV_MSG_REPEATED_N_TIMES
	"Das <b>Kennwort</b> wird zur Prüfung verwendet, dass Sie berechtigt sind, Änderungen an einem Gerät vorzunehmen. Sie finden das Kennwort auf dem Geräteetikett auf der Rückseite Ihres Gerätes.", //ca_intro
	"Es besteht ein Konflikt zwischen der über DHCP erkannten internetseitigen Adresse und der für das LAN gewählten Adresse. Die Internet-Verbindung bleibt so lange deaktiviert, bis Sie die LAN-seitige Adresse ändern und den Fehler beheben.", //GW_WAN_LAN_ADDRESS_CONFLICT_DHCP
	"In diesem Abschnitt werden die aktuellen Filter für eingehenden Datenverkehr aufgelistet. Sie können eine Filterregel für eingehenden Datenverkehr ändern, indem Sie auf das Symbol 'Bearbeiten' klicken. Um eine Regel zu löschen, klicken Sie auf das Symbol 'Löschen'. Wenn Sie auf das Symbol 'Bearbeiten' klicken, wird das Element hervorgehoben und der Abschnitt 'Filterregel für eingehenden Datenverkehr aktualisieren' wird zum Bearbeiten aktiviert.", //help176
	"Durch HNAP AddPortMapping erstellter %d. Eintrag für virtuellen Server '%s' %v:%d<->%v:%d %S", //GW_PURE_ADDPORTMAPPING_CREATE
	"Wählen Sie einen Zeitplan für die Aktivierung der Regel. Wenn Sie den benötigten Zeitplan nicht in der Liste finden, wechseln Sie zum Bildschirm <a href='tools_schedules.asp' onclick='return jump_if();'>Extras &rarr; Zeitpläne</a>, und erstellen Sie einen neuen Zeitplan.", //hhag_30
	"Klicken Sie auf die Schaltfläche <strong>Hinzufügen</strong> oder <strong>Aktualisieren</strong>, um eine fertige Regel in der Regelliste unten zu speichern.", //hhai_save
	"Administrator", //ADMIN
	"Der folgende Drucker wurde erkannt. Klicken Sie auf <em>Weiter</em>, um den Drucker auf Ihrem Computer zu installieren.", //wprn_s1a
	"Die E-Mail-Benachrichtigung ist deaktiviert.", //sl_alert_3
	"Nachdem Sie den Router für dynamischen DNS konfiguriert haben, können Sie einen Browser öffnen und die URL Ihrer Domäne eingeben (z. B. <code>http://www.mydomain.info</code>). Der Router versucht, die Anfrage an Port 80 Ihres LAN weiterzuleiten. Wenn die Eingabe allerdings von einem LAN-seitigen Computer aus erfolgt und kein virtueller Server für Port 80 definiert ist, leitet der Router die Konfigurationsseite des Routers zurück. Weitere Informationen zur Einrichtung eines virtuellen Servers finden Sie auf der Konfigurationsseite <a href='adv_virtual.asp'>Erweitert &rarr; Virtueller Server</a>.", //help900
	"Die IP-Adresse des Druckers und der Warteschlangenname werden <a href='../Status/PS.shtml' onclick='return jump_if();'>hier</a> angezeigt.", //tps_foo2
	"Diese Einstellung sollte bei ihrem Standardwert 2346 Bytes belassen werden.", //help182
	" -- Die IP-Adresse sollte im LAN-Subnetz sein.", //aa_alert_12
	"Um nach der neuesten Firmware zu suchen, klicken Sie auf die Schaltfläche [Jetzt online nach aktueller Firmware-Version suchen...]. Falls Sie benachrichtigt werden möchten, sobald neue Firmware verfügbar ist, setzen Sie ein Häkchen in das Feld neben 'E-Mail-Benachrichtigung bei neuer Firmware-Version'.", //tf_intro_FWCh
	"Auf der lokalen Festplatte speichern", //ts_ss
	"Benutzername- und Kennwortverbindung einrichten (PPTP)", //wwa_title_set_pptp
	"(z. B.: ich.meinedomaene.net)", //_hostname_eg
	"Hinweis: Damit die drahtlose Kommunikation einwandfrei funktioniert, müssen Sie das hier festgelegte Kennwort auch in den drahtlosen Clients eingeben.", //wwl_s4_note
	"Wählen Sie einen Filter, der den Zugang entsprechend den Anforderungen des virtuellen Servers überprüft. Wenn Sie den benötigten Filter nicht in der Liste finden, wechseln Sie zum Bildschirm <a href='Inbound_Filter.asp'> Erweitert &rarr; Filter für eingehenden Datenverkehr</a>, und erstellen Sie einen neuen Filter.", //help22
	"Das WLAN-Sicherheitskennwort muss aus 13 alphanumerischen Zeichen oder 26 Hexadezimalzeichen bestehen. Ihre Eingabe:", //wwl_alert_pv5_1
	"Über HNAP SetWLanSettings24 aktivierter %s, SSIDBroadcast %s, Kanal %d", //GW_PURE_SETWLANSETTINGS24
	"Geben Sie die LAN IP-Adresse des Computers im LAN an, für den Sie uneingeschränkte Internetkommunikation wünschen. Wenn dieser Computer seine Adresse automatisch über DHCP erhält, sollten Sie eine statische Reservierung auf der Seite <a href='adv_network.asp'>Setup&rarr;Netzwerk&nbsp;Einstellungen</a> vornehmen, damit sich die IP-Adresse des DMZ-Computers nicht ändert.", //help167
	"Erkanntes xDSL- oder anderes Frame-Relay-Netzwerk", //at_DxDSL
	"Der Assistent für die Druckerinstallation unterstützt nur die Betriebssysteme Windows XP/2000/98/ME. Ihr Computer verwendet das Betriebssystem <span id='wz_page_1_err_1_os'> </span>.", //wprn_bados2
	"In der von Ihnen ausgeführten Setup-Datei ist eine Fortschrittsanzeige dargestellt. Sobald die Installation abgeschlossen ist, erhalten Sie eine Meldung. Klicken Sie nach der Installation unten auf die Schaltfläche <em>Beenden</em>, um den Assistenten für die Druckerinstallation zu schließen.", //wprn_s3a
	"Falls die Setup-Datei nach dem Herunterladen nicht automatisch startet, öffnen Sie mit Windows Explorer den Ordner, in dem Sie die Datei gespeichert haben, und doppelklicken Sie auf das Symbol <em>Printer_Setup.exe.</em>.", //wprn_tt10
	"<a href='Inbound_Filter.asp' onclick='return jump_if();'>Filter für eingehenden Datenverkehr</a> für WAN-Ping", //bwn_IF
	"Wenn die AP-Einstellungen jedoch eine (dynamische) DHCP-Adresse enthalten, und der DHCP-Server des Routers dem AP einen Domänennamen zuweist, überschreibt dieser Domänenname den hier eingegebenen Namen.", //_1044a
	"Versuchen Sie, den Druckerfehler zu beheben, und klicken Sie anschließend auf <em>Aktualisieren</em>, um den Drucker-Status zu aktualisieren.", //wprn_tt6
	"Wählen Sie einen Zeitplan für die Zeiten, an denen diese Regel wirksam sein soll. Wenn der gewünschte Zeitplan nicht in der entsprechenden Liste mit Zeitplänen ist, rufen Sie <a href='tools_schedules.asp'> Extras&nbsp;&rarr;&nbsp;Zeitpläne</a> auf und erstellen Sie einen neuen.", //help72
	"Unbekannt", //_sdi_s6
	"Wählen Sie einen Zeitplan für die Serviceaktivierung. Wenn Sie den benötigten Zeitplan nicht in der Liste finden, wechseln Sie zum Bildschirm <a href='tools_schedules.asp' onclick='return jump_if();'>Extras &rarr; Zeitpläne</a>, und erstellen Sie einen neuen Zeitplan.", //hhpt_sch
	"Aktivieren oder deaktivieren Sie diese SSID. Bei Aktivierung sind folgende Parameter wirksam.", //tps_enraw
	"Dieses Protokoll wird an die E-Mail-Adresse gesendet.", //sl_alert_2
	"Auto 10/100/1000 Mbit/s", //anet_wp_2
	"Setzen Sie alle Einstellungen auf die Standardwerte zurück.", //tss_RestAll
	"Über HNAP SetDeviceSettings wird der WAN-Modus auf %S, %v/%v/%v gestellt.", //GW_PURE_SETWANSETTINGS
	"Wählen Sie einen Zeitplan für die Zeit, an der diese Regel wirksam sein soll. Wenn der gewünschte Zeitplan nicht in der entsprechenden Liste mit Zeitplänen ist, rufen Sie <a href='tools_schedules.asp'> Extras&nbsp;&rarr;&nbsp;Zeitpläne</a> auf und erstellen Sie einen neuen.", //help53
	"Speichert die neue oder bearbeitete Eingangsfilterregel in der folgenden Liste.", //help175
	"Wenn Sie die Option 'Nach Zeitplan' aktiviert haben, wählen Sie eine der festgelegten Zeitplan-Regeln. Wenn Sie den benötigten Zeitplan nicht in der Liste finden, wechseln Sie zum Bildschirm <a href='tools_schedules.asp'>Extras &rarr; Zeitpläne</a>, und erstellen Sie einen neuen Zeitplan.", //help872
	"Der vom Client verwendete Übertragungsstandard. Die Werte sind 11a, 11b, 11g oder 11n für 802.11a, 802.11b, 802.11g bzw. 802.11n.", //help785
	"Klicken Sie auf <em>Weiter</em>, und stimmen Sie dem Herunterladen einer ausführbaren Datei zu. Klicken Sie auf <em>Ausführen/Öffnen</em>, um diese Datei auf dem Computer zu starten. Wenn Sie aufgefordert werden, den Herausgeber zu bestätigen, klicken Sie erneut auf <em>Ausführen</em>.", //wprn_s2b
	"Der Assistent führt Sie durch die einzelnen Konfigurationsschritte. Klicken Sie auf <em>Weiter</em>, um die Konfiguration zu starten.", //wprn_intro2
	"Bitte wählen Sie einen Filter aus.", //GW_INET_ACL_NO_FILTER_SELECTED_INVALID
	"Bei Aktivierung dieser Option wird jedes Mal eine E-Mail an die im E-Mail-Abschnitt angegebene E-Mail-Adresse gesendet, wenn neue Firmware verfügbar ist. Die E-Mail-Benachrichtigungsoption muss dazu unter <a href ='tools_email.asp'>Extras&rarr;E-Mail-Einstellungen</a> aktiviert sein.", //help890
	"Die IP-Adresse und, wo zutreffend, die Portnummer der lokalen Anwendung.", //help814
	"Das Zeitintervall, in dem das Gerät sich im Leerlauf befinden kann, bevor die PPTP-Verbindung getrennt wird. Der Wert der maximalen Leerlaufzeit wird nur für die Wiederverbindungsmodi 'Bei Bedarf' und 'Manuell' verwendet.", //help283
	"Das Druckprotokoll ist derzeit deaktiviert. Sie können es <a href='../Tools/PS.shtml' onclick='return jump_if();'>hier</a> aktivieren.", //sps_protdis
	"Select a filter that controls access as needed for this admin port. If you do not see the filter you need in the list of filters, go to the <a href ='Inbound_Filter.asp' onclick ='return jump_if();'>Erweitert &rarr;&nbsp;Eingehender&nbsp;Filter</a> screen an", //help831
	"Unzureichende Berechtigung", //_cantapplysettings
	"Ermöglicht H.323 Clients (speziell Microsoft Netmeeting) über NAT zu kommunizieren. Falls Sie kontaktiert werden wollen, sollten Sie auch einen virtuellen Server für NetMeeting einrichten. Informationen zum Einrichten eines virtuellen Servers finden Sie auf der Seite <a href='adv_virtual.asp'> Erweitert&nbsp;&rarr;&nbsp;Virtueller&nbsp;Server</a>.", //help39
	"Die WCN-Konfiguration wurde aufgrund von %s abgebrochen.", //WCN_LOG_ABORT
	"(GMT+13:00) Nuku'alofa, Tonga", //up_tz_73
	"Die hier aufgelisteten Websites werden verwendet, wenn die Webfilter-Option unter <a href='adv_access_control.asp'>Erweitert &rarr; Zugangskontrolle </a> aktiviert ist.", //help141_a
	"Mit Hilfe der Firewall-Einstellungen können Sie einen einzelnen Computer in Ihrem Netzwerk außerhalb des Routers einrichten.", //af_intro_x
	"Eingangsfilterregel hinzufügen/aktualisieren", //help170
	"Um den gemeinsam genutzten Drucker von diesem Computer aus zu verwenden, starten Sie den Assistenten für die Druckerinstallation auf der <a href='../Basic/Wizard.shtml' onclick='return jump_if();'> Seite <i> </i>Assistent </a>.", //tps_intro4
	"Sie können auch manuell einen DDNS-Dienstanbieter eingeben.", //help893b
	"DHCP-Server starten", //GW_DHCPSERVER_START
	"Durch manche Firmware-Aktualisierungen werden die Konfigurationsoptionen auf die werkseitigen Standardeinstellungen zurückgesetzt. Bevor Sie ein solches Upgrade durchführen, sollten Sie die aktuelle Konfiguration über <a href ='tools_system.asp'>Extras&rarr;System</a> speichern.", //help887
	"Ermöglicht FTP Clients und Servern, Daten über NAT zu übertragen. Wenn Sie einen FTP-Server als Host verwenden möchten, finden Informationen dazu auf der Seite <a href='adv_virtual.asp'>Erweitert&nbsp;&rarr;&nbsp;Virtueller&nbsp;Server</a>.", //help38
	"SPI (\"Stateful Packet Inspection\", auch als \"Dynamic packet filtering\" bezeichnet) ist eine dynamische Paketfiltertechnik zur Verhinderung von Angriffen aus dem Internet, bei dem an Hand von dynamischen Zustandstabellen und auf der Basis des Vergleichs von mehreren Datenpaketen und durch die Ermittlung der Korrelation zwischen zusammengehörenden Datenpaketen Entscheidungen für die Weiterleitung der Datenpakete getroffen werden. Dabei wird geprüft, ob die die Sitzung passierenden Datenpakete dem Protokoll entsprechen.", //help164
	"Wählen Sie einen Filter, um nur vertrauenswürdigen Internet-Hosts Zugang zu diesem virtuellen Server zu gewähren. Wenn Sie den benötigten Filter nicht in der Liste finden, wechseln Sie zum Bildschirm <a href='Inbound_Filter.asp' onclick='return jump_if();'> Erweitert &rarr; Filter für eingehenden Datenverkehr</a>, und erstellen Sie einen neuen Filter.", //hhav_filt
	"Konflikt zwischen HNAP AddPortMapping '%s' %v:%d<->%v:%d %S und %d. Eintrag des virtuellen Servers '%s' %v:%d<->%v:%d %S", //GW_PURE_ADDPORTMAPPING_CONFLICT
	"Über HNAP SetRouterLanSettings festgelegte RouterIPAddress %v, RouterSubnetMask %v, DHCPServerEnabled %s", //GW_PURE_SETROUTERLANSETTINGS
	"Über HNAP SetWLanSecurity aktivierter %s, Typ %s", //GW_PURE_SETWLANSECURITY
	"Das Feld 'Richtlinien-Name' darf nicht leer sein.", //aa_alert_9
	"Das Zeitintervall, in dem das Gerät sich im Leerlauf befinden kann, bevor die L2TP-Verbindung getrennt wird. Der Wert der maximalen Leerlaufzeit wird für die Wiederverbindungsmodi 'Bei Bedarf' und 'Manuell' verwendet.", //help287
	"Remote Admin <a href=\"Inbound_Filter.asp\" onclick=\"return jump_if();\">Eingangsfilter</a>", //ta_RAIF
	"Diese Einstellung sollte bei ihrem Standardwert 2346 Bytes belassen werden.", //help180
	"DeviceName wurde durch HNAP SetDeviceSettings auf '%s' gestellt", //GW_PURE_SETDEVICESETTINGS
	"Signal (%)", //_rssi
	"Dieser Assistent führt Sie Schritt für Schritt durch die Einrichtung und Sicherung des drahtlosen Netzwerks.", //wwl_intro_wel
	"Hier klicken, um online auf die Firmware zuzugreifen.", //tf_ClickDL
	"DMZ bedeutet 'Demilitarisierte Zone'. Wenn eine Anwendung Probleme damit hat, hinter einem Router zu operieren, können Sie einen Computer vom Internet aus erreichbar machen und die Anwendung auf diesem Computer laufen lassen.", //help165
	"Weitere", //_vs_other
	"Um den gemeinsam genutzten Drucker von diesem Computer aus zu verwenden, folgen Sie den Setup-Anweisungen unter <a href='../Help/Basic.shtml#PS' onclick='return jump_if();' style='white-space: nowrap;'>Hilfe -&gt; Startseite -&gt; Assistent für die Druckerinstallation</a>.", //tps_intro5
	"Die hochgeladene Firmware-Datei ist möglicherweise nicht korrekt. Sie haben eventuell eine nicht für dieses Gerät bestimmte Datei hochgeladen oder die Datei ist beschädigt.", //ub_intro_1
	"Das Zeitintervall, in dem das Gerät sich im Leerlauf befinden kann, bevor die PPPoE-Verbindung getrennt wird. Der Wert der maximalen Leerlaufzeit wird nur für die Wiederverbindungsmodi 'Bei Bedarf' und 'Manuell' verwendet.", //help277
	"Diese Funktion ermöglicht das Weiterleiten der so genannten \"Magic Packets\" (d. h. speziell formatierte Wake-up Datenpakete, bei dessen Empfang der Rechner eingeschaltet ('aufgeweckt') wird) von dem WAN an einen LAN-Computer oder ein anderes Gerät, das \"Wake on LAN\" (WOL) fähig ist. Das WOL-fähige Gerät muss solches auf der Seite <a href='adv_virtual.asp'> Erweitert&nbsp;&rarr;&nbsp;Virtueller&nbsp;Server</a> bestimmt werden. Die LAN IP-Adresse für den virtuellen Server wird in der Regel auf die Broadcast-Adresse 192.168.0.255 gesetzt. Der Computer im LAN, dessen MAC-Adresse im 'Magic Packet' enthalten ist, wird 'aufgeweckt'.", //help41
	"Virtueller Server", //VIRTUAL_SERVERS
	"Wählen Sie einen Zeitplan für die Aktivierung des virtuellen Servers. Wenn Sie den benötigten Zeitplan nicht in der Liste finden, wechseln Sie zum Bildschirm <a href='tools_schedules.asp' onclick='return jump_if();'>Extras &rarr; Zeitpläne</a>, und erstellen Sie einen neuen Zeitplan.", //hhav_sch
	"Auf Werkseinstellungen zurücksetzen", //ts_rfd
	"Wenn PPTP ALG aktiviert ist, können die LAN-Computer sowohl mit demselben als auch mit anderen VPN-Servern PPTP VPN-Verbindungen herstellen. Wenn PPTP ALG deaktiviert ist, lässt der Router nur eingeschränkten VPN-Betrieb zu. LAN-Computer können normalerweise VPN-Tunnels zu anderen VPN-Internet-Servern aufbauen, nicht jedoch zu demselben Server. Indem PPTP ALG deaktiviert wird, lässt sich die VPN-Leistung erhöhen. Die PPTP ALG-Aktivierung ermöglicht zudem eingehende VPN-Verbindungen zu einem LAN-seitigen VPN-Server (weitere Informationen finden Sie unter <a href='adv_virtual.asp'>Erweitert &rarr; Virtueller Server</a>).", //help33b
	"Von der lokalen Festplatte laden", //ts_ls
	"Über HNAP DeletePortMapping %s:%d geänderter %d. Eintrag des virtuellen Servers '%s' %v:%d<->%v:%d %S zu %S", //GW_PURE_DELETEPORTMAPPING_MODIFY
	"Klicken Sie auf <em>Weiter</em>, und stimmen Sie dem Herunterladen einer ausführbaren Datei zu. Klicken Sie auf 'OK', um die Datei <br/><br/> herunterzuladen. Um die Datei auszuführen, müssen Sie eventuell über einen Dateibrowser den Ordner öffnen, in dem Sie die Datei gespeichert haben, und auf das Symbol <em>Printer_Setup.exe</em> doppelklicken.", //wprn_s2c
	"Auch Adressen von manuell konfigurierten Computern und Geräten können innerhalb dieses Bereichs liegen. In diesem Fall sollte die Adresse reserviert sein (siehe <a href='#Static_DHCP'>DHCP-Reservierung</a> unten), so dass der DHCP-Server erkennt, dass diese Adresse nur von einem speziellen Computer oder Gerät verwendet werden kann.", //help320
	"Auf der Seite 'Internetsitzungen' werden Details zu den aktiven Internetsitzungen über Ihren Router angezeigt. Eine Internetsitzung ist ein Dialog zwischen einem Programm oder einer Anwendung auf einem LAN-seitigen Computer und einem Programm oder einer Anwendung auf einem WAN-seitigen Computer.", //help813
	"Wählen Sie einen Anbieter von DDNS-Diensten von der Pulldown-Liste oder geben Sie einen manuell ein.", //help893
	"Wählen Sie diese Option, um das Router-Protokoll in einer Datei auf Ihrem Computer zu speichern.", //help803
	"Um nach der neuesten Firmware zu suchen, klicken Sie auf die Schaltfläche <span class='button_ref'>Jetzt online prüfen</span>.", //help877
	"(GMT+01:00) Belgrad, Bratislava, Ljubljana", //up_tz_27
	"Wurden in dem obigen Beispiel die Werte eingegeben und diese Gaming-Regel wurde aktiviert, wird der gesamte TCP- und UDP-Datenverkehr auf den Ports 6159 bis 6180 und Port 99 durch den Router geleitet und an die interne private IP-Adresse Ihres Spieleservers (192.168.0.50) weitergeleitet.", //help74
	"Wenn Sie die Option 'AUS' gewählt haben, werden die Adressen nicht für die Kontrolle des Netzwerkzugangs verwendet. Bei Auswahl der Option 'Zulassen' erhalten nur Computer Netzwerkzugriff, deren MAC-Adresse in der entsprechenden Liste enthalten ist. Bei Auswahl von 'Verweigern' wird jedem Computer der Netzwerkzugriff verweigert, dessen MAC-Adresse in der Liste enthalten ist.", //help155_2
	"Hergestellt: Rate wird gemessen", //_sdi_s4
	"Verschiedenes", //MISC
	"Hinweis: Daten werden hochgeladen. Das Hochladen kann bis zu 1 Minute dauern.", //tf_msg_Upping
	"Senden der Protokoll-E-Mail fehlgeschlagen. Versuchen Sie es erneut in %d Minuten.", //GW_LOG_EMAIL_FAILED
	"Aufbau oder Trennen der TCP-Verbindungen.", //help823_17
	"SSID aktivieren", //IPV6_TEXT4
	"Auf dieser Seite werden alle Einzelheiten aktiver Sitzungen über Ihren Router angezeigt.", //sa_intro
	"Beim Neustart werden alle aktiven Internet-Sitzungen abgebrochen.", //up_rb_2
	"Wählen Sie einen Zeitplan für die Serviceaktivierung. Wenn Sie den benötigten Zeitplan nicht in der Liste finden, wechseln Sie zum Bildschirm <a href='tools_schedules.asp'>Extras &rarr; Zeitpläne</a>, und erstellen Sie einen neuen Zeitplan.", //help23
	"Wenn IGMP aktiviert ist, zeigt dieser Bereich des Bildschirms alle Multicast-Gruppen an, zu denen die LAN-Geräte gehören.", //_bln_title_IGMPMemberships_h
	"Siehe auch <a href ='adv_virtual.asp'>Erweitert&rarr;Virtueller&nbsp;Server</a>, <a href ='adv_portforward.asp'>Erweitert&rarr;Portweiterleitung</a>, <a href ='adv_appl.asp'>Erweitert&rarr;Anwendungsregeln</a> und <a href ='adv_network.asp'>Erweitert&rarr;Netzwerk (UPnP) </a> für zugeordnete Optionen.", //haf_intro_2
	"Wenn Sie E-Mail-Informationen über den Bildschirm <a href='tools_email.asp'>Extras &rarr; E-Mail</a> eingegeben haben, klicken Sie die Schaltfläche <span class='button_ref'>E-Mail jetzt senden</span>, um das Router-Protokoll an die konfigurierte E-Mail-Adresse zu senden.", //help802
	"Klicken Sie auf 'Aktualisieren', um eine Verbindung herzustellen.", //wprn_tt5
	"Sie können sich das Protokoll auch regelmäßig zusenden lassen. Gehen Sie zu <a href='tools_email.asp' onclick='return jump_if();'>Extras &rarr; E-Mail</a>.", //hhsl_lmail
	"Drücken Sie die Schaltfläche unten, um die Konfiguration des Routers fortzusetzen, falls die vorherige Seite nicht in <span id='show_sec'></span> Sekunden wiederhergestellt wird.", //ap_intro_noreboot
	"(GMT+01:00) Sarajevo, Skopje, Sofia, Vilnius, Zagreb", //up_tz_29
	"HNAP SetMACFilters2", //GW_PURE_SETMACFILTERS2
	"HNAP neu starten", //GW_PURE_REBOOT
	"Wenn Sie die IP-Adresse des Routers geändert haben, müssen Sie die entsprechende IP-Adresse in Ihren Browser eingeben, um erneut auf die Konfigurations-Website zugreifen zu können.", //rb_change
	"Die IP-Adresse und, wo zutreffend, die Portnummer der Anwendung im Internet.", //help816
	"Durch HNAP DeletePortMapping %s:%d wurde der %d. Eintrag des virtuellen Servers '%s' %v:%d<->%v:%d %S gelöscht.", //GW_PURE_DELETEPORTMAPPING_DELETE
	"Wenn die korrekte Datei hochgeladen wurde, kann diese derzeit wegen Überlastung möglicherweise nicht vom Gerät empfangen werden. Versuchen Sie in diesem Fall, die Datei erneut hochzuladen. Stellen Sie sicher, dass Sie nicht als 'Benutzer', sondern als 'Administrator' angemeldet sind, da nur der Administrator neue Firmware hochladen kann.", //ub_intro_3
	"Anfragen können an die Seite \"Forbidden\" weitergeleitet werden, wenn der Web-Zugang für den LAN-Rechner durch eine Zugriffssteuerungsregel eingeschränkt ist. Fügen Sie die WAN-seitige Identität (WAN-seitige IP-Adresse des Routers oder sein DDNS-Name) im Fenster <a href='adv_filters_url.asp'> Erweitert&nbsp;&rarr;&nbsp;Webfilter</a> hinzu, um dieses Problem zu umgehen.", //help30
	"Ungültige LAN-IP-Adresse", //bln_alert_2
	"Verwenden Sie hierfür <a href='adv_access_control.asp' onclick='return jump_if();'>Erweitert &rarr; Zugangskontrolle</a>.", //hhwf_xref
	"Die Remote-Verwaltung des Gateways wurde an folgendem Port aktiviert: %u", //GW_REMOTE_ADMINSTRATION
	"Sie haben Ihre Sicherheitsstufe ausgewählt, nun müssen Sie ein Kennwort für die Wireless-Sicherheit festlegen.", //wwl_s4_intro
	"Sicherheitsmodus", //sd_SecTyp
	"WAN IPv6-ADRESSENEINSTELLUNGEN", //IPV6_WAN_IP
	"IPv6-Adresse", //IPV6_TEXT0
	"Bitte akzeptieren Sie und installieren Sie ActiveX. Versuchen Sie es anschließend erneut.", //gw_wcn_alert_3
	"Ungültiger Netzwerkschlüssel!", //IPV6_TEXT2
	"Kommunikation zwischen Netzen erlauben", //S473
	"SPI aktivieren", //af_ES
	"Diese Auswahl hilft Ihnen bei der Angabe der Gastzonenskala.", //IPV6_TEXT5
	"Gibt an, ob die Gastzone aktiviert oder deaktiviert wird.", //IPV6_TEXT6
	"Geben Sie einen Namen für die Gastzone des Funknetzes an.", //IPV6_TEXT7
	"Verwenden Sie diesen Teil dazu, um das Routing der Daten zwischen der Host- und der Gastzone zu ermöglichen. Gast-Clients können nicht ohne Aktivierung dieser Funktion auf die Daten von Host-Clients zugreifen.", //IPV6_TEXT8
	"Es ist wichtig, dass Sie Ihr drahtloses Netz sichern. Nur so kann die Integrität von Datenübertragungen gewährleistet werden. Der Router bietet 4 Verschlüsselungsstandards für Ihr drahtloses Netz: WEP, WPA only, WPA2 only und WPA/WPA2 (auto-detect).", //IPV6_TEXT9
	"WEP (Wired Equivalent Protocol) ist ein drahtloses Sicherheitsprotokoll für WLANs (Wireless Local Area Networks). WEP bietet Sicherheit, indem es die über das WLAN gesendeten Daten verschlüsselt. Der Router unterstützt zwei WEP-Verschlüsselungsstufen: 64 Bit und 128 Bit. WEP ist standardmäßig deaktiviert. Sie können die WEP-Einstellungen ändern, damit sie zu einem vorhandenen drahtlosen Netzwerk passen oder um Ihr eigenes drahtloses Netzwerk nach Bedarf anzupassen.", //IPV6_TEXT10
	"Mithilfe der Authentifizierung prüft der Router die Identität eines Netzwerkgeräts, das versucht, sich dem drahtlosen Netzwerk anzuschließen. Bei der Verwendung des WEP-Sicherheitsprotokolls stehen Ihnen zwei Authentifizierungsmöglichkeiten für dieses Gerät zur Verfügung.", //IPV6_TEXT11
	"Wählen Sie diese Option, damit alle drahtlosen Geräte mit dem Router kommunizieren können, ohne dass diese den für den Zugang zum Netzwerk erforderlichen Verschlüsselungsschlüssel angeben müssen.", //IPV6_TEXT12
	"Wählen Sie diese Option, wenn Sie wünschen, dass drahtlose Geräte, die mit dem Router zu kommunizieren versuchen, den für den Zugang zum Netzwerk erforderlichen Verschlüsselungsschlüssel angeben, bevor sie mit dem Router kommunizieren können.", //IPV6_TEXT13
	"Wählen Sie die WEP-Verschlüsselungsstufe, die Sie auf Ihrem Netzwerk verwenden möchten. Unterstützt werden 64-Bit und 128-Bit.", //IPV6_TEXT14
	"Die vom %m unterstützten Schlüsseltypen sind HEX (Hexadezimal) und ASCII (American Standard Code for Information Interchange). Sie können den Schlüsseltyp ändern, damit er zu einem vorhandenen drahtlosen Netzwerk passt oder um Ihr drahtloses Netzwerk nach Bedarf anzupassen.", //IPV6_TEXT15
	"Schlüssel", //IPV6_TEXT16
	"Mithilfe der Schlüssel 1 - 4 können Sie die Einstellungen für die drahtlose Verschlüsselung problemlos ändern, um die Netzwerksicherheit zu gewährleisten. Wählen Sie einfach den Schlüssel, der für die Verschlüsselung der drahtlosen Daten im Netzwerk verwendet werden soll.", //IPV6_TEXT17
	"Schlüsseltyp", //IPV6_TEXT18
	"WEP-Verschlüsselung", //IPV6_TEXT19
	"Wi-Fi Protected Access autorisiert und authentifiziert Benutzer, die Zugang zu dem drahtlosen Netzwerk wünschen. WPA verwendet eine leistungsstärkere Verschlüsselungsmethode als WEP und basiert auf einem Schlüssel, der in regelmäßigen zeitlichen Abständen automatisch geändert wird.", //IPV6_TEXT20
	"%m unterstützt zwei verschiedene Verschlüsselungstypen, wenn WPA als Sicherheitstyp verwendet wird. Diese zwei Optionen sind TKIP (Temporal Key Integrity Protocol/Temporäres Schlüsselintegritätsprotokoll) und AES (Advanced Encryption Standard/Erweiterter Verschlüsselungsstandard).", //IPV6_TEXT21
	"PSK/EAP", //IPV6_TEXT22
	"Bei Auswahl von PSK müssen die drahtlosen Clients zur Authentifizierung einen Kennwortsatz angeben. Bei Auswahl von EAP muss im Netzwerk ein RADIUS-Server vorhanden sein, der für die Authentifizierung aller drahtlosen Clients zuständig ist.", //IPV6_TEXT23
	"KINDERSCHUTZ", //DNS_TEXT0
	"Das ist erforderlich, damit Ihre drahtlosen Clients mit Ihrem %m kommunizieren können, wenn PSK gewählt wurde. Geben Sie 8 - 63 alphanumerische Zeichen ein. Schreiben Sie sich diesen Kennwortsatz unbedingt auf. Sie müssen ihn auf jedem anderen drahtlosen Gerät eingeben, das Sie Ihrem Netzwerk hinzufügen möchten.", //IPV6_TEXT25
	"Diese Methode der WPA-Authentifizierung wird in Verbindung mit einem RADIUS-Server verwendet, der in Ihrem Netzwerk vorhanden sein muss. Geben Sie die IP-Adresse, den Port und den gemeinsamen geheimen Schlüssel zur Konfiguration des RADIUS-Servers ein. Darüber hinaus haben Sie die Option, Informationen für einen zweiten RADIUS-Server für den Fall einzugeben, dass Ihr Netzwerk zwei dieser Server aufweist, die Sie zur Authentifizierung drahtloser Clients verwenden.", //IPV6_TEXT26
	"Wi-Fi Protected Access 2 autorisiert und authentifiziert Benutzer in einem drahtlosen Netz. WPA2 verwendet eine leistungsstärkere Verschlüsselungsmethode als WEP und basiert auf einem Schlüssel, der in regelmäßigen zeitlichen Abständen automatisch geändert wird.", //IPV6_TEXT27
	"In diesem Abschnitt können Sie Ihren IPv6-Internetverbindungstyp konfigurieren. Wenn Sie nicht sicher sind, welche Verbindungsmethode Sie verwenden sollen, wenden Sie sich bitte an Ihren Internetdienstanbieter.", //IPV6_TEXT28
	"IPv6-VERBINDUNGSTYP", //IPV6_TEXT29
	"IPv6-VERBINDUNGSTYP", //IPV6_TEXT29a
	"Wählen Sie den Modus, den der Router zum IPv6-Internet verwenden soll.", //IPV6_TEXT30
	"Meine IPv6-Verbindung ist", //IPV6_TEXT31
	"Statische IPv6", //IPV6_TEXT32
	"DHCPv6", //IPV6_TEXT33
	"PPPoE", //IPV6_TEXT34
	"IPv6 in IPv4 Tunnel", //IPV6_TEXT35
	"6to4", //IPV6_TEXT36
	"Nur lokale Verbindung", //IPV6_TEXT37
	"IPv6 in IPv4 TUNNELEINSTELLUNGEN", //IPV6_TEXT38
	"Geben Sie die von Ihrem Tunnelbroker bereitgestellten IPv6 in IPv4-Tunnelinformationen ein.", //IPV6_TEXT39
	"Ferne IPv4-Adresse", //IPV6_TEXT40
	"Ferne IPv6-Adresse", //IPV6_TEXT41
	"Lokale IPv4-Adresse", //IPV6_TEXT42
	"Lokale IPv6-Adresse", //IPV6_TEXT43
	"LAN IPv6-ADRESSENEINSTELLUNGEN", //IPV6_TEXT44
	"In diesem Abschnitt können Sie die internen Netzwerkeinstellungen Ihres Routers konfigurieren. Wenn Sie die LAN IPv6-Adresse hier ändern, müssen Sie Ihre PC-Netzwerkeinstellungen möglicherweise anpassen, um wieder auf das Netzwerk zugreifen zu können.", //IPV6_TEXT45
	"LAN IPv6-Adresse", //IPV6_TEXT46
	"LAN IPv6 Link-Local-Adresse", //IPV6_TEXT47
	"EINSTELLUNGEN FÜR DIE ADRESSEN-AUTOKONFIGURATION", //IPV6_TEXT48
	"In diesem Abschnitt können Sie die IPv6-Autokonfiguration einrichten und den Computern in Ihrem Netzwerk IP-Adressen zuweisen.", //IPV6_TEXT49
	"Aktivieren Sie die automatische Kanalerkennung, damit der Router den bestmöglichen Kanal für Ihr Wireless-Netzwerk auswählen kann.", //TA11
	"Autokonfigurationstyp", //IPV6_TEXT51
	"Zustandslos", //IPV6_TEXT52
	"Zustandsbehaftet (DHCPv6)", //IPV6_TEXT53
	"IPv6-Adressbereich (Start)", //IPV6_TEXT54
	"IPv6-Adressbereich (Ende)", //IPV6_TEXT55
	"IPv6-Adresse Lifetime", //IPV6_TEXT56
	"Router Advertisement Lifetime", //IPV6_TEXT57
	"Wenn Sie den Router für den Zugang zum IPv6-Internet konfigurieren, wählen Sie im Dropdown-Menü unbedingt den korrekten IPv6-Internet-Verbindungstyp. Wenn Sie nicht sicher ist, welche Option Sie wählen sollen, wenden Sie sich an Ihren Internetdienstanbieter.", //IPV6_TEXT58
	"Wenn beim IPv6 Internetzugang über den Router Probleme auftreten, prüfen Sie alle Einstellungen, die Sie auf dieser Seite eingegeben haben, und gleichen Sie sie ggf. mit Ihrem Internetdienstanbieter ab.", //IPV6_TEXT59
	"6to4-EINSTELLUNGEN", //IPV6_TEXT60
	"Geben Sie die Informationen zur IPv6-Adresse ein, die Sie von Ihrem Internetdienstanbieter erhalten haben.", //IPV6_TEXT61
	"6to4-Adresse", //IPV6_TEXT62
	"IPv6 DNS-EINSTELLUNGEN", //IPV6_TEXT63
	"Eine DNS-Server-Adresse automatisch beziehen", //IPV6_TEXT65
	"Obszön", //_aa_bsecure_obscene
	"Die folgenden IPv6 DNS-Server verwenden", //IPV6_TEXT66
	"In diesem Abschnitt können Sie die internen Netzwerkeinstellungen Ihres Routers konfigurieren.", //IPV6_TEXT67
	"Adressen-Lifetime", //IPV6_TEXT68
	"Advertisement Lifetime", //IPV6_TEXT69
	"Adressbereich (Start)", //IPV6_TEXT70
	"Adressbereich (Ende)", //IPV6_TEXT71
	"Geben Sie die Informationen ein, die Sie von Ihrem Internetdienstanbieter erhalten haben.", //IPV6_TEXT72
	"LEERLAUFZEIT", //IPV6_TEXT73
	"Subnetzmasken-Präfixlänge", //IPV6_TEXT74
	"IPv6 Standard-Gateway", //IPV6_TEXT75
	"Im Abschnitt IPv6 (Internet Protocol Version 6) können Sie Ihren IPv6-Verbindungstyp konfigurieren.", //IPV6_TEXT76
	"Sie können unter mehreren Verbindungstypen auswählen: Link-lokal, Statische IPv6, DHCPv6, Zustandslose Autokonfiguration, PPPoE, IPv6 in IPv4 Tunnel und 6to4. Wenn Sie nicht genau wissen, welche Verbindungsmethode verwendet wird, wenden Sie sich an Ihren IPv6 Internetdienstanbieter. Hinweis: Bei Verwendung von PPPoE müssen Sie sicherstellen, dass jegliche PPPoE-Clientsoftware auf Ihren Computern entfernt oder deaktiviert wurde.", //IPV6_TEXT77
	"Link-local-Modus", //IPV6_TEXT78
	"Die Link-local Adresse wird von Knoten und Routern bei der Kommunikation mit Nachbar-Knoten auf dem gleichen Link verwendet. Dieser Modus ermöglicht IPv6-fähigen Geräten, LAN-seitig miteinander zu kommunizieren.", //IPV6_TEXT79
	"Statischer IPv6-Modus", //IPV6_TEXT80
	"Dieser Modus wird verwendet, wenn Ihr Internetdienstanbieter Ihnen einen Satz mit IPv6-Adressen zugeteilt hat, der sich nicht ändert. Die IPv6-Informationen müssen manuell in Ihre IPv6-Konfigurationseinstellungen eingegeben werden. Sie müssen die folgenden Informationen eingeben: IPv6-Adresse, Subnetzmasken-Präfixlänge, Standard-Gateway, primärer DNS-Server und sekundärer DNS-Server. Sie erhalten diese Informationen von Ihrem Internetdienstanbieter.", //IPV6_TEXT81
	"DHCPv6-Modus", //IPV6_TEXT82
	"Bei dieser Verbindungsmethode weist Ihnen der Internetdienstanbieter Ihre IPv6-Adresse zu, wenn Ihr Router diese vom Server des Internetdienstanbieters anfordert. Bei einigen Internetdienstanbietern müssen Sie in Ihrer Umgebung einige Einstellungen vornehmen, bevor Ihr Router eine Verbindung mit dem IPv6-Internet herstellen kann.", //IPV6_TEXT83
	"Modus Zustandslose Autokonfiguration", //IPV6_TEXT84
	"Bei dieser Verbindungsmethode weist Ihnen der Internetdienstanbieter Ihre IPv6-Adresse zu, wenn Ihr Router diese vom Standard Gateway anfordert. Die Konfiguration der IPv6-Adresse basiert auf dem Empfang der Router Advertisement-Nachricht.", //IPV6_TEXT85
	"Wählen Sie diese Option, wenn Ihr Internetdienstanbieter von Ihnen die Verwendung einer PPPoE-Verbindung (Point to Point Protocol over Ethernet) zum IPv6 Internet fordert. Diese Option wird in der Regel von DSL-Anbietern verwendet.  Bei dieser Verbindungsmethode müssen Sie einen <strong>Benutzernamen</strong> und ein <strong>Kennwort</strong> eingeben, damit der Zugang zum IPv6 Internet gewährt wird (Sie erhalten diese Informationen von Ihrem Internetdienstanbieter). Die unterstützten Authentifizierungsprotokolle sind PAP und CHAP.", //IPV6_TEXT86
	"Wählen Sie diese Option, wenn die Server des Internetdienstanbieters die WAN IPv6-Adresse des Routers bei Aufbau einer Verbindung zuweisen.", //IPV6_TEXT87
	"Wählen Sie diese Option, wenn Ihr Internetdienstanbieter eine feste IPv6-Adresse zugewiesen hat. Ihr Internetdienstanbieter gibt Ihnen den Wert für die <SPAN class=option>IPv6-Adresse.</SPAN>", //IPV6_TEXT88
	"Die maximale Leerlaufzeit gibt an, wie lange der Computer inaktiv sein kann, bevor die WAN-Verbindung getrennt wird. Der Wert für die maximale Leerlaufzeit wird nur bei den Neuverbindungsmodi \"Bei Bedarf\" und \"Manuell\" verwendet.", //IPV6_TEXT89
	"IPv6 in IPv4 Tunnel-Modus", //IPV6_TEXT90
	"IPv6 in IPv4 Tunneling kapselt IPv6-Datenpakete in IPv4-Paketen, sodass IPv6-Pakete über eine IPv4-Infrastruktur gesendet werden können.", //IPV6_TEXT91
	"6to4-Modus", //IPV6_TEXT92
	"6to4 ist eine IPv6-Adressenzuweisung und automatische Tunneltechnologie, die Unicast IPv6-Konnektivität zwischen IPv6-Sites und Hosts im IPv4-Internet bereitstellt.", //IPV6_TEXT93
	"Primärer DNS-Server, sekundärer DNS-Server: Geben Sie die IPv6-Adressen der DNS-Server ein. Wenn kein sekundärer Server verwendet wird, lassen Sie das entsprechende Feld leer.", //IPV6_TEXT94
	"Dies sind die Einstellungen der IPv6-Schnittstelle für den Router. Die LAN IPv6-Adressenkonfiguration basiert auf der von Ihrem Internetdienstanbieter zugewiesenen IPv6-Adresse und dem Subnetz. (Ein Subnetz mit Präfix /64 wird im LAN unterstützt.)", //IPV6_TEXT95
	"In diesem Abschnitt können Sie die IPv6-Autokonfiguration einrichten und den Computern in Ihrem lokalen Netzwerk eine IPv6-Adresse zuweisen. Es steht eine zustandlose und eine zustandsbehaftete Autokonfigurationsmethode zur Verfügung.", //IPV6_TEXT96
	"Diese beiden Werte (\"von\" und \"bis\") legen den IPv6-Adressenbereich fest, den der DHCPv6-Server für die Zuteilung von IP-Adressen an Rechner und Geräte in Ihrem LAN nutzt. Adressen, die außerhalb dieses Bereiches liegen, werden vom DHCPv6 Server nicht verwaltet. Diese Adressen können jedoch für Geräte genutzt werden, die manuell konfiguriert werden oder die Netzwerkadressenangaben nicht automatisch mittels DHCP beziehen können.", //IPV6_TEXT97
	"Wenn Sie 'Zustandsbehaftet (DHCPv6)' wählen, werden die folgenden Optionen angezeigt.", //IPV6_TEXT98
	"Bei den Rechnern (und anderen Geräten), die an Ihr LAN angeschlossen sind, muss die TCP/IP-Konfiguration entsprechend auf \"DHCPv6\" oder \"IPv6-Adresse automatisch beziehen\" eingestellt sein.", //IPV6_TEXT99
	"IPv6-Adressbereich (DHCPv6)", //IPV6_TEXT100
	"Es ist möglich für einen Computer oder ein Gerät, das manuell konfiguriert wurde, eine IPv6-Adresse zu haben, die sich innerhalb dieses Bereichs befindet.", //IPV6_TEXT102
	"Die Zeitspanne, für die ein Rechner über eine IPv6-Adresse verfügen kann, bevor die Lease erneuert werden muss.", //IPV6_TEXT103
	"Link-local-Adresse verwenden", //IPV6_TEXT104
	"Automatisches DHCP-PD in LAN aktivieren", //IPV6_TEXT108
	"SLAAC + Zustandslose DHCPv6", //IPV6_TEXT106
	"Autokonfiguration (SLAAC/DHCPv6)", //IPV6_TEXT107
	"Autokonfiguration aktivieren", //IPV6_TEXT50
	"Geben Sie ein Kennwort für den Benutzer &quot;Benutzer&quot; ein, der nur schreibgeschützten Zugriff auf die webbasierte Verwaltungsschnittstelle erhält.", //help825
	"Setup-Assistent für die IPv6-Internetverbindung", //IPV6_TEXT110
	"Manuelle Einrichtung der IPv6-Internetverbindung", //IPV6_TEXT111
	"IPv6-Internetverbindung", //IPV6_TEXT112
	"Es gibt zwei Möglichkeiten, Ihre IPv6-Internetverbindung einzurichten: Sie können den webbasierten Setup-Assistenten für die IPv6-Internetverbindung verwenden oder die Verbindung manuell konfigurieren.", //IPV6_TEXT113
	"Dieser Assistent führt Sie Schritt für Schritt durch die Konfiguration einer neuen Verbindung zum IPv6-Internet.", //IPV6_TEXT116
	"Schritt 1: Ihre IPv6-Internetverbindung konfigurieren", //IPV6_TEXT117
	"Schritt 2: Einstellung speichern und Verbindung herstellen", //IPV6_TEXT118
	"Router sucht nach Ihrem IPv6-Internetverbindungstyp, bitte warten...", //IPV6_TEXT119
	"Router kann Ihren IPv6-Internetverbindungstyp nicht erkennen", //IPV6_TEXT120
	"Ich wünsche schrittweise Anleitungen zu den IPv6-Einstellungen", //IPV6_TEXT121
	"IPv6 over PPPoE", //IPV6_TEXT122
	"Wählen Sie diese Option, wenn Ihre IPv6-Internetverbindung einen Benutzernamen und ein Kennwort erfordert, um online zu gehen. Die meisten DSL-Modems verwenden diesen Verbindungstyp.", //IPV6_TEXT123
	"Statische IPv6-Adresse und -Route", //IPV6_TEXT124
	"Wählen Sie diese Option, wenn Ihr Internetdienstanbieter Ihnen IPv6-Adressinformationen gegeben hat, die manuell eingerichtet werden müssen.", //IPV6_TEXT125
	"Tunnelverbindung (6rd)", //IPV6_TEXT126
	"Wählen Sie diese Option, wenn Ihr Internetdienstanbieter für Sie eine IPv6-Internetverbindung unter Verwendung der 6rd automatischen Tunneltechnologie eingerichtet hat.", //IPV6_TEXT127
	"Um diese Verbindung einzurichten, benötigen Sie einen Benutzernamen und ein Kennwort von Ihrem IPv6-Internetdienstanbieter. Wenn Sie diese Informationen nicht haben, kontaktieren Sie bitte Ihren Internetdienstanbieter.", //IPV6_TEXT128
	"Freigabe mit IPv4", //IPV6_TEXT129
	"Um diese Verbindung einzurichten, benötigen Sie eine vollständige Liste der von Ihrem IPv6-Internetdienstanbieter bereitgestellten IPv6-Informationen. Wenn Sie eine statische IPv6-Verbindung haben und diese Informationen nicht haben, wenden Sie sich bitte diesbezüglich an Ihren Internetdienstanbieter.;", //IPV6_TEXT130
	"Um diese 6rd-Tunnel-Verbindung einzurichten, benötigen Sie die entsprechenden Informationen von Ihrem IPv6-Internetdienstanbieter. Wenn Sie diese Informationen nicht haben, kontaktieren Sie bitte Ihren Internetdienstanbieter.", //IPV6_TEXT131
	"6rd IPv6 Präfix", //IPV6_TEXT132
	"Zugeordnetes IPv6-Präfix", //IPV6_TEXT133
	"6rd Border Relais-IPv4-Adresse", //IPV6_TEXT134
	"IPv6 DNS-Server", //IPV6_TEXT135
	"Der Setup-Assistent für die IPv6-Internetverbindung ist abgeschlossen. Klicken Sie auf die Schaltfläche \"Verbinden\", um Ihre Einstellungen zu speichern und den Router neu zu starten.", //IPV6_TEXT136
	"Ipv6", //IPV6_TEXT137
	"Autom. Erkennung", //IPV6_TEXT138
	"6rd", //IPV6_TEXT139
	"DS-Lite", //IPV6_TEXT140
	"Teredo Tunneling Path-through", //IPV6_TEXT141
	"6rd-Konfiguration", //IPV6_TEXT142
	"6rd DHCPv4-Option", //IPV6_TEXT143
	"Manuelle Konfiguration", //IPV6_TEXT144
	"Tunnel Link-Local-Adresse", //IPV6_TEXT145
	"INTERNET-VERBINDUNGSTYP AFTR-ADRESSE", //IPV6_TEXT146
	"DHCP-Server aktivieren", //bd_EDSv
	"Geben Sie entweder die IP-Adresse des Zielcomputers ein oder geben Sie den vollständigen Domain-Namen an. (z.B. www.ihrname.eu)", //htsc_pingt_h
	"DS-Lite-Konfiguration", //IPV6_TEXT149
	"DS-Lite DHCPv6-Option", //IPV6_TEXT150
	"AFTR IPv6-Adresse", //IPV6_TEXT151
	"B4 IPv4-Adresse", //IPV6_TEXT152
	"IPv6 WAN Standard-Gateway", //IPV6_TEXT153
	"Wählen Sie eine der folgenden Konfigurationsmethoden und klicken Sie auf \"Weiter\", um fortzufahren.", //wps_KR37
	"Statische IPv6-Adressenverbindung einrichten", //IPV6_TEXT155
	"Der Setup-Assistent für die IPv6-Internetverbindung ist abgeschlossen. Klicken Sie auf die Schaltfläche \"Verbinden\", um Ihre Einstellungen zu speichern und den Router neu zu starten.", //IPV6_TEXT156
	"SLAAC + RDNSS", //IPV6_TEXT157
	"Ziel-IP/Präfixlänge", //IPV6_TEXT158
	"Der Bereich der B4 IPv4-Adresse ist von 192.0.0.2 bis 192.0.0.7", //IPV6_TEXT159
	"AFTR-Adresse", //IPV6_TEXT160
	"IPv6 PPPoE ist zusammen mit IPv4 PPPoE freigegeben. Ändern Sie bitte zuerst das IPv4 WAN-Protokoll.", //IPV6_TEXT161
	"6rd verwendet die DHCPv4-Option. Ändern Sie bitte zuerst das IPv6 WAN-Protokoll.", //IPV6_TEXT162
	"IPv6-WAN-Typ sollte SLAAC/DHCPv6, PPPoE, Autodetect-Modus sein", //IPV6_TEXT163
	"Sie können DHCP-PD auch aktivieren, damit Präfixe für Router in Ihrem LAN delegiert werden.", //IPV6_TEXT164
	"Hier werden alle Ihre IPv6 LAN-Daten angezeigt.", //IPV6_TEXT165
	"Von DHCP-PD zugewiesenes IPv6-Netzwerk", //IPV6_TEXT166
	"Anwendungs-Regel Einstellungen", //haar_p
	"Optionaler Backup RADIUS-Server", //bws_ORAD
	"SICHERHEITSOPTIONEN", //DNS_TEXT2
	"Advanced DNS&#8482", //DNS_TEXT3
	"Advanced DNS macht Ihre Internetverbindung sicherer, schneller, intelligenter und zuverlässiger. Dieser Dienst sperrt Phishing-Websites und schützt Sie vor dem Diebstahl persönlicher Daten.", //DNS_TEXT4
	"OpenDNS Parental Controls (Kinderschutz) bietet preisgekrönte Filterfunktionen von Internetinhalten und macht Ihre Internetverbindung sicherer, schneller, intelligenter und zuverlässiger. Mit mehr als 50 auswählbaren Inhaltskategorien bietet diese Funktion einen wirksamen Schutz vor jugendgefährdendem Material (Adult Content), gegen Proxies (Anonymisierungsmethoden), den ungewünschten Zugriff sozialer Netzwerke, Phishing-Websites, Schadprogrammen (Malware), usw. Vollständig konfigurierbar von allen Orten, an denen Sie Zugriff auf das Internet haben.", //DNS_TEXT8
	"Sperren Sie automatisch Websites der Kategorie 'Adult Content' (jugendgefährendes Material) und Phishing-Websites bei gleichzeitiger Erhöhung der Geschwindigkeit und Zuverlässigkeit Ihrer Internetverbindung.", //DNS_TEXT6
	"OpenDNS&reg; FamilyShield&#8482", //DNS_TEXT5
	"Open Systems Interconnection (Kommunikation offener Systeme). Das Referenzmodell für die Übertragung von Daten zwischen zwei Geräten in einem Netzwerk.", //help639
	"Keine: Statische IP-Adresse oder automatisch vom Internetdienstanbieter beziehen", //DNS_TEXT9
	"Verwenden Sie die von Ihrem Internetdienstanbieter bereitgestellten DNS-Server oder geben Sie Ihre bevorzugten DNS-Server ein.", //DNS_TEXT10
	"Obwohl die Funktion 'Advanced DNS' aktiviert ist, kann die DNS IP-Adresse Ihres Arbeitsplatzrechners nach Bedarf immer noch auf die DNS Server IP-Adresse geändert werden. Beachten Sie bitte, dass der Router die DNS-Namensauflösung nicht vorschreibt, wenn die DNS IP-Adresse auf dem Arbeitsplatzrechner manuell konfiguriert wird.", //DNS_TEXT11
	"Wenn Sie diese Option gewählt haben und in Ihrem Netz ist ein virtuelles privates Netz (VPN) oder ein Intranet eingerichtet, können Sie den 'Advanced DNS-Dienst' deaktivieren, falls Sie Schwierigkeiten mit der Verbindung haben.", //DNS_TEXT12
	"TRENDNET | %m | Status | Device Information", //TEXT000
	"Zustandslose Autokonfiguration", //TEXT001
	"Der Name des virtuellen Servers %s ist ungültig. Die Zeichen ',/,''\" sind nicht gültig.", //TEXT002
	"Name der Regel '+ i +' ist ungültig. Ungültiges Zeichen: ',/,''", //TEXT003
	"Ungültiger Hostname. Ungültiges Zeichen: ',/,''", //TEXT004
	"Lokaler Domain-Name ist ungültig. Ungültiges Zeichen: ',/,'", //TEXT005
	"Name der Regel '+ i +' ist ungültig. Ungültiges Zeichen: ',/,''", //TEXT006
	"Port-Weiterleitungsname '+ %s +' ist ungültig. Ungültiges Zeichen: ',/,''", //TEXT007
	"Regeln '+i+' sind gleich Regeln '+j+'.", //TEXT008
	"obj_word + \" Konflikt mit anderem privaten Port.\"", //TEXT010
	"Anzahl der Drahtlos-Clients", //sw_title_list
	"Der andere Protokolltyp ist ungültig.", //TEXT011
	"Wählen Sie das drahtlose Gerät mithilfe von WPS!", //TEXT012
	"Eingangsfilter muss kleiner sein als + rule_max_num", //TEXT013
	"Name kann nicht gleich dem Standard-Eingangsfilternamen 'Alle zulassen' oder 'Alle verweigern' sein.", //TEXT014
	"Zeitplanregelliste ist voll. Bitte löschen Sie einen Eintrag.", //TEXT015
	"Erste Seite", //TEXT016
	"Letzte Seite", //TEXT017
	"Vorherige Seite", //TEXT018
	"Systemaktivität", //TEXT019
	"Debug-Informationen", //TEXT020
	"Angriffe", //TEXT021
	"Verlorene Pakete", //TEXT022
	"Es liegen keine Änderungen vor. Trotzdem speichern?", //LS3
	"Der WEP-Schlüssel 2, 3, 4 kann nicht gewählt werden, wenn WPS aktiviert ist.", //TEXT024
	"Personal/TKIP und AES können nicht gewählt werden, wenn WPS aktiviert ist.", //TEXT025
	"WPA-Enterprise kann nicht gewählt werden, wenn WPS aktiviert ist.", //TEXT026
	"Shared Key' kann nicht gewählt werden, wenn WPS aktiviert ist.", //TEXT027
	"Aktivieren Sie zuerst die Drahtlosfunktion.", //TEXT028
	"Die WPS-Funktion ist derzeit deaktiviert. Klicken Sie auf \"Ja\", um sie zu aktivieren, oder auf \"Nein\", um den Assistenten zu beenden.", //TEXT029
	"Für %s sind Loopback-IP- oder Multicast-IP-Einträge (127.x.x.x, 224.x.x.x ~ 239.x.x.x) nicht zulässig.", //TEXT030
	"Der eingegebene %s Port ist ungültig.", //TEXT031
	"Das eingegebene %s Secret (Geheimnis) ist ungültig.", //TEXT032
	"Reservierte IP-Adresse", //TEXT033
	"Start-IP-Adresse", //TEXT035
	"\"IP-Endadresse\"", //TEXT036
	"Die LAN-IP-Adresse und die Start-IP-Adresse sind nicht im gleichen Subnetz", //TEXT037
	"Die LAN-IP-Adresse und die End-IP-Adresse sind nicht im gleichen Subnetz", //TEXT038
	"Die End-IP-Adresse muss größer sein als die Start-IP-Adresse.", //TEXT039
	"Die Einstellung wurde gespeichert.", //TEXT040
	"Der Schlüssel ' + i +' ist ungültig. Er muss ' + wep_key_len + ' Zeichen oder ' + hex_len + ' hexadezimale Ziffern und Zahlen aufweisen.", //TEXT041
	"Der Schlüssel ' + i + ' ist nicht korrekt. Gültige Zeichen sind 0-9, A-F oder a-f.", //TEXT042
	"%s Gateway IP-Adresse %s muss innerhalb des WAN-Subnetzes sein.", //TEXT043
	"Diese Firmware ist die neueste Version.", //TEXT045
	"Fehler beim Versuch, mit dem Server Kontakt aufzunehmen. Prüfen Sie den Status der Internetverbindung.", //TEXT046
	"WAN- und LAN IP-Adresse können nicht im gleichen Subnetz sein.", //TEXT047
	"Geben Sie ein Gerät an.", //aa_alert_10
	"Sie haben das drahtlose Gerät dem drahtlosen Netzwerk nicht innerhalb des vorgesehenen Zeitraums hinzugefügt. Klicken Sie unten auf die Schaltfläche, um es erneut zu versuchen.", //TEXT049
	"\"IP-Adresse '\"+ res_ip +\"' wurde bereits verwendet.\"", //TEXT050
	"Das bestätigte Kennwort stimmt nicht mit dem neuen Kennwort überein", //TEXT051
	"AUCH WCN 2.0 IN WINDOW VISTA GENANNT", //TEXT053
	"obj_word + ' Konflikt mit Anwendungs-Firewall-Port.'", //TEXT055
	"obj_word + \" Konflikt mit anderem öffentlichen Port.\"", //TEXT009
	"obj_word + ' Konflikt mit Portweiterleitungs-Port.'", //TEXT054
	"Port-Konflikt.", //TEXT057
	"TCP-Port-Konflikt.", //TEXT058
	"UDP-Port-Konflikt.", //TEXT059
	"Der Portweiterleitungsname ist bereits in der Liste", //TEXT060
	"Möchten Sie die DHCP-Reservierungseingabe für die IP-Adresse + DataArray[idx].IP aktivieren?", //TEXT062
	"Die Regel wird von einer anderen Regel verwendet und kann nicht gelöscht werden.", //TEXT063
	"Der Zeitplanname ist ungültig. Gültige Zeichen sind 0~9, A~Z oder a~z.", //TEXT064
	"Der Zeitplanname isr der Standardname.", //TEXT065
	"Der Name des Zeitplans ist bereits in der Liste", //TEXT066
	"Die Regel wird von einer anderen Regel verwendet und kann nicht bearbeitet werden.", //TEXT067
	"IPv6-Netzwerkinformationen", //TEXT068
	"Auf dieser Seite werden alle Details Ihrer IPv6-Internet- und Netzwerkverbindung angezeigt.", //TEXT069
	"IPv6-Verbindungsdaten", //TEXT070
	"WAN IPv6-Adresse", //TEXT071
	"LAN IPv6-Computer", //TEXT072
	"Erneut versuchen", //TEXT073
	"Weiter", //TEXT074
	"Hostname oder IPv6-Adresse", //TEXT075
	"Versuchen Sie es noch einmal", //TEXT076
	"PPPoE-Sitzung", //TEXT077
	"Erstellen Sie eine neue Sitzung", //TEXT078
	"Der 1. Teil der Adresse (von %s) muss eine Ganzzahl sein.", //MSG002
	"Der 2. Teil der Adresse (von %s) muss eine Ganzzahl sein.", //MSG003
	"Der 3. Teil der Adresse (von %s) muss eine Ganzzahl sein.", //MSG004
	"Der 4. Teil der Adresse (von %s) muss eine Ganzzahl sein.", //MSG005
	"%s ist ungültig.", //MSG006
	"%s darf nicht Null sein.", //MSG007
	"Das eingegebene %s Secret (Geheimnis) ist ungültig.", //MSG008
	"Das eingegebene %s Secret (Geheimnis) ist ungültig.", //MSG009
	"Für %s ist die Eingabe zu Loopback-IP oder Multicast-IP (127.x.x.x, 224.x.x.x ~ 239.x.x.x) nicht zulässig.", //MSG010
	"%s muss ein numerischer Wert sein.", //MSG013
	"Der Bereich von %s ist %1n ~ %2n.", //MSG014
	"Der Bereich von %s ist %n ~ %n.", //MSG014a
	"Der Wert von %s muss eine Ganzzahl sein.", //MSG015
	"Der Schlüssel ist ungültig. Er muss 5 Zeichen oder 10 hexadezimale Ziffern und Zahlen aufweisen. Ihre Eingabe:", //MSG016
	"Der Schlüssel ist ungültig. Er muss 13 Zeichen oder 26 hexadezimale Ziffern und Zahlen aufweisen. Ihre Eingabe:", //MSG017
	"Die erste Adresse von %s muss hexadezimal sein.", //MSG018
	"Die zweite Adresse von %s muss hexadezimal sein.", //MSG019
	"Die dritte Adresse von %s muss hexadezimal sein.", //MSG020
	"Die vierte Adresse von %s muss hexadezimal sein.", //MSG021
	"Die fünfte Adresse von %s muss hexadezimal sein.", //MSG022
	"Die sechste Adresse von %s muss hexadezimal sein.", //MSG023
	"Die siebte Adresse von %s muss hexadezimal sein.", //MSG024
	"Die achte Adresse von %s muss hexadezimal sein.", //MSG025
	"Der erste Bereich von %s muss zwischen folgenden Werten sein:", //MSG026
	"Der zweite Bereich von %s muss zwischen folgenden Werten sein:", //MSG027
	"Der dritte Bereich von %s muss zwischen folgenden Werten sein:", //MSG028
	"Der vierte Bereich von %s muss zwischen folgenden Werten sein:", //MSG029
	"Der fünfte Bereich von %s muss zwischen folgenden Werten sein:", //MSG030
	"Der sechste Bereich von %s muss zwischen folgenden Werten sein:", //MSG031
	"Der siebte Bereich von %s muss zwischen folgenden Werten sein:", //MSG032
	"Der achte Bereich von %s muss zwischen folgenden Werten sein:", //MSG033
	"Für %s ist die Eingabe zu Loopback-IP ( ::1 ) nicht zulässig.", //MSG034
	"Für %s ist die Eingabe zu Multicast-IP (FFxx:0:0:0:0:0:0:2 oder ffxx:0:0:0:0:0:0:2) nicht zulässig.", //MSG035
	"Das Suffix von", //MSG036_1
	"Das Subnetz von", //MSG037_1
	" muss hexadezimal sein.", //MSG038_1
	" ist eine ungültige Adresse.", //MSG039_1
	"Das Suffix von '+tag +' muss hexadezimal sein.", //MSG036
	"Das Suffix von '+tag+' ist eine ungültige Adresse.", //MSG037
	"Das Subnetz von '+tag +' muss hexadezimal sein.", //MSG038
	"Das Subnetz von '+tag+' ist eine ungültige Adresse.", //MSG039
	"Das Suffix des IPv6-Adressbereichs (Start) ist mehr als das des IPv6-Adressbereichs (Ende).", //MSG040
	"Die IPv6-Adresse erlaubt die Verwendung eines zweifachen Doppelpunktes nur einmal.", //MSG041
	"Die IPv6-Adresse ist nicht gültig", //MSG042
	"Ungültige Metrik", //MSG043
	"Der reine 802.11n-Modus unterstützt WEP nicht.", //MSG044
	"Der reine 802.11n-Modus unterstützt TKIP nicht.", //MSG045
	"Der Bereich von %s ist von %s bis ", //MSG046
	"Ungültiges IPv6-ULA-Präfix", //MSG047
	"Das Feld des ULA-Präfix ist leer. Standard ULA-Präfix verwenden?", //MSG048
	"Ihre Suche erfolgt durch Yahoo. Die Suche wird für Sie dadurch wesentlich komfortabler. Wird beispielsweise eine Website nicht erreicht oder existiert nicht, erhalten Sie entsprechende Suchvorschläge anstelle der allgemein gültigen Fehlermeldung des Browsers. Außerdem werden einige der häufig von Benutzern in der Adresszeile gemachten Rechtschreibfehler automatisch korrigiert. Diese Rechtschreibfehlerkorrektur erfolgt lediglich auf der höchsten Domänenebene, wie z. B. bei  .cmo und .ogr. Es kann vorkommen, dass Sie auf die Suchergebnisseite fehlgeleitet wurden. Das ist beispielsweise dann möglich, wenn Sie auf einen Link in einer Spam-E-Mail geklickt haben, um eine Seite anzuzeigen, die deaktiviert wurde, um möglichen Missbrauch zu verhindern. Weil diese Website nicht mehr existiert, wird Ihnen dann unsere Suchseite angezeigt.", //ADV_DNS_DESC3
	"Die von Ihnen angeforderte Seite ist nicht verfügbar.", //ERROR404
	"Vorschläge", //SUGGESTIONS
	"Stellen Sie sicher, dass Ihr Internetkabel fest an den Internetport Ihres Routers angeschlossen ist, und Ihre Internet-LED grün oder blau blinkt.", //SUGGESTIONS_1
	"Vergewissern Sie sich, dass die <a href='http://<% CmoGetCfg('lan_ipaddr',''); %>/'>Interneteinstellungen</a> auf Ihrem Router, wie Ihre PPPoE-Benutzernamen-/Kennworteinstellungen, korrekt sind.", //SUGGESTIONS_2
	"(Stunde:Minute)", //tsc_hrmin_1
	"DHCP-PD", //DHCP_PD
	"DHCP-PD aktivieren", //IPV6_TEXT147
	"Von DHCP-PD <br>zugewiesenes IPv6-Netzwerk", //DHCP_PD_ASSIGNED
	"6to4 Relay", //_6to4RELAY
	"Rufen Sie eine DNS-Serveradresse automatisch ab oder geben Sie eine spezifische DNS-Serveradresse ein.", //IPV6_TEXT64
	"Verwenden Sie die folgende IPv6 DNS-Adresse verwenden", //IPV6_TEXT66_v6
	"Das Ändern des USB-Typs auf Windows Mobile, iPhone oder Android Phone führt zu einem Neustart des Geräts.", //usb_reboot
	"Ein Ändern des USB-Typs auf Windows Mobile oder iPhone führt zum Neustart des Geräts und die IP-Adresse des Geräts wird auf 192.168.99.1 geändert.", //usb_reboot_chnip
	"Philippinen", //country_8
	"USB-Telefon wählen", //_select_phone
	"Wählen Sie das von Ihnen genutzte 3G USB-Mobiltelefon.", //_phone_info
	"3G USB Mobiltelefon", //usb_3g_phone
	"Windows Mobile 5", //usb_window_mobile_5
	"iPhone 3G(s)", //usb_iphone
	"Android-Telefon", //android_phone
	"Zeigt den aktuellen Verbindungsstatus zum DDNS-Server an.", //help901
	"Gerätename", //DEVICE_NAME
	"Die Lease %v wurde gesperrt.", //IPDHCPSERVER_LEASE_REVOKED2
	"Lease-Reservierung %v wurde gelöscht.", //IPDHCPSERVER_LEASE_RESERVATION_DELETED
	"Lease %v durch Client %m erneuert", //IPDHCPSERVER_LEASE_RENEW
	"Wake on LAN (Remoteaktivierung über LAN)", //help738
	"WLAN (Wireless Local Area Network)", //help759
	"Die am häufigsten genutzte Technologie für lokale Netzwerke (LAN).", //help517
	"Bits pro Sekunde.", //help443
	"Die Zeichen A-Z und 0-9.", //help414
	"OK", //_ok
	"Standard", //help486
	"DSL", //help503
	"Der Verlust in der Signalstärke digitaler und analoger Signale. Der Verlust ist größer, je länger die Strecken sind, über die das Signal übertragen wird.", //help426
	"Bandbreite", //help432
	"Durch das Aufteilen der Daten in kleinere Dateneinheiten sind diese leichter zu speichern.", //help527
	"Mithilfe der Webfilter-Option können Sie eine Liste zugelassener Websites einrichten, die von mehreren Benutzern verwendet werden können. Bei Aktivierung werden alle nicht auf dieser Seite aufgelisteten Websites gesperrt. Um diese Funktion zu verwenden, müssen Sie auch das Kontrollkästchen \"Web-Filter anwenden\" im Abschnitt 'Zugriffssteuerung' markieren.", //awf_intro_WF
	"Post Office Protocol 3. Protokoll, das zum Empfangen von E-Mails genutzt wird.", //help652
	"CardBus", //help456
	"Graphical User Interface (Grafische Benutzerschnittstelle)", //help539
	"Datenbank", //help472
	"Dateiserver", //help520
	"VoIP", //help737
	"Die erste Schicht des OSI-Modells. Die Hardware zur Übertragung elektrischer Signale auf einem Datenträger.", //help646
	"Webbrowser", //help745
	"Dient zum Synchronisieren der Kommunikationszeit zwischen den Geräten in einem Netzwerk.", //help659
	"USB", //help727
	"Wireless ISP", //help753
	"Das Verfahren zum Übertragen von Daten über das Internet von einem Rechner auf andere Rechner.", //help574
	"Remote Authentication Dial-In User Service (Fernauthentifizierung von Benutzern, die sich per Telefonverbindung einwählen). Ermöglicht abgesetzten Benutzern, sich auf einen zentralen Server einzuwählen und zu authentifizieren, um Zugriff auf Ressourcen in einem Netzwerk zu erhalten.", //help663
	"Wi-Fi", //help748
	"Erstellen Sie eine Liste mit Websites, auf die der Zugriff von den Geräten in Ihrem Netzwerk erlaubt werden soll.", //hhwf_intro
	"Light Emitting Diode (Lichtemittierende Diode).", //help598
	"xDSL", //help761
	"Eine IP-Adresse, die durch einen DHCP-Server zugeordnet wird und die sich ändern kann. Internetanbieter nutzen dieses Verfahren in der Regel, um ihren Kunden IP-Adressen zuzuweisen.", //help510
	"IPsec", //help584
	"Ein Dienstprogramm, das die Route zwischen einem Rechner und einem spezifischen Ziel grafisch anzeigt.", //help716
	"Bitrate", //help440
	"ADSL (Asymmetric Digital Subscriber Line)", //help410
	"dBi", //help480
	"IEEE", //help559
	"LAN", //help516
	"Alphanumerisch", //help413
	"Maximum Transmission Unit (Maximale Übertragungseinheit). Die maximale Paketgröße, die in einem paketbasierten Netzwerk, wie z. B. dem Internet, übertragen werden kann.", //help619
	"Ein Rechner in einem Netzwerk, auf dem Daten gespeichert werden, so dass die anderen Rechner im Netzwerk uneingeschränkt auf diese Daten zugreifen können.", //help521
	"DSSS: Modulationstechnik, die von Drahtlos-Geräten des Typs 802.11b genutzt wird.", //help494
	"Domain Name System: Übersetzt Domainnamen in IP-Adressen", //help498
	"Netzwerkschnittstellenkarte", //help628
	"Ein Verschlüsselungs- und Entschlüsselungs-Schlüssel, der für jede Kommunikationssitzung zwischen zwei Rechnern generiert wird.", //help683
	"Gigabits pro Sekunde.", //help535
	"SPI", //help695
	"Wide Area Network", //help740
	"Ein ISP stellt Privatpersonen und Unternehmen Zugang zum Internet bereit.", //help578
	"Signalrahmen", //help438
	"Der dynamische DNS-Dienst wird von bestimmten Internetdienstanbietern angeboten und ermöglicht es Anwendern mit dynamischen IP-Adressen, einen Domänennamen zu erhalten, der permanent mit der sich ständig verändernden IP-Adresse verknüpft ist. Die IP-Adresse wird bei jeder Adressenänderung entweder durch eine Client-Software aktualisiert, die auf einem Rechner läuft, oder durch einen Router aktualisiert, der dynamisches DNS unterstützt.", //help508
	"ASCII", //help423
	"NetBIOS", //help625
	"Server", //help680
	"Bei Funknetzwerken bezeichnet man damit die Situation, wenn ein drahtloser Client über einen Zugriffspunkt Zugriff auf das Netzwerk erhält.", //help568
	"Multicast", //help620
	"Die Apple-Version von UPnP, die es Geräten in einem Netzwerk ermöglicht, sich gegenseitig zu erkennen und miteinander zu verbinden, ohne irgendwelche Einstellungen konfigurieren zu müssen.", //help667
	"Eine Sammlung an Standards und Spezifikationen für Wireless Local Area Networks (WLANs), die von einer Arbeitsgruppe des Institute of Electrical and Electronics Engineers (IEEE) erarbeitet wurde.", //help766
	"RADIUS", //help662
	"Stateful Inspection (Zustandsbehaftete Inspektion)", //help701
	"Halbduplex", //help542
	"Ein weltumspannendes Rechnernetzwerk, das TCP/IP verwendet und Rechnern aus der ganzen Welt den Zugriff auf Ressourcen ermöglicht.", //help570
	"DMZ: Ein einzelner Rechner oder eine Rechnergruppe, auf den/die sowohl von Internetnutzern als auch von Nutzern im lokalen Netzwerk zugegriffen werden kann, der/die jedoch nicht mit der gleichen Sicherheit geschützt ist wie das lokale Netzwerk.", //help489
	"Das Installieren einer neueren Version einer Soft- oder Firmware.", //help723
	"Kilobyte", //help593
	"Eine Zeitspanne während der Ausführung von Prozessen, in der etwas den Prozess verlangsamt oder ganz stoppt.", //help447
	"System-Logger – Eine verteilte Protokollierschnittstelle, mit deren Hilfe Protokolle aus verschiedenen Quellen an einer zentralen Stelle gesammelt werden können. Ursprünglich für UNIX entwickelt, steht es nun auch für andere Betriebssysteme, einschließlich Windows, zur Verfügung.", //help705
	"Die Verbindung zu einem Local Area Network über einen der 802.11-Funkstandards.", //help755
	"H.323", //_H323
	"Die Eingabe von Anmeldeinformationen, wie z. B. einem Kennwort, um zu prüfen, ob eine Person oder ein Gerät wirklich ist, wer sie/es vorgibt, zu sein.", //help427
	"Die Entschlüsselung einer verschlüsselten Meldung zurück in Volltext.", //help485
	"Dynamic Host Configuration Protocol (Dynamisches Hostkonfigurationsprotokoll, DHCP): Dient zur automatischen Zuordnung von IP-Adressen aus einem vordefinierten Adressenpool an Rechner oder Geräte, die eine IP-Adresse anfordern.", //help490
	"HTTP over SSL wird verwendet, um HTTP-Datenübertragungen zu ver- und entschlüsseln.", //help555
	"Kollision", //help462
	"VPN. Ein sicherer Tunnel über das Internet zur Verbindung abgesetzter Büros oder Nutzer mit dem Netzwerk ihrer Firma.", //help732
	"KByte", //help592
	"Ein Gerät, das den Anschluss eines Rechners an ein koaxiales Kabel ermöglicht und damit den Zugriff auf das Internet erlaubt.", //help455
	"Die fünfte Schicht des OSI-Modells, die die Verbindung und die Kommunikation zwischen Anwendungen an beiden Enden koordiniert.", //help685
	"Viele Websites verwenden auf ihren Seiten Bilder und Inhalte von anderen Websites. Der Zugriff wird untersagt, wenn Sie nicht alle Websites aktivieren, die zum Aufbau einer Seite verwendet wurden. Wenn Sie z. B. auf <code>my.yahoo.com</code> zugreifen, müssen Sie den Zugriff auf <code>yahoo.com</code>, <code>yimg.com</code> und <code>doubleclick.net</code> aktivieren.", //help146
	"Point-to-Point Protocol (Punkt-zu-Punkt-Protokoll). Dient zur Kommunikation zweier Rechner über eine serielle Schnittstelle, vergleichbar einer Telefonleitung.", //help655
	"Ein Datenrahmen, über den eine der Stationen in einem Wi-Fi-Netzwerk regelmäßig Netzwerk-Kontrolldaten an andere Drahtlosstationen überträgt.", //help439
	"Dient zum Senden und Empfangen von HF-Signalen.", //help416
	"Uniform Resource Locator (Einheitlicher Ortsangeber für Ressourcen). Eine eindeutige Adresse für Dateien, die über das Internet aufgerufen werden können.", //help726
	"SNMP", //help692
	"Host", //help550
	"Die Datenmenge, die in einer gegebenen Zeitspanne übertragen werden kann.", //help714
	"Digital Subscriber Line (Digitaler Teilnehmeranschluss). Breitbandige Internetverbindung über Telefonleitungen.", //help504
	"Nutzt einen zufällig ausgewählten 56-Bit-Schlüssel, der beim Austausch von Informationen sowohl dem Sender als auch dem Empfänger bekannt sein muss.", //help469
	"Eine Karte, die im Rechner installiert wird oder in der Hauptplatine integriert ist und die dem Rechner die Herstellung einer Verbindung zu einem Netzwerk ermöglicht.", //help629
	"LED", //help597
	"Ein Dienstprogramm, das die Anzeige von Inhalten sowie das interaktive Nutzen der Informationen im World Wide Web ermöglicht.", //help746
	"Wireless Fidelity", //help749
	"Die 2. Schicht des OSI-Modells. Steuert die Bewegungen von Daten in der physischen Verbindung eines Netzwerks.", //help471
	"Das Übertragen von Sprachdaten über das Internet, im Gegensatz zu PSTN.", //help736
	"Die Zeit, die ein Paket benötigt, um von einem Punkt im Netzwerk zu einem anderen Punkt zu gelangen. Wird auch als Verzögerung bezeichnet.", //help596
	"TCP (Transmission Control Protocol)", //help706
	"Neustarten", //help664
	"Eine Funktion einer Firewall, die ausgehenden und ankommenden Traffic überwacht und sicherstellt, dass nur zulässige Antworten auf ausgehende Anfragen durch die Firewall gelangen.", //help702
	"WISP", //help756
	"Internetprotokoll", //help573
	"Eine Gruppe von Rechnern in einem Gebäude, die in der Regel auf Dateien auf einem Server zugreifen.", //help601
	"Sitzungsschicht", //help684
	"RSA", //help678
	"Wi-Fi Protected Access (Wi-Fi geschützter Zugriff) Eine Erweiterung der Wi-Fi-Sicherheit, die gegenüber WEP eine verbesserte Datenverschlüsselung bietet.", //help760
	"Gigabit LAN", //help536
	"Domänenname", //help499
	"Internet Group Management Protocol (Internetgruppen-Verwaltungsprotokoll). Dient dazu, sicherzustellen, dass Rechner ihre Multicast-Gruppenzugehörigkeit an angrenzende Router melden können.", //help562
	"WCN", //help741
	"Ein Standard, der die Konsistenz von Sprach- und Videoübertragungen sowie die Kompatibilität von Videokonferenz-Geräten zum Inhalt hat.", //help541
	"UDP (User Datagram Protocol)", //help717
	"Layer 2-Tunnelingprotokoll", //help604
	"Unicast", //help718
	"Ein Rechner in einem Netzwerk.", //help551
	"Internetdienstanbieter", //help577
	"Das Konvertieren von Daten in einen verschlüsselten Text, der nicht ohne Weiteres gelesen werden kann.", //help515
	"Bezeichnet das Senden von Daten von einem Gerät auf zahlreiche andere Geräte in einem Netzwerk.", //help621
	"AES. Verschlüsselungsstandard der Regierung", //help412
	"Datendurchsatz", //help713
	"Wird zum Versenden und Empfangen von E-Mails genutzt.", //help687
	"Infrastruktur", //help567
	"Microsoft Point-to-Point Encryption (Microsoft Punkt-zu-Punkt-Verschlüsselung). Wird verwendet, um Datenübertragungen über PPTP-Verbindungen zu sichern.", //help618
	"Die Anzahl der Bits, die in einer bestimmten Zeitspanne übertragen werden.", //help441
	"Daten", //help466
	"SMTP", //gw_vs_5
	"DMZ", //help488
	"Kilobits pro Sekunde.", //help591
	"AP. Gerät, dass Drahtlos-Clients die Verbindung und den Zugriff auf das Netzwerk ermöglicht.", //help402
	"QoS (Quality of Service)", //help661
	"DMZ", //help495
	"Internetdienstanbieter", //help587
	"Präambel", //help658
	"Upgrade", //help722
	"Dezibel pro ein Milliwatt.", //help483
	"RIP", //help670
	"WPA", //help750
	"Browser", //help452
	"SPI (Stateful Packet Inspection/Zustandsbehaftete Paketüberprüfung)", //help696
	"Verstärker", //help668
	"Die maximale Anzahl an Bytes oder Bits pro Sekunde, die von und zu einem Netzwerkgerät übertragen werden kann.", //help433
	"Ein Rechner in einem Netzwerk, der Dienste und Ressourcen für andere Rechner im Netzwerk bereitstellt.", //help681
	"NTP (Network Time Protocol)", //help632
	"ADSL", //help409
	"802.11", //help765
	"Anwendungsobjekt-Schicht", //help421
	"URL", //help725
	"QoS", //help660
	"IPsec gewährleistet die Sicherheit in der Paketverarbeitungsschicht der Netzwerkkommunikation.", //help576
	"Die neuere Sicherheitsversion für Drahtlosnetzwerke, die sowohl Authentifizierung als auch Verschlüsselung bietet.", //help751
	"VoIP (Voice over IP)", //help735
	"Access Point", //help401
	"POP3", //gw_vs_6
	"Digitales Zertifikat:", //help491
	"Breitband", //help448
	"Internet Key Exchange (Internetschlüsselaustausch). Wird verwendet, um die Sicherheit von VPN-Verbindungen zu gewährleisten.", //help566
	"Hilfeglossar", //help398
	"Internetwork Packet Exchange (Internet-Paketaustausch). Ein Netzwerkprotokoll, das von Novel entwickelt wurde, um die Kommunikation zwischen Netware-Clients und –Servern zu ermöglichen.", //help586
	"Ein TCP/IP-Protokoll zur Übertragung von Druckdaten an Drucker.", //help710
	"SMTP (Simple Mail Transfer Protocol)", //help686
	"Eine Übertragungstechnologie, die eine Datenübertragungsrate von 1 Milliarde Bits pro Sekunde bereitstellt.", //help537
	"PPP", //help654
	"TCP/IP (Transmission Control Protocol/Internet Protocol)", //help708
	"American Standard Code for Information Interchange (Amerikanischer Standard-Code für den Informationsaustausch). Dieses Zeichensystem wird am häufigsten für Text-Dateien verwendet.", //help424
	"Duplex", //help505
	"Bei Internetprotokoll-Version 4 eine 32-Bit-Nummer zu Identifizierung jedes Rechners, der Daten im Internet oder einem Intranet überträgt.", //help583
	"Rückwärtskompatibel", //help430
	"Entschlüsseln", //help484
	"Kabelmodem", //help454
	"Hub", //help556
	"Datenverbindungsschicht", //help470
	"Steuert die Verwaltung und Überwachung von Netzwerkgeräten.", //help689
	"Cookie", //help464
	"Ein Programm oder ein Nutzer, das/der Daten von einem Server anfordert.", //help461
	"Nov.", //tt_Nov
	"Traceroute", //help715
	"Network Address Translation (Netzwerkadress-Übersetzung). Ermöglicht vielen privaten IP-Adressen die Verbindung zum Internet oder zu einem anderen Netzwerk mittels einer einzigen IP-Adresse.", //help622
	"Virtuelles Privates Netzwerk", //help731
	"ARP. Wird verwendet zum Assoziieren von MAC- und IP-Adressen, damit Unterhaltungen in beide Richtungen stattfinden können.", //help408
	"SNMP (Simple Network Management Protocol)", //help688
	"Informationen, die auf der Festplatte Ihres Rechners gespeichert werden und die Informationen über Ihre Präferenzen auf der Website enthalten, von der dieser Cookie auf Ihrem Rechner gespeichert wurde.", //help465
	"Subnetzmaske", //help703
	"SSH", //help697
	"MAC-Adresse", //help605
	"Der Vorgang, bei dem Datenpakete von einem Router zu einem anderen Router übertragen werden.", //help549
	"Das gleichzeitige Senden und Empfangen von Datenübertragungen.", //help506
	"Eine Zeichenfolge, die zur Authentifizierung von Anfragen an Netzwerkressourcen genutzt wird.", //help642
	"Automatische private IP-Adressierung", //help428
	"Sitzungsschlüssel", //help682
	"Ein elektronisches Verfahren zum Bereitstellen von Anmeldeinformationen an einen Server, um auf diesen Server oder ein Netzwerk Zugriff zu erhalten.", //help492
	"Fragmentierung", //help526
	"Die dritte Schicht des OSI-Modells, die für das Routen des Traffics in einem Netzwerk zuständig ist.", //help631
	"Eine eindeutige Hardware-ID, die jedem Ethernet-Adapter vom Hersteller zugewiesen wird.", //help606
	"Das erneute Hochfahren eines Rechners und erneute Laden der Betriebssoftware bzw. Firmware aus einem permanenten Speicher.", //help665
	"In dem Abschnitt werden die aktuell zugelassenen Websites aufgeführt.", //help148
	"Ratenschätzung abgebrochen, weil Ressourcen gering", //RATE_ESTIMATOR_RESOURCE_ERROR
	"Ein Standard, der es Geräten im Netzwerk ermöglicht, sich gegenseitig zu erkennen und sich selbst als Teil des Netzwerks zu konfigurieren.", //help721
	"HTTPS", //gw_vs_2
	"UTP", //help729
	"WISP (Wireless Internet Service Provider)", //help757
	"Latenz", //help595
	"Routing Information Protocol (Routing-Informationsprotokoll). Wird genutzt, um die Routingtabellen aller Router in einem Netzwerk miteinander zu synchronisieren.", //help671
	"Wired Equivalent Privacy (Kabelsystemen äquivalente Sicherheit). Sicherheit für Funknetzwerke, die der Sicherheit verkabelter Netzwerke gleichkommt.", //help747
	"TCP/IP", //help707
	"Die Übertragung von Daten in alle Richtungen gleichzeitig.", //help451
	"Eine elektronische Nachricht, die auf dem Rechner gespeichert und anschließend über das Internet übertragen wird.", //help514
	"Extensible Authentication Protokoll (Erweiterbares Authentifizierungsprotokoll).", //help512
	"Die am häufigsten genutzte Verbindungsmethode für Ethernet.", //help675
	"Zugriffssteuerungsliste", //help399
	"Allgemeines Netzwerk-Ein-/Ausgabesystem", //help626
	"Antenne", //help415
	"Ein Gerät, das eine Verbindung Ihres Netzwerkes zu einem anderen Netzwerk, wie z. B. dem Internet, herstellt.", //help533
	"Ein Internetbrowser, der von Microsoft entwickelt und vermarktet wird.", //help572
	"Ein Netzwerkgerät, das eine Verbindung zwischen mehreren Geräten herstellt.", //help557
	"Datenverschlüsselungsstandard", //help468
	"Das Senden einer Anfrage von einem Rechner an einen zweiten Rechner und die daraufhin erfolgende Übertragung von Dateien vom zweiten Rechner an den anfragenden Rechner.", //help724
	"Ein Dienstprogramm, das überprüft, ob eine bestimmte Internetadresse überhaupt existiert und Daten empfangen kann. Das Dienstprogramm sendet ein Steuerpaket an die angegebene Adresse und wartet auf eine Antwort.", //help648
	"Bitte warten", //wt_title
	"Point-to-Point Tunneling Protocol (Punkt-zu-Punkt-Tunnel-Protokoll). Wird genutzt, um VPN-Tunnel zwischen zwei Netzwerken über das Internet herzustellen.", //help657
	"dBm", //help482
	"Algorithmus, der zur Verschlüsselung und Authentifizierung genutzt wird.", //help679
	"Die Fähigkeit neuer Geräte, mit älteren Geräten zu kommunizieren und zu interagieren, um die Interoperabilität sicherzustellen.", //help431
	"IEEE (Institute of Electrical and Electronics Engineers)", //help560
	"Windows Connect Now. Ein Verfahren von Microsoft zum Konfigurieren und Bootstrappen von drahtloser Hardware (Zugriffspunkte) und Drahtlos-Clients, einschl. Rechnern und anderen Geräten.", //help742
	"Ein breites Frequenzband zur Übertragung von Daten.", //help449
	"IKE", //help565
	"ODER klicken Sie auf die Schaltfläche <em>Weiter</em>, um fortzufahren. Wählen Sie anschließend <em>Nein</em>, wenn Sie gefragt werden, ob Sie eine Testseite drucken möchten.", //wprn_tt7
	"Altsystem", //help599
	"IPX", //help585
	"Das gleichzeitige Senden und Empfangen von Daten.", //help530
	"NetBEUI", //help623
	"WLAN", //help758
	"NIC", //help634
	"Das nächstgrößere Netzwerk, an das Ihr LAN angeschlossen ist. Dabei kann es sich um das Internet selbst, oder um ein regionales oder Firmen-Netzwerk handeln.", //help752
	"Internet Protocol Security (IPsec)", //help575
	"Broadcast", //help450
	"DIE PHYSISCHE VERBINDUNG DES INTERNETPORTS IST UNTERBROCHEN", //ES_CABLELOST_bnr
	"Wenn zwei Geräte im gleichen Ethernet-Netzwerk zum exakt gleichen Zeitpunkt einen Zugriff versuchen und Daten übertragen.", //help463
	"ARP (Address Resolution Protocol)", //help407
	"Ein Programm, das den Zugriff auf Ressourcen im Internet ermöglicht und diese in grafischer Form für den Benutzer darstellt.", //help453
	"IGMP", //help561
	"Bits/Sek", //help442
	"Der Sammelbegriff für die Familie der DSL-Technologien (digitale Teilnehmerleitungen), wie z. B. ADSL, HDSL, RADSL, und SDSL.", //help762
	"Das Hypertext Transfer Protocol (Hypertext-Übertragungsprotokoll) wird verwendet, um Dateien von HTTP-Servern (Webservern) auf HTTP-Clients (Webbrowser) zu übertragen.", //help553
	"KBit/s", //help590
	"Megabits pro Sekunde.", //help608
	"ARS (Advanced Encryption Standard)", //help411
	"DNS", //gw_vs_4
	"Hexadezimal", //help546
	"Ein logischer Kanal-Endpunkt in einem Netzwerk. Ein Rechner kann nur einen physischen Kanal (seinen Ethernet-Kanal), aber mehrere Ports (logische Kanäle) besitzen, die mittels Nummern identifiziert werden.", //help653
	"Dezibel relativ zum isotropen Strahler", //help481
	"Vollduplex", //help529
	"Dämpfung", //help425
	"ACL. Hierbei handelt es sich um eine Datenbank der Netzwerkgeräte, denen der Zugriff auf Ressourcen im Netzwerk gestattet ist.", //help400
	"Dynamische IP-Adresse", //help509
	"DHCP", //_DHCP
	"TCP Raw", //help709
	"UPNP", //help720
	"USB", //help728
	"Informationen, die in ein binäres Format übertragen wurden, so dass diese verarbeitet oder auf ein anderes Gerät übertragen werden können.", //help467
	"Bezeichnet die Kommunikation zwischen einem einzigen Sender und einem einzigen Empfänger.", //help719
	"LAN (Local Area Network)", //help594
	"Eine neuere Version der PC-Karte oder PCMCIA-Schnittstelle. CardBus unterstützt einen 32-Bit-Datenpfad und DMA und bietet einen geringeren Stromverbrauch.", //help457
	"Rendezvous", //help666
	"Secure Shell ist eine Befehlszeilenschnittstelle, die die Herstellung sicherer Verbindungen zu abgesetzten Rechnern ermöglicht.", //help698
	"GUI", //help538
	"Netzwerkschicht", //help630
	"Die 7. Schicht des OSI-Modells. Stellt Dienste für Anwendungen bereit, um sicherzustellen, dass diese fehlerfrei mit anderen Anwendungen im einem Netzwerk kommunizieren können.", //help422
	"DSSS (Direct Sequence Spread Spectrum)", //help493
	"Dynamischer DNS-Dienst", //help507
	"Internet Explorer", //help571
	"Ratenschätzung abgebrochen, weil Messungen nicht konvergierten", //RATE_ESTIMATOR_CONVERGENCE_ERROR
	"Ein bestimmter Wert oder eine bestimmte Einstellung, die von einem Programm verwendet wird, wenn vom Benutzer keine Eingabe für diesen Wert bzw. diese Einstellung vorgenommen wurde.", //help487
	"NetBIOS Extended User Interface (Erweiterte NetBIOS-Benutzerschnittstelle). Ein LAN-Kommunikationsprotokoll. Die erweiterte Version von NetBIOS.", //help624
	"Bei diesem Verfahren können Daten nicht gleichzeitig versendet und empfangen werden.", //help543
	"Service Set Identifier (Dienstsatz-Identifizierung). Der Name eines Funknetzwerkes.", //help700
	"Client", //help460
	"UTP (Unshielded Twisted Pair)", //help730
	"Das Senden einer Anfrage von einem Rechner an einen zweiten Rechner und die daraufhin erfolgende Übertragung von Dateien vom zweiten Rechner auf den anfragenden Rechner.", //help502
	"E-Mail", //help513
	"Session Initiation Protocol (Sitzungsaktivierungsprotokoll). Ein Standardprotokoll zum Initiieren einer Benutzersitzung mit Multimedia-Inhalten, wie z. B. Sprache oder Chat.", //help690
	"MBit/s", //help607
	"Eine Programmierung, die in einer Hardware enthalten ist und die dem Benutzer die Funktionen der Hardware erklärt.", //help525
	"Ein Unternehmen, das Breitband-Internetzugang über Funkverbindungen anbietet.", //help754
	"MPPE", //help617
	"Ein Name, der einer bestimmten IP-Adresse zugeordnet ist.", //help500
	"Internet Control Messaging Protocol (Internet-Kontroll-Nachrichten-Protokoll)", //help558
	"APIPA. Eine IP-Adresse, die ein Windows-Rechner sich selbst zuordnet, wenn er für den automatischen Bezug von IP-Adressen konfiguriert wurde, aber kein DHCP-Server im Netzwerk verfügbar ist.", //help429
	"EAP", //help511
	"GBit/s", //help534
	"&quot;Demilitarisierte Zone&quot;. Ein Rechner, der logisch gesehen in einem &quot;Niemandsland&quot; zwischen dem LAN und dem WAN angesiedelt ist. Der DMZ-Rechner verzichtet auf einen gewissen Schutz der Router-Sicherheitsmechanismen, bietet dafür aber den Vorteil, dass vom Internet aus direkt auf ihn zugegriffen werden kann.", //help496
	"Flaschenhals", //help446
	"Ermöglicht das Hochfahren eines Rechners über dessen Netzwerkkarte.", //help739
	"Legt fest, welcher Teil der IP-Adresse für das Netzwerk, und welcher Teil für den Host steht.", //help627
	"Aktive Sitzungen", //_actsess
	"Priorität 0 ist reserviert.", //help91a
	"Nicht durch eine Regel priorisierten Datenströmen wird die niedrigste Priorität zugewiesen.", //help91b
	"Die allgemein gebräuchlichen Optionen können von dem Dropdown-Menü gewählt werden.", //help92x1
	"Um irgendein anderes Protokoll anzugeben, geben Sie seine entsprechende Protokollnummer (<a href='http://www.iana.org/assignments/protocol-numbers' target='_blank'> wie von der IANA zugewiesen </a>) in das Feld <span class='option'>Protokoll</span> ein.", //help92x2
	"Wenn eine Internetsitzung durch eine LAN-Anwendung gestartet wird, die ein anderes Protokoll als UDP, TCP oder ICMP verwendet, vermittelt der Router-NAT die Sitzung, auch wenn das Protokoll von ihm nicht erkannt wird. Diese Funktion ist für die Aktivierung bestimmter Anwendungen nützlich (hauptsächlich eine einfache VPN-Verbindung zu einem Remote-Host), ohne dass ein ALG benötigt wird.", //TA21
	"Beachten Sie, dass diese Funktion nicht bei DMZ-Hosts (sofern aktiviert) verfügbar ist. Der DMZ-Host behandelt stets diese Sitzungsart.", //TA22
	"sind empfohlen.", //help183
	"Aktivieren Sie dieses Kontrollkästchen, damit der DHCP-Server den LAN-Hosts die NetBIOS-Konfigurationseinstellungen bereitstellt.", //help400_b
	"Wenn die NetBIOS-Anzeige aktiviert ist, sorgt die Aktivierung dieser Einstellung dafür, dass WINS-Informationen (sofern verfügbar) von der WAN-Seite abgerufen werden können.", //help401_b
	"Konfigurieren Sie die IP-Adresse des gewünschten WINS-Servers.", //help402_b
	"ActiveX", //help403
	"Konfigurieren Sie die IP-Adresse des Backup-WINS-Servers, falls Sie einen solchen verwenden.", //help403_b
	"Eine Microsoft-Spezifikation für die Interaktion von Software-Komponenten.", //help404
	"Das Feld steht für eine erweiterte Einstellung und bleibt normalerweise leer. Hier kann ein NetBIOS-'Domänenname' konfiguriert werden, unter dem Netzwerk-Hosts arbeiten.", //help404_b
	"Ad-hoc-Netzwerk", //help405
	"Gibt an, wie Netzwerk-Hosts die NetBIOS-Namensregistrierung und -erkennung ausführen sollen.", //help405_b
	"Peer-Konfigurationsfehler %u", //WIFISC_AP_PEER_CFG_ERR
	"AppleTalk", //help417
	"Eine Reihe von LAN-Protokollen (Local Area Network-Protokolle), die von Apple für ihre Computersysteme entwickelt wurden.", //help418
	"AppleTalk ARP (Address Resolution Protocol)", //help419
	"AARP. Dient dazu, MAC-Adressen von Apple-Rechnern zu deren AppleTalk-Netzwerkadressen zuzuordnen, so dass Konvertierungen in beide Richtungen vorgenommen werden können.", //help420
	"Allgemeines Eingabe-/Ausgabesystem", //help434
	"BIOS. Ein Programm, das der Prozessor eines Rechners nutzt, um das System des Rechners hochzufahren.", //help435
	"Baud", //help436
	"Datenübertragungsgeschwindigkeit", //help437
	"BOOTP", //help444
	"Bootstrap-Protokoll. Ermöglicht Rechnern das Booten und Zuordnen einer IP-Adresse ohne Eingriff seitens eines Benutzers.", //help445
	"CAT 5", //help458
	"Category 5. Wird für 10/100 MBit/s- oder 1 GBit/s-Ethernet-Verbindungen verwendet.", //help459
	"DB-25", //help474
	"Ein 25poliger Stecker für den Anschluss externer Modems oder serieller RS-232-Geräte.", //help475
	"DB-9", //help476
	"Ein 9 Pin Anschluß für RS-232 Verbindungen", //help477
	"dBd", //help478
	"Dezibel pro Dipol-Antenne.", //help479
	"Glasfasertechnik", //help518
	"Das Übertragen von Daten mittels Lichtwellen über Glas- oder Plastikfasern.", //help519
	"Gemeinsamer Dateizugriff", //help522
	"Die Möglichkeit, dass auf Dateien auf Rechnern in einem Netzwerk durch andere Rechner im Netzwerk zugegriffen werden kann. Hierfür können verschiedene Zugriffsrechte festgelegt werden.", //help523
	"File Transfer Protocol (Dateiübertragungsprotokoll). Die einfachste Möglichkeit, um Dateien über das Internet zwischen verschiedenen Rechnern auszutauschen.", //help528
	"Verstärkung", //help531
	"Der Betrag, um den ein Verstärker das Funksignal verstärkt.", //help532
	"Streuwertfunktion", //help544
	"Das Zerlegen einer Zeichenkette in mehrere kurze Zeichenketten mit vordefinierter Länge.", //help545
	"Hop", //help548
	"IIS", //help563
	"Internet Information Server. Ein Webserver und FTP-Server, der von Microsoft bereitgestellt wird.", //help564
	"Intranet", //help579
	"Ein privates Netzwerk.", //help580
	"Eindringungserkennung", //help581
	"Ein Schutztyp, bei dem das Netzwerk permanent auf Angriffe von innerhalb oder außerhalb des Netzwerkes überwacht wird.", //help582
	"Java", //help588
	"Eine Programmiersprache, die zum Erstellen von Programmen und Applets für Internetseiten verwendet wird.", //help589
	"LPR/LPD", //help602
	"Line Printer Requestor&quot;/&quot;Line Printer Daemon&quot;. Ein TCP/IP-Protokoll zur Übertragung von Druckdaten an Drucker.", //help603
	"MDI", //help609
	"Medium Dependent Interface (Übertragungsmedium-abhängige Schnittstelle). Ein Ethernet-Port für den Anschluss an ein nicht gekreuztes Kabel.", //help610
	"MDIX", //help611
	"Medium Dependent Interface Crossover(Übertragungsmedium-abhängige Schnittstelle, gekreuzt). Ein Ethernet-Port für den Anschluss an ein gekreuztes Kabel.", //help612
	"MIB", //help613
	"Management Information Base (Verwaltungsinformationsdatenbank). Eine Reihe an Objekten, die über SNMP verwaltet werden können.", //help614
	"Modem", //help615
	"Ein Gerät, das digitale Signale eines Rechners in analoge Signale moduliert, um diese analogen Signale über Telefonleitungen übertragen zu können. Das Modem demoduliert auch die analogen Signale, die über die Telefonleitung eingehen, in digitale und damit für den Rechner lesbare Signale.", //help616
	"Okt.", //tt_Oct
	"Sender", //sa_Originator
	"Orthogonal Frequency-Division Multiplexing (Orthogonales Frequenzmultiplexing). Die sowohl für 802.11a als auch 802.11g verwendete Modulationstechnik.", //help637
	"Open Shortest Path First (kürzesten Pfad zuerst öffnen). Ein Routingprotokoll, das in großen Netzwerken häufiger zum Einsatz kommt als RIP. Bei OSPF werden nur die Änderungen in der Routingtabelle an alle anderen Router im Netzwerk übertragen. Bei RIP hingegen wird die gesamte Routingtabelle in regelmäßigen Abständen an alle anderen Router übertragen.", //help641
	"OSI", //help638
	"Die Konfiguration im offenen Modus ist nicht sicher.", //msg_non_sec
	"Personal", //LW24
	"Die Verbindung von Netzwerkgeräten auf eine Reichweite von 10 Metern.", //help644
	"PoE", //help649
	"Power over Ethernet (Strom über Ethernet). Die Möglichkeit zum Übertragen von Strom über die ungenutzten Kabelpaare eines Ethernet-Kabels der Kategorie 5.", //help650
	"RJ-11", //help672
	"Die am häufigsten genutzte Verbindungsmethode für Telefone.", //help673
	"RS-232C", //help676
	"Die Schnittstelle für die serielle Kommunikation zwischen Rechnern und anderen zugehörigen Geräten.", //help677
	"SOHO", //help693
	"Klein- und Heimbüros", //help694
	"TFTP", //help711
	"Trivial File Transfer Protocol (Triviales Dateiübertragungsprotokoll). Ein sehr einfaches Dienstprogramm zur Übertragung von Dateien, das einfacher zu nutzen ist als FTP, jedoch weniger Funktionen bietet.", //help712
	"VLAN", //help733
	"Virtuelles LAN.", //help734
	"WDS", //help743
	"Wireless Distribution System (Drahtloses Verteilungssystem). Ein System, das die drahtlose Verbindung von Zugriffspunkten untereinander ermöglicht.", //help744
	"Yagi-Antenne", //help763
	"Eine Richtfunkantenne, die zum Bündeln von Funksignalen auf ein spezifisches Ziel eingesetzt wird.", //help764
	"Beachten Sie, dass in einer Protokollmeldung die Sprache verwendet ist, die zum Zeitpunkt des protokollierten Ereignisses aktiv ist. Werden die Spracheinstellungen verändert, werden ggf. bestimmte Protokollmeldungen in einer Sprache, und andere Protokollmeldungen in einer anderen Sprache angezeigt.", //help795a
	"Intern", //sa_Internal
	"Extern", //sa_External
	"OpenDNS&reg; Kinderschutz&#8482", //DNS_TEXT7
	"Select a filter that controls access as needed for this admin port. If you do not see the filter you need in the list of filters, go to the <a href ='Inbound_Filter.asp' onclick ='return jump_if();'>Advanced &rarr;&nbsp;Inbound&nbsp;Filter</a> screen an", //help831_1
	"Optionen zur Erhöhung der Geschwindigkeit und Zuverlässigkeit Ihrer Internetverbindung, zum Einsatz von Inhaltsfiltern und zum Phishing-Schutz. Wählen Sie aus vorkonfigurierten Paketen Ihre Pakete aus oder registrieren Sie Ihren Router mit OpenDNS&reg; und wählen Sie zur Erstellung Ihrer benutzerdefinierten Sperrfunktion unter 50 Inhaltskategorien die für Sie geeigneten aus.", //DNS_TEXT1
	"Zeitplanregeln hinzufügen/bearbeiten", //help191
	"Speichert die neue oder bearbeitete Filterregel für eingehenden Verkehr in der folgenden Liste.", //help198
	"Unbekannt (bitte warten...)", //_unknown_wait
	"Unbekannt", //_unknown
	"nicht verfügbar", //_na
	"Noch keine Computerinformationen.", //_sdi_nciy
	"DHCP-Client", //_sdi_dhcpclient
	"BigPond-Client", //_sdi_bpc
	"Ältere Geräte bzw. ältere Technologie.", //help600
	"Keine Multicast Gruppen Information verfügbar.", //_bln_nmgmy
	"Nicht richtig konfiguriert", //_sdi_s1
	" Statusänderung (bitte warten...)", //_sdi_s10
	" Abgemeldet", //_sdi_s8
	" Fehlgeschlagen", //_sdi_s9
	"Tag(e),", //_sdi_days
	"(Verbindungsabbruch in", //_sdi_disconnectpending
	"Sekunden)", //_sdi_secs
	"DHCP-Erneuerung", //sd_Renew
	"DHCP-Freigabe", //sd_Release
	"Trennen", //sd_Disconnect
	"BigPond-Anmeldung", //sd_bp_login
	"BigPond-Abmeldung", //sd_bp_logout
	"Kanal", //_channel
	"Systemprotokolle", //sl_SLogs
	"Druck-Server Status", //sps_intro2
	"Drucker werden", //sps_pare
	"Routing-Tabelle", //sr_RTable
	"Das Routing-Status-Menü zeigt Informationen zu den Routen, die auf Ihrem Router aktiviert wurden. Die Liste zeigt die Ziel-IP-Adresse, Gateway-IP-Adresse, Subnetzmaske, Metrik und Schnittstelle für jede Route.", //sr_intro
	"Statistiken Netzwerkverkehr", //ss_title_stats
	"Liste drahtloser zugeordneter Clients", //sw_title
	"Ungültiger Wert für Administrator-Leerlaufzeitlimit; dieses muss sich im Bereich (1..65535) befinden", //ta_alert_1
	"Stellen Sie sicher, dass das Kabel zwischen dem ADSL/Kabelmodem und dem Router korrekt angeschlossen ist. Der Router wird noch einmal versuchen, Ihren Internetverbindungstyp zu erkennen.", //ES_CABLELOST_dsc1
	"Die beiden Kennwörter müssen übereinstimmen. Geben Sie sie noch einmal ein.", //_pwsame
	"Ungültiger Remote Management-Port '+data.wan_web_port+', er sollte im Bereich (1..65535) sein", //ta_alert_3
	"Der angegebene DDNS-Dienstanbieter wird nicht unterstützt.", //_invalidddnsserver
	"Die angegebene Serveradresse ist leer", //_blankddnsserver
	"Ändern Sie bitte zuerst das IPv6 WAN-Protokoll.", //IPV6_TEXT1
	"Der Zeitlimit-Wert darf nicht Null sein.", //td_alert_2
	"Der Zeitlimit-Wert darf nicht größer als 8760 sein.", //td_alert_3
	"Dynamischer DNS (DDNS)", //td_DDNSDDNS
	"Dynamischen DNS-Server auswählen", //tt_SelDynDns
	"Es muss ein gültiger Kontoname eingegeben werden", //_emailaccnameisblank
	"Das Feld „Von“ Email-Adresse sollte nicht leer sein.", //_blankfromemailaddr
	"Das Feld „An“ Email-Adresse sollte nicht leer sein.", //_blanktomemailaddr
	"Das Feld „SMTP Server Adresse“ sollte nicht leer sein", //_blanksmtpmailaddr
	"Die Email Adresse ' + from_addr + ' ist unzulässig.", //_badfromemailaddr
	"Die Email Adresse ' + to_addr + ' ist unzulässig.", //_badtoemailaddr
	"Die SMTP Server Adresse ' + data.smtp_email_server_addr + ' ist unzulässig.", //_invalidsmtpserveraddr
	"Ungültige SMTP-Serveradresse", //_badsmtpserveraddr
	"Eine neuere Firmware-Version ist verfügbar.", //tf_NFWA
	"Die Web-Session ist ausgelaufen.Bitte Loggen Sie sich erneut ein um auf die Seite zu zugreifen.", //tf_alert_1
	"Laut Ergebnis der Online-Prüfung ist die neueste Firmware-Version:", //tf_LFWVis
	"Firmware-Aktualisierungsprüfung läuft.", //tf_FWCinP
	"Verfügbarkeit neuer Firmware wird geprüft", //tf_Ching_FW
	"Die E-Mail-Benachrichtigung ist deaktiviert.", //tf_EM_not
	"Neuste Firmware-Version", //tf_LFWV
	"Jetzt online nach aktueller Firmware-Version suchen", //tf_FWChNow
	"Firmware-Aktualisierungen werden regelmäßig veröffentlicht, um die Funktionalität Ihres Routers zu verbessern und Funktionen hinzuzufügen. Sollte ein Problem mit einer spezifischen Funktion des Routers aufgetreten sein, klicken Sie auf <strong>Jetzt online nach aktueller Firmware-Version suchen</strong>, um zu prüfen, ob eine aktualisierte Version der Firmware für Ihren Router auf unserer Support-Website verfügbar ist.", //TA17
	"Suche nach Druckern...", //tps_sfp
	"Doppelklicken Sie auf ein Symbol zum Installieren des Druckers", //tps_dci
	"Druck-Server Setup", //tps_intro2
	"Es wurde kein Tag ausgewählt für den Zeitplan namens '+(data.sched_table[i].sched_name)+'", //tsc_alert_1
	"Ungültige Zeitangabe", //tsc_alert_2
	"\"Der Name des Zeitplans '\"+(data.sched_table[i].sched_name)+\"' ist reserviert und kann nicht verwendet werden\"", //tsc_alert_3
	"Dieser Zeitplan wird bereits verwendet", //tsc_alert_6
	"Kein Speicherplatz mehr für weitere Einträge", //tsc_alert_9
	"Tag(e) wählen", //tsc_SelDays
	"Zeitraum", //tsc_TimeFr
	"Die IP-Adresse des Syslog-Servers sollte nicht dieselbe IP-Adresse wie die des Gateways sein", //tsl_alert_3
	"Die IP-Adresse des Syslog-Servers befindet sich im WAN-Subnetz, diese sollte aber innerhalb des LAN-Subnetz liegen ('+lan_subnet+')", //tsl_alert_1
	"Die IP-Adresse des Syslog-Servers sollte sich innerhalb des LAN-Subnetzes befinden ('+lan_subnet+')", //tsl_alert_2
	"Wenn die Konfiguration des Routers abgeschlossen ist, können Sie die vorgenommen Einstellungen in einer Konfigurationsdatei speichern.", //ZM18
	"Millisekunden. TTL =", //tsc_pingt_msg9
	"NTP", //help635
	"Die Gateway-Zeit wurde aktualisiert", //tt_alert_tupdt
	"Woche", //TA24
	"Wochentag", //TA25
	"Verbotener Zugriff", //fb_FbAc
	"Sentinel hat Web Access blockiert", //sentinel_1
	"Der Zugriff von diesem Computer zu der Webseite wurde vom Sentinel Service Ihres Routers blockiert.", //sentinel_2
	"Wenden Sie sich an Ihren Sentinel-Administrator, um den Zugriff auf diese Seite freischalten zu lassen.", //sentinal_3
	"Ausfall", //fl_Failure
	"Die neuen Einstellungen wurden aufgrund eines Fehlers NICHT gespeichert.", //fl_text
	"Neue Firmware-Aktualisierung ist verfügbar. Sie werden nach der Anmeldung auf die Upgrade-Seite weitergeleitet.", //li_newfw
	"Sie werden jetzt auf die Anmeldeseite weitergeleitet.", //rd_p_1
	"Falls Sie nicht automatisch zur Anmeldeseite weitergeleitet werden, klicken Sie <a href='login.asp>hier</a>.", //rd_p_2
	"Wiederherstellung der Einstellungen", //rs_Restoring_Settings
	"Die Wiederherstellungsdatei ist unzulässig.", //reh
	"Einstellungen werden wiederhergestellt, bitte warten ...", //rs_RSPW
	"Konvertierte lokale Daten", //rs_cld
	"Fertig!", //rs_Done
	"Entpackte lokale Daten", //rs_uld
	"Entpackte gespeicherte Daten", //rs_usd
	"Konvertierte gespeicherte Daten", //rs_csd
	"Neu gepackt", //rs_Repacked
	"Konvertiert", //rs_Converted
	"Speichern", //rs_Saving
	"Damit die neuen Einstellungen übernommen werden können, müssen Sie den Router neu starten. Sie können den Router unter Verwendung der Schaltfläche unten neu starten oder weitere Änderungen vornehmen und dann die Schaltfläche 'Neustart' auf der Seite 'Extras/System' verwenden.", //sc_intro_rb
	"Neu anmelden", //_relogin
	"Ungültige WAN-Subnetzmaske.", //_badWANsub
	"Ungültige Gateway-IP-Adresse.", //wwa_pv5_alert_4
	"Die Gateway IP-Adresse ist nicht im WAN-Subnetz", //wwa_pv5_alert_5
	"Sie müssen den primären DNS-Server bestimmen", //wwa_pv5_alert_8
	"Ungültige primäre DNS-IP-Adresse.", //wwa_pv5_alert_6
	"Ungültige sekundäre DNS-IP-Adresse.", //wwa_pv5_alert_7
	"Das Feld Benutzername darf nicht leer sein", //wwa_pv5_alert_21
	"Ungültige PPTP-Gateway-IP-Adresse", //_badPPTPgwip
	"Ungültige PPTP Server-Adresse", //wwa_pv5_alert_15
	"Ungültige L2TP-Gateway-IP-Adresse", //_badL2TPgwip
	"Ungültige L2TP-Serveradresse", //wwa_pv5_alert_20
	"Zum Schutz Ihres Netzwerks vor Hackern und unbefugten Benutzern wird dringend empfohlen, dass Sie eine der folgenden Sicherheitseinstellungen für drahtlose Netzwerke auswählen.", //wwl_intro_s3_1
	"Es gibt drei Ebenen der Drahtlossicherheit - Gute Sicherheit, Bessere Sicherheit UND Beste Sicherheit. Die Ebene, die Sie wählen, hängt davon ab, welche Sicherheitsfunktionen Ihre drahtlosen Adapter (auch Funkadapter oder Wireless Adapter genannt) unterstützen.", //wwl_intro_s3_2r
	"Wireless-Sicherheitskennwort", //wwl_WSP_1
	"WPA-PSK/TKIP (auch WPA Personal genannt)", //wwl_wpa
	"WPA-PSK/AES (auch als WPA2 Personal bezeichnet)", //wwl_wpa2
	"TELNET", //gw_vs_0
	"REMOTE-DESKTOP", //gw_vs_8
	"AIM Talk", //gw_sa_0
	"Calista IP-Telefon", //gw_sa_2
	"ICQ", //gw_sa_3
	"MSN Messenger", //gw_sa_4
	"PalTalk", //YM47
	"BigPond-Server auswählen", //gw_SelBPS
	"Name1", //gw_bp_0
	"Name2", //gw_bp_1
	"Name3", //gw_bp_2
	"PlayStation2", //gw_gm_81
	"WCN ActiveX-Steuerelement ist nicht verfügbar. Bitte überprüfen Sie die Sicherheitseinstellungen und aktualisieren Sie diese Seite, um es zu installieren.", //gw_wcn_alert_4
	"WCN unterstützt derzeit nur den Schlüsselindex 1.", //gw_wcn_alert5
	"WCN unterstützt den WPA2-Modus derzeit nicht.", //gw_wcn_alert6
	"WCN unterstützt die WPA-Enterprise-Authentifizierung derzeit nicht.", //gw_wcn_alert7
	"Drahtloseinstellungen wurden erfolgreich gespeichert", //gw_wcn_err_ok
	"Fehlercode:", //gw_wcn_err_code
	"Diese Betriebssystemversion unterstützt WCN nicht", //gw_wcn_err_os_version
	"Laden der Drahtlos-Konfigurationsdatei fehlgeschlagen. Führen Sie den Windows Drahtlosnetzwerkinstallations-Assistent aus, um die Konfigurationsdatei zu erstellen bzw. neu zu erstellen", //gw_wcn_err_load_config
	"Hinzufügen des Drahtlosprofils fehlgeschlagen. Stellen Sie sicher, dass der neue SSID nicht mit einem vorhandenen Profil in Konflikt steht", //gw_wcn_err_provision
	"Speichern der drahtlosen Konfiguration fehlgeschlagen. Bitte die Sicherheitseinstellungen prüfen.", //gw_wcn_err_io_write_config
	"Verschlüsseln der drahtlosen Daten fehlgeschlagen.", //gw_wcn_err_encryption
	"Interne Ausnahme Fehler", //gw_wcn_err_exception
	"WCN ActiveX Steuerung ist fehlgeschlagen. Überprüfen Sie bitte die Sicherheitseinstellungen und wiederholen Sie diesen Schritt, um sie zu installieren.", //gw_wcn_err_com
	"Ungültige drahtlose Einstellungen. Überprüfen Sie bitte Ihre Einstellungen für drahtlose Netzwerke.", //gw_wcn_err_bad_wsetting_entry
	"Die drahtlose XML Datei kann nicht herstellt werden", //gw_wcn_err_bad_wps_profile
	"WPA Sicherheits Modus fehlgeschlagen. Überprüfen Sie bitte Ihre WPA Sicherheiteinstellungen", //gw_wcn_err_unsupported_wsetting
	"Der MSXML2 DOM Parser konnte, die Zeichenkette im XML-Format nicht analysieren", //gw_wcn_err_dom_processing
	"Unerwarteter Fehler", //gw_wcn_err_default
	"Alle zugelassen", //adv_Everyone
	"Keiner zugelassen", //adv_Noone
	"In Warteschlange", //psQueued
	"Gestartet", //psStarting
	"Fertig", //psClosed
	"Wartet", //psIdle
	"Bereit", //psReady
	"Angebot für %s PPPoE-Sitzung erhalten. Der angebotene Service ist %s von %s (%m)", //GW_PPPOE_EVENT_OFFER
	"Nicht angeschlossen", //psUnplugged
	"Druckt", //psPrinting
	"PAP hat Authentifizierungsantwort \'%s\' an Remotepeer übertragen.", //IPPPPPAP_AUTH_RESULT
	"Die Zeichenkette ' + value + ' ist zu lang\n(maximale Länge ist ' + length + ' Zeichen).", //up_gS_1
	"Die Nummer ' + value + ' ist ungültig.", //up_gIUH_1
	"Die Nummer ' + value + ' muss positiv sein.", //up_gIUH_2
	"Die Nummer ' + value + ' muss zwischen '+ min + ' und ' + max + ' liegen.", //up_gIUH_3
	"Die Hex-Zeichenkette ' + value + ' ist ungültig.", //up_gH_1
	"Es ist kein Platz für weitere Einträge.", //up_ae_se_1
	"Das Feld \"%s\" darf nicht leer sein.", //up_ai_se_2
	"this.primary_key_name '+ this.thearray[-1][this.primary_key] +' wird bereits verwendet", //up_ae_se_3
	"Einige Änderungen im aktuell bearbeiteten Eintrag wurden noch nicht gespeichert.", //up_ae_wic_1
	"Klicken Sie auf 'Ok', um diese Änderungen zu verwerfen und den geforderten Vorgang auszuführen.", //up_ae_wic_2
	"Hinweis:<br />Wird DNS Relay zusammen mit der Funktion 'Advanced DNS' aktiviert, empfangen Ihre Arbeitsplatzrechner im Netz, die eine IP-Adresse vom DHCP-Server des Routers erhalten, die IP-Adresse des Routers: 192.168.0.1.", //_Advanced_02
	"Möchten Sie alle Änderungen verwerfen, die Sie in diesem Assistenten vorgenommen haben?", //up_fm_dc_1
	"Das Wiederherstellen der Einstellungen ist fehlgeschlagen", //up_fm_re_1
	"Klicken Sie auf 'OK', um fortzufahren", //up_fm_re_2
	"Ungültige Einstellungsdatei", //up_fm_dr_1
	"Ungültige Einstellungsdatei", //up_fm_dr_2
	"Wiederhergestellte Daten nicht zulässig", //up_fm_dr_3
	"Dieser Vorgang kann nicht abgeschlossen werden, da die Netzwerkverbindung offenbar ausgefallen ist.", //up_if_1
	"Neustart.", //up_rb_3
	"Auf Herstellerstandards zurücksetzen und neu starten.", //up_rb_6
	"Die '+name+' Portbereich-Zeichenkette '+input_string+' ist ungültig.", //up_vp_1
	"Der '+name+' Port '+n+' in der Portbereich-Zeichenkette '+input_string+' muss zwischen 1 und 65535 liegen.", //up_vp_2
	"Der '+name+' Portbereich'+got2[0]+' in der Portbereich-Zeichenkette '+input_string+' muss von einem niedrigen Port zu einem hohen Port gehen.", //up_vp_3
	"Die '+name+' Portbereich-Zeichenkette darf nicht leer sein.", //up_vp_0
	"Ein MAC-Adressenfeld darf nicht leer sein.", //up_vm_1
	"ist keine gültige MAC-Adresse.", //up_vm_2
	"Auf dieser Seite ist ein Fehler aufgetreten. Grund hierfür kann sein, dass Sie\n'+ sich nicht richtig angemeldet haben, z. B. nach einem Neustart.\n", //up_he_1
	"Klicken Sie auf OK, um zur Anmeldeseite zu wechseln, oder klicken Sie auf Abbrechen, um die \n+ Fehlermeldung anzuzeigen.", //up_he_2
	"Der Fehler in Zeile '+line+' von '+url+' ist:\n\'+msg+'\'.", //up_he_5
	"PalTalk", //gw_sa_5
	"Das blockierte Packet von %v zu %v wurde von einem falschen Netzwerk-Interface erhalten (IP Adress Spoofing)", //IPSTACK_REJECTED_SPOOFED_PACKET
	"Lease-Zuweisungsversuch fehlgeschlagen - mit Adresse %v und MAC von %m aktiven LAN-Host erkannt", //IPDHCPSERVER_HOST_IS_ACTIVE
	"%S Autorisierung des Dienstes fehlgeschlagen: Der Dienst ist nicht registriert", //BSECURE_LOG_AUTH_FAIL_UNREG
	"Geschätzte Verbindungsrate: %d KBit/s", //RATE_ESTIMATOR_RATE_IS
	"Filter – Paket zurückgewiesen von IP-Adresse %v Port %u, Protokoll %u, bis %v Port %u", //GW_IPFILTER_DENY
	"Es kann keine Verbindung zum E-Mail-Server aufgebaut werden", //GW_SMTP_EMAIL_CANNOT_CREATE_CONNECTION
	"Paket an unzulässiges Ziel %v fallengelassen ab %v", //IPNAT_ILLEGAL_DEST
	"%S Filterserver Verbindung wurde getrennt: Zeitüberschreitung", //BSECURE_LOG_FLTR_DISCONNECTED_TIMEOUT
	"Client %02x:%02x:%02x:%02x:%02x:%02x wurde die zugehörige Lease (%v) gesperrt.", //IPDHCPSERVER_LEASE_REVOKED1
	"Vorhergehende Nachricht 1 Mal wiederholt", //LOG_PREV_MSG_REPEATED_1_TIME
	"UPnP hat den VS-Eintrag %v <-> %v:%d <-> %v::%d %s in %s geändert", //GW_UPNP_PORTMAP_VS_CHANGE
	"Lease abgelaufen %v", //IPDHCPSERVER_LEASE_EXPIRED
	"%S Autorisierung des Dienstes fehlgeschlagen: Interner Fehler", //BSECURE_LOG_AUTH_FAIL_INTNL
	"Der Eintrag %v <-> %v:%d %s wurde von UPnP gelöscht", //GW_UPNP_PORTMAP_DEL
	"E-Mail kann nicht gesendet werden, da \'%s\' keine gültige \'An:\' –Adresse ist", //GW_SMTP_EMAIL_INVALID_TO_ADDRESS
	"%S Filterserver Verbindung getrennt: geschlossen", //BSECURE_LOG_FLTR_DISCONNECTED_CLOSED
	"Lease abgelaufen %v – wurde neu zugeordnet, da ein Client diese spezifische Adresse anforderte", //IPDHCPSERVER_LEASE_EXPIRED_SPECIFIC
	"%S Autorisierung des Dienstes erfolgreich", //BSECURE_LOG_AUTH_PASS
	"%S Autorisierung des Dienstes fehlgeschlagen: Authentifizierungsserver gab einen UNBEKANNTEN Fehler zurück", //BSECURE_LOG_AUTH_FAIL_UNKNW
	"Nur PAP", //wwan_auth_pap
	"%S Autorisierung des Dienstes fehlgeschlagen: Dienst muss erneuert werden", //BSECURE_LOG_AUTH_FAIL_RENEW
	"Client %m wünschte spezifische Adresse (%v). Die ist aber nicht verfügbar.", //IPDHCPSERVER_LEASE_DENIED
	"E-Mail kann nicht gesendet werden (Zeitüberschreitung der Verbindung)", //GW_SMTP_EMAIL_TIMEOUT
	"%S Autorisierung des Dienstes fehlgeschlagen: Authentifizierungsserver gab einen Datenbankfehler zurück", //BSECURE_LOG_AUTH_FAIL_DB
	"DHCP-Serverparameter %u wurde aktualisiert", //IPDHCPSERVER_PARAM_DB_UPDATED
	"Regeln für Anwendungen", //APP_RULES
	"Lease-Tabelle voll", //IPDHCPSERVER_LEASE_POOL_FULL
	"PAP-Authentifizierung fehlgeschlagen. Prüfen Sie die Anmeldeinformationen.", //IPPPPPAP_AUTH_SUCCESS
	"Erweitertes Netzwerk", //ADVANCED_NETWORKS
	"Neue Lease %v Client %m zugewiwsen", //IPDHCPSERVER_LEASE_ASSIGNED
	"%S Filterserver verbunden", //BSECURE_LOG_FLTR_CONNECTED
	"%S Authentifizierungsserver verbunden", //BSECURE_LOG_AUTH_CONNECTED
	"%S Autorisierung des Dienstes fehlgeschlagen: Das Authentifizierungs-Antwortpaket ist beschädigt", //BSECURE_LOG_AUTH_FAIL_PKT
	"SMTP-Client konnte keine Verbindung zum Server %v herstellen", //IPSMTPCLIENT_CONN_FAILED
	"PAP-Authentifizierung fehlgeschlagen. Prüfen Sie die Anmeldeinformationen.", //IPPPPPAP_AUTH_FAIL
	"Die neueste Firmwareversion, die vom Server geholt wurde, war %d.%d", //GW_LOG_ON_LATEST_FIRMWARE_RETRIEVED
	"E-Mail kann nicht gesendet werden (Sendestatus %u)", //GW_SMTP_EMAIL_SEND_FAILURE
	"Lease %v von Client %m freigegeben", //IPDHCPSERVER_LEASE_RELEASED
	"DHCP-Serverparameter %u wurde der Parameterdatenbank hinzugefügt", //IPDHCPSERVER_PARAM_DB_ADDED
	"PAP-Authentifizierung erfolgreich.", //IPPPPPAP_AUTH_TIMEOUT
	"UPnP hat Eintrag %v <-> %v:%d <-> %v:%d %s hinzugefügt; Timeout:%d '%s'", //GW_UPNP_PORTMAP_ADD
	"E-Mail kann nicht gesendet werden, da Server-IP-Adresse nicht bekannt", //GW_SMTP_EMAIL_NO_SERVER_IP_ADDRESS
	"UPnP erneuert Eintrag %v <-> %v:%d <-> %v:%d %s Timeout:%d '%s'", //GW_UPNP_PORTMAP_REFRESH
	"Abgelaufener UpnP-Eintrag %v <-> %v:%d <-> %v%d %s '%s'", //GW_UPNP_PORTMAP_EXPIRE
	"DHCP-Serverparameter %u wurde aus der Parameterdatenbank entfernt", //IPDHCPSERVER_PARAM_DB_REMOVED
	"Lease wurde aus Serverpool %v gelöscht", //IPDHCPSERVER_LEASE_DELETED
	"UPnP-Konflikt mit vorhandenem Eintrag %v <-> %v:%d <-> %v:%d %s '%s'", //GW_UPNP_PORTMAP_CONFLICT
	"Nicht alle erforderlichen Komponenten wurden geladen; diese Seite wird aktualisiert.", //TA1
	"ist keine gültige IP-Adresse", //aa_alert_11
	"Diese Zugriffssteuerungsregel ist bereits durch die Richtlinie  + data.access_ctrl_table[i].policy_name festgelegt", //aa_alert_1
	"Es gibt ' + unsaved_policies +' unspeicherte Regeln, möchten Sie diese Regeln verwerfen.", //aa_sched_conf_3
	"Die Port-Filterrichtlinie ' + data.access_ctrl_table[-1].port_filter_table[i].entry_name + ' ist doppelt.'", //aa_alert_16
	"Start IP-Adresse des Ziels für Port-Filter = '+data.access_ctrl_table[-1].port_filter_table[j].entry_name+' sollte sich nicht im LAN Subnetz ('+lan_subnet+') befinden", //aa_alert_2
	"End IP-Adresse des Ziels für Port-Filter = '+data.access_ctrl_table[-1].port_filter_table[j].entry_name+' sollte sich nicht im LAN Subnetz ('+lan_subnet+') befinden", //aa_alert_3
	"Ungültiger Ziel IP-Addressbereich für Port-Filter = '+data.access_ctrl_table[-1].port_filter_table[j].entry_name+'", //aa_alert_4
	"Ungültiger Zielport-Bereich für Port-Filter = '+data.access_ctrl_table[-1].port_filter_table[j].entry_name+' sollte sich im Bereich (1..65535) befinden", //aa_alert_5
	"Ziel-Startport für Port-Filter = '+data.access_ctrl_table[-1].port_filter_table[j].entry_name+' sollte nicht größer sein als der Ziel-Endport", //aa_alert_6
	"Sonstige", //_aa_other_machines
	"&copy; Copyright 2015 TRENDnet. All Rights Reserved.", //_copyright
	"Der gültige Bereich für den Fragmentierungsschwellenwert ist 256..65535", //aw_alert_1
	"Der gültige Bereich für den RTS-Schwellenwert ist 1..65535", //aw_alert_2
	"Der gültige Bereich für den Signalisierungszeitraum ist 20..1000", //aw_alert_3
	"Der gültige Bereich für das DTIM-Intervall ist 1..255", //aw_alert_4
	"DMZ-Adresse muss im LAN-Subnetz liegen('+lan_subnet+')", //af_alert_1
	"DMZ-Adresse ist nicht zulässig", //af_alert_2
	"(automatisch deaktiviert, wenn UPnP aktiviert ist)", //TA19
	"Dieser '+ data.game_rules[j].entry_name +' Eintrag ist bereits vorhanden.", //ag_alert_4
	"Dieser '+ data.game_rules[j].entry_name + ' Datensatz ist ein Duplikat von '' + data.game_rules[i].entry_name + ''.", //ag_alert_5
	"TCP Ports ['+data.game_rules[i].tcp_ports_to_open+'] widerspricht '+data.game_rules[j].entry_name+' TCP Ports ['+data.game_rules[j].tcp_ports_to_open+']", //ag_conflict10
	"UDP Ports ['+data.game_rules[i].udp_ports_to_open+'] widerspricht '+data.game_rules[j].entry_name+' UDP Ports ['+data.game_rules[j].udp_ports_to_open+']", //ag_conflict20
	"Wählen Sie einen Zeitplan für den Datensatz ' + data.game_rules[i].entry_name + ''.'", //ag_conflict21
	"IP-Adresse für '+data.game_rules[i].entry_name+' muss innerhalb des LAN-Subnetz liegen ('+lan_subnet+')", //ag_alert_1
	"IP-Adresse für '+data.game_rules[i].entry_name+' ist nicht zulässig", //ag_alert_3
	"Die Felder 'Zu öffnende TCP-Ports' und 'Zu öffnende UDP-Ports' dürfen nicht leer sein", //ag_alert2
	"TCP-Ports", //_tcpports
	"UDP-Ports", //_udpports
	"%s Ports[%s] sind mit dem Fernverwaltungs-Port im Konflikt", //ag_conflict4
	"Der Name dieses Eintrags kann nicht geändert werden, da dieser auf Seite '+used_page+' verwendet wird.", //tsc_alert_7
	"Ungültiger Quell-IP-Bereich für '+data.ingress_rules[i].ingress_filter_name+'('+data.ingress_rules[i].ip_range_table[j].ip_start+','+data.ingress_rules[i].ip_range_table[j].ip_end+')", //ai_alert_3
	"Aktivieren Sie mindestens einen Quell-IP-Bereich für '%s'", //GW_FIREWALL_NO_IP_RANGE_INVALID
	"Der Eingangsfilterbereich '%s - %s' ist dupliziert", //ai_alert_7
	"Der Inbound Filter-Name '+(data.ingress_rules[i].ingress_filter_name)+' ist bereits belegt und kann nicht verwendet werden", //ai_alert_4
	"Die Eingangs-Filterregel ' + data.ingress_rules[-1].ingress_filter_name + ' ist doppelt vorhanden.", //ai_alert_6
	"Dieser Eintrag kann nicht gelöscht werden, da dieser auf Seite '+x+' verwendet wird.", //tsc_alert_5
	"Inbound Filter Regeln", //ai_title_2
	"Bearbeiten", //_edit
	"Quell-IP-Bereich", //_srcip
	"Quell-IP Start", //ai_c2
	"Quell-IP Ende", //ai_c3
	"Die \"' + saved_records[i].mac_addr + '\" MAC-Adresse ist dupliziert", //amaf_alert_1
	"Verweigern Sie den Zugriff zu allen Geräten mit Ausnahme derer in dieser Liste (gemäß den „Filter-Einstellungen“):", //am_cMT_deny
	"Erlauben Sie Zugriff zu allen Geräten mit Ausnahme derer in dieser Liste (gemäß den „Filter-Einstellungen“):", //am_cMT_Allow
	"Es liegen keine Routeninformationen vor.", //_sr_nriy
	"Diese interne Route wird bereits verwendet", //ar_alert_1
	"Diese Route ist bereits vorhanden", //ar_alert_2
	"Metrischer Wert sollte zwischen (1..16) sein.", //ar_alert_3
	"Nächster Hop nicht auf der festgelegten Schnittstelle", //ar_alert_4
	"Ungültige Netzmaske.", //ar_alert_5
	"Die Routing-Option erlaubt Ihnen, festgelegte Routen zu bestimmten Zielen zu definieren.", //ar_RoutI
	"Route", //ar_Route
	"Routenliste", //ar_RoutesList
	"Löschen", //_delete
	"Existierende Routen", //ar_ERTable
	"Der Name der Anwendungsregel ' + saved_records[i].entry_name + ' ist doppelt.", //ag_alert_duplicate_name
	"Der Name der Anwendungsregeln ' + saved_records[i].entry_name + ' ist eine Duplikat von ' + saved_records[i].entry_name + ';", //ag_alert_duplicate
	"Diese Regel wird bereits verwendet", //ag_inuse
	"'Trigger Port-Bereich '+protocols[ae.thearray[-1].trigger_ports.protocol]+' ['+ae.thearray[-1].trigger_ports.port_range+'] steht im Konflikt mit '+saved_records[i].entry_name+':'+protocols[saved_records[i].trigger_ports.protocol]+' ['+saved_records[i].trigger_ports.port_range+']'", //_specapps_alert_2
	"Trigger Port-Bereich", //_specapps_tpr
	"Eingabe Port-Bereich", //_specapps_ipr
	"Regel für Spezialanwendungen", //as_title_SAR
	"Trigger Port-Bereich", //as_TPRange
	"Bsp.", //as_ex
	"Triggerprotokoll", //as_TPR
	"Eingabe Port-Bereich", //as_IPR
	"Eingabeprotokoll", //as_IPrt
	"Max. Übertragungsrate sollte zwischen 8 Kbit/s und 10 Mbit/s (inkl.) sein.", //at_alert_1_1
	"Der Name muss angegeben werden", //at_alert_15
	"Die Regel ''+data.qos_rules[i].entry_name+'' Priorität '+data.qos_rules[i].priority+' sollte zwischen 1 und 255 inklusive sein.'", //at_alert_16
	"Regel ''+data.qos_rules[i].entry_name+'' Protokoll muss angegeben werden.'", //at_alert_17
	"Die Regel ''+data.qos_rules[i].entry_name+'' Quell-IP-Bereich ''+data.qos_rules[i].source_ip_start+'' sollte innerhalb des LAN-Subnetzes ('+lan_subnet+') sein.'", //at_alert_2
	"Die Regel ''+data.qos_rules[i].entry_name+'' Quell-IP-Bereich ''+data.qos_rules[i].source_ip_start+'' ist ungültig.'", //at_alert_18
	"Die Regel ''+data.qos_rules[i].entry_name+'' Quell-IP-Bereich ''+data.qos_rules[i].source_ip_end+'' sollte innerhalb des LAN-Subnetzes ('+lan_subnet+') sein.'", //at_alert_3
	"Die Regel ''+data.qos_rules[i].entry_name+'' Quell-IP-Bereich ''+data.qos_rules[i].source_ip_end+'' ist ungültig.'", //at_alert_19
	"Die Regel ''+data.qos_rules[i].entry_name+'' Quell-IP-Bereich ist ungültig.'", //at_alert_4
	"Die Regel ''+data.qos_rules[i].entry_name+'' Ziel-IP-Bereich ''+data.qos_rules[i].dest_ip_start+'' sollte nicht innerhalb des LAN-Subnetzes ('+lan_subnet+') sein.'", //at_alert_5
	"Die Regel ''+data.qos_rules[i].entry_name+'' Ziel-IP-Bereich ''+data.qos_rules[i].dest_ip_start+'' ist ungültig.'", //at_alert_20
	"Die Regel ''+data.qos_rules[i].entry_name+'' Ziel-IP-Bereich ''+data.qos_rules[i].dest_ip_end+'' sollte nicht innerhalb des LAN-Subnetzes ('+lan_subnet+') sein.'", //at_alert_6
	"Die Regel ''+data.qos_rules[i].entry_name+'' Ziel-IP-Bereich ''+data.qos_rules[i].dest_ip_end+'' ist ungültig.'", //at_alert_21
	"Die Regel ''+data.qos_rules[i].entry_name+'' Ziel-IP-Bereich ist ungültig.'", //at_alert_8
	"Die Regel ''+data.qos_rules[i].entry_name+'' Quell-Port-Bereich sollte zwischen 0 und 65535 inklusive sein.'", //at_alert_7
	"Quell-Port-Start für Regel ''+data.qos_rules[i].entry_name+'' sollte geringer als Quell-Port-Ende sein.'", //at_alert_10
	"Die Regel ''+data.qos_rules[i].entry_name+'' Ziel-Port-Bereich sollte zwischen 0 und 65535 inklusive sein.'", //at_alert_9
	"Ziel-Port-Start für Regel ''+data.qos_rules[i].entry_name+'' sollte geringer als Ziel-Port-Ende sein.'", //at_alert_11
	"Der Name ''+data.qos_rules[i].entry_name+'' wird bereits verwendet.'", //at_alert_22
	"Quell-/Ziel-IP-Bereich für ''+data.qos_rules[i].entry_name+'' überschneidet sich mit ''+data.qos_rules[i].entry_name+''.'", //at_alert_23
	"Quell-/Ziel-IP/Portbereich für ''+data.qos_rules[i].entry_name+'' überschneidet sich mit ''+data.qos_rules[i].entry_name+''.'", //at_alert_24
	"Protokoll \"ANY\" enthält ICMP. Portbereiche sind deshalb deaktiviert. Wählen Sie TCP oder UDP, wenn Sie Portbereiche konfigurieren möchten.", //at_alert_14
	"Beliebig", //at_Prot_0
	"Quellport-Bereich", //_srcport
	"Ziel IP Bereich", //at_DIPR
	"Zielport-Bereich", //at_DPR
	"Der Eintrag ' + data.virtual_servers[i].entry_name + ' ist doppelt vorhanden.", //av_alert_11
	"Der Datensatz ' + data.virtual_servers[j].entry_name + ' ist ein Duplikat von ' + data.virtual_servers[i].entry_name + '.", //av_alert_21
	"Wählen Sie einen Zeitplan für den Datensatz ' + data.virtual_servers[i].entry_name + '.", //av_alert_24
	"IP-Adresse für ' + data.virtual_servers[i].entry_name + ' sollte innerhalb eines LAN-Subnetzes ('+lan_subnet+') sein", //av_alert_1
	"IP-Adresse für ' + data.virtual_servers[i].entry_name + ' ist nicht möglich", //av_alert_2
	"Privater Port für ' + data.virtual_servers[i].entry_name + ' sollte im Bereich (1..65535) sein", //av_alert_3
	"Öffentlicher Port für ' + data.virtual_servers[i].entry_name + ' sollte im Bereich (1..65535) sein", //av_alert_4
	"Öffentlicher Port sollte nicht gleich dem Fernwartungs-Port sein", //av_alert_12
	"Ein Eintrag für ICMP (Protokoll 1) kann nicht erstellt werden, da der Router dann nicht richtig arbeiten kann", //av_alert_18
	"Es konnte kein Eintrag für IGMP (Protokoll 2) erstellt werden, weil das die korrekte Arbeitsweise des Routers verhindert", //av_alert_23
	"Bitte wählen Sie TCP anstelle Protokoll 6 und geben Sie Portdetails an", //av_alert_19
	"Bitte wählen Sie UDP anstelle Protokoll 17 und geben Sie Portdetails an", //av_alert_20
	"Anderes Protokoll für ' + data.virtual_servers[i].entry_name + ' sollte im Bereich (2..5, 7..16 oder 18..255) sein", //av_alert_13
	"Protokoll für ' + data.virtual_servers[i].entry_name + ' überschneidet sich mit ' + data.virtual_servers[j].entry_name+ '", //av_alert_17
	"Ports für ' + data.virtual_servers[i].entry_name + ' überschneidet sich mit ' + data.virtual_servers[j].entry_name+'", //av_alert_5
	"Privater Port für ' + data.virtual_servers[i].entry_name + ' widerspricht ' + data.virtual_servers[j].entry_name+'", //av_alert_6
	"FTP ALG ist aktiviert worden", //av_alert_7
	"PPTP ALG wurde aktiviert", //av_alert_8
	"Wake-On-LAN ALG wurde aktiviert", //av_alert_9
	"H.323 ALG ist aktiviert worden", //av_alert_10
	"Öffentlich", //_public
	"Weitere", //at_Prot__1
	"Privat", //_private
	"Website", //aa_WebSite
	"Das Protokoll HTTPS wird nicht unterstützt.", //awf_alert_4
	"Die Website-Adresse %s' wird bereits verwendet.", //awf_alert_5
	"Die Web-Adressen: ' + invalid_wf_str + 'sind ungültig.", //awf_alert_7
	"'Die Web-Adresse: ' + invalid_wf_str + ' ist ungültig.'", //awf_alert_8
	"Internet Verbindungs-Assistent", //int_ConWz2
	"Manuelles Einrichten der Internetverbindungsoptionen", //int_WlsWz
	"Wenn Sie Netzwerk-Neuling sind und vorher nie einen Router konfiguriert haben, klicken Sie an <strong>Installations-Assistent</strong> und der Router wird Sie durch einige einfache Schritte führen, um Ihr Netzwerk betriebsbereit zu machen.", //hhbi_wiz
	"Wenn Sie bereits Erfahrung mit der Konfiguration eines Routers haben, klicken Sie <strong>Manuell konfigurieren</strong> an, um alle Einstellungen manuell vorzunehmen.", //hhbi_man
	"Es wurden noch keine dynamischen Clients entdeckt.", //bd_noneyet
	"Die Gültigkeit wurde aufgehoben", //bd_revoked
	"Ungültige LAN-IP-Adresse", //bln_alert_3
	"LAN-Subnetz steht in Konflikt mit WAN-Subnetz", //bd_alert_10
	"Der DHCP Adressbereich BIS ist nicht im LAN Subnetz.", //bd_alert_11
	"Die DHCP FROM-Adresse enthält keinen gültigen Host-Startwert.", //bd_alert_1
	"Der DHCP-Adressbereich muss sich von einer niedrigen Adresse zu einer hohen Adresse erstrecken, nicht von einer hohen zu einer niedrigen Adresse", //bd_alert_3
	"Der DHCP Adressbereich darf nicht die Subnetz Broadcast Adresse einschließen.", //bd_alert_13
	"Die Zahl der IP-Adressen im angegebenen Bereich überschreitet die Grenze von 256.", //bd_alert_12
	"DHCP Gültigkeitsdauer darf nicht 0 sein", //bd_alert_5
	"Die reservierte IP-Adresse für diese MAC-Adresse ('+ae.thearray[-1].mac_addr+') wurde bereits festgelegt", //bd_alert_6
	"Die reservierte IP-Adresse für diesen Computernamen ('+ae.thearray[-1].comp_name+') wurde bereits festgelegt", //bd_alert_7
	"Eine Reservierung kann nicht der konfigurierten LAN IP-Adresse gleich sein.", //TA20
	"Reservierte IP-Adresse sollte innerhalb des konfigurierten DHCP Bereiches sein.", //bd_alert_8
	"Es muss erst der primäre DNS-Server angegeben werden, bevor ein sekundärer DNS-Server angegeben wird", //bd_alert_22
	"Ungültige primäre DNS IP-Adresse", //bd_alert_23
	"Ungültige sekundäre DNS-IP-Adresse.", //bd_alert_24
	"Ungültige WAN-IP-Adresse", //_badWANIP
	"Ungültige WAN-Subnetzmaske", //bwn_alert_2
	"Die Standard Gateway-Adresse ist nicht im WAN Subnetz", //bwn_alert_3
	"Keine DNS konfiguriert. Die Clients werden Domänennamen nicht auflösen können. Weiter?", //bwn_alert_4
	"Konflikt zwischen WAN-Subnetz und LAN-Subnetz", //bwn_alert_5
	"Geben Sie bitte eine Trigger-Portnummer ein", //MSG000
	"Die maximale Leerlaufzeit muss im Bereich zwischen 0..600 liegen", //bwn_alert_8
	"Ungültige PPPoE-IP-Adresse", //bwn_alert_12
	"Ungültige PPTP-IP-Adresse", //_badPPTPip
	"Ungültige PPTP-Subnetzmaske", //_badPPTPsub
	"Die PPTP Gateway IP-Adresse ist nicht im PPTP Subnetz", //_badPPTPipsub
	"Ungültige IP-Adresse des PPTP-Servers", //bwn_alert_11
	"Ungültige L2TP-Adresse", //_badL2TP3
	"Ungültige L2TP-Subnetzmaske", //_badL2TP
	"Die L2TP Gateway IP-Adresse ist nicht im L2TP-Subnetz", //_badL2TP2
	"Ungültige L2TP Server IP-Adresse", //bwn_alert_17
	"Die MTU muss im Bereich zwischen 128..30000 liegen", //bwn_alert_21
	"Die WEP-Schlüssel '+ wep_error_msg + ' sind ungültig.", //bws_alert_15
	"Der WEP-Schlüssel '+ wep_error_msg + ' ist ungültig.", //bws_alert_16
	"Der 802.11b/g Kanal kann nicht verwendet werden, wenn der 802.11 Modus 802.11a ist", //bwl_alert_2
	"Der 802.11a Kanal kann nicht verwendet werden, wenn der 802.11 Modus 802.11b/g ist", //bwl_alert_3
	"RADIUS-Server Port Eintrag kann nicht leer sein.", //bwl_alert_15
	"Der RADIUS-Server Port ' + data.wireless.radius_server_port + ' sollte im Bereich (1..65535) liegen.", //bwl_alert_16
	"802.11b-Übertragungsraten können nicht genutzt werden, wenn der PHY-Modus 802.11a ist", //bwl_alert_4
	"802.11a/g-Übertragungsraten können nicht genutzt werden, wenn der PHY-Modus 802.11b ist", //bwl_alert_5
	"Der Modus 'Statischer Turbo' ist bei 802.11b nicht zulässig.", //bwl_alert_6
	"Die Verwendung des 'Dynamischen Turbo'-Modus ist mit 802.11b zulässig", //bwl_alert_7
	"Bei 11g Turbo-Modus muss der Kanal auf 6 gestellt werden", //bwl_alert_8
	"Bei 11a Static Turbo sollte der Kanal auf entweder 42,50,58,152, oder 160 gestellt werden.", //bwl_alert_9
	"Bei 11a Dynamic Turbo sollte der Kanal auf entweder 40,48,56,153 oder 161 gestellt werden.", //bwl_alert_10
	"Ungültige Schlüssellänge. Diese muss zwischen 8 und 64 Zeichen lang sein.", //bws_alert_2
	"Das Aktualisierungsintervall für WPA-Gruppenschlüssel muss zwischen 30 und 65535 Sekunden liegen.", //bwl_alert_11
	"IEEE 802.1X Zeitüberschreitung der Authentifizierung sollte zwischen 1 und 65535 Minuten liegen", //bwl_alert_12
	"Der WEP-Schlüssel ' +(i+1)+' muss '+len+' Zeichen aufweisen", //bws_alert_3
	"Deaktivieren Sie die \"Automatische Kanalauswahl\" für den WDS-Modus.\"", //aw_alert_5_1
	"'Die IP-Adresse ' + data.wireless.radius_server_address + 'ist ungültig. '", //bwl_alert_13
	"'Die IP-Adresse ' + data.wireless.second_radius_server_address + ' ist ungültig. '", //bwl_alert_14
	"nur 802.11g", //bwl_Mode_2
	"gemischter 802.11g und 802.11b", //bwl_Mode_3
	"nur 802.11b", //bwl_Mode_1
	"nur 802.11n", //bwl_Mode_8
	"Gemischt 802.11n, 802.11g und 802.11b", //bwl_Mode_11
	"20 MHz", //bwl_ht20
	"Auto 20/40 MHz", //bwl_ht2040
	"Am Besten (automatisch)", //bwl_TxR_0
	"Der erste Schritt zur Sicherung Ihres drahtlosen Netzwerks besteht darin, den Namen Ihres drahtlosen Netzwerks zu ändern. Wählen Sie einen geläufigen Namen, der keinerlei persönliche Informationen enthält.", //TA9
	"Aktivieren Sie die automatische Kanalerkennung, damit der Router den bestmöglichen Kanal für Ihr Wireless-Netzwerk auswählen kann.", //YM124
	"Das Einstellen des Sichtbarkeitsstatus auf 'Unsichtbar' eine andere Möglichkeit zur Absicherung Ihres Netzwerks. Wenn die Sichtbarkeit deaktiviert ist, können drahtlose Clients Ihr drahtloses Netzwerk nicht sehen, wenn Sie nach verfügbaren Netzwerken suchen. Damit Ihre drahtlosen Geräte mit Ihrem Router verbunden werden können, müssen Sie auf jedem Gerät den Namen des drahtlosen Netzwerks manuell eingeben.", //TA12
	"Wenn Sie die Sicherheit für drahtlose Netzwerke aktiviert haben, notieren Sie sich unbedingt den von Ihnen festgelegten Kennwortsatz.", //TA14
	"Sie müssen diese Informationen auf jedem drahtlosen Gerät eingeben, das Sie mit Ihrem drahtlosen Netzwerk verbinden möchten.", //TA15
	"Assistent", //_wizard
	"Internetverbindung Installationsassistenten starten", //bwz_LConWz
	"Wireless Sicherheit Setup Assistent", //bwz_WlsWz
	"Der folgende webbasierte Setup Assistent unterstützt Sie bei der Einrichtung Ihres Wireless-Netzwerkes. Dieser Assistent führt Sie schrittweise durch die Anweisungen, wie Sie Ihr Wireless-Netzwerk einrichten und es absichern.", //bwz_intro_WlsWz
	"Wireless Sicherheit Setup Assistent starten", //bwz_LWlsWz
	"Spezialanwendungen", //_specapps
	"Spiele", //_gaming
	"Allgemein", //_basic
	"Der Name der Regel muss angegeben werden.", //ag_alert_empty_name
	"Der Name der Regel ' + data.game_rules[j].entry_name + '' ist doppelt.'", //ag_alert_duplicate_name2
	"Der MAC-Adressfilter erlaubt keine Geräte/Rechner, weil alle gesperrt würden.", //amaf_alert_2
	"Der Name der Regel ' + saved_records[i].entry_name + '' ist doppelt.'", //specapps_alert_duplicate_name
	"\"Die Regel '\" + saved_records[j].entry_name + \"' ist eine Duplikat von '\" + saved_records[i].entry_name + \"'.\"", //specapps_alert_duplicate1
	"Der Trigger-Portbereich '+saved_records[i].entry_name+'' '+protocols[saved_records[i].trigger_ports.protocol]+' ['+saved_records[i].trigger_ports.port_range+'] ist im Konflikt mit ''+saved_records[j].entry_name+'' '+protocols[saved_records[j].trigger_ports.protocol]+' ['+saved_records[j].trigger_ports.port_range+'].'", //specapps_alert_conflict1
	"Wählen Sie einen Zeitplan für die Regel ' + data.port_trigger_rules[i].entry_name + ''.'", //specapps_alert_empty_schedule
	"Einrichten des Traffic Shaping", //at_title_TSSet
	"Protokoll ' + entry_1.user_protocol + ' of ' + entry_1.entry_name + ' ist im Konflikt mit ' + entry_2.entry_name + '", //av_alert_35
	"Das Feld \"Name\" darf nicht leer sein.", //av_alert_empty_name
	"Der Name '%s' wird bereits verwendet", //av_alert_16
	"Die primäre WINS IP-Adresse muss angegeben werden.", //bln_alert_lannbpri
	"Die sekundäre WINS-IP-Adresse ist ungültig.", //bln_alert_lannbsec
	"Primäre DNS", //lan_dns
	"Sekundärer DNS", //lan_dns2
	"Gemischter Modus (Point-to-Point , anschließend Broadcast)", //bln_NetBIOSReg_H
	"Gemischter Modus (Broadcast, anschließend Point-to-Point)", //bln_NetBIOSReg_M
	"Point-to-Point (kein Broadcast)", //bln_NetBIOSReg_P
	"Nur Broadcast (wird verwendet, wenn keine WINS-Server konfiguriert sind)", //bln_NetBIOSReg_B
	"Hilfe", //_help
	"Wenn diese Option aktiviert ist, wird der ausgehende Datenverkehr eingeschränkt, so dass der ausgehende Datenverkehr nicht die maximal mögliche Uplink-Bandbreite überschreitet.", //help81ets
	"Über die Endpunktfilteroptionen für den NAT (Netzwerkadressübersetzer) wird kontrolliert, wie der Router-NAT mit Verbindungsanfragen an belegte Anschlüsse verfährt.", //af_EFT_h4
	"Wenn eine Anwendung auf der LAN-Seite über einen bestimmten Port verbunden ist, werden durch den NAT alle an den gleichen Port gerichteten eingehenden Verbindungsanfragen an diese Anwendung weitergeleitet. Der Ausgangspunkt der Anfragen spielt dabei keine Rolle. Bei dieser Option sind die Beschränkungen am geringsten. Die Verbindung ist am schnellsten, und einige Anwendungen (v. a. P2P-Anwendungen) funktionieren fast wie bei direkter Internetverbindung.", //YM134
	"Der NAT leitet eingehende Verbindungsanfragen nur dann an den Host auf der LAN-Seite weiter, wenn diese von der IP-Adresse gesendet wurden, mit der eine Verbindung hergestellt wurde. Dadurch kann für die Datenrücksendung durch die Remoteanwendung ein anderer Port genutzt werden als bei der Datenzusendung.", //af_EFT_h1
	"Der NAT leitet keine eingehenden Verbindungsanfragen weiter, wenn für diese bereits eine Verbindung besteht.", //af_EFT_h2
	"Beachten Sie, dass die Verwendung einiger dieser Optionen Auswirkungen auf andere Portbeschränkungen haben kann. Die endpunktunabhängige Filterung hat Vorrang vor Filtern oder Zeitplänen für eingehende Daten. Der Eingang von abgefragten Datenpaketen kann deshalb direkt über einen Port statt über einen vorgeschalteten aktiven Filter für eingehenden Verkehr erfolgen. Datenpakete an Ports, die durch einen Zeitplan oder einen Filter für eingehenden Verkehr gesperrt sind, werden jedoch zurückgewiesen. Die port- und adressenbeschränkte Filterung stellt sicher, dass Filter für eingehenden Datenverkehr und Zeitpläne genau funktionieren. Allerdings wirkt sich ihre Verwendung auf die Verbindung aus, weshalb mit Hilfe von Porttriggern, virtuellen Servern oder Portweiterleitungen die von der Anwendung benötigten Ports geöffnet werden müssen. Mit der adressenbeschränkten Filterung werden Kommunikationsprobleme mit verschiedenen anderen NAT-Routertypen, besonders den symmetrischen, vermieden. Gleichzeitig wird kontrolliert, dass die Filter für eingehenden Verkehr und Zeitpläne wie vorgesehen funktionieren.", //af_EFT_h5
	"Überprüfung der Endpunktfilterung von UDP-Protokolldaten", //af_UEFT_h1
	"Kontrolle für die Endpunktfilterung von TCP-Protokollpaketen.", //af_TEFT_h2
	"Die Subnetzmaske des lokalen Netzwerks.", //help309A
	"NetBIOS ermöglicht es LAN-Hosts, alle anderen Computer innerhalb des Netzwerks, z. B. innerhalb der Netzwerkumgebung, zu erkennen.", //help400_1
	"Deaktivieren Sie diese Einstellung, um eine manuelle Konfiguration vorzunehmen.", //help401_1
	"WINS-Server speichern Daten bezüglich Netzwerk-Hosts und ermöglichen diesen, sich selbst zu registrieren und andere verfügbare Hosts (z. B. für die Verwendung in Netzwerkumgebungen) zu erkennen.", //help402_1
	"Diese Einstellung hat keine Auswirkungen, wenn die Option 'NetBIOS-Informationen vom WAN abrufen' aktiviert ist.", //help402_2
	"H-Knoten; gibt einen Hybrid-Betriebsstatus an. Zuerst werden möglicherweise vorhandene WINS-Server getestet, danach lokale Netzwerk-Broadcasts. Dies ist normalerweise der bevorzugte Modus, wenn Sie WINS-Server konfiguriert haben.", //help405_1
	"M-Knoten (Standard); gibt einen gemischten Betriebsmodus an. Die erste Broadcast-Aktion wird zum Registrieren von Hosts und Erkennen anderer Hosts ausgeführt; wenn die Broadcast-Aktion fehlschlägt, werden bei Bedarf WINS-Server getestet. Dieser Modus favorisiert Broadcast-Aktionen, die bevorzugt werden können, wenn WINS-Server über eine langsame Netzwerkverknüpfung erreichbar sind und die Mehrzahl der Netzwerkdienste wie Dienst und Drucker im LAN lokal sind.", //help405_2
	"P-Knoten; dies gibt an, dass NUR WINS-Server verwendet werden dürfen. Diese Einstellung ist hilfreich, um den gesamten NetBIOS-Betrieb auf die konfigurierten WINS-Server zu zwingen. Sie müssen mindestens die primäre WINS-Server-IP konfiguriert haben, um auf einen funktionierenden WINS-Server zu verweisen.", //help405_3
	"B-Knoten; gibt an, dass NUR lokale Netzwerk-Broadcasts verwendet werden dürfen. Diese Einstellung ist nützlich, wenn keine anderen WINS-Server verfügbar sind; es ist jedoch empfehlenswert, dass Sie den M-Knoten-Betrieb zuerst überprüfen.", //help405_4
	" Falsch konfiguriert - Protokolle prüfen", //_sdi_s1a
	"Ungültiger sicherer Remote Management-Port '+data.web_server_wan_port_https+', er sollte im Bereich (1..65535) sein", //ta_alert_3b
	"Sicherer Remote Management-Port und Remote Management-Port dürfen nicht gleich sein.", //ta_alert_3c
	"Sie müssen eine Managementmethode aktivieren.", //ta_alert_3d
	"Ungültiger Management-Port '+data.web_server_lan_port_http+', er sollte im Bereich (1..65535) sein", //ta_alert_3e
	"Ungültiger sicherer Management-Port '+data.web_server_lan_port_https+', er sollte im Bereich (1..65535) sein", //ta_alert_3f
	"Sicherer Management-Port und Management-Port dürfen nicht gleich sein.", //ta_alert_3g
	"LPD/LPR Drucken aktivieren", //tps_enlpd
	"Admin-Port", //ta_LMAP
	"Anmeldung fehlgeschlagen", //fb_FailLogin
	"Zugriff auf dieses Gerät ist ohne ein korrektes Kennwort nicht zulässig.", //fb_FailLogin_1
	"Öffnen", //_open
	"Weitere", //_other
	"Ablauf-Zeit", //_223
	"Die Gateway-Adresse ist nicht im LAN-Subnetz", //_225ap
	"Die IP-Adresse oder die Subnetzmaske ist ungültig", //_226ap
	"Dieser Eintrag ist optional. Geben Sie einen Domain-Namen für das lokale Netzwerk ein. Ihr LAN-Computer nimmt diesen Domain-Namen an, wenn er eine Adresse von dem im <span>Rou</span><span>ter</span> integrierten DHCP-Server erhält. Wenn Sie hier beispielsweise <code>meinnetzwerk.net</code> eingeben und Sie haben einen Laptop LAN-seitig mit einem Namen wie z. B.<code>franz</code>, wird der Laptop als <code>franz.meinnetzwerk.net</code> bezeichnet.", //_1044wired
	"Beachten Sie jedoch, dass der eingegebene Domain-Name durch den vom Upstream-DHC-Server des <span>Rou</span><span>ter</span>s empfangenen außer Kraft gesetzt wird.", //_1044awired
	"IPv6-Adresse", //TEXT0
	"Erneut erstellen", //regenerate
	"Advanced DNS Service", //_title_AdvDns
	"Mit dem erweiterten DNS Service (Advanced DNS) handelt es sich um eine kostenlose Sicherheitsoption, die Anti-Phishing zum Schutz Ihrer Internetverbindung vor betrügerischen Absichten bereitstellt und Navigationsverbesserungen wie die automatische Korrektur häufiger URL-Eingabefehler bietet.", //_desc_AdvDns
	"Erweiterten DNS-Service aktivieren", //ta_EUPNP_dns
	"Advanced DNS", //_st_AdvDns
	"Advanced DNS", //_sp_title_AdvDNS
	"Wenn die Funktion aktiviert ist, wird Ihr Internet-Datenverkehr von einem auf Sicherheit ausgelegten DNS-Server geschützt. Diese Funktion bietet Anti-Phishing zum Schutz Ihrer Internetverbindung vor betrügerischen Absichten und Navigationsverbesserungen wie die automatische Korrektur häufiger URL-Eingabefehler.", //_sp_desc1_AdvDNS
	"Hinweis:<br />Wird DNS Relay zusammen mit der Funktion 'Advanced DNS' aktiviert, empfangen Ihre Arbeitsplatzrechner im Netz, die eine IP-Adresse vom DHCP-Server des Routers erhalten, die IP-Adresse des Routers: 192.168.0.1.", //_sp_desc2_AdvDNS
	"Obwohl die Funktion 'Advanced DNS' aktiviert ist, kann die DNS IP-Adresse Ihres Arbeitsplatzrechners nach Bedarf immer noch auf die DNS Server IP-Adresse geändert werden. Beachten Sie bitte, dass der Router die DNS-Namensauflösung nicht vorschreibt, wenn die DNS IP-Adresse auf dem Arbeitsplatzrechner konfiguriert ist.", //_sp_desc3_AdvDNS
	"Wenn Sie diese Option gewählt haben und in Ihrem Netz ist ein virtuelles privates Netz (VPN) oder ein Intranet eingerichtet, können Sie den 'Advanced DNS-Dienst' deaktivieren, falls Sie Schwierigkeiten mit der Verbindung haben.", //_sp_desc4_AdvDNS
	"Der Schlüssel", //TEXT041_1
	" ist ungültig. Der Schlüssel muss wie folgt sein:", //TEXT041_2
	" Zeichen oder", //TEXT041_3
	"Hexadezimalzahl.", //TEXT041_4
	"Der Schlüssel", //TEXT042_1
	"ist nicht korrekt. Gültige Zeichen sind 0-9, A-F oder a-f.", //TEXT042_2
	"Ungültige URL.", //GW_URL_INVALID
	"NetBIOS-Bereich ist ungültig.", //GW_LAN_NETBIOS_SCOPE_INVALID
	"sollte innerhalb des konfigurierten DHCP-Bereichs liegen.", //GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID_a
	"DHCP Plus", //bwn_Mode_DHCPPLUS
	"Net Sniper wird unterstützt", //net_sniper_support
	"Spezielle Wählmodusoptionen", //SEL_DIAL_MODE
	"Normale Einwahl (Standard)", //pppoe_dialmode_normal
	"Spez. Wählvorgang 1", //pppoe_dialmode_sp1
	"Spez. Wählvorgang 2", //pppoe_dialmode_sp2
	"Spez. Wählvorgang 3", //pppoe_dialmode_sp3
	"Spez. Wählvorgang 4", //pppoe_dialmode_sp4
	"Spez. Wählvorgang 5", //pppoe_dialmode_sp5
	"Spez. Wählvorgang 6", //pppoe_dialmode_sp6
	"Lernmodus", //pppoe_dialmode_learn
	"Lernen", //bt_learn_text
	"Anti-ARP-Angriff", //box_ip_mac_binding
	"Erweiterten DNS-Service aktivieren", //_en_AdvDns
	"XKJS unterstützt", //xkjs_support
	"Diensttyp", //ddns_serv_type
	"Domäne", //ddns_domain
	"DDNS-Kontotest", //ddns_account
	"Ungültiger öffentlicher Port", //virtual_pub_port_err
	"Ungültiger privater Port", //virtual_pri_port_err
	"Ungültige Protokollnummer", //virtual_proto_num_err
	"WPS (Wi-Fi Protected Setup)", //menu_wps
	"IP-Bereich", //tc_iprange
	"Öffnen oder Schließen der TCP Verbindungen.", //help823_15
	"Bandbreite (Kbit/s)", //tc_bw
	"Zeitplan", //tc_schedule
	"hinzufügen", //tc_new_sch
	"garantierte Mindestbandbreite", //tc_min_bw
	"garantierte max. Bandbreite", //tc_max_bw
	"VERWALTUNG", //_login_admin
	"Benutzer", //_login_user
	"PPPoE Plus unterstützt", //pppoe_plus_dail
	"Ungültiger DHCP+ Benutzername", //GW_WAN_DHCPPLUS_USERNAME_INVALID
	"Ungültiges DHCP+ Kennwort", //GW_WAN_DHCPPLUS_PASSWORD_INVALID
	"SMTP-Server-Port", //te_SMTPPort
	"Drahtlos-Modus", //WLANMODE
	"Router-Modus", //ROUTER_MODE
	"AP-Modus", //AP_MODE
	"WDS+Router-Modus", //WDSROUTER_MODE
	"WDS+AP-Modus", //WDSAP_MODE
	"Bridge-Sicherheit", //BR_SET
	"Gerätemodus", //device_mode
	"Router-Modus", //router_mode
	"AP-Modus", //ap_mode
	"Automatisch", //auto_mode
	"WDS aktivieren", //enable_WDS
	"Der Router versucht, Ihren Internetverbindungstyp zu erkennen. Warten Sie bitte, bis er die passenden Einstellungen für Ihre Konfiguration liefert.", //ES_AUTODECT
	"Telefontyp", //_phone
	"Wenn Sie keine Verbindung zum Internet herstellen möchten, klicken Sie auf die Schaltfläche unten.", //ES_CABLELOST_dsc2
	"Ich möchte keine Verbindung zum Internet herstellen", //ES_DONT_CONN_btn
	"INTERNETKONFIGURATION AKTUALISIERT", //ES_UPDATE_SETTING_bnr
	"Der Router versucht, Ihren Internetverbindungstyp ausfindig zu machen und eine Verbindung zum Internet herzustellen.                                Warten Sie bitte, bis der Vorgang abgeschlossen ist.", //ES_UPDATE_SETTING_dsc
	"INTERNET-VERBINDUNG KONFIGURIEREN", //ES_CONFIG_INTERNET_bnr
	"Ihr Benutzername und Kennwort scheinen nicht korrekt zu sein. Prüfen Sie sie noch einmal und klicken Sie dann auf \"Verbinden\".", //ES_CONFIG_INTERNET_dsc2
	"Internet Verbindung", //ES_INTERNET_CONN_dsc
	"(* ist ein Pflichtfeld)", //ES_MUST_FIELD_dsc
	"EINWAHL IST FEHLGESCHLAGEN", //ES_DIALUP_ERROR_bnr
	"Konfigurieren Sie Ihre WWAN-Einstellungen.  Wenn Sie nicht sicher ist, welche Einstellungen Sie wählen sollen, wenden Sie sich an Ihren Internetdienstanbieter.", //usb_config1
	"Easy Setup", //ES_NAME
	"Geben Sie den Benutzernamen ein", //MSG011
	"Was ist das?", //ES_what_is_this
	"Primärer DNS-Server", //ES_PRI_DNS
	"Sekundärer DNS-Server", //ES_SEC_DNS
	"Gateway-Adresse", //ES_GW_ADDR
	"Subnetzmaske", //ES_MASK
	"IP-Adresse", //ES_IP_ADDR
	"EASY SETUP' ABGESCHLOSSEN", //ES_complete
	"Der 'Easy Setup'-Prozess ist erfolgreich abgeschlossen. Klicken Sie auf 'Speichern', um Ihre Einstellungen zu speichern und damit sie wirksam werden. Es wird empfohlen, das Kästchen “Netzwerkeinstellungen speichern” zu markieren, um die Einstellungen für Ihr drahtloses Netz auf Ihrem Computer zu speichern, falls mehrere PCs drahtlos mit Ihrem Router verbunden werden müssen.<br><br> Nachdem Sie auf “Speichern” geklickt haben, müssen Sie Ihren Benutzernamen und Ihr Kennwort für den Zugriff auf das Gerät angeben, wenn Sie sich das nächste Mal anmelden.", //ES_save_dsc
	"Status", //ES_status
	"Verbunden", //ES_connected
	"Nicht verbunden", //ES_unconnected
	"Wireless Einstellungen", //ES_wlan_setting
	"Name des drahtlosen Netzwerks (SSID)", //ES_wlan_ssid
	"Sicherheit", //ES_security
	"Ungesichert", //ES_unsecured
	"Ihre gegenwärtigen Sicherheitseinstellungen für drahtlose Verbindungen sind nicht sicher. Wir empfehlen, die Einstellungen für drahtlose Verbindungen zu konfigurieren.", //ES_unsecured_suggest
	"Meine Netzwerkeinstellungen speichern", //ES_save_mySetting
	"Setzen Sie das Kennwort des Geräts auf den Schlüssel für ein drahtloses Netz.", //ES_sync_pw
	"Speichern", //ES_save
	"Netzwerkschlüssel", //ES_network_key
	"Netzwerkschlüssel automatisch generieren", //ES_autogen_key
	"Drahtlos-Sicherheit deaktivieren (nicht empfohlen)", //ES_disable_wifi_sec
	"AUTO-WPA/WPA2(empfohlen)", //ES_wifi_sec_recomm
	"Die aktuellen Netzwerkeinstellungen und der Verbindungsstatus werden unten angezeigt. Falls Sie Ihre Einstellungen für drahtlose Verbindungen neu konfigurieren möchten, klicken Sie auf \"Konfigurieren\". Sie können auch spezielle Einstellungen vornehmen, indem Sie auf \"Manuelles Setup\" klicken.", //ES_current_setting_dsc
	"AKTUELLE NETZWERKEINSTELLUNG", //ES_current_setting
	"Manuelles Setup", //ES_manual_btn
	"Abbrechen", //ES_cancel
	"ABMELDEN", //logout_caption
	"您已成功登出。", //logout_desc
	"Zurück zur Anmeldeseite", //logout_return
	"Verbindungszeit", //st_connected_time
	"Zugriff verweigert", //t_ctl_title
	"Der Zugang zum Internet ist zurzeit NICHT erlaubt. <br>Sind Sie sicher, dass Sie den Emergency Internet Access nutzen möchten?", //t_ctl_note
	"Der Zugang zum Internet ist zurzeit NICHT erlaubt. Beachten Sie bitte die entsprechende Studie.", //t_ctl_note1
	"TRENDnet Wireless N Home Router", //page_title
	"Portbereich muss zwischen den Werten 1 und 65535 sein.", //ac_alert_invalid_port
	"Duplizierter Name:", //ac_alert_dup_name
	"Port-Konflikt.", //ac_alert_port_conflit
	"Richtlinie darf nicht Null sein.", //ac_alert_policy_null
	"Prüfen Sie die konfigurierte Serveradresse", //tt_alert_checkdyndns
	"Der Router hat mit der aktuellen statischen IP-Einstellung keinen Zugang zum Internet.", //ES_static_no_internet
	"Der Zugang zum Internet ist mit der aktuellen Konfiguration nicht möglich. Bitte prüfen Sie Ihre Einstellungen.", //ES_static_no_internet_desc
	"Soll dieses Fenster wirklich geschlossen werden?", //_CFM_close_window
	"KONFIGURATIONSERGEBNIS SPEICHERN", //ES_save_result
	"Die Konfiguration wurde gespeichert.", //ES_save_success
	"Bestätigen", //ES_confirm_bt
	"Uhrzeitformat", //sch_timeformat
	"12-Stunden", //sch_hourfmt_12
	"24-Stunden", //sch_hourfmt_24
	"Diese Firmware ist die neueste Version.", //no_available_update
	"Sprachpaket entfernen", //clear_lang_pack
	"Aktuelle Sprachpaket-Version", //current_lang_pack_version
	"Aktuelles Sprachpaketdatum", //current_lang_pack_date
	"Sprachpaket-Aktualisierung", //lang_package_info
	"Ein Upgrade des Sprachpakets wird die Sprache ändern, welches auf der Webseite angezeigt wird.", //lang_package_note1
	"Suchen Sie zum Aktualisieren des Sprachpakets mithilfe der Schaltfläche \"Browse\" (Durchsuchen) die Aktualisierungsdatei auf der lokalen Festplatte. Wenn Sie die Datei gefunden haben, klicken Sie auf die Schaltfläche \"Upload\" (Hochladen), um die Sprachpaket-Aktualisierung zu starten.", //lang_package_note2
	"Neueste Sprachpaket-Version", //latest_lang_package_ver
	"Neuestes Sprachpaket-Datum", //latest_lang_package_date
	"Es ist kein Sprachpaket verfügbar.", //no_lang_pack
	"Portweiterleitungsname muss angegeben werden.", //pf_name_empty
	"Name des virtuellen Servers muss angegeben werden.", //vs_name_empty
	"Prüfsummenfehler.", //fw_checksum_err
	"Ungültige Hardware-ID.", //fw_bad_hwid
	"Unbekanntes Dateiformat.", //fw_unknow_file_format
	"Ihr Firmware-Upgrade war erfolgreich.", //fw_fw_upgrade_success
	"Das Sprachpaket-Upgrade war erfolgreich.", //fw_lp_upgrade_success
	"Das Konfigurations-Upgrade war erfolgreich.", //fw_cfg_upgrade_success
	"Zeitsteuerung einrichten", //ES_timectrl_bnr
	"Zeitsteuerung", //ES_timectrl_btn
	"Web-Steuerung", //ES_webpolicy_btn
	"Echte Gigabit Routing-Konnektivitätseinstellung", //HW_NAT_desc
	"Traffic-Shaping aktivieren", //at_ETS
	"Wenn Echte Gigabit Routing-Konnektivität aktiviert ist, wird die SPI- und QoS-Engine automatisch deaktiviert. Möchten Sie fortfahren?", //alert_hw_nat_1
	"Wenn die QoS-Engine aktiviert ist, wird die Echte Gigabit Routing-Konnektivität automatisch deaktiviert. Möchten Sie fortfahren?", //alert_hw_nat_2
	"Wenn SPI aktiviert ist, wird die Echte Gigabit Routing-Konnektivität automatisch deaktiviert. Möchten Sie fortfahren?", //alert_hw_nat_3
	"Wenn diese Option aktiviert ist, wird die Echte Gigabit Routing-Konnektivität automatisch deaktiviert.", //help_auto_disable_hw_nat
	" und die Echte Gigabit Routing-Konnektivität wird automatisch deaktiviert.", //help_auto_disable_hw_nat_1
	"Echte Gigabit Routing-Konnektivität:", //help_hw_nat
	"Wenn diese Option aktiviert ist, erhöht der Router die NAT/Routing-Geschwindigkeit durch ein Hardware-Beschleunigungsverfahren. Eingeschränkt wird diese Funktion jedoch dadurch, dass sowohl SPI als auch QoS-Engine automatisch deaktiviert werden, wenn die Echte Gigabit Routing-Konnektivität aktiviert ist.", //help_hw_nat_desc
	"Schritt 2: Konfigurieren Sie Ihre Wi-Fi-Sicherheit", //ES_step_wifi_security
	"Stellen Sie sicher, dass die zwei Benutzer-Kennwörter identisch sind und wiederholen Sie den Vorgang", //_pwsame_user
	"Versuchen Sie es noch einmal", //ES_btn_try_again
	"Router sucht nach Ihrem Internetverbindungstyp, bitte warten...", //ES_auto_detect_desc
	"Router kann Ihren Internetverbindungstyp nicht erkennen.", //ES_auto_detect_failed_desc
	"Ich wünsche schrittweise Anleitungen zu den Einstellungen für die Internetverbindung", //ES_btn_guide_me
	"Speichern & Verbinden", //ES_btn_save_conn
	"Speichern", //ES_btn_save
	"IPv6 Routing", //v6_routing
	"IPv6 Routing-Tabelle", //v6_routing_table
	"Das Routing-Status-Menü zeigt Informationen zu den Routen, die auf Ihrem Router aktiviert wurden. Die Liste zeigt die Ziel-IP-Adresse, Gateway-IP-Adresse, Subnetzmaske, Metrik und Schnittstelle für jede Route.", //v6_routing_info
	"Ipv6", //ipv6
	"IPv6 FIREWALL", //ipv6_firewall
	"Restliche Anzahl konfigurierbarer Firewall-Regeln:", //ipv6_firewall_info
	"6RD-EINSTELLUNGEN", //_6rd_settings
	"IPv4-Adresse", //ipv4_addr
	"Maskenlänge", //mask_len
	"IPv6-ULA-Einstellungen", //IPV6_ULA_TEXT01
	"Echte Gigabit Routing-Konnektivität aktivieren", //HW_NAT_enable
	"Standard-ULA-Präfix verwenden", //IPV6_ULA_TEXT03
	"ULA-Präfix", //IPV6_ULA_TEXT04
	"Aktuelle IPv6-ULA-Einstellungen", //IPV6_ULA_TEXT05
	"Aktuelles ULA-Präfix", //IPV6_ULA_TEXT06
	"LAN IPv6 ULA", //IPV6_ULA_TEXT07
	"LAN IPv6 ULA (Eindeutige lok. Adresse)", //IPV6_ULA_TEXT08
	"Manuelle Einrichtung der lokalen IPv6-Verbindung", //IPV6_ULA_TEXT09
	"In diesem Abschnitt können Sie die eindeutigen lokalen IPv6 Unicast-Adessen (ULA) für Ihren Router konfigurieren. ULA ist für die lokale Kommunikation gedacht und nicht für Routen im globalen Internet.", //IPV6_ULA_TEXT11
	"LOKALE IPV6-VERBINDUNGSEINSTELLUNGEN", //IPV6_ULA_TEXT12
	"ULA (Unique Local Adresses) ist für lokale IPv6-Kommunikationen von Nutzen. Um sie nach Bedarf zu aktivieren, klicken Sie auf <b>ULA aktivieren</b>. Standardmäßig ist ULA deaktiviert.", //IPV6_ULA_TEXT13
	"LOKALE IPV6-VERBINDUNGSEINSTELLUNGEN ", //IPV6_ULA_TEXT14
	"LAN IPv6-Adresse für lokale Kommunikationen.", //IPv6_Local_Info
	"IPv6 SIMPLE SECURITY", //IPv6_Simple_Security
	"IPv6 Multicast-Streams aktivieren", //anet_multicast_enable_v6
	"6rd Tunneling-Verbindung einrichten", //IPv6_Wizard_6rd_title
	"Name der Firewall-Regel muss angegeben werden.", //fr_name_empty
	"Der IPv6-Routing-Name muss angegeben werden.", //r6_name_empty
	"Geben Sie Ihrem Wi-Fi-Netzwerk einen Namen.", //wwz_wwl_intro_s2_1
	"Wi-Fi-Netzwerkname (SSID)", //wwz_wwl_intro_s2_1_1
	"(Bis zu 32 Zeichen verwenden)", //wwz_wwl_intro_s2_1_2
	"Richten Sie für Ihr Wi-Fi-Netzwerk ein Kennwort ein.", //wwz_wwl_intro_s2_2
	"Wi-Fi-Kennwort", //wwz_wwl_intro_s2_2_1
	"(Zwischen 8 und 63 Zeichen)", //wwz_wwl_intro_s2_2_2
	"Schritt 3: Richten Sie Ihr Kennwort ein", //ES_title_s3
	"Schritt 4: Wählen Sie Ihre Zeitzone", //ES_title_s4
	"Schritt 5: Speichern Sie die Einstellungen", //ES_title_s5
	"nur 802.11n", //bwl_Mode_n
	"nur 802.11a", //bwl_Mode_a
	"Mischbetrieb (802.11g und 802.11n)", //bwl_Mode_5
	"Der Zeitplan der Gastzone muss innerhalb des Zeitplans der Haupt-WLAN sein.", //MSG049
	"Das GuestZone WLAN muss deaktiviert werden, wenn Sie das Haupt-WLAN auschalten. Möchten Sie wirklich fortfahren?", //MSG050
	"Hardware-Init.-Fehler", //HWerr
	"Speicher", //storage
	"Mit dem SharePort Web Access können Sie mithilfe eines Webbrowsers auf Dateien zugreifen, die auf dem an den Router angeschlossenen USB-Speichermedium abgelegt sind. Um diese Funktion zu verwenden, markieren Sie das Kontrollkästchen <strong>SharePort SharePort Web Access aktivieren</strong> und erstellen Sie dann ein Benutzerkonto, um den Zugriff auf Ihre Speichergeräte zu verwalten oder um das Gästekonto (guest/guest) für den Zugriff auf den Gästeordner (Guest) zu verwenden. Nach Anschluss eines USB-Speichers erscheint das neue Gerät in der Liste mit einem auf dieses Gerät verweisenden Link. Sie können diesen Link dann nutzen, um auf das Laufwerk zuzugreifen und um sich über ein Benutzerkonto anzumelden.", //sto_into
	"SHAREPORT WEB ACCESS", //sto_http_0
	"WAN-Ping-Antwort aktivieren", //bwn_RPing
	"Gastzone aktivieren", //guestzone_enable
	"HTTP-Zugriffs-Port", //sto_http_3
	"HTTPS-Server aktivieren", //LV2
	"HTTPS-Zugriffs-Port", //sto_http_5
	"10 -- Benutzererstellung", //sto_creat
	"Hinzufügen/Bearbeiten", //_add_edit
	"Benutzerliste", //sto_list
	"Ändern", //_modify
	"Zugriffspfad", //sto_path
	"Leistungsverbessernde Funktionen wie Packet Bursting, FastFrames und Compression.", //help361
	"verwendeter NTP-Server", //tt_NTPSrvU
	"Gerät", //sto_dev
	"Speicherplatz insgesamt", //_total_space
	"Freier Speicherplatz", //_free_space
	"SHAREPORT WEB ACCESS LINK", //sto_link_0
	"Sie können diesen Link nutzen, um remote auf das Laufwerk zuzugreifen, nachdem Sie sich über ein Benutzerkonto angemeldet haben.", //sto_link_1
	"http://&lt;DDNS&gt; oder&lt;WAN IP-Adresse&gt;:8184", //sto_link_2
	"Jetzt E-Mail senden", //_email_now
	"Die Seite 'Speicher' enthält Informationen über die zum aktuellen Zeitpunkt an das Gerät angeschlossenen USB-Speicherlaufwerke oder SD-Karten.", //sto_help
	"Geräte-Link", //_DevLink
	"Ordner", //_folder
	"Browser", //_browse
	"Anhängen", //_append
	"Fernzugriffs-Port & Fern-HTTPS-Port sind leer.", //sto_01
	"Das eingegebene Kennwort stimmt nicht mit dem neuen Benutzerkennwort überein", //sto_02
	"Schreibgeschützt", //_readonly
	"Les./Schreib", //_readwrite
	"Neuen Ordner anhängen", //_AppendNewFolder
	"Drücken Sie die Taste an Ihrem drahtlosen Gerät, und klicken Sie anschließend unten auf die Schaltfläche 'Verbinden'.", //KR45
	"Dieses Konto hat den max. Regelwert erreicht", //MSG052
	"Diese Regel existiert bereits", //MSG053
	"Diese Regel wurde nicht gefunden. Verwenden Sie die Anhängeschaltfläche.", //MSG054
	"Neuen Ordner hinzufügen", //_AddFolder
	"http://&lt;DDNS&gt; oder &lt;WAN IP-Adresse&gt;", //_StorageLink
	"WPS-PIN-Methode deaktivieren ", //LW6_1
	"Die Benutzerhöchstzahl", //MSG055
	"Schritt 5: Bestätigen Sie die WI-FI-Einstellungen", //ES_title_s5_0
	"EINSTELLUNGEN SPEICHERN", //save_settings
	"Ihre Einstellungen werden gespeichert.", //save_wait
	"Sprache", //_Language
	"Adelphia Power Link", //manul_conn_01
	"ALLTEL DSL", //manul_conn_02
	"ATAT DSL Service", //manul_conn_03
	"Bell Sympatico", //manul_conn_04
	"Bellsouth", //manul_conn_05
	"Charter High-Speed", //manul_conn_06
	"Comcast", //manul_conn_07
	"Covad", //manul_conn_08
	"Cox Communications", //manul_conn_09
	"Earthlink Cable", //manul_conn_10
	"Earthlink DSL", //manul_conn_11
	"FrontierNet", //manul_conn_12
	"Meinung", //_aa_bsecure_opinion
	"RCN", //manul_conn_14
	"Road Runner", //manul_conn_15
	"Rogers Yahoo!", //manul_conn_16
	"SBC Yahoo! DSL", //manul_conn_17
	"Shaw", //manul_conn_18
	"Speakeasy", //manul_conn_19
	"Sprint FastConnect", //manul_conn_20
	"Telus", //manul_conn_21
	"Time Warner Cable", //manul_conn_22
	"US West / Qwest", //manul_conn_23
	"Verizon Online DSL", //manul_conn_24
	"XO Communications", //manul_conn_25
	"5 GHz Band-Netzwerkname (SSID) manuell vergeben", //manul_5g_ssid
	"Das Sprachpaket ermöglicht Ihnen, die Sprache der Benutzeroberfläche des Routers zu ändern. ", //tf_intro_FWU4
	"Es wird empfohlen, zusammen mit der Firmware auch das Sprachpaket zu aktualisieren. Dies stellt sicher, dass alle Änderungen in der Firmware korrekt angezeigt werden.", //tf_intro_FWU5
	"Firmware-Aktualisierung", //_firmwareUpdate
	"Datum", //_date
	"Entfernen", //_remove
	"Wenn Sie WEP, EAP als Sicherheit setzen, der Verschlüsselungstyp TKIP oder der Sichtbarkeitsstatus 'Unsichtbar' ist, wird WPS deaktiviert.", //notify_wps
	"%s Ports[%s] sind mit der anderen Einstellung im Konflikt", //ag_conflict5
	"Deaktivieren", //_disable
	"HT 20/40 MHZ Koexistenz ", //coexi
	"Verwenden Sie das gleiche Kennwort für die drahtlose Sicherheit auf dem 2,4 GHz sowie auf dem 5 GHz Frequenzband.", //wwl_SSP
	"Geben Sie Ihrem Wi-Fi-Netzwerk einen Namen und richten Sie ein Kennwort ein.", //wwz_wwl_intro_s0
	"Diese Seite zeigt Ihr IPv6-Internet- und Netzwerkverbindungsdetails an.", //STATUS_IPV6_DESC_0
	"IPv6-Verbindungsdaten", //STATUS_IPV6_DESC_1
	"Die IPv6-Adresse des verbundenen Computers.", //STATUS_IPV6_DESC_6
	"Die LAN IPv6 Link-Local-Adresse.", //STATUS_IPV6_DESC_5
	"Die MAC-Adresse des verbundenen Computers.", //STATUS_IPV6_DESC_4
	"Der IPv6-Verbindungstyp.", //STATUS_IPV6_DESC_3
	"Der Name des verbundenen Computers.", //STATUS_IPV6_DESC_2
	"Die QoS Engine-Funktion hilft, die Leistung im Internet zu verbessern, indem sie Anwendungen priorisiert. ;", //ag_conflict6
	"Regel", //TEXT008a
	"weist gleiche Einstellung wie Regel.", //TEXT008b
	"Beobachtung", //TEXT023
	"MBit/s", //at_mbps
	"Ungültiges PIN-Format. Verwenden Sie folgendes Format:  0000 0000 oder 0000-0000", //pin_f
	"Die Nutzung der WEP-Verschlüsselung deaktiviert WPS. Sind Sie sicher?", //msg_eap
	"Öffnen", //open
	"Geben Sie bitte eine andere Nummer für den Privaten Port ein", //PRIVATE_PORT_ERROR
	"Ordner kann nicht eingerichtet werden mit: \"/\" ", //MSG056
	"Sie verwenden den gleichen Kontonamen und Kennwort!", //MSG057
	"Ziel-IP", //_DestIP
	"Typ", //_type
	"Internet nicht gefunden. Möchten Sie den Assistenten noch einmal starten?", //mydlink_tx03
	"WAN-Verbindung prüfen.", //mydlink_tx05
	"Sekunden verbleiben.", //sec_left
	"Bitte füllen Sie die Pflichtfelder aus und klicken Sie auf \"Verbinden\"", //ES_CONN_dsc
	"Kennwort bestätigen", //chk_pass
	"Nachname", //Lname
	"Vorname", //Fname
	"Anmeldung", //_login
	"%s Ports[%s] sind mit dem Http-Fernzugriffsspeicher-Port im Konflikt", //ag_conflict22
	"%s Ports[%s] sind mit dem Https-Fernzugriffsspeicher-Port im Konflikt", //ag_conflict23
	"Drahtloser Host ist deaktiviert. Drahtlose Gastzone kann nicht aktiviert werden.", //wifi_enable_chk
	"Die IPv6-Adresse darf nicht Null sein", //ZERO_IPV6_ADDRESS
	"Der IPv6 Portbereich muss angegeben werden.", //port_empty
	"Deaktivieren", //_disable_s
	"Wählen Sie bitte Ihren IPv6-Internetverbindungstyp aus", //IPV6_TEXT154
	"Anmelden", //_signup
	"(GMT+07:00) Nowosibirsk", //up_tz_74
	"Die Kennworteingabe für die Sicherheit des Funknetzes ist ungültig.", //wifi_pass_chk
	"Entfernen(Remove)", //_remove_multi
	"Möchten Sie das Gerät wirklich mit der Sprachdatei neu programmieren?", //tf_really_langf
	"Sie müssen zuerst den Namen einer Sprachdatei eingeben.", //tf_langf
	"Die hochgeladene und SPRACHPAKET ist möglicherweise nicht korrekt. Sie haben eventuell eine nicht für dieses Gerät bestimmte Datei hochgeladen oder die Datei ist beschädigt.", //ub_intro_l1
	"Wenn die korrekte Datei hochgeladen wurde, kann diese derzeit wegen Überlastung möglicherweise nicht vom Gerät empfangen werden. Versuchen Sie in diesem Fall, die Datei erneut hochzuladen. Stellen Sie sicher, dass Sie nicht als 'Benutzer', sondern als 'Administrator' angemeldet sind, da nur der Administrator neue Firmware hochladen kann.", //ub_intro_l3
	"Die von Ihnen angeforderte Seite ist leider nicht verfügbar. ", //err404_title
	"Es wurde keine Internetverbindung gefunden.", //err404_detect
	"Vorschläge:", //err404_sug
	"Stellen Sie sicher, dass Ihr Internetkabel fest an den Internetport Ihres Routers angeschlossen ist, und Ihre Internet-LED grün oder blau blinkt. ", //err404_sug1
	"Vergewissern Sie sich, dass die", //err404_sug2
	"\"Interneteinstellungen\"", //err404_sug3
	"auf Ihrem Router sowie Ihre PPPoE-Benutzernamen-/Kennworteinstellungen korrekt sind.", //err404_sug4
	"Der DNS-Server ist möglicherweise gegenwärtig nicht verfügbar. Wenden Sie sich an Ihren Internetdienstanbieter oder versuchen Sie es später noch einmal.", //err404_sug5
	"Endzeit", //tsc_end_time
	"Geben Sie einen anderen Port für den Fernadministrationszugang an", //remote_port_msg
	"Geben Sie einen anderen Namen ein", //TEXT034
	"Nur der Administrator kann auf diese Funktionen zugreifen. Die Schaltflächen sind deaktiviert, da Sie derzeit nicht als Administrator angemeldet sind.", //LW39b
	"Geben Sie bitte einen Benutzernamen ein und versuchen Sie es noch einmal", //_nousername
	"Geben Sie bitte ein anderes Schlüsselwort ein", //metric_empty
	"Geben Sie eine TCP-Portnummer oder eine UDP-Portnummer ein.", //TEXT061
	"Wenden Sie sich an Ihren Internetdienstanbieter, um den korrekten Benutzernamen und das korrekte Kennwort zu erhalten", //ES_DIALUP_ERROR_dsc
	"Geben Sie bitte eine Firewall-Portnummer ein", //MSG001
	"Wählen Sie \"Geräte-Link\"", //MSG051
	"Geben Sie einen anderen %s-Wert ein.", //MSG012
	"Bitte wählen Sie einen Filter aus.", //aa_alert_13
	"Wählen Sie bitte erst einen Computernamen aus.", //TEXT044
	"Geben Sie einen anderen Benutzernamen ein", //sto_03
	"Keine Änderungen auf dieser Seite. Möchten Sie dennoch speichern?", //up_nosave
	"Geben Sie bitte das gleiche Passwort in beide Kästchen zur Bestätigung ein.", //ta_msg_TW
	"Wenn Sie den \"Web-Dateizugriff aktivieren\" möchten, müssen Sie \"HTTP-Speicher - Fernzugriff aktivieren\" oder  \"HTTPS Speicher - Fernzugriff aktivieren\" wählen.", //sto_04
	"Hub- und Spoke-Modus aktivieren", //IPV6_TEXT167
	"Diese Seite zeigt die für Ihren Router konfigurierten IPv6 Routing-Details.", //IPV6_TEXT170
	"Für jede Regel können Sie einen Namen erstellen und die Richtung des Datenverkehrs steuern. Sie können auch einen Bereich mit IP-Adressen, das Protokoll und einen Portbereich zulassen oder verweigern. Um einen Zeitplan auf eine Firewall-Regel anzuwenden, müssen Sie zuerst eine Zeitplan auf der Seite <a href=\"tools_schedules.asp\">Extras &rarr; Zeitpläne</a> festlegen.", //help_171
	"Der Host-Name ist ungültig.", //DDNS_HOST_ERROR
	"No.", //_item_no
	"Einrichten von USB-Gerät ist fehlgeschlagen", //_usb_not_found
	"Name des Servers muss angegeben werden.", //srv_name_empty
	"Die Nutzung der WEP-Verschlüsselung deaktiviert WPS. Sind Sie sicher?", //msg_wps_sec_01
	"Die Nutzung der WPA/TKIP-Verschlüsselung deaktiviert WPS. Sind Sie sicher?", //msg_wps_sec_02
	"Ausblenden der SSID deaktiviert WPS. Sind Sie sicher?", //msg_wps_sec_03
	"SharePort", //sh_port_tx_00a
	"Mobile/Web Access", //sh_port_tx_00b
	"SharePort&trade; Mobile/Web Access", //sh_port_tx_00
	"SharePort&trade; Mobile/Web Access bietet einen leichten und gemeinsam nutzbaren Zugriff von jedem Computer oder mobilen Gerät in Ihrem Heimnetz auf ein mit Ihrem Router verbundenes USB-Speichermedium. Es ermöglicht Ihnen und Gastbenutzern über das von Ihnen erstellte Benutzerkonto auf Dateien zuzugreifen, die auf einem USB-Speicher abgelegt sind.", //sh_port_tx_01
	"Sie können den Setup-Assistenten zur Konfiguration des SharePort&trade; Mobile/Web Access verwenden oder ihn manuell konfigurieren.", //sh_port_tx_02
	"SharePort&trade; Mobile Setup-Assistent", //sh_port_tx_03
	"Klicken Sie auf die Schaltfläche unten, wenn Sie unseren einfach zu bedienenden, webbasierten Assistenten verwenden möchten, um Sie beim Einrichten SharePort&trade; Mobile Service zu unterstützen.", //sh_port_tx_04
	"SharePort&trade; Mobile manuell einrichten", //sh_port_tx_05
	"Falls Sie die Einstellungen für den SharePort&trade; Mobile/Web Access Service manuell vornehmen möchten, klicken Sie auf die Schaltfläche unten.", //sh_port_tx_06
	"Stellen Sie sicher, dass der USB-Speicher mit dem Router verbunden ist.", //sh_port_tx_07
	"Kein USB-Speicher! Stellen Sie sicher, dass ein Speichergerät an den Router angeschlossen ist.", //sh_port_tx_08
	"Erstellen Sie zur Verwaltung des Speicherzugriffs ein Benutzerkonto.", //sh_port_tx_09
	"Wählen/erstellen Sie einen Ordner auf dem USB-Laufwerk, um auf seine Inhalte zuzugreifen.", //sh_port_tx_10
	"Geben Sie die DDNS-Kontoinformationen ein, um den Fernzugriffsdienst zu aktivieren. Sollten Sie kein DDNS-Konto haben, melden Sie sich auf der folgenden Adresse für ein Konto an:", //sh_port_ddns_01
	"verarbeite Einstellungen", //sh_port_ddns_02
	"Der Link für den Internetzugang wird geprüft. Bitte warten...", //sh_port_ddns_03
	"Der Einrichtungsvorgang ist abgeschlossen! Sie können nun den Link unten für den Zugriff auf Ihren USB-Speicher über das unten angezeigte Benutzerkonto verwenden.", //sh_port_tx_11
	"Lokaler Zugriff", //sh_port_tx_12
	"Fernzugriff", //sh_port_tx_13
	"oder", //sh_port_tx_16
	"<a href=\"http://FQDN:8181\">http://FQDN:8181</a>", //sh_port_tx_17
	"Die Links oben werden aktiviert, sobald die Einstellungen gespeichert sind und das Gerät neu gestartet wurde.", //sh_port_tx_18
	"Benutzername oder Schlüssel", //sh_port_tx_19
	"Kennwort oder Schlüssel", //sh_port_tx_20
	"Auswählen", //sh_port_tx_21
	"Der Kontoname muss angegeben werden.", //sh_port_msg_01
	"Der Kennwort für das Konto muss angegeben werden.", //sh_port_msg_02
	"Die zwei eingegebenen Kennwörter stimmen nicht überein.", //sh_port_msg_04
	"Wählen Sie einen Ordner für Ihr Benutzerkonto.", //sh_port_msg_05
	"Der Hostname muss angegeben werden.", //sh_port_msg_06
	"Der Benutzername muss angegeben werden.", //sh_port_msg_07
	"Das Kennwort muss angegeben werden.", //sh_port_msg_08
	"DDNS kann keine Verbindung herstellen.", //sh_port_msg_09
	"Fernzugriff zulassen", //sto_http_6
	"Möchten Sie diesen Benutzer wirklich löschen?", //file_acc_del_user
	"Möchten Sie diesen Pfad wirklich löschen?", //file_acc_del_path
	"Möchten Sie diese Datei wirklich löschen?", //file_acc_del_file
	"Noch einmal anmelden", //_login_a
	"DDNS für IPv6 HOSTS", //IPv6_ddns_01
	"IPv6 DDNS-LISTE", //IPv6_ddns_02
	"IPv6-Firewall unten konfigurieren:", //IPv6_fw_01
	"IPv6-Firewall AUSSCHALTEN", //IPv6_fw_02
	"IPv6 Firewall und aufgelistete Zulassungsregeln EINSCHALTEN", //IPv6_fw_03
	"IPv6 Firewall und aufgelistete Verweigerungsregeln EINSCHALTEN", //IPv6_fw_04
	"IP-Adressbereich", //IPv6_fw_ipr
	"Portbereich", //IPv6_fw_pr
	"Quelle", //IPv6_fw_sr
	"Ziel", //IPv6_fw_dest
	"6rd Relay darf nicht leer sein.", //IPv6_6rd_relay
	"Ändern Sie bitte zuerst das IPv4 WAN-Protokoll auf den DHCP-Modus.", //IPv6_6rd_wan
	"6to4 Relay darf nicht leer sein.", //IPv6_6to4_relay
	"Adressbereich (Start)", //IPv6_addrSr
	"Adressbereich (Ende)", //IPv6_addrEr
	"Die Nutzung der WPA Only-Verschlüsselung deaktiviert WPS. Sind Sie sicher?", //msg_wps_sec_04
	"Warten Sie bitte %d Sekunden.", //msg_wait_sec
	"Wählen Sie bitte eine Datei aus, die gelöscht werden soll.", //file_acc_del_empty
	"IPv6 PPPoE ist zusammen mit IPv4 PPPoE freigegeben. Ändern Sie bitte zuerst das IPv6 WAN-Protokoll.", //IPV6_TEXT161a
	"Statistiken WI-FI 2.4GHZ", //ss_Wstats_2
	"Statistiken WI-FI 5GHZ", //ss_Wstats_5g
	"Medienserver", //dlna_t
	"Medienserver aktivieren", //dlna_01
	"Name des Medienservers", //dlna_02
	"Angegebener Name des Medienservers ist ungültig", //dlna_03
	"Russia PPTP (Dual Access)", //rus_wan_pptp
	"Russia PPTP (Dual Access) Internetverbindungstyp", //rus_wan_pptp_01
	"Russia L2TP (Dual Access)", //rus_wan_l2tp
	"Russia L2TP (Dual Access) Internetverbindungstyp", //rus_wan_l2tp_01
	"Russia PPPoE (Dual Access)", //rus_wan_pppoe
	"Russia PPPoE (Dual Access) Internetverbindungstyp", //rus_wan_pppoe_02
	"Einstellung WAN Physisch", //rus_wan_pppoe_03
	"Die Nutzung der WPA-Enterprise-Verschlüsselung deaktiviert WPS. Sind Sie sicher?", //msg_wps_sec_05
	"Anmeldung für Web-Dateizugriff", //webf_login
	"Anmelden auf dem Web-Dateizugriff-Server", //webf_intro
	"SharePort-Webzugriff", //webf_title
	"Neuer Ordner", //webf_folder
	"Festplatte meines Zugriffgeräts", //webf_hd
	"Ordner erstellen", //webf_createfd
	"Geben Sie einen Ordnernamen ein.", //webf_fd_name
	"Datei hochladen", //webf_upload
	"Wählen Sie bitte eine Datei.", //webf_file_sel
	"Wenn Sie die gemeinsame Nutzung von Medieninhalten mit Geräten aktivieren, kann jeder Computer oder jedes Gerät, das eine Verbindung zu Ihrem Netzwerk herstellt, Ihre freigegebene Musik und freigegebenen Bilder und Videos anzeigen und abspielen.", //dlna_t1
	"<strong>HINWEIS: </strong>Die freigegebenen Medien sind möglicherweise nicht sicher. Es wird empfohlen, das Streamen von Medieninhalten auf beliebige Geräte nur in entsprechend sicheren Netzen zuzulassen.", //dlna_t2
	"Das ermöglicht Ihnen, auf Dateien von einer externen USB-Festplatte oder einem USB-Stick (Thumbdrive) zuzugreifen, der/die über Ihr lokales Netzwerk oder das Internet an den %m angeschlossen ist/sind, indem Sie entweder einen Webbrowser oder die SharePort<sup>TM</sup> Mobile App für Ihr Smartphone oder Ihren Tablet-PC verwenden. Sie können Benutzer erstellen und die Zugriffsberechtigungen auf die auf dem USB-Laufwerk gespeicherten Dateien Ihren Erfordernissen entsprechend anpassen. Klicken Sie nach Durchführung Ihrer Änderungen auf <strong>Einstellungen speichern</strong>.", //help_stor1
	"Markieren Sie dieses Kontrollkästchen, um den gemeinsamen Zugriff auf Dateien zu aktivieren, die auf einem USB-Speicherlaufwerk abgelegt sind, das mit dem %m verbunden ist.", //help_stor2
	"Geben Sie einen Port ein, der für den HTTP-Internetzugriff auf Ihre Dateien verwendet werden soll (8181 ist die standardmäßige Angabe). Dieser Port muss der IP-Adresse des %m bei Herstellung einer Verbindung hinzugefügt werden. Beispiel: http://192.168.0.1:8181", //help_stor3
	"Geben Sie einen Port ein, der für den sicheren HTTPS-Internetzugriff auf Ihre Dateien verwendet werden soll (4433 ist die standardmäßige Angabe). Dieser Port muss der IP-Adresse des %m bei Herstellung einer Verbindung hinzugefügt werden. Beispiel: https://192.168.0.1:4433", //help_stor4
	"Markieren Sie dieses Kästchen, um den Fernzugriff auf den Speicher Ihres Routers zu aktivieren.", //help_stor5
	"Benutzererstellung", //help_stor6
	"Um einen neuen Benutzer zu erstellen, geben Sie einen Benutzernamen ein. Wenn Sie einen vorhandenen Benutzer bearbeiten möchten, verwenden Sie das Dropdown-Feld auf der rechten Seite.", //help_stor7
	"Geben Sie ein Kennwort ein, das Sie für das Konto verwenden möchten, und geben Sie es dann noch einmal zur Bestätigung im Textfeld <strong>Kennwort bestätigen</strong> ein. Klicken Sie dann auf <strong>Hinzufügen/Bearbeiten</strong>.", //help_stor8
	"In diesem Abschnitt werden die vorhandenen Benutzerkonten angezeigt. Vorgegeben Sind die Konten <strong>admin</strong> und <strong>guest</strong>.", //help_stor9
	"Mithilfe dieser Funktion können Sie Musik, Bilder und Videos gemeinsam mit anderen über alle Geräte, die mit Ihrem Netzwerk verbunden sind, nutzen. Klicken Sie nach Durchführung Ihrer Änderungen auf <strong>Einstellungen speichern</strong>.", //help_dlna1
	"Kein USB-Speicher eingesetzt.", //webf_non_hd
	"DDNS-Erkennung fehlgeschlagen!", //sh_port_tx_22
	"DDNS-Verbindung fehlgeschlagen. Versuchen Sie es bitte noch einmal und überprüfen Sie Ihre Kontoinformationen oder klicken Sie auf 'Weiter', um Ihre DDNS-Einstellungen trotzdem zu speichern.", //sh_port_tx_23
	"IPv6 Ingress-Filterung aktivieren", //IPv6_Ingress_Filtering_enable
	"Musik", //share_title_1
	"Foto", //share_title_2
	"Film", //share_title_3
	"Dokument", //share_title_4
	"Songs werden gesucht...", //share_ser_1
	"Fotos werden gesucht...", //share_ser_2
	"Film wird gesucht......", //share_ser_3
	"Dokumente werden gesucht...", //share_ser_4
	"Verbindung wird abgebrochen...", //ddns_disconnecting
	"Reservierungs-IP", //lan_reserveIP
	"End-IP-Adresse", //end_ip
	"Keine", //_NULL
	"dyndns.com(Custom)", //ddns_sel2
	"dyndns.com(Free)", //ddns_sel3
	"Remote IP-Adresse", //_remoteipaddr
	"Zurück", //_back
	"Ping %s fehlgeschlagen.", //_ping_fail
	"Ping %s erfolgreich.", //_ping_success
	"Die WPS-Funktion ist derzeit deaktiviert. Klicken Sie auf \"Ja\", um sie zu aktivieren, oder auf \"Nein\", um den Assistenten zu beenden.", //_wz_disWPS
	"Das Kontokennwort muss mehr als sechs Zeichen aufweisen", //limit_pass_msg
	"When WPS is enabled, security mode can not set WEP, EAP,and WPA only, or cipher type can not set TKIP.", //_gz_wps_enable
	"When security mode is WEP, EAP, ciphter type is TKIP, or WPA only, WPS can not be enabled.", //_gz_wps_deny
	"Auto 20/40/80 MHz", //bwl_ht204080
	"Fertig", //_supp_close
	"nur 802.11ac", //bwl_Mode_ac
	"Mischbetrieb (802.11ac und 802.11n)", //bwl_Mode_acn
	"Gemischt 802.11ac, 802.11n und 802.11a", //bwl_Mode_acna
	"Drahtlos 2.4GHz", //_wireless_2
	"Drahtlos 5GHz", //_wireless_5
	"WPS", //_WPS
	"Geräteliste", //_statlst
	"Wireless Security Setting", //_wifiser_title
	"SSID auswählen", //_wifiser_title0
	"SSID auswählen", //_wifiser_title1
	"WEP-OPEN", //_wifiser_mode0
	"WEP-SHARED", //_wifiser_mode1
	"WEP-AUTO", //_wifiser_mode2
	"WPA-PSK", //_wifiser_mode3
	"WPA2-PSK", //_wifiser_mode4
	"WPA2-PSKl Gemischt", //_wifiser_mode5
	"WPA2", //_wifiser_mode6
	"WPA2-Enterprise Gemischt", //_wifiser_mode7
	"Verschlüsselungstyp", //_wifiser_mode8
	"If you choose WPA/WPA2-TKIP encryption, the wireless mode should be Non-HT 11n mode. This means you will NOT get high throughput performance due to the fact that is not supported by 11N specification.", //_wifiser_mode9
	"Default Schlüssel", //_wifiser_mode10
	"Schlüssel", //_wifiser_mode11
	"HEX", //_wifiser_mode12
	"WPA Verschlüsselungsart", //_wifiser_mode13
	"Schlüssel Aktualisierungs-Abstand", //_wifiser_mode14
	"PMK Cache Periode", //_wifiser_mode15
	"Vor-Authentifizierung", //_wifiser_mode16
	"802.1x WEP", //_wifiser_mode17
	"RADIUS-Servers", //_wifiser_mode18
	"Gemeinsamer geheimer Schlüssel", //_wifiser_mode19
	"Sitzungstimeout", //_wifiser_mode20
	"Leerlauf Timeout", //_wifiser_mode21
	"W-LAN MAC Filter", //_wifiser_mode22
	"Filtermodus:", //_wifiser_mode23
	"Ablehnen", //_wifiser_mode24
	"Ungültiges MAC Adressen", //_wifiser_mode25
	"Kann mehr als 24 Einträge in der MAC Filter-Liste nicht Hinzufügen.", //_wifiser_mode26
	"Bitte ein gültiges Intervall zur Schlüsselcodewiederherstellung eingeben.", //_wifiser_mode27
	"Schlüsselcode Erneuerung Intervallwert muss größer oder gleich 60 sein.", //_wifiser_mode28
	"Bitte einen gültigen Schlüsselcode PMK Cache Periode eingeben.", //_wifiser_mode29
	"10 oder 26 Charaktere WEP-Schlüssel Bitte eingeben", //_wifiser_mode30
	"5 oder 13 Charaktere WEP-Schlüssel Bitte eingeben", //_wifiser_mode31
	"Bitte den WEP Schlüsselcode eingeben", //_wifiser_mode32
	"Bitte die PMK Cache Zeitspanne eingeben.", //_wifiser_mode33
	"Bitte weniger als 63 ASCII Zeichen für einen WPA-PSK Schlüssel eingeben!", //_wifiser_mode34
	"Bitte mindestens 8 ASCII Zeichen für einen WPA-PSK Schlüssel eingeben!", //_wifiser_mode35
	"Bitte Input 64 Hexencharakter von WPA-PSK-Schlüssel!", //_wifiser_mode36
	"Geben Sie bitte den WPA-PSK-Schlüssel ein!", //_wifiser_mode37
	"Wenn Sie Unterstützung Multi-SSID wünschen und Hoffnungssicherheit richtig arbeiten kann, Neustartgerät bitte nicht vergessen, wenn Sie irgendeine Einstellung ändern.", //_wifiser_mode38
	"Sind Sie sicher, dass Sie die Änderungen ignorieren möchten?", //_wifiser_mode39
	"MAC-Filterliste", //_wifiser_mode40
	"Der W-LAN Sender is AUS.", //_wifiser_mode41
	"Regel aktivieren", //_adv_txt_00
	"Regelname", //_adv_txt_01
	" Regel Name: %s, das eingeführt wird, ist ungültig.", //_adv_txt_02
	"Der virtuelle Server legt einen einzelnen öffentlichen Port für die Weiterleitung zum internen IP und Port fest.", //_adv_txt_03
	"Virtuellen Server hinzufügen", //_adv_txt_04
	"Liste virtuelle Server", //_adv_txt_05
	"Spiele", //_adv_txt_06
	"That can open multiple ports or a range of ports in your router.", //_adv_txt_07
	"The formats including Single Port (ex: 80), Port Ranges (ex: 50-60).), Individual Ports (80, 68, 888), or Mixed (1020-5000, 689).", //_adv_txt_08
	"Add Port Range Rule", //_adv_txt_09
	"Port Range Rule List", //_adv_txt_10
	"TCP/UDP Ports", //_adv_txt_11
	"Port Weiterleitung", //_adv_txt_12
	"Port trigger is a way to automate port forwarding in which outbound traffic on predetermined ports ('triggering ports') causes inbound traffic to specific incoming ports to be dynamically forwarded to the initiating host, while the outbound ports are in use.", //_adv_txt_13
	"Please assign the port with below format:<br>1. Single Port (ex: 80)<br>2. Port Ranges (ex: 50-60)", //_adv_txt_14
	"Port Ansteuerungsfunktion", //_adv_txt_15
	"Port Ansteuerung Regel hinzufügen", //_adv_txt_16
	"Übernehmen", //_adv_txt_17
	"Port ansteuern", //_adv_txt_18
	"Regel Liste", //_adv_txt_19
	"Matchprotokoll", //_adv_txt_20
	"Match Port", //_adv_txt_21
	"Protokolle/Ports", //_adv_txt_22
	"Netzwerk", //_network
	"Ansteuerung", //_management
	"Firmware uploaden", //_upload_firm
	"Einstellung Verwaltung", //_settings_management
	"Zeit  ", //_time_cap
	"System Log", //_system_log
	"IPv6-Status", //_ipv6_status
	"ALG", //_alg
	"WAN-Einstellungen", //_wan_setting
	"LAN-Einstellungen", //_lan_setting
	"IPv6-Einstellungen", //_ipv6_setting
	"oben", //_top
	"Netzwerk Hilfe", //_network_help
	"QoS-Einstellung", //_qos_help
	"W-LAN Hilfe", //_wireless_help
	"Administrator-Hilfe", //_administrator_help
	"WAN Anschlußtyp", //_wan_conn_type
	"There are several connection types to choose from: Static IP, DHCP, PPPoE, PPTP, L2TP, and Russia PPTP. If you are unsure of your connection method, please contact your Internet Service Provider.", //_help_txt2
	"STATISCH", //_static
	"Hilfe-MENÜ", //_help_txt1
	"Your ISP provides a set IP address that does not change. The IP information is manually entered in your IP configuration settings. You must enter the IP address, Subnet Mask, Gateway, Primary DNS Server, and Secondary DNS Server. Your ISP provides you with all of this information.", //_help_txt4
	"A method of connection where the ISP assigns your IP address when your router requests one from the ISP's server.", //_help_txt6
	"<b>Host Name:</b> Some ISP's may check your computer's Host Name. The Host Name identifies your system to the ISP's server.", //_help_txt7
	"Select this option if your ISP requires you to use a PPPoE (Point to Point Protocol over Ethernet) connection. DSL providers typically use this option. This method of connection requires you to enter a <b>Username</b> and <b>Password</b> (provided by your Internet Service Provider) to gain access to the Internet.", //_help_txt9
	"<b>Wiedereinwahlmodus: </b>Gewöhnlich sind PPPoE-Verbindungen nicht immer online. Der Router erlaubt Ihnen einen Wiedereinwahlmodus einzustellen. Die Einstellungen sind", //_help_txt10
	"<b>Immer aktiv: </b>Eine Verbindung zum Internet wird immer aufrecht erhalten.", //_help_txt11
	"<b>Auf Verlangen: </b>Eine Verbindung zum Internet wird bei Bedarf hergestellt.", //_help_txt12
	"<b>Manuell: </b>Sie öffnen die webbasierte Benutzeroberfläche und klicken jedesmal manuell die Verbindungstaste, wenn Sie eine Verbindung zum Internet herstellen möchten.", //_help_txt13
	"<b>Maximale Leerlaufzeit: </b>Maximale Leerlaufzeit Gibt an, wie lange der Computer inaktiv sein kann, bevor die PPPoE-Verbindung getrennt wird. Der Wert für die maximale Leerlaufzeit wird nur bei den Wiederverbindungsmodi \"Bei Bedarf\" und \"Manuell\" verwendet.", //_help_txt14
	"L2TP (Layer Two Tunneling Protocol) verwendet ein Virtuelles Privates Netzwerk zur Verbindung mit Ihrem ISP. Es benötigt die Eingabe von Benutzername und Passwort (von Ihrem Internetdienstanbieter zugewiesen), um die Internetverbindung herzustellen.", //_help_txt16
	"<b>L2TP-Server-IP-Adresse: </b>Das ISP liefert, wenn erforderlich, diesen Parameter. Dieser Wert kann derselbe wie die IP-Adresse des Gateways sein.", //_help_txt17
	"<b>Wiedereinwahlmodus: </b>Gewöhnlich sind PPPoE-Verbindungen nicht immer online. Der Router erlaubt Ihnen einen Wiedereinwahlmodus einzustellen. Die Einstellungen sind", //_help_txt18
	"<b>Immer aktiv: </b>Eine Verbindung zum Internet wird immer aufrecht erhalten.", //_help_txt19
	"<b>Auf Verlangen: </b>Eine Verbindung zum Internet wird bei Bedarf hergestellt.", //_help_txt20
	"<b>Manuell: </b>Sie öffnen die webbasierte Benutzeroberfläche und klicken jedesmal manuell die Verbindungstaste, wenn Sie eine Verbindung zum Internet herstellen möchten.", //_help_txt21
	"<b>Maximale Leerlaufzeit: </b>Maximale Leerlaufzeit Gibt an, wie lange der Computer inaktiv sein kann, bevor die PPPoE-Verbindung getrennt wird. Der Wert für die maximale Leerlaufzeit wird nur bei den Wiederverbindungsmodi \"Bei Bedarf\" und \"Manuell\" verwendet.", //_help_txt22
	"<b>Static:</b> If your ISP has assigned a fixed IP address, select this option. The ISP provides the values for the following fields for <b>WAN Interface IP Setting: IP Address, Subnet Mask , Default Gateway.</b>", //_help_txt24
	"<b>Dynamic:</b> If the ISP's servers assign the router's IP addressing upon establishing a connection, select this option.", //_help_txt25
	"PPTP (Point to Point Tunneling Protocol) verwendet ein Virtuelles Privates Netzwerk zur Verbindung mit Ihrem ISP. Diese Verbindungsart wird hauptsächlich in Österreich verwendet. Sie benötigt die Eingabe von Benutzername</b> und Passwort</b> (von Ihrem Internetdienstanbieter zugewiesen), um die Internetverbindung herzustellen.", //_help_txt27
	"<b>PPTP-Server-IP-Adresse: </b>Das ISP liefert, wenn erforderlich, diesen Parameter. Dieser Wert kann derselbe wie die IP-Adresse des Gateways sein.", //_help_txt28
	"<b>Wiedereinwahlmodus: </b>Gewöhnlich sind PPPoE-Verbindungen nicht immer online. Der Router erlaubt Ihnen einen Wiedereinwahlmodus einzustellen. Die Einstellungen sind", //_help_txt29
	"<b>Immer aktiv: </b>Eine Verbindung zum Internet wird immer aufrecht erhalten.", //_help_txt30
	"<b>Auf Verlangen: </b>Eine Verbindung zum Internet wird bei Bedarf hergestellt.", //_help_txt31
	"<b>Manuell: </b>Sie öffnen die webbasierte Benutzeroberfläche und klicken jedesmal manuell die Verbindungstaste, wenn Sie eine Verbindung zum Internet herstellen möchten.", //_help_txt32
	"<b>Maximale Leerlaufzeit: </b>Maximale Leerlaufzeit Gibt an, wie lange der Computer inaktiv sein kann, bevor die PPPoE-Verbindung getrennt wird. Der Wert für die maximale Leerlaufzeit wird nur bei den Wiederverbindungsmodi \"Bei Bedarf\" und \"Manuell\" verwendet.", //_help_txt33
	"WAN Interface IP Type", //_help_txt34
	"<b>Static:</b> If your ISP has assigned a fixed IP address, select this option. The ISP provides the values for the following fields for <b>WAN Interface IP Setting: IP Address, Subnet Mask , Default Gateway</b>, and optional for <b>DNS Server</b>", //_help_txt35
	"<b>Dynamic:</b> If the ISP's servers assign the router's IP addressing upon establishing a connection, select this option.", //_help_txt36
	"WAN MTU Setting", //_help_txt37
	"The Maximum Transmission Unit (MTU) is a parameter that determines the largest packet size (in bytes) that the router will send to the WAN. If LAN devices send larger packets, the router will break them into smaller packets. Ideally, you should set this to match the MTU of the connection to your ISP. Typical values are 1500 bytes for an Ethernet connection and 1492 bytes for a PPPoE connection. If the router's MTU is set too high, packets will be fragmented downstream. If the router's MTU is set too low, the router will fragment packets unnecessarily and in extreme cases may be unable to establish some connections. In either case, network performance can suffer. t modes.", //_help_txt38
	"LAN Interface Setting", //_help_txt39
	"The IP address of the this device on the local area network. Assign any unused IP address in the range of IP addresses available for the LAN. For example, 192.168.10.101.", //_help_txt41
	"The subnet mask of the local area network.", //_help_txt43
	"DHCP stands for Dynamic Host Configuration Protocol. The DHCP section is where you configure the built-in DHCP Server to assign IP addresses to the computers and other devices on your local area network (LAN).", //_help_txt45
	"Once your router is properly configured and this option is enabled, the DHCP Server will manage the IP addresses and other network configuration information for computers and other devices connected to your Local Area Network. There is no need for you to do this yourself.", //_help_txt47
	"The computers (and other devices) connected to your LAN also need to have their TCP/IP configuration set to \"DHCP\" or \"Obtain an IP address automatically\". When you set <b>Enable DHCP Server</b>, the following options are displayed.", //_help_txt48
	"These two IP values (Start and End) define a range of IP addresses that the DHCP Server uses when assigning addresses to computers and devices on your Local Area Network. TAny addresses that are outside of this range are not managed by the DHCP Server; these could, therefore, be used for manually configured devices or devices that cannot use DHCP to obtain network address details automatically.", //_help_txt50
	"It is possible for a computer or device that is manually configured to have an address that does reside within this range. In this case the address should be reserved, so that the DHCP Server knows that this specific address can only be used by a specific computer or device.", //_help_txt51
	"Your router, by default, has a static IP address of 192.168.10.1. This means that addresses 192.168.10.2 to 192.168.10.254 can be made available for allocation by the DHCP Server.", //_help_txt52
	"The subnet mask of the local area network.", //_help_txt54
	"The IP address of the router on the local area network. For example, 192.168.10.1.", //_help_txt56
	"The amount of time that a computer may have an IP address before it is required to renew the lease. The lease functions just as a lease on an apartment would. The initial lease designates the amount of time before the lease expires. If the tenant wishes to retain the address when the lease is expired then a new lease is established. If the lease expires and the address is no longer needed than another tenant may use the address.", //_help_txt58
	"DHCP-Reservierung Hinzufügen/Bearbeiten", //_help_txt59
	"This option lets you reserve IP addresses, and assign the same IP address to the network device with the specified MAC address any time it requests an IP address. This is almost the same as when a device has a static IP address except that the device must still request an IP address from the router. The router will provide the device the same IP address every time. DHCP Reservations are helpful for server computers on the local network that are hosting applications such as Web and FTP. Servers on your network should either use a static IP address or use this option.", //_help_txt60
	"You can assign a name for each computer that is given a reserved IP address. This may help you keep track of which computers are assigned this way. Example: <b>Game Server</b>.", //_help_txt62
	"Die LAN Adresse, die Sie reservieren möchten.", //_help_txt64
	"To input the MAC address of your system, enter it in manually or connect to the router's Web-Management interface from the system and click the <b>Copy Your PC's MAC Address</b> button.", //_help_txt66
	"A MAC address is usually located on a sticker on the bottom of a network device. The MAC address is comprised of twelve digits. Each pair of hexadecimal digits are usually separated by dashes or colons such as 00-0D-88-11-22-33 or 00:0D:88:11:22:33. If your network device is a computer and the network card is already located inside the computer, you can connect to the router from the computer and click the <b>Copy Your PC's MAC Address</b> button to enter the MAC address.", //_help_txt67
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt69
	"This shows clients that you have specified to reserve DHCP addresses. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit DHCP Reservation\" section is activated for editing.", //_help_txt71
	"In diesem Bereich können Sie sehen, welche LAN-Geräte momentan IP-Adressen bezogen haben.", //_help_txt73
	"IPv6 can be configured with the following connection types: Stateless DHCPv6, Stateful DHCPv6, Link-Local, Static, PPPoE, 6to4 , IPv6 in IPv4 Tunnel, and 6rd (IPv6 Rapid Deployment).  Please consult with your local ISP (Internet Service Provider) to obtain information in regard to the IPv6 connection type.  Note: In order to avoid any software conflict, please be sure to remove or disable any PPPoE client software on your computer when using the PPPoE connection type.", //_help_txt85
	"Please select this connection type if your ISP provides you with a set of IPv6 static addresses.  Configuration settings, such as IPv6 address, Default Gateway, Primary DNS Server, and Secondary DNS Server, and Subnet Prefix Length are required and will be entered manually.  Please contact your local ISP for all relevant information.", //_help_txt87
	"Zustandslose DHCPv6", //_help_txt82
	" Nodes on an IPv6 network can use the ICMPv6 and DHCPv6 server to obtain configuration information such as a list of DNS recursive name servers.  A Stateless DHCPv6 mode does not maintain any dynamic state for individual clients.", //_help_txt83
	"DHCPv6 (Zustandsbehaftet)", //_help_txt84
	"Hosts from DHCPv6 servers to obtain IP addresses and other configuration information.  Dynamic state information about each individual client is stored and centrally managed on the DHCPv6 server.", //_help_txt85
	"6to4 is provided as a transition for migrating from IPv4 to IPv6.  It allows IPv6 packets to be transmitted over an IPv4 network through the automatic tunneling technology, and routes traffic between 6to4 and IPv6 networks.", //_help_txt89
	"6in4", //_help_txt90
	"IPv6 in IPv4 tunneling has the capability to encapsulate IPv6 packets within IPv4 packets for transmission over an IPv4 infrastructure.", //_help_txt91
	"It is a mechanism used to facilitate IPv6 rapid deployment across current IPv4 infrastructures.", //_help_txt93
	"IPv6 DNS Server Setting", //_help_txt94
	"Enter the IPv6 addresses of the DNS Servers provided by your ISP.", //_help_txt95
	"LAN IPv6 IP Setting", //_help_txt96
	"The following settings will be applied to the LAN (Local Area Network) IPv6 interface.  You ISP will assign an IPv6 address and subnet (prefix /64 will be supported in LAN) to be configured in the LAN IPv6 Address Configuration section of this device.", //_help_txt97
	"Einstellungen für die LAN-Adressen-Autokonfiguration", //_help_txt98
	"Set up IPv6 Autoconfiguration in this section in order to have IPv6 addresses assigned to the clients on the local area network.", //_help_txt99
	"<b>Stateless Auto:</b> When connected to an IPv6 network utilizing ICMPv6 (Internet Control Message Protocol version 6) router discovery messages, IPv6 hosts will be configured automatically.", //_help_txt100
	"<b>Stateless DHCPv6:</b> A stateless DHCP server will only provide configuration information to the nodes and will rely on ICMPv6 (Internet Control Message Protocol version 6) router discovery messages to assign IPv6 addresses.", //_help_txt101
	"<b>DHCPv6(Stateful):</b> Dynamic Host Configuration Protocol for IPv6.  Stateless address autoconfiguration for IPv6 can be used to acquire access in an IPv6 network, however, it is generally recommended to use DHCPv6 instead to assign addresses, name servers and other configuration information to the clients.", //_help_txt102
	"<b>IPv6 Address Range (DHCPv6):</b> This device will manage IPv6 addresses and other configuration information for all clients connected to it as soon as it is properly configured with this option enabled.  However, users may also opt to use manual IPv6 configuration if they prefer as long as the address does not reside within the range specified here.", //_help_txt103
	"<b>IPv6 Address Lifetime:</b> The time duration in which a client is required to release and renew its IPv6 address.", //_help_txt104
	"Quality of Service Settings", //_help_txt105
	"QoS Setup", //_help_txt106
	"There are several Maximum upload bandwidth to choose or user defined.", //_help_txt107
	"QoS Group", //_help_txt108
	"There are several group of QoS rate and ceil upload bandwidth to setup.", //_help_txt109
	"Nur Link-Local", //_help_txt110
	"Die Link-local Adresse wird von Knoten und Routern bei der Kommunikation mit Nachbar-Knoten auf dem gleichen Link verwendet. Dieser Modus ermöglicht IPv6-fähigen Geräten, LAN-seitig miteinander zu kommunizieren.", //_help_txt111
	"Select this option if your ISP requires you to use a PPPoE (Point to Point Protocol over Ethernet) connection to IPv6 Internet. DSL providers typically use this option. This method of connection requires you to enter a <b>Username</b> and <b>Password</b> (provided by your Internet Service Provider) to gain access to the IPv6 Internet. ", //_help_txt113
	"<b>Auto:</b>Select this option if the ISP's servers assign the router's WAN IPv6 address upon establishing a connection.", //_help_txt114
	"<b>Static:</b>If your ISP has assigned a fixed IPv6 address, select this option. The ISP provides the value for the IPv6 Address.", //_help_txt115
	"QoS Liste", //_help_txt116
	"Vous pouvez configurer QoS pour application de différent protocole.", //_help_txt117
	"W-Lan Ein/Aus", //_help_txt121
	"This indicates the wireless operating status. The wireless can be turned on or off by the slide switch. When the radio is on, the following parameters are in effect.", //_help_txt122
	"If all of the wireless devices you want to connect with this router can connect in the same transmission mode, you can improve performance slightly by choosing the appropriate wireless mode. If you have some devices that use a different transmission mode, choose the appropriate wireless mode. ", //_help_txt123
	"There are many different configuration options available to choose from. Use the drop down list to select the wireless mode.", //_help_txt124
	"Note: One wireless mode can be selected can select at any one time. This means that you can only select one of the operating frequency at a time.", //_help_txt125
	"W-LAN Modus Optionen", //_help_txt126
	"<b>2.4GHz 802.11b/g mixed mode</b> - This wireless mode works in the 2.4GHz frequency range and will allow both wireless b and wireless g client to connect and access the %m at 11Mbps for wireless b, at 54Mbps for wireless g and share access at the same time. Although the wireless b/g operates in the 2.4GHz frequency, it will allow the use of other 2.4GHz client devices (Wireless n/g @ 54Mbps) to connect and access at the same time.", //_help_txt127
	"<b>2.4GHz 802.11 n only</b> ??This wireless mode works in the 2.4GHz frequency range and will only allow the use of wireless n client devices to connect and access the %m. Although the wireless n operates in the 2.4GHz frequency, this mode will only permit wireless n client devices to work and will exclude any other wireless mode and devices that are not wireless n only.", //_help_txt128
	"<b>5GHz 802.11a only mode</b> - This wireless mode works in the 5GHz frequency range and will allow wireless a client to connect and access the %m at 54Mbps for wireless a only mode. Although the wireless a operates in the 5GHz frequency, this mode will only permit wireless a client devices to work and will exclude any other wireless mode and devices that are not wireless a only.", //_help_txt129
	"<b>5GHz 802.11a/n mixed mode</b> - This wireless mode works in the 5GHz frequency range and will only allow the use of wireless a/n dual band client devices to connect and access the %m*. Dual band wireless client devices that support both wireless a/n can connect and access the %m. Wireless a client devices can connect and access the %m but, will only connect up to 54Mbps, (this due to the legacy limitation of wireless a technology for that standard). Although the wireless a/n operate in the same 5GHz frequency, this mode will only permit wireless a/n client devices to work and will exclude any other wireless mode and devices that are not wireless a/n. (note: wireless b/g/n will not be able to connect at the same time to the %m with 5GHz wireless a/n mode enable).", //_help_txt130
	"<b>2.4 GHz 802.11b/g/n mixed mode</b> - This wireless mode works in the 2.4GHz frequency range and will only allow the use of wireless g client devices to connect and access the %m at 11Mbps for wireless b, 54Mbps for wireless g and up to 150Mbps* for wireless n and share access at the same time. Although the wireless b/g/n operates in the same 2.4GHz frequency, it will allow the use of other 2.4GHz client devices (Wireless b/g/n) to connect and access at the same time.", //_help_txt131
	"*Maximum wireless signal rates are referenced from IEEE 802.11 theoretical specifications. Actual data throughput and coverage will vary depending on interference, network traffic, building materials and other conditions.", //_help_txt132
	"When you are browsing for available wireless networks, this is the name that will appear in the list (unless Visibility Status is set to Invisible, see below). This name is also referred to as the SSID. For security purposes, it is highly recommended to change from the pre-configured network name. Add up to three additional SSIDs to create virtual wireless networks from one wireless Router Access Point device.", //_help_txt133
	"Zusätzliche W-LAN Netzwerkkennung (SSID) hinzufügen", //_help_txt134
	"To add additional wireless Network Names simply add the name to the Multiple SSID field and click on apply at the bottom of the page. When finished, go to the Security section in this Users Guide for wireless security configuration.", //_help_txt135
	"frequenz (Kanal)", //_help_txt136
	"Ein drahtloses Netzwerk verwendet spezifische Kanäle im drahtlosen Spektrum, um die Kommunikation zwischen Clients zu handhaben. Einige Kanäle in Ihrem Bereich sind möglicherweise Interferenzen durch andere elektronische Geräte ausgesetzt. Wählen Sie den Kanal mit der geringsten Störung, um die Leistung und den Deckungsbereich Ihres drahtlosen Netzwerks zu optimieren.", //_help_txt137
	"Wireless Distribution System(WDS)", //_help_txt138
	"When WDS is enabled, this access point functions as a wireless repeater and is able to wirelessly communicate with other APs via WDS links. A WDS link is bidirectional; so this AP must know the MAC Address (creates the WDS link) of the other AP, and the other AP must have a WDS link back to this AP. Each WDS APs need setting as same channel, encryption type. (Note that WDS security is incompatible with mixed mode, like WPAPSK+WPA2PSK mixed, WEP AUTO and 802.1x, both feature cannot be used at the same time).", //_help_txt139
	"KonfigurationsWDS mit ", //_help_txt140
	"Enable the option for WDS and input the MAC Address of the wireless device that also supports WDS in to the blank fields. You can add up to four additional devices in the spaces provided. Click on apply at the bottom of the page, to apply your setting changes. Enable the security seeing in security page, each WDS APs need to use same security setting. (Note: WDS supports wireless g/n modes. The use multiple Access Point will reduces the overall network throughput to ½ the %m", //_help_txt141
	"When WDS is enabled, this access point functions as a wireless repeater and is able to wirelessly communicate with other APs via WDS links. A WDS link is bidirectional, so this AP must know the MAC Address (creates the WDS link) of the other AP, and the other AP must have a WDS link back to this AP. Make sure the APs are configured with same channel number, encryption type. (Note that WDS security is incompatible with mixed mode, like WPAPSK+WPA2PSK mixed, WEP AUTO and 802.1x, both feature cannot be used at the same time).", //_help_txt142
	"Input the MAC Address of the wireless device that also supports WDS link in to the blank fields. The other AP must also have the MAC address of this AP to create the WDS link back to this AP. Enter a MAC address for each of the other APs that you want to connect with WDS.", //_help_txt143
	"Physikalischer HT-Modus", //_help_txt144
	"Der HT (hohe Durchsatzrate) technische Modus lässt eine Steuerung der 802.11n W-LAn Umgebung zu.", //_help_txt145
	"Betriebsmodus", //_help_txt146
	"Gemischter Modus", //_help_txt147
	"Green Field", //_help_txt148
	"In this mode packets are transmitted with a preamble compatible with the legacy 802.11a/g, the rest of the packet has a new format. In this mode the receiver shall be able to decode both the Mixed Mode packets and legacy packets.", //_help_txt149
	"In this mode high throughput packets are transmitted without a legacy compatible part.", //_help_txt150
	"Kanalbreite", //_help_txt151
	"Kanalbreite der Wireless Übertragung festlegen.", //_help_txt152
	"20 Kanalbreite = 20 MHz", //_help_txt153
	"20/40 Kanalbreite = 20/40 MHz", //_help_txt154
	"Guard-Intervall", //_help_txt155
	"\"Kurze/Lange GI Unterstützung, denn der Zweck des Wächter-Intervalls besteht darin, eine Immunität gegen Laufzeitverzögerungen, Echos und Reflektionen, für die digitale Daten normalerweise sehr empfindlich sind, aufzubauen.", //_help_txt156
	"Lang", //_help_txt157
	"Langer Schutz-Abstand, 800 Nanosekunden", //_help_txt158
	"Kurzer Schutz-Abstand, 400 Nanosekunden", //_help_txt159
	"MCS", //_help_txt160
	"Fixez le taux MCS pour le taux HT.<br/>􀂃 0-15<br/>Le schéma de modulation et de codage (MCS) est une valeur qui détermine la modulation, le codage et un nombre de canaux spatiaux.", //_help_txt161
	"Beacon Intervall", //_help_txt162
	"Beacons sind Pakete, die von einem Wireless Router zur Synchronisierung an Wireless-Geräte gesendet werden. Geben Sie ein Beacon-Intervall zwischen 20 und 1000 Millisekunden an. Der Standardwert beträgt 100 Millisekunden.", //_help_txt163
	"DTIM", //_help_txt164
	"Bei einem DTIM handelt es sich um einen Countdown, der die Klienten über das Fenster zur nächsten Übertragung oder Multicast-Übertragung informiert. Hat der Wireless Router Übertragungen oder Multicast-Übertragungen für zugehörige Klienten im Pufferspeicher gesichert, sendet er den nächsten DTIM mit einem DTIM-Intervallwert. Wireless-Klienten erkennen diese Signale und wechseln in den aktiven Zustand, um die Übertragung und Multicast-Übertragung zu empfangen. Der Standardwert beträgt 1. Gültige Einstellungen liegen zwischen 1 und 255.", //_help_txt165
	"Fragmentierungsschwellenwert", //_help_txt166
	"Wireless frames can be divided into smaller units (fragments) to improve performance in the presence of RF interference and at the limits of RF coverage. Fragmentation will occur when frame size in bytes is greater than the Fragmentation Threshold. This setting should remain at its default value of 2346 bytes. Setting the Fragmentation value too low may result in poor performance.", //_help_txt167
	"When an excessive number of wireless packet collisions are occurring, wireless performance can be improved by using the RTS/CTS (Request to Send/Clear to Send) handshake protocol. The wireless transmitter will begin to send RTS frames (and wait for CTS) when data frame size in bytes is greater than the RTS Threshold. This setting should remain at its default value of 2346 bytes.", //_help_txt168
	"Kurze Einleitung und Slot", //_help_txt169
	"Die Verwendung eines kurzen (400 ns) Guard-Intervalls kann den Durchsatz erhöhen. Sie kann jedoch aufgrund von gesteigerter Empfindlichkeit gegenüber Radiofrequenzreflektionen auch die Fehlerrate in einigen Installationen erhöhen. Wählen Sie die Option, d", //_help_txt170
	"TX Burst", //_help_txt171
	"Der W-LAN Router kann eine bessere Durchsatzrate in derselben Periode und Umgebung erzielen, um die Geschwindigkeit zu erhöhen.", //_help_txt172
	"Pkt_Aggregate", //_help_txt173
	"Increase efficiency by aggregating multiple packets of application data into a single transmission frame. In this way, 802.11n networks can send multiple data packets with the fixed overhead cost of just a single frame.", //_help_txt174
	"Wenn keines dieser Verschlüsselungsverfahren ausgewählt ist, können Funkübertragungen zu und von Ihrem Netzwerk leicht von nicht autorisierten Benutzern abgefangen und gelesen werden.", //_help_txt175
	"Ein Verfahren zur Verschlüsselung von Daten in der drahtlosen Kommunikation, das den gleichen Grad an Datenschutz bieten soll wie in einem herkömmlichen kabelgebundenen Netzwerk. Die WEP-Verschlüsselung ist weniger sicher als die WPA-Verschlüsselung. Um Zugriff auf ein WEP-Netzwerk zu erhalten, muss der Schlüssel bekannt sein. Bei dem Schlüssel handelt es sich um eine Zeichenfolge, die Sie selbst erstellen. Bei der Verwendung von WEP müssen Sie die Verschlüsselungsstufe selbst angeben. Der Verschlüsselungstyp bestimmt dabei die Länge des Schlüssels. Eine 128-Bit-Verschlüsselung erfordert demzufolge einen längeren Schlüssel als eine 64-Bit-Verschlüsselung. Die Schlüssel werden durch Eingabe einer Zeichenfolge im HEX-Format (hexadezimal – die Zeichen 0-9 und A-F) oder im ASCII-Format (American Standard Code for Information Interchange – alphanumerische Zeichen) festgelegt. Das ASCII-Format ermöglicht hier die Eingabe einer Zeichenfolge, die sich einfacher merken lässt. Für die Verwendung im Netzwerk wird die eingegebene ASCII-Zeichenfolge in das HEX-Format konvertiert. Es können bis zu vier Schlüssel angegeben werden, so dass die Schlüssel schnell und einfach geändert werden können. Für die Verwendung im Netzwerk wird ein Standardschlüssel ausgewählt.", //_help_txt176
	"Both of these options select some variant of Wi-Fi Protected Access (WPA) -- security standards published by the Wi-Fi Alliance. The WPA Mode further refines the variant that the router should employ.", //_help_txt177
	"WPA Mode: WPA is the older standard; select this option if the clients that will be used with the router only support the older standard. WPA2 is the newer implementation of the stronger IEEE 802.11i security standard. With the \"WPA2\" option, the router tries WPA2 first, but falls back to WPA if the client only supports WPA. With the \"WPA2 Only\" option, the router associates only with clients that also support WPA2 security.", //_help_txt178
	"Cipher Type: The encryption algorithm used to secure the data communication. TKIP (Temporal Key Integrity Protocol) provides per-packet key generation and is based on WEP. AES (Advanced Encryption Standard) is a very secure block based encryption. With the \"TKIP and AES\" option, the router negotiates the cipher type with the client, and uses AES when available.", //_help_txt179
	"<b>Gruppenschlüssel Aktualisierungsintervall:</b> Die Länge der Zeit, bevor der Gruppenschlüssel, der für Broadcast- und Multicast-Daten verwendet wird, geändert wird.", //_help_txt180
	"Diese Option verwendet Wi-Fi Protected Access mit einem Pre-Shared Key (PSK).", //_help_txt181
	"Pre-Shared Key: Der Schlüssel wird als Pass-Phrase von bis zu 63 alphanumerischen Zeichen im ASCII-Format (American Standard Code for Information Interchange) an beiden Enden der drahtlosen Verbindung eingetragen. Er darf nicht kürzer als 8 Zeichen sein. Für eine angemessene Sicherheit sollte er von ausreichender Länge und kein allgemein bekannter Ausdruck sein. Dieser Ausdruck wird verwendet, um Sitzungsschlüssel zu erzeugen, die für jeden Wireless-Klienten einzigartig sind.", //_help_txt182
	"Dieser Bereich arbeitet mit einem RADIUS-Server zur Authentifizierung von Wireless-Klienten. Wireless-Klienten sollten die erforderlichen Berechtigungen besitzen, bevor sie versuchen, sich durch diesen Gateway auf dem Server zu authentifizieren. Ausserdem kann es erforderlich sein, den RADIUS-Server so zu konfigurieren, daß dieser dem Gateway die Benutzerauthentifizierung gestattet.", //_help_txt183
	"Authentifizierung ZeitüberschreitungD: ie Länge der Zeit bevor ein Klient zur erneuten Authentifizierung aufgefordert wird.", //_help_txt184
	"Radius-Server IP-Adresse: Die IP-Adresse des Authentifizierungsservers.", //_help_txt185
	"Radius Server-Port: Die Portnummer, die für den Anschluss des Authentifizierungsservers genutzt wird.", //_help_txt186
	"Radius-Server Shared Secret: Eine Pass-Phrase, welche mit dem Authentifizierungsserver zusammenpassen muß.", //_help_txt187
	"Wireless MAC Filtering", //_help_txt188
	"Choose the type of MAC filtering needed.", //_help_txt189
	"<b>Turn MAC Filtering Disable:</b> When \"Disable\" is selected, MAC addresses are not used to control network access.", //_help_txt190
	"Add MAC Filtering Rule", //_help_txt191
	"Use this section to add MAC addresses to the list below.", //_help_txt192
	"Enter the MAC address of a computer that you want to control with MAC filtering. Computers that have obtained an IP address from the router's DHCP server will be in the DHCP Client List. Select a device from the drop down menu.", //_help_txt193
	"Enable the WPS feature.", //_help_txt194
	"Locking the wireless security settings prevents the settings from being changed by any new external registrar using its PIN. Devices can still be added to the wireless network using WPS.", //_help_txt195
	"Eine PIN ist eine einzigartige Zahl, die verwendet werden kann, um den Router einem vorhandenen Netzwerk hinzuzufügen oder um ein neues Netzwerk zu erstellen. Die Standard-PIN ist möglicherweise auf der Unterseite des Routers aufgedruckt. Für mehr Sicherheit kann eine neue PIN generiert werden. Sie können die Standard-PIN jederzeit wiederherstellen. Nur der Administrator ('Admin'-Konto) kann die PIN ändern oder zurücksetzen.", //_help_txt196
	"Zeigt den aktuellen PIN-Wert des Routers an.", //_help_txt197
	"Reset To WPS Default", //_help_txt198
	"Stellen Sie die Standard-PIN des Routers wieder her.", //_help_txt199
	"Erstellen Sie eine zufällige Nummer, die eine gültige PIN ist. Dies wird die PIN des Routers. Sie können dann diese PIN in die Benutzeroberfläche des Registrators kopieren.", //_help_txt200
	"You could monitor stations which associated to this AP here.", //_help_txt201
	"Enter a password for the user \"admin\", who will have full access to the Web-based management interface. ", //_help_txt202
	"The name of the router can be changed here. ", //_help_txt203
	"Aktivieren Sie diese Option nur, wenn Sie Ihren eigenen Domainnamen beantragt und bei einem Dynamischen DNS-Dienstanbieter registriert haben. Die folgenden Parameter werden angezeigt, wenn diese Option aktiviert ist.", //_help_txt204
	"Dynamic DNS Provider", //_help_txt205
	"Wählen Sie einen Anbieter für dynamisches DNS aus der Dropdown-Liste, oder geben Sie manuell einen Anbieter an.", //_help_txt206
	"Geben Sie den vollständigen Namen Ihres Servers ein, z.B.: <b>myhost.mydomain.net</b>", //_help_txt207
	"Account", //_help_txt208
	"Enter the account provided by your service provider. If the Dynamic DNS provider supplies only a key, enter that key in all three fields. ", //_help_txt209
	"Enter the password provided by your service provider. If the Dynamic DNS provider supplies only a key, enter that key in all three fields. ", //_help_txt210
	"Haben Sie eine Firmware lokal auf Ihrem Computer, dann verwenden Sie diese Option, um den Computer nach der Datei zu durchsuchen und anschließend die Informationen hochzuladen.", //_help_txt211
	"Einstellungen exportieren", //_help_txt212
	"Mit dieser Option können die Routerkonfigurationen exportiert und in einer Datei auf dem Computer abgespeichert werden. Die Konfiguration immer vor einem Firmware-Upgrade abspeichern.", //_help_txt213
	"Einstellungen importieren", //_help_txt214
	"Verwenden Sie diese Option, um eine vorher gesicherte Routerkonfiguration wiederherzustellen.", //_help_txt215
	"Auf Werkseinstellungen zurücksetzen", //_help_txt216
	"This option restores all configuration settings back to the settings that were in effect at the time the router was shipped from the factory. Any settings that have not been saved will be lost. If you want to save your router configuration settings, use the<b> Export Settings</b> option above. ", //_help_txt217
	"System Neustart", //_help_txt218
	"Dies startet den Router neu. Das ist nützlich, wenn Sie sich nicht in der Nähe des Gerätes befinden.", //_help_txt219
	"Zeigt die Zeit an, die aktuell durch den Router verwendet wird. Wenn diese nicht korrekt ist, verwenden Sie die folgenden Optionen, um die Zeit richtig einzustellen", //_help_txt220
	"Wählen Sie Ihre lokale Zeitzone aus dem Klappmenü aus.", //_help_txt221
	"\"Diese Option auswählen, wenn die Router-Uhrzeit mit einem Netzwerk Zeitserver über das Internet synchronisiert werden soll. Wenn Zeitpläne oder Logbücher benutzt werden, ist dies der beste Weg, dass die Zeitpläne und Logbücher präzise bleibenBitte vormerken, auch wenn der NTP Server aktiviert wurde, müssen eine Zeitzone ausgewählt und die Sommerzeit-Parameter eingestellt werden.\"", //_help_txt222
	"Wählen Sie einen Netzwerkzeitserver für die Synchronisierung. Sie können die Adresse eines Zeitservers eingeben oder einen Zeitserver in der Liste auswählen. Wenn sich bei der Verwendung eines Servers Probleme ergeben, veruschen Sie einen anderen Server.", //_help_txt223
	"Wenn die NTP Server Option nicht eingeschaltet ist, kann die Uhrzeit für den Router an dieser Stelle manuell eingestellt werden.", //_help_txt224
	"Dieser Abschnitt zeigt die GerätStatusangaben an.", //_help_txt225
	"DMZ-Einstellungen", //_help_txt226
	"DMZ bedeutet 'Demilitarisierte Zone'. Wenn eine Anwendung Probleme damit hat, hinter einem Router zu operieren, können Sie einen Computer vom Internet aus erreichbar machen und die Anwendung auf diesem Computer laufen lassen.", //_help_txt227
	"Wenn ein LAN Computer als DMZ Host konfiguriert wird, wird er zum Ziel für alle ankommenden Pakete, die keiner anderen ankommenden Session oder Regel entsprechen. Wenn eine beliebige Eingangsregel existiert wird immer diese angewendet, statt die Pakete zum DMZ Host zu senden; Deshalb haben aktive Sessions, Virtuelle Server, ein aktiver Portauslöser oder eine Portweiterleitungsregel immer höhere Priorität vor dem Senden eines Pakets zum DMZ Host. (Die DMZ-Regel ähnelt einer Standard-Portweiterleitungsregel, die jeden Port weiterleitet, der nicht anderweitig definiert ist.)", //_help_txt228
	"Der Router stellt nur begrenzten Firewallschutz für den DMZ Host zur Verfügung. Der Router sendet ein TCP-Paket nicht weiter, das nicht zu einer aktiven DMZ Session passt, es sei denn es ist ein Verbindungseinrichtungspaket (SYN). Abgesehen von diesem begrenzten Schutz ist der DMZ Host effektiv „außerhalb der Firewall“. Jeder, der einen DMZ Host verwenden möchte, sollte deshalb eine Firewall auf dem DMZ Hostsystem verwenden, um zusätzlichen Schutz zu gewährleisten.", //_help_txt229
	"Die IP-Adressen der Pakete, die vom DMZ Host empfangen werden, sind von der WAN IP-Adresse des Routers zum LAN IP-Adresse des DMZ Hosts übersetzt worden. Die IP-Portnummern werden jedoch nicht übersetzt, damit Anwendungen auf dem DMZ Host mit den speziellen Portnummern verbunden sind.", //_help_txt230
	"Die DMZ Fähigkeit ist nur eines von mehreren Mitteln unaufgefordert eingehende Anfragen durch die NAT hereinzulassen. Im Allgemeinen sollte der DMZ Host nur eingerichtet werden, wenn es keine anderen Alternativen gibt, weil er viel mehr als jedes andere System im LAN Angriffen aus dem Internet ausgesetzt wird. Andere Konfigurationen sollten Vorrang haben: ein Virtueller Server, eine Portweiterleitungsregel oder ein Portauslöser. Virtuelle Server öffnen einen Port nur für für ankommende Sessions bestimmter Anwendungen (und erlauben somit auch Portumleitung und die Verwendung des ALGs). Portweiterleitung ist eher wie eine teilweise DMZ, in der der ankommende Verkehr, der an einen oder mehrer Ports gerichtet wird, zu einem bestimmten LAN Computer weitergesendet wird (dabei werden nicht so viel Ports wie auf einem DMZ Host geöffnet). Die Port-Auslösung ist eine spezielle Form der Portweiterleitung, die durch ausgehenden Verkehr aktiviert wird und die Ports nur weiterleitet, solange der Auslöser aktiv ist.", //_help_txt231
	"Nur wenige Anwendungen benötigen wirklich einen DMZ Host. Für folgende Beispiele könnte ein DMZ Host benötigt werden:", //_help_txt232
	"‧ Ein Computer muss einige Applikationen unterstützen, die überlappende Eingangs-Ports benutzen könnten, so dass zwei Portweiterleitungsregeln nicht verwendet werden könnten, weil sie sich möglicherweise widersprechen würden.", //_help_txt233
	"‧ Um ankommende Verbindungen zu verarbeiten, die ein anderes Protokoll als ICMP, TCP, UDP und IGMP verwenden (auch GRE und ESP, wenn diese Protokolle durch die PPTP und IPSec ALGs aktiviert werden).", //_help_txt234
	"Wird ein Rechner in die DMZ gesetzt, ist dieser Rechner ggf. zahlreichen Sicherheitsrisiken ausgesetzt. Diese Option sollte daher nur als letzter Ausweg genutzt werden.", //_help_txt235
	"Gibt die LAN IP Adresse des LAN Computers an, der über einen unbeschränkten Internetzugang verfügen soll.", //_help_txt236
	"Virtuellen Server hinzufügen/ändern", //_help_txt237
	"Gibt an, ob der Eintrag aktiv oder inaktiv ist.", //_help_txt238
	"Assign a meaningful name to the virtual server, for example <b>Web Server</b>. Several well-known types of virtual server are available from the \"Application Name\" drop-down list. Selecting one of these entries fills some of the remaining parameters with standard values for that type of server.", //_help_txt239
	"Die IP-Adresse des Systems in Ihrem internen Netzwerk, das den virtuellen Dienst liefert. Die Adresse könnte z. B. <b>192.168.0.50</b> sein.Sie können einen Computer von der Liste der DHCP Clients im „Computer Name“ Pulldown-Menü auswählen, oder Sie können die IP-Adresse des Server Computers manuell eingeben.", //_help_txt240
	"Wählen Sie das von dem Dienst verwendete Protokoll. Die allgemein gebräuchlichen Optionen -- UDP, TCP und beide UDP und TCP -- können von dem Dropdown-Menü gewählt werden. Um irgendein anderes Protokoll anzugeben, wählen Sie \"Andere\" von der Liste, und geben Sie dann die entsprechende Protokollnummer ( wie von der IANA zugewiesen ) in das Feld <b>Protokoll</b> ein.", //_help_txt241
	"Der Port, der in Ihrem internen Netzwerk verwendet werden soll.", //_help_txt242
	"Der Port, auf den über das Internet zugegriffen wird.", //_help_txt243
	"Wählen Sie einen Zeitplan für die Serviceaktivierung. Wenn Sie den benötigten Zeitplan nicht in der Liste finden.", //_help_txt244
	"Diesen Bildschirmbereich neu initialisieren und die bisherigen Änderungen verwerfen.", //_help_txt245
	"Statische Route hinzufügen/ändern", //_help_txt246
	"Eine neue Route zur IP Routing-Tabelle hinzufügen oder eine bestehende Route ändern.", //_help_txt247
	"IP-Adresse der Pakete, die diese Route verwenden", //_help_txt248
	"Gibt den nächsten Punkt (Hop) an, der bei Verwendung dieser Route angesprungen wird. Wenn die Adresse 0.0.0.0 als Gateway verwendet wird, bedeutet dies, dass es keinen nächsten Hop gibt und die passende IP-Adresse direkt mit dem Router auf der angegebenen Schnittstelle verbunden ist: LAN oder WAN.", //_help_txt249
	"Die Routenmetrik ist ein Wert zwischen 1 und 16, der die Kosten der Verwendung dieser Route angibt. Ein Wert von 1 steht für die niedrigsten Kosten, 15 für die höchsten Kosten. Der Wert 16 gibt an, dass die Route über diesen Router nicht erreichbar ist. Wenn versucht wird, ein bestimmtes Ziel zu erreichen, wählen die Computer in Ihrem Netzwerk die beste Route aus und ignorieren nicht erreichbare Routen.", //_help_txt250
	"Legt die Schnittstelle (LAN oder WAN) fest, die das IP-Paket verwenden muss, um bei Verwendung dieser Route den Router zu verlassen.", //_help_txt251
	"Diesen Bildschirmbereich neu initialisieren und die bisherigen Änderungen verwerfen.", //_help_txt252
	"The section shows the current routing table entries. Certain required routes are predefined and cannot be changed. Routes that you add can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Route\" section is activated for editing. Click the Enable checkbox at the left to directly activate or de-activate the entry.", //_help_txt253
	"Standardmäßig ist die Zugriffskontroll-Funktion deaktiviert. Wenn Sie Zugriffskontrolle benötigen, überprüfen Sie diese Option.", //_help_txt254
	"<b>Hinweis:</b>Wenn Zugriffskontrolle deaktiviert ist, hat jedes Gerät im LAN uneingeschränkten Zugriff zum Internet. Bei eingeschalteter Zugriffskontrolle  ist Internet-Zugriff für die Geräte eingeschränkt, für die eine Zugriffskontroll-Regel gilt. Alle anderen Geräte haben weiterhin uneingeschränkten Zugriff zum Internet.", //_help_txt255
	"By default, the ALG feature is enabled. ALG configuration allows users to disable some application service.", //_help_txt256
	"Add/Edit Port Trigger Rule", //_help_txt257
	"Specifies whether the entry will be active or inactive.", //_help_txt258
	"Enter a name for the Special Application Rule, for example <b>Game App</b>, which will help you identify the rule in the future. Alternatively, you can select from the <b>Application</b> list of common applications.", //_help_txt259
	"Select the protocol used by the service. The common choices -- UDP, TCP, and both UDP and TCP -- can be selected from the drop-down menu.", //_help_txt260
	"Enter the outgoing port range used by your application (for example <b>6500-6700</b>).", //_help_txt261
	"Select a schedule for when this rule is in effect.", //_help_txt262
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt263
	"This is a list of the defined application rules. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon.", //_help_txt264
	"Add/Edit Port Range Rule", //_help_txt265
	"Use this section to add a Port Range Rule to the following list or to edit a rule already in the list.", //_help_txt266
	"Specifies whether the entry will be active or inactive.", //_help_txt267
	"Give the rule a name that is meaningful to you, for example <b>Game Server</b>. You can also select from a list of popular games, and many of the remaining configuration values will be filled in accordingly. However, you should check whether the port values have changed since this list was created, and you must fill in the IP address field.", //_help_txt268
	"Enter the local network IP address of the system hosting the server, for example <b>192.168.10.50</b>. You can select a computer from the list of DHCP clients in the \"Computer Name\" drop-down menu, or you can manually enter the IP address of the server computer.", //_help_txt269
	"Zu öffnende TCP-Ports", //_help_txt270
	"Geben Sie die TCP-Ports ein, die geöffnet werden sollen (z. B. <b>6159-6180, 99</b>).", //_help_txt271
	"Zu öffnende UDP-Ports", //_help_txt272
	"Geben Sie die UDP-Ports ein, die geöffnet werden sollen (z. B. <b>6159-6180, 99</b>).", //_help_txt273
	"Wählen Sie einen Filter, der den für diese Regel benötigten Zugriff steuert.", //_help_txt274
	"Wählen Sie einen Zeitplan für die Zeiten, an denen diese Regel wirksam sein soll.", //_help_txt275
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt276
	"This is a list of the defined Port Range Rules. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Port Forwarding Rule\" section is activated for editing.", //_help_txt277
	"Regeln für eingehenden Verkehr hinzufügen/aktualisieren", //_help_txt278
	"Hier können Sie Einträge zur Inbound Filterliste hinzufügen oder bereits existierende Einträge bearbeiten.", //_help_txt279
	"Geben Sie einen beschreibenden Namen für die Regel ein.", //_help_txt280
	"Bei der Regel kann es sich entweder um Zulassen- oder um Verweigern-Meldungen handeln.", //_help_txt281
	"Define the ranges of Internet addresses this rule applies to. For a single IP address, enter the same address in both the <b>Start</b> and <b>End</b> boxes. Up to eight ranges can be entered. The <b>Enable</b> checkbox allows you to turn on or off specific entries in the list of ranges.", //_help_txt282
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt283
	"The section lists the current Inbound Filter Rules. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Inbound Filter Rule\" section is activated for editing.", //_help_txt284
	"Zusätzlich zu den hier aufgelisteten Filterregeln sind überall da, wo Inbound Filter angewendet werden können, zwei vordefinierte Filter möglich:", //_help_txt285
	"Allen WAN-Nutzern Zugriff auf die zugehörigen Funktionen genehmigen.", //_help_txt286
	"Unterbindet allen WAN-Benutzern den Zugriff zu ähnlichen Leistungsmerkmalen. (LAN Benutzer sind nicht von Inbound Filtern betroffen.)", //_help_txt287
	"Zeitplanregeln hinzufügen/bearbeiten", //_help_txt288
	"In diesem Abschnitt können Sie Einträge zu der Zeitplan Regelliste hinzufügen oder bereits vorhandene Einträge bearbeiten.", //_help_txt289
	"Geben Sie dem Zeitplan einen beschreibenden Namen, wie z. B. &quot;Wochenregel&quot;.", //_help_txt290
	"Setzen Sie ein Häkchen in das Kästchen für die gewünschten Tage oder wählen Sie den Auswahlknopf für die ganze Woche, um alle sieben Tage der Woche auszuwählen.", //_help_txt291
	"Wählen Sie diese Option, wenn dieser Zeitplan an dem/den ausgewählten Tag(en) den ganzen Tag über aktiv sein soll.", //_help_txt292
	"Falls Sie nicht die Option Ganzer Tag wählen, geben Sie hier die gewünschte Zeit ein. Die Startzeit wird in zwei Feldern eingegeben. Das erste Feld dient zur Eingabe der Stunden, das zweite Feld zur Eingabe der Minuten. E-Mail-Ereignisse werden normalerweise nur durch die Startzeit ausgelöst.", //_help_txt293
	"Die Endzeit wird im gleiche Format eingegeben wie die Startzeit, d. h. die Stunden werden im ersten Feld, die Minuten im zweiten Feld eingegeben. Die Endzeit wird bei den meisten Regeln verwendet, jedoch normalerweise nicht bei E-Mail-Ereignisse.", //_help_txt294
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt295
	"In diesem Abschnitt werden die zum aktuellen Zeitpunkt festgelegten Zeitplanregeln angezeigt. Ein Eintrag kann durch Klicken auf das Bearbeitungssymbol geändert oder durch Klicken auf das Löschsymbol gelöscht werden. Wenn Sie auf das Bearbeitungssymbol kl", //_help_txt296
	"By default, the UPnP feature is enabled. Universal Plug and Play (UPnP) is a set of networking protocols for primarily residential networks without enterprise class devices that permits networked devices, such as personal computers, printers, Internet gateways, Wi-Fi access points and mobile devices to seamlessly discover each other's presence on the network and establish functional network services for data sharing, communications, and entertainment.", //_help_txt297
	"By default, the WAN Ping Respond feature is disabled. Enable WAN Ping Respond will reply information of router to outside network.", //_help_txt298
	"The Inbound Filter controlling data received from the Internet. In this feature you can configure inbound data filtering rules that control data based on an IP address.", //_adv_txt_23
	"Eingangsfilterregel hinzufügen", //_adv_txt_24
	"Regel Aktion", //_adv_txt_25
	"Der %s-Name: %s ist bereits in der Liste", //_adv_txt_26
	"InlandsFilter-Liste", //_adv_txt_27
	"IPv6-Einstellungen", //_net_ipv6_01
	"Dieser Abschnitt erlaubt Ihnen, Ihre Einstellungen des Internetanschlusses IPv6 und Einstellungen LAN IPv6 zu konfigurieren. Wenn Sie nicht von Ihren Einstellungen des Internetanschlusses IPv6 sicher sind, oder wenn er verfügbar ist, mit Ihrem Internetanbieter bitte in Verbindung treten (ISP).", //_net_ipv6_02
	"WAN IPv6 IP-Einstellung", //_net_ipv6_03
	"Zustandslose Autokonfiguration", //_net_ipv6_04
	"Länge des LAN-Präfixes", //_net_ipv6_05
	"Paramétrages IPv6 vers IPv4", //_net_ipv6_06
	"IPv6-to-IPv4-Adresse", //_net_ipv6_07
	"PPPoE Einstellung", //_net_ipv6_08
	"Voreingestellte MTU Einstellung benutzen", //_net_ipv6_09
	"MTU Einstellung", //_net_ipv6_10
	"DNS manuell konfigurieren", //_net_ipv6_11
	"STATISCH", //_net_ipv6_12
	"(QoS) Quality of Service Einstellungen", //_qos_txt00
	"You may setup rules to provide Quality of Service guarantees for specific applications.", //_qos_txt01
	"QoS Setup", //_qos_txt02
	"QoS (Quality of Service)", //_qos_txt03
	"Upload-Bandbreite", //_qos_txt04
	"Eingetragener Benutzer", //_qos_txt05
	"Bits pro Sekunde.", //_qos_txt06
	"Download Bandbreite", //_qos_txt07
	"Default laden", //_qos_txt08
	"Der Wert der Upload-Bandbreite ist zu niedrig, sind Sie sicher?", //_qos_txt09
	"Der Wert der Upload-Bandbreite ist zu hoch.", //_qos_txt10
	"Die maximale Upload Bandbreite", //_qos_txt11
	"Die Upload-Bandbreite ist falsch. (z.B. \"10k\" \" 20M\")", //_qos_txt12
	"Die Antriebskraftbandbreite Bitte eintragen.", //_qos_txt13
	"Quell-Port", //_qos_txt14
	"Src Port-Bereich:", //_qos_txt15
	"Kategorie", //_qos_txt16
	"Informationen", //_qos_txt17
	"Prio", //_qos_txt18
	"Hochladen:  %s% mindestens", //_qos_txt19
	"Attribut", //_qos_txt20
	"Gruppen", //_qos_txt21
	"Einstellung", //_qos_txt22
	"Erweitert", //_qos_txt23
	"Grundlegende Klassifikator-Einstellungen", //_qos_txt24
	"End-Ziel-IP-Adresse", //_qos_txt25
	"Quell-IP-Adresse", //_qos_txt26
	"Packet-Länge", //_qos_txt27
	"ex: 0-128 für Päckchen", //_qos_txt28
	"DSCP", //_qos_txt29
	"Ziel Portbereich", //_qos_txt30
	"Src Port-Bereich:", //_qos_txt31
	"DSCP ausführen als:", //_qos_txt32
	"Eine Anwendung Bitte vorwählen.", //_qos_txt33
	"Ungültiger Quell Portbereich.", //_qos_txt34
	"Die Anschlussnummer Bitte eingeben.", //_qos_txt35
	"Ungültiges MAC Adressenformat.", //_qos_txt36
	"Der Name enthält ein nicht genehmigtes Zeichen.", //_qos_txt37
	"Einen Namen eingeben.", //_qos_txt38
	"Moderne Klassifikator-Einstellungen", //_qos_txt39
	"Ungültiger Ziel Portbereich.", //_qos_txt40
	"Der Packet-Längen Bereich ist ungültig.", //_qos_txt41
	"Die Packet-Länge ist zu klein.", //_qos_txt42
	"Die Packet-Länge ist zu groß.", //_qos_txt43
	"Packet-Länge sollte eine Ganze Zahl sein!", //_qos_txt44
	"Bitte einen Bereich für die Packet-Länge eingeben. (z.B. 0-128 64-1024)", //_qos_txt45
	"Bitte die Klassifizierungen eingeben.", //_qos_txt46
	"Basis W-LAN Einstellungen", //_basic_wireless_settings
	"Dieser Abschnitt erlaubt Ihnen, die grundlegenden Einstellungen zu konfigurieren, die für Ihr drahtloses Netzwerk wie Ihren Namen des drahtlosen Netzwerks (SSID) erfordert werden und Wi-Fischlüssel.", //_desc_basic
	"Dieser Abschnitt erlaubt Ihnen, drahtlose Kundengeräte zu überwachen, die z.Z. an Ihren Fräser angeschlossen werden.", //_desc_station_list
	"Dieser Abschnitt erlaubt Ihnen, WPS (Wi-Fi Geschützte Einrichtung) zu aktivieren das Ihnen erlaubt, Kundengeräte WPS an Ihren Fräser leicht anzuschließen fähige drahtlose. Der Fräser bietet drei Möglichkeiten an, drahtlose Kundengeräte unter Verwendung WPS anzuschließen: Hardware Druckknopf (physikalisch gelegen auf dem Fräser), Virtuelle Funktionstaste (PBC) oder PIN. WPS kann nicht verwendet werden, wenn die SSID-Sendungsfunktion untauglich ist.", //_desc_wps
	"DRAHTLOSES NETZWERK", //_wireless_network
	"Wireless Distribution System(WDS)", //_wds_long
	"WPS Konfig", //_wps_config
	"WPS Zusammenfassung", //_wps_summary
	"WPS Aktion", //_wps_action
	"DHCP Clients", //_dhcp_clients
	"Please click Wireless Client Card and Router's WPS button in 120 seconds to complete this setting.", //_desc_wps_action
	"W-Lan Ein/Aus", //_lb_radio_onoff
	"Termin für Ausschaltung", //_lb_radio_off_sche
	"Name des drahtlosen Netzwerks (SSID)", //_wmode_ssid
	"Multi SSID1", //_lb_multi_ssid_1
	"Multi SSID2", //_lb_multi_ssid_2
	"Multi SSID3", //_lb_multi_ssid_3
	"Multi SSID4", //_lb_multi_ssid_4
	"Multi SSID5", //_lb_multi_ssid_5
	"Multi SSID6", //_lb_multi_ssid_6
	"Multi SSID7", //_lb_multi_ssid_7
	"Netzwerkkennung senden (SSID):", //_lb_broadcast_ssid
	"Phy Modus", //_lb_phy_mode
	"Verschlüsselungstyp", //_lb_enc_type
	"Cryptage de clé", //_lb_enc_key
	"Remote AP MAC Adresse", //_lb_apmacaddr
	"HT20/40 Koexistenz", //_lb_coexistence
	"Umgekehrte Richtung Gewährung (RDG)", //_lb_rdg
	"MCS", //_lb_mcs
	"Kanal Ausweitung", //_lb_exten_channel
	"Bündelung MSDU(A-MSDU)", //_lb_a_msdu
	"SelbstBlock ACK", //_lb_autoba
	"Abnahme BA Antrag", //_lb_declineba
	"40 MHZ Intolerant", //_lb_forty_into
	"WiFi-Optimum", //_lb_wifi_opt
	"HT TxStream", //_lb_ht_txstream
	"HT RxStream", //_lb_ht_rxstream
	"Externe WPS-Registrierung blockiert", //_lb_wps_ext_reg_lock
	"Auto", //_sel_autoselect
	"Gemischter Modus", //_sel_mixed
	"Green Field", //_sel_greenfield
	"Lang", //_long
	"Radio Ein", //_btn_radio_on
	"Radio Aus:", //_btn_radio_off
	"Der W-LAN Sender is AUS.", //_MSG_woff
	"Use the Advanced Setup page to make detailed settings for the Wireless. Advanced Setup includes items that are not available from the Basic Setup page, such as Beacon Interval, etc.", //_desc_advanced
	"QoS-Einstellung", //_bx_advanced_2
	"Wi-Fi Multimedia", //_bx_advanced_3
	"Multicast-zu-Unicast Konverter", //_bx_advanced_4
	"BG-Schutz-Modus", //_lb_bg_protection
	"(Bereich 10 - 100, Rückstellung 100)", //_hint_beacon
	"(Bereich 1 - 255, Rückstellung 1)", //_hint_dtim
	"Fragmentierungsschwellenwert", //_lb_frag_thres
	"(Bereich 256 - 2346, Rückstellung 2346)", //_hint_frag_thres
	"(Bereich 1 - 2347, Rückstellung 2347)", //_hint_rts_thres
	"TX Stromversorgung", //_lb_txpower
	"Kurze Präambel", //_lb_short_preamble
	"Kurzer Slot", //_lb_short_slot
	"Tx Burst", //_lb_tx_burst
	"Pkt_Aggregate", //_lb_pkt_aggregate
	"Unterstützung IEEE 802.11H", //_lb_80211h_support
	"nur in A-Band", //_hint_only_a_band
	"Ländercode", //_lb_country_code
	"Möglichkeit WMM", //_lb_wmm_capable
	"APSD Fähig", //_lb_apsd_capable
	"DLS Fähig", //_lb_dls_capable
	"WMM Parameter", //_lb_wmm_param
	"WMM-Konfiguration", //_lb_wmm_config
	"Video Turbine", //_lb_video_turbine
	"Multicast-zu-Unicast", //_lb_multi_uni
	"Läuft aus", //_lb_expire_in
	"voll", //_pwr_full
	"Halb", //_pwr_half
	"Tief", //_pwr_low
	"Drahtlose WMM-Einstellungen", //_tl_wmm_settings
	"WMM Parameter des Access Points", //_lb_wmm_param_ap
	"WMM Parameter der Station", //_lb_wmm_param_station
	"gemischter 2.4GHz 802.11b/g", //m_bwl_Mode_3
	"Nur 2.4GHz 802.11n", //m_bwl_Mode_8
	"gemischter 2.4GHz 802.11b/g/n", //m_bwl_Mode_11
	"Nur 5GHz 802.11a", //m_bwl_Mode5_1
	"Nur 5GHz 802.11n", //m_bwl_Mode5_2
	"gemischter 5GHz 802.11a/n", //m_bwl_Mode5_3
	"Signal", //_singal
	"BSSID", //_bssid
	"WPS aktueller Status", //_wps_cur_state
	"WPS konfiguriert", //_wps_configed
	"WPS SSID", //_wps_ssid
	"WPS Sicherheitsmodus", //_wps_sec_mode
	"WPS Verschlüsselungstyp", //_wps_enc_type
	"WPS Default Schlüsselcode Index", //_wps_def_key_idx
	"HEX", //_hex
	"ASCII", //_ascii
	"WPS Key", //_wps_key
	"AP PIN", //_ap_pin
	"DHCP Clients können hier überwacht werden.", //_desc_dhcp_client_list
	"Setting wireless security.", //_wifiser_mode42
	"Wird bearbeitet", //_processing
	"Netzwerkstatus Adresse", //_netwrk_status_addr
	"System Info", //_system_info
	"Systemzeit", //_system_time
	"System Betriebszeit", //_system_up_time
	"Interneteinstellungen", //_internet_configs
	"Art der Verbindung", //_connected_type
	"WAN IP-Adresse", //_wan_ip_addr
	"Primärer Domain Server Name (DNS)", //_pri_dns
	"Zweiter Domain Namensserver (DNS)", //_sec_dns
	"2.4GHz Wireless Vebindung", //_24Ghz_wireless
	"5GHz Wireless Vebindung", //_5Ghz_wireless
	"Dieser Abschnitt zeigt die Protokollierungsinformationen des Gerätes zu Überwachungsund Überprüfungszwecken an.", //_SYSLOG_DESC
	"Aktivieren System Logbücher", //_enable_system_log
	"Zeit- und Datum-Konfiguration", //_time_setting
	"Dieser Abschnitt erlaubt Ihnen, die Zeit- und Datumseinstellungen des Routers zu konfigurieren.", //_TIME_DESC
	"Sommerzeit", //_daylight_saving_time
	"NTP Einstellungen", //_ntp_settings
	"NTP-Server", //_ntp_server
	"NTP Abgleichung", //_ntp_sync
	"Einstellungen Datum und Uhrzeit", //_date_time_settings
	"Dieser Abschnitt erlaubt Sie zur Unterstützung (Export) oder stellt (Import) die Konfiguration Ihres Fräsers wieder her. Diese Seite erlaubt Ihnen auch, den Fräser zu den FabrikStandardannahmen oder dem Neustart zurückzustellen.", //_SETTINGS_MANAGER_DESC
	"Exportieren", //_export
	"Ablage von Dateien festlegen", //_settings_file_location
	"import", //_import
	"FIRMWARE", //_upgrade_firmw
	"Sie können auf neueren Mikroprogrammaufstellung überprüfen, die für Ihr Gerät an der TRENDnet-Website verfügbar sind (<a href= \ „http://www.trendnet.com/downloads \“ style= \" Textdekoration: Unterstreichung; „> http://www.trendnet.com/downloads </a>). Ladende neuere Mikroprogrammaufstellung können Adreßprobleme oder Funktionalität Ihres Gerätes zu erhöhen. Es ist wichtig, dass Sie das Begleitschreiben überprüfen, das mit dem Mikroprogrammaufstellungsdownload eingeschlossen ist, wenn ein Problem möglicherweise, das Sie angetroffen haben, wird angesprochen oder wird adressiert, gibt oder, wenn es erhöhte Funktionalität möglicherweise, Sie hinzufügen möchten, bevor Sie zu einer neuen Mikroprogrammaufstellungsversion luden. Nachdem Sie die Datei herunterladen haben, die Datei zu Ihrem lokalen Festplattenlaufwerk extrahieren. Klicken-„Grasen“ oder „DateiBeschließen“ Knopf, um zum Standort der extrahierten Mikroprogrammaufstellungsdatei zu steuern. Klicken Trifft zu, um die Mikroprogrammaufstellung zu Ihrem Gerät zu laden.", //_FIRMW_DESC
	"Wichtige Anmerkung: Den Mikroprogrammaufstellungsantriebskraftprozeß nicht unterbrechen, wie er möglicherweise Ihr Gerät schädigt. Bitte warten, bis die Mikroprogrammaufstellungsantriebskraft völlig abgeschlossen hat und das Gerät erfolgreich Neustart hat.", //_FIRMW_DESC_sub
	"Standort", //_location
	"Übernehmen", //_apply
	"System Verwaltung", //_system_management
	"You may configure administrator account and password.", //_SYS_MANGER_DESC
	"Maximal: %s-Charaktere", //_max_length_characters
	"Geräte URL Einstellungen", //_device_url_settings
	"Geräte URL", //_device_url
	"Gerätename Einstellungen", //_device_name_settings
	"DDNS Einstellungen", //_ddns_settings
	"Remote-Management", //_remote_management
	"Fernsteuerung (via Internet)", //_remote_control_via_wan
	"Remote Port", //_remote_port
	"Zurücksetzen", //_reset
	"Wenn Sie mit diesen erweiterten Netzwerkeinstellungen nicht vertraut sind, lesen Sie bitte zuerst die Hilfe dazu, bevor Sie versuchen, diese Einstellungen zu ändern.", //_ADV_NETWRK_DESC
	"WAN Ping Antwort", //_wan_ping_respond
	"Zeitplanregel", //_schedule_rules
	"Define schedule rules for various firewall features.", //_SCHEDULE_DESC
	"ZEITPLANREGEL HINZUFÜGEN", //_add_sche_rule
	"Ganzer Tag – 24 Stunden", //_tsc_allday_24hr
	"Liste der Zeitplanregeln", //_schedule_rule_list
	"Uhrzeit Stempel", //_time_stamp
	"24-Stunden", //_24hr
	"gemischter 5GHz 802.11a/n/ac", //m_bwl_Mode5_4
	"Wegewahl Zwischen Zonen", //_routing_bet_zone
	"MAC Adresse Kopie", //_mac_clone
	"MAC Adresse Kopie", //_mac_addr_clone
	"DNS Servereinstellung", //_dns_server_setting
	"DHCP Einstellungen", //_dhcp_setting
	"You may choose different connection type suitable for your environment. Besides, you may also configure parameters according to the selected connection type.", //_DHCP_DESC
	"WAN Einstellungen (Wide Area Network)", //_wan_setting_l
	"(bytes) Rückstellung=%s bytes", //_mtu_default_byte
	"WAN Schnittstelle IP Einstellung", //_wan_if_ip_setting
	"Betriebsmodus", //_opeartion_mode
	"Keep-alive", //_keep_alive
	"Aufrechterhaltungsmodus: Zeitspanne Erneut wählen", //_keep_alive_mode_redial
	"Bei Bedarf-Modus:  Idle Time", //_on_demand_mode_idle_time
	"Minuten", //_mintues_lower
	"L2TP Einstellung", //_l2tp_setting
	"PPTP Einstellung", //_pptp_setting
	"Dynamischer", //_dynamic
	"Lokales Netzwerk (LAN) Einstellungen", //_lan_setting_l
	"Dieser Abschnitt erlaubt Ihnen, die IP- addresseinstellungen des Fräsers zu ändern. Tyically, die Fräser IP- addresseinstellungen braucht nicht geändert zu werden. Darüber hinaus erlaubt diese Seite Ihnen, die das DHCP-Servereinstellungen des Fräsers zu konfigurieren oder DHCP-Reservierungen, die automatisch IP address Ihrem verdrahtet zuwiesen und drahtlose Apparate, die an Ihren Fräser anschließen.", //_LAN_DESC
	"DHCP-Servereinstellung", //_dhcp_server_setting
	"DHCP IP Anfang", //_dhcp_start_ip
	"DHCP IP Ende", //_dhcp_end_ip
	"Andere Einstellung", //_other_setting
	"802.1d Spanning Tree", //_8021d_spanning_tree
	"LLTD", //_lltd
	"IGMP-Stellvertreter", //_igmp_proxy
	"PPPOE-Relais", //_pppoe_relay
	"DNS-Stellvertreter", //_dns_proxy
	"DHCP-Reservierung hinzufügen", //_add_dhcp_reservation
	"MAC-Adresse des Rechners kopieren", //_copy_pc_mac
	"Koppieren", //_copy
	"DHCP-Reservierungen Bereit-Gruppe", //_dhcp_reservation_ready_group
	"DHCP-Reservierung Redigieren", //_edit_dhcp_reservation
	"Alle löschen", //_delete_all
	"Auswahl löschen", //_delete_selected
	"Start-PIN", //_config_via_pin
	"Druckknopf Anstellen", //_config_via_pbc
	"Application Level Gateway (ALG) Konfiguration", //_alg_config_l
	"ALG configuration allows users to disable some application service.", //_ALG_DESC
	"Beschreibung", //_description
	"E-mail wird empfangen", //_email_receiving
	"Post Office Protocol - Version 3 (POP3)", //_pop3_l
	"SMTP (Simple Mail Transfer Protocol)", //_smtp_l
	"Media streamen", //_streaming_media
	"Echtzeit Übertragungsprotokoll (RTP)", //_rtp_l
	"Echtzeit Stream Protokoll (RTSP)", //_rtsp_1
	"Microsoft Medien Server Protokoll (WMP/MMS)", //_mms_l
	"Media-VoIP streamen", //_streaming_media_voip
	"Sitzungsaktivierungsprotokoll (SIP)", //_session_init_protocol_l
	"NetMeeting (H.323)", //_h323_l
	"Datenübertragung", //_file_transfer
	"File Transfer Protocol (FTP)", //_ftp_l
	"Trivialdatei Übertragungsprotokoll (TFTP)", //_tftp_l
	"Fernsteuerung", //_remote_control
	"Telnet", //_telnet
	"Sofortnachrichten", //_instant_messaging
	"MSN Messenger", //_msn_messenger
	"IPSec VPN", //_ipsec
	"Status abspeichern", //_save_status
	"DMZ-Einstellungen", //_dmz_settings
	"You may setup a De-militarized Zone(DMZ) to separate internal network and Internet.", //_DMZ_DESC
	"Access Control allows users to define the traffic type not-permitted to WAN port service.", //_AC_DESC
	"Add Port Range and Service Block Rule", //_add_port_block_rule
	"Richtlinie aktivieren", //_policy_enable
	"Richtlinienname", //_policy_name
	"Client IP Address", //_client_ip_addr
	"Regel festlegen", //_rule_define
	"Spezieller Service", //_special_service
	"Eingetragener Benutzer", //_user_define
	"TCP-Ports", //_tcp_ports
	"Ex: 21 oder 300-500", //_ex_21_or_3_500
	"UDP-Ports", //_udp_ports
	"Diense", //_service
	"Service-Block-Regel Redigieren", //_edit_port_block_rule
	"Services Block-Regel-Liste", //_port_block_rule
	"Alle Service-Block-Regel Addieren", //_add_ip_block_rule
	"Service-Block-Regel Redigieren", //_edit_ip_block_rule
	"Alle Service-Block-Regel-Liste", //_ip_block_rule_list
	"Web-URL Filter-Regel hinzufügen", //_add_weburl_rule
	"Netz URL-Filter-Regel Redigieren", //_edit_weburl_rule
	"URL-Filter-Liste", //_weburl_rule_list
	"E-mail wird verschickt", //_email_sending
	"Datenübertragung", //_file_transfer_l
	"Telnet Dienst", //_telnet_service
	"DNS Abfrage", //_dns_query
	"TCP Protokoll", //_tcp_protocol
	"UDP Protokoll", //_udp_protocol
	"WWW", //_www
	"IP Adresse Formatfehler.", //_err_ip_addr_format
	"IP-Masken-Fehler", //_err_ip_mask
	"Eingabeformatfehler", //_err_input_format
	"IP-Adressfehler", //_err_ip_addr
	"Einstellung Routing", //_static_routing_settings
	"Dieser Abschnitt erlaubt Ihnen, statische Wege manuell zu definieren und dem Gebrauch von dynamischer Wegewahl auf Ihrem Fräser zu ermöglichen oder zu sperren.", //_ROUTING_DESC
	"Statische Route hinzufügen", //_add_static_route
	"Ziel-IP-Adresse", //_dest_ip_addr
	"Bestimmung IP Netzmaske", //_dest_ip_mask
	"Körperlicher Hafen", //_physical_port
	"RIP aktivieren", //_enable_rip
	"RIP-Modus", //_rip_mode
	"Statische Weg-Liste", //_static_route_list
	"Verarbeitung läuft! Bitte warten...", //_processing_plz_wait
	"Neustart, Bitte warten.....", //_rebooting_plz_wait
	"L2TP-Gateway-IP-Adresse", //_L2TPgw
	"Erneut versuchen", //_retry
	"Überspringen", //_skip
	"Router prüft Internetverbindung, bitte warten.", //_chk_wanconn_msg_00
	"Setup-Assistent", //_tnw_01
	"Dieser Zauberer führt Sie durch einen schrittweisen Prozess, um Ihren Internetanschluss zu konfigurieren.", //_tnw_02
	"Prüfung des Internetanschlusses", //_tnw_03
	"Information", //_tnw_04
	"SSID", //_ssid
	"Authentifizierungstyp:", //_auth_type
	"Fertig stellen", //_finish
	"Konfigurieren Sie Ihre Internet-Verbindung", //_tnw_05
	"IP Automatisch Beschaffen (DHCP-Kunde)", //_tnw_dhcp
	"Verbesserte IP Adresse", //_tnw_static
	"PPPoE", //_tnw_pppoe
	"PPTP", //_tnw_pptp
	"L2TP", //_tnw_l2tp
	"Dynamische IP-Adresse einstellen", //_tnw_06
	"MAC", //_mac
	"MAC-Adresse klonen", //_tnw_clone
	"feste IP-Adresse einstellen", //_tnw_07
	"WAN IP-Adresse", //_wan_ipaddr
	"WAN Subnetz-Maske", //_wan_submask
	"WAN-Gateway-IP-Adresse", //_wan_gwaddr
	"DNS-Server-Adresse 1", //_dns_1
	"DNS-Server-Adresse 2", //_dns_2
	"%s Setup-Assistent: PPPoE", //_tnw_08
	"%s Setup-Assistent: PPTP", //_tnw_09
	"Meine IP", //_my_ip
	"Server-IP", //_server_ip
	"PPTP Konto", //_pptp_account
	"PPTP Passwort", //_pptp_password
	"PPTP Passwort wiederholen", //_pptp_password_re
	"%s Setup-Assistent: L2TP", //_tnw_10
	"L2TP Konto", //_l2tp_account
	"L2TP Passwort", //_l2tp_password
	"L2TP Passwort wiederholen", //_l2tp_password_re
	"Die Einstellungen werden gespeichert und aktiviert.", //_tnw_11
	"Bitte warten", //_tnw_12
	"Sekunden.", //_tnw_13
	"Den Kabelanschluss zwischen dem Internet-Hafen und dem Modem Bitte überprüfen.", //_tnw_14
	"Druck", //_print
	"Leerzeichen im Kennwort nicht zulässig. Versuchen Sie es noch einmal.", //_TAG00840
	"Autokonfiguration (SLAAC/DHCPv6)", //IPV6_TEXT171
	"Autokonfiguration (SLAAC/DHCPv6) + 6RD", //IPV6_TEXT172
	"Freigegeben", //_wps_shared
	"Öffnen", //_wps_open
	"Der Name der Regel '%s' ist doppelt.", //_webfilterrule_dup
	"WPS 2.4GHz", //_wps_24g
	"WPS 5GHz", //_wps_5g
	"Name (SSID)", //_name_ssid
	"Produkt Garantie-Ausrichtung", //_warranty
	"USB", //_usb
	"Filesharing- Server", //_samba_server
	"FTP Server", //_ftp_server
	"Druckserver", //_print_server
	"Verbundene Geräte", //_connected_devices
	"Gästenetzwerk", //_guest_network
	"Dieser Abschnitt erlaubt Ihnen, die drahtlosen Gastnetzeinstellungen zu gründen und zu konfigurieren.", //_guest_text1
	"Netzwerkbrücke:", //_network_bridge
	"Nur Internet-Zugang", //_inet_access_only
	"(Keine Sicherheit)", //_security_no
	"(Niedrige Sicherheit)", //_security_low
	"(Mittlere Sicherheit)", //_security_middle
	"(Hohe Sicherheit)", //_security_high
	"Kinderschutz", //_parental_control
	"Internet Verbindung", //_has_inet_connection
	"Internet getrennt", //_no_inet_connection
	"Gästenetzwerk ermöglicht", //_guest_network_enabled
	"Gästenetzwerk gesperrt", //_guest_network_disabled
	"USB-Geräte angeschlossen", //_usb_connected
	"Keine USB-Geräte angeschlossen", //_no_usb_connected
	"Haushalt Zugang", //_household_access
	"Einstellungen Bestätigen", //_confirm_settings
	"Verbindung Überprüfen", //_check_connection
	"Adresse", //_address
	"Auf Regel-Liste Zugreifen", //_ha_rule_list
	"Zugangs-Regel Addieren", //_add_ha_rule
	"Haushalts-Zugangs-Regel Redigieren", //_edit_ha_rule
	"Der 802.11 Modus kann nicht auf 802.11n Only geändert werden, so lange eine SSID mit WEP/WPA-TKIP-Sicherung vorliegt.", //_wlan_11n_not_support_wep_wpa_tkip
	"Radio Auf Zeitplan", //_lb_radio_on_sche
	"Sie können keine weiteren Regeln hinzufügen, da die Tabelle voll ist.", //_rule_full
	"WDS kann nicht aktiviert werden, da die aktuelle Sicherheit nicht unterstützt. ", //_wds_cant_enble
	"Die Kunden sollten freigeben und IP address oder das DUT zu erneuern sollte Neustart sein.", //_LAN_CHK_REBOOT_MSG
	"Bitte Geräte URL angeben.", //_specify_url
	"Das IP address „%s“ bereits verwendet.", //_ipaddr_used
	"Das MAC address „%s“ bereits verwendet.", //_macaddr_used
	"Nicht jede Regel löschen", //_lan_dr
	"Bitte mindestens eine Route zum Entfernen auswählen!!", //_adv_rtd
	"A-MPDU", //_lb_a_mpdu
	"AC750 Dual Band Wireless Router", //PRODUCT_DESC_810
	"AC750 Dual Band Wireless Router", //PRODUCT_DESC_817
	"Das IP address „%s“ bereits verwendet.", //_ipaddr_used
	"Das MAC address „%s“ bereits verwendet.", //_macaddr_used
	"Internet nicht hergestellt", //no_wan_up
	"AP-Modus", //dev_mode_ap
	"Repeater-Modus", //dev_mode_repeater
	"WISP-Modus", //dev_mode_wisp
	"AP Client", //ap_client
	"SSID erweitern", //extend_ssid
	"Wireless Client Liste", //wlan_client_list
	"Access Point Modus; bitte wählen Sie diesen Modus, um sowohl ein 2.4GHz (802.11b/g/n) als auch ein 5GHz (802.11a/n/ac) Wireless-Netzwerk zu erstellen. Um ein Wireless-Netzwerk zu Ihrem bestehenden Netzwerk hinzuzufügen, verbinden Sie bitte den %s über ein Netzwerkkabel mit dem LAN/Ethernet Port des %s und Ihrem Router/Netzwerk.", //desc_ap
	"Wählen Sie diesen Modus, um ein bestehendes Wireless-Netzwerk mit dem %s zu erweitern. ", //desc_repeater
	"Wireless Internet Service Provider; Wählen Sie diesen Modus, wenn Sie eine Verbindung zum Netzwerk eines Internetdienstanbieters für Internetzugang herstellen (z.B. Wireless-Service in einem Hotel) und erstellen Sie ein internes Netzwerk für Ihre Client-Geräte mit dem %s.", //desc_wisp
	"Wählen Sie eine Seite aus, zu der Sie eine Verbindung herstellen möchten, und klicken Sie auf Weiter.", //wiz_select_site
	"Klicken Sie auf Aktualisieren, um die Liste der verfügbaren Seiten zu aktualisieren.", //wiz_refresh_site
	"Keine Seite verfügbar.", //wiz_no_result
	"Bitte wählen Sie eine SSID aus oder klicken Sie auf Manuell.", //wiz_no_selected
	"Möchten Sie den Einrichtungsassistenten schließen?", //wiz_quit
	"Bereich %d - %d", //custom_range
	"Interneteinstellungen", //_internet_setting
	"Konfigurieren statische IPv6", //desc_static_ipv6
	"%s Pakete", //_s_packet
	"WPS blockiert", //_wps_lock
	"PPTP Passthrough", //pptp_passthrough
	"L2TP Passthrough", //l2tp_passthrough
	"Local Area Network (LAN) und DHCP Einstellungen konfigurieren", //desc_ap_lan
	"IP-Protokoll einholen", //attain_ip
	"Gerätestatus", //dev_stat
	"Im Zeitplankonfigurationsabschnitt werden Zeitplanregeln für das Wireless verwaltet.", //desc_ap_sch
	"" //MAX
);
var _Advanced_01=0;
var _Advanced_03=1;
var _Advanced_04=2;
var bwn_ict_dns=3;
var bwn_msg_Modes_dns=4;
var aa_EAC=5;
var new_bwn_mici_usb=6;
var _tkip_11n=7;
var bln_title_guest_use_shareport=8;
var IPV6_TEXT3=9;
var bwl_Mode_10=10;
var IPV6_TEXT148=11;
var _regenerate=12;
var TEXT048=13;
var te_EnEmN=14;
var usb3g_titile=15;
var usb3g_apn_name=16;
var usb3g_dial_num=17;
var usb3g_reconnect_mode=18;
var usb3g_max_idle_time=19;
var usb_device=20;
var usb3g_manual=21;
var usb3g_stat_titile=22;
var bln_title_usb=23;
var usb_wcn=24;
var bwn_intro_usb=25;
var usb_network=26;
var usb_3g=27;
var wwan_dial_num=28;
var bwn_wwanICT=29;
var help862=30;
var wwan_auth_label=31;
var wwan_auth_auto=32;
var IPPPPPAP_AUTH_ISSUE=33;
var wwan_auth_chap=34;
var wwan_auth_mschap=35;
var usb_network_help=36;
var usb_3g_help=37;
var usb_3g_help_support_help=38;
var usb_wcn_help=39;
var bwn_mici_usb=40;
var _info_netowrk=41;
var anet_multicast_enable=42;
var bwn_usb_time=43;
var bwn_bytes_usb=44;
var _wps_albert_1=45;
var _wps_albert_2=46;
var usb_config2=47;
var ac_alert_choose_dev=48;
var usb_config3=49;
var usb_config4=50;
var usb_config5=51;
var usb_config6=52;
var bwn_msg_usb=53;
var _country=54;
var _select_country=55;
var _select_ISP=56;
var country_1=57;
var country_2=58;
var country_3=59;
var country_4=60;
var country_5=61;
var country_6=62;
var country_7=63;
var _aa_bsecure_personals=64;
var country_9=65;
var country_10=66;
var country_11=67;
var country_12=68;
var country_13=69;
var country_14=70;
var country_15=71;
var S500=72;
var S496=73;
var sto_http_2=74;
var logs_LW39b_email=75;
var LV3=76;
var GW_WIRELESS_DEVICE_LINK_UP=77;
var LT248=78;
var GW_PPPOE_EVENT_DISCOVERY_ATTEMPT=79;
var GW_WLAN_RADIO_1_NAME=80;
var te_SMTPSv_Port=81;
var GW_WLAN_CHANGING_PHY_MODE_TO_11NG_ONLY_INVALID=82;
var S558=83;
var KRL8=84;
var LY30=85;
var GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=86;
var GW_WIFISC_DISABLED_AUTOMATICALLY=87;
var _off=88;
var GW_WLAN_RADIO_0_NAME=89;
var GW_PPPOE_EVENT_DISCOVERY_REQUEST_ERROR=90;
var GW_WAN_PPPOE_SESSION_NAME_CONFLICT=91;
var S525=92;
var YM174=93;
var KR136=94;
var GW_PPPOE_EVENT_DISCONNECT=95;
var af_EFT_0=96;
var LY34=97;
var GW_WIRELESS_SHUT_DOWN=98;
var GW_WIRELESS_RESTART=99;
var S528=100;
var GW_PORT_FORWARD_TCP_PACKET_ALLOC_FAILURE=101;
var guestzone_Intro_1=102;
var GW_NAT_VIRTUAL_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=103;
var ta_ERM=104;
var te_SMTPSv_Port_alert=105;
var GW_WIRELESS_DEVICE_START_FAILED=106;
var GW_PORT_FORWARD_UDP_PACKET_ALLOC_FAILURE=107;
var GW_WIRELESS_DEVICE_DISCONNECT_ALL=108;
var GW_PPPOE_EVENT_OFFER_REQUEST=109;
var GW_ROUTES_ROUTERS_IP_ADDRESS_INVALID=110;
var GW_PORT_TRIGGER_UDP_PACKET_ALLOC_FAILURE=111;
var GW_WLAN_SETTING_SSID_SECURITY_TO_WEP_INVALID=112;
var GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT=113;
var GW_WLAN_STATION_TIMEOUT=114;
var GW_NAT_VIRTUAL_SERVER_IP_ADDRESS_CAN_NOT_MATCH_ROUTER=115;
var GW_NAT_VIRTUAL_SERVER_PROTO_CONFLICT_INVALID=116;
var LY28=117;
var GW_PPPOE_EVENT_CONNECT=118;
var GW_NAT_TRIGGER_PORT=119;
var tc_opmode=120;
var wwz_auto_assign_key3=121;
var LY292=122;
var LY293=123;
var bws_msg_WEP_4=124;
var GW_ROUTES_ON_LINK_DATALINK_CHECK_INVALID=125;
var wwa_dnsset=126;
var wireless_gu=127;
var add_gu_wps=128;
var wwl_band=129;
var _band=130;
var wwa_5G_nname=131;
var _guestzone=132;
var guestzone_title_1=133;
var _graph_auth=134;
var guestzone_inclw=135;
var guest=136;
var lower_wnt=137;
var equal_wnt=138;
var _lowest=139;
var ssid_lst=140;
var mult_ssid=141;
var add_ed_ssid=142;
var help75a=143;
var wpin_filter=144;
var tps_raw1=145;
var up_tz_52=146;
var _r_alert_new1=147;
var te_EmSt=148;
var IPNAT_BLOCKED_EGRESS=149;
var bws_WSMode=150;
var anet_wan_ping_1=151;
var help65=152;
var ta_upnp=153;
var bwl_TxR=154;
var GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED=155;
var tsc_pingt_msg106=156;
var tsc_AllDay=157;
var gw_gm_53=158;
var GW_WAN_RATE_ESTIMATOR_RESOURCE_ERROR=159;
var DHCP_CLIENT_LOST_LEASE=160;
var _aa_wiz_s3_msg=161;
var bwsAT_=162;
var hhtt_intro=163;
var gw_gm_20=164;
var help388=165;
var tt_StDT=166;
var psOffline=167;
var _status=168;
var up_ae_wic_3=169;
var sl_WtV=170;
var WIFISC_AP_PROXY_PROCESS_START=171;
var wprn_nopr2=172;
var help352=173;
var wwz_wwl_wnn=174;
var _ipaddr=175;
var GW_WLS_SCHEDULE_START=176;
var help820=177;
var help326=178;
var up_tz_54=179;
var help773=180;
var am_MACFILT=181;
var aa_alert_7_new1=182;
var help302=183;
var aa_intro=184;
var help348=185;
var haf_dmz_30=186;
var sl_Infrml=187;
var _wireless=188;
var bws_RIPA=189;
var KR108=190;
var help83=191;
var hhase_intro=192;
var RUNTIME_CONFIG_MAGIC_NUM_ERROR=193;
var _Sat=194;
var awf_title_WSFR=195;
var help18_a=196;
var dlink_wf_op_1=197;
var gw_gm_18=198;
var gw_gm_7=199;
var USB_LOG_STORAGE_TYPE=200;
var help346=201;
var up_rb_5=202;
var _WEP=203;
var IPMSCHAP_AUTH_FAIL_AND_NO_RETRY=204;
var gw_gm_82=205;
var bw_sap=206;
var bwn_msg_SWM=207;
var li_alert_2=208;
var help120=209;
var IGMP_HOST_LOW_RESOURCES=210;
var wwl_s4_intro_z3=211;
var help78=212;
var help339=213;
var IPv6_Simple_Security_enable=214;
var help51=215;
var GW_WAN_LAN_ADDRESS_CONFLICT_PPP=216;
var ss_Errors=217;
var help899=218;
var li_alert_4=219;
var haf_dmz_40=220;
var hhts_edit=221;
var wwl_wnn=222;
var WEB_FILTER_LOG_URL_ACCESSED_MAC=223;
var aw_WE=224;
var help201a=225;
var _bsecure_activate_trial=226;
var help896=227;
var help815=228;
var _netmask=229;
var _please_wait=230;
var help12=231;
var am_intro_1=232;
var IPPPPLCP_SET_LOCAL_AUTH=233;
var gw_gm_11=234;
var _dontsavesettings=235;
var wwl_s4_intro_za1=236;
var _308=237;
var aa_AT_1=238;
var IPL2TP_TUNNEL_ABORTING=239;
var help330=240;
var wwa_msg_l2tp=241;
var tt_time_5=242;
var help6=243;
var _time=244;
var at_xDSL=245;
var wprn_intro4=246;
var help296=247;
var _LAN=248;
var gw_gm_60=249;
var _aa_wiz_s4_msg=250;
var wwl_64bits=251;
var IPFAT_DISK_FULL=252;
var help341=253;
var aa_sched_conf_2=254;
var IPL2TP_SESSION_CONNECTING=255;
var NET_RTC_SYNCHRONIZATION_FAILED=256;
var tf_AutoCh=257;
var wprn_iderr2=258;
var help319=259;
var af_intro_2=260;
var help800=261;
var sd_title_Dev_Info=262;
var GW_INET_ACCESS_DROP_PORT_FILTER=263;
var _connow=264;
var IPSIPALG_REJECTED_PACKET=265;
var IPNAT_TCP_UNABLE_TO_MODIFY_OPTIONS=266;
var tt_SelNTPSrv=267;
var help812=268;
var _user=269;
var up_tz_59=270;
var SPECIAL_APP=271;
var wwl_NONE=272;
var GW_WAN_SERVICES_STARTED=273;
var fb_FbWbAc=274;
var help275=275;
var wprn_nopr=276;
var tt_TimeZ=277;
var wprn_tt=278;
var help841=279;
var aa_sched_new=280;
var tt_time_14=281;
var gw_vs_1=282;
var tsl_SLSt=283;
var IPH323ALG_REJECTED_PACKET=284;
var aa_wiz_s1_msg4=285;
var help336=286;
var ta_sn=287;
var help780=288;
var _interface=289;
var WEB_FILTER_LOG_URL_BLOCKED=290;
var vs_http_port=291;
var haf_intro_1=292;
var up_tz_07=293;
var aw_intro=294;
var wwa_gw=295;
var _sentinel_serv=296;
var wwa_msg_sipa=297;
var IPNAT_TCP_UNABLE_TO_HANDLE_HEADER=298;
var hhav_ip=299;
var haf_dmz_50=300;
var GW_INET_ACCESS_POLICY_END_MAC=301;
var tsc_intro_Sch=302;
var GW_WLAN_ACCESS_DENIED=303;
var _262=304;
var help79=305;
var GW_BIGPOND_CONFIG=306;
var aw_TP_0=307;
var _sdi_s3=308;
var tsc_pingr=309;
var tsc_pingt_v6=310;
var _WPApersonal=311;
var _email=312;
var PPPOE_EVENT_DISCOVERY_REQUEST=313;
var _firewall=314;
var wwa_wanmode_sipa=315;
var _syscheck=316;
var help784=317;
var UNKNOWN=318;
var help_upnp_1=319;
var gw_gm_61=320;
var _optional=321;
var help181=322;
var help569=323;
var anet_intro=324;
var _authword=325;
var IPNAT_TCP_BLOCKED_EGRESS_NOT_SYN=326;
var ta_GWN=327;
var wprn_tt3=328;
var help293=329;
var help265_2=330;
var IPNAT_UNABLE_TO_CREATE_CONNECTION=331;
var help270=332;
var aw_title_2=333;
var _firewalls=334;
var LW67=335;
var PPPOE_EVENT_UP=336;
var _protocol=337;
var help372=338;
var up_tz_32=339;
var at_kbps=340;
var at_Cable=341;
var anet_wp_1=342;
var help17=343;
var ta_intro_Adm2=344;
var tool_admin_check=345;
var IPPPPIPCP_PPP_LINK_UP=346;
var _stop=347;
var GW_SYSLOG_STATUS=348;
var bd_title_DHCPSSt=349;
var help827=350;
var tf_FWCheckInf=351;
var tf_FWInf=352;
var hhai_ipr=353;
var hhaw_1=354;
var help34=355;
var _network_usb_auto=356;
var help309=357;
var aa_alert_15=358;
var _savesettings=359;
var help193=360;
var help14_p=361;
var gw_gm_32=362;
var IPNAT_TCP_BLOCKED_INGRESS_SYN=363;
var anet_msg_wan_ping=364;
var ai_intro_2=365;
var help285=366;
var ss_LANStats=367;
var ta_alert_4=368;
var _clone=369;
var gw_gm_14=370;
var PPTP_ALG_GRE_UNABLE_TO_HANDLE_HEADER=371;
var _aa_block_some=372;
var help819_3=373;
var tt_time_24=374;
var help873=375;
var ss_Collisions=376;
var help863=377;
var help397=378;
var av_title_VSL=379;
var help636=380;
var tf_ENFA=381;
var help13=382;
var wwa_title_s3=383;
var ES_wwa_title_s1=384;
var GW_WAN_RATE_ESTIMATOR_CONVERGENCE_ERROR=385;
var wwa_wanmode_bigpond=386;
var help254=387;
var haf_dmz_70=388;
var GW_SCHED_ATTACH_FAILED=389;
var _badssid=390;
var RUNTIME_CONFIG_STORING_CONFIG_IN_NVRAM=391;
var FW_UPDATE_AVAILABLE=392;
var help891=393;
var help777=394;
var help393=395;
var bwn_ict=396;
var tt_Jun=397;
var IPL2TP_TUNNEL_CONNECTED=398;
var gw_gm_9=399;
var gw_gm_2=400;
var wwl_wl_wiz=401;
var network_dhcp_range=402;
var wprn_intro6=403;
var GW_BIGPOND_FAIL=404;
var af_EFT_1=405;
var _use_unicasting=406;
var _networkstate=407;
var tt_Year=408;
var IPASYNCFILEUSB_MOUNT_FAILED=409;
var af_UEFT=410;
var help356=411;
var help381=412;
var _inboundfilter=413;
var _aa_apply_port_filter=414;
var aa_FPR_c7=415;
var gw_gm_27=416;
var BIGPOND_NOT_PROPERLY_CFGD=417;
var help335=418;
var up_tz_58=419;
var _never=420;
var help801=421;
var tsc_pingt_msg105=422;
var li_WJS=423;
var te_ToEm=424;
var tt_time_1=425;
var help787=426;
var IPV6_TEXT65_v6=427;
var GW_EMAIL_SUBJ=428;
var IPPORTTRIGGERALG_UDP_PACKET_ALLOC_FAILURE=429;
var bi_wiz=430;
var _Out=431;
var hhpt_app=432;
var _dhcpconn=433;
var bln_title_Rtrset=434;
var _ps=435;
var _1044=436;
var wwl_text_best=437;
var wwa_pptp_svraddr=438;
var GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED=439;
var _LANComputers=440;
var hhte_intro=441;
var as_NM=442;
var wwa_setupwiz=443;
var help264=444;
var bw_WDUU_note=445;
var as_MMS=446;
var _srvname=447;
var help93=448;
var tt_Minute=449;
var sa_State=450;
var aw_dE=451;
var tsc_pingt_h=452;
var tsc_pingt_h_v6=453;
var ss_WStats=454;
var IPMSCHAP_AUTH_SEND_CHALLENGE=455;
var help889=456;
var as_H323=457;
var tool_admin_pfname=458;
var IPNAT_SESSION_ALREADY_EXISTS=459;
var wwa_title_set_bigpond=460;
var up_tz_16=461;
var GW_BIGPOND_STATUS=462;
var wwa_msg_set_bigpond=463;
var ai_alert_5=464;
var help848=465;
var gw_gm_41=466;
var _aa_pol_wiz=467;
var IP_FILTERS=468;
var gw_gm_50=469;
var wwa_intro_s3=470;
var IPSEC_ALG_ESP_ESTABLISH_ALREADY_PENDING=471;
var help59=472;
var wps_reboot_need=473;
var at_DF=474;
var help265_7=475;
var tt_alert_dstchkmonth=476;
var up_tz_23=477;
var _advanced=478;
var STATIC_IP_ADDRESS=479;
var wwl_title_s3=480;
var hhsw_intro=481;
var ish_menu=482;
var up_tz_33=483;
var GW_FW_NOTIFY_FIRMWARE_ERROR=484;
var _bsecure_more_info=485;
var tf_CFWV=486;
var tt_week_2=487;
var help3=488;
var _creator=489;
var bln_title_DNSRly=490;
var GW_INET_ACCESS_DROP_PORT_FILTER_MAC=491;
var ish_glossary=492;
var wwl_s4_intro_z4=493;
var help118=494;
var gw_gm_66=495;
var help312dr2=496;
var tsc_24hrs=497;
var hhag_10=498;
var help261=499;
var as_TPrt=500;
var help28=501;
var tt_time_12=502;
var ss_reload=503;
var EGRESS=504;
var sps_fp=505;
var gw_gm_57=506;
var wwa_msg_dhcp=507;
var aa_wiz_s1_msg1=508;
var MUST_BE_LOGGED_IN_AS_ADMIN=509;
var up_tz_64=510;
var GW_WLS_SCHEDULE_STOP=511;
var IPWOLALG_REJECTED_PACKET=512;
var WCN_LOG_UPDATE=513;
var help80=514;
var help171=515;
var _Mon=516;
var up_tz_66=517;
var wwl_title_s4_2=518;
var help196=519;
var PPPOE_EVENT_DISCOVERY_REQUEST_ERROR=520;
var li_Log_In=521;
var af_gss=522;
var _defgw=523;
var YM185=524;
var add_wireless_device=525;
var help8=526;
var help258=527;
var PPPOE_EVENT_TERMINATED=528;
var up_rb_1=529;
var help25_b=530;
var sl_saveLog=531;
var sl_intro=532;
var _aa_wiz_s4_help=533;
var GW_WAN_CARRIER_LOST=534;
var bwn_bytes=535;
var help890_1=536;
var help779=537;
var _macaddr=538;
var help823_13=539;
var ta_ELM=540;
var sto_http_4=541;
var anet_multicast_enable_v4=542;
var GW_DYNDNS_UPDATE_NEXT=543;
var help866=544;
var sl_RStat=545;
var gw_gm_78=546;
var help90=547;
var PPTP_EVENT_TUNNEL_DOWN=548;
var bwn_SWM=549;
var IPWEBFILTER_REJECTED_PACKET=550;
var GW_UPGRADE_FAILED=551;
var ag_intro=552;
var ta_intro_Adm=553;
var bwn_L2TPSIPA=554;
var GW_INET_ACCESS_UNRESTRICTED=555;
var up_tz_11=556;
var _disabled=557;
var GW_LOG_EMAIL_ON_LOG_FULL=558;
var tt_time_8=559;
var help43=560;
var ddns_connecting=561;
var _enable=562;
var help272=563;
var tt_Apr=564;
var tt_alert_invlddt=565;
var bwl_MS=566;
var tool_admin_portconflict=567;
var gw_SelVS=568;
var bwn_RM_0=569;
var hhai_edit=570;
var te_FromEm=571;
var wt_p_1=572;
var NET_RTC_REQUEST_TIME=573;
var help48=574;
var N_A=575;
var help279=576;
var tt_week_6=577;
var gw_gm_48=578;
var bwl_VS_1=579;
var help882=580;
var up_tz_41=581;
var RUNTIME_CONFIG_LOADED_CONFIG_FROM_NVRAM=582;
var li_alert_1=583;
var help307=584;
var help273=585;
var help194=586;
var up_rb_4=587;
var NEWER_FW_VERSION=588;
var bwn_PPTPICT=589;
var GW_UPGRADE_SUCCEEDED=590;
var bwl_AS=591;
var help96=592;
var _wchannel=593;
var wwz_manual_key=594;
var ap_intro_cont=595;
var tsl_EnLog=596;
var _L2TP=597;
var bd_DIPAR=598;
var _stats=599;
var wwl_s4_intro_za2=600;
var IPL2TP_SESSION_DOWN=601;
var bwn_DIAICT=602;
var help338=603;
var help859=604;
var _add=605;
var _acccon=606;
var tsc_pingt_msg4=607;
var ddns_disconnect=608;
var _verifypw=609;
var am_intro_2=610;
var _aa_pol_add=611;
var gw_gm_59=612;
var help11=613;
var _system=614;
var help261a=615;
var up_tz_02=616;
var hhtsc_pingt_intro=617;
var help5=618;
var help767s=619;
var gw_gm_45=620;
var wwa_wanmode_pppoe=621;
var GW_ROUTES_GATEWAY_SUBNET_SAME=622;
var haf_dmz_60=623;
var te_intro_Em=624;
var wwl_text_none=625;
var help895=626;
var GW_WAN_RECONNECT_ON_ACTIVE=627;
var aa_Machine=628;
var GW_WLS_SCHEDULE_INIT=629;
var _Wed=630;
var tt_time_20=631;
var aa_FPR_c3=632;
var help68=633;
var help150=634;
var te_Acct=635;
var IPSMTPCLIENT_MSG_SENT=636;
var gw_gm_38=637;
var help384=638;
var tt_time_2=639;
var at_AUS=640;
var hhts_del=641;
var help818=642;
var help886=643;
var _aa_wiz_s2_msg=644;
var help52=645;
var wps_KR46=646;
var wwz_wwl_intro_s3_1=647;
var gw_gm_19=648;
var td_intro_DDNS=649;
var up_tz_53=650;
var help845=651;
var wt_p_3=652;
var up_tz_51=653;
var wprn_s3d=654;
var IPPPPCHAP_AUTH_FAIL=655;
var gw_gm_52=656;
var IPNAT_TCP_BAD_FLAGS=657;
var _name=658;
var help66=659;
var IPNAT_UDP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=660;
var IPFTPALG_REJECTED_PACKET=661;
var fb_p_1=662;
var _contype=663;
var help829=664;
var _specappsr=665;
var help353=666;
var gw_gm_23=667;
var help325=668;
var bwn_RM=669;
var sl_LogOps=670;
var help772=671;
var _aa_method=672;
var sl_LogDet=673;
var help788=674;
var _continue=675;
var help804=676;
var _devinfo=677;
var _yes=678;
var help699=679;
var up_tz_62=680;
var help192=681;
var DHCP_PD_ENABLE=682;
var gw_gm_31=683;
var help271=684;
var help33=685;
var IPNAT_TCP_BLOCKED_INGRESS_BAD_ACK=686;
var htsc_pingt_p=687;
var tf_CKN=688;
var wprn_cps=689;
var up_tz_45=690;
var help84=691;
var GW_FW_NOTIFY_FIRMWARE_AVAIL=692;
var ss_RXPD=693;
var WEB_FILTER_LOG_URL_BLOCKED_MAC=694;
var IPPORTTRIGGERALG_TCP_PACKET_ALLOC_FAILURE=695;
var wwa_note_hostname=696;
var ai_Action=697;
var RUNTIME_CONFIG_RESET_CONFIG_TO_FACTORY_DEFAULTS=698;
var sps_nopr=699;
var gw_hours=700;
var _Fri=701;
var tps_lpd=702;
var tf_FWUg=703;
var anet_wp_0=704;
var gw_gm_4=705;
var help373=706;
var tt_dsoffs=707;
var wwz_auto_assign_key=708;
var gw_gm_15=709;
var wwl_s3_note_1=710;
var hhts_save=711;
var at_Auto=712;
var tsc_pingt_msg100=713;
var IPPPPIPCP_PPP_LINK_DOWN=714;
var aa_AT=715;
var gw_gm_71=716;
var aa_wiz_s1_msg3=717;
var BIGPOND_FAILED=718;
var help898=719;
var bwn_PPTPSIPA=720;
var _routing=721;
var hham_intro=722;
var WIFISC_IR_REGISTRATION_FAIL_3=723;
var ai_intro_1=724;
var wwa_title_s2=725;
var up_tz_69=726;
var IPMSCHAP_AUTH_RESULT=727;
var tss_intro2=728;
var help354=729;
var up_tz_19=730;
var ta_alert_5=731;
var bd_DAB=732;
var _WPAenterprise=733;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL_MAC=734;
var sps_pr=735;
var up_tz_34=736;
var _psk=737;
var _dyndns=738;
var _deny=739;
var IPNAT_TCP_BLOCKED_INGRESS_UNEXP_FLAGS=740;
var help276=741;
var _to=742;
var aa_AT_0=743;
var tt_Dec=744;
var GW_INET_ACCESS_POLICY_START_OTHERS=745;
var up_tz_75=746;
var up_tz_72=747;
var tsc_pingt_msg11=748;
var up_ae_de_1=749;
var help781=750;
var help161_2=751;
var tt_time_19=752;
var am_intro=753;
var help811=754;
var aw_TP_1=755;
var up_tz_24=756;
var IPMSCHAP_AUTH_SENT=757;
var sw_intro=758;
var tps_lpd1=759;
var help257=760;
var _upgintro=761;
var help819_8=762;
var bws_secs=763;
var IPNAT_ICMP_BLOCKED_EGRESS_PACKET=764;
var PORT_FORWARDING=765;
var bwn_Mode_DHCP=766;
var tt_Hour=767;
var help290a=768;
var BIGPOND_LOGGING_OUT=769;
var hhan_mc=770;
var _dns1=771;
var _dns1_v6=772;
var _tools=773;
var _sdi_s2=774;
var sps_usbport=775;
var GW_SCHED_ALLOC_FAILED=776;
var help179=777;
var help262=778;
var _allow=779;
var help798=780;
var DHCP_CLIENT_GOT_LEASE=781;
var anet_wan_phyrate=782;
var _note=783;
var aa_FPR_c6=784;
var help69=785;
var bd_DLT=786;
var ai_title_IFRL=787;
var GW_LAN_INTERFACE_UP=788;
var _logs=789;
var am_FM_2=790;
var GW_LOG_EMAIL_ON_USER_REQUEST=791;
var help21=792;
var bwl_Mode=793;
var bwn_AM=794;
var bwn_BPS=795;
var _ispinfo=796;
var _rate=797;
var up_tz_06=798;
var _success=799;
var _bsecure_parental_serv=800;
var wwa_set_l2tp_title=801;
var help342=802;
var help265=803;
var GW_SMTP_EMAIL_RESOLVED_DNS=804;
var tsc_pingt_msg102=805;
var bws_RSP=806;
var PPPOE_EVENT_CONNECT=807;
var tt_auto=808;
var PPTP_EVENT_LOW_RESOURCES_TO_QUEUE=809;
var IPL2TP_TUNNEL_UNEXPECTED_MESSAGE=810;
var gw_gm_34=811;
var tt_week_5=812;
var wwl_intro_end=813;
var aa_Policy_Table=814;
var tt_TimeConf=815;
var _none=816;
var _aa_wiz_s3_title=817;
var help392=818;
var GW_LOG_EMAIL_ON_SCHEDULE=819;
var wwa_intro_s2=820;
var _PPTPgw=821;
var WEB_FILTER_LOG_URL_ACCESSED=822;
var IPMMSALG_REJECTED_PACKET=823;
var _wirelesst=824;
var int_intro=825;
var GW_LAN_ACCESS_DENIED=826;
var gw_gm_26=827;
var PPTP_ALG_GRE_BLOCKED_INGRESS=828;
var up_tz_30=829;
var gw_gm_49=830;
var _sched=831;
var IPFAT_MOUNT_FAILED=832;
var gw_gm_75=833;
var help883=834;
var ta_alert_6=835;
var GW_INET_ACCESS_POLICY_START_IP=836;
var help841a=837;
var tt_time_23=838;
var ag_title_4=839;
var gw_gm_68=840;
var IPNAT_TCP_BLOCKED_EGRESS_UNEXP_FLAGS=841;
var help260=842;
var help819_4=843;
var help357=844;
var _TCP=845;
var IPMSCHAP_CHALLENGE_RECVD=846;
var anet_msg_upnp=847;
var help776=848;
var KR49=849;
var help32=850;
var gw_gm_3=851;
var help823=852;
var _L2TPip=853;
var _reboot=854;
var wps_p3_1=855;
var wprn_intro5=856;
var _bsecure_security_serv=857;
var tsc_pingt_msg8=858;
var gw_gm_56=859;
var tf_intro_FWU=860;
var up_tz_57=861;
var GW_FW_NOTIFY_RESOLVED_DNS=862;
var af_EFT_2=863;
var up_tz_00=864;
var hhts_intro=865;
var _auth=866;
var IPL2TP_TUNNEL_DISCONNECTING=867;
var NET_RTC_SYNCHRONIZATION_FAILED_AFTER_RETRIES=868;
var sd_FWV=869;
var tsc_SchRuLs=870;
var KR58_ww=871;
var YM98=872;
var ta_SavConf=873;
var wwa_sdns=874;
var help876=875;
var help380=876;
var _netfilt=877;
var gw_days=878;
var li_Login=879;
var WAN_ALREADY_CONNECTED=880;
var bws_WPAM_3=881;
var GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS=882;
var GW_DYNDNS_PASSWORD_INVALID=883;
var tool_admin_vsname=884;
var up_tz_50=885;
var static_PPPoE=886;
var tsc_StrTime=887;
var tsc_pingt_msg104=888;
var wprn_iderr=889;
var wps_KR42=890;
var td_Timeout=891;
var _aa_apply_web_filter=892;
var resetUnconfiged=893;
var GAMING=894;
var tt_time_9=895;
var IPNAT_BLOCKED_INGRESS=896;
var GW_WAN_INTERFACE_UP=897;
var _ripaddr=898;
var sa_TimeOut=899;
var IPNAT_TCP_BLOCKED_EGRESS_BAD_SEQ=900;
var GW_LAN_INTERFACE_DOWN=901;
var help778=902;
var sps_qname=903;
var _seconds=904;
var GW_LOGS_CLEARED=905;
var sl_Warning=906;
var aa_MAC=907;
var wps_KR51=908;
var help274=909;
var aw_sgi_h1=910;
var IPSTACK_REJECTED_SOURCE_ROUTED_PACKET=911;
var wwa_pdns=912;
var help834=913;
var _Sun=914;
var sto_no_dev=915;
var wwz_auto_assign_key2=916;
var bwl_NSS=917;
var up_tz_15=918;
var help880=919;
var IPL2TP_TUNNEL_CONNECTING=920;
var bwn_mici_guest_use_shareport=921;
var NET_RTC_SYNCHRONIZED=922;
var up_tz_10=923;
var _on=924;
var NOT_LOGGED_IN_PLEASE_REFRESH=925;
var IPSEC_ALG_ESP_BLOCKED_INGRESS=926;
var ub_continue=927;
var td_UNK=928;
var IPPMVM_MOUNT_FAILED=929;
var gw_gm_42=930;
var _1066=931;
var tsc_AllWk=932;
var _virtserv=933;
var help2=934;
var help869=935;
var IPPPPLCP_SET_LOCAL_OPTIONS=936;
var ts_rd=937;
var IPSEC_ALG_REJECTED_PACKET=938;
var tsc_pingt_msg3=939;
var GW_WIRELESS_DEVICE_DISCONNECTED=940;
var sd_WRadio=941;
var ALLOWED_WEB_SITES=942;
var gw_sa_1=943;
var _UDP=944;
var help166=945;
var help117=946;
var bwn_L2TPICT=947;
var help795=948;
var _no=949;
var up_tz_63=950;
var tf_FWF1=951;
var up_tz_65=952;
var _priority=953;
var WAN_ALREADY_DISCONNECTED=954;
var up_jt_1=955;
var GW_INET_ACCESS_INITIAL_OTHERS=956;
var hhai_ip=957;
var as_intro_SA=958;
var tsc_pingt_mesg=959;
var up_tz_44=960;
var help27=961;
var as_IPSec=962;
var _admin=963;
var gw_gm_65=964;
var tf_intro_FWChB=965;
var BLOCKED=966;
var wwa_msg_bigpond=967;
var help857=968;
var help819_5=969;
var aw_TP_2=970;
var help385=971;
var _setupdone=972;
var li_intro=973;
var IPSMTPCLIENT_MSG_FAILED=974;
var bwz_note_ConWz=975;
var gw_gm_64=976;
var help268=977;
var NONE_BLOCKED=978;
var tt_May=979;
var bwn_BPICT=980;
var tt_time_15=981;
var _Tue=982;
var ss_clear_stats=983;
var help197=984;
var ai_intro_3=985;
var GW_WAN_DISCONNECT_ON_INACTIVE=986;
var DHCP_CLIENT_RELEASED_LEASE=987;
var wwa_set_sipa_title=988;
var up_tz_71=989;
var hhaf_alg=990;
var help843=991;
var wprn_tt11=992;
var _tstats=993;
var IPPPPLCP_SET_REMOTE_OPTIONS=994;
var tf_COLF=995;
var up_tz_28=996;
var tt_Mar=997;
var _aa_allow_all=998;
var wwa_wanmode_l2tp=999;
var _dmzh=1000;
var GW_TIME_RESOLVED_DNS=1001;
var bws_EAPx=1002;
var aa_PolName=1003;
var wwa_set_sipa_msg=1004;
var _aa_wiz_s2_title=1005;
var PPTP_EVENT_TUNNEL_CONNECTED=1006;
var USB_LOG_STORAGE_NOT_FOUND=1007;
var GW_INIT_DONE=1008;
var carriertype_ct_0=1009;
var help305=1010;
var tps_raw=1011;
var av_PubP=1012;
var help374=1013;
var PPTP_EVENT_TUNNEL_CLEAR_DOWN_REQUEST=1014;
var hhac_delete=1015;
var IPL2TP_SESSION_CLEAR_DOWN_REQUEST=1016;
var aa_ACR_c2=1017;
var help29=1018;
var up_tz_01=1019;
var _app=1020;
var bln_alert_1=1021;
var GW_WAN_RATE_ESTIMATOR_STARTED_ON_WAN=1022;
var sl_FWandSec=1023;
var hhan_ping=1024;
var sa_NAT=1025;
var help828=1026;
var GW_SMTP_EMAIL_FAILED_DNS=1027;
var help810=1028;
var _WOL=1029;
var bwn_RM_1=1030;
var help819_1=1031;
var IPNAT_TCP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1032;
var up_tz_14=1033;
var gw_gm_51=1034;
var td_SvAd=1035;
var hhag_40=1036;
var help169=1037;
var help324=1038;
var htsc_intro=1039;
var KR4_ww=1040;
var help317=1041;
var anet_multicast=1042;
var anet_multicast_v4=1043;
var anet_multicast_v6=1044;
var _aa_wiz_s1_title=1045;
var IPL2TP_SHUTDOWN_COMPLETE=1046;
var help819_7=1047;
var help9=1048;
var help809=1049;
var GW_LAN_CARRIER_DETECTED=1050;
var sl_alert_1=1051;
var as_TPRange_b=1052;
var tt_week_1=1053;
var up_jt_3=1054;
var _clear=1055;
var PPPOE_EVENT_DISCONNECT=1056;
var WIFISC_IR_REGISTRATION_FAIL_2=1057;
var _sdi_staticip=1058;
var hhts_name=1059;
var WAN=1060;
var help824=1061;
var hham_add=1062;
var ss_WANStats=1063;
var GW_WAN_CONNECT_ON_ACTIVE=1064;
var aa_sched_conf_1=1065;
var GW_INET_ACCESS_POLICY_END_OTHERS=1066;
var bd_title_list=1067;
var _aa_logging=1068;
var IPNAT_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1069;
var _username=1070;
var gw_gm_67=1071;
var GW_TIME_FAILED_DNS=1072;
var wprn_tt1=1073;
var tt_time_22=1074;
var help256=1075;
var GW_INET_ACCESS_INITIAL_IP_FAIL=1076;
var _aa_details=1077;
var help36=1078;
var help817=1079;
var bwn_Mode_PPPoE=1080;
var _allowall=1081;
var awf_clearlist=1082;
var sc_intro_rb3=1083;
var help67=1084;
var gw_gm_37=1085;
var aa_AT_2=1086;
var wwa_title_s1=1087;
var tps_drname=1088;
var tt_CopyTime=1089;
var IPL2TP_SEQUENCING_ACTIVATED=1090;
var bd_Reserve=1091;
var IPMSNMESSENGERALG_REJECTED_PACKET=1092;
var help782=1093;
var gw_gm_16=1094;
var IPPORTFORWARDALG_UDP_PACKET_ALLOC_FAILURE=1095;
var wprn_mod=1096;
var help119=1097;
var gw_gm_46=1098;
var am_FM_3=1099;
var sps_lpd1=1100;
var tss_SysSt=1101;
var ta_ResConf=1102;
var WCN_LOG_SAVE=1103;
var as_FPrt=1104;
var help823_11=1105;
var tsc_EvDay=1106;
var ham_del=1107;
var _PPPoE=1108;
var wwa_intro_online1=1109;
var tt_dstend=1110;
var tsc_SchRu=1111;
var GW_AUTH_FAILED=1112;
var _scheds=1113;
var up_tz_56=1114;
var _dns2=1115;
var _dns2_v6=1116;
var tsc_pingt_msg2=1117;
var tps_apc1=1118;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL_WITH_PORT=1119;
var up_tz_48=1120;
var _password_admin=1121;
var bd_intro_=1122;
var help387=1123;
var GW_AUTH_SUCCEEDED=1124;
var IPPPPCHAP_AUTH_SENT=1125;
var _bsecure_parental_blurb=1126;
var _aa_wiz_s1_msg=1127;
var help807=1128;
var up_tz_61=1129;
var _L2TPgw=1130;
var IPMSCHAP_AUTH_FAIL=1131;
var help395=1132;
var help888=1133;
var gw_gm_29=1134;
var help95=1135;
var aw_BP=1136;
var GW_WAN_SERVICES_STOPPED=1137;
var gw_gm_79=1138;
var help850=1139;
var help4=1140;
var up_tz_18=1141;
var help168a=1142;
var PPTP_ALG_REJECTED_PACKET=1143;
var te_SMTPSv=1144;
var gw_gm_84=1145;
var IPL2TP_LOW_RESOURCES=1146;
var hhac_add=1147;
var anet_wp_auto2=1148;
var as_RTSP=1149;
var _authsecmodel=1150;
var bwn_MTU=1151;
var gw_gm_72=1152;
var _WAN=1153;
var anet_multicast_enhanced=1154;
var gw_gm_8=1155;
var _WPA=1156;
var help897=1157;
var IPNAT_TCP_BLOCKED_INGRESS_BAD_SEQ=1158;
var tsc_pingt_msg7=1159;
var tt_Jan=1160;
var gw_gm_5=1161;
var _adwwls=1162;
var tsc_pingt_msg101=1163;
var gw_gm_55=1164;
var anet_wan_ping=1165;
var GW_DHCP_SERVER_WINS_INCOMPATIBILITY_WARNING=1166;
var bws_RMAA=1167;
var aa_wiz_s1_msg2=1168;
var tt_time_7=1169;
var help822a=1170;
var gw_gm_1=1171;
var up_tz_37=1172;
var bws_SM=1173;
var up_tz_68=1174;
var wwl_s4_intro_za3=1175;
var _prev=1176;
var sto_http_1=1177;
var wprn_foo1=1178;
var help355=1179;
var aa_ACR_c6=1180;
var bws_2RSSS=1181;
var help391=1182;
var _PM=1183;
var help174=1184;
var PPPOE_EVENT_DISCOVERY_TIMEOUT=1185;
var WCN_LOG_NO_WSETTING=1186;
var psPaperError=1187;
var anet_wan_ping_2=1188;
var help878=1189;
var LOGGED=1190;
var bwn_RM_2=1191;
var bws_RSSs=1192;
var up_tz_43=1193;
var IPRTSPALG_REJECTED_PACKET=1194;
var GW_SCHEDULES_IN_USE_INVALID_s2=1195;
var help1=1196;
var gw_gm_73=1197;
var hhtsn_intro=1198;
var _ping=1199;
var at_UpSp=1200;
var aa_wiz_s1_msg6=1201;
var _PPTPip=1202;
var help185=1203;
var help799=1204;
var up_tz_17=1205;
var sd_intro=1206;
var tf_Upload=1207;
var tt_Second=1208;
var wps_lost=1209;
var help26=1210;
var up_tz_35=1211;
var bwn_intro_ICS=1212;
var bwn_intro_ICS_3G=1213;
var bwn_intro_ICS_v6=1214;
var help81=1215;
var help833=1216;
var ss_Sent=1217;
var help378=1218;
var gw_gm_80=1219;
var _uploadgood=1220;
var KR38=1221;
var wprn_s3c=1222;
var haf_dmz_20=1223;
var ss_Received=1224;
var help263=1225;
var _bsecure_free_trial=1226;
var tf_FUNO=1227;
var aw_sgi=1228;
var help386=1229;
var help254_ict=1230;
var help254_ict_3G=1231;
var _aa_wiz_s5_msg1=1232;
var td_VPWK=1233;
var gw_gm_33=1234;
var gw_gm_0=1235;
var _macfilt=1236;
var TA16=1237;
var bd_DAB_note=1238;
var help796=1239;
var tf_really_FWF=1240;
var up_tz_05=1241;
var tt_time_16=1242;
var help861=1243;
var help19=1244;
var bwn_DWM=1245;
var _ICMP=1246;
var gw_gm_22=1247;
var help868=1248;
var IPV6_TEXT24=1249;
var tt_time_6=1250;
var _501_12=1251;
var hhac_en=1252;
var int_LWlsWz=1253;
var at_STR=1254;
var tt_Aug=1255;
var am_FM_4=1256;
var aa_wiz_s1_msg5=1257;
var ACCESS_CONTROL=1258;
var GW_DYNDNS_HERROR=1259;
var sps_ports=1260;
var help851=1261;
var hhag_20=1262;
var aa_alert_7=1263;
var af_DI=1264;
var tf_ADS=1265;
var tsc_pingt=1266;
var sl_VLevs=1267;
var wwl_enc=1268;
var help151=1269;
var hhta_pt=1270;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL=1271;
var te_EnAuth=1272;
var WIFISC_AP_PROXY_PROCESS_CLOSE=1273;
var bd_CName=1274;
var help305rt=1275;
var li_alert_3=1276;
var GW_DYNDNS_UPDATE_TO=1277;
var tt_week_4=1278;
var tt_Day=1279;
var GW_LAN_CARRIER_LOST=1280;
var hhai_action=1281;
var help121=1282;
var wwa_msg_set_pppoe=1283;
var IPNAT_ICMP_BLOCKED_INGRESS_PACKET=1284;
var tf_intro_FWU2=1285;
var at_ESE=1286;
var _bsecure_security_blurb=1287;
var bd_DHCP=1288;
var help865=1289;
var wwl_s4_intro_z1=1290;
var help501=1291;
var help280=1292;
var help775=1293;
var _connect=1294;
var GW_BIGPOND_INIT=1295;
var _always=1296;
var _minutes=1297;
var as_IPR_b=1298;
var _aa_bsecure_employment=1299;
var GW_INET_ACCESS_DROP_BAD_PKT=1300;
var gw_gm_12=1301;
var gw_gm_25=1302;
var help846=1303;
var tt_alert_1only=1304;
var gw_gm_76=1305;
var GW_LOGS_VIEWED=1306;
var bws_msg_EAP=1307;
var WIFISC_IR_REGISTRATION_INPROGRESS=1308;
var hhsa_intro=1309;
var help856=1310;
var sa_Dir=1311;
var _bln_title_IGMPMemberships=1312;
var bwn_Mode_L2TP=1313;
var _Thu=1314;
var KR30=1315;
var help184=1316;
var _worksbest=1317;
var _unavailable=1318;
var IPFAT_INCOMPATIBLE_FILESYS=1319;
var IPNAT_TCP_BLOCKED_INGRESS_NOT_SYN=1320;
var up_tz_04=1321;
var sl_ApplySt=1322;
var IPPPPCHAP_CHALLENGE_RECVD=1323;
var help141=1324;
var bd_Revoke=1325;
var wprn_intro3=1326;
var _conuptime=1327;
var wprn_tt4=1328;
var help383=1329;
var tsc_pingt_msg6=1330;
var help821a=1331;
var PPPOE_EVENT_SESSION_OFFER_RECVD=1332;
var gw_gm_30=1333;
var bi_man=1334;
var help60=1335;
var ta_RAP=1336;
var bwn_Mode_BigPond=1337;
var wprn_cps2=1338;
var tt_dststart=1339;
var help164_1=1340;
var IPMSCHAP_AUTH_TIMEOUT=1341;
var sl_emailLog=1342;
var bwl_title_1=1343;
var bwn_BPP=1344;
var sl_reload=1345;
var wwl_title_s1=1346;
var IPDRIVE_MOUNT_FAILED=1347;
var int_ConWz=1348;
var sto_permi=1349;
var help329=1350;
var IPL2TP_TUNNEL_DISCONNECTED=1351;
var help830=1352;
var help294=1353;
var up_tz_21=1354;
var tf_LFWD=1355;
var GW_BIGPOND_SUCCESS=1356;
var _denyall=1357;
var at_AC=1358;
var bwl_VS=1359;
var help327=1360;
var wprn_s2a=1361;
var td_=1362;
var PPTP_EVENT_TUNNEL_WINDOW_TIMEOUT=1363;
var aw_TP=1364;
var bwn_SIAICT=1365;
var help57=1366;
var tt_dsen2=1367;
var _sdi_s5=1368;
var wprn_man=1369;
var tt_time_3=1370;
var up_tz_20=1371;
var RIP_LOW_RESOURCES=1372;
var help266=1373;
var CONNECTED=1374;
var help265_5=1375;
var tsc_Days=1376;
var up_tz_13=1377;
var sd_General=1378;
var hhan_upnp=1379;
var help35=1380;
var help18=1381;
var bwz_psw=1382;
var tt_DaT=1383;
var help190=1384;
var help819_2=1385;
var bwn_MIT=1386;
var hhai_name=1387;
var te__title_EmLog=1388;
var up_tz_47=1389;
var IPSMTPCLIENT_DIALOG_FAILED=1390;
var hham_del=1391;
var wwa_msg_ispnot=1392;
var help808=1393;
var PPTP_EVENT_TUNNEL_ESTABLISH_REQUEST=1394;
var help37=1395;
var WCN_LOG_REBOOT=1396;
var PPTP_EVENT_TUNNEL_CONNECT_FAIL=1397;
var bwl_CWM=1398;
var up_tz_12=1399;
var _cancel=1400;
var IPV6_ULA_TEXT02=1401;
var af_ED=1402;
var up_tz_38=1403;
var aw_DI=1404;
var up_tz_31=1405;
var hhai_delete=1406;
var av_intro_vs=1407;
var av_intro_if=1408;
var GW_WAN_RECONNECT_ALWAYS_ON=1409;
var wwl_WSP=1410;
var INGRESS=1411;
var RESTRICTED=1412;
var bwn_msg_DHCPDesc=1413;
var help390=1414;
var KR58=1415;
var help867=1416;
var GW_WAN_CONNECT_ALWAYS_ON=1417;
var IPRTSPALG_REJECTED_ODD_RTP_PACKET=1418;
var help60f=1419;
var gw_gm_10=1420;
var bwn_min=1421;
var tt_Month=1422;
var tf_CFWD=1423;
var _advnetwork=1424;
var bwn_PPPOEICT=1425;
var help389=1426;
var help844=1427;
var tt_time_17=1428;
var help284=1429;
var GW_WIRELESS_DEVICE_ASSOCIATED=1430;
var bws_2RMAA=1431;
var as_SIP=1432;
var help704=1433;
var WIFISC_IR_REGISTRATION_FAIL_1=1434;
var up_tz_25=1435;
var help55=1436;
var GW_WLAN_LINK_UP=1437;
var bln_EnDNSRelay=1438;
var ai_title_IFR=1439;
var _PPTP=1440;
var _both=1441;
var up_tz_40=1442;
var wprn_tt8=1443;
var tps_dsr=1444;
var at_Prot_1=1445;
var help875=1446;
var awsf_p=1447;
var wwl_s4_intro_z2=1448;
var wwa_set_l2tp_msg=1449;
var up_tz_42=1450;
var _error=1451;
var aa_FPR_c4=1452;
var tt_EnNTP=1453;
var network_dhcp_ip_in_server=1454;
var tf_msg_wired=1455;
var wwa_title_set_pppoe=1456;
var help10=1457;
var bwl_CWM_h2=1458;
var help884=1459;
var rb_Rebooting=1460;
var help819_6=1461;
var tt_time_10=1462;
var help199=1463;
var help259=1464;
var af_algconfig=1465;
var wwa_msg_pptp=1466;
var bws_2RIPA=1467;
var _aa_wiz_s4_title=1468;
var wwa_note_svcn=1469;
var help85=1470;
var GW_INET_ACCESS_DROP_PORT_FILTER_WITH_PORT=1471;
var sd_BPSt=1472;
var up_tz_49=1473;
var gw_gm_62=1474;
var BIGPOND_LOGGED_OUT=1475;
var tf_EmNew=1476;
var GW_INET_ACCESS_INITIAL_MAC_FAIL=1477;
var help303=1478;
var wwa_selectisp_not=1479;
var IPNAT_TCP_BLOCKED_EGRESS_BAD_ACK=1480;
var help94=1481;
var gw_gm_70=1482;
var IPNAT_ICMP_UNABLE_TO_HANDLE_HEADER=1483;
var _FTP=1484;
var _neft=1485;
var ta_A12n=1486;
var GW_BIGPOND_LOGOUT=1487;
var help46=1488;
var hhsl_intro=1489;
var help770=1490;
var wwa_msg_set_pptp=1491;
var GW_FW_NOTIFY_FAILED_DNS=1492;
var gw_gm_40=1493;
var bln_IGMP_title_h=1494;
var hhaw_11d=1495;
var up_jt_2=1496;
var GW_INET_ACCESS_POLICY_START_MAC=1497;
var wwa_msg_pppoe=1498;
var help323=1499;
var ta_intro1=1500;
var tt_week_3=1501;
var _dhcpsrv=1502;
var Dynamic_PPPoE=1503;
var help102=1504;
var GW_DHCP_SERVER_WINS_MODE_INVALID=1505;
var help107=1506;
var gw_gm_69=1507;
var aa_ACR_c5=1508;
var help345=1509;
var hhav_name=1510;
var av_PriP=1511;
var tsc_pingt_msg103=1512;
var help_upnp_2=1513;
var WAN_MODE_INCORRECT=1514;
var wwl_alert_pv5_2_5=1515;
var _aa_wiz_s5_title=1516;
var KR22_ww=1517;
var _aa_wiz_s7_help=1518;
var IPL2TP_SEQUENCING_DEACTIVATED=1519;
var tps_apc=1520;
var up_tz_09=1521;
var tt_Jul=1522;
var GW_WAN_INTERFACE_DOWN=1523;
var WCN_LOG_RESTORE=1524;
var gw_gm_17=1525;
var GW_INET_ACCESS_INITIAL_IP=1526;
var _wizquit=1527;
var tss_intro=1528;
var help318=1529;
var tsl_intro=1530;
var tt_time_4=1531;
var tt_time_21=1532;
var IPL2TP_SESSION_CONNECTED=1533;
var aw_FT=1534;
var _save=1535;
var at_NEst=1536;
var af_EFT_h0=1537;
var _firmware=1538;
var gw_gm_43=1539;
var wps_messgae1_1=1540;
var IPL2TP_SHUTDOWN_STARTED=1541;
var ss_TXPD=1542;
var up_tz_55=1543;
var wwa_intro_online2=1544;
var help50=1545;
var help70=1546;
var help188_wmm=1547;
var bd_title_SDC=1548;
var up_tz_60=1549;
var gw_gm_54=1550;
var help396=1551;
var GW_ADMIN_LOGOUT=1552;
var gw_gm_44=1553;
var ta_EUPNP=1554;
var igmp_e_h=1555;
var help806=1556;
var dlink_wf_op_0=1557;
var help49=1558;
var help367=1559;
var gw_gm_28=1560;
var help337=1561;
var ta_AdmSt=1562;
var _syslog=1563;
var up_tz_08=1564;
var help394=1565;
var _aa_wiz_s7_title=1566;
var tt_intro_Time=1567;
var GW_DYNDNS_SERROR=1568;
var IPV6_TEXT105=1569;
var sps_port=1570;
var help164_2=1571;
var help881=1572;
var _destip=1573;
var help840=1574;
var wwa_l2tp_svra=1575;
var tt_dsdates=1576;
var help34b=1577;
var tt_time_11=1578;
var td_EnDDNS=1579;
var help786=1580;
var bwn_UN=1581;
var aa_alert_8=1582;
var wprn_tt2=1583;
var IPPPPLCP_SET_REMOTE_AUTH=1584;
var IPL2TP_FATAL_TIMEOUT=1585;
var hhaf_ngss=1586;
var bln_title_NetSt=1587;
var av_traftype=1588;
var bwn_Mode_PPTP=1589;
var help140=1590;
var wprn_rppd=1591;
var hhsd_intro=1592;
var IPMSCHAP_AUTH_SUCCESS=1593;
var help63=1594;
var ES_cable_lost_desc=1595;
var ap_intro_sv=1596;
var _L2TPsubnet=1597;
var GW_LOG_EMAIL_BEFORE_REBOOT=1598;
var at_Any=1599;
var help288=1600;
var bws_SM_h1=1601;
var help177=1602;
var up_tz_46=1603;
var rb_wait=1604;
var bwl_NN=1605;
var IPL2TP_SESSION_CONNECT_FAIL=1606;
var gw_gm_21=1607;
var wwl_BEST=1608;
var _support=1609;
var aa_alert_14=1610;
var _cablestate=1611;
var help314=1612;
var wps_LW13=1613;
var sl_Critical=1614;
var sc_intro_sv=1615;
var SYSTEM_LOG_INACTIVE=1616;
var bwn_mici=1617;
var gw_mins=1618;
var help852=1619;
var _In=1620;
var help870=1621;
var gw_gm_74=1622;
var help797=1623;
var gw_gm_39=1624;
var wwl_alert_pv5_3_10=1625;
var help149=1626;
var hhpt_intro=1627;
var GW_WAN_CARRIER_DETECTED=1628;
var bwn_BPU=1629;
var help195=1630;
var help823_1=1631;
var _internetc=1632;
var tsc_pingt_msg5=1633;
var help189a=1634;
var _trigger=1635;
var help783=1636;
var ub_intro_2=1637;
var hhta_pw=1638;
var _aa_wiz_s8_title=1639;
var help173=1640;
var help771=1641;
var tsl_SLSIPA=1642;
var _aa_wiz_s7_msg=1643;
var tt_time_13=1644;
var up_tz_67=1645;
var help289a=1646;
var BIGPOND_LOGGED_IN=1647;
var haf_dmz_10=1648;
var help819=1649;
var wprn_s3b=1650;
var sps_tcpport=1651;
var dlink_wf_intro=1652;
var _websfilter=1653;
var sd_BPSN=1654;
var _password_user=1655;
var GW_INET_ACCESS_POLICY_END_IP=1656;
var bwn_msg_Modes=1657;
var up_gX_1=1658;
var _next=1659;
var _setup=1660;
var htsc_pingt_s=1661;
var EMAIL=1662;
var _mode=1663;
var tt_Feb=1664;
var sps_raw1=1665;
var GW_DYNDNS_SUCCESS=1666;
var IPPORTFORWARDALG_TCP_PACKET_ALLOC_FAILURE=1667;
var IGMP_ROUTER_LOW_RESOURCES=1668;
var bwl_CWM_h1=1669;
var up_tz_39=1670;
var help40=1671;
var _pf=1672;
var IPNAT_UDP_UNABLE_TO_HANDLE_HEADER=1673;
var GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS_WARNING=1674;
var GW_INET_ACCESS_INITIAL_MAC=1675;
var IPPPPCHAP_AUTH_SUCCESS=1676;
var help187=1677;
var _aa_block_all=1678;
var GW_WLAN_LINK_DOWN=1679;
var help379=1680;
var up_tz_70=1681;
var IPNAT_ICMP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1682;
var GW_SCHEDULES_IN_USE_INVALID_s1=1683;
var fb_p_2=1684;
var sps_ps=1685;
var help47=1686;
var wwa_title_s4=1687;
var tt_time_18=1688;
var help860=1689;
var GW_UPNP_IGD_PORTMAP_RELEASE=1690;
var wwa_intro_s4=1691;
var help267=1692;
var IPL2TP_SESSION_ABORTED=1693;
var help874=1694;
var tt_Sep=1695;
var IPSEC_ALG_ESP_UNABLE_TO_HANDLE_HEADER=1696;
var bws_GKUI=1697;
var help80b=1698;
var help168c=1699;
var BIGPOND_LOGGING_IN=1700;
var wwa_wanmode_pptp=1701;
var help58=1702;
var ddns_connected=1703;
var ub_Upload_Failed=1704;
var WIFISC_AP_PROXY_END_ON_MSG=1705;
var help278=1706;
var KR18=1707;
var hhts_def=1708;
var help255=1709;
var bws_2RSP=1710;
var help7=1711;
var bwl_VS_0=1712;
var af_TEFT=1713;
var help86=1714;
var sd_NNSSID=1715;
var wt_p_2=1716;
var _gateway=1717;
var tt_CurTime=1718;
var _AM=1719;
var DISCONNECTED=1720;
var gw_gm_47=1721;
var up_tz_22=1722;
var WIFISC_IR_REGISTRATION_SESSION_OVERLAP=1723;
var _pwsame_admin=1724;
var GW_DYNDNS_UPDATE_IP=1725;
var GW_DHCPSERVER_NEW_ASSIGNMENT=1726;
var as_WM=1727;
var up_tz_03=1728;
var KR43=1729;
var YM177=1730;
var help774=1731;
var hhac_edit=1732;
var up_tz_36=1733;
var _hostname=1734;
var GW_INET_ACCESS_INITIAL_FAIL=1735;
var GW_WEB_FILTER_INITIAL_FAIL=1736;
var te_OnFull=1737;
var wwl_title_s4=1738;
var help281=1739;
var gw_gm_77=1740;
var _clonemac=1741;
var hhss_intro=1742;
var at_MUS=1743;
var hhan_wans=1744;
var YM141=1745;
var help382=1746;
var tsc_hrmin=1747;
var tsc_hrmin1=1748;
var help82=1749;
var gw_gm_24=1750;
var gw_gm_13=1751;
var aw_RT=1752;
var help340=1753;
var sd_WLAN=1754;
var help864=1755;
var tf_intro_FWU1=1756;
var wprn_bados=1757;
var _metric=1758;
var INBOUND_FILTER=1759;
var IPNAT_UDP_BLOCKED_INGRESS=1760;
var help351=1761;
var wwz_manual_key2=1762;
var _PPTPsubnet=1763;
var help20=1764;
var gw_gm_6=1765;
var bws_WPAM=1766;
var wwl_GOOD=1767;
var gw_gm_36=1768;
var help894=1769;
var _subnet=1770;
var PPTP_EVENT_REMOTE_WINDOW_SIZE=1771;
var wps_KR35=1772;
var help329_rsv=1773;
var gw_gm_58=1774;
var GW_WAN_MODE_IS=1775;
var ns_intro_=1776;
var IPDNSRELAYALG_REJECTED_PACKET=1777;
var ss_intro=1778;
var KR112=1779;
var GW_WLAN_11A_CH_MID_BAND_WARN=1780;
var ip_mac_binding_desc=1781;
var LW50=1782;
var GW_NAT_CONFLICTING_CONNECTIONS_LOG=1783;
var KR111=1784;
var KR109=1785;
var GW_NAT_CONFLICTING_CONNECTIONS_WARNING=1786;
var GW_PURE_SETACCESSPOINTMODE=1787;
var GW_NAT_REJECTED_SPOOFED_PACKET=1788;
var KR110=1789;
var GW_ROUTES_ROUTE_GATEWAY_NOT_IN_SUBNET_WARNING=1790;
var KR107=1791;
var KR105=1792;
var IPSTACK_REJECTED_LAND_ATTACK=1793;
var LS321=1794;
var KR67=1795;
var YM71=1796;
var GW_FIREWALL_RANGE_DUPLICATED_INVALID=1797;
var LS422=1798;
var bwz_LWCNWz=1799;
var GW_WAN_WAN_GATEWAY_IP_ADDRESS_INVALID=1800;
var ta_wcn=1801;
var LW57=1802;
var _wepkey2=1803;
var tsc_pingt_msg109=1804;
var bd_NETBIOS_REG_TYPE=1805;
var wps_messgae1_2=1806;
var LW60=1807;
var _rs_failed=1808;
var KR62=1809;
var KR20=1810;
var at_intro_2=1811;
var bd_NETBIOS_ENABLE=1812;
var KR77=1813;
var help364=1814;
var _aa_bsecure_shopping=1815;
var _aa_bsecure_public_proxies=1816;
var wepkey1=1817;
var ZM11=1818;
var tsc_start_time=1819;
var YM69=1820;
var KR82=1821;
var ss_intro_user=1822;
var GW_SCHEDULES_NAME_RESERVED_INVALID=1823;
var LW12=1824;
var YM75=1825;
var GW_ROUTES_GATEWAY_IP_ADDRESS_INVALID=1826;
var GW_WLAN_WPA_REKEY_TIME_INVALID=1827;
var bws_msg_WEP_1=1828;
var YM125=1829;
var _aa_bsecure_gambling=1830;
var KR14=1831;
var GW_SMTP_FROM_ADDRESS_INVALID=1832;
var KR89=1833;
var help106=1834;
var LW35=1835;
var YM151=1836;
var YM2=1837;
var ta_wcn_note=1838;
var YM131=1839;
var GW_WEB_SERVER_SAME_PORT_LAN=1840;
var KR25=1841;
var YM3=1842;
var GW_NAT_WOL_ALG_ACTIVATED_WARNING=1843;
var YM20=1844;
var YM86=1845;
var GW_WAN_MAC_ADDRESS_INVALID=1846;
var IPSMTPCLIENT_MSG_WRONG_RECEPIENT_ADDR_FORMAT=1847;
var YM146=1848;
var LS151=1849;
var GW_QOS_RULES_NAME_INVALID=1850;
var GW_NAT_VS_PROTO_CONFLICT_INVALID=1851;
var GW_WISH_RULES_NAME_INVALID=1852;
var WIFISC_IR_REGISTRATION_FAIL=1853;
var r_rlist=1854;
var IPV6_TEXT109=1855;
var bws_WKL_1=1856;
var help473=1857;
var aw_erpe=1858;
var GW_NAT_PORT_FORWARD_RANGE_BOTH_EMPTY_INVALID=1859;
var GW_ROUTES_GATEWAY_IP_ADDRESS_IN_SUBNET_INVALID=1860;
var LW37=1861;
var tsc_pingdisallowed=1862;
var ZM20=1863;
var help376=1864;
var GW_FW_NOTIFY_EMAIL_DISABLED_INVALID=1865;
var YM122=1866;
var GW_NAT_DMZ_CONFLICT_WITH_LAN_IP_INVALID=1867;
var _sdi_s7=1868;
var at_title_SESet=1869;
var GW_INET_ACL_START_PORT_INVALID=1870;
var IPSMTPCLIENT_DATA_FAILED=1871;
var KR91=1872;
var KR971=1873;
var tss_RestAll_b=1874;
var GW_NAT_PORT_TRIGGER_CONFLICT_INVALID=1875;
var LW54=1876;
var TA7=1877;
var KR74=1878;
var bws_DFWK=1879;
var LW46=1880;
var IPSMTPCLIENT_RESOLVED_DNS=1881;
var help110=1882;
var YM107=1883;
var YM180=1884;
var GW_WAN_WAN_SUBNET_INVALID=1885;
var GW_NAT_DMZ_DISABLED_WARNING=1886;
var YM93=1887;
var GW_NAT_FTP_ALG_ACTIVATED_WARNING=1888;
var _aa_bsecure_free_host=1889;
var _r_alert2=1890;
var LS47=1891;
var GW_DHCP_SERVER_SUBNET_SIZE_INVALID=1892;
var GW_INET_ACCESS_POLICY_TOO_MANY_MAC_INVALID=1893;
var GW_FIREWALL_START_IP_ADDRESS_INVALID=1894;
var YM8=1895;
var GW_WISH_RULES_PRIORITY_RANGE=1896;
var _aa_bsecure_travel=1897;
var help113=1898;
var ZM6=1899;
var bws_length=1900;
var help836=1901;
var rs_intro_2=1902;
var GW_INET_ACL_IP_ADDRESS_DUPLICATION_INVALID=1903;
var KR7=1904;
var ZM1=1905;
var hhta_831=1906;
var LW30=1907;
var YM110=1908;
var bd_NETBIOS_REG_TYPE_P=1909;
var GW_LAN_SUBNET_MASK_INVALID=1910;
var YM88=1911;
var GW_DHCP_SERVER_NETBIOS_PRIMARY_WINS_INVALID=1912;
var YM187=1913;
var GW_NAT_NAME_UNDEFINED_INVALID=1914;
var GW_WIRELESS_RADAR_DETECTED=1915;
var LW25=1916;
var _rs_invalid=1917;
var YM113=1918;
var LW65=1919;
var KR41=1920;
var GW_WAN_DNS_SERVER_PRIMARY_INVALID=1921;
var KR21=1922;
var help643=1923;
var KR63=1924;
var LW31=1925;
var GW_WAN_DNS_SERVER_SECONDARY_INVALID=1926;
var YM55=1927;
var KR37=1928;
var KR80=1929;
var YM100=1930;
var _wakeonlan=1931;
var rs_intro_3=1932;
var gw_gm_35=1933;
var YM7=1934;
var YM124g=1935;
var GW_INET_ACL_MAC_ADDRESS_DUPLICATION_INVALID=1936;
var YM66=1937;
var manul_conn_13=1938;
var bd_NETBIOS=1939;
var sa_Target=1940;
var help56_a=1941;
var GW_DHCP_SERVER_RECONFIG_WARNING=1942;
var _wifisc_addfail=1943;
var GW_WLAN_BEACON_PERIOD_INVALID=1944;
var YM79=1945;
var YM32=1946;
var ta_intro_wcn=1947;
var wwl_text_better=1948;
var YM78=1949;
var sd_channel=1950;
var KR53=1951;
var LW16=1952;
var GW_NAT_TCP=1953;
var help202=1954;
var CRIT=1955;
var YM154=1956;
var help76=1957;
var GW_WISH_RULES_HOST1_PORT=1958;
var GW_WLAN_11G_TURBO_INVALID=1959;
var _aa_bsecure_entertainment=1960;
var YM165=1961;
var help172=1962;
var _aa_bsecure_lifestyles=1963;
var GW_NAT_DMZ_NOT_IN_SUBNET_INVALID=1964;
var sd_TMode=1965;
var GW_NAT_PORT_FORWARD_PORT_RANGE_INVALID=1966;
var GW_QOS_RULES_LOCAL_IP_END_SUBNET=1967;
var bws_CT_2=1968;
var _bsecure_parental_limits=1969;
var aw_64=1970;
var _aa_bsecure_humor=1971;
var KR92=1972;
var KR13=1973;
var GW_INET_ACL_POLICY_NAME_DUPLICATE_INVALID=1974;
var YM136=1975;
var TA3=1976;
var help360=1977;
var YM10=1978;
var GW_WAN_PPTP_SERVER_IP_ADDRESS_INVALID=1979;
var YM150=1980;
var GW_DHCP_SERVER_RESERVATION_IN_USE=1981;
var GW_NAT_INPUT_PORT=1982;
var WIFISC_AP_REBOOT_COMPLETE=1983;
var YM182=1984;
var LW3=1985;
var YM116=1986;
var LW22=1987;
var OOPS=1988;
var YM158=1989;
var ZM16=1990;
var _aa_bsecure_select_age=1991;
var GW_ROUTES_DESTINATION_IP_ADDRESS_INVALID=1992;
var WIFISC_AP_RESET_COMPLETE=1993;
var bd_NETBIOS_REG=1994;
var GW_LAN_GATEWAY_IP_ADDRESS_INVALID=1995;
var KR96=1996;
var GW_XML_CONFIG_GET_SUCCESS=1997;
var GW_UPNP_IGD_PORTMAP_REFRESH=1998;
var bws_msg_WPA_2=1999;
var GW_LAN_IP_ADDRESS_INVALID=2000;
var KR5=2001;
var help88c=2002;
var GW_INET_ACL_SCHEDULE_NAME_INVALID=2003;
var GW_QOS_RULES_REMOTE_PORT=2004;
var GW_NAT_IP_ADDRESS_INVALID=2005;
var help369=2006;
var help48a=2007;
var LW38=2008;
var GW_DYNDNS_USER_NAME_INVALID=2009;
var hhav_r_dest_ip=2010;
var YM175=2011;
var LY3=2012;
var GW_UPNP_IGD_PORTMAP_ADD=2013;
var GW_UPNP_IGD_PORTMAP_CONFLICT=2014;
var KRA1=2015;
var _vs_port=2016;
var GW_INET_ACL_RECONFIGURED_WARNING=2017;
var help186=2018;
var YM145=2019;
var WIFISC_AP_UNSET_SELECTED_REGISTRAR=2020;
var GW_WAN_DNS_SERVER_SECONDARY_WITHOUT_PRIMARY_INVALID=2021;
var YM72=2022;
var _hints=2023;
var GW_QOS_RULES_LOCAL_PORT=2024;
var YM52=2025;
var _aa_bsecure_chat=2026;
var help104=2027;
var help839=2028;
var YM99=2029;
var _aa_bsecure_byage=2030;
var GW_INET_ACL_NAME_DUPLICATE_INVALID=2031;
var GW_DHCP_SERVER_POOL_TO_INVALID=2032;
var KR26=2033;
var YM92=2034;
var GW_DHCP_SERVER_RESERVED_IP_INVALID=2035;
var help19x1=2036;
var _aa_bsecure_unstable=2037;
var GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID=2038;
var GW_FIREWALL_FILTER_NAME_INVALID=2039;
var ZM19=2040;
var YM80=2041;
var bd_NETBIOS_WINS_2=2042;
var KR57=2043;
var YM164=2044;
var _logsyslog_alert2=2045;
var YM149=2046;
var LT120=2047;
var KR48=2048;
var GW_WAN_RECONNECT_INTERVAL_INVALID=2049;
var YM139=2050;
var YM61=2051;
var GW_NAT_VIRTUAL_SERVER_TABLE_RECONFIGURED_WARNING=2052;
var YM1=2053;
var bws_WKL=2054;
var wps_p3_2=2055;
var KR102=2056;
var GW_QOS_RULES_LOCAL_IP_START_SUBNET=2057;
var GW_WAN_PPTP_IP_ADDRESS_INVALID=2058;
var _aa_bsecure_alcohol=2059;
var YM14=2060;
var GW_WLAN_11B_DYNAMIC_TURBO_INVALID=2061;
var GW_UPNP_IGD_PORTMAP_EXPIRE=2062;
var TA18=2063;
var aw_erpe_h2=2064;
var YM21=2065;
var YM147=2066;
var KR68=2067;
var LW61=2068;
var GW_WAN_L2TP_USERNAME_INVALID=2069;
var LT120z=2070;
var KR97=2071;
var GW_WAN_L2TP_SUBNET_INVALID=2072;
var help_ts_ss=2073;
var _aa_bsecure_automobile=2074;
var LW13=2075;
var sch_time=2076;
var bws_intro_WlsSec=2077;
var GW_WAN_PPPOE_PASSWORD_INVALID=2078;
var help211=2079;
var LS202=2080;
var tsc_EndTime=2081;
var KR34=2082;
var _wepkey3=2083;
var at_RePortR=2084;
var help640=2085;
var GW_SMTP_SERVER_ADDRESS_INVALID=2086;
var GW_WAN_L2TP_GATEWAY_IP_ADDRESS_INVALID=2087;
var LW58=2088;
var LW22usekey=2089;
var GW_WLAN_11B_STATIC_TURBO_INVALID=2090;
var YM67=2091;
var GW_WIFISC_CFG_CHANGED_WARNING=2092;
var ZM10=2093;
var GW_WLAN_11A_CHANNEL_INVALID=2094;
var at_title_SERules=2095;
var YM176=2096;
var KR81=2097;
var GW_NAT_TCP_PORT=2098;
var YM155=2099;
var help365=2100;
var bd_NETBIOS_SCOPE=2101;
var KR28=2102;
var _webfilter=2103;
var YM33=2104;
var YM76=2105;
var WIFISC_AP_SETUP_UNLOCKED=2106;
var GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=2107;
var LS313=2108;
var bwz_WCNWz=2109;
var ZM9=2110;
var GW_DHCP_SERVER_RESERVED_MAC_UNIQUENESS_INVALID=2111;
var LY5=2112;
var YM87=2113;
var GW_NAT_WAN_PING_FILTER_INVALID=2114;
var help835=2115;
var at_lowpriority=2116;
var YM49=2117;
var GW_INET_ACCESS_POLICY_TOO_MANY_IP_INVALID=2118;
var YM112=2119;
var KR90=2120;
var help838=2121;
var help892=2122;
var KR73=2123;
var wwl_intro_s3_2=2124;
var _r_alert5=2125;
var GW_NAT_WAN_PING_FILTER_WARNING=2126;
var YM53=2127;
var help215=2128;
var YM140=2129;
var GW_DHCPSERVER_REJECTED=2130;
var YM142=2131;
var GW_SMTP_PASSWORD_INVALID=2132;
var YM152=2133;
var LT119a=2134;
var LW36=2135;
var help377=2136;
var GW_NAT_PORT_TRIGGER_PORT_RANGE_INVALID=2137;
var YM121=2138;
var YM29=2139;
var YM159=2140;
var YM120=2141;
var wwl_BETTER=2142;
var hhaf_dmz=2143;
var YM106=2144;
var _aa_bsecure_block_unrated=2145;
var GW_WAN_BIGPOND_USERNAME_INVALID=2146;
var KR76=2147;
var GW_DHCPSERVER_EXHAUSTED=2148;
var GW_WAN_L2TP_SERVER_IP_ADDRESS_INVALID=2149;
var wwl_alert_pv5_2=2150;
var GW_ROUTES_SUBNET_INVALID=2151;
var _aa_bsecure_drugs=2152;
var LW1=2153;
var GW_DHCPSERVER_EXPIRED=2154;
var GW_INET_ACL_IP_ADDRESS_IN_LAN_SUBNET_INVALID=2155;
var bd_NETBIOS_REG_TYPE_B=2156;
var _aa_bsecure_financial=2157;
var YM135=2158;
var LT119=2159;
var _vs_public=2160;
var KR93=2161;
var GW_SECURE_REMOTE_ADMINSTRATION=2162;
var YM160=2163;
var LS423=2164;
var GW_WAN_L2TP_GATEWAY_IN_SUBNET_INVALID=2165;
var GW_WISH_RULES_HOST1_IP=2166;
var _vs_private=2167;
var KR86=2168;
var bd_NETBIOS_SEC_WINS=2169;
var GW_INET_ACL_START_IP_ADDRESS_INVALID=2170;
var auth=2171;
var KR24=2172;
var KR17=2173;
var YM84=2174;
var help88=2175;
var hhta_en=2176;
var YM103=2177;
var KR64=2178;
var GW_WLAN_11A_DFS_CHANNEL_INVALID=2179;
var LW4=2180;
var help645=2181;
var GW_WLAN_11A_STATIC_TURBO_INVALID=2182;
var help358=2183;
var YM6=2184;
var _aa_bsecure_categ_select=2185;
var YM58=2186;
var _aa_bsecure_age_youth=2187;
var LW17=2188;
var YM18=2189;
var LT210=2190;
var GW_WAN_IDLE_TIME_INVALID=2191;
var YM186=2192;
var _aa_bsecure_sports=2193;
var GW_QOS_RULES_NAME_ALREADY_USED=2194;
var bwz_intro_WCNWz=2195;
var GW_DHCP_SERVER_POOL_TO_IN_SUBNET_INVALID=2196;
var GW_NAT_H323_ALG_ACTIVATED_WARNING=2197;
var KR4=2198;
var LT120y=2199;
var KR103=2200;
var YM44=2201;
var LW47=2202;
var GW_XML_CONFIG_GET_FAILED=2203;
var WIFISC_AP_SET_APSETTINGS_COMPLETE=2204;
var wwl_WKL=2205;
var YM168=2206;
var GW_NAT_NAME_USED_INVALID=2207;
var GW_DYNDNS_SERVER_INDEX_VALUE_INVALID=2208;
var WARN=2209;
var LW23=2210;
var ADVANCED_NETWORK=2211;
var GW_WAN_PPTP_PASSWORD_INVALID=2212;
var LW59=2213;
var YM126=2214;
var _enabled=2215;
var _r_alert4=2216;
var LY10=2217;
var GW_DHCP_SERVER_POOL_FROM_INVALID=2218;
var WIFISC_AP_SETUP_LOCKED=2219;
var YM91=2220;
var WIFISC_AP_SET_SELECTED_REGISTRAR_FAIL=2221;
var _ask_nochange=2222;
var GW_NAT_UNKNOWN=2223;
var GW_WLAN_11A_DYNAMIC_TURBO_INVALID=2224;
var YM163=2225;
var YM181=2226;
var _cantapplysettings_1=2227;
var YM11=2228;
var wwl_wsp_chars_2=2229;
var bd_NETBIOS_PRI_WINS=2230;
var wwl_DWKL=2231;
var KR44=2232;
var TEXT056=2233;
var YM130=2234;
var KR99=2235;
var GW_DHCP_SERVER_PRIMARY_AND_SECONDARY_WINS_IP_INVALID=2236;
var KR106=2237;
var GW_NAT_VS_PROTOCOL_INVALID=2238;
var KR52=2239;
var KR33=2240;
var ZM23=2241;
var LW40=2242;
var LY4=2243;
var LW34=2244;
var YM25=2245;
var YM15=2246;
var bwl_SGM=2247;
var GW_WLAN_80211X_RADIUS_INVALID=2248;
var GW_WISH_RULES_PROTOCOL=2249;
var LS316=2250;
var ZM15=2251;
var GW_DHCP_SERVER_RESERVATION_DISABLED_IN_CONFLICT_WARNING=2252;
var GW_DYNDNS_HOST_NAME_INVALID=2253;
var LW42=2254;
var GW_WAN_PPTP_GATEWAY_IP_ADDRESS_INVALID=2255;
var rs_intro_4=2256;
var GW_QOS_RULES_REMOTE_IP_END_SUBNET=2257;
var _NA=2258;
var hhav_r_gateway=2259;
var INFO=2260;
var help112=2261;
var tf_msg_FWUgReset=2262;
var bd_NETBIOS_WAN=2263;
var aw_igslot=2264;
var ZM2=2265;
var LT7=2266;
var WIFISC_AP_SET_SELECTED_REGISTRAR=2267;
var help214=2268;
var at_Both=2269;
var ZM22=2270;
var help_ts_rfd=2271;
var help209=2272;
var YM70=2273;
var GW_UPNP_IGD_PORTMAP_VS_CHANGE=2274;
var help143s=2275;
var help363=2276;
var _aa_bsecure_web_newsgroup=2277;
var YM128=2278;
var GW_NAT_PORT_TRIGGER_PORT_RANGE_EMPTY_INVALID=2279;
var KR72=2280;
var td_PWK=2281;
var YM82=2282;
var YM119=2283;
var KR70=2284;
var YM161=2285;
var GW_DHCP_SERVER_POOL_SIZE_INVALID=2286;
var _sdi_s4b=2287;
var ZM8=2288;
var YM129=2289;
var help370=2290;
var LY29=2291;
var GW_XML_CONFIG_WRITE_WARN=2292;
var GW_FIREWALL_NAME_INVALID=2293;
var GW_WISH_RULES_HOST2_IP=2294;
var TA2=2295;
var LS314=2296;
var _vs_traffictype=2297;
var GW_DYNDNS_TIMEOUT_TOO_BIG_INVALID=2298;
var wps_p3_4=2299;
var KR51=2300;
var GW_WAN_PPTP_GATEWAY_IN_SUBNET_INVALID=2301;
var help837=2302;
var TEXT052=2303;
var OPEN=2304;
var _aa_bsecure_news=2305;
var YM34=2306;
var _advwls=2307;
var GW_DHCP_SERVER_RESERVATION_DISABLED_OUT_OF_POOL_WARNING=2308;
var GW_MAC_FILTER_ALL_LOCKED_OUT_INVALID=2309;
var _wepkey4=2310;
var LT124=2311;
var _aa_bsecure_search_engine=2312;
var KR47=2313;
var bws_msg_WEP_3=2314;
var GW_SMTP_LAN_ADDRESS_CONFLICT_WARNING=2315;
var GW_LAN_IP_MODE_INVALID=2316;
var GW_WAN_BIGPOND_SERVER_NOTSTD15=2317;
var GW_WLAN_FRAGMENT_THRESHOLD_INVALID=2318;
var GW_LAN_DOMAIN_NAME_INVALID=2319;
var GW_LAN_DEVICE_NAME_INVALID=2320;
var _wifisc_overlap=2321;
var LW62=2322;
var KR23=2323;
var _aa_bsecure_pornography=2324;
var GW_NAT_NAME_INVALID=2325;
var bd_title_clients=2326;
var YM108=2327;
var YM19=2328;
var WIFISC_AP_PROXY_PROCESS_COMPLETE=2329;
var GW_NAT_ENTRY_DUPLICATED_INVALID=2330;
var GW_NAT_PORT_FORWARD_CONFLICT_INVALID=2331;
var YM38=2332;
var tt_alert_nontp=2333;
var LY2=2334;
var KR29=2335;
var KR31=2336;
var _init_fail=2337;
var YM68=2338;
var sd_macaddr=2339;
var KR12=2340;
var help366=2341;
var WIFISC_AP_REGISTRATION_COMPLETE=2342;
var aw_TPC=2343;
var aw_WDSMAC=2344;
var YM62=2345;
var aw_erpe_h=2346;
var GW_WAN_RECONNECT_MODE_INVALID=2347;
var WIFISC_AP_DEL_APSETTINGS_COMPLETE=2348;
var LW15=2349;
var LW33=2350;
var KR27=2351;
var YM138=2352;
var GW_NAT_VS_PORT_CONFLICT_INVALID=2353;
var bd_NETBIOS_WINS_1=2354;
var _aa_wiz_s6_title=2355;
var YM77=2356;
var YM48=2357;
var YM89=2358;
var GW_WLAN_WPA_PSK_HEX_STRING_INVALID=2359;
var GW_WAN_WAN_IP_ADDRESS_INVALID=2360;
var LS4=2361;
var KR98=2362;
var YM148=2363;
var bws_WPAM_2=2364;
var help877a=2365;
var KR56=2366;
var LS424=2367;
var GW_DHCPSERVER_DECLINED=2368;
var GW_SCHEDULES_DAY_INVALID=2369;
var GW_NAT_UDP=2370;
var IPSMTPCLIENT_CANNOT_CREATE_CONNECTION=2371;
var _aa_check_all=2372;
var LS312=2373;
var KR2=2374;
var _vs_proto=2375;
var GW_SMTP_TO_ADDRESS_INVALID=2376;
var WIFISC_AP_REGISTRATION_FAIL=2377;
var GW_WISH_RULES_NAME_ALREADY_USED=2378;
var LW48=2379;
var YM54=2380;
var LW9=2381;
var LW41=2382;
var ebwl_AChan=2383;
var GW_WLAN_RTS_THRESHOLD_INVALID=2384;
var GW_WAN_L2TP_PASSWORD_INVALID=2385;
var YM12=2386;
var ZM14=2387;
var KR60=2388;
var YM28=2389;
var YM184=2390;
var int_intro_WCNWz7=2391;
var bws_Auth_2=2392;
var rs_intro_1=2393;
var help92=2394;
var GW_NAT_BOTH=2395;
var rs_success=2396;
var up_tz_29b=2397;
var day=2398;
var GW_DHCP_SERVER_DISABLED_WARNING=2399;
var _password=2400;
var GW_INET_ACCESS_POLICY_MAC_INVALID=2401;
var LW2=2402;
var KR75=2403;
var GW_XML_CONFIG_WRITE_FAILED=2404;
var YM73=2405;
var GW_WISH_RULES_NAME_USED_INVALID=2406;
var GW_DHCP_SERVER_POOL_SIZE_IN_SUBNET_INVALID=2407;
var aw_AS=2408;
var YM171=2409;
var GW_DHCP_SERVER_RESERVED_IP_NOT_LAN_IP_INVALID=2410;
var GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT=2411;
var hhav_r_netmask=2412;
var vs_vslist=2413;
var if_iflist=2414;
var YM137=2415;
var YM74=2416;
var GW_SYSLOG_ADDRESS_IN_SUBNET_INVALID=2417;
var help858=2418;
var GW_MAC_FILTER_MAC_UNIQUENESS_INVALID=2419;
var KR40=2420;
var GW_MAC_FILTER_NULL_MAC_INVALID=2421;
var aw_32=2422;
var GW_WAN_LAN_SUBNET_CONFLICT_INVALID=2423;
var LW66=2424;
var WIFISC_AP_DEL_APSETTINGS_FAIL=2425;
var wwl_wsp_chars_1=2426;
var KR85=2427;
var YM115=2428;
var YM83=2429;
var wwl_128bits=2430;
var LW51=2431;
var YM178=2432;
var _aa_bsecure_cults=2433;
var YM5=2434;
var KR65=2435;
var ZM17=2436;
var LW14=2437;
var ta_wcn_bv=2438;
var GW_NAT_VS_IP_ADDRESS_CAN_NOT_MATCH_ROUTER=2439;
var GW_SCHEDULES_IN_USE_INVALID=2440;
var wepkey3=2441;
var KR69=2442;
var YM43=2443;
var YM45=2444;
var GW_SMTP_USERNAME_INVALID=2445;
var help362=2446;
var tf_intro_FWChA=2447;
var _remotedesktop=2448;
var LW7=2449;
var help359=2450;
var KR84=2451;
var YM30=2452;
var at_LoPortR=2453;
var GW_DHCP_SERVER_POOL_FROM_IN_SUBNET_INVALID=2454;
var GW_MAC_FILTER_MULTICAST_MAC_INVALID=2455;
var GW_SMTP_INIT_FAILED_WARNING=2456;
var GW_DHCPSERVER_STOP=2457;
var help350=2458;
var GW_NAT_DMZ_NOT_ALLOWED_INVALID=2459;
var YM143=2460;
var GW_XML_CONFIG_SET_FAILED=2461;
var GW_NAT_PORT_DUP_INVALID=2462;
var KR46=2463;
var KR35=2464;
var GW_WAN_BIGPOND_PASSWORD_INVALID=2465;
var YM57=2466;
var KR104=2467;
var IPSMTPCLIENT_MSG_WRONG_SENDER_ADDR_FORMAT=2468;
var LS317=2469;
var YM102=2470;
var help188=2471;
var _logsyslog_alert1=2472;
var KR3=2473;
var _aa_bsecure_hate=2474;
var GW_WLAN_11BG_CHANNEL_INVALID=2475;
var RATE_ESTIMATOR_RATE_COMPLETED=2476;
var wwl_alert_pv5_3=2477;
var aw_aggr=2478;
var _wifisc_addstart=2479;
var help111=2480;
var GW_QOS_RULES_REMOTE_IP_START_SUBNET=2481;
var YM22=2482;
var GW_WLAN_WDS_MAC_ADDR_INVALID=2483;
var LW10=2484;
var LT291=2485;
var YM156=2486;
var _aa_bsecure_age_ado=2487;
var wwl_text_good=2488;
var GW_QOS_RULES_PRIORITY_RANGE=2489;
var te_OnSch=2490;
var _aa_bsecure_web_mail=2491;
var help188b=2492;
var GW_INET_ACL_START_IP_ADDRESS_IN_LAN_SUBNET_INVALID=2493;
var at_title_Traff=2494;
var help189=2495;
var GW_WIRELESS_SWITCH_CHANNEL=2496;
var GW_WAN_BIGPOND_SERVER_INVALID=2497;
var GW_XML_CONFIG_SET_PARSE=2498;
var hhaw_wmm=2499;
var LT290wifisc=2500;
var GW_FIREWALL_RULE_NAME_INVALID=2501;
var GW_NAT_SCHEDULE=2502;
var help109=2503;
var GW_LAN_RIP_MODE_INVALID=2504;
var LW52=2505;
var _aa_bsecure_popups=2506;
var GW_WLAN_WPA_WPA2_TKIP_INVALID=2507;
var KR16=2508;
var _vs_title=2509;
var _if_title=2510;
var GW_WAN_PPPOE_USERNAME_INVALID=2511;
var GW_WAN_PPTP_SUBNET_INVALID=2512;
var GW_DHCP_SERVER_NETBIOS_SCOPE_INVALID=2513;
var KR94=2514;
var YM63=2515;
var help108=2516;
var GW_SCHEDULES_DUPLICATED_INVALID=2517;
var bws_WPAM_1=2518;
var KR11=2519;
var LW45=2520;
var KR6=2521;
var GW_DHCP_SERVER_NETBIOS_TYPE_INVALID=2522;
var _aa_bsecure_games=2523;
var KR42=2524;
var YM104=2525;
var _aa_bsecure_tickets=2526;
var KR39=2527;
var bd_NETBIOS_REG_TYPE_M=2528;
var tsc_pingt_msg1=2529;
var GW_UPNP_IGD_PORTMAP_DEL=2530;
var YM111=2531;
var LS315=2532;
var GW_WLAN_WPA_PSK_LEN_INVALID=2533;
var help178=2534;
var YM167=2535;
var help371=2536;
var _aa_bsecure_anarchy=2537;
var YM4=2538;
var _aa_bsecure_criminal_skills=2539;
var YM188=2540;
var YM133=2541;
var YM59=2542;
var _aa_bsecure_manually=2543;
var YM169=2544;
var YM97=2545;
var _aa_bsecure_age_child=2546;
var help375=2547;
var GW_WEB_FILTER_WEBSITE_INVALID_INVALID=2548;
var ZM21=2549;
var YM157=2550;
var help213=2551;
var YM24=2552;
var wps_p3_3=2553;
var LW43=2554;
var help99_s=2555;
var YM90=2556;
var bws_CT_3=2557;
var help371_n=2558;
var GW_DHCP_SERVER_RESERVATION_RECONFIG_WARNING=2559;
var _r_alert3=2560;
var GW_LAN_RIP_METRIC_INVALID=2561;
var YM118=2562;
var YM127=2563;
var KR71=2564;
var aw_WDSEn=2565;
var KR32=2566;
var sa_Local=2567;
var GW_WEB_SERVER_IDLE_TIME=2568;
var KR59=2569;
var GW_WAN_WAN_GATEWAY_IN_SUBNET_INVALID=2570;
var at_LoIPR=2571;
var YM81=2572;
var aw_AP=2573;
var LT290=2574;
var YM162=2575;
var GW_XML_CONFIG_SET_PARSE_MIME=2576;
var GW_NAT_UDP_PORT=2577;
var YM9=2578;
var GW_WAN_MTU_INVALID=2579;
var LW63=2580;
var WIFISC_IR_REGISTRATION_SUCCESS=2581;
var help105=2582;
var GW_DHCPSERVER_RELEASED=2583;
var LW32=2584;
var WIFISC_AP_SET_APSETTINGS_FAIL=2585;
var KR8=2586;
var hhav_r_name=2587;
var bd_NETBIOS_REG_TYPE_H=2588;
var KR55=2589;
var GW_WAN_PPPOE_LAN_SUBNET_CONFLICT_INVALID=2590;
var GW_XML_CONFIG_SET_SUCCESS=2591;
var YM60=2592;
var KR100=2593;
var KR61=2594;
var bws_WKL_0=2595;
var bws_msg_WPA=2596;
var YM109=2597;
var WIFISC_AP_RESET_FAIL=2598;
var GW_WISH_RULES_HOST2_PORT=2599;
var help_ts_ls=2600;
var YM101=2601;
var KR50=2602;
var YM56=2603;
var aa_WebSite_Domain=2604;
var GW_QOS_RULES_MAX_TRANS=2605;
var GW_QOS_RULES_PROTOCOL=2606;
var GW_WEB_SERVER_NO_ACCESS=2607;
var KR87=2608;
var GW_WISH_RULES_DUPLICATED=2609;
var YM16=2610;
var GW_SCHEDULES_NAME_CONFLICT_INVALID=2611;
var wepkey4=2612;
var GW_WEB_SERVER_SAME_PORT_WAN=2613;
var YM65=2614;
var bln_title=2615;
var WIFISC_AP_PROXY_PROCESS_FAIL=2616;
var _more=2617;
var ZM12=2618;
var _aa_bsecure_banner_ad=2619;
var LY23=2620;
var help88b=2621;
var bwl_NSS_h1=2622;
var help203=2623;
var GW_INET_ACL_NO_MACHINE_IN_LAN_SUBNET_INVALID=2624;
var LW39c=2625;
var WIFISC_AP_SET_SELECTED_REGISTRAR_COMPLETE=2626;
var GW_DHCP_CLIENT_CLIENT_NAME_INVALID=2627;
var YM166=2628;
var WIFISC_AP_REBOOT_FAIL=2629;
var help91=2630;
var LW39=2631;
var YM173=2632;
var YM13=2633;
var YM172=2634;
var YM31=2635;
var _aa_wiz_s6_msg=2636;
var S493=2637;
var YM85=2638;
var GW_SCHEDULES_NAME_INVALID=2639;
var LS204=2640;
var aw_16=2641;
var aw_erpe_h3=2642;
var LW64=2643;
var _days=2644;
var help103=2645;
var YM183=2646;
var YM117=2647;
var KR54=2648;
var av_intro_r=2649;
var help368=2650;
var hhav_enable=2651;
var GW_WAN_DNS_SERVERS_INVALID=2652;
var _rs_succeeded=2653;
var GW_WAN_PPTP_USERNAME_INVALID=2654;
var GW_WAN_L2TP_IP_ADDRESS_INVALID=2655;
var GW_INET_ACL_NAME_INVALID=2656;
var days=2657;
var KR88=2658;
var GW_WAN_PPPOE_IP_ADDRESS_INVALID=2659;
var KR19=2660;
var RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED=2661;
var YM27=2662;
var LT291wifisc=2663;
var KR1=2664;
var YM51=2665;
var ZM13=2666;
var GW_LAN_PRIMARY_DNS_INVALID=2667;
var GW_WLAN_11A_DFS_TURBO_INVALID=2668;
var YM123=2669;
var TA8=2670;
var KR9=2671;
var KR79=2672;
var GW_QOS_RULES_REMOTE_IP=2673;
var _aa_bsecure_age_adult=2674;
var ZM7=2675;
var YM23=2676;
var tf_USSW=2677;
var LW55=2678;
var bwl_EW=2679;
var LS425=2680;
var wwl_WK=2681;
var LW11=2682;
var GW_NAT_PPTP_ALG_ACTIVATED_WARNING=2683;
var YM35=2684;
var tsc_sel_days=2685;
var sc_intro_rb4=2686;
var GW_SCHEDULES_TIME_INVALID=2687;
var GW_DHCP_SERVER_LEASE_TIME_INVALID=2688;
var IPSMTPCLIENT_NO_SERVER_IP_ADDRESS=2689;
var KR10=2690;
var GW_WEB_FILTER_HTTPS_NOT_SUPPORTED_INVALID=2691;
var KR22=2692;
var _vs_both=2693;
var wwl_alert_pv5_4=2694;
var GW_WIFISC_LOCK_VERIFY_ERR=2695;
var LW53=2696;
var GW_WEB_FILTER_WEB_SITE_IS_USED_INVALID=2697;
var YM64=2698;
var GW_ROUTES_INTERFACE_INVALID=2699;
var GW_LAN_SECONDARY_DNS_INVALID=2700;
var bd_NETBIOS_LEARN_FROM_WAN_ENABLE=2701;
var GW_NAT_PORT_FORWARDING_TABLE_RECONFIGURED_WARNING=2702;
var KR15=2703;
var WIFISC_AP_REGISTRATION_UNEXPECTED_EVENT=2704;
var GW_SYSLOG_ADDRESS_NOT_IN_SUBNET_WARNING=2705;
var GW_DHCP_SERVER_NETBIOS_SECONDARY_WINS_INVALID=2706;
var LW49=2707;
var KR95=2708;
var aw_8=2709;
var YM114=2710;
var bws_CT=2711;
var _aa_bsecure_rrated=2712;
var LW6=2713;
var bws_msg_WEP_2=2714;
var GW_QOS_RULES_LOCAL_IP=2715;
var GW_DHCP_SERVER_POOL_FROM_TO_ORIENTATION_INVALID=2716;
var bws_CT_1=2717;
var GW_XML_CONFIG_SET_LOCK=2718;
var GW_DHCP_SERVER_RESERVED_IP_UNIQUENESS_INVALID=2719;
var wepkey2=2720;
var LW28=2721;
var _wepkey1=2722;
var KR83=2723;
var GW_SYSLOG_ADDRESS_INVALID=2724;
var YM105=2725;
var ZM5=2726;
var help212=2727;
var wps_p3_5=2728;
var help19x2=2729;
var KR36=2730;
var GW_ROUTES_METRIC_INVALID=2731;
var GW_WLAN_SSID_INVALID=2732;
var LS46=2733;
var YM179=2734;
var KR78=2735;
var KR66=2736;
var _aa_bsecure_magazine=2737;
var KR101=2738;
var GW_WLAN_WPA_WPA_AES_INVALID=2739;
var GW_NAT_INBOUND_FILTER=2740;
var GW_INET_ACL_POLICY_NAME_INVALID=2741;
var sa_Internet=2742;
var help406=2743;
var YM153=2744;
var at_ReIPR=2745;
var GW_INET_ACCESS_RESTRICTED=2746;
var GW_WLAN_DTIM_INVALID=2747;
var YM144=2748;
var up_tz_26=2749;
var help71=2750;
var GW_PURE_ADDPORTMAPPING_MODIFY=2751;
var tsc_pingt_msg10=2752;
var tps_foo=2753;
var GW_PURE_ADDPORTMAPPING_CHG_PROTOCOL=2754;
var LOG_PREV_MSG_REPEATED_N_TIMES=2755;
var ca_intro=2756;
var GW_WAN_LAN_ADDRESS_CONFLICT_DHCP=2757;
var help176=2758;
var GW_PURE_ADDPORTMAPPING_CREATE=2759;
var hhag_30=2760;
var hhai_save=2761;
var ADMIN=2762;
var wprn_s1a=2763;
var sl_alert_3=2764;
var help900=2765;
var tps_foo2=2766;
var help182=2767;
var aa_alert_12=2768;
var tf_intro_FWCh=2769;
var ts_ss=2770;
var wwa_title_set_pptp=2771;
var _hostname_eg=2772;
var wwl_s4_note=2773;
var help22=2774;
var wwl_alert_pv5_1=2775;
var GW_PURE_SETWLANSETTINGS24=2776;
var help167=2777;
var at_DxDSL=2778;
var wprn_bados2=2779;
var wprn_s3a=2780;
var wprn_tt10=2781;
var bwn_IF=2782;
var _1044a=2783;
var wprn_tt6=2784;
var help72=2785;
var _sdi_s6=2786;
var hhpt_sch=2787;
var tps_enraw=2788;
var sl_alert_2=2789;
var anet_wp_2=2790;
var tss_RestAll=2791;
var GW_PURE_SETWANSETTINGS=2792;
var help53=2793;
var help175=2794;
var help872=2795;
var help785=2796;
var wprn_s2b=2797;
var wprn_intro2=2798;
var GW_INET_ACL_NO_FILTER_SELECTED_INVALID=2799;
var help890=2800;
var help814=2801;
var help283=2802;
var sps_protdis=2803;
var help831=2804;
var _cantapplysettings=2805;
var help39=2806;
var WCN_LOG_ABORT=2807;
var up_tz_73=2808;
var help141_a=2809;
var af_intro_x=2810;
var help170=2811;
var tps_intro4=2812;
var help893b=2813;
var GW_DHCPSERVER_START=2814;
var help887=2815;
var help38=2816;
var help164=2817;
var hhav_filt=2818;
var GW_PURE_ADDPORTMAPPING_CONFLICT=2819;
var GW_PURE_SETROUTERLANSETTINGS=2820;
var GW_PURE_SETWLANSECURITY=2821;
var aa_alert_9=2822;
var help287=2823;
var ta_RAIF=2824;
var help180=2825;
var GW_PURE_SETDEVICESETTINGS=2826;
var _rssi=2827;
var wwl_intro_wel=2828;
var tf_ClickDL=2829;
var help165=2830;
var _vs_other=2831;
var tps_intro5=2832;
var ub_intro_1=2833;
var help277=2834;
var help41=2835;
var VIRTUAL_SERVERS=2836;
var hhav_sch=2837;
var ts_rfd=2838;
var help33b=2839;
var ts_ls=2840;
var GW_PURE_DELETEPORTMAPPING_MODIFY=2841;
var wprn_s2c=2842;
var help320=2843;
var help813=2844;
var help893=2845;
var help803=2846;
var help877=2847;
var up_tz_27=2848;
var help74=2849;
var help155_2=2850;
var _sdi_s4=2851;
var MISC=2852;
var tf_msg_Upping=2853;
var GW_LOG_EMAIL_FAILED=2854;
var help823_17=2855;
var IPV6_TEXT4=2856;
var sa_intro=2857;
var up_rb_2=2858;
var help23=2859;
var _bln_title_IGMPMemberships_h=2860;
var haf_intro_2=2861;
var help802=2862;
var wprn_tt5=2863;
var hhsl_lmail=2864;
var ap_intro_noreboot=2865;
var up_tz_29=2866;
var GW_PURE_SETMACFILTERS2=2867;
var GW_PURE_REBOOT=2868;
var rb_change=2869;
var help816=2870;
var GW_PURE_DELETEPORTMAPPING_DELETE=2871;
var ub_intro_3=2872;
var help30=2873;
var bln_alert_2=2874;
var hhwf_xref=2875;
var GW_REMOTE_ADMINSTRATION=2876;
var wwl_s4_intro=2877;
var sd_SecTyp=2878;
var IPV6_WAN_IP=2879;
var IPV6_TEXT0=2880;
var gw_wcn_alert_3=2881;
var IPV6_TEXT2=2882;
var S473=2883;
var af_ES=2884;
var IPV6_TEXT5=2885;
var IPV6_TEXT6=2886;
var IPV6_TEXT7=2887;
var IPV6_TEXT8=2888;
var IPV6_TEXT9=2889;
var IPV6_TEXT10=2890;
var IPV6_TEXT11=2891;
var IPV6_TEXT12=2892;
var IPV6_TEXT13=2893;
var IPV6_TEXT14=2894;
var IPV6_TEXT15=2895;
var IPV6_TEXT16=2896;
var IPV6_TEXT17=2897;
var IPV6_TEXT18=2898;
var IPV6_TEXT19=2899;
var IPV6_TEXT20=2900;
var IPV6_TEXT21=2901;
var IPV6_TEXT22=2902;
var IPV6_TEXT23=2903;
var DNS_TEXT0=2904;
var IPV6_TEXT25=2905;
var IPV6_TEXT26=2906;
var IPV6_TEXT27=2907;
var IPV6_TEXT28=2908;
var IPV6_TEXT29=2909;
var IPV6_TEXT29a=2910;
var IPV6_TEXT30=2911;
var IPV6_TEXT31=2912;
var IPV6_TEXT32=2913;
var IPV6_TEXT33=2914;
var IPV6_TEXT34=2915;
var IPV6_TEXT35=2916;
var IPV6_TEXT36=2917;
var IPV6_TEXT37=2918;
var IPV6_TEXT38=2919;
var IPV6_TEXT39=2920;
var IPV6_TEXT40=2921;
var IPV6_TEXT41=2922;
var IPV6_TEXT42=2923;
var IPV6_TEXT43=2924;
var IPV6_TEXT44=2925;
var IPV6_TEXT45=2926;
var IPV6_TEXT46=2927;
var IPV6_TEXT47=2928;
var IPV6_TEXT48=2929;
var IPV6_TEXT49=2930;
var TA11=2931;
var IPV6_TEXT51=2932;
var IPV6_TEXT52=2933;
var IPV6_TEXT53=2934;
var IPV6_TEXT54=2935;
var IPV6_TEXT55=2936;
var IPV6_TEXT56=2937;
var IPV6_TEXT57=2938;
var IPV6_TEXT58=2939;
var IPV6_TEXT59=2940;
var IPV6_TEXT60=2941;
var IPV6_TEXT61=2942;
var IPV6_TEXT62=2943;
var IPV6_TEXT63=2944;
var IPV6_TEXT65=2945;
var _aa_bsecure_obscene=2946;
var IPV6_TEXT66=2947;
var IPV6_TEXT67=2948;
var IPV6_TEXT68=2949;
var IPV6_TEXT69=2950;
var IPV6_TEXT70=2951;
var IPV6_TEXT71=2952;
var IPV6_TEXT72=2953;
var IPV6_TEXT73=2954;
var IPV6_TEXT74=2955;
var IPV6_TEXT75=2956;
var IPV6_TEXT76=2957;
var IPV6_TEXT77=2958;
var IPV6_TEXT78=2959;
var IPV6_TEXT79=2960;
var IPV6_TEXT80=2961;
var IPV6_TEXT81=2962;
var IPV6_TEXT82=2963;
var IPV6_TEXT83=2964;
var IPV6_TEXT84=2965;
var IPV6_TEXT85=2966;
var IPV6_TEXT86=2967;
var IPV6_TEXT87=2968;
var IPV6_TEXT88=2969;
var IPV6_TEXT89=2970;
var IPV6_TEXT90=2971;
var IPV6_TEXT91=2972;
var IPV6_TEXT92=2973;
var IPV6_TEXT93=2974;
var IPV6_TEXT94=2975;
var IPV6_TEXT95=2976;
var IPV6_TEXT96=2977;
var IPV6_TEXT97=2978;
var IPV6_TEXT98=2979;
var IPV6_TEXT99=2980;
var IPV6_TEXT100=2981;
var IPV6_TEXT102=2982;
var IPV6_TEXT103=2983;
var IPV6_TEXT104=2984;
var IPV6_TEXT108=2985;
var IPV6_TEXT106=2986;
var IPV6_TEXT107=2987;
var IPV6_TEXT50=2988;
var help825=2989;
var IPV6_TEXT110=2990;
var IPV6_TEXT111=2991;
var IPV6_TEXT112=2992;
var IPV6_TEXT113=2993;
var IPV6_TEXT116=2994;
var IPV6_TEXT117=2995;
var IPV6_TEXT118=2996;
var IPV6_TEXT119=2997;
var IPV6_TEXT120=2998;
var IPV6_TEXT121=2999;
var IPV6_TEXT122=3000;
var IPV6_TEXT123=3001;
var IPV6_TEXT124=3002;
var IPV6_TEXT125=3003;
var IPV6_TEXT126=3004;
var IPV6_TEXT127=3005;
var IPV6_TEXT128=3006;
var IPV6_TEXT129=3007;
var IPV6_TEXT130=3008;
var IPV6_TEXT131=3009;
var IPV6_TEXT132=3010;
var IPV6_TEXT133=3011;
var IPV6_TEXT134=3012;
var IPV6_TEXT135=3013;
var IPV6_TEXT136=3014;
var IPV6_TEXT137=3015;
var IPV6_TEXT138=3016;
var IPV6_TEXT139=3017;
var IPV6_TEXT140=3018;
var IPV6_TEXT141=3019;
var IPV6_TEXT142=3020;
var IPV6_TEXT143=3021;
var IPV6_TEXT144=3022;
var IPV6_TEXT145=3023;
var IPV6_TEXT146=3024;
var bd_EDSv=3025;
var htsc_pingt_h=3026;
var IPV6_TEXT149=3027;
var IPV6_TEXT150=3028;
var IPV6_TEXT151=3029;
var IPV6_TEXT152=3030;
var IPV6_TEXT153=3031;
var wps_KR37=3032;
var IPV6_TEXT155=3033;
var IPV6_TEXT156=3034;
var IPV6_TEXT157=3035;
var IPV6_TEXT158=3036;
var IPV6_TEXT159=3037;
var IPV6_TEXT160=3038;
var IPV6_TEXT161=3039;
var IPV6_TEXT162=3040;
var IPV6_TEXT163=3041;
var IPV6_TEXT164=3042;
var IPV6_TEXT165=3043;
var IPV6_TEXT166=3044;
var haar_p=3045;
var bws_ORAD=3046;
var DNS_TEXT2=3047;
var DNS_TEXT3=3048;
var DNS_TEXT4=3049;
var DNS_TEXT8=3050;
var DNS_TEXT6=3051;
var DNS_TEXT5=3052;
var help639=3053;
var DNS_TEXT9=3054;
var DNS_TEXT10=3055;
var DNS_TEXT11=3056;
var DNS_TEXT12=3057;
var TEXT000=3058;
var TEXT001=3059;
var TEXT002=3060;
var TEXT003=3061;
var TEXT004=3062;
var TEXT005=3063;
var TEXT006=3064;
var TEXT007=3065;
var TEXT008=3066;
var TEXT010=3067;
var sw_title_list=3068;
var TEXT011=3069;
var TEXT012=3070;
var TEXT013=3071;
var TEXT014=3072;
var TEXT015=3073;
var TEXT016=3074;
var TEXT017=3075;
var TEXT018=3076;
var TEXT019=3077;
var TEXT020=3078;
var TEXT021=3079;
var TEXT022=3080;
var LS3=3081;
var TEXT024=3082;
var TEXT025=3083;
var TEXT026=3084;
var TEXT027=3085;
var TEXT028=3086;
var TEXT029=3087;
var TEXT030=3088;
var TEXT031=3089;
var TEXT032=3090;
var TEXT033=3091;
var TEXT035=3092;
var TEXT036=3093;
var TEXT037=3094;
var TEXT038=3095;
var TEXT039=3096;
var TEXT040=3097;
var TEXT041=3098;
var TEXT042=3099;
var TEXT043=3100;
var TEXT045=3101;
var TEXT046=3102;
var TEXT047=3103;
var aa_alert_10=3104;
var TEXT049=3105;
var TEXT050=3106;
var TEXT051=3107;
var TEXT053=3108;
var TEXT055=3109;
var TEXT009=3110;
var TEXT054=3111;
var TEXT057=3112;
var TEXT058=3113;
var TEXT059=3114;
var TEXT060=3115;
var TEXT062=3116;
var TEXT063=3117;
var TEXT064=3118;
var TEXT065=3119;
var TEXT066=3120;
var TEXT067=3121;
var TEXT068=3122;
var TEXT069=3123;
var TEXT070=3124;
var TEXT071=3125;
var TEXT072=3126;
var TEXT073=3127;
var TEXT074=3128;
var TEXT075=3129;
var TEXT076=3130;
var TEXT077=3131;
var TEXT078=3132;
var MSG002=3133;
var MSG003=3134;
var MSG004=3135;
var MSG005=3136;
var MSG006=3137;
var MSG007=3138;
var MSG008=3139;
var MSG009=3140;
var MSG010=3141;
var MSG013=3142;
var MSG014=3143;
var MSG014a=3144;
var MSG015=3145;
var MSG016=3146;
var MSG017=3147;
var MSG018=3148;
var MSG019=3149;
var MSG020=3150;
var MSG021=3151;
var MSG022=3152;
var MSG023=3153;
var MSG024=3154;
var MSG025=3155;
var MSG026=3156;
var MSG027=3157;
var MSG028=3158;
var MSG029=3159;
var MSG030=3160;
var MSG031=3161;
var MSG032=3162;
var MSG033=3163;
var MSG034=3164;
var MSG035=3165;
var MSG036_1=3166;
var MSG037_1=3167;
var MSG038_1=3168;
var MSG039_1=3169;
var MSG036=3170;
var MSG037=3171;
var MSG038=3172;
var MSG039=3173;
var MSG040=3174;
var MSG041=3175;
var MSG042=3176;
var MSG043=3177;
var MSG044=3178;
var MSG045=3179;
var MSG046=3180;
var MSG047=3181;
var MSG048=3182;
var ADV_DNS_DESC3=3183;
var ERROR404=3184;
var SUGGESTIONS=3185;
var SUGGESTIONS_1=3186;
var SUGGESTIONS_2=3187;
var tsc_hrmin_1=3188;
var DHCP_PD=3189;
var IPV6_TEXT147=3190;
var DHCP_PD_ASSIGNED=3191;
var _6to4RELAY=3192;
var IPV6_TEXT64=3193;
var IPV6_TEXT66_v6=3194;
var usb_reboot=3195;
var usb_reboot_chnip=3196;
var country_8=3197;
var _select_phone=3198;
var _phone_info=3199;
var usb_3g_phone=3200;
var usb_window_mobile_5=3201;
var usb_iphone=3202;
var android_phone=3203;
var help901=3204;
var DEVICE_NAME=3205;
var IPDHCPSERVER_LEASE_REVOKED2=3206;
var IPDHCPSERVER_LEASE_RESERVATION_DELETED=3207;
var IPDHCPSERVER_LEASE_RENEW=3208;
var help738=3209;
var help759=3210;
var help517=3211;
var help443=3212;
var help414=3213;
var _ok=3214;
var help486=3215;
var help503=3216;
var help426=3217;
var help432=3218;
var help527=3219;
var awf_intro_WF=3220;
var help652=3221;
var help456=3222;
var help539=3223;
var help472=3224;
var help520=3225;
var help737=3226;
var help646=3227;
var help745=3228;
var help659=3229;
var help727=3230;
var help753=3231;
var help574=3232;
var help663=3233;
var help748=3234;
var hhwf_intro=3235;
var help598=3236;
var help761=3237;
var help510=3238;
var help584=3239;
var help716=3240;
var help440=3241;
var help410=3242;
var help480=3243;
var help559=3244;
var help516=3245;
var help413=3246;
var help619=3247;
var help521=3248;
var help494=3249;
var help498=3250;
var help628=3251;
var help683=3252;
var help535=3253;
var help695=3254;
var help740=3255;
var help578=3256;
var help438=3257;
var help508=3258;
var help423=3259;
var help625=3260;
var help680=3261;
var help568=3262;
var help620=3263;
var help667=3264;
var help766=3265;
var help662=3266;
var help701=3267;
var help542=3268;
var help570=3269;
var help489=3270;
var help723=3271;
var help593=3272;
var help447=3273;
var help705=3274;
var help755=3275;
var _H323=3276;
var help427=3277;
var help485=3278;
var help490=3279;
var help555=3280;
var help462=3281;
var help732=3282;
var help592=3283;
var help455=3284;
var help685=3285;
var help146=3286;
var help655=3287;
var help439=3288;
var help416=3289;
var help726=3290;
var help692=3291;
var help550=3292;
var help714=3293;
var help504=3294;
var help469=3295;
var help629=3296;
var help597=3297;
var help746=3298;
var help749=3299;
var help471=3300;
var help736=3301;
var help596=3302;
var help706=3303;
var help664=3304;
var help702=3305;
var help756=3306;
var help573=3307;
var help601=3308;
var help684=3309;
var help678=3310;
var help760=3311;
var help536=3312;
var help499=3313;
var help562=3314;
var help741=3315;
var help541=3316;
var help717=3317;
var help604=3318;
var help718=3319;
var help551=3320;
var help577=3321;
var help515=3322;
var help621=3323;
var help412=3324;
var help713=3325;
var help687=3326;
var help567=3327;
var help618=3328;
var help441=3329;
var help466=3330;
var gw_vs_5=3331;
var help488=3332;
var help591=3333;
var help402=3334;
var help661=3335;
var help495=3336;
var help587=3337;
var help658=3338;
var help722=3339;
var help483=3340;
var help670=3341;
var help750=3342;
var help452=3343;
var help696=3344;
var help668=3345;
var help433=3346;
var help681=3347;
var help632=3348;
var help409=3349;
var help765=3350;
var help421=3351;
var help725=3352;
var help660=3353;
var help576=3354;
var help751=3355;
var help735=3356;
var help401=3357;
var gw_vs_6=3358;
var help491=3359;
var help448=3360;
var help566=3361;
var help398=3362;
var help586=3363;
var help710=3364;
var help686=3365;
var help537=3366;
var help654=3367;
var help708=3368;
var help424=3369;
var help505=3370;
var help583=3371;
var help430=3372;
var help484=3373;
var help454=3374;
var help556=3375;
var help470=3376;
var help689=3377;
var help464=3378;
var help461=3379;
var tt_Nov=3380;
var help715=3381;
var help622=3382;
var help731=3383;
var help408=3384;
var help688=3385;
var help465=3386;
var help703=3387;
var help697=3388;
var help605=3389;
var help549=3390;
var help506=3391;
var help642=3392;
var help428=3393;
var help682=3394;
var help492=3395;
var help526=3396;
var help631=3397;
var help606=3398;
var help665=3399;
var help148=3400;
var RATE_ESTIMATOR_RESOURCE_ERROR=3401;
var help721=3402;
var gw_vs_2=3403;
var help729=3404;
var help757=3405;
var help595=3406;
var help671=3407;
var help747=3408;
var help707=3409;
var help451=3410;
var help514=3411;
var help512=3412;
var help675=3413;
var help399=3414;
var help626=3415;
var help415=3416;
var help533=3417;
var help572=3418;
var help557=3419;
var help468=3420;
var help724=3421;
var help648=3422;
var wt_title=3423;
var help657=3424;
var help482=3425;
var help679=3426;
var help431=3427;
var help560=3428;
var help742=3429;
var help449=3430;
var help565=3431;
var wprn_tt7=3432;
var help599=3433;
var help585=3434;
var help530=3435;
var help623=3436;
var help758=3437;
var help634=3438;
var help752=3439;
var help575=3440;
var help450=3441;
var ES_CABLELOST_bnr=3442;
var help463=3443;
var help407=3444;
var help453=3445;
var help561=3446;
var help442=3447;
var help762=3448;
var help553=3449;
var help590=3450;
var help608=3451;
var help411=3452;
var gw_vs_4=3453;
var help546=3454;
var help653=3455;
var help481=3456;
var help529=3457;
var help425=3458;
var help400=3459;
var help509=3460;
var _DHCP=3461;
var help709=3462;
var help720=3463;
var help728=3464;
var help467=3465;
var help719=3466;
var help594=3467;
var help457=3468;
var help666=3469;
var help698=3470;
var help538=3471;
var help630=3472;
var help422=3473;
var help493=3474;
var help507=3475;
var help571=3476;
var RATE_ESTIMATOR_CONVERGENCE_ERROR=3477;
var help487=3478;
var help624=3479;
var help543=3480;
var help700=3481;
var help460=3482;
var help730=3483;
var help502=3484;
var help513=3485;
var help690=3486;
var help607=3487;
var help525=3488;
var help754=3489;
var help617=3490;
var help500=3491;
var help558=3492;
var help429=3493;
var help511=3494;
var help534=3495;
var help496=3496;
var help446=3497;
var help739=3498;
var help627=3499;
var _actsess=3500;
var help91a=3501;
var help91b=3502;
var help92x1=3503;
var help92x2=3504;
var TA21=3505;
var TA22=3506;
var help183=3507;
var help400_b=3508;
var help401_b=3509;
var help402_b=3510;
var help403=3511;
var help403_b=3512;
var help404=3513;
var help404_b=3514;
var help405=3515;
var help405_b=3516;
var WIFISC_AP_PEER_CFG_ERR=3517;
var help417=3518;
var help418=3519;
var help419=3520;
var help420=3521;
var help434=3522;
var help435=3523;
var help436=3524;
var help437=3525;
var help444=3526;
var help445=3527;
var help458=3528;
var help459=3529;
var help474=3530;
var help475=3531;
var help476=3532;
var help477=3533;
var help478=3534;
var help479=3535;
var help518=3536;
var help519=3537;
var help522=3538;
var help523=3539;
var help528=3540;
var help531=3541;
var help532=3542;
var help544=3543;
var help545=3544;
var help548=3545;
var help563=3546;
var help564=3547;
var help579=3548;
var help580=3549;
var help581=3550;
var help582=3551;
var help588=3552;
var help589=3553;
var help602=3554;
var help603=3555;
var help609=3556;
var help610=3557;
var help611=3558;
var help612=3559;
var help613=3560;
var help614=3561;
var help615=3562;
var help616=3563;
var tt_Oct=3564;
var sa_Originator=3565;
var help637=3566;
var help641=3567;
var help638=3568;
var msg_non_sec=3569;
var LW24=3570;
var help644=3571;
var help649=3572;
var help650=3573;
var help672=3574;
var help673=3575;
var help676=3576;
var help677=3577;
var help693=3578;
var help694=3579;
var help711=3580;
var help712=3581;
var help733=3582;
var help734=3583;
var help743=3584;
var help744=3585;
var help763=3586;
var help764=3587;
var help795a=3588;
var sa_Internal=3589;
var sa_External=3590;
var DNS_TEXT7=3591;
var help831_1=3592;
var DNS_TEXT1=3593;
var help191=3594;
var help198=3595;
var _unknown_wait=3596;
var _unknown=3597;
var _na=3598;
var _sdi_nciy=3599;
var _sdi_dhcpclient=3600;
var _sdi_bpc=3601;
var help600=3602;
var _bln_nmgmy=3603;
var _sdi_s1=3604;
var _sdi_s10=3605;
var _sdi_s8=3606;
var _sdi_s9=3607;
var _sdi_days=3608;
var _sdi_disconnectpending=3609;
var _sdi_secs=3610;
var sd_Renew=3611;
var sd_Release=3612;
var sd_Disconnect=3613;
var sd_bp_login=3614;
var sd_bp_logout=3615;
var _channel=3616;
var sl_SLogs=3617;
var sps_intro2=3618;
var sps_pare=3619;
var sr_RTable=3620;
var sr_intro=3621;
var ss_title_stats=3622;
var sw_title=3623;
var ta_alert_1=3624;
var ES_CABLELOST_dsc1=3625;
var _pwsame=3626;
var ta_alert_3=3627;
var _invalidddnsserver=3628;
var _blankddnsserver=3629;
var IPV6_TEXT1=3630;
var td_alert_2=3631;
var td_alert_3=3632;
var td_DDNSDDNS=3633;
var tt_SelDynDns=3634;
var _emailaccnameisblank=3635;
var _blankfromemailaddr=3636;
var _blanktomemailaddr=3637;
var _blanksmtpmailaddr=3638;
var _badfromemailaddr=3639;
var _badtoemailaddr=3640;
var _invalidsmtpserveraddr=3641;
var _badsmtpserveraddr=3642;
var tf_NFWA=3643;
var tf_alert_1=3644;
var tf_LFWVis=3645;
var tf_FWCinP=3646;
var tf_Ching_FW=3647;
var tf_EM_not=3648;
var tf_LFWV=3649;
var tf_FWChNow=3650;
var TA17=3651;
var tps_sfp=3652;
var tps_dci=3653;
var tps_intro2=3654;
var tsc_alert_1=3655;
var tsc_alert_2=3656;
var tsc_alert_3=3657;
var tsc_alert_6=3658;
var tsc_alert_9=3659;
var tsc_SelDays=3660;
var tsc_TimeFr=3661;
var tsl_alert_3=3662;
var tsl_alert_1=3663;
var tsl_alert_2=3664;
var ZM18=3665;
var tsc_pingt_msg9=3666;
var help635=3667;
var tt_alert_tupdt=3668;
var TA24=3669;
var TA25=3670;
var fb_FbAc=3671;
var sentinel_1=3672;
var sentinel_2=3673;
var sentinal_3=3674;
var fl_Failure=3675;
var fl_text=3676;
var li_newfw=3677;
var rd_p_1=3678;
var rd_p_2=3679;
var rs_Restoring_Settings=3680;
var reh=3681;
var rs_RSPW=3682;
var rs_cld=3683;
var rs_Done=3684;
var rs_uld=3685;
var rs_usd=3686;
var rs_csd=3687;
var rs_Repacked=3688;
var rs_Converted=3689;
var rs_Saving=3690;
var sc_intro_rb=3691;
var _relogin=3692;
var _badWANsub=3693;
var wwa_pv5_alert_4=3694;
var wwa_pv5_alert_5=3695;
var wwa_pv5_alert_8=3696;
var wwa_pv5_alert_6=3697;
var wwa_pv5_alert_7=3698;
var wwa_pv5_alert_21=3699;
var _badPPTPgwip=3700;
var wwa_pv5_alert_15=3701;
var _badL2TPgwip=3702;
var wwa_pv5_alert_20=3703;
var wwl_intro_s3_1=3704;
var wwl_intro_s3_2r=3705;
var wwl_WSP_1=3706;
var wwl_wpa=3707;
var wwl_wpa2=3708;
var gw_vs_0=3709;
var gw_vs_8=3710;
var gw_sa_0=3711;
var gw_sa_2=3712;
var gw_sa_3=3713;
var gw_sa_4=3714;
var YM47=3715;
var gw_SelBPS=3716;
var gw_bp_0=3717;
var gw_bp_1=3718;
var gw_bp_2=3719;
var gw_gm_81=3720;
var gw_wcn_alert_4=3721;
var gw_wcn_alert5=3722;
var gw_wcn_alert6=3723;
var gw_wcn_alert7=3724;
var gw_wcn_err_ok=3725;
var gw_wcn_err_code=3726;
var gw_wcn_err_os_version=3727;
var gw_wcn_err_load_config=3728;
var gw_wcn_err_provision=3729;
var gw_wcn_err_io_write_config=3730;
var gw_wcn_err_encryption=3731;
var gw_wcn_err_exception=3732;
var gw_wcn_err_com=3733;
var gw_wcn_err_bad_wsetting_entry=3734;
var gw_wcn_err_bad_wps_profile=3735;
var gw_wcn_err_unsupported_wsetting=3736;
var gw_wcn_err_dom_processing=3737;
var gw_wcn_err_default=3738;
var adv_Everyone=3739;
var adv_Noone=3740;
var psQueued=3741;
var psStarting=3742;
var psClosed=3743;
var psIdle=3744;
var psReady=3745;
var GW_PPPOE_EVENT_OFFER=3746;
var psUnplugged=3747;
var psPrinting=3748;
var IPPPPPAP_AUTH_RESULT=3749;
var up_gS_1=3750;
var up_gIUH_1=3751;
var up_gIUH_2=3752;
var up_gIUH_3=3753;
var up_gH_1=3754;
var up_ae_se_1=3755;
var up_ai_se_2=3756;
var up_ae_se_3=3757;
var up_ae_wic_1=3758;
var up_ae_wic_2=3759;
var _Advanced_02=3760;
var up_fm_dc_1=3761;
var up_fm_re_1=3762;
var up_fm_re_2=3763;
var up_fm_dr_1=3764;
var up_fm_dr_2=3765;
var up_fm_dr_3=3766;
var up_if_1=3767;
var up_rb_3=3768;
var up_rb_6=3769;
var up_vp_1=3770;
var up_vp_2=3771;
var up_vp_3=3772;
var up_vp_0=3773;
var up_vm_1=3774;
var up_vm_2=3775;
var up_he_1=3776;
var up_he_2=3777;
var up_he_5=3778;
var gw_sa_5=3779;
var IPSTACK_REJECTED_SPOOFED_PACKET=3780;
var IPDHCPSERVER_HOST_IS_ACTIVE=3781;
var BSECURE_LOG_AUTH_FAIL_UNREG=3782;
var RATE_ESTIMATOR_RATE_IS=3783;
var GW_IPFILTER_DENY=3784;
var GW_SMTP_EMAIL_CANNOT_CREATE_CONNECTION=3785;
var IPNAT_ILLEGAL_DEST=3786;
var BSECURE_LOG_FLTR_DISCONNECTED_TIMEOUT=3787;
var IPDHCPSERVER_LEASE_REVOKED1=3788;
var LOG_PREV_MSG_REPEATED_1_TIME=3789;
var GW_UPNP_PORTMAP_VS_CHANGE=3790;
var IPDHCPSERVER_LEASE_EXPIRED=3791;
var BSECURE_LOG_AUTH_FAIL_INTNL=3792;
var GW_UPNP_PORTMAP_DEL=3793;
var GW_SMTP_EMAIL_INVALID_TO_ADDRESS=3794;
var BSECURE_LOG_FLTR_DISCONNECTED_CLOSED=3795;
var IPDHCPSERVER_LEASE_EXPIRED_SPECIFIC=3796;
var BSECURE_LOG_AUTH_PASS=3797;
var BSECURE_LOG_AUTH_FAIL_UNKNW=3798;
var wwan_auth_pap=3799;
var BSECURE_LOG_AUTH_FAIL_RENEW=3800;
var IPDHCPSERVER_LEASE_DENIED=3801;
var GW_SMTP_EMAIL_TIMEOUT=3802;
var BSECURE_LOG_AUTH_FAIL_DB=3803;
var IPDHCPSERVER_PARAM_DB_UPDATED=3804;
var APP_RULES=3805;
var IPDHCPSERVER_LEASE_POOL_FULL=3806;
var IPPPPPAP_AUTH_SUCCESS=3807;
var ADVANCED_NETWORKS=3808;
var IPDHCPSERVER_LEASE_ASSIGNED=3809;
var BSECURE_LOG_FLTR_CONNECTED=3810;
var BSECURE_LOG_AUTH_CONNECTED=3811;
var BSECURE_LOG_AUTH_FAIL_PKT=3812;
var IPSMTPCLIENT_CONN_FAILED=3813;
var IPPPPPAP_AUTH_FAIL=3814;
var GW_LOG_ON_LATEST_FIRMWARE_RETRIEVED=3815;
var GW_SMTP_EMAIL_SEND_FAILURE=3816;
var IPDHCPSERVER_LEASE_RELEASED=3817;
var IPDHCPSERVER_PARAM_DB_ADDED=3818;
var IPPPPPAP_AUTH_TIMEOUT=3819;
var GW_UPNP_PORTMAP_ADD=3820;
var GW_SMTP_EMAIL_NO_SERVER_IP_ADDRESS=3821;
var GW_UPNP_PORTMAP_REFRESH=3822;
var GW_UPNP_PORTMAP_EXPIRE=3823;
var IPDHCPSERVER_PARAM_DB_REMOVED=3824;
var IPDHCPSERVER_LEASE_DELETED=3825;
var GW_UPNP_PORTMAP_CONFLICT=3826;
var TA1=3827;
var aa_alert_11=3828;
var aa_alert_1=3829;
var aa_sched_conf_3=3830;
var aa_alert_16=3831;
var aa_alert_2=3832;
var aa_alert_3=3833;
var aa_alert_4=3834;
var aa_alert_5=3835;
var aa_alert_6=3836;
var _aa_other_machines=3837;
var _copyright=3838;
var aw_alert_1=3839;
var aw_alert_2=3840;
var aw_alert_3=3841;
var aw_alert_4=3842;
var af_alert_1=3843;
var af_alert_2=3844;
var TA19=3845;
var ag_alert_4=3846;
var ag_alert_5=3847;
var ag_conflict10=3848;
var ag_conflict20=3849;
var ag_conflict21=3850;
var ag_alert_1=3851;
var ag_alert_3=3852;
var ag_alert2=3853;
var _tcpports=3854;
var _udpports=3855;
var ag_conflict4=3856;
var tsc_alert_7=3857;
var ai_alert_3=3858;
var GW_FIREWALL_NO_IP_RANGE_INVALID=3859;
var ai_alert_7=3860;
var ai_alert_4=3861;
var ai_alert_6=3862;
var tsc_alert_5=3863;
var ai_title_2=3864;
var _edit=3865;
var _srcip=3866;
var ai_c2=3867;
var ai_c3=3868;
var amaf_alert_1=3869;
var am_cMT_deny=3870;
var am_cMT_Allow=3871;
var _sr_nriy=3872;
var ar_alert_1=3873;
var ar_alert_2=3874;
var ar_alert_3=3875;
var ar_alert_4=3876;
var ar_alert_5=3877;
var ar_RoutI=3878;
var ar_Route=3879;
var ar_RoutesList=3880;
var _delete=3881;
var ar_ERTable=3882;
var ag_alert_duplicate_name=3883;
var ag_alert_duplicate=3884;
var ag_inuse=3885;
var _specapps_alert_2=3886;
var _specapps_tpr=3887;
var _specapps_ipr=3888;
var as_title_SAR=3889;
var as_TPRange=3890;
var as_ex=3891;
var as_TPR=3892;
var as_IPR=3893;
var as_IPrt=3894;
var at_alert_1_1=3895;
var at_alert_15=3896;
var at_alert_16=3897;
var at_alert_17=3898;
var at_alert_2=3899;
var at_alert_18=3900;
var at_alert_3=3901;
var at_alert_19=3902;
var at_alert_4=3903;
var at_alert_5=3904;
var at_alert_20=3905;
var at_alert_6=3906;
var at_alert_21=3907;
var at_alert_8=3908;
var at_alert_7=3909;
var at_alert_10=3910;
var at_alert_9=3911;
var at_alert_11=3912;
var at_alert_22=3913;
var at_alert_23=3914;
var at_alert_24=3915;
var at_alert_14=3916;
var at_Prot_0=3917;
var _srcport=3918;
var at_DIPR=3919;
var at_DPR=3920;
var av_alert_11=3921;
var av_alert_21=3922;
var av_alert_24=3923;
var av_alert_1=3924;
var av_alert_2=3925;
var av_alert_3=3926;
var av_alert_4=3927;
var av_alert_12=3928;
var av_alert_18=3929;
var av_alert_23=3930;
var av_alert_19=3931;
var av_alert_20=3932;
var av_alert_13=3933;
var av_alert_17=3934;
var av_alert_5=3935;
var av_alert_6=3936;
var av_alert_7=3937;
var av_alert_8=3938;
var av_alert_9=3939;
var av_alert_10=3940;
var _public=3941;
var at_Prot__1=3942;
var _private=3943;
var aa_WebSite=3944;
var awf_alert_4=3945;
var awf_alert_5=3946;
var awf_alert_7=3947;
var awf_alert_8=3948;
var int_ConWz2=3949;
var int_WlsWz=3950;
var hhbi_wiz=3951;
var hhbi_man=3952;
var bd_noneyet=3953;
var bd_revoked=3954;
var bln_alert_3=3955;
var bd_alert_10=3956;
var bd_alert_11=3957;
var bd_alert_1=3958;
var bd_alert_3=3959;
var bd_alert_13=3960;
var bd_alert_12=3961;
var bd_alert_5=3962;
var bd_alert_6=3963;
var bd_alert_7=3964;
var TA20=3965;
var bd_alert_8=3966;
var bd_alert_22=3967;
var bd_alert_23=3968;
var bd_alert_24=3969;
var _badWANIP=3970;
var bwn_alert_2=3971;
var bwn_alert_3=3972;
var bwn_alert_4=3973;
var bwn_alert_5=3974;
var MSG000=3975;
var bwn_alert_8=3976;
var bwn_alert_12=3977;
var _badPPTPip=3978;
var _badPPTPsub=3979;
var _badPPTPipsub=3980;
var bwn_alert_11=3981;
var _badL2TP3=3982;
var _badL2TP=3983;
var _badL2TP2=3984;
var bwn_alert_17=3985;
var bwn_alert_21=3986;
var bws_alert_15=3987;
var bws_alert_16=3988;
var bwl_alert_2=3989;
var bwl_alert_3=3990;
var bwl_alert_15=3991;
var bwl_alert_16=3992;
var bwl_alert_4=3993;
var bwl_alert_5=3994;
var bwl_alert_6=3995;
var bwl_alert_7=3996;
var bwl_alert_8=3997;
var bwl_alert_9=3998;
var bwl_alert_10=3999;
var bws_alert_2=4000;
var bwl_alert_11=4001;
var bwl_alert_12=4002;
var bws_alert_3=4003;
var aw_alert_5_1=4004;
var bwl_alert_13=4005;
var bwl_alert_14=4006;
var bwl_Mode_2=4007;
var bwl_Mode_3=4008;
var bwl_Mode_1=4009;
var bwl_Mode_8=4010;
var bwl_Mode_11=4011;
var bwl_ht20=4012;
var bwl_ht2040=4013;
var bwl_TxR_0=4014;
var TA9=4015;
var YM124=4016;
var TA12=4017;
var TA14=4018;
var TA15=4019;
var _wizard=4020;
var bwz_LConWz=4021;
var bwz_WlsWz=4022;
var bwz_intro_WlsWz=4023;
var bwz_LWlsWz=4024;
var _specapps=4025;
var _gaming=4026;
var _basic=4027;
var ag_alert_empty_name=4028;
var ag_alert_duplicate_name2=4029;
var amaf_alert_2=4030;
var specapps_alert_duplicate_name=4031;
var specapps_alert_duplicate1=4032;
var specapps_alert_conflict1=4033;
var specapps_alert_empty_schedule=4034;
var at_title_TSSet=4035;
var av_alert_35=4036;
var av_alert_empty_name=4037;
var av_alert_16=4038;
var bln_alert_lannbpri=4039;
var bln_alert_lannbsec=4040;
var lan_dns=4041;
var lan_dns2=4042;
var bln_NetBIOSReg_H=4043;
var bln_NetBIOSReg_M=4044;
var bln_NetBIOSReg_P=4045;
var bln_NetBIOSReg_B=4046;
var _help=4047;
var help81ets=4048;
var af_EFT_h4=4049;
var YM134=4050;
var af_EFT_h1=4051;
var af_EFT_h2=4052;
var af_EFT_h5=4053;
var af_UEFT_h1=4054;
var af_TEFT_h2=4055;
var help309A=4056;
var help400_1=4057;
var help401_1=4058;
var help402_1=4059;
var help402_2=4060;
var help405_1=4061;
var help405_2=4062;
var help405_3=4063;
var help405_4=4064;
var _sdi_s1a=4065;
var ta_alert_3b=4066;
var ta_alert_3c=4067;
var ta_alert_3d=4068;
var ta_alert_3e=4069;
var ta_alert_3f=4070;
var ta_alert_3g=4071;
var tps_enlpd=4072;
var ta_LMAP=4073;
var fb_FailLogin=4074;
var fb_FailLogin_1=4075;
var _open=4076;
var _other=4077;
var _223=4078;
var _225ap=4079;
var _226ap=4080;
var _1044wired=4081;
var _1044awired=4082;
var TEXT0=4083;
var regenerate=4084;
var _title_AdvDns=4085;
var _desc_AdvDns=4086;
var ta_EUPNP_dns=4087;
var _st_AdvDns=4088;
var _sp_title_AdvDNS=4089;
var _sp_desc1_AdvDNS=4090;
var _sp_desc2_AdvDNS=4091;
var _sp_desc3_AdvDNS=4092;
var _sp_desc4_AdvDNS=4093;
var TEXT041_1=4094;
var TEXT041_2=4095;
var TEXT041_3=4096;
var TEXT041_4=4097;
var TEXT042_1=4098;
var TEXT042_2=4099;
var GW_URL_INVALID=4100;
var GW_LAN_NETBIOS_SCOPE_INVALID=4101;
var GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID_a=4102;
var bwn_Mode_DHCPPLUS=4103;
var net_sniper_support=4104;
var SEL_DIAL_MODE=4105;
var pppoe_dialmode_normal=4106;
var pppoe_dialmode_sp1=4107;
var pppoe_dialmode_sp2=4108;
var pppoe_dialmode_sp3=4109;
var pppoe_dialmode_sp4=4110;
var pppoe_dialmode_sp5=4111;
var pppoe_dialmode_sp6=4112;
var pppoe_dialmode_learn=4113;
var bt_learn_text=4114;
var box_ip_mac_binding=4115;
var _en_AdvDns=4116;
var xkjs_support=4117;
var ddns_serv_type=4118;
var ddns_domain=4119;
var ddns_account=4120;
var virtual_pub_port_err=4121;
var virtual_pri_port_err=4122;
var virtual_proto_num_err=4123;
var menu_wps=4124;
var tc_iprange=4125;
var help823_15=4126;
var tc_bw=4127;
var tc_schedule=4128;
var tc_new_sch=4129;
var tc_min_bw=4130;
var tc_max_bw=4131;
var _login_admin=4132;
var _login_user=4133;
var pppoe_plus_dail=4134;
var GW_WAN_DHCPPLUS_USERNAME_INVALID=4135;
var GW_WAN_DHCPPLUS_PASSWORD_INVALID=4136;
var te_SMTPPort=4137;
var WLANMODE=4138;
var ROUTER_MODE=4139;
var AP_MODE=4140;
var WDSROUTER_MODE=4141;
var WDSAP_MODE=4142;
var BR_SET=4143;
var device_mode=4144;
var router_mode=4145;
var ap_mode=4146;
var auto_mode=4147;
var enable_WDS=4148;
var ES_AUTODECT=4149;
var _phone=4150;
var ES_CABLELOST_dsc2=4151;
var ES_DONT_CONN_btn=4152;
var ES_UPDATE_SETTING_bnr=4153;
var ES_UPDATE_SETTING_dsc=4154;
var ES_CONFIG_INTERNET_bnr=4155;
var ES_CONFIG_INTERNET_dsc2=4156;
var ES_INTERNET_CONN_dsc=4157;
var ES_MUST_FIELD_dsc=4158;
var ES_DIALUP_ERROR_bnr=4159;
var usb_config1=4160;
var ES_NAME=4161;
var MSG011=4162;
var ES_what_is_this=4163;
var ES_PRI_DNS=4164;
var ES_SEC_DNS=4165;
var ES_GW_ADDR=4166;
var ES_MASK=4167;
var ES_IP_ADDR=4168;
var ES_complete=4169;
var ES_save_dsc=4170;
var ES_status=4171;
var ES_connected=4172;
var ES_unconnected=4173;
var ES_wlan_setting=4174;
var ES_wlan_ssid=4175;
var ES_security=4176;
var ES_unsecured=4177;
var ES_unsecured_suggest=4178;
var ES_save_mySetting=4179;
var ES_sync_pw=4180;
var ES_save=4181;
var ES_network_key=4182;
var ES_autogen_key=4183;
var ES_disable_wifi_sec=4184;
var ES_wifi_sec_recomm=4185;
var ES_current_setting_dsc=4186;
var ES_current_setting=4187;
var ES_manual_btn=4188;
var ES_cancel=4189;
var logout_caption=4190;
var logout_desc=4191;
var logout_return=4192;
var st_connected_time=4193;
var t_ctl_title=4194;
var t_ctl_note=4195;
var t_ctl_note1=4196;
var page_title=4197;
var ac_alert_invalid_port=4198;
var ac_alert_dup_name=4199;
var ac_alert_port_conflit=4200;
var ac_alert_policy_null=4201;
var tt_alert_checkdyndns=4202;
var ES_static_no_internet=4203;
var ES_static_no_internet_desc=4204;
var _CFM_close_window=4205;
var ES_save_result=4206;
var ES_save_success=4207;
var ES_confirm_bt=4208;
var sch_timeformat=4209;
var sch_hourfmt_12=4210;
var sch_hourfmt_24=4211;
var no_available_update=4212;
var clear_lang_pack=4213;
var current_lang_pack_version=4214;
var current_lang_pack_date=4215;
var lang_package_info=4216;
var lang_package_note1=4217;
var lang_package_note2=4218;
var latest_lang_package_ver=4219;
var latest_lang_package_date=4220;
var no_lang_pack=4221;
var pf_name_empty=4222;
var vs_name_empty=4223;
var fw_checksum_err=4224;
var fw_bad_hwid=4225;
var fw_unknow_file_format=4226;
var fw_fw_upgrade_success=4227;
var fw_lp_upgrade_success=4228;
var fw_cfg_upgrade_success=4229;
var ES_timectrl_bnr=4230;
var ES_timectrl_btn=4231;
var ES_webpolicy_btn=4232;
var HW_NAT_desc=4233;
var at_ETS=4234;
var alert_hw_nat_1=4235;
var alert_hw_nat_2=4236;
var alert_hw_nat_3=4237;
var help_auto_disable_hw_nat=4238;
var help_auto_disable_hw_nat_1=4239;
var help_hw_nat=4240;
var help_hw_nat_desc=4241;
var ES_step_wifi_security=4242;
var _pwsame_user=4243;
var ES_btn_try_again=4244;
var ES_auto_detect_desc=4245;
var ES_auto_detect_failed_desc=4246;
var ES_btn_guide_me=4247;
var ES_btn_save_conn=4248;
var ES_btn_save=4249;
var v6_routing=4250;
var v6_routing_table=4251;
var v6_routing_info=4252;
var ipv6=4253;
var ipv6_firewall=4254;
var ipv6_firewall_info=4255;
var _6rd_settings=4256;
var ipv4_addr=4257;
var mask_len=4258;
var IPV6_ULA_TEXT01=4259;
var HW_NAT_enable=4260;
var IPV6_ULA_TEXT03=4261;
var IPV6_ULA_TEXT04=4262;
var IPV6_ULA_TEXT05=4263;
var IPV6_ULA_TEXT06=4264;
var IPV6_ULA_TEXT07=4265;
var IPV6_ULA_TEXT08=4266;
var IPV6_ULA_TEXT09=4267;
var IPV6_ULA_TEXT11=4268;
var IPV6_ULA_TEXT12=4269;
var IPV6_ULA_TEXT13=4270;
var IPV6_ULA_TEXT14=4271;
var IPv6_Local_Info=4272;
var IPv6_Simple_Security=4273;
var anet_multicast_enable_v6=4274;
var IPv6_Wizard_6rd_title=4275;
var fr_name_empty=4276;
var r6_name_empty=4277;
var wwz_wwl_intro_s2_1=4278;
var wwz_wwl_intro_s2_1_1=4279;
var wwz_wwl_intro_s2_1_2=4280;
var wwz_wwl_intro_s2_2=4281;
var wwz_wwl_intro_s2_2_1=4282;
var wwz_wwl_intro_s2_2_2=4283;
var ES_title_s3=4284;
var ES_title_s4=4285;
var ES_title_s5=4286;
var bwl_Mode_n=4287;
var bwl_Mode_a=4288;
var bwl_Mode_5=4289;
var MSG049=4290;
var MSG050=4291;
var HWerr=4292;
var storage=4293;
var sto_into=4294;
var sto_http_0=4295;
var bwn_RPing=4296;
var guestzone_enable=4297;
var sto_http_3=4298;
var LV2=4299;
var sto_http_5=4300;
var sto_creat=4301;
var _add_edit=4302;
var sto_list=4303;
var _modify=4304;
var sto_path=4305;
var help361=4306;
var tt_NTPSrvU=4307;
var sto_dev=4308;
var _total_space=4309;
var _free_space=4310;
var sto_link_0=4311;
var sto_link_1=4312;
var sto_link_2=4313;
var _email_now=4314;
var sto_help=4315;
var _DevLink=4316;
var _folder=4317;
var _browse=4318;
var _append=4319;
var sto_01=4320;
var sto_02=4321;
var _readonly=4322;
var _readwrite=4323;
var _AppendNewFolder=4324;
var KR45=4325;
var MSG052=4326;
var MSG053=4327;
var MSG054=4328;
var _AddFolder=4329;
var _StorageLink=4330;
var LW6_1=4331;
var MSG055=4332;
var ES_title_s5_0=4333;
var save_settings=4334;
var save_wait=4335;
var _Language=4336;
var manul_conn_01=4337;
var manul_conn_02=4338;
var manul_conn_03=4339;
var manul_conn_04=4340;
var manul_conn_05=4341;
var manul_conn_06=4342;
var manul_conn_07=4343;
var manul_conn_08=4344;
var manul_conn_09=4345;
var manul_conn_10=4346;
var manul_conn_11=4347;
var manul_conn_12=4348;
var _aa_bsecure_opinion=4349;
var manul_conn_14=4350;
var manul_conn_15=4351;
var manul_conn_16=4352;
var manul_conn_17=4353;
var manul_conn_18=4354;
var manul_conn_19=4355;
var manul_conn_20=4356;
var manul_conn_21=4357;
var manul_conn_22=4358;
var manul_conn_23=4359;
var manul_conn_24=4360;
var manul_conn_25=4361;
var manul_5g_ssid=4362;
var tf_intro_FWU4=4363;
var tf_intro_FWU5=4364;
var _firmwareUpdate=4365;
var _date=4366;
var _remove=4367;
var notify_wps=4368;
var ag_conflict5=4369;
var _disable=4370;
var coexi=4371;
var wwl_SSP=4372;
var wwz_wwl_intro_s0=4373;
var STATUS_IPV6_DESC_0=4374;
var STATUS_IPV6_DESC_1=4375;
var STATUS_IPV6_DESC_6=4376;
var STATUS_IPV6_DESC_5=4377;
var STATUS_IPV6_DESC_4=4378;
var STATUS_IPV6_DESC_3=4379;
var STATUS_IPV6_DESC_2=4380;
var ag_conflict6=4381;
var TEXT008a=4382;
var TEXT008b=4383;
var TEXT023=4384;
var at_mbps=4385;
var pin_f=4386;
var msg_eap=4387;
var open=4388;
var PRIVATE_PORT_ERROR=4389;
var MSG056=4390;
var MSG057=4391;
var _DestIP=4392;
var _type=4393;
var mydlink_tx03=4394;
var mydlink_tx05=4395;
var sec_left=4396;
var ES_CONN_dsc=4397;
var chk_pass=4398;
var Lname=4399;
var Fname=4400;
var _login=4401;
var ag_conflict22=4402;
var ag_conflict23=4403;
var wifi_enable_chk=4404;
var ZERO_IPV6_ADDRESS=4405;
var port_empty=4406;
var _disable_s=4407;
var IPV6_TEXT154=4408;
var _signup=4409;
var up_tz_74=4410;
var wifi_pass_chk=4411;
var _remove_multi=4412;
var tf_really_langf=4413;
var tf_langf=4414;
var ub_intro_l1=4415;
var ub_intro_l3=4416;
var err404_title=4417;
var err404_detect=4418;
var err404_sug=4419;
var err404_sug1=4420;
var err404_sug2=4421;
var err404_sug3=4422;
var err404_sug4=4423;
var err404_sug5=4424;
var tsc_end_time=4425;
var remote_port_msg=4426;
var TEXT034=4427;
var LW39b=4428;
var _nousername=4429;
var metric_empty=4430;
var TEXT061=4431;
var ES_DIALUP_ERROR_dsc=4432;
var MSG001=4433;
var MSG051=4434;
var MSG012=4435;
var aa_alert_13=4436;
var TEXT044=4437;
var sto_03=4438;
var up_nosave=4439;
var ta_msg_TW=4440;
var sto_04=4441;
var IPV6_TEXT167=4442;
var IPV6_TEXT170=4443;
var help_171=4444;
var DDNS_HOST_ERROR=4445;
var _item_no=4446;
var _usb_not_found=4447;
var srv_name_empty=4448;
var msg_wps_sec_01=4449;
var msg_wps_sec_02=4450;
var msg_wps_sec_03=4451;
var sh_port_tx_00a=4452;
var sh_port_tx_00b=4453;
var sh_port_tx_00=4454;
var sh_port_tx_01=4455;
var sh_port_tx_02=4456;
var sh_port_tx_03=4457;
var sh_port_tx_04=4458;
var sh_port_tx_05=4459;
var sh_port_tx_06=4460;
var sh_port_tx_07=4461;
var sh_port_tx_08=4462;
var sh_port_tx_09=4463;
var sh_port_tx_10=4464;
var sh_port_ddns_01=4465;
var sh_port_ddns_02=4466;
var sh_port_ddns_03=4467;
var sh_port_tx_11=4468;
var sh_port_tx_12=4469;
var sh_port_tx_13=4470;
var sh_port_tx_16=4471;
var sh_port_tx_17=4472;
var sh_port_tx_18=4473;
var sh_port_tx_19=4474;
var sh_port_tx_20=4475;
var sh_port_tx_21=4476;
var sh_port_msg_01=4477;
var sh_port_msg_02=4478;
var sh_port_msg_04=4479;
var sh_port_msg_05=4480;
var sh_port_msg_06=4481;
var sh_port_msg_07=4482;
var sh_port_msg_08=4483;
var sh_port_msg_09=4484;
var sto_http_6=4485;
var file_acc_del_user=4486;
var file_acc_del_path=4487;
var file_acc_del_file=4488;
var _login_a=4489;
var IPv6_ddns_01=4490;
var IPv6_ddns_02=4491;
var IPv6_fw_01=4492;
var IPv6_fw_02=4493;
var IPv6_fw_03=4494;
var IPv6_fw_04=4495;
var IPv6_fw_ipr=4496;
var IPv6_fw_pr=4497;
var IPv6_fw_sr=4498;
var IPv6_fw_dest=4499;
var IPv6_6rd_relay=4500;
var IPv6_6rd_wan=4501;
var IPv6_6to4_relay=4502;
var IPv6_addrSr=4503;
var IPv6_addrEr=4504;
var msg_wps_sec_04=4505;
var msg_wait_sec=4506;
var file_acc_del_empty=4507;
var IPV6_TEXT161a=4508;
var ss_Wstats_2=4509;
var ss_Wstats_5g=4510;
var dlna_t=4511;
var dlna_01=4512;
var dlna_02=4513;
var dlna_03=4514;
var rus_wan_pptp=4515;
var rus_wan_pptp_01=4516;
var rus_wan_l2tp=4517;
var rus_wan_l2tp_01=4518;
var rus_wan_pppoe=4519;
var rus_wan_pppoe_02=4520;
var rus_wan_pppoe_03=4521;
var msg_wps_sec_05=4522;
var webf_login=4523;
var webf_intro=4524;
var webf_title=4525;
var webf_folder=4526;
var webf_hd=4527;
var webf_createfd=4528;
var webf_fd_name=4529;
var webf_upload=4530;
var webf_file_sel=4531;
var dlna_t1=4532;
var dlna_t2=4533;
var help_stor1=4534;
var help_stor2=4535;
var help_stor3=4536;
var help_stor4=4537;
var help_stor5=4538;
var help_stor6=4539;
var help_stor7=4540;
var help_stor8=4541;
var help_stor9=4542;
var help_dlna1=4543;
var webf_non_hd=4544;
var sh_port_tx_22=4545;
var sh_port_tx_23=4546;
var IPv6_Ingress_Filtering_enable=4547;
var share_title_1=4548;
var share_title_2=4549;
var share_title_3=4550;
var share_title_4=4551;
var share_ser_1=4552;
var share_ser_2=4553;
var share_ser_3=4554;
var share_ser_4=4555;
var ddns_disconnecting=4556;
var lan_reserveIP=4557;
var end_ip=4558;
var _NULL=4559;
var ddns_sel2=4560;
var ddns_sel3=4561;
var _remoteipaddr=4562;
var _back=4563;
var _ping_fail=4564;
var _ping_success=4565;
var _wz_disWPS=4566;
var limit_pass_msg=4567;
var _gz_wps_enable=4568;
var _gz_wps_deny=4569;
var bwl_ht204080=4570;
var _supp_close=4571;
var bwl_Mode_ac=4572;
var bwl_Mode_acn=4573;
var bwl_Mode_acna=4574;
var _wireless_2=4575;
var _wireless_5=4576;
var _WPS=4577;
var _statlst=4578;
var _wifiser_title=4579;
var _wifiser_title0=4580;
var _wifiser_title1=4581;
var _wifiser_mode0=4582;
var _wifiser_mode1=4583;
var _wifiser_mode2=4584;
var _wifiser_mode3=4585;
var _wifiser_mode4=4586;
var _wifiser_mode5=4587;
var _wifiser_mode6=4588;
var _wifiser_mode7=4589;
var _wifiser_mode8=4590;
var _wifiser_mode9=4591;
var _wifiser_mode10=4592;
var _wifiser_mode11=4593;
var _wifiser_mode12=4594;
var _wifiser_mode13=4595;
var _wifiser_mode14=4596;
var _wifiser_mode15=4597;
var _wifiser_mode16=4598;
var _wifiser_mode17=4599;
var _wifiser_mode18=4600;
var _wifiser_mode19=4601;
var _wifiser_mode20=4602;
var _wifiser_mode21=4603;
var _wifiser_mode22=4604;
var _wifiser_mode23=4605;
var _wifiser_mode24=4606;
var _wifiser_mode25=4607;
var _wifiser_mode26=4608;
var _wifiser_mode27=4609;
var _wifiser_mode28=4610;
var _wifiser_mode29=4611;
var _wifiser_mode30=4612;
var _wifiser_mode31=4613;
var _wifiser_mode32=4614;
var _wifiser_mode33=4615;
var _wifiser_mode34=4616;
var _wifiser_mode35=4617;
var _wifiser_mode36=4618;
var _wifiser_mode37=4619;
var _wifiser_mode38=4620;
var _wifiser_mode39=4621;
var _wifiser_mode40=4622;
var _wifiser_mode41=4623;
var _adv_txt_00=4624;
var _adv_txt_01=4625;
var _adv_txt_02=4626;
var _adv_txt_03=4627;
var _adv_txt_04=4628;
var _adv_txt_05=4629;
var _adv_txt_06=4630;
var _adv_txt_07=4631;
var _adv_txt_08=4632;
var _adv_txt_09=4633;
var _adv_txt_10=4634;
var _adv_txt_11=4635;
var _adv_txt_12=4636;
var _adv_txt_13=4637;
var _adv_txt_14=4638;
var _adv_txt_15=4639;
var _adv_txt_16=4640;
var _adv_txt_17=4641;
var _adv_txt_18=4642;
var _adv_txt_19=4643;
var _adv_txt_20=4644;
var _adv_txt_21=4645;
var _adv_txt_22=4646;
var _network=4647;
var _management=4648;
var _upload_firm=4649;
var _settings_management=4650;
var _time_cap=4651;
var _system_log=4652;
var _ipv6_status=4653;
var _alg=4654;
var _wan_setting=4655;
var _lan_setting=4656;
var _ipv6_setting=4657;
var _top=4658;
var _network_help=4659;
var _qos_help=4660;
var _wireless_help=4661;
var _administrator_help=4662;
var _wan_conn_type=4663;
var _help_txt2=4664;
var _static=4665;
var _help_txt1=4666;
var _help_txt4=4667;
var _help_txt6=4668;
var _help_txt7=4669;
var _help_txt9=4670;
var _help_txt10=4671;
var _help_txt11=4672;
var _help_txt12=4673;
var _help_txt13=4674;
var _help_txt14=4675;
var _help_txt16=4676;
var _help_txt17=4677;
var _help_txt18=4678;
var _help_txt19=4679;
var _help_txt20=4680;
var _help_txt21=4681;
var _help_txt22=4682;
var _help_txt24=4683;
var _help_txt25=4684;
var _help_txt27=4685;
var _help_txt28=4686;
var _help_txt29=4687;
var _help_txt30=4688;
var _help_txt31=4689;
var _help_txt32=4690;
var _help_txt33=4691;
var _help_txt34=4692;
var _help_txt35=4693;
var _help_txt36=4694;
var _help_txt37=4695;
var _help_txt38=4696;
var _help_txt39=4697;
var _help_txt41=4698;
var _help_txt43=4699;
var _help_txt45=4700;
var _help_txt47=4701;
var _help_txt48=4702;
var _help_txt50=4703;
var _help_txt51=4704;
var _help_txt52=4705;
var _help_txt54=4706;
var _help_txt56=4707;
var _help_txt58=4708;
var _help_txt59=4709;
var _help_txt60=4710;
var _help_txt62=4711;
var _help_txt64=4712;
var _help_txt66=4713;
var _help_txt67=4714;
var _help_txt69=4715;
var _help_txt71=4716;
var _help_txt73=4717;
var _help_txt85=4718;
var _help_txt87=4719;
var _help_txt82=4720;
var _help_txt83=4721;
var _help_txt84=4722;
var _help_txt85=4723;
var _help_txt89=4724;
var _help_txt90=4725;
var _help_txt91=4726;
var _help_txt93=4727;
var _help_txt94=4728;
var _help_txt95=4729;
var _help_txt96=4730;
var _help_txt97=4731;
var _help_txt98=4732;
var _help_txt99=4733;
var _help_txt100=4734;
var _help_txt101=4735;
var _help_txt102=4736;
var _help_txt103=4737;
var _help_txt104=4738;
var _help_txt105=4739;
var _help_txt106=4740;
var _help_txt107=4741;
var _help_txt108=4742;
var _help_txt109=4743;
var _help_txt110=4744;
var _help_txt111=4745;
var _help_txt113=4746;
var _help_txt114=4747;
var _help_txt115=4748;
var _help_txt116=4749;
var _help_txt117=4750;
var _help_txt121=4751;
var _help_txt122=4752;
var _help_txt123=4753;
var _help_txt124=4754;
var _help_txt125=4755;
var _help_txt126=4756;
var _help_txt127=4757;
var _help_txt128=4758;
var _help_txt129=4759;
var _help_txt130=4760;
var _help_txt131=4761;
var _help_txt132=4762;
var _help_txt133=4763;
var _help_txt134=4764;
var _help_txt135=4765;
var _help_txt136=4766;
var _help_txt137=4767;
var _help_txt138=4768;
var _help_txt139=4769;
var _help_txt140=4770;
var _help_txt141=4771;
var _help_txt142=4772;
var _help_txt143=4773;
var _help_txt144=4774;
var _help_txt145=4775;
var _help_txt146=4776;
var _help_txt147=4777;
var _help_txt148=4778;
var _help_txt149=4779;
var _help_txt150=4780;
var _help_txt151=4781;
var _help_txt152=4782;
var _help_txt153=4783;
var _help_txt154=4784;
var _help_txt155=4785;
var _help_txt156=4786;
var _help_txt157=4787;
var _help_txt158=4788;
var _help_txt159=4789;
var _help_txt160=4790;
var _help_txt161=4791;
var _help_txt162=4792;
var _help_txt163=4793;
var _help_txt164=4794;
var _help_txt165=4795;
var _help_txt166=4796;
var _help_txt167=4797;
var _help_txt168=4798;
var _help_txt169=4799;
var _help_txt170=4800;
var _help_txt171=4801;
var _help_txt172=4802;
var _help_txt173=4803;
var _help_txt174=4804;
var _help_txt175=4805;
var _help_txt176=4806;
var _help_txt177=4807;
var _help_txt178=4808;
var _help_txt179=4809;
var _help_txt180=4810;
var _help_txt181=4811;
var _help_txt182=4812;
var _help_txt183=4813;
var _help_txt184=4814;
var _help_txt185=4815;
var _help_txt186=4816;
var _help_txt187=4817;
var _help_txt188=4818;
var _help_txt189=4819;
var _help_txt190=4820;
var _help_txt191=4821;
var _help_txt192=4822;
var _help_txt193=4823;
var _help_txt194=4824;
var _help_txt195=4825;
var _help_txt196=4826;
var _help_txt197=4827;
var _help_txt198=4828;
var _help_txt199=4829;
var _help_txt200=4830;
var _help_txt201=4831;
var _help_txt202=4832;
var _help_txt203=4833;
var _help_txt204=4834;
var _help_txt205=4835;
var _help_txt206=4836;
var _help_txt207=4837;
var _help_txt208=4838;
var _help_txt209=4839;
var _help_txt210=4840;
var _help_txt211=4841;
var _help_txt212=4842;
var _help_txt213=4843;
var _help_txt214=4844;
var _help_txt215=4845;
var _help_txt216=4846;
var _help_txt217=4847;
var _help_txt218=4848;
var _help_txt219=4849;
var _help_txt220=4850;
var _help_txt221=4851;
var _help_txt222=4852;
var _help_txt223=4853;
var _help_txt224=4854;
var _help_txt225=4855;
var _help_txt226=4856;
var _help_txt227=4857;
var _help_txt228=4858;
var _help_txt229=4859;
var _help_txt230=4860;
var _help_txt231=4861;
var _help_txt232=4862;
var _help_txt233=4863;
var _help_txt234=4864;
var _help_txt235=4865;
var _help_txt236=4866;
var _help_txt237=4867;
var _help_txt238=4868;
var _help_txt239=4869;
var _help_txt240=4870;
var _help_txt241=4871;
var _help_txt242=4872;
var _help_txt243=4873;
var _help_txt244=4874;
var _help_txt245=4875;
var _help_txt246=4876;
var _help_txt247=4877;
var _help_txt248=4878;
var _help_txt249=4879;
var _help_txt250=4880;
var _help_txt251=4881;
var _help_txt252=4882;
var _help_txt253=4883;
var _help_txt254=4884;
var _help_txt255=4885;
var _help_txt256=4886;
var _help_txt257=4887;
var _help_txt258=4888;
var _help_txt259=4889;
var _help_txt260=4890;
var _help_txt261=4891;
var _help_txt262=4892;
var _help_txt263=4893;
var _help_txt264=4894;
var _help_txt265=4895;
var _help_txt266=4896;
var _help_txt267=4897;
var _help_txt268=4898;
var _help_txt269=4899;
var _help_txt270=4900;
var _help_txt271=4901;
var _help_txt272=4902;
var _help_txt273=4903;
var _help_txt274=4904;
var _help_txt275=4905;
var _help_txt276=4906;
var _help_txt277=4907;
var _help_txt278=4908;
var _help_txt279=4909;
var _help_txt280=4910;
var _help_txt281=4911;
var _help_txt282=4912;
var _help_txt283=4913;
var _help_txt284=4914;
var _help_txt285=4915;
var _help_txt286=4916;
var _help_txt287=4917;
var _help_txt288=4918;
var _help_txt289=4919;
var _help_txt290=4920;
var _help_txt291=4921;
var _help_txt292=4922;
var _help_txt293=4923;
var _help_txt294=4924;
var _help_txt295=4925;
var _help_txt296=4926;
var _help_txt297=4927;
var _help_txt298=4928;
var _adv_txt_23=4929;
var _adv_txt_24=4930;
var _adv_txt_25=4931;
var _adv_txt_26=4932;
var _adv_txt_27=4933;
var _net_ipv6_01=4934;
var _net_ipv6_02=4935;
var _net_ipv6_03=4936;
var _net_ipv6_04=4937;
var _net_ipv6_05=4938;
var _net_ipv6_06=4939;
var _net_ipv6_07=4940;
var _net_ipv6_08=4941;
var _net_ipv6_09=4942;
var _net_ipv6_10=4943;
var _net_ipv6_11=4944;
var _net_ipv6_12=4945;
var _qos_txt00=4946;
var _qos_txt01=4947;
var _qos_txt02=4948;
var _qos_txt03=4949;
var _qos_txt04=4950;
var _qos_txt05=4951;
var _qos_txt06=4952;
var _qos_txt07=4953;
var _qos_txt08=4954;
var _qos_txt09=4955;
var _qos_txt10=4956;
var _qos_txt11=4957;
var _qos_txt12=4958;
var _qos_txt13=4959;
var _qos_txt14=4960;
var _qos_txt15=4961;
var _qos_txt16=4962;
var _qos_txt17=4963;
var _qos_txt18=4964;
var _qos_txt19=4965;
var _qos_txt20=4966;
var _qos_txt21=4967;
var _qos_txt22=4968;
var _qos_txt23=4969;
var _qos_txt24=4970;
var _qos_txt25=4971;
var _qos_txt26=4972;
var _qos_txt27=4973;
var _qos_txt28=4974;
var _qos_txt29=4975;
var _qos_txt30=4976;
var _qos_txt31=4977;
var _qos_txt32=4978;
var _qos_txt33=4979;
var _qos_txt34=4980;
var _qos_txt35=4981;
var _qos_txt36=4982;
var _qos_txt37=4983;
var _qos_txt38=4984;
var _qos_txt39=4985;
var _qos_txt40=4986;
var _qos_txt41=4987;
var _qos_txt42=4988;
var _qos_txt43=4989;
var _qos_txt44=4990;
var _qos_txt45=4991;
var _qos_txt46=4992;
var _basic_wireless_settings=4993;
var _desc_basic=4994;
var _desc_station_list=4995;
var _desc_wps=4996;
var _wireless_network=4997;
var _wds_long=4998;
var _wps_config=4999;
var _wps_summary=5000;
var _wps_action=5001;
var _dhcp_clients=5002;
var _desc_wps_action=5003;
var _lb_radio_onoff=5004;
var _lb_radio_off_sche=5005;
var _wmode_ssid=5006;
var _lb_multi_ssid_1=5007;
var _lb_multi_ssid_2=5008;
var _lb_multi_ssid_3=5009;
var _lb_multi_ssid_4=5010;
var _lb_multi_ssid_5=5011;
var _lb_multi_ssid_6=5012;
var _lb_multi_ssid_7=5013;
var _lb_broadcast_ssid=5014;
var _lb_phy_mode=5015;
var _lb_enc_type=5016;
var _lb_enc_key=5017;
var _lb_apmacaddr=5018;
var _lb_coexistence=5019;
var _lb_rdg=5020;
var _lb_mcs=5021;
var _lb_exten_channel=5022;
var _lb_a_msdu=5023;
var _lb_autoba=5024;
var _lb_declineba=5025;
var _lb_forty_into=5026;
var _lb_wifi_opt=5027;
var _lb_ht_txstream=5028;
var _lb_ht_rxstream=5029;
var _lb_wps_ext_reg_lock=5030;
var _sel_autoselect=5031;
var _sel_mixed=5032;
var _sel_greenfield=5033;
var _long=5034;
var _btn_radio_on=5035;
var _btn_radio_off=5036;
var _MSG_woff=5037;
var _desc_advanced=5038;
var _bx_advanced_2=5039;
var _bx_advanced_3=5040;
var _bx_advanced_4=5041;
var _lb_bg_protection=5042;
var _hint_beacon=5043;
var _hint_dtim=5044;
var _lb_frag_thres=5045;
var _hint_frag_thres=5046;
var _hint_rts_thres=5047;
var _lb_txpower=5048;
var _lb_short_preamble=5049;
var _lb_short_slot=5050;
var _lb_tx_burst=5051;
var _lb_pkt_aggregate=5052;
var _lb_80211h_support=5053;
var _hint_only_a_band=5054;
var _lb_country_code=5055;
var _lb_wmm_capable=5056;
var _lb_apsd_capable=5057;
var _lb_dls_capable=5058;
var _lb_wmm_param=5059;
var _lb_wmm_config=5060;
var _lb_video_turbine=5061;
var _lb_multi_uni=5062;
var _lb_expire_in=5063;
var _pwr_full=5064;
var _pwr_half=5065;
var _pwr_low=5066;
var _tl_wmm_settings=5067;
var _lb_wmm_param_ap=5068;
var _lb_wmm_param_station=5069;
var m_bwl_Mode_3=5070;
var m_bwl_Mode_8=5071;
var m_bwl_Mode_11=5072;
var m_bwl_Mode5_1=5073;
var m_bwl_Mode5_2=5074;
var m_bwl_Mode5_3=5075;
var _singal=5076;
var _bssid=5077;
var _wps_cur_state=5078;
var _wps_configed=5079;
var _wps_ssid=5080;
var _wps_sec_mode=5081;
var _wps_enc_type=5082;
var _wps_def_key_idx=5083;
var _hex=5084;
var _ascii=5085;
var _wps_key=5086;
var _ap_pin=5087;
var _desc_dhcp_client_list=5088;
var _wifiser_mode42=5089;
var _processing=5090;
var _netwrk_status_addr=5091;
var _system_info=5092;
var _system_time=5093;
var _system_up_time=5094;
var _internet_configs=5095;
var _connected_type=5096;
var _wan_ip_addr=5097;
var _pri_dns=5098;
var _sec_dns=5099;
var _24Ghz_wireless=5100;
var _5Ghz_wireless=5101;
var _SYSLOG_DESC=5102;
var _enable_system_log=5103;
var _time_setting=5104;
var _TIME_DESC=5105;
var _daylight_saving_time=5106;
var _ntp_settings=5107;
var _ntp_server=5108;
var _ntp_sync=5109;
var _date_time_settings=5110;
var _SETTINGS_MANAGER_DESC=5111;
var _export=5112;
var _settings_file_location=5113;
var _import=5114;
var _upgrade_firmw=5115;
var _FIRMW_DESC=5116;
var _FIRMW_DESC_sub=5117;
var _location=5118;
var _apply=5119;
var _system_management=5120;
var _SYS_MANGER_DESC=5121;
var _max_length_characters=5122;
var _device_url_settings=5123;
var _device_url=5124;
var _device_name_settings=5125;
var _ddns_settings=5126;
var _remote_management=5127;
var _remote_control_via_wan=5128;
var _remote_port=5129;
var _reset=5130;
var _ADV_NETWRK_DESC=5131;
var _wan_ping_respond=5132;
var _schedule_rules=5133;
var _SCHEDULE_DESC=5134;
var _add_sche_rule=5135;
var _tsc_allday_24hr=5136;
var _schedule_rule_list=5137;
var _time_stamp=5138;
var _24hr=5139;
var m_bwl_Mode5_4=5140;
var _routing_bet_zone=5141;
var _mac_clone=5142;
var _mac_addr_clone=5143;
var _dns_server_setting=5144;
var _dhcp_setting=5145;
var _DHCP_DESC=5146;
var _wan_setting_l=5147;
var _mtu_default_byte=5148;
var _wan_if_ip_setting=5149;
var _opeartion_mode=5150;
var _keep_alive=5151;
var _keep_alive_mode_redial=5152;
var _on_demand_mode_idle_time=5153;
var _mintues_lower=5154;
var _l2tp_setting=5155;
var _pptp_setting=5156;
var _dynamic=5157;
var _lan_setting_l=5158;
var _LAN_DESC=5159;
var _dhcp_server_setting=5160;
var _dhcp_start_ip=5161;
var _dhcp_end_ip=5162;
var _other_setting=5163;
var _8021d_spanning_tree=5164;
var _lltd=5165;
var _igmp_proxy=5166;
var _pppoe_relay=5167;
var _dns_proxy=5168;
var _add_dhcp_reservation=5169;
var _copy_pc_mac=5170;
var _copy=5171;
var _dhcp_reservation_ready_group=5172;
var _edit_dhcp_reservation=5173;
var _delete_all=5174;
var _delete_selected=5175;
var _config_via_pin=5176;
var _config_via_pbc=5177;
var _alg_config_l=5178;
var _ALG_DESC=5179;
var _description=5180;
var _email_receiving=5181;
var _pop3_l=5182;
var _smtp_l=5183;
var _streaming_media=5184;
var _rtp_l=5185;
var _rtsp_1=5186;
var _mms_l=5187;
var _streaming_media_voip=5188;
var _session_init_protocol_l=5189;
var _h323_l=5190;
var _file_transfer=5191;
var _ftp_l=5192;
var _tftp_l=5193;
var _remote_control=5194;
var _telnet=5195;
var _instant_messaging=5196;
var _msn_messenger=5197;
var _ipsec=5198;
var _save_status=5199;
var _dmz_settings=5200;
var _DMZ_DESC=5201;
var _AC_DESC=5202;
var _add_port_block_rule=5203;
var _policy_enable=5204;
var _policy_name=5205;
var _client_ip_addr=5206;
var _rule_define=5207;
var _special_service=5208;
var _user_define=5209;
var _tcp_ports=5210;
var _ex_21_or_3_500=5211;
var _udp_ports=5212;
var _service=5213;
var _edit_port_block_rule=5214;
var _port_block_rule=5215;
var _add_ip_block_rule=5216;
var _edit_ip_block_rule=5217;
var _ip_block_rule_list=5218;
var _add_weburl_rule=5219;
var _edit_weburl_rule=5220;
var _weburl_rule_list=5221;
var _email_sending=5222;
var _file_transfer_l=5223;
var _telnet_service=5224;
var _dns_query=5225;
var _tcp_protocol=5226;
var _udp_protocol=5227;
var _www=5228;
var _err_ip_addr_format=5229;
var _err_ip_mask=5230;
var _err_input_format=5231;
var _err_ip_addr=5232;
var _static_routing_settings=5233;
var _ROUTING_DESC=5234;
var _add_static_route=5235;
var _dest_ip_addr=5236;
var _dest_ip_mask=5237;
var _physical_port=5238;
var _enable_rip=5239;
var _rip_mode=5240;
var _static_route_list=5241;
var _processing_plz_wait=5242;
var _rebooting_plz_wait=5243;
var _L2TPgw=5244;
var _retry=5245;
var _skip=5246;
var _chk_wanconn_msg_00=5247;
var _tnw_01=5248;
var _tnw_02=5249;
var _tnw_03=5250;
var _tnw_04=5251;
var _ssid=5252;
var _auth_type=5253;
var _finish=5254;
var _tnw_05=5255;
var _tnw_dhcp=5256;
var _tnw_static=5257;
var _tnw_pppoe=5258;
var _tnw_pptp=5259;
var _tnw_l2tp=5260;
var _tnw_06=5261;
var _mac=5262;
var _tnw_clone=5263;
var _tnw_07=5264;
var _wan_ipaddr=5265;
var _wan_submask=5266;
var _wan_gwaddr=5267;
var _dns_1=5268;
var _dns_2=5269;
var _tnw_08=5270;
var _tnw_09=5271;
var _my_ip=5272;
var _server_ip=5273;
var _pptp_account=5274;
var _pptp_password=5275;
var _pptp_password_re=5276;
var _tnw_10=5277;
var _l2tp_account=5278;
var _l2tp_password=5279;
var _l2tp_password_re=5280;
var _tnw_11=5281;
var _tnw_12=5282;
var _tnw_13=5283;
var _tnw_14=5284;
var _print=5285;
var _TAG00840=5286;
var IPV6_TEXT171=5287;
var IPV6_TEXT172=5288;
var _wps_shared=5289;
var _wps_open=5290;
var _webfilterrule_dup=5291;
var _wps_24g=5292;
var _wps_5g=5293;
var _name_ssid=5294;
var _warranty=5295;
var _usb=5296;
var _samba_server=5297;
var _ftp_server=5298;
var _print_server=5299;
var _connected_devices=5300;
var _guest_network=5301;
var _guest_text1=5302;
var _network_bridge=5303;
var _inet_access_only=5304;
var _security_no=5305;
var _security_low=5306;
var _security_middle=5307;
var _security_high=5308;
var _parental_control=5309;
var _has_inet_connection=5310;
var _no_inet_connection=5311;
var _guest_network_enabled=5312;
var _guest_network_disabled=5313;
var _usb_connected=5314;
var _no_usb_connected=5315;
var _household_access=5316;
var _confirm_settings=5317;
var _check_connection=5318;
var _address=5319;
var _ha_rule_list=5320;
var _add_ha_rule=5321;
var _edit_ha_rule=5322;
var _wlan_11n_not_support_wep_wpa_tkip=5323;
var _lb_radio_on_sche=5324;
var _rule_full=5325;
var _wds_cant_enble=5326;
var _LAN_CHK_REBOOT_MSG=5327;
var _specify_url=5328;
var _ipaddr_used=5329;
var _macaddr_used=5330;
var _lan_dr=5331;
var _adv_rtd=5332;
var _lb_a_mpdu=5333;
var PRODUCT_DESC_810=5334;
var PRODUCT_DESC_817=5335;
var _ipaddr_used=5336;
var _macaddr_used=5337;
var no_wan_up=5338;
var dev_mode_ap=5339;
var dev_mode_repeater=5340;
var dev_mode_wisp=5341;
var ap_client=5342;
var extend_ssid=5343;
var wlan_client_list=5344;
var desc_ap=5345;
var desc_repeater=5346;
var desc_wisp=5347;
var wiz_select_site=5348;
var wiz_refresh_site=5349;
var wiz_no_result=5350;
var wiz_no_selected=5351;
var wiz_quit=5352;
var custom_range=5353;
var _internet_setting=5354;
var desc_static_ipv6=5355;
var _s_packet=5356;
var _wps_lock=5357;
var pptp_passthrough=5358;
var l2tp_passthrough=5359;
var desc_ap_lan=5360;
var attain_ip=5361;
var dev_stat=5362;
var desc_ap_sch=5363;
