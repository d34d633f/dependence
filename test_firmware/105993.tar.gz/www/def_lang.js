//Version=1.01b01
//Language=ENGLISH
//Date=Tue, 24, Feb, 2015
//Merged=FALSE
//Merged Fw=FALSE
var msg = new Array ( //
	"The IP Address entered is invalid", //INVALID_IP_ADDRESS
	"The IP Address cannot be zero.", //ZERO_IP_ADDRESS
	"IP Address", //IP_ADDRESS_DESC
	"The Subnet Mask entered is invalid", //INVALID_MASK_ADDRESS
	"The Subnet Mask can not be zero.", //ZERO_MASK_ADDRESS
	"Subnet Mask", //MASK_ADDRESS_DESC
	"The Gateway IP Address entered is invalid", //INVALID_GATEWAY_ADDRESS
	"The Gateway IP Address cannot be zero", //ZERO_GATEWAY_ADDRESS
	"Gateway IP Address", //GATEWAY_ADDRESS_DESC
	"%s Gateway IP address %s must be within the WAN subnet.", //NOT_SAME_DOMAIN
	"The Starting IP Address entered is invalid (IP Range: 1~254)", //INVALID_START_IP
	"Please enter another SMTP Server or IP Address", //SMTP_SERVER_ERROR
	"Starting IP Address", //START_IP_DESC
	"The LAN IP Address and the Start IP Address are not in the same subnet", //START_INVALID_DOMAIN
	"The Ending IP Address entered is invalid.", //INVALID_END_IP
	"Please enter another Domain", //DOMAIN_ERROR
	"The LAN IP Address and the End IP Address are not in the same subnet", //END_INVALID_DOMAIN
	"The Primary DNS Address entered is invalid", //INVALID_DNS_ADDRESS
	"The Primary DNS Address cannot be zero", //ZERO_DNS_ADDRESS
	"Primary DNS Address", //DNS_ADDRESS_DESC
	"The SSID field can not be blank", //SSID_EMPTY_ERROR
	"WEP cannot be disabled when the Authentication type is set to Shared Key", //AUTH_TYPE_ERROR
	"The length of the Passphrase must be at least 8 characters", //PSK_LENGTH_ERROR
	"The Confirmed Passphrase does not match the Passphrase", //PSK_MATCH_ERROR
	"The Confirmed Password does not match the New Password", //MATCH_PWD_ERROR
	"The selected WEP key field cannot be blank", //WEP_KEY_EMPTY
	"Please enter another IP Address", //ZERO_STATIC_DHCP_IP
	"Quit setup wizard and discard settings?", //QUIT_WIZARD
	"The MAC Address entered is invalid.", //MAC_ADDRESS_ERROR
	"The Ending IP Address must be greater than the Starting IP Address", //IP_RANGE_ERROR
	"The Secondary DNS Address entered is invalid", //INVALID_SEC_DNS_ADDRESS
	"The Secondary DNS Address cannot be zero", //ZERO_SEC_DNS_ADDRESS
	"Secondary DNS Address", //SEC_DNS_ADDRESS_DESC
	"The confirmed password does not match the new Admin password", //ADMIN_PASS_ERROR
	"The confirmed password does not match the new User password", //USER_PASS_ERROR
	"The Host Name is invalid!", //DDNS_HOST_ERROR
	"Please enter another Starting IP Address", //ZERO_START_IP
	"Are you sure you want to reset the device to its factory default settings?\nThis will cause all current settings to be lost.", //RESTORE_DEFAULT
	"Are you sure you want to reboot the device?\nRebooting will disconnect any active internet sessions.", //REBOOT_ROUTER
	"Load settings from a saved configuration file?", //LOAD_SETTING
	"You must enter the name of a configuration file first.", //LOAD_FILE_ERROR
	"Please enter at least one Control Domain", //CONTROL_DOMAIN_ERROR
	"Please enter another Server Name", //DDNS_SERVER_ERROR
	"Are you sure that you want to delete this Virtual Server Rule?", //DEL_SERVER_MSG
	"Are you sure that you want to delete this Application Rule", //DEL_APPLICATION_MSG
	"Are you sure that you want to delete this Filter?", //DEL_FILTER_MSG
	"Are you sure that you want to delete this Route?", //DEL_ROUTE_MSG
	"Are you sure that you want to delete this MAC Address?", //DEL_MAC_MSG
	"Are you sure that you want to delete this Keyword?", //DEL_KEYWORD_MSG
	"Are you sure that you want to delete this Domain?", //DEL_DOMAIN_MSG
	"Are you sure that you want to delete this Entry?", //DEL_ENTRY_MSG
	"Are you sure that you want to delete this DHCP Reservation?", //DEL_STATIC_DHCP_MSG
	"Please enter another port number", //PORT_ERROR
	"Please enter another Permitted Domain", //PERMIT_DOMAIN_ERROR
	"Please select a Firmware file to upgrade the router to", //FIRMWARE_UPGRADE_ERROR
	"The Keyword entered already exists in the list", //SAME_KEYWORD_ERROR
	"Please enter another Key", //WIZARD_KEY_EMPTY
	"Unable to add another Keyword", //ADD_KEYWORD_ERROR
	"Please select a machine first", //SELECT_MACHINE_ERROR
	"The Domain entered already exists in the list of Blocked Domains", //SAME_BLOCK_DOMAIN
	"Unable to add another Blocked Domain", //ADD_BLOCK_DOMAIN_ERROR
	"The Domain entered already exists in the list of Permitted Domains", //SAME_PERMIT_DOMAIN
	"Please enter another Password", //DDNS_PASS_ERROR
	"Unable to add another Permitted Domain", //ADD_PERMIT_DOMAIN_ERROR
	"Please enter another Blocked Domain", //BLOCK_DOMAIN_ERROR
	"Unable to add another Control Domains", //ADD_CONTROL_DOMAIN_ERROR
	"Please enter another Wireless Security Password", //SECURITY_PWD_ERROR
	"The RADIUS Server 1 IP Address entered is invalid", //INVALID_RADIUS_SERVER1_IP
	"The Radius Server 1 IP Address cannot be zero or blank", //ZERO_RADIUS_SERVER1_IP
	"Radius Server 1 IP Address", //RADIUS_SERVER1_IP_DESC
	"The RADIUS Server 2 IP Address entered is invalid", //INVALID_RADIUS_SERVER2_IP
	"The Radius Server 2 IP Address cannot be zero or blank", //ZERO_RADIUS_SERVER2_IP
	"Radius Server 2 IP Address", //RADIUS_SERVER2_IP_DESC
	"The IP Address entered is invalid (IP Range: 1~254)", //INVALID_STATIC_DHCP_IP
	"Please enter another Ending IP Address", //ZERO_END_IP
	"Please enter another name", //NAME_ERROR
	"The Server IP Address entered is invalid", //INVALID_SERVER_IP
	"The Server IP Address cannot be zero or blank", //ZERO_SERVER_IP
	"Server IP Address", //SERVER_IP_DESC
	"The Passwords entered do not match", //MATCH_WIZARD_PWD_ERROR
	"The Source Start IP Address entered is invalid", //INVALID_SOURCE_START_IP
	"The Source Start IP Address cannot be zero or blank", //ZERO_SOURCE_START_IP
	"Source Start IP Address", //SOURCE_START_IP_DESC
	"The Source End IP Address entered is invalid", //INVALID_SOURCE_END_IP
	"The Source End IP Address cannot be zero or blank", //ZERO_SOURCE_END_IP
	"Source End IP Address", //SOURCE_END_IP_DESC
	"The Destination Start IP Address entered is invalid", //INVALID_DEST_START_IP
	"The Destination Start IP Address cannot be zero or blank", //ZERO_DEST_START_IP
	"Destination Start IP Address", //DEST_START_IP_DESC
	"The Destination End IP Address entered is invalid", //INVALID_DEST_END_IP
	"The Destination End IP Address cannot be zero or blank", //ZERO_DEST_END_IP
	"Destination End IP Address", //DEST_END_IP_DESC
	"The length of the Passphrase must be between 8 and 63 characters", //PSK_OVER_LEN
	"Reset JumpStart?", //RESET_JUMPSTAR
	"Are you sure that you want to delete this rule?", //DEL_RULE_MSG
	"Are you sure that you want to delete this schedule?", //DEL_SCHEDULE_MSG
	"Unable to add another schedule", //ADD_SCHEDULE_ERROR
	"Schedule Name can not empty", //SCHEDULE_NAME_ERROR
	"Schedule Name can not enter all space", //SCHEDULE_NAME_SPACE_ERROR
	"The Start Time entered is invalid", //START_TIME_ERROR
	"The End Time entered is invalid", //END_TIME_ERROR
	"The Start Time cannot be greater than the End Time", //TIME_RANGE_ERROR
	"Please select a Keyword to delete", //DEL_KEYWORD_ERROR
	"Please select a Permitted Domain to delete", //DEL_PERMIT_DOMAIN_ERROR
	"Please select a Blocked Domain to delete", //DEL_BLOCK_DOMAIN_ERROR
	"The Parental Control rule entered is already in the list", //DUPLICATE_URL_ERROR
	"Login Name error", //LOGIN_NAME_ERROR
	"Login Password error", //LOGIN_PASS_ERROR
	"%s is conflicted with LAN IP address, please enter again.", //THE_SAME_LAN_IP
	"The PSK should Hex.", //THE_PSK_IS_HEX
	"The IP Address and the reservation IP Address are not in the same subnet.", //SER_NOT_SAME_DOMAIN
	"There is unsaved data on this page. Do you want to abandon it?%s If not, press Cancel and then click Save Settings.%s If so, press Ok.", //IS_CHANGE_DATA
	"The confirmed password does not match the new User password", //DDNS_PASS_ERROR_MARTH
	"Rule name can not be empty string", //INBOUND_NAME_ERROR
	"The Ending Port number must be greater than the Starting Port number", //PORT_RANGE_ERROR
	"Are you sure that you want to enable/disable", //CHECK_ENABLE
	"Are you sure that you want to delete ?", //DEL_MSG
	"You must abandon all your changes in order to define a new schedule.\n Press 'Ok' to abandon these changes and display the Schedule page.\n Otherwise press 'Cancel'.", //GO_SCHEDULE
	"Please enter user name", //PPP_USERNAME_EMPTY
	"Nothing has changed, save anyway?", //FORM_MODIFIED_CHECK
	"Please select an Application Name first", //SELECT_APPLICATION_ERROR
	"Please select a Computer Name first", //SELECT_COMPUTER_ERROR
	"Please enter another Name", //STATIC_DHCP_NAME
	"Please select a Control Domain to delete", //DEL_CONTROL_DOMAIN_ERROR
	"Please enter another Keyword", //KEYWORD_ERROR
	"Please enter a Private IP Address.", //PRIVATE_IP_ERROR
	"Please enter a Firewall Port number", //PUBLIC_PORT_ERROR
	"Please enter a Trigger Port number", //TRIGGER_PORT_ERROR
	"Please enter a valid email Address", //EMAIL_ADDRESS_ERROR
	"Please enter either a Host Name or an IP Address", //PING_IP_ERROR
	"Only the Admin account can download the settings", //DOWNLOAD_SETTING_ERROR
	"Please enter another User Name", //DDNS_USER_ERROR
	"Ending IP Address", //END_IP_DESC
	"" //MAX
);
var INVALID_IP_ADDRESS=0;
var ZERO_IP_ADDRESS=1;
var IP_ADDRESS_DESC=2;
var INVALID_MASK_ADDRESS=3;
var ZERO_MASK_ADDRESS=4;
var MASK_ADDRESS_DESC=5;
var INVALID_GATEWAY_ADDRESS=6;
var ZERO_GATEWAY_ADDRESS=7;
var GATEWAY_ADDRESS_DESC=8;
var NOT_SAME_DOMAIN=9;
var INVALID_START_IP=10;
var SMTP_SERVER_ERROR=11;
var START_IP_DESC=12;
var START_INVALID_DOMAIN=13;
var INVALID_END_IP=14;
var DOMAIN_ERROR=15;
var END_INVALID_DOMAIN=16;
var INVALID_DNS_ADDRESS=17;
var ZERO_DNS_ADDRESS=18;
var DNS_ADDRESS_DESC=19;
var SSID_EMPTY_ERROR=20;
var AUTH_TYPE_ERROR=21;
var PSK_LENGTH_ERROR=22;
var PSK_MATCH_ERROR=23;
var MATCH_PWD_ERROR=24;
var WEP_KEY_EMPTY=25;
var ZERO_STATIC_DHCP_IP=26;
var QUIT_WIZARD=27;
var MAC_ADDRESS_ERROR=28;
var IP_RANGE_ERROR=29;
var INVALID_SEC_DNS_ADDRESS=30;
var ZERO_SEC_DNS_ADDRESS=31;
var SEC_DNS_ADDRESS_DESC=32;
var ADMIN_PASS_ERROR=33;
var USER_PASS_ERROR=34;
var DDNS_HOST_ERROR=35;
var ZERO_START_IP=36;
var RESTORE_DEFAULT=37;
var REBOOT_ROUTER=38;
var LOAD_SETTING=39;
var LOAD_FILE_ERROR=40;
var CONTROL_DOMAIN_ERROR=41;
var DDNS_SERVER_ERROR=42;
var DEL_SERVER_MSG=43;
var DEL_APPLICATION_MSG=44;
var DEL_FILTER_MSG=45;
var DEL_ROUTE_MSG=46;
var DEL_MAC_MSG=47;
var DEL_KEYWORD_MSG=48;
var DEL_DOMAIN_MSG=49;
var DEL_ENTRY_MSG=50;
var DEL_STATIC_DHCP_MSG=51;
var PORT_ERROR=52;
var PERMIT_DOMAIN_ERROR=53;
var FIRMWARE_UPGRADE_ERROR=54;
var SAME_KEYWORD_ERROR=55;
var WIZARD_KEY_EMPTY=56;
var ADD_KEYWORD_ERROR=57;
var SELECT_MACHINE_ERROR=58;
var SAME_BLOCK_DOMAIN=59;
var ADD_BLOCK_DOMAIN_ERROR=60;
var SAME_PERMIT_DOMAIN=61;
var DDNS_PASS_ERROR=62;
var ADD_PERMIT_DOMAIN_ERROR=63;
var BLOCK_DOMAIN_ERROR=64;
var ADD_CONTROL_DOMAIN_ERROR=65;
var SECURITY_PWD_ERROR=66;
var INVALID_RADIUS_SERVER1_IP=67;
var ZERO_RADIUS_SERVER1_IP=68;
var RADIUS_SERVER1_IP_DESC=69;
var INVALID_RADIUS_SERVER2_IP=70;
var ZERO_RADIUS_SERVER2_IP=71;
var RADIUS_SERVER2_IP_DESC=72;
var INVALID_STATIC_DHCP_IP=73;
var ZERO_END_IP=74;
var NAME_ERROR=75;
var INVALID_SERVER_IP=76;
var ZERO_SERVER_IP=77;
var SERVER_IP_DESC=78;
var MATCH_WIZARD_PWD_ERROR=79;
var INVALID_SOURCE_START_IP=80;
var ZERO_SOURCE_START_IP=81;
var SOURCE_START_IP_DESC=82;
var INVALID_SOURCE_END_IP=83;
var ZERO_SOURCE_END_IP=84;
var SOURCE_END_IP_DESC=85;
var INVALID_DEST_START_IP=86;
var ZERO_DEST_START_IP=87;
var DEST_START_IP_DESC=88;
var INVALID_DEST_END_IP=89;
var ZERO_DEST_END_IP=90;
var DEST_END_IP_DESC=91;
var PSK_OVER_LEN=92;
var RESET_JUMPSTAR=93;
var DEL_RULE_MSG=94;
var DEL_SCHEDULE_MSG=95;
var ADD_SCHEDULE_ERROR=96;
var SCHEDULE_NAME_ERROR=97;
var SCHEDULE_NAME_SPACE_ERROR=98;
var START_TIME_ERROR=99;
var END_TIME_ERROR=100;
var TIME_RANGE_ERROR=101;
var DEL_KEYWORD_ERROR=102;
var DEL_PERMIT_DOMAIN_ERROR=103;
var DEL_BLOCK_DOMAIN_ERROR=104;
var DUPLICATE_URL_ERROR=105;
var LOGIN_NAME_ERROR=106;
var LOGIN_PASS_ERROR=107;
var THE_SAME_LAN_IP=108;
var THE_PSK_IS_HEX=109;
var SER_NOT_SAME_DOMAIN=110;
var IS_CHANGE_DATA=111;
var DDNS_PASS_ERROR_MARTH=112;
var INBOUND_NAME_ERROR=113;
var PORT_RANGE_ERROR=114;
var CHECK_ENABLE=115;
var DEL_MSG=116;
var GO_SCHEDULE=117;
var PPP_USERNAME_EMPTY=118;
var FORM_MODIFIED_CHECK=119;
var SELECT_APPLICATION_ERROR=120;
var SELECT_COMPUTER_ERROR=121;
var STATIC_DHCP_NAME=122;
var DEL_CONTROL_DOMAIN_ERROR=123;
var KEYWORD_ERROR=124;
var PRIVATE_IP_ERROR=125;
var PUBLIC_PORT_ERROR=126;
var TRIGGER_PORT_ERROR=127;
var EMAIL_ADDRESS_ERROR=128;
var PING_IP_ERROR=129;
var DOWNLOAD_SETTING_ERROR=130;
var DDNS_USER_ERROR=131;
var END_IP_DESC=132;

var which_lang = new Array ( //
	"When feature is enabled, your internet traffic will be protected by a security ready DNS server. This feature provides Anti-Phishing to protect your Internet connection from fraud and navigation improvements such as auto-correction of common URL typos.", //_Advanced_01
	"Although Advanced DNS feature is enabled, DNS IP address of your workstation can still be modified to the DNS server IP you desire. Please note that the router does not dictate the DNS name resolution when DNS IP address is configured on the workstation.", //_Advanced_03
	"If you selected this option and have VPN or Intranet setup in your network, you can disable Advanced DNS service if you experience connection difficulties.", //_Advanced_04
	"Advanced DNS Service", //bwn_ict_dns
	"Advanced DNS is a free security option that provides Anti-Phishing to protect your Internet connection from fraud and navigation improvements such as auto-correction of common URL typos.", //bwn_msg_Modes_dns
	"Enable Access Control", //aa_EAC
	"My USB type is", //new_bwn_mici_usb
	"Can't choose TKIP when 802.11n only.!!", //_tkip_11n
	"SharePort For Guest Zone", //bln_title_guest_use_shareport
	"Enable Routing Between Zones", //IPV6_TEXT3
	"Mixed 802.11n and 802.11g", //bwl_Mode_10
	"Enter the AFTR address information provided by your Internet Service Provider(ISP).", //IPV6_TEXT148
	"Regenerate", //_regenerate
	"Please enter the following settings in the device that you are adding to your wireless network and keep a note of it for future reference.", //TEXT048
	"Enable Email Notification", //te_EnEmN
	"USB 3.5G Settings", //usb3g_titile
	"APN Name", //usb3g_apn_name
	"Dial Number", //usb3g_dial_num
	"Reconnect Mode(0:always/1:OnDemand/2:Manual)", //usb3g_reconnect_mode
	"Idle Time", //usb3g_max_idle_time
	"USB DEVICE(0:3G Modem/1:KCODE)", //usb_device
	"USB 3.5G Manual", //usb3g_manual
	"USB 3.5G Statistic", //usb3g_stat_titile
	"USB Settings", //bln_title_usb
	"WCN Configuration", //usb_wcn
	"Use this section to configure your USB port. There are several configurations to choose from: Network USB, 3G USB Adapter and WCN Configuration.", //bwn_intro_usb
	"Network USB", //usb_network
	"3G USB Adapter", //usb_3g
	"Dial Number", //wwan_dial_num
	"WWAN Internet Connection Type", //bwn_wwanICT
	"Enter the email address where you want the email sent.", //help862
	"Authentication Protocol", //wwan_auth_label
	"Auto(PAP+CHAP)", //wwan_auth_auto
	"PAP issued an authentication request.", //IPPPPPAP_AUTH_ISSUE
	"CHAP only", //wwan_auth_chap
	"MS CHAP only", //wwan_auth_mschap
	"Select to share a USB printer, scanner, or storage device connected to the USB port behind the router with multiple users within your network.", //usb_network_help
	"Select 3G USB Adapter to use a 3G adapter to provide access to the Internet using an EV-DO cellular signal. Simply connect a 3G USB adapter to access the Internet (third party EV-DO subscription and available signal required).", //usb_3g_help
	"If you have trouble accessing the Internet through the router. Double check the settings you entered on this page and verify with your Internet Service Provider (ISP) if needed.", //usb_3g_help_support_help
	"Select to configure your wireless network using Windows Connect Now (WCN). WCN allows you to copy your wireless settings from the router to a USB flash drive and use to automatically configure the wireless settings on your computer(s) or other WCN-compatible devices.", //usb_wcn_help
	"My plug of USB type is", //bwn_mici_usb
	"Please set Network USB Detection interval time, the router will automatically detect the USB device.", //_info_netowrk
	"Enable Multicast Streams", //anet_multicast_enable
	"Network USB Detection interval", //bwn_usb_time
	"sec (range:3-600 sec.)", //bwn_bytes_usb
	"Can't choose shared key when WPS is enable!!", //_wps_albert_1
	"Can't choos WPA-Enterprisey when WPS is enable!!", //_wps_albert_2
	"Please configure your Internet Connection Type settings.  If you are unsure of the settings, please contact your Internet Service Provider (ISP).", //usb_config2
	"Please choose a device to apply the policy.", //ac_alert_choose_dev
	"The Internet Connection Type is not for 3G Internet connection. Please select WWAN to support 3G Internet connection.", //usb_config3
	"The Internet Connection Type is for 3G Internet connection, please select another Internet Connection Type.", //usb_config4
	"The Internet Connection Type you selected is for 3G Internet connection.  The USB settings will be changed from Network USB/WCN to 3G USB Adapter.", //usb_config5
	"The Internet Connection Type you selected is not for 3G Internet connection. The USB settings will be changed from 3G USB Adapter to Network USB.", //usb_config6
	"Choose the type of USB device to be plugged into the USB port.", //bwn_msg_usb
	"Country", //_country
	"Select your country", //_select_country
	"Select your ISP", //_select_ISP
	"Australia", //country_1
	"Italy", //country_2
	"Portugal", //country_3
	"UK", //country_4
	"Indonesia", //country_5
	"Malaysia", //country_6
	"Singapore", //country_7
	"Personals", //_aa_bsecure_personals
	"South Africa", //country_9
	"HongKong", //country_10
	"Taiwan", //country_11
	"Egypt", //country_12
	"Dominican Republic", //country_13
	"El Salvador", //country_14
	"Brasil", //country_15
	"Select this option if you want to add a guest network", //S500
	"Network Type", //S496
	"Enable HTTP Storage Remote Access", //sto_http_2
	"The Email Now button is disabled because Email Notification is not enabled on <a href=\"tools_email.asp\" onclick=\"return jump_if();\" shape=\"rect\">Tools &rarr; Email</a> screen.", //logs_LW39b_email
	"Use HTTPS", //LV3
	"%s%sWireless system with MAC address %m secured and linked", //GW_WIRELESS_DEVICE_LINK_UP
	"All log entries were cleared.", //LT248
	"Discovering PPPoE servers for %s PPPoE Session", //GW_PPPOE_EVENT_DISCOVERY_ATTEMPT
	"5GHz Band", //GW_WLAN_RADIO_1_NAME
	"SMTP Server Port", //te_SMTPSv_Port
	"Can not change 802.11 Mode to 802.11n only, while there is an SSID with WEP security.", //GW_WLAN_CHANGING_PHY_MODE_TO_11NG_ONLY_INVALID
	"Select your Wireless Network", //S558
	"Select the Radio you Want to Configure", //KRL8
	"The selection helps you to define the Guest Zone scale.", //LY30
	"Virtual server '%s' can not use the router's HTTPS WAN administration port, %u", //GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"Wi-Fi protected setup disabled because security of SSID '%s' is set to WPA-Enterprise.", //GW_WIFISC_DISABLED_AUTOMATICALLY
	"Off", //_off
	"2.4GHz Band", //GW_WLAN_RADIO_0_NAME
	"%s PPPoE session protocol fault. Connection attempt failed.", //GW_PPPOE_EVENT_DISCOVERY_REQUEST_ERROR
	"PPPoE session name %s conflicts with other session name", //GW_WAN_PPPOE_SESSION_NAME_CONFLICT
	"Problem in receiving logs! Memory is too low to display logs or there is a problem with the connection.", //S525
	"Password and Verify Password do not match. Please reconfirm user password.", //YM174
	"You should examine these warnings, because some features may have been disabled or modified.", //KR136
	"Terminating %s PPPoE session ID %u", //GW_PPPOE_EVENT_DISCONNECT
	"Endpoint Independent", //af_EFT_0
	"Use this section to enable routing between Host Zone and Guest Zone, Guest clients can not access Host clients' data without enable the function.", //LY34
	"%sWireless shut down", //GW_WIRELESS_SHUT_DOWN
	"%sWireless restart", //GW_WIRELESS_RESTART
	"The administration idle time should be in the range of 1 to 65535.", //S528
	"Port forwarding ALG failed to allocate session for TCP packet from %v:%u to %v:%u", //GW_PORT_FORWARD_TCP_PACKET_ALLOC_FAILURE
	"Use this section to configure the guest zone settings of your router. The guest zone provide a separate network zone for guest to access Internet.", //guestzone_Intro_1
	"Virtual server '%s' can not use the router's HTTPS WAN administration port, %u", //GW_NAT_VIRTUAL_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"Enable Remote Management", //ta_ERM
	"Port should be in range (1..65535)", //te_SMTPSv_Port_alert
	"%sFailed to start wireless", //GW_WIRELESS_DEVICE_START_FAILED
	"Port forwarding ALG failed to allocate session for UDP packet from %v:%u to %v:%u", //GW_PORT_FORWARD_UDP_PACKET_ALLOC_FAILURE
	"%sDisconnect all stations", //GW_WIRELESS_DEVICE_DISCONNECT_ALL
	"Issuing request for offer for %s PPPoE Session", //GW_PPPOE_EVENT_OFFER_REQUEST
	"Router IP %v must be a valid host address", //GW_ROUTES_ROUTERS_IP_ADDRESS_INVALID
	"Port trigger ALG failed to allocate session for UDP packet from %v:%u to %v:%u", //GW_PORT_TRIGGER_UDP_PACKET_ALLOC_FAILURE
	"Can not set WEP security for an SSID, while 802.11 Mode is 802.11n only.", //GW_WLAN_SETTING_SSID_SECURITY_TO_WEP_INVALID
	"Virtual server '%s' can not use the router's HTTP WAN administration port, %u", //GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT
	"Timeout, station left", //GW_WLAN_STATION_TIMEOUT
	"Virtual server '%s' can not use the router's IP address, %v.", //GW_NAT_VIRTUAL_SERVER_IP_ADDRESS_CAN_NOT_MATCH_ROUTER
	"%s' [protocol:%u]->%v conflicts with '%s' [protocol:%u]->%v.", //GW_NAT_VIRTUAL_SERVER_PROTO_CONFLICT_INVALID
	"Specifies whether the Guest Zone will be enabled or disabled.", //LY28
	"Trying to establish %s PPPoE connection", //GW_PPPOE_EVENT_CONNECT
	"Trigger Port", //GW_NAT_TRIGGER_PORT
	"operate mode", //tc_opmode
	"Automatically assign a network key for both 2.4GHz and 5GHz band (Recommended)", //wwz_auto_assign_key3
	"Provide a name for Guest Zone wireless network.", //LY292
	"Securing your wireless network is important as it is used to protect the integrity of the information being transmitted over your wireless network. The router is capable of 4 types of wireless security; WEP, WPA only, WPA2 only, and WPA/WPA2 (auto-detect).", //LY293
	"If you choose the WEP security option this device will <strong>ONLY</strong> operate in <strong>Legacy Wireless mode (802.11B/G)</strong>. This means you will <strong>NOT</strong> get 11N performance due to the fact that WEP is not supported by the Draft 11N specification.", //bws_msg_WEP_4
	"The route for %v on interface %s may not be created - only routes via gateways may be created on this interface", //GW_ROUTES_ON_LINK_DATALINK_CHECK_INVALID
	"DNS settings", //wwa_dnsset
	"This wizard is designed to assist you in connecting your guest wireless device to your wireless router. It will guide you through step-by-step instructions on how to get your guest wireless device connected. Click the button below to begin.", //wireless_gu
	"Add Guest Wireless with WPS", //add_gu_wps
	"Wireless Band", //wwl_band
	"Band", //_band
	"Manually set 5GHz band Network Name", //wwa_5G_nname
	"GUEST ZONE", //_guestzone
	"Guest Zone Selection", //guestzone_title_1
	"Enable Graphical Authentication", //_graph_auth
	"Include Wireless", //guestzone_inclw
	"Guest", //guest
	"lower than wireless network", //lower_wnt
	"equal to wireless network", //equal_wnt
	"lowest", //_lowest
	"SSID List", //ssid_lst
	"Multiple SSID", //mult_ssid
	"Add/Edit SSID", //add_ed_ssid
	"Enable or disable defined rules with the checkboxes at the left.", //help75a
	"WAN Ping Inbound Filter", //wpin_filter
	"The raw TCP port printing protocol uses a fixed IP address and TCP port to communicate with your printer.", //tps_raw1
	"(GMT+06:30) Rangoon", //up_tz_52
	"Destination IP address are same", //_r_alert_new1
	"Email Settings", //te_EmSt
	"Blocked outgoing packet from %v to %v (IP protocol %u)", //IPNAT_BLOCKED_EGRESS
	"Wireless Security Mode", //bws_WSMode
	"Pinging public WAN IP addresses is a common method used by hackers to test whether your WAN IP address is valid.", //anet_wan_ping_1
	"Give the rule a name that is meaningful to you, for example <code>Game Server</code>. You can also select from a list of popular games, and many of the remaining configuration values will be filled in accordingly. However, you should check whether the port values have changed since this list was created, and you must fill in the IP address field.", //help65
	"UPnP", //ta_upnp
	"Transmission Rate", //bwl_TxR
	"WAN interface speed measurement completed", //GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED
	"Average ping time (in milliseconds)", //tsc_pingt_msg106
	"All Day", //tsc_AllDay
	"Tiger Woods 2K4", //gw_gm_53
	"WAN interface speed measurements not started as low on resources", //GW_WAN_RATE_ESTIMATOR_RESOURCE_ERROR
	"Lost lease on IP Address", //DHCP_CLIENT_LOST_LEASE
	"Choose a schedule to apply to this policy.", //_aa_wiz_s3_msg
	"Authentication Timeout", //bwsAT_
	"Good timekeeping is important for accurate logs and scheduled firewall rules.", //hhtt_intro
	"Final Fantasy XI (PC)", //gw_gm_20
	"The IP address of the authentication server.", //help388
	"Set the Date and Time Manually", //tt_StDT
	"Offline", //psOffline
	"Status", //_status
	"Otherwise press 'Cancel'.", //up_ae_wic_3
	"What to View", //sl_WtV
	"STA with MAC (%m) requested for WPS registration", //WIFISC_AP_PROXY_PROCESS_START
	"The setup wizard was unable to communicate with the printer.", //wprn_nopr2
	"When you are browsing for available wireless networks, this is the name that will appear in the list (unless Visibility Status is set to Invisible, see below). This name is also referred to as the SSID. For security purposes, it is highly recommended to change from the pre-configured network name.", //help352
	"Network Name (SSID)", //wwz_wwl_wnn
	"IP Address", //_ipaddr
	"gw_wireless_schedule start", //GW_WLS_SCHEDULE_START
	"The direction of initiation of the conversation:", //help820
	"If all the computers on the LAN successfully obtain their IP addresses from the router's DHCP server as expected, this option can remain disabled. However, if one of the computers on the LAN fails to obtain an IP address from the router's DHCP server, it may have an old DHCP client that incorrectly turns off the broadcast flag of DHCP packets. Enabling this option will cause the router to always broadcast its responses to all clients, thereby working around the problem, at the cost of increased broadcast traffic on the LAN.", //help326
	"(GMT+08:00) Krasnoyarsk", //up_tz_54
	"Note: Some browsers have limitations that make it impossible to update the WAN status display when the status changes. Some browsers require that you refresh the display to obtain updated status. Some browsers report an error condition when trying to obtain WAN status.", //help773
	"MAC Filtering Rules", //am_MACFILT
	"are same Machine.", //aa_alert_7_new1
	"Each networking device has it's own unique MAC address defined by the hardware manufacturer. Some ISP's may check your computer's MAC address. Some ISP's record the MAC address of the network adapter in the computer or router used to initially connect to their service. The ISP will then only grant Internet access to requests from a computer or router with this particular MAC address. This router has a different MAC address than the computer or router that initially connected to the ISP.", //help302
	"The Access Control option allows you to control access in and out of your network. Use this feature as Access Controls to only grant access to approved sites, limit web access based on time or dates, and/or block internet access for applications like P2P utilities or games.", //aa_intro
	"This shows clients that you have specified to have reserved DHCP addresses. An entry can be changed by clicking the Edit icon, or deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit DHCP Reservation\" section is activated for editing.", //help348
	"Packets received by the DMZ host have their IP addresses translated from the WAN-side IP address of the router to the LAN-side IP address of the DMZ host. However, port numbers are not translated; so applications on the DMZ host can depend on specific port numbers.", //haf_dmz_30
	"Informational", //sl_Infrml
	"Wireless", //_wireless
	"RADIUS server IP Address", //bws_RIPA
	"Enabling this option can provide protection from certain kinds of \"spoofing\" attacks. However, enble this option with care. With some modems, the WAN connection may be lost when this option is enabled. In that case, it may be necessary to change the LAN subnet to something other than 192.168.0.x (192.168.2.x, for example), to re-establish the WAN connection.", //KR108
	"If Automatic Uplink Speed is disabled, this option allows you to set the uplink speed manually. Uplink speed is the speed at which data can be transferred from the router to your ISP. This is determined by your ISP. ISPs often specify speed as a downlink/uplink pair; for example, 1.5Mbps/284kbps. For this example, you would enter \"284\". Alternatively you can test your uplink speed with a service such as <a href=\"http://www.dslreports.com\">www.dslreports.com</a>. Note however that sites such as DSL Reports, because they do not consider as many network protocol overheads, will generally note speeds slightly lower than the Measured Uplink Speed or the ISP rated speed.", //help83
	"If the <strong>Measured Uplink Speed</strong> is known to be incorrect (that is, it produces suboptimal performance), disable <strong>Automatic Uplink Speed</strong> and enter the <strong>Manual Uplink Speed</strong>. Some experimentation and performance measurement may be required to converge on the optimal value.", //hhase_intro
	"Error loading configuration from non-volatile memory (Magic number mis-match). Reset configuration to factory defaults", //RUNTIME_CONFIG_MAGIC_NUM_ERROR
	"Sat", //_Sat
	"Website Filtering Rules", //awf_title_WSFR
	"You can select a computer from the list of DHCP clients in the \"Computer Name\" drop-down menu, or you can manually enter the IP address of the server computer.", //help18_a
	"ALLOW computers access to ONLY these sites", //dlink_wf_op_1
	"Far Cry", //gw_gm_18
	"Call of Duty", //gw_gm_7
	"Found USB mass storage with subclass %u protocol %u", //USB_LOG_STORAGE_TYPE
	"Game Server", //help346
	"This will cause all current settings to be lost.", //up_rb_5
	"WEP", //_WEP
	"MSCHAP send authentication response (Failure and no Retry).", //IPMSCHAP_AUTH_FAIL_AND_NO_RETRY
	"SWAT 4", //gw_gm_82
	"The supported authentication protocols are PAP and CHAP.", //bw_sap
	"Enter the static address information provided by your Internet Service Provider (ISP).", //bwn_msg_SWM
	"The network connection seems to be down. Press\"Ok\" to try again.", //li_alert_2
	"When Access Control is disabled, every device on the LAN has unrestricted access to the Internet. However, if you enable Access Control, Internet access is restricted for those devices that have an Access Control Policy configured for them. All other devices have unrestricted access to the Internet.", //help120
	"IGMP host has rejected group %v due to low system resources", //IGMP_HOST_LOW_RESOURCES
	"- Exactly 10 or 26 characters using 0-9 and A-F", //wwl_s4_intro_z3
	"Enable this option for better performance and experience with online games and other interactive applications, such as VoIP.", //help78
	"Windows 2000", //help339
	"Enable IPv6 Simple Security ", //IPv6_Simple_Security_enable
	"Enter the port range that you want to open up to Internet traffic (for example <code>6000-6200</code>).", //help51
	"THE ADDRESSING OF THE INTERNET SIDE LEARNT THRU PPPoE CONFLICTS WITH THE ADDRESSING SELECTED FOR THE LAN SIDE. INTERNET COMMUNICATIONS WILL BE DISABLED UNTIL YOU HAVE CHANGED THE LAN SIDE ADDRESSING TO RESOLVE THE PROBLEM", //GW_WAN_LAN_ADDRESS_CONFLICT_PPP
	"Errors", //ss_Errors
	"If a dynamic DNS update fails for any reason (for example, when incorrect parameters are entered), the router automatically disables the Dynamic DNS feature and records the failure in the log.", //help899
	"Please enter the graphical authentication code.", //li_alert_4
	"The DMZ capability is just one of several means for allowing incoming requests that might appear unsolicited to the NAT. In general, the DMZ host should be used only if there are no other alternatives, because it is much more exposed to cyberattacks than any other system on the LAN. Thought should be given to using other configurations instead: a virtual server, a port forwarding rule, or a port trigger. Virtual servers open one port for incoming sessions bound for a specific application (and also allow port redirection and the use of ALGs ). Port forwarding is rather like a selective DMZ, where incoming traffic targeted at one or more ports is forwarded to a specific LAN host (thereby not exposing as many ports as a DMZ host). Port triggering is a special form of port forwarding, which is activated by outgoing traffic, and for which ports are only forwarded while the trigger is active.", //haf_dmz_40
	"Click the <strong>Edit</strong> icon to change an existing schedule.", //hhts_edit
	"Wireless Network Name (SSID)", //wwl_wnn
	"Web site %S accessed from %s", //WEB_FILTER_LOG_URL_ACCESSED_MAC
	"WMM Enable", //aw_WE
	"Setup Help", //help201a
	"Activate Your FREE 30 Day Trial Here", //_bsecure_activate_trial
	"Enter the password or key provided by your service provider. If the Dynamic DNS provider supplies only a key, enter that key in all three fields.", //help896
	"The communications protocol used for the conversation.", //help815
	"Netmask", //_netmask
	"Please wait...", //_please_wait
	"Repeat these steps for each Virtual Server Rule you wish to add. After the list is complete, click <span class=\"button_ref\">Save Settings</span> at the top of the page.", //help12
	"The MAC (Media Access Controller) Address filter option is used to control network access based on the MAC Address of the network adapter. A MAC address is a unique ID assigned by the manufacturer of the network adapter. This feature can be configured to ALLOW or DENY network/Internet access.", //am_intro_1
	"LCP sets local auth: %04x", //IPPPPLCP_SET_LOCAL_AUTH
	"Crimson Skies", //gw_gm_11
	"Don't Save Settings", //_dontsavesettings
	"The WPA (Wi-Fi Protected Access) key must meet following guildelines", //wwl_s4_intro_za1
	"MTU default =", //_308
	"MAC", //aa_AT_1
	"L2TP local tunnel 0x%04X aborted", //IPL2TP_TUNNEL_ABORTING
	"Add/Edit DHCP Reservation", //help330
	"L2TP client.", //wwa_msg_l2tp
	"04:00 AM", //tt_time_5
	"Enter the IP Address of the machine on your LAN (for example: <code>192.168.0.50</code>", //help6
	"TIME", //_time
	"xDSL Or Other Frame Relay Network", //at_xDSL
	"Step 2: Launch the setup executable on your computer", //wprn_intro4
	"Normally, this is set to \"auto\". If you have trouble connecting to the WAN, try the other settings.", //help296
	"LAN", //_LAN
	"Warcraft III", //gw_gm_60
	"Select the machine to which this policy applies.", //_aa_wiz_s4_msg
	"64 bits", //wwl_64bits
	"Disk is full", //IPFAT_DISK_FULL
	"Go to your Start menu, select Programs, select Accessories, and select Command Prompt. At the command prompt type <code>ipconfig /all</code> and hit Enter. The physical address displayed for the adapter connecting to the router is the MAC address.", //help341
	"Press \"Ok \" to abandon these changes and display the Schedule page.", //aa_sched_conf_2
	"Trying to start L2TP local session 0x%04X", //IPL2TP_SESSION_CONNECTING
	"Time synchronization failed (status %d)", //NET_RTC_SYNCHRONIZATION_FAILED
	"Automatically Check Online for Latest Firmware Version", //tf_AutoCh
	"The printer manufacturer and/or model could not be determined, possibly due to an invalid device ID reported by the printer. The wizard cannot continue without this information.", //wprn_iderr2
	"These two IP values (<i>from</i> and <i>to</i>) define a range of IP addresses that the DHCP Server uses when assigning addresses to computers and devices on your Local Area Network. Any addresses that are outside of this range are not managed by the DHCP Server; these could, therefore, be used for manually configured devices or devices that cannot use DHCP to obtain network address details automatically.", //help319
	"<b>Note:</b> Putting a computer in the DMZ may expose that computer to a variety of security risks. Use of this option is only recommended as a last resort.", //af_intro_2
	"Clicking this button refreshes the display of log entries. There may be new events since the last time you accessed the log.", //help800
	"Device Information", //sd_title_Dev_Info
	"Internet access port filter dropped packet from %v to %v (protocol %u)", //GW_INET_ACCESS_DROP_PORT_FILTER
	"Windows Connect Now", //_connow
	"SIP ALG rejected packet from %v:%u to %v:%u", //IPSIPALG_REJECTED_PACKET
	"Dropped TCP packet from %v:%u to %v:%u as unable to modify header options", //IPNAT_TCP_UNABLE_TO_MODIFY_OPTIONS
	"Select NTP Server", //tt_SelNTPSrv
	"A noisy radio-frequency environment can cause a high error rate on the wireless LAN.", //help812
	"User", //_user
	"(GMT+08:00) Taipei", //up_tz_59
	"Special Applications", //SPECIAL_APP
	"NONE", //wwl_NONE
	"Starting WAN Services", //GW_WAN_SERVICES_STARTED
	"Forbidden Web Access", //fb_FbWbAc
	"You have to open up the Web-based management interface and click the Connect button manually any time that you wish to connect to the Internet.", //help275
	"No printer detected", //wprn_nopr
	"Time Zone", //tt_TimeZ
	"Troubleshooting Tips", //wprn_tt
	"Select your local time zone from pull down menu.", //help841
	"Define a new schedule", //aa_sched_new
	"01:00 PM", //tt_time_14
	"HTTP", //gw_vs_1
	"SysLog Settings", //tsl_SLSt
	"H.323 ALG rejected packet from %v:%u to %v:%u", //IPH323ALG_REJECTED_PACKET
	"Step 4 - Select filtering method", //aa_wiz_s1_msg4
	"Windows 98", //help336
	"System Name", //ta_sn
	"Depending on whether you are currently logged in to BigPond, you can click either the <span class=\"button_ref\">BigPond Login</span> to attempt to establish the WAN connection or the <span class=\"button_ref\">BigPond Logout</span> to break the WAN connection.", //help780
	"Interface", //_interface
	"Web site %S blocked for %v", //WEB_FILTER_LOG_URL_BLOCKED
	"Remote Admin Port confict with Virtual Server Item", //vs_http_port
	"The router provides a tight firewall by virtue of the way NAT works. Unless you configure the router to the contrary, the NAT does not respond to unsolicited incoming requests on any port, thereby making your LAN invisible to Internet cyberattackers. However, some network applications cannot run with a tight firewall. Those applications need to selectively open ports in the firewall to function correctly. The options on this page control several ways of opening the firewall to address the needs of specific types of applications.", //haf_intro_1
	"(GMT-06:00) Central America", //up_tz_07
	"If you are not familiar with these Advanced Wireless settings, please read the help section before attempting to modify these settings.", //aw_intro
	"Gateway Address", //wwa_gw
	"Sentinel Services", //_sentinel_serv
	"Choose this option if your Internet Setup Provider provided you with IP Address information that has to be manually configured.", //wwa_msg_sipa
	"Dropped TCP packet from %v to %v as unable handle packet header", //IPNAT_TCP_UNABLE_TO_HANDLE_HEADER
	"You can select a computer from the list of DHCP clients in the <strong>Computer Name</strong> drop down menu, or you can manually enter the IP address of the computer at which you would like to open the specified port.", //hhav_ip
	"Few applications truly require the use of the DMZ host. Following are examples of when a DMZ host might be required:", //haf_dmz_50
	"Policy %s stopped; Internet access for MAC address %m changed to: %s", //GW_INET_ACCESS_POLICY_END_MAC
	"The Schedule configuration option is used to manage schedule rules for various firewall and parental control features.", //tsc_intro_Sch
	"Access denied to wireless system with MAC address %m", //GW_WLAN_ACCESS_DENIED
	"Local Domain Name", //_262
	"This option is enabled by default so that your router will automatically determine which programs should have network priority.", //help79
	"BigPond not configured properly", //GW_BIGPOND_CONFIG
	"High", //aw_TP_0
	"Establishing (please wait...)", //_sdi_s3
	"Ping Result", //tsc_pingr
	"IPv6 Ping Test", //tsc_pingt_v6
	"WPA-Personal", //_WPApersonal
	"EMail Settings", //_email
	"PPPoE confirming session offer", //PPPOE_EVENT_DISCOVERY_REQUEST
	"Firewall", //_firewall
	"Static IP Address Connection", //wwa_wanmode_sipa
	"System Check", //_syscheck
	"The LAN-side IP address of the client.", //help784
	"Unknown", //UNKNOWN
	"UPnP is short for Universal Plug and Play, which is a networking architecture that provides compatibility among networking equipment, software, and peripherals. This router has optional UPnP capability, and can work with other UPnP devices and software.", //help_upnp_1
	"Wolfenstein: Enemy Territory", //gw_gm_61
	"(optional)", //_optional
	"Setting the Fragmentation value too low may result in poor performance.", //help181
	"Internet", //help569
	"If you are not familiar with these Advanced Network settings, please read the help section before attempting to modify these settings.", //anet_intro
	"Enter the correct password above and<br>then type the characters you see in the<br>picture below.", //_authword
	"Blocked outgoing TCP packet from %v:%u to %v:%u as %s received but there is no active connection", //IPNAT_TCP_BLOCKED_EGRESS_NOT_SYN
	"Gateway Name", //ta_GWN
	"If you are not authorized to modify the router's configuration, contact the router administrator.", //wprn_tt3
	"MTU", //help293
	"If your ISP has assigned a fixed IP address, select this option. The ISP provides the value for the", //help265_2
	"Dropped packet from %v to %v (IP protocol %u) as unable to create new session", //IPNAT_UNABLE_TO_CREATE_CONNECTION
	"Always on", //help270
	"Advanced Wireless Settings", //aw_title_2
	"Firewall Settings", //_firewalls
	"Enabled/Not Configured", //LW67
	"PPPoE session 0x%04X established", //PPPOE_EVENT_UP
	"Protocol", //_protocol
	"WPA-Personal and WPA-Enterprise", //help372
	"(GMT+02:00) Bucharest", //up_tz_32
	"kbps", //at_kbps
	"Cable Or Other Broadband Network", //at_Cable
	"100Mbps", //anet_wp_1
	"Assign a meaningful name to the virtual server, for example <code>Web Server</code>. Several well-known types of virtual server are available from the \"Application Name\" drop-down list. Selecting one of these entries fills some of the remaining parameters with standard values for that type of server.", //help17
	"By default there is no password configured. It is highly recommended that you create a password to keep your router secure.", //ta_intro_Adm2
	", Please check", //tool_admin_check
	"PPP network up with IP Address %v", //IPPPPIPCP_PPP_LINK_UP
	"Stop", //_stop
	"Syslog server set as IP address %v", //GW_SYSLOG_STATUS
	"DHCP Server Setting", //bd_title_DHCPSSt
	"The name of the router can be changed here.", //help827
	"Check Latest Firmware Version", //tf_FWCheckInf
	"FIRMWARE and LANGUAGE PACK INFORMATION", //tf_FWInf
	"Up to eight ranges of WAN IP addresses can be controlled by each rule. The checkbox by each IP range can be used to disable ranges already defined.", //hhai_ipr
	"It is recommended that you leave these parameters at their default values. Adjusting them could limit the performance of your wireless network.", //hhaw_1
	"Allows multiple VPN clients to connect to their corporate networks using IPSec. Some VPN clients support traversal of IPSec through NAT. This option may interfere with the operation of such VPN clients. If you are having trouble connecting with your corporate network, try disabling this option.", //help34
	"Enable Network USB Auto-Detection", //_network_usb_auto
	"The subnet mask of your router on the local area network.", //help309
	"You cannot add new MAC addresses. You can only reuse MAC addresses from other policies.", //aa_alert_15
	"Save Settings", //_savesettings
	"Give the schedule a name that is meaningful to you, such as \"Weekday rule\".", //help193
	"Virtual Server Parameters", //help14_p
	"Need for Speed: Hot Pursuit 2", //gw_gm_32
	"Blocked incoming TCP connection request from %v:%u to %v:%u", //IPNAT_TCP_BLOCKED_INGRESS_SYN
	"If you enable this feature, the WAN port of your router will respond to ping requests from the Internet that are sent to the WAN IP Address.", //anet_msg_wan_ping
	"Inbound Filters can be used for limiting access to a server on your network to a system or group of systems.", //ai_intro_2
	"L2TP Subnet Mask", //help285
	"LAN Statistics", //ss_LANStats
	"A restore is already in progress.", //ta_alert_4
	"Copy Your PC's MAC Address", //_clone
	"Diablo I and II", //gw_gm_14
	"Dropped GRE packet from %v to %v as unable handle packet header", //PPTP_ALG_GRE_UNABLE_TO_HANDLE_HEADER
	"Block Some Access", //_aa_block_some
	"Established -- the connection is passing data.", //help819_3
	"11:00 PM", //tt_time_24
	"Normally email is sent at the start time defined for a schedule, and the schedule end time is not used. However, rebooting the router during the schedule period will cause additional emails to be sent.", //help873
	"Collisions", //ss_Collisions
	"Enter the SMTP server address for sending email.", //help863
	"This option enables configuration of an optional second RADIUS server. A second RADIUS server can be used as backup for the primary RADIUS server. The second RADIUS server is consulted only when the primary server is not available or not responding. The fields <span class=\"option\">Second RADIUS Server IP Address</span>, <span class=\"option\">RADIUS Server Port</span>, <span class=\"option\">Second RADIUS server Shared Secret</span>, <span class=\"option\">Second MAC Address Authentication</span> provide the corresponding parameters for the second RADIUS Server.", //help397
	"Virtual Servers List", //av_title_VSL
	"OFDM", //help636
	"Email me if a newer Firmware is available", //tf_ENFA
	"With this Virtual Server entry, all Internet traffic on Port 8888 will be redirected to your internal web server on port 80 at IP Address 192.168.0.50.", //help13
	"Step 3: Configure your Internet Connection", //wwa_title_s3
	"Step 1: Configure your Internet Connection", //ES_wwa_title_s1
	"WAN interface speed measurement aborted as they did not converge", //GW_WAN_RATE_ESTIMATOR_CONVERGENCE_ERROR
	"BigPond", //wwa_wanmode_bigpond
	"The WAN (Wide Area Network) section is where you configure your Internet Connection type.", //help254
	"To handle incoming connections that use a protocol other than ICMP, TCP, UDP, and IGMP (also GRE and ESP, when these protocols are enabled by the PPTP and IPSec ALGs ).", //haf_dmz_70
	"System error occured when attaching with schedule %s", //GW_SCHED_ATTACH_FAILED
	"The SSID field can not be blank", //_badssid
	"Stored configuration to non-volatile memory", //RUNTIME_CONFIG_STORING_CONFIG_IN_NVRAM
	"Firmware Update is Available", //FW_UPDATE_AVAILABLE
	"The Dynamic DNS feature allows you to host a server (Web, FTP, Game Server, etc.) using a domain name that you have purchased (www.whateveryournameis.com) with your dynamically assigned IP address. Most broadband Internet Service Providers assign dynamic (changing) IP addresses. When you use a Dynamic DNS service provider, your friends can enter your host name to connect to your server, no matter what your IP address is.", //help891
	"PPPoE, PPTP, L2TP Connection", //help777
	"MAC Address Authentication", //help393
	"Internet Connection Type", //bwn_ict
	"Jun", //tt_Jun
	"L2TP local tunnel 0x%04X has been connected to \"%s\"", //IPL2TP_TUNNEL_CONNECTED
	"Command and Conquer Zero Hour", //gw_gm_9
	"Aliens vs. Predator", //gw_gm_2
	"Wireless Network Setup Wizard", //wwl_wl_wiz
	"DHCP Range Invalid, FROM not bigger than TO", //network_dhcp_range
	"Step 4: Print a test page", //wprn_intro6
	"BigPond failed, state=%d with error=%d, server response=%s", //GW_BIGPOND_FAIL
	"Address Restricted", //af_EFT_1
	"Use Unicasting", //_use_unicasting
	"Network Status", //_networkstate
	"Year", //tt_Year
	"Failed to mount USB device", //IPASYNCFILEUSB_MOUNT_FAILED
	"UDP Endpoint Filtering", //af_UEFT
	"By default the fastest possible transmission rate will be selected. You have the option of selecting the speed if necessary.", //help356
	"Pre-Shared Key", //help381
	"Inbound Filter", //_inboundfilter
	"Apply Advanced Port Filters", //_aa_apply_port_filter
	"Dest<br />Port<br />End", //aa_FPR_c7
	"Jedi Knight III: Jedi Academy", //gw_gm_27
	"BigPond not properly configured", //BIGPOND_NOT_PROPERLY_CFGD
	"As an alternative, you can locate a MAC address in a specific operating system by following the steps below:", //help335
	"(GMT+08:00) Perth", //up_tz_58
	"Never", //_never
	"Clicking this button erases all log entries.", //help801
	"Longest ping time (in milliseconds):", //tsc_pingt_msg105
	"WARNING: JavaScript is not enabled for this browser!", //li_WJS
	"To Email Address", //te_ToEm
	"12:00 AM", //tt_time_1
	"Signal", //help787
	"Obtain IPv6 DNS server address automatically", //IPV6_TEXT65_v6
	"Gateway Logs", //GW_EMAIL_SUBJ
	"Port trigger ALG failed to allocate session for UDP packet from %v:%u to %v:%u", //IPPORTTRIGGERALG_UDP_PACKET_ALLOC_FAILURE
	"If you are new to networking and have never configured a router before, click on <span class=\"button_ref\">Setup Wizard</span> and the router will guide you through a few simple steps to get your network up and running.", //bi_wiz
	"Out", //_Out
	"Check the <strong>Application Name</strong> drop down menu for a list of predefined applications. If you select one of the predefined applications, click the arrow button next to the drop down menu to fill out the corresponding field.", //hhpt_app
	"DHCP Connection (Dynamic IP Address)", //_dhcpconn
	"Router Settings", //bln_title_Rtrset
	"Print Server", //_ps
	"This entry is optional. Enter a domain name for the local network. The AP's DHCP server will give this domain name to the computers on the wireless LAN. So, for example, if you enter <code>mynetwork.net</code> here, and you have a wireless laptop with a name of <code>chris</code>, that laptop will be known as <code>chris.mynetwork.net</code>.", //_1044
	"Select this option if your wireless adapters SUPPORT WPA2", //wwl_text_best
	"PPTP Server IP Address (may be same as gateway)", //wwa_pptp_svraddr
	"WAN interface speed measurement completed. Upstream speed is %u kbps", //GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED
	"LAN Computers", //_LANComputers
	"You may want to make the email settings similar to those of your email client program.", //hhte_intro
	"H.323 (Netmeeting)", //as_NM
	"Setup Wizard", //wwa_setupwiz
	"and", //help264
	"(compatibility for some DHCP Servers)", //bw_WDUU_note
	"MMS", //as_MMS
	"Service Name", //_srvname
	"The rule applies to a flow of messages whose LAN-side IP address falls within the range set here.", //help93
	"Minute", //tt_Minute
	"State", //sa_State
	"802.11d Enable", //aw_dE
	"Host Name or IP Address", //tsc_pingt_h
	"Host Name or IPv6 Address", //tsc_pingt_h_v6
	"Wireless Statistics", //ss_WStats
	"MSCHAP authenticator send challenge.", //IPMSCHAP_AUTH_SEND_CHALLENGE
	"When this option is enabled, your router will check online periodically to see if a newer version of the firmware is available.", //help889
	"H.323 (NetMeeting)", //as_H323
	"Port Forwarding Item", //tool_admin_pfname
	"Dropped packet from %v to %v (protocol %u) as session already exists", //IPNAT_SESSION_ALREADY_EXISTS
	"Set BigPond Cable Connection", //wwa_title_set_bigpond
	"(GMT-04:00) Santiago", //up_tz_16
	"BigPond state changed, new state=%d", //GW_BIGPOND_STATUS
	"To set up this connection you will need to have a Username and Password from your Internet Service Provider. You also need BigPond Server IP adress. If you do not have this information, please contact your ISP.", //wwa_msg_set_bigpond
	"Enable at least one Source IP Range for %s", //ai_alert_5
	"Select this option if you want to synchronize the router's clock to a Network Time Server over the Internet. If you are using schedules or logs, this is the best way to ensure that the schedules and logs are kept accurate.", //help848
	"Return to Castle Wolfenstein", //gw_gm_41
	"Policy Wizard", //_aa_pol_wiz
	"IP Filters", //IP_FILTERS
	"Starsiege Tribes", //gw_gm_50
	"Please select your Internet connection type below:", //wwa_intro_s3
	"Dropped ESP packet from %v as connection attempt already pending from %v to %v", //IPSEC_ALG_ESP_ESTABLISH_ALREADY_PENDING
	"Individual (80, 68, 888)", //help59
	"Are you sure you want to reset the device to Unconfiged?", //wps_reboot_need
	"Dynamic Fragmentation", //at_DF
	"If the ISP's servers assign the router's IP addressing upon establishing a connection, select this option.", //help265_7
	"DST end month must be different than DST start month", //tt_alert_dstchkmonth
	"(GMT-01:00) Cape Verde Is.", //up_tz_23
	"Advanced", //_advanced
	"Static IP Address", //STATIC_IP_ADDRESS
	"Step 2: Secure your Wireless Network", //wwl_title_s3
	"This is a list of all wireless clients that are currently connected to your wireless router.", //hhsw_intro
	"Menu", //ish_menu
	"(GMT+02:00) Cairo", //up_tz_33
	"Failed to check for new firmware", //GW_FW_NOTIFY_FIRMWARE_ERROR
	"More info...", //_bsecure_more_info
	"Current Firmware Version", //tf_CFWV
	"2nd", //tt_week_2
	"Example:", //help3
	"Creator", //_creator
	"DNS Relay", //bln_title_DNSRly
	"Internet access port filter dropped packet from %v:%u[%s] to %v:%u (protocol %u)", //GW_INET_ACCESS_DROP_PORT_FILTER_MAC
	"Glossary", //ish_glossary
	"A longer WEP key is more secure than a short one", //wwl_s4_intro_z4
	"By default, the Access Control feature is disabled. If you need Access Control, check this option.", //help118
	"Shareaza", //gw_gm_66
	"When DNS Relay is enabled, the router plays the role of a DNS server. DNS requests sent to the router are forwarded to the ISP's DNS server. This provides a constant DNS address that LAN computers can use, even when the router obtains a different DNS server address from the ISP upon re-establishing the WAN connection. You should disable DNS relay if you implement a LAN-side DNS server as a virtual server.", //help312dr2
	"All Day - 24 hrs", //tsc_24hrs
	"Check the <strong>Application Name</strong> drop down menu for a list of predefined applications. If you select one of the predefined applications, click the arrow button next to the drop down menu to fill out the corresponding field.", //hhag_10
	"Some ISP's may check your computer's Host Name. The Host Name identifies your system to the ISP's server. This way they know your computer is eligible to receive an IP address. In other words, they know that you are paying for their service.", //help261
	"Trigger Traffic Type", //as_TPrt
	"This will happen if you have an Access Control Rule configured for this LAN machine.", //help28
	"11:00 AM", //tt_time_12
	"Refresh Statistics", //ss_reload
	"Out", //EGRESS
	"The following <span id='status_text'>printer is</span> attached to your router.", //sps_fp
	"Unreal Tournament 2004", //gw_gm_57
	"Choose this if your Internet connection automatically provides you with an IP Address. Most Cable Modems use this type of connection.", //wwa_msg_dhcp
	"Step 1 - Choose a unique name for your policy", //aa_wiz_s1_msg1
	"You must be logged in as \"admin\" to perform this action", //MUST_BE_LOGGED_IN_AS_ADMIN
	"(GMT+09:30) Darwin", //up_tz_64
	"gw_wireless_schedule stop", //GW_WLS_SCHEDULE_STOP
	"Wake-on-LAN ALG rejected packet from %v:%u to %v:%u", //IPWOLALG_REJECTED_PACKET
	"Update device to wsetting.wfc", //WCN_LOG_UPDATE
	"This option should be enabled when you have a slow Internet uplink. It helps to reduce the impact that large low priority network packets can have on more urgent ones by breaking the large packets into several smaller packets.", //help80
	"Here you can add entries to the Inbound Filter Rules List below, or edit existing entries.", //help171
	"Mon", //_Mon
	"(GMT+10:00) Canberra, Melbourne, Sydney", //up_tz_66
	"Step 2: Set your Wireless Security Password", //wwl_title_s4_2
	"If you don't use the All Day option, then you enter the time here. The start time is entered in two fields. The first box is for the hour and the second box is for the minute. Email events are normally triggered only by the start time.", //help196
	"PPPoE session offer had errors. Connection attempt failed.", //PPPOE_EVENT_DISCOVERY_REQUEST_ERROR
	"Log In", //li_Log_In
	"Non-UDP/TCP/ICMP LAN Sessions", //af_gss
	"Default Gateway", //_defgw
	"NTP Server is not configured.", //YM185
	"Adding wireless device:", //add_wireless_device
	"Enter the Public Port as [8888]", //help8
	"Your ISP provides you with all of this information.", //help258
	"PPPoE session 0x%04X terminated by access concentrator", //PPPOE_EVENT_TERMINATED
	"Are you sure you want to reboot the device?", //up_rb_1
	"Use the checkboxes at the left to activate or deactivate completed Virtual Server entries.", //help25_b
	"Save Log", //sl_saveLog
	"Use this option to view the router logs. You can define what types of events you want to view and the event levels to view. This router also has internal syslog server support so you can send the log files to a computer on your network that is running a syslog utility.", //sl_intro
	"Specify a machine with its IP or MAC address, or select \"Other Machines\" for machines that do not have a policy.", //_aa_wiz_s4_help
	"WAN interface cable has been disconnected", //GW_WAN_CARRIER_LOST
	"(bytes)", //bwn_bytes
	"Register the email notification service online to receive an email notification when a newer version of the firmware is available.", //help890_1
	"BigPond Connection", //help779
	"MAC Address", //_macaddr
	"Reset or closed TCP connections. The connection does not close instantly so that lingering packets can pass or the connection can be re-established.", //help823_13
	"Enable Management", //ta_ELM
	"Enable HTTPS Storage Remote Access", //sto_http_4
	"Enable IPv4 Multicast Streams", //anet_multicast_enable_v4
	"Next dynamic DNS update scheduled for %s", //GW_DYNDNS_UPDATE_NEXT
	"Enter the password associated with the account.", //help866
	"Router Status", //sl_RStat
	"Roger Wilco", //gw_gm_78
	"Create a name for the rule that is meaningful to you.", //help90
	"PPTP tunnel ID 0x%04X has been closed", //PPTP_EVENT_TUNNEL_DOWN
	"Static WAN Mode", //bwn_SWM
	"Web filter rejected packet from %v:%u to %v:%u", //IPWEBFILTER_REJECTED_PACKET
	"Invalid firmware upgrade image uploaded - discarding it", //GW_UPGRADE_FAILED
	"This option is used to open multiple ports or a range of ports in your router and redirect data through those ports to a single PC on your network. This feature allows you to enter ports in various formats including, Port Ranges (100-150), Individual Ports (80, 68, 888), or Mixed (1020-5000, 689).", //ag_intro
	"The Admin option is used to set a password for access to the Web-based management. By default there is no password configured. It is highly recommended that you create a password to keep your new router secure.", //ta_intro_Adm
	"L2TP Server IP Address", //bwn_L2TPSIPA
	"No Internet access policy is in effect. Unrestricted Internet access allowed to everyone", //GW_INET_ACCESS_UNRESTRICTED
	"(GMT-05:00) Bogota, Lima, Quito", //up_tz_11
	"Disabled", //_disabled
	"Sending log email as log is full", //GW_LOG_EMAIL_ON_LOG_FULL
	"07:00 AM", //tt_time_8
	"Allows Windows Media Player, using MMS protocol, to receive streaming media from the internet.", //help43
	"Connecting", //ddns_connecting
	"Enable", //_enable
	"On demand", //help272
	"Apr", //tt_Apr
	"Invalid Date or Time", //tt_alert_invlddt
	"(Mbit/s)", //bwl_MS
	"Remote Admin Port conflict with", //tool_admin_portconflict
	"Application Name", //gw_SelVS
	"Always on", //bwn_RM_0
	"Click the <strong>Edit</strong> icon in the Rules List to change a rule.", //hhai_edit
	"From Email Address", //te_FromEm
	"The gateway is currently measuring your network connection.", //wt_p_1
	"Requesting time from %v", //NET_RTC_REQUEST_TIME
	"Enter a name for the Special Application Rule, for example <code>Game App</code>, which will help you identify the rule in the future. Alternatively, you can select from the <span class=\"option\">Application</span> list of common applications.", //help48
	"N/A", //N_A
	"PPTP Subnet Mask", //help279
	"6th", //tt_week_6
	"Soldier of Fortune II: Double Helix", //gw_gm_48
	"Invisible", //bwl_VS_1
	"Confirm updated firmware revision on status page.", //help882
	"(GMT+03:00) Tehran", //up_tz_41
	"Loaded configuration from non-volatile memory", //RUNTIME_CONFIG_LOADED_CONFIG_FROM_NVRAM
	"Session timeout, please try again.", //li_alert_1
	"The IP address of your router on the local area network. Your local area network settings are based on the address assigned here. For example, 192.168.0.1.", //help307
	"A connection to the Internet is made as needed.", //help273
	"Place a checkmark in the boxes for the desired days or select the All Week radio button to select all seven days of the week.", //help194
	"Are you sure you want to reset the device to its factory default settings?", //up_rb_4
	"Newer Firmware Version %d.%d for your %s %s router is now available at", //NEWER_FW_VERSION
	"PPTP Internet Connection Type", //bwn_PPTPICT
	"Firmware upgrade image successfully uploaded - installing", //GW_UPGRADE_SUCCEEDED
	"(Also called the SSID)", //bwl_AS
	"The rule applies to a flow of messages whose WAN-side port number is within the range set here.", //help96
	"Wireless Channel", //_wchannel
	"Manually assign a network key", //wwz_manual_key
	"Please press the button below to continue configuring the router.", //ap_intro_cont
	"Enable Logging To Syslog Server", //tsl_EnLog
	"L2TP", //_L2TP
	"DHCP IP Address Range", //bd_DIPAR
	"Statistics", //_stats
	"- Between 8 and 63 characters (A longer WPA key is more secure than a short one)", //wwl_s4_intro_za2
	"L2TP local session 0x%04X is down", //IPL2TP_SESSION_DOWN
	"Dynamic IP (DHCP) Internet Connection Type", //bwn_DIAICT
	"Go to the Start menu, select Run, type in <code>winipcfg</code>, and hit Enter. A popup window will be displayed. Select the appropriate adapter from the pull-down menu and you will see the Adapter Address. This is the MAC address of the device.", //help338
	"Enter the LAN IP address of the Syslog Server.", //help859
	"Add", //_add
	"Access Control", //_acccon
	"Unable to resolve, check that the name is correct.", //tsc_pingt_msg4
	"Disconnect", //ddns_disconnect
	"Verify Password", //_verifypw
	"Configure MAC Filtering", //am_intro_2
	"Add Policy", //_aa_pol_add
	"Warcraft II", //gw_gm_59
	"Click <span class=\"button_ref\">Save</span> to add the settings to the Virtual Servers List", //help11
	"System", //_system
	"This option is normally turned off, and should remain off as long as the WAN-side DHCP server correctly provides an IP address to the router. However, if the router cannot obtain an IP address from the DHCP server, the DHCP server may be one that works better with unicast responses. In this case, turn the unicasting option on, and observe whether the router can obtain an IP address. In this mode, the router accepts unicast responses from the DHCP server instead of broadcast responses.", //help261a
	"(GMT-10:00) Hawaii", //up_tz_02
	"Ping checks whether a computer on the Internet is running and responding.", //hhtsc_pingt_intro
	"Name the Virtual Server (for example: <code>Web Server</code>)", //help5
	"Support Menu", //help767s
	"Splinter Cell: Pandora Tomorrow", //gw_gm_45
	"Username / Password Connection (PPPoE)", //wwa_wanmode_pppoe
	"Destination and Gateway should not reside on the same subnet %v", //GW_ROUTES_GATEWAY_SUBNET_SAME
	"A host needs to support several applications that might use overlapping ingress ports such that two port forwarding rules cannot be used because they would potentially be in conflict.", //haf_dmz_60
	"The Email feature can be used to send the system log files, router alert messages, and firmware update notification to your email address.", //te_intro_Em
	"Select this option if you do not want to activate any security features", //wwl_text_none
	"Enter the username or key provided by your service provider. If the Dynamic DNS provider supplies only a key, enter that key in all three fields.", //help895
	"Attempting to re-connect on-demand WAN connection", //GW_WAN_RECONNECT_ON_ACTIVE
	"Machine", //aa_Machine
	"gw_wireless_schedule init", //GW_WLS_SCHEDULE_INIT
	"Wed", //_Wed
	"07:00 PM", //tt_time_20
	"Dest IP<br />Start", //aa_FPR_c3
	"Enter the TCP ports to open (for example <code>6159-6180, 99</code>).", //help68
	"It is most useful to prevent unauthorized wireless devices from connecting to your network.", //help150
	"Account Name", //te_Acct
	"SMTP client succeeded sending email", //IPSMTPCLIENT_MSG_SENT
	"Quake 3", //gw_gm_38
	"This option works with a RADIUS Server to authenticate wireless clients. Wireless clients should have established the necessary credentials before attempting to authenticate to the Server through this Gateway. Furthermore, it may be necessary to configure the RADIUS Server to allow this Gateway to authenticate users.", //help384
	"01:00 AM", //tt_time_2
	"Automatic Uplink Speed", //at_AUS
	"Click the <strong>Delete</strong> icon to permanently delete a schedule.", //hhts_del
	"The preference given to outbound packets of this conversation by the QoS Engine logic. Smaller numbers represent higher priority.", //help818
	"Firmware upgrade cannot be performed from a wireless device. To perform an upgrade, ensure that you are using a PC that is connected to the router by wire.", //help886
	"Choose a unique name for your policy.", //_aa_wiz_s2_msg
	"Select the protocol used by the Internet traffic coming back into the router through the opened port range (for example <code>Both</code>).", //help52
	"seconds ...", //wps_KR46
	"Give your network a name, using up to 32 characters.", //wwz_wwl_intro_s3_1
	"Ghost Recon", //gw_gm_19
	"The DDNS feature allows you to host a server (Web, FTP, Game Server, etc...) using a domain name that you have purchased (www.whateveryournameis.com) with your dynamically assigned IP address. Most broadband Internet Service Providers assign dynamic (changing) IP addresses. Using a DDNS service provider, your friends can enter your host name to connect to your game server no matter what your IP address is.", //td_intro_DDNS
	"(GMT+07:00) Bangkok, Hanoi, Jakarta", //up_tz_53
	"DST Start and DST End", //help845
	"This page will refresh shortly.", //wt_p_3
	"(GMT+06:00) Sri Jayawardenepura", //up_tz_51
	"Alternatively, you can direct the setup executable to a folder on your computer containing a printer driver you have downloaded from the printer manufacturer's web site.", //wprn_s3d
	"CHAP authentication failed - please check login details.", //IPPPPCHAP_AUTH_FAIL
	"Tiberian Sun", //gw_gm_52
	"Blocked TCP packet from %v:%u to %v:%u as control %s in not valid", //IPNAT_TCP_BAD_FLAGS
	"Name", //_name
	"Enter the local network IP address of the system hosting the server, for example <code>192.168.0.50</code>.", //help66
	"Blocked incoming ICMP error message (ICMP type %u) from %v to %v as there is no UDP session active between %v:%u and %v:%u", //IPNAT_UDP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"FTP ALG rejected packet from %v:%u to %v:%u", //IPFTPALG_REJECTED_PACKET
	"Access to this Web site is not allowed from this computer.", //fb_p_1
	"Connection Type", //_contype
	"The port that you will use to address the management interface from the Internet. For example, if you specify port 1080 here, then, to access the router from the Internet, you would use a URL of the form: <code>http://my.domain.com:1080/</code>.", //help829
	"Application Rules", //_specappsr
	"The Invisible option allows you to hide your wireless network. When this option is set to Visible, your wireless network name is broadcast to anyone within the range of your signal. If you're not using encryption then they could connect to your network. When Invisible mode is enabled, you must enter the Wireless Network Name (SSID) on the client manually to connect to the network.", //help353
	"Halo: Combat Evolved", //gw_gm_23
	"Always Broadcast", //help325
	"Reconnect Mode", //bwn_RM
	"Log Options", //sl_LogOps
	"All of your Internet and network connection details are displayed on the Device Info page. The firmware version is also displayed here.", //help772
	"Method", //_aa_method
	"Log Details", //sl_LogDet
	"This is a relative measure of signal quality. The value is expressed as a percentage of theoretical best quality. Signal quality can be reduced by distance, by interference from other radio-frequency sources (such as cordless telephones or neighboring wireless networks), and by obstacles between the router and the wireless device.", //help788
	"Continue", //_continue
	"The Statistics page displays all of the LAN, WAN, and Wireless packet transmit and receive statistics.", //help804
	"Device Info", //_devinfo
	"Yes", //_yes
	"SSID", //help699
	"(GMT+10:00) Yakutsk", //up_tz_62
	"In this section you can add entries to the Schedule Rules List below or edit existing entries.", //help192
	"Enable DHCP-PD", //DHCP_PD_ENABLE
	"Need for Speed", //gw_gm_31
	"A connection to the Internet is always maintained.", //help271
	"Allows multiple machines on the LAN to connect to their corporate networks using PPTP protocol.", //help33
	"Blocked incoming TCP packet from %v:%u to %v:%u with unexpected acknowledgement %lu (expected %lu to %lu)", //IPNAT_TCP_BLOCKED_INGRESS_BAD_ACK
	"Start pinging the specified host.", //htsc_pingt_p
	"Check Now", //tf_CKN
	"Check Printer Status", //wprn_cps
	"(GMT+06:00) Ekaterinburg", //up_tz_45
	"By default, the router automatically determines whether the underlying connection is an xDSL/Frame-relay network or some other connection type (such as cable modem or Ethernet), and it displays the result as <span class=\"option\">Detected xDSL or Frame Relay Network</span>. If you have an unusual network connection in which you are actually connected via xDSL but for which you configure either \"Static\" or \"DHCP\" in the WAN settings, setting this option to <span class=\"option\"> xDSL or Other Frame Relay Network</span> ensures that the router will recognize that it needs to shape traffic slightly differently in order to give the best performance. Choosing <span class=\"option\">xDSL or Other Frame Relay Network</span> causes the measured uplink speed to be reported slightly lower than before on such connections, but gives much better results.", //help84
	"Latest firmware version %d.%02d is available", //GW_FW_NOTIFY_FIRMWARE_AVAIL
	"RX Packets Dropped", //ss_RXPD
	"Web site %S blocked for %s", //WEB_FILTER_LOG_URL_BLOCKED_MAC
	"Port trigger ALG failed to allocate session for TCP packet from %v:%u to %v:%u", //IPPORTTRIGGERALG_TCP_PACKET_ALLOC_FAILURE
	"Note: You may also need to provide a Host Name. If you do not have or know this information, please contact your ISP.", //wwa_note_hostname
	"Action", //ai_Action
	"Reset configuration to factory defaults", //RUNTIME_CONFIG_RESET_CONFIG_TO_FACTORY_DEFAULTS
	"No printer detected", //sps_nopr
	"Hours", //gw_hours
	"Fri", //_Fri
	"LPD/LPR Printing", //tps_lpd
	"Firmware Upgrade", //tf_FWUg
	"10Mbps", //anet_wp_0
	"Battlefield 1942", //gw_gm_4
	"Both of these options select some variant of Wi-Fi Protected Access (WPA) -- security standards published by the Wi-Fi Alliance. The <span class ='option'>WPA Mode</span> further refines the variant that the router should employ.", //help373
	"Daylight Saving Offset", //tt_dsoffs
	"Automatically assign a network key (Recommended)", //wwz_auto_assign_key
	"Doom 3", //gw_gm_15
	"For information on which security features your wireless adapters support, please refer to the adapters' documentation.", //wwl_s3_note_1
	"Click <strong>Save</strong> to add a completed schedule to the list below.", //hhts_save
	"Auto-detect", //at_Auto
	"Pings sent:", //tsc_pingt_msg100
	"PPP network down", //IPPPPIPCP_PPP_LINK_DOWN
	"Address Type", //aa_AT
	"Ubi.com", //gw_gm_71
	"Step 3 - Select the machine to which this policy applies", //aa_wiz_s1_msg3
	"BigPond failed, see log for details", //BIGPOND_FAILED
	"The time between periodic updates to the Dynamic DNS, if your dynamic IP address has not changed. The timeout period is entered in hours.", //help898
	"PPTP Server IP Address", //bwn_PPTPSIPA
	"Routing", //_routing
	"Create a list of MAC addresses that you would either like to allow or deny access to your network.", //hham_intro
	"WPS Internal Registrar did not receive request from any wireless station in 2 minutes and stopped.", //WIFISC_IR_REGISTRATION_FAIL_3
	"The Inbound Filter option is an advanced method of controlling data received from the Internet. With this feature you can configure inbound data filtering rules that control data based on an IP address range.", //ai_intro_1
	"Step 2: Select your Time Zone", //wwa_title_s2
	"(GMT+11:00) Vladivostok", //up_tz_69
	"MSCHAP sent authentication response to peer.", //IPMSCHAP_AUTH_RESULT
	"The current system settings can be saved as a file onto the local hard drive. The saved file or any other saved setting file created by device can be uploaded into the unit.", //tss_intro2
	"If you select this option, the router automatically finds the channel with least interference and uses that channel for wireless networking. If you disable this option, the router uses the channel that you specify with the following <span class=\"option\">Wireless Channel</span> option.", //help354
	"(GMT-03:00) Buenos Aires, Georgetown", //up_tz_19
	"You must enter the name of a configuration file first.", //ta_alert_5
	"Always broadcast", //bd_DAB
	"WPA-Enterprise", //_WPAenterprise
	"Internet access control dropped packet from %v:%u[%s] to %v:%u (protocol %u)", //GW_INET_ACCESS_DROP_ACCESS_CONTROL_MAC
	"Printer", //sps_pr
	"(GMT+02:00) Harare, Pretoria", //up_tz_34
	"Pre-Shared Key", //_psk
	"Dynamic DNS", //_dyndns
	"Deny", //_deny
	"Blocked incoming TCP packet from %v:%u to %v:%u as %s is not allowed in state %s", //IPNAT_TCP_BLOCKED_INGRESS_UNEXP_FLAGS
	"Maximum Idle Time", //help276
	"to", //_to
	"IP", //aa_AT_0
	"Dec", //tt_Dec
	"Policy %s started; Internet access for all non-specified systems changed to: %s", //GW_INET_ACCESS_POLICY_START_OTHERS
	"(GMT+12:00) Magadan", //up_tz_75
	"(GMT+12:00) Fiji, Kamchatka, Marshall Is.", //up_tz_72
	"No response from host, retrying...", //tsc_pingt_msg11
	"Are you sure you want to delete this entry?", //up_ae_de_1
	"This area of the screen continually updates to show all DHCP enabled computers and devices connected to the LAN side of your router. The detection \"range\" is limited to the address range as configured in DHCP Server. Computers that have an address outside of this range will not show. If the DHCP Client (i.e. a computer configured to \"Automatically obtain an address\") supplies a Host Name then that will also be shown. Any computer or device that has a static IP address that lies within the detection \"range\" may show, however its host name will not.", //help781
	"Enter the MAC address of the desired.", //help161_2
	"06:00 PM", //tt_time_19
	"Configure MAC Filtering below:", //am_intro
	"The number of transmission failures that cause loss of a packet.", //help811
	"Medium", //aw_TP_1
	"(GMT) Casablanca, Monrovia", //up_tz_24
	"MSCHAP authentication details were sent to authenticator.", //IPMSCHAP_AUTH_SENT
	"Use this option to view the wireless clients that are connected to your wireless router.", //sw_intro
	"The LPD/LPR printing protocol uses a fixed IP address and queue name to communicate with your printer.", //tps_lpd1
	"and", //help257
	"The router will now be reprogrammed using the uploaded firmware file. Please wait <span id=\"show_sec\"></span>&nbsp;seconds for this process to complete, after which you may access these web pages again. Pressing reload or back on your browser may cause this operation to fail.", //_upgintro
	"Closed -- The connection is no longer active but the session is being tracked in case there are any retransmitted packets still pending.", //help819_8
	"(seconds)", //bws_secs
	"Blocked outgoing ICMP packet (ICMP type %u) from %v to %v", //IPNAT_ICMP_BLOCKED_EGRESS_PACKET
	"Port Forwarding", //PORT_FORWARDING
	"Dynamic IP (DHCP)", //bwn_Mode_DHCP
	"Hour", //tt_Hour
	"Enter the IP addresses of the DNS Servers. Leave the field for the secondary server empty if not used.", //help290a
	"BigPond logging out", //BIGPOND_LOGGING_OUT
	"If you are having trouble receiving multicast streams from the Internet, make sure the Multicast Streams option is enabled.", //hhan_mc
	"Primary DNS Server", //_dns1
	"Primary IPv6 DNS Server", //_dns1_v6
	"Tools", //_tools
	"Disconnected", //_sdi_s2
	"USB Port", //sps_usbport
	"System error occured when allocating schedule %s", //GW_SCHED_ALLOC_FAILED
	"Prevent all WAN users from accessing the related capability. (LAN users are not affected by Inbound Filter Rules.)", //help179
	"Enable BigPond:", //help262
	"Allow", //_allow
	"Select the level of events that you want to view.", //help798
	"Obtained IP Address using DHCP. IP address is %v", //DHCP_CLIENT_GOT_LEASE
	"WAN Port Speed", //anet_wan_phyrate
	"Note", //_note
	"Dest<br />Port<br />Start", //aa_FPR_c6
	"UDP Ports To Open", //help69
	"DHCP Lease Time", //bd_DLT
	"Inbound Filter Rules List", //ai_title_IFRL
	"LAN interface is up", //GW_LAN_INTERFACE_UP
	"Logs", //_logs
	"Turn MAC Filtering OFF", //am_FM_2
	"Sending log email after administrator request", //GW_LOG_EMAIL_ON_USER_REQUEST
	"The port that will be accessed from the Internet.", //help21
	"802.11 Mode", //bwl_Mode
	"Address Mode", //bwn_AM
	"BigPond Server", //bwn_BPS
	"Enter the information provided by your Internet Service Provider (ISP).", //_ispinfo
	"Rate", //_rate
	"(GMT-07:00) Mountain Time (US/Canada)", //up_tz_06
	"Success", //_success
	"Sentinel Parental Controls Service", //_bsecure_parental_serv
	"Set Username and Password Connection (L2TP)", //wwa_set_l2tp_title
	"Mac OS X", //help342
	"Select this option if your ISP requires you to use a PPPoE (Point to Point Protocol over Ethernet) connection. DSL providers typically use this option. This method of connection requires you to enter a <span class=\"option\">Username</span> and <span class=\"option\">Password</span> (provided by your Internet Service Provider) to gain access to the Internet.", //help265
	"SMTP (Email) server %s is at IP address %v", //GW_SMTP_EMAIL_RESOLVED_DNS
	"Pings lost", //tsc_pingt_msg102
	"RADIUS server Port", //bws_RSP
	"Trying to establish a PPPoE connection", //PPPOE_EVENT_CONNECT
	"Automatic Time Configuration", //tt_auto
	"The PPTP subsystem is low on resources. Connectivity may be affected.", //PPTP_EVENT_LOW_RESOURCES_TO_QUEUE
	"L2TP local tunnel 0x%04X received unexpected control message (ignored)", //IPL2TP_TUNNEL_UNEXPECTED_MESSAGE
	"Neverwinter Nights", //gw_gm_34
	"5th", //tt_week_5
	"Below is a detailed summary of your wireless security settings. Please print this page out, or write the information on a piece of paper, so you can configure the correct settings on your wireless client adapters.", //wwl_intro_end
	"Policy Table", //aa_Policy_Table
	"Time Configuration", //tt_TimeConf
	"None", //_none
	"Step 2: Select Schedule", //_aa_wiz_s3_title
	"A pass-phrase that must match with the authentication server.", //help392
	"Sending log email on schedule", //GW_LOG_EMAIL_ON_SCHEDULE
	"Select the appropriate time zone for your location. This information is required to configure the time-based options. Your router will be set to automatically update its internal clock from an NTP time server.", //wwa_intro_s2
	"PPTP Gateway IP Address", //_PPTPgw
	"Web site %S accessed from %v", //WEB_FILTER_LOG_URL_ACCESSED
	"MMS ALG rejected packet from %v:%u to %v:%u", //IPMMSALG_REJECTED_PACKET
	"Wireless Settings", //_wirelesst
	"There are two ways to set up your Internet connection: you can use the Web-based Internet Connection Setup Wizard, or you can manually configure the connection.", //int_intro
	"Access denied to LAN system with MAC address %m", //GW_LAN_ACCESS_DENIED
	"Jedi Knight II: Jedi Outcast", //gw_gm_26
	"Blocked incoming GRE packet from %v to %v", //PPTP_ALG_GRE_BLOCKED_INGRESS
	"(GMT+01:00) West Central Africa", //up_tz_30
	"Starcraft", //gw_gm_49
	"Schedule", //_sched
	"Failed to mount FAT device", //IPFAT_MOUNT_FAILED
	"KALI", //gw_gm_75
	"Here are displayed the version numbers of the firmware currently installed in your router and the most recent upgrade that is available.", //help883
	"Please wait, uploading configuration file", //ta_alert_6
	"Policy %s started; Internet access for IP address %v changed to: %s", //GW_INET_ACCESS_POLICY_START_IP
	"Displays the time currently maintained by the router. If this is not correct, use the following options to configure the time correctly.", //help841a
	"10:00 PM", //tt_time_23
	"Port Forwarding Rules", //ag_title_4
	"WinMX", //gw_gm_68
	"Blocked outgoing TCP packet from %v:%u to %v:%u as %s is not allowed in state %s", //IPNAT_TCP_BLOCKED_EGRESS_UNEXP_FLAGS
	"Host Name", //help260
	"FIN Wait -- The client system has requested that the connection be stopped.", //help819_4
	"If all of the wireless devices you want to connect with this router can connect in the same transmission mode, you can improve performance slightly by choosing the appropriate \"Only\" mode. If you have some devices that use a different transmission mode, choose the appropriate \"Mixed\" mode.", //help357
	"TCP", //_TCP
	"MSCHAP authentication challenge received from peer.", //IPMSCHAP_CHALLENGE_RECVD
	"Universal Plug and Play (UPnP) supports peer-to-peer Plug and Play functionality for network devices.", //anet_msg_upnp
	"Clicking the <span class=\"button_ref\">DHCP Release</span> button unassigns the router's IP address. The router will not respond to IP messages from the WAN side until you click the <span class=\"button_ref\">DHCP Renew</span> button or power-up the router again. Clicking the <span class=\"button_ref\">DHCP Renew</span> button causes the router to request a new IP address from the ISP's server.", //help776
	"Please Select Configuration Method to set up your Wireless Network", //KR49
	"Here you can enable or disable ALGs. Some protocols and applications require special handling of the IP payload to make them work with network address translation (NAT). Each ALG provides special handling for a specific protocol or application. A number of ALGs for common applications are enabled by default.", //help32
	"Asheron's Call", //gw_gm_3
	"The number of seconds of idle time until the router considers the session terminated.", //help823
	"L2TP IP Address", //_L2TPip
	"Reboot the Device", //_reboot
	"There are two ways to add wireless device to your wireless network:", //wps_p3_1
	"Step 3: Insert the printer driver CD if requested", //wprn_intro5
	"Sentinel Security Services", //_bsecure_security_serv
	"received in", //tsc_pingt_msg8
	"Unreal Tournament", //gw_gm_56
	"The Firmware Upgrade section can be used to update to the latest firmware code to improve functionality and performance.", //tf_intro_FWU
	"(GMT+08:00) Kuala Lumpur, Singapore", //up_tz_57
	"Firmware upgrade server %s is at IP address %v", //GW_FW_NOTIFY_RESOLVED_DNS
	"Port And Address Restricted", //af_EFT_2
	"(GMT-12:00) Eniwetok, Kwajalein", //up_tz_00
	"Schedules are used with a number of other features to define when those features are in effect.", //hhts_intro
	"Authentication", //_auth
	"L2TP local tunnel 0x%04X is disconnecting", //IPL2TP_TUNNEL_DISCONNECTING
	"Time synchronization failed after retries ... giving up", //NET_RTC_SYNCHRONIZATION_FAILED_AFTER_RETRIES
	"Firmware Version", //sd_FWV
	"Schedule Rules List", //tsc_SchRuLs
	"Enabling WLAN Partition prevents associated wireless clients from communicating with each other.", //KR58_ww
	"optional", //YM98
	"Save Configuration", //ta_SavConf
	"Secondary DNS Address", //wwa_sdns
	"This option restores all configuration settings back to the settings that were in effect at the time the router was shipped from the factory. Any settings that have not been saved will be lost. If you want to save your router configuration settings, use the Save Settings option above.", //help876
	"This option uses Wi-Fi Protected Access with a Pre-Shared Key (PSK).", //help380
	"Network Filter", //_netfilt
	"Days", //gw_days
	"Login", //li_Login
	"WAN is already connected", //WAN_ALREADY_CONNECTED
	"WPA2 Only", //bws_WPAM_3
	"Gateway address %v must not be the address of the intended interface", //GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS
	"password must be specified", //GW_DYNDNS_PASSWORD_INVALID
	"Virtual Server Item", //tool_admin_vsname
	"(GMT+06:00) Astana, Dhaka", //up_tz_50
	"Static IP", //static_PPPoE
	"Start Time", //tsc_StrTime
	"Shortest ping time (in milliseconds):", //tsc_pingt_msg104
	"Printer Device ID Error", //wprn_iderr
	"Select this option will display the current wireless settings for you to configure the wireless device manually", //wps_KR42
	"Timeout", //td_Timeout
	"Apply Web Filter", //_aa_apply_web_filter
	"Reset to Unconfigured", //resetUnconfiged
	"Gaming", //GAMING
	"08:00 AM", //tt_time_9
	"Blocked incoming packet from %v to %v (IP protocol %u)", //IPNAT_BLOCKED_INGRESS
	"WAN interface is up. Connection to Internet established with IP Address %v and default gateway %v", //GW_WAN_INTERFACE_UP
	"Router IP Address", //_ripaddr
	"Time Out", //sa_TimeOut
	"Blocked outgoing TCP packet from %v:%u to %v:%u with unexpected sequence %lu (expected %lu to %lu)", //IPNAT_TCP_BLOCKED_EGRESS_BAD_SEQ
	"LAN interface is down", //GW_LAN_INTERFACE_DOWN
	"Depending on whether the WAN connection is currently established, you can click either the <span class=\"button_ref\">Connect</span> to attempt to establish the WAN connection or the <span class=\"button_ref\">Disconnect</span> to break the WAN connection.", //help778
	"Queue Name", //sps_qname
	"seconds", //_seconds
	"Log cleared by IP address %v", //GW_LOGS_CLEARED
	"Warning", //sl_Warning
	"Machine Address", //aa_MAC
	"Select this option if your wireless device supports WPS (Wi-Fi Protected Setup)", //wps_KR51
	"Manual", //help274
	"Using a short (400ns) guard interval can increase throughput. However, it can also increase error rate in some installations, due to increased sensitivity to radio-frequency reflections.", //aw_sgi_h1
	"Blocked source-routed packet from %v to %v", //IPSTACK_REJECTED_SOURCE_ROUTED_PACKET
	"Primary DNS Address", //wwa_pdns
	"Use this option to restore previously saved router configuration settings.", //help834
	"Sun", //_Sun
	"Number of Devices", //sto_no_dev
	"To prevent outsiders from accessing your network, the router will automatically assign a security (also called WEP or WPA key) to your network.", //wwz_auto_assign_key2
	"Number of Spatial Streams", //bwl_NSS
	"(GMT-04:00) Caracas, La Paz", //up_tz_15
	"Once you have found the file to be used, click the <span class=\"button_ref\">Upload</span> button below to start the firmware upgrade process. This can take a minute or more.", //help880
	"Trying to connect to L2TP server", //IPL2TP_TUNNEL_CONNECTING
	"Enable SharePort For Guest Zone", //bwn_mici_guest_use_shareport
	"Time synchronized", //NET_RTC_SYNCHRONIZED
	"(GMT-06:00) Saskatchewan", //up_tz_10
	"On", //_on
	"You are not logged in, please refresh the browser", //NOT_LOGGED_IN_PLEASE_REFRESH
	"Blocked incoming ESP packet from %v to %v", //IPSEC_ALG_ESP_BLOCKED_INGRESS
	"continue", //ub_continue
	"Username or Key", //td_UNK
	"Failed to mount PV%d device", //IPPMVM_MOUNT_FAILED
	"Rise of Nations", //gw_gm_42
	"The LAN address that you want to reserve.", //_1066
	"All Week", //tsc_AllWk
	"Virtual Server", //_virtserv
	"The Virtual Server option gives Internet users access to services on your LAN. This feature is useful for hosting online services such as FTP, Web, or game servers. For each Virtual Server, you define a public port on your router for redirection to an internal LAN IP Address and LAN port.", //help2
	"Select this option if you want logs to be sent by email when the log is full.", //help869
	"LCP sets local options: ACCM: %lx, ACFC: %u, PFC: %u, MRU: %u", //IPPPPLCP_SET_LOCAL_OPTIONS
	"Reboot The Device", //ts_rd
	"IPSec ALG rejected packet from %v:%u to %v:%u", //IPSEC_ALG_REJECTED_PACKET
	"Please wait, resolving", //tsc_pingt_msg3
	"Wireless system with MAC address %m disconnected for reason: %s", //GW_WIRELESS_DEVICE_DISCONNECTED
	"Wireless Radio", //sd_WRadio
	"Allowed, Web Sites - %s%s, Ports - %s", //ALLOWED_WEB_SITES
	"BitTorrent", //gw_sa_1
	"UDP", //_UDP
	"Putting a computer in the DMZ may expose that computer to a variety of security risks. Use of this option is only recommended as a last resort.", //help166
	"The Access Control section allows you to control access in and out of devices on your network. Use this feature as Parental Controls to only grant access to approved sites, limit web access based on time or dates, and/or block access from applications such as peer-to-peer utilities or games.", //help117
	"L2TP Internet Connection Type", //bwn_L2TPICT
	"The router automatically logs (records) events of possible interest in its internal memory. If there is not enough internal memory for all events, logs of older events are deleted, but logs of the latest events are retained. The Logs option allows you to view the router logs. You can define what types of events you want to view and the level of events to view. This router also has internal Syslog Server support so you can send the log files to a computer on your network that is running a Syslog utility.", //help795
	"No", //_no
	"(GMT+09:30) Adelaide", //up_tz_63
	"You must enter the name of a firmware file first.", //tf_FWF1
	"(GMT+10:00) Brisbane", //up_tz_65
	"Priority", //_priority
	"WAN is already disconnected", //WAN_ALREADY_DISCONNECTED
	"There is unsaved data on this page. Do you want to abandon it?", //up_jt_1
	"Internet access for all non-specified systems set to: %s", //GW_INET_ACCESS_INITIAL_OTHERS
	"The starting and ending IP addresses are WAN-side address.", //hhai_ip
	"This option is used to open single or multiple ports on your router when the router senses data sent to the Internet on a \"trigger\" port or port range. Special Applications rules apply to all computers on your internal network.", //as_intro_SA
	"Ping Test sends \"ping\" packets to test a computer on the Internet.", //tsc_pingt_mesg
	"(GMT+04:30) Kabul", //up_tz_44
	"You might have trouble accessing a virtual server using its public identity (WAN-side IP-address of the gateway or its dynamic DNS name) from a machine on the LAN. Your requests may not be looped back or you may be redirected to the \"Forbidden\" page.", //help27
	"IPSec (VPN)", //as_IPSec
	"Admin", //_admin
	"eDonkey", //gw_gm_65
	"To upgrade the firmware, locate the upgrade file on the local hard drive with the Browse button.Once you have found the file to be used, click the Upload button below to start the firmware upgrade.", //tf_intro_FWChB
	"Blocked", //BLOCKED
	"BigPond Cable (Australia)", //wwa_msg_bigpond
	"Enable Logging To Syslog Server", //help857
	"Close Wait -- the server system has requested that the connection be stopped.", //help819_5
	"Low", //aw_TP_2
	"Authentication Timeout", //help385
	"Setup Complete!", //_setupdone
	"Log in to the router", //li_intro
	"SMTP client failed to send email", //IPSMTPCLIENT_MSG_FAILED
	"Before launching these wizards, please make sure you have followed all steps outlined in the Quick Installation Guide included in the package.", //bwz_note_ConWz
	"Gnutella", //gw_gm_64
	"Reconnect Mode:", //help268
	"None Blocked", //NONE_BLOCKED
	"May", //tt_May
	"Big Pond Internet Connection Type", //bwn_BPICT
	"02:00 PM", //tt_time_15
	"Tue", //_Tue
	"Clear Statistics", //ss_clear_stats
	"The end time is entered in the same format as the start time. The hour in the first box and the minutes in the second box. The end time is used for most other rules, but is not normally used for email events.", //help197
	"Filter rules can be used with Virtual Server, Port Forwarding, or Remote Administration features.", //ai_intro_3
	"WAN connection inactive too long so attempting to disconnect", //GW_WAN_DISCONNECT_ON_INACTIVE
	"The DHCP address %v is released by the user", //DHCP_CLIENT_RELEASED_LEASE
	"Set Static IP Address Connection", //wwa_set_sipa_title
	"(GMT+12:00) Auckland, Wellington", //up_tz_71
	"ALGs provide special handling of the IP payload for some protocols and applications to make them work with network address translation (NAT). If you are having trouble using any of these applications, try both enabling and disabling the corresponding ALG.", //hhaf_alg
	"Check this option if your location observes daylight saving time.", //help843
	"Verify that a printer is attached to the router's USB port.", //wprn_tt11
	"Traffic Statistics", //_tstats
	"LCP sets remote options: ACCM: %lx, ACFC: %u, PFC: %u, MRU: %u", //IPPPPLCP_SET_REMOTE_OPTIONS
	"Check Online Now for Latest Firmware and Language pack Version", //tf_COLF
	"(GMT+01:00) Brussels, Copenhagen, Madrid, Paris", //up_tz_28
	"Mar", //tt_Mar
	"Log Web Access Only", //_aa_allow_all
	"Username / Password Connection (L2TP)", //wwa_wanmode_l2tp
	"DMZ Host", //_dmzh
	"Time server %s is at IP address %v", //GW_TIME_RESOLVED_DNS
	"EAP (802.1x)", //bws_EAPx
	"Policy Name", //aa_PolName
	"To set up this connection you will need to have a complete list of IP information provided by your Internet Service Provider. If you have a Static IP connection and do not have this information, please contact your ISP.", //wwa_set_sipa_msg
	"Step 1: Choose Policy Name", //_aa_wiz_s2_title
	"PPTP connected to server \"%s\" with ID 0x%04X", //PPTP_EVENT_TUNNEL_CONNECTED
	"No WCN compatible USB mass storage interface was found", //USB_LOG_STORAGE_NOT_FOUND
	"Device initialized", //GW_INIT_DONE
	"Dynamic IP", //carriertype_ct_0
	"These are the settings of the LAN (Local Area Network) interface for the router. The router's local network (LAN) settings are configured based on the IP Address and Subnet Mask assigned in this section. The IP address is also used to access this Web-based management interface.", //help305
	"Raw TCP Port Printing", //tps_raw
	"Public Port", //av_PubP
	"WPA Mode:", //help374
	"PPTP received a tunnel clear down request from the application, the tunnel will now be closed.", //PPTP_EVENT_TUNNEL_CLEAR_DOWN_REQUEST
	"Click the <strong>Delete</strong> icon to permanently remove a rule.", //hhac_delete
	"L2TP local session 0x%04X terminating", //IPL2TP_SESSION_CLEAR_DOWN_REQUEST
	"Policy", //aa_ACR_c2
	"The requests from the LAN machine will not be looped back if Internet access is blocked at the time of access. To work around this problem, access the LAN machine using its LAN-side identity.", //help29
	"(GMT-11:00) Midway Island, Samoa", //up_tz_01
	"Application", //_app
	"Invalid LAN subnet mask.", //bln_alert_1
	"Estimating speed of WAN interface", //GW_WAN_RATE_ESTIMATOR_STARTED_ON_WAN
	"Firewall &amp; Security", //sl_FWandSec
	"For added security, it is recommended that you disable the WAN Ping Respond option. Ping is often used by malicious Internet users to locate active networks or PCs.", //hhan_ping
	"NAT", //sa_NAT
	"Enabling Remote Management allows you to manage the router from anywhere on the Internet. Disabling Remote Management allows you to manage the router only from computers on your LAN.", //help828
	"Unable to find DNS record for SMTP (Email) server %s", //GW_SMTP_EMAIL_FAILED_DNS
	"The number of packets that were dropped due to Ethernet collisions (two or more devices attempting to use an Ethernet circuit at the same time).", //help810
	"Wake-On-LAN", //_WOL
	"On demand", //bwn_RM_1
	"None -- This entry is used as a placeholder for a future connection that may occur.", //help819_1
	"Blocked incoming ICMP error message (ICMP type %u) from %v to %v as there is no TCP connection active between %v:%u and %v:%u", //IPNAT_TCP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"(GMT-04:00) Atlantic Time (Canada)", //up_tz_14
	"Star Trek: Elite Force II", //gw_gm_51
	"Server Address", //td_SvAd
	"You can enter ports in various formats:", //hhag_40
	"Inbound Filters can be used for limiting access to a server on your network to a system or group of systems. Filter rules can be used with Virtual Server, Gaming, or Remote Administration features. Each filter can be used for several functions; for example a \"Game Clan\" filter might allow all of the members of a particular gaming group to play several different games for which gaming entries have been created. At the same time an \"Admin\" filter might only allows systems from your office network to access the WAN admin pages and an FTP server you use at home. If you add an IP address to a filter, the change is effected in all of the places where the filter is used.", //help169
	"The amount of time that a computer may have an IP address before it is required to renew the lease. The lease functions just as a lease on an apartment would. The initial lease designates the amount of time before the lease expires. If the tenant wishes to retain the address when the lease is expired then a new lease is established. If the lease expires and the address is no longer needed than another tenant may use the address.", //help324
	"Ping is an Internet utility function that sends a series of short messages to a target computer and reports the results. You can use it to test whether a computer is running, and to get an idea of the quality of the connection to that computer, based on the speed of the responses.", //htsc_intro
	"WLAN Partition", //KR4_ww
	"The computers (and other devices) connected to your LAN also need to have their TCP/IP configuration set to \"DHCP\" or \"Obtain an IP address automatically\".", //help317
	"Multicast Streams", //anet_multicast
	"IPv4 Multicast Streams", //anet_multicast_v4
	"IPv6 Multicast Streams", //anet_multicast_v6
	"Add New Policy", //_aa_wiz_s1_title
	"L2TP local tunnel 0x%04X RTE module has shut down.", //IPL2TP_SHUTDOWN_COMPLETE
	"Last ACK -- Waiting for a short time while a connection that was in Close Wait is fully closed.", //help819_7
	"Select the Protocol (for example <code>TCP</code>).", //help9
	"The number of packets that were dropped while being received, due to errors, collisions, or router resource limitations.", //help809
	"LAN Ethernet Carrier Detected", //GW_LAN_CARRIER_DETECTED
	"Are you sure you want to clear all log entries?", //sl_alert_1
	"Trigger Port", //as_TPRange_b
	"1st", //tt_week_1
	"If so, press Ok.", //up_jt_3
	"Clear", //_clear
	"Terminating PPPoE session 0x%04X", //PPPOE_EVENT_DISCONNECT
	"WPS Internal Registrar failed to add wireless station %m, reason: %s, err_code %u.", //WIFISC_IR_REGISTRATION_FAIL_2
	"Static IP", //_sdi_staticip
	"Give each schedule a name that is meaningful to you. For example, a schedule for Monday through Friday from 3:00pm to 9:00pm, might be called \"After School\".", //hhts_name
	"WAN", //WAN
	"Enter a password for the user \"admin\", who will have full access to the Web-based management interface.", //help824
	"Computers that have obtained an IP address from the router's DHCP server will be in the DHCP Client List. Select a device from the drop down menu, then click the arrow to add that device's MAC address to the list.", //hham_add
	"WAN Statistics", //ss_WANStats
	"Attempting to start WAN connection on-demand", //GW_WAN_CONNECT_ON_ACTIVE
	"You must abandon all your changes in order to define a new schedule.", //aa_sched_conf_1
	"Policy %s stopped; Internet access for all non-specified systems changed to: %s", //GW_INET_ACCESS_POLICY_END_OTHERS
	"DHCP Reservations List", //bd_title_list
	"Web Access Logging", //_aa_logging
	"Blocked incoming ICMP error message (ICMP type %u) from %v to %v as there is no session active for protocol %u between %v and %v", //IPNAT_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"User Name", //_username
	"eMule", //gw_gm_67
	"Unable to find DNS record for time server %s", //GW_TIME_FAILED_DNS
	"Refer to the documentation that came with your router for printer setup instructions specific to your operating system.", //wprn_tt1
	"09:00 PM", //tt_time_22
	"IP address", //help256
	"Internet access policy for IP address %v cannot be set", //GW_INET_ACCESS_INITIAL_IP_FAIL
	"Details", //_aa_details
	"Allows applications that use Real Time Streaming Protocol to receive streaming media from the internet. QuickTime and Real Player are some of the common applications using this protocol.", //help36
	"The port number of the LAN-side application as viewed by the WAN-side application.", //help817
	"PPPoE (Username / Password)", //bwn_Mode_PPPoE
	"Allow All", //_allowall
	"Clear the list below...", //awf_clearlist
	"The router must be rebooted before settings saved on a previous page will take effect. You can reboot the router now using the \"Reboot\" button below, or press the \"Continue\" button and make other changes.", //sc_intro_rb3
	"TCP Ports To Open", //help67
	"Quake 2", //gw_gm_37
	"Others", //aa_AT_2
	"Step 1: Set your Password", //wwa_title_s1
	"Driver Name", //tps_drname
	"Copy Your Computer's Time Settings", //tt_CopyTime
	"L2TP session server started sending sequencing numbers for local session 0x%04X", //IPL2TP_SEQUENCING_ACTIVATED
	"Reserve", //bd_Reserve
	"MSN Messenger ALG rejected packet from %v:%u to %v:%u", //IPMSNMESSENGERALG_REJECTED_PACKET
	"The wireless section allows you to view the wireless clients that are connected to your wireless router.", //help782
	"Dungeon Siege", //gw_gm_16
	"Port forwarding ALG failed to allocate session for UDP packet from %v:%u to %v:%u", //IPPORTFORWARDALG_UDP_PACKET_ALLOC_FAILURE
	"Model", //wprn_mod
	"Note:", //help119
	"Silent Hunter II", //gw_gm_46
	"Turn MAC Filtering ON and ALLOW computers listed to access the network", //am_FM_3
	"Use this information to configure your computer for LPD/LPR printing.", //sps_lpd1
	"System Settings", //tss_SysSt
	"Restore Configuration from File", //ta_ResConf
	"Updated flash to wireless configuration", //WCN_LOG_SAVE
	"Firewall Traffic Type", //as_FPrt
	"UDP connections.", //help823_11
	"Every Day", //tsc_EvDay
	"Click the <span class=\"button_ref\">Clear</span> button to remove the MAC address from the MAC Filtering list.", //ham_del
	"PPPoE", //_PPPoE
	"It appears that you have already successfully connected your new router to the Internet.", //wwa_intro_online1
	"DST End", //tt_dstend
	"Schedule Rule", //tsc_SchRu
	"Failed configuration authentication attempt by IP address %v", //GW_AUTH_FAILED
	"Schedules", //_scheds
	"(GMT+09:00) Irkutsk, Ulaan Bataar", //up_tz_56
	"Secondary DNS Server", //_dns2
	"Secondary IPv6 DNS Server", //_dns2_v6
	"You must enter a host name or IP address.", //tsc_pingt_msg2
	"These settings are automatically configured and should be modified only by advanced users.", //tps_apc1
	"Internet access control dropped packet from %v:%u to %v:%u (protocol %u)", //GW_INET_ACCESS_DROP_ACCESS_CONTROL_WITH_PORT
	"(GMT+05:45) Kathmandu", //up_tz_48
	"Admin Password", //_password_admin
	"Use this section to configure the built-in DHCP Server to assign IP addresses to the computers on your network.", //bd_intro_
	"RADIUS Server IP Address:", //help387
	"Allowed configuration authentication by IP address %v", //GW_AUTH_SUCCEEDED
	"CHAP Authentication details sent to peer.", //IPPPPCHAP_AUTH_SENT
	"The Parental Controls service is a simple yet effective way to limit access to offensive, illegal or hateful web sites. This service covers all PC's or Apple Computers behind your router and is always automatically updated in real time. (No need for you to download or manually input sites.) This service is fast and will not slow down your network.", //_bsecure_parental_blurb
	"This wizard will guide you through the following steps to add a new policy for Access Control.", //_aa_wiz_s1_msg
	"The number of packets received by the router.", //help807
	"(GMT+09:00) Seoul", //up_tz_61
	"L2TP Gateway IP Address", //_L2TPgw
	"MSCHAP authentication failed - please check login details.", //IPMSCHAP_AUTH_FAIL
	"Advanced:", //help395
	"Once you have a firmware update on your computer, use this option to browse for the file and then upload the information into the router.", //help888
	"Medal of Honor: Games", //gw_gm_29
	"The rule applies to a flow of messages whose WAN-side IP address falls within the range set here.", //help95
	"Beacon Period", //aw_BP
	"Stopping WAN Services", //GW_WAN_SERVICES_STOPPED
	"TeamSpeak", //gw_gm_79
	"Select a Network Time Server for synchronization. You can type in the address of a time server or select one from the list. If you have trouble using one server, select another.", //help850
	"You are hosting a Web Server on a PC that has LAN IP Address of 192.168.0.50 and your ISP is blocking Port 80.", //help4
	"(GMT-03:00) Brazilia", //up_tz_18
	"When you use the Virtual Server, Port Forwarding, or Remote Administration features to open specific ports to traffic from the Internet, you could be increasing the exposure of your LAN to cyberattacks from the Internet.", //help168a
	"PPTP ALG rejected packet from %v:%u to %v:%u", //PPTP_ALG_REJECTED_PACKET
	"SMTP Server Address", //te_SMTPSv
	"Battlefield 2", //gw_gm_84
	"L2TP local tunnel 0x%04X RTE module is low on resources.", //IPL2TP_LOW_RESOURCES
	"Click <strong>Add Policy</strong> to start the processes of creating a rule. You can cancel the process at any time. When you are finished creating a rule it will be added to the <strong>Policy Table</strong> below.", //hhac_add
	"Auto 10/100Mbps", //anet_wp_auto2
	"RTSP", //as_RTSP
	"Authentication &amp; Security", //_authsecmodel
	"MTU", //bwn_MTU
	"Steam", //gw_gm_72
	"WAN", //_WAN
	"Enhanced IGMP Proxy", //anet_multicast_enhanced
	"Command and Conquer Generals", //gw_gm_8
	"WPA", //_WPA
	"Re-type the password or key provided by your service provider. If the Dynamic DNS provider supplies only a key, enter that key in all three fields.", //help897
	"Blocked incoming TCP packet from %v:%u to %v:%u with unexpected sequence %lu (expected %lu to %lu)", //IPNAT_TCP_BLOCKED_INGRESS_BAD_SEQ
	"Response from", //tsc_pingt_msg7
	"Jan", //tt_Jan
	"Battlefield: Vietnam", //gw_gm_5
	"Advanced Wireless", //_adwwls
	"Pings received:", //tsc_pingt_msg101
	"Unreal", //gw_gm_55
	"WAN Ping", //anet_wan_ping
	"<warn>WINS/NetBIOS settings cannot be learned from the internet in this Internet mode - WINS will not function as expected.</warn>", //GW_DHCP_SERVER_WINS_INCOMPATIBILITY_WARNING
	"MAC Address Authentication", //bws_RMAA
	"Step 2 - Select a schedule", //aa_wiz_s1_msg2
	"06:00 AM", //tt_time_7
	"Initiated from WAN to LAN.", //help822a
	"America's Army", //gw_gm_1
	"(GMT+03:00) Baghdad", //up_tz_37
	"Security Mode", //bws_SM
	"(GMT+10:00) Hobart", //up_tz_68
	"- Exactly 64 characters using 0-9 and A-F", //wwl_s4_intro_za3
	"Prev", //_prev
	"Enable SharePort Web Access", //sto_http_1
	"The Printer Setup Wizard requires the raw TCP port printing protocol. This protocol is currently disabled on your router.", //wprn_foo1
	"A wireless network uses specific channels in the wireless spectrum to handle communication between clients. Some channels in your area may have interference from other electronic devices. Choose the clearest channel to help optimize the performance and coverage of your wireless network.", //help355
	"Logged", //aa_ACR_c6
	"Second RADIUS server Shared Secret", //bws_2RSSS
	"RADIUS Server Shared Secret:", //help391
	"PM", //_PM
	"Define the ranges of Internet addresses this rule applies to. For a single IP address, enter the same address in both the <span class=\"option\">Start</span> and <span class=\"option\">End</span> boxes. Up to eight ranges can be entered. The <span class=\"option\">Enable</span> checkbox allows you to turn on or off specific entries in the list of ranges.", //help174
	"PPPoE timed out waiting for connection. Connection attempt failed.", //PPPOE_EVENT_DISCOVERY_TIMEOUT
	"Device %s, wsetting.wfc: file not found", //WCN_LOG_NO_WSETTING
	"Paper Error", //psPaperError
	"If you leave this option unchecked, you are causing the router to ignore <code>ping</code> commands for the public WAN IP address of the router.", //anet_wan_ping_2
	"To upgrade the firmware, follow these steps:", //help878
	", Logged", //LOGGED
	"Manual", //bwn_RM_2
	"RADIUS server Shared Secret", //bws_RSSs
	"(GMT+04:00) Baku, Tbilisi, Yerevan", //up_tz_43
	"RTSP ALG rejected packet from %v:%u to %v:%u", //IPRTSPALG_REJECTED_PACKET
	"can't be deleted or renamed because it is used.", //GW_SCHEDULES_IN_USE_INVALID_s2
	"Advanced Help", //help1
	"MSN Game Zone", //gw_gm_73
	"Clicking any of these links or buttons will take you to another web site for further information.", //hhtsn_intro
	"Ping", //_ping
	"Manual Uplink Speed", //at_UpSp
	"Step 6 - Configure Web Access Logging", //aa_wiz_s1_msg6
	"PPTP IP Address", //_PPTPip
	"A DTIM is a countdown informing clients of the next window for listening to broadcast and multicast messages. When the wireless router has buffered broadcast or multicast messages for associated clients, it sends the next DTIM with a DTIM Interval value. Wireless clients detect the beacons and awaken to receive the broadcast and multicast messages. The default value is 1. Valid settings are between 1 and 255.", //help185
	"Click this button after changing Log Options to make them effective and permanent.", //help799
	"(GMT-03:30) Newfoundland", //up_tz_17
	"All of your Internet and network connection details are displayed on this page. The firmware version is also displayed here.", //sd_intro
	"Upload", //tf_Upload
	"Second", //tt_Second
	"This will cause all wireless settings to be lost.", //wps_lost
	"Note:", //help26
	"(GMT+02:00) Helsinki, Riga, Tallinn", //up_tz_35
	"Use this section to configure your Internet Connection type. There are several connection types to choose from Static IP, DHCP, PPPoE, PPTP, L2TP. If you are unsure of your connection method, please contact your Internet Service Provider.", //bwn_intro_ICS
	"Use this section to configure your Internet Connection type. There are several connection types to choose from: Static IP, DHCP, PPPoE, PPTP, L2TP, and 3G USB. If you are unsure of your connection method, please contact your Internet Service Provider.", //bwn_intro_ICS_3G
	"Use this section to configure your Internet Connection type. There are several connection types to choose from: Static IP, DHCP, PPPoE, PPTP, L2TP, and DS-Lite. If you are unsure of your connection method, please contact your Internet Service Provider.", //bwn_intro_ICS_v6
	"When enabled, this option causes the router to automatically measure the useful uplink bandwidth each time the WAN interface is re-established (after a reboot, for example).", //help81
	"This option allows you to save the router's configuration to a file on your computer. Be sure to save the configuration before performing a firmware upgrade.", //help833
	"Sent", //ss_Sent
	"Group Key Update Interval:", //help378
	"Tribes of Vengeance", //gw_gm_80
	"Upload Succeeded", //_uploadgood
	"PIN", //KR38
	"The setup executable will search for a compatible printer driver on your computer. If one cannot be found, you will be prompted to insert the driver CD that shipped with the printer.", //wprn_s3c
	"The router provides only limited firewall protection for the DMZ host. The router does not forward a TCP packet that does not match an active DMZ session, unless it is a connection establishment packet (SYN). Except for this limited protection, the DMZ host is effectively \"outside the firewall\". Anyone considering using a DMZ host should also consider running a firewall on that DMZ host system to provide additional protection.", //haf_dmz_20
	"Received", //ss_Received
	"Check this option to connect to the internet through Telstra BigPond Cable Broadband in Australia. Telstra BigPond provides the values for", //help263
	"FREE 30 Day Trial", //_bsecure_free_trial
	"Firmware Upgrade Notification Options", //tf_FUNO
	"Short GI", //aw_sgi
	"Amount of time before a client will be required to re-authenticate.", //help386
	"There are several connection types to choose from: Static IP, DHCP, PPPoE, PPTP and L2TP. If you are unsure of your connection method, please contact your Internet Service Provider. Note: If using the PPPoE option, you will need to ensure that any PPPoE client software on your computers is removed or disabled.", //help254_ict
	"There are several connection types to choose from: Static IP, DHCP, PPPoE, PPTP, L2TP, and 3G USB. If you are unsure of your connection method, please contact your Internet Service Provider. Note: If using the PPPoE option, you will need to ensure that any PPPoE client software on your computers is removed or disabled.", //help254_ict_3G
	"Select the method for filtering.", //_aa_wiz_s5_msg1
	"Verify Password or Key", //td_VPWK
	"Need for Speed 3", //gw_gm_33
	"Age of Empires", //gw_gm_0
	"MAC Address Filter", //_macfilt
	"To use this feature, you must first have a Dynamic DNS account from one of the providers in the drop down menu.", //TA16
	"(compatibility for some DHCP Clients)", //bd_DAB_note
	"Select the kinds of events that you want to view.", //help796
	"Do you really want to reprogram the device using the firmware file", //tf_really_FWF
	"(GMT-07:00) Arizona", //up_tz_05
	"03:00 PM", //tt_time_16
	"This email address will appear as the sender when you receive a log file or firmware upgrade notification via email.", //help861
	"Select the protocol used by the service.", //help19
	"DHCP WAN Mode", //bwn_DWM
	"ICMP", //_ICMP
	"Half Life", //gw_gm_22
	"Email Log When Full or on Schedule", //help868
	"Passphrase", //IPV6_TEXT24
	"05:00 AM", //tt_time_6
	"Click this button to start creating a new access control policy.", //_501_12
	"Check <strong>Enable Access Control</strong> if you want to enforce rules that limit Internet access from specific LAN computers.", //hhac_en
	"Manual Configure", //int_LWlsWz
	"Select Transmission Rate", //at_STR
	"Aug", //tt_Aug
	"Turn MAC Filtering ON and DENY computers listed to access the network", //am_FM_4
	"Step 5 - Select filters", //aa_wiz_s1_msg5
	"Access Control", //ACCESS_CONTROL
	"Error updating dynamic DNS entry: %s. Please check configuration. Disabling DynDNS", //GW_DYNDNS_HERROR
	"Ports to Open", //sps_ports
	"If you do not have the NTP Server option in effect, you can either manually set the time for your router here, or you can click the <span class=\"button_ref\">Copy Your Computer's Time Settings</span> button to copy the time from the computer you are using. (Make sure that computer's time is set correctly.)", //help851
	"You can select a computer from the list of DHCP clients in the <strong>Computer Name</strong> drop down menu, or you can manually enter the IP address of the LAN computer to which you would like to open the specified port.", //hhag_20
	"This Machine rule is already used.", //aa_alert_7
	"DMZ IP Address", //af_DI
	"Available Download Site", //tf_ADS
	"Ping Test", //tsc_pingt
	"View Levels", //sl_VLevs
	"Encryption", //wwl_enc
	"A MAC address is a unique ID assigned by the manufacturer of the network adapter.", //help151
	"Choose a port to open for remote management.", //hhta_pt
	"Internet access control dropped packet from %v to %v (protocol %u)", //GW_INET_ACCESS_DROP_ACCESS_CONTROL
	"Enable Authentication", //te_EnAuth
	"STA with MAC (%m) WPS process closed", //WIFISC_AP_PROXY_PROCESS_CLOSE
	"Computer Name", //bd_CName
	"It is recommended that you use the default settings if you do not have an existing network.", //help305rt
	"Invalid password, please try again.", //li_alert_3
	"Updating dynamic DNS entry due to timeout", //GW_DYNDNS_UPDATE_TO
	"4th", //tt_week_4
	"Day", //tt_Day
	"LAN Ethernet Carrier Lost", //GW_LAN_CARRIER_LOST
	"Each rule can either <strong>Allow</strong> or <strong>Deny</strong> access from the WAN.", //hhai_action
	"The Policy Wizard guides you through the steps of defining each access control policy. A policy is the \"Who, What, When, and How\" of access control -- whose computer will be affected by the control, what internet addresses are controlled, when will the control be in effect, and how is the control implemented. You can define multiple policies. The Policy Wizard starts when you click the button below and also when you edit an existing policy.", //help121
	"To set up this connection you will need to have a Username and Password from your Internet Service Provider. If you do not have this information, please contact your ISP.", //wwa_msg_set_pppoe
	"Blocked incoming ICMP packet (ICMP type %u) from %v to %v", //IPNAT_ICMP_BLOCKED_INGRESS_PACKET
	"to improve functionality and performance.", //tf_intro_FWU2
	"Enable QoS Engine", //at_ESE
	"Security Services are a great way to protect all your PC's with a unified suite of services that are managed from any web browser. Includes Anti-Virus, Firewall, Intrusion Detection, Content Filtering, Spam Killer and Pop-up blocker. Any or all services can be selected at one low price.", //_bsecure_security_blurb
	"DHCP Client List", //bd_DHCP
	"Enter your account for sending email.", //help865
	"The WEP ( Wired Equivalent Privacy) key must meet one of following guildelines:", //wwl_s4_intro_z1
	"Download", //help501
	"The ISP provides this parameter, if necessary. The value may be the same as the Gateway IP Address.", //help280
	"DHCP Connection", //help775
	"Connect", //_connect
	"BigPond enabled", //GW_BIGPOND_INIT
	"Always", //_always
	"(minutes)", //_minutes
	"Firewall Port", //as_IPR_b
	"Employment", //_aa_bsecure_employment
	"Internet access control dropped bad packet from %v to %v (protocol %u)", //GW_INET_ACCESS_DROP_BAD_PKT
	"Dark Reign 2", //gw_gm_12
	"Hexen II", //gw_gm_25
	"Select the starting and ending times for the change to and from daylight saving time. For example, suppose for DST Start you select Month=\"Oct\", Week=\"3rd\", Day=\"Sun\" and Time=\"2am\". This is the same as saying: \"Daylight saving starts on the third Sunday of October at 2:00 AM.\"", //help846
	"Please select one of Automatic or Manual Time setting. Not both", //tt_alert_1only
	"Gamespy Arcade", //gw_gm_76
	"Log viewed by IP address %v", //GW_LOGS_VIEWED
	"When WPA enterprise is enabled, the router uses EAP (802.1x) to authenticate clients via a remote RADIUS server.", //bws_msg_EAP
	"WPS Internal Registrar started %s registration", //WIFISC_IR_REGISTRATION_INPROGRESS
	"This is a list of all active conversations between WAN computers and LAN computers.", //hhsa_intro
	"This section allows you to archive your log files to a Syslog Server.", //help856
	"Dir", //sa_Dir
	"IGMP Multicast memberships", //_bln_title_IGMPMemberships
	"L2TP (Username / Password)", //bwn_Mode_L2TP
	"Thu", //_Thu
	"PIN(2nd half) Mismatch Detected", //KR30
	"Beacons are packets sent by a wireless router to synchronize wireless devices. Specify a Beacon Period value between 20 and 1000. The default value is set to 100 milliseconds.", //help184
	"Select the option that works best for your installation.", //_worksbest
	"unavailable", //_unavailable
	"Detected file system is not compatible (FAT32,FAT16,FAT12)", //IPFAT_INCOMPATIBLE_FILESYS
	"Blocked incoming TCP packet from %v:%u to %v:%u as %s received but there is no active connection", //IPNAT_TCP_BLOCKED_INGRESS_NOT_SYN
	"(GMT-08:00) Pacific Time (US/Canada), Tijuana", //up_tz_04
	"Apply Log Settings Now", //sl_ApplySt
	"CHAP authentication challenge received from peer.", //IPPPPCHAP_CHALLENGE_RECVD
	"This section is where you add the Web sites to be used for Access Control.", //help141
	"Revoke", //bd_Revoke
	"Step 1: Detect the printer", //wprn_intro3
	"Connection Up Time", //_conuptime
	"Verify that the printer is turned on.", //wprn_tt4
	"Wireless Networking technology enables ubiquitous communication", //help383
	"No response to ping from router, will retry.", //tsc_pingt_msg6
	"Initiated from LAN to WAN.", //help821a
	"PPPoE received session offer", //PPPOE_EVENT_SESSION_OFFER_RECVD
	"Myth", //gw_gm_30
	"If you consider yourself an advanced user and have configured a router before, click <span class=\"button_ref\">Manual Configure</span> to input all the settings manually.", //bi_man
	"Mixed (1020-5000, 689)", //help60
	"Remote Admin Port", //ta_RAP
	"BigPond (Australia)", //bwn_Mode_BigPond
	"The current printer status will result in the test page failing to print later in the setup process.", //wprn_cps2
	"DST Start", //tt_dststart
	"When the protocol is TCP, SPI checks that packet sequence numbers are within the valid range for the session, discarding those packets that do not have valid sequence numbers.", //help164_1
	"MSCHAP authentication timed out - authentication failed.", //IPMSCHAP_AUTH_TIMEOUT
	"Email Now", //sl_emailLog
	"Wireless Network Settings", //bwl_title_1
	"BigPond Password", //bwn_BPP
	"Refresh", //sl_reload
	"Step 1: Name your Wireless Network", //wwl_title_s1
	"Failed to mount drive device", //IPDRIVE_MOUNT_FAILED
	"Internet Connection Setup Wizard", //int_ConWz
	"Permission", //sto_permi
	"The <code>Revoke</code> option is available for the situation in which the lease table becomes full or nearly full, you need to recover space in the table for new entries, and you know that some of the currently allocated leases are no longer needed. Clicking <code>Revoke</code> cancels the lease for a specific LAN device and frees an entry in the lease table. Do this only if the device no longer needs the leased IP address, because, for example, it has been removed from the network.", //help329
	"L2TP local tunnel 0x%04X has been disconnected", //IPL2TP_TUNNEL_DISCONNECTED
	"Remote Admin Inbound Filter", //help830
	"The Maximum Transmission Unit (MTU) is a parameter that determines the largest packet size (in bytes) that the router will send to the WAN. If LAN devices send larger packets, the router will break them into smaller packets. Ideally, you should set this to match the MTU of the connection to your ISP. Typical values are 1500 bytes for an Ethernet connection and 1492 bytes for a PPPoE connection. If the router's MTU is set too high, packets will be fragmented downstream. If the router's MTU is set too low, the router will fragment packets unnecessarily and in extreme cases may be unable to establish some connections. In either case, network performance can suffer.", //help294
	"(GMT-02:00) Mid-Atlantic", //up_tz_21
	"Latest Firmware Date", //tf_LFWD
	"BigPond logged in, state=%d, server response=%s", //GW_BIGPOND_SUCCESS
	"Deny All", //_denyall
	"Automatic Classification", //at_AC
	"Visibility Status", //bwl_VS
	"In this section you can see what LAN devices are currently leasing IP addresses.", //help327
	"To complete the setup process, the wizard will now launch an executable file on your computer.", //wprn_s2a
	"(hours)", //td_
	"The remote PPTP access concentrator is slow to respond. There may be connectivity problems.", //PPTP_EVENT_TUNNEL_WINDOW_TIMEOUT
	"Transmit Power", //aw_TP
	"Static IP Address Internet Connection Type", //bwn_SIAICT
	"Multiple connections are required by some applications, such as internet games, video conferencing, Internet telephony, and others. These applications have difficulties working through NAT (Network Address Translation). This section is used to open multiple ports or a range of ports in your router and redirect data through those ports to a single PC on your network. You can enter ports in various formats", //help57
	"Enable Daylight Saving", //tt_dsen2
	"Disconnecting (please wait...)", //_sdi_s5
	"Manufacturer", //wprn_man
	"02:00 AM", //tt_time_3
	"(GMT-03:00) Greenland", //up_tz_20
	"RIP has rejected route %v from peer router %v due to low system resources", //RIP_LOW_RESOURCES
	"Service Name:", //help266
	"Connected", //CONNECTED
	"If your ISP has assigned a fixed IP address, select this option. The ISP provides the values for the following fields:", //help265_5
	"Day(s)", //tsc_Days
	"(GMT-05:00) Indiana (East)", //up_tz_13
	"General", //sd_General
	"UPnP helps other UPnP LAN hosts interoperate with the router. Leave the UPnP option enabled as long as the LAN has other UPnP applications.", //hhan_upnp
	"Check with the system administrator of your corporate network whether your VPN client supports NAT traversal.", //help35
	"The IP address of the system on your internal network that will provide the virtual service, for example <code>192.168.0.50</code>.", //help18
	"Printer Setup Wizard", //bwz_psw
	"Date And Time", //tt_DaT
	"Schedules can be created for use with enforcing rules. For example, if you want to restrict web access to Mon-Fri from 3pm to 8pm, you could create a schedule selecting Mon, Tue, Wed, Thu, and Fri and enter a Start Time of 3pm and End Time of 8pm.", //help190
	"SYN Sent -- One of the systems is attempting to start a connection.", //help819_2
	"Maximum Idle Time", //bwn_MIT
	"Give each rule a <strong>Name</strong> that is meaningful to you.", //hhai_name
	"Email Log When Full or on Schedule", //te__title_EmLog
	"(GMT+05:30) Calcutta, Chennai, Mumbai, New Delhi", //up_tz_47
	"SMTP failed during sender/recipient dialog", //IPSMTPCLIENT_DIALOG_FAILED
	"Click the <strong>Clear</strong> button to remove the MAC address from the MAC Filtering list.", //hham_del
	"If your Internet Service Provider was not listed or you don't know who it is, please select the Internet connection type below:", //wwa_msg_ispnot
	"The number of packets that were dropped while being sent, due to errors, collisions, or router resource limitations.", //help808
	"Attempting to establish a PPTP connection.", //PPTP_EVENT_TUNNEL_ESTABLISH_REQUEST
	"Supports use on LAN computers of Microsoft Windows Messenger (the Internet messaging client that ships with Microsoft Windows) and MSN Messenger. The SIP ALG must also be enabled when the Windows Messenger ALG is enabled.", //help37
	"Reboot requested for WCN", //WCN_LOG_REBOOT
	"PPTP connection attempt failed. Check remote PPTP server details.", //PPTP_EVENT_TUNNEL_CONNECT_FAIL
	"Channel Width", //bwl_CWM
	"(GMT-05:00) Eastern Time (US/Canada)", //up_tz_12
	"Cancel", //_cancel
	"Enable ULA", //IPV6_ULA_TEXT02
	"Enable DMZ", //af_ED
	"(GMT+03:00) Kuwait, Riyadh", //up_tz_38
	"DTIM Interval", //aw_DI
	"(GMT+02:00) Athens, Istanbul, Minsk", //up_tz_31
	"Click the <strong>Delete</strong> icon in the Rules List to permanently remove a rule.", //hhai_delete
	"The Virtual Server option allows you to define a single public port on your router for redirection to an internal LAN IP Address and Private LAN port if required. This feature is useful for hosting online services such as FTP or Web Servers.", //av_intro_vs
	"The Firewall Settings section is an advance feature used to allow or deny traffic from passing through the device. It works in the same way as IP Filters with additional settings.  You can create more detailed rules for the device.", //av_intro_if
	"Attempting to re-connect always-on WAN connection", //GW_WAN_RECONNECT_ALWAYS_ON
	"Wireless Security Password", //wwl_WSP
	"In", //INGRESS
	"Restricted", //RESTRICTED
	"Use this Internet connection type if your Internet Service Provider (ISP) didn't provide you with IP Address information and/or a username and password.", //bwn_msg_DHCPDesc
	"The port number used to connect to the authentication server.", //help390
	"Enabling L2 (Layer 2) Isolation prevents associated wireless clients from communicating with each other.", //KR58
	"Re-type the password associated with the account.", //help867
	"Attempting to start always-on WAN connection", //GW_WAN_CONNECT_ALWAYS_ON
	"RTSP ALG rejected packet from %v:%u to %v:%u with odd RTP port %u", //IPRTSPALG_REJECTED_ODD_RTP_PACKET
	"Port Forwarding Fields", //help60f
	"Counter Strike", //gw_gm_10
	"(minutes, 0=infinite)", //bwn_min
	"Month", //tt_Month
	"Current Firmware Date", //tf_CFWD
	"Advanced Network", //_advnetwork
	"PPPOE Internet Connection Type", //bwn_PPPOEICT
	"RADIUS Server Port:", //help389
	"Select the time offset, if your location observes daylight saving time.", //help844
	"04:00 PM", //tt_time_17
	"L2TP (Layer Two Tunneling Protocol) uses a virtual private network to connect to your ISP. This method of connection requires you to enter a <span class=\"option\">Username</span> and <span class=\"option\">Password</span> (provided by your Internet Service Provider) to gain access to the Internet.", //help284
	"Wireless system with MAC address %m associated", //GW_WIRELESS_DEVICE_ASSOCIATED
	"Second MAC Address Authentication", //bws_2RMAA
	"SIP", //as_SIP
	"Syslog", //help704
	"WPS Internal Registrar failed to add new station, reason %s", //WIFISC_IR_REGISTRATION_FAIL_1
	"(GMT) Greenwich Time: Dublin, Edinburgh, Lisbon, London", //up_tz_25
	"With the above example application rule enabled, the router will open up a range of ports from 6000-6200 for incoming traffic from the Internet, whenever any computer on the internal network opens up an application that sends data to the Internet using a port in the range of 6500-6700.", //help55
	"Wireless Link is up", //GW_WLAN_LINK_UP
	"Enable DNS Relay", //bln_EnDNSRelay
	"Inbound Filter Rule", //ai_title_IFR
	"PPTP", //_PPTP
	"Both", //_both
	"(GMT+03:00) Nairobi", //up_tz_40
	"Unplug and reinsert the printer's USB cable.", //wprn_tt8
	"Disable Soft Reset", //tps_dsr
	"Other", //at_Prot_1
	"This restarts the router. Useful for restarting when you are not near the device.", //help875
	"Website Filter Parameters", //awsf_p
	"- Exactly 5 or 13 characters", //wwl_s4_intro_z2
	"To set up this connection you will need to have a Username and Password from your Internet Service Provider. You also need L2TP IP adress. If you do not have this information, please contact your ISP.", //wwa_set_l2tp_msg
	"(GMT+04:00) Abu Dhabi, Muscat", //up_tz_42
	"Error", //_error
	"Dest IP<br />End", //aa_FPR_c4
	"Enable NTP Server", //tt_EnNTP
	"Invalid LAN IP Address, ip address in DHCP Server range", //network_dhcp_ip_in_server
	"To upgrade the firmware, your PC must have a wired connection to the router. Enter the name of the firmware upgrade file, and click on the Upload button.", //tf_msg_wired
	"Set Username and Password Connection (PPPoE)", //wwa_title_set_pppoe
	"Ensure the schedule is set to <code>Always</code>", //help10
	"The other options are available for special circumstances.", //bwl_CWM_h2
	"Check Online", //help884
	"Rebooting", //rb_Rebooting
	"Time Wait -- Waiting for a short time while a connection that was in FIN Wait is fully closed.", //help819_6
	"09:00 AM", //tt_time_10
	"This section shows the currently defined Schedule Rules. A Schedule Rule can be changed by clicking the Edit icon, or deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Schedule Rule\" section is activated for editing.", //help199
	"A method of connection where the ISP assigns your IP address when your router requests one from the ISP's server. Some ISP's require you to make some settings on your side before your router can connect to the Internet.", //help259
	"Application Level Gateway (ALG) Configuration", //af_algconfig
	"PPTP client.", //wwa_msg_pptp
	"Second RADIUS server IP Address", //bws_2RIPA
	"Step 3: Select Machine", //_aa_wiz_s4_title
	"Note: You may also need to provide a Service Name. If you do not have or know this information, please contact your ISP.", //wwa_note_svcn
	"Detected xDSL or Frame Relay Network", //help85
	"Internet access port filter dropped packet from %v:%u to %v:%u (protocol %u)", //GW_INET_ACCESS_DROP_PORT_FILTER_WITH_PORT
	"BigPond Status", //sd_BPSt
	"(GMT+06:00) Almaty", //up_tz_49
	"World of Warcraft", //gw_gm_62
	"BigPond logged out", //BIGPOND_LOGGED_OUT
	"Email Notification of Newer Firmware Version", //tf_EmNew
	"Internet access policy for MAC address %m cannot be set", //GW_INET_ACCESS_INITIAL_MAC_FAIL
	"MAC Address", //help303
	"Not Listed or Don't Know", //wwa_selectisp_not
	"Blocked outgoing TCP packet from %v:%u to %v:%u with unexpected acknowledgement %lu (expected %lu to %lu)", //IPNAT_TCP_BLOCKED_EGRESS_BAD_ACK
	"The rule applies to a flow of messages whose LAN-side port number is within the range set here.", //help94
	"Xbox Live", //gw_gm_70
	"Dropped ICMP packet from %v to %v as unable handle packet header", //IPNAT_ICMP_UNABLE_TO_HANDLE_HEADER
	"FTP", //_FTP
	"NAT Endpoint Filtering", //_neft
	"Administration", //ta_A12n
	"BigPond logged out", //GW_BIGPOND_LOGOUT
	"An application rule is used to open single or multiple ports on your router when the router senses data sent to the Internet on a \"trigger\" port or port range. An application rule applies to all computers on your internal network.", //help46
	"Check the log frequently to detect unauthorized network usage.", //hhsl_intro
	"Tools Help", //help770
	"To set up this connection you will need to have a Username and Password from your Internet Service Provider. You also need PPTP IP adress. If you do not have this information, please contact your ISP.", //wwa_msg_set_pptp
	"Unable to find DNS record for firmware upgrade server %s", //GW_FW_NOTIFY_FAILED_DNS
	"Rainbow Six: Raven Shield", //gw_gm_40
	"The router uses the IGMP protocol to support efficient multicasting -- transmission of identical content, such as multimedia, from a source to a number of recipients.", //bln_IGMP_title_h
	"Use <strong>802.11d</strong> only for countries where it is required.", //hhaw_11d
	"If not, press Cancel and then click Save Settings.", //up_jt_2
	"Policy %s started; Internet access for MAC address %s changed to: %s", //GW_INET_ACCESS_POLICY_START_MAC
	"Choose this option if your Internet connection requires a username and password to get online. Most DSL modems use this type of connection.", //wwa_msg_pppoe
	"Suppose you configure the DHCP Server to manage addresses From 192.168.0.100 To 192.168.0.199. This means that 192.168.0.3 to 192.168.0.99 and 192.168.0.200 to 192.168.0.254 are NOT managed by the DHCP Server. Computers or devices that use addresses from these ranges are to be manually configured. Suppose you have a web server computer that has a manually configured address of 192.168.0.100. Because this falls within the \"managed range\" be sure to create a reservation for this address and match it to the relevant computer (see <a href=\"#Static_DHCP\">Static DHCP Client</a> below).", //help323
	"The 'admin' account can access the management interface. The admin has read/write access and can change passwords.", //ta_intro1
	"3rd", //tt_week_3
	"DHCP Server", //_dhcpsrv
	"Dynamic PPPoE", //Dynamic_PPPoE
	"Enable:", //help102
	"WINS/NetBIOS may not operate in this mode given your Internet connection settings.", //GW_DHCP_SERVER_WINS_MODE_INVALID
	"One bits in the mask specify which bits of the IP address must match.", //help107
	"WON Servers", //gw_gm_69
	"Filtering", //aa_ACR_c5
	"You can assign a name for each computer that is given a reserved IP address. This may help you keep track of which computers are assigned this way.", //help345
	"Check the <strong>Application Name</strong> drop down menu for a list of predefined server types. If you select one of the predefined server types, click the arrow button next to the drop down menu to fill out the corresponding field.", //hhav_name
	"Private Port", //av_PriP
	"% loss", //tsc_pingt_msg103
	"If you need to use the UPnP functionality, you can enable it here.", //help_upnp_2
	"Incorrect WAN connectivity mode", //WAN_MODE_INCORRECT
	"WEP password must be exactly 5 alphanumeric characters.", //wwl_alert_pv5_2_5
	"Step 4: Select Filtering Method", //_aa_wiz_s5_title
	"Invalid PIN number.", //KR22_ww
	"Specify rules to prohibit access to specific IP addresses and ports.", //_aa_wiz_s7_help
	"L2TP session server stopped sending sequencing numbers for local session 0x%04X", //IPL2TP_SEQUENCING_DEACTIVATED
	"Advanced Printer Configuration", //tps_apc
	"(GMT-06:00) Mexico City", //up_tz_09
	"Jul", //tt_Jul
	"WAN interface is down", //GW_WAN_INTERFACE_DOWN
	"Restore wireless settings", //WCN_LOG_RESTORE
	"Everquest", //gw_gm_17
	"Internet access for IP address %v set to: %s", //GW_INET_ACCESS_INITIAL_IP
	"Do you want to abandon all changes you made to this wizard?", //_wizquit
	"The System Settings section allows you to reboot the device, or restore the router to the factory default settings. Restoring the unit to the factory default settings will erase all settings, including any rules that you have created.", //tss_intro
	"When you set <span class='option'>Enable DHCP Server</span>, the following options are displayed.", //help318
	"The SysLog options allow you to send log information to a SysLog Server.", //tsl_intro
	"03:00 AM", //tt_time_4
	"08:00 PM", //tt_time_21
	"L2TP local session 0x%04X connected", //IPL2TP_SESSION_CONNECTED
	"Fragmentation Threshold", //aw_FT
	"Save", //_save
	"Not Estimated", //at_NEst
	"Once a LAN-side application has created a connection through a specific port, the NAT will forward any incoming connection requests with the same port to the LAN-side application regardless of their origin. This is the least restrictive option, giving the best connectivity and allowing some applications (P2P applications in particular) to behave almost as if they are directly connected to the Internet.", //af_EFT_h0
	"FIRMWARE", //_firmware
	"Rogue Spear", //gw_gm_43
	"Please start WPS on the wireless device you are adding to your wireless network winth", //wps_messgae1_1
	"L2TP local tunnel 0x%04X RTE module is shutting down.", //IPL2TP_SHUTDOWN_STARTED
	"TX Packets Dropped", //ss_TXPD
	"(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi", //up_tz_55
	"Click Next if you still want to secure the router with a password and set the time zone.", //wwa_intro_online2
	"Select the outbound protocol used by your application (for example <code>Both</code>).", //help50
	"Enter the UDP ports to open (for example <code>6159-6180, 99</code>).", //help70
	"Enabling WMM can help control latency and jitter when transmitting multimedia content over a wireless connection.", //help188_wmm
	"DHCP Reservation", //bd_title_SDC
	"(GMT+09:00) Osaka, Sapporo, Tokyo", //up_tz_60
	"Ultima", //gw_gm_54
	"Optional backup RADIUS server", //help396
	"Administrator logout", //GW_ADMIN_LOGOUT
	"Serious Sam II", //gw_gm_44
	"Enable UPnP", //ta_EUPNP
	"This option must be enabled if any applications on the LAN participate in a multicast group. If you have a multimedia LAN application that is not receiving content as expected, try enabling this option.", //igmp_e_h
	"The number of packets sent from the router.", //help806
	"DENY computers access to ONLY these sites", //dlink_wf_op_0
	"Enter the outgoing port range used by your application (for example <code>6500-6700</code>).", //help49
	"Example:", //help367
	"Links", //gw_gm_28
	"Windows Me", //help337
	"Administrator Settings", //ta_AdmSt
	"SysLog", //_syslog
	"(GMT-06:00) Central Time (US/Canada)", //up_tz_08
	"If this is selected, the user must connect from the same computer whenever logging into the wireless network.", //help394
	"Step 5: Port Filter", //_aa_wiz_s7_title
	"The Time Configuration option allows you to configure, update, and maintain the correct time on the internal system clock. From this section you can set the time zone that you are in and set the NTP (Network Time Protocol) Server. Daylight Saving can also be configured to automatically adjust the time when needed.", //tt_intro_Time
	"Error updating dynamic DNS entry: %s. Will retry later", //GW_DYNDNS_SERROR
	"Enable automatic IPv6 address assignment", //IPV6_TEXT105
	"Port", //sps_port
	"Whether SPI is enabled or not, the router always tracks TCP connection states and ensures that each TCP packet's flags are valid for the current state.", //help164_2
	"Wait for the router to reboot. This can take another minute or more.", //help881
	"Destination IP", //_destip
	"The Time Configuration option allows you to configure, update, and maintain the correct time on the router's internal system clock. From this section you can set the time zone that you are in and set the Time Server. Daylight saving can also be configured to automatically adjust the time when needed.", //help840
	"L2TP Server IP Address (may be same as gateway)", //wwa_l2tp_svra
	"Daylight Saving Dates", //tt_dsdates
	"Note that L2TP VPN connections typically use IPSec to secure the connection. To achieve multiple VPN pass-through in this case, the IPSec ALG must be enabled.", //help34b
	"10:00 AM", //tt_time_11
	"Enable Dynamic DNS", //td_EnDDNS
	"The actual transmission rate of the client in megabits per second.", //help786
	"Username", //bwn_UN
	"This Policy Name is already used.", //aa_alert_8
	"Enable raw TCP port printing from the <em>Print Server </em> page under the <em>Tools</em> submenu.", //wprn_tt2
	"LCP sets remote auth: %04x", //IPPPPLCP_SET_REMOTE_AUTH
	"L2TP local tunnel 0x%04X RTE module fatal timeout - remote server is not responding.", //IPL2TP_FATAL_TIMEOUT
	"<strong>Non-UDP/TCP/ICMP LAN Sessions</strong> is normally enabled. It facilitates single VPN connections to a remote host.", //hhaf_ngss
	"Network Settings", //bln_title_NetSt
	"Traffic Type", //av_traftype
	"PPTP (Username / Password)", //bwn_Mode_PPTP
	"This section shows the currently defined access control policies. A policy can be changed by clicking the Edit icon, or deleted by clicking the Delete icon. When you click the Edit icon, the Policy Wizard starts and guides you through the process of changing a policy. You can enable or disable specific policies in the list by clicking the \"Enable\" checkbox.", //help140
	"A Required Printing Protocol Is Disabled", //wprn_rppd
	"All of your WAN and LAN connection details are displayed here.", //hhsd_intro
	"MSCHAP authentication successful.", //IPMSCHAP_AUTH_SUCCESS
	"Suppose you are hosting an online game server that is running on a PC with a private IP Address of 192.168.0.50. This game requires that you open multiple ports (6159-6180, 99) on the router so Internet users can connect.", //help63
	"Please plug one end of the included Ethernet cable that came with your router into the port labeled INTERNET on the back of the router. Plug the other end of this cable into the Ethernet port on your modem.", //ES_cable_lost_desc
	"The new settings have been applied.", //ap_intro_sv
	"L2TP Subnet Mask", //_L2TPsubnet
	"Sending log email before reboot", //GW_LOG_EMAIL_BEFORE_REBOOT
	"Any", //at_Any
	"The following options apply to all WAN modes.", //help288
	"Unless one of these encryption modes is selected, wireless transmissions to and from your wireless network can be easily intercepted and interpreted by unauthorized users.", //bws_SM_h1
	"In addition to the filters listed here, two predefined filters are available wherever inbound filters can be applied:", //help177
	"(GMT+05:00) Islamabad, Karachi, Tashkent", //up_tz_46
	"Please wait <span id=\"show_sec\"></span>&nbsp;seconds.", //rb_wait
	"Wireless Network Name", //bwl_NN
	"L2TP local session 0x%04X connect attempt failed", //IPL2TP_SESSION_CONNECT_FAIL
	"Final Fantasy XI (PS2)", //gw_gm_21
	"BEST", //wwl_BEST
	"Support", //_support
	"You cannot add new IP addresses. You can only reuse IP addresses from other policies.", //aa_alert_14
	"Cable Status", //_cablestate
	"DHCP stands for Dynamic Host Configuration Protocol. The DHCP section is where you configure the built-in DHCP Server to assign IP addresses to the computers and other devices on your local area network (LAN).", //help314
	"Add Wireless Device WITH WPS (WI-FI PROTECTED SETUP) Wizard", //wps_LW13
	"Critical", //sl_Critical
	"The new settings have been saved.", //sc_intro_sv
	"System LOG is inactive", //SYSTEM_LOG_INACTIVE
	"My Internet Connection is", //bwn_mici
	"Minutes", //gw_mins
	"If the router loses power for any reason, it cannot keep its clock running, and will not have the correct time when it is started again. To maintain correct time for schedules and logs, either you must enter the correct time after you restart the router, or you must enable the NTP Server option.", //help852
	"In", //_In
	"Select this option if you want logs to be sent by email according to a schedule.", //help870
	"MSN Game Zone (DX)", //gw_gm_74
	"Firewall and Security", //help797
	"Rainbow Six", //gw_gm_39
	"WEP key must be exactly 10 hexadecimal digits (0-9 or A-F).", //wwl_alert_pv5_3_10
	"The MAC address filter section can be used to filter network access by machines based on the unique MAC addresses of their network adapter(s).", //help149
	"Use this feature if you are trying to execute one of the listed network applications and it is not communicating as expected.", //hhpt_intro
	"WAN interface cable has been connected", //GW_WAN_CARRIER_DETECTED
	"BigPond User Id", //bwn_BPU
	"Select this option if you want this schedule in effect all day for the selected day(s).", //help195
	"The initial value of Time Out depends on the type and state of the connection.", //help823_1
	"Internet Connection", //_internetc
	"Resolved to", //tsc_pingt_msg5
	"Enter a MAC address for each of the other APs that you want to connect with WDS.", //help189a
	"Trigger", //_trigger
	"The Ethernet ID (MAC address) of the wireless client.", //help783
	"The Gateway will not be reprogrammed.", //ub_intro_2
	"For security reasons, it is recommended that you change the password for the Admin account. Be sure to write down the new and passwords to avoid having to reset the router in case they are forgotten.", //hhta_pw
	"Step 6: Configure Web Access Logging", //_aa_wiz_s8_title
	"The rule can either Allow or Deny messages.", //help173
	"Status Help", //help771
	"Syslog Server IP Address", //tsl_SLSIPA
	"Add Port Filters Rules.", //_aa_wiz_s7_msg
	"12:00 PM", //tt_time_13
	"(GMT+10:00) Guam, Port Moresby", //up_tz_67
	"Primary DNS Server, Secondary DNS Server", //help289a
	"BigPond logged in", //BIGPOND_LOGGED_IN
	"When a LAN host is configured as a DMZ host, it becomes the destination for all incoming packets that do not match some other incoming session or rule. If any other ingress rule is in place, that will be used instead of sending packets to the DMZ host; so, an active session, virtual server, active port trigger, or port forwarding rule will take priority over sending a packet to the DMZ host. (The DMZ policy resembles a default port forwarding rule that forwards every port that is not specifically sent anywhere else.)", //haf_dmz_10
	"State for sessions that use the TCP protocol.", //help819
	"If the progress bar did not appear, the setup executable did not launch and setup is not yet complete. Refer to the Troubleshooting Tips section below.", //wprn_s3b
	"TCP Port", //sps_tcpport
	"Configure Website Filter below", //dlink_wf_intro
	"Website Filter", //_websfilter
	"BigPond Server Name", //sd_BPSN
	"User Password", //_password_user
	"Policy %s stopped; Internet access for IP address %v changed to: %s", //GW_INET_ACCESS_POLICY_END_IP
	"Choose the mode to be used by the router to connect to the Internet.", //bwn_msg_Modes
	"The IP address ' + mf.dmz_address.value + ' is not valid.", //up_gX_1
	"Next", //_next
	"Setup", //_setup
	"The host is pinged repeatedly until you press this button.", //htsc_pingt_s
	"Email", //EMAIL
	"Mode", //_mode
	"Feb", //tt_Feb
	"Use this information to configure your computer for raw TCP port printing.", //sps_raw1
	"Successfully updated dynamic DNS entry for %s", //GW_DYNDNS_SUCCESS
	"Port forwarding ALG failed to allocate session for TCP packet from %v:%u to %v:%u", //IPPORTFORWARDALG_TCP_PACKET_ALLOC_FAILURE
	"IGMP router has rejected group %v due to low system resources", //IGMP_ROUTER_LOW_RESOURCES
	"The \"Auto 20/40 MHz\" option is usually best.", //bwl_CWM_h1
	"(GMT+04:00) Moscow, St. Petersburg, Volgograd", //up_tz_39
	"Allows devices and applications using VoIP (Voice over IP) to communicate across NAT. Some VoIP applications and devices have the ability to discover NAT devices and work around them. This ALG may interfere with the operation of such devices. If you are having trouble making VoIP calls, try turning this ALG off.", //help40
	"Port Forwarding", //_pf
	"Dropped UDP packet from %v to %v as unable handle packet header", //IPNAT_UDP_UNABLE_TO_HANDLE_HEADER
	"<warn>Route gateway IP %v matches the address of the intended interface and will be disabled.</warn>", //GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS_WARNING
	"Internet access for MAC address %m set to: %s", //GW_INET_ACCESS_INITIAL_MAC
	"CHAP authentication successful.", //IPPPPCHAP_AUTH_SUCCESS
	"Normally the wireless transmitter operates at 100% power. In some circumstances, however, there might be a need to isolate specific frequencies to a smaller area. By reducing the power of the radio, you can prevent transmissions from reaching beyond your corporate/home office or designated wireless area.", //help187
	"Block All Access", //_aa_block_all
	"Wireless Link is down", //GW_WLAN_LINK_DOWN
	"The amount of time before the group key used for broadcast and multicast data is changed.", //help379
	"(GMT+11:00) Solomon Is., New Caledonia", //up_tz_70
	"Blocked incoming ICMP error message (ICMP type %u) from %v to %v as there is no ICMP session active between %v and %v", //IPNAT_ICMP_BLOCKED_INGRESS_ICMP_ERROR_PACKET
	"Schedule", //GW_SCHEDULES_IN_USE_INVALID_s1
	"This page is not included in the router's Allowed Web Site List.", //fb_p_2
	"Printer Status", //sps_ps
	"You need to configure your router to allow a software application running on any computer on your network to connect to a web-based server or another user on the Internet.", //help47
	"Step 4: Save Settings and Connect", //wwa_title_s4
	"05:00 PM", //tt_time_18
	"When this option is enabled, router activity logs or firmware upgrade notifications can be emailed to a designated email address, and the following parameters are displayed.", //help860
	"UPnP deleted entry %v <-> %v:%d <-> %v%d %s '%s' (client released address)", //GW_UPNP_IGD_PORTMAP_RELEASE
	"The Internet Connection Setup Wizard has completed. Click the save button to save your settings and reboot the router.", //wwa_intro_s4
	"Some ISP's may require that you enter a Service Name. Only enter a Service Name if your ISP requires one.", //help267
	"L2TP local session 0x%04X aborted", //IPL2TP_SESSION_ABORTED
	"This section allows you to manage the router's configuration settings, reboot the router, and restore the router to the factory default settings. Restoring the unit to the factory default settings will erase all settings, including any rules that you've created.", //help874
	"Sep", //tt_Sep
	"Dropped ESP packet from %v to %v as unable handle packet header", //IPSEC_ALG_ESP_UNABLE_TO_HANDLE_HEADER
	"Group Key Update Interval", //bws_GKUI
	"Enables the router to recognize certain audio and video streams generated by a Windows Media Center PC and to prioritize these above other traffic. Such streams are used by systems known as Windows Media Extenders, such as the Xbox 360.", //help80b
	"In these cases, you can use Inbound Filters to limit that exposure by specifying the IP addresses of internet hosts that you trust to access your LAN through the ports that you have opened. You might, for example, only allow access to a game server on your home LAN from the computers of friends whom you have invited to play the games on that server.", //help168c
	"BigPond logging in", //BIGPOND_LOGGING_IN
	"Username / Password Connection (PPTP)", //wwa_wanmode_pptp
	"Range (50-100)", //help58
	"Connected", //ddns_connected
	"Upload Failed", //ub_Upload_Failed
	"WPS end for STA with MAC (%m) on msg: %s", //WIFISC_AP_PROXY_END_ON_MSG
	"PPTP (Point to Point Tunneling Protocol) uses a virtual private network to connect to your ISP. This method of connection is primarily used in Europe. This method of connection requires you to enter a <span class=\"option\">Username</span> and <span class=\"option\">Password</span> (provided by your Internet Service Provider) to gain access to the Internet.", //help278
	"Enter an 8- to 63-character alphanumeric pass-phrase.", //KR18
	"A System Logger (syslog) is a server that collects in one place the logs from different sources. If the LAN includes a syslog server, you can use this option to send the router's logs to that server.", //hhts_def
	"Used when your ISP provides you a set IP address that does not change. The IP information is manually entered in your IP configuration settings. You must enter the", //help255
	"Second RADIUS server Port", //bws_2RSP
	"Enter the Private Port as [80]", //help7
	"Visible", //bwl_VS_0
	"TCP Endpoint Filtering", //af_TEFT
	"When <span class='option'>Connection Type</span> is set to <span class='option'> Auto-detect</span>, the automatically detected connection type is displayed here.", //help86
	"Network Name (SSID)", //sd_NNSSID
	"Accessing this web page might have an effect on the measurement.", //wt_p_2
	"Gateway", //_gateway
	"Current Router Time", //tt_CurTime
	"AM", //_AM
	"Disconnected", //DISCONNECTED
	"Soldier of Fortune", //gw_gm_47
	"(GMT-01:00) Azores", //up_tz_22
	"WPS Internal Registrar detected session overlap between %m and %m", //WIFISC_IR_REGISTRATION_SESSION_OVERLAP
	"Please make the two admin passwords the same and try again", //_pwsame_admin
	"WAN IP changed to %v, updating to dynamic DNS provider", //GW_DYNDNS_UPDATE_IP
	"A network computer (%s) was assigned the IP address of %v.", //GW_DHCPSERVER_NEW_ASSIGNMENT
	"Windows/MSN Messenger", //as_WM
	"(GMT-09:00) Alaska", //up_tz_03
	"Please enter the PIN of your wireless device, then click on the Connect button below.", //KR43
	"passwords do not match, please re-enter", //YM177
	"Depending on the type of WAN connection, you can take one of the following sets of actions:", //help774
	"Click the <strong>Edit</strong> icon to modify an existing rule using the Policy Wizard.", //hhac_edit
	"(GMT+02:00) Jerusalem", //up_tz_36
	"Host Name", //_hostname
	"Internet access control initialization failed", //GW_INET_ACCESS_INITIAL_FAIL
	"Web filter initialization failed", //GW_WEB_FILTER_INITIAL_FAIL
	"On Log Full", //te_OnFull
	"Step 3: Set your Wireless Security Password", //wwl_title_s4
	"Reconnect Mode:", //help281
	"Gamespy Tunnel", //gw_gm_77
	"Clone Your PC's MAC Address", //_clonemac
	"This is a summary of the number of packets that have passed between the WAN and the LAN since the router was last initialized.", //hhss_intro
	"Measured Uplink Speed", //at_MUS
	"The WAN speed is usually detected automatically. If you are having problems connecting to the WAN, try selecting the speed manually.", //hhan_wans
	"Enable this option if you want to allow WISH to prioritize your traffic.", //YM141
	"The key is entered as a pass-phrase of up to 63 alphanumeric characters in ASCII (American Standard Code for Information Interchange) format at both ends of the wireless connection. It cannot be shorter than eight characters, although for proper security it needs to be of ample length and should not be a commonly known phrase. This phrase is used to generate session keys that are unique for each wireless client.", //help382
	"(hour:minute, 12 hour time)", //tsc_hrmin
	"(hour:minute, 24 hour time)", //tsc_hrmin1
	"This is the uplink speed measured when the WAN interface was last re-established. The value may be lower than that reported by your ISP as it does not include all of the network protocol overheads associated with your ISP's network. Typically, this figure will be between 87% and 91% of the stated uplink speed for xDSL connections and around 5 kbps lower for cable network connections.", //help82
	"Heretic II", //gw_gm_24
	"Delta Force", //gw_gm_13
	"RTS Threshold", //aw_RT
	"Windows XP", //help340
	"Wireless LAN", //sd_WLAN
	"If your SMTP server requires authentication, select this option.", //help864
	"There may be new firmware for your", //tf_intro_FWU1
	"Unsupported Operating System", //wprn_bados
	"Metric", //_metric
	"Inbound Filter", //INBOUND_FILTER
	"Blocked incoming UDP packet from %v:%u to %v:%u", //IPNAT_UDP_BLOCKED_INGRESS
	"This option turns off and on the wireless connection feature of the router. When you set this option, the following parameters are in effect.", //help351
	"Use this options if you prefer to create our own key.", //wwz_manual_key2
	"PPTP Subnet Mask", //_PPTPsubnet
	"The port that will be used on your internal network.", //help20
	"Black and White", //gw_gm_6
	"WPA Mode", //bws_WPAM
	"GOOD", //wwl_GOOD
	"Postal 2: Share the Pain", //gw_gm_36
	"Enter your host name, fully qualified; for example: <code>myhost.mydomain.net</code>.", //help894
	"Subnet Mask", //_subnet
	"The PPTP transmit window is %u", //PPTP_EVENT_REMOTE_WINDOW_SIZE
	"Step 1: Select Configuration Method for your Wireless Network", //wps_KR35
	"The <code>Reserve</code> option converts this dynamic IP allocation into a DHCP Reservation and adds the corresponding entry to the DHCP Reservations List.", //help329_rsv
	"Vietcong", //gw_gm_58
	"Bringing up WAN using %s", //GW_WAN_MODE_IS
	"Use this section to configure the internal network settings of your router and also to configure the built-in DHCP Server to assign IP addresses to the computers on your network. The IP Address that is configured here is the IP Address that you use to access the Web-based management interface. If you change the IP Address here, you may need to adjust your PC's network settings to access the network again.", //ns_intro_
	"DNS relay ALG rejected packet from %v:%u to %v:%u", //IPDNSRELAYALG_REJECTED_PACKET
	"Traffic Statistics display Receive and Transmit packets passing through your router.", //ss_intro
	"You should examine these warnings as some features may have been disabled.", //KR112
	"<warn>Not all station are able to operate in channel 100-140. Please change channel if the station fails to connect.</warn>", //GW_WLAN_11A_CH_MID_BAND_WARN
	"Enable Anti-ARP Attack", //ip_mac_binding_desc
	"Enabling this option (the default setting) enables single VPN connections to a remote host. (But, for multiple VPN connections, the appropriate VPN ALG must be used.) Disabling this option, however, only disables VPN if the appropriate VPN ALG is also disabled.", //LW50
	"Rule %s conflicts with an existing connection (%v:%u (public %v:%u)--->%v:%u). Connectivity to the rule may be affected until this connection ends.", //GW_NAT_CONFLICTING_CONNECTIONS_LOG
	"Warnings were raised as a result of configuration changes.", //KR111
	"Log Entries", //KR109
	"<warn>Rule %s conflicts with an existing connection (%v:%u (public %v:%u)--->%v:%u). Connectivity to the rule may be affected until this connection ends.</warn>", //GW_NAT_CONFLICTING_CONNECTIONS_WARNING
	"HNAP SetAccessPointMode %s returns %s, %s", //GW_PURE_SETACCESSPOINTMODE
	"Blocked packet from %v to %v that was received from the wrong network interface (IP address spoofing)", //GW_NAT_REJECTED_SPOOFED_PACKET
	"Message", //KR110
	"<warn>Route gateway IP %v is not in interface subnet (%v/%v) and will be disabled.</warn>", //GW_ROUTES_ROUTE_GATEWAY_NOT_IN_SUBNET_WARNING
	"When this option is enabled, the router restricts the flow of outbound traffic so as not to exceed the WAN uplink bandwidth", //KR107
	"Anti-Spoof checking", //KR105
	"Blocked packet from %v to %v (LAND Attack)", //IPSTACK_REJECTED_LAND_ATTACK
	"WEP", //LS321
	"Log emails", //KR67
	"destination ending port should be between 0 and 65535 inclusive.", //YM71
	"The Source IP Range '%v-%v' is duplicated.", //GW_FIREWALL_RANGE_DUPLICATED_INVALID
	"Hardware Address", //LS422
	"Use Windows Connect Now", //bwz_LWCNWz
	"Invalid WAN gateway IP address: %v", //GW_WAN_WAN_GATEWAY_IP_ADDRESS_INVALID
	"Save Configuration To Wireless Network Setup Wizard", //ta_wcn
	"A PIN is a unique number that can be used to add the router to an existing network or to create a new network. The default PIN may be printed on the bottom of the router. For extra security, a new PIN can be generated. You can restore the default PIN at any time. Only the Administrator (\"admin\" account) can change or reset the PIN.", //LW57
	"WEP Key 2", //_wepkey2
	"Hop", //tsc_pingt_msg109
	"NetBIOS node type", //bd_NETBIOS_REG_TYPE
	"Please press down the Push Button (physical or virtual) on the wireless device you are adding to your wireless network within", //wps_messgae1_2
	"Create a random number that is a valid PIN. This becomes the router's PIN. You can then copy this PIN to the user interface of the registrar.", //LW60
	"Restore Failed", //_rs_failed
	"Select this option if the device is connected to a local network downstream from another router. In this mode, the device functions as a bridge between the network on its WAN port and the devices on its LAN port and those connected to it wirelessly.", //KR62
	"The Wireless Device PIN field cannot be blank", //KR20
	"For best performance, use the Automatic Classification option to automatically set the priority for your applications.", //at_intro_2
	"NetBIOS announcement", //bd_NETBIOS_ENABLE
	"The subnet mask of the local area network.", //KR77
	"Super G with Dynamic Turbo", //help364
	"Shopping", //_aa_bsecure_shopping
	"Public Proxies", //_aa_bsecure_public_proxies
	"WEP Key 1", //wepkey1
	"Send/Receive authorization", //ZM11
	"Start Time", //tsc_start_time
	"source ending port should be between 0 and 65535 inclusive.", //YM69
	"If NetBIOS advertisement is swicthed on, switching this setting on causes WINS information to be learned from the WAN side, if available.", //KR82
	"Only Administrator can clear the statistics. The Clear Statistics button is disabled as you are not currently logged in as Administrator.", //ss_intro_user
	"The Schedule name '%s' is reserved and can not be used", //GW_SCHEDULES_NAME_RESERVED_INVALID
	"Add Wireless Station", //LW12
	"Windows Media Center", //YM75
	"Route gateway IP %v is invalid", //GW_ROUTES_GATEWAY_IP_ADDRESS_INVALID
	"WPA Group Key Update Interval should be between 30 and 65535 seconds.", //GW_WLAN_WPA_REKEY_TIME_INVALID
	"WEP is the wireless encryption standard. To use it you must enter the same key(s) into the router and the wireless stations. For 64 bit keys you must enter 10 hex digits into each key box. For 128 bit keys you must enter 26 hex digits into each key box. A hex digit is either a number from 0 to 9 or a letter from A to F. For the most secure use of WEP set the authentication type to \"Shared Key\" when WEP is enabled.", //bws_msg_WEP_1
	"Enabling Hidden Mode is another way to secure your network. With this option enabled, no wireless clients will be able to see your wireless network when they scan to see what's available. For your wireless devices to connect to your router, you will need to manually enter the Wireless Network Name on each device.", //YM125
	"Gambling", //_aa_bsecure_gambling
	"Bridge Mode", //KR14
	"The given FROM address (%s) is invalid", //GW_SMTP_FROM_ADDRESS_INVALID
	"Indicates how network hosts are to perform NetBIOS name registration and discovery.", //KR89
	"Netmask:", //help106
	"When configuring the router to access the Internet, be sure to choose the correct <strong>Internet Connection Type</strong> from the drop down menu. If you are unsure of which option to choose, contact your <strong>Internet Service Provider (ISP)</strong>.", //LW35
	"Voice (most urgent).", //YM151
	"Your changes have been saved. The router must be rebooted for the changes to take effect. You can reboot now, or you can continue to make other changes and reboot later.", //YM2
	"Note: refer to <a href=\"../Help/Tools.shtml#wcn\" onclick=\"return jump_if();\" style=\"white-space: nowrap;\">Help -> Tools</a> for possible limitations regarding this feature.", //ta_wcn_note
	"The router configuration was changed by something else during wizard operation.\nWizard function will be cancelled, please try again.", //YM131
	"HTTP and HTTPS cannot occupy the same LAN port.", //GW_WEB_SERVER_SAME_PORT_LAN
	"Session Time Out", //KR25
	"Reboot Now", //YM3
	"<warn>The Wake-On-LAN ALG has been automatically enabled because a virtual server entry you created requires it.</warn>", //GW_NAT_WOL_ALG_ACTIVATED_WARNING
	"Invalid Destination IP range for Port Filter", //YM20
	"Enable this option if you want to allow WISH to prioritize wireless traffic.", //YM86
	"Invalid WAN MAC address: %m", //GW_WAN_MAC_ADDRESS_INVALID
	"recepient email address is in wrong format", //IPSMTPCLIENT_MSG_WRONG_RECEPIENT_ADDR_FORMAT
	"WISH supports overlaps between rules. If more than one rule matches for a specific message flow, the rule with the highest priority will be used.", //YM146
	"Configuration Warnings", //LS151
	"Name can not be empty string.", //GW_QOS_RULES_NAME_INVALID
	"%s' [protocol:%d]->%v conflicts with '%s' [protocol:%d]->%v.", //GW_NAT_VS_PROTO_CONFLICT_INVALID
	"Name can not be empty string.", //GW_WISH_RULES_NAME_INVALID
	"Adding wireless station %s failed, reason %s, err_code %u", //WIFISC_IR_REGISTRATION_FAIL
	"ROUTE LIST", //r_rlist
	"Enter a specific DNS server address", //IPV6_TEXT109
	"128 bit (26 hex digits)", //bws_WKL_1
	"Organizes information so that it can be managed updated, as well as easily accessed by users or applications.", //help473
	"Extra Wireless Protection", //aw_erpe
	"Port ranges can not be both empty.", //GW_NAT_PORT_FORWARD_RANGE_BOTH_EMPTY_INVALID
	"Route gateway IP %v is not in interface subnet", //GW_ROUTES_GATEWAY_IP_ADDRESS_IN_SUBNET_INVALID
	"Wireless Wizard", //LW37
	"This feature is disabled when logged in as User", //tsc_pingdisallowed
	"To save the configuration, click the <strong>Save Configuration</strong> button.", //ZM20
	"Cipher Type:", //help376
	"Email Notification is not enabled on Tools->Email Settings page but Email Notification of New Firmware Version is enabled in Tools->Firmware page.", //GW_FW_NOTIFY_EMAIL_DISABLED_INVALID
	"Invalid WEP Key", //YM122
	"DMZ address %v can not be the same as the LAN IP address.", //GW_NAT_DMZ_CONFLICT_WITH_LAN_IP_INVALID
	"Incorrectly configured - check logs", //_sdi_s7
	"QoS Engine Setup", //at_title_SESet
	"Start port must be less than end port: %d-%d.", //GW_INET_ACL_START_PORT_INVALID
	"failed to send email data", //IPSMTPCLIENT_DATA_FAILED
	"M-Node (default), this indicates a Mixed-Mode of operation. First Broadcast operation is performed to register hosts and discover other hosts, if broadcast operation fails, WINS servers are tried, if any. This mode favours broadcast operation which may be preferred if WINS servers are reachable by a slow network link and the majority of network services such as servers and printers are local to the LAN.", //KR91
	"Operating frequency band. Choose 2.4GHz for visibility to legacy devices and for longer range. Choose 5GHz for least interference; interference can hurt performance.", //KR971
	"Restore Factory Defaults", //tss_RestAll_b
	"%s of '%s' [%s:%s]->%s conflicts with '%s' [%s:%s]->%s.", //GW_NAT_PORT_TRIGGER_CONFLICT_INVALID
	"Fragmentation will occur when frame size in bytes is greater than the Fragmentation Threshold.", //LW54
	"If you already have a DHCP server on your network or are using static IP addresses on all the devices on your network, uncheck <strong>Enable DHCP Server </strong> to disable this feature.", //TA7
	"The IP address of the this device on the local area network.", //KR74
	"Default WEP Key", //bws_DFWK
	"If you are new to wireless networking and have never configured a wireless router before, click on <strong>Wireless Network Setup Wizard</strong> and the router will guide you through a few simple steps to get your wireless network up and running.", //LW46
	"SMTP (Email) server %s is at IP address %v", //IPSMTPCLIENT_RESOLVED_DNS
	"Interface:", //help110
	"Invalid PPTP gateway IP address", //YM107
	"The timeout value cannot be greater than 8760.", //YM180
	"Invalid WAN subnet mask %v", //GW_WAN_WAN_SUBNET_INVALID
	"<warn>DMZ is disabled because the LAN subnet has been changed.</warn>", //GW_NAT_DMZ_DISABLED_WARNING
	"Do you want to disable the DHCP Reservation entry for IP Address", //YM93
	"<warn>The FTP ALG has been automatically enabled because a virtual server entry you created requires it.</warn>", //GW_NAT_FTP_ALG_ACTIVATED_WARNING
	"Free Host", //_aa_bsecure_free_host
	"Invalid Netmask for route", //_r_alert2
	"Invalid MAC Address", //LS47
	"LAN subnet mask leaves no addresses for DHCP server to use.", //GW_DHCP_SERVER_SUBNET_SIZE_INVALID
	"You cannot add new MAC address %m. You can only reuse MAC addresses from other policies.", //GW_INET_ACCESS_POLICY_TOO_MANY_MAC_INVALID
	"Start IP address must be less than end IP address: %v-%v", //GW_FIREWALL_START_IP_ADDRESS_INVALID
	"seconds.", //YM8
	"'%s': Priority, %u, needs to be between 0 and 7", //GW_WISH_RULES_PRIORITY_RANGE
	"Travel", //_aa_bsecure_travel
	"The route metric is a value from 1 to 16 that indicates the cost of using this route. A value of 1 is the lowest cost, and 15 is the highest cost. A value of 16 indicates that the route is not reachable from this router. When trying to reach a particular destination, computers on your network will select the best route, ignoring unreachable routes.", //help113
	"BigPond Client", //ZM6
	"(length applies to all keys)", //bws_length
	"The WCN ActiveX Control provides the necessary WCN link between the router and your PC via the browser. The browser will attempt to download the WCN ActiveX Control, if it is not already available on your PC. For this action to succeed, the WAN connection must be established, and the browser's internet security setting must be Medium or lower (select Tools &rarr; Internet Options &rarr; Security &rarr; Custom Level &rarr; Medium).", //help836
	"Try the restore again with valid restore configuration file.", //rs_intro_2
	"IP address %v already exists.", //GW_INET_ACL_IP_ADDRESS_DUPLICATION_INVALID
	"You must be logged in as Administrator to use these features.", //KR7
	"(automatically disabled if UPnP is enabled)", //ZM1
	"Select a filter that controls access as needed for this admin port. If you do not see the filter you need in the list of filters, go to the <a href=\"Inbound_Filter.asp\" onclick=\"return jump_if();\">Advanced → Inbound Filter</a> screen and create a new filter.", //hhta_831
	"Manual Internet Connection Setup", //LW30
	"Invalid L2TP subnet mask", //YM110
	"Point-to-Point (no broadcast)", //bd_NETBIOS_REG_TYPE_P
	"LAN subnet mask is invalid.", //GW_LAN_SUBNET_MASK_INVALID
	"No more reservations may be created", //YM88
	"Invalid primary WINS IP address", //GW_DHCP_SERVER_NETBIOS_PRIMARY_WINS_INVALID
	"Name (if any)", //YM187
	"%s name %s of '%s' is not defined.", //GW_NAT_NAME_UNDEFINED_INVALID
	"Wireless radar detected on channel %d", //GW_WIRELESS_RADAR_DETECTED
	"Pre-shared Key", //LW25
	"Restore Invalid", //_rs_invalid
	"Invalid primary DNS server IP address", //YM113
	"Wi-FI Protected Setup", //LW65
	"Select this option if your wireless device supports push button", //KR41
	"Invalid primary DNS server IP address: %v", //GW_WAN_DNS_SERVER_PRIMARY_INVALID
	"The Wireless Device PIN is not valid", //KR21
	"Personal Area Network", //help643
	"The <span class=\"option\">Router IP Address</span> field below must be set to the IP address of this device. The <span class=\"option\">Gateway</span> must be set to the IP address of the upstream router. Both addresses must be within the LAN subnet as specified by <span class=\"option\">Subnet Mask</span>.", //KR63
	"The following Web-based Setup Wizard is designed to assist you in your printer setup. This Setup Wizard will guide you through step-by-step instructions on how to set up your printer.", //LW31
	"Invalid secondary DNS server IP address: %v", //GW_WAN_DNS_SERVER_SECONDARY_INVALID
	"Invalid remote end IP Address.", //YM55
	"For information on which configuration method your wireless device support, please refer to the adapters' documentation.", //KR37
	"Check this box to allow the DHCP Server to offer NetBIOS configuration settings to the LAN hosts.", //KR80
	"Invalid WAN subnet mask", //YM100
	"Wake-On-LAN", //_wakeonlan
	"The device may be too busy to properly receive it right now. Please try the restore again. It is also possible that you are logged in as a \"user\" instead of an \"admin\" - only administrators can restore the configuration file. Please check the system log for any errors.", //rs_intro_3
	"PainKiller", //gw_gm_35
	"You will be redirected to the login page in", //YM7
	"If you are not utilizing Super G with Dynamic Turbo for its speed improvements, enable Auto Channel Scan so that the router can select the best possible channel for your wireless network to operate on.", //YM124g
	"MAC address %m already exists.", //GW_INET_ACL_MAC_ADDRESS_DUPLICATION_INVALID
	"invalid destination starting IP Address.", //YM66
	"Optimum Online", //manul_conn_13
	"NetBIOS Advertisement", //bd_NETBIOS
	"Target", //sa_Target
	"This section is where you define application rules.", //help56_a
	"<warn>DHCP Server is being reconfigured because the LAN subnet is not suitable, please ensure your server remains correct.</warn>", //GW_DHCP_SERVER_RECONFIG_WARNING
	"Failed", //_wifisc_addfail
	"Beacon period should be between 100 and 1000.", //GW_WLAN_BEACON_PERIOD_INVALID
	"Best Effort (BE)", //YM79
	"Invalid Aggregation Max Size", //YM32
	"This will save the current wireless configuration from the router to your computer through Microsoft's Windows Connect Now technology and allow future propagation of the setting through Microsoft's Wireless Network Setup Wizard.", //ta_intro_wcn
	"Select this option if your wireless adapters SUPPORT WPA", //wwl_text_better
	"Background (BK)", //YM78
	"Channel", //sd_channel
	"Note that different LAN computers cannot be associated with Port Forwarding rules that contain any ports in common; such rules would contradict each other.", //KR53
	"<strong>Lock Wireless Security Settings</strong> after all wireless network devices have been configured.", //LW16
	"TCP", //GW_NAT_TCP
	"This router has a USB port; so, if you have a USB flash drive, a USB port on your PC, and your PC runs Windows XP Service Pack 2 (SP2) or later, you can transfer wireless configuration data between your PC and the router with the USB flash drive. Go to the Windows Control Panel and select Wireless Network Setup Wizard. The Wireless Network Setup Wizard gives you the choices: \"Use a USB flash drive\" and \"Set up a network manually\". Select \"Use a USB flash drive\".", //help202
	"[CRIT]", //CRIT
	"The rule applies to a flow of messages for which the other computer's IP address falls within the range set here.", //YM154
	"The QoS Engine feature helps improve your network performance by prioritizing the data flows of network applications.", //help76
	"'%s': Host 1 port start, %u, must be less than host 1 port end, %u", //GW_WISH_RULES_HOST1_PORT
	"For 11g Turbo mode, the channel should be set to 6.", //GW_WLAN_11G_TURBO_INVALID
	"Entertainment", //_aa_bsecure_entertainment
	"Inactive", //YM165
	"Enter a name for the rule that is meaningful to you.", //help172
	"Lifestyles", //_aa_bsecure_lifestyles
	"DMZ address should be within LAN subnet(%v).", //GW_NAT_DMZ_NOT_IN_SUBNET_INVALID
	"Turbo Mode", //sd_TMode
	"%s port range '%s' of '%s' is invalid.", //GW_NAT_PORT_FORWARD_PORT_RANGE_INVALID
	"'%s': Local IP end '%v' is not in the LAN subnet", //GW_QOS_RULES_LOCAL_IP_END_SUBNET
	"AES", //bws_CT_2
	"Note that it is not possible to control access to web sites that use the secure HTTP protocol; that is, those whose URL is of the form <code>https://...</code>.", //_bsecure_parental_limits
	"64 Kbytes", //aw_64
	"Humor", //_aa_bsecure_humor
	"P-Node, this indicates to use WINS servers ONLY. This setting is useful to force all NetBIOS operation to the configured WINS servers. You must have configured at least the primary WINS server IP to point to a working WINS server.", //KR92
	"Router Mode", //KR13
	"Policy name can't be duplicated: %s.", //GW_INET_ACL_POLICY_NAME_DUPLICATE_INVALID
	"The NAT does not forward any incoming connection requests with the same port address as an already establish connection.", //YM136
	"Hardware Version", //TA3
	"Super G without Turbo:", //help360
	"Warnings", //YM10
	"Invalid PPTP server IP address: %v", //GW_WAN_PPTP_SERVER_IP_ADDRESS_INVALID
	"Video.", //YM150
	"The IP address %v is in use; you must Revoke its lease and reset the network settings for the device that uses it.", //GW_DHCP_SERVER_RESERVATION_IN_USE
	"Firewall Port", //GW_NAT_INPUT_PORT
	"Reboot by %s complete", //WIFISC_AP_REBOOT_COMPLETE
	"Latest Firmware Version", //YM182
	"1000Mbps", //LW3
	"WPA Personal Key must be at least 8 characters.", //YM116
	"WEP Key", //LW22
	"Oops!", //OOPS
	"WISH Sessions", //YM158
	"Send/Receive instance failure", //ZM16
	"Select Age Category", //_aa_bsecure_select_age
	"Route destination IP %s is invalid", //GW_ROUTES_DESTINATION_IP_ADDRESS_INVALID
	"Reset by %s complete", //WIFISC_AP_RESET_COMPLETE
	"NetBIOS Registration mode", //bd_NETBIOS_REG
	"LAN Gateway IP address is invalid.", //GW_LAN_GATEWAY_IP_ADDRESS_INVALID
	"Saves the new or edited Schedule Rule.", //KR96
	"Successfully exported configuration file", //GW_XML_CONFIG_GET_SUCCESS
	"UPnP renew entry %v <-> %v:%d <-> %v:%d %s timeout:%d '%s'", //GW_UPNP_IGD_PORTMAP_REFRESH
	"To achieve better wireless performance use <strong>WPA2 Only</strong> security mode (or in other words AES cipher).", //bws_msg_WPA_2
	"LAN IP address is invalid.", //GW_LAN_IP_ADDRESS_INVALID
	"Remote IP Start", //KR5
	"The QoS Engine supports overlaps between rules, where more than one rule can match for a specific message flow. If more than one rule is found to match the rule with the highest priority will be used.", //help88c
	"Schedule name %s is not defined.", //GW_INET_ACL_SCHEDULE_NAME_INVALID
	"'%s': Remote port start, %u, must be less than remote port end, %u", //GW_QOS_RULES_REMOTE_PORT
	"IP address for '%s' should be within LAN subnet (%v).", //GW_NAT_IP_ADDRESS_INVALID
	"128-bit hexadecimal keys are exactly 26 characters in length. (456FBCDF123400122225271730 is a valid string of 26 characters for 128-bit encryption.)", //help369
	"Instead of entering a name for the Special Application rule, you can select from this list of common applications, and the remaining configuration values will be filled in accordingly.", //help48a
	"Wireless Settings", //LW38
	"user account must be specified", //GW_DYNDNS_USER_NAME_INVALID
	"The destination IP address is the address of the host or network you wish to reach.", //hhav_r_dest_ip
	"The remote admin port number is not valid.", //YM175
	"Wi-Fi Protected Setup is used to easily add devices to a network using a PIN or button press. Devices must support Wi-Fi Protected Setup in order to be configured by this method.", //LY3
	"UPnP added entry %v <-> %v%d <-> %v%d %s timeout%d '%s'", //GW_UPNP_IGD_PORTMAP_ADD
	"UPnP conflict with existing entry %v <-> %v:%d <-> %v:%d %s '%s'", //GW_UPNP_IGD_PORTMAP_CONFLICT
	"Message", //KRA1
	"Port", //_vs_port
	"<warn>Access Control Table is being reconfigured because the LAN subnet has been changed.</warn>", //GW_INET_ACL_RECONFIGURED_WARNING
	"Enables 802.11d operation. 802.11d is a wireless specification for operation in additional regulatory domains. This supplement to the 802.11 specifications defines the physical layer requirements (channelization, hopping patterns, new values for current MIB attributes, and other requirements to extend the operation of 802.11 WLANs to new regulatory domains (countries). The current 802.11 standard defines operation in only a few regulatory domains (countries). This supplement adds the requirements and definitions necessary to allow 802.11 WLAN equipment to operate in markets not served by the current standard. Enable this option if you are operating in one of these \"additional regulatory domains\".", //help186
	"For most applications, the priority classifiers ensure the right priorities and specific WISH Rules are not required.", //YM145
	"Unset Selected Registrar", //WIFISC_AP_UNSET_SELECTED_REGISTRAR
	"Secondary DNS cannot be specified without giving a primary also.", //GW_WAN_DNS_SERVER_SECONDARY_WITHOUT_PRIMARY_INVALID
	"WISH (Wireless Intelligent Stream Handling) prioritizes the traffic of various wireless applications.", //YM72
	"Helpful Hints", //_hints
	"'%s': Local port start, %u, must be less than local port end, %u", //GW_QOS_RULES_LOCAL_PORT
	"Invalid local start IP Address.", //YM52
	"Chat", //_aa_bsecure_chat
	"Destination IP:", //help104
	"Note that, in Microsoft's current implementation of WCN, you cannot save the wireless settings if a profile of the same name already exists. To work around this limitation, either delete the existing profile or change the SSID when you change the wireless settings; then, when you save the new settings, a new profile will be created.", //help839
	"Invalid WAN IP address", //YM99
	"By Age", //_aa_bsecure_byage
	"Name '%s' already exists.", //GW_INET_ACL_NAME_DUPLICATE_INVALID
	"The DHCP server end address %v is not valid in the LAN subnet %v.", //GW_DHCP_SERVER_POOL_TO_INVALID
	"In progress", //KR26
	"Do you want to enable the DHCP Reservation entry for IP Address", //YM92
	"Reserved IP %v is invalid", //GW_DHCP_SERVER_RESERVED_IP_INVALID
	"The common choices -- UDP, TCP, and both UDP and TCP -- can be selected from the drop-down menu.", //help19x1
	"Unstable", //_aa_bsecure_unstable
	"Reserved IP address %v should be within the configured DHCP range.", //GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID
	"Filter Rule '%s' can't be deleted or renamed because it is used.", //GW_FIREWALL_FILTER_NAME_INVALID
	"You might need this file so that you can load your configuration later in the event that the router's default settings are restored.", //ZM19
	"Video (VI)", //YM80
	"Secondary WINS Server IP address", //bd_NETBIOS_WINS_2
	"Re-initializes the Add/Update area of the screen, erasing any changes that you may have made prior to clicking the Add/Update button.", //KR57
	"Active", //YM164
	"IP address is not allowed", //_logsyslog_alert2
	"Best Effort.", //YM149
	"Invalid DHCP Server lease time", //LT120
	"Auto (WPA or WPA2) - Personal", //KR48
	"Invalid Reconnect interval: %u (must be between 20 and 180)", //GW_WAN_RECONNECT_INTERVAL_INVALID
	"Controls endpoint filtering for packets of the TCP protocol.", //YM139
	"Remote start port should be between 0 and 65535 inclusive.", //YM61
	"<warn>Virtual Server Table is being reconfigured because the LAN subnet has been changed.</warn>", //GW_NAT_VIRTUAL_SERVER_TABLE_RECONFIGURED_WARNING
	"Reboot needed", //YM1
	"WEP Key Length", //bws_WKL
	"PIN (Personal Identification Number)", //wps_p3_2
	"Save Settings Succeeded", //KR102
	"'%s': Local IP start '%v' is not in the LAN subnet", //GW_QOS_RULES_LOCAL_IP_START_SUBNET
	"Invalid PPTP IP address: %v", //GW_WAN_PPTP_IP_ADDRESS_INVALID
	"Alcohol", //_aa_bsecure_alcohol
	"Port Filter rule names cannot be duplicated.", //YM14
	"Dynamic Turbo mode is not allowed with 802.11b.", //GW_WLAN_11B_DYNAMIC_TURBO_INVALID
	"UPnP expired entry %v <-> %v:%d <-> %v%d %s '%s'", //GW_UPNP_IGD_PORTMAP_EXPIRE
	"Once your router is configured the way you want it, you can save the configuration settings to a configuration file. You might need this file so that you can load your configuration later in the event that the router's default settings are restored. To save the configuration, click the <strong>Save Configuration</strong> button.", //TA18
	"This option is available only when <span class='option'>802.11 Mode</span> is set to <span class='option'>802.11n only</span> or <span class='option'>802.11g only</span>.", //aw_erpe_h2
	"Invalid Destination Port Start for Port Filter", //YM21
	"The priority of the message flow is entered here. Four priorities are defined:", //YM147
	"When the log email option is set, log emails are sent to the Internet by way of the upstream router.", //KR68
	"This Wizard helps you add wireless devices to the wireless network.", //LW61
	"A L2TP user name MUST be specified", //GW_WAN_L2TP_USERNAME_INVALID
	"Invalid Secondary WINS IP", //LT120z
	"WPA/WPA2", //KR97
	"Invalid L2TP subnet mask %v", //GW_WAN_L2TP_SUBNET_INVALID
	"Save Settings To Local Hard Drive", //help_ts_ss
	"Automobile", //_aa_bsecure_automobile
	"Add Wireless Device With WPS", //LW13
	"Time Frame", //sch_time
	"To protect your privacy you can configure wireless security features. This device supports three wireless security modes, including WEP, WPA-Personal, and WPA-Enterprise. WEP is the original wireless encryption standard. WPA provides a higher level of security. WPA-Personal does not require an authentication server. The WPA-Enterprise option requires an external RADIUS server.", //bws_intro_WlsSec
	"A PPPoE password MUST be specified", //GW_WAN_PPPOE_PASSWORD_INVALID
	"Before you can use the router's WCN Wizard, you must first execute the Wireless Network Setup Wizard on your PC. If you have not already done so, go to the Windows Control Panel and select Wireless Network Setup Wizard. When the Wireless Network Setup Wizard gives you the choice to \"Use a USB flash drive\" or \"Set up a network manually\", choose the latter. (In fact, you will not have to do the set-up manually; it will be done with the WCN ActiveX Control.)", //help211
	"Invalid Subnet Mask", //LS202
	"End Time", //tsc_EndTime
	"This wizard will guide you through a step-by-step process to add your wireless device to your wireless network.", //KR34
	"WEP Key 3", //_wepkey3
	"Remote Port Range", //at_RePortR
	"OSPF", //help640
	"The given server address (%s) is invalid", //GW_SMTP_SERVER_ADDRESS_INVALID
	"Invalid L2TP gateway IP address: %v", //GW_WAN_L2TP_GATEWAY_IP_ADDRESS_INVALID
	"Shows the current value of the router's PIN.", //LW58
	"Key In Use", //LW22usekey
	"Static Turbo mode is not allowed with 802.11b.", //GW_WLAN_11B_STATIC_TURBO_INVALID
	"invalid destination ending IP Address.", //YM67
	"<warn>Changing wireless security settings may cause Wi-Fi protected Setup to not function as expected.</warn>", //GW_WIFISC_CFG_CHANGED_WARNING
	"Restart during DNS query", //ZM10
	"Can not use 802.11b/g channel when the 802.11 mode is 802.11a.", //GW_WLAN_11A_CHANNEL_INVALID
	"QoS Engine Rules", //at_title_SERules
	"The remote admin port should be in the range of 1 to 65535.", //YM176
	"NetBIOS allow LAN hosts to discover all other computers within the network, e.g. within Network Neighbourhood.", //KR81
	"TCP Port", //GW_NAT_TCP_PORT
	"The rule applies to a flow of messages for which host 2's port number is within the range set here.", //YM155
	"This mode is backwards compatible with non-Turbo (legacy) devices. This mode should be enabled when some devices on the wireless network are not Turbo enabled but support other Super G features mentioned above.", //help365
	"NetBIOS Scope", //bd_NETBIOS_SCOPE
	"Session Aborted", //KR28
	"Web Filter", //_webfilter
	"Invalid Aggregation Num Packets", //YM33
	"Automatic", //YM76
	"Unlock AP setup", //WIFISC_AP_SETUP_UNLOCKED
	"Virtual server '%s' can not use the router's HTTPS WAN administration port, %u", //GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT
	"Release", //LS313
	"Microsoft Windows Connect Now Wizard", //bwz_WCNWz
	"DNS Lookup Login Server", //ZM9
	"Reserved IP address for this MAC address(%m) is already set.", //GW_DHCP_SERVER_RESERVED_MAC_UNIQUENESS_INVALID
	"PIN Settings", //LY5
	"For most applications, the priority classifiers ensure the right priorities, and specific WISH Rules are not required.", //YM87
	"The WAN Ping filter name %s does not exist", //GW_NAT_WAN_PING_FILTER_INVALID
	"If your PC's operating system is Windows XP Service Pack 2 (SP2) or later and you are using Windows Internet Explorer (IE) as your browser, you can use this option to save key parts of the router's current wireless security settings to your PC with Windows Connect Now (WCN) technology. The settings will then be available to propagate to other wireless devices.", //help835
	"(1..255)", //at_lowpriority
	"A name is required for rule number %d", //YM49
	"You cannot add new IP address %v. You can only reuse IP addresses from other policies.", //GW_INET_ACCESS_POLICY_TOO_MANY_IP_INVALID
	"Invalid L2TP server IP address", //YM112
	"H-Node, this indicates a Hybrid-State of operation. First WINS servers are tried, if any, followed by local network broadcast. This is generally the preferred mode if you have configured WINS servers.", //KR90
	"Note that WCN only saves a few of the wireless security settings. When you use WCN to propagate settings to other wireless devices, you may have to make additional settings manually on those devices.", //help838
	"Enable this option only if you have purchased your own domain name and registered with a dynamic DNS service provider. The following parameters are displayed when the option is enabled.", //help892
	"If WAN Port Mode is set to \"Bridge Mode\", the following choices are displayed in place of the above choices, because the device is functioning as a bridge in a network that contains another router.", //KR73
	"There are several levels of wireless security. The level you choose depends on the security features your wireless adapters support.", //wwl_intro_s3_2
	"Invalid Metric for route", //_r_alert5
	"<warn>The WAN Ping filter name %s no longer exists, WAN PING will be disabled.</warn>", //GW_NAT_WAN_PING_FILTER_WARNING
	"Invalid local end IP Address.", //YM53
	"Note that WCN only sets a few of the wireless options. You will still need to go to the <a href=\"wireless.asp\">Wireless Settings</a> page to set other wireless options such as Super G Mode and transmission rate.", //help215
	"WISH is short for Wireless Intelligent Stream Handling, a technology developed to enhance your experience of using a wireless network by prioritizing the traffic of different applications.", //YM140
	"The DHCP server address %v was rejected by the network device. If you have more than one DHCP server on your network this may cause IP address conflicts.", //GW_DHCPSERVER_REJECTED
	"Allows the router to recognize HTTP transfers for many common audio and video streams and prioritize them above other traffic. Such streams are frequently used by digital media players.", //YM142
	"Password is invalid", //GW_SMTP_PASSWORD_INVALID
	"The rule applies to a flow of messages for which one computer's IP address falls within the range set here.", //YM152
	"Invalid DHCP Server End IP Range", //LT119a
	"If you are having trouble accessing the Internet through the router, double check any settings you have entered on this page and verify them with your ISP if needed.", //LW36
	"The encryption algorithm used to secure the data communication. TKIP (Temporal Key Integrity Protocol) provides per-packet key generation and is based on WEP. AES (Advanced Encryption Standard) is a very secure block based encryption. With the \"TKIP and AES\" option, the router negotiates the cipher type with the client, and uses AES when available.", //help377
	"%s '%s' is invalid.", //GW_NAT_PORT_TRIGGER_PORT_RANGE_INVALID
	"Invalid WEP Keys", //YM121
	"Invalid Fragmentation Threshold", //YM29
	"The WISH Sessions page displays full details of active local wireless sessions through your router when WISH has been enabled. A WISH session is a conversation between a program or application on a wirelessly connected LAN-side computer and another computer, however connected.", //YM159
	"Invalid Port Number.", //YM120
	"BETTER", //wwl_BETTER
	"Enable the DMZ option only as a last resort. If you are having trouble using an application from a computer behind the router, first try opening ports associated with the application in the <a href='adv_virtual.asp' onclick='return jump_if();'>Virtual Server</a> or <a href='adv_portforward.asp' onclick='return jump_if();'>Port Forwarding</a> sections.", //hhaf_dmz
	"Invalid PPTP subnet mask", //YM106
	"Block Unrated Sites", //_aa_bsecure_block_unrated
	"A Big Pond user name MUST be specified", //GW_WAN_BIGPOND_USERNAME_INVALID
	"For example, 192.168.0.101.", //KR76
	"The DHCP server can offer no more IP addresses because all available addresses are in use. Increase the number of available IP addresses on the DHCP server configuration.", //GW_DHCPSERVER_EXHAUSTED
	"Invalid L2TP server IP address: %v", //GW_WAN_L2TP_SERVER_IP_ADDRESS_INVALID
	"WEP password must be exactly 13 alphanumeric characters.", //wwl_alert_pv5_2
	"Route subnet %v is invalid", //GW_ROUTES_SUBNET_INVALID
	"Drugs", //_aa_bsecure_drugs
	"IP address cannot be the same as LAN IP address of the router.", //LW1
	"A network computer never renewed its 'leasease' of %v and has lost its right to use that address. If the device continues to use that address it may cause IP address conflicts.", //GW_DHCPSERVER_EXPIRED
	"IP address %v should be within LAN subnet (%v).", //GW_INET_ACL_IP_ADDRESS_IN_LAN_SUBNET_INVALID
	"Broadcast only (use when no WINS servers configured)", //bd_NETBIOS_REG_TYPE_B
	"Financial", //_aa_bsecure_financial
	"The NAT forwards incoming connection requests to a LAN-side host only when they come from the same IP address with which a connection was established. This allows the remote application to send data back through a port different from the one used when the outgoing session was created.", //YM135
	"Invalid DHCP Server Start IP Range", //LT119
	"Public", //_vs_public
	"B-Node, this indicates to use local network broadcast ONLY. This setting is useful where there are no WINS servers available, however, it is preferred you try M-Node operation first.", //KR93
	"Gateway remote administration enabled on port: %u", //GW_SECURE_REMOTE_ADMINSTRATION
	"The IP address and, where appropriate, port number of the computer that originated a network connection.", //YM160
	"Assigned IP", //LS423
	"L2TP Gateway IP address %v must be within the WAN subnet.", //GW_WAN_L2TP_GATEWAY_IN_SUBNET_INVALID
	"%s': Host 1 IP start, %v, must be less than host 1 IP end, %v", //GW_WISH_RULES_HOST1_IP
	"Private", //_vs_private
	"This setting has no effect if the \"Learn NetBIOS information from WAN\" is activated.", //KR86
	"Secondary WINS IP Address", //bd_NETBIOS_SEC_WINS
	"Start IP address must be less than end IP address: %v-%v.", //GW_INET_ACL_START_IP_ADDRESS_INVALID
	"Authentication", //auth
	"Cannot stop the process", //KR24
	"5GHz", //KR17
	"Host 2 IP Range", //YM84
	"A QoS Engine Rule identifies a specific message flow and assigns a priority to that flow.", //help88
	"Enabling Remote Management, allows you or others to change the router configuration from a computer on the Internet.", //hhta_en
	"Invalid PPPoE IP address", //YM103
	"In bridge mode, the device still supports several features not available in ordinary bridges -- features that involve the WAN side of the upstream router.", //KR64
	"Per regulatory request, channel 52 - 140 can not be used without enable radar detection.", //GW_WLAN_11A_DFS_CHANNEL_INVALID
	"Wi-Fi Protected Setup", //LW4
	"Physical layer", //help645
	"For 11a Static Turbo mode, channel should be set to one of 42,50,58,152, or 160.", //GW_WLAN_11A_STATIC_TURBO_INVALID
	"Super G™ Mode", //help358
	"You do not have permissions to perform the specified action.", //YM6
	"Categories Selection", //_aa_bsecure_categ_select
	"Priority must be a number between 1 and 255 inclusive.", //YM58
	"Youth (13-17)", //_aa_bsecure_age_youth
	"Click <strong>Add Wireless Device Wizard</strong> to use Wi-Fi Protected Setup to add wireless devices to the wireless network.", //LW17
	"Invalid Destination IP End address for Port Filter", //YM18
	"WPA2-PSK/AES (also known as WPA2 Personal)", //LT210
	"Invalid Idle Time (the permitted range is %u to %u)", //GW_WAN_IDLE_TIME_INVALID
	"Multicast Group Address", //YM186
	"Sports", //_aa_bsecure_sports
	"Name '%s' is already used.", //GW_QOS_RULES_NAME_ALREADY_USED
	"The following wizard uses Microsoft's Windows Connect Now technology to automatically configure the wireless settings on your Router. Make sure that you have sucessfully run Microsoft's Network Wireless Configuarion Wizard on your computer before using this feature.", //bwz_intro_WCNWz
	"DHCP server pool TO %v is not in LAN subnet %v.", //GW_DHCP_SERVER_POOL_TO_IN_SUBNET_INVALID
	"<warn>The H.323 has been automatically enabled because a virtual server entry you created requires it.</warn>", //GW_NAT_H323_ALG_ACTIVATED_WARNING
	"L2 Isolation", //KR4
	"Invalid Primary WINS IP", //LT120y
	"The Wi-Fi Protected Setup Network Settings have been saved successfully.", //KR103
	"Calista IP phone", //YM44
	"If you consider yourself an advanced user and have configured a wireless router before, click <strong>Manual Wireless Network Setup</strong> to input all the settings manually.", //LW47
	"Failed to export configuration file #%u", //GW_XML_CONFIG_GET_FAILED
	"SetAPSettings by (%s) complete", //WIFISC_AP_SET_APSETTINGS_COMPLETE
	"Wep Key Length", //wwl_WKL
	"Communication with the router failed", //YM168
	"Name '%s' is already used.", //GW_NAT_NAME_USED_INVALID
	"invalid server index value: %d", //GW_DYNDNS_SERVER_INDEX_VALUE_INVALID
	"[WARN]", //WARN
	"Enterprise", //LW23
	"Advanced Network", //ADVANCED_NETWORK
	"A PPTP password MUST be specified", //GW_WAN_PPTP_PASSWORD_INVALID
	"Restore the default PIN of the router.", //LW59
	"If you have enabled Wireless Security, make sure you write down the Key or Passphrase that you have configured. You will need to enter this information on any wireless device that you connect to your wireless network.", //YM126
	"Enabled", //_enabled
	"Invalid Interface for route", //_r_alert4
	"Add Wireless Station", //LY10
	"The DHCP server start address %v is not valid in the LAN subnet %v.", //GW_DHCP_SERVER_POOL_FROM_INVALID
	"Lock AP setup", //WIFISC_AP_SETUP_LOCKED
	"Do you want to abandon changes you made to the current entry?", //YM91
	"Set Selected Registrar failed, reason (%s), err_code (%u)", //WIFISC_AP_SET_SELECTED_REGISTRAR_FAIL
	"Nothing has changed, save anyway?", //_ask_nochange
	"Unknown", //GW_NAT_UNKNOWN
	"For 11a Dynamic Turbo mode, channel should be set to one of 40,48,56,153, or 161.", //GW_WLAN_11A_DYNAMIC_TURBO_INVALID
	"Note that, even when NTP Server is enabled, you must still choose a time zone and set the daylight saving parameters.", //YM163
	"To use this feature, you must first have a Dynamic DNS account from one of the providers in the drop down menu.", //YM181
	"Insufficient Permission", //_cantapplysettings_1
	"Warnings:", //YM11
	"(8 to 63 characters)", //wwl_wsp_chars_2
	"Primary WINS IP Address", //bd_NETBIOS_PRI_WINS
	"Default WEP Key to Use", //wwl_DWKL
	"Wireless Device PIN", //KR44
	"obj_word + \" conflict with Virtual Server Port.\"", //TEXT056
	"Invalid Server IP Address", //YM130
	"Select Dynamic DNS Server", //KR99
	"Primary WINS IP address must be specified if secondary is also specified.", //GW_DHCP_SERVER_PRIMARY_AND_SECONDARY_WINS_IP_INVALID
	"Enable anti-spoof checking", //KR106
	"Virtual server '%s' protocol number, %d, must be 0 or between 3 and 255.", //GW_NAT_VS_PROTOCOL_INVALID
	"Select this option if you want to setup your network manually", //KR52
	"Welcome to the Add Wireless Device Wizard", //KR33
	"You must be logged in as \"admin\" to perform this action.", //ZM23
	"This wizard is designed to assist you in connecting your wireless device to your router. It will guide you through step-by-step instructions on how to get your wireless device connected. Click the button below to begin.", //LW40
	"Lock Wireless Security Settings", //LY4
	"If you consider yourself an advanced user and have configured a router before, click <strong>Manual Internet Connection Setup</strong> to input all the settings manually.", //LW34
	"Are you sure you want to delete", //YM25
	"Invalid Destination IP Start address for Port Filter", //YM15
	"Super&nbsp;G&trade;&nbsp;Mode", //bwl_SGM
	"Radius server address is not valid.", //GW_WLAN_80211X_RADIUS_INVALID
	"'%s': Protocol, %u, needs to be between 0 and 257", //GW_WISH_RULES_PROTOCOL
	"Login", //LS316
	"User has logged out", //ZM15
	"<warn>A DHCP Reservation has been disabled because it conflicts with the routers own LAN IP.</warn>", //GW_DHCP_SERVER_RESERVATION_DISABLED_IN_CONFLICT_WARNING
	"host must be specified", //GW_DYNDNS_HOST_NAME_INVALID
	"Manual Wireless Network Setup", //LW42
	"Invalid PPTP gateway IP address: %v", //GW_WAN_PPTP_GATEWAY_IP_ADDRESS_INVALID
	"The restored configuration file has been uploaded successfully.", //rs_intro_4
	"'%s': Remote IP end '%v' is in the LAN subnet", //GW_QOS_RULES_REMOTE_IP_END_SUBNET
	"N/A", //_NA
	"The gateway IP address is the IP address of the router, if any, used to reach the specified destination.", //hhav_r_gateway
	"[INFO]", //INFO
	"Metric", //help112
	"Note: Some firmware upgrades reset the configuration options to the factory defaults. Before performing an upgrade, be sure to save the current configuration.\n Do you still want to upgrade?", //tf_msg_FWUgReset
	"Learn NetBIOS information from WAN", //bd_NETBIOS_WAN
	"Force Short Slot for 11N Clients", //aw_igslot
	"(default if not matched by anything else)", //ZM2
	"You do not have permission to perform the specified action.", //LT7
	"Set Selected Registrar", //WIFISC_AP_SET_SELECTED_REGISTRAR
	"When the necessary preparations are complete, the WCN technology will propagate the wireless network settings from your PC to the router. Then you will have to reboot the router for the settings to take effect.", //help214
	"Both", //at_Both
	"Day of Week", //ZM22
	"Restore To Factory Default Settings", //help_ts_rfd
	"If your PC's operating system is Windows XP Service Pack 2 (SP2) or later and you are using Windows Internet Explorer (IE) as your browser, you can use Windows Connect Now (WCN) technology to help configure the router's wireless security settings.", //help209
	"destination starting port should be between 0 and 65535 inclusive.", //YM70
	"UPnP changed VS entry %v <-> %v:%d <-> %v:%d %s to %s", //GW_UPNP_IGD_PORTMAP_VS_CHANGE
	"The Web Filter section is one of two means by which you can specify the web sites you want to allow. You also have the alternative of using the Sentinel Parental Controls Service, which allows you to specify broad categories of web sites and saves you the trouble of entering specific web site URLs. For more information about the Sentinel service, refer to <a href='../Tools/Sentinel.shtml'>Tools&nbsp;&rarr;&nbsp;Sentinel</a>.", //help143s
	"This mode is not backwards compatible with non-Turbo (legacy) devices. This mode should only be enabled when all devices on the wireless network are Static Turbo enabled.", //help363
	"Web Newsgroup", //_aa_bsecure_web_newsgroup
	"Invalid Primary DNS Address", //YM128
	"%s of '%s' can not be empty.", //GW_NAT_PORT_TRIGGER_PORT_RANGE_EMPTY_INVALID
	"StreamEngine&trade; technology is applied to media streams that are passed between the WAN side of the upstream router and clients of the bridge.", //KR72
	"Password or Key", //td_PWK
	"Host 1 IP Range", //YM82
	"Invalid Authentication Timeout.", //YM119
	"The bridge still has the ability to analyze traffic on the WAN side of the upstream router so as to determine the speed of its WAN connection.", //KR70
	"The IP address and, where appropriate, port number of the computer to which a network connection has been made.", //YM161
	"DHCP server pool size is too big (must be no more than 256 addresses).", //GW_DHCP_SERVER_POOL_SIZE_INVALID
	"Established", //_sdi_s4b
	"DNS Lookup Authentication Server", //ZM8
	"Invalid Secondary DNS Address", //YM129
	"64-bit ASCII keys are up to 5 characters in length (DMODE is a valid string of 5 characters for 64-bit encryption.)", //help370
	"Locking the WPS-PIN Setup prevents the settings from being changed by any new external register using its PIN. Devices can still be added to the wireless network using Wi-Fi Protected Setup. It is still possible to change wireless network settings with <a href=\"wireless.asp\" shape=\"rect\">Manual Wireless Network Setup</a>, <a href=\"wizard_wlan.asp\" shape=\"rect\">Wireless Network Setup Wizard</a>", //LY29
	"Warning while writing configuration file: %s", //GW_XML_CONFIG_WRITE_WARN
	"Name '%s' is already used", //GW_FIREWALL_NAME_INVALID
	"'%s': Host 2 IP start, %v, must be less than host 2 IP end, %v", //GW_WISH_RULES_HOST2_IP
	"Product Page", //TA2
	"Connect", //LS314
	"Traffic Type", //_vs_traffictype
	"The timeout value cannot be greater than 8760.", //GW_DYNDNS_TIMEOUT_TOO_BIG_INVALID
	"please enter the PIN from your wireless device and click the below 'Connect' Button", //wps_p3_4
	"Select this option if your wireless device supports Wi-Fi Protected Setup", //KR51
	"PPTP Gateway IP address %v must be within the WAN subnet.", //GW_WAN_PPTP_GATEWAY_IN_SUBNET_INVALID
	"Click the <span class=\"button_ref\">Save to Windows Connect Now</span> button, and the WCN technology will capture the wireless network settings from your router and save them on your PC.", //help837
	"Please select an Application Name first", //TEXT052
	"Open", //OPEN
	"News", //_aa_bsecure_news
	"Update", //YM34
	"Advanced Wireless", //_advwls
	"<warn>DHCP Reservation %v has been disabled because the DHCP pool is too small.</warn>", //GW_DHCP_SERVER_RESERVATION_DISABLED_OUT_OF_POOL_WARNING
	"MAC Filter settings will lockout all machines. This is not allowed.", //GW_MAC_FILTER_ALL_LOCKED_OUT_INVALID
	"WEP Key 4", //_wepkey4
	"optional", //LT124
	"Search Engine", //_aa_bsecure_search_engine
	"WPA Only", //KR47
	"If you choose the WEP security option this device will <strong>ONLY</strong> operate in <strong>Legacy Wireless mode (802.11B/G)</strong>. This means you will <strong>NOT</strong> get 11N performance due to the fact that WEP is not supported by the Draft 11N specification.", //bws_msg_WEP_3
	"<warn>Email server address conflicts with router LAN address - email will be disabled.</warn>", //GW_SMTP_LAN_ADDRESS_CONFLICT_WARNING
	"LAN IP mode is invalid", //GW_LAN_IP_MODE_INVALID
	"The specified Big Pond server is not a proper domain name or IP address.", //GW_WAN_BIGPOND_SERVER_NOTSTD15
	"Fragmentation threshold should be between 256 and 2346.", //GW_WLAN_FRAGMENT_THRESHOLD_INVALID
	"Domain name given is invalid", //GW_LAN_DOMAIN_NAME_INVALID
	"Device name given is invalid", //GW_LAN_DEVICE_NAME_INVALID
	"Session Overlap Detected", //_wifisc_overlap
	"The wizard will either display the wireless network settings to guide you through manual configuration, prompt you to enter the PIN for the device, or ask you to press the configuration button on the device. If the device supports Wi-Fi Protected Setup and has a configuration button, you can add it to the network by pressing the configuration button on the device and then the on the router within 60 seconds. The status LED on the router will flash three times if the device has been successfully added to the network.", //LW62
	"Process stopped. You may click on the Cancel button below to return to the beginning of the wizard page and restart the process", //KR23
	"Pornography", //_aa_bsecure_pornography
	"Name can not be empty string.", //GW_NAT_NAME_INVALID
	"Number of Dynamic DHCP Clients", //bd_title_clients
	"Invalid PPTP server IP address", //YM108
	"Destination IP End address should not be in LAN subnet", //YM19
	"STA with MAC (%m) registered in", //WIFISC_AP_PROXY_PROCESS_COMPLETE
	"Record '%s' is duplicate of '%s'.", //GW_NAT_ENTRY_DUPLICATED_INVALID
	"%s' [%s:%s] conflicts with '%s'[%s:%s] on different IP Addresses.", //GW_NAT_PORT_FORWARD_CONFLICT_INVALID
	"Are you sure you want to update", //YM38
	"NTP Server is not configured", //tt_alert_nontp
	"Wi-Fi Protected Setup", //LY2
	"PIN(1st half) Mismatch Detected", //KR29
	"Session Over", //KR31
	"Init failed", //_init_fail
	"source starting port should be between 0 and 65535 inclusive.", //YM68
	"MAC Address", //sd_macaddr
	"WAN Port Mode", //KR12
	"A method of encrypting data for wireless communication intended to provide the same level of privacy as a wired network. WEP is not as secure as WPA encryption. To gain access to a WEP network, you must know the key. The key is a string of characters that you create. When using WEP, you must determine the level of encryption. The type of encryption determines the key length. 128-bit encryption requires a longer key than 64-bit encryption. Keys are defined by entering in a string in HEX (hexadecimal - using characters 0-9, A-F) or ASCII (American Standard Code for Information Interchange - alphanumeric characters) format. ASCII format is provided so you can enter a string that is easier to remember. The ASCII string is converted to HEX for use over the network. Four keys can be defined so that you can change keys easily. A default key is selected for use on the network.", //help366
	"AP registered to Registrar (%s) through %s", //WIFISC_AP_REGISTRATION_COMPLETE
	"TPC Max Gain", //aw_TPC
	"WDS AP MAC Address", //aw_WDSMAC
	"Remote end port should be between 0 and 65535 inclusive.", //YM62
	"Extra protection for neighboring 11b wireless networks. Turn this option off to reduce the adverse effect of legacy wireless networks on 802.11ng performance.", //aw_erpe_h
	"Invalid reconnect mode", //GW_WAN_RECONNECT_MODE_INVALID
	"DelAPSettings by (%s) complete", //WIFISC_AP_DEL_APSETTINGS_COMPLETE
	"Only \"Admin\" account can change security settings.", //LW15
	"If you are new to networking and have never configured a router before, click on <strong>Internet Connection Setup Wizard</strong> and the router will guide you through a few simple steps to get your network up and running.", //LW33
	"Succeeded. To add another device click on the Cancel button below or click on the Wireless Status button to check wireless status.", //KR27
	"Controls endpoint filtering for packets of the UDP protocol.", //YM138
	"%s' [%s%d]->%v/%d conflicts with '%s' [%s%d]->%v%d.", //GW_NAT_VS_PORT_CONFLICT_INVALID
	"Primary WINS Server IP address", //bd_NETBIOS_WINS_1
	"Step 5: Sentinel Categories", //_aa_wiz_s6_title
	"WISH Rules", //YM77
	"QoS Engine", //YM48
	"Invalid Reservation IP Address", //YM89
	"Pre-Shared Key should be all HEX chars if length is 64.", //GW_WLAN_WPA_PSK_HEX_STRING_INVALID
	"Invalid WAN IP address: %v", //GW_WAN_WAN_IP_ADDRESS_INVALID
	"Do you want to abandon all changes you made to this page?", //LS4
	"The specified Dynamic DNS Service Provider is not supported.", //KR98
	"Background (least urgent).", //YM148
	"Auto (WPA or WPA2)", //bws_WPAM_2
	"If you would like to be notified when new firmware is released, place a checkmark in the box next to <span class=\"option\">Email Notification of Newer Firmware Version</span>.", //help877a
	"Add/Update", //KR56
	"Hostname", //LS424
	"The DHCP server address %v was declined by the network device - check your network for IP Address conflicts.", //GW_DHCPSERVER_DECLINED
	"No day is selected", //GW_SCHEDULES_DAY_INVALID
	"UDP", //GW_NAT_UDP
	"Unable to create connection to email server", //IPSMTPCLIENT_CANNOT_CREATE_CONNECTION
	"Check All", //_aa_check_all
	"Renew", //LS312
	"Invalid IP address", //KR2
	"Protocol", //_vs_proto
	"The given TO address (%s) is invalid", //GW_SMTP_TO_ADDRESS_INVALID
	"AP failed to registere to Registrar (%s) through %s, reason (%s), err code (%u)", //WIFISC_AP_REGISTRATION_FAIL
	"Name '%s' is already used.", //GW_WISH_RULES_NAME_ALREADY_USED
	"When a LAN application that uses a protocol other than UDP, TCP, or ICMP initiates a session to the Internet, the router's NAT can track such a session, even though it does not recognize the protocol. This feature is useful because it enables certain applications (most importantly a single VPN connection to a remote host) without the need for an ALG.", //LW48
	"Invalid remote start IP Address.", //YM54
	"Current PIN", //LW9
	"This wizard is designed to assist you in your wireless network setup. It will guide you through step-by-step instructions on how to set up your wireless network and how to make it secure.", //LW41
	"Enable Auto Channel Scan", //ebwl_AChan
	"RTS threshold should be between 1 and 2347.", //GW_WLAN_RTS_THRESHOLD_INVALID
	"A L2TP password MUST be specified", //GW_WAN_L2TP_PASSWORD_INVALID
	"Some configuration changes have an effect upon other system settings. Those changes may impact in a negative way, raising warnings that need to be communicated to you. A warning may indicate a feature has been modified, or even disabled, to match the new operating conditions.", //YM12
	"User is logging out", //ZM14
	"In this case the term \"port\" refers to the Ethernet connectors on the device.", //KR60
	"Invalid RTS Threshold", //YM28
	"The schedule is not valid.", //YM184
	"If you would like to utilize our easy to use Web-based Wizards to assist you in configuring the Microsoft's Windows Connect Now technology, click on the Setup Wizard button below.", //int_intro_WCNWz7
	"Shared Key", //bws_Auth_2
	"The restored configuration file is not correct. You may have restored a file that is not intended for this device, or the restored file may be corrupted.", //rs_intro_1
	"The protocol used by the messages.", //help92
	"Both", //GW_NAT_BOTH
	"Restore Success", //rs_success
	"(GMT+01:00) Budapest, Vienna, Prague, Warsaw", //up_tz_29b
	"Day", //day
	"<warn>DHCP Server is being disabled because the LAN subnet is not suitable</warn>", //GW_DHCP_SERVER_DISABLED_WARNING
	"Password", //_password
	"Invalid MAC address %m.", //GW_INET_ACCESS_POLICY_MAC_INVALID
	"Wi-Fi Protected Setup", //LW2
	"Assign any unused IP address in the range of IP addresses available for the LAN.", //KR75
	"Failed to write configuration file: %s", //GW_XML_CONFIG_WRITE_FAILED
	"Enable WISH", //YM73
	"Name '%s' is already used.", //GW_WISH_RULES_NAME_USED_INVALID
	"The DHCP server pool size is too big to fit in LAN subnet %v.", //GW_DHCP_SERVER_POOL_SIZE_IN_SUBNET_INVALID
	"Aggregation Max Size", //aw_AS
	"This is a list of all active conversations involving wireless clients in the local network.", //YM171
	"Reserved IP %v conflicts with configured LAN IP Address", //GW_DHCP_SERVER_RESERVED_IP_NOT_LAN_IP_INVALID
	"Virtual server '%s' can not use the router's HTTP WAN administration port, %u", //GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT
	"The netmask field identifies the portion of the destination IP in use.", //hhav_r_netmask
	"VIRTUAL SERVERS LIST", //vs_vslist
	"IPv6 FIREWALL", //if_iflist
	"Note that some of these options can interact with other port restrictions. Endpoint Independent Filtering takes priority over inbound filters or schedules, so it is possible for an incoming session request related to an outgoing session to enter through a port in spite of an active inbound filter on that port. However, packets will be rejected as expected when sent to blocked ports (whether blocked by schedule or by inbound filter) for which there are no active sessions. Port and Address Restricted Filtering ensures that inbound filters and schedules work precisely, but prevents some level of connectivity, and therefore might require the use of port triggers, virtual servers, or port forwarding to open the ports needed by the application. Address Restricted Filtering gives a compromise position, which avoids problems when communicating with certain other types of NAT router (symmetric NATs in particular) but leaves inbound filters and scheduled access working as expected.", //YM137
	"Priority Classifiers", //YM74
	"Syslog server IP address %v is not in the lan subnet.", //GW_SYSLOG_ADDRESS_IN_SUBNET_INVALID
	"Enable this option if you have a syslog server currently running on the LAN and wish to send log messages to it.", //help858
	"MAC address is already used: %s", //GW_MAC_FILTER_MAC_UNIQUENESS_INVALID
	"Push Button", //KR40
	"MAC address filter can't be NULL address: %m", //GW_MAC_FILTER_NULL_MAC_INVALID
	"32 Kbytes", //aw_32
	"WAN subnet conflicts with LAN subnet", //GW_WAN_LAN_SUBNET_CONFLICT_INVALID
	"Enabled/Configured", //LW66
	"DelAPSettings by (%s) failed, reason (%s), err_code (%u)", //WIFISC_AP_DEL_APSETTINGS_FAIL
	"(13 characters or 26 hex digits)", //wwl_wsp_chars_1
	"WINS Servers store information regarding network hosts, allowing hosts to \"register\" themselves as well as discover other available hosts, e.g. for use in Network Neighbourhood.", //KR85
	"Invalid MTU Size", //YM115
	"Host 1 Port Range", //YM83
	"128 bits", //wwl_128bits
	"When an excessive number of wireless packet collisions are occurring, wireless performance can be improved by using the RTS/CTS (Request to Send/Clear to Send) handshake protocol.", //LW51
	"You must enter a numeric value between 0 and 8760 inclusive.", //YM178
	"Cults", //_aa_bsecure_cults
	"Forbidden", //YM5
	"Firmware update checks", //KR65
	"Firmware updates are released periodically to improve the functionality of your router and to add features. If you run into a problem with a specific feature of the router, check if updated firmware is available for your router.", //ZM17
	"<strong>Enable</strong> if other wireless devices you wish to include in the local network support Wi-Fi Protected Setup.", //LW14
	"Save to Windows Connect Now", //ta_wcn_bv
	"Virtual server '%s' can not use the router's IP address, %v.", //GW_NAT_VS_IP_ADDRESS_CAN_NOT_MATCH_ROUTER
	"Schedule '%s' can't be deleted or renamed because it is used.", //GW_SCHEDULES_IN_USE_INVALID
	"WEP Key 3", //wepkey3
	"Internet rate estimation", //KR69
	"AIM Talk", //YM43
	"ICQ", //YM45
	"User name is invalid", //GW_SMTP_USERNAME_INVALID
	"Super G with Static Turbo", //help362
	"If you would like to be notified when new firmware is released, place a checkmark in the box next to Email Notification of Newer Firmware Version.", //tf_intro_FWChA
	"REMOTE DESKTOP", //_remotedesktop
	"PIN Settings", //LW7
	"Super G Turbo Modes must use channel 6 for communication. For Super G with Static Turbo, <span class=\"option\">802.11 Mode</span> must be set to 802.11g. For proper operation, RTS threshold and Fragmentation Threshold on the <a href=\"adv_wlan_perform.asp\">Advanced &rarr; Advanced Wireless</a> screen should both be set to their default values.", //help359
	"Configure the IP address of the preferred WINS server.", //KR84
	"DTIM should be between 1 and 255.", //YM30
	"Local Port Range", //at_LoPortR
	"DHCP server pool FROM %v is not in LAN subnet %v.", //GW_DHCP_SERVER_POOL_FROM_IN_SUBNET_INVALID
	"MAC address filter can't be multicast address format: %m", //GW_MAC_FILTER_MULTICAST_MAC_INVALID
	"<warn>Initialisation of email failed</warn>", //GW_SMTP_INIT_FAILED_WARNING
	"DHCP server stopped", //GW_DHCPSERVER_STOP
	"To protect your privacy, use the wireless security mode to configure the wireless security features. This device supports three wireless security modes including: WEP, WPA-Personal, and WPA-Enterprise. WEP is the original wireless encryption standard. WPA provides a higher level of security. WPA-Personal does not require an authentication server. The WPA-Enterprise option does require a RADIUS authentication server.", //help350
	"DMZ address %v is not allowed.", //GW_NAT_DMZ_NOT_ALLOWED_INVALID
	"When enabled, this option causes the router to automatically attempt to prioritize traffic streams that it doesn't otherwise recognize, based on the behaviour that the streams exhibit. This acts to deprioritize streams that exhibit bulk transfer characteristics, such as file transfers, while leaving interactive traffic, such as gaming or VoIP, running at a normal priority.", //YM143
	"Failed to import configuration file #%u", //GW_XML_CONFIG_SET_FAILED
	"%s '%s' of '%s' should not contain duplicated numbers.", //GW_NAT_PORT_DUP_INVALID
	"seconds for your wireless device to be connected. If you want to stop the process, click on the Cancel button below.", //KR46
	"Step 1: Select Configuration Method for your Wireless Network", //KR35
	"A Big Pond password MUST be specified", //GW_WAN_BIGPOND_PASSWORD_INVALID
	"Protocol must be specified.", //YM57
	"The router must be rebooted before the new settings will take effect. You can reboot now, or you can continue to make other changes and reboot later.", //KR104
	"sender email address is in wrong format", //IPSMTPCLIENT_MSG_WRONG_SENDER_ADDR_FORMAT
	"Logout", //LS317
	"The entered passwords do not match", //YM102
	"When WDS is enabled, this access point functions as a wireless repeater and is able to wirelessly communicate with other APs via WDS links. Note that WDS is incompatible with WPA -- both features cannot be used at the same time. A WDS link is bidirectional; so this AP must know the MAC Address (creates the WDS link) of the other AP, and the other AP must have a WDS link back to this AP.", //help188
	"IP address is not valid", //_logsyslog_alert1
	"Invalid MAC address", //KR3
	"Hate", //_aa_bsecure_hate
	"Can not use 802.11a channel when the 802.11 mode is 802.11b/g.", //GW_WLAN_11BG_CHANNEL_INVALID
	"Rate estimation completed", //RATE_ESTIMATOR_RATE_COMPLETED
	"WEP key must be exactly 26 hexadecimal digits (0-9 or A-F).", //wwl_alert_pv5_3
	"Aggregation Limit", //aw_aggr
	"Started", //_wifisc_addstart
	"Specifies the interface -- LAN or WAN -- that the IP packet must use to transit out of the router, when this route is used.", //help111
	"'%s': Remote IP start '%v' is in the LAN subnet", //GW_QOS_RULES_REMOTE_IP_START_SUBNET
	"Invalid Destination Port End for Port Filter", //YM22
	"Can not use a multicast MAC address in WDS.", //GW_WLAN_WDS_MAC_ADDR_INVALID
	"Reset PIN to Default", //LW10
	"This area of the screen reflects configuration settings from the <a href='wireless.asp'>Setup &rarr; Wireless Settings</a> page. The <span class='option'>MAC Address</span> is the factory-assigned identifier of the wireless card.", //LT291
	"This section is where you define WISH Rules.", //YM156
	"Adolescent (9-12)", //_aa_bsecure_age_ado
	"Select this option if your wireless adapters DO NOT SUPPORT WPA", //wwl_text_good
	"'%s': Priority, %d, needs to be between 1 and 255", //GW_QOS_RULES_PRIORITY_RANGE
	"On Schedule", //te_OnSch
	"Web Mail", //_aa_bsecure_web_mail
	"Make sure the APs are configured with same channel number.", //help188b
	"Start IP address(%v) of '%s' should not be within LAN subnet(%v).", //GW_INET_ACL_START_IP_ADDRESS_IN_LAN_SUBNET_INVALID
	"WAN Traffic Shaping", //at_title_Traff
	"Specifies one-half of the WDS link. The other AP must also have the MAC address of this AP to create the WDS link back to this AP.", //help189
	"Wireless radar detected, switch to channel %d", //GW_WIRELESS_SWITCH_CHANNEL
	"A Big Pond server MUST be specified", //GW_WAN_BIGPOND_SERVER_INVALID
	"Configuration file parse error around line %u char %u", //GW_XML_CONFIG_SET_PARSE
	"Enabling <strong>WMM</strong> can help control latency and jitter when transmitting multimedia content over a wireless connection.", //hhaw_wmm
	"This area of the screen reflects configuration settings from the <a href=\"wireless.asp\">Setup &rarr; Wireless Settings</a> page, the <a href=\"adv_wish.asp\">Advanced &rarr; WISH</a> page and the <a href=\"../Advanced/Protected_Setup.shtml\">Advanced &rarr; Wi-Fi Protected Setup</a> page. The <span class=\"option\">MAC Address</span> is the factory-assigned identifier of the wireless card.", //LT290wifisc
	"Rule name can not be empty string", //GW_FIREWALL_RULE_NAME_INVALID
	"Schedule", //GW_NAT_SCHEDULE
	"Specifies the next hop to be taken if this route is used. A gateway of 0.0.0.0 implies there is no next hop, and the IP address matched is directly connected to the router on the interface specified: LAN or WAN.", //help109
	"RIP mode is invalid.", //GW_LAN_RIP_MODE_INVALID
	"The wireless transmitter will begin to send RTS frames (and wait for CTS) when data frame size in bytes is greater than the RTS Threshold.", //LW52
	"Pop-ups", //_aa_bsecure_popups
	"WPA2 only mode doesn't support TKIP.", //GW_WLAN_WPA_WPA2_TKIP_INVALID
	"2.4GHz", //KR16
	"Virtual Server", //_vs_title
	"IPv6 FIREWALL", //_if_title
	"A PPPoE user name MUST be specified", //GW_WAN_PPPOE_USERNAME_INVALID
	"Invalid PPTP subnet mask %v", //GW_WAN_PPTP_SUBNET_INVALID
	"NetBIOS Scope is not in a valid form", //GW_DHCP_SERVER_NETBIOS_SCOPE_INVALID
	"Static IP mode is always on, so no action buttons are avaliable.", //KR94
	"WISH", //YM63
	"Gateway", //help108
	"This schedule is already used in '%s'", //GW_SCHEDULES_DUPLICATED_INVALID
	"WPA Only", //bws_WPAM_1
	"Public port should be in range (1..65535) for virtual server", //KR11
	"If you already have a wireless network setup with Wi-Fi Protected Setup, click on <strong>Add Wireless Device Wizard</strong> to add new device to your wireless network.", //LW45
	"Remote IP End", //KR6
	"Invalid NetBIOS registration type", //GW_DHCP_SERVER_NETBIOS_TYPE_INVALID
	"Games", //_aa_bsecure_games
	"Select this option if you want to configure your wireless device manually", //KR42
	"Invalid Idle Time", //YM104
	"Tickets", //_aa_bsecure_tickets
	"Select this option if your wireless device supports PIN", //KR39
	"Mixed-mode (Broadcast then Point-to-Point)", //bd_NETBIOS_REG_TYPE_M
	"Enter a host name or IP address above and click 'Ping'", //tsc_pingt_msg1
	"UPnP deleted entry %v <-> %v:%d %s", //GW_UPNP_IGD_PORTMAP_DEL
	"Invalid L2TP gateway IP address", //YM111
	"Disconnect", //LS315
	"Incorrect key length, should be 8 to 63 characters long.", //GW_WLAN_WPA_PSK_LEN_INVALID
	"Permit any WAN user to access the related capability.", //help178
	"Getting active session list. Please wait", //YM167
	"128-bit ASCII keys are up to 13 characters in length (2002HALOSWIN1 is a valid string of 13 characters for 128-bit encryption.)", //help371
	"Anarchy", //_aa_bsecure_anarchy
	"Reboot Later", //YM4
	"Criminal Skills", //_aa_bsecure_criminal_skills
	"Warnings have been raised as a result of configuration changes.\nThe system is unable to generate a list of those warnings right now, but will retry.", //YM188
	"The NAT Endpoint Filtering options control how the router's NAT manages incoming connection requests to ports that are already being used.", //YM133
	"Local start port should be between 0 and 65535 inclusive.", //YM59
	"Manually", //_aa_bsecure_manually
	"Email address is not configured.", //YM169
	"Use this section to configure the internal network settings of your router. The IP Address that is configured here is the IP Address that you use to access the Web-based management interface. If you change the IP Address here, you may need to adjust your PC's network settings to access the network again.", //YM97
	"Child (0-8)", //_aa_bsecure_age_child
	"WPA is the older standard; select this option if the clients that will be used with the router only support the older standard. WPA2 is the newer implementation of the stronger IEEE 802.11i security standard. With the \"WPA or WPA2\" option, the router tries WPA2 first, but falls back to WPA if the client only supports WPA. The strongest cipher that the client supports will be used. With the \"WPA2 Only\" option, the router associates only with clients that also support WPA2 security. The AES cipher will be used in \"WPA or WPA2\" and \"WPA2 Only\" modes to ensure best security. Some gaming and legacy devices work only in \"WPA Only\" mode. TKIP is the cipher for \"WPA only\" mode.", //help375
	"This web site address '%s' is invalid.", //GW_WEB_FILTER_WEBSITE_INVALID_INVALID
	"Week", //ZM21
	"Internet Sessions", //YM157
	"The WCN ActiveX Control provides the WCN link between your PC and the router via the browser that communicates wireless configuration data without a USB flash drive. The browser will attempt to download the WCN ActiveX Control, if it is not already available on your PC. For this action to succeed, you must already have a WAN connection, and the browser's internet security setting must be Medium or lower (select Tools &rarr; Internet Options &rarr; Security &rarr; Custom Level &rarr; Medium).", //help213
	"Are you sure you want to enable/disable", //YM24
	"PBC (Push Button Configuration)", //wps_p3_3
	"If your wireless network is already set up with Wi-Fi Protected Setup, manual confguration of the wireless network will destroy the existing wireless network.", //LW43
	"This section is where you define QoS Engine Rules.", //help99_s
	"Invalid Reservation MAC address", //YM90
	"TKIP and AES", //bws_CT_3
	"Note that, if you enter fewer characters in the WEP key than required, the remainder of the key is automatically padded with zeros.", //help371_n
	"<warn>A DHCP Reservation %v has been reconfigured to %v, please check this meets your network requirements.</warn>", //GW_DHCP_SERVER_RESERVATION_RECONFIG_WARNING
	"Invalid Gateway for route", //_r_alert3
	"RIP metric is invalid.", //GW_LAN_RIP_METRIC_INVALID
	"WPA Group Key Update Interval should be between 30 and 65535 seconds.", //YM118
	"Invalid Gateway Address", //YM127
	"StreamEngine", //KR71
	"WDS Enable", //aw_WDSEn
	"Received Unknown Message", //KR32
	"Local", //sa_Local
	"Idle time cannot be zero.", //GW_WEB_SERVER_IDLE_TIME
	"This option controls how the device reacts to traffic on the WAN connector.", //KR59
	"WAN Gateway IP address %v must be within the WAN subnet.", //GW_WAN_WAN_GATEWAY_IN_SUBNET_INVALID
	"Local IP Range", //at_LoIPR
	"Voice (VO)", //YM81
	"Aggregation Num Packets", //aw_AP
	"This area of the screen reflects configuration settings from the <a href=\"wireless.asp\">Setup &rarr; Wireless Settings</a> page and the <a href=\"adv_wish.asp\">Advanced &rarr; WISH</a> page. The <span class=\"option\">MAC Address</span> is the factory-assigned identifier of the wireless card.", //LT290
	"The priority given to packets sent wirelessly over this conversation by the WISH logic. The priorities are:", //YM162
	"Configuration file parse error (MIME)", //GW_XML_CONFIG_SET_PARSE_MIME
	"UDP Port", //GW_NAT_UDP_PORT
	"Succeeded", //YM9
	"The MTU size is invalid (the permitted range is %u to %u)", //GW_WAN_MTU_INVALID
	"There are several ways to add a wireless device to your network. Access to the wireless network is controlled by a “registrar”. A registrar only allows devices onto the wireless network if you have entered the PIN, or pressed a special Wi-Fi Protected Setup button on the device. The router acts as a registrar for the network, although other devices may act as a registrar as well.", //LW63
	"Successfully added station %s (%m)", //WIFISC_IR_REGISTRATION_SUCCESS
	"The IP address of packets that will take this route.", //help105
	"The DHCP server address %v was released by the network device - the network device no longer wants to use it.", //GW_DHCPSERVER_RELEASED
	"Launch Printer Setup Wizard", //LW32
	"SetAPSettings by (%s) failed, reason (%s), err_code (%u)", //WIFISC_AP_SET_APSETTINGS_FAIL
	"Invalid IP address for route", //KR8
	"The name field allows you to specify a name for identification of this route, e.g. \"Network 2\"", //hhav_r_name
	"Hybrid (Point-to-Point then Broadcast)", //bd_NETBIOS_REG_TYPE_H
	"While not a perfect mapping, the following loose correspondences between the \"cone\" classification and the \"endpoint filtering\" modes can be drawn: if this router is configured for endpoint independent filtering, it implements full cone behavior; address restricted filtering implements restricted cone behavior; and port and address restricted filtering implements port restricted cone behavior.", //KR55
	"PPPoE IP address %v conflicts with LAN subnet", //GW_WAN_PPPOE_LAN_SUBNET_CONFLICT_INVALID
	"Successfully imported configuration file", //GW_XML_CONFIG_SET_SUCCESS
	"Local end port should be between 0 and 65535 inclusive.", //YM60
	"Save Settings Failed", //KR100
	"Select this option if the WAN port is connected to the Internet. The device functions as a NAT router.", //KR61
	"64 bit (10 hex digits)", //bws_WKL_0
	"Use <strong>WPA or WPA2</strong> mode to achieve a balance of strong security and best compatibility. This mode uses WPA for legacy clients while maintaining higher security with stations that are WPA2 capable. Also the strongest cipher that the client supports will be used. For best security, use <strong>WPA2 Only</strong> mode. This mode uses AES(CCMP) cipher and legacy stations are not allowed access with WPA security. For maximum compatibility, use <strong>WPA Only</strong>. This mode uses TKIP cipher. Some gaming and legacy devices work only in this mode.", //bws_msg_WPA
	"Invalid L2TP IP address", //YM109
	"Reset by %s failed, reason (%s), err_code (%u)", //WIFISC_AP_RESET_FAIL
	"'%s': Host 2 port start, %u, must be less than host 2 port end, %u", //GW_WISH_RULES_HOST2_PORT
	"Load Settings From Local Hard Drive", //help_ts_ls
	"Invalid WAN gateway IP address", //YM101
	"Auto", //KR50
	"Protocol must be a number.", //YM56
	"Website URL/Domain", //aa_WebSite_Domain
	"Max transmission rate should be between 8 kbps and 100 Mbps, inclusive.", //GW_QOS_RULES_MAX_TRANS
	"'%s': Protocol, %d, needs to be between 0 and 257", //GW_QOS_RULES_PROTOCOL
	"You must have at least one of HTTP or HTTPS enabled.", //GW_WEB_SERVER_NO_ACCESS
	"Configure the IP address of the backup WINS server, if any.", //KR87
	"%s' is duplicate of '%s'", //GW_WISH_RULES_DUPLICATED
	"Destination IP Start address should not be in LAN subnet", //YM16
	"Name '%s' is already used", //GW_SCHEDULES_NAME_CONFLICT_INVALID
	"WEP Key 4", //wepkey4
	"HTTP and HTTPS cannot occupy the same WAN port.", //GW_WEB_SERVER_SAME_PORT_WAN
	"invalid source ending IP Address.", //YM65
	"Network Settings", //bln_title
	"STA with MAC (%m) failed to register in, reason (%s), err_code (%u)", //WIFISC_AP_PROXY_PROCESS_FAIL
	"More", //_more
	"Send/Receive login", //ZM12
	"Banner Ad", //_aa_bsecure_banner_ad
	"Wireless Status", //LY23
	"For most applications, automatic classification will be adequate, and specific QoS Engine Rules will not be required.", //help88b
	"Selecting more than one spatial stream can increase throughput, but can in some cases decrease signal quality.", //bwl_NSS_h1
	"Note: Do not connect more than one USB flash drive to the router, not even with a USB hub.", //help203
	"There is no machine defined in policy %s.", //GW_INET_ACL_NO_MACHINE_IN_LAN_SUBNET_INVALID
	"Before launching these wizards, please make sure you have followed all steps outlined in the Quick Installation Guide included in the package.", //LW39c
	"Set Selected Registrar complete", //WIFISC_AP_SET_SELECTED_REGISTRAR_COMPLETE
	"Invalid DHCP Client name", //GW_DHCP_CLIENT_CLIENT_NAME_INVALID
	"Failed to retrieve active session list. Retrying", //YM166
	"Reboot by %s fail, reason (%s), err_code (%u)", //WIFISC_AP_REBOOT_FAIL
	"The priority of the message flow is entered here -- 1 receives the highest priority (most urgent) and 255 receives the lowest priority (least urgent).", //help91
	"The following Web-based wizards are designed to assist you in your wireless network setup and wireless device connection.", //LW39
	"Password and Verify Password do not match. Please reconfirm admin password.", //YM173
	"A Port Filter rule name cannot be blank.", //YM13
	"Your web browser is too old to use this web site. Please upgrade your browser.", //YM172
	"Invalid TPC Max Gain", //YM31
	"Select the Sentinel categories to filter.", //_aa_wiz_s6_msg
	"Password can only contain printable characters.", //S493
	"Host 2 Port Range", //YM85
	"The 'Name' field can not be blank", //GW_SCHEDULES_NAME_INVALID
	"Invalid Gateway", //LS204
	"16 Kbytes", //aw_16
	"(Refer to the <a href=\"wireless.asp\"> Setup &rarr; Wireless Settings &rarr; Manual Wireless Network Setup</a> page.)", //aw_erpe_h3
	"Start the wizard.", //LW64
	"Day(s)", //_days
	"Specifies whether the entry will be enabled or disabled.", //help103
	"-", //YM183
	"Invalid Group Key Update Interval.", //YM117
	"Formerly, the terms \"Full Cone\", \"Restricted Cone\", \"Port Restricted Cone\" and \"Symmetric\" were used to refer to different variations of NATs. These terms are purposely not used here, because they do not fully describe the behavior of this router's NAT.", //KR54
	"This Routing page allows you to specify custom routes that determine how data is moved around your network.", //av_intro_r
	"64-bit hexadecimal keys are exactly 10 characters in length. (12345678FA is a valid string of 10 characters for 64-bit encryption.)", //help368
	"Each route has a check box next to it, check this box if you want the route to be enabled.", //hhav_enable
	"DNS Servers must be configured.", //GW_WAN_DNS_SERVERS_INVALID
	"Restore Succeeded", //_rs_succeeded
	"A PPTP user name MUST be specified", //GW_WAN_PPTP_USERNAME_INVALID
	"Invalid L2TP IP address: %v", //GW_WAN_L2TP_IP_ADDRESS_INVALID
	"Name can not be empty string.", //GW_INET_ACL_NAME_INVALID
	"Days", //days
	"This is an advanced setting and is normally left blank. This allows the configuration of a NetBIOS \"domain\" name under which network hosts operate.", //KR88
	"Invalid PPPoE IP address: %v", //GW_WAN_PPPOE_IP_ADDRESS_INVALID
	"For good security it should be of ample length and should not be a commonly known phrase.", //KR19
	"Rate estimation completed. Upstream speed is %u kbps", //RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED
	"Invalid Beacon Period", //YM27
	"This area of the screen reflects configuration settings from the <a href=\"wireless.asp\">Setup &rarr; Wireless Settings</a> page and the <a href=\"../Advanced/Protected_Setup.shtml\">Advanced &rarr; Wi-Fi Protected Setup</a> page. The <span class=\"option\">MAC Address</span> is the factory-assigned identifier of the wireless card.", //LT291wifisc
	"Port Filter name", //KR1
	"Rule \'", //YM51
	"Send/Receive heartbeat", //ZM13
	"Primary DNS is invalid.", //GW_LAN_PRIMARY_DNS_INVALID
	"Can not use Turbo in 11a mode.", //GW_WLAN_11A_DFS_TURBO_INVALID
	"Changing your Wireless Network Name is the first step in securing your wireless network. Change it to a familiar name that does not contain any personal information.", //YM123
	"If you have devices on your network that should always have fixed IP addresses, add a <strong>DHCP Reservation </strong> for each such device.", //TA8
	"Invalid IP address for virtual server", //KR9
	"For example, 192.168.0.1.", //KR79
	"'%s': Remote IP start, '%v' ,must be less than remote IP end, '%v'", //GW_QOS_RULES_REMOTE_IP
	"Adult (18+)", //_aa_bsecure_age_adult
	"Uninitalized", //ZM7
	"Destination Port Start should not be greater than Destination Port End for Port Filter", //YM23
	"Note: Some firmware upgrades reset the router's configuration options to the factory defaults.\n Before performing an upgrade, be sure to save the current configuration from the Tools-System screen.\n Do you still want to upgrade?", //tf_USSW
	"Enable the Wi-Fi Protected Setup feature.", //LW55
	"Enable Wireless", //bwl_EW
	"Expires", //LS425
	"Wep Key", //wwl_WK
	"Generate New PIN", //LW11
	"<warn>The PPTP ALG has been automatically enabled because a virtual server entry you created requires it.</warn>", //GW_NAT_PPTP_ALG_ACTIVATED_WARNING
	"Are you sure you want to delete", //YM35
	"Select Day(s)", //tsc_sel_days
	"The router must be rebooted before the restored settings will take effect. You can reboot now, or you can continue to make other changes and reboot later.", //sc_intro_rb4
	"Invalid Time for schedule name: '%s'", //GW_SCHEDULES_TIME_INVALID
	"Lease time is invalid (must be 1 to 65535)", //GW_DHCP_SERVER_LEASE_TIME_INVALID
	"Unable to send email since server IP address could not resolved", //IPSMTPCLIENT_NO_SERVER_IP_ADDRESS
	"Private port should be in range (1..65535) for virtual server", //KR10
	"https is not a supported protocol.", //GW_WEB_FILTER_HTTPS_NOT_SUPPORTED_INVALID
	"The Wireless Device PIN should be either 4 or 8 digits", //KR22
	"Both", //_vs_both
	"The Wireless Security Password must be at least 8 characters.", //wwl_alert_pv5_4
	"AP should not be locked before configuring.", //GW_WIFISC_LOCK_VERIFY_ERR
	"Wireless frames can be divided into smaller units (fragments) to improve performance in the presence of RF interference and at the limits of RF coverage.", //LW53
	"The web site address '%s' already used.", //GW_WEB_FILTER_WEB_SITE_IS_USED_INVALID
	"invalid source starting IP Address.", //YM64
	"Route interface is invalid", //GW_ROUTES_INTERFACE_INVALID
	"Secondary DNS is invalid.", //GW_LAN_SECONDARY_DNS_INVALID
	"Learn NetBIOS from WAN", //bd_NETBIOS_LEARN_FROM_WAN_ENABLE
	"<warn>Port Forwarding Table is being reconfigured because the LAN subnet has been changed.</warn>", //GW_NAT_PORT_FORWARDING_TABLE_RECONFIGURED_WARNING
	"802.11 Band", //KR15
	"AP failed to registere to Registrar (%s) through %s, unexpected (%s), at state (%s)", //WIFISC_AP_REGISTRATION_UNEXPECTED_EVENT
	"<warn>Syslog server IP address is no longer in the LAN subnet, this may need to be reconfigured.</warn>", //GW_SYSLOG_ADDRESS_NOT_IN_SUBNET_WARNING
	"Invalid secondary WINS IP address", //GW_DHCP_SERVER_NETBIOS_SECONDARY_WINS_INVALID
	"Note that this feature does not apply to the DMZ host (if one is enabled). The DMZ host always handles these kinds of sessions.", //LW49
	"Add/Update Schedule Rule", //KR95
	"8 Kbytes", //aw_8
	"Invalid secondary DNS server IP address", //YM114
	"Cipher Type", //bws_CT
	"R-rated", //_aa_bsecure_rrated
	"Lock Wireless Security Settings", //LW6
	"You may also enter any text string into a WEP key box, in which case it will be converted into a hexadecimal key using the ASCII values of the characters. A maximum of 5 text characters can be entered for 64 bit keys, and a maximum of 13 characters for 128 bit keys.", //bws_msg_WEP_2
	"'%s': Local IP start, '%v', must be less than local IP end, '%v'", //GW_QOS_RULES_LOCAL_IP
	"Pool IP address FROM must not be bigger than TO.", //GW_DHCP_SERVER_POOL_FROM_TO_ORIENTATION_INVALID
	"TKIP", //bws_CT_1
	"Configuration database lock failed #%u", //GW_XML_CONFIG_SET_LOCK
	"Reserved IP %v conflicts with another reservation", //GW_DHCP_SERVER_RESERVED_IP_UNIQUENESS_INVALID
	"WEP Key 2", //wepkey2
	"Manual Internet Connection Options", //LW28
	"WEP Key 1", //_wepkey1
	"Turn this setting off to configure manually.", //KR83
	"Syslog server IP address is invalid.", //GW_SYSLOG_ADDRESS_INVALID
	"Invalid PPTP IP address", //YM105
	"DHCP Client", //ZM5
	"WCN ActiveX Control", //help212
	"please press the push button on your wireless device and click the below 'Connect' Button within 120 seconds", //wps_p3_5
	"To specify any other protocol, select \"Other\" from the list, then enter the corresponding protocol number (<a href='http://www.iana.org/assignments/protocol-numbers' target='_blank'> as assigned by the IANA</a>) in the <span class='option'>Protocol</span> box.", //help19x2
	"Step 2: Connect your Wireless Device", //KR36
	"Route metric %u is invalid, must be from 1 to 16", //GW_ROUTES_METRIC_INVALID
	"The SSID field can not be blank.", //GW_WLAN_SSID_INVALID
	"Invalid IP Address", //LS46
	"The timeout value cannot be less than or equal to zero.", //YM179
	"The IP address of the router on the local area network. For example, 192.168.0.1.", //KR78
	"The bridge checks the support site for updates by way of the upstream router.", //KR66
	"Magazine", //_aa_bsecure_magazine
	"The device may be too busy to properly receive it right now. Please try to save the settings again.", //KR101
	"WPA only mode doesn't support AES.", //GW_WLAN_WPA_WPA_AES_INVALID
	"Inbound Filter", //GW_NAT_INBOUND_FILTER
	"The Policy Name cannot be blank.", //GW_INET_ACL_POLICY_NAME_INVALID
	"Internet", //sa_Internet
	"Peer-to-Peer network between wireless clients", //help406
	"The rule applies to a flow of messages for which host 1's port number is within the range set here.", //YM153
	"Remote IP Range", //at_ReIPR
	"One or more Internet access policies are in effect. Internet access will be restricted according to these policies", //GW_INET_ACCESS_RESTRICTED
	"DTIM should be between 1 and 255.", //GW_WLAN_DTIM_INVALID
	"A WISH Rule identifies a specific message flow and assigns a priority to that flow.", //YM144
	"(GMT+01:00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna", //up_tz_26
	"Select a filter that controls access as needed for this rule. If you do not see the filter you need in the list of filters, go to the <a href=\"Inbound_Filter.asp\"> Advanced &rarr; Inbound&nbsp;Filter</a> screen and create a new filter.", //help71
	"HNAP AddPortMapping modified %dth virtual server entry from '%s' %v%d<->%v%d %S to '%s' %v%d<->%v%d %S", //GW_PURE_ADDPORTMAPPING_MODIFY
	"User stopped", //tsc_pingt_msg10
	"The printer's IP address and TCP port number are shown <a href=\"../Status/PS.shtml\" onclick=\"return jump_if();\">here</a>.", //tps_foo
	"HNAP AddPortMapping modified %dth virtual server entry from '%s' %v%d<->%v%d %S to %S", //GW_PURE_ADDPORTMAPPING_CHG_PROTOCOL
	"Above message repeated %d times", //LOG_PREV_MSG_REPEATED_N_TIMES
	"The <strong>user</strong> account may not perform the requested action.", //ca_intro
	"The addressing of the Internet side learnt thru DHCP conflicts with the addressing selected for the LAN side. Internet communications will be disabled until you have changed the LAN side addressing to resolve the problem.", //GW_WAN_LAN_ADDRESS_CONFLICT_DHCP
	"The section lists the current Inbound Filter Rules. An Inbound Filter Rule can be changed by clicking the Edit icon, or deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Update Inbound Filter Rule\" section is activated for editing.", //help176
	"HNAP AddPortMapping created %dth virtual server entry '%s' %v%d<->%v%d %S", //GW_PURE_ADDPORTMAPPING_CREATE
	"Select a schedule for when the rule will be enabled. If you do not see the schedule you need in the list of schedules, go to the <a href=\"tools_schedules.asp\" onclick=\"return jump_if();\">Tools → Schedules</a> screen and create a new schedule.", //hhag_30
	"Click the <strong>Add</strong> or <strong>Update</strong> button to store a finished rule in the Rules List below.", //hhai_save
	"Administrator", //ADMIN
	"The following printer has been detected.&nbsp; Click <i>Next</i>&nbsp; to install the printer onto your computer.", //wprn_s1a
	"Email notification is not enabled.", //sl_alert_3
	"After configuring the router for dynamic DNS, you can open a browser and navigate to the URL for your domain (for example <code>http://www.mydomain.info</code>) and the router will attempt to forward the request to port 80 on your LAN. If, however, you do this from a LAN-side computer and there is no virtual server defined for port 80, the router will return the router's configuration home page. Refer to the <a href='adv_virtual.asp'>Advanced &rarr; Virtual&nbsp;Server</a> configuration page to set up a virtual server.", //help900
	"The printer's IP address and queue name are shown <a href=\"../Status/PS.shtml\" onclick=\"return jump_if();\">here</a>.", //tps_foo2
	"This setting should remain at its default value of 2346 bytes.", //help182
	" -- IP Address should be in LAN subnet.", //aa_alert_12
	"To check for the latest firmware, click the [Check Online Now...] button. If you would like to be notified when new firmware is released, place a checkmark in the box next to Email Notification of Newer Firmware Version.", //tf_intro_FWCh
	"Save To Local Hard Drive", //ts_ss
	"Set Username and Password Connection (PPTP)", //wwa_title_set_pptp
	"(e.g. myhost.mydomain.net)", //_hostname_eg
	"Note: You will need to enter the same password as keys in this step into your wireless clients in order to enable proper wireless communication.", //wwl_s4_note
	"Select a filter that controls access as needed for this virtual server. If you do not see the filter you need in the list of filters, go to the <a href=\"Inbound_Filter.asp\"> Advanced &rarr; Inbound&nbsp;Filter</a> screen and create a new filter.", //help22
	"The Wireless Security Password must be at least 13 characters or 26 hex digits. You entered", //wwl_alert_pv5_1
	"HNAP SetWLanSettings24 set Enabled %s, SSIDBroadcast %s, Channel %d", //GW_PURE_SETWLANSETTINGS24
	"Specify the LAN IP address of the LAN computer that you want to have unrestricted Internet communication. If this computer obtains its address Automatically using DHCP, then you may want to make a static reservation on the <a href=\"adv_network.asp\">Setup &rarr; Network&nbsp;Settings</a> page so that the IP address of the DMZ computer does not change.", //help167
	"Detected xDSL or Other Frame Relay Network", //at_DxDSL
	"The Printer Setup Wizard supports only Windows XP/2000/98/ME operating systems. Your computer uses the <span id=\"wz_page_1_err_1_os\">&nbsp;</span> operating system.", //wprn_bados2
	"The setup executable you have just launched will display a progress bar and notify you when setup is complete. When done, click <em>Finish</em> below to close the Printer Setup wizard.", //wprn_s3a
	"If the setup executable did not launch automatically after downloading to your computer, you may need to open the file-download folder using a file browser and double-click on the icon labeled <em>Printer_Setup.exe.</em>", //wprn_tt10
	"WAN Ping <a href=\"Inbound_Filter.asp\" onclick=\"return jump_if();\">Inbound Filter</a>", //bwn_IF
	"Note, however, if the AP's settings specify \"DHCP (Dynamic)\" Address, and the <span>router</span>'s DHCP server assigns a domain name to the AP, that domain name will override any name you enter here.", //_1044a
	"Attempt to fix the problem with the printer, then click <i>Refresh</i>&nbsp; to update printer status.", //wprn_tt6
	"Select a schedule for the times when this rule is in effect. If you do not see the schedule you need in the list of schedules, go to the <a href=\"tools_schedules.asp\"> Tools &rarr; Schedules</a> screen and create a new schedule.", //help72
	"Unknown", //_sdi_s6
	"Select a schedule for when the service will be enabled. If you do not see the schedule you need in the list of schedules, go to the <a href=\"tools_schedules.asp\" onclick=\"return jump_if();\">Tools → Schedules</a> screen and create a new schedule.", //hhpt_sch
	"Enable Raw Port Printing", //tps_enraw
	"This log will be sent to email address", //sl_alert_2
	"Auto 10/100/1000Mbps", //anet_wp_2
	"Restore all Settings to the Factory Defaults", //tss_RestAll
	"HNAP SetDeviceSettings set wan mode to %S, %v/%v/%v", //GW_PURE_SETWANSETTINGS
	"Select a schedule for when this rule is in effect. If you do not see the schedule you need in the list of schedules, go to the <a href=\"tools_schedules.asp\"> Tools &rarr; Schedules</a> screen and create a new schedule.", //help53
	"Saves the new or edited Inbound Filter Rule in the following list.", //help175
	"If you selected the On Schedule option, select one of the defined schedule rules. If you do not see the schedule you need in the list of schedules, go to the <a href='tools_schedules.asp'>Tools&nbsp;&rarr;&nbsp;Schedules</a> screen and create a new schedule.", //help872
	"The transmission standard being used by the client. Values are 11a, 11b, 11g, or 11n for 802.11a, 802.11b, 802.11g, or 802.11n respectively.", //help785
	"After clicking <i>Next</i>, you will be asked for permission to download an executable file. Please click <i>Run/Open</i>&nbsp; to allow the executable to run on your computer. If a second window appears prompting you to verify the publisher, please click <i>Run</i>&nbsp; again.", //wprn_s2b
	"The wizard will guide you through the following steps. Click <em>Next</em> to begin.", //wprn_intro2
	"Please select a filter.", //GW_INET_ACL_NO_FILTER_SELECTED_INVALID
	"When this option is enabled, an email will be sent to the email address configured in the email section whenever new firmware is available. You must have Email Notification enabled from the <a href=\"tools_email.asp\">Tools &rarr; Email&nbsp;Settings</a> page.", //help890
	"The IP address and, where appropriate, port number of the local application.", //help814
	"Time interval the machine can be idle before the PPTP connection is disconnected. The Maximum Idle Time value is only used for the \"On demand\" and \"Manual\" reconnect modes.", //help283
	"This printing protocol is currently disabled. You can enable it <a href='../Tools/PS.shtml' onclick='return jump_if();'>here</a>.", //sps_protdis
	"Select a filter that controls access as needed for this admin port. If you do not see the filter you need in the list of filters, go to the <a href=\"Inbound_Filter.asp\" onclick=\"return jump_if();\">Advanced &rarr; Inbound&nbsp;Filter</a> screen and create a new filter.", //help831
	"Insufficient Permissions", //_cantapplysettings
	"Allows H.323 (specifically Microsoft Netmeeting) clients to communicate across NAT. Note that if you want your buddies to call you, you should also set up a virtual server for NetMeeting. Refer to the <a href='adv_virtual.asp'> Advanced&nbsp;&rarr;&nbsp;Virtual&nbsp;Server</a> page for information on how to set up a virtual server.", //help39
	"WCN configuration aborted due to %s", //WCN_LOG_ABORT
	"(GMT+13:00) Nuku'alofa, Tonga", //up_tz_73
	"The Web sites listed here are used when the Web Filter option is enabled in <a href='adv_access_control.asp'>Access Control</a>.", //help141_a
	"The Firewall Settings allows you to set a single computer on your network outside of the router.", //af_intro_x
	"Add/Update Inbound Filter Rule", //help170
	"To use the shared printer from this computer, launch the Printer Wizard from the <a href=\"../Basic/Wizard.shtml\" onclick=\"return jump_if();\"> <i>Wizard </i> page</a>.", //tps_intro4
	"Or you may enter a dynamic DNS service provider manually.", //help893b
	"Starting DHCP server", //GW_DHCPSERVER_START
	"Some firmware upgrades reset the configuration options to the factory defaults. Before performing an upgrade, be sure to save the current configuration from the <a href=\"tools_system.asp\">Tools &rarr; System</a> screen.", //help887
	"Allows FTP clients and servers to transfer data across NAT. Refer to the <a href='adv_virtual.asp'>Advanced&nbsp;&rarr;&nbsp;Virtual&nbsp;Server</a> page if you want to host an FTP server.", //help38
	"SPI (\"stateful packet inspection\" also known as \"dynamic packet filtering\") helps to prevent cyberattacks by tracking more state per session. It validates that the traffic passing through that session conforms to the protocol.", //help164
	"Select a filter that restricts the Internet hosts that can access this virtual server to hosts that you trust. If you do not see the filter you need in the list of filters, go to the <a href=\"Inbound_Filter.asp\" onclick=\"return jump_if();\"> Advanced &rarr; Inbound&nbsp;Filter</a> screen and create a new filter.", //hhav_filt
	"HNAP AddPortMapping '%s' %v%d<->%v%d %S conflict with %dth virtual server entry '%s' %v%d<->%v%d %S", //GW_PURE_ADDPORTMAPPING_CONFLICT
	"HNAP SetRouterLanSettings set RouterIPAddress %v, RouterSubnetMask %v, DHCPServerEnabled %s", //GW_PURE_SETROUTERLANSETTINGS
	"HNAP setWLanSecurity set Enabled %s, Type %s", //GW_PURE_SETWLANSECURITY
	"The Policy Name cannot be blank.", //aa_alert_9
	"Time interval the machine can be idle before the L2TP connection is disconnected. The Maximum Idle Time value is used for the \"On demand\" and \"Manual\" reconnect modes.", //help287
	"Remote Admin <a href=\"Inbound_Filter.asp\" onclick=\"return jump_if();\">Inbound Filter</a>", //ta_RAIF
	"This setting should remain at its default value of 2346 bytes.", //help180
	"HNAP SetDeviceSettings changed DeviceName to '%s'", //GW_PURE_SETDEVICESETTINGS
	"Signal(%)", //_rssi
	"This wizard will guide you through a step-by-step process to setup your wireless network and make it secure.", //wwl_intro_wel
	"Click here to access firmware online.", //tf_ClickDL
	"DMZ means \"Demilitarized Zone.\" If an application has trouble working from behind the router, you can expose one computer to the Internet and run the application on that computer.", //help165
	"Other", //_vs_other
	"To use the shared printer from this computer, follow the setup instructions found in <a href='../Help/Basic.shtml#PS' onclick='return jump_if();' style='white-spacenowrap;'>Help -> Home -> Printer Wizard</a>.", //tps_intro5
	"The uploaded firmware file may not be correct. You may have uploaded a file that is not intended for this device, or the uploaded file may be corrupted.", //ub_intro_1
	"Time interval the machine can be idle before the PPPoE connection is disconnected. The Maximum Idle Time value is only used for the \"On demand\" and \"Manual\" reconnect modes.", //help277
	"This feature enables forwarding of \"magic packets\" (that is, specially formatted wake-up packets) from the WAN to a LAN computer or other device that is \"Wake on LAN\" (WOL) capable. The WOL device must be defined as such on the <a href='adv_virtual.asp'> Advanced&nbsp;&rarr;&nbsp;Virtual&nbsp;Server</a> page. The LAN IP address for the virtual server is typically set to the broadcast address 192.168.0.255. The computer on the LAN whose MAC address is contained in the magic packet will be awakened.", //help41
	"Virtual Server", //VIRTUAL_SERVERS
	"Select a schedule for when the virtual server will be enabled. If you do not see the schedule you need in the list of schedules, go to the <a href=\"tools_schedules.asp\" onclick=\"return jump_if();\">Tools &rarr; Schedules</a> screen and create a new schedule.", //hhav_sch
	"Restore To Factory Default Settings", //ts_rfd
	"When the PPTP ALG is enabled, LAN computers can establish PPTP VPN connections either with the same or with different VPN servers. When the PPTP ALG is disabled, the router allows VPN operation in a restricted way 。 LAN computers are typically able to establish VPN tunnels to different VPN Internet servers but not to the same server. The advantage of disabling the PPTP ALG is to increase VPN performance. Enabling the PPTP ALG also allows incoming VPN connections to a LAN side VPN server (refer to <a href=\"adv_virtual.asp\">Advanced &rarr; Virtual Server</a>).", //help33b
	"Load From Local Hard Drive", //ts_ls
	"HNAP DeletePortMapping %s%d modified %dth virtual server entry '%s' %v%d<->%v%d %S to %S", //GW_PURE_DELETEPORTMAPPING_MODIFY
	"After clicking <i>Next</i>, you will be asked for permission to download an executable file. Please click \"OK\" to download the the file.<br /><br /> To launch the executable, you may need to open the file-download folder using a file browser and double-click on the icon labeled <i>Printer_Setup.exe</i>.", //wprn_s2c
	"It is possible for a computer or device that is manually configured to have an address that does reside within this range. In this case the address should be reserved (see <a href=\"#Static_DHCP\">DHCP Reservation</a> below), so that the DHCP Server knows that this specific address can only be used by a specific computer or device.", //help320
	"The Internet Sessions page displays full details of active Internet sessions through your router. An Internet session is a conversation between a program or application on a LAN-side computer and a program or application on a WAN-side computer.", //help813
	"Select a dynamic DNS service provider from the pull-down list, or you may enter a dynamic DNS service provider manually.", //help893
	"Select this option to save the router log to a file on your computer.", //help803
	"To check for the latest firmware, click the <span class='button_ref'>Check Online Now</span> button. If you would like to be notified when new firmware is released, place a checkmark in the box next to <span class='option'>Email Notification of Newer Firmware Version</span>.", //help877
	"(GMT+01:00) Belgrade, Brastislava, Ljubljana", //up_tz_27
	"With the above example values filled in and this Port Forwarding Rule enabled, all TCP and UDP traffic on ports 6159 through 6180 and port 99 is passed through the router and redirected to the Internal Private IP Address of your Game Server at 192.168.0.50.", //help74
	"When \"OFF\" is selected, MAC addresses are not used to control network access. When \"ALLOW\" is selected, only computers with MAC addresses listed in the MAC Address List are granted network access. When \"DENY\" is selected, any computer with a MAC address listed in the MAC Address List is refused access to the network.", //help155_2
	"Established: Rate Estimating", //_sdi_s4
	"Miscellaneous", //MISC
	"Note: Now uploading. The upload may take up to 1 minute.", //tf_msg_Upping
	"Failure sending log email - try again in %d minutes", //GW_LOG_EMAIL_FAILED
	"Established or closing TCP connections.", //help823_17
	"Enable SSID", //IPV6_TEXT4
	"This page displays the full details of active sessions to your router.", //sa_intro
	"Rebooting will disconnect any active internet sessions.", //up_rb_2
	"Select a schedule for when the service will be enabled. If you do not see the schedule you need in the list of schedules, go to the <a href=\"tools_schedules.asp\"> Tools &rarr; Schedules</a> screen and create a new schedule.", //help23
	"If IGMP is enabled, this area of the screen shows all multicast groups of which any LAN devices are members.", //_bln_title_IGMPMemberships_h
	"See also <a href=\"adv_virtual.asp\"> Advanced &rarr; Virtual&nbsp;Server</a>, <a href=\"adv_portforward.asp\">Advanced &rarr; Port&nbsp;Forwarding</a>, <a href=\"adv_appl.asp\"> Advanced &rarr; Application&nbsp;Rules</a>, and <a href=\"adv_network.asp\">Advanced &rarr; Network (UPnP)</a> for related options.", //haf_intro_2
	"If you provided email information with the <a href='tools_email.asp'>Tools&nbsp;&rarr;&nbsp;Email</a> screen, clicking the <span class='button_ref'>Email Now</span> button sends the router log to the configured email address.", //help802
	"Click <i>Refresh</i>&nbsp; to try again.", //wprn_tt5
	"You can also have the log mailed to you periodically. Refer to <a href='tools_email.asp' onclick='return jump_if();'>Tools &rarr; EMail</a>.", //hhsl_lmail
	"Press the button below to continue configuring the router if the previous page doesn't restore in <span id=\"show_sec\"></span>&nbsp;seconds.", //ap_intro_noreboot
	"(GMT+01:00) Sarajevo, Skopje, Sofija, Vilnus, Warsaw, Zagreb", //up_tz_29
	"HNAP SetMACFilters2", //GW_PURE_SETMACFILTERS2
	"HNAP Reboot", //GW_PURE_REBOOT
	"If you changed the IP address of the router you will need to change the IP address in your browser before accessing the configuration website again.", //rb_change
	"The IP address and, where appropriate, port number of the application on the Internet.", //help816
	"HNAP DeletePortMapping %s%d deleted %dth virtual server entry '%s' %v%d<->%v%d %S", //GW_PURE_DELETEPORTMAPPING_DELETE
	"If the uploaded file is correct, it is possible that the device may be too busy to properly receive it right now. In this case, please try the upload again. It is also possible that you are logged in as a 'user' instead of an 'admin' - only administrators can upload new firmware.", //ub_intro_3
	"Requests may be redirected to the \"Forbidden\" page if web access for the LAN machine is restricted by an Access Control Rule. Add the WAN-side identity (WAN-side IP-address of the router or its dynamic DNS name) on the <a href='adv_filters_url.asp'> Advanced&nbsp;&rarr;&nbsp;Web&nbsp;Filter</a> screen to work around this problem.", //help30
	"Invalid LAN IP Address", //bln_alert_2
	"Use with <a href='adv_access_control.asp' onclick='return jump_if();'>Access Control</a>.", //hhwf_xref
	"Gateway remote administration enabled on port: %u", //GW_REMOTE_ADMINSTRATION
	"You have selected your security level - you will need to set a wireless security password.", //wwl_s4_intro
	"Security Mode", //sd_SecTyp
	"WAN IPv6 ADDRESS SETTINGS", //IPV6_WAN_IP
	"IPv6 Address", //IPV6_TEXT0
	"Please accept and install the ActiveX, then try it again.", //gw_wcn_alert_3
	"Invalid Network Key!", //IPV6_TEXT2
	"Enable Routing Between Zones", //S473
	"Enable SPI", //af_ES
	"This selection helps you to define the Guest Zone scale.", //IPV6_TEXT5
	"Specifies whether the Guest Zone will be enabled or disabled.", //IPV6_TEXT6
	"Provide a name for Guest Zone wireless network.", //IPV6_TEXT7
	"Use this section to enable routing between Host Zone and Guest Zone, Guest clients cannot access Host clients' data without enabling this function.", //IPV6_TEXT8
	"Securing your wireless network is important as it is used to protect the integrity of the information being transmitted. The router is capable of 4 types of wireless security; WEP, WPA only, WPA2 only, and WPA/WPA2 (auto-detect).", //IPV6_TEXT9
	"Wired Equivalent Protocol (WEP) is a wireless security protocol for Wireless Local Area Networks (WLAN). WEP provides security by encrypting the data that is sent over the WLAN. The router supports 2 levels of WEP Encryption: 64-bit and 128-bit. WEP is disabled by default. The WEP setting can be changed to suit an existing wireless network or to customize your wireless network.", //IPV6_TEXT10
	"Authentication is a process by which the router verifies the identity of a network device that is attempting to join the wireless network. There are two types of authentication for this device when using WEP.", //IPV6_TEXT11
	"Select this option to allow all wireless devices to communicate with the router without being required to provide the encryption key needed to gain access to the network.", //IPV6_TEXT12
	"Select this option if you require any wireless device attempting to communicate with the router to provide the encryption key needed to access the network before being allowed to communicate with the %m.", //IPV6_TEXT13
	"Select the level of WEP Encryption that you would like to use on your network. The two supported levels are 64-bit and 128-bit.", //IPV6_TEXT14
	"The Key Types that are supported by the %m are HEX (Hexadecimal) and ASCII (American Standard Code for Information Interchange.) The Key Type can be changed to suit an existing wireless network or to customize your wireless network.", //IPV6_TEXT15
	"Keys", //IPV6_TEXT16
	"Keys 1-4 allow you to easily change wireless encryption settings to maintain a secure network. Simply select the specific key to be used for encrypting the network wireless data.", //IPV6_TEXT17
	"Key Type", //IPV6_TEXT18
	"WEP Encryption", //IPV6_TEXT19
	"Wi-Fi Protected Access authorizes and authenticates users coming onto the wireless network. WPA uses stronger security than WEP and is based on a key that changes automatically at regular intervals.", //IPV6_TEXT20
	"%s supports two different cipher types when WPA is used as the Security Type. These two options are TKIP (Temporal Key Integrity Protocol) and AES (Advanced Encryption Standard).", //IPV6_TEXT21
	"PSK/EAP", //IPV6_TEXT22
	"When PSK is selected, your wireless clients will need to provide a Passphrase for authentication. When EAP is selected, you will need to have a RADIUS server on your network which will handle the authentication of all your wireless clients.", //IPV6_TEXT23
	"PARENTAL CONTROL", //DNS_TEXT0
	"This will be needed by your wireless clients in order to communicate with your %m, when PSK is selected. Enter 8 to 63 alphanumeric characters. Be sure to write this Passphrase down as you will need to enter it on any other wireless devices you are trying to add to your network.", //IPV6_TEXT25
	"This means of WPA authentication is used in conjunction with a RADIUS server that must be presented on your network. Enter the IP address, port, and Shared Secret used to configure the RADIUS. You also have the option to enter information for a second RADIUS server in the event that there are two on your network being used to authenticate wireless clients.", //IPV6_TEXT26
	"Wi-Fi Protected Access 2 authorizes and authenticates users onto the wireless network. WPA2 uses stronger security than WEP and is based on a key that changes automatically at regular intervals.", //IPV6_TEXT27
	"Use this section to configure your IPv6 Connection type. If you are unsure of your connection method, please contact your Internet Service Provider.", //IPV6_TEXT28
	"IPv6 CONNECTION TYPE", //IPV6_TEXT29
	"IPv6 Connection Type", //IPV6_TEXT29a
	"Choose the mode to be used by the router to the IPv6 Internet.", //IPV6_TEXT30
	"My IPv6 Connection is", //IPV6_TEXT31
	"Static IPv6", //IPV6_TEXT32
	"DHCPv6", //IPV6_TEXT33
	"PPPoE", //IPV6_TEXT34
	"IPv6 in IPv4 Tunnel", //IPV6_TEXT35
	"6to4", //IPV6_TEXT36
	"Local Connectivity Only", //IPV6_TEXT37
	"IPv6 in IPv4 TUNNEL SETTINGS", //IPV6_TEXT38
	"Enter the IPv6 in IPv4 Tunnel information provided by your Tunnel Broker.", //IPV6_TEXT39
	"Remote IPv4 Address", //IPV6_TEXT40
	"Remote IPv6 Address", //IPV6_TEXT41
	"Local IPv4 Address", //IPV6_TEXT42
	"Local IPv6 Address", //IPV6_TEXT43
	"LAN IPv6 ADDRESS SETTINGS", //IPV6_TEXT44
	"Use this section to configure the internal network settings of your router. If you change the LAN IPv6 Address here, you may need to adjust your PC network settings to access the network again.", //IPV6_TEXT45
	"LAN IPv6 Address", //IPV6_TEXT46
	"LAN IPv6 Link-Local Address", //IPV6_TEXT47
	"ADDRESS AUTOCONFIGURATION SETTINGS", //IPV6_TEXT48
	"Use this section to setup IPv6 Autoconfiguration to assign IPv6 addresses to the computers in your network. ", //IPV6_TEXT49
	"Enable Auto Channel Scan so that the router can select the best possible channel for your wireless network to operate on.", //TA11
	"Autoconfiguration Type", //IPV6_TEXT51
	"Stateless", //IPV6_TEXT52
	"Stateful (DHCPv6)", //IPV6_TEXT53
	"IPv6 Address Range (Start)", //IPV6_TEXT54
	"IPv6 Address Range (End)", //IPV6_TEXT55
	"IPv6 Address Lifetime", //IPV6_TEXT56
	"Router Advertisement Lifetime", //IPV6_TEXT57
	"When configuring the router to access the IPv6 Internet, be sure to choose the correct IPv6 Connection Type from the drop down menu. If you are unsure of which option to choose, contact your Internet Service Provider (ISP).", //IPV6_TEXT58
	"If you are having trouble accessing the IPv6 Internet through the router, double check any settings you have entered on this page and verify them with your ISP if needed.", //IPV6_TEXT59
	"6to4 SETTINGS", //IPV6_TEXT60
	"Enter the IPv6 address information provided by your Internet Service Provider (ISP).", //IPV6_TEXT61
	"6to4 Address", //IPV6_TEXT62
	"IPv6 DNS SETTINGS", //IPV6_TEXT63
	"Obtain a DNS server address automatically", //IPV6_TEXT65
	"Obscene", //_aa_bsecure_obscene
	"Use the following IPv6 DNS servers", //IPV6_TEXT66
	"Use this section to configure the internal network settings of your router.", //IPV6_TEXT67
	"Address Lifetime", //IPV6_TEXT68
	"Advertisement Lifetime", //IPV6_TEXT69
	"Address Range (Start)", //IPV6_TEXT70
	"Address Range (End)", //IPV6_TEXT71
	"Enter the information provided by your Internet Service Provider (ISP).", //IPV6_TEXT72
	"Idle Time", //IPV6_TEXT73
	"Subnet Prefix Length", //IPV6_TEXT74
	"IPv6 Default Gateway", //IPV6_TEXT75
	"The IPv6 (Internet Protocol version 6) section is where you configure your IPv6 Connection type.", //IPV6_TEXT76
	"There are several connection types to choose from: Link-local, Static IPv6, DHCPv6, Stateless Autoconfiguration, PPPoE, IPv6 in IPv4 Tunnel and 6to4. If you are unsure of your connection method, please contact your IPv6 Internet Service Provider. Note: If using the PPPoE option, you will need to ensure that any PPPoE client software on your computers has been removed or disabled.", //IPV6_TEXT77
	"Link-local Mode", //IPV6_TEXT78
	"The Link-local address is used by nodes and routers when communicating with neighboring nodes on the same link. This mode enables IPv6-capable devices to communicate with each other on the LAN side.", //IPV6_TEXT79
	"Static IPv6 Mode", //IPV6_TEXT80
	"This mode is used when your ISP provides you with a set IPv6 addresses that does not change. The IPv6 information is manually entered in your IPv6 configuration settings. You must enter the IPv6 address, Subnet Prefix Length, Default Gateway, Primary DNS Server, and Secondary DNS Server. Your ISP provides you with all this information.", //IPV6_TEXT81
	"DHCPv6 Mode", //IPV6_TEXT82
	"This is a method of connection where the ISP assigns your IPv6 address when your router requests one from the ISP's server. Some ISP's require you to make some settings on your side before your router can connect to the IPv6 Internet.", //IPV6_TEXT83
	"Stateless Autoconfiguration Mode", //IPV6_TEXT84
	"This is a method of connection where the ISP assigns your IPv6  address when your router requests one from the Default Gateway. Configuration of the IPv6 address is based on the receipt of the Router Advertisement message.", //IPV6_TEXT85
	"Select this option if your ISP requires you to use a  PPPoE (Point to Point Protocol over Ethernet) connection  to IPv6 Internet. DSL providers typically use this option.  This method of connection requires you to enter a <strong>Username</strong> and <strong>Password</strong> (provided by your Internet Service Provider) to gain access to the IPv6 Internet. The supported authentication protocols are PAP and CHAP.", //IPV6_TEXT86
	"Select this option if the ISP's servers assign the router's WAN IPv6 address upon establishing a connection.", //IPV6_TEXT87
	"If your ISP has assigned a fixed IPv6 address, select this option. The ISP provides the value for the <SPAN class=option>IPv6 Address.", //IPV6_TEXT88
	"The time interval the machine can be idle before the WAN link is disconnected. The Maximum Idle Time value is only used for the \"On demand\" and \"Manual\" reconnect modes.", //IPV6_TEXT89
	"IPv6 in IPv4 Tunnel Mode", //IPV6_TEXT90
	"IPv6 in IPv4 tunneling encapsulate of IPv6 packets in IPv4 packets so that IPv6 packets can be sent over an IPv4 infrastructure.", //IPV6_TEXT91
	"6to4 Mode", //IPV6_TEXT92
	"6to4 is an IPv6 address assignment and automatic tunneling technology that used to provide unicast IPv6 connectivity between IPv6 sites and hosts across the IPv4 Internet.", //IPV6_TEXT93
	"Primary DNS Server, Secondary DNS Server: Enter the IPv6 addresses of the DNS Servers. Leave the field for the secondary server empty if not used.", //IPV6_TEXT94
	"These are the settings of the LAN (Local Area Network) IPv6 interface for the router. The router's LAN IPv6 Address configuration is based on the IPv6 Address and Subnet assigned by your ISP. (A subnet with prefix /64 is supported in LAN.)", //IPV6_TEXT95
	"Use this section to set up IPv6 Autoconfiguration to assign an IPv6 address to the computers on your local network. A Stateless and a Stateful Autoconfiguration method are provided.", //IPV6_TEXT96
	"These two values (from and to) define a range of IPv6 addresses that the DHCPv6 Server uses when assigning addresses to computers and devices on your Local Area Network. Any addresses that are outside this range are not managed by the DHCPv6 Server. However, these could be used for manually configuring devices or devices that cannot use DHCPv6 to automatically obtain network address details.", //IPV6_TEXT97
	"When you select Stateful (DHCPv6), the following options are displayed.", //IPV6_TEXT98
	"The computers (and other devices) connected to your LAN also need to have their TCP/IP configuration set to \"DHCPv6\" or \"Obtain an IPv6 address automatically\".", //IPV6_TEXT99
	"IPv6 Address Range (DHCPv6)", //IPV6_TEXT100
	"It is possible for a computer or device that is manually configured to have an IPv6 address that does reside within this range.", //IPV6_TEXT102
	"The amount of time that a computer may have an IPv6 address before it is required to renew the lease.", //IPV6_TEXT103
	"Use Link-Local Address", //IPV6_TEXT104
	"Enable Automatic DHCP-PD in LAN", //IPV6_TEXT108
	"SLAAC + Stateless DHCPv6", //IPV6_TEXT106
	"Autoconfiguration (SLAAC/DHCPv6)", //IPV6_TEXT107
	"Enable Autoconfiguration", //IPV6_TEXT50
	"Enter a password for the user \"user\", who will have read-only access to the Web-based management interface.", //help825
	"IPv6 Internet Connection Setup Wizard", //IPV6_TEXT110
	"Manual IPv6 Internet Connection Setup", //IPV6_TEXT111
	"IPv6 Internet Connection", //IPV6_TEXT112
	"There are two ways to set up your IPv6 Internet connection. You can use the Web-based IPv6 Internet Connection Setup Wizard, or you can manually configure the connection.", //IPV6_TEXT113
	"This wizard will guide you through a step-by-step process to configure a new connection to the IPv6 Internet.", //IPV6_TEXT116
	"Step 1: Configure your IPv6 Internet Connection", //IPV6_TEXT117
	"Step 2: Save Settings and Connect", //IPV6_TEXT118
	"Router is detecting your IPv6 Interent connection type, please wait ...", //IPV6_TEXT119
	"Router is unable to detect your IPv6 Internet connection type.", //IPV6_TEXT120
	"Guide me through the IPv6 settings", //IPV6_TEXT121
	"IPv6 over PPPoE", //IPV6_TEXT122
	"Choose this option if your IPv6 Internet connection requires a username and password to get online. Most DSL modems use this type of connection.", //IPV6_TEXT123
	"Static IPv6 address and Route", //IPV6_TEXT124
	"Choose this option if your Internet Service Provider (ISP) provided you with IPv6 address information that has to be manually configured.", //IPV6_TEXT125
	"Tunneling Connection (6rd)", //IPV6_TEXT126
	"Choose this option if your Internet Service Provider (ISP) provided you a IPv6 Internet connection by using 6rd automatic tunneling mechanism. ", //IPV6_TEXT127
	"To set up this connection you will need to have a Username and Password from your IPv6 Internet Service Provider. If you do not have this inforamtion, please contact your ISP.", //IPV6_TEXT128
	"Share with IPv4", //IPV6_TEXT129
	"To set up this connection you will need to have a complete list of IPv6 information provided by your IPv6 Internet Service Provider.  If you have a Static IPv6 connection and do not have this inforamtion, please contact your ISP.", //IPV6_TEXT130
	"To set up this 6rd tunneling connection you will need to have the following information from your IPv6 Internet Service Provider. If you do not have this information, please contact your ISP.", //IPV6_TEXT131
	"6rd IPv6 Prefix", //IPV6_TEXT132
	"Assigned IPv6 Prefix", //IPV6_TEXT133
	"6rd Border Relay IPv4 Address", //IPV6_TEXT134
	"IPv6 DNS Server", //IPV6_TEXT135
	"The IPv6 Internet Connection Setup Wizard has completed. Click the Connect button to save your settings and reboot the router.", //IPV6_TEXT136
	"IPv6", //IPV6_TEXT137
	"Auto Detection", //IPV6_TEXT138
	"6rd", //IPV6_TEXT139
	"DS-Lite", //IPV6_TEXT140
	"Teredo Tunneling Path-through", //IPV6_TEXT141
	"6rd Configuration", //IPV6_TEXT142
	"6rd DHCPv4 Option", //IPV6_TEXT143
	"Manual Configuration", //IPV6_TEXT144
	"Tunnel Link-Local Address", //IPV6_TEXT145
	"AFTR ADDRESS INTERNET CONNECTION TYPE", //IPV6_TEXT146
	"Enable DHCP Server", //bd_EDSv
	"Enter either the IP address of the target computer or enter its fully qualified domain name.", //htsc_pingt_h
	"DS-Lite Configuration", //IPV6_TEXT149
	"DS-Lite DHCPv6 Option", //IPV6_TEXT150
	"AFTR IPv6 Address", //IPV6_TEXT151
	"B4 IPv4 Address", //IPV6_TEXT152
	"IPv6 WAN Default Gateway", //IPV6_TEXT153
	"Please select one of following configuration methods and click next to continue.", //wps_KR37
	"Set static ipv6 address connection", //IPV6_TEXT155
	"The IPv6 Internet Connection Setup Wizard has completed. Click the Connect button to save your settings and reboot the router.", //IPV6_TEXT156
	"SLAAC + RDNSS", //IPV6_TEXT157
	"Destination IPv6/Prefix Length", //IPV6_TEXT158
	"The range of B4 IPv4 Address is from 192.0.0.2 to 192.0.0.7", //IPV6_TEXT159
	"AFTR Address", //IPV6_TEXT160
	"IPv6 PPPoE is share with IPv4 PPPoE. Please change IPv4 WAN protocol at first!", //IPV6_TEXT161
	"6rd is using DHCPv4 option. Please change IPv6 WAN protocol at first!", //IPV6_TEXT162
	"IPv6 wan type should be SLAAC/DHCPv6, PPPoE, Autodetect Mode", //IPV6_TEXT163
	"You can also enable DHCP-PD to delegate prefixes for router in your LAN.", //IPV6_TEXT164
	"All of your IPv6 LAN connection details are displayed here.", //IPV6_TEXT165
	"IPv6 Network assigned by DHCP-PD", //IPV6_TEXT166
	"Parameters for an Application Rule", //haar_p
	"Optional backup RADIUS server", //bws_ORAD
	"SECURITY OPTIONS", //DNS_TEXT2
	"Advanced DNS&#8482;", //DNS_TEXT3
	"Advanced DNS makes your Internet connection safer, faster, smarter and more reliable. It blocks phishing websites to proetct you from identity theft.", //DNS_TEXT4
	"OpenDNS Parental Controls provides award-winning Web content filtering while making your Internet connection safer, faster, smarter and more reliable. With more than 50 content categories to choose from it's effective against adult content, proxies, social networking, phishing sites, malware and more. Fully configurable from anywhere there is Internet access. ", //DNS_TEXT8
	"Automatically block adult and phishing websites while improving the speed and reliability of your Internet connection.", //DNS_TEXT6
	"OpenDNS&reg; FamilyShield&#8482", //DNS_TEXT5
	"Open Systems Interconnection is the reference model for how data should travel between two devices on a network", //help639
	"None: Static IP or Obtain Automatically From ISP", //DNS_TEXT9
	"Use the DNS servers provided by your ISP, or enter your preferred DNS servers.", //DNS_TEXT10
	"Although the Advanced DNS feature is enabled, the DNS IP address of your workstation can still be modified to the DNS server IP you desire. Please note that the router does not dictate the DNS name resolution when the DNS IP address is manually configured on the workstation.", //DNS_TEXT11
	"If you selected this option and have a VPN or an Intranet setup on your network, you can disable the Advanced DNS service if you experience connection difficulties.", //DNS_TEXT12
	"TRENDNET | %m | Status | Device Information", //TEXT000
	"Stateless Autoconfiguration", //TEXT001
	"Virtual server name %s invalid. Illegal character ',/,''\"", //TEXT002
	"Rules name '+ i +' invalid. Illegal character ',/,''", //TEXT003
	"Host name invalid. Illegal character ',/,''", //TEXT004
	"Local domain name invalid. Illegal character ',/,'", //TEXT005
	"Rules name '+ i +' invalid. Illegal character ',/,''", //TEXT006
	"Port forwarding name %s invalid. Illegal character ',/,''", //TEXT007
	"Rules'+i+' is setting same as Rules'+j+'.", //TEXT008
	"obj_word + \" conflict with another private port.\"", //TEXT010
	"Number Of Wireless Clients", //sw_title_list
	"The Other Protocol Type is invalid", //TEXT011
	"Please choose wireless device with wps!", //TEXT012
	"Inbound filter must be smaller than + rule_max_num", //TEXT013
	"Name cannot be set as the same as default Inbound filter name 'Allow All' or 'Deny All'.", //TEXT014
	"Schedule rules Full! Please Delete an Entry.", //TEXT015
	"First Page", //TEXT016
	"Last Page", //TEXT017
	"Previous", //TEXT018
	"System Activity", //TEXT019
	"Debug Information", //TEXT020
	"Attacks", //TEXT021
	"Dropped Packets", //TEXT022
	"Nothing has changed, save anyway?", //LS3
	"Cannot choose WEP key 2, 3, 4 when WPS is enabled!!", //TEXT024
	"Cannot choose WPA-Personal/TKIP and AES when WPS is enabled!!", //TEXT025
	"Cannot choose WPA-Enterprise when WPS is enabled!!", //TEXT026
	"Cannot choose shared key when WPS is enabled!!", //TEXT027
	"Please Enable Wireless first.", //TEXT028
	"The WPS Function is currently set to disabled. Please click \"Yes\" to enable it or \"No\" to exit the wizard.", //TEXT029
	"The %s cannot allow loopback IP or multicase IP (127.x.x.x, 224.x.x.x ~ 239.x.x.x) entries.", //TEXT030
	"The %s port entered is invalid.", //TEXT031
	"The %s secret entered is invalid.", //TEXT032
	"Reserved IP address", //TEXT033
	"Start IP address", //TEXT035
	"\"End IP address\"", //TEXT036
	"The LAN IP Address and the Start IP Address are not in the same subnet", //TEXT037
	"The LAN IP Address and the End IP Address are not in the same subnet", //TEXT038
	"The Ending IP Address must be greater than the Starting IP Address", //TEXT039
	"The setting has been saved.", //TEXT040
	"The Key \" + i + \" is invalid. The Key must be \" + wep_key_len + \" characters or \" + hex_len + \" hexadecimal number.", //TEXT041
	"Key ' + i + 'is wrong, the legal characters are 0~9, A~F, or a~f.", //TEXT042
	"%s Gateway IP address %s must be within the WAN subnet.", //TEXT043
	"This firmware is the latest version.", //TEXT045
	"Error contacting the server, please check the Internet connection status.", //TEXT046
	"WAN and LAN IP Address cannot be in the same subnet.", //TEXT047
	"Please enter one machine.", //aa_alert_10
	"You have failed to add the wireless device to your wireless network within the given timeframe, please click on the button below to do it again.", //TEXT049
	"\"IP Address '\"+ res_ip +\"' has already been used.\"", //TEXT050
	"The Confirmed Password does not match the New Password", //TEXT051
	"ALSO CALLED WCN 2.0 IN WINDOW VISTA", //TEXT053
	"obj_word + \" conflict with Application Firewall Port.\"", //TEXT055
	"obj_word + \" conflict with another public port.\"", //TEXT009
	"obj_word + \" conflict with Port Forwarding Port.\"", //TEXT054
	"Port conflict.", //TEXT057
	"TCP Port conflict.", //TEXT058
	"UDP Port conflict.", //TEXT059
	"The Port Forwarding name is already in the list", //TEXT060
	"Do you want to enable the DHCP Reservation entry for IP Address ' + DataArray[idx].IP", //TEXT062
	"The rule is being used by another rule and cannot be deleted.", //TEXT063
	"Schedule Name is invalid. Legal characters are 0~9, A~Z, or a~z.", //TEXT064
	"Schedule Name is the default name.", //TEXT065
	"The Schdule name is already in the list", //TEXT066
	"The rule is being used by another rule and cannot be edited.", //TEXT067
	"IPv6 Network Information", //TEXT068
	"All of your IPv6 Internet and network connection details are displayed on this page.", //TEXT069
	"IPv6 Connection Information", //TEXT070
	"WAN IPv6 Address", //TEXT071
	"LAN IPv6 Computers", //TEXT072
	"Retry", //TEXT073
	"Next", //TEXT074
	"Host Name or IPv6 Address", //TEXT075
	"Try again", //TEXT076
	"PPPoE Session", //TEXT077
	"Create new session", //TEXT078
	"The 1st address of %s must be an integer.", //MSG002
	"The 2nd address of %s must be an integer.", //MSG003
	"The 3rd address of %s must be an integer.", //MSG004
	"The 4th address of %s must be an integer.", //MSG005
	"The %s is an invalid address.", //MSG006
	"The %s cannot be zero.", //MSG007
	"The %s port entered is invalid.", //MSG008
	"The %s secret entered is invalid", //MSG009
	"The %s can't allow entry to loopback IP or multicast IP (127.x.x.x, 224.x.x.x ~ 239.x.x.x).", //MSG010
	"The value of %s must be numeric!", //MSG013
	"The range of %s is %1n ~ %2n.", //MSG014
	"The range of %s is %d ~ %d.", //MSG014a
	"The value of %s must be an even number.", //MSG015
	"The Key is invalid. The Key must be a 5 or 10 character hexadecimal number. You entered \"", //MSG016
	"The Key is invalid. The Key must be a 13 or 26 character hexadecimal number. You entered", //MSG017
	"The 1st address of %s must be hexadecimal.", //MSG018
	"The 2nd address of %s must be hexadecimal.", //MSG019
	"The 3rd address of %s must be hexadecimal.", //MSG020
	"The 4th address of %s must be hexadecimal.", //MSG021
	"The 5th address of %s must be a hexadecimal.", //MSG022
	"The 6th address of %s must be hexadecimal.", //MSG023
	"The 7th address of %s must be hexadecimal.", //MSG024
	"The 8th address of %s must be hexadecimal.", //MSG025
	"The 1st range of %s must be between", //MSG026
	"The 2nd range of %s must be between", //MSG027
	"The 3rd range of %s must be between", //MSG028
	"The 4th range of %s must be between", //MSG029
	"The 5th range of %s must be between", //MSG030
	"The 6th range of %s must be between", //MSG031
	"The 7th range of %s must be between", //MSG032
	"The 8th range of %s must be between", //MSG033
	"The %s cannot allow entry to loopback IP ( ::1 ).", //MSG034
	"The %s cannot allow entry to multicast IP ( FFxx:0:0:0:0:0:0:2 or ffxx:0:0:0:0:0:0:2.", //MSG035
	"The suffix of ", //MSG036_1
	"The subnet of ", //MSG037_1
	" must be hexadecimal.", //MSG038_1
	" is an invalid address.", //MSG039_1
	"The suffix of \"+tag +\" must be hexadecimal.", //MSG036
	"The suffix of \"+tag+\" is an invalid address.", //MSG037
	"The subnet of \"+tag +\" must be hexadecimal.", //MSG038
	"The subnet of \"+tag+\" is an invalid address.", //MSG039
	"The suffix of IPv6 Address Range(Start) is more than the suffix of IPv6 Address Range(End)", //MSG040
	"The IPv6 address allows a double-colon only once.", //MSG041
	"The IPv6 address is illegal", //MSG042
	"Invalid Metric", //MSG043
	"Pure 802.11n mode doesn't support WEP.", //MSG044
	"Pure 802.11n mode doesn't support TKIP.", //MSG045
	"The range of %s is from %s to ", //MSG046
	"Invalid IPv6 ULA Prefix", //MSG047
	"The field of ULA prefix is blank, use the default ULA prefix?", //MSG048
	"Your search results are powered by Yahoo. The search function provides you with a much more fluid browsing experience. When a site cannot be reached, or a site does not exist, we will provide you with search suggestions instead of the generic error message displayed by your browser. We also automatically correct some of the common typos users make in the address bar. The typo-correction feature only works for top level domains that have been misspelled, such .cmo and .ogr. Sometimes you might be mis-directed to the search results page. If you clicked on a link in a spam email it is quite possible that the site has been disabled for abuse. Because the site no longer exists you may receive our search page.", //ADV_DNS_DESC3
	"The page you requested is not available.", //ERROR404
	"Suggestions", //SUGGESTIONS
	"Make sure your internet cable is securely connected to the internet port on your router, and your internet LED is blink green or blue.", //SUGGESTIONS_1
	"Check to make sure that the <a href='http://<% CmoGetCfg('lan_ipaddr',''); %>/'>Internet settings</a> on your router are set correctly, such as your PPPoE username/password settings.", //SUGGESTIONS_2
	"(hour minute)", //tsc_hrmin_1
	"DHCP-PD", //DHCP_PD
	"Enable DHCP-PD", //IPV6_TEXT147
	"IPv6 network assigned <br>by DHCP-PD", //DHCP_PD_ASSIGNED
	"6to4 Relay", //_6to4RELAY
	"Obtain a DNS server address automatically or enter a specific DNS server address.", //IPV6_TEXT64
	"Use the following IPv6 DNS address", //IPV6_TEXT66_v6
	"Changing usb type to Windows Mobile or iPhone or Android Phone will cause the device to reboot.", //usb_reboot
	"Changing usb type to Windows Mobile or iPhone will cause the device to reboot, also will change device IP to 192.168.99.1.", //usb_reboot_chnip
	"Philippine", //country_8
	"Select usb phone", //_select_phone
	"Select the 3G USB phone you used.", //_phone_info
	"3G USB Phone", //usb_3g_phone
	"Windows Mobile 5", //usb_window_mobile_5
	"iPhone 3G(s)", //usb_iphone
	"Android Phone", //android_phone
	"Displays the current status of connection to DDNS server", //help901
	"Device Name", //DEVICE_NAME
	"The lease %v was revoked.", //IPDHCPSERVER_LEASE_REVOKED2
	"Lease reservation %v was deleted.", //IPDHCPSERVER_LEASE_RESERVATION_DELETED
	"Lease %v renewed by client %m", //IPDHCPSERVER_LEASE_RENEW
	"Wake on LAN", //help738
	"Wireless Local Area Network", //help759
	"The most widely used technology for Local Area Networks.", //help517
	"Bits per second", //help443
	"Characters A-Z and 0-9", //help414
	"OK", //_ok
	"Default", //help486
	"DSL", //help503
	"The loss in strength of digital and analog signals. The loss is greater when the signal is being transmitted over long distances.", //help426
	"Bandwidth", //help432
	"Breaking up data into smaller pieces to make it easier to store", //help527
	"The Web Filter option allows you to set up a list of allowed Web sites that can be used by multiple users. When Web Filter is enabled, all Web sites not listed on this page will be blocked. To use this feature, you must also select the \"Apply Web Filter\" checkbox in the Access Control section.", //awf_intro_WF
	"Post Office Protocol 3 is used for receiving email", //help652
	"CardBus", //help456
	"Graphical user interface", //help539
	"Database", //help472
	"File server", //help520
	"VoIP", //help737
	"The first layer of the OSI model. Provides the hardware means of transmitting electrical signals on a data carrier", //help646
	"Web browser", //help745
	"Used to synchronize communication timing between devices on a network", //help659
	"USB", //help727
	"Wireless ISP", //help753
	"The method of transferring data from one computer to another on the Internet", //help574
	"Remote Authentication Dial-In User Service allows for remote users to dial into a central server and be authenticated in order to access resources on a network", //help663
	"Wi-Fi", //help748
	"Create a list of Web sites to which you would like to allow access from the devices on your network.", //hhwf_intro
	"Light Emitting Diode", //help598
	"xDSL", //help761
	"IP address that is assigned by a DHCP server and that may change. Cable Internet providers usually use this method to assign IP addresses to their customers.", //help510
	"IPsec", //help584
	"A utility displays the routes between you computer and specific destination", //help716
	"Bit rate", //help440
	"Asymmetric Digital Subscriber Line", //help410
	"dBi", //help480
	"IEEE", //help559
	"Ethernet", //help516
	"Alphanumeric", //help413
	"Maximum Transmission Unit is the largest packet that can be transmitted on a packet-based network like the Internet", //help619
	"A computer on a network that stores data so that the other computers on the network can all access it", //help521
	"DSSS: Modulation technique used by 802.11b wireless devices", //help494
	"Domain Name System: Translates Domain Names to IP addresses", //help498
	"Network Interface Card", //help628
	"An encryption and decryption key that is generated for every communication session between two computers", //help683
	"Gigabits per second", //help535
	"SPI", //help695
	"Wi, Wide Area Network", //help740
	"An ISP provides access to the Internet to individuals or companies", //help578
	"Beacon", //help438
	"Dynamic DNS is provided by companies to allow users with Dynamic IP addresses to obtain a Domain Name that will always by linked to their changing IP address. The IP address is updated by either client software running on a computer or by a router that supports Dynamic DNS, whenever the IP address changes", //help508
	"ASCII", //help423
	"NetBIOS", //help625
	"Server", //help680
	"In terms of a wireless network, this is when wireless clients use an Access Point to gain access to the network", //help568
	"Multicast", //help620
	"Apple's version of UPnP, which allows for devices on a network to discover each other and be connected without the need to configure any settings", //help667
	"A family of specifications for wireless local area networks (WLANs) developed by a working group of the Institute of Electrical and Electronics Engineers (IEEE).", //help766
	"RADIUS", //help662
	"Stateful inspection", //help701
	"Half-duplex", //help542
	"A system of worldwide networks which use TCP/IP to allow for resources to be accessed from computers around the world", //help570
	"DMZ: A single computer or group of computers that can be accessed by both users on the Internet as well as users on the Local Network, but that is not protected by the same security as the Local Network.", //help489
	"To install a more recent version of a software or firmware product", //help723
	"Kilobyte", //help593
	"A time during processes when something causes the process to slowdown or stop all together", //help447
	"System Logger -- a distributed logging interface for collecting in one place the logs from different sources. Originally written for UNIX, it is now available for other operating systems, including Windows.", //help705
	"Connecting to a Local Area Network over one of the 802.11 wireless standards", //help755
	"H.323", //_H323
	"To provide credentials, like a Password, in order to verify that the person or device is really who they are claiming to be", //help427
	"To unscramble an encrypted message back into plain text", //help485
	"Dynamic Host Configuration Protocol: Used to automatically assign IP addresses from a predefined pool of addresses to computers or devices that request them", //help490
	"HTTP over SSL is used to encrypt and decrypt HTTP transmissions", //help555
	"Collision", //help462
	"VPN: A secure tunnel over the Internet to connect remote offices or users to their company's network", //help732
	"Kbyte", //help592
	"A device that allows you to connect a computer up to a coaxial cable and receive Internet access from your Cable provider", //help455
	"The fifth layer of the OSI model which coordinates the connection and communication between applications on both ends", //help685
	"Many web sites construct pages with images and content from other web sites. Access will be forbidden if you do not enable all the web sites used to construct a page. For example, to access <code>my.yahoo.com</code>, you need to enable access to <code>yahoo.com</code>, <code>yimg.com</code>, and <code>doubleclick.net</code>.", //help146
	"Point-to-Point Protocol is used for two computers to communicate with each over a serial interface, like a phone line", //help655
	"A data frame by which one of the stations in a Wi-Fi network periodically broadcasts network control data to other wireless stations.", //help439
	"Used to transmit and receive RF signals.", //help416
	"Uniform Resource Locator is a unique address for files accessible on the Internet", //help726
	"SNMP", //help692
	"Host", //help550
	"The amount of data that can be transferred in a given time period", //help714
	"Digital Subscriber Line. High bandwidth Internet connection over telephone lines", //help504
	"Uses a randomly selected 56-bit key that must be known by both the sender and the receiver when information is exchanged", //help469
	"A card installed in a computer or built onto the motherboard that allows the computer to connect to a network", //help629
	"LED", //help597
	"A utility that allows you to view content and interact with all of the information on the World Wide Web", //help746
	"Wireless Fidelity", //help749
	"The second layer of the OSI model. Controls the movement of data on the physical link of a network", //help471
	"Sending voice information over the Internet as opposed to the PSTN", //help736
	"The amount of time that it takes a packet to get from the one point to another on a network. Also referred to as delay", //help596
	"Transmission Control Protocol", //help706
	"Reboot", //help664
	"A feature of a firewall that monitors outgoing and incoming traffic to make sure that only valid responses to outgoing requests are allowed to pass though the firewall", //help702
	"WISP", //help756
	"Internet Protocol", //help573
	"A group of computers in a building that usually access files from a server", //help601
	"Session layer", //help684
	"RSA", //help678
	"Wi-Fi Protected Access. A Wi-Fi security enhancement that provides improved data encryption, relative to WEP.", //help760
	"Gigabit Ethernet", //help536
	"Domain name", //help499
	"Internet Group Management Protocol is used to make sure that computers can report their multicast group membership to adjacent routers", //help562
	"WCN", //help741
	"A standard that provides consistency of voice and video transmissions and compatibility for videoconferencing devices", //help541
	"User Datagram Protocol", //help717
	"Layer 2 Tunneling Protocol", //help604
	"Unicast", //help718
	"Computer on a network", //help551
	"Internet Service Provider", //help577
	"Converting data into cyphertext so that it cannot be easily read", //help515
	"Sending data from one device to many devices on a network", //help621
	"AES. Government encryption standard", //help412
	"Throughput", //help713
	"Used for sending and receiving email", //help687
	"Infrastructure", //help567
	"Microsoft Point-to-Point Encryption is used to secure data transmissions over PPTP connections", //help618
	"The amount of bits that pass in given amount of time", //help441
	"Data", //help466
	"SMTP", //gw_vs_5
	"DMZ", //help488
	"Kilobits per second", //help591
	"AP. Device that allows wireless clients to connect to it and access the network", //help402
	"Quality of Service", //help661
	"DMZ", //help495
	"ISP", //help587
	"Preamble", //help658
	"Upgrade", //help722
	"Decibels relative to one milliwatt", //help483
	"RIP", //help670
	"WPA", //help750
	"Browser", //help452
	"Stateful Packet Inspection", //help696
	"Repeater", //help668
	"The maximum amount of bytes or bits per second that can be transmitted to and from a network device", //help433
	"A computer on a network that provides services and resources to other computers on the network", //help681
	"Network Time Protocol", //help632
	"ADSL", //help409
	"802.11", //help765
	"Application layer", //help421
	"URL", //help725
	"QoS", //help660
	"IPsec provides security at the packet processing layer of network communication", //help576
	"An updated version of security for wireless networks that provides authentication as well as encryption", //help751
	"Voice over IP", //help735
	"Access Point", //help401
	"POP3", //gw_vs_6
	"Digital certificate:", //help491
	"Broadband", //help448
	"Internet Key Exchange is used to ensure security for VPN connections", //help566
	"Help Glossary", //help398
	"Internetwork Packet Exchange is a networking protocol developed by Novel to enable their Netware clients and servers to communicate", //help586
	"A TCP/IP protocol for transmitting streams of printer data.", //help710
	"Simple Mail Transfer Protocol", //help686
	"Transmission technology that provides a data rate of 1 billion bits per second", //help537
	"PPP", //help654
	"TCP/IP(Transmission Control Protocol/Internet Protocol)", //help708
	"American Standard Code for Information Interchange. This system of characters is most commonly used for text files", //help424
	"Duplex", //help505
	"A 32-bit number, when talking about Internet Protocol Version 4, that identifies each computer that transmits data on the Internet or on an Intranet", //help583
	"Backward Compatible", //help430
	"Decrypt", //help484
	"Cable modem", //help454
	"HUB", //help556
	"Data-Link layer", //help470
	"Governs the management and monitoring of network devices", //help689
	"Cookie", //help464
	"A program or user that requests data from a server", //help461
	"Nov", //tt_Nov
	"Traceroute", //help715
	"Network Address Translation allows many private IP addresses to connect to the Internet, or another network, through one IP address", //help622
	"Virtual Private Network", //help731
	"ARP. Used to map MAC addresses to IP addresses so that conversions can be made in both directions.", //help408
	"Simple Network Management Protocol", //help688
	"Information that is stored on the hard drive of your computer that holds your preferences to the site that gave your computer the cookie", //help465
	"Subnet mask", //help703
	"SSH", //help697
	"MAC address", //help605
	"The action of data packets being transmitted from one router to another", //help549
	"Sending and Receiving data transmissions at the sane time", //help506
	"A sequence of characters that is used to authenticate requests to resources on a network", //help642
	"Automatic Private IP Addressing", //help428
	"Session key", //help682
	"An electronic method of providing credentials to a server in order to have access to it or a network", //help492
	"Fragmentation", //help526
	"The third layer of the OSI model which handles the routing of traffic on a network", //help631
	"A unique hardware ID assigned to every Ethernet adapter by the manufacturer.", //help606
	"To restart a computer and reload it's operating software or firmware from nonvolatile storage.", //help665
	"The section lists the currently allowed web sites.", //help148
	"Rate estimation aborted as low on resources", //RATE_ESTIMATOR_RESOURCE_ERROR
	"A standard that allows network devices to discover each other and configure themselves to be a part of the network", //help721
	"HTTPS", //gw_vs_2
	"UTP", //help729
	"Wireless Internet Service Provider", //help757
	"Latency", //help595
	"Routing Information Protocol is used to synchronize the routing table of all the routers on a network", //help671
	"Wired Equivalent Privacy is security for wireless networks that is supposed to be comparable to that of a wired network", //help747
	"TCP/IP", //help707
	"Transmitting data in all directions at once", //help451
	"Electronic Mail is a computer-stored message that is transmitted over the Internet", //help514
	"Extensible Authentication Protocol", //help512
	"The most commonly used connection method for Ethernet", //help675
	"Access Control List", //help399
	"Network Basic Input/Output System", //help626
	"Antenna", //help415
	"A device that connects your network to another, like the internet", //help533
	"A World Wide Web browser created and provided by Microsoft", //help572
	"A networking device that connects multiple devices together", //help557
	"Data Encryption Standard", //help468
	"To send a request from one computer to another and have a file transmitted from the requesting computer to the other", //help724
	"A utility program that verifies that a given Internet address exists and can receive messages. The utility sends a control packet to the given address and waits for a response.", //help648
	"Please wait", //wt_title
	"Point-to-Point Tunneling Protocol is used for creating VPN tunnels over the Internet between two networks", //help657
	"dBm", //help482
	"Algorithm used for encryption and authentication", //help679
	"The ability for new devices to communicate and interact with older legacy devices to guarantee interoperability", //help431
	"Institute of Electrical and Electronics Engineers", //help560
	"Windows Connect Now. A Microsoft method for configuring and bootstrapping wireless networking hardware (access points) and wireless clients, including PCs and other devices.", //help742
	"A wide band of frequencies available for transmitting data", //help449
	"IKE", //help565
	"OR, click <em>Next</em> to continue anyway and later choose <em>No</em> when asked if you'd like to print a test page.", //wprn_tt7
	"Legacy", //help599
	"IPX", //help585
	"Sending and Receiving data at the same time", //help530
	"NetBEUI", //help623
	"WLAN", //help758
	"NIC", //help634
	"The larger network that your LAN is connected to, which may be the Internet itself, or a regional or corporate network", //help752
	"Internet Protocol Security", //help575
	"Broadcast", //help450
	"PHYSICAL CONNECTION OF INTERNET PORT IS DISCONNECTED", //ES_CABLELOST_bnr
	"When do two devices on the same Ethernet network try and transmit data at the exact same time.", //help463
	"Address Resolution Protocol", //help407
	"A program that allows you to access resources on the web and provides them to you graphically", //help453
	"IGMP", //help561
	"Bit/sec", //help442
	"A generic term for the family of digital subscriber line (DSL) technologies, such as ADSL, HDSL, RADSL, and SDSL.", //help762
	"Hypertext Transfer Protocol is used to transfer files from HTTP servers (web servers) to HTTP clients (web browsers)", //help553
	"Kbps", //help590
	"Megabits per second", //help608
	"Advanced Encryption Standard", //help411
	"DNS", //gw_vs_4
	"Hexadecimal", //help546
	"A logical channel endpoint in a network. A computer might have only one physical channel (its Ethernet channel) but can have multiple ports (logical channels) each identified by a number.", //help653
	"Decibels relative to isotropic radiator", //help481
	"Full-duplex", //help529
	"Attenuation", //help425
	"ACL. This is a database of network devices that are allowed to access resources on the network.", //help400
	"Dynamic IP address", //help509
	"DHCP", //_DHCP
	"TCP Raw", //help709
	"UPnP", //help720
	"USB", //help728
	"Information that has been translated into binary so that it can be processed or moved to another device", //help467
	"Communication between a single sender and receiver", //help719
	"Local Area Network", //help594
	"A newer version of the PC Card or PCMCIA interface. It supports a 32-bit data path, DMA, and consumes less voltage", //help457
	"Rendezvous", //help666
	"Secure Shell is a command line interface that allows for secure connections to remote computers", //help698
	"GUI", //help538
	"Network Layer", //help630
	"7th Layer of the OSI model. Provides services to applications to ensure that they can communicate properly with other applications on a network.", //help422
	"Direct Sequence Spread Spectrum", //help493
	"Dynamic DNS service", //help507
	"Internet Explorer", //help571
	"Rate estimation aborted as measurements failed to converge", //RATE_ESTIMATOR_CONVERGENCE_ERROR
	"A predetermined value or setting that is used by a program when no user input has been entered for this value or setting", //help487
	"NetBIOS Extended User Interface is a Local Area Network communication protocol. This is an updated version of NetBIOS", //help624
	"Data cannot be transmitted and received at the same time", //help543
	"Service Set Identifier is a name for a wireless network", //help700
	"Client", //help460
	"Unshielded Twisted Pair", //help730
	"To send a request from one computer to another and have the file transmitted back to the requesting computer", //help502
	"Email", //help513
	"Session Initiation Protocol. A standard protocol for initiating a user session that involves multimedia content, such as voice or chat.", //help690
	"Mbps", //help607
	"Programming that is inserted into a hardware device that tells it how to function", //help525
	"A company that provides a broadband Internet connection over a wireless connection", //help754
	"MPPE", //help617
	"A name that is associated with an IP address", //help500
	"Internet Control Message Protocol", //help558
	"APIPA. An IP address that that a Windows computer will assign itself when it is configured to obtain an IP address automatically but no DHCP server is available on the network", //help429
	"EAP", //help511
	"Gbps", //help534
	"Demilitarized Zone. A computer that logically sits in a \"no-mans land\" between the LAN and the WAN. The DMZ computer trades some of the protection of the router's security mechanisms for the convenience of being directly addressable from the Internet.", //help496
	"Bottleneck", //help446
	"Allows you to power up a computer though it's Network Interface Card", //help739
	"Determines what portion of an IP address designates the Network and which part designates the Host", //help627
	"Active Sessions", //_actsess
	"Priority 0 is reserved.", //help91a
	"Flows that are not prioritized by any rule receive lowest priority.", //help91b
	"The common choices can be selected from the drop-down menu.", //help92x1
	"To specify any other protocol, enter its protocol number (<a href='http://www.iana.org/assignments/protocol-numbers' target='_blank'>as assigned by the IANA</a>) in the <span class='option'>Protocol</span> box.", //help92x2
	"When a LAN application that uses a protocol other than UDP, TCP, or ICMP initiates a session to the Internet, the router's NAT can track such a session, even though it does not recognize the protocol. This feature is useful because it enables certain applications (most importantly a single VPN connection to a remote host) without the need for an ALG.", //TA21
	"Note that this feature does not apply to the DMZ host (if one is enabled). The DMZ host always handles these kinds of sessions.", //TA22
	"are recommended.", //help183
	"Check this box to allow the DHCP Server to offer NetBIOS configuration settings to the LAN hosts.", //help400_b
	"If NetBIOS advertisement is swicthed on, switching this setting on causes WINS information to be learned from the WAN side, if available.", //help401_b
	"Configure the IP address of the preferred WINS server.", //help402_b
	"ActiveX", //help403
	"Configure the IP address of the backup WINS server, if any.", //help403_b
	"A Microsoft specification for the interaction of software components.", //help404
	"This is an advanced setting and is normally left blank. This allows the configuration of a NetBIOS \"domain\" name under which network hosts operate.", //help404_b
	"Ad-hoc network", //help405
	"Indicates how network hosts are to perform NetBIOS name registration and discovery.", //help405_b
	"Peer configuration error %u", //WIFISC_AP_PEER_CFG_ERR
	"AppleTalk", //help417
	"A set of Local Area Network protocols developed by Apple for their computer systems", //help418
	"AppleTalk Address Resolution Protocol (AARP)", //help419
	"AARP. Used to map the MAC addresses of Apple computers to their AppleTalk network addresses, so that conversions can be made in both directions.", //help420
	"Basic Input/Output System", //help434
	"BIOS. A program that the processor of a computer uses to startup the system once it is turned on", //help435
	"Baud", //help436
	"Data transmission speed", //help437
	"BOOTP", //help444
	"Bootstrap Protocol. Allows for computers to be booted up and given an IP address with no user intervention", //help445
	"CAT 5", //help458
	"Category 5. Used for 10/100 Mbps or 1Gbps Ethernet connections", //help459
	"DB-25", //help474
	"A 25 ping male connector for attaching External modems or RS-232 serial devices", //help475
	"DB-9", //help476
	" A 9 pin connector for RS-232 connections", //help477
	"dBd", //help478
	"Decibels related to dipole antenna", //help479
	"Fiber optic", //help518
	"A way of sending data through light impulses over glass or plastic wire or fiber", //help519
	"File sharing", //help522
	"Allowing data from computers on a network to be accessed by other computers on the network with different levels of access rights", //help523
	"File Transfer Protocol. Easiest way to transfer files between computers on the Internet", //help528
	"Gain", //help531
	"The amount an amplifier boosts the wireless signal", //help532
	"Hashing", //help544
	"Transforming a string of characters into a shorter string with a predefined length", //help545
	"Hop", //help548
	"IIS", //help563
	"Internet Information Server is a WEB server and FTP server provided by Microsoft", //help564
	"Intranet", //help579
	"A private network", //help580
	"Intrusion Detection", //help581
	"A type of security that scans a network to detect attacks coming from inside and outside of the network", //help582
	"Java", //help588
	"A programming language used to create programs and applets for web pages", //help589
	"LPR/LPD", //help602
	"Line Printer Requestor/\"Line Printer Daemon\". A TCP/IP protocol for transmitting streams of printer data.", //help603
	"MDI", //help609
	"Medium Dependent Interface is an Ethernet port for a connection to a straight-through cable", //help610
	"MDIX", //help611
	"Medium Dependent Interface Crossover, is an Ethernet port for a connection to a crossover cable", //help612
	"MIB", //help613
	"Management Information Base is a set of objects that can be managed by using SNMP", //help614
	"Modem", //help615
	"A device that Modulates digital signals from a computer to an analog signal in order to transmit the signal over phone lines. It also Demodulates the analog signals coming from the phone lines to digital signals for your computer", //help616
	"Oct", //tt_Oct
	"Originator", //sa_Originator
	"Orthogonal Frequency-Division Multiplexing is the modulation technique for both 802.11a and 802.11g", //help637
	"Open Shortest Path First is a routing protocol that is used more than RIP in larger scale networks because only changes to the routing table are sent to all the other routers in the network as opposed to sending the entire routing table at a regular interval, which is how RIP functions", //help641
	"OSI", //help638
	"Open mode configuration is not secure", //msg_non_sec
	"Personal", //LW24
	"The interconnection of networking devices within a range of 10 meters", //help644
	"PoE", //help649
	"Power over Ethernet is the means of transmitting electricity over the unused pairs in a category 5 Ethernet cable", //help650
	"RJ-11", //help672
	"The most commonly used connection method for telephones", //help673
	"RS-232C", //help676
	"The interface for serial communication between computers and other related devices", //help677
	"SOHO", //help693
	"Small Office/Home Office", //help694
	"TFTP", //help711
	"Trivial File Transfer Protocol is a utility used for transferring files that is simpler to use than FTP but with less features", //help712
	"VLAN", //help733
	"Virtual LAN", //help734
	"WDS", //help743
	"Wireless Distribution System. A system that enables the interconnection of access points wirelessly.", //help744
	"Yagi antenna", //help763
	"A directional antenna used to concentrate wireless signals on a specific location", //help764
	"Note that a log message uses the language that is in effect at the time of the logged event. If you change languages, you may see some log messages in one language and other log messages in another language.", //help795a
	"Internal", //sa_Internal
	"External", //sa_External
	"OpenDNS&reg; Parental Controls&#8482", //DNS_TEXT7
	"Select a filter that controls access as needed for this admin port. If you do not see the filter you need in the list of filters, go to the <a href=\"Inbound_Filter.asp\" onclick=\"return jump_if();\">Advanced &rarr; Inbound&nbsp;Filter</a> screen and create a new filter.", //help831_1
	"Options to improve the speed and reliability of your Internet connection, to apply content filtering and to protect you from phishing sites. Choose from pre-configured bundles or register your router with OpenDNS&reg; to choose from 50 content categories for custom blocking.", //DNS_TEXT1
	"Add/Edit Schedule Rule", //help191
	"Saves the new or edited Schedule Rule in the following list. When finished updating the Schedule Rules, you must still click the <span class='button_ref'>Save Settings</span> button at the top of the page to make the changes effective and permanent.", //help198
	"Unknown (Please wait...)", //_unknown_wait
	"Unknown", //_unknown
	"N/A", //_na
	"No computer information yet.", //_sdi_nciy
	"DHCP Client", //_sdi_dhcpclient
	"BigPond Client", //_sdi_bpc
	"Older devices or technology", //help600
	"No multicast group membership information yet.", //_bln_nmgmy
	" Incorrectly configured", //_sdi_s1
	" Status change (please wait...)", //_sdi_s10
	" Logged out", //_sdi_s8
	" Failed", //_sdi_s9
	"day(s)", //_sdi_days
	" (disconnection pending in", //_sdi_disconnectpending
	" seconds)", //_sdi_secs
	"DHCP Renew", //sd_Renew
	"DHCP Release", //sd_Release
	"Disconnect", //sd_Disconnect
	"BigPond Login", //sd_bp_login
	"BigPond Logout", //sd_bp_logout
	"Channel", //_channel
	"System Logs", //sl_SLogs
	"Print Server Status", //sps_intro2
	"printers are", //sps_pare
	"Routing Table", //sr_RTable
	"The Routing Status menu shows information about the routes that have been enabled on your router. The list will display the destination IP address, gateway IP address, subnet mask, metric and interface for each route.", //sr_intro
	"Network Traffic Stats", //ss_title_stats
	"Associated Wireless Client List", //sw_title
	"Invalid value for Admin Idle Timeout, should be in range (1..65535)", //ta_alert_1
	"Please make sure the cable between the ADSL/cable modem and the router is properly connected. The router will try to detect your Internet connection type again.", //ES_CABLELOST_dsc1
	"Please make the two passwords the same and try again", //_pwsame
	"Invalid remote management port '+data.wan_web_port+', should be in range (1..65535)", //ta_alert_3
	"The specified Dynamic DNS Service Provider is not supported", //_invalidddnsserver
	"The specified Server Address is blank", //_blankddnsserver
	"Please change IPv6 WAN protocol first!", //IPV6_TEXT1
	"The timeout value can not be less than or equal to zero.", //td_alert_2
	"The timeout value can not be greater than 8760.", //td_alert_3
	"Dynamic DNS (DDNS)", //td_DDNSDDNS
	"Select Dynamic DNS Server", //tt_SelDynDns
	"Account Name must be valid", //_emailaccnameisblank
	"From email address should not be blank", //_blankfromemailaddr
	"To email address should not be blank", //_blanktomemailaddr
	"SMTP Server address should not be blank", //_blanksmtpmailaddr
	"The Email address \"' + from_addr + '\" is not valid.", //_badfromemailaddr
	"The Email address \"' + to_addr + '\" is not valid.", //_badtoemailaddr
	" The SMTP Server Address' + data.smtp_email_server_addr + ' is not valid.", //_invalidsmtpserveraddr
	" SMTP Server Address is not allowed", //_badsmtpserveraddr
	"Newer firmware version is available.", //tf_NFWA
	"The web session has timed out. Please re-login to access this page.", //tf_alert_1
	"Based on the result of checking online, the latest firmware version is:", //tf_LFWVis
	"Firmware update check is in progress.", //tf_FWCinP
	"Checking availability of new firmware", //tf_Ching_FW
	"Email notification is not enabled on Tools -> Email Settings page", //tf_EM_not
	"Latest Firmware Version", //tf_LFWV
	"Check Online Now for Latest Firmware Version", //tf_FWChNow
	"Firmware updates are released periodically to improve the functionality of your router and to add features. If you run into a problem with a specific feature of the router, check our support site by clicking on the <strong>Check Online Now for Latest Firmware Version</strong> link and see if updated firmware is available for your router.", //TA17
	"Searching for Printers...", //tps_sfp
	"Double-click on an icon to install printer", //tps_dci
	"Print Server Setup", //tps_intro2
	"No day is selected for schedule name '+(data.sched_table[i].sched_name)+'", //tsc_alert_1
	"Invalid Time", //tsc_alert_2
	"\"The schedule name '\"+(data.sched_table[i].sched_name)+\"' is reserved and can not be used\"", //tsc_alert_3
	"This schedule is already used", //tsc_alert_6
	"There is no room for any more entries", //tsc_alert_9
	"Select Day(s)", //tsc_SelDays
	"Time Frame", //tsc_TimeFr
	"Syslog server IP address should not be same as Gateway IP address", //tsl_alert_3
	"Syslog server IP address is in WAN subnet, it should be within LAN subnet (+lan_subnet+)", //tsl_alert_1
	"Syslog server IP address should be within LAN subnet (+lan_subnet+)", //tsl_alert_2
	"Once your router is configured the way you want it, you can save the configuration settings to a configuration file.", //ZM18
	"milliseconds. TTL =", //tsc_pingt_msg9
	"NTP", //help635
	"Gateway Time has been updated", //tt_alert_tupdt
	"Week", //TA24
	"Day of Week", //TA25
	"Forbidden Access", //fb_FbAc
	"Sentinel Blocked Web Access", //sentinel_1
	"Access to this Web site has been blocked on this computer by your router's Sentinel Service.", //sentinel_2
	"Contact your Sentinel Service Administrator to enable access to this page.", //sentinal_3
	"Failure", //fl_Failure
	"The new settings have NOT been saved because an error occurred.", //fl_text
	"A new firmware update is available. You will be directed to the upgrade page upon login.", //li_newfw
	"You will now be redirected to the login page.", //rd_p_1
	"If the login page does not appear, click <a href=\"/login.asp\">this link</a>.", //rd_p_2
	"Restoring Settings", //rs_Restoring_Settings
	"The settings file is invalid.", //reh
	"Restoring Settings, Please Wait", //rs_RSPW
	"Converted local data", //rs_cld
	"Done", //rs_Done
	"Unpacked local data", //rs_uld
	"Unpacked saved data", //rs_usd
	"Converted saved data", //rs_csd
	"Repacked", //rs_Repacked
	"Converted", //rs_Converted
	"Saving", //rs_Saving
	"The router must be rebooted before the new settings will take effect. You can reboot the router now using the button below, or make other changes and then use the reboot button on the Tools/System page.", //sc_intro_rb
	"Re-login", //_relogin
	"Invalid WAN subnet mask.", //_badWANsub
	"Invalid Gateway IP address.", //wwa_pv5_alert_4
	"The gateway IP address is not in the WAN subnet", //wwa_pv5_alert_5
	"You must specify the primary DNS server", //wwa_pv5_alert_8
	"Invalid Primary DNS IP address.", //wwa_pv5_alert_6
	"Invalid Secondary DNS IP address.", //wwa_pv5_alert_7
	"The User Name field can not be blank", //wwa_pv5_alert_21
	"Invalid PPTP gateway IP address", //_badPPTPgwip
	"Invalid PPTP Server address", //wwa_pv5_alert_15
	"Invalid L2TP gateway IP address", //_badL2TPgwip
	"Invalid L2TP Server address", //wwa_pv5_alert_20
	"In order to protect your network from hackers and unauthorized users, it is highly recommended you choose one of the following wireless network security settings.", //wwl_intro_s3_1
	"There are three levels of wireless security -Good Security, Better Security, AND Best Security. The level you choose depends on the security features your wireless adapters support.", //wwl_intro_s3_2r
	"Wireless Security Password", //wwl_WSP_1
	"WPA-PSK/TKIP (also known as WPA Personal)", //wwl_wpa
	"WPA2-PSK/AES (also known as WPA2 Personal)", //wwl_wpa2
	"TELNET", //gw_vs_0
	"REMOTE DESKTOP", //gw_vs_8
	"AIM Talk", //gw_sa_0
	"Calista IP phone", //gw_sa_2
	"ICQ", //gw_sa_3
	"MSN Messenger", //gw_sa_4
	"PalTalk", //YM47
	"Select BigPond Server", //gw_SelBPS
	"Name1", //gw_bp_0
	"Name2", //gw_bp_1
	"Name3", //gw_bp_2
	"PlayStation2", //gw_gm_81
	"WCN ActiveX control is not available. Please check the security setting and refresh this page to install it.", //gw_wcn_alert_4
	"WCN does not support key index other than 1 now.", //gw_wcn_alert5
	"WCN does not support WPA2 mode now.", //gw_wcn_alert6
	"WCN does not support WPA enterprise authentication now.", //gw_wcn_alert7
	"Wireless settings saved successfully", //gw_wcn_err_ok
	"Error code:", //gw_wcn_err_code
	"This version of the operation system does not support WCN", //gw_wcn_err_os_version
	"Loading the Wireless Configuration file failed. Please run Windows Wireless Network Setup Wizard to create/re-create the configuration file", //gw_wcn_err_load_config
	"Failed to add the wireless profile. Please make sure that the new SSID does not conflict with an existing profile", //gw_wcn_err_provision
	"Failed to write wireless data in to configuration file. Please check the security setting", //gw_wcn_err_io_write_config
	"Failed to encrypt wireless data.", //gw_wcn_err_encryption
	"Internal exception occured", //gw_wcn_err_exception
	"WCN ActiveX control is not registered. Please check the security setting and refresh this page to install it.", //gw_wcn_err_com
	"Invalid wireless settings. Please check wireless settings", //gw_wcn_err_bad_wsetting_entry
	"Cannot create the wirless profile XML file", //gw_wcn_err_bad_wps_profile
	"WPA security mode is not enabled. Please check WPA security settings", //gw_wcn_err_unsupported_wsetting
	"MSXML2 DOM parser failed to parse the string in XML format", //gw_wcn_err_dom_processing
	"Unexpected error", //gw_wcn_err_default
	"Everyone allowed", //adv_Everyone
	"No one allowed", //adv_Noone
	"Queued", //psQueued
	"Starting", //psStarting
	"Closed", //psClosed
	"Idle", //psIdle
	"Ready", //psReady
	"Offer received for %s PPPoE Session, service offered is %s from %s (%m)", //GW_PPPOE_EVENT_OFFER
	"Unplugged", //psUnplugged
	"Printing", //psPrinting
	"PAP sent authentication \"%s\" response to remote peer.", //IPPPPPAP_AUTH_RESULT
	"'The string \"' + value + '\" is too long\n(maximum length is ' + length + ' characters).'", //up_gS_1
	"The number ' + value + ' is not valid.", //up_gIUH_1
	"The number ' + value + ' must be positive.", //up_gIUH_2
	"The number ' + value + ' should be in between '+ min + ' to ' + max + '.", //up_gIUH_3
	"The hex string ' + value + ' is not valid.", //up_gH_1
	"There is no room for any more entries.", //up_ae_se_1
	"The '%s' field can not be blank", //up_ai_se_2
	"this.primary_key_name+'+ this.thearray[-1][this.primary_key] +' is already used", //up_ae_se_3
	"You have unsaved changes in the entry you are editing.", //up_ae_wic_1
	"Press \"Ok\" to abandon these changes and perform the requested action.", //up_ae_wic_2
	"Note:<br />When DNS Relay is enabled along with Advanced DNS feature, your workstations on the network that are obtaining an IP address from router's DHCP server will obtain 192.168.0.1 (router's IP address). However, traffic will still be protected.", //_Advanced_02
	"Do you want to abandon all changes you made to this page?", //up_fm_dc_1
	"The restoration of settings failed", //up_fm_re_1
	"Press OK to continue", //up_fm_re_2
	"bad settings file", //up_fm_dr_1
	"Bad settings file", //up_fm_dr_2
	"Restored data not acceptable", //up_fm_dr_3
	"The action can not complete because the network connection seems to be down", //up_if_1
	"Rebooting.", //up_rb_3
	"Resetting to factory defaults and rebooting.", //up_rb_6
	"\"The \"+name+\" port range string '\"+input_string+\"' is invalid.\"", //up_vp_1
	"\"The \"+name+\" port '\"+n+\"' in the port range string '\"+input_string+\"' should be in between 1 to 65535.\"", //up_vp_2
	"\"The \"+name+\" port range'\"+got2[0]+\"' in the port range string '\"+input_string+\"' should go from low port to high port.\"", //up_vp_3
	"\"The \"+name+\" port range string can't be empty.\"", //up_vp_0
	"A MAC address field can not be empty.", //up_vm_1
	"input_string+\" is not a valid MAC address\"", //up_vm_2
	"An error occurred on this page. This might be because you are\n+ \not properly logged in, for example just after a reboot.\n", //up_he_1
	"Press OK to go to the login page, or Cancel if you want to see\n+ the error message.", //up_he_2
	"\"The error on line \"+line+\" of \"+url+\" is:\n\"\"+msg+\"\".\"", //up_he_5
	"PalTalk", //gw_sa_5
	"Blocked packet from %v to %v that was received from the wrong network interface (IP address spoofing)", //IPSTACK_REJECTED_SPOOFED_PACKET
	"Lease assignment attempt fail - detected a LAN host active with address %v and MAC of %m", //IPDHCPSERVER_HOST_IS_ACTIVE
	"%S service authorization failed: service is unregistered", //BSECURE_LOG_AUTH_FAIL_UNREG
	"Estimated rate of link is %d kbps", //RATE_ESTIMATOR_RATE_IS
	"Filter - Denied packet from IP address %v port %u, protocol %u, to %v port %u", //GW_IPFILTER_DENY
	"Unable to create connection to email server", //GW_SMTP_EMAIL_CANNOT_CREATE_CONNECTION
	"Dropped packet to illegal destination %v from %v", //IPNAT_ILLEGAL_DEST
	"%S filter server disconnected timeout", //BSECURE_LOG_FLTR_DISCONNECTED_TIMEOUT
	"The client %02x%02x%02x%02x%02x%02x had its lease (%v) revoked.", //IPDHCPSERVER_LEASE_REVOKED1
	"Previous message repeated 1 time", //LOG_PREV_MSG_REPEATED_1_TIME
	"UPnP changed VS entry %v <-> %v:%d <-> %v:%d %s to %s", //GW_UPNP_PORTMAP_VS_CHANGE
	"Lease expired %v", //IPDHCPSERVER_LEASE_EXPIRED
	"%S service authorization failed: internal error", //BSECURE_LOG_AUTH_FAIL_INTNL
	"UPnP deleted entry %v <-> %v:%d %s", //GW_UPNP_PORTMAP_DEL
	"Unable to send email as \"%s\" is not a valid \"To:\" address", //GW_SMTP_EMAIL_INVALID_TO_ADDRESS
	"%S filter server disconnected closed", //BSECURE_LOG_FLTR_DISCONNECTED_CLOSED
	"Lease expired %v - was reassigned because a client specifically requested this address", //IPDHCPSERVER_LEASE_EXPIRED_SPECIFIC
	"%S service authorization passed", //BSECURE_LOG_AUTH_PASS
	"%S service authorization failed: auth server returned UNKNOWN error", //BSECURE_LOG_AUTH_FAIL_UNKNW
	"PAP only", //wwan_auth_pap
	"%S service authorization failed: service needs renewal", //BSECURE_LOG_AUTH_FAIL_RENEW
	"Client %m wanted specific address (%v) but it is not available", //IPDHCPSERVER_LEASE_DENIED
	"Unable to send email (connection timed out)", //GW_SMTP_EMAIL_TIMEOUT
	"%S service authorization failed: auth server returned DB error", //BSECURE_LOG_AUTH_FAIL_DB
	"DHCP Server Parameter %u was updated", //IPDHCPSERVER_PARAM_DB_UPDATED
	"Application Rules", //APP_RULES
	"Lease table full", //IPDHCPSERVER_LEASE_POOL_FULL
	"PAP authentication successful.", //IPPPPPAP_AUTH_SUCCESS
	"Advanced Networks", //ADVANCED_NETWORKS
	"Assigned new lease %v to client %m", //IPDHCPSERVER_LEASE_ASSIGNED
	"%S filter server connected", //BSECURE_LOG_FLTR_CONNECTED
	"%S auth server connected", //BSECURE_LOG_AUTH_CONNECTED
	"%S service authorization failed: auth response packet corrupted", //BSECURE_LOG_AUTH_FAIL_PKT
	"SMTP client failed to connect to server %v", //IPSMTPCLIENT_CONN_FAILED
	"PAP authentication failed - please check login details.", //IPPPPPAP_AUTH_FAIL
	"Latest firmware version retrieved from the server was %d.%d", //GW_LOG_ON_LATEST_FIRMWARE_RETRIEVED
	"Unable to send email (send status %u)", //GW_SMTP_EMAIL_SEND_FAILURE
	"Lease %v released by client %m", //IPDHCPSERVER_LEASE_RELEASED
	"DHCP Server Parameter %u was added to the parameter database", //IPDHCPSERVER_PARAM_DB_ADDED
	"PAP authentication timed out - authentication failed.", //IPPPPPAP_AUTH_TIMEOUT
	"UPnP added entry %v <-> %v%d <-> %v%d %s timeout%d '%s'", //GW_UPNP_PORTMAP_ADD
	"Unable to send email as server IP address is not known", //GW_SMTP_EMAIL_NO_SERVER_IP_ADDRESS
	"UPnP renew entry %v <-> %v:%d <-> %v:%d %s timeout:%d '%s'", //GW_UPNP_PORTMAP_REFRESH
	"UPnP expired entry %v <-> %v:%d <-> %v%d %s '%s'", //GW_UPNP_PORTMAP_EXPIRE
	"DHCP Server Parameter %u was removed from the parameter database", //IPDHCPSERVER_PARAM_DB_REMOVED
	"Lease was deleted from server pool %v", //IPDHCPSERVER_LEASE_DELETED
	"UPnP conflict with existing entry %v <-> %v:%d <-> %v:%d %S '%s'", //GW_UPNP_PORTMAP_CONFLICT
	"Not all of the needed components have been loaded; this page will refresh.", //TA1
	"is not a valid IP address", //aa_alert_11
	"This Access Control rule is already defined by the Policy  + data.access_ctrl_table[i].policy_name", //aa_alert_1
	"There are ' + unsaved_policies + ' unsaved policies, do you want to abandon these policies.", //aa_sched_conf_3
	"'The Port Filter rule \"' + data.access_ctrl_table[-1].port_filter_table[i].entry_name + '\" is duplicated.'", //aa_alert_16
	"Destination IP Start address for Port Filter = '+data.access_ctrl_table[-1].port_filter_table[j].entry_name+' should not be in LAN subnet ('+lan_subnet+')", //aa_alert_2
	"Destination IP End address for Port Filter = '+data.access_ctrl_table[-1].port_filter_table[j].entry_name+' should not be in LAN subnet ('+lan_subnet+')", //aa_alert_3
	"Invalid destination IP address range for Port Filter = '+data.access_ctrl_table[-1].port_filter_table[j].entry_name+'", //aa_alert_4
	"Invalid destination port range for Port Filter = '+data.access_ctrl_table[-1].port_filter_table[j].entry_name+' should be in range (1..65535)", //aa_alert_5
	"Destination start port for Port Filter = '+data.access_ctrl_table[-1].port_filter_table[j].entry_name+' should not be greater than destination end port", //aa_alert_6
	"Other Machines", //_aa_other_machines
	"&copy; Copyright 2015 TRENDnet. All Rights Reserved.", //_copyright
	"The valid range for fragmentation threshold is 256..65535", //aw_alert_1
	"The valid range for RTS threshold is 1..65535", //aw_alert_2
	"The valid range for beacon period is 20..1000", //aw_alert_3
	"The valid range for DTIM interval is 1..255", //aw_alert_4
	"DMZ address should be within LAN subnet (+lan_subnet+')", //af_alert_1
	"DMZ Address is not allowed", //af_alert_2
	"(automatically disabled if UPnP is enabled)", //TA19
	"This '+ data.game_rules[j].entry_name + ' record is already present.", //ag_alert_4
	"This '+ data.game_rules[j].entry_name + ' record is duplicate of '' + data.game_rules[i].entry_name + ''.", //ag_alert_5
	"'TCP ports ['+data.game_rules[i].tcp_ports_to_open+'] conflicts with '+data.game_rules[j].entry_name+' TCP ports ['+data.game_rules[j].tcp_ports_to_open+']'", //ag_conflict10
	"'UDP ports ['+data.game_rules[i].udp_ports_to_open+'] conflicts with '+data.game_rules[j].entry_name+' UDP ports ['+data.game_rules[j].udp_ports_to_open+']'", //ag_conflict20
	"Please select a schedule for record ' + data.game_rules[i].entry_name + ''.'", //ag_conflict21
	"IP address for '+data.game_rules[i].entry_name+'' should be within LAN subnet ('+lan_subnet+')'", //ag_alert_1
	"IP Address for '+data.game_rules[i].entry_name+'' is not allowed'", //ag_alert_3
	"Both 'TCP Ports to Open' and 'UDP Ports to Open' fields can not be blank", //ag_alert2
	"TCP ports", //_tcpports
	"UDP ports", //_udpports
	"%s ports[%s] conflicts with Remote Management Port", //ag_conflict4
	"You can not change name of this entry because it is used on the '+used_page+' page.", //tsc_alert_7
	"Invalid source IP Range for '+data.ingress_rules[i].ingress_filter_name+'+' ('+data.ingress_rules[i].ip_range_table[j].ip_start+', +data.ingress_rules[i].ip_range_table[j].ip_end+)'", //ai_alert_3
	"Enable at least one Source IP Range for '%s'", //GW_FIREWALL_NO_IP_RANGE_INVALID
	"The inbound filter range '%s - %s' is duplicated.", //ai_alert_7
	"The inbound filter name '+(data.ingress_rules[i].ingress_filter_name)+'' is reserved and can not be used'", //ai_alert_4
	"'The inbound filter rule \"' + data.ingress_rules[-1].ingress_filter_name + '\" is duplicated.'", //ai_alert_6
	"You can not delete this entry because it is used on the +x+ page.", //tsc_alert_5
	"Inbound Filter Rules", //ai_title_2
	"Edit", //_edit
	"Source IP Range", //_srcip
	"Source IP Start", //ai_c2
	"Source IP End", //ai_c3
	"'The \"' + saved_records[i].mac_addr + '\" MAC address is duplicate.'", //amaf_alert_1
	"Deny access to all except the machines in this list (subject to \"Filter Settings\"):", //am_cMT_deny
	"Allow access to all except the machines in this list (subject to \"Filter Settings\"):", //am_cMT_Allow
	"No routes information yet.", //_sr_nriy
	"This internal route is already used", //ar_alert_1
	"This Route is already Present", //ar_alert_2
	"Metric value should be in between (1..16).", //ar_alert_3
	"Next Hop not on the specified interface", //ar_alert_4
	"Invalid Netmask.", //ar_alert_5
	"The Routing option allows you to define fixed routes to defined destinations.", //ar_RoutI
	"Route", //ar_Route
	"Routes List", //ar_RoutesList
	"Delete", //_delete
	"Existing routes", //ar_ERTable
	"The Application Rules name ' + saved_records[i].entry_name + ' is duplicated.", //ag_alert_duplicate_name
	"The Application Rules name ' + saved_records[j].entry_name + ' is duplicate of ' + saved_records[i].entry_name + '", //ag_alert_duplicate
	"This Rule is already used", //ag_inuse
	"Trigger port range '+protocols[ae.thearray[-1].trigger_ports.protocol]+' ['+ae.thearray[-1].trigger_ports.port_range+'] conflicts with '+saved_records[i].entry_name+':'+protocols[saved_records[i].trigger_ports.protocol]+' ['+saved_records[i].trigger_ports.port_range+']'", //_specapps_alert_2
	"Trigger port range", //_specapps_tpr
	"Input port range", //_specapps_ipr
	"Special Applications Rule", //as_title_SAR
	"Trigger Port Range", //as_TPRange
	"ex.", //as_ex
	"Trigger Protocol", //as_TPR
	"Input Port Range", //as_IPR
	"Input Protocol", //as_IPrt
	"Max transmission rate should be between 8 kbps and 10 Mbps, inclusive.", //at_alert_1_1
	"'Name can not be blank.'", //at_alert_15
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Priority '+data.qos_rules[i].priority+' should be between 1 and 255, inclusive.'", //at_alert_16
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Protocol can not be blank.'", //at_alert_17
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Source IP Range \"'+data.qos_rules[i].source_ip_start+'\" should be within LAN subnet ('+lan_subnet+').'", //at_alert_2
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Source IP Range \"'+data.qos_rules[i].source_ip_start+'\" is invalid.'", //at_alert_18
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Source IP Range \"'+data.qos_rules[i].source_ip_end+'\" should be within LAN subnet ('+lan_subnet+').'", //at_alert_3
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Source IP Range \"'+data.qos_rules[i].source_ip_end+'\" is invalid.'", //at_alert_19
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Source IP Range is invalid.'", //at_alert_4
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Destination IP Range \"'+data.qos_rules[i].dest_ip_start+'\" should not be within LAN subnet ('+lan_subnet+').'", //at_alert_5
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Destination IP Range \"'+data.qos_rules[i].dest_ip_start+'\" is invalid.'", //at_alert_20
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Destination IP Range \"'+data.qos_rules[i].dest_ip_end+'\" should not be within LAN subnet ('+lan_subnet+').'", //at_alert_6
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Destination IP Range \"'+data.qos_rules[i].dest_ip_end+'\" is invalid.'", //at_alert_21
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Destination IP Range is invalid.'", //at_alert_8
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Source Port Range should be between 0 and 65535, inclusive.'", //at_alert_7
	"'Source Port start for rule \"'+data.qos_rules[i].entry_name+'\" should be less than Source Port end.'", //at_alert_10
	"'Rule \"'+data.qos_rules[i].entry_name+'\" Destination Port Range should be between 0 and 65535, inclusive.'", //at_alert_9
	"'Destination Port start for rule \"'+data.qos_rules[i].entry_name+'\" should be less than Destination Port end.'", //at_alert_11
	"Name ''+data.qos_rules[i].entry_name+'' is already used.'", //at_alert_22
	"'Source/Destination IP Range for \"'+data.qos_rules[j].entry_name+'\" is overlapped with \"'+data.qos_rules[i].entry_name+'\".'", //at_alert_23
	"'Source/Destination IP/Port Range for \"'+data.qos_rules[j].entry_name+'\" is overlapped with \"'+data.qos_rules[i].entry_name+'\".'", //at_alert_24
	"'Protocol \"ANY\" includes ICMP so port ranges are disabled. Select TCP or UDP if you want to configure port ranges.'", //at_alert_14
	"ANY", //at_Prot_0
	"Source Port Range", //_srcport
	"Destination IP Range", //at_DIPR
	"Destination Port Range", //at_DPR
	"The record ' + data.virtual_servers[i].entry_name + ' is duplicated.", //av_alert_11
	"The record ' + data.virtual_servers[j].entry_name + ' is duplicate of ' + data.virtual_servers[i].entry_name + '.", //av_alert_21
	"Please select a schedule for record ' + data.virtual_servers[i].entry_name + '.", //av_alert_24
	"IP address for ' + data.virtual_servers[i].entry_name + ' should be within LAN subnet ('+lan_subnet+')", //av_alert_1
	"IP address for ' + data.virtual_servers[i].entry_name + ' is not allowed", //av_alert_2
	"Private port for ' + data.virtual_servers[i].entry_name + ' should be in range (1..65535)", //av_alert_3
	"Public port for ' + data.virtual_servers[i].entry_name + ' should be in range (1..65535)", //av_alert_4
	"Public port should not be same as Remote Management Port", //av_alert_12
	"Cannot create an entry for ICMP (protocol 1) as this will prevent the router from working correctly", //av_alert_18
	"Cannot create an entry for IGMP (protocol 2) as this will prevent the router from working correctly", //av_alert_23
	"Please select TCP instead of protocol 6 and specify port details", //av_alert_19
	"Please select UDP instead of protocol 17 and specify port details", //av_alert_20
	"Other protocol for ' + data.virtual_servers[i].entry_name + ' should be in range (3..5, 7..16 or 18..255)", //av_alert_13
	"Protocol for ' + data.virtual_servers[i].entry_name + ' is overlapped with ' + data.virtual_servers[j].entry_name+'", //av_alert_17
	"Ports for ' + data.virtual_servers[i].entry_name + ' are overlapped with ' + data.virtual_servers[j].entry_name+'", //av_alert_5
	"Private Port for '\" + data.virtual_servers[i].entry_name + \"' conflicts with '\" + data.virtual_servers[j].entry_name+\"'", //av_alert_6
	"FTP ALG has been enabled", //av_alert_7
	"PPTP ALG has been enabled", //av_alert_8
	"Wake-On-LAN ALG has been enabled", //av_alert_9
	"H.323 ALG has been enabled", //av_alert_10
	"Public", //_public
	"Other", //at_Prot__1
	"Private", //_private
	"Web Site", //aa_WebSite
	"https is not a supported protocol.", //awf_alert_4
	"The web site address '%s' already used.", //awf_alert_5
	"The web site addresses ' + invalid_wf_str + ' are invalid.", //awf_alert_7
	"The web site address ' + invalid_wf_str + ' is invalid.", //awf_alert_8
	"Internet Connection Wizard", //int_ConWz2
	"Manual Internet Connection Options", //int_WlsWz
	"If you are new to networking and have never configured a router before, click on <strong>Setup Wizard</strong> and the router will guide you through a few simple steps to get your network up and running.", //hhbi_wiz
	"If you consider yourself an advanced user and have configured a router before, click <strong>Manual Configure</strong> to input all the settings manually.", //hhbi_man
	"No dynamic clients detected yet.", //bd_noneyet
	"The lease has been revoked", //bd_revoked
	"Invalid LAN IP address", //bln_alert_3
	"LAN subnet conflicts with WAN subnet", //bd_alert_10
	"The DHCP address range TO is not in the LAN subnet.", //bd_alert_11
	"The DHCP FROM address does not contain a valid host starting value.", //bd_alert_1
	"The DHCP address range should go from a low address to a high address, not high to low", //bd_alert_3
	"The DHCP address range must not include the subnet broadcast address.", //bd_alert_13
	"The number of IP addresses in the range exceeds a limit of 256.", //bd_alert_12
	"DHCP Lease Time can not be 0", //bd_alert_5
	"Reserved IP address for this MAC address ('+ae.thearray[-1].mac_addr+') is already set", //bd_alert_6
	"Reserved IP address for this Computer Name ('+ae.thearray[-1].comp_name+') is already set", //bd_alert_7
	"A reservation cannot be the same as the configured LAN IP Address.", //TA20
	"Reserved IP address should be within the configured DHCP range.", //bd_alert_8
	"Must specify primary DNS server before supplying a secondary DNS server", //bd_alert_22
	"Invalid Primary dns IP address", //bd_alert_23
	"Invalid Secondary dns IP address", //bd_alert_24
	"Invalid WAN IP address", //_badWANIP
	"Invalid WAN subnet mask", //bwn_alert_2
	"The default gateway address is not in the WAN subnet", //bwn_alert_3
	"DNS are not configured. The clients will not be able to resolve domain names. Proceed ?", //bwn_alert_4
	"WAN subnet conflicts with LAN subnet", //bwn_alert_5
	"Please enter a Trigger Port number", //MSG000
	"The maximum idle time should be in the range 0..600", //bwn_alert_8
	"Invalid PPPoE IP address", //bwn_alert_12
	"Invalid PPTP IP address", //_badPPTPip
	"Invalid PPTP subnet mask", //_badPPTPsub
	"The PPTP gateway IP address is not in the PPTP subnet", //_badPPTPipsub
	"Invalid PPTP server IP address", //bwn_alert_11
	"Invalid L2TP address", //_badL2TP3
	"Invalid L2TP subnet mask", //_badL2TP
	"The L2TP gateway IP address is not in the L2TP subnet", //_badL2TP2
	"Invalid L2TP server IP address", //bwn_alert_17
	"The MTU should be in the range 128..30000", //bwn_alert_21
	"WEP Keys '+ wep_error_msg + ' are invalid.", //bws_alert_15
	"WEP Key '+ wep_error_msg + ' is invalid.", //bws_alert_16
	"Can not use 802.11b/g channel when the 802.11 mode is 802.11a", //bwl_alert_2
	"Can not use 802.11a channel when the 802.11 mode is 802.11b/g", //bwl_alert_3
	" RADIUS server Port field can not be blank.", //bwl_alert_15
	" RADIUS server Port ' + data.wireless.radius_server_port + ' should be in range (1..65535).", //bwl_alert_16
	"Can not use 802.11b transmit rates when the PHY mode is 802.11a", //bwl_alert_4
	"Can not use 802.11a/g transmit rates when the PHY mode is 802.11b", //bwl_alert_5
	"Static Turbo mode is not allowed with 802.11b", //bwl_alert_6
	"Dynamic Turbo mode is not allowed with 802.11b", //bwl_alert_7
	"For 11g Turbo mode, the channel should be set to 6", //bwl_alert_8
	"For 11a Static Turbo, channel should be set to one of 42,50,58,152, or 160.", //bwl_alert_9
	"For 11a Dynamic Turbo, channel should be set to one of 40,48,56,153 or 161.", //bwl_alert_10
	"Incorrect key length, should be 8 to 63 character long.", //bws_alert_2
	"WPA Group Key Update Interval should be between 30 and 65535 seconds.", //bwl_alert_11
	"IEEE 802.1X Authentication Timeout should be between 1 and 65535 minutes", //bwl_alert_12
	"WEP key' +(i+1)+' must be '+len+' characters long", //bws_alert_3
	"Uncheck \"Auto Channel Select\" for WDS mode.", //aw_alert_5_1
	"The IP address ' + data.wireless.radius_server_address + ' is not valid.", //bwl_alert_13
	"The IP address ' + data.wireless.second_radius_server_address + ' is not valid.", //bwl_alert_14
	"802.11g only", //bwl_Mode_2
	"Mixed 802.11g and 802.11b", //bwl_Mode_3
	"802.11b only", //bwl_Mode_1
	"802.11n only", //bwl_Mode_8
	"Mixed 802.11n, 802.11g and 802.11b", //bwl_Mode_11
	"20 MHz", //bwl_ht20
	"Auto 20/40 MHz", //bwl_ht2040
	"Best (automatic)", //bwl_TxR_0
	"Changing your Wireless Network Name is the first step in securing your wireless network. Change it to a familiar name that does not contain any personal information.", //TA9
	"Enable Auto Channel Scan so that the router can select the best possible channel for your wireless network to operate on.", //YM124
	"Setting Visibility Status to Invisible is another way to secure your network. With visibility disabled, no wireless clients will be able to see your wireless network when they scan to see what's available. For your wireless devices to connect to your router, you will need to manually enter the Wireless Network Name on each device.", //TA12
	"If you have enabled Wireless Security, make sure you write down the Passphrase that you have configured.", //TA14
	"You will need to enter this information on any wireless device that you connect to your wireless network.", //TA15
	"Wizard", //_wizard
	"Launch Internet Connection Setup Wizard", //bwz_LConWz
	"Wireless Security Setup Wizard", //bwz_WlsWz
	"The following Web-based Setup Wizard is designed to assist you in your wireless network setup. This Setup Wizard will guide you through step-by-step instructions on how to set up your wireless network and how to make it secure.", //bwz_intro_WlsWz
	"Launch Wireless Security Setup Wizard", //bwz_LWlsWz
	"Special Applications", //_specapps
	"Gaming", //_gaming
	"Basic", //_basic
	"The rule name can not be empty.", //ag_alert_empty_name
	"The rule name ' + data.game_rules[j].entry_name + '' is duplicated.'", //ag_alert_duplicate_name2
	"'MAC Address Filter allows no machines. This is not allowed because it locks out all machines.'", //amaf_alert_2
	"The rule name ' + saved_records[i].entry_name + '' is duplicated.'", //specapps_alert_duplicate_name
	"\"The rule '\" + saved_records[j].entry_name + \"' is duplicate of '\" + saved_records[i].entry_name + \"'.\"", //specapps_alert_duplicate1
	"Trigger port range of '+saved_records[i].entry_name+'' '+protocols[saved_records[i].trigger_ports.protocol]+' ['+saved_records[i].trigger_ports.port_range+'] conflicts with ''+saved_records[j].entry_name+'' '+protocols[saved_records[j].trigger_ports.protocol]+' ['+saved_records[j].trigger_ports.port_range+'].'", //specapps_alert_conflict1
	"Please select a schedule for rule ' + data.port_trigger_rules[i].entry_name + ''.'", //specapps_alert_empty_schedule
	"Traffic Shaping Setup", //at_title_TSSet
	"Protocol \" + entry_1.user_protocol + \" of '\" + entry_1.entry_name + \"' conflicts with '\" + entry_2.entry_name + \"'", //av_alert_35
	"The 'Name' field can not be blank", //av_alert_empty_name
	"Name '%s' is already used", //av_alert_16
	"Primary WINS IP address must be specified.", //bln_alert_lannbpri
	"Secondary WINS IP address is invalid.", //bln_alert_lannbsec
	"Primary DNS", //lan_dns
	"Secondary DNS", //lan_dns2
	"Hybrid (Point-to-Point then Broadcast)", //bln_NetBIOSReg_H
	"Mixed-mode (Broadcast then Point-to-Point)", //bln_NetBIOSReg_M
	"Point-to-Point (no broadcast)", //bln_NetBIOSReg_P
	"Broadcast only (use when no WINS servers configured)", //bln_NetBIOSReg_B
	"Help", //_help
	"When this option is enabled, the router restricts the flow of outbound traffic so as not to exceed the WAN uplink bandwidth.", //help81ets
	"The NAT Endpoint Filtering options control how the router's NAT manages incoming connection requests to ports that are already being used.", //af_EFT_h4
	"Once a LAN-side application has created a connection through a specific port, the NAT will forward any incoming connection requests with the same port to the LAN-side application regardless of their origin. This is the least restrictive option, giving the best connectivity and allowing some applications (P2P applications in particular) to behave almost as if they are directly connected to the Internet.", //YM134
	"The NAT forwards incoming connection requests to a LAN-side host only when they come from the same IP address with which a connection was established. This allows the remote application to send data back through a port different from the one used when the outgoing session was created.", //af_EFT_h1
	"The NAT does not forward any incoming connection requests with the same port address as an already establish connection.", //af_EFT_h2
	"Note that some of these options can interact with other port restrictions. Endpoint Independent Filtering takes priority over inbound filters or schedules, so it is possible for an incoming session request related to an outgoing session to enter through a port in spite of an active inbound filter on that port. However, packets will be rejected as expected when sent to blocked ports (whether blocked by schedule or by inbound filter) for which there are no active sessions. Port and Address Restricted Filtering ensures that inbound filters and schedules work precisely, but prevents some level of connectivity, and therefore might require the use of port triggers, virtual servers, or port forwarding to open the ports needed by the application. Address Restricted Filtering gives a compromise position, which avoids problems when communicating with certain other types of NAT router (symmetric NATs in particular) but leaves inbound filters and scheduled access working as expected.", //af_EFT_h5
	"Controls endpoint filtering for packets of the UDP protocol.", //af_UEFT_h1
	"Controls endpoint filtering for packets of the TCP protocol.", //af_TEFT_h2
	"The subnet mask of the local area network.", //help309A
	"NetBIOS allow LAN hosts to discover all other computers within the network, e.g. within Network Neighbourhood.", //help400_1
	"Turn this setting off to configure manually.", //help401_1
	"WINS Servers store information regarding network hosts, allowing hosts to \"register\" themselves as well as discover other available hosts, e.g. for use in Network Neighbourhood.", //help402_1
	"This setting has no effect if the \"Learn NetBIOS information from WAN\" is activated.", //help402_2
	"H-Node, this indicates a Hybrid-State of operation. First WINS servers are tried, if any, followed by local network broadcast. This is generally the preferred mode if you have configured WINS servers.", //help405_1
	"M-Node (default), this indicates a Mixed-Mode of operation. First Broadcast operation is performed to register hosts and discover other hosts, if broadcast operation fails, WINS servers are tried, if any. This mode favours broadcast operation which may be preferred if WINS servers are reachable by a slow network link and the majority of network services such as servers and printers are local to the LAN.", //help405_2
	"P-Node, this indicates to use WINS servers ONLY. This setting is useful to force all NetBIOS operation to the configured WINS servers. You must have configured at least the primary WINS server IP to point to a working WINS server.", //help405_3
	"B-Node, this indicates to use local network broadcast ONLY. This setting is useful where there are no WINS servers available, however, it is preferred you try M-Node operation first.", //help405_4
	" Incorrectly configured - check logs", //_sdi_s1a
	"Invalid secure remote management port '+data.web_server_wan_port_https+', should be in range (1..65535)", //ta_alert_3b
	"Secure remote management port and remote management port may not be the same.", //ta_alert_3c
	"You must enable one method of management.", //ta_alert_3d
	"Invalid management port '+data.web_server_lan_port_http+', should be in range (1..65535)", //ta_alert_3e
	"Invalid secure management port '+data.web_server_lan_port_https+', should be in range (1..65535)", //ta_alert_3f
	"Secure management port and management port may not be the same.", //ta_alert_3g
	"Enable LPD/LPR Printing", //tps_enlpd
	"Admin Port", //ta_LMAP
	"Failed Login", //fb_FailLogin
	"Access to this device is not allowed without a correct password.", //fb_FailLogin_1
	"Open", //_open
	"Other", //_other
	"Expire Time", //_223
	"The gateway address is not in the LAN subnet", //_225ap
	"IP address or subnet mask is badly formatted", //_226ap
	"This entry is optional. Enter a domain name for the local network. Your LAN computer will assume this domain name when it gets an address from the <span>rou</span><span>ter</span>'s built in DHCP server. So, for example, if you enter <code>mynetwork.net</code> here, and you have a LAN side laptop with a name of <code>chris</code>, that laptop will be known as <code>chris.mynetwork.net</code>.", //_1044wired
	"Note, however, the entered domain name can be overridden by the one obtained from the <span>rou</span><span>ter</span>'s upstream DHCP server.", //_1044awired
	"IPv6 address", //TEXT0
	"Regenerate", //regenerate
	"Advanced DNS Service", //_title_AdvDns
	"Advanced DNS is a free security option that provides Anti-Phishing to protect your Internet connection from fraud and navigation improvements such as auto-correction of common URL typos.", //_desc_AdvDns
	"Enable Advanced DNS Service", //ta_EUPNP_dns
	"Advanced DNS", //_st_AdvDns
	"Advanced DNS", //_sp_title_AdvDNS
	"When feature is enabled, your internet traffic will be protected by a security ready DNS server. This feature provides Anti-Phishing to protect your Internet connection from fraud and navigation improvements such as auto-correction of common URL typos.", //_sp_desc1_AdvDNS
	"Note:<br />When DNS Relay is enabled along with Advanced DNS feature, your workstations on the network that are obtaining an IP address from router’s DHCP server will obtain 192.168.0.1 (router’s IP address). However, traffic will still be protected.", //_sp_desc2_AdvDNS
	"Although Advanced DNS feature is enabled, DNS IP address of your workstation can still be modified to the DNS server IP you desire. Please note that the router does not dictate the DNS name resolution when DNS IP address is configured on the workstation.", //_sp_desc3_AdvDNS
	"If you selected this option and have VPN or Intranet setup in your network, you can disable Advanced DNS service if you experience connection difficulties.", //_sp_desc4_AdvDNS
	"The Key", //TEXT041_1
	" is invalid. The Key must be", //TEXT041_2
	" characters or", //TEXT041_3
	"hexadecimal number.", //TEXT041_4
	"The Key", //TEXT042_1
	" is wrong, the legal characters are 0~9, A~F, or a~f.", //TEXT042_2
	"Invalid URL.", //GW_URL_INVALID
	"Invalid NetBIOS Scope.", //GW_LAN_NETBIOS_SCOPE_INVALID
	"should be within the configured DHCP range.", //GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID_a
	"DHCP Plus", //bwn_Mode_DHCPPLUS
	"Net Sniper Supported", //net_sniper_support
	"Special dialing mode options", //SEL_DIAL_MODE
	"Normal dialing (default)", //pppoe_dialmode_normal
	"Special dialing 1", //pppoe_dialmode_sp1
	"Special dialing 2", //pppoe_dialmode_sp2
	"Special dialing 3", //pppoe_dialmode_sp3
	"Special dialing 4", //pppoe_dialmode_sp4
	"Special dialing 5", //pppoe_dialmode_sp5
	"Special dialing 6", //pppoe_dialmode_sp6
	"Learning Mode", //pppoe_dialmode_learn
	"Learning", //bt_learn_text
	"Anti-ARP Attack", //box_ip_mac_binding
	"Enable Advanced DNS Service", //_en_AdvDns
	"XKJS Supported", //xkjs_support
	"Service type", //ddns_serv_type
	"Domain", //ddns_domain
	"DDNS account test", //ddns_account
	"Invalid public port", //virtual_pub_port_err
	"Invalid private port", //virtual_pri_port_err
	"Invalid protocol number", //virtual_proto_num_err
	"Wi-Fi Protected Setup", //menu_wps
	"IP Range", //tc_iprange
	"Opening or closing TCP connections.", //help823_15
	"bandwidth(kbps)", //tc_bw
	"Schedule", //tc_schedule
	"New Schedule", //tc_new_sch
	"gaurantee minimum bandwidth", //tc_min_bw
	"gaurantee maximum bandwidth", //tc_max_bw
	"Admin", //_login_admin
	"User", //_login_user
	"PPPoE Plus Supported", //pppoe_plus_dail
	"Invalid DHCP+ username", //GW_WAN_DHCPPLUS_USERNAME_INVALID
	"Invalid DHCP+ password", //GW_WAN_DHCPPLUS_PASSWORD_INVALID
	"SMTP server port", //te_SMTPPort
	"Wireless Mode", //WLANMODE
	"Router Mode", //ROUTER_MODE
	"AP Mode", //AP_MODE
	"WDS+Router Mode", //WDSROUTER_MODE
	"WDS+AP Mode", //WDSAP_MODE
	"Bridge setting", //BR_SET
	"Device Mode", //device_mode
	"Router Mode", //router_mode
	"AP Mode", //ap_mode
	"Automatic", //auto_mode
	"WDS Enable", //enable_WDS
	"The router is detecting your Internet connection type. Please wait until the router provides suitable settings for your configuration.", //ES_AUTODECT
	"Phone Type", //_phone
	"If you don't want to connect to Internet, please click the button below.", //ES_CABLELOST_dsc2
	"I don't need to connect to Internet", //ES_DONT_CONN_btn
	"INTERNET CONFIGURATION UPDATED", //ES_UPDATE_SETTING_bnr
	"The router is detecting your Internet connection type and trying to connect to Internet.                                Please wait until the detection is completed.", //ES_UPDATE_SETTING_dsc
	"CONFIGURE YOUR INTERNET CONNECTION", //ES_CONFIG_INTERNET_bnr
	"It seems that your username and passoword are incorrect. Please check again and click \"Connect\"", //ES_CONFIG_INTERNET_dsc2
	"Internet Connection", //ES_INTERNET_CONN_dsc
	"(* is required field)", //ES_MUST_FIELD_dsc
	"DIAL-UP IS FAILED", //ES_DIALUP_ERROR_bnr
	"Please configure your WWAN settings.  If you are unsure of the settings, please contact your Internet Service Provider (ISP).", //usb_config1
	"Easy Setup", //ES_NAME
	"Please enter user name", //MSG011
	"What is this?", //ES_what_is_this
	"Primary DNS Server", //ES_PRI_DNS
	"Secondary DNS Server", //ES_SEC_DNS
	"Gateway Address", //ES_GW_ADDR
	"Subnet Mask", //ES_MASK
	"IP Address", //ES_IP_ADDR
	"EASY SETUP COMPLETE", //ES_complete
	"The Easy Setup process has successfully completed. Click the “Save” button for your settings to take effect. We recommend you check “Save the network settings” box to save your wireless network settings to your computer in case there are more PCs that need to connect to your router wirelessly.<br><br> After clicking the “Save” button, you need to provide your username and password to access the device when logging in next time.", //ES_save_dsc
	"Status", //ES_status
	"Connected", //ES_connected
	"Unconnected", //ES_unconnected
	"Wireless Settings", //ES_wlan_setting
	"Wireless Network Name (SSID)", //ES_wlan_ssid
	"Security", //ES_security
	"Unsecured", //ES_unsecured
	"Your current wireless security settings are not safe. We recommend you configure wireless settings.", //ES_unsecured_suggest
	"Save my network settings", //ES_save_mySetting
	"Set the password of the device to wireless network key", //ES_sync_pw
	"Save", //ES_save
	"Network Key", //ES_network_key
	"Auto generate network key", //ES_autogen_key
	"Disable Wireless Security (Not recommended)", //ES_disable_wifi_sec
	"AUTO-WPA/WPA2(Recommended)", //ES_wifi_sec_recomm
	"The current network settings and the connection status are displayed below. If you want to reconfigure your wireless settings, please click the “Configure” button. You can also enter advanced settings by clicking “Manual Setup”.", //ES_current_setting_dsc
	"CURRENT NETWORK SETTING", //ES_current_setting
	"Manual Setup", //ES_manual_btn
	"Cancel", //ES_cancel
	"Logout", //logout_caption
	"You have been logout.", //logout_desc
	"Return to login page.", //logout_return
	"Connected Time", //st_connected_time
	"Access Deny", //t_ctl_title
	"It is NOT allowed to access Internet currently. <br>Are you sure you want to use Emergency Internet Access?", //t_ctl_note
	"It is NOT allowed to access Internet currently. Pay attention to study please.", //t_ctl_note1
	"TRENDnet Wireless N Home Router", //page_title
	"Port range should be set between 1 and 65535.", //ac_alert_invalid_port
	"Duplicated name:", //ac_alert_dup_name
	"Port conflict.", //ac_alert_port_conflit
	"Policy cannot be null.", //ac_alert_policy_null
	"Please check the configured Server Address", //tt_alert_checkdyndns
	"The router can't access Internet with the current static IP setting.", //ES_static_no_internet
	"Unable to access Internet with the current configuration. Please check your setting!", //ES_static_no_internet_desc
	"This window will be closed. Are you sure?", //_CFM_close_window
	"SAVE CONFIGURATION RESULT", //ES_save_result
	"The configuration has been saved.", //ES_save_success
	"Confirm", //ES_confirm_bt
	"Time format", //sch_timeformat
	"12-hour", //sch_hourfmt_12
	"24-hour", //sch_hourfmt_24
	"This firmware is the latest version.", //no_available_update
	"Remove Language Pack", //clear_lang_pack
	"Current Language Pack Version", //current_lang_pack_version
	"Current Language Pack Date", //current_lang_pack_date
	"Language pack Upgrade", //lang_package_info
	"Upgrade language pack will change the language displayed on web site.", //lang_package_note1
	"To upgrade the language pack, locate the upgrade file on the local hard drive with Browse button. Once you have found the file to be used, click the Upload button to start the language pack upgrade.", //lang_package_note2
	"Latest Language Pack Version", //latest_lang_package_ver
	"Latest Language Pack Date", //latest_lang_package_date
	"There is no language pack.", //no_lang_pack
	"Port forward name cannot be empty.", //pf_name_empty
	"Virtual server name cannot be empty.", //vs_name_empty
	"Checksum error.", //fw_checksum_err
	"Bad hardware ID.", //fw_bad_hwid
	"Unknow file format.", //fw_unknow_file_format
	"Firmware upgrade success.", //fw_fw_upgrade_success
	"Language pack upgrade success.", //fw_lp_upgrade_success
	"Configuration upgrade success.", //fw_cfg_upgrade_success
	"Set Time Control", //ES_timectrl_bnr
	"Time Control", //ES_timectrl_btn
	"Web Control", //ES_webpolicy_btn
	"True Gigabit Routing Connectivity Setting", //HW_NAT_desc
	"Enable Traffic Shaping", //at_ETS
	"When True Gigabit Routing Connectivity is enabled, SPI and QoS engine will be disabled automatically. Would you like to proceed?", //alert_hw_nat_1
	"When QoS engine is enabled, True Gigabit Routing Connectivity will be disabled automatically. Would you like to proceed?", //alert_hw_nat_2
	"When SPI is enabled, True Gigabit Routing Connectivity will be disabled automatically. Would you like to proceed?", //alert_hw_nat_3
	"When this option is enabled, True Gigabit Routing Connectivity will be disabled automatically.", //help_auto_disable_hw_nat
	" and True Gigabit Routing Connectivity will be disabled automatically.", //help_auto_disable_hw_nat_1
	"True Gigabit Routing Connectivity:", //help_hw_nat
	"When this option is enabled, the router will speed up the NAT/Routing performance by hardware acceleration mechanism. The limitation is that both of SPI and QoS engine will be disabled automatically when True Gigabit Routing Connectivity is enabled.", //help_hw_nat_desc
	"Step 2: Configure your Wi-Fi Security", //ES_step_wifi_security
	"Please make the two user passwords the same and try again", //_pwsame_user
	"Try again", //ES_btn_try_again
	"Router is detecting your Internet connection type, please wait ...", //ES_auto_detect_desc
	"Router is unable to detect your Internet connection type", //ES_auto_detect_failed_desc
	"Guide me through the Internet connection settings", //ES_btn_guide_me
	"Save & Connect", //ES_btn_save_conn
	"Save", //ES_btn_save
	"IPv6 Routing", //v6_routing
	"IPv6 Routing Table", //v6_routing_table
	"The Routing Status menu shows information about the routes that have been enabled on your router. The list will display the destination IP address, gateway IP address, subnet mask, metric and interface for each route.", //v6_routing_info
	"IPv6", //ipv6
	"IPv6 FIREWALL", //ipv6_firewall
	"Remaining number of firewall rules that can be configured:", //ipv6_firewall_info
	"6RD SETTINGS", //_6rd_settings
	"IPv4 Address", //ipv4_addr
	"Mask Length", //mask_len
	"IPv6 ULA Settings", //IPV6_ULA_TEXT01
	"Enable True Gigabit Routing Connectivity", //HW_NAT_enable
	"Use default ULA prefix", //IPV6_ULA_TEXT03
	"ULA Prefix", //IPV6_ULA_TEXT04
	"Current IPv6 ULA Settings", //IPV6_ULA_TEXT05
	"Current ULA Prefix", //IPV6_ULA_TEXT06
	"LAN IPv6 ULA", //IPV6_ULA_TEXT07
	"LAN IPv6 Unique Local Address", //IPV6_ULA_TEXT08
	"Manual IPv6 Local Connectivity Setup", //IPV6_ULA_TEXT09
	"Use this section to configure Unique Local IPv6 Unicast Addresses(ULA) settings for your router. ULA is intended for local communications and not expected to be routable on the global Internet.", //IPV6_ULA_TEXT11
	"IPv6 Local Connectivity Settings", //IPV6_ULA_TEXT12
	"ULA is useful for Local IPv6 communications, if you would like to enable it, click <b>Enable ULA</b>. By default ULA is disabled.", //IPV6_ULA_TEXT13
	"IPv6 LOCAL CONNECTIVITY SETTINGS ", //IPV6_ULA_TEXT14
	"LAN IPv6 address for local IPv6 communicatoins.", //IPv6_Local_Info
	"IPv6 SIMPLE SECURITY", //IPv6_Simple_Security
	"Enable IPv6 Multicast Streams", //anet_multicast_enable_v6
	"Set up 6rd tunneling connection", //IPv6_Wizard_6rd_title
	"Firewall rule name cannot be empty.", //fr_name_empty
	"IPv6 routing name cannot be empty.", //r6_name_empty
	"Give your Wi-Fi network a name.", //wwz_wwl_intro_s2_1
	"Wi-Fi Network Name (SSID)", //wwz_wwl_intro_s2_1_1
	"(Using up to 32 characters)", //wwz_wwl_intro_s2_1_2
	"Give your Wi-Fi network a password.", //wwz_wwl_intro_s2_2
	"Wi-Fi Password", //wwz_wwl_intro_s2_2_1
	"(Between 8 and 63 characters)", //wwz_wwl_intro_s2_2_2
	"Step 3: Set your Password", //ES_title_s3
	"Step 4: Select your Time Zone", //ES_title_s4
	"Step 5: Save Settings", //ES_title_s5
	"802.11n only", //bwl_Mode_n
	"802.11a only", //bwl_Mode_a
	"Mixed 802.11n and 802.11a", //bwl_Mode_5
	"The schedule of Guest Zone must be within the schedule of main WLAN.", //MSG049
	"The GuestZone WLAN will be disabled when you turn off main WLAN. Are you sure to continue?", //MSG050
	"Hardware init error", //HWerr
	"Storage", //storage
	"Share Port Web Access allows you to use a web browser to access files stored on an USB storage drive plugged into the router. To use this feature, check the <strong>Enable SharePort Web Access</strong> checkbox, then create user accounts to manage access to your storage devices or use the Guest account (guest/guest) to access the Guest Folder. After plugging in an USB storage drive, the new device will appear in the list with a link to it. You can then use this link to connect to the drive and log in with a user account.", //sto_into
	"SHAREPORT WEB ACCESS", //sto_http_0
	"Enable WAN Ping Respond", //bwn_RPing
	"Enable Guest Zone", //guestzone_enable
	"HTTP Access Port", //sto_http_3
	"Enable HTTPS Server", //LV2
	"HTTPS Access Port", //sto_http_5
	"10 -- USER CREATION", //sto_creat
	"Add/Edit", //_add_edit
	"User List", //sto_list
	"Modify", //_modify
	"Access Path", //sto_path
	"Performance enhancing features such as Packet Bursting, FastFrames, and Compression.", //help361
	"NTP Server Used", //tt_NTPSrvU
	"Device", //sto_dev
	"Total Space", //_total_space
	"Free Space", //_free_space
	"SHAREPORT WEB ACCESS LINK", //sto_link_0
	"You can use this link to connect to the drive remotely after logging with a user account.", //sto_link_1
	"http://&lt;DDNS&gt; or&lt;WAN IP Address&gt;:8181", //sto_link_2
	"Email Now", //_email_now
	"The Storage page contains information about the USB storage drives or SD cards currently plugged in to the device.", //sto_help
	"Device Link", //_DevLink
	"Folder", //_folder
	"Browse", //_browse
	"Append", //_append
	"Remote Access Port & Remote HTTPS Port is Empty!!!", //sto_01
	"The confirmed password does not match the new User password", //sto_02
	"Read Only", //_readonly
	"Read/Write", //_readwrite
	"Append New Folder", //_AppendNewFolder
	"Please push button on your wireless device, then click on the Connect button below.", //KR45
	"This account has reached the maximum rule", //MSG052
	"This rule already exists", //MSG053
	"Can't find this rule, please press the Append button", //MSG054
	"Add New Folder", //_AddFolder
	"http://&lt;DDNS&gt; or &lt;WAN IP Address&gt;", //_StorageLink
	"Lock WPS-PIN Setup", //LW6_1
	"The maximum number of users", //MSG055
	"Step 5: Confirm WI-FI Settiongs", //ES_title_s5_0
	"Saving Settings", //save_settings
	"Your settings are being saved.", //save_wait
	"Language", //_Language
	"Adelphia Power Link", //manul_conn_01
	"ALLTEL DSL", //manul_conn_02
	"ATAT DSL Service", //manul_conn_03
	"Bell Sympatico", //manul_conn_04
	"Bellsouth", //manul_conn_05
	"Charter High-Speed", //manul_conn_06
	"Comcast", //manul_conn_07
	"Covad", //manul_conn_08
	"Cox Communications", //manul_conn_09
	"Earthlink Cable", //manul_conn_10
	"Earthlink DSL", //manul_conn_11
	"FrontierNet", //manul_conn_12
	"Opinion", //_aa_bsecure_opinion
	"RCN", //manul_conn_14
	"Road Runner", //manul_conn_15
	"Rogers Yahoo!", //manul_conn_16
	"SBC Yahoo! DSL", //manul_conn_17
	"Shaw", //manul_conn_18
	"Speakeasy", //manul_conn_19
	"Sprint FastConnect", //manul_conn_20
	"Telus", //manul_conn_21
	"Time Warner Cable", //manul_conn_22
	"US West / Qwest", //manul_conn_23
	"Verizon Online DSL", //manul_conn_24
	"XO Communications", //manul_conn_25
	"Manully set 5GHz band Network Name(SSID)", //manul_5g_ssid
	"The language pack allows you to change the language of the user interface on the ", //tf_intro_FWU4
	" We suggest that you upgrade your current language pack if you upgrade the firmware. This ensures that any changes in the firmware are displayed correctly.", //tf_intro_FWU5
	"Firmware update", //_firmwareUpdate
	"Date", //_date
	"Remove", //_remove
	"When you set security WEP, EAP, cipher type is TKIP or Visibility Status is Invisible, WPS will be disable.", //notify_wps
	"%s ports[%s] conflicts with other setting", //ag_conflict5
	"Disable", //_disable
	"HT 20/40 MHz Coexistence ", //coexi
	"Use the same Wireless Security Password on both 2.4GHz and 5GHz band", //wwl_SSP
	"Give your Wi-Fi network a name and  a password.", //wwz_wwl_intro_s0
	"This page displays your IPv6 internet and network connection details.", //STATUS_IPV6_DESC_0
	"IPv6 Connection Information", //STATUS_IPV6_DESC_1
	"The IPv6 address of the connected computer.", //STATUS_IPV6_DESC_6
	"The LAN IPv6 Link-Local Address.", //STATUS_IPV6_DESC_5
	"The MAC address of the connected computer.", //STATUS_IPV6_DESC_4
	"The type of IPv6 connection.", //STATUS_IPV6_DESC_3
	"The name of the connected computer.", //STATUS_IPV6_DESC_2
	"The QoS Engine feature helps improve your network performance by prioritizing applications.\" ;", //ag_conflict6
	"Rules", //TEXT008a
	"is setting same as Rules", //TEXT008b
	"Notice", //TEXT023
	"Mbps", //at_mbps
	"Invalid PIN format. Please follow this  0000 0000 or 0000-0000", //pin_f
	"Using WEP Encryption will be disabled the WPS, Are you sure?", //msg_eap
	"Open", //open
	"Please enter another Private Port number", //PRIVATE_PORT_ERROR
	"Folder can't be set as \"%s\"", //MSG056
	"You use the same account and password!", //MSG057
	"Destination IP", //_DestIP
	"Type", //_type
	"No internet detected, would you like to restart the wizard?", //mydlink_tx03
	"Checking WAN connectivity.", //mydlink_tx05
	"seconds left.", //sec_left
	"Please fill out the required fields and click \"Connect\"", //ES_CONN_dsc
	"Confirm Password", //chk_pass
	"Last name", //Lname
	"First Name", //Fname
	"Login", //_login
	"%s ports[%s] conflicts with Storage Remote Access Http Port", //ag_conflict22
	"%s ports[%s] conflicts with Storage Remote Access Https Port", //ag_conflict23
	"host wireless is disabled, can't enable guest zone wireless.", //wifi_enable_chk
	"The IPv6 Address cannot be zero.", //ZERO_IPV6_ADDRESS
	"The IPv6 Port Range cannot be blank.", //port_empty
	"disable", //_disable_s
	"Please select your IPv6 Internet Connection type", //IPV6_TEXT154
	"Sign up", //_signup
	"(GMT+07:00) Novosibirsk", //up_tz_74
	"The Wireless Security Password field entered is invalid.", //wifi_pass_chk
	"Remove", //_remove_multi
	"Do you really want to reprogram the device using the language file", //tf_really_langf
	"You must enter the name of a language file first.", //tf_langf
	"The uploaded language file may not be correct. You may have uploaded a file that is not intended for this device, or the uploaded file may be corrupted.", //ub_intro_l1
	"If the uploaded file is correct, it is possible that the device may be too busy to properly receive it right now. In this case, please try the upload again. It is also possible that you are logged in as a 'user' instead of an 'admin' - only administrators can upload new language.", //ub_intro_l3
	"The page you requested is not available ", //err404_title
	"Could not detect an Internet connection.", //err404_detect
	"Suggestions:", //err404_sug
	"Make sure your Internet cable is securely connected to the Internet port on your router, and your Internet LED is blinking green or blue. ", //err404_sug1
	"Check to make sure that the", //err404_sug2
	"\"Internet settings\"", //err404_sug3
	"on your router are set correctly, such as your PPPoE username/password settings.", //err404_sug4
	"The DNS server may be down at the moment, please contact your ISP or try again later.", //err404_sug5
	"End Time", //tsc_end_time
	"Please enter another remote Admin Port value", //remote_port_msg
	"Please enter another Name", //TEXT034
	"Only Administrator has access to these functionalities. The buttons are disabled as you are not currently logged in as Administrator.", //LW39b
	"Please enter a user name and try again", //_nousername
	"Please enter another Metric value.", //metric_empty
	"Please enter a TCP port number or a UDP port number.", //TEXT061
	"Please contact your ISP to get the correct username/password", //ES_DIALUP_ERROR_dsc
	"Please enter a Firewall Port number", //MSG001
	"Please select \"Device Link\"", //MSG051
	"Please enter another %s value.", //MSG012
	"Please select a filter.", //aa_alert_13
	"Please select a Computer Name first", //TEXT044
	"Please enter another User Name", //sto_03
	"Nothing has changed on this page. Do you want to save it anyway?", //up_nosave
	"Please enter the same password into both boxes, for confirmation.", //ta_msg_TW
	"If you want to \" Enable Web File Access\", you need select \"Enable HTTP Storage Remote Access\" or  \"Enable HTTPS Storage Remote Access\" .", //sto_04
	"Enable Hub and Spoke Mode", //IPV6_TEXT167
	"This page displays IPv6 routing details configured for your router.", //IPV6_TEXT170
	"For each rule you can create a name and control the direction of traffic. You can also allow or deny a range of IP Addresses, the protocol and a port range. In order to apply a schedule to a firewall rule, you must first define a schedule on the <a href=\"tools_schedules.asp\"> Tools &rarr; Schedules</a> page.", //help_171
	"The Host Name is invalid!", //DDNS_HOST_ERROR
	"No.", //_item_no
	"Failed to mount USB device", //_usb_not_found
	"Server name cannot be empty.", //srv_name_empty
	"Using WEP Encryption will be disabled the WPS, Are you sure ?", //msg_wps_sec_01
	"Using WPA/TKIP Encryption will be disabled the WPS, Are you sure ?", //msg_wps_sec_02
	"To hidden SSID will be disabled the WPS, Are you sure ?", //msg_wps_sec_03
	"SharePort", //sh_port_tx_00a
	"Mobile/Web Access", //sh_port_tx_00b
	"SharePort&trade; Mobile/Web Access", //sh_port_tx_00
	"SharePort&trade; Mobile/Web Access is an easy to use shared access from any computer or mobile device in your home network to an external USB storage drive connected to your router. It allows you and other guest users to access files stored on a USB storage drive via the user account you create.", //sh_port_tx_01
	"You can use the Setup Wizard or manually configure for the SharePort&trade; Mobile/Web Access.", //sh_port_tx_02
	"SharePort&trade; Mobile Setup Wizard", //sh_port_tx_03
	"If you would like to utilize our easy to use Web-based Wizards to assist you in setting SharePort&trade; Mobile service, click on the button below.", //sh_port_tx_04
	"SharePort&trade; Mobile Manual Setup", //sh_port_tx_05
	"If you would like to configure SharePort&trade; Mobile/Web Access service settings manually, please click on the button below.", //sh_port_tx_06
	"Please make sure your USB storage is connected to the router.", //sh_port_tx_07
	"No USB storage! Please make sure there is a storage device plugged in the router.", //sh_port_tx_08
	"Create a User Account to manage the storage accessibility.", //sh_port_tx_09
	"Select/Create a folder in the USB drive for accessing the contents.", //sh_port_tx_10
	"Fill in Dynamic DNS Account information for enabling remote access service. If you don't have DDNS account, please sign up one from here:", //sh_port_ddns_01
	"Process Settings", //sh_port_ddns_02
	"Please wait for web access link checking…", //sh_port_ddns_03
	"setup is complete! You can now use below link to access your USB storage via below User Account.", //sh_port_tx_11
	"Local Access", //sh_port_tx_12
	"Remote Access", //sh_port_tx_13
	"or", //sh_port_tx_16
	"<a href=\"http://FQDN:8181\">http://FQDN:8181</a>", //sh_port_tx_17
	"Above links will activate when settings are saved and after device reboot.", //sh_port_tx_18
	"User Name or key", //sh_port_tx_19
	"Password or key", //sh_port_tx_20
	"Select", //sh_port_tx_21
	"The Account Name field cannot be empty.", //sh_port_msg_01
	"The Account Password field cannot be empty.", //sh_port_msg_02
	"The two Password entries do not match.", //sh_port_msg_04
	"Please select a folder for your User Account.", //sh_port_msg_05
	"The Host Name field cannot be empty.", //sh_port_msg_06
	"The User Name field cannot be empty.", //sh_port_msg_07
	"The Password field cannot be empty.", //sh_port_msg_08
	"The Dynamic DNS cannot establish a connection.", //sh_port_msg_09
	"Allow Remote Access", //sto_http_6
	"Are you sure you want to delete this User?", //file_acc_del_user
	"Are you sure  you want to delete this Path?", //file_acc_del_path
	"Are you sure  you want to delete this File?", //file_acc_del_file
	"login again", //_login_a
	"DYNAMIC DNS FOR IPv6 HOSTS", //IPv6_ddns_01
	"IPv6 DYNAMIC DNS LIST", //IPv6_ddns_02
	"Configure IPv6 Firewall below:", //IPv6_fw_01
	"Turn IPv6 Firewall OFF", //IPv6_fw_02
	"Turn IPv6 Firewall ON and ALLOW rules listed", //IPv6_fw_03
	"Turn IPv6 Firewall ON and DENY rules listed", //IPv6_fw_04
	"IP Address Range", //IPv6_fw_ipr
	"Port Range", //IPv6_fw_pr
	"Source", //IPv6_fw_sr
	"Dest", //IPv6_fw_dest
	"6rd Relay can not be empty.", //IPv6_6rd_relay
	"Please change IPv4 wan protocol to DHCP mode first.", //IPv6_6rd_wan
	"6to4 Relay cannot be empty.", //IPv6_6to4_relay
	"Address Range(Start)", //IPv6_addrSr
	"Address Range(End)", //IPv6_addrEr
	"Using WPA Only will be disabled the WPS, Are you sure ?", //msg_wps_sec_04
	"Please wait %d seconds.", //msg_wait_sec
	"Please select a file to delete", //file_acc_del_empty
	"IPv6 PPPoE is share with IPv4 PPPoE. Please change IPv6 WAN protocol at first!", //IPV6_TEXT161a
	"WI-FI Statistics 2.4GHZ", //ss_Wstats_2
	"WI-FI Statistics 5GHZ", //ss_Wstats_5g
	"Media Server", //dlna_t
	"Enable Media Server", //dlna_01
	"Media Server Name", //dlna_02
	"Media Server name given is invalid", //dlna_03
	"Russia PPTP (Dual Access)", //rus_wan_pptp
	"Russia PPTP (Dual Access) internet connection type", //rus_wan_pptp_01
	"Russia L2TP (Dual Access)", //rus_wan_l2tp
	"Russia L2TP (Dual Access) internet connection type", //rus_wan_l2tp_01
	"Russia PPPoE (Dual Access)", //rus_wan_pppoe
	"Russia PPPoE (Dual Access) internet connection type", //rus_wan_pppoe_02
	"Wan Physical Setting", //rus_wan_pppoe_03
	"Using WPA-Enterprise Encryption will be disabled the WPS, Are you sure ?", //msg_wps_sec_05
	"Web File Access Login", //webf_login
	"Log in to the web file access Server", //webf_intro
	"SharePort Web Access", //webf_title
	"New Folder", //webf_folder
	"My Access Device Hard Drive", //webf_hd
	"Create Folder", //webf_createfd
	"Please enter a folder name", //webf_fd_name
	"Upload File", //webf_upload
	"Please select a file", //webf_file_sel
	"If you enable to share media with devices, any computer or device that connects to your network can play your shared music, pictures and videos.", //dlna_t1
	"<strong>Note:</strong> The shared media may not be secure. Allowing any devices to stream is recommended only on secure networks.", //dlna_t2
	"It will allow you to access files from a USB external hard drive or thumb drive that is plugged into the %m from your local network or from the Internet using either a web browser or the SharePort &trade; Mobile app for your smartphone or tablet. You can create users to customize access rights to the files stored on the USB drive. After making your changes, click the <strong>Save Settings</strong> button.", //help_stor1
	"Tick this checkbox to enable sharing files stored on a USB storage drive connected to the %m.", //help_stor2
	"Enter a port to use for HTTP web access to your files (8181 is the default). You will have to add this port to the IP address of the %m when connecting. For example: http://192.168.0.1:8181", //help_stor3
	"Enter a port to use for HTTPS secure access to your files (4433 is the default). You will have to add this port to the IP address of the %m when connecting. For example: https://192.168.0.1:4433", //help_stor4
	"Check to enable remote access to your router's storage.", //help_stor5
	"User Creation", //help_stor6
	"To create a new user, enter a user name. To edit an existing user, use the dropdown box to the right.", //help_stor7
	"Enter a password you want to use for the account, re-enter the password in the <strong>Verify Password</strong> text box, then click <strong>Add/Edit</strong> to save your changes.", //help_stor8
	"This section shows existing user accounts. There are <strong>admin</strong> and <strong>guest</strong> accounts by default.", //help_stor9
	"This feature allows you to share music, pictures and videos with any devices connected to your network. After making your changes, click the <strong>Save Settings</strong> button.", //help_dlna1
	"None USB Storage Insert.", //webf_non_hd
	"DDNS detection fail!", //sh_port_tx_22
	"DDNS link failed, please try again and check your account information, or click next to save your DDNS settings anyway.", //sh_port_tx_23
	"Enable IPv6 Ingress Filtering", //IPv6_Ingress_Filtering_enable
	"Music", //share_title_1
	"Photo", //share_title_2
	"Movie", //share_title_3
	"Document", //share_title_4
	"Search Songs...", //share_ser_1
	"Search Photos...", //share_ser_2
	"Search Movie...", //share_ser_3
	"Search Documents...", //share_ser_4
	"Disconnecting", //ddns_disconnecting
	"Reservation IP", //lan_reserveIP
	"End IP address", //end_ip
	"NULL", //_NULL
	"dyndns.com(Custom)", //ddns_sel2
	"dyndns.com(Free)", //ddns_sel3
	"Remote IP Address", //_remoteipaddr
	"Back", //_back
	"Ping %s failed.", //_ping_fail
	"Ping %s successfully.", //_ping_success
	"The WPS function is currently set to disable. Click \"Yes\" to enable it or \"No\" to exit the wizard.", //_wz_disWPS
	"The account password must be more than six characters", //limit_pass_msg
	"When WPS is enabled, security mode can not set WEP, EAP,and WPA only, or cipher type can not set TKIP.", //_gz_wps_enable
	"When security mode is WEP, EAP, ciphter type is TKIP, or WPA only, WPS can not be enabled.", //_gz_wps_deny
	"Auto 20/40/80 MHz", //bwl_ht204080
	"Close", //_supp_close
	"802.11ac only", //bwl_Mode_ac
	"Mixed 802.11ac and 802.11n", //bwl_Mode_acn
	"Mixed 802.11ac, 802.11n and 802.11a", //bwl_Mode_acna
	"Wireless 2.4GHz", //_wireless_2
	"Wireless 5GHz", //_wireless_5
	"WPS", //_WPS
	"Station List", //_statlst
	"Wireless Security Setting", //_wifiser_title
	"Select SSID", //_wifiser_title0
	"Select SSID", //_wifiser_title1
	"WEP-OPEN", //_wifiser_mode0
	"WEP-SHARED", //_wifiser_mode1
	"WEP-AUTO", //_wifiser_mode2
	"WPA-PSK", //_wifiser_mode3
	"WPA2-PSK", //_wifiser_mode4
	"WPA2-PSK Mixed", //_wifiser_mode5
	"WPA2", //_wifiser_mode6
	"WPA2-Enterprise Mixed", //_wifiser_mode7
	"Encrypt Type", //_wifiser_mode8
	"If you choose WPA/WPA2-TKIP encryption, the wireless mode should be Non-HT 11n mode. This means you will NOT get high throughput performance due to the fact that is not supported by 11N specification.", //_wifiser_mode9
	"Default Key", //_wifiser_mode10
	"Key", //_wifiser_mode11
	"Hex", //_wifiser_mode12
	"WPA Cipher", //_wifiser_mode13
	"Key Update Interval", //_wifiser_mode14
	"PMK Cache Period", //_wifiser_mode15
	"Pre-Authentication", //_wifiser_mode16
	"802.1x WEP", //_wifiser_mode17
	"Radius Server", //_wifiser_mode18
	"Shared Secret", //_wifiser_mode19
	"Session Timeout", //_wifiser_mode20
	"Idle Timeout", //_wifiser_mode21
	"Wireless MAC Filter", //_wifiser_mode22
	"Filter Mode", //_wifiser_mode23
	"Reject", //_wifiser_mode24
	"The MAC address is invalid.", //_wifiser_mode25
	"Can't Add more than 24 entries in MAC Filter List.", //_wifiser_mode26
	"Please input a valid key renewal interval.", //_wifiser_mode27
	"Key renewal interval value must larger than or equal with 60.", //_wifiser_mode28
	"Please input a valid key PMK Cache Period.", //_wifiser_mode29
	"Please input 10 or 26 characters of WEP key", //_wifiser_mode30
	"Please input 5 or 13 characters of WEP key", //_wifiser_mode31
	"Please input WEP key", //_wifiser_mode32
	"Please input the PMK Cache Period.", //_wifiser_mode33
	"Please input less than 63 ASCII character of WPA-PSK key!", //_wifiser_mode34
	"Please input at least 8 ASCII character of WPA-PSK key!", //_wifiser_mode35
	"Please input 64 Hex character of WPA-PSK key!", //_wifiser_mode36
	"Please input WPA-PSK key!", //_wifiser_mode37
	"If you want support Multi-SSID and hope security can work properly, please don't forget reboot device when you change any setting.", //_wifiser_mode38
	"Are you sure that you want to ignore the changes?", //_wifiser_mode39
	"MAC Filter List", //_wifiser_mode40
	"The Wireless Network Radio is OFF.", //_wifiser_mode41
	"Rule Enable", //_adv_txt_00
	"Rule Name", //_adv_txt_01
	"Rule Name: %s entered is invalid.", //_adv_txt_02
	"The Virtual Server can define a single public port for redirection to an internal IP and port.", //_adv_txt_03
	"Add Virtual Server", //_adv_txt_04
	"Virtual Server List", //_adv_txt_05
	"Gaming", //_adv_txt_06
	"That can open multiple ports or a range of ports in your router.", //_adv_txt_07
	"The formats including Single Port (ex: 80), Port Ranges (ex: 50-60).), Individual Ports (80, 68, 888), or Mixed (1020-5000, 689).", //_adv_txt_08
	"Add Port Range Rule", //_adv_txt_09
	"Port Range Rule List", //_adv_txt_10
	"TCP/UDP Ports", //_adv_txt_11
	"Port Trigger", //_adv_txt_12
	"Port trigger is a way to automate port forwarding in which outbound traffic on predetermined ports ('triggering ports') causes inbound traffic to specific incoming ports to be dynamically forwarded to the initiating host, while the outbound ports are in use.", //_adv_txt_13
	"Please assign the port with below format:<br>1. Single Port (ex: 80)<br>2. Port Ranges (ex: 50-60)", //_adv_txt_14
	"Port Trigger Function", //_adv_txt_15
	"Add Port Trigger Rule", //_adv_txt_16
	"Apply", //_adv_txt_17
	"Port Triggering", //_adv_txt_18
	"Rule List", //_adv_txt_19
	"Match Protocol", //_adv_txt_20
	"Match Port", //_adv_txt_21
	"Protocol/Ports", //_adv_txt_22
	"Network", //_network
	"Management", //_management
	"Upload Firmware", //_upload_firm
	"Settings Management", //_settings_management
	"Time", //_time_cap
	"System Log", //_system_log
	"IPv6 Status", //_ipv6_status
	"ALG", //_alg
	"WAN Settings", //_wan_setting
	"LAN Settings", //_lan_setting
	"IPv6 Settings", //_ipv6_setting
	"TOP", //_top
	"Network Help", //_network_help
	"QoS Setting", //_qos_help
	"Wireless Help", //_wireless_help
	"Administrator Help", //_administrator_help
	"WAN Connection Type", //_wan_conn_type
	"There are several connection types to choose from: Static IP, DHCP, PPPoE, PPTP, L2TP, and Russia PPTP. If you are unsure of your connection method, please contact your Internet Service Provider.", //_help_txt2
	"Static", //_static
	"Help menu", //_help_txt1
	"Your ISP provides a set IP address that does not change. The IP information is manually entered in your IP configuration settings. You must enter the IP address, Subnet Mask, Gateway, Primary DNS Server, and Secondary DNS Server. Your ISP provides you with all of this information.", //_help_txt4
	"A method of connection where the ISP assigns your IP address when your router requests one from the ISP's server.", //_help_txt6
	"<b>Host Name:</b> Some ISP's may check your computer's Host Name. The Host Name identifies your system to the ISP's server.", //_help_txt7
	"Select this option if your ISP requires you to use a PPPoE (Point to Point Protocol over Ethernet) connection. DSL providers typically use this option. This method of connection requires you to enter a <b>Username</b> and <b>Password</b> (provided by your Internet Service Provider) to gain access to the Internet.", //_help_txt9
	"<b>Reconnect Mode:</b> Typically PPPoE connections are not always on. The router allows you to set the reconnection mode. The settings are:", //_help_txt10
	"<b>Always on:</b> A connection to the Internet is always maintained.", //_help_txt11
	"<b>On demand:</b> A connection to the Internet is made as needed.", //_help_txt12
	"<b>Manual:</b> You have to open up the Web-based management interface and click the Connect button manually any time that you wish to connect to the Internet.", //_help_txt13
	"<b>Maximum Idle Time:</b> Time interval the machine can be idle before the PPPoE connection is disconnected. The Maximum Idle Time value is only used for the \"On demand\" and \"Manual\" reconnect modes.", //_help_txt14
	"L2TP (Layer Two Tunneling Protocol) uses a virtual private network to connect to your ISP. This method of connection requires you to enter a Username and Password (provided by your Internet Service Provider) to gain access to the Internet.", //_help_txt16
	"<b>L2TP Server IP Address:</b> The ISP provides this parameter, if necessary. The value may be the same as the Gateway IP Address.", //_help_txt17
	"<b>Reconnect Mode:</b> Typically PPPoE connections are not always on. The router allows you to set the reconnection mode. The settings are:", //_help_txt18
	"<b>Always on:</b> A connection to the Internet is always maintained.", //_help_txt19
	"<b>On demand:</b> A connection to the Internet is made as needed.", //_help_txt20
	"<b>Manual:</b> You have to open up the Web-based management interface and click the Connect button manually any time that you wish to connect to the Internet.", //_help_txt21
	"<b>Maximum Idle Time:</b> Time interval the machine can be idle before the PPPoE connection is disconnected. The Maximum Idle Time value is only used for the \"On demand\" and \"Manual\" reconnect modes.", //_help_txt22
	"<b>Static:</b> If your ISP has assigned a fixed IP address, select this option. The ISP provides the values for the following fields for <b>WAN Interface IP Setting: IP Address, Subnet Mask , Default Gateway.</b>", //_help_txt24
	"<b>Dynamic:</b> If the ISP's servers assign the router's IP addressing upon establishing a connection, select this option.", //_help_txt25
	"PPTP (Point to Point Tunneling Protocol) uses a virtual private network to connect to your ISP. This method of connection is primarily used in Europe. This method of connection requires you to enter a <b>Username</b> and <b>Password</b> (provided by your Internet Service Provider) to gain access to the Internet.", //_help_txt27
	"<b>PPTP Server IP Address:</b> The ISP provides this parameter, if necessary. The value may be the same as the Gateway IP Address.", //_help_txt28
	"<b>Reconnect Mode:</b> Typically PPPoE connections are not always on. The router allows you to set the reconnection mode. The settings are:", //_help_txt29
	"<b>Always on:</b> A connection to the Internet is always maintained.", //_help_txt30
	"<b>On demand:</b> A connection to the Internet is made as needed.", //_help_txt31
	"<b>Manual:</b> You have to open up the Web-based management interface and click the Connect button manually any time that you wish to connect to the Internet.", //_help_txt32
	"<b>Maximum Idle Time:</b> Time interval the machine can be idle before the PPPoE connection is disconnected. The Maximum Idle Time value is only used for the \"On demand\" and \"Manual\" reconnect modes.", //_help_txt33
	"WAN Interface IP Type", //_help_txt34
	"<b>Static:</b> If your ISP has assigned a fixed IP address, select this option. The ISP provides the values for the following fields for <b>WAN Interface IP Setting: IP Address, Subnet Mask , Default Gateway</b>, and optional for <b>DNS Server</b>", //_help_txt35
	"<b>Dynamic:</b> If the ISP's servers assign the router's IP addressing upon establishing a connection, select this option.", //_help_txt36
	"WAN MTU Setting", //_help_txt37
	"The Maximum Transmission Unit (MTU) is a parameter that determines the largest packet size (in bytes) that the router will send to the WAN. If LAN devices send larger packets, the router will break them into smaller packets. Ideally, you should set this to match the MTU of the connection to your ISP. Typical values are 1500 bytes for an Ethernet connection and 1492 bytes for a PPPoE connection. If the router's MTU is set too high, packets will be fragmented downstream. If the router's MTU is set too low, the router will fragment packets unnecessarily and in extreme cases may be unable to establish some connections. In either case, network performance can suffer. t modes.", //_help_txt38
	"LAN Interface Setting", //_help_txt39
	"The IP address of the this device on the local area network. Assign any unused IP address in the range of IP addresses available for the LAN. For example, 192.168.10.101.", //_help_txt41
	"The subnet mask of the local area network.", //_help_txt43
	"DHCP stands for Dynamic Host Configuration Protocol. The DHCP section is where you configure the built-in DHCP Server to assign IP addresses to the computers and other devices on your local area network (LAN).", //_help_txt45
	"Once your router is properly configured and this option is enabled, the DHCP Server will manage the IP addresses and other network configuration information for computers and other devices connected to your Local Area Network. There is no need for you to do this yourself.", //_help_txt47
	"The computers (and other devices) connected to your LAN also need to have their TCP/IP configuration set to \"DHCP\" or \"Obtain an IP address automatically\". When you set <b>Enable DHCP Server</b>, the following options are displayed.", //_help_txt48
	"These two IP values (Start and End) define a range of IP addresses that the DHCP Server uses when assigning addresses to computers and devices on your Local Area Network. TAny addresses that are outside of this range are not managed by the DHCP Server; these could, therefore, be used for manually configured devices or devices that cannot use DHCP to obtain network address details automatically.", //_help_txt50
	"It is possible for a computer or device that is manually configured to have an address that does reside within this range. In this case the address should be reserved, so that the DHCP Server knows that this specific address can only be used by a specific computer or device.", //_help_txt51
	"Your router, by default, has a static IP address of 192.168.10.1. This means that addresses 192.168.10.2 to 192.168.10.254 can be made available for allocation by the DHCP Server.", //_help_txt52
	"The subnet mask of the local area network.", //_help_txt54
	"The IP address of the router on the local area network. For example, 192.168.10.1.", //_help_txt56
	"The amount of time that a computer may have an IP address before it is required to renew the lease. The lease functions just as a lease on an apartment would. The initial lease designates the amount of time before the lease expires. If the tenant wishes to retain the address when the lease is expired then a new lease is established. If the lease expires and the address is no longer needed than another tenant may use the address.", //_help_txt58
	"Add/Edit DHCP Reservation", //_help_txt59
	"This option lets you reserve IP addresses, and assign the same IP address to the network device with the specified MAC address any time it requests an IP address. This is almost the same as when a device has a static IP address except that the device must still request an IP address from the router. The router will provide the device the same IP address every time. DHCP Reservations are helpful for server computers on the local network that are hosting applications such as Web and FTP. Servers on your network should either use a static IP address or use this option.", //_help_txt60
	"You can assign a name for each computer that is given a reserved IP address. This may help you keep track of which computers are assigned this way. Example: <b>Game Server</b>.", //_help_txt62
	"The LAN address that you want to reserve.", //_help_txt64
	"To input the MAC address of your system, enter it in manually or connect to the router's Web-Management interface from the system and click the <b>Copy Your PC's MAC Address</b> button.", //_help_txt66
	"A MAC address is usually located on a sticker on the bottom of a network device. The MAC address is comprised of twelve digits. Each pair of hexadecimal digits are usually separated by dashes or colons such as 00-0D-88-11-22-33 or 00:0D:88:11:22:33. If your network device is a computer and the network card is already located inside the computer, you can connect to the router from the computer and click the <b>Copy Your PC's MAC Address</b> button to enter the MAC address.", //_help_txt67
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt69
	"This shows clients that you have specified to reserve DHCP addresses. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit DHCP Reservation\" section is activated for editing.", //_help_txt71
	"In this section you can see what LAN devices are currently leasing IP addresses.", //_help_txt73
	"IPv6 can be configured with the following connection types: Stateless DHCPv6, Stateful DHCPv6, Link-Local, Static, PPPoE, 6to4 , IPv6 in IPv4 Tunnel, and 6rd (IPv6 Rapid Deployment).  Please consult with your local ISP (Internet Service Provider) to obtain information in regard to the IPv6 connection type.  Note: In order to avoid any software conflict, please be sure to remove or disable any PPPoE client software on your computer when using the PPPoE connection type.", //_help_txt85
	"Please select this connection type if your ISP provides you with a set of IPv6 static addresses.  Configuration settings, such as IPv6 address, Default Gateway, Primary DNS Server, and Secondary DNS Server, and Subnet Prefix Length are required and will be entered manually.  Please contact your local ISP for all relevant information.", //_help_txt87
	"Stateless DHCPv6", //_help_txt82
	" Nodes on an IPv6 network can use the ICMPv6 and DHCPv6 server to obtain configuration information such as a list of DNS recursive name servers.  A Stateless DHCPv6 mode does not maintain any dynamic state for individual clients.", //_help_txt83
	"DHCPv6(Stateful)", //_help_txt84
	"Hosts from DHCPv6 servers to obtain IP addresses and other configuration information.  Dynamic state information about each individual client is stored and centrally managed on the DHCPv6 server.", //_help_txt85
	"6to4 is provided as a transition for migrating from IPv4 to IPv6.  It allows IPv6 packets to be transmitted over an IPv4 network through the automatic tunneling technology, and routes traffic between 6to4 and IPv6 networks.", //_help_txt89
	"6in4", //_help_txt90
	"IPv6 in IPv4 tunneling has the capability to encapsulate IPv6 packets within IPv4 packets for transmission over an IPv4 infrastructure.", //_help_txt91
	"It is a mechanism used to facilitate IPv6 rapid deployment across current IPv4 infrastructures.", //_help_txt93
	"IPv6 DNS Server Setting", //_help_txt94
	"Enter the IPv6 addresses of the DNS Servers provided by your ISP.", //_help_txt95
	"LAN IPv6 IP Setting", //_help_txt96
	"The following settings will be applied to the LAN (Local Area Network) IPv6 interface.  You ISP will assign an IPv6 address and subnet (prefix /64 will be supported in LAN) to be configured in the LAN IPv6 Address Configuration section of this device.", //_help_txt97
	"LAN Address Autoconfiguration Setting", //_help_txt98
	"Set up IPv6 Autoconfiguration in this section in order to have IPv6 addresses assigned to the clients on the local area network.", //_help_txt99
	"<b>Stateless Auto:</b> When connected to an IPv6 network utilizing ICMPv6 (Internet Control Message Protocol version 6) router discovery messages, IPv6 hosts will be configured automatically.", //_help_txt100
	"<b>Stateless DHCPv6:</b> A stateless DHCP server will only provide configuration information to the nodes and will rely on ICMPv6 (Internet Control Message Protocol version 6) router discovery messages to assign IPv6 addresses.", //_help_txt101
	"<b>DHCPv6(Stateful):</b> Dynamic Host Configuration Protocol for IPv6.  Stateless address autoconfiguration for IPv6 can be used to acquire access in an IPv6 network, however, it is generally recommended to use DHCPv6 instead to assign addresses, name servers and other configuration information to the clients.", //_help_txt102
	"<b>IPv6 Address Range (DHCPv6):</b> This device will manage IPv6 addresses and other configuration information for all clients connected to it as soon as it is properly configured with this option enabled.  However, users may also opt to use manual IPv6 configuration if they prefer as long as the address does not reside within the range specified here.", //_help_txt103
	"<b>IPv6 Address Lifetime:</b> The time duration in which a client is required to release and renew its IPv6 address.", //_help_txt104
	"Quality of Service Settings", //_help_txt105
	"QoS Setup", //_help_txt106
	"There are several Maximum upload bandwidth to choose or user defined.", //_help_txt107
	"QoS Group", //_help_txt108
	"There are several group of QoS rate and ceil upload bandwidth to setup.", //_help_txt109
	"Link-local Only", //_help_txt110
	"The Link-local address is used by nodes and routers when communicating with neighboring nodes on the same link. This mode enables IPv6-capable devices to communicate with each other on the LAN side.", //_help_txt111
	"Select this option if your ISP requires you to use a PPPoE (Point to Point Protocol over Ethernet) connection to IPv6 Internet. DSL providers typically use this option. This method of connection requires you to enter a <b>Username</b> and <b>Password</b> (provided by your Internet Service Provider) to gain access to the IPv6 Internet. ", //_help_txt113
	"<b>Auto:</b>Select this option if the ISP's servers assign the router's WAN IPv6 address upon establishing a connection.", //_help_txt114
	"<b>Static:</b>If your ISP has assigned a fixed IPv6 address, select this option. The ISP provides the value for the IPv6 Address.", //_help_txt115
	"QoS List", //_help_txt116
	"You can setup QoS per different protocol Application.", //_help_txt117
	"Radio On/Off", //_help_txt121
	"This indicates the wireless operating status. The wireless can be turned on or off by the slide switch. When the radio is on, the following parameters are in effect.", //_help_txt122
	"If all of the wireless devices you want to connect with this router can connect in the same transmission mode, you can improve performance slightly by choosing the appropriate wireless mode. If you have some devices that use a different transmission mode, choose the appropriate wireless mode. ", //_help_txt123
	"There are many different configuration options available to choose from. Use the drop down list to select the wireless mode.", //_help_txt124
	"Note: One wireless mode can be selected can select at any one time. This means that you can only select one of the operating frequency at a time.", //_help_txt125
	"Wireless Mode options", //_help_txt126
	"<b>2.4GHz 802.11b/g mixed mode</b> - This wireless mode works in the 2.4GHz frequency range and will allow both wireless b and wireless g client to connect and access the %m at 11Mbps for wireless b, at 54Mbps for wireless g and share access at the same time. Although the wireless b/g operates in the 2.4GHz frequency, it will allow the use of other 2.4GHz client devices (Wireless n/g @ 54Mbps) to connect and access at the same time.", //_help_txt127
	"<b>2.4GHz 802.11 n only</b> ??This wireless mode works in the 2.4GHz frequency range and will only allow the use of wireless n client devices to connect and access the %m. Although the wireless n operates in the 2.4GHz frequency, this mode will only permit wireless n client devices to work and will exclude any other wireless mode and devices that are not wireless n only.", //_help_txt128
	"<b>5GHz 802.11a only mode</b> - This wireless mode works in the 5GHz frequency range and will allow wireless a client to connect and access the %m at 54Mbps for wireless a only mode. Although the wireless a operates in the 5GHz frequency, this mode will only permit wireless a client devices to work and will exclude any other wireless mode and devices that are not wireless a only.", //_help_txt129
	"<b>5GHz 802.11a/n mixed mode</b> - This wireless mode works in the 5GHz frequency range and will only allow the use of wireless a/n dual band client devices to connect and access the %m*. Dual band wireless client devices that support both wireless a/n can connect and access the %m. Wireless a client devices can connect and access the %m but, will only connect up to 54Mbps, (this due to the legacy limitation of wireless a technology for that standard). Although the wireless a/n operate in the same 5GHz frequency, this mode will only permit wireless a/n client devices to work and will exclude any other wireless mode and devices that are not wireless a/n. (note: wireless b/g/n will not be able to connect at the same time to the %m with 5GHz wireless a/n mode enable).", //_help_txt130
	"<b>2.4 GHz 802.11b/g/n mixed mode</b> - This wireless mode works in the 2.4GHz frequency range and will only allow the use of wireless g client devices to connect and access the %m at 11Mbps for wireless b, 54Mbps for wireless g and up to 150Mbps* for wireless n and share access at the same time. Although the wireless b/g/n operates in the same 2.4GHz frequency, it will allow the use of other 2.4GHz client devices (Wireless b/g/n) to connect and access at the same time.", //_help_txt131
	"*Maximum wireless signal rates are referenced from IEEE 802.11 theoretical specifications. Actual data throughput and coverage will vary depending on interference, network traffic, building materials and other conditions.", //_help_txt132
	"When you are browsing for available wireless networks, this is the name that will appear in the list (unless Visibility Status is set to Invisible, see below). This name is also referred to as the SSID. For security purposes, it is highly recommended to change from the pre-configured network name. Add up to three additional SSIDs to create virtual wireless networks from one wireless Router Access Point device.", //_help_txt133
	"Add Additional Wireless Network Name (SSID)", //_help_txt134
	"To add additional wireless Network Names simply add the name to the Multiple SSID field and click on apply at the bottom of the page. When finished, go to the Security section in this Users Guide for wireless security configuration.", //_help_txt135
	"Frequency (Channel)", //_help_txt136
	"A wireless network uses specific channels in the wireless spectrum to handle communication between clients. Some channels in your area may have interference from other electronic devices. Choose the clearest channel to help optimize the performance and coverage of your wireless network.", //_help_txt137
	"Wireless Distribution System (WDS)", //_help_txt138
	"When WDS is enabled, this access point functions as a wireless repeater and is able to wirelessly communicate with other APs via WDS links. A WDS link is bidirectional; so this AP must know the MAC Address (creates the WDS link) of the other AP, and the other AP must have a WDS link back to this AP. Each WDS APs need setting as same channel, encryption type. (Note that WDS security is incompatible with mixed mode, like WPAPSK+WPA2PSK mixed, WEP AUTO and 802.1x, both feature cannot be used at the same time).", //_help_txt139
	"Configuring WDS with", //_help_txt140
	"Enable the option for WDS and input the MAC Address of the wireless device that also supports WDS in to the blank fields. You can add up to four additional devices in the spaces provided. Click on apply at the bottom of the page, to apply your setting changes. Enable the security seeing in security page, each WDS APs need to use same security setting. (Note: WDS supports wireless g/n modes. The use multiple Access Point will reduces the overall network throughput to ½ the %m", //_help_txt141
	"When WDS is enabled, this access point functions as a wireless repeater and is able to wirelessly communicate with other APs via WDS links. A WDS link is bidirectional, so this AP must know the MAC Address (creates the WDS link) of the other AP, and the other AP must have a WDS link back to this AP. Make sure the APs are configured with same channel number, encryption type. (Note that WDS security is incompatible with mixed mode, like WPAPSK+WPA2PSK mixed, WEP AUTO and 802.1x, both feature cannot be used at the same time).", //_help_txt142
	"Input the MAC Address of the wireless device that also supports WDS link in to the blank fields. The other AP must also have the MAC address of this AP to create the WDS link back to this AP. Enter a MAC address for each of the other APs that you want to connect with WDS.", //_help_txt143
	"HT Physical Mode", //_help_txt144
	"In HT (High Throughput) Physical mode setting allow for control of the 802.11n wireless environment.", //_help_txt145
	"Operating Mode", //_help_txt146
	"Mixed Mode", //_help_txt147
	"Green Field", //_help_txt148
	"In this mode packets are transmitted with a preamble compatible with the legacy 802.11a/g, the rest of the packet has a new format. In this mode the receiver shall be able to decode both the Mixed Mode packets and legacy packets.", //_help_txt149
	"In this mode high throughput packets are transmitted without a legacy compatible part.", //_help_txt150
	"Channel Width", //_help_txt151
	"Set channel width of wireless radio.", //_help_txt152
	"20 Channel Width = 20 MHz", //_help_txt153
	"20/40 Channel Width = 20/40 MHz", //_help_txt154
	"Guard Interval", //_help_txt155
	"Support Short/Long GI, the purpose of the guard interval is to introduce immunity to propagation delays, echoes and reflections, to which digital data is normally very sensitive.", //_help_txt156
	"Long", //_help_txt157
	"Long Guard Interval, 800 nsec", //_help_txt158
	"Short Guard Interval, 400 nsec", //_help_txt159
	"MCS", //_help_txt160
	"Fix MCS rate for HT rate.<br>􀂃 0-15<br>The Modulation and Coding Scheme (MCS) is a value that determines the modulation, coding and number of spatial channels.", //_help_txt161
	"Beacon Interval", //_help_txt162
	"Beacons are packets sent by a wireless router to synchronize wireless devices. Specify a Beacon Period value between 20 and 1000. The default value is set to 100 milliseconds.", //_help_txt163
	"DTIM", //_help_txt164
	"A DTIM is a countdown informing clients of the next window for listening to broadcast and multicast messages. When the wireless router has buffered broadcast or multicast messages for associated clients, it sends the next DTIM with a DTIM Interval value. Wireless clients detect the beacons and awaken to receive the broadcast and multicast messages. The default value is 1. Valid settings are between 1 and 255.", //_help_txt165
	"Fragmentation Threshold", //_help_txt166
	"Wireless frames can be divided into smaller units (fragments) to improve performance in the presence of RF interference and at the limits of RF coverage. Fragmentation will occur when frame size in bytes is greater than the Fragmentation Threshold. This setting should remain at its default value of 2346 bytes. Setting the Fragmentation value too low may result in poor performance.", //_help_txt167
	"When an excessive number of wireless packet collisions are occurring, wireless performance can be improved by using the RTS/CTS (Request to Send/Clear to Send) handshake protocol. The wireless transmitter will begin to send RTS frames (and wait for CTS) when data frame size in bytes is greater than the RTS Threshold. This setting should remain at its default value of 2346 bytes.", //_help_txt168
	"Short Preamble and Slot", //_help_txt169
	"Using a short (400ns) guard interval can increase throughput. However, it can also increase error rate in some installations, due to increased sensitivity to radio-frequency reflections. Select the option that works best for your installation.", //_help_txt170
	"TX Burst", //_help_txt171
	"Allows the wireless Router to deliver better throughput in the same period and environment in order to increase speed.", //_help_txt172
	"Pkt_Aggregate", //_help_txt173
	"Increase efficiency by aggregating multiple packets of application data into a single transmission frame. In this way, 802.11n networks can send multiple data packets with the fixed overhead cost of just a single frame.", //_help_txt174
	"Unless one of these encryption modes is selected, wireless transmissions to and from your wireless network can be easily intercepted and interpreted by unauthorized users.", //_help_txt175
	"A method of encrypting data for wireless communication intended to provide the same level of privacy as a wired network. WEP is not as secure as WPA encryption. To gain access to a WEP network, you must know the key. The key is a string of characters that you create. When using WEP, you must determine the level of encryption. The type of encryption determines the key length. 128-bit encryption requires a longer key than 64-bit encryption. Keys are defined by entering in a string in HEX (hexadecimal - using characters 0-9, A-F) or ASCII (American Standard Code for Information Interchange - alphanumeric characters) format. ASCII format is provided so you can enter a string that is easier to remember. The ASCII string is converted to HEX for use over the network. Four keys can be defined so that you can change keys easily. A default key is selected for use on the network.", //_help_txt176
	"Both of these options select some variant of Wi-Fi Protected Access (WPA) -- security standards published by the Wi-Fi Alliance. The WPA Mode further refines the variant that the router should employ.", //_help_txt177
	"WPA Mode: WPA is the older standard; select this option if the clients that will be used with the router only support the older standard. WPA2 is the newer implementation of the stronger IEEE 802.11i security standard. With the \"WPA2\" option, the router tries WPA2 first, but falls back to WPA if the client only supports WPA. With the \"WPA2 Only\" option, the router associates only with clients that also support WPA2 security.", //_help_txt178
	"Cipher Type: The encryption algorithm used to secure the data communication. TKIP (Temporal Key Integrity Protocol) provides per-packet key generation and is based on WEP. AES (Advanced Encryption Standard) is a very secure block based encryption. With the \"TKIP and AES\" option, the router negotiates the cipher type with the client, and uses AES when available.", //_help_txt179
	"<b>Group Key Update Interval:</b> The amount of time before the group key used for broadcast and multicast data is changed.", //_help_txt180
	"This option uses Wi-Fi Protected Access with a Pre-Shared Key (PSK).", //_help_txt181
	"Pre-Shared Key: The key is entered as a pass-phrase of up to 63 alphanumeric characters in ASCII (American Standard Code for Information Interchange) format at both ends of the wireless connection. It cannot be shorter than eight characters, although for proper security it needs to be of ample length and should not be a commonly known phrase. This phrase is used to generate session keys that are unique for each wireless client.", //_help_txt182
	"This option works with a RADIUS Server to authenticate wireless clients. Wireless clients should have established the necessary credentials before attempting to authenticate to the Server through this Gateway. Furthermore, it may be necessary to configure the RADIUS Server to allow this Gateway to authenticate users.", //_help_txt183
	"Authentication Timeout: Amount of time before a client will be required to re-authenticate.", //_help_txt184
	"RADIUS Server IP Address: The IP address of the authentication server.", //_help_txt185
	"RADIUS Server Port: The port number used to connect to the authentication server.", //_help_txt186
	"RADIUS Server Shared Secret: A pass-phrase that must match with the authentication server.", //_help_txt187
	"Wireless MAC Filtering", //_help_txt188
	"Choose the type of MAC filtering needed.", //_help_txt189
	"<b>Turn MAC Filtering Disable:</b> When \"Disable\" is selected, MAC addresses are not used to control network access.", //_help_txt190
	"Add MAC Filtering Rule", //_help_txt191
	"Use this section to add MAC addresses to the list below.", //_help_txt192
	"Enter the MAC address of a computer that you want to control with MAC filtering. Computers that have obtained an IP address from the router's DHCP server will be in the DHCP Client List. Select a device from the drop down menu.", //_help_txt193
	"Enable the WPS feature.", //_help_txt194
	"Locking the wireless security settings prevents the settings from being changed by any new external registrar using its PIN. Devices can still be added to the wireless network using WPS.", //_help_txt195
	"A PIN is a unique number that can be used to add the router to an existing network or to create a new network. The default PIN may be printed on the bottom of the router. For extra security, a new PIN can be generated. You can restore the default PIN at any time. Only the Administrator (\"admin\" account) can change or reset the PIN.", //_help_txt196
	"Shows the current value of the router's PIN.", //_help_txt197
	"Reset To WPS Default", //_help_txt198
	"Restore the default PIN of the router.", //_help_txt199
	"Create a random number that is a valid PIN. This becomes the router's PIN. You can then copy this PIN to the user interface of the registrar.", //_help_txt200
	"You could monitor stations which associated to this AP here.", //_help_txt201
	"Enter a password for the user \"admin\", who will have full access to the Web-based management interface. ", //_help_txt202
	"The name of the router can be changed here. ", //_help_txt203
	"Enable this option only if you have purchased your own domain name and registered with a dynamic DNS service provider. The following parameters are displayed when the option is enabled.  ", //_help_txt204
	"Dynamic DNS Provider", //_help_txt205
	"Select a dynamic DNS service provider from the pull-down list. ", //_help_txt206
	"Enter your host name, fully qualified; for example: <b>myhost.mydomain.net</b>.", //_help_txt207
	"Account", //_help_txt208
	"Enter the account provided by your service provider. If the Dynamic DNS provider supplies only a key, enter that key in all three fields. ", //_help_txt209
	"Enter the password provided by your service provider. If the Dynamic DNS provider supplies only a key, enter that key in all three fields. ", //_help_txt210
	"Once you have a firmware update on your computer, use this option to browse for the file and then upload the information into the router.", //_help_txt211
	"Export Settings", //_help_txt212
	"This option allows you to export and then save the router's configuration to a file on your computer. Be sure to save the configuration before performing a firmware upgrade.", //_help_txt213
	"Import Settings", //_help_txt214
	"Use this option to restore previously saved router configuration settings.", //_help_txt215
	"Reset to Factory Defaults", //_help_txt216
	"This option restores all configuration settings back to the settings that were in effect at the time the router was shipped from the factory. Any settings that have not been saved will be lost. If you want to save your router configuration settings, use the<b> Export Settings</b> option above. ", //_help_txt217
	"System Reboot", //_help_txt218
	"This restarts the router. It is useful for restarting when you are not near the device.", //_help_txt219
	"Displays the time currently maintained by the router. If this is not correct, use the following options to configure the time correctly.", //_help_txt220
	"Select your local time zone from pull down menu.", //_help_txt221
	"Select this option if you want to synchronize the router's clock to a Network Time Server over the Internet. If you are using schedules or logs, this is the best way to ensure that the schedules and logs are kept accurate. Note that, even when NTP Server is enabled, you must still choose a time zone and set the daylight saving parameters.", //_help_txt222
	"Select a Network Time Server for synchronization. You can type in the address of a time server or select one from the list. If you have trouble using one server, try another.", //_help_txt223
	"If you do not have the NTP Server option in effect, you can either manually set the time for your router here.", //_help_txt224
	"This section displays the device status information.", //_help_txt225
	"DMZ Setting", //_help_txt226
	"DMZ means \"Demilitarized Zone.\" If an application has trouble working from behind the router, you can expose one computer to the Internet and run the application on that computer. ", //_help_txt227
	"When a LAN host is configured as a DMZ host, it becomes the destination for all incoming packets that do not match some other incoming session or rule. If any other ingress rule is in place, that will be used instead of sending packets to the DMZ host; so, an active session, virtual server, active port trigger, or port forwarding rule will take priority over sending a packet to the DMZ host. (The DMZ policy resembles a default port forwarding rule that forwards every port that is not specifically sent anywhere else.) ", //_help_txt228
	"The router provides only limited firewall protection for the DMZ host. The router does not forward a TCP packet that does not match an active DMZ session, unless it is a connection establishment packet (SYN). Except for this limited protection, the DMZ host is effectively \"outside the firewall\". Anyone considering using a DMZ host should also consider running a firewall on that DMZ host system to provide additional protection. ", //_help_txt229
	"Packets received by the DMZ host have their IP addresses translated from the WAN-side IP address of the router to the LAN-side IP address of the DMZ host. However, port numbers are not translated; so applications on the DMZ host can depend on specific port numbers. ", //_help_txt230
	"The DMZ capability is just one of several means for allowing incoming requests that might appear unsolicited to the NAT. In general, the DMZ host should be used only if there are no other alternatives, because it is much more exposed to cyberattacks than any other system on the LAN. Thought should be given to using other configurations instead: a virtual server, a port forwarding rule, or a port trigger. Virtual servers open one port for incoming sessions bound for a specific application (and also allow port redirection and the use of ALGs). Port forwarding is rather like a selective DMZ, where incoming traffic targeted at one or more ports is forwarded to a specific LAN host (thereby not exposing as many ports as a DMZ host). Port triggering is a special form of port forwarding, which is activated by outgoing traffic, and for which ports are only forwarded while the trigger is active. ", //_help_txt231
	"Few applications truly require the use of the DMZ host. Following are examples of when a DMZ host might be required: ", //_help_txt232
	"‧ A host needs to support several applications that might use overlapping ingress ports such that two port forwarding rules cannot be used because they would potentially be in conflict. ", //_help_txt233
	"‧ To handle incoming connections that use a protocol other than ICMP, TCP, UDP, and IGMP (also GRE and ESP, when these protocols are enabled by the PPTP and IPSec", //_help_txt234
	"Putting a computer in the DMZ may expose that computer to a variety of security risks. Use of this option is only recommended as a last resort.", //_help_txt235
	"Specify the LAN IP address of the LAN computer that you want to have unrestricted Internet communication.", //_help_txt236
	"Add/Edit Virtual Server", //_help_txt237
	"Specifies whether the entry will be active or inactive.", //_help_txt238
	"Assign a meaningful name to the virtual server, for example <b>Web Server</b>. Several well-known types of virtual server are available from the \"Application Name\" drop-down list. Selecting one of these entries fills some of the remaining parameters with standard values for that type of server.", //_help_txt239
	"The IP address of the system on your internal network that will provide the virtual service, for example <b>192.168.10.50</b>. You can select a computer from the list of DHCP clients in the \"Computer Name\" drop-down menu, or you can manually enter the IP address of the server computer.", //_help_txt240
	"Select the protocol used by the service. The common choices -- UDP, TCP, and both UDP and TCP -- can be selected from the drop-down menu. To specify any other protocol, select \"Other\" from the list, then enter the corresponding protocol number (as assigned by the IANA) in the <b>Protocol</b> box.", //_help_txt241
	"The port that will be used on your internal network.", //_help_txt242
	"The port that will be accessed from the Internet.", //_help_txt243
	"Select a schedule for when the service will be enabled. If you do not see the schedule you need in the list of schedules.", //_help_txt244
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt245
	"Add/Edit Route", //_help_txt246
	"Adds a new route to the IP routing table or edits an existing route.", //_help_txt247
	"The IP address of packets that will take this route.", //_help_txt248
	"Specifies the next hop to be taken if this route is used. A gateway of 0.0.0.0 implies there is no next hop, and the IP address matched is directly connected to the router on the interface specified: LAN or WAN.", //_help_txt249
	"The route metric is a value from 1 to 16 that indicates the cost of using this route. A value of 1 is the lowest cost, and 15 is the highest cost. A value of 16 indicates that the route is not reachable from this router. When trying to reach a particular destination, computers on your network will select the best route, ignoring unreachable routes.", //_help_txt250
	"Specifies the interface -- LAN or WAN -- that the IP packet must use to transit out of the router, when this route is used.", //_help_txt251
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt252
	"The section shows the current routing table entries. Certain required routes are predefined and cannot be changed. Routes that you add can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Route\" section is activated for editing. Click the Enable checkbox at the left to directly activate or de-activate the entry.", //_help_txt253
	"By default, the Access Control feature is disabled. If you need Access Control, check this option.", //_help_txt254
	"<b>Note:</b> When Access Control is disabled, every device on the LAN has unrestricted access to the Internet. However, if you enable Access Control, Internet access is restricted for those devices that have an Access Control Policy configured for them. All other devices have unrestricted access to the Internet.", //_help_txt255
	"By default, the ALG feature is enabled. ALG configuration allows users to disable some application service.", //_help_txt256
	"Add/Edit Port Trigger Rule", //_help_txt257
	"Specifies whether the entry will be active or inactive.", //_help_txt258
	"Enter a name for the Special Application Rule, for example <b>Game App</b>, which will help you identify the rule in the future. Alternatively, you can select from the <b>Application</b> list of common applications.", //_help_txt259
	"Select the protocol used by the service. The common choices -- UDP, TCP, and both UDP and TCP -- can be selected from the drop-down menu.", //_help_txt260
	"Enter the outgoing port range used by your application (for example <b>6500-6700</b>).", //_help_txt261
	"Select a schedule for when this rule is in effect.", //_help_txt262
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt263
	"This is a list of the defined application rules. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon.", //_help_txt264
	"Add/Edit Port Range Rule", //_help_txt265
	"Use this section to add a Port Range Rule to the following list or to edit a rule already in the list.", //_help_txt266
	"Specifies whether the entry will be active or inactive.", //_help_txt267
	"Give the rule a name that is meaningful to you, for example <b>Game Server</b>. You can also select from a list of popular games, and many of the remaining configuration values will be filled in accordingly. However, you should check whether the port values have changed since this list was created, and you must fill in the IP address field.", //_help_txt268
	"Enter the local network IP address of the system hosting the server, for example <b>192.168.10.50</b>. You can select a computer from the list of DHCP clients in the \"Computer Name\" drop-down menu, or you can manually enter the IP address of the server computer.", //_help_txt269
	"TCP Ports to Open", //_help_txt270
	"Enter the TCP ports to open (for example <b>6159-6180, 99</b>).", //_help_txt271
	"UDP Ports to Open", //_help_txt272
	"Enter the UDP ports to open (for example <b>6159-6180, 99</b>).", //_help_txt273
	"Select a filter that controls access as needed for this rule.", //_help_txt274
	"Select a schedule for the times when this rule is in effect.", //_help_txt275
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt276
	"This is a list of the defined Port Range Rules. Click the Enable checkbox at the left to directly activate or de-activate the entry. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Port Forwarding Rule\" section is activated for editing.", //_help_txt277
	"Add/Edit Inbound Filter Rule", //_help_txt278
	"Here you can add entries to the Inbound Filter Rules List below, or edit existing entries.", //_help_txt279
	"Enter a name for the rule that is meaningful to you.", //_help_txt280
	"The rule can either Allow or Deny messages.", //_help_txt281
	"Define the ranges of Internet addresses this rule applies to. For a single IP address, enter the same address in both the <b>Start</b> and <b>End</b> boxes. Up to eight ranges can be entered. The <b>Enable</b> checkbox allows you to turn on or off specific entries in the list of ranges.", //_help_txt282
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt283
	"The section lists the current Inbound Filter Rules. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Inbound Filter Rule\" section is activated for editing.", //_help_txt284
	"In addition to the filters listed here, two predefined filters are available wherever inbound filters can be applied:", //_help_txt285
	"Permit any WAN user to access the related capability.", //_help_txt286
	"Prevent all WAN users from accessing the related capability. (LAN users are not affected by Inbound Filter Rules.)", //_help_txt287
	"Add/Edit Schedule Rule", //_help_txt288
	"In this section you can add entries to the Schedule Rules List below or edit existing entries.", //_help_txt289
	"Give the schedule a name that is meaningful to you, such as \"Weekday rule\".", //_help_txt290
	"Place a checkmark in the boxes for the desired days or select the All Week radio button to select all seven days of the week.", //_help_txt291
	"Select this option if you want this schedule in effect all day for the selected day(s).", //_help_txt292
	"If you don't use the All Day option, then you enter the time here. The start time is entered in two fields. The first box is for the hour and the second box is for the minute. Email events are normally triggered only by the start time.End Time", //_help_txt293
	"The end time is entered in the same format as the start time. The hour in the first box and the minutes in the second box. The end time is used for most other rules, but is not normally used for email events.", //_help_txt294
	"Re-initialize this area of the screen, discarding any changes you have made.", //_help_txt295
	"This section shows the currently defined Schedule Rules. An entry can be changed by clicking the Edit icon or can be deleted by clicking the Delete icon. When you click the Edit icon, the item is highlighted, and the \"Edit Schedule Rule\" section is activated for editing.", //_help_txt296
	"By default, the UPnP feature is enabled. Universal Plug and Play (UPnP) is a set of networking protocols for primarily residential networks without enterprise class devices that permits networked devices, such as personal computers, printers, Internet gateways, Wi-Fi access points and mobile devices to seamlessly discover each other's presence on the network and establish functional network services for data sharing, communications, and entertainment.", //_help_txt297
	"By default, the WAN Ping Respond feature is disabled. Enable WAN Ping Respond will reply information of router to outside network.", //_help_txt298
	"The Inbound Filter controlling data received from the Internet. In this feature you can configure inbound data filtering rules that control data based on an IP address.", //_adv_txt_23
	"Add Inbound Filter Rule", //_adv_txt_24
	"Rule Action", //_adv_txt_25
	"The %s name: %s is already in the list", //_adv_txt_26
	"Inbound Filter List", //_adv_txt_27
	"IPv6 Settings", //_net_ipv6_01
	"This section allows you to configure your IPv6 Internet connection settings and LAN IPv6 settings. If you are not sure of your IPv6 Internet connection settings or if it is available, please contact with your Internet Service Provider (ISP).", //_net_ipv6_02
	"WAN IPv6 IP Setting", //_net_ipv6_03
	"Stateless Auto", //_net_ipv6_04
	"LAN Prefix Length", //_net_ipv6_05
	"IPv6 To IPv4 Settings", //_net_ipv6_06
	"IPv6 to IPv4 Address", //_net_ipv6_07
	"PPPoE Setting", //_net_ipv6_08
	"Use Default MTU Setting", //_net_ipv6_09
	"MTU Setting", //_net_ipv6_10
	"Manually configure DNS", //_net_ipv6_11
	"Static", //_net_ipv6_12
	"Quality of Service Settings", //_qos_txt00
	"You may setup rules to provide Quality of Service guarantees for specific applications.", //_qos_txt01
	"QoS Setup", //_qos_txt02
	"Quality of Service", //_qos_txt03
	"Upload Bandwidth", //_qos_txt04
	"User defined", //_qos_txt05
	"Bits/sec", //_qos_txt06
	"Download Bandwidth", //_qos_txt07
	"Load Default", //_qos_txt08
	"The value of upload bandwidth is too small, are you sure?", //_qos_txt09
	"The value of upload bandwidth is too large.", //_qos_txt10
	"The maximum upload bandwidth", //_qos_txt11
	"The upload bandwidth format is wrong. (ex. '10K','20M')", //_qos_txt12
	"Please enter the upload bandwidth.", //_qos_txt13
	"Src Port", //_qos_txt14
	"Src Port Range", //_qos_txt15
	"Category", //_qos_txt16
	"Info", //_qos_txt17
	"Prio", //_qos_txt18
	"Upload : %s% at least", //_qos_txt19
	"Attribute", //_qos_txt20
	"Group", //_qos_txt21
	"Setting", //_qos_txt22
	"Advance", //_qos_txt23
	"Basic Classifier Settings", //_qos_txt24
	"Dest IP Address", //_qos_txt25
	"Source IP Address", //_qos_txt26
	"Packet Length", //_qos_txt27
	"ex: 0-128 for small packets", //_qos_txt28
	"DSCP", //_qos_txt29
	"Dest. Port Range", //_qos_txt30
	"Src. Port Range", //_qos_txt31
	"Remark DSCP as", //_qos_txt32
	"Please select one application.", //_qos_txt33
	"The source port range is invalid.", //_qos_txt34
	"Please enter the port number.", //_qos_txt35
	"The MAC address format is invalid.", //_qos_txt36
	"There is a illegal character in the name.", //_qos_txt37
	"Please input a name.", //_qos_txt38
	"Advanced Classifier Settings", //_qos_txt39
	"The destination port range is invalid.", //_qos_txt40
	"The packet length range is invalid.", //_qos_txt41
	"The packet length is too small.", //_qos_txt42
	"The packet length is too big.", //_qos_txt43
	"Packet Length should be an integer number!", //_qos_txt44
	"Please input a range for packet length. (ex: 0-128 64-1024)", //_qos_txt45
	"Please input the classifications.", //_qos_txt46
	"Basic Wireless Settings", //_basic_wireless_settings
	"This section allows you to configure the basic settings required for your wireless network such as your wireless network name (SSID) and Wi-Fi key.", //_desc_basic
	"This section allows you to monitor wireless client devices that are currently connected to your router.", //_desc_station_list
	"This section allows you to activate WPS (Wi-Fi Protected Setup) which allows you to easily connect WPS capable wireless client devices to your router. The router offers three ways to connect wireless client devices using WPS: Hardware Push Button (physically located on the router), Virtual Push Button (PBC), or PIN. WPS cannot be used if the SSID Broadcast function is disabled.", //_desc_wps
	"Wireless Network", //_wireless_network
	"Wireless Distribution System(WDS)", //_wds_long
	"WPS Config", //_wps_config
	"WPS Summary", //_wps_summary
	"WPS Action", //_wps_action
	"DHCP Clients", //_dhcp_clients
	"Please click Wireless Client Card and Router's WPS button in 120 seconds to complete this setting.", //_desc_wps_action
	"Radio On/Off", //_lb_radio_onoff
	"Radio Off Schedule", //_lb_radio_off_sche
	"Wireless Network Name (SSID)", //_wmode_ssid
	"Multiple SSID1", //_lb_multi_ssid_1
	"Multiple SSID2", //_lb_multi_ssid_2
	"Multiple SSID3", //_lb_multi_ssid_3
	"Multiple SSID4", //_lb_multi_ssid_4
	"Multiple SSID5", //_lb_multi_ssid_5
	"Multiple SSID6", //_lb_multi_ssid_6
	"Multiple SSID7", //_lb_multi_ssid_7
	"Broadcast Network Name (SSID)", //_lb_broadcast_ssid
	"Phy Mode", //_lb_phy_mode
	"Encrypt Type", //_lb_enc_type
	"Encrypt Key", //_lb_enc_key
	"Remote AP MAC Address", //_lb_apmacaddr
	"20/40 Coexistence", //_lb_coexistence
	"Reverse Direction Grant(RDG)", //_lb_rdg
	"MCS", //_lb_mcs
	"Extension Channel", //_lb_exten_channel
	"Aggregation MSDU(A-MSDU)", //_lb_a_msdu
	"Auto Block ACK", //_lb_autoba
	"Decline BA Request", //_lb_declineba
	"40 Mhz Intolerant", //_lb_forty_into
	"WiFi Optimum", //_lb_wifi_opt
	"HT TxStream", //_lb_ht_txstream
	"HT RxStream", //_lb_ht_rxstream
	"WPS External Registrar Lock", //_lb_wps_ext_reg_lock
	"Auto", //_sel_autoselect
	"Mixed Mode", //_sel_mixed
	"Green Field", //_sel_greenfield
	"long", //_long
	"RADIO ON", //_btn_radio_on
	"RADIO OFF", //_btn_radio_off
	"The Wireless Network Radio is OFF.", //_MSG_woff
	"Use the Advanced Setup page to make detailed settings for the Wireless. Advanced Setup includes items that are not available from the Basic Setup page, such as Beacon Interval, etc.", //_desc_advanced
	"Qos Setting", //_bx_advanced_2
	"Wi-Fi Multimedia", //_bx_advanced_3
	"Multicast-to-Unicast Converter", //_bx_advanced_4
	"BG Protection Mode", //_lb_bg_protection
	"(range 100 - 1000, default 100)", //_hint_beacon
	"(range 1 - 255, default 1)", //_hint_dtim
	"Fragment Threshold", //_lb_frag_thres
	"(range 256 - 2346, default 2346)", //_hint_frag_thres
	"(range 1 - 2347, default 2347)", //_hint_rts_thres
	"TX Power", //_lb_txpower
	"Short Preamble", //_lb_short_preamble
	"Short Slot", //_lb_short_slot
	"Tx Burst", //_lb_tx_burst
	"Pkt_Aggregate", //_lb_pkt_aggregate
	"IEEE 802.11H Support", //_lb_80211h_support
	"only in A band", //_hint_only_a_band
	"Country Code", //_lb_country_code
	"WMM Capable", //_lb_wmm_capable
	"APSD Capable", //_lb_apsd_capable
	"DLS Capable", //_lb_dls_capable
	"WMM Parameters", //_lb_wmm_param
	"WMM Configuration", //_lb_wmm_config
	"Video Turbine", //_lb_video_turbine
	"Multicast-to-Unicast", //_lb_multi_uni
	"Expires in", //_lb_expire_in
	"Full", //_pwr_full
	"Half", //_pwr_half
	"Low", //_pwr_low
	"Wireless WMM Settings", //_tl_wmm_settings
	"WMM Parameters of Access Point", //_lb_wmm_param_ap
	"WMM Parameters of Station", //_lb_wmm_param_station
	"2.4GHz 802.11 b/g mixed mode", //m_bwl_Mode_3
	"2.4GHz 802.11 n only", //m_bwl_Mode_8
	"2.4GHz 802.11 b/g/n mixed mode", //m_bwl_Mode_11
	"5GHz 802.11 a only", //m_bwl_Mode5_1
	"5GHz 802.11 n only", //m_bwl_Mode5_2
	"5GHz 802.11 a/n mixed mode", //m_bwl_Mode5_3
	"Signal", //_singal
	"BSSID", //_bssid
	"WPS Current Status", //_wps_cur_state
	"WPS Configured", //_wps_configed
	"WPS SSID", //_wps_ssid
	"WPS Security Mode", //_wps_sec_mode
	"WPS Encrypt Type", //_wps_enc_type
	"WPS Default Key Index", //_wps_def_key_idx
	"HEX", //_hex
	"ASCII", //_ascii
	"WPS Key", //_wps_key
	"AP PIN", //_ap_pin
	"You could monitor DHCP clients here.", //_desc_dhcp_client_list
	"Setting wireless security.", //_wifiser_mode42
	"Processing", //_processing
	"Network Status Address", //_netwrk_status_addr
	"System Info", //_system_info
	"System Time", //_system_time
	"System Up Time", //_system_up_time
	"Internet Configuration", //_internet_configs
	"Connected Type", //_connected_type
	"WAN IP Address", //_wan_ip_addr
	"Primary Domain Name Server", //_pri_dns
	"Secondary Domain Name Server", //_sec_dns
	"2.4GHz Wireless", //_24Ghz_wireless
	"5GHz Wireless", //_5Ghz_wireless
	"This section displays the device logging information for monitoring and troubleshooting purposes.", //_SYSLOG_DESC
	"Enable System Log", //_enable_system_log
	"Time and Date Settings", //_time_setting
	"This section allows you to configure the router's time and date settings.", //_TIME_DESC
	"Daylight Saving Time", //_daylight_saving_time
	"NTP Settings", //_ntp_settings
	"NTP Server", //_ntp_server
	"NTP Synchronization", //_ntp_sync
	"Date and Time Settings", //_date_time_settings
	"This section allows you to backup (export) or restore (import) your router’s configuration. This page also allows you to reset the router to factory default settings or reboot.", //_SETTINGS_MANAGER_DESC
	"Export", //_export
	"Settings file location", //_settings_file_location
	"Import", //_import
	"Firmware", //_upgrade_firmw
	"You can check for newer firmware available for your device at the TRENDnet website (<a href=\"http://www.trendnet.com/downloads\" style=\"text-decoration:underline;\">http://www.trendnet.com/downloads</a>). Uploading newer firmware may address problems or enhance functionality of your device. It is important that you check the release notes included with the firmware download, if a problem you have encountered is addressed or may be addressed or if there may be enhanced functionality you would like to add before uploading to a new firmware version. After downloading the file, extract the file to your local hard drive. Click “Browse” or “Choose File” button to navigate to the location of the extracted firmware file. Click Apply to upload the firmware to your device.", //_FIRMW_DESC
	"Important Note: Do not interrupt the firmware upload process as it may damage your device. Please wait until the firmware upload has fully completed and the device has successfully reboot.", //_FIRMW_DESC_sub
	"Location", //_location
	"Apply", //_apply
	"System Management", //_system_management
	"You may configure administrator account and password.", //_SYS_MANGER_DESC
	"Max: %s characters", //_max_length_characters
	"Device URL Settings", //_device_url_settings
	"Device URL", //_device_url
	"Device Name Settings", //_device_name_settings
	"DDNS Settings", //_ddns_settings
	"Remote Management", //_remote_management
	"Remote Control (via Internet)", //_remote_control_via_wan
	"Remote Port", //_remote_port
	"Reset", //_reset
	"If you are not familiar with these Advanced Network settings, please read the help section before attempting to modify these settings.", //_ADV_NETWRK_DESC
	"WAN Ping Respond", //_wan_ping_respond
	"Schedule Rules", //_schedule_rules
	"Define schedule rules for various firewall features.", //_SCHEDULE_DESC
	"Add Schedule Rule", //_add_sche_rule
	"All Day - 24hrs", //_tsc_allday_24hr
	"Schedule Rule List", //_schedule_rule_list
	"Time stamp", //_time_stamp
	"24hr", //_24hr
	"5GHz 802.11 a/n/ac mixed mode", //m_bwl_Mode5_4
	"Routing Between Zones", //_routing_bet_zone
	"MAC Clone", //_mac_clone
	"MAC Address Clone", //_mac_addr_clone
	"DNS Server Setting", //_dns_server_setting
	"DHCP Setting", //_dhcp_setting
	"You may choose different connection type suitable for your environment. Besides, you may also configure parameters according to the selected connection type.", //_DHCP_DESC
	"Wide Area Network (WAN) Settings", //_wan_setting_l
	"(bytes) default=%s bytes", //_mtu_default_byte
	"WAN Interface IP Setting", //_wan_if_ip_setting
	"Operation Mode", //_opeartion_mode
	"Keep Alive", //_keep_alive
	"Keep Alive Mode: Redial Period", //_keep_alive_mode_redial
	"On demand Mode:  Idle Time", //_on_demand_mode_idle_time
	"minutes", //_mintues_lower
	"L2TP Setting", //_l2tp_setting
	"PPTP Setting", //_pptp_setting
	"Dynamic", //_dynamic
	"Local Area Network (LAN) Settings", //_lan_setting_l
	"This section allows you to modify the router’s IP address settings. Tyically, the router IP address settings do not need to be changed. IN addition, this page allows you to configure the router’s DHCP server settings or DHCP reservations which automatically assigned IP addresses to your wired and wireless devices that connect to your router.", //_LAN_DESC
	"DHCP Server Setting", //_dhcp_server_setting
	"DHCP Start IP", //_dhcp_start_ip
	"DHCP End IP", //_dhcp_end_ip
	"Others Setting", //_other_setting
	"802.1D Spanning Tree", //_8021d_spanning_tree
	"LLTD", //_lltd
	"IGMP proxy", //_igmp_proxy
	"PPPOE relay", //_pppoe_relay
	"DNS proxy", //_dns_proxy
	"Add DHCP Reservation", //_add_dhcp_reservation
	"Copy your PC's MAC", //_copy_pc_mac
	"Copy", //_copy
	"DHCP Reservations Ready Group", //_dhcp_reservation_ready_group
	"Edit DHCP Reservation", //_edit_dhcp_reservation
	"Delete All", //_delete_all
	"Delete Selected", //_delete_selected
	"Start PIN", //_config_via_pin
	"Start Push Button", //_config_via_pbc
	"Application Level Gateway (ALG) Configuration", //_alg_config_l
	"ALG configuration allows users to disable some application service.", //_ALG_DESC
	"Description", //_description
	"Email Receiving", //_email_receiving
	"Post Office Protocol - Version 3 (POP3)", //_pop3_l
	"Simple Mail Transfer Protocol(SMTP)", //_smtp_l
	"Streaming Media", //_streaming_media
	"Real Time Transport Protocol (RTP)", //_rtp_l
	"Real Time Streaming Protocol (RTSP)", //_rtsp_1
	"Microsoft Media Server protocol(WMP/MMS)", //_mms_l
	"Streaming Media-VoIP", //_streaming_media_voip
	"Session Initiation Protocol(SIP)", //_session_init_protocol_l
	"NetMeeting (H.323)", //_h323_l
	"File transfer", //_file_transfer
	"File Transfer Protocol (FTP)", //_ftp_l
	"Trivial File Transfer Protocol (TFTP)", //_tftp_l
	"Remote control", //_remote_control
	"Telnet", //_telnet
	"Instant messaging", //_instant_messaging
	"MSN messenger", //_msn_messenger
	"IPSec VPN", //_ipsec
	"Save Status", //_save_status
	"DMZ Settings", //_dmz_settings
	"You may setup a De-militarized Zone(DMZ) to separate internal network and Internet.", //_DMZ_DESC
	"Access Control allows users to define the traffic type not-permitted to WAN port service.", //_AC_DESC
	"Add Port Range and Service Block Rule", //_add_port_block_rule
	"Policy Enable", //_policy_enable
	"Policy Name", //_policy_name
	"Client IP Address", //_client_ip_addr
	"Rule Define", //_rule_define
	"Special Service", //_special_service
	"User Define", //_user_define
	"TCP Ports", //_tcp_ports
	"Ex: 21 or 300-500", //_ex_21_or_3_500
	"UDP Ports", //_udp_ports
	"Service", //_service
	"Edit Services Block Rule", //_edit_port_block_rule
	"Services Block Rule List", //_port_block_rule
	"Add All Services Block Rule", //_add_ip_block_rule
	"Edit Services Block Rule", //_edit_ip_block_rule
	"All Services Block Rule List", //_ip_block_rule_list
	"Add Web URL Filter Rule", //_add_weburl_rule
	"Edit Web URL Filter Rule", //_edit_weburl_rule
	"URL Filter Rule List", //_weburl_rule_list
	"Email Sending", //_email_sending
	"File Transfer", //_file_transfer_l
	"Telnet Service", //_telnet_service
	"DNS Query", //_dns_query
	"TCP Protocol", //_tcp_protocol
	"UDP Protocol", //_udp_protocol
	"WWW", //_www
	"IP Address format error", //_err_ip_addr_format
	"IP Mask Error", //_err_ip_mask
	"Input format error", //_err_input_format
	"IP Address error", //_err_ip_addr
	"Static Routing Settings", //_static_routing_settings
	"This section allows you to manually define static routes and enable or disable the use of dynamic routing on your router.", //_ROUTING_DESC
	"Add Static Route", //_add_static_route
	"Destination IP Address", //_dest_ip_addr
	"Destination IP Netmask", //_dest_ip_mask
	"Physical Port", //_physical_port
	"Enable RIP", //_enable_rip
	"RIP mode", //_rip_mode
	"Static Route List", //_static_route_list
	"Processing, Please wait......", //_processing_plz_wait
	"Rebooting, Please wait......", //_rebooting_plz_wait
	"L2TP Gateway IP Address", //_L2TPgw
	"Retry", //_retry
	"Skip", //_skip
	"Router is checking Internet connectivity, please wait.", //_chk_wanconn_msg_00
	"Setup Wizard", //_tnw_01
	"This wizard will guide you through a step-by-step process to configure your Internet Connection.", //_tnw_02
	"Checking internet connection", //_tnw_03
	"Information", //_tnw_04
	"SSID", //_ssid
	"Authentication Type", //_auth_type
	"Finish", //_finish
	"Configure your Internet Connection", //_tnw_05
	"Obtain IP Automatically(DHCP Client)", //_tnw_dhcp
	"Fixed IP address", //_tnw_static
	"PPPoE", //_tnw_pppoe
	"PPTP", //_tnw_pptp
	"L2TP", //_tnw_l2tp
	"Set Dynamic IP Address", //_tnw_06
	"MAC", //_mac
	"Clone MAC Address", //_tnw_clone
	"Set Fixed IP Address", //_tnw_07
	"WAN IP Address", //_wan_ipaddr
	"WAN Subnet Mask", //_wan_submask
	"WAN Gateway Address", //_wan_gwaddr
	"DNS Server Address 1", //_dns_1
	"DNS Server Address 2", //_dns_2
	"PPPoE", //_tnw_08
	"PPTP", //_tnw_09
	"My IP", //_my_ip
	"Server IP", //_server_ip
	"PPTP Account", //_pptp_account
	"PPTP Password", //_pptp_password
	"Retype PPTP Password", //_pptp_password_re
	"L2TP", //_tnw_10
	"L2TP Account", //_l2tp_account
	"L2TP Password", //_l2tp_password
	"Retype L2TP Password", //_l2tp_password_re
	"The settings are saving and taking effect.", //_tnw_11
	"Please wait for", //_tnw_12
	"seconds.", //_tnw_13
	"Please plug one end of the included Ethernet cable.", //_tnw_14
	"Print", //_print
	"Cannot accept space character in password. Please try it again.", //_TAG00840
	"Auto Configuration (SLAAC/DHCPv6)", //IPV6_TEXT171
	"Auto Configuration (SLAAC/DHCPv6) + 6RD", //IPV6_TEXT172
	"Shared", //_wps_shared
	"Open", //_wps_open
	"The rule name '%s' is duplicated.", //_webfilterrule_dup
	"WPS 2.4GHz", //_wps_24g
	"WPS 5GHz", //_wps_5g
	"Name (SSID)", //_name_ssid
	"Product Warranty Registration", //_warranty
	"USB", //_usb
	"Samba Server", //_samba_server
	"FTP Server", //_ftp_server
	"Print Server", //_print_server
	"Connected Devices", //_connected_devices
	"Guest Network", //_guest_network
	"This page allows you to configure the Guest Network.", //_guest_text1
	"Network Bridge", //_network_bridge
	"Internet Access Only", //_inet_access_only
	"(No Security)", //_security_no
	"(Low Security)", //_security_low
	"(Middle Security)", //_security_middle
	"(High Security)", //_security_high
	"Parental Control", //_parental_control
	"Internet connection", //_has_inet_connection
	"No Internet connection", //_no_inet_connection
	"Guest Network enabled", //_guest_network_enabled
	"Guest Network disabled", //_guest_network_disabled
	"USB devices connected", //_usb_connected
	"No USB devices connected", //_no_usb_connected
	"Household Access", //_household_access
	"Confirm Settings", //_confirm_settings
	"Check Connection", //_check_connection
	"Address ", //_address
	"Household Access Rule List", //_ha_rule_list
	"Add Household Access Rule", //_add_ha_rule
	"Edit Household Access Rule", //_edit_ha_rule
	"Can not change 802.11 Mode to 802.11n only, while there is an SSID with WEP/WPA-TKIP security.", //_wlan_11n_not_support_wep_wpa_tkip
	"Radio On Schedule", //_lb_radio_on_sche
	"You cannot add more rules because the table is full.", //_rule_full
	"You can not enable WDS because current security is not supported. ", //_wds_cant_enble
	"The clients should release and renew IP address or the DUT should be reboot.", //_LAN_CHK_REBOOT_MSG
	"Please specify Device URL.", //_specify_url
	"The IP address '%s' already used.", //_ipaddr_used
	"The MAC address '%s' already used.", //_macaddr_used
	"Not delete any rule", //_lan_dr
	"Please select one route at least to remove!!", //_adv_rtd
	"A-MPDU", //_lb_a_mpdu
	"AC750 Dual Band Wireless Router", //PRODUCT_DESC_810
	"AC750 Wireless Travel Router", //PRODUCT_DESC_817
	"The IP address '%s' already used.", //_ipaddr_used
	"The MAC address '%s' already used.", //_macaddr_used
	"Internet not established", //no_wan_up
	"AP Mode", //dev_mode_ap
	"Repeater Mode", //dev_mode_repeater
	"WISP Mode", //dev_mode_wisp
	"AP Client", //ap_client
	"Extend SSID", //extend_ssid
	"Wireless Client List", //wlan_client_list
	"Access point mode; select this mode to create both 2.4GHz (802.11b/g/n) and 5GHz (802.11a/n/ac) wireless networks. To add a wireless network on your existing network, connect a network cable to the LAN/Ethernet port of the %s and to your router/network.", //desc_ap
	"Select this mode to extend an existing wireless network using the %s.", //desc_repeater
	"Wireless Internet Service Provider; select this mode when connecting to a wireless Internet Service Provider network (ie. hotel wireless services) for Internet access and create an internal network for your client devices using the %s.", //desc_wisp
	"Choose a site you want to connect to and then click Next.", //wiz_select_site
	"Click Refresh to update available site list.", //wiz_refresh_site
	"No availabe site.", //wiz_no_result
	"Please select a SSID or click Maunal.", //wiz_no_selected
	"Do you want to quit the wizard?", //wiz_quit
	"range %d - %d", //custom_range
	"Internet settings", //_internet_setting
	"Configure static IPv6", //desc_static_ipv6
	"%s Packets", //_s_packet
	"WPS Lock", //_wps_lock
	"PPTP Passthrough", //pptp_passthrough
	"L2TP Passthrough", //l2tp_passthrough
	"Configure Local Area Network (LAN) and DHCP settings.", //desc_ap_lan
	"Attain IP Protocol", //attain_ip
	"Device Status", //dev_stat
	"The Schedule configuration section is used to manage schedule rules for wireless.", //desc_ap_sch
	"" //MAX
);
var _Advanced_01=0;
var _Advanced_03=1;
var _Advanced_04=2;
var bwn_ict_dns=3;
var bwn_msg_Modes_dns=4;
var aa_EAC=5;
var new_bwn_mici_usb=6;
var _tkip_11n=7;
var bln_title_guest_use_shareport=8;
var IPV6_TEXT3=9;
var bwl_Mode_10=10;
var IPV6_TEXT148=11;
var _regenerate=12;
var TEXT048=13;
var te_EnEmN=14;
var usb3g_titile=15;
var usb3g_apn_name=16;
var usb3g_dial_num=17;
var usb3g_reconnect_mode=18;
var usb3g_max_idle_time=19;
var usb_device=20;
var usb3g_manual=21;
var usb3g_stat_titile=22;
var bln_title_usb=23;
var usb_wcn=24;
var bwn_intro_usb=25;
var usb_network=26;
var usb_3g=27;
var wwan_dial_num=28;
var bwn_wwanICT=29;
var help862=30;
var wwan_auth_label=31;
var wwan_auth_auto=32;
var IPPPPPAP_AUTH_ISSUE=33;
var wwan_auth_chap=34;
var wwan_auth_mschap=35;
var usb_network_help=36;
var usb_3g_help=37;
var usb_3g_help_support_help=38;
var usb_wcn_help=39;
var bwn_mici_usb=40;
var _info_netowrk=41;
var anet_multicast_enable=42;
var bwn_usb_time=43;
var bwn_bytes_usb=44;
var _wps_albert_1=45;
var _wps_albert_2=46;
var usb_config2=47;
var ac_alert_choose_dev=48;
var usb_config3=49;
var usb_config4=50;
var usb_config5=51;
var usb_config6=52;
var bwn_msg_usb=53;
var _country=54;
var _select_country=55;
var _select_ISP=56;
var country_1=57;
var country_2=58;
var country_3=59;
var country_4=60;
var country_5=61;
var country_6=62;
var country_7=63;
var _aa_bsecure_personals=64;
var country_9=65;
var country_10=66;
var country_11=67;
var country_12=68;
var country_13=69;
var country_14=70;
var country_15=71;
var S500=72;
var S496=73;
var sto_http_2=74;
var logs_LW39b_email=75;
var LV3=76;
var GW_WIRELESS_DEVICE_LINK_UP=77;
var LT248=78;
var GW_PPPOE_EVENT_DISCOVERY_ATTEMPT=79;
var GW_WLAN_RADIO_1_NAME=80;
var te_SMTPSv_Port=81;
var GW_WLAN_CHANGING_PHY_MODE_TO_11NG_ONLY_INVALID=82;
var S558=83;
var KRL8=84;
var LY30=85;
var GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=86;
var GW_WIFISC_DISABLED_AUTOMATICALLY=87;
var _off=88;
var GW_WLAN_RADIO_0_NAME=89;
var GW_PPPOE_EVENT_DISCOVERY_REQUEST_ERROR=90;
var GW_WAN_PPPOE_SESSION_NAME_CONFLICT=91;
var S525=92;
var YM174=93;
var KR136=94;
var GW_PPPOE_EVENT_DISCONNECT=95;
var af_EFT_0=96;
var LY34=97;
var GW_WIRELESS_SHUT_DOWN=98;
var GW_WIRELESS_RESTART=99;
var S528=100;
var GW_PORT_FORWARD_TCP_PACKET_ALLOC_FAILURE=101;
var guestzone_Intro_1=102;
var GW_NAT_VIRTUAL_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=103;
var ta_ERM=104;
var te_SMTPSv_Port_alert=105;
var GW_WIRELESS_DEVICE_START_FAILED=106;
var GW_PORT_FORWARD_UDP_PACKET_ALLOC_FAILURE=107;
var GW_WIRELESS_DEVICE_DISCONNECT_ALL=108;
var GW_PPPOE_EVENT_OFFER_REQUEST=109;
var GW_ROUTES_ROUTERS_IP_ADDRESS_INVALID=110;
var GW_PORT_TRIGGER_UDP_PACKET_ALLOC_FAILURE=111;
var GW_WLAN_SETTING_SSID_SECURITY_TO_WEP_INVALID=112;
var GW_WEB_SERVER_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT=113;
var GW_WLAN_STATION_TIMEOUT=114;
var GW_NAT_VIRTUAL_SERVER_IP_ADDRESS_CAN_NOT_MATCH_ROUTER=115;
var GW_NAT_VIRTUAL_SERVER_PROTO_CONFLICT_INVALID=116;
var LY28=117;
var GW_PPPOE_EVENT_CONNECT=118;
var GW_NAT_TRIGGER_PORT=119;
var tc_opmode=120;
var wwz_auto_assign_key3=121;
var LY292=122;
var LY293=123;
var bws_msg_WEP_4=124;
var GW_ROUTES_ON_LINK_DATALINK_CHECK_INVALID=125;
var wwa_dnsset=126;
var wireless_gu=127;
var add_gu_wps=128;
var wwl_band=129;
var _band=130;
var wwa_5G_nname=131;
var _guestzone=132;
var guestzone_title_1=133;
var _graph_auth=134;
var guestzone_inclw=135;
var guest=136;
var lower_wnt=137;
var equal_wnt=138;
var _lowest=139;
var ssid_lst=140;
var mult_ssid=141;
var add_ed_ssid=142;
var help75a=143;
var wpin_filter=144;
var tps_raw1=145;
var up_tz_52=146;
var _r_alert_new1=147;
var te_EmSt=148;
var IPNAT_BLOCKED_EGRESS=149;
var bws_WSMode=150;
var anet_wan_ping_1=151;
var help65=152;
var ta_upnp=153;
var bwl_TxR=154;
var GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED=155;
var tsc_pingt_msg106=156;
var tsc_AllDay=157;
var gw_gm_53=158;
var GW_WAN_RATE_ESTIMATOR_RESOURCE_ERROR=159;
var DHCP_CLIENT_LOST_LEASE=160;
var _aa_wiz_s3_msg=161;
var bwsAT_=162;
var hhtt_intro=163;
var gw_gm_20=164;
var help388=165;
var tt_StDT=166;
var psOffline=167;
var _status=168;
var up_ae_wic_3=169;
var sl_WtV=170;
var WIFISC_AP_PROXY_PROCESS_START=171;
var wprn_nopr2=172;
var help352=173;
var wwz_wwl_wnn=174;
var _ipaddr=175;
var GW_WLS_SCHEDULE_START=176;
var help820=177;
var help326=178;
var up_tz_54=179;
var help773=180;
var am_MACFILT=181;
var aa_alert_7_new1=182;
var help302=183;
var aa_intro=184;
var help348=185;
var haf_dmz_30=186;
var sl_Infrml=187;
var _wireless=188;
var bws_RIPA=189;
var KR108=190;
var help83=191;
var hhase_intro=192;
var RUNTIME_CONFIG_MAGIC_NUM_ERROR=193;
var _Sat=194;
var awf_title_WSFR=195;
var help18_a=196;
var dlink_wf_op_1=197;
var gw_gm_18=198;
var gw_gm_7=199;
var USB_LOG_STORAGE_TYPE=200;
var help346=201;
var up_rb_5=202;
var _WEP=203;
var IPMSCHAP_AUTH_FAIL_AND_NO_RETRY=204;
var gw_gm_82=205;
var bw_sap=206;
var bwn_msg_SWM=207;
var li_alert_2=208;
var help120=209;
var IGMP_HOST_LOW_RESOURCES=210;
var wwl_s4_intro_z3=211;
var help78=212;
var help339=213;
var IPv6_Simple_Security_enable=214;
var help51=215;
var GW_WAN_LAN_ADDRESS_CONFLICT_PPP=216;
var ss_Errors=217;
var help899=218;
var li_alert_4=219;
var haf_dmz_40=220;
var hhts_edit=221;
var wwl_wnn=222;
var WEB_FILTER_LOG_URL_ACCESSED_MAC=223;
var aw_WE=224;
var help201a=225;
var _bsecure_activate_trial=226;
var help896=227;
var help815=228;
var _netmask=229;
var _please_wait=230;
var help12=231;
var am_intro_1=232;
var IPPPPLCP_SET_LOCAL_AUTH=233;
var gw_gm_11=234;
var _dontsavesettings=235;
var wwl_s4_intro_za1=236;
var _308=237;
var aa_AT_1=238;
var IPL2TP_TUNNEL_ABORTING=239;
var help330=240;
var wwa_msg_l2tp=241;
var tt_time_5=242;
var help6=243;
var _time=244;
var at_xDSL=245;
var wprn_intro4=246;
var help296=247;
var _LAN=248;
var gw_gm_60=249;
var _aa_wiz_s4_msg=250;
var wwl_64bits=251;
var IPFAT_DISK_FULL=252;
var help341=253;
var aa_sched_conf_2=254;
var IPL2TP_SESSION_CONNECTING=255;
var NET_RTC_SYNCHRONIZATION_FAILED=256;
var tf_AutoCh=257;
var wprn_iderr2=258;
var help319=259;
var af_intro_2=260;
var help800=261;
var sd_title_Dev_Info=262;
var GW_INET_ACCESS_DROP_PORT_FILTER=263;
var _connow=264;
var IPSIPALG_REJECTED_PACKET=265;
var IPNAT_TCP_UNABLE_TO_MODIFY_OPTIONS=266;
var tt_SelNTPSrv=267;
var help812=268;
var _user=269;
var up_tz_59=270;
var SPECIAL_APP=271;
var wwl_NONE=272;
var GW_WAN_SERVICES_STARTED=273;
var fb_FbWbAc=274;
var help275=275;
var wprn_nopr=276;
var tt_TimeZ=277;
var wprn_tt=278;
var help841=279;
var aa_sched_new=280;
var tt_time_14=281;
var gw_vs_1=282;
var tsl_SLSt=283;
var IPH323ALG_REJECTED_PACKET=284;
var aa_wiz_s1_msg4=285;
var help336=286;
var ta_sn=287;
var help780=288;
var _interface=289;
var WEB_FILTER_LOG_URL_BLOCKED=290;
var vs_http_port=291;
var haf_intro_1=292;
var up_tz_07=293;
var aw_intro=294;
var wwa_gw=295;
var _sentinel_serv=296;
var wwa_msg_sipa=297;
var IPNAT_TCP_UNABLE_TO_HANDLE_HEADER=298;
var hhav_ip=299;
var haf_dmz_50=300;
var GW_INET_ACCESS_POLICY_END_MAC=301;
var tsc_intro_Sch=302;
var GW_WLAN_ACCESS_DENIED=303;
var _262=304;
var help79=305;
var GW_BIGPOND_CONFIG=306;
var aw_TP_0=307;
var _sdi_s3=308;
var tsc_pingr=309;
var tsc_pingt_v6=310;
var _WPApersonal=311;
var _email=312;
var PPPOE_EVENT_DISCOVERY_REQUEST=313;
var _firewall=314;
var wwa_wanmode_sipa=315;
var _syscheck=316;
var help784=317;
var UNKNOWN=318;
var help_upnp_1=319;
var gw_gm_61=320;
var _optional=321;
var help181=322;
var help569=323;
var anet_intro=324;
var _authword=325;
var IPNAT_TCP_BLOCKED_EGRESS_NOT_SYN=326;
var ta_GWN=327;
var wprn_tt3=328;
var help293=329;
var help265_2=330;
var IPNAT_UNABLE_TO_CREATE_CONNECTION=331;
var help270=332;
var aw_title_2=333;
var _firewalls=334;
var LW67=335;
var PPPOE_EVENT_UP=336;
var _protocol=337;
var help372=338;
var up_tz_32=339;
var at_kbps=340;
var at_Cable=341;
var anet_wp_1=342;
var help17=343;
var ta_intro_Adm2=344;
var tool_admin_check=345;
var IPPPPIPCP_PPP_LINK_UP=346;
var _stop=347;
var GW_SYSLOG_STATUS=348;
var bd_title_DHCPSSt=349;
var help827=350;
var tf_FWCheckInf=351;
var tf_FWInf=352;
var hhai_ipr=353;
var hhaw_1=354;
var help34=355;
var _network_usb_auto=356;
var help309=357;
var aa_alert_15=358;
var _savesettings=359;
var help193=360;
var help14_p=361;
var gw_gm_32=362;
var IPNAT_TCP_BLOCKED_INGRESS_SYN=363;
var anet_msg_wan_ping=364;
var ai_intro_2=365;
var help285=366;
var ss_LANStats=367;
var ta_alert_4=368;
var _clone=369;
var gw_gm_14=370;
var PPTP_ALG_GRE_UNABLE_TO_HANDLE_HEADER=371;
var _aa_block_some=372;
var help819_3=373;
var tt_time_24=374;
var help873=375;
var ss_Collisions=376;
var help863=377;
var help397=378;
var av_title_VSL=379;
var help636=380;
var tf_ENFA=381;
var help13=382;
var wwa_title_s3=383;
var ES_wwa_title_s1=384;
var GW_WAN_RATE_ESTIMATOR_CONVERGENCE_ERROR=385;
var wwa_wanmode_bigpond=386;
var help254=387;
var haf_dmz_70=388;
var GW_SCHED_ATTACH_FAILED=389;
var _badssid=390;
var RUNTIME_CONFIG_STORING_CONFIG_IN_NVRAM=391;
var FW_UPDATE_AVAILABLE=392;
var help891=393;
var help777=394;
var help393=395;
var bwn_ict=396;
var tt_Jun=397;
var IPL2TP_TUNNEL_CONNECTED=398;
var gw_gm_9=399;
var gw_gm_2=400;
var wwl_wl_wiz=401;
var network_dhcp_range=402;
var wprn_intro6=403;
var GW_BIGPOND_FAIL=404;
var af_EFT_1=405;
var _use_unicasting=406;
var _networkstate=407;
var tt_Year=408;
var IPASYNCFILEUSB_MOUNT_FAILED=409;
var af_UEFT=410;
var help356=411;
var help381=412;
var _inboundfilter=413;
var _aa_apply_port_filter=414;
var aa_FPR_c7=415;
var gw_gm_27=416;
var BIGPOND_NOT_PROPERLY_CFGD=417;
var help335=418;
var up_tz_58=419;
var _never=420;
var help801=421;
var tsc_pingt_msg105=422;
var li_WJS=423;
var te_ToEm=424;
var tt_time_1=425;
var help787=426;
var IPV6_TEXT65_v6=427;
var GW_EMAIL_SUBJ=428;
var IPPORTTRIGGERALG_UDP_PACKET_ALLOC_FAILURE=429;
var bi_wiz=430;
var _Out=431;
var hhpt_app=432;
var _dhcpconn=433;
var bln_title_Rtrset=434;
var _ps=435;
var _1044=436;
var wwl_text_best=437;
var wwa_pptp_svraddr=438;
var GW_WAN_RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED=439;
var _LANComputers=440;
var hhte_intro=441;
var as_NM=442;
var wwa_setupwiz=443;
var help264=444;
var bw_WDUU_note=445;
var as_MMS=446;
var _srvname=447;
var help93=448;
var tt_Minute=449;
var sa_State=450;
var aw_dE=451;
var tsc_pingt_h=452;
var tsc_pingt_h_v6=453;
var ss_WStats=454;
var IPMSCHAP_AUTH_SEND_CHALLENGE=455;
var help889=456;
var as_H323=457;
var tool_admin_pfname=458;
var IPNAT_SESSION_ALREADY_EXISTS=459;
var wwa_title_set_bigpond=460;
var up_tz_16=461;
var GW_BIGPOND_STATUS=462;
var wwa_msg_set_bigpond=463;
var ai_alert_5=464;
var help848=465;
var gw_gm_41=466;
var _aa_pol_wiz=467;
var IP_FILTERS=468;
var gw_gm_50=469;
var wwa_intro_s3=470;
var IPSEC_ALG_ESP_ESTABLISH_ALREADY_PENDING=471;
var help59=472;
var wps_reboot_need=473;
var at_DF=474;
var help265_7=475;
var tt_alert_dstchkmonth=476;
var up_tz_23=477;
var _advanced=478;
var STATIC_IP_ADDRESS=479;
var wwl_title_s3=480;
var hhsw_intro=481;
var ish_menu=482;
var up_tz_33=483;
var GW_FW_NOTIFY_FIRMWARE_ERROR=484;
var _bsecure_more_info=485;
var tf_CFWV=486;
var tt_week_2=487;
var help3=488;
var _creator=489;
var bln_title_DNSRly=490;
var GW_INET_ACCESS_DROP_PORT_FILTER_MAC=491;
var ish_glossary=492;
var wwl_s4_intro_z4=493;
var help118=494;
var gw_gm_66=495;
var help312dr2=496;
var tsc_24hrs=497;
var hhag_10=498;
var help261=499;
var as_TPrt=500;
var help28=501;
var tt_time_12=502;
var ss_reload=503;
var EGRESS=504;
var sps_fp=505;
var gw_gm_57=506;
var wwa_msg_dhcp=507;
var aa_wiz_s1_msg1=508;
var MUST_BE_LOGGED_IN_AS_ADMIN=509;
var up_tz_64=510;
var GW_WLS_SCHEDULE_STOP=511;
var IPWOLALG_REJECTED_PACKET=512;
var WCN_LOG_UPDATE=513;
var help80=514;
var help171=515;
var _Mon=516;
var up_tz_66=517;
var wwl_title_s4_2=518;
var help196=519;
var PPPOE_EVENT_DISCOVERY_REQUEST_ERROR=520;
var li_Log_In=521;
var af_gss=522;
var _defgw=523;
var YM185=524;
var add_wireless_device=525;
var help8=526;
var help258=527;
var PPPOE_EVENT_TERMINATED=528;
var up_rb_1=529;
var help25_b=530;
var sl_saveLog=531;
var sl_intro=532;
var _aa_wiz_s4_help=533;
var GW_WAN_CARRIER_LOST=534;
var bwn_bytes=535;
var help890_1=536;
var help779=537;
var _macaddr=538;
var help823_13=539;
var ta_ELM=540;
var sto_http_4=541;
var anet_multicast_enable_v4=542;
var GW_DYNDNS_UPDATE_NEXT=543;
var help866=544;
var sl_RStat=545;
var gw_gm_78=546;
var help90=547;
var PPTP_EVENT_TUNNEL_DOWN=548;
var bwn_SWM=549;
var IPWEBFILTER_REJECTED_PACKET=550;
var GW_UPGRADE_FAILED=551;
var ag_intro=552;
var ta_intro_Adm=553;
var bwn_L2TPSIPA=554;
var GW_INET_ACCESS_UNRESTRICTED=555;
var up_tz_11=556;
var _disabled=557;
var GW_LOG_EMAIL_ON_LOG_FULL=558;
var tt_time_8=559;
var help43=560;
var ddns_connecting=561;
var _enable=562;
var help272=563;
var tt_Apr=564;
var tt_alert_invlddt=565;
var bwl_MS=566;
var tool_admin_portconflict=567;
var gw_SelVS=568;
var bwn_RM_0=569;
var hhai_edit=570;
var te_FromEm=571;
var wt_p_1=572;
var NET_RTC_REQUEST_TIME=573;
var help48=574;
var N_A=575;
var help279=576;
var tt_week_6=577;
var gw_gm_48=578;
var bwl_VS_1=579;
var help882=580;
var up_tz_41=581;
var RUNTIME_CONFIG_LOADED_CONFIG_FROM_NVRAM=582;
var li_alert_1=583;
var help307=584;
var help273=585;
var help194=586;
var up_rb_4=587;
var NEWER_FW_VERSION=588;
var bwn_PPTPICT=589;
var GW_UPGRADE_SUCCEEDED=590;
var bwl_AS=591;
var help96=592;
var _wchannel=593;
var wwz_manual_key=594;
var ap_intro_cont=595;
var tsl_EnLog=596;
var _L2TP=597;
var bd_DIPAR=598;
var _stats=599;
var wwl_s4_intro_za2=600;
var IPL2TP_SESSION_DOWN=601;
var bwn_DIAICT=602;
var help338=603;
var help859=604;
var _add=605;
var _acccon=606;
var tsc_pingt_msg4=607;
var ddns_disconnect=608;
var _verifypw=609;
var am_intro_2=610;
var _aa_pol_add=611;
var gw_gm_59=612;
var help11=613;
var _system=614;
var help261a=615;
var up_tz_02=616;
var hhtsc_pingt_intro=617;
var help5=618;
var help767s=619;
var gw_gm_45=620;
var wwa_wanmode_pppoe=621;
var GW_ROUTES_GATEWAY_SUBNET_SAME=622;
var haf_dmz_60=623;
var te_intro_Em=624;
var wwl_text_none=625;
var help895=626;
var GW_WAN_RECONNECT_ON_ACTIVE=627;
var aa_Machine=628;
var GW_WLS_SCHEDULE_INIT=629;
var _Wed=630;
var tt_time_20=631;
var aa_FPR_c3=632;
var help68=633;
var help150=634;
var te_Acct=635;
var IPSMTPCLIENT_MSG_SENT=636;
var gw_gm_38=637;
var help384=638;
var tt_time_2=639;
var at_AUS=640;
var hhts_del=641;
var help818=642;
var help886=643;
var _aa_wiz_s2_msg=644;
var help52=645;
var wps_KR46=646;
var wwz_wwl_intro_s3_1=647;
var gw_gm_19=648;
var td_intro_DDNS=649;
var up_tz_53=650;
var help845=651;
var wt_p_3=652;
var up_tz_51=653;
var wprn_s3d=654;
var IPPPPCHAP_AUTH_FAIL=655;
var gw_gm_52=656;
var IPNAT_TCP_BAD_FLAGS=657;
var _name=658;
var help66=659;
var IPNAT_UDP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=660;
var IPFTPALG_REJECTED_PACKET=661;
var fb_p_1=662;
var _contype=663;
var help829=664;
var _specappsr=665;
var help353=666;
var gw_gm_23=667;
var help325=668;
var bwn_RM=669;
var sl_LogOps=670;
var help772=671;
var _aa_method=672;
var sl_LogDet=673;
var help788=674;
var _continue=675;
var help804=676;
var _devinfo=677;
var _yes=678;
var help699=679;
var up_tz_62=680;
var help192=681;
var DHCP_PD_ENABLE=682;
var gw_gm_31=683;
var help271=684;
var help33=685;
var IPNAT_TCP_BLOCKED_INGRESS_BAD_ACK=686;
var htsc_pingt_p=687;
var tf_CKN=688;
var wprn_cps=689;
var up_tz_45=690;
var help84=691;
var GW_FW_NOTIFY_FIRMWARE_AVAIL=692;
var ss_RXPD=693;
var WEB_FILTER_LOG_URL_BLOCKED_MAC=694;
var IPPORTTRIGGERALG_TCP_PACKET_ALLOC_FAILURE=695;
var wwa_note_hostname=696;
var ai_Action=697;
var RUNTIME_CONFIG_RESET_CONFIG_TO_FACTORY_DEFAULTS=698;
var sps_nopr=699;
var gw_hours=700;
var _Fri=701;
var tps_lpd=702;
var tf_FWUg=703;
var anet_wp_0=704;
var gw_gm_4=705;
var help373=706;
var tt_dsoffs=707;
var wwz_auto_assign_key=708;
var gw_gm_15=709;
var wwl_s3_note_1=710;
var hhts_save=711;
var at_Auto=712;
var tsc_pingt_msg100=713;
var IPPPPIPCP_PPP_LINK_DOWN=714;
var aa_AT=715;
var gw_gm_71=716;
var aa_wiz_s1_msg3=717;
var BIGPOND_FAILED=718;
var help898=719;
var bwn_PPTPSIPA=720;
var _routing=721;
var hham_intro=722;
var WIFISC_IR_REGISTRATION_FAIL_3=723;
var ai_intro_1=724;
var wwa_title_s2=725;
var up_tz_69=726;
var IPMSCHAP_AUTH_RESULT=727;
var tss_intro2=728;
var help354=729;
var up_tz_19=730;
var ta_alert_5=731;
var bd_DAB=732;
var _WPAenterprise=733;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL_MAC=734;
var sps_pr=735;
var up_tz_34=736;
var _psk=737;
var _dyndns=738;
var _deny=739;
var IPNAT_TCP_BLOCKED_INGRESS_UNEXP_FLAGS=740;
var help276=741;
var _to=742;
var aa_AT_0=743;
var tt_Dec=744;
var GW_INET_ACCESS_POLICY_START_OTHERS=745;
var up_tz_75=746;
var up_tz_72=747;
var tsc_pingt_msg11=748;
var up_ae_de_1=749;
var help781=750;
var help161_2=751;
var tt_time_19=752;
var am_intro=753;
var help811=754;
var aw_TP_1=755;
var up_tz_24=756;
var IPMSCHAP_AUTH_SENT=757;
var sw_intro=758;
var tps_lpd1=759;
var help257=760;
var _upgintro=761;
var help819_8=762;
var bws_secs=763;
var IPNAT_ICMP_BLOCKED_EGRESS_PACKET=764;
var PORT_FORWARDING=765;
var bwn_Mode_DHCP=766;
var tt_Hour=767;
var help290a=768;
var BIGPOND_LOGGING_OUT=769;
var hhan_mc=770;
var _dns1=771;
var _dns1_v6=772;
var _tools=773;
var _sdi_s2=774;
var sps_usbport=775;
var GW_SCHED_ALLOC_FAILED=776;
var help179=777;
var help262=778;
var _allow=779;
var help798=780;
var DHCP_CLIENT_GOT_LEASE=781;
var anet_wan_phyrate=782;
var _note=783;
var aa_FPR_c6=784;
var help69=785;
var bd_DLT=786;
var ai_title_IFRL=787;
var GW_LAN_INTERFACE_UP=788;
var _logs=789;
var am_FM_2=790;
var GW_LOG_EMAIL_ON_USER_REQUEST=791;
var help21=792;
var bwl_Mode=793;
var bwn_AM=794;
var bwn_BPS=795;
var _ispinfo=796;
var _rate=797;
var up_tz_06=798;
var _success=799;
var _bsecure_parental_serv=800;
var wwa_set_l2tp_title=801;
var help342=802;
var help265=803;
var GW_SMTP_EMAIL_RESOLVED_DNS=804;
var tsc_pingt_msg102=805;
var bws_RSP=806;
var PPPOE_EVENT_CONNECT=807;
var tt_auto=808;
var PPTP_EVENT_LOW_RESOURCES_TO_QUEUE=809;
var IPL2TP_TUNNEL_UNEXPECTED_MESSAGE=810;
var gw_gm_34=811;
var tt_week_5=812;
var wwl_intro_end=813;
var aa_Policy_Table=814;
var tt_TimeConf=815;
var _none=816;
var _aa_wiz_s3_title=817;
var help392=818;
var GW_LOG_EMAIL_ON_SCHEDULE=819;
var wwa_intro_s2=820;
var _PPTPgw=821;
var WEB_FILTER_LOG_URL_ACCESSED=822;
var IPMMSALG_REJECTED_PACKET=823;
var _wirelesst=824;
var int_intro=825;
var GW_LAN_ACCESS_DENIED=826;
var gw_gm_26=827;
var PPTP_ALG_GRE_BLOCKED_INGRESS=828;
var up_tz_30=829;
var gw_gm_49=830;
var _sched=831;
var IPFAT_MOUNT_FAILED=832;
var gw_gm_75=833;
var help883=834;
var ta_alert_6=835;
var GW_INET_ACCESS_POLICY_START_IP=836;
var help841a=837;
var tt_time_23=838;
var ag_title_4=839;
var gw_gm_68=840;
var IPNAT_TCP_BLOCKED_EGRESS_UNEXP_FLAGS=841;
var help260=842;
var help819_4=843;
var help357=844;
var _TCP=845;
var IPMSCHAP_CHALLENGE_RECVD=846;
var anet_msg_upnp=847;
var help776=848;
var KR49=849;
var help32=850;
var gw_gm_3=851;
var help823=852;
var _L2TPip=853;
var _reboot=854;
var wps_p3_1=855;
var wprn_intro5=856;
var _bsecure_security_serv=857;
var tsc_pingt_msg8=858;
var gw_gm_56=859;
var tf_intro_FWU=860;
var up_tz_57=861;
var GW_FW_NOTIFY_RESOLVED_DNS=862;
var af_EFT_2=863;
var up_tz_00=864;
var hhts_intro=865;
var _auth=866;
var IPL2TP_TUNNEL_DISCONNECTING=867;
var NET_RTC_SYNCHRONIZATION_FAILED_AFTER_RETRIES=868;
var sd_FWV=869;
var tsc_SchRuLs=870;
var KR58_ww=871;
var YM98=872;
var ta_SavConf=873;
var wwa_sdns=874;
var help876=875;
var help380=876;
var _netfilt=877;
var gw_days=878;
var li_Login=879;
var WAN_ALREADY_CONNECTED=880;
var bws_WPAM_3=881;
var GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS=882;
var GW_DYNDNS_PASSWORD_INVALID=883;
var tool_admin_vsname=884;
var up_tz_50=885;
var static_PPPoE=886;
var tsc_StrTime=887;
var tsc_pingt_msg104=888;
var wprn_iderr=889;
var wps_KR42=890;
var td_Timeout=891;
var _aa_apply_web_filter=892;
var resetUnconfiged=893;
var GAMING=894;
var tt_time_9=895;
var IPNAT_BLOCKED_INGRESS=896;
var GW_WAN_INTERFACE_UP=897;
var _ripaddr=898;
var sa_TimeOut=899;
var IPNAT_TCP_BLOCKED_EGRESS_BAD_SEQ=900;
var GW_LAN_INTERFACE_DOWN=901;
var help778=902;
var sps_qname=903;
var _seconds=904;
var GW_LOGS_CLEARED=905;
var sl_Warning=906;
var aa_MAC=907;
var wps_KR51=908;
var help274=909;
var aw_sgi_h1=910;
var IPSTACK_REJECTED_SOURCE_ROUTED_PACKET=911;
var wwa_pdns=912;
var help834=913;
var _Sun=914;
var sto_no_dev=915;
var wwz_auto_assign_key2=916;
var bwl_NSS=917;
var up_tz_15=918;
var help880=919;
var IPL2TP_TUNNEL_CONNECTING=920;
var bwn_mici_guest_use_shareport=921;
var NET_RTC_SYNCHRONIZED=922;
var up_tz_10=923;
var _on=924;
var NOT_LOGGED_IN_PLEASE_REFRESH=925;
var IPSEC_ALG_ESP_BLOCKED_INGRESS=926;
var ub_continue=927;
var td_UNK=928;
var IPPMVM_MOUNT_FAILED=929;
var gw_gm_42=930;
var _1066=931;
var tsc_AllWk=932;
var _virtserv=933;
var help2=934;
var help869=935;
var IPPPPLCP_SET_LOCAL_OPTIONS=936;
var ts_rd=937;
var IPSEC_ALG_REJECTED_PACKET=938;
var tsc_pingt_msg3=939;
var GW_WIRELESS_DEVICE_DISCONNECTED=940;
var sd_WRadio=941;
var ALLOWED_WEB_SITES=942;
var gw_sa_1=943;
var _UDP=944;
var help166=945;
var help117=946;
var bwn_L2TPICT=947;
var help795=948;
var _no=949;
var up_tz_63=950;
var tf_FWF1=951;
var up_tz_65=952;
var _priority=953;
var WAN_ALREADY_DISCONNECTED=954;
var up_jt_1=955;
var GW_INET_ACCESS_INITIAL_OTHERS=956;
var hhai_ip=957;
var as_intro_SA=958;
var tsc_pingt_mesg=959;
var up_tz_44=960;
var help27=961;
var as_IPSec=962;
var _admin=963;
var gw_gm_65=964;
var tf_intro_FWChB=965;
var BLOCKED=966;
var wwa_msg_bigpond=967;
var help857=968;
var help819_5=969;
var aw_TP_2=970;
var help385=971;
var _setupdone=972;
var li_intro=973;
var IPSMTPCLIENT_MSG_FAILED=974;
var bwz_note_ConWz=975;
var gw_gm_64=976;
var help268=977;
var NONE_BLOCKED=978;
var tt_May=979;
var bwn_BPICT=980;
var tt_time_15=981;
var _Tue=982;
var ss_clear_stats=983;
var help197=984;
var ai_intro_3=985;
var GW_WAN_DISCONNECT_ON_INACTIVE=986;
var DHCP_CLIENT_RELEASED_LEASE=987;
var wwa_set_sipa_title=988;
var up_tz_71=989;
var hhaf_alg=990;
var help843=991;
var wprn_tt11=992;
var _tstats=993;
var IPPPPLCP_SET_REMOTE_OPTIONS=994;
var tf_COLF=995;
var up_tz_28=996;
var tt_Mar=997;
var _aa_allow_all=998;
var wwa_wanmode_l2tp=999;
var _dmzh=1000;
var GW_TIME_RESOLVED_DNS=1001;
var bws_EAPx=1002;
var aa_PolName=1003;
var wwa_set_sipa_msg=1004;
var _aa_wiz_s2_title=1005;
var PPTP_EVENT_TUNNEL_CONNECTED=1006;
var USB_LOG_STORAGE_NOT_FOUND=1007;
var GW_INIT_DONE=1008;
var carriertype_ct_0=1009;
var help305=1010;
var tps_raw=1011;
var av_PubP=1012;
var help374=1013;
var PPTP_EVENT_TUNNEL_CLEAR_DOWN_REQUEST=1014;
var hhac_delete=1015;
var IPL2TP_SESSION_CLEAR_DOWN_REQUEST=1016;
var aa_ACR_c2=1017;
var help29=1018;
var up_tz_01=1019;
var _app=1020;
var bln_alert_1=1021;
var GW_WAN_RATE_ESTIMATOR_STARTED_ON_WAN=1022;
var sl_FWandSec=1023;
var hhan_ping=1024;
var sa_NAT=1025;
var help828=1026;
var GW_SMTP_EMAIL_FAILED_DNS=1027;
var help810=1028;
var _WOL=1029;
var bwn_RM_1=1030;
var help819_1=1031;
var IPNAT_TCP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1032;
var up_tz_14=1033;
var gw_gm_51=1034;
var td_SvAd=1035;
var hhag_40=1036;
var help169=1037;
var help324=1038;
var htsc_intro=1039;
var KR4_ww=1040;
var help317=1041;
var anet_multicast=1042;
var anet_multicast_v4=1043;
var anet_multicast_v6=1044;
var _aa_wiz_s1_title=1045;
var IPL2TP_SHUTDOWN_COMPLETE=1046;
var help819_7=1047;
var help9=1048;
var help809=1049;
var GW_LAN_CARRIER_DETECTED=1050;
var sl_alert_1=1051;
var as_TPRange_b=1052;
var tt_week_1=1053;
var up_jt_3=1054;
var _clear=1055;
var PPPOE_EVENT_DISCONNECT=1056;
var WIFISC_IR_REGISTRATION_FAIL_2=1057;
var _sdi_staticip=1058;
var hhts_name=1059;
var WAN=1060;
var help824=1061;
var hham_add=1062;
var ss_WANStats=1063;
var GW_WAN_CONNECT_ON_ACTIVE=1064;
var aa_sched_conf_1=1065;
var GW_INET_ACCESS_POLICY_END_OTHERS=1066;
var bd_title_list=1067;
var _aa_logging=1068;
var IPNAT_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1069;
var _username=1070;
var gw_gm_67=1071;
var GW_TIME_FAILED_DNS=1072;
var wprn_tt1=1073;
var tt_time_22=1074;
var help256=1075;
var GW_INET_ACCESS_INITIAL_IP_FAIL=1076;
var _aa_details=1077;
var help36=1078;
var help817=1079;
var bwn_Mode_PPPoE=1080;
var _allowall=1081;
var awf_clearlist=1082;
var sc_intro_rb3=1083;
var help67=1084;
var gw_gm_37=1085;
var aa_AT_2=1086;
var wwa_title_s1=1087;
var tps_drname=1088;
var tt_CopyTime=1089;
var IPL2TP_SEQUENCING_ACTIVATED=1090;
var bd_Reserve=1091;
var IPMSNMESSENGERALG_REJECTED_PACKET=1092;
var help782=1093;
var gw_gm_16=1094;
var IPPORTFORWARDALG_UDP_PACKET_ALLOC_FAILURE=1095;
var wprn_mod=1096;
var help119=1097;
var gw_gm_46=1098;
var am_FM_3=1099;
var sps_lpd1=1100;
var tss_SysSt=1101;
var ta_ResConf=1102;
var WCN_LOG_SAVE=1103;
var as_FPrt=1104;
var help823_11=1105;
var tsc_EvDay=1106;
var ham_del=1107;
var _PPPoE=1108;
var wwa_intro_online1=1109;
var tt_dstend=1110;
var tsc_SchRu=1111;
var GW_AUTH_FAILED=1112;
var _scheds=1113;
var up_tz_56=1114;
var _dns2=1115;
var _dns2_v6=1116;
var tsc_pingt_msg2=1117;
var tps_apc1=1118;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL_WITH_PORT=1119;
var up_tz_48=1120;
var _password_admin=1121;
var bd_intro_=1122;
var help387=1123;
var GW_AUTH_SUCCEEDED=1124;
var IPPPPCHAP_AUTH_SENT=1125;
var _bsecure_parental_blurb=1126;
var _aa_wiz_s1_msg=1127;
var help807=1128;
var up_tz_61=1129;
var _L2TPgw=1130;
var IPMSCHAP_AUTH_FAIL=1131;
var help395=1132;
var help888=1133;
var gw_gm_29=1134;
var help95=1135;
var aw_BP=1136;
var GW_WAN_SERVICES_STOPPED=1137;
var gw_gm_79=1138;
var help850=1139;
var help4=1140;
var up_tz_18=1141;
var help168a=1142;
var PPTP_ALG_REJECTED_PACKET=1143;
var te_SMTPSv=1144;
var gw_gm_84=1145;
var IPL2TP_LOW_RESOURCES=1146;
var hhac_add=1147;
var anet_wp_auto2=1148;
var as_RTSP=1149;
var _authsecmodel=1150;
var bwn_MTU=1151;
var gw_gm_72=1152;
var _WAN=1153;
var anet_multicast_enhanced=1154;
var gw_gm_8=1155;
var _WPA=1156;
var help897=1157;
var IPNAT_TCP_BLOCKED_INGRESS_BAD_SEQ=1158;
var tsc_pingt_msg7=1159;
var tt_Jan=1160;
var gw_gm_5=1161;
var _adwwls=1162;
var tsc_pingt_msg101=1163;
var gw_gm_55=1164;
var anet_wan_ping=1165;
var GW_DHCP_SERVER_WINS_INCOMPATIBILITY_WARNING=1166;
var bws_RMAA=1167;
var aa_wiz_s1_msg2=1168;
var tt_time_7=1169;
var help822a=1170;
var gw_gm_1=1171;
var up_tz_37=1172;
var bws_SM=1173;
var up_tz_68=1174;
var wwl_s4_intro_za3=1175;
var _prev=1176;
var sto_http_1=1177;
var wprn_foo1=1178;
var help355=1179;
var aa_ACR_c6=1180;
var bws_2RSSS=1181;
var help391=1182;
var _PM=1183;
var help174=1184;
var PPPOE_EVENT_DISCOVERY_TIMEOUT=1185;
var WCN_LOG_NO_WSETTING=1186;
var psPaperError=1187;
var anet_wan_ping_2=1188;
var help878=1189;
var LOGGED=1190;
var bwn_RM_2=1191;
var bws_RSSs=1192;
var up_tz_43=1193;
var IPRTSPALG_REJECTED_PACKET=1194;
var GW_SCHEDULES_IN_USE_INVALID_s2=1195;
var help1=1196;
var gw_gm_73=1197;
var hhtsn_intro=1198;
var _ping=1199;
var at_UpSp=1200;
var aa_wiz_s1_msg6=1201;
var _PPTPip=1202;
var help185=1203;
var help799=1204;
var up_tz_17=1205;
var sd_intro=1206;
var tf_Upload=1207;
var tt_Second=1208;
var wps_lost=1209;
var help26=1210;
var up_tz_35=1211;
var bwn_intro_ICS=1212;
var bwn_intro_ICS_3G=1213;
var bwn_intro_ICS_v6=1214;
var help81=1215;
var help833=1216;
var ss_Sent=1217;
var help378=1218;
var gw_gm_80=1219;
var _uploadgood=1220;
var KR38=1221;
var wprn_s3c=1222;
var haf_dmz_20=1223;
var ss_Received=1224;
var help263=1225;
var _bsecure_free_trial=1226;
var tf_FUNO=1227;
var aw_sgi=1228;
var help386=1229;
var help254_ict=1230;
var help254_ict_3G=1231;
var _aa_wiz_s5_msg1=1232;
var td_VPWK=1233;
var gw_gm_33=1234;
var gw_gm_0=1235;
var _macfilt=1236;
var TA16=1237;
var bd_DAB_note=1238;
var help796=1239;
var tf_really_FWF=1240;
var up_tz_05=1241;
var tt_time_16=1242;
var help861=1243;
var help19=1244;
var bwn_DWM=1245;
var _ICMP=1246;
var gw_gm_22=1247;
var help868=1248;
var IPV6_TEXT24=1249;
var tt_time_6=1250;
var _501_12=1251;
var hhac_en=1252;
var int_LWlsWz=1253;
var at_STR=1254;
var tt_Aug=1255;
var am_FM_4=1256;
var aa_wiz_s1_msg5=1257;
var ACCESS_CONTROL=1258;
var GW_DYNDNS_HERROR=1259;
var sps_ports=1260;
var help851=1261;
var hhag_20=1262;
var aa_alert_7=1263;
var af_DI=1264;
var tf_ADS=1265;
var tsc_pingt=1266;
var sl_VLevs=1267;
var wwl_enc=1268;
var help151=1269;
var hhta_pt=1270;
var GW_INET_ACCESS_DROP_ACCESS_CONTROL=1271;
var te_EnAuth=1272;
var WIFISC_AP_PROXY_PROCESS_CLOSE=1273;
var bd_CName=1274;
var help305rt=1275;
var li_alert_3=1276;
var GW_DYNDNS_UPDATE_TO=1277;
var tt_week_4=1278;
var tt_Day=1279;
var GW_LAN_CARRIER_LOST=1280;
var hhai_action=1281;
var help121=1282;
var wwa_msg_set_pppoe=1283;
var IPNAT_ICMP_BLOCKED_INGRESS_PACKET=1284;
var tf_intro_FWU2=1285;
var at_ESE=1286;
var _bsecure_security_blurb=1287;
var bd_DHCP=1288;
var help865=1289;
var wwl_s4_intro_z1=1290;
var help501=1291;
var help280=1292;
var help775=1293;
var _connect=1294;
var GW_BIGPOND_INIT=1295;
var _always=1296;
var _minutes=1297;
var as_IPR_b=1298;
var _aa_bsecure_employment=1299;
var GW_INET_ACCESS_DROP_BAD_PKT=1300;
var gw_gm_12=1301;
var gw_gm_25=1302;
var help846=1303;
var tt_alert_1only=1304;
var gw_gm_76=1305;
var GW_LOGS_VIEWED=1306;
var bws_msg_EAP=1307;
var WIFISC_IR_REGISTRATION_INPROGRESS=1308;
var hhsa_intro=1309;
var help856=1310;
var sa_Dir=1311;
var _bln_title_IGMPMemberships=1312;
var bwn_Mode_L2TP=1313;
var _Thu=1314;
var KR30=1315;
var help184=1316;
var _worksbest=1317;
var _unavailable=1318;
var IPFAT_INCOMPATIBLE_FILESYS=1319;
var IPNAT_TCP_BLOCKED_INGRESS_NOT_SYN=1320;
var up_tz_04=1321;
var sl_ApplySt=1322;
var IPPPPCHAP_CHALLENGE_RECVD=1323;
var help141=1324;
var bd_Revoke=1325;
var wprn_intro3=1326;
var _conuptime=1327;
var wprn_tt4=1328;
var help383=1329;
var tsc_pingt_msg6=1330;
var help821a=1331;
var PPPOE_EVENT_SESSION_OFFER_RECVD=1332;
var gw_gm_30=1333;
var bi_man=1334;
var help60=1335;
var ta_RAP=1336;
var bwn_Mode_BigPond=1337;
var wprn_cps2=1338;
var tt_dststart=1339;
var help164_1=1340;
var IPMSCHAP_AUTH_TIMEOUT=1341;
var sl_emailLog=1342;
var bwl_title_1=1343;
var bwn_BPP=1344;
var sl_reload=1345;
var wwl_title_s1=1346;
var IPDRIVE_MOUNT_FAILED=1347;
var int_ConWz=1348;
var sto_permi=1349;
var help329=1350;
var IPL2TP_TUNNEL_DISCONNECTED=1351;
var help830=1352;
var help294=1353;
var up_tz_21=1354;
var tf_LFWD=1355;
var GW_BIGPOND_SUCCESS=1356;
var _denyall=1357;
var at_AC=1358;
var bwl_VS=1359;
var help327=1360;
var wprn_s2a=1361;
var td_=1362;
var PPTP_EVENT_TUNNEL_WINDOW_TIMEOUT=1363;
var aw_TP=1364;
var bwn_SIAICT=1365;
var help57=1366;
var tt_dsen2=1367;
var _sdi_s5=1368;
var wprn_man=1369;
var tt_time_3=1370;
var up_tz_20=1371;
var RIP_LOW_RESOURCES=1372;
var help266=1373;
var CONNECTED=1374;
var help265_5=1375;
var tsc_Days=1376;
var up_tz_13=1377;
var sd_General=1378;
var hhan_upnp=1379;
var help35=1380;
var help18=1381;
var bwz_psw=1382;
var tt_DaT=1383;
var help190=1384;
var help819_2=1385;
var bwn_MIT=1386;
var hhai_name=1387;
var te__title_EmLog=1388;
var up_tz_47=1389;
var IPSMTPCLIENT_DIALOG_FAILED=1390;
var hham_del=1391;
var wwa_msg_ispnot=1392;
var help808=1393;
var PPTP_EVENT_TUNNEL_ESTABLISH_REQUEST=1394;
var help37=1395;
var WCN_LOG_REBOOT=1396;
var PPTP_EVENT_TUNNEL_CONNECT_FAIL=1397;
var bwl_CWM=1398;
var up_tz_12=1399;
var _cancel=1400;
var IPV6_ULA_TEXT02=1401;
var af_ED=1402;
var up_tz_38=1403;
var aw_DI=1404;
var up_tz_31=1405;
var hhai_delete=1406;
var av_intro_vs=1407;
var av_intro_if=1408;
var GW_WAN_RECONNECT_ALWAYS_ON=1409;
var wwl_WSP=1410;
var INGRESS=1411;
var RESTRICTED=1412;
var bwn_msg_DHCPDesc=1413;
var help390=1414;
var KR58=1415;
var help867=1416;
var GW_WAN_CONNECT_ALWAYS_ON=1417;
var IPRTSPALG_REJECTED_ODD_RTP_PACKET=1418;
var help60f=1419;
var gw_gm_10=1420;
var bwn_min=1421;
var tt_Month=1422;
var tf_CFWD=1423;
var _advnetwork=1424;
var bwn_PPPOEICT=1425;
var help389=1426;
var help844=1427;
var tt_time_17=1428;
var help284=1429;
var GW_WIRELESS_DEVICE_ASSOCIATED=1430;
var bws_2RMAA=1431;
var as_SIP=1432;
var help704=1433;
var WIFISC_IR_REGISTRATION_FAIL_1=1434;
var up_tz_25=1435;
var help55=1436;
var GW_WLAN_LINK_UP=1437;
var bln_EnDNSRelay=1438;
var ai_title_IFR=1439;
var _PPTP=1440;
var _both=1441;
var up_tz_40=1442;
var wprn_tt8=1443;
var tps_dsr=1444;
var at_Prot_1=1445;
var help875=1446;
var awsf_p=1447;
var wwl_s4_intro_z2=1448;
var wwa_set_l2tp_msg=1449;
var up_tz_42=1450;
var _error=1451;
var aa_FPR_c4=1452;
var tt_EnNTP=1453;
var network_dhcp_ip_in_server=1454;
var tf_msg_wired=1455;
var wwa_title_set_pppoe=1456;
var help10=1457;
var bwl_CWM_h2=1458;
var help884=1459;
var rb_Rebooting=1460;
var help819_6=1461;
var tt_time_10=1462;
var help199=1463;
var help259=1464;
var af_algconfig=1465;
var wwa_msg_pptp=1466;
var bws_2RIPA=1467;
var _aa_wiz_s4_title=1468;
var wwa_note_svcn=1469;
var help85=1470;
var GW_INET_ACCESS_DROP_PORT_FILTER_WITH_PORT=1471;
var sd_BPSt=1472;
var up_tz_49=1473;
var gw_gm_62=1474;
var BIGPOND_LOGGED_OUT=1475;
var tf_EmNew=1476;
var GW_INET_ACCESS_INITIAL_MAC_FAIL=1477;
var help303=1478;
var wwa_selectisp_not=1479;
var IPNAT_TCP_BLOCKED_EGRESS_BAD_ACK=1480;
var help94=1481;
var gw_gm_70=1482;
var IPNAT_ICMP_UNABLE_TO_HANDLE_HEADER=1483;
var _FTP=1484;
var _neft=1485;
var ta_A12n=1486;
var GW_BIGPOND_LOGOUT=1487;
var help46=1488;
var hhsl_intro=1489;
var help770=1490;
var wwa_msg_set_pptp=1491;
var GW_FW_NOTIFY_FAILED_DNS=1492;
var gw_gm_40=1493;
var bln_IGMP_title_h=1494;
var hhaw_11d=1495;
var up_jt_2=1496;
var GW_INET_ACCESS_POLICY_START_MAC=1497;
var wwa_msg_pppoe=1498;
var help323=1499;
var ta_intro1=1500;
var tt_week_3=1501;
var _dhcpsrv=1502;
var Dynamic_PPPoE=1503;
var help102=1504;
var GW_DHCP_SERVER_WINS_MODE_INVALID=1505;
var help107=1506;
var gw_gm_69=1507;
var aa_ACR_c5=1508;
var help345=1509;
var hhav_name=1510;
var av_PriP=1511;
var tsc_pingt_msg103=1512;
var help_upnp_2=1513;
var WAN_MODE_INCORRECT=1514;
var wwl_alert_pv5_2_5=1515;
var _aa_wiz_s5_title=1516;
var KR22_ww=1517;
var _aa_wiz_s7_help=1518;
var IPL2TP_SEQUENCING_DEACTIVATED=1519;
var tps_apc=1520;
var up_tz_09=1521;
var tt_Jul=1522;
var GW_WAN_INTERFACE_DOWN=1523;
var WCN_LOG_RESTORE=1524;
var gw_gm_17=1525;
var GW_INET_ACCESS_INITIAL_IP=1526;
var _wizquit=1527;
var tss_intro=1528;
var help318=1529;
var tsl_intro=1530;
var tt_time_4=1531;
var tt_time_21=1532;
var IPL2TP_SESSION_CONNECTED=1533;
var aw_FT=1534;
var _save=1535;
var at_NEst=1536;
var af_EFT_h0=1537;
var _firmware=1538;
var gw_gm_43=1539;
var wps_messgae1_1=1540;
var IPL2TP_SHUTDOWN_STARTED=1541;
var ss_TXPD=1542;
var up_tz_55=1543;
var wwa_intro_online2=1544;
var help50=1545;
var help70=1546;
var help188_wmm=1547;
var bd_title_SDC=1548;
var up_tz_60=1549;
var gw_gm_54=1550;
var help396=1551;
var GW_ADMIN_LOGOUT=1552;
var gw_gm_44=1553;
var ta_EUPNP=1554;
var igmp_e_h=1555;
var help806=1556;
var dlink_wf_op_0=1557;
var help49=1558;
var help367=1559;
var gw_gm_28=1560;
var help337=1561;
var ta_AdmSt=1562;
var _syslog=1563;
var up_tz_08=1564;
var help394=1565;
var _aa_wiz_s7_title=1566;
var tt_intro_Time=1567;
var GW_DYNDNS_SERROR=1568;
var IPV6_TEXT105=1569;
var sps_port=1570;
var help164_2=1571;
var help881=1572;
var _destip=1573;
var help840=1574;
var wwa_l2tp_svra=1575;
var tt_dsdates=1576;
var help34b=1577;
var tt_time_11=1578;
var td_EnDDNS=1579;
var help786=1580;
var bwn_UN=1581;
var aa_alert_8=1582;
var wprn_tt2=1583;
var IPPPPLCP_SET_REMOTE_AUTH=1584;
var IPL2TP_FATAL_TIMEOUT=1585;
var hhaf_ngss=1586;
var bln_title_NetSt=1587;
var av_traftype=1588;
var bwn_Mode_PPTP=1589;
var help140=1590;
var wprn_rppd=1591;
var hhsd_intro=1592;
var IPMSCHAP_AUTH_SUCCESS=1593;
var help63=1594;
var ES_cable_lost_desc=1595;
var ap_intro_sv=1596;
var _L2TPsubnet=1597;
var GW_LOG_EMAIL_BEFORE_REBOOT=1598;
var at_Any=1599;
var help288=1600;
var bws_SM_h1=1601;
var help177=1602;
var up_tz_46=1603;
var rb_wait=1604;
var bwl_NN=1605;
var IPL2TP_SESSION_CONNECT_FAIL=1606;
var gw_gm_21=1607;
var wwl_BEST=1608;
var _support=1609;
var aa_alert_14=1610;
var _cablestate=1611;
var help314=1612;
var wps_LW13=1613;
var sl_Critical=1614;
var sc_intro_sv=1615;
var SYSTEM_LOG_INACTIVE=1616;
var bwn_mici=1617;
var gw_mins=1618;
var help852=1619;
var _In=1620;
var help870=1621;
var gw_gm_74=1622;
var help797=1623;
var gw_gm_39=1624;
var wwl_alert_pv5_3_10=1625;
var help149=1626;
var hhpt_intro=1627;
var GW_WAN_CARRIER_DETECTED=1628;
var bwn_BPU=1629;
var help195=1630;
var help823_1=1631;
var _internetc=1632;
var tsc_pingt_msg5=1633;
var help189a=1634;
var _trigger=1635;
var help783=1636;
var ub_intro_2=1637;
var hhta_pw=1638;
var _aa_wiz_s8_title=1639;
var help173=1640;
var help771=1641;
var tsl_SLSIPA=1642;
var _aa_wiz_s7_msg=1643;
var tt_time_13=1644;
var up_tz_67=1645;
var help289a=1646;
var BIGPOND_LOGGED_IN=1647;
var haf_dmz_10=1648;
var help819=1649;
var wprn_s3b=1650;
var sps_tcpport=1651;
var dlink_wf_intro=1652;
var _websfilter=1653;
var sd_BPSN=1654;
var _password_user=1655;
var GW_INET_ACCESS_POLICY_END_IP=1656;
var bwn_msg_Modes=1657;
var up_gX_1=1658;
var _next=1659;
var _setup=1660;
var htsc_pingt_s=1661;
var EMAIL=1662;
var _mode=1663;
var tt_Feb=1664;
var sps_raw1=1665;
var GW_DYNDNS_SUCCESS=1666;
var IPPORTFORWARDALG_TCP_PACKET_ALLOC_FAILURE=1667;
var IGMP_ROUTER_LOW_RESOURCES=1668;
var bwl_CWM_h1=1669;
var up_tz_39=1670;
var help40=1671;
var _pf=1672;
var IPNAT_UDP_UNABLE_TO_HANDLE_HEADER=1673;
var GW_ROUTES_GATEWAY_IP_ADDRESS_CONFLICTS_WARNING=1674;
var GW_INET_ACCESS_INITIAL_MAC=1675;
var IPPPPCHAP_AUTH_SUCCESS=1676;
var help187=1677;
var _aa_block_all=1678;
var GW_WLAN_LINK_DOWN=1679;
var help379=1680;
var up_tz_70=1681;
var IPNAT_ICMP_BLOCKED_INGRESS_ICMP_ERROR_PACKET=1682;
var GW_SCHEDULES_IN_USE_INVALID_s1=1683;
var fb_p_2=1684;
var sps_ps=1685;
var help47=1686;
var wwa_title_s4=1687;
var tt_time_18=1688;
var help860=1689;
var GW_UPNP_IGD_PORTMAP_RELEASE=1690;
var wwa_intro_s4=1691;
var help267=1692;
var IPL2TP_SESSION_ABORTED=1693;
var help874=1694;
var tt_Sep=1695;
var IPSEC_ALG_ESP_UNABLE_TO_HANDLE_HEADER=1696;
var bws_GKUI=1697;
var help80b=1698;
var help168c=1699;
var BIGPOND_LOGGING_IN=1700;
var wwa_wanmode_pptp=1701;
var help58=1702;
var ddns_connected=1703;
var ub_Upload_Failed=1704;
var WIFISC_AP_PROXY_END_ON_MSG=1705;
var help278=1706;
var KR18=1707;
var hhts_def=1708;
var help255=1709;
var bws_2RSP=1710;
var help7=1711;
var bwl_VS_0=1712;
var af_TEFT=1713;
var help86=1714;
var sd_NNSSID=1715;
var wt_p_2=1716;
var _gateway=1717;
var tt_CurTime=1718;
var _AM=1719;
var DISCONNECTED=1720;
var gw_gm_47=1721;
var up_tz_22=1722;
var WIFISC_IR_REGISTRATION_SESSION_OVERLAP=1723;
var _pwsame_admin=1724;
var GW_DYNDNS_UPDATE_IP=1725;
var GW_DHCPSERVER_NEW_ASSIGNMENT=1726;
var as_WM=1727;
var up_tz_03=1728;
var KR43=1729;
var YM177=1730;
var help774=1731;
var hhac_edit=1732;
var up_tz_36=1733;
var _hostname=1734;
var GW_INET_ACCESS_INITIAL_FAIL=1735;
var GW_WEB_FILTER_INITIAL_FAIL=1736;
var te_OnFull=1737;
var wwl_title_s4=1738;
var help281=1739;
var gw_gm_77=1740;
var _clonemac=1741;
var hhss_intro=1742;
var at_MUS=1743;
var hhan_wans=1744;
var YM141=1745;
var help382=1746;
var tsc_hrmin=1747;
var tsc_hrmin1=1748;
var help82=1749;
var gw_gm_24=1750;
var gw_gm_13=1751;
var aw_RT=1752;
var help340=1753;
var sd_WLAN=1754;
var help864=1755;
var tf_intro_FWU1=1756;
var wprn_bados=1757;
var _metric=1758;
var INBOUND_FILTER=1759;
var IPNAT_UDP_BLOCKED_INGRESS=1760;
var help351=1761;
var wwz_manual_key2=1762;
var _PPTPsubnet=1763;
var help20=1764;
var gw_gm_6=1765;
var bws_WPAM=1766;
var wwl_GOOD=1767;
var gw_gm_36=1768;
var help894=1769;
var _subnet=1770;
var PPTP_EVENT_REMOTE_WINDOW_SIZE=1771;
var wps_KR35=1772;
var help329_rsv=1773;
var gw_gm_58=1774;
var GW_WAN_MODE_IS=1775;
var ns_intro_=1776;
var IPDNSRELAYALG_REJECTED_PACKET=1777;
var ss_intro=1778;
var KR112=1779;
var GW_WLAN_11A_CH_MID_BAND_WARN=1780;
var ip_mac_binding_desc=1781;
var LW50=1782;
var GW_NAT_CONFLICTING_CONNECTIONS_LOG=1783;
var KR111=1784;
var KR109=1785;
var GW_NAT_CONFLICTING_CONNECTIONS_WARNING=1786;
var GW_PURE_SETACCESSPOINTMODE=1787;
var GW_NAT_REJECTED_SPOOFED_PACKET=1788;
var KR110=1789;
var GW_ROUTES_ROUTE_GATEWAY_NOT_IN_SUBNET_WARNING=1790;
var KR107=1791;
var KR105=1792;
var IPSTACK_REJECTED_LAND_ATTACK=1793;
var LS321=1794;
var KR67=1795;
var YM71=1796;
var GW_FIREWALL_RANGE_DUPLICATED_INVALID=1797;
var LS422=1798;
var bwz_LWCNWz=1799;
var GW_WAN_WAN_GATEWAY_IP_ADDRESS_INVALID=1800;
var ta_wcn=1801;
var LW57=1802;
var _wepkey2=1803;
var tsc_pingt_msg109=1804;
var bd_NETBIOS_REG_TYPE=1805;
var wps_messgae1_2=1806;
var LW60=1807;
var _rs_failed=1808;
var KR62=1809;
var KR20=1810;
var at_intro_2=1811;
var bd_NETBIOS_ENABLE=1812;
var KR77=1813;
var help364=1814;
var _aa_bsecure_shopping=1815;
var _aa_bsecure_public_proxies=1816;
var wepkey1=1817;
var ZM11=1818;
var tsc_start_time=1819;
var YM69=1820;
var KR82=1821;
var ss_intro_user=1822;
var GW_SCHEDULES_NAME_RESERVED_INVALID=1823;
var LW12=1824;
var YM75=1825;
var GW_ROUTES_GATEWAY_IP_ADDRESS_INVALID=1826;
var GW_WLAN_WPA_REKEY_TIME_INVALID=1827;
var bws_msg_WEP_1=1828;
var YM125=1829;
var _aa_bsecure_gambling=1830;
var KR14=1831;
var GW_SMTP_FROM_ADDRESS_INVALID=1832;
var KR89=1833;
var help106=1834;
var LW35=1835;
var YM151=1836;
var YM2=1837;
var ta_wcn_note=1838;
var YM131=1839;
var GW_WEB_SERVER_SAME_PORT_LAN=1840;
var KR25=1841;
var YM3=1842;
var GW_NAT_WOL_ALG_ACTIVATED_WARNING=1843;
var YM20=1844;
var YM86=1845;
var GW_WAN_MAC_ADDRESS_INVALID=1846;
var IPSMTPCLIENT_MSG_WRONG_RECEPIENT_ADDR_FORMAT=1847;
var YM146=1848;
var LS151=1849;
var GW_QOS_RULES_NAME_INVALID=1850;
var GW_NAT_VS_PROTO_CONFLICT_INVALID=1851;
var GW_WISH_RULES_NAME_INVALID=1852;
var WIFISC_IR_REGISTRATION_FAIL=1853;
var r_rlist=1854;
var IPV6_TEXT109=1855;
var bws_WKL_1=1856;
var help473=1857;
var aw_erpe=1858;
var GW_NAT_PORT_FORWARD_RANGE_BOTH_EMPTY_INVALID=1859;
var GW_ROUTES_GATEWAY_IP_ADDRESS_IN_SUBNET_INVALID=1860;
var LW37=1861;
var tsc_pingdisallowed=1862;
var ZM20=1863;
var help376=1864;
var GW_FW_NOTIFY_EMAIL_DISABLED_INVALID=1865;
var YM122=1866;
var GW_NAT_DMZ_CONFLICT_WITH_LAN_IP_INVALID=1867;
var _sdi_s7=1868;
var at_title_SESet=1869;
var GW_INET_ACL_START_PORT_INVALID=1870;
var IPSMTPCLIENT_DATA_FAILED=1871;
var KR91=1872;
var KR971=1873;
var tss_RestAll_b=1874;
var GW_NAT_PORT_TRIGGER_CONFLICT_INVALID=1875;
var LW54=1876;
var TA7=1877;
var KR74=1878;
var bws_DFWK=1879;
var LW46=1880;
var IPSMTPCLIENT_RESOLVED_DNS=1881;
var help110=1882;
var YM107=1883;
var YM180=1884;
var GW_WAN_WAN_SUBNET_INVALID=1885;
var GW_NAT_DMZ_DISABLED_WARNING=1886;
var YM93=1887;
var GW_NAT_FTP_ALG_ACTIVATED_WARNING=1888;
var _aa_bsecure_free_host=1889;
var _r_alert2=1890;
var LS47=1891;
var GW_DHCP_SERVER_SUBNET_SIZE_INVALID=1892;
var GW_INET_ACCESS_POLICY_TOO_MANY_MAC_INVALID=1893;
var GW_FIREWALL_START_IP_ADDRESS_INVALID=1894;
var YM8=1895;
var GW_WISH_RULES_PRIORITY_RANGE=1896;
var _aa_bsecure_travel=1897;
var help113=1898;
var ZM6=1899;
var bws_length=1900;
var help836=1901;
var rs_intro_2=1902;
var GW_INET_ACL_IP_ADDRESS_DUPLICATION_INVALID=1903;
var KR7=1904;
var ZM1=1905;
var hhta_831=1906;
var LW30=1907;
var YM110=1908;
var bd_NETBIOS_REG_TYPE_P=1909;
var GW_LAN_SUBNET_MASK_INVALID=1910;
var YM88=1911;
var GW_DHCP_SERVER_NETBIOS_PRIMARY_WINS_INVALID=1912;
var YM187=1913;
var GW_NAT_NAME_UNDEFINED_INVALID=1914;
var GW_WIRELESS_RADAR_DETECTED=1915;
var LW25=1916;
var _rs_invalid=1917;
var YM113=1918;
var LW65=1919;
var KR41=1920;
var GW_WAN_DNS_SERVER_PRIMARY_INVALID=1921;
var KR21=1922;
var help643=1923;
var KR63=1924;
var LW31=1925;
var GW_WAN_DNS_SERVER_SECONDARY_INVALID=1926;
var YM55=1927;
var KR37=1928;
var KR80=1929;
var YM100=1930;
var _wakeonlan=1931;
var rs_intro_3=1932;
var gw_gm_35=1933;
var YM7=1934;
var YM124g=1935;
var GW_INET_ACL_MAC_ADDRESS_DUPLICATION_INVALID=1936;
var YM66=1937;
var manul_conn_13=1938;
var bd_NETBIOS=1939;
var sa_Target=1940;
var help56_a=1941;
var GW_DHCP_SERVER_RECONFIG_WARNING=1942;
var _wifisc_addfail=1943;
var GW_WLAN_BEACON_PERIOD_INVALID=1944;
var YM79=1945;
var YM32=1946;
var ta_intro_wcn=1947;
var wwl_text_better=1948;
var YM78=1949;
var sd_channel=1950;
var KR53=1951;
var LW16=1952;
var GW_NAT_TCP=1953;
var help202=1954;
var CRIT=1955;
var YM154=1956;
var help76=1957;
var GW_WISH_RULES_HOST1_PORT=1958;
var GW_WLAN_11G_TURBO_INVALID=1959;
var _aa_bsecure_entertainment=1960;
var YM165=1961;
var help172=1962;
var _aa_bsecure_lifestyles=1963;
var GW_NAT_DMZ_NOT_IN_SUBNET_INVALID=1964;
var sd_TMode=1965;
var GW_NAT_PORT_FORWARD_PORT_RANGE_INVALID=1966;
var GW_QOS_RULES_LOCAL_IP_END_SUBNET=1967;
var bws_CT_2=1968;
var _bsecure_parental_limits=1969;
var aw_64=1970;
var _aa_bsecure_humor=1971;
var KR92=1972;
var KR13=1973;
var GW_INET_ACL_POLICY_NAME_DUPLICATE_INVALID=1974;
var YM136=1975;
var TA3=1976;
var help360=1977;
var YM10=1978;
var GW_WAN_PPTP_SERVER_IP_ADDRESS_INVALID=1979;
var YM150=1980;
var GW_DHCP_SERVER_RESERVATION_IN_USE=1981;
var GW_NAT_INPUT_PORT=1982;
var WIFISC_AP_REBOOT_COMPLETE=1983;
var YM182=1984;
var LW3=1985;
var YM116=1986;
var LW22=1987;
var OOPS=1988;
var YM158=1989;
var ZM16=1990;
var _aa_bsecure_select_age=1991;
var GW_ROUTES_DESTINATION_IP_ADDRESS_INVALID=1992;
var WIFISC_AP_RESET_COMPLETE=1993;
var bd_NETBIOS_REG=1994;
var GW_LAN_GATEWAY_IP_ADDRESS_INVALID=1995;
var KR96=1996;
var GW_XML_CONFIG_GET_SUCCESS=1997;
var GW_UPNP_IGD_PORTMAP_REFRESH=1998;
var bws_msg_WPA_2=1999;
var GW_LAN_IP_ADDRESS_INVALID=2000;
var KR5=2001;
var help88c=2002;
var GW_INET_ACL_SCHEDULE_NAME_INVALID=2003;
var GW_QOS_RULES_REMOTE_PORT=2004;
var GW_NAT_IP_ADDRESS_INVALID=2005;
var help369=2006;
var help48a=2007;
var LW38=2008;
var GW_DYNDNS_USER_NAME_INVALID=2009;
var hhav_r_dest_ip=2010;
var YM175=2011;
var LY3=2012;
var GW_UPNP_IGD_PORTMAP_ADD=2013;
var GW_UPNP_IGD_PORTMAP_CONFLICT=2014;
var KRA1=2015;
var _vs_port=2016;
var GW_INET_ACL_RECONFIGURED_WARNING=2017;
var help186=2018;
var YM145=2019;
var WIFISC_AP_UNSET_SELECTED_REGISTRAR=2020;
var GW_WAN_DNS_SERVER_SECONDARY_WITHOUT_PRIMARY_INVALID=2021;
var YM72=2022;
var _hints=2023;
var GW_QOS_RULES_LOCAL_PORT=2024;
var YM52=2025;
var _aa_bsecure_chat=2026;
var help104=2027;
var help839=2028;
var YM99=2029;
var _aa_bsecure_byage=2030;
var GW_INET_ACL_NAME_DUPLICATE_INVALID=2031;
var GW_DHCP_SERVER_POOL_TO_INVALID=2032;
var KR26=2033;
var YM92=2034;
var GW_DHCP_SERVER_RESERVED_IP_INVALID=2035;
var help19x1=2036;
var _aa_bsecure_unstable=2037;
var GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID=2038;
var GW_FIREWALL_FILTER_NAME_INVALID=2039;
var ZM19=2040;
var YM80=2041;
var bd_NETBIOS_WINS_2=2042;
var KR57=2043;
var YM164=2044;
var _logsyslog_alert2=2045;
var YM149=2046;
var LT120=2047;
var KR48=2048;
var GW_WAN_RECONNECT_INTERVAL_INVALID=2049;
var YM139=2050;
var YM61=2051;
var GW_NAT_VIRTUAL_SERVER_TABLE_RECONFIGURED_WARNING=2052;
var YM1=2053;
var bws_WKL=2054;
var wps_p3_2=2055;
var KR102=2056;
var GW_QOS_RULES_LOCAL_IP_START_SUBNET=2057;
var GW_WAN_PPTP_IP_ADDRESS_INVALID=2058;
var _aa_bsecure_alcohol=2059;
var YM14=2060;
var GW_WLAN_11B_DYNAMIC_TURBO_INVALID=2061;
var GW_UPNP_IGD_PORTMAP_EXPIRE=2062;
var TA18=2063;
var aw_erpe_h2=2064;
var YM21=2065;
var YM147=2066;
var KR68=2067;
var LW61=2068;
var GW_WAN_L2TP_USERNAME_INVALID=2069;
var LT120z=2070;
var KR97=2071;
var GW_WAN_L2TP_SUBNET_INVALID=2072;
var help_ts_ss=2073;
var _aa_bsecure_automobile=2074;
var LW13=2075;
var sch_time=2076;
var bws_intro_WlsSec=2077;
var GW_WAN_PPPOE_PASSWORD_INVALID=2078;
var help211=2079;
var LS202=2080;
var tsc_EndTime=2081;
var KR34=2082;
var _wepkey3=2083;
var at_RePortR=2084;
var help640=2085;
var GW_SMTP_SERVER_ADDRESS_INVALID=2086;
var GW_WAN_L2TP_GATEWAY_IP_ADDRESS_INVALID=2087;
var LW58=2088;
var LW22usekey=2089;
var GW_WLAN_11B_STATIC_TURBO_INVALID=2090;
var YM67=2091;
var GW_WIFISC_CFG_CHANGED_WARNING=2092;
var ZM10=2093;
var GW_WLAN_11A_CHANNEL_INVALID=2094;
var at_title_SERules=2095;
var YM176=2096;
var KR81=2097;
var GW_NAT_TCP_PORT=2098;
var YM155=2099;
var help365=2100;
var bd_NETBIOS_SCOPE=2101;
var KR28=2102;
var _webfilter=2103;
var YM33=2104;
var YM76=2105;
var WIFISC_AP_SETUP_UNLOCKED=2106;
var GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTPS_ADMIN_PORT=2107;
var LS313=2108;
var bwz_WCNWz=2109;
var ZM9=2110;
var GW_DHCP_SERVER_RESERVED_MAC_UNIQUENESS_INVALID=2111;
var LY5=2112;
var YM87=2113;
var GW_NAT_WAN_PING_FILTER_INVALID=2114;
var help835=2115;
var at_lowpriority=2116;
var YM49=2117;
var GW_INET_ACCESS_POLICY_TOO_MANY_IP_INVALID=2118;
var YM112=2119;
var KR90=2120;
var help838=2121;
var help892=2122;
var KR73=2123;
var wwl_intro_s3_2=2124;
var _r_alert5=2125;
var GW_NAT_WAN_PING_FILTER_WARNING=2126;
var YM53=2127;
var help215=2128;
var YM140=2129;
var GW_DHCPSERVER_REJECTED=2130;
var YM142=2131;
var GW_SMTP_PASSWORD_INVALID=2132;
var YM152=2133;
var LT119a=2134;
var LW36=2135;
var help377=2136;
var GW_NAT_PORT_TRIGGER_PORT_RANGE_INVALID=2137;
var YM121=2138;
var YM29=2139;
var YM159=2140;
var YM120=2141;
var wwl_BETTER=2142;
var hhaf_dmz=2143;
var YM106=2144;
var _aa_bsecure_block_unrated=2145;
var GW_WAN_BIGPOND_USERNAME_INVALID=2146;
var KR76=2147;
var GW_DHCPSERVER_EXHAUSTED=2148;
var GW_WAN_L2TP_SERVER_IP_ADDRESS_INVALID=2149;
var wwl_alert_pv5_2=2150;
var GW_ROUTES_SUBNET_INVALID=2151;
var _aa_bsecure_drugs=2152;
var LW1=2153;
var GW_DHCPSERVER_EXPIRED=2154;
var GW_INET_ACL_IP_ADDRESS_IN_LAN_SUBNET_INVALID=2155;
var bd_NETBIOS_REG_TYPE_B=2156;
var _aa_bsecure_financial=2157;
var YM135=2158;
var LT119=2159;
var _vs_public=2160;
var KR93=2161;
var GW_SECURE_REMOTE_ADMINSTRATION=2162;
var YM160=2163;
var LS423=2164;
var GW_WAN_L2TP_GATEWAY_IN_SUBNET_INVALID=2165;
var GW_WISH_RULES_HOST1_IP=2166;
var _vs_private=2167;
var KR86=2168;
var bd_NETBIOS_SEC_WINS=2169;
var GW_INET_ACL_START_IP_ADDRESS_INVALID=2170;
var auth=2171;
var KR24=2172;
var KR17=2173;
var YM84=2174;
var help88=2175;
var hhta_en=2176;
var YM103=2177;
var KR64=2178;
var GW_WLAN_11A_DFS_CHANNEL_INVALID=2179;
var LW4=2180;
var help645=2181;
var GW_WLAN_11A_STATIC_TURBO_INVALID=2182;
var help358=2183;
var YM6=2184;
var _aa_bsecure_categ_select=2185;
var YM58=2186;
var _aa_bsecure_age_youth=2187;
var LW17=2188;
var YM18=2189;
var LT210=2190;
var GW_WAN_IDLE_TIME_INVALID=2191;
var YM186=2192;
var _aa_bsecure_sports=2193;
var GW_QOS_RULES_NAME_ALREADY_USED=2194;
var bwz_intro_WCNWz=2195;
var GW_DHCP_SERVER_POOL_TO_IN_SUBNET_INVALID=2196;
var GW_NAT_H323_ALG_ACTIVATED_WARNING=2197;
var KR4=2198;
var LT120y=2199;
var KR103=2200;
var YM44=2201;
var LW47=2202;
var GW_XML_CONFIG_GET_FAILED=2203;
var WIFISC_AP_SET_APSETTINGS_COMPLETE=2204;
var wwl_WKL=2205;
var YM168=2206;
var GW_NAT_NAME_USED_INVALID=2207;
var GW_DYNDNS_SERVER_INDEX_VALUE_INVALID=2208;
var WARN=2209;
var LW23=2210;
var ADVANCED_NETWORK=2211;
var GW_WAN_PPTP_PASSWORD_INVALID=2212;
var LW59=2213;
var YM126=2214;
var _enabled=2215;
var _r_alert4=2216;
var LY10=2217;
var GW_DHCP_SERVER_POOL_FROM_INVALID=2218;
var WIFISC_AP_SETUP_LOCKED=2219;
var YM91=2220;
var WIFISC_AP_SET_SELECTED_REGISTRAR_FAIL=2221;
var _ask_nochange=2222;
var GW_NAT_UNKNOWN=2223;
var GW_WLAN_11A_DYNAMIC_TURBO_INVALID=2224;
var YM163=2225;
var YM181=2226;
var _cantapplysettings_1=2227;
var YM11=2228;
var wwl_wsp_chars_2=2229;
var bd_NETBIOS_PRI_WINS=2230;
var wwl_DWKL=2231;
var KR44=2232;
var TEXT056=2233;
var YM130=2234;
var KR99=2235;
var GW_DHCP_SERVER_PRIMARY_AND_SECONDARY_WINS_IP_INVALID=2236;
var KR106=2237;
var GW_NAT_VS_PROTOCOL_INVALID=2238;
var KR52=2239;
var KR33=2240;
var ZM23=2241;
var LW40=2242;
var LY4=2243;
var LW34=2244;
var YM25=2245;
var YM15=2246;
var bwl_SGM=2247;
var GW_WLAN_80211X_RADIUS_INVALID=2248;
var GW_WISH_RULES_PROTOCOL=2249;
var LS316=2250;
var ZM15=2251;
var GW_DHCP_SERVER_RESERVATION_DISABLED_IN_CONFLICT_WARNING=2252;
var GW_DYNDNS_HOST_NAME_INVALID=2253;
var LW42=2254;
var GW_WAN_PPTP_GATEWAY_IP_ADDRESS_INVALID=2255;
var rs_intro_4=2256;
var GW_QOS_RULES_REMOTE_IP_END_SUBNET=2257;
var _NA=2258;
var hhav_r_gateway=2259;
var INFO=2260;
var help112=2261;
var tf_msg_FWUgReset=2262;
var bd_NETBIOS_WAN=2263;
var aw_igslot=2264;
var ZM2=2265;
var LT7=2266;
var WIFISC_AP_SET_SELECTED_REGISTRAR=2267;
var help214=2268;
var at_Both=2269;
var ZM22=2270;
var help_ts_rfd=2271;
var help209=2272;
var YM70=2273;
var GW_UPNP_IGD_PORTMAP_VS_CHANGE=2274;
var help143s=2275;
var help363=2276;
var _aa_bsecure_web_newsgroup=2277;
var YM128=2278;
var GW_NAT_PORT_TRIGGER_PORT_RANGE_EMPTY_INVALID=2279;
var KR72=2280;
var td_PWK=2281;
var YM82=2282;
var YM119=2283;
var KR70=2284;
var YM161=2285;
var GW_DHCP_SERVER_POOL_SIZE_INVALID=2286;
var _sdi_s4b=2287;
var ZM8=2288;
var YM129=2289;
var help370=2290;
var LY29=2291;
var GW_XML_CONFIG_WRITE_WARN=2292;
var GW_FIREWALL_NAME_INVALID=2293;
var GW_WISH_RULES_HOST2_IP=2294;
var TA2=2295;
var LS314=2296;
var _vs_traffictype=2297;
var GW_DYNDNS_TIMEOUT_TOO_BIG_INVALID=2298;
var wps_p3_4=2299;
var KR51=2300;
var GW_WAN_PPTP_GATEWAY_IN_SUBNET_INVALID=2301;
var help837=2302;
var TEXT052=2303;
var OPEN=2304;
var _aa_bsecure_news=2305;
var YM34=2306;
var _advwls=2307;
var GW_DHCP_SERVER_RESERVATION_DISABLED_OUT_OF_POOL_WARNING=2308;
var GW_MAC_FILTER_ALL_LOCKED_OUT_INVALID=2309;
var _wepkey4=2310;
var LT124=2311;
var _aa_bsecure_search_engine=2312;
var KR47=2313;
var bws_msg_WEP_3=2314;
var GW_SMTP_LAN_ADDRESS_CONFLICT_WARNING=2315;
var GW_LAN_IP_MODE_INVALID=2316;
var GW_WAN_BIGPOND_SERVER_NOTSTD15=2317;
var GW_WLAN_FRAGMENT_THRESHOLD_INVALID=2318;
var GW_LAN_DOMAIN_NAME_INVALID=2319;
var GW_LAN_DEVICE_NAME_INVALID=2320;
var _wifisc_overlap=2321;
var LW62=2322;
var KR23=2323;
var _aa_bsecure_pornography=2324;
var GW_NAT_NAME_INVALID=2325;
var bd_title_clients=2326;
var YM108=2327;
var YM19=2328;
var WIFISC_AP_PROXY_PROCESS_COMPLETE=2329;
var GW_NAT_ENTRY_DUPLICATED_INVALID=2330;
var GW_NAT_PORT_FORWARD_CONFLICT_INVALID=2331;
var YM38=2332;
var tt_alert_nontp=2333;
var LY2=2334;
var KR29=2335;
var KR31=2336;
var _init_fail=2337;
var YM68=2338;
var sd_macaddr=2339;
var KR12=2340;
var help366=2341;
var WIFISC_AP_REGISTRATION_COMPLETE=2342;
var aw_TPC=2343;
var aw_WDSMAC=2344;
var YM62=2345;
var aw_erpe_h=2346;
var GW_WAN_RECONNECT_MODE_INVALID=2347;
var WIFISC_AP_DEL_APSETTINGS_COMPLETE=2348;
var LW15=2349;
var LW33=2350;
var KR27=2351;
var YM138=2352;
var GW_NAT_VS_PORT_CONFLICT_INVALID=2353;
var bd_NETBIOS_WINS_1=2354;
var _aa_wiz_s6_title=2355;
var YM77=2356;
var YM48=2357;
var YM89=2358;
var GW_WLAN_WPA_PSK_HEX_STRING_INVALID=2359;
var GW_WAN_WAN_IP_ADDRESS_INVALID=2360;
var LS4=2361;
var KR98=2362;
var YM148=2363;
var bws_WPAM_2=2364;
var help877a=2365;
var KR56=2366;
var LS424=2367;
var GW_DHCPSERVER_DECLINED=2368;
var GW_SCHEDULES_DAY_INVALID=2369;
var GW_NAT_UDP=2370;
var IPSMTPCLIENT_CANNOT_CREATE_CONNECTION=2371;
var _aa_check_all=2372;
var LS312=2373;
var KR2=2374;
var _vs_proto=2375;
var GW_SMTP_TO_ADDRESS_INVALID=2376;
var WIFISC_AP_REGISTRATION_FAIL=2377;
var GW_WISH_RULES_NAME_ALREADY_USED=2378;
var LW48=2379;
var YM54=2380;
var LW9=2381;
var LW41=2382;
var ebwl_AChan=2383;
var GW_WLAN_RTS_THRESHOLD_INVALID=2384;
var GW_WAN_L2TP_PASSWORD_INVALID=2385;
var YM12=2386;
var ZM14=2387;
var KR60=2388;
var YM28=2389;
var YM184=2390;
var int_intro_WCNWz7=2391;
var bws_Auth_2=2392;
var rs_intro_1=2393;
var help92=2394;
var GW_NAT_BOTH=2395;
var rs_success=2396;
var up_tz_29b=2397;
var day=2398;
var GW_DHCP_SERVER_DISABLED_WARNING=2399;
var _password=2400;
var GW_INET_ACCESS_POLICY_MAC_INVALID=2401;
var LW2=2402;
var KR75=2403;
var GW_XML_CONFIG_WRITE_FAILED=2404;
var YM73=2405;
var GW_WISH_RULES_NAME_USED_INVALID=2406;
var GW_DHCP_SERVER_POOL_SIZE_IN_SUBNET_INVALID=2407;
var aw_AS=2408;
var YM171=2409;
var GW_DHCP_SERVER_RESERVED_IP_NOT_LAN_IP_INVALID=2410;
var GW_NAT_VS_PUBLIC_PORT_CAN_NOT_MATCH_HTTP_ADMIN_PORT=2411;
var hhav_r_netmask=2412;
var vs_vslist=2413;
var if_iflist=2414;
var YM137=2415;
var YM74=2416;
var GW_SYSLOG_ADDRESS_IN_SUBNET_INVALID=2417;
var help858=2418;
var GW_MAC_FILTER_MAC_UNIQUENESS_INVALID=2419;
var KR40=2420;
var GW_MAC_FILTER_NULL_MAC_INVALID=2421;
var aw_32=2422;
var GW_WAN_LAN_SUBNET_CONFLICT_INVALID=2423;
var LW66=2424;
var WIFISC_AP_DEL_APSETTINGS_FAIL=2425;
var wwl_wsp_chars_1=2426;
var KR85=2427;
var YM115=2428;
var YM83=2429;
var wwl_128bits=2430;
var LW51=2431;
var YM178=2432;
var _aa_bsecure_cults=2433;
var YM5=2434;
var KR65=2435;
var ZM17=2436;
var LW14=2437;
var ta_wcn_bv=2438;
var GW_NAT_VS_IP_ADDRESS_CAN_NOT_MATCH_ROUTER=2439;
var GW_SCHEDULES_IN_USE_INVALID=2440;
var wepkey3=2441;
var KR69=2442;
var YM43=2443;
var YM45=2444;
var GW_SMTP_USERNAME_INVALID=2445;
var help362=2446;
var tf_intro_FWChA=2447;
var _remotedesktop=2448;
var LW7=2449;
var help359=2450;
var KR84=2451;
var YM30=2452;
var at_LoPortR=2453;
var GW_DHCP_SERVER_POOL_FROM_IN_SUBNET_INVALID=2454;
var GW_MAC_FILTER_MULTICAST_MAC_INVALID=2455;
var GW_SMTP_INIT_FAILED_WARNING=2456;
var GW_DHCPSERVER_STOP=2457;
var help350=2458;
var GW_NAT_DMZ_NOT_ALLOWED_INVALID=2459;
var YM143=2460;
var GW_XML_CONFIG_SET_FAILED=2461;
var GW_NAT_PORT_DUP_INVALID=2462;
var KR46=2463;
var KR35=2464;
var GW_WAN_BIGPOND_PASSWORD_INVALID=2465;
var YM57=2466;
var KR104=2467;
var IPSMTPCLIENT_MSG_WRONG_SENDER_ADDR_FORMAT=2468;
var LS317=2469;
var YM102=2470;
var help188=2471;
var _logsyslog_alert1=2472;
var KR3=2473;
var _aa_bsecure_hate=2474;
var GW_WLAN_11BG_CHANNEL_INVALID=2475;
var RATE_ESTIMATOR_RATE_COMPLETED=2476;
var wwl_alert_pv5_3=2477;
var aw_aggr=2478;
var _wifisc_addstart=2479;
var help111=2480;
var GW_QOS_RULES_REMOTE_IP_START_SUBNET=2481;
var YM22=2482;
var GW_WLAN_WDS_MAC_ADDR_INVALID=2483;
var LW10=2484;
var LT291=2485;
var YM156=2486;
var _aa_bsecure_age_ado=2487;
var wwl_text_good=2488;
var GW_QOS_RULES_PRIORITY_RANGE=2489;
var te_OnSch=2490;
var _aa_bsecure_web_mail=2491;
var help188b=2492;
var GW_INET_ACL_START_IP_ADDRESS_IN_LAN_SUBNET_INVALID=2493;
var at_title_Traff=2494;
var help189=2495;
var GW_WIRELESS_SWITCH_CHANNEL=2496;
var GW_WAN_BIGPOND_SERVER_INVALID=2497;
var GW_XML_CONFIG_SET_PARSE=2498;
var hhaw_wmm=2499;
var LT290wifisc=2500;
var GW_FIREWALL_RULE_NAME_INVALID=2501;
var GW_NAT_SCHEDULE=2502;
var help109=2503;
var GW_LAN_RIP_MODE_INVALID=2504;
var LW52=2505;
var _aa_bsecure_popups=2506;
var GW_WLAN_WPA_WPA2_TKIP_INVALID=2507;
var KR16=2508;
var _vs_title=2509;
var _if_title=2510;
var GW_WAN_PPPOE_USERNAME_INVALID=2511;
var GW_WAN_PPTP_SUBNET_INVALID=2512;
var GW_DHCP_SERVER_NETBIOS_SCOPE_INVALID=2513;
var KR94=2514;
var YM63=2515;
var help108=2516;
var GW_SCHEDULES_DUPLICATED_INVALID=2517;
var bws_WPAM_1=2518;
var KR11=2519;
var LW45=2520;
var KR6=2521;
var GW_DHCP_SERVER_NETBIOS_TYPE_INVALID=2522;
var _aa_bsecure_games=2523;
var KR42=2524;
var YM104=2525;
var _aa_bsecure_tickets=2526;
var KR39=2527;
var bd_NETBIOS_REG_TYPE_M=2528;
var tsc_pingt_msg1=2529;
var GW_UPNP_IGD_PORTMAP_DEL=2530;
var YM111=2531;
var LS315=2532;
var GW_WLAN_WPA_PSK_LEN_INVALID=2533;
var help178=2534;
var YM167=2535;
var help371=2536;
var _aa_bsecure_anarchy=2537;
var YM4=2538;
var _aa_bsecure_criminal_skills=2539;
var YM188=2540;
var YM133=2541;
var YM59=2542;
var _aa_bsecure_manually=2543;
var YM169=2544;
var YM97=2545;
var _aa_bsecure_age_child=2546;
var help375=2547;
var GW_WEB_FILTER_WEBSITE_INVALID_INVALID=2548;
var ZM21=2549;
var YM157=2550;
var help213=2551;
var YM24=2552;
var wps_p3_3=2553;
var LW43=2554;
var help99_s=2555;
var YM90=2556;
var bws_CT_3=2557;
var help371_n=2558;
var GW_DHCP_SERVER_RESERVATION_RECONFIG_WARNING=2559;
var _r_alert3=2560;
var GW_LAN_RIP_METRIC_INVALID=2561;
var YM118=2562;
var YM127=2563;
var KR71=2564;
var aw_WDSEn=2565;
var KR32=2566;
var sa_Local=2567;
var GW_WEB_SERVER_IDLE_TIME=2568;
var KR59=2569;
var GW_WAN_WAN_GATEWAY_IN_SUBNET_INVALID=2570;
var at_LoIPR=2571;
var YM81=2572;
var aw_AP=2573;
var LT290=2574;
var YM162=2575;
var GW_XML_CONFIG_SET_PARSE_MIME=2576;
var GW_NAT_UDP_PORT=2577;
var YM9=2578;
var GW_WAN_MTU_INVALID=2579;
var LW63=2580;
var WIFISC_IR_REGISTRATION_SUCCESS=2581;
var help105=2582;
var GW_DHCPSERVER_RELEASED=2583;
var LW32=2584;
var WIFISC_AP_SET_APSETTINGS_FAIL=2585;
var KR8=2586;
var hhav_r_name=2587;
var bd_NETBIOS_REG_TYPE_H=2588;
var KR55=2589;
var GW_WAN_PPPOE_LAN_SUBNET_CONFLICT_INVALID=2590;
var GW_XML_CONFIG_SET_SUCCESS=2591;
var YM60=2592;
var KR100=2593;
var KR61=2594;
var bws_WKL_0=2595;
var bws_msg_WPA=2596;
var YM109=2597;
var WIFISC_AP_RESET_FAIL=2598;
var GW_WISH_RULES_HOST2_PORT=2599;
var help_ts_ls=2600;
var YM101=2601;
var KR50=2602;
var YM56=2603;
var aa_WebSite_Domain=2604;
var GW_QOS_RULES_MAX_TRANS=2605;
var GW_QOS_RULES_PROTOCOL=2606;
var GW_WEB_SERVER_NO_ACCESS=2607;
var KR87=2608;
var GW_WISH_RULES_DUPLICATED=2609;
var YM16=2610;
var GW_SCHEDULES_NAME_CONFLICT_INVALID=2611;
var wepkey4=2612;
var GW_WEB_SERVER_SAME_PORT_WAN=2613;
var YM65=2614;
var bln_title=2615;
var WIFISC_AP_PROXY_PROCESS_FAIL=2616;
var _more=2617;
var ZM12=2618;
var _aa_bsecure_banner_ad=2619;
var LY23=2620;
var help88b=2621;
var bwl_NSS_h1=2622;
var help203=2623;
var GW_INET_ACL_NO_MACHINE_IN_LAN_SUBNET_INVALID=2624;
var LW39c=2625;
var WIFISC_AP_SET_SELECTED_REGISTRAR_COMPLETE=2626;
var GW_DHCP_CLIENT_CLIENT_NAME_INVALID=2627;
var YM166=2628;
var WIFISC_AP_REBOOT_FAIL=2629;
var help91=2630;
var LW39=2631;
var YM173=2632;
var YM13=2633;
var YM172=2634;
var YM31=2635;
var _aa_wiz_s6_msg=2636;
var S493=2637;
var YM85=2638;
var GW_SCHEDULES_NAME_INVALID=2639;
var LS204=2640;
var aw_16=2641;
var aw_erpe_h3=2642;
var LW64=2643;
var _days=2644;
var help103=2645;
var YM183=2646;
var YM117=2647;
var KR54=2648;
var av_intro_r=2649;
var help368=2650;
var hhav_enable=2651;
var GW_WAN_DNS_SERVERS_INVALID=2652;
var _rs_succeeded=2653;
var GW_WAN_PPTP_USERNAME_INVALID=2654;
var GW_WAN_L2TP_IP_ADDRESS_INVALID=2655;
var GW_INET_ACL_NAME_INVALID=2656;
var days=2657;
var KR88=2658;
var GW_WAN_PPPOE_IP_ADDRESS_INVALID=2659;
var KR19=2660;
var RATE_ESTIMATOR_RATE_COMPLETED_WITH_SPEED=2661;
var YM27=2662;
var LT291wifisc=2663;
var KR1=2664;
var YM51=2665;
var ZM13=2666;
var GW_LAN_PRIMARY_DNS_INVALID=2667;
var GW_WLAN_11A_DFS_TURBO_INVALID=2668;
var YM123=2669;
var TA8=2670;
var KR9=2671;
var KR79=2672;
var GW_QOS_RULES_REMOTE_IP=2673;
var _aa_bsecure_age_adult=2674;
var ZM7=2675;
var YM23=2676;
var tf_USSW=2677;
var LW55=2678;
var bwl_EW=2679;
var LS425=2680;
var wwl_WK=2681;
var LW11=2682;
var GW_NAT_PPTP_ALG_ACTIVATED_WARNING=2683;
var YM35=2684;
var tsc_sel_days=2685;
var sc_intro_rb4=2686;
var GW_SCHEDULES_TIME_INVALID=2687;
var GW_DHCP_SERVER_LEASE_TIME_INVALID=2688;
var IPSMTPCLIENT_NO_SERVER_IP_ADDRESS=2689;
var KR10=2690;
var GW_WEB_FILTER_HTTPS_NOT_SUPPORTED_INVALID=2691;
var KR22=2692;
var _vs_both=2693;
var wwl_alert_pv5_4=2694;
var GW_WIFISC_LOCK_VERIFY_ERR=2695;
var LW53=2696;
var GW_WEB_FILTER_WEB_SITE_IS_USED_INVALID=2697;
var YM64=2698;
var GW_ROUTES_INTERFACE_INVALID=2699;
var GW_LAN_SECONDARY_DNS_INVALID=2700;
var bd_NETBIOS_LEARN_FROM_WAN_ENABLE=2701;
var GW_NAT_PORT_FORWARDING_TABLE_RECONFIGURED_WARNING=2702;
var KR15=2703;
var WIFISC_AP_REGISTRATION_UNEXPECTED_EVENT=2704;
var GW_SYSLOG_ADDRESS_NOT_IN_SUBNET_WARNING=2705;
var GW_DHCP_SERVER_NETBIOS_SECONDARY_WINS_INVALID=2706;
var LW49=2707;
var KR95=2708;
var aw_8=2709;
var YM114=2710;
var bws_CT=2711;
var _aa_bsecure_rrated=2712;
var LW6=2713;
var bws_msg_WEP_2=2714;
var GW_QOS_RULES_LOCAL_IP=2715;
var GW_DHCP_SERVER_POOL_FROM_TO_ORIENTATION_INVALID=2716;
var bws_CT_1=2717;
var GW_XML_CONFIG_SET_LOCK=2718;
var GW_DHCP_SERVER_RESERVED_IP_UNIQUENESS_INVALID=2719;
var wepkey2=2720;
var LW28=2721;
var _wepkey1=2722;
var KR83=2723;
var GW_SYSLOG_ADDRESS_INVALID=2724;
var YM105=2725;
var ZM5=2726;
var help212=2727;
var wps_p3_5=2728;
var help19x2=2729;
var KR36=2730;
var GW_ROUTES_METRIC_INVALID=2731;
var GW_WLAN_SSID_INVALID=2732;
var LS46=2733;
var YM179=2734;
var KR78=2735;
var KR66=2736;
var _aa_bsecure_magazine=2737;
var KR101=2738;
var GW_WLAN_WPA_WPA_AES_INVALID=2739;
var GW_NAT_INBOUND_FILTER=2740;
var GW_INET_ACL_POLICY_NAME_INVALID=2741;
var sa_Internet=2742;
var help406=2743;
var YM153=2744;
var at_ReIPR=2745;
var GW_INET_ACCESS_RESTRICTED=2746;
var GW_WLAN_DTIM_INVALID=2747;
var YM144=2748;
var up_tz_26=2749;
var help71=2750;
var GW_PURE_ADDPORTMAPPING_MODIFY=2751;
var tsc_pingt_msg10=2752;
var tps_foo=2753;
var GW_PURE_ADDPORTMAPPING_CHG_PROTOCOL=2754;
var LOG_PREV_MSG_REPEATED_N_TIMES=2755;
var ca_intro=2756;
var GW_WAN_LAN_ADDRESS_CONFLICT_DHCP=2757;
var help176=2758;
var GW_PURE_ADDPORTMAPPING_CREATE=2759;
var hhag_30=2760;
var hhai_save=2761;
var ADMIN=2762;
var wprn_s1a=2763;
var sl_alert_3=2764;
var help900=2765;
var tps_foo2=2766;
var help182=2767;
var aa_alert_12=2768;
var tf_intro_FWCh=2769;
var ts_ss=2770;
var wwa_title_set_pptp=2771;
var _hostname_eg=2772;
var wwl_s4_note=2773;
var help22=2774;
var wwl_alert_pv5_1=2775;
var GW_PURE_SETWLANSETTINGS24=2776;
var help167=2777;
var at_DxDSL=2778;
var wprn_bados2=2779;
var wprn_s3a=2780;
var wprn_tt10=2781;
var bwn_IF=2782;
var _1044a=2783;
var wprn_tt6=2784;
var help72=2785;
var _sdi_s6=2786;
var hhpt_sch=2787;
var tps_enraw=2788;
var sl_alert_2=2789;
var anet_wp_2=2790;
var tss_RestAll=2791;
var GW_PURE_SETWANSETTINGS=2792;
var help53=2793;
var help175=2794;
var help872=2795;
var help785=2796;
var wprn_s2b=2797;
var wprn_intro2=2798;
var GW_INET_ACL_NO_FILTER_SELECTED_INVALID=2799;
var help890=2800;
var help814=2801;
var help283=2802;
var sps_protdis=2803;
var help831=2804;
var _cantapplysettings=2805;
var help39=2806;
var WCN_LOG_ABORT=2807;
var up_tz_73=2808;
var help141_a=2809;
var af_intro_x=2810;
var help170=2811;
var tps_intro4=2812;
var help893b=2813;
var GW_DHCPSERVER_START=2814;
var help887=2815;
var help38=2816;
var help164=2817;
var hhav_filt=2818;
var GW_PURE_ADDPORTMAPPING_CONFLICT=2819;
var GW_PURE_SETROUTERLANSETTINGS=2820;
var GW_PURE_SETWLANSECURITY=2821;
var aa_alert_9=2822;
var help287=2823;
var ta_RAIF=2824;
var help180=2825;
var GW_PURE_SETDEVICESETTINGS=2826;
var _rssi=2827;
var wwl_intro_wel=2828;
var tf_ClickDL=2829;
var help165=2830;
var _vs_other=2831;
var tps_intro5=2832;
var ub_intro_1=2833;
var help277=2834;
var help41=2835;
var VIRTUAL_SERVERS=2836;
var hhav_sch=2837;
var ts_rfd=2838;
var help33b=2839;
var ts_ls=2840;
var GW_PURE_DELETEPORTMAPPING_MODIFY=2841;
var wprn_s2c=2842;
var help320=2843;
var help813=2844;
var help893=2845;
var help803=2846;
var help877=2847;
var up_tz_27=2848;
var help74=2849;
var help155_2=2850;
var _sdi_s4=2851;
var MISC=2852;
var tf_msg_Upping=2853;
var GW_LOG_EMAIL_FAILED=2854;
var help823_17=2855;
var IPV6_TEXT4=2856;
var sa_intro=2857;
var up_rb_2=2858;
var help23=2859;
var _bln_title_IGMPMemberships_h=2860;
var haf_intro_2=2861;
var help802=2862;
var wprn_tt5=2863;
var hhsl_lmail=2864;
var ap_intro_noreboot=2865;
var up_tz_29=2866;
var GW_PURE_SETMACFILTERS2=2867;
var GW_PURE_REBOOT=2868;
var rb_change=2869;
var help816=2870;
var GW_PURE_DELETEPORTMAPPING_DELETE=2871;
var ub_intro_3=2872;
var help30=2873;
var bln_alert_2=2874;
var hhwf_xref=2875;
var GW_REMOTE_ADMINSTRATION=2876;
var wwl_s4_intro=2877;
var sd_SecTyp=2878;
var IPV6_WAN_IP=2879;
var IPV6_TEXT0=2880;
var gw_wcn_alert_3=2881;
var IPV6_TEXT2=2882;
var S473=2883;
var af_ES=2884;
var IPV6_TEXT5=2885;
var IPV6_TEXT6=2886;
var IPV6_TEXT7=2887;
var IPV6_TEXT8=2888;
var IPV6_TEXT9=2889;
var IPV6_TEXT10=2890;
var IPV6_TEXT11=2891;
var IPV6_TEXT12=2892;
var IPV6_TEXT13=2893;
var IPV6_TEXT14=2894;
var IPV6_TEXT15=2895;
var IPV6_TEXT16=2896;
var IPV6_TEXT17=2897;
var IPV6_TEXT18=2898;
var IPV6_TEXT19=2899;
var IPV6_TEXT20=2900;
var IPV6_TEXT21=2901;
var IPV6_TEXT22=2902;
var IPV6_TEXT23=2903;
var DNS_TEXT0=2904;
var IPV6_TEXT25=2905;
var IPV6_TEXT26=2906;
var IPV6_TEXT27=2907;
var IPV6_TEXT28=2908;
var IPV6_TEXT29=2909;
var IPV6_TEXT29a=2910;
var IPV6_TEXT30=2911;
var IPV6_TEXT31=2912;
var IPV6_TEXT32=2913;
var IPV6_TEXT33=2914;
var IPV6_TEXT34=2915;
var IPV6_TEXT35=2916;
var IPV6_TEXT36=2917;
var IPV6_TEXT37=2918;
var IPV6_TEXT38=2919;
var IPV6_TEXT39=2920;
var IPV6_TEXT40=2921;
var IPV6_TEXT41=2922;
var IPV6_TEXT42=2923;
var IPV6_TEXT43=2924;
var IPV6_TEXT44=2925;
var IPV6_TEXT45=2926;
var IPV6_TEXT46=2927;
var IPV6_TEXT47=2928;
var IPV6_TEXT48=2929;
var IPV6_TEXT49=2930;
var TA11=2931;
var IPV6_TEXT51=2932;
var IPV6_TEXT52=2933;
var IPV6_TEXT53=2934;
var IPV6_TEXT54=2935;
var IPV6_TEXT55=2936;
var IPV6_TEXT56=2937;
var IPV6_TEXT57=2938;
var IPV6_TEXT58=2939;
var IPV6_TEXT59=2940;
var IPV6_TEXT60=2941;
var IPV6_TEXT61=2942;
var IPV6_TEXT62=2943;
var IPV6_TEXT63=2944;
var IPV6_TEXT65=2945;
var _aa_bsecure_obscene=2946;
var IPV6_TEXT66=2947;
var IPV6_TEXT67=2948;
var IPV6_TEXT68=2949;
var IPV6_TEXT69=2950;
var IPV6_TEXT70=2951;
var IPV6_TEXT71=2952;
var IPV6_TEXT72=2953;
var IPV6_TEXT73=2954;
var IPV6_TEXT74=2955;
var IPV6_TEXT75=2956;
var IPV6_TEXT76=2957;
var IPV6_TEXT77=2958;
var IPV6_TEXT78=2959;
var IPV6_TEXT79=2960;
var IPV6_TEXT80=2961;
var IPV6_TEXT81=2962;
var IPV6_TEXT82=2963;
var IPV6_TEXT83=2964;
var IPV6_TEXT84=2965;
var IPV6_TEXT85=2966;
var IPV6_TEXT86=2967;
var IPV6_TEXT87=2968;
var IPV6_TEXT88=2969;
var IPV6_TEXT89=2970;
var IPV6_TEXT90=2971;
var IPV6_TEXT91=2972;
var IPV6_TEXT92=2973;
var IPV6_TEXT93=2974;
var IPV6_TEXT94=2975;
var IPV6_TEXT95=2976;
var IPV6_TEXT96=2977;
var IPV6_TEXT97=2978;
var IPV6_TEXT98=2979;
var IPV6_TEXT99=2980;
var IPV6_TEXT100=2981;
var IPV6_TEXT102=2982;
var IPV6_TEXT103=2983;
var IPV6_TEXT104=2984;
var IPV6_TEXT108=2985;
var IPV6_TEXT106=2986;
var IPV6_TEXT107=2987;
var IPV6_TEXT50=2988;
var help825=2989;
var IPV6_TEXT110=2990;
var IPV6_TEXT111=2991;
var IPV6_TEXT112=2992;
var IPV6_TEXT113=2993;
var IPV6_TEXT116=2994;
var IPV6_TEXT117=2995;
var IPV6_TEXT118=2996;
var IPV6_TEXT119=2997;
var IPV6_TEXT120=2998;
var IPV6_TEXT121=2999;
var IPV6_TEXT122=3000;
var IPV6_TEXT123=3001;
var IPV6_TEXT124=3002;
var IPV6_TEXT125=3003;
var IPV6_TEXT126=3004;
var IPV6_TEXT127=3005;
var IPV6_TEXT128=3006;
var IPV6_TEXT129=3007;
var IPV6_TEXT130=3008;
var IPV6_TEXT131=3009;
var IPV6_TEXT132=3010;
var IPV6_TEXT133=3011;
var IPV6_TEXT134=3012;
var IPV6_TEXT135=3013;
var IPV6_TEXT136=3014;
var IPV6_TEXT137=3015;
var IPV6_TEXT138=3016;
var IPV6_TEXT139=3017;
var IPV6_TEXT140=3018;
var IPV6_TEXT141=3019;
var IPV6_TEXT142=3020;
var IPV6_TEXT143=3021;
var IPV6_TEXT144=3022;
var IPV6_TEXT145=3023;
var IPV6_TEXT146=3024;
var bd_EDSv=3025;
var htsc_pingt_h=3026;
var IPV6_TEXT149=3027;
var IPV6_TEXT150=3028;
var IPV6_TEXT151=3029;
var IPV6_TEXT152=3030;
var IPV6_TEXT153=3031;
var wps_KR37=3032;
var IPV6_TEXT155=3033;
var IPV6_TEXT156=3034;
var IPV6_TEXT157=3035;
var IPV6_TEXT158=3036;
var IPV6_TEXT159=3037;
var IPV6_TEXT160=3038;
var IPV6_TEXT161=3039;
var IPV6_TEXT162=3040;
var IPV6_TEXT163=3041;
var IPV6_TEXT164=3042;
var IPV6_TEXT165=3043;
var IPV6_TEXT166=3044;
var haar_p=3045;
var bws_ORAD=3046;
var DNS_TEXT2=3047;
var DNS_TEXT3=3048;
var DNS_TEXT4=3049;
var DNS_TEXT8=3050;
var DNS_TEXT6=3051;
var DNS_TEXT5=3052;
var help639=3053;
var DNS_TEXT9=3054;
var DNS_TEXT10=3055;
var DNS_TEXT11=3056;
var DNS_TEXT12=3057;
var TEXT000=3058;
var TEXT001=3059;
var TEXT002=3060;
var TEXT003=3061;
var TEXT004=3062;
var TEXT005=3063;
var TEXT006=3064;
var TEXT007=3065;
var TEXT008=3066;
var TEXT010=3067;
var sw_title_list=3068;
var TEXT011=3069;
var TEXT012=3070;
var TEXT013=3071;
var TEXT014=3072;
var TEXT015=3073;
var TEXT016=3074;
var TEXT017=3075;
var TEXT018=3076;
var TEXT019=3077;
var TEXT020=3078;
var TEXT021=3079;
var TEXT022=3080;
var LS3=3081;
var TEXT024=3082;
var TEXT025=3083;
var TEXT026=3084;
var TEXT027=3085;
var TEXT028=3086;
var TEXT029=3087;
var TEXT030=3088;
var TEXT031=3089;
var TEXT032=3090;
var TEXT033=3091;
var TEXT035=3092;
var TEXT036=3093;
var TEXT037=3094;
var TEXT038=3095;
var TEXT039=3096;
var TEXT040=3097;
var TEXT041=3098;
var TEXT042=3099;
var TEXT043=3100;
var TEXT045=3101;
var TEXT046=3102;
var TEXT047=3103;
var aa_alert_10=3104;
var TEXT049=3105;
var TEXT050=3106;
var TEXT051=3107;
var TEXT053=3108;
var TEXT055=3109;
var TEXT009=3110;
var TEXT054=3111;
var TEXT057=3112;
var TEXT058=3113;
var TEXT059=3114;
var TEXT060=3115;
var TEXT062=3116;
var TEXT063=3117;
var TEXT064=3118;
var TEXT065=3119;
var TEXT066=3120;
var TEXT067=3121;
var TEXT068=3122;
var TEXT069=3123;
var TEXT070=3124;
var TEXT071=3125;
var TEXT072=3126;
var TEXT073=3127;
var TEXT074=3128;
var TEXT075=3129;
var TEXT076=3130;
var TEXT077=3131;
var TEXT078=3132;
var MSG002=3133;
var MSG003=3134;
var MSG004=3135;
var MSG005=3136;
var MSG006=3137;
var MSG007=3138;
var MSG008=3139;
var MSG009=3140;
var MSG010=3141;
var MSG013=3142;
var MSG014=3143;
var MSG014a=3144;
var MSG015=3145;
var MSG016=3146;
var MSG017=3147;
var MSG018=3148;
var MSG019=3149;
var MSG020=3150;
var MSG021=3151;
var MSG022=3152;
var MSG023=3153;
var MSG024=3154;
var MSG025=3155;
var MSG026=3156;
var MSG027=3157;
var MSG028=3158;
var MSG029=3159;
var MSG030=3160;
var MSG031=3161;
var MSG032=3162;
var MSG033=3163;
var MSG034=3164;
var MSG035=3165;
var MSG036_1=3166;
var MSG037_1=3167;
var MSG038_1=3168;
var MSG039_1=3169;
var MSG036=3170;
var MSG037=3171;
var MSG038=3172;
var MSG039=3173;
var MSG040=3174;
var MSG041=3175;
var MSG042=3176;
var MSG043=3177;
var MSG044=3178;
var MSG045=3179;
var MSG046=3180;
var MSG047=3181;
var MSG048=3182;
var ADV_DNS_DESC3=3183;
var ERROR404=3184;
var SUGGESTIONS=3185;
var SUGGESTIONS_1=3186;
var SUGGESTIONS_2=3187;
var tsc_hrmin_1=3188;
var DHCP_PD=3189;
var IPV6_TEXT147=3190;
var DHCP_PD_ASSIGNED=3191;
var _6to4RELAY=3192;
var IPV6_TEXT64=3193;
var IPV6_TEXT66_v6=3194;
var usb_reboot=3195;
var usb_reboot_chnip=3196;
var country_8=3197;
var _select_phone=3198;
var _phone_info=3199;
var usb_3g_phone=3200;
var usb_window_mobile_5=3201;
var usb_iphone=3202;
var android_phone=3203;
var help901=3204;
var DEVICE_NAME=3205;
var IPDHCPSERVER_LEASE_REVOKED2=3206;
var IPDHCPSERVER_LEASE_RESERVATION_DELETED=3207;
var IPDHCPSERVER_LEASE_RENEW=3208;
var help738=3209;
var help759=3210;
var help517=3211;
var help443=3212;
var help414=3213;
var _ok=3214;
var help486=3215;
var help503=3216;
var help426=3217;
var help432=3218;
var help527=3219;
var awf_intro_WF=3220;
var help652=3221;
var help456=3222;
var help539=3223;
var help472=3224;
var help520=3225;
var help737=3226;
var help646=3227;
var help745=3228;
var help659=3229;
var help727=3230;
var help753=3231;
var help574=3232;
var help663=3233;
var help748=3234;
var hhwf_intro=3235;
var help598=3236;
var help761=3237;
var help510=3238;
var help584=3239;
var help716=3240;
var help440=3241;
var help410=3242;
var help480=3243;
var help559=3244;
var help516=3245;
var help413=3246;
var help619=3247;
var help521=3248;
var help494=3249;
var help498=3250;
var help628=3251;
var help683=3252;
var help535=3253;
var help695=3254;
var help740=3255;
var help578=3256;
var help438=3257;
var help508=3258;
var help423=3259;
var help625=3260;
var help680=3261;
var help568=3262;
var help620=3263;
var help667=3264;
var help766=3265;
var help662=3266;
var help701=3267;
var help542=3268;
var help570=3269;
var help489=3270;
var help723=3271;
var help593=3272;
var help447=3273;
var help705=3274;
var help755=3275;
var _H323=3276;
var help427=3277;
var help485=3278;
var help490=3279;
var help555=3280;
var help462=3281;
var help732=3282;
var help592=3283;
var help455=3284;
var help685=3285;
var help146=3286;
var help655=3287;
var help439=3288;
var help416=3289;
var help726=3290;
var help692=3291;
var help550=3292;
var help714=3293;
var help504=3294;
var help469=3295;
var help629=3296;
var help597=3297;
var help746=3298;
var help749=3299;
var help471=3300;
var help736=3301;
var help596=3302;
var help706=3303;
var help664=3304;
var help702=3305;
var help756=3306;
var help573=3307;
var help601=3308;
var help684=3309;
var help678=3310;
var help760=3311;
var help536=3312;
var help499=3313;
var help562=3314;
var help741=3315;
var help541=3316;
var help717=3317;
var help604=3318;
var help718=3319;
var help551=3320;
var help577=3321;
var help515=3322;
var help621=3323;
var help412=3324;
var help713=3325;
var help687=3326;
var help567=3327;
var help618=3328;
var help441=3329;
var help466=3330;
var gw_vs_5=3331;
var help488=3332;
var help591=3333;
var help402=3334;
var help661=3335;
var help495=3336;
var help587=3337;
var help658=3338;
var help722=3339;
var help483=3340;
var help670=3341;
var help750=3342;
var help452=3343;
var help696=3344;
var help668=3345;
var help433=3346;
var help681=3347;
var help632=3348;
var help409=3349;
var help765=3350;
var help421=3351;
var help725=3352;
var help660=3353;
var help576=3354;
var help751=3355;
var help735=3356;
var help401=3357;
var gw_vs_6=3358;
var help491=3359;
var help448=3360;
var help566=3361;
var help398=3362;
var help586=3363;
var help710=3364;
var help686=3365;
var help537=3366;
var help654=3367;
var help708=3368;
var help424=3369;
var help505=3370;
var help583=3371;
var help430=3372;
var help484=3373;
var help454=3374;
var help556=3375;
var help470=3376;
var help689=3377;
var help464=3378;
var help461=3379;
var tt_Nov=3380;
var help715=3381;
var help622=3382;
var help731=3383;
var help408=3384;
var help688=3385;
var help465=3386;
var help703=3387;
var help697=3388;
var help605=3389;
var help549=3390;
var help506=3391;
var help642=3392;
var help428=3393;
var help682=3394;
var help492=3395;
var help526=3396;
var help631=3397;
var help606=3398;
var help665=3399;
var help148=3400;
var RATE_ESTIMATOR_RESOURCE_ERROR=3401;
var help721=3402;
var gw_vs_2=3403;
var help729=3404;
var help757=3405;
var help595=3406;
var help671=3407;
var help747=3408;
var help707=3409;
var help451=3410;
var help514=3411;
var help512=3412;
var help675=3413;
var help399=3414;
var help626=3415;
var help415=3416;
var help533=3417;
var help572=3418;
var help557=3419;
var help468=3420;
var help724=3421;
var help648=3422;
var wt_title=3423;
var help657=3424;
var help482=3425;
var help679=3426;
var help431=3427;
var help560=3428;
var help742=3429;
var help449=3430;
var help565=3431;
var wprn_tt7=3432;
var help599=3433;
var help585=3434;
var help530=3435;
var help623=3436;
var help758=3437;
var help634=3438;
var help752=3439;
var help575=3440;
var help450=3441;
var ES_CABLELOST_bnr=3442;
var help463=3443;
var help407=3444;
var help453=3445;
var help561=3446;
var help442=3447;
var help762=3448;
var help553=3449;
var help590=3450;
var help608=3451;
var help411=3452;
var gw_vs_4=3453;
var help546=3454;
var help653=3455;
var help481=3456;
var help529=3457;
var help425=3458;
var help400=3459;
var help509=3460;
var _DHCP=3461;
var help709=3462;
var help720=3463;
var help728=3464;
var help467=3465;
var help719=3466;
var help594=3467;
var help457=3468;
var help666=3469;
var help698=3470;
var help538=3471;
var help630=3472;
var help422=3473;
var help493=3474;
var help507=3475;
var help571=3476;
var RATE_ESTIMATOR_CONVERGENCE_ERROR=3477;
var help487=3478;
var help624=3479;
var help543=3480;
var help700=3481;
var help460=3482;
var help730=3483;
var help502=3484;
var help513=3485;
var help690=3486;
var help607=3487;
var help525=3488;
var help754=3489;
var help617=3490;
var help500=3491;
var help558=3492;
var help429=3493;
var help511=3494;
var help534=3495;
var help496=3496;
var help446=3497;
var help739=3498;
var help627=3499;
var _actsess=3500;
var help91a=3501;
var help91b=3502;
var help92x1=3503;
var help92x2=3504;
var TA21=3505;
var TA22=3506;
var help183=3507;
var help400_b=3508;
var help401_b=3509;
var help402_b=3510;
var help403=3511;
var help403_b=3512;
var help404=3513;
var help404_b=3514;
var help405=3515;
var help405_b=3516;
var WIFISC_AP_PEER_CFG_ERR=3517;
var help417=3518;
var help418=3519;
var help419=3520;
var help420=3521;
var help434=3522;
var help435=3523;
var help436=3524;
var help437=3525;
var help444=3526;
var help445=3527;
var help458=3528;
var help459=3529;
var help474=3530;
var help475=3531;
var help476=3532;
var help477=3533;
var help478=3534;
var help479=3535;
var help518=3536;
var help519=3537;
var help522=3538;
var help523=3539;
var help528=3540;
var help531=3541;
var help532=3542;
var help544=3543;
var help545=3544;
var help548=3545;
var help563=3546;
var help564=3547;
var help579=3548;
var help580=3549;
var help581=3550;
var help582=3551;
var help588=3552;
var help589=3553;
var help602=3554;
var help603=3555;
var help609=3556;
var help610=3557;
var help611=3558;
var help612=3559;
var help613=3560;
var help614=3561;
var help615=3562;
var help616=3563;
var tt_Oct=3564;
var sa_Originator=3565;
var help637=3566;
var help641=3567;
var help638=3568;
var msg_non_sec=3569;
var LW24=3570;
var help644=3571;
var help649=3572;
var help650=3573;
var help672=3574;
var help673=3575;
var help676=3576;
var help677=3577;
var help693=3578;
var help694=3579;
var help711=3580;
var help712=3581;
var help733=3582;
var help734=3583;
var help743=3584;
var help744=3585;
var help763=3586;
var help764=3587;
var help795a=3588;
var sa_Internal=3589;
var sa_External=3590;
var DNS_TEXT7=3591;
var help831_1=3592;
var DNS_TEXT1=3593;
var help191=3594;
var help198=3595;
var _unknown_wait=3596;
var _unknown=3597;
var _na=3598;
var _sdi_nciy=3599;
var _sdi_dhcpclient=3600;
var _sdi_bpc=3601;
var help600=3602;
var _bln_nmgmy=3603;
var _sdi_s1=3604;
var _sdi_s10=3605;
var _sdi_s8=3606;
var _sdi_s9=3607;
var _sdi_days=3608;
var _sdi_disconnectpending=3609;
var _sdi_secs=3610;
var sd_Renew=3611;
var sd_Release=3612;
var sd_Disconnect=3613;
var sd_bp_login=3614;
var sd_bp_logout=3615;
var _channel=3616;
var sl_SLogs=3617;
var sps_intro2=3618;
var sps_pare=3619;
var sr_RTable=3620;
var sr_intro=3621;
var ss_title_stats=3622;
var sw_title=3623;
var ta_alert_1=3624;
var ES_CABLELOST_dsc1=3625;
var _pwsame=3626;
var ta_alert_3=3627;
var _invalidddnsserver=3628;
var _blankddnsserver=3629;
var IPV6_TEXT1=3630;
var td_alert_2=3631;
var td_alert_3=3632;
var td_DDNSDDNS=3633;
var tt_SelDynDns=3634;
var _emailaccnameisblank=3635;
var _blankfromemailaddr=3636;
var _blanktomemailaddr=3637;
var _blanksmtpmailaddr=3638;
var _badfromemailaddr=3639;
var _badtoemailaddr=3640;
var _invalidsmtpserveraddr=3641;
var _badsmtpserveraddr=3642;
var tf_NFWA=3643;
var tf_alert_1=3644;
var tf_LFWVis=3645;
var tf_FWCinP=3646;
var tf_Ching_FW=3647;
var tf_EM_not=3648;
var tf_LFWV=3649;
var tf_FWChNow=3650;
var TA17=3651;
var tps_sfp=3652;
var tps_dci=3653;
var tps_intro2=3654;
var tsc_alert_1=3655;
var tsc_alert_2=3656;
var tsc_alert_3=3657;
var tsc_alert_6=3658;
var tsc_alert_9=3659;
var tsc_SelDays=3660;
var tsc_TimeFr=3661;
var tsl_alert_3=3662;
var tsl_alert_1=3663;
var tsl_alert_2=3664;
var ZM18=3665;
var tsc_pingt_msg9=3666;
var help635=3667;
var tt_alert_tupdt=3668;
var TA24=3669;
var TA25=3670;
var fb_FbAc=3671;
var sentinel_1=3672;
var sentinel_2=3673;
var sentinal_3=3674;
var fl_Failure=3675;
var fl_text=3676;
var li_newfw=3677;
var rd_p_1=3678;
var rd_p_2=3679;
var rs_Restoring_Settings=3680;
var reh=3681;
var rs_RSPW=3682;
var rs_cld=3683;
var rs_Done=3684;
var rs_uld=3685;
var rs_usd=3686;
var rs_csd=3687;
var rs_Repacked=3688;
var rs_Converted=3689;
var rs_Saving=3690;
var sc_intro_rb=3691;
var _relogin=3692;
var _badWANsub=3693;
var wwa_pv5_alert_4=3694;
var wwa_pv5_alert_5=3695;
var wwa_pv5_alert_8=3696;
var wwa_pv5_alert_6=3697;
var wwa_pv5_alert_7=3698;
var wwa_pv5_alert_21=3699;
var _badPPTPgwip=3700;
var wwa_pv5_alert_15=3701;
var _badL2TPgwip=3702;
var wwa_pv5_alert_20=3703;
var wwl_intro_s3_1=3704;
var wwl_intro_s3_2r=3705;
var wwl_WSP_1=3706;
var wwl_wpa=3707;
var wwl_wpa2=3708;
var gw_vs_0=3709;
var gw_vs_8=3710;
var gw_sa_0=3711;
var gw_sa_2=3712;
var gw_sa_3=3713;
var gw_sa_4=3714;
var YM47=3715;
var gw_SelBPS=3716;
var gw_bp_0=3717;
var gw_bp_1=3718;
var gw_bp_2=3719;
var gw_gm_81=3720;
var gw_wcn_alert_4=3721;
var gw_wcn_alert5=3722;
var gw_wcn_alert6=3723;
var gw_wcn_alert7=3724;
var gw_wcn_err_ok=3725;
var gw_wcn_err_code=3726;
var gw_wcn_err_os_version=3727;
var gw_wcn_err_load_config=3728;
var gw_wcn_err_provision=3729;
var gw_wcn_err_io_write_config=3730;
var gw_wcn_err_encryption=3731;
var gw_wcn_err_exception=3732;
var gw_wcn_err_com=3733;
var gw_wcn_err_bad_wsetting_entry=3734;
var gw_wcn_err_bad_wps_profile=3735;
var gw_wcn_err_unsupported_wsetting=3736;
var gw_wcn_err_dom_processing=3737;
var gw_wcn_err_default=3738;
var adv_Everyone=3739;
var adv_Noone=3740;
var psQueued=3741;
var psStarting=3742;
var psClosed=3743;
var psIdle=3744;
var psReady=3745;
var GW_PPPOE_EVENT_OFFER=3746;
var psUnplugged=3747;
var psPrinting=3748;
var IPPPPPAP_AUTH_RESULT=3749;
var up_gS_1=3750;
var up_gIUH_1=3751;
var up_gIUH_2=3752;
var up_gIUH_3=3753;
var up_gH_1=3754;
var up_ae_se_1=3755;
var up_ai_se_2=3756;
var up_ae_se_3=3757;
var up_ae_wic_1=3758;
var up_ae_wic_2=3759;
var _Advanced_02=3760;
var up_fm_dc_1=3761;
var up_fm_re_1=3762;
var up_fm_re_2=3763;
var up_fm_dr_1=3764;
var up_fm_dr_2=3765;
var up_fm_dr_3=3766;
var up_if_1=3767;
var up_rb_3=3768;
var up_rb_6=3769;
var up_vp_1=3770;
var up_vp_2=3771;
var up_vp_3=3772;
var up_vp_0=3773;
var up_vm_1=3774;
var up_vm_2=3775;
var up_he_1=3776;
var up_he_2=3777;
var up_he_5=3778;
var gw_sa_5=3779;
var IPSTACK_REJECTED_SPOOFED_PACKET=3780;
var IPDHCPSERVER_HOST_IS_ACTIVE=3781;
var BSECURE_LOG_AUTH_FAIL_UNREG=3782;
var RATE_ESTIMATOR_RATE_IS=3783;
var GW_IPFILTER_DENY=3784;
var GW_SMTP_EMAIL_CANNOT_CREATE_CONNECTION=3785;
var IPNAT_ILLEGAL_DEST=3786;
var BSECURE_LOG_FLTR_DISCONNECTED_TIMEOUT=3787;
var IPDHCPSERVER_LEASE_REVOKED1=3788;
var LOG_PREV_MSG_REPEATED_1_TIME=3789;
var GW_UPNP_PORTMAP_VS_CHANGE=3790;
var IPDHCPSERVER_LEASE_EXPIRED=3791;
var BSECURE_LOG_AUTH_FAIL_INTNL=3792;
var GW_UPNP_PORTMAP_DEL=3793;
var GW_SMTP_EMAIL_INVALID_TO_ADDRESS=3794;
var BSECURE_LOG_FLTR_DISCONNECTED_CLOSED=3795;
var IPDHCPSERVER_LEASE_EXPIRED_SPECIFIC=3796;
var BSECURE_LOG_AUTH_PASS=3797;
var BSECURE_LOG_AUTH_FAIL_UNKNW=3798;
var wwan_auth_pap=3799;
var BSECURE_LOG_AUTH_FAIL_RENEW=3800;
var IPDHCPSERVER_LEASE_DENIED=3801;
var GW_SMTP_EMAIL_TIMEOUT=3802;
var BSECURE_LOG_AUTH_FAIL_DB=3803;
var IPDHCPSERVER_PARAM_DB_UPDATED=3804;
var APP_RULES=3805;
var IPDHCPSERVER_LEASE_POOL_FULL=3806;
var IPPPPPAP_AUTH_SUCCESS=3807;
var ADVANCED_NETWORKS=3808;
var IPDHCPSERVER_LEASE_ASSIGNED=3809;
var BSECURE_LOG_FLTR_CONNECTED=3810;
var BSECURE_LOG_AUTH_CONNECTED=3811;
var BSECURE_LOG_AUTH_FAIL_PKT=3812;
var IPSMTPCLIENT_CONN_FAILED=3813;
var IPPPPPAP_AUTH_FAIL=3814;
var GW_LOG_ON_LATEST_FIRMWARE_RETRIEVED=3815;
var GW_SMTP_EMAIL_SEND_FAILURE=3816;
var IPDHCPSERVER_LEASE_RELEASED=3817;
var IPDHCPSERVER_PARAM_DB_ADDED=3818;
var IPPPPPAP_AUTH_TIMEOUT=3819;
var GW_UPNP_PORTMAP_ADD=3820;
var GW_SMTP_EMAIL_NO_SERVER_IP_ADDRESS=3821;
var GW_UPNP_PORTMAP_REFRESH=3822;
var GW_UPNP_PORTMAP_EXPIRE=3823;
var IPDHCPSERVER_PARAM_DB_REMOVED=3824;
var IPDHCPSERVER_LEASE_DELETED=3825;
var GW_UPNP_PORTMAP_CONFLICT=3826;
var TA1=3827;
var aa_alert_11=3828;
var aa_alert_1=3829;
var aa_sched_conf_3=3830;
var aa_alert_16=3831;
var aa_alert_2=3832;
var aa_alert_3=3833;
var aa_alert_4=3834;
var aa_alert_5=3835;
var aa_alert_6=3836;
var _aa_other_machines=3837;
var _copyright=3838;
var aw_alert_1=3839;
var aw_alert_2=3840;
var aw_alert_3=3841;
var aw_alert_4=3842;
var af_alert_1=3843;
var af_alert_2=3844;
var TA19=3845;
var ag_alert_4=3846;
var ag_alert_5=3847;
var ag_conflict10=3848;
var ag_conflict20=3849;
var ag_conflict21=3850;
var ag_alert_1=3851;
var ag_alert_3=3852;
var ag_alert2=3853;
var _tcpports=3854;
var _udpports=3855;
var ag_conflict4=3856;
var tsc_alert_7=3857;
var ai_alert_3=3858;
var GW_FIREWALL_NO_IP_RANGE_INVALID=3859;
var ai_alert_7=3860;
var ai_alert_4=3861;
var ai_alert_6=3862;
var tsc_alert_5=3863;
var ai_title_2=3864;
var _edit=3865;
var _srcip=3866;
var ai_c2=3867;
var ai_c3=3868;
var amaf_alert_1=3869;
var am_cMT_deny=3870;
var am_cMT_Allow=3871;
var _sr_nriy=3872;
var ar_alert_1=3873;
var ar_alert_2=3874;
var ar_alert_3=3875;
var ar_alert_4=3876;
var ar_alert_5=3877;
var ar_RoutI=3878;
var ar_Route=3879;
var ar_RoutesList=3880;
var _delete=3881;
var ar_ERTable=3882;
var ag_alert_duplicate_name=3883;
var ag_alert_duplicate=3884;
var ag_inuse=3885;
var _specapps_alert_2=3886;
var _specapps_tpr=3887;
var _specapps_ipr=3888;
var as_title_SAR=3889;
var as_TPRange=3890;
var as_ex=3891;
var as_TPR=3892;
var as_IPR=3893;
var as_IPrt=3894;
var at_alert_1_1=3895;
var at_alert_15=3896;
var at_alert_16=3897;
var at_alert_17=3898;
var at_alert_2=3899;
var at_alert_18=3900;
var at_alert_3=3901;
var at_alert_19=3902;
var at_alert_4=3903;
var at_alert_5=3904;
var at_alert_20=3905;
var at_alert_6=3906;
var at_alert_21=3907;
var at_alert_8=3908;
var at_alert_7=3909;
var at_alert_10=3910;
var at_alert_9=3911;
var at_alert_11=3912;
var at_alert_22=3913;
var at_alert_23=3914;
var at_alert_24=3915;
var at_alert_14=3916;
var at_Prot_0=3917;
var _srcport=3918;
var at_DIPR=3919;
var at_DPR=3920;
var av_alert_11=3921;
var av_alert_21=3922;
var av_alert_24=3923;
var av_alert_1=3924;
var av_alert_2=3925;
var av_alert_3=3926;
var av_alert_4=3927;
var av_alert_12=3928;
var av_alert_18=3929;
var av_alert_23=3930;
var av_alert_19=3931;
var av_alert_20=3932;
var av_alert_13=3933;
var av_alert_17=3934;
var av_alert_5=3935;
var av_alert_6=3936;
var av_alert_7=3937;
var av_alert_8=3938;
var av_alert_9=3939;
var av_alert_10=3940;
var _public=3941;
var at_Prot__1=3942;
var _private=3943;
var aa_WebSite=3944;
var awf_alert_4=3945;
var awf_alert_5=3946;
var awf_alert_7=3947;
var awf_alert_8=3948;
var int_ConWz2=3949;
var int_WlsWz=3950;
var hhbi_wiz=3951;
var hhbi_man=3952;
var bd_noneyet=3953;
var bd_revoked=3954;
var bln_alert_3=3955;
var bd_alert_10=3956;
var bd_alert_11=3957;
var bd_alert_1=3958;
var bd_alert_3=3959;
var bd_alert_13=3960;
var bd_alert_12=3961;
var bd_alert_5=3962;
var bd_alert_6=3963;
var bd_alert_7=3964;
var TA20=3965;
var bd_alert_8=3966;
var bd_alert_22=3967;
var bd_alert_23=3968;
var bd_alert_24=3969;
var _badWANIP=3970;
var bwn_alert_2=3971;
var bwn_alert_3=3972;
var bwn_alert_4=3973;
var bwn_alert_5=3974;
var MSG000=3975;
var bwn_alert_8=3976;
var bwn_alert_12=3977;
var _badPPTPip=3978;
var _badPPTPsub=3979;
var _badPPTPipsub=3980;
var bwn_alert_11=3981;
var _badL2TP3=3982;
var _badL2TP=3983;
var _badL2TP2=3984;
var bwn_alert_17=3985;
var bwn_alert_21=3986;
var bws_alert_15=3987;
var bws_alert_16=3988;
var bwl_alert_2=3989;
var bwl_alert_3=3990;
var bwl_alert_15=3991;
var bwl_alert_16=3992;
var bwl_alert_4=3993;
var bwl_alert_5=3994;
var bwl_alert_6=3995;
var bwl_alert_7=3996;
var bwl_alert_8=3997;
var bwl_alert_9=3998;
var bwl_alert_10=3999;
var bws_alert_2=4000;
var bwl_alert_11=4001;
var bwl_alert_12=4002;
var bws_alert_3=4003;
var aw_alert_5_1=4004;
var bwl_alert_13=4005;
var bwl_alert_14=4006;
var bwl_Mode_2=4007;
var bwl_Mode_3=4008;
var bwl_Mode_1=4009;
var bwl_Mode_8=4010;
var bwl_Mode_11=4011;
var bwl_ht20=4012;
var bwl_ht2040=4013;
var bwl_TxR_0=4014;
var TA9=4015;
var YM124=4016;
var TA12=4017;
var TA14=4018;
var TA15=4019;
var _wizard=4020;
var bwz_LConWz=4021;
var bwz_WlsWz=4022;
var bwz_intro_WlsWz=4023;
var bwz_LWlsWz=4024;
var _specapps=4025;
var _gaming=4026;
var _basic=4027;
var ag_alert_empty_name=4028;
var ag_alert_duplicate_name2=4029;
var amaf_alert_2=4030;
var specapps_alert_duplicate_name=4031;
var specapps_alert_duplicate1=4032;
var specapps_alert_conflict1=4033;
var specapps_alert_empty_schedule=4034;
var at_title_TSSet=4035;
var av_alert_35=4036;
var av_alert_empty_name=4037;
var av_alert_16=4038;
var bln_alert_lannbpri=4039;
var bln_alert_lannbsec=4040;
var lan_dns=4041;
var lan_dns2=4042;
var bln_NetBIOSReg_H=4043;
var bln_NetBIOSReg_M=4044;
var bln_NetBIOSReg_P=4045;
var bln_NetBIOSReg_B=4046;
var _help=4047;
var help81ets=4048;
var af_EFT_h4=4049;
var YM134=4050;
var af_EFT_h1=4051;
var af_EFT_h2=4052;
var af_EFT_h5=4053;
var af_UEFT_h1=4054;
var af_TEFT_h2=4055;
var help309A=4056;
var help400_1=4057;
var help401_1=4058;
var help402_1=4059;
var help402_2=4060;
var help405_1=4061;
var help405_2=4062;
var help405_3=4063;
var help405_4=4064;
var _sdi_s1a=4065;
var ta_alert_3b=4066;
var ta_alert_3c=4067;
var ta_alert_3d=4068;
var ta_alert_3e=4069;
var ta_alert_3f=4070;
var ta_alert_3g=4071;
var tps_enlpd=4072;
var ta_LMAP=4073;
var fb_FailLogin=4074;
var fb_FailLogin_1=4075;
var _open=4076;
var _other=4077;
var _223=4078;
var _225ap=4079;
var _226ap=4080;
var _1044wired=4081;
var _1044awired=4082;
var TEXT0=4083;
var regenerate=4084;
var _title_AdvDns=4085;
var _desc_AdvDns=4086;
var ta_EUPNP_dns=4087;
var _st_AdvDns=4088;
var _sp_title_AdvDNS=4089;
var _sp_desc1_AdvDNS=4090;
var _sp_desc2_AdvDNS=4091;
var _sp_desc3_AdvDNS=4092;
var _sp_desc4_AdvDNS=4093;
var TEXT041_1=4094;
var TEXT041_2=4095;
var TEXT041_3=4096;
var TEXT041_4=4097;
var TEXT042_1=4098;
var TEXT042_2=4099;
var GW_URL_INVALID=4100;
var GW_LAN_NETBIOS_SCOPE_INVALID=4101;
var GW_DHCP_SERVER_RESERVED_IP_IN_POOL_INVALID_a=4102;
var bwn_Mode_DHCPPLUS=4103;
var net_sniper_support=4104;
var SEL_DIAL_MODE=4105;
var pppoe_dialmode_normal=4106;
var pppoe_dialmode_sp1=4107;
var pppoe_dialmode_sp2=4108;
var pppoe_dialmode_sp3=4109;
var pppoe_dialmode_sp4=4110;
var pppoe_dialmode_sp5=4111;
var pppoe_dialmode_sp6=4112;
var pppoe_dialmode_learn=4113;
var bt_learn_text=4114;
var box_ip_mac_binding=4115;
var _en_AdvDns=4116;
var xkjs_support=4117;
var ddns_serv_type=4118;
var ddns_domain=4119;
var ddns_account=4120;
var virtual_pub_port_err=4121;
var virtual_pri_port_err=4122;
var virtual_proto_num_err=4123;
var menu_wps=4124;
var tc_iprange=4125;
var help823_15=4126;
var tc_bw=4127;
var tc_schedule=4128;
var tc_new_sch=4129;
var tc_min_bw=4130;
var tc_max_bw=4131;
var _login_admin=4132;
var _login_user=4133;
var pppoe_plus_dail=4134;
var GW_WAN_DHCPPLUS_USERNAME_INVALID=4135;
var GW_WAN_DHCPPLUS_PASSWORD_INVALID=4136;
var te_SMTPPort=4137;
var WLANMODE=4138;
var ROUTER_MODE=4139;
var AP_MODE=4140;
var WDSROUTER_MODE=4141;
var WDSAP_MODE=4142;
var BR_SET=4143;
var device_mode=4144;
var router_mode=4145;
var ap_mode=4146;
var auto_mode=4147;
var enable_WDS=4148;
var ES_AUTODECT=4149;
var _phone=4150;
var ES_CABLELOST_dsc2=4151;
var ES_DONT_CONN_btn=4152;
var ES_UPDATE_SETTING_bnr=4153;
var ES_UPDATE_SETTING_dsc=4154;
var ES_CONFIG_INTERNET_bnr=4155;
var ES_CONFIG_INTERNET_dsc2=4156;
var ES_INTERNET_CONN_dsc=4157;
var ES_MUST_FIELD_dsc=4158;
var ES_DIALUP_ERROR_bnr=4159;
var usb_config1=4160;
var ES_NAME=4161;
var MSG011=4162;
var ES_what_is_this=4163;
var ES_PRI_DNS=4164;
var ES_SEC_DNS=4165;
var ES_GW_ADDR=4166;
var ES_MASK=4167;
var ES_IP_ADDR=4168;
var ES_complete=4169;
var ES_save_dsc=4170;
var ES_status=4171;
var ES_connected=4172;
var ES_unconnected=4173;
var ES_wlan_setting=4174;
var ES_wlan_ssid=4175;
var ES_security=4176;
var ES_unsecured=4177;
var ES_unsecured_suggest=4178;
var ES_save_mySetting=4179;
var ES_sync_pw=4180;
var ES_save=4181;
var ES_network_key=4182;
var ES_autogen_key=4183;
var ES_disable_wifi_sec=4184;
var ES_wifi_sec_recomm=4185;
var ES_current_setting_dsc=4186;
var ES_current_setting=4187;
var ES_manual_btn=4188;
var ES_cancel=4189;
var logout_caption=4190;
var logout_desc=4191;
var logout_return=4192;
var st_connected_time=4193;
var t_ctl_title=4194;
var t_ctl_note=4195;
var t_ctl_note1=4196;
var page_title=4197;
var ac_alert_invalid_port=4198;
var ac_alert_dup_name=4199;
var ac_alert_port_conflit=4200;
var ac_alert_policy_null=4201;
var tt_alert_checkdyndns=4202;
var ES_static_no_internet=4203;
var ES_static_no_internet_desc=4204;
var _CFM_close_window=4205;
var ES_save_result=4206;
var ES_save_success=4207;
var ES_confirm_bt=4208;
var sch_timeformat=4209;
var sch_hourfmt_12=4210;
var sch_hourfmt_24=4211;
var no_available_update=4212;
var clear_lang_pack=4213;
var current_lang_pack_version=4214;
var current_lang_pack_date=4215;
var lang_package_info=4216;
var lang_package_note1=4217;
var lang_package_note2=4218;
var latest_lang_package_ver=4219;
var latest_lang_package_date=4220;
var no_lang_pack=4221;
var pf_name_empty=4222;
var vs_name_empty=4223;
var fw_checksum_err=4224;
var fw_bad_hwid=4225;
var fw_unknow_file_format=4226;
var fw_fw_upgrade_success=4227;
var fw_lp_upgrade_success=4228;
var fw_cfg_upgrade_success=4229;
var ES_timectrl_bnr=4230;
var ES_timectrl_btn=4231;
var ES_webpolicy_btn=4232;
var HW_NAT_desc=4233;
var at_ETS=4234;
var alert_hw_nat_1=4235;
var alert_hw_nat_2=4236;
var alert_hw_nat_3=4237;
var help_auto_disable_hw_nat=4238;
var help_auto_disable_hw_nat_1=4239;
var help_hw_nat=4240;
var help_hw_nat_desc=4241;
var ES_step_wifi_security=4242;
var _pwsame_user=4243;
var ES_btn_try_again=4244;
var ES_auto_detect_desc=4245;
var ES_auto_detect_failed_desc=4246;
var ES_btn_guide_me=4247;
var ES_btn_save_conn=4248;
var ES_btn_save=4249;
var v6_routing=4250;
var v6_routing_table=4251;
var v6_routing_info=4252;
var ipv6=4253;
var ipv6_firewall=4254;
var ipv6_firewall_info=4255;
var _6rd_settings=4256;
var ipv4_addr=4257;
var mask_len=4258;
var IPV6_ULA_TEXT01=4259;
var HW_NAT_enable=4260;
var IPV6_ULA_TEXT03=4261;
var IPV6_ULA_TEXT04=4262;
var IPV6_ULA_TEXT05=4263;
var IPV6_ULA_TEXT06=4264;
var IPV6_ULA_TEXT07=4265;
var IPV6_ULA_TEXT08=4266;
var IPV6_ULA_TEXT09=4267;
var IPV6_ULA_TEXT11=4268;
var IPV6_ULA_TEXT12=4269;
var IPV6_ULA_TEXT13=4270;
var IPV6_ULA_TEXT14=4271;
var IPv6_Local_Info=4272;
var IPv6_Simple_Security=4273;
var anet_multicast_enable_v6=4274;
var IPv6_Wizard_6rd_title=4275;
var fr_name_empty=4276;
var r6_name_empty=4277;
var wwz_wwl_intro_s2_1=4278;
var wwz_wwl_intro_s2_1_1=4279;
var wwz_wwl_intro_s2_1_2=4280;
var wwz_wwl_intro_s2_2=4281;
var wwz_wwl_intro_s2_2_1=4282;
var wwz_wwl_intro_s2_2_2=4283;
var ES_title_s3=4284;
var ES_title_s4=4285;
var ES_title_s5=4286;
var bwl_Mode_n=4287;
var bwl_Mode_a=4288;
var bwl_Mode_5=4289;
var MSG049=4290;
var MSG050=4291;
var HWerr=4292;
var storage=4293;
var sto_into=4294;
var sto_http_0=4295;
var bwn_RPing=4296;
var guestzone_enable=4297;
var sto_http_3=4298;
var LV2=4299;
var sto_http_5=4300;
var sto_creat=4301;
var _add_edit=4302;
var sto_list=4303;
var _modify=4304;
var sto_path=4305;
var help361=4306;
var tt_NTPSrvU=4307;
var sto_dev=4308;
var _total_space=4309;
var _free_space=4310;
var sto_link_0=4311;
var sto_link_1=4312;
var sto_link_2=4313;
var _email_now=4314;
var sto_help=4315;
var _DevLink=4316;
var _folder=4317;
var _browse=4318;
var _append=4319;
var sto_01=4320;
var sto_02=4321;
var _readonly=4322;
var _readwrite=4323;
var _AppendNewFolder=4324;
var KR45=4325;
var MSG052=4326;
var MSG053=4327;
var MSG054=4328;
var _AddFolder=4329;
var _StorageLink=4330;
var LW6_1=4331;
var MSG055=4332;
var ES_title_s5_0=4333;
var save_settings=4334;
var save_wait=4335;
var _Language=4336;
var manul_conn_01=4337;
var manul_conn_02=4338;
var manul_conn_03=4339;
var manul_conn_04=4340;
var manul_conn_05=4341;
var manul_conn_06=4342;
var manul_conn_07=4343;
var manul_conn_08=4344;
var manul_conn_09=4345;
var manul_conn_10=4346;
var manul_conn_11=4347;
var manul_conn_12=4348;
var _aa_bsecure_opinion=4349;
var manul_conn_14=4350;
var manul_conn_15=4351;
var manul_conn_16=4352;
var manul_conn_17=4353;
var manul_conn_18=4354;
var manul_conn_19=4355;
var manul_conn_20=4356;
var manul_conn_21=4357;
var manul_conn_22=4358;
var manul_conn_23=4359;
var manul_conn_24=4360;
var manul_conn_25=4361;
var manul_5g_ssid=4362;
var tf_intro_FWU4=4363;
var tf_intro_FWU5=4364;
var _firmwareUpdate=4365;
var _date=4366;
var _remove=4367;
var notify_wps=4368;
var ag_conflict5=4369;
var _disable=4370;
var coexi=4371;
var wwl_SSP=4372;
var wwz_wwl_intro_s0=4373;
var STATUS_IPV6_DESC_0=4374;
var STATUS_IPV6_DESC_1=4375;
var STATUS_IPV6_DESC_6=4376;
var STATUS_IPV6_DESC_5=4377;
var STATUS_IPV6_DESC_4=4378;
var STATUS_IPV6_DESC_3=4379;
var STATUS_IPV6_DESC_2=4380;
var ag_conflict6=4381;
var TEXT008a=4382;
var TEXT008b=4383;
var TEXT023=4384;
var at_mbps=4385;
var pin_f=4386;
var msg_eap=4387;
var open=4388;
var PRIVATE_PORT_ERROR=4389;
var MSG056=4390;
var MSG057=4391;
var _DestIP=4392;
var _type=4393;
var mydlink_tx03=4394;
var mydlink_tx05=4395;
var sec_left=4396;
var ES_CONN_dsc=4397;
var chk_pass=4398;
var Lname=4399;
var Fname=4400;
var _login=4401;
var ag_conflict22=4402;
var ag_conflict23=4403;
var wifi_enable_chk=4404;
var ZERO_IPV6_ADDRESS=4405;
var port_empty=4406;
var _disable_s=4407;
var IPV6_TEXT154=4408;
var _signup=4409;
var up_tz_74=4410;
var wifi_pass_chk=4411;
var _remove_multi=4412;
var tf_really_langf=4413;
var tf_langf=4414;
var ub_intro_l1=4415;
var ub_intro_l3=4416;
var err404_title=4417;
var err404_detect=4418;
var err404_sug=4419;
var err404_sug1=4420;
var err404_sug2=4421;
var err404_sug3=4422;
var err404_sug4=4423;
var err404_sug5=4424;
var tsc_end_time=4425;
var remote_port_msg=4426;
var TEXT034=4427;
var LW39b=4428;
var _nousername=4429;
var metric_empty=4430;
var TEXT061=4431;
var ES_DIALUP_ERROR_dsc=4432;
var MSG001=4433;
var MSG051=4434;
var MSG012=4435;
var aa_alert_13=4436;
var TEXT044=4437;
var sto_03=4438;
var up_nosave=4439;
var ta_msg_TW=4440;
var sto_04=4441;
var IPV6_TEXT167=4442;
var IPV6_TEXT170=4443;
var help_171=4444;
var DDNS_HOST_ERROR=4445;
var _item_no=4446;
var _usb_not_found=4447;
var srv_name_empty=4448;
var msg_wps_sec_01=4449;
var msg_wps_sec_02=4450;
var msg_wps_sec_03=4451;
var sh_port_tx_00a=4452;
var sh_port_tx_00b=4453;
var sh_port_tx_00=4454;
var sh_port_tx_01=4455;
var sh_port_tx_02=4456;
var sh_port_tx_03=4457;
var sh_port_tx_04=4458;
var sh_port_tx_05=4459;
var sh_port_tx_06=4460;
var sh_port_tx_07=4461;
var sh_port_tx_08=4462;
var sh_port_tx_09=4463;
var sh_port_tx_10=4464;
var sh_port_ddns_01=4465;
var sh_port_ddns_02=4466;
var sh_port_ddns_03=4467;
var sh_port_tx_11=4468;
var sh_port_tx_12=4469;
var sh_port_tx_13=4470;
var sh_port_tx_16=4471;
var sh_port_tx_17=4472;
var sh_port_tx_18=4473;
var sh_port_tx_19=4474;
var sh_port_tx_20=4475;
var sh_port_tx_21=4476;
var sh_port_msg_01=4477;
var sh_port_msg_02=4478;
var sh_port_msg_04=4479;
var sh_port_msg_05=4480;
var sh_port_msg_06=4481;
var sh_port_msg_07=4482;
var sh_port_msg_08=4483;
var sh_port_msg_09=4484;
var sto_http_6=4485;
var file_acc_del_user=4486;
var file_acc_del_path=4487;
var file_acc_del_file=4488;
var _login_a=4489;
var IPv6_ddns_01=4490;
var IPv6_ddns_02=4491;
var IPv6_fw_01=4492;
var IPv6_fw_02=4493;
var IPv6_fw_03=4494;
var IPv6_fw_04=4495;
var IPv6_fw_ipr=4496;
var IPv6_fw_pr=4497;
var IPv6_fw_sr=4498;
var IPv6_fw_dest=4499;
var IPv6_6rd_relay=4500;
var IPv6_6rd_wan=4501;
var IPv6_6to4_relay=4502;
var IPv6_addrSr=4503;
var IPv6_addrEr=4504;
var msg_wps_sec_04=4505;
var msg_wait_sec=4506;
var file_acc_del_empty=4507;
var IPV6_TEXT161a=4508;
var ss_Wstats_2=4509;
var ss_Wstats_5g=4510;
var dlna_t=4511;
var dlna_01=4512;
var dlna_02=4513;
var dlna_03=4514;
var rus_wan_pptp=4515;
var rus_wan_pptp_01=4516;
var rus_wan_l2tp=4517;
var rus_wan_l2tp_01=4518;
var rus_wan_pppoe=4519;
var rus_wan_pppoe_02=4520;
var rus_wan_pppoe_03=4521;
var msg_wps_sec_05=4522;
var webf_login=4523;
var webf_intro=4524;
var webf_title=4525;
var webf_folder=4526;
var webf_hd=4527;
var webf_createfd=4528;
var webf_fd_name=4529;
var webf_upload=4530;
var webf_file_sel=4531;
var dlna_t1=4532;
var dlna_t2=4533;
var help_stor1=4534;
var help_stor2=4535;
var help_stor3=4536;
var help_stor4=4537;
var help_stor5=4538;
var help_stor6=4539;
var help_stor7=4540;
var help_stor8=4541;
var help_stor9=4542;
var help_dlna1=4543;
var webf_non_hd=4544;
var sh_port_tx_22=4545;
var sh_port_tx_23=4546;
var IPv6_Ingress_Filtering_enable=4547;
var share_title_1=4548;
var share_title_2=4549;
var share_title_3=4550;
var share_title_4=4551;
var share_ser_1=4552;
var share_ser_2=4553;
var share_ser_3=4554;
var share_ser_4=4555;
var ddns_disconnecting=4556;
var lan_reserveIP=4557;
var end_ip=4558;
var _NULL=4559;
var ddns_sel2=4560;
var ddns_sel3=4561;
var _remoteipaddr=4562;
var _back=4563;
var _ping_fail=4564;
var _ping_success=4565;
var _wz_disWPS=4566;
var limit_pass_msg=4567;
var _gz_wps_enable=4568;
var _gz_wps_deny=4569;
var bwl_ht204080=4570;
var _supp_close=4571;
var bwl_Mode_ac=4572;
var bwl_Mode_acn=4573;
var bwl_Mode_acna=4574;
var _wireless_2=4575;
var _wireless_5=4576;
var _WPS=4577;
var _statlst=4578;
var _wifiser_title=4579;
var _wifiser_title0=4580;
var _wifiser_title1=4581;
var _wifiser_mode0=4582;
var _wifiser_mode1=4583;
var _wifiser_mode2=4584;
var _wifiser_mode3=4585;
var _wifiser_mode4=4586;
var _wifiser_mode5=4587;
var _wifiser_mode6=4588;
var _wifiser_mode7=4589;
var _wifiser_mode8=4590;
var _wifiser_mode9=4591;
var _wifiser_mode10=4592;
var _wifiser_mode11=4593;
var _wifiser_mode12=4594;
var _wifiser_mode13=4595;
var _wifiser_mode14=4596;
var _wifiser_mode15=4597;
var _wifiser_mode16=4598;
var _wifiser_mode17=4599;
var _wifiser_mode18=4600;
var _wifiser_mode19=4601;
var _wifiser_mode20=4602;
var _wifiser_mode21=4603;
var _wifiser_mode22=4604;
var _wifiser_mode23=4605;
var _wifiser_mode24=4606;
var _wifiser_mode25=4607;
var _wifiser_mode26=4608;
var _wifiser_mode27=4609;
var _wifiser_mode28=4610;
var _wifiser_mode29=4611;
var _wifiser_mode30=4612;
var _wifiser_mode31=4613;
var _wifiser_mode32=4614;
var _wifiser_mode33=4615;
var _wifiser_mode34=4616;
var _wifiser_mode35=4617;
var _wifiser_mode36=4618;
var _wifiser_mode37=4619;
var _wifiser_mode38=4620;
var _wifiser_mode39=4621;
var _wifiser_mode40=4622;
var _wifiser_mode41=4623;
var _adv_txt_00=4624;
var _adv_txt_01=4625;
var _adv_txt_02=4626;
var _adv_txt_03=4627;
var _adv_txt_04=4628;
var _adv_txt_05=4629;
var _adv_txt_06=4630;
var _adv_txt_07=4631;
var _adv_txt_08=4632;
var _adv_txt_09=4633;
var _adv_txt_10=4634;
var _adv_txt_11=4635;
var _adv_txt_12=4636;
var _adv_txt_13=4637;
var _adv_txt_14=4638;
var _adv_txt_15=4639;
var _adv_txt_16=4640;
var _adv_txt_17=4641;
var _adv_txt_18=4642;
var _adv_txt_19=4643;
var _adv_txt_20=4644;
var _adv_txt_21=4645;
var _adv_txt_22=4646;
var _network=4647;
var _management=4648;
var _upload_firm=4649;
var _settings_management=4650;
var _time_cap=4651;
var _system_log=4652;
var _ipv6_status=4653;
var _alg=4654;
var _wan_setting=4655;
var _lan_setting=4656;
var _ipv6_setting=4657;
var _top=4658;
var _network_help=4659;
var _qos_help=4660;
var _wireless_help=4661;
var _administrator_help=4662;
var _wan_conn_type=4663;
var _help_txt2=4664;
var _static=4665;
var _help_txt1=4666;
var _help_txt4=4667;
var _help_txt6=4668;
var _help_txt7=4669;
var _help_txt9=4670;
var _help_txt10=4671;
var _help_txt11=4672;
var _help_txt12=4673;
var _help_txt13=4674;
var _help_txt14=4675;
var _help_txt16=4676;
var _help_txt17=4677;
var _help_txt18=4678;
var _help_txt19=4679;
var _help_txt20=4680;
var _help_txt21=4681;
var _help_txt22=4682;
var _help_txt24=4683;
var _help_txt25=4684;
var _help_txt27=4685;
var _help_txt28=4686;
var _help_txt29=4687;
var _help_txt30=4688;
var _help_txt31=4689;
var _help_txt32=4690;
var _help_txt33=4691;
var _help_txt34=4692;
var _help_txt35=4693;
var _help_txt36=4694;
var _help_txt37=4695;
var _help_txt38=4696;
var _help_txt39=4697;
var _help_txt41=4698;
var _help_txt43=4699;
var _help_txt45=4700;
var _help_txt47=4701;
var _help_txt48=4702;
var _help_txt50=4703;
var _help_txt51=4704;
var _help_txt52=4705;
var _help_txt54=4706;
var _help_txt56=4707;
var _help_txt58=4708;
var _help_txt59=4709;
var _help_txt60=4710;
var _help_txt62=4711;
var _help_txt64=4712;
var _help_txt66=4713;
var _help_txt67=4714;
var _help_txt69=4715;
var _help_txt71=4716;
var _help_txt73=4717;
var _help_txt85=4718;
var _help_txt87=4719;
var _help_txt82=4720;
var _help_txt83=4721;
var _help_txt84=4722;
var _help_txt85=4723;
var _help_txt89=4724;
var _help_txt90=4725;
var _help_txt91=4726;
var _help_txt93=4727;
var _help_txt94=4728;
var _help_txt95=4729;
var _help_txt96=4730;
var _help_txt97=4731;
var _help_txt98=4732;
var _help_txt99=4733;
var _help_txt100=4734;
var _help_txt101=4735;
var _help_txt102=4736;
var _help_txt103=4737;
var _help_txt104=4738;
var _help_txt105=4739;
var _help_txt106=4740;
var _help_txt107=4741;
var _help_txt108=4742;
var _help_txt109=4743;
var _help_txt110=4744;
var _help_txt111=4745;
var _help_txt113=4746;
var _help_txt114=4747;
var _help_txt115=4748;
var _help_txt116=4749;
var _help_txt117=4750;
var _help_txt121=4751;
var _help_txt122=4752;
var _help_txt123=4753;
var _help_txt124=4754;
var _help_txt125=4755;
var _help_txt126=4756;
var _help_txt127=4757;
var _help_txt128=4758;
var _help_txt129=4759;
var _help_txt130=4760;
var _help_txt131=4761;
var _help_txt132=4762;
var _help_txt133=4763;
var _help_txt134=4764;
var _help_txt135=4765;
var _help_txt136=4766;
var _help_txt137=4767;
var _help_txt138=4768;
var _help_txt139=4769;
var _help_txt140=4770;
var _help_txt141=4771;
var _help_txt142=4772;
var _help_txt143=4773;
var _help_txt144=4774;
var _help_txt145=4775;
var _help_txt146=4776;
var _help_txt147=4777;
var _help_txt148=4778;
var _help_txt149=4779;
var _help_txt150=4780;
var _help_txt151=4781;
var _help_txt152=4782;
var _help_txt153=4783;
var _help_txt154=4784;
var _help_txt155=4785;
var _help_txt156=4786;
var _help_txt157=4787;
var _help_txt158=4788;
var _help_txt159=4789;
var _help_txt160=4790;
var _help_txt161=4791;
var _help_txt162=4792;
var _help_txt163=4793;
var _help_txt164=4794;
var _help_txt165=4795;
var _help_txt166=4796;
var _help_txt167=4797;
var _help_txt168=4798;
var _help_txt169=4799;
var _help_txt170=4800;
var _help_txt171=4801;
var _help_txt172=4802;
var _help_txt173=4803;
var _help_txt174=4804;
var _help_txt175=4805;
var _help_txt176=4806;
var _help_txt177=4807;
var _help_txt178=4808;
var _help_txt179=4809;
var _help_txt180=4810;
var _help_txt181=4811;
var _help_txt182=4812;
var _help_txt183=4813;
var _help_txt184=4814;
var _help_txt185=4815;
var _help_txt186=4816;
var _help_txt187=4817;
var _help_txt188=4818;
var _help_txt189=4819;
var _help_txt190=4820;
var _help_txt191=4821;
var _help_txt192=4822;
var _help_txt193=4823;
var _help_txt194=4824;
var _help_txt195=4825;
var _help_txt196=4826;
var _help_txt197=4827;
var _help_txt198=4828;
var _help_txt199=4829;
var _help_txt200=4830;
var _help_txt201=4831;
var _help_txt202=4832;
var _help_txt203=4833;
var _help_txt204=4834;
var _help_txt205=4835;
var _help_txt206=4836;
var _help_txt207=4837;
var _help_txt208=4838;
var _help_txt209=4839;
var _help_txt210=4840;
var _help_txt211=4841;
var _help_txt212=4842;
var _help_txt213=4843;
var _help_txt214=4844;
var _help_txt215=4845;
var _help_txt216=4846;
var _help_txt217=4847;
var _help_txt218=4848;
var _help_txt219=4849;
var _help_txt220=4850;
var _help_txt221=4851;
var _help_txt222=4852;
var _help_txt223=4853;
var _help_txt224=4854;
var _help_txt225=4855;
var _help_txt226=4856;
var _help_txt227=4857;
var _help_txt228=4858;
var _help_txt229=4859;
var _help_txt230=4860;
var _help_txt231=4861;
var _help_txt232=4862;
var _help_txt233=4863;
var _help_txt234=4864;
var _help_txt235=4865;
var _help_txt236=4866;
var _help_txt237=4867;
var _help_txt238=4868;
var _help_txt239=4869;
var _help_txt240=4870;
var _help_txt241=4871;
var _help_txt242=4872;
var _help_txt243=4873;
var _help_txt244=4874;
var _help_txt245=4875;
var _help_txt246=4876;
var _help_txt247=4877;
var _help_txt248=4878;
var _help_txt249=4879;
var _help_txt250=4880;
var _help_txt251=4881;
var _help_txt252=4882;
var _help_txt253=4883;
var _help_txt254=4884;
var _help_txt255=4885;
var _help_txt256=4886;
var _help_txt257=4887;
var _help_txt258=4888;
var _help_txt259=4889;
var _help_txt260=4890;
var _help_txt261=4891;
var _help_txt262=4892;
var _help_txt263=4893;
var _help_txt264=4894;
var _help_txt265=4895;
var _help_txt266=4896;
var _help_txt267=4897;
var _help_txt268=4898;
var _help_txt269=4899;
var _help_txt270=4900;
var _help_txt271=4901;
var _help_txt272=4902;
var _help_txt273=4903;
var _help_txt274=4904;
var _help_txt275=4905;
var _help_txt276=4906;
var _help_txt277=4907;
var _help_txt278=4908;
var _help_txt279=4909;
var _help_txt280=4910;
var _help_txt281=4911;
var _help_txt282=4912;
var _help_txt283=4913;
var _help_txt284=4914;
var _help_txt285=4915;
var _help_txt286=4916;
var _help_txt287=4917;
var _help_txt288=4918;
var _help_txt289=4919;
var _help_txt290=4920;
var _help_txt291=4921;
var _help_txt292=4922;
var _help_txt293=4923;
var _help_txt294=4924;
var _help_txt295=4925;
var _help_txt296=4926;
var _help_txt297=4927;
var _help_txt298=4928;
var _adv_txt_23=4929;
var _adv_txt_24=4930;
var _adv_txt_25=4931;
var _adv_txt_26=4932;
var _adv_txt_27=4933;
var _net_ipv6_01=4934;
var _net_ipv6_02=4935;
var _net_ipv6_03=4936;
var _net_ipv6_04=4937;
var _net_ipv6_05=4938;
var _net_ipv6_06=4939;
var _net_ipv6_07=4940;
var _net_ipv6_08=4941;
var _net_ipv6_09=4942;
var _net_ipv6_10=4943;
var _net_ipv6_11=4944;
var _net_ipv6_12=4945;
var _qos_txt00=4946;
var _qos_txt01=4947;
var _qos_txt02=4948;
var _qos_txt03=4949;
var _qos_txt04=4950;
var _qos_txt05=4951;
var _qos_txt06=4952;
var _qos_txt07=4953;
var _qos_txt08=4954;
var _qos_txt09=4955;
var _qos_txt10=4956;
var _qos_txt11=4957;
var _qos_txt12=4958;
var _qos_txt13=4959;
var _qos_txt14=4960;
var _qos_txt15=4961;
var _qos_txt16=4962;
var _qos_txt17=4963;
var _qos_txt18=4964;
var _qos_txt19=4965;
var _qos_txt20=4966;
var _qos_txt21=4967;
var _qos_txt22=4968;
var _qos_txt23=4969;
var _qos_txt24=4970;
var _qos_txt25=4971;
var _qos_txt26=4972;
var _qos_txt27=4973;
var _qos_txt28=4974;
var _qos_txt29=4975;
var _qos_txt30=4976;
var _qos_txt31=4977;
var _qos_txt32=4978;
var _qos_txt33=4979;
var _qos_txt34=4980;
var _qos_txt35=4981;
var _qos_txt36=4982;
var _qos_txt37=4983;
var _qos_txt38=4984;
var _qos_txt39=4985;
var _qos_txt40=4986;
var _qos_txt41=4987;
var _qos_txt42=4988;
var _qos_txt43=4989;
var _qos_txt44=4990;
var _qos_txt45=4991;
var _qos_txt46=4992;
var _basic_wireless_settings=4993;
var _desc_basic=4994;
var _desc_station_list=4995;
var _desc_wps=4996;
var _wireless_network=4997;
var _wds_long=4998;
var _wps_config=4999;
var _wps_summary=5000;
var _wps_action=5001;
var _dhcp_clients=5002;
var _desc_wps_action=5003;
var _lb_radio_onoff=5004;
var _lb_radio_off_sche=5005;
var _wmode_ssid=5006;
var _lb_multi_ssid_1=5007;
var _lb_multi_ssid_2=5008;
var _lb_multi_ssid_3=5009;
var _lb_multi_ssid_4=5010;
var _lb_multi_ssid_5=5011;
var _lb_multi_ssid_6=5012;
var _lb_multi_ssid_7=5013;
var _lb_broadcast_ssid=5014;
var _lb_phy_mode=5015;
var _lb_enc_type=5016;
var _lb_enc_key=5017;
var _lb_apmacaddr=5018;
var _lb_coexistence=5019;
var _lb_rdg=5020;
var _lb_mcs=5021;
var _lb_exten_channel=5022;
var _lb_a_msdu=5023;
var _lb_autoba=5024;
var _lb_declineba=5025;
var _lb_forty_into=5026;
var _lb_wifi_opt=5027;
var _lb_ht_txstream=5028;
var _lb_ht_rxstream=5029;
var _lb_wps_ext_reg_lock=5030;
var _sel_autoselect=5031;
var _sel_mixed=5032;
var _sel_greenfield=5033;
var _long=5034;
var _btn_radio_on=5035;
var _btn_radio_off=5036;
var _MSG_woff=5037;
var _desc_advanced=5038;
var _bx_advanced_2=5039;
var _bx_advanced_3=5040;
var _bx_advanced_4=5041;
var _lb_bg_protection=5042;
var _hint_beacon=5043;
var _hint_dtim=5044;
var _lb_frag_thres=5045;
var _hint_frag_thres=5046;
var _hint_rts_thres=5047;
var _lb_txpower=5048;
var _lb_short_preamble=5049;
var _lb_short_slot=5050;
var _lb_tx_burst=5051;
var _lb_pkt_aggregate=5052;
var _lb_80211h_support=5053;
var _hint_only_a_band=5054;
var _lb_country_code=5055;
var _lb_wmm_capable=5056;
var _lb_apsd_capable=5057;
var _lb_dls_capable=5058;
var _lb_wmm_param=5059;
var _lb_wmm_config=5060;
var _lb_video_turbine=5061;
var _lb_multi_uni=5062;
var _lb_expire_in=5063;
var _pwr_full=5064;
var _pwr_half=5065;
var _pwr_low=5066;
var _tl_wmm_settings=5067;
var _lb_wmm_param_ap=5068;
var _lb_wmm_param_station=5069;
var m_bwl_Mode_3=5070;
var m_bwl_Mode_8=5071;
var m_bwl_Mode_11=5072;
var m_bwl_Mode5_1=5073;
var m_bwl_Mode5_2=5074;
var m_bwl_Mode5_3=5075;
var _singal=5076;
var _bssid=5077;
var _wps_cur_state=5078;
var _wps_configed=5079;
var _wps_ssid=5080;
var _wps_sec_mode=5081;
var _wps_enc_type=5082;
var _wps_def_key_idx=5083;
var _hex=5084;
var _ascii=5085;
var _wps_key=5086;
var _ap_pin=5087;
var _desc_dhcp_client_list=5088;
var _wifiser_mode42=5089;
var _processing=5090;
var _netwrk_status_addr=5091;
var _system_info=5092;
var _system_time=5093;
var _system_up_time=5094;
var _internet_configs=5095;
var _connected_type=5096;
var _wan_ip_addr=5097;
var _pri_dns=5098;
var _sec_dns=5099;
var _24Ghz_wireless=5100;
var _5Ghz_wireless=5101;
var _SYSLOG_DESC=5102;
var _enable_system_log=5103;
var _time_setting=5104;
var _TIME_DESC=5105;
var _daylight_saving_time=5106;
var _ntp_settings=5107;
var _ntp_server=5108;
var _ntp_sync=5109;
var _date_time_settings=5110;
var _SETTINGS_MANAGER_DESC=5111;
var _export=5112;
var _settings_file_location=5113;
var _import=5114;
var _upgrade_firmw=5115;
var _FIRMW_DESC=5116;
var _FIRMW_DESC_sub=5117;
var _location=5118;
var _apply=5119;
var _system_management=5120;
var _SYS_MANGER_DESC=5121;
var _max_length_characters=5122;
var _device_url_settings=5123;
var _device_url=5124;
var _device_name_settings=5125;
var _ddns_settings=5126;
var _remote_management=5127;
var _remote_control_via_wan=5128;
var _remote_port=5129;
var _reset=5130;
var _ADV_NETWRK_DESC=5131;
var _wan_ping_respond=5132;
var _schedule_rules=5133;
var _SCHEDULE_DESC=5134;
var _add_sche_rule=5135;
var _tsc_allday_24hr=5136;
var _schedule_rule_list=5137;
var _time_stamp=5138;
var _24hr=5139;
var m_bwl_Mode5_4=5140;
var _routing_bet_zone=5141;
var _mac_clone=5142;
var _mac_addr_clone=5143;
var _dns_server_setting=5144;
var _dhcp_setting=5145;
var _DHCP_DESC=5146;
var _wan_setting_l=5147;
var _mtu_default_byte=5148;
var _wan_if_ip_setting=5149;
var _opeartion_mode=5150;
var _keep_alive=5151;
var _keep_alive_mode_redial=5152;
var _on_demand_mode_idle_time=5153;
var _mintues_lower=5154;
var _l2tp_setting=5155;
var _pptp_setting=5156;
var _dynamic=5157;
var _lan_setting_l=5158;
var _LAN_DESC=5159;
var _dhcp_server_setting=5160;
var _dhcp_start_ip=5161;
var _dhcp_end_ip=5162;
var _other_setting=5163;
var _8021d_spanning_tree=5164;
var _lltd=5165;
var _igmp_proxy=5166;
var _pppoe_relay=5167;
var _dns_proxy=5168;
var _add_dhcp_reservation=5169;
var _copy_pc_mac=5170;
var _copy=5171;
var _dhcp_reservation_ready_group=5172;
var _edit_dhcp_reservation=5173;
var _delete_all=5174;
var _delete_selected=5175;
var _config_via_pin=5176;
var _config_via_pbc=5177;
var _alg_config_l=5178;
var _ALG_DESC=5179;
var _description=5180;
var _email_receiving=5181;
var _pop3_l=5182;
var _smtp_l=5183;
var _streaming_media=5184;
var _rtp_l=5185;
var _rtsp_1=5186;
var _mms_l=5187;
var _streaming_media_voip=5188;
var _session_init_protocol_l=5189;
var _h323_l=5190;
var _file_transfer=5191;
var _ftp_l=5192;
var _tftp_l=5193;
var _remote_control=5194;
var _telnet=5195;
var _instant_messaging=5196;
var _msn_messenger=5197;
var _ipsec=5198;
var _save_status=5199;
var _dmz_settings=5200;
var _DMZ_DESC=5201;
var _AC_DESC=5202;
var _add_port_block_rule=5203;
var _policy_enable=5204;
var _policy_name=5205;
var _client_ip_addr=5206;
var _rule_define=5207;
var _special_service=5208;
var _user_define=5209;
var _tcp_ports=5210;
var _ex_21_or_3_500=5211;
var _udp_ports=5212;
var _service=5213;
var _edit_port_block_rule=5214;
var _port_block_rule=5215;
var _add_ip_block_rule=5216;
var _edit_ip_block_rule=5217;
var _ip_block_rule_list=5218;
var _add_weburl_rule=5219;
var _edit_weburl_rule=5220;
var _weburl_rule_list=5221;
var _email_sending=5222;
var _file_transfer_l=5223;
var _telnet_service=5224;
var _dns_query=5225;
var _tcp_protocol=5226;
var _udp_protocol=5227;
var _www=5228;
var _err_ip_addr_format=5229;
var _err_ip_mask=5230;
var _err_input_format=5231;
var _err_ip_addr=5232;
var _static_routing_settings=5233;
var _ROUTING_DESC=5234;
var _add_static_route=5235;
var _dest_ip_addr=5236;
var _dest_ip_mask=5237;
var _physical_port=5238;
var _enable_rip=5239;
var _rip_mode=5240;
var _static_route_list=5241;
var _processing_plz_wait=5242;
var _rebooting_plz_wait=5243;
var _L2TPgw=5244;
var _retry=5245;
var _skip=5246;
var _chk_wanconn_msg_00=5247;
var _tnw_01=5248;
var _tnw_02=5249;
var _tnw_03=5250;
var _tnw_04=5251;
var _ssid=5252;
var _auth_type=5253;
var _finish=5254;
var _tnw_05=5255;
var _tnw_dhcp=5256;
var _tnw_static=5257;
var _tnw_pppoe=5258;
var _tnw_pptp=5259;
var _tnw_l2tp=5260;
var _tnw_06=5261;
var _mac=5262;
var _tnw_clone=5263;
var _tnw_07=5264;
var _wan_ipaddr=5265;
var _wan_submask=5266;
var _wan_gwaddr=5267;
var _dns_1=5268;
var _dns_2=5269;
var _tnw_08=5270;
var _tnw_09=5271;
var _my_ip=5272;
var _server_ip=5273;
var _pptp_account=5274;
var _pptp_password=5275;
var _pptp_password_re=5276;
var _tnw_10=5277;
var _l2tp_account=5278;
var _l2tp_password=5279;
var _l2tp_password_re=5280;
var _tnw_11=5281;
var _tnw_12=5282;
var _tnw_13=5283;
var _tnw_14=5284;
var _print=5285;
var _TAG00840=5286;
var IPV6_TEXT171=5287;
var IPV6_TEXT172=5288;
var _wps_shared=5289;
var _wps_open=5290;
var _webfilterrule_dup=5291;
var _wps_24g=5292;
var _wps_5g=5293;
var _name_ssid=5294;
var _warranty=5295;
var _usb=5296;
var _samba_server=5297;
var _ftp_server=5298;
var _print_server=5299;
var _connected_devices=5300;
var _guest_network=5301;
var _guest_text1=5302;
var _network_bridge=5303;
var _inet_access_only=5304;
var _security_no=5305;
var _security_low=5306;
var _security_middle=5307;
var _security_high=5308;
var _parental_control=5309;
var _has_inet_connection=5310;
var _no_inet_connection=5311;
var _guest_network_enabled=5312;
var _guest_network_disabled=5313;
var _usb_connected=5314;
var _no_usb_connected=5315;
var _household_access=5316;
var _confirm_settings=5317;
var _check_connection=5318;
var _address=5319;
var _ha_rule_list=5320;
var _add_ha_rule=5321;
var _edit_ha_rule=5322;
var _wlan_11n_not_support_wep_wpa_tkip=5323;
var _lb_radio_on_sche=5324;
var _rule_full=5325;
var _wds_cant_enble=5326;
var _LAN_CHK_REBOOT_MSG=5327;
var _specify_url=5328;
var _ipaddr_used=5329;
var _macaddr_used=5330;
var _lan_dr=5331;
var _adv_rtd=5332;
var _lb_a_mpdu=5333;
var PRODUCT_DESC_810=5334;
var PRODUCT_DESC_817=5335;
var _ipaddr_used=5336;
var _macaddr_used=5337;
var no_wan_up=5338;
var dev_mode_ap=5339;
var dev_mode_repeater=5340;
var dev_mode_wisp=5341;
var ap_client=5342;
var extend_ssid=5343;
var wlan_client_list=5344;
var desc_ap=5345;
var desc_repeater=5346;
var desc_wisp=5347;
var wiz_select_site=5348;
var wiz_refresh_site=5349;
var wiz_no_result=5350;
var wiz_no_selected=5351;
var wiz_quit=5352;
var custom_range=5353;
var _internet_setting=5354;
var desc_static_ipv6=5355;
var _s_packet=5356;
var _wps_lock=5357;
var pptp_passthrough=5358;
var l2tp_passthrough=5359;
var desc_ap_lan=5360;
var attain_ip=5361;
var dev_stat=5362;
var desc_ap_sch=5363;
