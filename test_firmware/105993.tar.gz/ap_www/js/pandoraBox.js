var noAuthPage = new Array('login.asp', 'login_fail.asp', 'logout.asp', 'es_base.asp', 
		'es_display.asp', 'summary.asp', 'reject.asp', 'time_ctl.asp', 'error-404.asp', 
		'wizard_router.asp', 'wa_login.asp', 'reject.htm', 'goto_mydlink.asp', 'test_page.asp',
		'setup_wizard_acs.asp', 'reboot.asp');
var noRedirectLogin = new Array('login.asp', 'reject.asp', 'time_ctl.asp',
		'back.asp', 'error-404.asp', 'wps_back.asp', 'reboot.asp', 'wizard_router.asp', 'wa_login.asp', 'reject.asp',
		'wizard_mydlink.asp', 'goto_mydlink.asp','test_page.asp', 'index.asp','tools_firmw_ret.asp', 'login.html');
var noTimeoutPage = new Array('wizard_router.asp', 'wizard_skip.asp', 'setup_wizard.asp', 
		'setup_wizard_mode_set.asp', 'setup_wizard_load_sel.asp', 'setup_wizard_acs.asp');
var gConfig;

function get_time_str(str)
{
	try {
		var n = parseInt(str);
		
		if (n < 10)
			return ('0'+str);
		else
			return str;
	} catch (e) {
		return '00';
	}
}

function show_schedule_detail(idx, sch_obj){
	var detail = '';
	var s_day = '';
	var str_day = new String(sch_obj.days);

	for(var j = 0; j < 8; j++){			
		if(str_day.substr(j, 1) == "1"){
			s_day += (Week[j] + ' ');
		}
	}

	if(sch_obj.allweek == '1' || s_day == ''){
		s_day = "All week";
	}

	var str_time = get_time_str(sch_obj.start_h)+':'+get_time_str(sch_obj.start_mi)+
				'~'+get_time_str(sch_obj.end_h)+':'+get_time_str(sch_obj.end_mi);
	if(sch_obj.allday == '1' || str_time== '00:00~24:00'){
		str_time = "All Day";
	}
	
	detail = s_day + ", " + str_time;
	return detail;
}

function getCookieValue(val) {
	if ((endOfCookie = document.cookie.indexOf(";", val)) == -1) {
		endOfCookie = document.cookie.length;
	}
	return unescape(document.cookie.substring(val,endOfCookie));
}

function getCookie(name) {
	if (document.cookie == null)
		return null
	
	var ckLen = document.cookie.length;
	var sName = name + "=";
	var cookieLen = sName.length;
	var x = 0;
	while (x <= ckLen) {
		var y = (x + cookieLen);
		if (document.cookie.substring(x, y) == sName)
			return getCookieValue(y);
		x = document.cookie.indexOf(" ", x) + 1;
		if (x == 0){
			break;
		}
	}
	return null;
}

function getDocName() {
	var file_name = document.location.pathname;
	var end = (file_name.indexOf("?") == -1) ? file_name.length : file_name.indexOf("?");
	return file_name.substring(file_name.lastIndexOf("/")+1, end);
}

function needAuth(page) {
	if (noAuthPage == null || page == null)
		return 1;

	for (var i=0; i<noAuthPage.length; i++) {
		if (page == noAuthPage[i])
			return 0;
	}
	
	return 1;
}

function isWizard(page) {
	if (noTimeoutPage == null || page == null)
		return 1;

	for (var i=0; i<noTimeoutPage.length; i++) {
		if (page == noTimeoutPage[i])
			return 0;
	}
	return 1;
}

function inst_array_to_string(inst)
{
	var size = inst.length;
	var string = "";
	for(var i=0; i<size; i++)
	{
		string += inst[i];
	}
	//alert("string = "+ string);
	return string;
}

/*function config_val_by_inst(obj_name, param_name, inst)
{
	if ($(gConfig).find(name).size() == 0)
		return null;
	var size = $(gConfig).find(name).size()
	var i=0;

	for
}*/

/**
 *	make_req_entry
 *
 *	obj_name:	name of obj (ex: schRule_RuleName_)
 *	obj_value:	value of obj
 *	obj_inst:	instance of obj (ex: 11000 or 1.1.0.0.0)
 *
 *	return: entry name of the element
 */
function make_req_entry(obj_name, obj_value, obj_inst)
{
	var r = obj_name;
	var s = new String(obj_inst);

	// instance already contains 'dot'
	if (s.indexOf('.') != -1) {
		r += obj_inst+'='+obj_value;
		return r;
	}
	
	for (var i=0; i<obj_inst.length-1; i++) {
		r += (s.substr(i, 1) + '.');
	}
	
	r += s.substr(obj_inst.length-1, 1);
	r += '='+obj_value;
	
	return r;
}

/**
 *	check_addr_order
 *	
 *	return: true: 	start ip is behind end ip
 *			false: 	start ip is after end ip
 *
 *	parameters:
 *		ip_s:	a string of start ip
 *		ip_e:	a string of end ip
 */
function check_addr_order(ip_s, ip_e)
{
	var arr_ips = ip_s.split('.');
	var arr_ipe = ip_e.split('.');

	if (arr_ips == null || arr_ipe == null || 
		arr_ips.length != 4 || arr_ipe.length != 4) {
		return false;
	}
	
	for (var i=0; i<4; i++) {
		if (arr_ips[i] > arr_ipe[i])
			return false;
	}
	
	return true;
}

/**
 *	check_addr
 *	
 *	return: true: 	input ip is a LAN IP
 *			false: 	input ip is NOT a LAN IP
 *
 *	parameters:
 *		ip:		a string of ip we want to check
 *		lanip:	a string of lan ip
 *		mask:	subnet mask
 */
function check_addr(ip, lanip, mask)
{
	if (ip == null || lanip == null || mask == null)
		return false;

	var arr_ip 		= ip.split('.');
	var arr_lanip 	= lanip.split('.');
	var arr_mask	= mask.split('.');
	var err = 0;
	
	// input is not an IP
	if (arr_ip == null || arr_ip.length != 4) {
		alert(LangMap.msg['INVALID_IP']);
		return false;
	}
	
	// check the ip is "0.0.0.0" or not
	if (ip[0] == "0" && ip[1] == "0" && ip[2] == "0" && ip[3] == "0"){
		alert(LangMap.msg['INVALID_IP']);
		return false;
	}
	
	for (var i=0; i<4; i++) {
		if ((arr_ip[i] & arr_mask[i]) == 0) {
			if (arr_ip[i] != 0)
				continue;
		}
		
		if (arr_ip[i] == arr_lanip[i])
			continue;
		err++;
	}
	
	if (err > 0)
		return false;
	else
		return true;
}

/**
 *	getUrlEntry
 *	
 *	return: string: 	value of input key
 *			null: 		not found
 *
 *	parameters:
 *		key:		a string we want to find in url entry
 */
function getUrlEntry(key)
{
	var search=location.search.slice(1);
	//alert(search);
	var my_id=search.split("&");
	//alert(my_id);
	try {
		for(var i=0;i<my_id.length;i++)
		{
			var ar=my_id[i].split("=");
			if(ar[0]==key)
			{
				return ar[1];
			}
		}
	} catch (e) {
	}
	
	return null;
} 

function redirect_login()
{
	var file = window.location.pathname.replace(/^.*\/(\w{2})\.asp$/i, "$1").replace('/', '');
	
	for (var i=0; i<noRedirectLogin.length; i++) {
		if (file == noRedirectLogin[i])
			return;
	}

	document.cookie = 'hasLogin=0;';
	
	setTimeout(function() {
		location.replace('login.asp');
	}, 0);
}

function urlencode(text){
	text = text.toString();
	var matches = text.match(/[\x90-\xFF]/g);
	if (matches)
	{
		for (var matchid = 0; matchid < matches.length; matchid++)
		{
			var char_code = matches[matchid].charCodeAt(0);
			text = text.replace(matches[matchid], '%u00' + (char_code & 0xFF).toString(16).toUpperCase());
		}
	}
	//return escape(text).replace(/\+/g, "%2B");
	return text.replace(/[<>+\&\"\'\=\%]/g, function(c) { return '%' + (c.charCodeAt(0) & 0xFF).toString(16).toUpperCase() + ''; });
}

function urldecode(text){
	return decodeURIComponent(text);
}

function disableDiv(divname, opt)
{
	var divObj=document.getElementById(divname);
	var elInput = divObj.getElementsByTagName("input");
	for(i=0;i<elInput.length;i++)
	{
		elInput[i].disabled=opt;
	}
}


/**
 * the following 2 functions are used to check if port range is overlapped
 *
 * add_into_timeline()
 * 
 * parameters:
 * 		timeline: 	an input variable for recording all port range.
 *		port_s:		start port of the range.
 *		port_e:		end port of the range. (if single port, this parameter should be empty or null)
 *
 * return:
 * 		timeline:	timeline for the following reference.
 */
function add_into_timeline(timeline, port_s, port_e)
{
	var cur_state = 0;
	
	// inital
	if (timeline == null || timeline == '') {
		if (port_e == null || port_e == '') {
			timeline = new Array(2);
			timeline[0] = port_s;
			timeline[1] = 0;			// single port
		} else {
			timeline = new Array(4);
			timeline[0] = port_s;
			timeline[1] = 1;			// up
			timeline[2] = port_e;
			timeline[3] = 2;			// down
		}
		return timeline;				// successfully added into timeline
	}
	
	// check if there exist something wrong in timeline
	var rec_port_s = 0;
	var length = timeline.length;
	for (var i=0; i<length; i+=2) {
		// add port_s first
		if (parseInt(timeline[i]) > parseInt(port_s) && rec_port_s == 0) {
			if (port_e == null || port_e == '')	{ 	//single port
				timeline.splice(i, 0, 0);			// add state first
				timeline.splice(i, 0, port_s);		// add port number
				return timeline;					// successfully added into timeline
			} else {
				var addPort_e = false;
				rec_port_s = 1;
				timeline.splice(i, 0, 1);			// add state first
				timeline.splice(i, 0, port_s);		// add port number
				for (var j=i; j<timeline.length; j+=2) {
					if (parseInt(timeline[j]) > parseInt(port_e)) {
						timeline.splice(j, 0, 2);			// add state first
						timeline.splice(j, 0, port_e);		// add port number
						addPort_e = true;
						return timeline;
					}
				}
				
				if (addPort_e == false) {
					var append_idx = timeline.length;
					timeline.splice(append_idx, 0, 2);
					timeline.splice(append_idx, 0, port_e);
					return timeline;
				}
				continue;
			}
		}
		
		if (rec_port_s == 0)
			continue;
		
		// add port_e
		if (parseInt(timeline[i]) > parseInt(port_e)) {
			timeline.splice(i, 0, 2);			// add state first
			timeline.splice(i, 0, port_e);	// add port number
			break;
		}
	}
	
	if (timeline.length == length) {			// append to last of timeline
		if (port_e == null || port_e == '') {	// single port
			timeline.splice(length, 0, 0);
			timeline.splice(length, 0, port_s);
		} else {
			timeline.splice(length, 0, 2);
			timeline.splice(length, 0, port_e);
			timeline.splice(length, 0, 1);
			timeline.splice(length, 0, port_s);
		}
	}
	
	return timeline;
}

/**
 * 	check_timeline()
 *
 *	parameter:
 *		timeline:	an input timeline for checking.
 *
 *	return:
 *		true:		no overlapped.
 *		false:		contains an overlapped.
 */
function check_timeline(timeline)
{
	var prev_port = -1;
	var prev_stat = 0;
	
	if (timeline == null || timeline == '')
		return true;

	for (var i=0; i<timeline.length; i+=2) {
		if (prev_port == parseInt(timeline[i]))
			return false;
		
		if (prev_stat == 1 && timeline[i+1] != 2)
			return false;
		
		prev_port = timeline[i];
		if (timeline[i+1] != 0)
			prev_stat = timeline[i+1];
	}
	
	return true;
}

function translateFormObjToAJAXArg(form_id)
{
	var df = document.forms[form_id];
	if (!df) {
		return;
	}
	
	var str = "";
	for (var i = 0, k = df.elements.length; i < k; i++) {
		var obj = df.elements[i];

		var name = obj.name;
		var value = obj.value;
		
		str +="&"+name+"="+value;
	}
	
	return str;
}

function check_hw_nat_enable()
{
	if(get_checked_value(get_by_id('HW_NAT_Enable')) == "1")
	{
		if((spi_enable == "1") || (trafficshap_enable == "1"))
			return confirm(get_words("alert_hw_nat_1"));
	}
	return true;
}

function escape(text)
{
	return text.replace(/[<>\&\"\']/g, function(c) { return '&#' + c.charCodeAt(0) + ';'; });
}


function json_ajax(param)
{
	var time=new Date().getTime();
	var myData = null;
	var ajax_param = {
		type: 	"POST",
		async:	false,
		url: 	param.url,
		data: 	param.arg+"&"+time+"="+time,
		dataType: "json",
		success: function(data) {
			if (data['status'] != 'fail') {
				myData = data;
				return;
			}
			
			alert('error: '+data['errno']);
			location.replace('wa_login.asp');
			
		},
		error: function(xhr, ajaxOptions, thrownError){
			if (xhr.status == 200) {
				try {
					setTimeout(function() {
						document.write(xhr.responseText);
					}, 0);
				} catch (e) {
				}
			} else {
			}
		}
	};
	
	try {
		//setTimeout(function() {
			$.ajax(ajax_param);
			return myData;
		//}, 0);
	} catch (e) {
	}	
}

function sp_words(passwd)	//20120112 silvia add
{
	//var wd = new Array(passwd);
	var wd = passwd.split('');
	var nwd = '';
	var wds = '';
	var  len = passwd.length;
	for (var i = 0;i < len; i++)
	{
		switch (wd[i]){
			case '&':
				wds = '&amp;';
				break;
			case '"':
				wds = '&quot;';
				break;
			case '<':
				wds = '&lt;';
				break;
			case '>':
				wds = '&gt;';
				break;
			case ' ':
				wds = '&nbsp;';
				break;
			default :
				wds = wd[i];
				break;
		}
		nwd += wds;
	}
	return nwd;
}


function check_browser()	//chk support bookmark and lang
	{
		var isMSIE = (-[1,]) ? false : true;
		var is_support =0;
		if(window.sidebar && window.sidebar.addPanel){ //Firefox
			is_support = 1;
		}else if (isMSIE && window.external) {  //IE favorite
			is_support = 2;
		}
		return is_support;
	}
	
function chk_browser_lang()
	{
		var tem_lang;
		var is_support=check_browser();
		if (is_support == 2)	//only for ie
			tmp_lang = language = window.navigator.userLanguage;
		else	// for other browser
			tmp_lang = window.navigator.language;
		currLindex = lang_compare(tmp_lang);
		return currLindex;
	} 
	
function lang_compare(tlang)
	{
		var lang;
		if(tlang.indexOf('en')==0)
			lang = '1';
		else if(tlang.indexOf('es')==0)
			lang = '2';
		else if(tlang.indexOf('de')==0)
			lang = '3';
		else if(tlang.indexOf('fr')==0)
			lang = '4';
		else if(tlang.indexOf('it')==0)
			lang = '5';
		else if(tlang.indexOf('ru')==0)
			lang = '6';
		else if(tlang.indexOf('pt-BR')==0)
			lang = '21';
		else if(tlang.indexOf('pt')==0)
			lang = '7';
		else if(tlang.indexOf('ja')==0)
			lang = '8';
		else if((tlang.indexOf('tw')!=-1) || (tlang.indexOf('TW')!=-1))
			lang = '9';
		else if((tlang.indexOf('cn')!=-1) || (tlang.indexOf('CN')!=-1))
			lang = '10';
		else if(tlang.indexOf('ko')==0)
			lang = '11';
		else if(tlang.indexOf('cs')==0)
			lang = '12';
		else if(tlang.indexOf('da')==0)
			lang = '13';
		else if(tlang.indexOf('el')==0)
			lang = '14';
		else if(tlang.indexOf('fi')==0)
			lang = '15';
		else if(tlang.indexOf('hr')==0)
			lang = '16';
		else if(tlang.indexOf('hu')==0)
			lang = '17';
		else if(tlang.indexOf('nl')==0)
			lang = '18';
		else if(tlang.indexOf('no')==0)
			lang = '19';
		else if(tlang.indexOf('pl')==0)
			lang = '20';
		else if(tlang.indexOf('ro')==0)
			lang = '22';
		else if(tlang.indexOf('sl')==0)
			lang = '23';
		else if(tlang.indexOf('sv')==0)
			lang = '24';
		else
			lang = '1';
		return lang;
	}

function termsOfUse_link(num_lang){
	//Jerry, use user select lang instead of browser's
	//var num_lang =chk_browser_lang();
	var lang ="";
	switch(num_lang){
		case "1":
			lang = "en";
			break;
		case "2":
			lang = "es";
			break;
		case "3":
			lang = "de";
			break;
		case "4":
			lang = "fr";
			break;
		case "5":
			lang = "it";
			break;
		case "6":
			lang = "ru";
			break;
		case "7":
			lang = "pt";
			break;
		case "8":
			lang = "ja";
			break;
		case "9":
			lang = "zh_TW";
			break;
		case "10":
			lang = "zh_CN";
			break;
		case "11":
			lang = "ko";
			break;
		case "12":
			lang = "cs";
			break;
		case "13":
			lang = "da";
			break;
		case "14":
			lang = "el";
			break;
		case "15":
			lang = "fi";
			break;
		case "16":
			lang = "hr";
			break;
		case "17":
			lang = "hu";
			break;
		case "18":
			lang = "nl";
			break;
		case "19":
			lang = "no";
			break;
		case "20":
			lang = "pl";
			break;
		case "21":
			lang = "pt_BR";
			break;
		case "22":
			lang = "ro";
			break;
		case "23":
			lang = "sl";
			break;
		case "24":
			lang = "sv";
			break;
		default:
			lang = "en";
			break; 
		}
	return lang;
	}

	function mail_addr_test(str)
	{
		var rlt = 0;
		var tmp = str.split("@");
		try{
	        if(tmp.length == 2 && /^([+]?)*([a-zA-Z0-9]*[_|\-|\.|\+|\%|\*|\?|\!|\\]?)*[a-zA-Z0-9]*([+]?)+$/.test(tmp[0]) && /^([a-zA-Z0-9]*[_|\-|\.|\+|\%|\*|\?|\!|\\]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,6}$/.test(tmp[1])){
	            rlt = 1
	        }
		}catch(e){}
		return rlt;
	}

	function media_server_chk(str)
	{
		var rlt = 0;
		try{
	        if(str != '' && /^([+]?)*([a-zA-Z0-9]*[_|\-|\.|\+|\%|\*|\?|\!|\\]?)*[a-zA-Z0-9]*([+]?)+$/.test(str)){
	            rlt = 1
	        }
		}catch(e){}
		return rlt;
	}
	
	function mac_format(str)
	{
		var mac="";
		for(var i=0; i<6; i++)
		{
			if(i!=5)
				mac+= str.substring(i*2,i*2+2) + ":";
			else
				mac+= str.substring(i*2,i*2+2);
		}		
		return mac;
	}


/**
 *	ajax_load_page
 *
 *	This function is used to load dynamic page, especially for top and left menu.
 *
 *	parameter:
 *		page:	page name to load.
 *		disp:	display the loaded page in this object.
 *		sel_id:	selected id
 *
 *	return:
 *		void
 */
function ajax_load_page(page, disp, sel_id)
{
	var miscObj = new ccpObject();
	var dev_info = miscObj.get_router_info();
	var v4v6 = dev_info.v4v6_support;

		if (v4v6 == '1')
			$('.v6_use').show();
	var ajax_param = {
		type: 	"POST",
		async:	true,
		url: 	page,
		datatype: 'html',
		success: function(data) {
			try {
				$('#'+disp).html(data);
				
				if (sel_id != null && sel_id.indexOf('top_') == 0)
					$('#'+sel_id).addClass('topnavon');
				else if (sel_id != null && sel_id.indexOf('left_') == 0){
					$('#'+sel_id+'>a').removeAttr('href').removeAttr('onclick');
					$('#'+sel_id).addClass('sidenavon');
				}
			} catch (e) {
				alert('Cannot load '+ page + ' into '+ disp + '!');
			}
		},
		error: function(xhr, ajaxOptions, thrownError){
			if (xhr.status == 200) {
				try {
					setTimeout(function() {
						document.write(xhr.responseText);
					}, 0);
				} catch (e) {
				}
			}
		}
	};
	
	try {
		$.ajax(ajax_param);
	} catch (e) {
}
}

/*
**    Date:		2013-04-11
**    Author:	Silvia Chang
**    Reason:   Move it!! For Gateway Name use.
**/
function check_dev_name(devName)
{
	if (devName == null)
		return false;

	var all_num = true;

	for (var i=0; i<devName.length; i++) {
		var data = devName.substring(i, i+1);

		// check if at least one char is not an number
		if ((data >= 'A' && data <= 'Z') || (data >= 'a' && data <= 'z')) {
			all_num = false;
		}

		// first bit must be a-z or A-Z, 0-9
		if ((i == 0) && !(data >= 'A' && data <= 'Z') && !(data >= 'a' && data <= 'z') && !(data >= '0' && data <= '9')) {
			return false;
		}

		if ((data >= 'A' && data <= 'Z') || (data >= '0' && data <= '9') || (data >= 'a' && data <= 'z') || data == '-' || data == '_') {
			continue;
		}

		return false;
	}

	if (all_num == true) {
		return false;
	}

	return true;
}

/*
**    Date:		2013-04-11
**    Author:	Silvia Chang
**    Reason:   Check Host name cannot entry  `;:|'"\
**/
function check_client_name(name)
{
	var re = /[`;:|'"\\]/;
	if(re.test(name)){
		return false;
	}
	return true;
}

/*
** Check PPTP or L2TP Server IP Address is IP pattern or not
** @author:	Pascal Pai
** @date:	2013-05-23
** @param:	ip_str - ip address in string
** 			flag - 1 check v4 only
** 					2 check v6 only
** 					3 check both v4/v6(default)
** @note:		Moa: 2013-05-29 fixed for ip extract and shorter regex
				Moa: 2013-08-05 add for check if ipv6 address or not
				Moa: 2013-10-23 enhance: It can check which ip version by 2nd parameter
**/
function ip_pattern(ip_str,flag)
{
	if(flag==undefined)
		flag=3;
	var v4_pattern = /^\d+(\.\d+){3}$/;
	var v6_pattern = /^((?=.*::)(?!.*::.+::)(::)?([\dA-F]{1,4}:(:|\b)|){5}|([\dA-F]{1,4}:){6})((([\dA-F]{1,4}((?!\3)::|:\b|$))|(?!\2\3)){2}|(((2[0-4]|1\d|[1-9])?\d|25[0-5])\.?\b){4})$/i;
	if((flag & 0x1) && v4_pattern.test(ip_str)){
		return true;
	}
	if((flag & 0x2) && v6_pattern.test(ip_str)){
		return true;
	}
	return false;
}

/*
**    Date:		2013-07-02
**    Author:	Silvia Chang
**    Reason:	fixed DIR-820L Pre-test bug No.207 ntp can't get right time zone when win 7 os in -8:00 time zone (english version) ,see spec. p18
**    Note:		Timezone Auto Detect w/o Daylight Saving Time
**/
function TimezoneDetect()
{
	var dtDate = new Date('1/1/' + (new Date()).getUTCFullYear());
	var intOffset = 10000;
	var intMonth;

	for (intMonth=0;intMonth < 12;intMonth++){
		dtDate.setUTCMonth(dtDate.getUTCMonth() + 1);

		if (intOffset > (dtDate.getTimezoneOffset() * (-1))){
			intOffset = (dtDate.getTimezoneOffset() * (-1));
		}
	}
	return intOffset;
}

/**
**    Date:		2013-07-23
**    Author:	Silvia Chang
**    Reason:   Uplink SSID w/ extra strings can not more than 32 chars.
**/
function get_uplink_ssid(Uplink_ssid, SSID_maxlength, ext_string)
{
	var cut_len = SSID_maxlength - ext_string.length;
	if ( Uplink_ssid.length > cut_len)
		var new_ssid = Uplink_ssid.substr(0,cut_len-1) + ext_string;
	else
		var new_ssid = Uplink_ssid + ext_string;
	return new_ssid;
}


/**
**    Date:		2013-08-01
**    Author:	Silvia Chang
**    Reason:	for cortina setup wizard
**/
function disable_all_btn(is_disable)
{
	var input_objs = document.getElementsByTagName("input");

	if (input_objs != null){
		for (var i = 0; i < input_objs.length; i++){
			if (input_objs[i].type == "button" || input_objs[i].type == "submit" || input_objs[i].type == "reset"){
				input_objs[i].disabled = is_disable;
			}
		}
	}
}

function check_sp_char(str)
{
	if (!is_ascii(str))
		return true;
	var sp = /\\/;
	if (sp.test(str))
		return true;
	var check_str = new Array( "\"", ">", "<", "/" );
	for (var i = 0; i < check_str.length; i++)
		if (str.search(check_str[i]) != -1)
			return true;
	return false;
}

//20120228 silvia add get url
function get_ip(next_page)
{
	if (!next_page)
		var next_page="";
	var web_url;
	var temp_cURL = document.URL.split('/');

	if (temp_cURL[0] == "https:")
		web_url="https://"+temp_cURL[1]+temp_cURL[2]+'/' + next_page;
	else
		web_url="http://"+temp_cURL[1]+temp_cURL[2]+'/' + next_page;
	return web_url;
}

function ip_num(IP_array){
	var total1 = 0;
	if(IP_array.length > 1){
		total1 += parseInt(IP_array[3],10);
		total1 += parseInt(IP_array[2],10)*256;
		total1 += parseInt(IP_array[1],10)*256*256;
		total1 += parseInt(IP_array[0],10)*256*256*256;
	}
	return total1;
}


/*
** page's  callback handler of permission
** @author:	Moa Chung
** @date:	2013-08-29
** @param:	perm - permission of current user
** 			wcb - permission 'w' callback function
** 			scb - permission 's' callback function
** 			rcb - permission 'r' callback function
*/
function page_permission(perm, wcb, scb, rcb)
{
	if(perm=='w')
	{
		wcb();
	}
	else if(perm=='s')
	{
		scb();
	}
	else if(perm=='r')
	{
		rcb();
	}
	else// impossable
	{
	}
}

/*
** show/hide between input[type=password] and input[type=text]
** tested under chrome,safari,opera,fx,IE8,IE11
** checked - password, unckecked - text
** @author:	Moa Chung
** @date:	2013-09-12
** @param:	that - the checkbox DOM
** 			ids - all id of password box (support multi by ,)
** 			revert - set checked type, true=password,false=text(default:false)
*/
function showHideBox(that, ids, revert)
{
	var aIds = ids.split(',');
	$(aIds).each(function(idx,id){
		if($(that).is(':checked') ^ revert){
			$('#'+id+'[type=text]').hide();
			$('#'+id+'[type=password]').show();
		}
		else{
			$('#'+id+'[type=text]').show();
			$('#'+id+'[type=password]').hide();
		}
	});
}

/*
** clone user's pc mac to specify tag id
** @author:	Moa Chung
** @date:	2013-10-03
** @param:	mac - mac to clone
** 			id - id of tag
*/
function clone_mac_action(mac, id)
{
	$('#'+id).val(mac);
}

/*
** NTT special function(TSD 0027081)
** check ip SHOULD NOT in private address class A(10.0.0.0/8) subnet
** @author:	Moa Chung
** @date:	2013-10-22
** @param:	ip_obj - ipv4 address, type is addr_obj()
** @return:	true - allow this setting
** 		false - deny this setting
*/
function check_private_IP_class_A(ip_obj)
{
	if((ip_obj.addr.length == 4) && (ip_obj.addr[0] == "10")){
		alert(LangMap.which_lang['ipaddr_msg0']);
		return false;
	}
	return true;
}

/*
** keep page session
** @author:	Moa Chung
** @date:	2013-11-15
*/
function poke(){
	setInterval(function(){
		var obj = new ccpObject();
		obj.set_param_url('get_set.ccp');
		obj.set_ccp_act('get');
		obj.add_param_arg('IGD_',1000);
		obj.ajax_submit();
	},120000);
}

/*
** convert subnet mask format to prefix length format
** @author:	Moa Chung
** @date:	2013-12-13
** @param:	s_ip - string of ip format
** @note:	if parameter is not a mask, It will return null
*/
function mask2prefix(s_ip){
	var a_ip = s_ip.split('.');
	var i_ip = ip_num(a_ip);
	var b_ip_r = i_ip.toString(2).split('').reverse().join('');
	var i_ip_r = parseInt(b_ip_r,2);
	var prefix = 0;
	
	while(i_ip_r & 0x1){
			prefix++;
			i_ip_r = i_ip_r>>>1;
	}
	if(i_ip_r!=0)
		return null;
	return prefix;
}

/*
** check if a valid domain name or not
** @author:	Moa Chung
** @date:	2014-02-24
** @param:	string - domain name to check
*/
function isDomainName(string){
    string += "";
    return string.match(/^[\x2D-\x2E\x30-\x39\x41-\x5A\x5F\x61-\x7A]+$/) ? true : false;
}

/*
** determine DNSEnabled by current setting. The function only use in setting datamodel.
** @author:	Moa Chung
** @date:	2013-10-14
** @param:	dns1 - value of primary dns
** 			dns2 - value of secondary dns
** @note:	It can move to pandoraBox.js
*/
function isDNSEnabled(dns1, dns2)
{
	return (dns1!='' && dns1!='0.0.0.0' || dns2!='' && dns2!='0.0.0.0');
}
/*
** formatted dns servers to datamodel-format. The function only use in setting datamodel.
** @author:	Moa Chung
** @date:	2013-10-14
** @param:	dns1 - value of primary dns
** 			dns2 - value of secondary dns
** @note:	It can move to pandoraBox.js
*/
function makeDNSServers(dns1, dns2)
{
	return (dns1==''?'0.0.0.0':dns1)+','+(dns2==''?'0.0.0.0':dns2);
}

/*
** NTT special function
** check ip SHOULD NOT in such subdomain which is specified by parameter 2
** @author:	Moa Chung
** @date:	2014-02-26
** @param:	ip_obj - ipv4 address, type is string
** 			cidr - subnet to check(represent by CIDR format)
** @return:	true - in subdomain
** 			false - not in subdomain
*/
function isInSubdomain(ip, cidr)
{
	var networkAddr = cidr.split('/')[0];
	var prefix = parseInt(cidr.split('/')[1],10);
	var a = ip_num(networkAddr.split('.'))
	var b = ip_num(ip.split('.'))
	return ((a^b)>>>0)>>(32-prefix)==0;
}

/*
** focus and select all text in which given seletor for UX foolproof
** @author:	Moa Chung
** @date:	2014-03-25
** @param:	selector - selector of dom element
*/
function focusSelect(selector){
	$(selector).focus().select();
	return true;
}
function getmonth(str){
	var month = ['_Jan', '_Feb', '_Mar', '_Apr', '_May', '_Jun', '_Jul', '_Aug', '_Sep', '_Oct', '_Nov', '_Dec'];
	var month2 = ['tt_Jan', 'tt_Feb', 'tt_Mar', 'tt_Apr', 'tt_May', 'tt_Jun', 'tt_Jul', 'tt_Aug', 'tt_Sep', 'tt_Oct', 'tt_Nov', 'tt_Dec'];
	var idx = parseInt(str,10);
	return LangMap.which_lang[month[idx]]||LangMap.which_lang[month2[idx]];
}
function getweekday(str){
	var week = ['_Sun', '_Mon', '_Tue', '_Wed', '_Thu', '_Fri', '_Sat'];
	var week2 = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
	var idx = parseInt(str,10);
	return LangMap.which_lang[week[idx]]||LangMap.which_lang[week2[idx]];
}
function prezero(str){
	str = (parseInt(str) < 10)?('0'+str):str;
	return str;
}
function splitdns(str,order){
	return str.split(',')[order]||'0.0.0.0';
}

function encode_base64(psstr) {
	return encode(psstr,psstr.length); 
}

function encode (psstrs, iLen) {
	var map1="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/{}|[]\:;'<>?,.~!@#$%^&*()_-+=\"";
	var oDataLen = (iLen*4+2)/3;
	var oLen = ((iLen+2)/3)*4;
	var out='';
	var ip = 0;
	var op = 0;
	while (ip < iLen) {
		var xx = psstrs.charCodeAt(ip++);
		var yy = ip < iLen ? psstrs.charCodeAt(ip++) : 0;
		var zz = ip < iLen ? psstrs.charCodeAt(ip++) : 0;
		var aa = xx >>> 2;
		var bb = ((xx &   3) << 4) | (yy >>> 4);
		var cc = ((yy & 0xf) << 2) | (zz >>> 6);
		var dd = zz & 0x3F;
		out += map1.charAt(aa);
		op++;
		out += map1.charAt(bb);
		op++;
		out += op < oDataLen ? map1.charAt(cc) : '='; 
		op++;
		out += op < oDataLen ? map1.charAt(dd) : '='; 
		op++; 
	}
	return out; 
}

function autoIncrement(obj){
	var replace = $(obj).data('replace')
	var type = $(obj).data('type')
	var txt = $(obj).data('format')
	if(type=='date'){
		date = new Date($(obj).data('seconds')*1000);
		txt = txt
		.replace('%Y', date.getFullYear())
		.replace('%m', prezero(date.getMonth()+1))
		.replace('%n', (date.getMonth()+1))
		.replace('%M', getmonth(date.getMonth()))
		.replace('%d', prezero(date.getDate()))
		.replace('%j', (date.getDate()+1))
		.replace('%N', (date.getDay()+1))
		.replace('%D', getweekday(date.getDay()))
		.replace('%G', (date.getHours()))
		.replace('%H', prezero(date.getHours()))
		.replace('%i', prezero(date.getMinutes()))
		.replace('%s', prezero(date.getSeconds()))
	}
	else{
		sec = $(obj).data('seconds')
		day = Math.floor(sec/86400);
		r = (sec%86400)
		hour = Math.floor(r/3600,0);
		r = (r%3600)
		minute = Math.floor(r/60);
		r = (r%60)
		second = Math.floor(r);
//		console.log(day,hour,minute,second)
		txt = txt
		.replace('%d', day+' '+get_words('tt_Day'))
		.replace('%H', hour)
		.replace('%i', minute)
		.replace('%s', second)
	}
	$(obj).text(txt);
	$(obj).data('seconds',$(obj).data('seconds')+1)
	
	setTimeout(function(){$(obj).trigger('auto-increment')},1000);
}

function setNameFromId(formSelector){
	var elms = $($(formSelector)[0].elements).filter('[id]:not([name])');
	elms.each(function(idx,e){
		e.name=e.id;
	});
};

$(function(){
if($.validator){
	var alertErr = function(errMap, errList){
		if(errList[0])
			alert(errList[0].message);
		return false;
	};

	$.validator.setDefaults({
		showErrors: alertErr,
		ignore: ':hidden,[disabled],.ignore',
		onkeyup: false,
		onfocusout: false,
		onclick: false
	});

	$.validator.messages = {
		required:		LangMap.which_lang.rule_msg_required,
		remote:			LangMap.which_lang.rule_msg_remote,
		email:			LangMap.which_lang.rule_msg_email,
		url:			LangMap.which_lang.rule_msg_url,
		date:			LangMap.which_lang.rule_msg_date,
		dateISO:		LangMap.which_lang.rule_msg_dateISO,
		number:			LangMap.which_lang.rule_msg_number,
		digits:			LangMap.which_lang.rule_msg_digits,
		creditcard:		LangMap.which_lang.rule_msg_creditcard,
		equalTo:		LangMap.which_lang.rule_msg_equalto,
		maxlength:		$.validator.format(LangMap.which_lang.rule_msg_maxlength),
		minlength:		$.validator.format(LangMap.which_lang.rule_msg_minlength),
		rangelength:	$.validator.format(LangMap.which_lang.rule_msg_rangelength),
		range:			$.validator.format(LangMap.which_lang.rule_msg_range),
		max:			$.validator.format(LangMap.which_lang.rule_msg_max),
		min:			$.validator.format(LangMap.which_lang.rule_msg_min),
		
		alpha:			LangMap.which_lang.rule_msg_alpha,
		alphanum:		LangMap.which_lang.rule_msg_alphanum,
		alphadash:		LangMap.which_lang.rule_msg_alphadash,
		notequalto:		LangMap.which_lang.rule_msg_notequalto,
		odd:			LangMap.which_lang.rule_msg_odd,
		even:			LangMap.which_lang.rule_msg_even,
		ipv4format:		LangMap.which_lang.rule_msg_ipv4format,
		ipv4addr:		LangMap.which_lang.rule_msg_ipv4addr,
		ipv4addrzero:	LangMap.which_lang.rule_msg_ipv4addr,
		ipv4indomain:	LangMap.which_lang.rule_msg_ipv4indomain,
		ipv4classa:		LangMap.which_lang.rule_msg_ipv4classa,
		ipv4classb:		LangMap.which_lang.rule_msg_ipv4classb,
		ipv4classc:		LangMap.which_lang.rule_msg_ipv4classc,
		ipv4mask:		LangMap.which_lang.rule_msg_ipv4mask,
		notipv4classa:	LangMap.which_lang.rule_msg_notipv4classa,
		notipv4classb:	LangMap.which_lang.rule_msg_notipv4classb,
		notipv4classc:	LangMap.which_lang.rule_msg_notipv4classc,
		notipv4multicast:LangMap.which_lang.rule_msg_notipv4multicast,
		notipv4reserved:LangMap.which_lang.rule_msg_notipv4reserved,
		notipv4broadcast:LangMap.which_lang.rule_msg_notipv4broadcast,
		ipv6addrformat:	LangMap.which_lang.rule_msg_ipv6addrformat,
		ipv6addr:		LangMap.which_lang.rule_msg_ipv6addr,
		ascii:			LangMap.which_lang.rule_msg_ascii,
		notempty:		LangMap.which_lang.rule_msg_notempty,
		hostname:		LangMap.which_lang.rule_msg_hostname,
		macaddr:		LangMap.which_lang.KR3,
		notsamein:		LangMap.which_lang.rule_msg_notsamein,
		snmpoid:		LangMap.which_lang.rule_msg_snmpoid,
		snmpoidmask:	LangMap.which_lang.rule_msg_snmpoidmask,
		none:			'none'
	};

	$.validator.regex = {
		alpha: /^[a-z]+$/i,
		alphanum: /^[a-z0-9]+$/i,
		alphadash: /^[a-z0-9_\-]+$/i,
		ipv4format: /^(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)$/i,
		ipv4addr: /^(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-4]|2[0-4]\d|1\d\d|[1-9]\d|[1-9])$/i,
		ipv4addrzero: /^0.0.0.0|(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-4]|2[0-4]\d|1\d\d|[1-9]\d|[1-9])$/i,
		ipv6addrformat: /^((([0-9a-f]{1,4}:){7}[0-9a-f]{1,4})|(([0-9a-f]{1,4}:){6}:[0-9a-f]{1,4})|(([0-9a-f]{1,4}:){5}:([0-9a-f]{1,4}:)?[0-9a-f]{1,4})|(([0-9a-f]{1,4}:){4}:([0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})|(([0-9a-f]{1,4}:){3}:([0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})|(([0-9a-f]{1,4}:){2}:([0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})|(([0-9a-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9a-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9a-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9a-f]{1,4}::([0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})|(::([0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})|(([0-9a-f]{1,4}:){1,7}:))$/i,
		ipv6zero: /^(((0:){7}0)|((0:){6}:0)|((0:){5}:(0:)?0)|((0:){4}:(0:){0,2}0)|((0:){3}:(0:){0,3}0)|((0:){2}:(0:){0,4}0)|((0:){6}(0.0.0.0))|((0:){0,5}:(0.0.0.0))|(::([0-9a-f]{1,4}:){0,5}(0.0.0.0))|(0::(0:){0,5}0)|(::(0:){0,6}0)|((0:){1,7}:))$/i,
		ascii: /^[\x00-\x7F]+$/,
		hostname: /^[a-z][a-z0-9\-]+[a-z0-9]$/i,
		macaddr: /^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$/i,
		snmpoid: /^(\.\d+)+$/i,
		snmpoidmask: /^(?:[0-9A-F]{2}(?:\:|.)){1,15}[0-9A-F]{2}$/i,
		hex: /^[a-f0-9]+$/i,
		none:			'none'
	};
	
	$.validator.methods.notempty = function(value, element, param) {
		return value!=='';
	};
	// a-z
	$.validator.methods.alpha = function(value, element, param) {
		return this.optional(element) || $.validator.regex.alpha.test(value);
	};
	// a-z0-9
	$.validator.methods.alphanum = function(value, element, param) {
		return this.optional(element) || $.validator.regex.alphanum.test(value);
	};
	// a-z0-9_\-
	$.validator.methods.alphadash = function(value, element, param) {
		return this.optional(element) || $.validator.regex.alphadash.test(value);
	};
	$.validator.methods.ascii = function(value, element, param) {
		return this.optional(element) || $.validator.regex.ascii.test(value);
	};
	//see http://en.wikipedia.org/wiki/Hostname
	$.validator.methods.hostname = function(value, element, param) {
		return this.optional(element) || $.validator.regex.hostname.test(value);
	};
	$.validator.methods.odd = function(value, element, param) {
		var b = true;
		if(!(b&=$.validator.methods.number.call(this, value, element))){
			$.validator.messages.odd = $.validator.messages.number;
		}
		b&=(parseInt(value)%2==0);
		return b;
	};
	$.validator.methods.even = function(value, element, param) {
		var b = true;
		if(!(b&=$.validator.methods.number.call(this, value, element))){
			$.validator.messages.even = $.validator.messages.number;
		}
		b&=(parseInt(value)%2==0);
		return b;
	};
	// 0.0.0.0~255.255.255.255
	$.validator.methods.ipv4format = function(value, element, param) {
		return $.validator.regex.ipv4format.test(value);
	};
	// not all zero,multicast,reserved,broadcast
	$.validator.methods.ipv4addr = function(value, element, param) {
		var b = true;
		if(!(b&=$.validator.methods.ipv4format(value, element, param))){
			$.validator.messages.ipv4addr = $.validator.messages.ipv4format;
		}
		else if(!(b&=$.validator.regex.ipv4addr.test(value))){
			$.validator.messages.ipv4addr = $.validator.messages.ipv4addr;
		}
		else if(!(b&=!isInSubdomain(value,'0.0.0.0/8'))){
			$.validator.messages.ipv4addr = $.validator.messages.ipv4addr;
		}
		else if(!(b&=$.validator.methods.notipv4multicast(value))){
			$.validator.messages.ipv4addr = $.validator.messages.notipv4multicast;
		}
		else if(!(b&=$.validator.methods.notipv4broadcast(value))){
			$.validator.messages.ipv4addr = $.validator.messages.notipv4broadcast;
		}
		else if(!(b&=$.validator.methods.notipv4reserved(value))){
			$.validator.messages.ipv4addr = $.validator.messages.notipv4reserved;
		}
		else{
			$.validator.messages.ipv4addr = $.validator.messages.ipv4addr;
		}
		return b;
	};
	// same as ipv4addr, but accept all zero or empty
	$.validator.methods.ipv4addrzero = function(value, element, param) {
		var b = true;
		if(value==''||value=='0.0.0.0')
			return b;
		if(!(b&=$.validator.methods.ipv4format(value))){
			$.validator.messages.ipv4addrzero = $.validator.messages.ipv4format;
		}
		else if(!(b&=$.validator.regex.ipv4addrzero.test(value))){
			$.validator.messages.ipv4addrzero = $.validator.messages.ipv4addrzero;
		}
		else if(!(b&=(value=='0.0.0.0'||!isInSubdomain(value,'0.0.0.0/8')))){
			$.validator.messages.ipv4addrzero = $.validator.messages.ipv4addrzero;
		}
		else if(!(b&=$.validator.methods.notipv4multicast(value))){
			$.validator.messages.ipv4addrzero = $.validator.messages.notipv4multicast;
		}
		else if(!(b&=$.validator.methods.notipv4broadcast(value))){
			$.validator.messages.ipv4addrzero = $.validator.messages.notipv4broadcast;
		}
		else if(!(b&=$.validator.methods.notipv4reserved(value))){
			$.validator.messages.ipv4addrzero = $.validator.messages.notipv4reserved;
		}
		else{
			$.validator.messages.ipv4addrzero = $.validator.messages.ipv4addrzero;
		}
		return b;
	};
	$.validator.methods.ipv4indomain = function(value, element, param) {
		var aParam = param.split('/');
		var domain = aParam[0];
		var prefix = (aParam[1].indexOf('.')>0?mask2prefix(aParam[1]):aParam[1]);
		var cidr = domain+'/'+prefix;
		$.validator.messages.ipv4indomain = $.validator.format($.validator.messages.ipv4indomain, cidr);
		return isInSubdomain(value,cidr);
	}
	// 10.0.0.0/8
	$.validator.methods.ipv4classa = function(value, element, param) {
		return $.validator.methods.ipv4indomain(value, element, '10.0.0.0/8');
//		return $.validator.methods.ipv4indomain(value, element, '10.0.0.0/255.0.0.0');
	};
	// 172.16.0.0/12
	$.validator.methods.ipv4classb = function(value, element, param) {
		return $.validator.methods.ipv4indomain(value, element, '172.16.0.0/12');
//		return $.validator.methods.ipv4indomain(value, element, '172.16.0.0/255.240.0.0');
	};
	// 192.168.0.0/16
	$.validator.methods.ipv4classc = function(value, element, param) {
		return $.validator.methods.ipv4indomain(value, element, '192.168.0.0/16');
//		return $.validator.methods.ipv4indomain(value, element, '192.168.0.0/255.255.0.0');
	};
	$.validator.methods.ipv4mask = function(value, element, param) {
		if(!$.validator.methods.ipv4format(value, element, param)){
			$.validator.messages.ipv4mask = $.validator.messages.ipv4format;
			return this.optional(element) || false;
		}
		var a_ip = value.split('.');
		var i_ip = ip_num(a_ip);
		var ss = i_ip.toString(2).split('');
		var z = ss.indexOf('0');
		var o = ss.lastIndexOf('1');
		if(ss.length!=32 || z<o)
			return this.optional(element) || false;
		return true;
	};
	$.validator.methods.notipv4classa = function(value, element, param) {
		return !$.validator.methods.ipv4classa(value, element, param);
	};
	$.validator.methods.notipv4classb = function(value, element, param) {
		return !$.validator.methods.ipv4classb(value, element, param);
	};
	$.validator.methods.notipv4classc = function(value, element, param) {
		return !$.validator.methods.ipv4classc(value, element, param);
	};
	$.validator.methods.notipv4multicast = function(value, element, param) {
		return !isInSubdomain(value,'224.0.0.0/4');
	};
	$.validator.methods.notipv4reserved = function(value, element, param) {
		return !isInSubdomain(value,'240.0.0.0/4');
	};
	$.validator.methods.notipv4broadcast = function(value, element, param) {
		return !isInSubdomain(value,'255.255.255.255/32');
	};
	$.validator.methods.ipv6addrformat = function(value, element, param) {
		return $.validator.regex.ipv6addrformat.test(value);
	};
	$.validator.methods.ipv6addr = function(value, element, param) {
		var b = true;
		if(!(b&=!(value==''||$.validator.regex.ipv6zero.test(value)))){
			$.validator.messages.ipv6addr = $.validator.messages.ipv6addr;
		}
		else if(!(b&=$.validator.methods.ipv6addrformat(value))){
			$.validator.messages.ipv6addr = $.validator.messages.ipv6addrformat;
		}
		return b;
	};
	$.validator.methods.ipv6addrzero = function(value, element, param) {
		var b = true;
		if((value=='') || $.validator.regex.ipv6zero.test(value)){
		}
		else if(!(b&=$.validator.methods.ipv6addrformat(value))){
			$.validator.messages.ipv6addrzero = $.validator.messages.ipv6addrformat;
		}
		return b;
	};
	$.validator.methods.logic_and = function(value, element, param) {
		console.log(param)
		var isAllRulePass = true;
		for(var i=0;i<param.length;++i){
			if(typeof(param[i]) === 'object'){
				if($.validator.methods[param[i][0]].call(this, value, element, param[i][1])==false){
					isAllRulePass = false;
					if(typeof($.validator.messages[param[i][0]])==='function'){
						$.validator.messages['logic_and'] = $.validator.messages[param[i][0]].call(this, param[i][1]);
					}
					else{
						$.validator.messages['logic_and'] = $.validator.messages[param[i][0]];
					}
					break;
				}
			}
			else if(typeof(param[i]) === 'string'){
				if($.validator.methods[param[i]].call(this, value, element)==false){
					isAllRulePass = false;
					$.validator.messages['logic_and'] = $.validator.messages[param[i]];
					break;
				}
			}
		}
		return isAllRulePass;
	};
	$.validator.methods.macaddr = function(value, element, param) {
		return this.optional(element) || $.validator.regex.macaddr.test(value);
	};
	/*
	 *	Usage:	data-rule-notequalto='[compared selector,replaced field msg]'
	 *	Ex:		data-rule-notequalto='["#wan_static_dns1","DNS-1"]'
	 *	Result:	Please do not enter the same value as DNS-1
	 */
	$.validator.methods.notequalto = function(value, element, param) {
		$.validator.messages.notequalto = $.validator.format($.validator.messages.notequalto, param[1]);
		return value!=$(param[0]).val();
	};
	/*
	 *	Usage:	data-rule-notsamein='deny strings'
	 *	Ex:		data-rule-notsamein='cat,dog,mouse'
	 *	Result:	This field should not the same in cat,dog,mouse.
	 */
	$.validator.methods.notsamein = function(value, element, param) {
		$.validator.messages.notsamein = $.validator.format($.validator.messages.notsamein, param);
		var isAllValuePass = true;
		var params = param.split(',');
		params.forEach(function(param){
			if(param==value){
				isAllValuePass = false;
			}
		})
		return isAllValuePass;
	};
	/*
	 *	Usage:	data-rule-snmpoid='snmp oid'
	 *	Ex:		data-rule-snmpoid='.2_22312'
	 *	Result:	Please enter a valid SNMP OID.
	 */
	$.validator.methods.snmpoid = function(value, element, param) {
		return this.optional(element) || $.validator.regex.snmpoid.test(value);
	};
	/*
	 *	Usage:	data-rule-snmpoidmask='snmp oid mask'
	 *	Ex:		data-rule-snmpoidmask='AX:AA'
	 *	Result:	Please enter a valid SNMP OID mask.
	 */
	$.validator.methods.snmpoidmask = function(value, element, param) {
		return this.optional(element) || $.validator.regex.snmpoidmask.test(value);
	};

	// 
	// add by silvester
	// 

	$.validator.methods.hex = function(value, element, param) {
		return this.optional(element) || $.validator.regex.hex.test(value);
	};

	$.validator.methods.wepkey = function(value, element, param) {
		var isAscii = +$(param).val(),
			idx = $(element).attr('idx') || '';

		if(isAscii){
			if(!$.validator.regex.ascii.test(value)){
				return false;
			}

			$.validator.messages.wepkey = getMsg('_wifiser_mode31');
			return (value.length === 5 || value.length === 13);
		}

		if(!$.validator.regex.hex.test(value)){
			$.validator.messages.wepkey = getMsg('LW22') + ' ' + idx + getMsg('MSG038_1');
			return false;
		}
		$.validator.messages.wepkey = getMsg('_wifiser_mode30');
		return (value.length === 10 || value.length === 26);

	};

	$.validator.methods.ipv4order = function(value, element, param) {
		var startIp = $(param).val(),
			endIp = value;

		$.validator.messages.ipv4order = getMsg('TEXT039');
		return chkIpOrder(startIp, endIp);
	};

	$.validator.methods.ipv4order = function(value, element, param) {
		var startIp = $(param).val(),
			endIp = value;

		$.validator.messages.ipv4order = getMsg('TEXT039');
		return chkIpOrder(startIp, endIp);
	};

	$.validator.methods.ipv4domain2 = function(value, element, param) {
		var ip = value,
			mask = $(param.split(',')[0]).val(),
			gateway = $(param.split(',')[1]).val();

		return chkDomain(ip, mask, gateway);
	};

	$.validator.methods.domainname = function(value, element, param) {
		// domain name can't be all number
		return $.validator.regex.alphadash.test(value) && /\D/.test(value);
	};
}
});