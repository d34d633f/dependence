// Trendnet Only Start

function slideNav(){
	var activedNav =  $('.nav-list.is-active'),
		selectedNav = $(this),
		src = activedNav.find('.nav-icon').attr('src');

	var toPage = function(){
		var url = selectedNav.attr('data-url');
		if(url)
			window.location.assign(url + '.asp');
	};

	// close the actived nav
	activedNav.toggleClass('is-active');
	activedNav.find('.nav-icon').attr('src', src.replace('-active', ''));
	activedNav.next('.nav-sublist.is-active').slideUp().toggleClass('is-active');

	// open the selected nav
	src = selectedNav.find('.nav-icon').attr('src');
	selectedNav.toggleClass('is-active');
	selectedNav.find('.nav-icon').attr('src', src.replace('.png', '-active.png'));
	selectedNav.next('.nav-sublist').slideDown(400, toPage).toggleClass('is-active');
}

function setScroll(){
	var showBtn = function(){
		var scrollHeight = document.body.scrollHeight,
			scrollTop = document.body.scrollTop;

		if(scrollTop / scrollHeight >= .4){
			$('.scroller').fadeIn();
		}
		else
			$('.scroller').fadeOut();
	};

	$(window).on('scroll', showBtn);
	$('.scroller').on('click', function(){
		document.body.scrollIntoView();
	});
}

function setProgress(time, interval, msg, url){
	var endTime = new Date().getTime() + (time * 1000),
		interval = interval || 500,
		msg = msg || getMsg('_processing_plz_wait');
	
	var drawBar = function(){
		var progress = Math.round((time * 1000 - (endTime - new Date().getTime())) /(time * 10));

		progress = (progress > 100)?100:progress;

		$('.progress-bar').animate({width: progress + '%'}, interval);
		$('.progress-cnt').html(progress + ' %');

		if(progress >= 100){
			if(url)
				return window.location.replace(url);
			return window.location.reload();
		}

		window.setTimeout(drawBar, interval);
	};

	$('.progress-msg').html(msg);
	drawBar();
}

// Trendnet Only End


// refine function

function getMsg(tag, cat){
	if(cat && LangMap[cat])
		return LangMap[cat][tag] || '';

	if(LangMap.which_lang[tag])
		return LangMap.which_lang[tag];
	return LangMap.msg[tag] || '';
}

function ipToNum(ip){
	var result = 0;

	ip.split('.').forEach(function(item, idx){
		result += +item * Math.pow(256, 3 - idx);
	});
	return result;
}

function chkDomain(ip, mask, gateway){
	var ipAry = ip.split('.'),
		maskAry = mask.split('.'),
		gateAry = gateway.split('.');

	if(ipToNum(gateway) === 0)
		return true;

	for(var i = 0; i < 3; i++){
		if((+ipAry[i] & +maskAry[i]) != (+gateAry[i] & +maskAry[i]))
			return false;
	}
	return true;
}

function chkIpOrder(startIp, endIp){
	var startNum = ipToNum(startIp),
		endNum = ipToNum(endIp);

	if(endNum < startNum)
		return false;
	return true;
}

function getUrlParam(){
	var paramList = window.location.search.substr(1).split('&'),
		result = {};

	paramList.forEach(function(item, idx){
		var key = item.split('=')[0],
			val = item.split('=')[1];
		result[key] = val;
	});

	return result;
}

// refine function end

function isElement(obj){
	try{
		return obj instanceof HTMLElement;
	}
	catch(e){
		return (typeof obj === 'object')
			&& (obj.nodeType === 1) 
			&& (typeof obj.style === 'object') 
			&& (typeof obj.ownerDocument === 'object');
	}
}

function doReboot(act){
	var act = (act === 'rebootAP')?act:'reboot',
		req = new ccpObject('cfg_op.ccp', act);
	
	req.add_param_event('CCP_SUB_SOFT_REBOOT');
	req.set_param_option('newIP', 'tew-817dtr/');
	req.ajax_submit(function(data){
		var url = /replace\('(.+)'\)/.exec(data);
		window.location.replace(url[1]);
	});
}

function cancelSetting(){
	window.location.reload();
}

function secToTime(sec){
	if(!sec)
		return 'na';

	var day = '' + Math.floor(sec / 86400),
		hour = ('00' + Math.floor((sec - day * 86400) / 3600)).slice(-2),
		min = ('00' + Math.floor((sec - day * 86400 - hour * 3600) / 60)).slice(-2),
		sec = ('00' + (sec - day * 86400 - hour * 3600 - min * 60)).slice(-2);

	return day + ' Day, ' + hour + ':' + min + ':' + sec;
}

function getPadStr(str, len, pad){
	var str = str || '',
		len = len || str.length,
		pad = pad || '0',
		prefix = new Array(len + 1).join(pad);

	return (prefix + str).slice(-1 * len);
}

function getDevMode(idx){
	var modeList = ['router_mode', 'dev_mode_ap', 'KR50', 'dev_mode_repeater', 'dev_mode_wisp'];
	return getMsg(modeList[idx]);
}

function getWanType(idx, isAP){
	var typeList = ['Static', 'DHCP', 'PPPoE', 'PPTP', 'L2TP', 'BigPond', 'RSPPPoE', 'RSPPTP', 'RSL2TP', 'DHCPPLUS', 'DSLite'];
	if(isAP && +idx > 2)
		return typeList[1];
	return typeList[+idx];
}

function getWlanSecuStr(secuMode, wepMode, wpaMode){
	var secuList = ['None', 'WEP', 'PSK', 'EAP'],
		wepList = ['OPEN', 'SHARED'],
		wpaList = ['WPA2 Mixed', 'WPA2', 'WPA'];

	if(secuMode === 0)
		return secuList[secuMode];
	else if(secuMode === 1)
		return secuList[secuMode] + '-' + wepList[wepMode];
	else
		return wpaList[wpaMode] + '-' + secuList[secuMode];
}