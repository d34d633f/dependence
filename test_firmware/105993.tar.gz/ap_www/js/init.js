/*
** init.js 
** added by Silvester 20131120
**
** Part A.
** import EsmaScript5
** replace with https://github.com/es-shims/es5-shim 
** Part B. 
** functions for new GUI coding style (MVC)
** dependency with jQuery, nunjucks
*/

// global
var ENV,
	DEV_MODE = false;

function pageInit(opts){
	var main = {},
		misc = {},
		args = {};
	
	misc = getMisc();
	
	if(typeof getMain === 'function')
		main = getMain();

	// OPT: check whatever you want
	// if()
	// 	return location.replace('somewhere');

	ENV = new nunjucks.Environment(new nunjucks.WebLoader('view'), $.extend({autoescape:true}, opts.env));
	setTemplateFilter();

	if(typeof opts.filter === 'function')
		opts.filter();

	// TODO: set args
	args.nav = opts.nav;
	args.misc = misc;
	args.msg = LangMap.which_lang;
	args = $.extend(args, getArgs(main, misc));

	var renderCallback = function(err, res){
		if(err)
			return renderErrHandler(err);

		if(typeof opts.render === 'function')
			opts.render(res);	// opt.render must be sync
		else{
			// i use prepend because all the scripts are at the bottom of body 
			$('body').prepend(res);
			// set page title
			setTitle(misc);
			// set nav bar
			setNav(opts.nav);
			// set scroll top btn
			setScroll();
		}

		if(typeof opts.afterRender === 'function')
			opts.afterRender(main, misc);
	};

	return renderTemplate(opts.target, args, renderCallback);
}

function getMisc(){
	var misc = new ccpObject();
	misc.get_router_info();
	misc.make_member();
	return misc.misc[0];
}

function renderTemplate(target, args, cbf){
	if(typeof target === 'string')
		return ENV.render(target, args, cbf);

	if(isElement(target))
		return ENV.renderString(target.innerHTML, args, cbf);
	
	throw TypeError('Render target must be a file path or a dom object');
}

function renderErrHandler(err){
	if(DEV_MODE){
		document.write(err);
		return false;
	}
	
	throw Error(err);
}

function setTitle(misc){
	document.title = 'TRENDNET | ' + misc.model;
}

function setNav(nav){
	if(!nav)
		return false;
	
	$('.nav-list').on('click', slideNav);
}

function setTemplateFilter(){
	ENV.addFilter('replaceStr', function(str){
		var idx = 1;

		if(arguments.length == 2)
			return str.replace(/%[sdfxm]/gi, arguments[1]);

		while(arguments[idx] !== undefined){
			str = str.replace(/%[sdfxm]/i, arguments[idx]);
			idx++;
		}
		return str;
	});

	ENV.addFilter('charAt', function(str, idx){
		return str.charAt(idx);
	});

	ENV.addFilter('idxOf', function(target, list){
		return list.indexOf(target);
	});

	ENV.addFilter('padZero', function(str, len, pad){
		return getPadStr(str, len, pad);
	});

	ENV.addFilter('dns', function(dnsAry, idx){
		return dnsAry.split(',')[idx];
	});

	ENV.addFilter('devMode', function(idx){
		return getDevMode(+idx);
	});

	ENV.addFilter('wanType', function(idx){
		return getWanType(+idx);
	});

	ENV.addFilter('wlanSecu', function(secuMode, wepMode, wpaMode){
		return getWlanSecuStr(+secuMode, +wepMode, +wpaMode);
	});
}

function getArgs(){
	// implement in each page 
	return {}; 
}