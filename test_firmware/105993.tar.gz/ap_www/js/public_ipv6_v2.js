/*
	IPv6 functions ver 2.0
	Author: Silvester
	Date: 2014.03.27
	Note: 
		1. dependency with jQuery, uk.js, public.js
*/

function getFullV6Addr(addr){
	var addr = addr || '',
		addrAbbAry = [],
		addrPrefixAry = [],
		addrSuffixAry = [],
		sections = 0,
		result = '';

	if(addr.substr(0, 1) == ':')
		addr = '0' + addr;
	if(addr.substr(-1, 1) == ':')
		addr = addr + '0';

	addrAbbAry = addr.split('::');
	
	if(addrAbbAry.length > 2)
		return false;
	else if(addrAbbAry.length == 1)
		return addr;
	else{
		addrPrefixAry = addrAbbAry[0].split(':');
		addrSuffixAry = addrAbbAry[1].split(':');
		sections += addrPrefixAry.length;
		sections += addrSuffixAry.length;
		result = addrPrefixAry.concat(getFilledAry(8 - sections, '0'), addrSuffixAry).join(':');
		return result;
	}
}

function getAbbV6Addr(addr){
	if(addr.indexOf('::') >= 0)
		return addr;

	var addr = addr,
		maxZero = '',
		result = '';

	addr = addr.replace(/:?\b0+\B/g, ':');
	maxZero = addr.match(/(0:)+/g).sort().pop();
	result = addr.replace(maxZero, ':');
	return result;
}

function getStatefulPrefix(addr, len){
	var addr = getFullV6Addr(addr),
		len = len || 64,
		result = '';

	if(!addr)
		return result;

	result = addr.split(':').splice(0, len/16).join(':');
	return result;
}

function getStatefulSuffix(addr){
	var addr = getFullV6Addr(addr),
		result = '';

	if(!addr)
		return result;

	result = addr.split(':').pop();
	return result;
}

/*
	checkV6Addr(addr, tag, [allowZero], [subMsg])

	addr: ipv6 address
	tag: tag name to replace %s in alert msg
	allowZero: set true to allow 0::0, default false
	subMsg: msg to replace current alert msg
*/
function checkV6Addr(addr, tag, allowZero, subMsg){
	var addr = addr,
		addrAry = [],
		allowZero = allowZero || false,
		allZero = true,
		errMsg = getV6Msg(tag, subMsg);

	var checkLen = function(){
		if(addrAry.length != 8){
			alert(errMsg.INVALID_IP);
			return false;
		}
		return true;
	};

	var checkFormat = function(section, idx){
		if(!section || section.length > 4){
			alert(errMsg.INVALID_IP);
			return false;
		}

		if(!isHex(section)){
			alert(errMsg.IP_ERROR[idx]);
			return false;
		}
		return true;
	};

	var checkMulticast = function(section){
		var re = /^FF/i;

		if(re.test(section)){
			alert(errMsg.MULTICASE_IP_ERROR);
			return false;
		}
		return true;
	};

	var checkZero = function(section){
		var re = /[^0]/;
		allZero = !re.test(section);
	};

	addr = getFullV6Addr(addr);

	if(!addr){
		alert(errMsg.INVALID_IP);
		return false;
	}

	addrAry = addr.split(':');

	if(!checkLen())
		return false;

	for(var i = 0; i < 8; i++){
		if(!checkFormat(addrAry[i], i))
			return false;

		if(allZero)
			checkZero(addrAry[i]);
	}

	if(!checkMulticast(addrAry[0]))
		return false;

	if(allZero && !allowZero){
		alert(errMsg.ZERO_IP);
		return false;
	}

	return true;
}

function checkV6Section(section, tag1, tag2){
	if(section.length && section.length < 5){
		if(!isHex(section)){
			alert(get_words(tag1) + ' ' + get_words(tag2) + get_words('MSG038_1'));
			return false;
		}
		return true;
	}
	else{
		alert(get_words(tag1) + ' ' + get_words(tag2) + get_words('MSG039_1'));
		return false;
	}
}

function checkSuffixRange(startSuffix, endSuffix){
	if(+('0x' + startSuffix) >= +('0x' + endSuffix)){
		alert(LangMap.which_lang['MSG040']);
		return false;
	}
	return true;
}

function getFilledAry(len, content){
	var emptyAry = Array.apply(null, Array(len));
	return emptyAry.map(function(ele, idx){ return content; });
}

function isHex(str){
	var re = /[^0-9a-fA-F]/;
	return !re.test(str);
}

function getV6Msg(tag, subMsg){
	var msgObj = $.extend(true, {}, IPV6_ADDR_MSG),
		result = {};

	var replaceObjVal = function(obj, tag){
		for(var key in obj){
			if(typeof obj[key] == 'string'){
				obj[key] = addstr(get_words(obj[key]), get_words(tag));
			}
			else if(typeof obj[key] == 'object')
				obj[key] = replaceObjVal(obj[key], tag);
		}

		return obj;
	}

	if(subMsg)
		msgObj = $.extend(true, msgObj, subMsg);

	result = replaceObjVal(msgObj, tag)

	return result;
}

/*
	ipv6 validator alert msg
	each value match a language tag
*/
var IPV6_ADDR_MSG = {
	INVALID_IP: 'MSG006',
	ZERO_IP: 'MSG007',
	IP_ERROR: {0: 'MSG018', 1: 'MSG019', 2: 'MSG020', 3: 'MSG021', 4: 'MSG022', 5: 'MSG023', 6: 'MSG024', 7: 'MSG025'},
	RANGE_ERROR: {0: 'MSG026', 1: 'MSG027', 2: 'MSG028', 3: 'MSG029', 4: 'MSG030', 5: 'MSG031', 6: 'MSG032', 7: 'MSG033'},
	LOOPBACK_IP_ERROR: 'MSG034',
	MULTICASE_IP_ERROR: 'MSG035'
};





/** 20120229 silvia add to filter ipv6 addr 0:0:0~ */
function filter_ipv6_addr(data){
	if(!data)
		return '';

	var v6_ip = data;
	var v6_ip_s = data.split(':');
	var tmp_ip ='';
	var tmp_ip_1 ='';
	var tmp_ip_2 ='';
	var isabridge = data.split('::');

	if (isabridge.length == 2)
		return v6_ip;

	for (var i = 0; i <8; i++)
	{
		if (v6_ip_s[i] == 0)
		{
			tmp_ip += (i==0)? '0': ':0';
		}else{
			if (tmp_ip_1 == '')
			{
				tmp_ip_1 = tmp_ip;
				tmp_ip = '';
			}else{
				tmp_ip_2 = tmp_ip;
				tmp_ip = '';
			}
		}
		if ((tmp_ip_1 != '') && (v6_ip_s[7] == 0))
			tmp_ip_2 = tmp_ip + ':';
	}
	tmp_ip = (tmp_ip == '')?((tmp_ip_1.length >= tmp_ip_2.length)?tmp_ip_1:tmp_ip_2):tmp_ip;

	if (tmp_ip ==':0')
		return v6_ip;

	if ((data.indexOf(tmp_ip) != -1) && (tmp_ip != ''))
		v6_ip = (data.replace(tmp_ip, ":") + ':');
		
	if ((v6_ip.indexOf('::') != -1) && (v6_ip.length == (v6_ip.lastIndexOf(':')+1))
		&& (v6_ip.length != (v6_ip.lastIndexOf('::')+2)))
		v6_ip = v6_ip.substring(0,v6_ip.length-1);

	return v6_ip;
}
