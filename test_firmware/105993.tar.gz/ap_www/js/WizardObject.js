/*
All of your wizard block should add a class `pagepiece`



How to set next page by page options:
You just need add input[type=radio] or input[type=checkbox] which contians a class `next-fork` and an attribute called `data-fork` which value is a selector of next page

Scenario 1. The next page is determined by visible radio button:
Code:
	<div id="p1" class="pagepiece">
		<input type="radio" name="wantype" class="next-fork" data-fork="#p2a" />
		<input type="radio" name="wantype" class="next-fork" data-fork="#p2b" />
	</div>
Explain:
	The next button will bind to show page $('#p1 .next-fork:checked').data('fork')

Scenario 2. The next page is determined by multiple tag:
Code:
	<script>
		wz.setFinalMap({'#p1':final_p1})
		function final_p1(){
			if($('#opt1').attr('checked'))
				$('#opt_fork').data($('#opt1').data('fork'))
			else if($('#opt2').attr('checked')){
				var bc = $('#tt').val();
				if(bc=='b')
					$('#opt_fork').data('fork','#p2b');
				else if(bc=='c')
					$('#opt_fork').data('fork','#p2c');
			}
		}
	</script>
	<div id="p1" class="pagepiece">
		<input type="radio" id="opt1" class="next-fork" data-fork="#p2a" />
		<input type="radio" id="opt2" />
		<select id="tt">
			<option value="b">p2b</option>
			<option value="c">p2c</option>
		</select>
		<input type="hidden" id="opt_fork" class="next-fork hide" data-fork="" />
	</div>
Explain:
	First, we need to add a input[name=hidden] contains a class `next-fork` and an attribute called `data-fork`.
	The next button will bind to show page $('#p1 .next-fork[type=hidden]').data('fork').
	So we should set data-fork value on its(page) final function.

*/
function WizardObj(){
	this.debug = false;
	this.nextMap = {};
	this.initMap = {};
	this.finalMap = {};
	this.storeMap = {};
	this.prevStack = [];
	this.$prevBtn;
	this.$nextBtn;
	this.curPage;
	//value which need save to datamodel
	this.pageValues = {};
	// get all btn for later using
	this.btnList = [];
	// tmp data
	this.tmp = {};
}
WizardObj.prototype.debugFn = function(){
	if(this.debug){
		if(arguments.length===1){
			console.log(arguments[0]);
		}
		else{
			console.log(arguments);
		}
	}
}
/*
WizardObj.set*Map() Usage:
	WizardObj.set*Map(curPage, nextPage);
		curPage: selector of current page
		nextPage: selector of next page
	WizardObj.set*Map(page, func);
		page: selector of current page
		func: initialize/finalize/save-value function of current page
	WizardObj.set*Map(map);
		map: A set of key/value pairs that setting above parameter
ex1:
	WizardObj.setNextMap({'#p1':'#p2'});
	WizardObj.setNextMap({'#p2':'#p3'});
	
	WizardObj.setInitMap({'#p1':init_p1});
	WizardObj.setInitMap({'#p2':init_p2});
ex2:
	WizardObj.setNextMap({'#p1':'#p2','#p2':'#p3'});
	
	WizardObj.setInitMap({'#p1':init_p1,'#p2':init_p2});
*/
//setting next page definition map
WizardObj.prototype.setNextMap = function(map){
//	this.debugFn(typeof map)
	if(typeof(arguments[0])==='object'){
		$.extend(this.nextMap,map);
	}
	else if(typeof(arguments[0])==='string'){
		this.nextMap[arguments[0]] = arguments[1];
	}
	else{
		throw new Error();
	}
}
//initialize function on page loading, must pass WizardObj to function
WizardObj.prototype.setInitMap = function(map){
	if(typeof(arguments[0])==='object'){
		$.extend(this.initMap,map);
	}
	else if(typeof(arguments[0])==='string'){
		this.initMap[arguments[0]] = arguments[1];
	}
	else{
		throw new Error();
	}
}
//Finalize function on page leaving, must return true(=continue) or false(=stop)
WizardObj.prototype.setFinalMap = function(map){
	if(typeof(arguments[0])==='object'){
		$.extend(this.finalMap,map);
	}
	else if(typeof(arguments[0])==='string'){
		this.finalMap[arguments[0]] = arguments[1];
	}
	else{
		throw new Error();
	}
}
//Save value on page leaving
WizardObj.prototype.setStoreMap = function(map){
	if(typeof(arguments[0])==='object'){
		$.extend(this.storeMap,map);
	}
	else if(typeof(arguments[0])==='string'){
		this.storeMap[arguments[0]] = arguments[1];
	}
	else{
		throw new Error();
	}
}
//set selector of previous button 
WizardObj.prototype.setPrevBtn = function(selector){
	this.$prevBtn = $(selector)
}
//set selector of next button
WizardObj.prototype.setNextBtn = function(selector){
	this.$nextBtn = $(selector)
}
//display page block
WizardObj.prototype.changePage = function(){
	$('.pagepiece').hide();
	$(this.curPage+'.pagepiece').show();
}
WizardObj.prototype.preparePage = function(page){
	this.debugFn('leave '+this.curPage);
	this.curPage = page;
//	this.setPageValue();//do not implement here, it should set on document ready.
	this.bindBtn();
//	this.setBtnVisible();//do not implement here, it should set in its initialize function.
	var initFn = this.initMap[page];
	if(initFn){
		this.debugFn('run '+initFn.name);
		initFn(this);
	}
	this.debugFn('enter '+page);
	this.changePage();
}
WizardObj.prototype.savePageValue = function(element){
	this.pageValues[this.curPage] = this.pageValues[this.curPage]||[];
	this.pageValues[this.curPage].push(element);
	this.debugFn(this.pageValues[this.curPage]);
}
WizardObj.prototype.restorePageValue = function(){
// it might not implement
}

WizardObj.prototype.bindBtn = function(){
	this.bindPrevBtn();
	this.bindNextBtn();
}
// bind previous button for 1.remove save value of previous page, 2.back to previous page
WizardObj.prototype.bindPrevBtn = function(){
	var that = this;
	var func = function(){
		if(that.prevStack.length!=0){
			var prevPage = that.prevStack.pop();
			that.debugFn('prev: '+prevPage+',cur: '+that.curPage);
			that.pageValues[prevPage] = [];//remove store value of previous page
			that.preparePage(prevPage);
		}
	}
	this.$prevBtn.unbind('click.prev').bind('click.prev',func);
}
// bind next button for 1.calculate next page, 2.store value of previous page, 3.store current page to history, 4.initialize next page, 5.switch to next page
WizardObj.prototype.bindNextBtn = function(){
	var that = this;
	var func = function(){
		var nextPage;
		//find if current page has special options to effect next page
		$optionNextCheck = $(that.curPage+' .next-fork:checked');
		$optionNextHide = $(that.curPage+' .next-fork[type=hidden]');
		if($optionNextCheck.length>0){
			nextPage = $optionNextCheck.data('fork');
		}
		else if($optionNextHide.length>0 && $optionNextHide.data('fork')!=''){
			nextPage = $optionNextHide.data('fork');
		}
		else{
			nextPage = that.nextMap[that.curPage];
		}
		that.debugFn('next: '+nextPage+',cur: '+that.curPage);
		var finalFn = that.finalMap[that.curPage];
		var storeFn = that.storeMap[that.curPage];
		if(finalFn){
			that.debugFn('run '+finalFn.name);
		}
		if((!finalFn || finalFn && finalFn()) && nextPage){
			if(storeFn){
				that.debugFn('run '+storeFn.name);
				storeFn(that);
			}
			that.prevStack.push(that.curPage);
			that.preparePage(nextPage);
		}
	}
	this.$nextBtn.unbind('click.next').bind('click.next',func);
}
// start wizard workflow at first page
WizardObj.prototype.run = function(firstPage){
	this.preparePage(firstPage);
}

WizardObj.prototype.setBtn = function(btnCfg){
	this.btnList.forEach(function(item, idx){
		if(btnCfg[idx])
			$(item).removeClass('is-hidden');
		else
			$(item).addClass('is-hidden');
	});
}

WizardObj.prototype.setTmp = function(key, val){
	this.tmp[key] = val;
}