#!/bin/sh
#description: auto generate certification

KEY_FILE="/var/tmp/key_file.pem"
OPENSSL_CNF_FILE="/etc/openssl.cnf"
TMP_KEY_FILE="/var/tmp/key_file.pem.tmp"
FLASH_KEY_FILE="/flash/key_file.pem"
TMP_OPENSSL_CA_KEY="/var/tmp/caKey.pem"
TMP_OPENSSL_CA_REQ="/var/tmp/caReq.pem"
TMP_OPENSSL_CA_CERT="/var/tmp/caCert.pem"


DATENOW=`date '+%m%d%H%M%Y'`
date -s 010100002015
HOME='/var/tmp/'
openssl genrsa -out ${TMP_OPENSSL_CA_KEY} 2048
echo -ne "\n\n\n\n\n" | openssl req -new -key ${TMP_OPENSSL_CA_KEY} -out ${TMP_OPENSSL_CA_REQ} -config ${OPENSSL_CNF_FILE} -subj /O=TRENDnet/C=TW/ST=Taiwan/L=Taipei/CN=General-Root-CA/emailAddress=webmaster@localhost
openssl x509 -req -sha256 -days 7303 -extfile ${OPENSSL_CNF_FILE} -extensions v3_ca -in ${TMP_OPENSSL_CA_REQ} -signkey ${TMP_OPENSSL_CA_KEY} -out ${TMP_OPENSSL_CA_CERT}

cat ${TMP_OPENSSL_CA_KEY} > ${TMP_KEY_FILE}
cat ${TMP_OPENSSL_CA_CERT} >> ${TMP_KEY_FILE}
rm -f ${TMP_OPENSSL_CA_REQ} ${TMP_OPENSSL_CA_CERT}
cp -f ${TMP_KEY_FILE} ${FLASH_KEY_FILE}
cp -f ${FLASH_KEY_FILE} ${KEY_FILE}
HOME='/'
date -s ${DATENOW}
