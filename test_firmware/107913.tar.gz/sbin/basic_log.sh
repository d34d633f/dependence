#!/bin/sh

# Collect basi debug information

i=1
while [ 1 ]
do
	echo "******************debug begin $i*********************" >> /tmp/basic_debug_log.txt
	date >> /tmp/basic_debug_log.txt
	ifconfig >> /tmp/basic_debug_log.txt 
	cat /proc/meminfo >> /tmp/basic_debug_log.txt
	cat /proc/slabinfo >> /tmp/basic_debug_log.txt
	ps >> /tmp/basic_debug_log.txt
	free >> /tmp/basic_debug_log.txt
	iwconfig >> /tmp/basic_debug_log.txt
	echo "=====ath0 connect device $i====" >> /tmp/basic_debug_log.txt
	wlanconfig ath0 list sta >> /tmp/basic_debug_log.txt
	echo "=====ath1 connect device $i====" >> /tmp/basic_debug_log.txt
	wlanconfig ath1 list sta >> /tmp/basic_debug_log.txt
	echo "=====ath01 connect device $i====" >> /tmp/basic_debug_log.txt
	wlanconfig ath01 list sta >> /tmp/basic_debug_log.txt
	echo "=====ath11 connect device $i====" >> /tmp/basic_debug_log.txt
	wlanconfig ath11 list sta >> /tmp/basic_debug_log.txt
	echo "=====2.4G scan results $i====" >> /tmp/basic_debug_log.txt
	cat /tmp/scan_result_2.4G >> /tmp/basic_debug_log.txt
	echo "=====5G scan results $i====" >> /tmp/basic_debug_log.txt
	cat /tmp/scan_result_5G >> /tmp/basic_debug_log.txt
	echo "=====channel list $i====" >> /tmp/basic_debug_log.txt
	iwlist ath0 channel >> /tmp/basic_debug_log.txt
	iwlist ath1 channel >> /tmp/basic_debug_log.txt
	iwlist ath01 channel >> /tmp/basic_debug_log.txt
	iwlist ath11 channel >> /tmp/basic_debug_log.txt
	 echo "=====link status with rootap 2.4G and 5G $i====" >> /tmp/basic_debug_log.txt
	cat /tmp/link_status >> /tmp/basic_debug_log.txt
	cat /tmp/link_status_5g >> /tmp/basic_debug_log.txt
	echo "=====link status with wireless client $i====" >> /tmp/basic_debug_log.txt
	cat /tmp/client_color >> /tmp/basic_debug_log.txt
	cat /tmp/client_color_5g >> /tmp/basic_debug_log.txt
	cat /tmp/client_link_color >> /tmp/basic_debug_log.txt
	echo "=====ssid and psk countrycode$i====" >> /tmp/basic_debug_log.txt
	config show |grep -nr ssid >> /tmp/basic_debug_log.txt
	config show |grep -nr psk >> /tmp/basic_debug_log.txt
	iwpriv ath1 get_countrycode >> /tmp/basic_debug_log.txt
	echo "============hostapd.conf=============" >> /tmp/basic_debug_log.txt
	cat /var/run/hostapd-ath0.conf >> /tmp/basic_debug_log.txt
	cat /var/run/hostapd-ath1.conf >> /tmp/basic_debug_log.txt
	echo "============wpa_supplicant.conf=============" >> /tmp/basic_debug_log.txt
	cat /var/run/wpa_supplicant-ath01.conf >> /tmp/basic_debug_log.txt
	cat /var/run/wpa_supplicant-ath11.conf >> /tmp/basic_debug_log.txt
	echo "******************debug end*********************" >> /tmp/basic_debug_log.txt
	sleep 30
	
	filesize=`ls -l /tmp/basic_debug_log.txt | awk '{print $5}'`
	if [ $filesize -ge 1048576 ]; then
		echo "filesize if over, rm basic_debug_log.txt"
		rm -rf /tmp/basic_debug_log.txt
	fi
	i=$((i+1))
done

