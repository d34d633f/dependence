#!/bin/sh

CONFIG=/bin/config
board_hw_id="$(/sbin/artmtd -r board_hw_id | cut -f 2 -d ":" | cut -f 7 -d "+")"

/sbin/artmtd -r region
firmware_region=`cat /tmp/firmware_region | awk '{print $1}'`

#When board_model_id on HW board data area is Ex7300
if [ "$board_hw_id" = "5508013271" ];then
	echo "EX7300" > /module_name
	echo "EX7300" > /hardware_version

	if [ "x$($CONFIG get board_region_default)" = "x1" ]; then
		/bin/config set wan_hostname="EX7300"
		/bin/config set netbiosname="EX7300"
		/bin/config set upnp_serverName="ReadyDLNA: EX7300"
	fi

	/bin/config set bridge_netbiosname="EX7300"
	/bin/config set ap_netbiosname="EX7300"
    /bin/config set device_name="EX7300"

    #difference in net-cgi
    /bin/config set cgi_mode_1="54"
    /bin/config set cgi_mode_2="216"
    /bin/config set cgi_mode_3="450"
    /bin/config set cgi_upg_mod="EX7300series"
    /bin/config set cgi_module_id="EX7300"
    /bin/config set cgi_ctl_mod="ex7300"
    #For the Netgear requirement EX6400 2.4G not support HT40
    if [ "x$(/bin/config get board_region_default)" = "x1"  ]; then
        /bin/config set wl_simple_mode="6"
    fi

   #difference in chainmask
   /bin/config set wl_txchainmask=7
   /bin/config set wl_rxchainmask=7
   /bin/config set wla_txchainmask=15
   /bin/config set wla_rxchainmask=15


    #difference in magic_number, to judge if backup cfg file match project
    /bin/config set magic_number="0x20131224"


	# madwifi_scripts
	ATH_TMP=/tmp/etc/ath
	ATH_ORI=/etc/ath
	[ ! -d $ATH_TMP ] && mkdir -p $ATH_TMP && cp -a $ATH_ORI/* $ATH_TMP
	sed -i 's/wsc_manufactuer=.*/wsc_manufactuer="NTGR"/g' $ATH_TMP/board.conf
	sed -i 's/wsc_model_name=.*/wsc_model_name="EX7300"/g' $ATH_TMP/board.conf
	sed -i 's/wsc_model_number=.*/wsc_model_number="V1"/g' $ATH_TMP/board.conf

	# preset hw_board_type in kernel
	echo "EX7300" > /proc/hw_board_type

	# lld2d 
#	cp /etc/wndr4500v3_icon.ico /tmp/icon.ico
#	cp /etc/wndr4500v3_large.ico /tmp/large.ico
fi




#When board_model_id on HW board data area is EX6400
if [ "$board_hw_id" = "5508013406" ];then
	echo "EX6400" > /module_name
	echo "EX6400" > /hardware_version

	if [ "x$($CONFIG get board_region_default)" = "x1" ]; then
		/bin/config set wan_hostname="EX6400"
		/bin/config set netbiosname="EX6400"
		/bin/config set upnp_serverName="ReadyDLNA: EX6400"
	fi

	/bin/config set bridge_netbiosname="EX6400"
	/bin/config set ap_netbiosname="EX6400"
    /bin/config set device_name="EX6400"

    #difference in net-cgi
    /bin/config set cgi_mode_1="54"
    /bin/config set cgi_mode_2="145"
    /bin/config set cgi_mode_3="300"
    /bin/config set cgi_upg_mod="EX7300series"
    /bin/config set cgi_module_id="EX6400"
    /bin/config set cgi_ctl_mod="ex6400"
    #For the Netgear requirement EX6400 2.4G not support HT40
    if [ "x$(/bin/config get board_region_default)" = "x1"  ]; then
        /bin/config set wl_simple_mode="6"
    fi

   #difference in chainmask
   /bin/config set wl_txchainmask=3
   /bin/config set wl_rxchainmask=7
   /bin/config set wla_txchainmask=15
   /bin/config set wla_rxchainmask=15
    
    #difference in magic_number, to judge if backup cfg file match project
    /bin/config set magic_number="0x20151120"

	# madwifi_scripts
	ATH_TMP=/tmp/etc/ath
	ATH_ORI=/etc/ath
	[ ! -d $ATH_TMP ] && mkdir -p $ATH_TMP && cp -a $ATH_ORI/* $ATH_TMP
	sed -i 's/wsc_manufactuer=.*/wsc_manufactuer="NTGR"/g' $ATH_TMP/board.conf
	sed -i 's/wsc_model_name=.*/wsc_model_name="EX6400"/g' $ATH_TMP/board.conf
	sed -i 's/wsc_model_number=.*/wsc_model_number="V1"/g' $ATH_TMP/board.conf

	# preset hw_board_type in kernel
	echo "EX6400" > /proc/hw_board_type

	# lld2d 
#	cp /etc/wndr4500v3_icon.ico /tmp/icon.ico
#	cp /etc/wndr4500v3_large.ico /tmp/large.ico
fi

