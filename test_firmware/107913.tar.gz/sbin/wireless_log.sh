#!/bin/sh

# Collect basi debug information

iwpriv ath0 dbgLVL 0x00f41066
iwpriv ath1 dbgLVL 0x00f41066
iwpriv ath1 dbgLVL 0x00f41066
iwpriv ath11 dbgLVL 0x00f41066


while [ 1 ]
do
	date
	iwconfig
	wlanconfig ath0 list
	wlanconfig ath1 list
	wlanconfig ath01 list
	wlanconfig ath11 list
	athstats
	sleep 30
done

