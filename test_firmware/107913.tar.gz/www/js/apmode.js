/**
 * For AP Mode Flow
 */
(function ($) {
	
	"use strict";

	var checkNum = 0,
	times = 0,
	max = 10;

	$(function() {
		/*******************************************************************************************
		*
		*       ap access checking
		*
		******************************************************************************************/

		if ($('#accessPointForm').length) {
			var opmode = document.getElementById('opmode');
			opmode.options[0].text = wlan_mode_1;
			opmode.options[1].text = wlan_mode_2;
			opmode.options[2].text = wlan_mode_3;

			var opmode = document.getElementById('opmode5g');
			opmode.options[0].text = wlan_mode_1;
			opmode.options[1].text = an_wlan_mode_1;
			opmode.options[2].text = an_wlan_mode_2;
			opmode.options[3].text = an_wlan_mode_3;
		}

		$.checkingInternet = function() {
			times++;
			$.getData('ca_access_checking_result.htm', function(json) {
				if(json.ap_conn_status.indexOf("0") > -1)
					top.location.href="ca_access_connect.htm"+$.ID_2;
				else if(json.ap_conn_status.indexOf("1") > -1 || times > max )
					top.location.href="ca_access_continue.htm"+$.ID_2;
				else if ( times < max )
					setTimeout('$.checkingInternet();', 5 * 1000);
			});
		}

		if ($('#apCheckingForm').length) {
			checkNum = 1;
			$('#checking').hide();
			if(lan_status == "0")
				top.location.href="ca_access_no_connect.htm"+$.ID_2;
			else {
				$('#checking').show();
				setTimeout(function(){
					$.checkingInternet();
				}, 5*1000);
			}
		}

		/*******************************************************************************************
		*
		*       access no connect
		*
		******************************************************************************************/
		if ($('#apNoConnectForm').length) {
			checkNum = 2;
			$('#nextStep').click(function() {
				top.location.href = "ca_access_checking.htm"+$.ID_2;
			});
		}

		/*******************************************************************************************
		*
		*       access connect, input security page
		*
		******************************************************************************************/

		$.checkAPInput = function() {
			if ( $('#securityOptions').val() != 0 ) {
				var sec_type = $('#securityOptions').val();
				switch(sec_type) {
					case '1': //None
						break;
					case '2': //WEP
						$('.first.access').find('.formElements').find('.key').each(function(i, ele) {						
							var reg = $.REG_KEY_64,
							msg = wep_64;
							if ( $('#wepEnc').val() == '13' ) {
								reg = $.REG_KEY_128;
								msg = wep_128;
							}
							if ( ( $(ele).val() != '' && !reg.test($(ele).val()) )
								|| ( $(ele).parent().find('input[type=radio]').is(':checked') && !reg.test($(ele).val()) )) {
							$.addErrMsgAfter($(ele).attr('id'), msg);
							}
						});
						break;
					case '3': // WPA-PSK [TKIP]
					case '6': // WPA2-PSK [AES]
					case '7': // WPA-PSK [TKIP] + WPA2-PSK [AES]
						if ( !$.REG_WPA_PWD.test($('#pwd').val()) ) {
							$.addErrMsgAfter('pwd', wpa_phrase, false, 'err_pripass');
						}
						break;
					default:
						$.addErrMsgAfter('securityOptions', no_security);
				}
			} else {
				$.addErrMsgAfter('securityOptions', no_security);
			}
		};

		$.checkAPInput5g = function() {
			if ( $('#securityOptions5g').val() != 0 ) {
				var sec_type = $('#securityOptions5g').val();
				switch(sec_type) {
					case '1': //None
						break;
					case '2': //WEP
						$('.second.access').find('.formElements').find('.key').each(function(i, ele) {						
							var reg = $.REG_KEY_64,
							msg = wep_64;
							if ( $('#wepEnc5g').val() == '13' ) {
								reg = $.REG_KEY_128;
								msg = wep_128;
							}
							if ( ( $(ele).val() != '' && !reg.test($(ele).val()) )
								|| ( $(ele).parent().find('input[type=radio]').is(':checked') && !reg.test($(ele).val()) )) {
							$.addErrMsgAfter($(ele).attr('id'), msg);
							}
						});
						break;
					case '3': // WPA-PSK [TKIP]
					case '6': // WPA2-PSK [AES]
					case '7': // WPA-PSK [TKIP] + WPA2-PSK [AES]
						if ( !$.REG_WPA_PWD.test($('#pwd5g').val()) ) {
							$.addErrMsgAfter('pwd5g', wpa_phrase, false, 'err_pripass');
						}
						break;
					default:
						$.addErrMsgAfter('securityOptions5g', no_security);
				}
			} else {
				$.addErrMsgAfter('securityOptions5g', no_security);
			}
		};

		if ($('#securityOptions').length) {
			$('#securityOptions').on('change', function () {
				var thisParent = $(this).parents('.formElements');
				if ($(this).val() != 0)
					$('.errorMsg').remove();
				if ($(this).val() > 2) {
					thisParent.find('.wep').slideUp();
					thisParent.find('.wpa').slideDown();
				} else if ($(this).val() > 1) {
					thisParent.find('.wep').slideDown();
					thisParent.find('.wpa').slideUp();
				} else {
					// hide the password pane
					thisParent.find('.pwdInput').slideUp();
					// reset the password fields
					thisParent.find('.pwdInput').find(':password').val('');
				}
			});
		}

		if ($('#securityOptions5g').length) {
			$('#securityOptions5g').on('change', function () {
				var thisParent = $(this).parents('.formElements');
				if ($(this).val() != 0)
					$('.errorMsg').remove();
				if ($(this).val() > 2) {
					thisParent.find('.wep').slideUp();
					thisParent.find('.wpa').slideDown();
				} else if ($(this).val() > 1) {
					thisParent.find('.wep').slideDown();
					thisParent.find('.wpa').slideUp();
				} else {
					// hide the password pane
					thisParent.find('.pwdInput').slideUp();
					// reset the password fields
					thisParent.find('.pwdInput').find(':password').val('');
				}
			});
		}

		$.setAPChannel = function() {
			var wChannel = document.getElementById("channel");
			if(wl_country == "8" || wl_country == "10")
				wChannel.options.length = 12;
			else
				wChannel.options.length = 14;
			for(var i=1; i<wChannel.options.length; i++) {
				wChannel.options[i].value = i;
				wChannel.options[i].text = (i < 10)? "0" + i : i;
			} 
		}

		/*$.setAPChannel5g = function() {
			var wChannel = document.getElementById("channel5g");
			if(wl_country == "8" || wl_country == "10")
				wChannel.options.length = 12;
			else
				wChannel.options.length = 14;
			for(var i=1; i<wChannel.options.length; i++) {
				wChannel.options[i].value = i;
				wChannel.options[i].text = (i < 10)? "0" + i : i;
			} 
		}*/

		$.setSecurity = function(num) {
			$('#securityOptions').val(num);
			if(num == "1") {
				$('.first.access').find('.formElements').find('.wep').hide();
				$('.first.access').find('.formElements').find('.wpa').hide();
				$('#securityOptions').val('0');
			} else if(num == "2") {
				$('.first.access').find('.formElements').find('.wep').show();
				$('.first.access').find('.formElements').find('.wpa').hide();
				$('#wepAuth').val(authType);
				$('#wepEnc').val(key_length);
				$('#wepEnc').trigger('change');
				if(keyno == '1')
					$('#wepKeyNo1').attr('checked', 'checked');
				else if(keyno == '2')
					$('#wepKeyNo2').attr('checked', 'checked');
				else if(keyno == '3')
					$('#wepKeyNo3').attr('checked', 'checked');
				else
					$('#wepKeyNo4').attr('checked', 'checked');
				$('#key1').val(ap_wl_key1);
				$('#key2').val(ap_wl_key2);
				$('#key3').val(ap_wl_key3);
				$('#key4').val(".");
			} else if(num == "3" || num == "6" || num == "7"){
				$('.first.access').find('.formElements').find('.wep').hide();
				$('.first.access').find('.formElements').find('.wpa').show();
				$('#pwd').val(ap_wl_password);
				$('#verifyPwd').val(ap_wl_password);
				if ( ap_wl_password.length >= $.MIN_PWD_CHARACTERS )
					$('#verifyPwd').prop('disabled', false);
			} else {
				$('.first.access').find('.formElements').find('.wep').hide();
				$('.first.access').find('.formElements').find('.wpa').hide();
				$('#securityOptions').val('0');
			}
		}

		$.setSecurity5g = function(num) {
			$('#securityOptions5g').val(num);
			if(num == "1") {
				$('.second.access').find('.formElements').find('.wep').hide();
				$('.second.access').find('.formElements').find('.wpa').hide();
				$('#securityOptions5g').val('0');
			} else if(num == "2") {
				$('.second.access').find('.formElements').find('.wep').show();
				$('.second.access').find('.formElements').find('.wpa').hide();
				$('#wepAuth5g').val(authType5g);
				$('#wepEnc5g').val(key_length_5g);
				$('#wepEnc5g').trigger('change');
				if(keyno5g == '1')
					$('#wepKeyNo5g1').attr('checked', 'checked');
				else if(keyno5g == '2')
					$('#wepKeyNo5g2').attr('checked', 'checked');
				else if(keyno5g == '3')
					$('#wepKeyNo5g3').attr('checked', 'checked');
				else
					$('#wepKeyNo5g4').attr('checked', 'checked');
				$('#key5g1').val(ap_wla_key1);
				$('#key5g2').val(ap_wla_key2);
				$('#key5g3').val(ap_wla_key3);
				$('#key5g4').val(".");
			} else if(num == "3" || num == "6" || num == "7"){
				$('.second.access').find('.formElements').find('.wep').hide();
				$('.second.access').find('.formElements').find('.wpa').show();
				$('#pwd5g').val(ap_wla_password);
				$('#verifyPwd5g').val(ap_wla_password);
				if ( ap_wla_password.length >= $.MIN_PWD_CHARACTERS )
					$('#verifyPwd5g').prop('disabled', false);
			} else {
				$('.second.access').find('.formElements').find('.wep').hide();
				$('.second.access').find('.formElements').find('.wpa').hide();
				$('#securityOptions5g').val('0');
			}
		}

		$.checkPass();
		if( typeof(wl_sectype) != "undefined" ) {
			setTimeout(function() {
				if(wl_sectype == "2") {
					$('#key4').val(ap_wl_key4);
					$('#pwd').val("");
					$('#verifyPwd').val("");
				} else if(wl_sectype == "3" || wl_sectype == "6" || wl_sectype == "7"){
					$('#key4').val("");
					$('#pwd').val(ap_wl_password);
					$('#verifyPwd').val(ap_wl_password);
				} else {
					$('#key4').val("");
					$('#pwd').val("");
					$('#verifyPwd').val("");
				}
				$('#key4').removeAttr('style');
			}, $.chromeTimer);
		}

		$.checkPass5g();
		if( typeof(wla_sectype) != "undefined" ) {
			setTimeout(function() {
				if(wla_sectype == "2") {
					$('#key5g4').val(ap_wla_key4);
					$('#pwd5g').val("");
					$('#verifyPwd5g').val("");
				} else if(wla_sectype == "3" || wla_sectype == "6" || wla_sectype == "7"){
					$('#key5g4').val("");
					$('#pwd5g').val(ap_wla_password);
					$('#verifyPwd5g').val(ap_wla_password);
				} else {
					$('#key5g4').val("");
					$('#pwd5g').val("");
					$('#verifyPwd5g').val("");
				}
				$('#key5g4').removeAttr('style');
			}, $.chromeTimer);
		}

		$.apWEPShowHidden = function() {
			var secOptions = document.getElementById('securityOptions'),
			sel = secOptions.value;
			if($('#opmode').val() != '1') {
				$("#securityOptions option[value='2']").remove();
			} else {
				if ( sel == '2' )
					sel = '0';
				secOptions.options[2].value = '2';
				secOptions.options[2].text = sec_wep_phrase;
				secOptions.options[3].value = '6';
				secOptions.options[3].text = sec_wpa2_phrase;
				secOptions.options[4] = new Option(sec_wpas_phrase, '7');
			}
			$('#securityOptions').val(sel);
			$('#securityOptions').trigger('change');
		};

		$.apWEPShowHidden5g = function() {
			var secOptions = document.getElementById('securityOptions5g'),
			sel = secOptions.value;
			if($('#opmode5g').val() != '1') {
				$("#securityOptions5g option[value='2']").remove();
			} else {
				if ( sel == '2' )
					sel = '0';
				secOptions.options[2].value = '2';
				secOptions.options[2].text = sec_wep_phrase;
				secOptions.options[3].value = '6';
				secOptions.options[3].text = sec_wpa2_phrase;
				secOptions.options[4] = new Option(sec_wpas_phrase, '7');
			}
			$('#securityOptions5g').val(sel);
			$('#securityOptions5g').trigger('change');
		};

		var modeArray = new Array(),
		modeValue = new Array(),
		selectMode = $('#opmode').val();

		$('option', '#opmode').each(function(i, ele){
			modeArray[i] = $(ele).html();
			modeValue[i] = $(ele).attr("value");
		});

		$.apModeShowHidden = function() {
			var options = 3,
			i = 0;
			selectMode = $('#opmode').val();
			if($('#securityOptions').val() == '2') {
				options = 1;
			}
			$('#opmode').empty();
			for ( ; i < options; i++ ) {
				if ( selectMode == modeValue[i] )
					$('<option value="'+modeValue[i]+'" selected>'+modeArray[i]+'</option>').appendTo('#opmode');
				else
					$('<option value="'+modeValue[i]+'">'+modeArray[i]+'</option>').appendTo('#opmode');
			}
		};

		var modeArray5g = new Array(),
		modeValue5g = new Array(),
		selectMode5g = $('#opmode5g').val();

		$('option', '#opmode5g').each(function(i, ele){
			modeArray5g[i] = $(ele).html();
			modeValue5g[i] = $(ele).attr("value");
		});

		$.apModeShowHidden5g = function() {
			var options = 4,
			i = 0;
			selectMode = $('#opmode5g').val();
			if($('#securityOptions5g').val() == '2') {
				options = 1;
			}
			$('#opmode5g').empty();
			for ( ; i < options; i++ ) {
				if ( selectMode == modeValue5g[i] )
					$('<option value="'+modeValue5g[i]+'" selected>'+modeArray5g[i]+'</option>').appendTo('#opmode5g');
				else
					$('<option value="'+modeValue5g[i]+'">'+modeArray5g[i]+'</option>').appendTo('#opmode5g');
			}
		};

		if ($('#accessPointForm').length) {
			$('#ssid').val(wl_ssid.replace(/&nbsp;/g, " "));
			$.setAPChannel();
			if(mode == '3' || mode == '5' || mode == '6')
				$('#opmode').val('3');
			else if(mode == '2')
				$('#opmode').val('2');
			else
				$('#opmode').val('1');
			//$('#opmode').val('3');
			$('#channel').val(get_channel);
			$.apWEPShowHidden();
			$.apModeShowHidden();
			$.setSecurity(wl_sectype);

			$('#ssid5g').val(wla_ssid.replace(/&nbsp;/g, " "));
			//$.setAPChannel5g();
			if(mode5g == '9')
				$('#opmode5g').val('9');
			else if(mode5g == '8')
				$('#opmode5g').val('8');
			else if(mode5g == '7')
				$('#opmode5g').val('7');
			else
				$('#opmode5g').val('1');
			//$('#opmode5g').val('3');
			$('#channel5g').val(get_channel_5g);
			$.apWEPShowHidden5g();
			$.apModeShowHidden5g();
			$.setSecurity5g(wla_sectype);

			$('#nextStep').click(function() {
				$('.errorMsg').remove();
				if ( !$.REG_SSID.test($('#ssid').val()) ) {
					$.addErrMsgAfter('ssid',ssid_invalid);
				}
				$.checkAPInput();

				if ( !$.REG_SSID.test($('#ssid5g').val()) ) {
					$.addErrMsgAfter('ssid5g',ssid_invalid);
				}
				$.checkAPInput5g();

				$('#confMode').val('0');
				$('#client2GHzSSID').val($.do_xss_ssid($('#ssid').val()));
				$('#wifiChannel').val($('#channel').val());
				$('#client2GHzSameSec').val('0');
				if($('#securityOptions').val() == '1') {
					$('#client2GHzSecurity').val('1');
					$('#clientMode').val($('#opmode').val());
				} else if($('#securityOptions').val() == '2') {
					$('#client2GHzSecurity').val('2');
					$('#clientMode').val('1');
					if($('#wepAuth').val() == '1')
						$('#client2GHzAuthType').val('1');
					else
						$('#client2GHzAuthType').val('2');
					if($('#wepEnc').val() == '5')
						$('#client2GHzEncrLen').val('5');
					else
						$('#client2GHzEncrLen').val('13');
					$('#client2GHzKeyNum').val($('input:radio[name="wep_key_no"]:checked').val());
					$('#client2GHzKey1').val($.do_xss_pass($('#key1').val()));
					$('#client2GHzKey2').val($.do_xss_pass($('#key2').val()));
					$('#client2GHzKey3').val($.do_xss_pass($('#key3').val()));
					$('#client2GHzKey4').val($.do_xss_pass($('#key4').val()));
					$('.column.first ul strong:last', '#continue').html($('#key'+$('#client2GHzKeyNum').val()).val().replace(/ /g, '&nbsp;'));
				} else {
					if ( $('#verifyPwd').val() != $('#pwd').val() && $('#pwd').val().length >= $.MIN_PWD_CHARACTERS ) {
						$('#verifyPwd').addClass('alert');
						$.addErrMsgAfter('verifyPwd', error_not_same_pwd, false, 'err_passsame');
						return false;
					}
					$('#clientMode').val($('#opmode').val());
					if($('#securityOptions').val() == '6')
						$('#client2GHzSecurity').val('6');
					else
						$('#client2GHzSecurity').val('7');
					$('#client2GHzPassword').val($.do_xss_pass($('#pwd').val()));
					$('.column.first ul strong:last', '#continue').html($('#pwd').val().replace(/ /g, '&nbsp;'));
				}

				$('#client5GHzSSID').val($.do_xss_ssid($('#ssid5g').val()));
				$('#wifiChannel5g').val($('#channel5g').val());
				$('#client5GHzSameSec').val('0');
				if($('#securityOptions5g').val() == '1') {
					$('#client5GHzSecurity').val('1');
					$('#clientMode5g').val($('#opmode5g').val());
				} else if($('#securityOptions5g').val() == '2') {
					$('#client5GHzSecurity').val('2');
					$('#clientMode5g').val('1');
					if($('#wepAuth5g').val() == '1')
						$('#client5GHzAuthType').val('1');
					else
						$('#client5GHzAuthType').val('2');
					if($('#wepEnc5g').val() == '5')
						$('#client5GHzEncrLen').val('5');
					else
						$('#client5GHzEncrLen').val('13');
					$('#client5GHzKeyNum').val($('input:radio[name="wep_key_no_5g"]:checked').val());
					$('#client5GHzKey1').val($.do_xss_pass($('#key5g1').val()));
					$('#client5GHzKey2').val($.do_xss_pass($('#key5g2').val()));
					$('#client5GHzKey3').val($.do_xss_pass($('#key5g3').val()));
					$('#client5GHzKey4').val($.do_xss_pass($('#key5g4').val()));
					$('.column.second ul strong:last', '#continue').html($('#key5g'+$('#client5GHzKeyNum').val()).val().replace(/ /g, '&nbsp;'));
				} else {
					if ( $('#verifyPwd5g').val() != $('#pwd5g').val() && $('#pwd5g').val().length >= $.MIN_PWD_CHARACTERS ) {
						$('#verifyPwd5g').addClass('alert');
						$.addErrMsgAfter('verifyPwd5g', error_not_same_pwd, false, 'err_passsame');
						return false;
					}
					$('#clientMode5g').val($('#opmode5g').val());
					if($('#securityOptions5g').val() == '6')
						$('#client5GHzSecurity').val('6');
					else
						$('#client5GHzSecurity').val('7');
					$('#client5GHzPassword').val($.do_xss_pass($('#pwd5g').val()));
					$('.column.second ul strong:last', '#continue').html($('#pwd5g').val().replace(/ /g, '&nbsp;'));
				}

				if ( !$('.errorMsg').length ) {
					if($('#client2GHzSecurity').val() == '1' || $('#client5GHzSecurity').val() == '1') {
						$.confirmBox(wps_warning3, null, function(){
                                                        $.submitApply();
						}, null, null);
					}else{
						$.submitApply();
					}
				}
			});
				$.submitApply = function() {
					$.submit_wait('body', $.APPLYING_DIV);

					$('.column.first ul strong:first', '#continue').html($('#ssid').val().replace(/ /g, '&nbsp;'));
					$('.column.first ul strong:eq(1)', '#continue').html($.formatSecType($('#securityOptions').val()));
					if($('#securityOptions').val() == "1" )
						$('.column.first ul li:last', '#continue').hide();

					$('.column.second ul strong:first', '#continue').html($('#ssid5g').val().replace(/ /g, '&nbsp;'));
					$('.column.second ul strong:eq(1)', '#continue').html($.formatSecType($('#securityOptions5g').val()));
					if($('#securityOptions5g').val() == "1" )
						$('.column.second ul li:last', '#continue').hide();

					$.postForm('#accessPointForm', '', function(json) {
						if ( json.status == '1' ) {
							var time = parseInt(json.wait) * 1000;
							if ( $.isMac || $.isPhonePad)
								time = 1000;
							setTimeout(function() {
								$('#accessPointDiv').hide();
								$('.running').remove();
								$('.secondary', '#fixedFooter').hide();
								$('#nextStep', '#fixedFooter').hide();
								$('#continueBt', '#fixedFooter').show();
								$('#continueBt').click(function() {
									$.change_domain(json.url);
								});
								$('#continue').show();
							}, time);
						} else {
							$.alertBox(json.msg);
						}
					});
				}
		}

		/*******************************************************************************************
		*
		*       apRetryForm, failure and continue page.
		*
		******************************************************************************************/

		if ( $("input[name='try_again']").length ) {
			$("input[name='try_again']").on('click', function(){
				if ( $(this).val() == "0" ) {
					$('.sectionIPAddr').show();
				} else {
					$('.sectionIPAddr').hide();
				}
			});
		}

		if ( $("input[name='configure']").length ) {
			$("input[name='configure']").on('click', function(){
				if ( $(this).val() == "0" ) {
					$('input', '.ipAddressInput').prop("disabled", false);
				} else {
					$('input', '.ipAddressInput').prop("disabled", true);
				}
			});
		}

		$.check_static_ip_mask_gtw = function() {
			var ipAddr = $('#ethr1').val()+'.'+$('#ethr2').val()+'.'+$('#ethr3').val()+'.'+$('#ethr4').val(),
			maskAddr = $('#mask1').val()+'.'+$('#mask2').val()+'.'+$('#mask3').val()+'.'+$('#mask4').val(),
			gatewayAddr = $('#gateway1').val()+'.'+$('#gateway2').val()+'.'+$('#gateway3').val()+'.'+$('#gateway4').val(),
			dnsAddr = $('#priAddr1').val()+'.'+$('#priAddr2').val()+'.'+$('#priAddr3').val()+'.'+$('#priAddr4').val(),
			secDnsAddr = $('#secAddr1').val()+'.'+$('#secAddr2').val()+'.'+$('#secAddr3').val()+'.'+$('#secAddr4').val();
			if($.checkipaddr(ipAddr) == false || $.is_sub_or_broad(ipAddr, ipAddr, maskAddr) == false) {
				$.addErrMsgAfter('ethr4', ip_invalid);
				return false;
			}
			if((maskAddr == "0.0.0.0") || (maskAddr == "255.255.255.255")) {
				$.addErrMsgAfter('mask4', subnet_invalid);
				return false;
			}
			if($.checksubnet(maskAddr) == false) {
				$.addErrMsgAfter('mask4', subnet_invalid);
				return false;
			}
			if($.checkgateway(gatewayAddr) == false) {
				$.addErrMsgAfter('gateway4', gateway_invalid);
				return false;
			}
			if($.isGateway(ipAddr,maskAddr,gatewayAddr) == false) {
				$.addErrMsgAfter('gateway4', gateway_invalid);
				return false;
			}
			if($.isSameIp(ipAddr, gatewayAddr) == true) {
				$.addErrMsgAfter('gateway4', gateway_invalid);
				return false;
			}
			if($.isSameSubNet(ipAddr,maskAddr,gatewayAddr,maskAddr) == false) {
				$.addErrMsgAfter('gateway4', same_subnet_ip_gtw);
				return false;
			}
			if($.checkipaddr(dnsAddr) == false) {
				$.addErrMsgAfter('priAddr4', primary_dns_invalid);
				return false;
			}
			if(secDnsAddr == '...')
				secDnsAddr = "";
			if(secDnsAddr != "") {
				if($.checkipaddr(secDnsAddr) == false) {
					$.addErrMsgAfter('secAddr4', invalid_second_dns);
					return false;
				}
			}
			return true;
		}

		if ($('#apRetryForm').length) {

			if(ether_get_ip != "") {
                                var ip_array = ether_get_ip.split('.');
                                $('#ethr1').val(ip_array[0]);
                                $('#ethr2').val(ip_array[1]);
                                $('#ethr3').val(ip_array[2]);
                                $('#ethr4').val(ip_array[3]);
                        }
                        if(ether_get_subnet != "") {
                                var mask_array=ether_get_subnet.split('.');
                                $('#mask1').val(mask_array[0]);
                                $('#mask2').val(mask_array[1]);
                                $('#mask3').val(mask_array[2]);
                                $('#mask4').val(mask_array[3]);
                        }
                        if(ether_get_gateway != "") {
                                var gtw_array=ether_get_gateway.split('.');
                                $('#gateway1').val(gtw_array[0]);
                                $('#gateway2').val(gtw_array[1]);
                                $('#gateway3').val(gtw_array[2]);
                                $('#gateway4').val(gtw_array[3]);
                        }
                        if(ether_get_dns1 != "") {
                                var dns_array=ether_get_dns1.split('.');
                                $('#priAddr1').val(dns_array[0]);
                                $('#priAddr2').val(dns_array[1]);
                                $('#priAddr3').val(dns_array[2]);
                                $('#priAddr4').val(dns_array[3]);
                        }
			if(ether_get_dns2 != "") {
                                var dns_array=ether_get_dns2.split('.');
                                $('#secAddr1').val(dns_array[0]);
                                $('#secAddr2').val(dns_array[1]);
                                $('#secAddr3').val(dns_array[2]);
                                $('#secAddr4').val(dns_array[3]);
                        }

			$('.primary').click(function(){
				$('.errorMsg').remove();

				if ( $('#retry').is(':checked') ) {
					top.location.href = "ca_welcome.htm" + $.ID_2;
					return false;
				} else {
					if ( $('#configSelf').is(':checked') ) {
						top.location.href = "status.htm" + $.ID_2;
						return false;
					} else {
						$('#etherIPAddr').val($('#ethr1').val()+'.'+$('#ethr2').val()+'.'+$('#ethr3').val()+'.'+$('#ethr4').val());
						$('#etherSubnet').val($('#mask1').val()+'.'+$('#mask2').val()+'.'+$('#mask3').val()+'.'+$('#mask4').val());
						$('#etherGateway').val($('#gateway1').val()+'.'+$('#gateway2').val()+'.'+$('#gateway3').val()+'.'+$('#gateway4').val());
						$('#etherDNSAddr1').val($('#priAddr1').val()+'.'+$('#priAddr2').val()+'.'+$('#priAddr3').val()+'.'+$('#priAddr4').val());
						$('#etherDNSAddr2').val($('#secAddr1').val()+'.'+$('#secAddr2').val()+'.'+$('#secAddr3').val()+'.'+$('#secAddr4').val());
						if($.check_static_ip_mask_gtw() == false) {
							return false;
						}
					}
				}

				if ( !$('.errorMsg').length ) {
					$.submit_wait('body', $.APPLYING_DIV);
					$.postForm('#apRetryForm', '', function(json) {
						if ( json.status == '1' ) {
							var time = parseInt(json.wait) * 1000;
							setTimeout(function() {
								location.href = json.url+$.ID_2;
							}, time);
						} else {
							$.alertBox(json.msg);
						}
					});
				}
			});
		}

	});//end ready function

}(jQuery));

