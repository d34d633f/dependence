/**
 * For password Settings page
 */
(function ($) {

        "use strict";

	var MIN_PWD_CHARACTERS = 8,
	timer = $.isChrome ? 1000 : 0;

	$(function () {
		/*******************************************************************************************
		 *
		 *       Password settings page
		 *
		 ******************************************************************************************/
		if ($('.pwdSettings').length) {
			//init
			if ( $("#pwdOn").is(':checked') ) {
				$('.pwdSettingsOptions').slideDown();
				$('.recoveryPwd').slideDown();
				$('.recoveryPwdOptions').slideDown();
			} else {
				$('.pwdSettingsOptions').slideUp();
				$('.recoveryPwd').slideUp();
				$('.recoveryPwdOptions').slideUp();
			}

			// show/hide the password settings
			$("#pwdOn").on('change', function () {
				$('.pwdSettingsOptions').slideDown();
				$('.recoveryPwd').slideDown();
				$('.recoveryPwdOptions').slideDown();
			});

			$("#pwdOff").on('change', function () {
				$('.pwdSettingsOptions').slideUp();
				$('.recoveryPwd').slideUp();
				$('.recoveryPwdOptions').slideUp();
			});

			$('#newUserName').blur(function() {
				var str = $('#newUserName').val();
				$('#err_email').remove();
				if ( !$.check_email(str) )
					$.addErrMsgAfter('newUserName', invalid_emaill, false, 'err_email');
			});

			$('#newUserName').keyup(function() {
				var str = $('#newUserName').val();
				if ( $.check_email(str) ) {
					$('#err_email').remove();
				}
			});

			$('.primaryPwd').blur(function () {
				var pwd = $(this).val();
				$('#err_passformat').remove();
				if ( pwd == '' )
					$.addErrMsgAfter('newPwd', error_password_format, false, 'err_passformat');
				else
					$('.verifyPwd').prop('disabled', false);
			});

			$('.primaryPwd').keyup(function () {
				var pwd = $(this).val();
				if (pwd.length > 0 ) {
					$('#err_passformat').remove();
					$('.verifyPwd').prop('disabled', false);
				} else {
					$('.verifyPwd').prop('disabled', true);
				}
			});

			$('.primaryPwd').focus(function () {
				var pwd = $(this).val();
				$('.verifyPwd').val('').removeClass('alert');
				$('#err_passsame').remove();
			});

			setTimeout(function(){
				$('#newUserName').val("");
				$('#newPwd').val("");
				$('#newPwdVerify').val("");
				$('#newUserName').removeAttr("style");
			}, $.chromeTimer);

			$('#saveBt').click(function () {
				$('.errorMsg').remove();
				if ( $("#pwdOn").is(":checked") ) {
					if ( !$.check_email($('#newUserName').val()) ) {
						$.addErrMsgAfter('newUserName', invalid_emaill, false, 'err_email');
						$("body,html").animate({scrollTop:0}, 200);
						return false;
					}
					if ( !$.REG_PASSWORD.test($('#newPwd').val()) ) {
						$.addErrMsgAfter('newPwd', error_password_format, false, 'err_passformat');
						$("body,html").animate({scrollTop:0}, 200);
						return false;
					}
					if ($('#newPwd').val() != $('#newPwdVerify').val() && $('#newPwd').val() != '' ) {
						$('.verifyPwd').addClass('alert');
						$.addErrMsgAfter('newPwdVerify', error_not_same_pwd, false, 'err_passsame');
						$("body,html").animate({scrollTop:0}, 200);
						return false;
					}

					if ($('#question1').val() == 0 ) {
						$.addErrMsgAfter('question1', error_no_question);
					}
					if ($('#answer1').val().length == 0 ) {
						$.addErrMsgAfter('answer1', error_no_answer);
					}
					if (!$.REG_ANSWER.test($('#answer1').val())) {
						$.addErrMsgAfter('answer1', invalid_answer);
					}
					if ($('#question2').val() == 0 ) {
						$.addErrMsgAfter('question2', error_no_question);
					}
					if ($('#answer2').val().length == 0 ) {
						$.addErrMsgAfter('answer2', error_no_answer);
					}
					if (!$.REG_ANSWER.test($('#answer2').val())) {
						$.addErrMsgAfter('answer2', invalid_answer);
					}
				}

				if (!$('.errorMsg').length){
					$.submit_wait('.main:first', $.PAGE_WAITING_DIV);
					$.postForm('#pwdSettingsForm','',function(json) {
						if ( json.status == "1" ) {
							if( typeof(json.reset) != 'undefined') {
								$.removeCookie('session');
								location.href = json.url;
							} else {
								setTimeout("$('.running').remove();", parseInt(json.wait, 10) * 1000);
							}
						} else {
							$.alertBox(json.msg);
						}
					});
				}
			});

			$('#resetBt').click(function () {
				document.location.reload();
			});
		} // end password settings page
		
	}); // end ready function
}(jQuery));
