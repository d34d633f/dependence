/**
 * For backup Settings page
 */
(function ($) {

	"use strict";

	$(function () {
		/*******************************************************************************************
		 * 
		 * init  page
		 *
		 *******************************************************************************************/
		if ( $('#backupForm').length ) {
			if ($('#backupBt').length) {
				var action = $('#backupForm').attr("action");
				$('#backupForm').attr("action", action+$.ID_2);
				$('#backupBt').click(function() {
					$('#backupForm').submit();
				});
			}
		}
		if ( $('#restoreForm').length ) {
			if ($('#restoreFile').length) {
				$('#restoreFile').on('change', function () {
					if ($.check_filesize(this, 4, 'M'))
						$('#restoreBt').prop("disabled", false);
					else
						$('#restoreBt').prop("disabled", true);
				});
			}

			if ($('#restoreYesBt').length ) {
				var action = $('#restoreForm').attr("action");
				$('#restoreForm').attr("action", action+$.ID_1);
				$('#restoreYesBt').click(function() {
					$('#restoreForm').submit();
				});
			}
			if ($('#restoreNoBt').length ) {
				$('#restoreNoBt').click(function() {
					$('#restoreMsg').hide();
					$('input[type=text]', '.fileInputWidget').val("");
					$('input[type=file]', '.fileInputWidget').val("");
					$('#restoreBt').prop("disabled", true);
					$('.backupSettingsOptions').show();
				});
			}
			$('#restoreBt').click(function() {
				$('.backupSettingsOptions').hide();
				$('#restoreMsg').show();
			});
		}

		if ( $('#resetYesBt').length ) {
			$('#resetYesBt').click(function() {
				$.submit_wait('body', $.UPDATEING_DIV);
				$.postForm('#resetForm', '', function(json) {
					$.removeCookie('interim');
					setTimeout('$.processing( 0, '+$.REBOOT_TIME +');', 1000 );
				});
			});
		}
		if ( $('#resetNoBt').length ) {
			$('#resetNoBt').click(function() {
				$('#resetMsg').hide();
				$('.backupSettingsOptions').show();
			});
		}
		$('#resetBt').click(function() {
			$('.backupSettingsOptions').hide();
			$('#resetMsg').show();
		});
		if ($('#okBt').length) {
			$('#okBt').click(function() {
				location.href="backUpSettings.htm"+$.ID_2;
			});
		}

		if ( $('#restartYesBt').length ) {
			$('#restartYesBt').click(function() {
				$.submit_wait('body', $.WAITING_DIV);
				$.postForm('#restartForm', '', function(json) {
					$.removeCookie('interim');
					$.removeCookie('session');
					setTimeout('$.processing( 0, '+$.REBOOT_TIME +');', 1000 );
				});
			});
		}
		if ( $('#restartNoBt').length ) {
			$('#restartNoBt').click(function() {
				$('#restartMsg').hide();
				$('.backupSettingsOptions').show();
			});
		}
		$('#restartBt').click(function() {
			$('.backupSettingsOptions').hide();
			$('#restartMsg').show();
		});

		$.get_status = function() {
			$.get('get_restore_status.htm'+$.ID_2, function(data){
				try {
				var json = JSON.parse(data); 
					if(json.restore_status == "1") {
						$(".running").remove();
						$.submit_wait('body', $.WAITING_DIV);
						setTimeout("$.get_status();", 2*1000);
					} else if ( json.restore_status == "2" ) {
						$(".running").remove();
						$('.backupSettingsOptions').hide();
						$('#pageMsg').html(restore_select_correct);
						$('#backupMsg').show();
					} else {
						$(".running").remove();
						$.submit_wait('body', $.UPDATEING_DIV);
						setTimeout('$.processing( 0, '+$.REBOOT_TIME +');', 1000 );
					}
				} catch ( e ) {
					$(".running").remove();
					$.submit_wait('body', $.UPDATEING_DIV);
					setTimeout('$.processing( 0, '+$.REBOOT_TIME +');', 1000 );
				}
			});
		}
		if (typeof(restore_status) != 'undefined') {
			if ( restore_status == "2" ) {
				$(".running").remove();
				$('.backupSettingsOptions').hide();
				$('#pageMsg').html(restore_select_correct);
				$('#backupMsg').show();
			} else if ( restore_status == "3" ) {
				$(".running").remove();
				$.submit_wait('body', $.UPDATEING_DIV);
				setTimeout('$.processing( 0, '+$.REBOOT_TIME +');', 1000 );
			} else {
				$.submit_wait('body', $.WAITING_DIV);
				$.get_status();
			}
		}
	}); // end ready function

}(jQuery));
