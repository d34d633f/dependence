<?
fwrite(w, $START, "#!/bin/sh\nexit 8\n");
fwrite(w, $STOP,  "#!/bin/sh\nexit 8\n");
?>
