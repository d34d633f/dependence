
get_reg() # $1: reg_addr
{
	ethreg $1 | awk '{print $5}'
}

set_reg() # $1: reg_addr, $2: value, $3: mask
{
	if [ $# == 2 ]; then
		ethreg $1=$2
		return
	fi

	local v0=$(get_reg $1)
	local v_value=$(($2 & $3))
	local v_clear=$(($3 ^ 0xffffffff))
	ethreg $1=$(($v0 & $v_clear | $v_value))
}

sw_enable_igmp_snooping() #
{
	set_reg 0x002c 0x00003f00 0x00003f00 # IGMP_JOIN_LEAVE_DP : flood IGMP/MLD
	set_reg 0x003c 0x0e480000 0x0f480000 # IGMP_JOIN_STATUS, IGMP_JOIN_NEW_EN, IGMP_V3_EN
	set_reg 0x0104 0x00300000 0x00300000 # port 0: IGMP_JOIN_EN, IGMP_LEAVE_EN
	set_reg 0x0204 0x00300000 0x00300000 # port 1: IGMP_JOIN_EN, IGMP_LEAVE_EN
	set_reg 0x0304 0x00300000 0x00300000 # port 2: IGMP_JOIN_EN, IGMP_LEAVE_EN
	set_reg 0x0404 0x00300000 0x00300000 # port 3: IGMP_JOIN_EN, IGMP_LEAVE_EN
	set_reg 0x0504 0x00300000 0x00300000 # port 4: IGMP_JOIN_EN, IGMP_LEAVE_EN
}

sw_config_vlan() # $1: iptv ports, eg. 0x8 means LAN4 is iptv port,
                 #                     0xc meas LAN3 & LAN4 are iptv ports, ...
{
	local iptv_port_mask=$(($1 & 0xf)) 
	local lan_port_mask=$(($iptv_port_mask ^ 0xf))
	local wan_port_mask=$(($iptv_port_mask | 0x10))

	# flush all vlan table
	set_reg 0x040 0x00000001
	set_reg 0x040 0x00000009
	# add vlan 1 in vlan table
	set_reg 0x044 $((0x00000800 | $(($lan_port_mask << 1)) | 1))
	set_reg 0x040 0x0001000a
	# add vlan 2 in vlan table
	set_reg 0x044 $((0x00000800 | $(($wan_port_mask << 1)) | 1))
	set_reg 0x040 0x0002000a

	# port0 (CPU_PORT)
	set_reg 0x104 0x00000200 0x00000300 # EG_VLAN_MODE (10): egress transmits frames with vlan
	set_reg 0x108 0x00010000 0x0fff0000 # VID
	set_reg 0x10c 0xc03e0000 0xc07f0000 # 802.1Q_MODE, PORT_VID_MEM

	# port 1~4 (LAN ports) and port 5 (WAN port)
	local i
	local i_mask
	local v_08
	local ports
	local v_0c
	local port_base
	for i in 1 2 3 4 5; do
		i_mask=$((1 << $(($i - 1)) ))
		if [ $(($wan_port_mask & $i_mask)) == 0 ]; then
			v_08=0x00010000
			ports=$(($lan_port_mask & $(($i_mask ^ 0x1f)) ))
		else
			v_08=0x00020000
			ports=$(($wan_port_mask & $(($i_mask ^ 0x1f)) ))
		fi
		v_0c=$(( $((3 << 30 )) | $(($ports << 17)) | $((1 << 16)) ))

		port_base=$(( $(($i+1)) << 8 ))
		set_reg $(($port_base + 0x4)) 0x00000100 0x00000300 # EG_VLAN_MODE (01): egress transmits frames without vlan
		set_reg $(($port_base + 0x8)) $v_08 0x0fff0000 # VID
		set_reg $(($port_base + 0xc)) $v_0c 0xc07f0000 # 802.1Q_MODE, PORT_VID_MEM
	done
}

sw_enable_acl()
{
	set_reg 0x003c 0x00200000 0x00200000 # ACL_EN
}

sw_adjust_ssdp_acl_rule() # $1: entry_index, $2: vlan_id, $3: phy_port
{
	local entry_index=$1
	local vlan_id=$2
	local phy_port=$3
	local index_offset=$(($entry_index << 5))
	local port_members=$(( $(($phy_port << 1)) | 1 ))

	# set a MAC match rule, mac addr: 01:00:5e:7f:ff:fa, vlan id

	# set entry index in ACL rule table
	set_reg $((0x58400 + $index_offset)) 0x5e7ffffa # DA:01:00:5e:7f:ff:fa
	set_reg $((0x58404 + $index_offset)) 0x00000100
	set_reg $((0x58408 + $index_offset)) 0x00000000
	set_reg $((0x5840c + $index_offset)) $((0x00000000 | $vlan_id)) # VID
	set_reg $((0x58410 + $index_offset)) 0x00000001 # VID_MASK_OPTION:1

	# set entry index in ACL mask table
	set_reg $((0x58c00 + $index_offset)) 0xffffffff # DA mask
	set_reg $((0x58c04 + $index_offset)) 0x0000ffff
	set_reg $((0x58c08 + $index_offset)) 0x00000000
	set_reg $((0x58c0c + $index_offset)) 0x00000fff # VID mask

	# set entry index for ACL rule control
	set_reg $((0x58800 + $index_offset)) 0x00000001 # just only one ACL rule, select ADDR0
	set_reg $((0x58804 + $index_offset)) $((0x00000000 | $entry_index)) # ADDR0: entry index
	set_reg $((0x58808 + $index_offset)) 0x00000000 # ADDR1
	set_reg $((0x5880c + $index_offset)) 0x00000000 # ADDR2
	set_reg $((0x58810 + $index_offset)) 0x00000000 # ADDR3
	# set ACL phy src port information
	set_reg $((0x58814 + $index_offset)) $((0x00000000 | $port_members))
	# set ACL rule length
	set_reg $((0x58818 + $index_offset)) 0x00000006 # rule length: 6 bytes
	# set ACL rule type select
	set_reg $((0x5881c + $index_offset)) 0x00000001 # type: MAC_RULE

	# set ACL rule result
	set_reg $((0x58000 + $index_offset)) 0x00000000
	set_reg $((0x58004 + $index_offset)) $(( 0x10000000 | $(($port_members << 20)) )) # DES_PORT_EN, DES_PORT
	set_reg $((0x58008 + $index_offset)) 0x00000000
}

sw_config_mac_clone() # $1: mac address xx:xx:xx:xx:xx:xx
{
	set - $(echo $1 |awk -F: '{print $1" "$2" "$3" "$4" "$5" "$6}')
	set_reg 0x54 0x${1}${2}${3}${4}
	set_reg 0x58 0x000f801f
	set_reg 0x50 0x${5}${6}000a
}
