config_email()
{
	$nvram set email_notify=$1
	if [ "$1" = "1" ];then
		$nvram set email_addr=$2
		$nvram set email_smtp=$3
		$nvram set email_send_alert=$8
        	$nvram set email_cfAlert_Select=$9      
       		if [ "${12}" = "1" ];then
			$nvram set email_endis_auth=${12}
			$nvram set email_username=$4
        		$nvram set email_password=$5
		else
			$nvram set email_endis_auth=${12}
		fi
	 	if [ "x${10}" = "x" ];then
			$nvram set email_cfAlert_Day=0
		else
			$nvram set email_cfAlert_Day=${10}
        	fi
		if [ "x${11}" = "x" ];then
			$nvram set email_schedule_hour=0
		else
			$nvram set email_schedule_hour=${11}  
		fi
	fi	
	$nvram set email_from_assign=$6
	$nvram set email_this_addr=$7
}
