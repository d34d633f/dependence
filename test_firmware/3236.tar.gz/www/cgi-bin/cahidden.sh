config_cahidden()
{
	$nvram set dns_hijack=$1
}
