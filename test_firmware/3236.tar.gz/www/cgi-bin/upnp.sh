config_upnp()
{
	if [ $1 -eq 1 ];then
		$nvram set upnp_enable=$1
		$nvram set upnp_AdverTime=$2
		$nvram set upnp_TimeToLive=$3
	else
		$nvram set upnp_enable=$1
	fi
}
