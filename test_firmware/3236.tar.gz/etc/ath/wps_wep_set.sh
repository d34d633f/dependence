#!/bin/sh
iwconfig=/sbin/iwconfig
iwpriv=/sbin/iwpriv
nvram=/usr/sbin/nvram

APNAME=ath0

wps_wep_set ()
{
 case "$(nvram get wl_sectype)" in
  2)
                iwpriv ${APNAME} wpa 0
                iwconfig ${APNAME} key [1] "$(nvram get wl_key1)"
                iwconfig ${APNAME} key [2] "$(nvram get wl_key2)"
                iwconfig ${APNAME} key [3] "$(nvram get wl_key3)"
                iwconfig ${APNAME} key [4] "$(nvram get wl_key4)"
                case "$(nvram get wl_auth)" in
                        0)      #Open System
                                iwpriv ${APNAME} authmode 1
                                iwconfig ${APNAME} key ["$(nvram get wl_key)"] open
                                ;;
                        1)      #Shared key
                                iwpriv ${APNAME} authmode 2
                                iwconfig ${APNAME} key ["$(nvram get wl_key)"] restricted
                                ;;
                        2)      #Automatic
                                iwpriv ${APNAME} authmode 4
                                iwconfig ${APNAME} key ["$(nvram get wl_key)"]
                                ;;
                esac
		;;
  *)
		echo "you should not call this script when the auth is not "
		;;
esac
}
#run form here
ATH_IF=$1
OPERATION=$2
case "$OPERATION" in
	start)
		wps_wep_set $ATH_IF
	;;
	stop)
		echo "only can be called in hostapd:wps_wep_set.sh start"
	;;
	*)
		echo "only can be called in hostapd:wps_wep_set.sh start"
	;;
esac
