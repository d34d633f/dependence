<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME		="adv_mssid";
$MY_MSG_FILE	=$MY_NAME.".php";
$CATEGORY		="adv";
$def_password	="XxXxXxXx";
/* --------------------------------------------------------------------------- */
if ($ACTION_POST!="" ||$mssid_del_id!="" )
{
	require("/www/model/__admin_check.php");
	echo "<!--\n";
	echo "f_final_mssid_state=".		$f_final_mssid_state.			"\n";	
	echo "f_final_vlan_state=".			$f_final_vlan_state.			"\n";
	echo "f_final_mssid_idx=".			$f_final_mssid_idx.				"\n";
	echo "f_final_ssid=".				$f_final_ssid.					"\n";
	echo "f_final_ssid_broadcast=".		$f_final_ssid_broadcast.		"\n";
	echo "f_final_security_type=".		$f_final_security_type.			"\n";
	echo "f_final_vlan_id=".			$f_final_vlan_id.				"\n";
	echo "f_final_wep_format=".			$f_final_wep_format.			"\n";
	echo "f_final_wep_length=".			$f_final_wep_length.			"\n";
	echo "f_final_wep_index=".			$f_final_wep_index.				"\n";
	echo "f_final_wep_key=".			$f_final_wep_key.				"\n";
	echo "f_final_cipher=".				$f_final_cipher.				"\n";
	echo "f_final_radius_server=".		$f_final_radius_server.			"\n";
	echo "f_final_radius_port=".		$f_final_radius_port.			"\n";
	echo "f_final_radius_secret=".		$f_final_radius_secret.			"\n";
	echo "f_final_passphrase=".			$f_final_passphrase.			"\n";
	echo "f_final_auth=".				$f_final_auth.					"\n";
	echo "f_final_key_interval=".		$f_final_key_interval.			"\n";
	if(query("/web/display/acct") =="1")
	{
		echo "f_final_ms_acc_mode=".		$f_final_ms_acc_mode.			"\n";
		echo "f_final_ms_acc_srv=".			$f_final_ms_acc_srv.			"\n";
		echo "f_final_ms_acc_port=".		$f_final_ms_acc_port.			"\n";
		echo "f_final_ms_acc_sec=".			$f_final_ms_acc_sec.			"\n";
	}
	echo "-->\n";
	
	if($mssid_del_id!="")
	{
		anchor("/wireless/multi/index:".$mssid_del_id);
		set("state",0);	
		$SUBMIT_STR=";submit WLAN";			
	}
	else
	{	
		$db_dirty=0;
		anchor("/wireless");
		if(query("vlan_state")	!= $f_final_vlan_state)		{set("vlan_state",	$f_final_vlan_state);			$db_dirty++;}

		if($f_final_vlan_state=="1" && $f_final_mssid_idx =="0")
		{
			anchor("/wireless");
			if(query("vlan_id")	!= $f_final_vlan_id)		{set("vlan_id",	$f_final_vlan_id);			$db_dirty++;}
		}
				
		if($f_final_vlan_state=="1" && $f_final_mssid_idx !="0")
		{
			anchor("/wireless/multi/index:".$f_final_mssid_idx);
			if(query("vlan_id")	!= $f_final_vlan_id)		{set("vlan_id",	$f_final_vlan_id);			$db_dirty++;}
		}

		if($f_final_mssid_state == "1" )
		{
			if(query("ap_mode")=="1"||query("ap_mode")=="2"|| query("ap_mode")=="3") 
			{
				if(query("ap_mode")=="1"||query("ap_mode")=="2")
					{set("ap_mode",	0);}
				if(query("ap_mode")=="3" && query("wds/withoutap")=="1") //if MSSID enable, AP Mode is "WDS without AP" ,"APC" or "APR" ,AP mode should be "Access Point"
					{set("ap_mode",	0);}
			}
		}			
		
		anchor("/wireless/multi");
		if(query("state")	!= $f_final_mssid_state)		{set("state",	$f_final_mssid_state);			$db_dirty++;}

		anchor("/wireless/multi/index:".$f_final_mssid_idx);

		if(query("state")			!= "1")							{set("state",			"1");				$db_dirty++;}								
		if(query("ssid")			!= $f_final_ssid)				{set("ssid",			$f_final_ssid);				$db_dirty++;}
		if(query("auth")			!= $f_final_auth)				{set("auth",			$f_final_auth);				$db_dirty++;}
		if(query("cipher")			!= $f_final_cipher)				{set("cipher",			$f_final_cipher);			$db_dirty++;}
		if(query("ssid_hidden")		!= $f_final_ssid_broadcast)		{set("ssid_hidden",		$f_final_ssid_broadcast);	$db_dirty++;}

		if($f_final_cipher ==1)
		{
			if(query("wep_key_index")	!= $f_final_wep_index)			{set("wep_key_index",	$f_final_wep_index);		$db_dirty++;}
			if(query("wep_keylength")	!= $f_final_wep_length)			{set("wep_keylength",	$f_final_wep_length);		$db_dirty++;}
			if(query("wep_keyformat")	!= $f_final_wep_format)			{set("wep_keyformat",	$f_final_wep_format);		$db_dirty++;}
			if(query("wep_key")			!= $f_final_wep_key)			{set("wep_key",			$f_final_wep_key);			$db_dirty++;}

			for("/wireless/multi/index")
			{
				$ms_check_index = query("wep_key_index");
				if($ms_check_index == $f_final_wep_index)
				{
					set("wep_keylength",	$f_final_wep_length);	$db_dirty++;
					set("wep_keyformat",	$f_final_wep_format);	$db_dirty++;
					set("wep_key",			$f_final_wep_key);	$db_dirty++;
				}
			}
			
			$wireless_defkey = query("/wireless/defkey");
			
			if($wireless_defkey == $f_final_wep_index) //if mssid key index = primary defkey
			{
				set("/wireless/keylength",	$f_final_wep_length);	$db_dirty++;
				set("/wireless/keyformat",	$f_final_wep_format);	$db_dirty++;
			}
			for("/wireless/wepkey")//change primary wepkey table
			{
				if($@ == $f_final_wep_index)
				{
					set("/wireless/wepkey:".$@.,	$f_final_wep_key);	$db_dirty++;
					set("/wireless/wepkey:".$@."/keyformat",	$f_final_wep_format);	$db_dirty++;
					set("/wireless/wepkey:".$@."/keylength",			$f_final_wep_length);	 $db_dirty++;
				}
			}

		}

		if($f_final_auth=="2" || $f_final_auth=="4" || $f_final_auth=="6")	// wpa series
		{
			if(query("radius_server")	!= $f_final_radius_server)		{set("radius_server",	$f_final_radius_server);	$db_dirty++;}
			if(query("radius_port")		!= $f_final_radius_port)		{set("radius_port",		$f_final_radius_port);		$db_dirty++;}
			if($f_final_radius_secret!=$def_password)
			{
				if(query("radius_secret")	!= $f_final_radius_secret)		{set("radius_secret",	$f_final_radius_secret);	$db_dirty++;}
			}

			if(query("/web/display/acct") =="1")
			{
				if(query("acct_state")	!= $f_final_ms_acc_mode)			{set("acct_state",	$f_final_ms_acc_mode);		$db_dirty++;}
				if($f_final_ms_acc_mode =="1")
				{
					if(query("acct_server")	!= $f_final_ms_acc_srv)			{set("acct_server",	$f_final_ms_acc_srv);		$db_dirty++;}
					if(query("acct_port")	!= $f_final_ms_acc_port)		{set("acct_port",	$f_final_ms_acc_port);		$db_dirty++;}
					if($f_final_ms_acc_sec != $def_password)
					{if(query("acct_secret")	!= $f_final_ms_acc_sec)			{set("acct_secret",	$f_final_ms_acc_sec);		$db_dirty++;}}
				}	
			}		
			
			if(query("interval")			!= $f_final_key_interval)		{set("interval",			$f_final_key_interval);			$db_dirty++;}	
		}
		
		if($f_final_auth=="3" || $f_final_auth=="5" || $f_final_auth=="7")	// wpa series
		{
			if(query("interval")			!= $f_final_key_interval)		{set("interval",			$f_final_key_interval);			$db_dirty++;}	

			if($f_final_passphrase!=$def_password)
			{
				if(query("passphrase")		!= $f_final_passphrase)			{set("passphrase",		$f_final_passphrase);		$db_dirty++;}
			}			
		}		

		if($db_dirty > 0)	{$SUBMIT_STR="submit WLAN";}
		else				{$SUBMIT_STR="";}
	}

	$NEXT_PAGE=$MY_NAME;
	if($SUBMIT_STR!="")	{require($G_SAVING_URL);}
	else				{require($G_NO_CHANGED_URL);}
}

/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
require("/www/comm/__js_ip.php");
/* --------------------------------------------------------------------------- */
// get the variable value from rgdb.	
anchor("/wireless");
$ms_apmode	=query("ap_mode");
$ms_wds_mode	=query("wds/withoutap");
$ms_vlan_state	= query("vlan_state");

/********* primary ssid data *********/	
$ms_pri_ssid		= get("j", "ssid");
$ms_pri_ssid_broadcast		= query("ssidhidden");
$ms_pri_vlan_id		= query("vlan_id");

$ms_auth		= query("authentication");
$ms_cipher		= query("wpa/wepmode");
$ms_key_interval = query("wpa/grp_rekey_interval");
if		($ms_cipher=="0")					{$security_type="0";}
else if	($ms_cipher=="1" &&	$ms_auth=="0")	{$security_type="1";}
else if	($ms_cipher=="1" &&	$ms_auth=="1")	{$security_type="2";}
if		($ms_auth=="2")		{$security_type="6";}
else if		($ms_auth=="3")		{$security_type="3";}
else if		($ms_auth=="4")		{$security_type="7";}
else if		($ms_auth=="5")		{$security_type="4";}
else if		($ms_auth=="6")		{$security_type="8";}
else if		($ms_auth=="7")		{$security_type="5";}

$ms_wep_length = query("keylength");
$ms_wep_format = query("keyformat");

$ms_wep_index	= query("defkey");
if($ms_wep_index ==1)	{$ms_wep		= get("j","wepkey:1");}
else if($ms_wep_index ==2)	{$ms_wep		= get("j","wepkey:2");}
else if($ms_wep_index ==3)	{$ms_wep		= get("j","wepkey:3");}
else if($ms_wep_index ==4)	{$ms_wep		= get("j","wepkey:4");}

$ms_radius_ip1		= query("wpa/radiusserver");
$ms_radius_port1	= query("wpa/radiusport");
if(query("wpa/radiussecret")=="")	{$ms_radius_sec1= "";}
else								{$ms_radius_sec1=$def_password;}

$ms_acc_display		= query("/web/display/acct");
if(query("/web/display/acct") =="1")
{
	$ms_db_acc_state		= query("wpa/acctstate");
	$ms_db_acc_srv		= query("wpa/acctserver");
	$ms_db_acc_port	= query("wpa/acctport");
	if(query("wpa/acctsecret")=="")	{$ms_db_acc_sec= "";}
	else								{$ms_db_acc_sec=$def_password;}
}

if(query("wpa/wpapsk")=="")			{$ms_wpapsk="";}
else								{$ms_wpapsk=$def_password;}
					
/********* mulit ssid data *********/				
anchor("/wireless/multi");
$ms_state	= query("state");
for("/wireless/multi/index")
{
	echo "<tr>\n";	
	echo "<input type=hidden id=ms_ssid".$@." name=ms_ssid".$@." value=\"".get("h","ssid")."\">\n";
	echo "<input type=hidden id=ms_ssidbroadcast".$@." name=ms_ssidbroadcast".$@." value=".query("ssid_hidden").">\n";
	echo "<input type=hidden id=ms_auth".$@." name=ms_auth".$@." value=".query("auth").">\n";
	echo "<input type=hidden id=ms_cipher".$@." name=ms_cipher".$@." value=".query("cipher").">\n";
	echo "<input type=hidden id=ms_vlan_id".$@." name=ms_vlan_id".$@." value=".query("vlan_id").">\n";
	echo "<input type=hidden id=ms_wep_key_index".$@." name=ms_wep_key_index".$@." value=".query("wep_key_index").">\n";
	echo "<input type=hidden id=ms_wep_keylength".$@." name=ms_wep_keylength".$@." value=".query("wep_keylength").">\n";
	echo "<input type=hidden id=ms_wep_keyformat".$@." name=ms_wep_keyformat".$@." value=".query("wep_keyformat").">\n";
	echo "<input type=hidden id=ms_wep_key".$@." name=ms_wep_key".$@." value=".query("wep_key").">\n";
	echo "<input type=hidden id=ms_interval".$@." name=ms_interval".$@." value=".query("interval").">\n";
	echo "<input type=hidden id=ms_passphrase".$@." name=ms_passphrase".$@." value=".query("passphrase").">\n";
	echo "<input type=hidden id=ms_radius_server".$@." name=ms_radius_server".$@." value=".query("radius_server").">\n";
	echo "<input type=hidden id=ms_radius_port".$@." name=ms_radius_port".$@." value=".query("radius_port").">\n";
	echo "<input type=hidden id=ms_radius_secret".$@." name=ms_radius_secret".$@." value=".query("radius_secret").">\n";
	echo "<input type=hidden id=ms_key_interval".$@." name=ms_key_interval".$@." value=".query("interval").">\n";
	if(query("/web/display/acct") =="1")
	{
		echo "<input type=hidden id=ms_acc_state".$@." name=ms_acc_state".$@." value=".query("acct_state").">\n";
		echo "<input type=hidden id=ms_acc_srv".$@." name=ms_acc_srv".$@." value=".query("acct_server").">\n";
		echo "<input type=hidden id=ms_acc_port".$@." name=ms_acc_sport".$@." value=".query("acct_port").">\n";
		echo "<input type=hidden id=ms_acc_sec".$@." name=ms_acc_sec".$@." value=".query("acct_secret").">\n";
	}
	echo "</tr>\n";	
	
	$ssid_value = get("j", "ssid");
	if($@==1)
	{$get_ms_ssid1= $ssid_value;}
	else if($@==2)
	{$get_ms_ssid2= $ssid_value;}	
	else if($@==3)
	{$get_ms_ssid3= $ssid_value;}
	else if($@==4)
	{$get_ms_ssid4= $ssid_value;}
	else if($@==5)
	{$get_ms_ssid5= $ssid_value;}
	else if($@==6)
	{$get_ms_ssid6= $ssid_value;}
	else if($@==7)
	{$get_ms_ssid7= $ssid_value;}					
}

$td1			="<td class='l_tb' width='120'>";
$td2			="<td class='l_tb'>";
/* --------------------------------------------------------------------------- */
?>

<script>
/* page init functoin */
var check_apmode_msg = 0;

function init()
{
	var f=get_obj("frm");

	get_obj("ms_security_pri").style.display = "none";
	get_obj("ms_security_sec").style.display = "none";
	
	if(f.f_mssid_state.value == "")
	{
		f.SecondSSIDState.checked = <? if ($ms_state=="1") {echo "true";} else {echo "false";}?>;
		f.VLAN.checked = <? if ($ms_vlan_state=="1") {echo "true";} else {echo "false";}?>;
	}
	else
	{	
		f.SecondSSIDState.value		=	f.f_mssid_state.value;
		f.VLAN.value		=	f.f_vlan_state.value;
	}		
	if(f.f_ssid_select.value == "" || f.f_ssid_select.value == "0")
	{
		f.MSSID.value = "<?=$ms_pri_ssid?>";
		select_index(f.MS_Ssid_Broadcast, "<?=$ms_pri_ssid_broadcast?>");
		get_obj("ms_security_pri").style.display = "";
		select_index(f.Security_pri, "<?=$security_type?>");
		f.GroupID.value = "<?=$ms_pri_vlan_id?>";
		
		/****** WEP *********/
		select_index(f.KeyType,"<?=$ms_wep_format?>");
		select_index(f.KeySize,	"<?=$ms_wep_length?>");
		select_index(f.KeyIndex, "<?=$ms_wep_index?>");
		f.KeySet.value = "<?=$ms_wep?>";
	
		/****** EAP *********/
		select_index(f.Cipher_eap,	"<?=$ms_cipher?>");
		f.MS_eap_grp_key_interval.value	="<?=$ms_key_interval?>";			
		f.RadiusServer.value		="<?=$ms_radius_ip1?>";
		f.RadiusPort.value	="<?=$ms_radius_port1?>";
		f.RadiusSecret.value	="<?=$ms_radius_sec1?>";	

		if("<?=$ms_acc_display?>"=="1")
		{
			select_index(f.ms_acc_mode,	"<?=$ms_db_acc_state?>");			
			f.ms_acc_srv.value		="<?=$ms_db_acc_srv?>";
			f.ms_acc_port.value	="<?=$ms_db_acc_port?>";
			f.ms_acc_sec.value	="<?=$ms_db_acc_sec?>";				
		}	
		/****** PSK *********/	
		select_index(f.Cipher_psk,	"<?=$ms_cipher?>");
		f.MS_psk_grp_key_interval.value	="<?=$ms_key_interval?>";			
		f.wpapsk1.value		="<?=$ms_wpapsk?>";	
	}
	else
	{
		var ssid_index = f.f_ssid_select.value;
		select_index(f.MS_MSSIDIdx, ssid_index);
		if(ssid_index==1)
			f.MSSID.value = "<?=$get_ms_ssid1?>";
		else if(ssid_index==2)
			f.MSSID.value = "<?=$get_ms_ssid2?>";			
		else if(ssid_index==3)
			f.MSSID.value = "<?=$get_ms_ssid3?>";			
		else if(ssid_index==4)
			f.MSSID.value = "<?=$get_ms_ssid4?>";			
		else if(ssid_index==5)
			f.MSSID.value = "<?=$get_ms_ssid5?>";			
		else if(ssid_index==6)
			f.MSSID.value = "<?=$get_ms_ssid6?>";			
		else if(ssid_index==7)
			f.MSSID.value = "<?=$get_ms_ssid7?>";																		
		//f.MSSID.value = document.getElementById("ms_ssid"+ssid_index).value;		
		select_index(f.MS_Ssid_Broadcast, document.getElementById("ms_ssidbroadcast"+ssid_index).value);
		get_obj("ms_security_sec").style.display = "";
		if(document.getElementById("ms_cipher"+ssid_index).value=="0")					
			f.Security.value="0";
		else if	(document.getElementById("ms_cipher"+ssid_index).value=="1" &&document.getElementById("ms_auth"+ssid_index).value=="0")	
			f.Security.value="1";
		else if	(document.getElementById("ms_cipher"+ssid_index).value=="1" &&document.getElementById("ms_auth"+ssid_index).value=="1")	
			f.Security.value="2";
		
		if(document.getElementById("ms_auth"+ssid_index).value=="2")		
			f.Security.value="6";
		else if(document.getElementById("ms_auth"+ssid_index).value=="3")		
			f.Security.value="3";
		else if(document.getElementById("ms_auth"+ssid_index).value=="4")		
			f.Security.value="7";
		else if(document.getElementById("ms_auth"+ssid_index).value=="5")		
			f.Security.value="4";
		else if(document.getElementById("ms_auth"+ssid_index).value=="6")		
			f.Security.value="8";
		else if(document.getElementById("ms_auth"+ssid_index).value=="7")		
			f.Security.value="5";

		/****** WEP *********/
		select_index(f.KeyType, document.getElementById("ms_wep_keyformat"+ssid_index).value);
		select_index(f.KeySize, document.getElementById("ms_wep_keylength"+ssid_index).value);
		select_index(f.KeyIndex, document.getElementById("ms_wep_key_index"+ssid_index).value);
		f.KeySet.value = document.getElementById("ms_wep_key"+ssid_index).value;

		/****** EAP *********/
		select_index(f.Cipher_eap,	document.getElementById("ms_cipher"+ssid_index).value);
		f.MS_eap_grp_key_interval.value =  document.getElementById("ms_key_interval"+ssid_index).value;
		f.RadiusServer.value =  document.getElementById("ms_radius_server"+ssid_index).value;
		f.RadiusPort.value	= document.getElementById("ms_radius_port"+ssid_index).value;
		if(document.getElementById("ms_radius_secret"+ssid_index).value =="")
			f.RadiusSecret.value = "";
		else
			f.RadiusSecret.value ="<?=$def_password?>";
			
		if("<?=$ms_acc_display?>"=="1")
		{
			f.ms_acc_mode.value =  document.getElementById("ms_acc_state"+ssid_index).value;
			f.ms_acc_srv.value =  document.getElementById("ms_acc_srv"+ssid_index).value;
			f.ms_acc_port.value	= document.getElementById("ms_acc_port"+ssid_index).value;
			if(document.getElementById("ms_acc_sec"+ssid_index).value =="")
				f.ms_acc_sec.value = "";
			else
				f.ms_acc_sec.value ="<?=$def_password?>";			
		}
		//f.RadiusSecret.value = document.getElementById("ms_radius_secret"+ssid_index).value;		

		/****** PSK *********/	
		select_index(f.Cipher_psk,	document.getElementById("ms_cipher"+ssid_index).value);
		f.MS_psk_grp_key_interval.value =  document.getElementById("ms_key_interval"+ssid_index).value;
		if(document.getElementById("ms_passphrase"+ssid_index).value =="")
			f.wpapsk1.value = "";
		else	
			f.wpapsk1.value ="<?=$def_password?>";
		//f.wpapsk1.value	= document.getElementById("ms_passphrase"+ssid_index).value;			

		f.GroupID.value = document.getElementById("ms_vlan_id"+ssid_index).value;
	}
	Change_VLAN();
	Change_Auth_Switch();
	if("<?=$ms_acc_display?>"=="1")
	{	
		chg_ms_acc_mode();
	}
}

function check()
{
	var f		=get_obj("frm");
	var f_final	=get_obj("final_form");
		
	f_final.f_final_mssid_state.value			="";
	f_final.f_final_vlan_state.value			="";	
	f_final.f_final_mssid_idx.value				="";		
	f_final.f_final_ssid.value					="";
	f_final.f_final_ssid_broadcast.value		="";
	f_final.f_final_security_type.value			="";
	f_final.f_final_vlan_id.value				="";	
	f_final.f_final_wep_format.value			="";
	f_final.f_final_wep_length.value			="";
	f_final.f_final_wep_index.value				="";
	f_final.f_final_wep_key.value				="";
	f_final.f_final_cipher.value				="";
	f_final.f_final_radius_server.value			="";
	f_final.f_final_radius_port.value			="";
	f_final.f_final_radius_secret.value			="";
	f_final.f_final_passphrase.value			="";	
	f_final.f_final_auth.value					="";
	f_final.f_final_key_interval.value			="";
	if("<?=$ms_acc_display?>"=="1")
	{
		f_final.f_final_ms_acc_mode.value			="";	
		f_final.f_final_ms_acc_srv.value			="";
		f_final.f_final_ms_acc_port.value			="";
		f_final.f_final_ms_acc_sec.value			="";
	}		
	
	if(is_blank(f.MSSID.value))
	{
		alert("<?=$a_empty_ssid?>");
		f.MSSID.focus();
		return false;
	}	
	if(first_blank(f.MSSID.value))
	{
		alert("<?=$a_first_blank_ssid?>");
		f.MSSID.select();
		return false;
	}
		
	if(strchk_unicode(f.MSSID.value))
	{
		alert("<?=$a_invalid_ssid?>");
		f.MSSID.select();
		return false;
	}	

	if(f.VLAN.checked)
	{
		if(is_blank(f.GroupID.value))
		{
			alert("<?=$a_empty_vlan_id?>");
			f.GroupID.focus();
			return false;
		}	
        else if (f.GroupID.value < 1 || f.GroupID.value > 4094 || (isNaN(f.GroupID.value)))
        {
            alert("<?=$a_invalid_vlan_id?>");
            f.GroupID.value = "";
            f.GroupID.focus();
            return false;
        }
	}
		
	f_final.f_final_mssid_state.value		=(f.SecondSSIDState.checked ? "1":"0");
	f_final.f_final_vlan_state.value		=(f.VLAN.checked ? "1":"0");
	f_final.f_final_mssid_idx.value			=f.MS_MSSIDIdx.value;
	f_final.f_final_ssid.value				=f.MSSID.value;
	f_final.f_final_ssid_broadcast.value	=f.MS_Ssid_Broadcast.value;
	f_final.f_final_security_type.value		=f.Security.value;
	f_final.f_final_vlan_id.value			=f.GroupID.value;	

	//open
	if(f.Security.value == "0")
	{
		// assign final post variables
		f_final.f_final_auth.value="0";
		f_final.f_final_cipher.value="0";
	}
	// open+wep / shared key
	else if(f.Security.value == "1" || f.Security.value == "2")
	{
	
		if(f.KeyType.value == 2)//hex
		{
			if(f.KeySize.value == 64)
			{
				if(f.KeySet.value.length != 10)	
				{
					alert("<?=$a_invalid_hex_64_key_length?>");	
				  	f.KeySet.value = "";
				  	return false;					
				}
				else
				{
				  	if(!HexCheck2(f.KeySet.value))
				  	{
                        alert("<?=$a_invalid_hex_64_key_value?>");
                        f.KeySet.value = "";
                        return false;
		    	  	}					
				}
			}	
			else if(f.KeySize.value == 128)
			{
				if(f.KeySet.value.length != 26)	
				{
					alert("<?=$a_invalid_hex_128_key_length?>");	
				  	f.KeySet.value = "";
				  	return false;					
				}
				else
				{
				  	if(!HexCheck2(f.KeySet.value))
				  	{
                        alert("<?=$a_invalid_hex_128_key_value?>");
                        f.KeySet.value = "";
                        return false;
		    	  	}					
				}
			}					
		}
		else //ascii
		{
			if(f.KeySize.value == 64)
			{
				if(f.KeySet.value.length != 5)	
				{
					alert("<?=$a_invalid_ascii_64_key_length?>");	
				  	f.KeySet.value = "";
				  	return false;					
				}
				else
				{
				  	if(!ASCIICheck(f.KeySet.value))
				  	{
                        alert("<?=$a_invalid_ascii_64_key_value?>");
                        f.KeySet.value = "";
                        return false;
		    	  	}					
				}
			}	
			else if(f.KeySize.value == 128)
			{
				if(f.KeySet.value.length != 13)	
				{
					alert("<?=$a_invalid_ascii_128_key_length?>");	
				  	f.KeySet.value = "";
				  	return false;					
				}
				else
				{
				  	if(!ASCIICheck(f.KeySet.value))
				  	{
                        alert("<?=$a_invalid_ascii_128_key_value?>");
                        f.KeySet.value = "";
                        return false;
		    	  	}					
				}
			}		
		}		
		if(f.Security.value == "1")
			f_final.f_final_auth.value		="0";
		else if(f.Security.value == "2")
			f_final.f_final_auth.value		="1";
			
		f_final.f_final_cipher.value						="1";
		f_final.f_final_wep_format.value			=f.KeyType.value;
		f_final.f_final_wep_length.value			=f.KeySize.value;
		f_final.f_final_wep_index.value				=f.KeyIndex.value;
		f_final.f_final_wep_key.value				=f.KeySet.value;		
	}	
	// wpa series
	else if(f.Security.value >= "3")
	{
		//eap
		if(f.Security.value == "6" || f.Security.value == "7" ||f.Security.value == "8")
		{

			if(is_blank(f.MS_psk_grp_key_interval.value) ||is_blank_in_string(f.MS_eap_grp_key_interval.value)|| isNaN(f.MS_psk_grp_key_interval.value) || f.MS_eap_grp_key_interval.value < 300 || f.MS_eap_grp_key_interval.value > 9999999)
			{
				alert("<?=$a_invalid_key_interval?>");
				f.MS_eap_grp_key_interval.focus();
				return false;
			}		

			if(!is_valid_ip(f.RadiusServer.value,0))
			{
				alert("<?=$a_invalid_radius_ip1?>");
				f.RadiusServer.select();
				return false;
			}
			if(is_blank(f.RadiusPort.value))
			{
				alert("<?=$a_invalid_radius_port1?>");
				f.RadiusPort.focus();
				return false;
			}
			if(!is_valid_port_str(f.RadiusPort.value))
			{
				alert("<?=$a_invalid_radius_port1?>");
				f.RadiusPort.select();
				return false;
			}
			if(is_blank(f.RadiusSecret.value))
			{
				alert("<?=$a_empty_radius_sec1?>");
				f.RadiusSecret.focus();
				return false;
			}
			if(strchk_unicode(f.RadiusSecret.value))
			{
				alert("<?=$a_invalid_radius_sec1?>");
				f.RadiusSecret.select();
				return false;
			}
			if("<?=$ms_acc_display?>"=="1")
			{
				if(f.ms_acc_mode.value == "1")
				{
					if(!is_valid_ip(f.ms_acc_srv.value,0))
					{
						alert("<?=$a_invalid_acc_srv?>");
						f.ms_acc_srv.select();
						return false;
					}
					if(is_blank(f.ms_acc_port.value))
					{
						alert("<?=$a_invalid_acc_port?>");
						f.ms_acc_port.focus();
						return false;
					}
					if(!is_valid_port_str(f.ms_acc_port.value))
					{
						alert("<?=$a_invalid_acc_port?>");
						f.ms_acc_port.select();
						return false;
					}
					if(is_blank(f.ms_acc_sec.value))
					{
						alert("<?=$a_empty_acc_sec?>");
						f.ms_acc_sec.focus();
						return false;
					}
					if(strchk_unicode(f.ms_acc_sec.value))
					{
						alert("<?=$a_invalid_acc_sec?>");
						f.ms_acc_sec.select();
						return false;
					}	
				}
			}	

			f_final.f_final_cipher.value			=f.Cipher_eap.value;
			f_final.f_final_key_interval.value		=f.MS_eap_grp_key_interval.value;
			f_final.f_final_radius_server.value		=f.RadiusServer.value;
			f_final.f_final_radius_port.value		=f.RadiusPort.value;
			f_final.f_final_radius_secret.value		=f.RadiusSecret.value;
			if("<?=$ms_acc_display?>"=="1")
			{
				f_final.f_final_ms_acc_mode.value		=f.ms_acc_mode.value;
				f_final.f_final_ms_acc_srv.value		=f.ms_acc_srv.value;
				f_final.f_final_ms_acc_port.value		=f.ms_acc_port.value;
				f_final.f_final_ms_acc_sec.value		=f.ms_acc_sec.value;
			}				
			if(f.Security.value == "6")
				f_final.f_final_auth.value		="2";	
			else if(f.Security.value == "7")
				f_final.f_final_auth.value		="4";
			else if(f.Security.value == "8")
				f_final.f_final_auth.value		="6";									
		}
		//psk
		else
		{
			if(is_blank(f.MS_psk_grp_key_interval.value) ||is_blank_in_string(f.MS_eap_grp_key_interval.value)|| isNaN(f.MS_psk_grp_key_interval.value)|| f.MS_psk_grp_key_interval.value < 300 || f.MS_psk_grp_key_interval.value > 9999999)
			{
				alert("<?=$a_invalid_key_interval?>");
				f.MS_psk_grp_key_interval.focus();
				return false;
			}

			if(f.wpapsk1.value.length <8 || f.wpapsk1.value.length > 63)
			{
				alert("<?=$a_invalid_psk_len?>");
				f.wpapsk1.select();
				return false;
			}
			if(strchk_unicode(f.wpapsk1.value))
			{
				alert("<?=$a_invalid_psk?>");
				f.wpapsk1.select();
				return false;
			}

			f_final.f_final_cipher.value			=f.Cipher_psk.value;
			f_final.f_final_key_interval.value		=f.MS_psk_grp_key_interval.value;
			f_final.f_final_passphrase.value		=f.wpapsk1.value;			
			if(f.Security.value == "3")
				f_final.f_final_auth.value		="3";	
			else if(f.Security.value == "4")
				f_final.f_final_auth.value		="5";
			else if(f.Security.value == "5")
				f_final.f_final_auth.value		="7";	
		}	
	}
	else
	{
		alert("Unknown Authentication Type.");
		return false;
	}
	f_final.submit();	
}

function do_cancel()
{
	self.location.href="<?=$MY_NAME?>.php?random_str="+generate_random_str();
}

function MSSID_Display()
{
	var f=get_obj("frm")
	
	get_obj("show_MSSID_table").style.display = "none";		
	
	if(f.SecondSSIDState.checked)
	{
		if(("<?=$ms_apmode?>" =="1" ||"<?=$ms_apmode?>" =="2" ||("<?=$ms_apmode?>" =="3" && "<?=$ms_wds_mode?>" =="1"))&& check_apmode_msg == 0)
		{
		 	alert("<?=$a_invalid_apmode?>");
			check_apmode_msg = 1;
		}
		get_obj("show_MSSID_table").style.display = "";	
		//f.MS_BAND.disabled = false;
		f.MS_MSSIDIdx.disabled = false;
		if(f.MS_MSSIDIdx.value == 0)
		{
			f.MSSID.disabled = true;
			f.MS_Ssid_Broadcast.disabled = true;
			f.Security_pri.disabled = true;
			f.KeyType.disabled = true;	
			f.KeySize.disabled = true;
			f.KeyIndex.disabled = true;
			f.KeySet.disabled = true;
			f.Cipher_eap.disabled = true;
			f.RadiusServer.disabled = true;
			f.RadiusPort.disabled = true;
			f.RadiusSecret.disabled = true;
			f.Cipher_psk.disabled = true;
			f.wpapsk1.disabled = true;	
			f.MS_eap_grp_key_interval.disabled = true;
			f.MS_psk_grp_key_interval.disabled = true;	
			if("<?=$ms_acc_display?>"=="1")
			{
				f.ms_acc_mode.disabled = true;
				f.ms_acc_srv.disabled = true;
				f.ms_acc_port.disabled = true;
				f.ms_acc_sec.disabled = true;
			}					
		}		
		else
		{
			f.MSSID.disabled = false;
			f.MS_Ssid_Broadcast.disabled = false;
			f.Security.disabled = false;		
			f.KeyType.disabled = false;	
			f.KeySize.disabled = false;
			f.KeyIndex.disabled = false;
			f.KeySet.disabled = false;
			f.Cipher_eap.disabled = false;
			f.RadiusServer.disabled = false;
			f.RadiusPort.disabled = false;
			f.RadiusSecret.disabled = false;
			f.Cipher_psk.disabled = false;
			f.wpapsk1.disabled = false;		
			f.MS_eap_grp_key_interval.disabled = false;
			f.MS_psk_grp_key_interval.disabled = false;	
			if("<?=$ms_acc_display?>"=="1")
			{
				f.ms_acc_mode.disabled = false;
				f.ms_acc_srv.disabled = false;
				f.ms_acc_port.disabled = false;
				f.ms_acc_sec.disabled = false;	
			}				
		}
	
	}
	else
	{
		//f.MS_BAND.disabled = true;
		f.MS_MSSIDIdx.disabled = true;
		f.MSSID.disabled = true;
		f.MS_Ssid_Broadcast.disabled = true;
		f.Security_pri.disabled = true;
		f.Security.disabled = true;
		f.GroupID.disabled = true;
		f.KeyType.disabled = true;	
		f.KeySize.disabled = true;
		f.KeyIndex.disabled = true;
		f.KeySet.disabled = true;
		f.Cipher_eap.disabled = true;
		f.RadiusServer.disabled = true;
		f.RadiusPort.disabled = true;
		f.RadiusSecret.disabled = true;
		f.Cipher_psk.disabled = true;
		f.wpapsk1.disabled = true;		
		f.MS_eap_grp_key_interval.disabled = true;
		f.MS_psk_grp_key_interval.disabled = true;
		if("<?=$ms_acc_display?>"=="1")
		{
			f.ms_acc_mode.disabled = true;
			f.ms_acc_srv.disabled = true;
			f.ms_acc_port.disabled = true;
			f.ms_acc_sec.disabled = true;		
		}
	}	
	
	
}

function Change_VLAN()
{
	var f = get_obj("frm");
	
	if(f.VLAN.checked)
	{
		f.SecondSSIDState.checked = true;
		f.SecondSSIDState.disabled = true;
		f.GroupID.disabled = false;
	}	
	else
	{
		f.SecondSSIDState.disabled = false;	
		f.GroupID.disabled = true;
	}	
				
	MSSID_Display();	
}	

function Change_Auth_Switch()
{
	var f=get_obj("frm")
	get_obj("show_key_setting").style.display = "none";	
	get_obj("show_PassPhrase_setting").style.display = "none";
	get_obj("show_eap_setting").style.display = "none";	


	if(f.f_ssid_select.value == "" || f.f_ssid_select.value == "0")
	{
		if((f.Security_pri.value == 1)||(f.Security_pri.value == 2))
			get_obj("show_key_setting").style.display = "";	
		
		if((f.Security_pri.value == 3)||(f.Security_pri.value == 4)||(f.Security_pri.value == 5))
			get_obj("show_PassPhrase_setting").style.display = "";				
	
		if((f.Security_pri.value == 6)||(f.Security_pri.value == 7)||(f.Security_pri.value == 8))
			get_obj("show_eap_setting").style.display = "";	
	}
	else
	{
		if((f.Security.value == 1)||(f.Security.value == 2))
			get_obj("show_key_setting").style.display = "";	
		
		if((f.Security.value == 3)||(f.Security.value == 4)||(f.Security.value == 5))
			get_obj("show_PassPhrase_setting").style.display = "";				
	
		if((f.Security.value == 6)||(f.Security.value == 7)||(f.Security.value == 8))
			get_obj("show_eap_setting").style.display = "";			
	}
}

function Change_Key_Type_Or_Size()
{
	
}

function Change_Band()
{
	var f=get_obj("frm")
	
	f.f_band.value	= f.MS_BAND.value;

	if(f.f_band.value == "")
		select_index(f.MS_BAND, "1");
	else
		f.MS_BAND.value = f.f_band.value;
		
		
	if(f.MS_BAND.value == 0)
		f.f_ssid.value = "papa_b";
	else if(f.MS_BAND.value == 1)
		f.f_ssid.value = "papa_g";
	else
		f.f_ssid.value = "papa_n";	
	
	f.MSSID.value = f.f_ssid.value;
}

function Change_MSSID_Index()
{
	var f=get_obj("frm")
	
	f.f_ssid_select.value= f.MS_MSSIDIdx.value;	
	f.f_mssid_state.value		=(f.SecondSSIDState.checked ? "1":"0");
	f.f_vlan_state.value		=(f.VLAN.checked ? "1":"0");	
	init();
	//location.href = "adv_mssid.php?" + f.MS_MSSIDIdx.selectedIndex;
}

function chg_ms_acc_mode()
{
	var f = get_obj("frm");

	if(f.MS_MSSIDIdx.value =="0" || f.ms_acc_mode.value == "0")
	{
		f.ms_acc_srv.disabled = true;
		f.ms_acc_port.disabled = true;
		f.ms_acc_sec.disabled = true;		
	}
	else
	{
		f.ms_acc_srv.disabled = false;
		f.ms_acc_port.disabled = false;
		f.ms_acc_sec.disabled = false;		
	}	
}
</script>
<body onload="init();" <?=$G_BODY_ATTR?>>
<form name="final_form" id="final_form" method="post" action="<?=$MY_NAME?>.php">
<input type="hidden" name="ACTION_POST"				value="final">
<input type="hidden" name="f_final_mssid_state"		value="">
<input type="hidden" name="f_final_vlan_state"		value="">
<input type="hidden" name="f_final_mssid_idx"		value="">
<input type="hidden" name="f_final_ssid"			value="">
<input type="hidden" name="f_final_ssid_broadcast"	value="">
<input type="hidden" name="f_final_security_type"	value="">
<input type="hidden" name="f_final_wep_format"		value="">
<input type="hidden" name="f_final_wep_length"		value="">
<input type="hidden" name="f_final_wep_index"		value="">
<input type="hidden" name="f_final_wep_key"			value="">
<input type="hidden" name="f_final_cipher"			value="">
<input type="hidden" name="f_final_radius_server"	value="">
<input type="hidden" name="f_final_radius_port"		value="">
<input type="hidden" name="f_final_radius_secret"	value="">
<input type="hidden" name="f_final_passphrase"		value="">
<input type="hidden" name="f_final_vlan_id"			value="">
<input type="hidden" name="f_final_auth"			value="">
<input type="hidden" name="f_final_key_interval"    value="">
<input type="hidden" name="f_final_ms_acc_mode"		value="">
<input type="hidden" name="f_final_ms_acc_srv"		value="">
<input type="hidden" name="f_final_ms_acc_port"		value="">
<input type="hidden" name="f_final_ms_acc_sec"		value="">
</form>

<form name="frm" id="frm" method="post" action="<?=$MY_NAME?>.php" onsubmit="return check();">
<input type="hidden" name="ACTION_POST" value="SOMETHING">
<input type="hidden" name="f_band"				value="">
<input type="hidden" name="f_ssid"				value="">
<input type="hidden" name="f_ssid_select"		value="">
<input type="hidden" name="f_MSSID1_ssid"		value="">
<input type="hidden" name="f_mssid_state"		value="">
<input type="hidden" name="f_vlan_state"		value="">
<?require("/www/model/__banner.php");?>
<?require("/www/model/__menu_top.php");?>
<table <?=$G_MAIN_TABLE_ATTR?> height="100%">
<tr valign=top>
	<td <?=$G_MENU_TABLE_ATTR?>>
	<?require("/www/model/__menu_left.php");?>
	</td>
	<td id="maincontent">
		<div id="box_header">
		<?
		require($LOCALE_PATH."/dsc/dsc_".$MY_NAME.".php");
		?>
		<script>apply('check()'); echo ("&nbsp;"); cancel('');</script>
		</div>
<!-- ________________________________ Main Content Start ______________________________ -->
		<div class="box">
			<h2><?=$m_context_title?></h2>
			<table cellpadding="1" cellspacing="1" border="0" width=525>
			<tr>
				<?=$td1?>
					<input name="SecondSSIDState" id="SecondSSIDState" type="checkbox" onclick="MSSID_Display()" value="1"><?=$m_enable_mssid?>
				</td>
				<?=$td2?>	
					<input name="VLAN" id="VLAN" type="checkbox" onclick="Change_VLAN()" value="1"><?=$m_enable_vlan?>
				</td>
			</tr>	

			<tr>
				<td height="10"></td>
			</tr>	
<!--
			<tr>
				<td class="l_tb"><?=$m_ms_band?></td>
				<td class="l_tb">
							<select name="MS_BAND" id="MS_BAND" onChange="Change_Band()">
								<option value="0"><?=$m_ms_11b?></option>
								<option value="1"><?=$m_ms_11g?></option>
								<option value="2"><?=$m_ms_11n?></option>																			
							</select>
				</td>
			</tr>	
-->			
			<tr>
				<?=$td1?><?=$m_ms_index?></td>
				<?=$td2?>
							<select name="MS_MSSIDIdx" id="MS_MSSIDIdx" onChange="Change_MSSID_Index()">
								<option value="0"><?=$m_ms_ps?></option>
								<option value="1"><?=$m_ms_ms1?></option>
								<option value="2"><?=$m_ms_ms2?></option>
								<option value="3"><?=$m_ms_ms3?></option>
								<option value="4"><?=$m_ms_ms4?></option>
								<option value="5"><?=$m_ms_ms5?></option>
								<option value="6"><?=$m_ms_ms6?></option>
								<option value="7"><?=$m_ms_ms7?></option>																				
							</select>
				</td>
			</tr>	
			<tr>
				<?=$td1?><?=$m_ms_ssid?></td>
				<?=$td2?>
					<input name="MSSID" id="MSSID" type="text" size="20" maxlength="32" value="">
				</td>
			</tr>	
			<tr>
				<?=$td1?><?=$m_ms_ssid_broadcast?></td>
				<?=$td2?>
							<select name="MS_Ssid_Broadcast" id="MS_Ssid_Broadcast">
								<option value="0"><?=$m_ms_enable?></option>									
								<option value="1"><?=$m_ms_disable?></option>																
							</select>
				</td>
			</tr>												
			</table>
			<div id="ms_security_pri" style="display:none">
			<table cellpadding="1" cellspacing="1" border="0" width="525">				
			<tr>
				<?=$td1?><?=$m_ms_security?></td>
				<?=$td2?>
					<select id="Security_pri" name="Security_pri" onChange="Change_Auth_Switch()">
						<option value="0" selected><?=$m_ms_disable_security?></option>
						<option value="1"><?=$m_ms_enable_wep_open?></option>
						<option value="2"><?=$m_ms_enable_wep_shared?></option>
						<option value="6"><?=$m_ms_wpa_eap_security?></option>						
						<option value="3"><?=$m_ms_wpa_psk_security?></option>
						<option value="7"><?=$m_ms_wpa2_eap_security?></option>
						<option value="4"><?=$m_ms_wpa2_psk_security?></option>
						<option value="8"><?=$m_ms_wpa2_auto_eap_security?></option>												
						<option value="5"><?=$m_ms_wpa2_auto_psk_security?></option>
					</select>
				</td>
			</tr>
			</table>
			</div>	
			<div id="ms_security_sec" style="display:none">
			<table cellpadding="1" cellspacing="1" border="0" width="525">				
			<tr>
				<?=$td1?><?=$m_ms_security?></td>
				<?=$td2?>
					<select id="Security" name="Security" onChange="Change_Auth_Switch()">
						<option value="0" selected><?=$m_ms_disable_security?></option>
						<option value="1"><?=$m_ms_enable_wep_open?></option>
						<!--option value="2"><?=$m_ms_enable_wep_shared?></option-->
						<option value="6"><?=$m_ms_wpa_eap_security?></option>						
						<option value="3"><?=$m_ms_wpa_psk_security?></option>
						<option value="7"><?=$m_ms_wpa2_eap_security?></option>
						<option value="4"><?=$m_ms_wpa2_psk_security?></option>
						<option value="8"><?=$m_ms_wpa2_auto_eap_security?></option>												
						<option value="5"><?=$m_ms_wpa2_auto_psk_security?></option>
					</select>
				</td>
			</tr>
			</table>
			</div>									
			<table cellpadding="1" cellspacing="1" border="0" width=525>
			<tr>
				<?=$td1?><?=$m_ms_vlanid?></td>
				<?=$td2?>
					<input name="GroupID" id="GroupID" type="text" size="5" maxlength="5" value="">
				</td>
			</tr>				
			</table>
			</div>				
		<div class="box" id="show_key_setting" style="display:none">
			<h2><?=$m_context_key_setting_title?></h2>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<td class="l_tb"><?=$m_ms_key_type?></td>
				<td class="l_tb">
					<select id="KeyType" name="KeyType" onChange="Change_Key_Type_Or_Size()">
						<option value="2"><?=$m_ms_hex?></option>
						<option value="1"><?=$m_ms_ascii?></option>
					</select>				
				</td>
			</tr>
			<tr>
				<td class="l_tb"><?=$m_ms_key_size?></td>
				<td class="l_tb">
					<select id="KeySize" name="KeySize" size=1 onChange="Change_Key_Type_Or_Size()">
						<option value="64"><?=$m_ms_64bit_wep?></option>
						<option value="128"><?=$m_ms_128bit_wep?></option>
					</select>			
				</td>
			</tr>	
			<tr>
				<td class="l_tb"><?=$m_ms_key?></td>
				<td class="l_tb">
					<select name="KeyIndex" id="KeyIndex">
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
					</select>		
					<input type="password" id="KeySet" name="KeySet" size="20" maxlength="32" value="">
				</td>
			</tr>	
							
			</table>
		</div>	
		<!-- **************************** PSK *********************************-->
		<div class="box" id="show_PassPhrase_setting" style="display:none">
			<h2><?=$m_context_PassPhrase_setting_title?></h2>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<td class="l_tb"><?=$m_ms_cipher_type?></td>
				<td class="l_tb">
						<select id="Cipher_psk" name="Cipher_psk">
						<option value="4"><?=$m_ms_auto?></option>							
						<option value="3"><?=$m_ms_aes?></option>
						<option value="2"><?=$m_ms_tkip?></option>
						</select>		
				</td>
			</tr>
			<tr>
				<td class="l_tb"><?=$m_ms_grp_key_interval?></td>
				<td class="l_tb"><?=$symbol?>
					<input id="MS_psk_grp_key_interval" name="MS_psk_grp_key_interval" maxlength=7 size=8 value="">
				</td>
			</tr>
			<tr>
				<td class="l_tb"><?=$m_ms_passphrase?></td>
				<td class="l_tb">
					<input type="password" id="wpapsk1" name="wpapsk1" size="40" maxlength="64" value="">
				</td>
			</tr>
			</table>
		</div>	
		<!-- **************************** EAP *********************************-->
		<div class="box" id="show_eap_setting" style="display:none">
			<h2><?=$m_context_eap_setting_title?></h2>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<td class="l_tb"><?=$m_ms_cipher_type?></td>
				<td class="l_tb">
						<select id="Cipher_eap" name="Cipher_eap">
						<option value="4"><?=$m_ms_auto?></option>							
						<option value="3"><?=$m_ms_aes?></option>
						<option value="2"><?=$m_ms_tkip?></option>
						</select>		
				</td>
			<tr>
				<td class="l_tb"><?=$m_ms_grp_key_interval?></td>
				<td class="l_tb"><?=$symbol?>
					<input id="MS_eap_grp_key_interval" name="MS_eap_grp_key_interval" maxlength=7 size=8 value="">
				</td>
			</tr>
			</tr>				
			<tr>
				<td class="l_tb"><?=$m_ms_ipaddr?></td>
				<td class="l_tb"><?=$symbol?>
					<input id="RadiusServer" name="RadiusServer" maxlength=15 size=15 value="">
				</td>
			</tr>
			<tr>
				<td class="l_tb"><?=$m_ms_port?></td>
				<td class="l_tb"><?=$symbol?>
					<input type="text" id="RadiusPort" name="RadiusPort" size="8" maxlength="5" value="">
				</td>
			</tr>
			<tr>
				<td class="l_tb"><?=$m_ms_shared_sec?></td>
				<td class="l_tb"><?=$symbol?>
					<input type="password" id="RadiusSecret" name="RadiusSecret" size="50" maxlength="64" value="">
				</td>
			</tr>

<? if(query("/web/display/acct") =="0")	{echo "<!--";} ?>	
			<tr>
				<td class="l_tb"><?=$m_ms_acc_state?></td>
				<td class="l_tb">
						<select id="ms_acc_mode" name="ms_acc_mode" onchange="chg_ms_acc_mode()">
						<option value="0"><?=$m_ms_disable?></option>							
						<option value="1"><?=$m_ms_enable?></option>
						</select>		
				</td>
			<tr>
			<tr>
				<td class="l_tb"><?=$m_ms_acc_ipaddr?></td>
				<td class="l_tb"><?=$symbol?>
					<input id="ms_acc_srv" name="ms_acc_srv" maxlength=15 size=15 value="">
				</td>
			</tr>
			<tr>
				<td class="l_tb"><?=$m_ms_acc_port?></td>
				<td class="l_tb"><?=$symbol?>
					<input type="text" id="ms_acc_port" name="ms_acc_port" size="8" maxlength="5" value="">
				</td>
			</tr>
			<tr>
				<td class="l_tb"><?=$m_ms_acc_sec?></td>
				<td class="l_tb"><?=$symbol?>
					<input type="password" id="ms_acc_sec" name="ms_acc_sec" size="50" maxlength="64" value="">
				</td>
			</tr>
<? if(query("/web/display/acct") =="0")	{echo "-->";} ?>						
			</table>
		</div>
		<!-- **************************** end of EAP *********************************-->		
		<div class="box" id="show_MSSID_table" style="display:none">
			<h2><?=$m_title_MSSID?></h2>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<td>
            		<table border="0" cellspacing="3">
             			<tr style="text-align:center;">
  	            			<td width="74" id="MSSIDList">
  	            				<font id="MSTableFont">Index</font>
	 		 	            </td>
  		    		        <td width="128" id="MSSIDList">
  	    	        			<font id="MSTableFont">SSID</font>
		  		            </td>
  	    			        <td width="45" id="MSSIDList">
  	            				<font id="MSTableFont">Band</font>
  	      		      		</td>
	  	        		    <td  width="114" id="MSSIDList">
  		            			<font id="MSTableFont">Encryption</font>
			  	            </td>
  	    			        <td width="42" id="MSSIDList">
  	            				<font id="MSTableFont">VLAN ID</font>
		            	    <td width="26" id="MSSIDList">
        		        	    <font id="MSTableFont">Del</font>
                			</td>  	            
              			</tr>
            		</table>
				</td>
			</tr>	
			<tr>
				<td>
            		<iframe src="MSSIDList.php" width="475" marginwidth="0" height="150" marginheight="0" align="middle" scrolling="auto">
            		</iframe>
            	</td>
            </tr>																																																				
			</table>
		</div>	
<!-- ________________________________  Main Content End _______________________________ -->
	</td>
	<td <?=$G_HELP_TABLE_ATTR?>><?require($LOCALE_PATH."/help/h_".$MY_NAME.".php");?></td>
</tr>
</table>
<?require("/www/model/__tailer.php");?>
</form>
</body>
</html>			
