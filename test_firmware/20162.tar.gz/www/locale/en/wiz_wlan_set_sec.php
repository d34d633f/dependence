<?
/* DAP-1522 */
$a_invalid_passphrase = "Invalid Password.";
$a_invalid_key_format = "Invalid Password Format.";
$a_invalid_key_length = "Invalid Password Length.";

$m_wep_key_len   = "Password Type";
$m_hex_h         = "64Bit (10 hex digits)";
$m_ascii_h       = "128Bit (26 hex digits)";
$m_hex_a         = "64Bit (5 ascii characters)";
$m_ascii_a       = "128Bit (13 ascii characters)";
$m_wep_key_value = "Password";
$m_passphrase    = "Password";
?>
