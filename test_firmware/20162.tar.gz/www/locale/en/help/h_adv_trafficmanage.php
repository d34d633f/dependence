<strong>Helpful Hints...</strong><br>
<br>
Enable this option if you want to allow TRAFFIC MANAGER to control wireless traffic speed.
<br><br>
For most applications, the traffic manager ensure the right traffic speed and specific traffic manager rules are not required.
<br><br>
<p class="helpful_hints"><b><a href="spt_adv.php#trafficmgr" class="special">More...</a></b></p>
