<strong>Helpful Hints...</strong><br>
<? if(query("/wireless/ap_mode") =="1")	{echo "<!--";} ?>
<br>
Changing your Wireless Network Name is the first step in securing your wireless network. Change it to a familiar name that does not contain any personal information.
<br><br>
Auto Channel Scan is set by default. It automatcially finds the least loaded channel for interference-free communication.
<br><br>
Enabling Hidden Mode is another way to secure your network. With this option enabled, no wireless clients will be able to see your wireless network when they scan to see what's available. For your wireless devices to connect to your access point, you will need to manually enter the Wireless Network Name on each device.
<br><br>
If you have enabled Wireless Security, make sure you write down the WEP Key or Passphrase that you have configured. You will need to enter this information on any wireless device that you connect to your wireless network.
<br><br>
<? if(query("/wireless/ap_mode") =="1")	{echo "-->";} ?>
<? if(query("/wireless/ap_mode") =="0")	{echo "<!--";} ?>
<br>
Select the SSID which you want your bridge to connect to.
<br><br>
If you have enabled Wireless Security, make sure you write down the WEP Key or Passphrase that you have configured. You will need to enter this information on every wireless device that you connect to your wireless network.
<br><br>
<? if(query("/wireless/ap_mode") =="0")	{echo "-->";} ?>
<p class="helpful_hints"><b><a href="spt_bsc.php#wizard" class="special">More...</a></b></p>