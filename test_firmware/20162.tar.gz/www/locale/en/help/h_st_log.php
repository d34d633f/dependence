<strong>Helpful Hints...</strong><br>
<br>
Check the log frequently to detect unauthorized network usage.
<br><br>
<p class="helpful_hints"><b><a href="spt_st.php#log" class="special">More...</a></b></p>
