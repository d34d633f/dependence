<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; Create a list of MAC addresses that you would either like to allow or deny access to your network.<br>
<br>
&nbsp;&#149;&nbsp; Computers that have obtained an IP address from the router's DHCP server will be in the DHCP Client List. Select a device from the drop down menu and click the arrow to add that device's MAC to the list.<br>
<br>
&nbsp;&#149;&nbsp; Click the <strong>CLEAR</strong> button to remove the MAC address from the MAC Filtering list.<br>
