<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; For added security, it is recommended that you disable the <strong>WAN Ping Respond</strong> option. Ping is often used by malicious Internet users to locate active networks or PCs.<br>
<br>
&nbsp;&#149;&nbsp; Gaming Mode should be used when you are playing games on the Internet from behind the router.<br>
<br>
&nbsp;&#149;&nbsp; If you are having trouble receiving multicast streams from the Internet, make sure the Multicast Stream option is enabled.<br>
