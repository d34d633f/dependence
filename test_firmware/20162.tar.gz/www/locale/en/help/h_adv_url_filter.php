<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; Create a list of Websites that you would like the devices on your network to be allowed or denied access to.<br>
<br>
&nbsp;&#149;&nbsp; Keywords can be entered in this list in order to block any URL containing the keyword entered.<br>
