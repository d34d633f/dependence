<strong>Helpful Hints...</strong><br>
<? if(query("/wireless/ap_mode") =="1")	{echo "<!--";} ?>
<br>
Also referred to as private settings. LAN settings allow you to configure the LAN interface of the access point. The LAN IP address is private to your internal network and is not visible to the Internet. The default IP address is 192.168.0.50, with a subnet mask of 255.255.255.0.
<br><br>
LAN Connection - The factory default setting is "Static IP" to allow the IP address of the access point to be manually configured in accordance with the local area network requirements. Enable "Dynamic IP (DHCP)" to allow the DHCP host to automatically assign the access point an IP address that conforms to the applied local area network requirements.
<br><br>
<? if(query("/wireless/ap_mode") =="1")	{echo "-->";} ?>
<? if(query("/wireless/ap_mode") =="0")	{echo "<!--";} ?>
<br>
If you have a DHCP server on your network, you can select DHCP to get the IP address from a DHCP server.
<? if(query("/wireless/ap_mode") =="0")	{echo "-->";} ?>

<p class="helpful_hints"><b><a href="spt_bsc.php#lan" class="special">More...</a></b></p>
