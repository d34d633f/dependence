<strong>Helpful Hints...</strong><BR>
<BR>
If you already have a wireless network setup with Wi-Fi protection, click "Add A Wireless Device Wizard" to add a new device to your wireless network.
<br><br>
If you are new to wireless networking and have never configured a wireless access point before, click "Wireless Network Setup Wizard" and the access point will guide you through a few simple steps to get your wireless network up and running.
<br><br>
If you consider yourself an advanced user and have configured a wireless access point before, click "Manual Wireless Network Setup" to input all the settings manually.
<br><br>
<p class="helpful_hints"><b><a href="spt_bsc.php#wizard" class="special">More...</a></b></p>