<strong>Helpful Hints...</strong><br>
<br>
Firmware updates are released periodically to improve the functionality of your access point and to add features. If you run into a problem with a specific feature of the access point, check our support site by clicking the "Click here to check for an upgrade on our support site" link and see if updated firmware is available for your access point.

<br><br>
<p class="helpful_hints"><b><a href="spt_tools.php#firmware" class="special">More...</a></b></p>