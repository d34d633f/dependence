<strong>Helpful Hints...</strong><br>
<br>
For security reasons, it is recommended that you change the password for the Admin. Be sure to write down the new passwords to avoid having to reset the access point in case they are forgotten.
<br><br>
<p class="helpful_hints"><b><a href="spt_tools.php#admin" class="special">More...</a></b></p>