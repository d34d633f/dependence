<strong>Helpful Hints...</strong><br>
<br>
Enable this option if you want to allow QOS to prioritize wireless traffic.
<br><br>
There are two options for QOS Type selected,such as priority by Lan port and by protocol,which ensure the right priorities available for your special applications.
<br><br>
<p class="helpful_hints"><b><a href="spt_adv.php#qos" class="special">More...</a></b></p>
