<strong>Helpful Hints...</strong><br>
<br>
All of your LAN and WLAN connection details are displayed here.
<br><br>
<p class="helpful_hints"><b><a href="spt_st.php#device" class="special">More...</a></b></p>