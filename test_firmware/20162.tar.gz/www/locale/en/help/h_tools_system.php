<strong>Helpful Hints...</strong><br>
<br>
Once your access point is configured the way you want it, you can save the configuration settings to a configuration file.
<br><br>
You might need this file so that you can load your configuration later in the event that the access point's default settings are restored.
<br><br>
To save the configuration, click the "Save Configuration" button.
<br><br>
<p class="helpful_hints"><b><a href="spt_tools.php#system" class="special">More...</a></b></p>