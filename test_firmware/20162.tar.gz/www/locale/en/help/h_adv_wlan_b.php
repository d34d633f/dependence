<strong>Helpful Hints...</strong><br>
<br>
It is recommended that you leave these parameters at their default values. Adjusting them could limit the performance of your wireless network.
<br><br>
<p class="helpful_hints"><b><a href="spt_adv.php#performance" class="special">More...</a></b></p>