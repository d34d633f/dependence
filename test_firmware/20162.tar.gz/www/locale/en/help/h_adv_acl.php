<strong>Helpful Hints...</strong><br>
<br>
Create a list of MAC addresses that you would either like to allow or deny access to your network.
<br><br>
Select filter OFF, ALLOW or DENY, enter a MAC address, and then click the "Add" button to add a new MAC filtering rule.
<br><br>
Click the delete icon to remove the MAC address from the MAC filtering rules.
<br><br>
<p class="helpful_hints"><b><a href="spt_adv.php#filter" class="special">More...</a></b></p>