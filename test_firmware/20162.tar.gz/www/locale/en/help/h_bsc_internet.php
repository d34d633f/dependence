<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; If you are new to networking and have never configured a router before, click on <strong>Setup Wizard</strong> and the router will run you through a few simple steps to get your network up and running.<br>
<br>
&nbsp;&#149;&nbsp; If you consider yourself an Advanced user and have configured a router before, click<strong> Manual Configure</strong> to input all the settings manually.<br>

