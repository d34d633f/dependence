<strong>Helpful Hints...</strong><br>
<br>
The Internal Station Connection default value is "enable." This allows stations to inter-communicate by connecting to the target AP. Disabling this function prevents wireless stations from exchanging data through an AP.
<br><br>
The Ethernet to WLAN Access default value is "enable." This allows data flow from the Ethernet to wireless stations connected to the AP. Disabling this function blocks broadcast data from the Ethernet to associated wireless devices while still allowing wireless stations to send data to the Ethernet through the AP.
<br><br>
<p class="helpful_hints"><b><a href="spt_adv.php#wlan_partition" class="special">More...</a></b></p>