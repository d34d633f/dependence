<strong>Helpful Hints...</strong><br>
<br>
Good timekeeping is important for accurate logs.
<br><br>
<p class="helpful_hints"><b><a href="spt_tools.php#time" class="special">More...</a></b></p>