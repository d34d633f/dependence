<strong>Helpful Hints..</strong><br>
<br>
&nbsp;&#149;&nbsp; If you already have a DHCP server on your network or are using static IP addresses on all the devices on your network, uncheck <strong>Enable DHCP Server </strong> to disable this feature.<br>
