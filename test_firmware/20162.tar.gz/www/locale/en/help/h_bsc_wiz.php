<strong>Helpful Hints..</strong><BR>
<BR>
<STRONG>Wireless Settings</STRONG><BR>
The Wireless Settings section is used to configure the wireless AP (Access Point) portion of the router. Note that some changes made in this section may also need to be matched by the wireless client devices. <BR>
<BR>
<STRONG>Wireless Radio</STRONG><BR>
This option turns on or off the wireless connection feature of the router. When the radio is turned on, the following wireless parameters are displayed. <BR>
<BR>
<STRONG>SSID</STRONG><BR>
Service Set Identifier (SSID) is the name that identifies a specific wireless local area network (WLAN). When a wireless device is browsing for available wireless networks, this is the name that will appear in the list. <BR>
<BR>
<STRONG>Auto Channel Select</STRONG><BR>
If you select this option, the router automatically finds the channel with least interference and uses that channel for wireless networking. If you disable this option, the router uses the channel that you specify with the Channel option.
