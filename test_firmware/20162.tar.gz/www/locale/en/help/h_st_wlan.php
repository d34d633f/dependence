<strong>Helpful Hints...</strong><br>
<br>
This is a list of all wireless clients that are currently connected to your access point.
<br><br>
<p class="helpful_hints"><b><a href="spt_st.php#client" class="special">More...</a></b></p>