<strong>Helpful Hints...</strong><BR>
<BR>
If you are new to wireless networking and have never configured a wireless bridge before, click "Wireless Setup Wizard" and the bridge will guide you through a few simple steps to set up your wireless network.
<br><br>
<p class="helpful_hints"><b><a href="spt_bsc.php#wizard" class="special">More...</a></b></p>