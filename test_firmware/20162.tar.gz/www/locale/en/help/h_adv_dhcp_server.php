<strong>Helpful Hints...</strong><br>
<br>
If you already have a DHCP server on your network or are using static IP addresses on all the devices on your network, uncheck <strong>Enable DHCP Server </strong> to disable this feature.
<br><br>
<p class="helpful_hints"><b><a href="spt_adv.php#dhcp" class="special">More...</a></b></p>
