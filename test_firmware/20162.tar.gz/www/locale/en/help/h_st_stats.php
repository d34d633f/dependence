<strong>Helpful Hints...</strong><br>
<br>
This is a summary of the number of packets that have passed between the WAN and the LAN since the access point was last initialized.
<br><br>
<p class="helpful_hints"><b><a href="spt_st.php#stats" class="special">More...</a></b></p>