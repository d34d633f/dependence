<?
$m_title_log	= "Log Details";

$m_first_page	= "First Page";
$m_last_page	= "Last Page";
$m_previous	= "Previous";
$m_next		= "Next";
$m_clear	= "Clear";
$m_logsetting	="Log Settings";

$m_time		= "Time";
$m_type		= "Priority";//"Type";
$m_message	= "Message";
$m_page		= "Page";
$m_of		= "of";

$m_title_log_setting = "Log Options";
$m_view_levels ="What to View";
$m_critical ="Critical"; 
$m_warning ="Warning";
$m_informational ="Informational";
$remote_log = "Enable Remote Log";
$m_log_ip	=  "Log Server / IP Address ";
$m_b_log_apply = "Apply Log Settings Now";
$m_b_refresh	="Refresh";
$m_b_save	="Save Log";

$a_invalid_log_ip		= "Invalid Log Server / IP Address !";

$system_activity	=  "System Activity";
$wireless_activity	=  "Wireless Activity";
$notice	=  "Notice";
?>
