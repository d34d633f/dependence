<?
$rgdb_mode	= query("/wireless/ap_mode");
if($rgdb_mode=="1")
{
	$m_auto_msg	= "<b>Auto</b> (Select this option if you want to use Wi-Fi Protected Setup)";
	$m_manual_msg	= "<b>Manual</b> (Select this option if you want to setup your network manually)";
}
else
{
	$m_auto_msg	= "Auto -- Select this option if your wireless device supports WPS (Wi-Fi Protected Setup)";
	$m_manual_msg	= "Manual -- Select this option if you want to setup your network manually";
}
?>
