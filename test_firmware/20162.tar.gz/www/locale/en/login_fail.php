<?
$m_html_title	= "LOGIN FAIL";
$m_context_title= "Login fail";
$m_context	= "User Name or Password is incorrect.";
$m_button_dsc	= "Login Again";
?>
