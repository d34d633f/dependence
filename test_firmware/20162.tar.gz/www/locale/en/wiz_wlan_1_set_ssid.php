<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIZARD";
/* ---------------------------------------------------------------------- */
$a_empty_ssid	="The SSID field cannot be blank.";
$a_invalid_ssid	="There are some invalid characters in the SSID field. Please check it.";
$m_wlan_ssid	="Wireless Network Name<br>(SSID)";
?>
