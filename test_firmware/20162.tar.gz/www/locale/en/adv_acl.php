<?
/* --------------------------------------------------------- */
//$TITLE=$m_pre_title."SETUP";
/* --------------------------------------------------------- */
$m_title_access_setting = "MAC Filtering Setup ";
$m_title_access_add = "Add MAC Filtering Rule";
$m_desc_access_setting	= "Use the client's <b>MAC Address</b> to authorise network access through the Access Point.";
$m_acl_type 	= "Configure MAC Filtering below";
$m_disabled 	= "Turn MAC Filtering OFF";//"Disable";
$m_accept 		= "Turn MAC Filtering ON and ALLOW computers listed to access the network";//"Accept";
$m_reject 		= "Turn MAC Filtering ON and DENY computers listed to access the network";//"Reject";
$m_macaddr		= "MAC Address";
$m_title_access_mac_list = "MAC Filtering Rules";
$m_macaddr_del = "Delete";
$a_acl_del_confirm		= "Are you sure that you want to delete this mac address?";
$a_same_acl_mac	= "There is an existent entry with the same MAC Address.\\n Please change the MAC Address.";
$a_invalid_mac		= "Invalid MAC Address !";
$a_max_acl_mac		= "Maximum number of Access Control List is 256!";
$m_b_add		= "Add";
?>
