<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."";
/* ---------------------------------------------------------------------- */
$m_context_title	="Multi-SSID Settings";

$m_enable_mssid	="Enable Multi-SSID";
$m_enable_vlan	="Enable VLAN State";
$m_ms_band		="Band";
$m_ms_11b		="IEEE 802.11b";
$m_ms_11g		="IEEE 802.11g";
$m_ms_11n		="IEEE 802.11n";
$m_ms_index		="Index";
$m_ms_ps		="Primary SSID";
$m_ms_ms1		="Multi-SSID 1";
$m_ms_ms2		="Multi-SSID 2";
$m_ms_ms3		="Multi-SSID 3";
$m_ms_ms4		="Multi-SSID 4";
$m_ms_ms5		="Multi-SSID 5";
$m_ms_ms6		="Multi-SSID 6";
$m_ms_ms7		="Multi-SSID 7";
$m_ms_ssid		="SSID";
$m_ms_security	="Security ";
/*
$m_ms_disable_security	= "Disable Wireless Security (not recommended)";
$m_ms_enable_wep		= "Enable WEP Wireless Security (basic)";
$m_ms_wpa_security		= "Enable WPA Wireless Security (enhanced)";
$m_ms_wpa2_security	= "Enable WPA2 Wireless Security (enhanced)";
$m_ms_wpa2_auto_security	= "Enable WPA2-Auto Wireless Security (enhanced)";
*/
$m_ms_disable_security	= "None";
$m_ms_enable_wep_open		= "Open System";
$m_ms_enable_wep_shared		= "Shared Key";
$m_ms_wpa_psk_security		= "WPA-Personal";
$m_ms_wpa2_psk_security	= "WPA2-Personal";
$m_ms_wpa2_auto_psk_security	= "WPA2-Auto-Personal";
$m_ms_wpa_eap_security		= "WPA-Enterprise";
$m_ms_wpa2_eap_security	= "WPA2-Enterprise";
$m_ms_wpa2_auto_eap_security	= "WPA2-Auto-Enterprise";
$m_ms_vlanid		="VLAN ID";
$m_context_key_setting_title		="Key Settings";
$m_ms_key_type		="Key Type";
$m_ms_key_size		="WEP Encryption";
$m_ms_64bit_wep		="64Bit";
$m_ms_128bit_wep	="128Bit";
$m_ms_hex			= "HEX";
$m_ms_ascii			= "ASCII";
$m_ms_key			="Key";
$m_context_PassPhrase_setting_title		="PassPhrase Settings";
$m_ms_cipher_type		="Cipher Type";
$m_ms_auto			="Auto";
$m_ms_tkip			="TKIP";
$m_ms_aes			="AES";
$m_ms_passphrase		="Passphrase";
$m_title_MSSID		="Mulit-SSID";
$m_context_eap_setting_title		="Server Settings ";
$m_ms_ipaddr	="RADIUS IP Address";
$m_ms_port	="RADIUS Port";
$m_ms_shared_sec	="RADIUS Secret";
$m_ms_ssid_broadcast	="SSID Broadcast";
$m_ms_visible	="Visible";
$m_ms_invisible	="Invisible";
$m_ms_disable	="Disable";
$m_ms_enable	="Enable";
$m_ms_vlan_state_off	="OFF";
$m_ms_num		="Multi-SSID";
$m_ms_grp_key_interval		="Group Key Update Interval";
$m_ms_acc_state	="Accounting mode";
$m_ms_acc_ipaddr	="Accounting IP Address";
$m_ms_acc_port	="Accounting Port";
$m_ms_acc_sec	="Accounting Secret";

$a_mssid_del_confirm		= "Are you sure that you want to delete this ssid?";
$a_empty_ssid		= "The SSID field cannot be blank.";
$a_invalid_ssid		= "There are some invalid characters in the SSID field. Please check it.";
$a_first_blank_ssid		= "The first character can't be blank.";
$a_invalid_hex_64_key_length		= "Please input 10 Hexadecimal digits.";
$a_invalid_hex_64_key_value		= "Please input hexadecimal digits.";
$a_invalid_hex_128_key_length		= "Please input 26 Hexadecimal digits.";
$a_invalid_hex_128_key_value		= "Please input hexadecimal digits.";
$a_invalid_ascii_64_key_length		= "Please input 5 characters.";
$a_invalid_ascii_64_key_value		= "The key has invalid character.";
$a_invalid_ascii_128_key_length		= "Please input 13 characters.";
$a_invalid_ascii_128_key_value		= "The key has invalid character.";


$a_invalid_radius_ip1		= "The IP Address of RADIUS Server is invalid.";
$a_invalid_radius_port1		= "The Port of RADIUS Server is invalid.";
$a_empty_radius_sec1		= "The Shared Secret of RADIUS Server cannot be empty.";
$a_invalid_radius_sec1		= "The Shared Secret of RADIUS Server should be ASCII characters.";
$a_invalid_psk_len		= "The length of Passphrase should be 8~63.";
$a_psk_not_match		= "The Confirmed Passphrase does not match the Passphrase.";
$a_invalid_psk			= "The Passphrase should be ASCII characters.";
$a_invalid_acc_srv		= "The IP Address of Accounting Server is invalid.";
$a_invalid_acc_port		= "The Port of Accounting Server is invalid.";
$a_empty_acc_sec		= "The Shared Secret of Accounting Server cannot be empty.";
$a_invalid_acc_sec		= "The Shared Secret of Accounting Server should be ASCII characters.";
$a_invalid_key_interval	= "The range of Group Key Update Interval is 300 to 9999999.";
$a_invalid_psk_len		= "The length of Passphrase should be 8~63.";
$a_invalid_psk			= "The Passphrase should be ASCII characters.";

$a_empty_vlan_id		= "Please input VLAN ID!";
$a_invalid_vlan_id		= "The VLAN ID is invalid.";
$a_invalid_apmode		="If you enable Multi-SSID, AP Mode will be set to 'Access Point'!";

$m_title_wireless_setting	= "Wireless Network Settings";


?>
