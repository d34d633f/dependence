<?
$rgdb_mode	= query("/wireless/ap_mode");
// category
$m_menu_top_bsc		="Setup";
$m_menu_top_adv		="Advanced";
$m_menu_top_tools	="MAINTENANCE";
$m_menu_top_st		="Status";
$m_menu_top_spt		="Help";

// basic
if($rgdb_mode=="0")
{
	$m_menu_bsc_wizard      ="Wireless Settings";//"WIZARD";
}
else
{
	$m_menu_bsc_wizard      ="Wizard";	
}	
$m_menu_bsc_internet	="INTERNET";
if($rgdb_mode=="0")
{
	$m_menu_bsc_wlan	="WIRELESS SETUP";
}
else
{
	$m_menu_bsc_wlan	="Wireless";
}
$m_menu_bsc_lan		="Network Settings";//"LAN SETUP";

// advanced
$m_menu_adv_vrtsrv	="VIRTUAL SERVER";
$m_menu_adv_port	="PORT FORWARDING";
$m_menu_adv_app		="APPLICATION RULES";
$m_menu_adv_mac_filter	="NETWORK FILTER";
$m_menu_adv_acl		="MAC Address Filter";
$m_menu_adv_url_filter	="WEBSITE FILTER";
$m_menu_adv_dmz		="FIREWALL SETTINGS";
$m_menu_adv_wlan	="Advanced Wireless";
$m_menu_adv_network	="ADVANCED NETWORK";
$m_menu_adv_dhcp	="DHCP Server";
$m_menu_adv_mssid	="MULTI-SSID";
$m_menu_adv_group	="User Limit";
$m_menu_adv_wtp		="WLAN Switch";
$m_menu_adv_wlan_partition	="WLAN Partition";
$m_menu_adv_qos		="QoS";
$m_menu_adv_trafficmgr		="Traffic Manager";
$m_menu_adv_schedule		="Schedule";

// tools
$m_menu_tools_admin	="Admin";
$m_menu_tools_time	="Time";
$m_menu_tools_system	="System";
$m_menu_tools_firmware	="Firmware";
$m_menu_tools_misc	="MISC";
$m_menu_tools_ddns	="DDNS";
$m_menu_tools_vct	="SYSTEM CHECK";
$m_menu_tools_sch	="SCHEDULES";
$m_menu_tools_log_setting	="LOG SETTINGS";

// status
$m_menu_st_device	="Device Info";
$m_menu_st_log		="Logs";
$m_menu_st_stats	="Statistics";
$m_menu_st_wlan		="Wireless";

// support
$m_menu_spt_menu	="MENU";
$m_menu_spt_setup	="SETUP";
$m_menu_spt_advanced	="ADVANCED";
$m_menu_spt_maintenance	="MAINTENANCE";
$m_menu_spt_status	="STATUS";

$m_logout	="Logout";
?>
