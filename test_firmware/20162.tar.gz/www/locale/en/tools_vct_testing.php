<?
$m_title_banner = "D-LINK SYSTEM, INC | WIRELESS ROUTER | HOME";
$m_diagnosing	= "Diagnosing ...";
?>
