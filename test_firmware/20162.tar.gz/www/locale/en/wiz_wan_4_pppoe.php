<?
$m_address_mode	= "Address Mode";
$m_dynamic_ip	= "Dynamic IP";
$m_static_ip	= "Static IP";
$m_verify_pwd	= "Verify Password";
$m_service_name	= "Service Name";
$m_optional	= "(Optional)";
$m_service_name_note	= "Note: You may also need to provide a Service Name. If you do not have or know this information, please contact your ISP.";

$a_invalid_username     = "Invalid user name !";
$a_password_mismatch    = "The confirm password does not match the new password !";
$a_invalid_ip           = "Invalid IP address !";
?>
