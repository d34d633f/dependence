<?
$m_verify_password	= "Verify Password";
$a_password_mismatch	= "The confirm password does not match the new password !";
?>
