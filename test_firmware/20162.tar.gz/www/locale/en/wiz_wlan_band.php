<?

/* DAP-1522 */
$m_band	="802.11 Band";
$m_2.4G	="2.4GHz";
$m_5G	="5GHz";

?>
