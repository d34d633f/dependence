<?
$m_wlan_ssid	="Wireless Network Name <br> (SSID)";
$m_wep_length	="Wep Key Length";
$m_def_wep_index="Default WEP Key to Use";
$m_auth		="Authentication";
$m_wep_key	="Wep Key";
$m_encry	="Encryption";
$m_psk		="Pre-Shared Key";
$m_128bits	="128 bits";

$m_open		="Open";
$m_wpa_psk	="WPA-PSK/TKIP (also known as WPA Personal)";
$m_wpa2_psk	="WPA2-PSK/TKIP (also known as WPA2 Personal)";
?>
