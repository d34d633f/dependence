<?
$m_ssid	= "Wireless Network Name (SSID) ";
$a_empty_ssid	="The SSID field cannot be blank.";
$a_invalid_ssid	="There are some invalid characters in the SSID field. Please check it.";
$a_first_blank_ssid		= "The first character can't be blank.";
$m_b_scan	= "Site Survey";
$m_band	="802.11 Band";
$m_2.4G	="2.4GHz";
$m_5G	="5GHz";
$m_wlan_channel ="Channel";
$m_wlan_auto_channel ="Auto Channel Scan";
$m_connect	="Connect";
$a_no_select_entry = "Please select a SSID.";
?>
