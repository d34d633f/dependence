<?
$m_title_logs	= "Log Settings ";
$m_smtp_title_logs	= "SMTP Settings ";

$m_log_ip	=  "Log Server / IP Address ";
$m_log_type	=  "Log Type ";
$system_activity	=  "System Activity";
$wireless_activity	=  "Wireless Activity";
$notice	=  "Notice";
$remote_log = "Enable Remote Log";
$smtp_enable = "Enable SMTP";
$m_smtp_ip = "Mail Server / IP Address";
$m_smtp_email = "Email";

$a_invalid_log_ip		= "Invalid Log Server / IP Address !";
$a_invalid_smtp_ip		= "Invalid Mail Server / IP Address !";
?>
