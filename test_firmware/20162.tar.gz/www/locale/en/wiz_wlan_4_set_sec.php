<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIZARD";
/* ---------------------------------------------------------------------- */
anchor($G_WIZ_PREFIX_WLAN."/wireless/");
$auth		=query("authentication");
$m_wlan_password = "Network Key :";
$m_note_set_sec = "- Between 8 and 63 ASCII characters or 64 hex characters(A longer WPA key is more secure than a short one)<br><br><br>";
$a_invliad_secret	="Please enter another WPA Personal Passphrase.";
/*
if($auth=="3")
{
$a_invliad_secret	="Please enter another WPA Personal Passphrase.";

$m_wlan_password	="WPA Personal Passphrase:";
$m_wlan_password_dsc	="(8 to 63 characters)";
$m_note_set_sec =
	"<p>Note: You will need to enter your WPA Personal Passphrase into ".
	"your wireless client to establish proper wireless communication.";
}
else if($auth=="5")
{
$a_invliad_secret	="Please enter another WPA2 Personal Passphrase.";

$m_wlan_password	="WPA2 Personal Passphrase:";
$m_wlan_password_dsc	="(8 to 63 characters)";
$m_note_set_sec =
	"<p>Note: You will need to enter your WPA2 Personal Passphrase into ".
	"your wireless client to establish proper wireless communication.";
}
*/
?>
