<?
$m_title_dhcp	= "DHCP Connection (Dynamic IP Address)";
$m_desc_dhcp	= "Choose this if your Internet connection automatically provides you with an IP Address. Most Cable Modems use this type of connection.";
$m_title_pppoe	= "Username / Password Connection (PPPoE)";
$m_desc_pppoe	= "Choose this option if your Internet connection requires a username and password to get online. Most DSL modems use this connection type of connection.";
$m_title_pptp	= "Username / Password Connection (PPTP)";
$m_desc_pptp	= "Choose this option if your Internet connection requires a username and password to get online. Most DSL modems use this connection type of connection.";
$m_title_l2tp	= "Username / Password Connection (L2TP)";
$m_desc_l2tp	= "Choose this option if your Internet connection requires a username and password to get online. Most DSL modems use this connection type of connection.";
$m_title_bigpond= "Username / Password Connection (Bigpond)";
$m_desc_bigpond	= "Choose this option if your Internet connection requires a username and password to get online. Most DSL modems use this connection type of connection.";
$m_title_static	= "Static IP Address Connection";
$m_desc_static	= "Choose this option if your Internet Setup Provider provided you with IP Address information that has to be manually configured.";
?>
