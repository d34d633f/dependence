<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIRELESS";
/* ---------------------------------------------------------------------- */
$m_context_console_title	="Console Settings";
$m_console_protocol	="Console Protocol";
$m_none			="None";
$m_telnet		="Telnet";
$m_ssh			="SSH";
$m_timeout		="Timeout";
$m_min		="Min";
$m_mins		="Mins";
$m_never	="Never";
$m_context_snmp_title	="SNMP Settings";
$m_snmp_status	="Status";
$m_snmp_enable	="Enabled";
$m_snmp_public	="Public Community String";
$m_snmp_private	="Private Community String";
$m_trap_server_ip	="Trap Server IP";
$m_status_notification	="User status notification (for LBS)";

$a_empty_snmp_public ="Please input private Community string.";
$a_empty_snmp_private="Please input public Community string.";
$a_invalid_trap_server_ip ="Invalid IP Address!";
/*$		="";*/
?>
