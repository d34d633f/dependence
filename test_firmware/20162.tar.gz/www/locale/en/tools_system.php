<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."SYSTEM";
/* ---------------------------------------------------------------------- */
$a_empty_cfg_file_path	="Please select a saved configuration file to upload.";
$a_error_cfg_file_path	="File format error! Please try again!";
$a_sure_to_reload_cfg	="Load Settings From File ?";
$a_sure_to_factory_reset="Restore To Factory Default Settings ?";
$a_sure_to_reboot	="Reboot Access Point ?";
$a_sure_to_reset_js	="Reset JumpStart ?";
$a_sure_to_clear_langpack       = "Clear the language pack ?";

$m_context_title	="System Settings";
$m_save_cfg		="Save To Local Hard Drive : ";
$m_load_cfg		="Load From Local Hard Drive : ";
$m_b_load		="Restore Configuration from File";
$m_factory_reset	="Restore To Factory Default : ";
$m_b_restore		="Restore Factory Defaults";
$m_restore_msg		="Restore all settings to the factory defaults.";
$m_reboot		="Reboot The Device : ";
$m_b_reboot		="Reboot the Device";
$m_clear_langpack	= "Clear Language Pack : ";
$m_jumpstart_title	="Jumpstart";
$m_enable_js_fn		="Enable JumpStart function";
$m_reset_js		="Reset JumpStart";
$m_apply		="Apply";
$m_jumpstart		="Jumpstart";
$m_b_save	="Save Configuration";
?>
