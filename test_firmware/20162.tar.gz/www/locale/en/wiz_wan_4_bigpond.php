<?
$m_auth_server	= "Auth Server";
$m_bp_server	= "Bigpond Server IP Address<br>(may be same as gateway)";
$m_bp_user_name	= "Bigpond User Name";
$m_bp_password	= "Bigpond Password";
$m_bp_verify_pwd= "Bigpond Verify Password";

$a_invalid_username     = "Invalid user name !";
$a_password_mismatch    = "The confirm password does not match the new password !";
?>
