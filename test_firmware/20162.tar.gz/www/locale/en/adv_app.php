<?
$m_title_app_rules	= "Application Rules";

$m_app_name	= "Application Name";
$m_trigger	= "Trigger";
$m_firewall	= "Firewall";
$m_any		= "Any";

$a_no_app_name		= "Please select an Application Name first !";
$a_invalid_trigger_port	= "Invalid Trigger port setting !";
$a_invalid_firewall_port= "Invalid Firewall port setting !";
$a_blocking_warning	= "The setting will block you from accessing the router!\nAre you sure to continue ?";
?>
