<?
$m_wlan_ssid	="Wireless Network Name (SSID)";
$m_wlan_channel ="Channel";
$m_wlan_auto_channel ="Auto Channel Scan";
$m_wep_key_type	="Wep Key Type";
$m_HEX		="HEX";
$m_ASCII	="ASCII";
$m_wep_length	="Wep Key Length";
$m_def_wep_index="Default WEP Key to Use";
$m_auth		="Authentication";
$m_wep_key	="Network Key";
$m_encry	="Wireless Security Mode";
$m_psk		="Network Key";
$m_128bits	="128 bits";

$m_open		="WEP";
$m_wpa_psk	="WPA-PSK";//"WPA-Personal/AUTO (also known as WPA Personal)";
$m_wpa2_psk	="WPA2-Personal/AUTO (also known as WPA2 Personal)";
$m_wlan_band = "802.11 Band";
?>
