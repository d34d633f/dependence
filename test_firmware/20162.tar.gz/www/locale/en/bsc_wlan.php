<?
/* ---------------------------------- */
//$TITLE=$m_pre_title."SETUP";
/* ---------------------------------- */
$a_empty_ssid		= "The SSID field cannot be blank.";
$a_invalid_ssid		= "There are some invalid characters in the SSID field. Please check it.";
$a_first_blank_ssid		= "The first character can't be blank.";


$a_invalid_len_h_128_wep1	= "The length of Key1 must be 26 hexadecimal number.";
$a_invalid_len_h_128_wep2	= "The length of Key2 must be 26 hexadecimal number.";
$a_invalid_len_h_128_wep3	= "The length of Key3 must be 26 hexadecimal number.";
$a_invalid_len_h_128_wep4	= "The length of Key4 must be 26 hexadecimal number.";

$a_invalid_len_h_64_wep1	= "The length of Key1 must be 10 hexadecimal number.";
$a_invalid_len_h_64_wep2	= "The length of Key2 must be 10 hexadecimal number.";
$a_invalid_len_h_64_wep3	= "The length of Key3 must be 10 hexadecimal number.";
$a_invalid_len_h_64_wep4	= "The length of Key4 must be 10 hexadecimal number.";

$a_invalid_len_a_128_wep1	= "The length of Key1 must be 13 characters.";
$a_invalid_len_a_128_wep2	= "The length of Key2 must be 13 characters.";
$a_invalid_len_a_128_wep3	= "The length of Key3 must be 13 characters.";
$a_invalid_len_a_128_wep4	= "The length of Key4 must be 13 characters.";

$a_invalid_len_a_64_wep1	= "The length of Key1 must be 5 characters.";
$a_invalid_len_a_64_wep2	= "The length of Key2 must be 5 characters.";
$a_invalid_len_a_64_wep3	= "The length of Key3 must be 5 characters.";
$a_invalid_len_a_64_wep4	= "The length of Key4 must be 5 characters.";

$a_empty_defkey			= "The default WEP Key cannot be empty.";
$a_invalid_wep1			= "WEP Key 1 is invalid.";
$a_invalid_wep2			= "WEP Key 2 is invalid.";
$a_invalid_wep3			= "WEP Key 3 is invalid.";
$a_invalid_wep4			= "WEP Key 4 is invalid.";
$a_valid_hex_char		= "The legal characters are 0~9, A~F or a~f.";
$a_valid_asc_char		= "The legal characters are ASCII.";

$a_invalid_radius_ip1		= "The IP Address of RADIUS Server is invalid.";
$a_invalid_radius_ip2		= "The IP Address of RADIUS Server 2 is invalid.";
$a_invalid_radius_port1		= "The Port of RADIUS Server is invalid.";
$a_invalid_radius_port2		= "The Port of RADIUS Server 2 is invalid.";
$a_empty_radius_sec1		= "The Shared Secret of RADIUS Server cannot be empty.";
$a_empty_radius_sec2		= "The Shared Secret of RADIUS Server 2 cannot be empty.";
$a_invalid_radius_sec1		= "The Shared Secret of RADIUS Server should be ASCII characters.";
$a_invalid_radius_sec2		= "The Shared Secret of RADIUS Server 2 should be ASCII characters.";
$a_invalid_psk_len		= "The length of Passphrase should be 8~63.";
$a_psk_not_match		= "The Confirmed Passphrase does not match the Passphrase.";
$a_invalid_psk			= "The Passphrase should be ASCII characters.";
$a_invalid_psk_hex      = "The Passphrase should be 64 hex characters.";
$a_invalid_acc_srv		= "The IP Address of Accounting Server is invalid.";
$a_invalid_acc_port		= "The Port of Accounting Server is invalid.";
$a_empty_acc_sec		= "The Shared Secret of Accounting Server cannot be empty.";
$a_invalid_acc_sec		= "The Shared Secret of Accounting Server should be ASCII characters.";
$a_invalid_key_interval	= "The range of Group Key Update Interval is 300 to 9999999.";
$a_invalid_mssid_status	=	"If AP Mode is not 'Access Point' or 'WDS with AP' , Multi-SSID will be disabled!";
$a_blank_wds_first_mac	=	"Please input MAC Address in the first blank space.";
$a_invalid_wds_mac		= "Invalid MAC Address. \\nFormat xx:xx:xx:xx:xx:xx(x:0-9;A-f).";
$a_same_wds_mac		= "There is an existent entry with the same MAC Address.\\n Please change the MAC Address.";

$m_title_wireless_setting	= "Wireless Network Settings";

$m_enable_wireless	= "Enable Wireless";
$m_wlan_name		= "Wireless Network Name";
$m_wlan_name_comment	= "(Also called the SSID)";
$m_wlan_mode	= "Wireless Mode";
$m_ap_access	= "Access Point";
$m_ap_repeater	= "AP Repeater";
$m_ap_client	= "Wireless Client";
$m_ap_wds	= "WDS";
$m_ap_wds_with_ap	= "WDS with AP";
$m_wlan_channel		= "Wireless Channel";
$m_enable_auto_channel	= "Enable Auto Channel Scan";
$m_super_g		= "Super G Mode";
$m_super_g_without_turbo= "Super G without Turbo";
$m_super_g_with_d_turbo = "Super G with Dynamic Turbo";
$m_xr			= "Enable Extended Range Mode";
$m_g_n_only		= "802.11g/n Only Mode";
$m_80211_mode		= "802.11 Mode";
$m_g_only		= "802.11g Only";
$m_mode_g_b		= "Mixed 802.11g and 802.11b";
$m_b_only		= "802.11b Only";
$m_n_only		= "802.11n Only";
$m_mode_g_n		= "Mixed 802.11n and 802.11g";
$m_mode_b_g_n		= "Mixed 802.11n, 802.11g and 802.11b";
$m_channel_width	= "Channel Width";
$m_cw_20	= "20 MHz";
$m_cw_auto	= "Auto 20/40 MHz";
$m_transmission_rate	= "Transmission Rate";
$m_tx_best	= "Best(automatic)";
$m_tx_54	= "54";
$m_tx_48	= "48";
$m_tx_36	= "36";
$m_tx_24	= "24";
$m_tx_18	= "18";
$m_tx_12	= "12";
$m_tx_9	= "9";
$m_tx_6	= "6";
$m_tx_11	= "11";
$m_tx_5.5	= "5.5";
$m_tx_2	= "2";
$m_tx_1	= "1";
$m_enable_ap_hidden	= "SSID Broadcast";
$m_ap_hidden_comment	= "(Also called the SSID Broadcast)";

$m_title_wireless_security	= "Wireless Security Mode";

$m_security_mode	= "Security Mode";
$m_disable_security	= "Disable Wireless Security (not recommended)";
$m_enable_wep		= "WEP";
$m_wpa_security		= "Enable WPA Wireless Security (enhanced)";
$m_wpa2_security	= "Enable WPA2 Wireless Security (enhanced)";
$m_wpa2_auto_security	= "Enable WPA2-Auto Wireless Security (enhanced)";

$m_title_wep		= "WEP";
$m_auth_type		= "Authentication";
$m_open			= "Open";
$m_shared_key		= "Shared Key";
$m_wep_key_len		= "WEP Key Length";
$m_64bit_wep		= "64Bit";
$m_128bit_wep		= "128Bit";
$m_hex			= "HEX";
$m_ascii		= "ASCII";
$m_key_type		= "Key Type";
$m_default_wep_key	= "Default WEP Key";
$m_wep_key		= "WEP Key";

$m_title_wpa		="WPA";
$m_dsc_wpa		="WPA requires stations to use high grade encryption and authentication.";
$m_title_wpa2		="WPA2";
$m_dsc_wpa2		="WPA2 requires stations to use high grade encryption and authentication.";
$m_title_wpa2_auto	="WPA2-Auto";
$m_dsc_wpa2_auto	="WPA2-Auto requires stations to use high grade encryption and authentication.";

$m_cipher_type		="Cipher Type";
$m_tkip			="TKIP";
$m_aes			="AES";
$m_psk_eap		="Personal / Enterprise";
$m_psk			="Personal";
$m_eap			="Enterprise";
$m_passphrase		="Passphrase";
$m_confirm_passphrase	="Comfirmed Passphrase";

$m_8021x		="802.1X";
$m_radius1		="RADIUS Server";
$m_radius2		="RADIUS Server 2";
$m_shared_sec		="Shared Secret";

$m_title_wireless_site_survey	= "Site Survey";

$m_b_scan	= "Site Survey";
$m_title_wireless_wds	= "WDS";
$m_remote_ap	= "Remote AP MAC Address";
$m_grp_key_interval	= "Group Key Update Interval";
$m_acc_srv	= "Accounting Server ";
$m_acc_port	= "Accounting Port";
$m_acc_sec	= "Accounting Secret";
$m_disable	="Disable";
$m_enable	="Enable";
$m_acc_state ="Mode";


/* DAP-1522 */
$m_band	="802.11 Band";
$m_2.4G	="2.4GHz";
$m_5G	="5GHz";
$m_a_only		= "802.11a Only";
$m_mode_n_a		= "Mixed 802.11n and 802.11a";
$m_tx_mbit	= "(Mbit/s)";
$m_tx_mcs15 = "MCS 15 - 130[270]";
$m_tx_mcs14 = "MCS 14 - 117[243]";
$m_tx_mcs13 = "MCS 13 - 104[216]";
$m_tx_mcs12 = "MCS 12 - 78[162]";
$m_tx_mcs11 = "MCS 11 - 52[108]";
$m_tx_mcs10 = "MCS 10 - 39[81]";
$m_tx_mcs9 = "MCS 9 - 26[54]";
$m_tx_mcs8 = "MCS 8 - 13[27]";
$m_tx_mcs7 = "MCS 7 - 65[135]";
$m_tx_mcs6 = "MCS 6 - 58.5[121.5]";
$m_tx_mcs5 = "MCS 5 - 52[108]";
$m_tx_mcs4 = "MCS 4 - 39[81]";
$m_tx_mcs3 = "MCS 3 - 26[54]";
$m_tx_mcs2 = "MCS 2 - 19.5[40.5]";
$m_tx_mcs1 = "MCS 1 - 13[27]";
$m_tx_mcs0 = "MCS 0 - 6.5[13.5]";
$m_visibility_status = "Visibility Status";
$m_visible	= "Visible";
$m_invisible	= "Invisible";
$m_ap_auto	= "Auto";
$m_wpa_psk	= "WPA-Personal";
$m_wpa_eap 	= "WPA-Enterprise";
$m_64bit_hex_wep	= "64Bit (10 hex digits)";
$m_128bit_hex_wep	= "128Bit (28 hex digits)";
$m_wep_length_msg	= "(length applies to all keys) ";
$m_wpa_mode = "WPA Mode";
$m_wpa_auto = "Auto (WPA or WPA2)";
$m_wpa_only = "WPA Only";
$m_wpa2_only = "WPA2 Only";
$m_cipher_auto = "TKIP and AES";
$m_wpa_grp_key_msg = "(seconds)";
$m_title_pre_shared_key = "Pre-Shared Key";
$m_title_eap = "EAP (802.1x)";
$m_auth_timeout = "Authentication Timeout";
$m_auth_timeout_msg = "(minutes)";

$a_reset_wps_pin		= "Are you sure to Reset PIN to Default?";
$a_gen_new_wps_pin		= "Are you sure to Generate a New PIN?";
$a_reset_wps_unconfig	= "Are you sure to Reset the device to Unconfigured?";
$a_enable_wps_first		= "The WPS is not enabled yet.  Please press the \\\"Save Settings\\\" to enable WPS first.";
$a_invalid_mac = "Invalid mac address!";

$m_hex_h =	"64Bit (10 hex digits)";
$m_ascii_h =	"128Bit (26 hex digits)";
$m_hex_a =	"64Bit (5 ascii characters)";
$m_ascii_a =	"128Bit (13 ascii characters)";
$m_wep_key_value ="WEP Key value";
$m_verify_wep_key_value ="Verify WEP Key value";

$a_wep_key_not_matched	="The New WEP Key value and Confirm WEP Key value are not matched.";
$a_invalid_wep_key_length			= "WEP Key length is invalid.";

$m_title_StationMac = "Wireless MAC CLONING";
$m_StationMac = "Enable";


$m_StationMacManual = "MAC Address";
$m_title_mat_survey = "Mat mac address table";
$m_bmat_scan	= " Scan ";
$m_macsource_auto = "Auto";
$m_macsource_manual = "Manual";
$m_mac_source = "MAC Source";
?>
