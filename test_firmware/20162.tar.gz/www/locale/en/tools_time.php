<?
$m_title_time	= "Time Configuration";
$m_time				= "Time";
$m_time_zone			= "Time Zone";
$m_enable_daylight_saving	= "Enable Daylight Saving";

$m_title_ntp	= "Automatic Time Configuration";
$m_enable_ntp		= "Enable NTP server";
$m_interval		= "Interval";
$m_ntp_server		= "NTP Server";
$m_select_ntp_server	= "Select NTP Server";

$m_title_manual	= "Set the Date and Time Manually";
$m_current_time	= "Date And Time";
$m_year		= "Year";
$m_month	= "Month";
$m_day		= "Day";
$m_days		= "Days";
$m_hour		= "Hour";
$m_minute	= "Minute";
$m_second	= "Second";
$m_copy_pc_time	= "Copy Your Computer's Time Settings";

$a_invalid_ntp_server	= "Invalid NTP server !";
$a_invalid_daylight_saving_dates	= "Invalid Daylight Saving Setting !";

$m_daylight_saving_offset	="Daylight Saving Offset";
$m_daylight_saving_date	="Daylight Saving Dates";
$m_week ="Week";
$m_day_of_week = "Day of Week";
$m_dst_start = "DST Start";
$m_dst_end = "DST End";
?>
