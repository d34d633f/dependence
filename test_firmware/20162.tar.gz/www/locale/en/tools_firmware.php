<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."FIRMWARE UPGRADE";
/* ---------------------------------------------------------------------- */
$a_blank_fw_file="Please select a firmware file.";
$a_blank_lp_file	= "Please select a language file.";
$m_fw_title="Firmware Upgrade";
$m_update_fw="Update Firmware step";
$m_cur_fw_ver="Current Firmware Version : ";
$m_cur_fw_date="Current Firmware Date : ";

$m_fw_info_title="Firmware Information";
$m_fw_note ="<font color=\"\#cc0033\"><b>Note: Some firmware upgrades reset the configuration options to ".
			"the factory defaults. Before performing an upgrade, be sure to ".
			"save the current configuration from the <a href=\"tools_admin.php\">Maintenance -> Admin</a> screen.</b></font>";
$m_fw_msg ="<font color=\"\#003399\"><b>To upgrade the firmware, your PC must have a wired connection to the access point.".
			" Enter the name of the firmware upgrade file, and click on the Upload button.</b></font> ";
$m_fw_upload ="Upload : ";
$m_b_fw_upload = "Upload";

$m_upgrade_lp_title  = "Language Package Information";

$m_lp_note ="<font color=\"\#cc0033\"><b>Note: Update language package will make changes language display on web page. ".
                        " Before performing an upgrade, be sure to do it!".
		        "</b></font>";
$m_lp_msg ="<font color=\"\#003399\"><b>To upgrade the language package, your PC must have a wired connection to the access point.".
		        " Enter the name of the language package upgrade file, and click on the Upload button.</b></font> "; 

?>
