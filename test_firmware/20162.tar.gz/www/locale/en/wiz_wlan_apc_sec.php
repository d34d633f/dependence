<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIZARD";
/* ---------------------------------------------------------------------- */
$a_empty_ssid			= "Please input hte Wireless Network Name";
$a_invalid_ssid			= "The Wireless Network Name is with invalid characters.  Please check.";

$m_best				="WPA2";
$m_best_dsc			="Select this option if your wireless adapters SUPPORT WPA2";

$m_better			="WPA";
$m_better_dsc			="Select this option if your wireless adapters SUPPORT WPA";

$m_good				="WEP";
$m_good_dsc			="Select this option if your wireless adapters DO NOT SUPPORT WPA";

$m_none				="None";
$m_none_dsc			="Select this option if you do not want to activate any security features";

$m_note_sel_sec	=
	"<p>For information on which security features your wireless adapters support, ".
	"please refer to the adapters' documentation.</p>".
	"<p>Note: All D-Link wireless adapters currently support WPA.</p>";
?>
