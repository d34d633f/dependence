<?
$m_title_app_rules      = "PORT FORWARDING RULES";

$m_app_name     = "Application Name";
$m_name		= "Name";
$m_any          = "Any";
$m_ip		= "IP Address";
$m_pc_name	= "Computer Name";
$m_start	= "Start";
$m_end		= "End";
$m_schedule     = "Schedule";
$m_always       = "Always";

$a_no_app_name	= "Please select an Application Name first !";
$a_no_host_name	= "Please select a Computer Name first !";
$a_invalid_ip	= "Invalid IP address !";
$a_invalid_port	= "Invalid port value !";
$a_end_big_start= "The end port shoule be equal or greater than the start port !";
$a_cant_blank	= "The field can not be blank !";
?>
