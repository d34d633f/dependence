<p>
WEP is the wireless encryption standard. To use it you must enter the same key(s) 
into the access point and the wireless stations. For 64 bit keys you must enter 
10 hex digits into each key box. For 128 bit keys you must enter 26 hex digits 
into each key box. A hex digit is either a number from 0 to 9 or a letter from 
A to F. For the most secure use of WEP set the authentication type to 
"Shared Key" when WEP is enabled.</p>
<p>
You may also enter any text string into a WEP key box, in which case it will be 
converted into a hexadecimal key using the ASCII values of the characters. 
A maximum of 5 text characters can be entered for 64 bit keys, and a maximum 
of 13 characters for 128 bit keys.<br>
</p>

<p>
If you choose the WEP security option this device will <b>ONLY</b> operate 
in <b>Legacy Wireless mode (802.11B/G)</b>. This means you will <b>NOT</b> get 11N 
performance due to the fact that WEP is not supported by Draft 11N 
specification.
<br></p>