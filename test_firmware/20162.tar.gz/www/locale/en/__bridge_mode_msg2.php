<p>The device is changing to AP mode.</p>
<p>The device will dynamically get the IP address from DHCP server.</p>
<p>Please check the DHCP server for the IP address of the device.</p>
<p>Or use UPnP tools to discover the device.</p>
