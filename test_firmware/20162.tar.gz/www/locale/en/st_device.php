<?
$m_system_uptime="System UpTime";
$m_days		= "days";
$m_expired	= "Expired";

$m_lan	= "LAN";
$m_netmask	= "Subnet Mask";
$m_dhcp_server	= "DHCP Server";

$m_wired= "Wired";
$m_wan	= "WAN";
$m_connection	= "Connection Type";
$m_default_gw	= "Default Gateway";
$m_dns		= "DNS";
$m_static_ip	= "Static IP";
$m_dhcp_client	= "DHCP client";
$m_connected	= "Connected";
$m_disconnected	= "Disconnected";
$m_dhcp_renew	= "DHCP Renew";
$m_dhcp_release	= "DHCP Release";
$m_pppoe	= "PPPoE";
$m_pptp		= "PPTP";
$m_l2tp		= "L2TP";
$m_bigpond	= "BigPond";
$m_connect	= "Connect";
$m_disconnect	= "Disconnect";
$m_na		= "N/A";
$m_null_ip	= "0.0.0.0";


$m_wireless_radio	= "Wireless Radio";
$m_wlan	        = "Wireless Lan";
$m_ssid		= "Network Name(SSID)";
$m_channel	= "Channel";
$m_privacy	= "Security Type";
$m_wireless_jumpstart = "Wireless JumpStart";
$m_jumpstart	= "JumpStart";
$m_protocol	= "Protocol";
$m_status	= "Status";
$m_bits		= "bits";
$m_tkip		= "TKIP";
$m_aes		= "AES";
$m_cipher_auto	= "Auto";
$m_wpa		= "WPA-";
$m_wpa2		= "WPA2-";
$m_wpa_auto		= "WPA-Auto-";
$m_eap		= "Enterprise/";
$m_psk		= "Personal /";
$m_open		="Open /";
$m_shared	="Shared Key /";
$on	= "Enabled";
$off	="Disabled";
$m_time_fw ="General";
$m_time ="Time";
$m_wi_fi ="Wi-Fi Protected Setup";
$m_configured	= "Configured";
$m_unconfigured	= "Not Configured";
$m_disconnected = "disconnected";
?>

