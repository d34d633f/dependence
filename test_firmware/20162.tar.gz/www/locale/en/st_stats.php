<?
$m_context_title_stats_lan	="LAN Statistics";
$m_receive		="Receive";
$m_transmit		="Transmit";
$m_wan			="WAN";
$m_lan			="LAN";
$m_wired		="LAN STATISTICS";
$m_wlan_11g		="WIRELESS LAN STATISTICS";
$m_packets		="Packets";
$m_b_refresh		="Refresh Statistics";
$m_b_reset		="Clear Statistics";
$a_only_admin_account_can_clear_the_statistics="Only admin account can clear the statistics!";

$m_context_title_stats_wireless ="Wireless Statistics";
$m_wlreless_sent	="Sent : ";
$m_wlreless_received	="Received : ";
$m_wlreless_tx	="TX Packets Dropped : ";
$m_wlreless_rx	="RX Packets Dropped : ";
$m_wlreless_error	="Errors : ";
$m_lan_sent	="Sent : ";
$m_lan_received	="Received : ";
$m_lan_tx	="TX Packets Dropped : ";
$m_lan_rx	="RX Packets Dropped : ";
$m_lan_collisions	="Collisions : ";
$m_lan_error	="Errors : ";

$m_wlreless_tx_b	="TX Packets Bytes : ";
$m_wlreless_rx_b	="RX Packets Bytes : ";
$m_wlreless_tx_p	="TX Packet Numbers : ";
$m_wlreless_rx_p	="RX Packet Numbers : ";
$m_lan_tx_b	="TX Packets Bytes : ";
$m_lan_rx_b	="RX Packets Bytes : ";
$m_lan_tx_p	="TX Packet Numbers : ";
$m_lan_rx_p	="RX Packet Numbers : ";
?>
