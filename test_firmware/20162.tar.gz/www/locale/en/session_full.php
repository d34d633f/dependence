<?
$m_html_title="SESSION FULL";
$m_context_title="Session full";
$m_context="The login session is full.  Please try later";
$m_button_dsc="Login Again";
?>
