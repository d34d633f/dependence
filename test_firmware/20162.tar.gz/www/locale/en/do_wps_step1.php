<?
$m_pin				= "PIN";
$m_connect			= "Connect";
$m_pbc				= "PBC";//"PUSH BUTTON";
$m_virtual_button	= "Virtual Push Button";

$m_wps_pin_desc	=	"Please enter the PIN from your wireless device and click the below \"Connect\" button";//"If the wireless device you are adding to your wireless network only comes with a PIN ".
					//"number, enter its PIN number below to add this device to your wireless network.";
$m_wps_pbc_desc =	"Please press the push button on your wireless device and press the \"Connect\" button<br>".
					"below within 120 seconds";//"If the wireless device you are adding to your wireless network has both options ".
					//"available, you may use the Virtual Push Button if you prefer.";
$m_wps_pbc_comment ="(The Virtual Push Button acts the same as the physical Push Button on the router)";

$a_invalid_pin	=	"Invalid PIN number.";
?>

