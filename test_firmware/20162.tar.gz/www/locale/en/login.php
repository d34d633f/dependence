<?
$rgdb_mode	= query("/wireless/ap_mode");

$a_invalid_user_name	="Please input the User Name.";

$m_html_title		="LOGIN";
$m_context_title	="Login";
$m_login_router		="Log in to the router:";
if($rgdb_mode=="0")
{
	$m_login_ap		="Login to the Access Point:";
}
else
{
	$m_login_ap		="Log in to the Bridge:";	
}
$m_log_in		=" Login ";
?>
