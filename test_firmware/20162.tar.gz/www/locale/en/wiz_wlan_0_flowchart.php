<?
$m_device_name	= "Device Name (NetBIOS Name) ";
$a_empty_device ="The Device Name field cannot be blank.";
$a_first_blank_device="There are some invalid characters in the Device Name field. Please check it.";
$a_invalid_device="The first character can't be blank.";
?>
