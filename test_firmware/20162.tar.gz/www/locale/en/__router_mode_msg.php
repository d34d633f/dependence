<p>The device is changing to router mode.</p>
<p>You may need to change the IP address of your computer to access the device.</p>
<p>You can access the device by the link below.</p>
