<?
$m_context_title	="Wireless Termination Point Settings";
$m_wtp_state	="WTP Enable";
$m_wtp_name	="WTP Name";
$m_wtp_location	="WTP Location Data";
$m_ipaddr		= "AC IP Address";
$m_title_wtp_ip_list = "AC IP Address List";
$m_ipaddr_del = "Del";

$a_empty_wtp_name	="The WTP Name cannot be blank.";
$a_first_blank_name		= "The first character can't be blank.";
$a_wtp_del_confirm		= "Are you sure that you want to delete this IP Address?";
$a_same_wtp_ip	= "There is an existent entry with the same IP Address.\\n Please change the IP Address.";
$a_invalid_ip		= "Invalid IP Address !";
$a_max_wtp_ip		= "Maximum number of IP Address List is 16!";
?>
