<?
$a_invalid_url       	="Invalid URL !";
$a_same_url_entry_exists="The URL/Domain entry is already exist !";
$m_title_url_filter	="Website Filtering Rules";
$m_desc_url_filter	="ConfigureWebsite Filtering below:";
$m_disable_url_filter	="Turn Website Filtering OFF";
$m_allow_entries_only	="Turn Website Filtering ON and ALLOW computers access to ONLY these sites";
$m_deny_entries_only	="Turn Website Filtering ON and DENY computers access to ONLY these sites";
$m_clear_list_below	="Clear the list below...";
$m_website_url_domain	="Website URL/Domain";
?>
