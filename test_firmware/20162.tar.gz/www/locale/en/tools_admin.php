<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."ADMIN";
/* ---------------------------------------------------------------------- */
$a_empty_login_name	="Please input the Login Name.";
$a_invalid_login_name	="The Login Name is with invalid character. Please check it.";
$a_invalid_new_password	="The New Password is with invalid character. Please check it.";
$a_password_not_matched	="The New Password and Confirm Password are not matched.";
$a_invalid_ipaddr	="Invalid IP Address.";

$m_context_title_admin	="Administrator (The default login name is \"admin\")";
$m_context_title_admin1	="ADMIN PASSWORD";
$m_context_title_user	="Admin Password";
$m_context_title_user1	="USER PASSWORD";
$m_login_name		="Login Name";
$m_new_password		="Password ";
$m_confirm_password	="Verify Password ";

$m_context_title_remote	="Remote Management";
$m_eable_remote		="Enable Remote Managment";
$m_defined_sch		="Defined Schedule";

$m_password_msg ="Please enter the same password into both boxes, for confirmation.";
?>
