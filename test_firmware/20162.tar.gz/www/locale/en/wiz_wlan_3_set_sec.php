<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIZARD";
/* ---------------------------------------------------------------------- */
$a_invliad_secret	="Please enter another Wireless Security Password.";

$m_wlan_password	="Wireless Security Password:";
$m_wlan_password_dsc	="(2 to 20 characters)";
$m_note_set_sec =
	"<p>Note: You will need to enter the unique security key generated into ".
	"your wireless clients enable proper wireless communication - ".
	"not the password you provided to create the security key.</p>";
?>
