<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIZARD";
/* ---------------------------------------------------------------------- */
$a_invliad_secret	="Please enter another Wireless Security Password.";
$a_no_secret	="No Key values !";
$a_10_hex_secret	="Please input 10 Hexadecimal digits!";
$a_26_hex_secret	="Please input 26 Hexadecimal digits!";
$a_hex_secret	="Please input hexadecimal digits!";
$a_5_ascii_secret	="Please input 5 characters!";
$a_13_ascii_secret	="Please input 13 characters!";
$a_ascii_invalid_character	="The String has invalid character.Please input again!";
$a_invalid_secret	="Invalid Network Key. Please input again!";

$m_key_type     ="Key Type:";
$m_hex			="HEX";
$m_ascii		="ASCII";

$m_wlan_size	="Key Size:";
$sec_size_64_dsc	="64-Bit";
$sec_size_128_dsc	="128-Bit";
$m_wlan_password	="Network Key :";//"Wireless Security Password:";
$m_wlan_password_dsc	="(2 to 20 characters)";
$m_note_set_sec =
	"- Exactly 5 or 13 characters <br>".
	"- Exactly 10 or 26 characters using 0-9 and A-F <br><br>".
	"A longer WEP key is more secure than a short one<br><br><br>";
?>
