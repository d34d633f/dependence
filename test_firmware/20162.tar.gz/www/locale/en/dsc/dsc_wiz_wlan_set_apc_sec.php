<?

anchor($G_WIZ_PREFIX_WLAN."/wireless/");
$auth		=query("authentication");

if($auth=="3")
{
	echo "<h1>Set Your WPA Personal Passphrase</h1>\n";
	echo "<center><p><b>Please enter the WPA personal passphrase to establish wireless connection.</b></p></center>\n";
}

else if($auth=="5")
{
	echo "<h1>Set Your WPA2 Personal Passphrase</h1>\n";
	echo "<center><p><b>Please enter the WPA2 personal passphrase to establish wireless connection.</b></p></center>\n";

}

?>