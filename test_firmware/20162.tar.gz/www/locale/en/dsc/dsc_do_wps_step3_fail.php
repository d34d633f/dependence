<h1>Add A Wireless Device with WPS</h1>
<br><br>
<center><p>
You have failed to add the wireless device to your wireless network within the given timeframe,
<br>please click on the button below to do it again.
</p></center>
<br><br>

