<? if(query("/wireless/ap_mode") =="1")	{echo "<!--";} ?>
<h1>Add A Wireless Device with WPS (Wi-Fi Protected Setup)</h1>
<? if(query("/wireless/ap_mode") =="1")	{echo "-->";} ?>

<? if(query("/wireless/ap_mode") =="0")	{echo "<!--";} ?>
<h1>Connect To Wireless Device With WPS</h1>
<? if(query("/wireless/ap_mode") =="0")	{echo "-->";} ?>
<p>There are two ways to add wireless device to your wireless network:
<br><br>
- PIN (Personal Identification Number)
<br><br>
- PBC (Push Button Configuration)</p>

