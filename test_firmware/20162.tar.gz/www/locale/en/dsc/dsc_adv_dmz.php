<h1>FIREWALL SETTINGS</h1>
The Web Filter options allows you to set-up a list of allowed Web sites that can be used by multiple users.When Web Filter is enabled,all other Web sites not listed on this page will be blocked.
<p>
