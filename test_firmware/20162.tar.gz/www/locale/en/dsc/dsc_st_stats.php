<h1>Traffic Statistics</h1>
Traffic Statistics display receive and transmit packets passing through your access point.
<br><br>

