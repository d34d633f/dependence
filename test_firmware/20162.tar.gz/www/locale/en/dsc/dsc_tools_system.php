<h1>System Settings</h1>
<!--	The current system settings can be saved as a file onto the local hard drive. The saved file or any other saved setting file created by device can be uploaded into the unit.<br>-->
The System Settings section allows you to reboot the device, or restore the 
access point to the factory default settings. Restoring the unit to the factory
 default settings will erase all settings, including any rules that you have 
 created.<br><br>

The current system settings can be saved as a file onto the local hard drive. 
The saved file or any other saved setting file created by device can be 
uploaded into the unit.<br>

