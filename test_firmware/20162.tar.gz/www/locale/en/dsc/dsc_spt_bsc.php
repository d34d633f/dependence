<head>
<link rel="stylesheet" href="/model/router.css" type="text/css">
</head>
<?
$empty_row="<tr><td height=20>&nbsp;</td></tr>";
?>
<?if($cfg_ap_mode=="1"){echo "<!--\n";}?>
<h1>Wireless<a name=wizard></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>The wireless section is used to configure the wireless settings for your access point. Note that changes made in this section may also need to be duplicated on wireless clients that you want to connect to your wireless network.</p>
 		</td>
	</tr>
 	<tr>
 		<td>
 			<br><p>To protect your privacy, use the wireless security mode to configure the wireless security features. This device supports three wireless security modes including: WEP, WPA-Personal, and WPA-Enterprise. WEP is the original wireless encryption standard. WPA provides a higher level of security. WPA-Personal does not require an authentication server. The WPA-Enterprise option does require a RADIUS authentication server. </p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=59>
	 		<p><b>Enable Wireless</b>
	 			<br>
	 			This option turns the wireless connection feature of the access point on and off. When you set this option, the following parameters are in effect.
			</p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=59>
	 		<p><b>Wireless Network Name </b>
	 			<br>
	 			When you are browsing for available wireless networks, this is the name that will appear in the list (unless Visibility Status is set to Invisible, see below). This name is also referred to as the SSID. For security purposes, it is highly recommended to change from the pre-configured network name.
			</p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=59>
	 		<p><b>Enable Auto Channel Scan </b>
	 		<br>
	 			If you select this option, the access point automatically finds the channel with least interference and uses that channel for wireless networking. If you disable this option, the access point uses the channel that you specify with the following <b>Wireless Channel</b> option.
			</p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=59>
	 		<p><b>Wireless Channel</b><br>
	 		A wireless network uses specific channels in the wireless spectrum to handle communication between clients. Some channels in your area may have interference from other electronic devices. Choose the clearest channel to help optimize the performance and coverage of your wireless network.
			</p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=59>
	 		<p><b>802.11 Band </b>
			Operating frequency band. Choose 2.4GHz for visibility to legacy devices and for longer range. Choose 5GHz for least interference; interference can hurt performance.
			</p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=59>
	 		<p><b>802.11 Mode</b>
	 			<br>
	 		If all of the wireless devices you want to connect with this access point can connect in the same transmission mode, you can improve performance slightly by choosing the appropriate "Only" mode. If you have some devices that use a different transmission mode, choose the appropriate "Mixed" mode.
			</p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=59>
	 		<p><b>Channel Width</b>
	 			<br>
	 		The "Auto 20/40 MHz" option is usually best. The other options are available for special circumstances.
			</p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=59>
	 		<p><b>Transmission Rate </b>
	 			<br>
	 			By default the fastest possible transmission rate will be selected. You have the option of selecting the speed if necessary.
			</p>
 		</td>
 	</tr>
  	<tr>
	 	<td height=59>
	 		<p><b>Visibility Status </b>
	 		<br>
	 		The Invisible option allows you to hide your wireless network. When this option is set to Visible, your wireless network name is broadcast to anyone within the range of your signal. If you're not using encryption, they can connect to your network. When Invisible mode is enabled, you must enter the Wireless Network Name (SSID) on the client manually to connect to the network.
			</p>
 		</td>
 	</tr>
  	<tr>
	 	<td height=59>
	 		<p><b>Security Mode</b>
	 		<br>
	 		Unless one of these encryption modes is selected, wireless transmissions to and from your wireless network can be easily intercepted and interpreted by unauthorized users.
			</p>
 		</td>
 	</tr>
  	<tr>
	 	<td height=59>
	 		<p><b>WEP</b>
	 		<br>
	 		A method of encrypting data for wireless communication intended to provide the same level of privacy as a wired network. WEP is not as secure as WPA encryption. To gain access to a WEP network, you must know the key. The key is a string of characters that you create. When using WEP, you must determine the level of encryption. The type of encryption determines the key length. 128-bit encryption requires a longer key than 64-bit encryption. Keys are defined by entering in a string in HEX (hexadecimal - using characters 0-9, A-F) or ASCII (American Standard Code for Information Interchange - alphanumeric characters) format. ASCII format is provided so you can enter a string that is easier to remember. The ASCII string is converted to HEX for use over the network. Four keys can be defined so that you can change keys easily. A default key is selected for use on the network.
			</p>
 		</td>
 	</tr>
	</table>
 	<div class="box">
 	<table border=0 cellspacing=0 cellpadding=0 width=700>
  	<tr>
	 	<td height=59>
	 		<p><b>Example: </b>
	 		<br>
	 		64-bit hexadecimal keys are exactly 10 characters in length. (12345678FA is a valid string of 10 characters for 64-bit encryption.) 128-bit hexadecimal keys are exactly 26 characters in length. (456FBCDF123400122225271730 is a valid string of 26 characters for 128-bit encryption.) 64-bit ASCII keys are up to 5 characters in length (DMODE is a valid string of 5 characters for 64-bit encryption.) 128-bit ASCII keys are up to 13 characters in length (2002HALOSWIN1 is a valid string of 13 characters for 128-bit encryption.)
			</p>
 		</td>
 	</tr>
 	</table>
	</div>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
  	<tr>
	 	<td>
	 		Note that, if you enter fewer characters in the WEP key than required, the remainder of the key is automatically padded with zeros.
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>WPA-Personal and WPA-Enterprise </b>
	 		<br>
	 		Both of these options select some variant of Wi-Fi Protected Access (WPA) -- security standards published by the Wi-Fi Alliance. The <b>WPA Mode</b> further refines the variant that the access point should employ.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>WPA Mode: </b>
	 		WPA is the older standard; select this option if the clients that will be used with the access point only support the older standard. WPA2 is the newer implementation of the stronger IEEE 802.11i security standard. With the "WPA2" option, the access point tries WPA2 first, but falls back to WPA if the client only supports WPA. With the "WPA2 Only" option, the access point associates only with clients that also support WPA2 security.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>Cipher Type:</b>
	 		The encryption algorithm used to secure the data communication. TKIP (Temporal Key Integrity Protocol) provides per-packet key generation and is based on WEP. AES (Advanced Encryption Standard) is a very secure block based encryption. With the "TKIP and AES" option, the access point negotiates the cipher type with the client, and uses AES when available.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=10>
	 		<p><b>Group Key Update Interval:</b>
	 		The amount of time before the group key used for broadcast and multicast data is changed.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>WPA-Personal </b>
	 		<br>
	 		This option uses Wi-Fi Protected Access with a Pre-Shared Key (PSK).
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>Pre-Shared Key: </b>
	 		The key is entered as a pass-phrase of up to 63 alphanumeric characters in ASCII (American Standard Code for Information Interchange) format at both ends of the wireless connection. It cannot be shorter than eight characters, although for proper security it needs to be of ample length and should not be a commonly known phrase. This phrase is used to generate session keys that are unique for each wireless client.
			</p>
 		</td>
 	</tr>
	</table>
 	<div class="box">
 	<table border=0 cellspacing=0 cellpadding=0 width=700>
  	<tr>
	 	<td height=30>
	 		<p><b>Example: </b>
	 		<br>
	 		Wireless Networking technology enables ubiquitous communication
	 		</p>
 		</td>
 	</tr>
 	</table>
	</div>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>WPA-Enterprise </b>
	 		<br>
	 		This option works with a RADIUS Server to authenticate wireless clients. Wireless clients should have established the necessary credentials before attempting to authenticate to the Server through this Gateway. Furthermore, it may be necessary to configure the RADIUS Server to allow this Gateway to authenticate users.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=25>
	 		<p><b>RADIUS Server IP Address: </b>
	 		The IP address of the authentication server.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=25>
	 		<p><b>RADIUS Server Port: </b>
	 		The port number used to connect to the authentication server.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=25>
	 		<p><b>RADIUS Server Shared Secret:</b>
	 		 A pass-phrase that must match with the authentication server.
			</p>
 		</td>
 	</tr>

	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=30>
	 		<b>Wi-Fi Protected Setup</b>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td width="10"></td>
	 	<td height=59>
	 		<b>Enable </b>
	 		<br>
	 		Enable the Wi-Fi Protected Setup feature.
			<br>
	 		<b>Lock Wireless Security Settings </b>
	 		<br>
	 		ELocking the wireless security settings prevents the settings from being changed by any new external registrar using its PIN. Devices can still be added to the wireless network using Wi-Fi Protected Setup. It is still possible to change wireless network settings with  <a href="bsc_wlan.php">Manual Wireless Network Setup</a>,<a href="wiz_wlan.php"> Wireless Network Setup Wizard</a>, or an existing external WLAN Manager Registrar.
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>PBC Settings </b>
	 		<br>
	 		Push Button Configuration is a button that can be pressed to add the device to an existing network or to create a new network. A virtual button can be used on the utility while a physical button is placed on the side of the device.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>PIN Settings </b>
	 		<br>
	 		A PIN is a unique number that can be used to add the access point to an existing network or to create a new network. The default PIN may be printed on the bottom of the access point. For extra security, a new PIN can be generated. You can restore the default PIN at any time. Only the Administrator ("admin" account) can change or reset the PIN.
			</p>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=60>
	 		<br>
	 		<p><b>Current PIN</b>
	 		<br>
	 		Shows the current value of the access point's PIN.
	 		</p>
	 		<p><b>Reset PIN to Default </b>
	 		<br>
	 		Restore the default PIN of the access point.
			</p>
	 		<p><b>Generate New PIN </b>
	 		<br>
	 		Create a random number that is a valid PIN. This becomes the access point's PIN. You can then copy this PIN to the user interface of the registrar.
 			</p>
 			<br>
 		</td>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=60>
	 		<b>Add Wireless Station </b>
	 		<br>
	 		This Wizard helps you add wireless devices to the wireless network.
			<br><br>
			The wizard will either display the wireless network settings to guide you through manual configuration, prompt you to enter the PIN for the device, or ask you to press the configuration button on the device. If the device supports Wi-Fi Protected Setup and has a configuration button, you can add it to the network by pressing the configuration button on the device and then the on the access point within 60 seconds. The status LED on the access point will flash three times if the device has been successfully added to the network.
			<br><br>
			There are several ways to add a wireless device to your network. Access to the wireless network is controlled by a "registrar". A registrar only allows devices onto the wireless network if you have entered the PIN, or pressed a special Wi-Fi Protected Setup button on the device. The access point acts as a registrar for the network, although other devices may act as a registrar as well.
			<br>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td width="10"></td>
	 	<td height=20>
	 		<b>Add A Wireless Device Wizard  </b>
	 		<br>
	 		Start the wizard.
			<br><br><br>
 		</td>
 	</tr>
 	</table>

	<h1>Network Settings<a name=lan></a></h1>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
	 	<td height=59><a name=lan></a>
	 		<p><b>Access Point Settings </b>
	 		<br>
	 		These are the settings of the LAN (Local Area Network) interface for the access point. The access point's local network (LAN) settings are configured based on the IP Address and Subnet Mask assigned in this section. The IP address is also used to access this Web-based management interface. It is recommended that you use the default settings if you do not have an existing network.
			</p>
 		</td>
 	</tr>
	<tr>
		<td height=59>
			<p><b>LAN Connection Type </b>
			<br>
			Select DHCP to get the IP settings from a DHCP server on your network. Select Static to use the IP settings specified on this page.
			</p>
		</td>
	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=60>
	 		<br>
	 		<p><b>IP Address</b>
	 		<br>
	 		The IP address of your access point on the local area network. Your local area network settings are based on the address assigned here. For example, 192.168.0.1.
	 		</p>
	 		<p><b>Subnet Mask </b>
	 		<br>
	 		The subnet mask of your access point on the local area network.
			</p>
	 		<p><b>Gateway </b>
	 		<br>
	 		Specify the gateway IP address of the local network.
 			</p>
 			<br>
 		</td>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>Device Name (NetBIOS Name) </b>
	 		<br>
	 		Device Name(NetBIOS NAME) allows you to configure this deice more easily when your network using TCP/IP protocol. You can enter the device name of the AP, instead of IP address, into your web browser to access for configuration. Recommend to change the device name if there&rsquo;s more than one D-Link devices within the subnet.
			</p>
 		</td>
 	</tr>

</table>
<?if($cfg_ap_mode=="1"){echo "-->\n";}?>

<?if($cfg_ap_mode=="0"){echo "<!--\n";}?>
<h1>Wizard<a name=wizard></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>If you want to connect a new wireless network, click on &quot;Setup Wizard&quot; and the bridge will guide you through a few steps to get your network up and running. </p>
 		</td>
	</tr>
</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>PBC Settings </b>
	 		<br>
	 		Push Button Configuration is a button that can be pressed to add the device to an existing network . A virtual button can be used on the utility while a physical button is placed on the side of the device.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>PIN Settings </b>
	 		<br>
	 		A PIN is a unique number that can be used to add the device to an existing network. The default PIN may be printed on the bottom of the router. For extra security, a new PIN can be generated. You can restore the default PIN at any time. Only the Administrator ("admin" account) can change or reset the PIN.
			</p>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=60>
	 		<br>
	 		<p><b>Current PIN</b>
	 		<br>
	 		Shows the current value of the bridge's PIN.
	 		</p>
	 		<p><b>Reset PIN to Default </b>
	 		<br>
	 		Restore the default PIN of the bridge.
			</p>
	 		<p><b>Generate New PIN </b>
	 		<br>
	 		Create a random number that is a valid PIN. This becomes the bridge's PIN. You can then copy this PIN to the user interface of the registrar.
 			</p>
 			<br>
 		</td>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>Set Up Wireless </b>
	 		<br>
	 		This Wizard helps you add a wireless devices to the wireless network.
			<br>
			The wizard will either display the wireless network settings to guide you through manual configuration, prompt you to enter the PIN for the device, or ask you to press the configuration button on the device. If the device supports Wi-Fi Protected Setup and has a configuration button, you can add it to the network by pressing the configuration button on the device and then pressing the button on the router within 120 seconds.
			<br>
			Each device has an LED, and the LED will start flashing if the button is pressed. The LED on the router will turn solid ON if the device has been successfully added to the network. If something goes wrong during configuration, the flashing pattern of the LED changes.
			</p>
 		</td>
 	</tr>

 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=20>
	 		<br>
	 		<p><b>Set Up Wireless Wizard </b>
	 		<br>
	 		Start the wizard.
	 		</p>
 			<br>
 		</td>
 	</table>
	<h1>Network Settings<a name=lan></a></h1>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
	 	<td height=59><a name=lan></a>
	 		<p><b>LAN Settings</b>
	 		<br>
	 		These are the settings of the LAN (Local Area Network) interface for the bridge. The IP address is also used to access this Web-based management interface. It is recommended that you use the default settings if you do not have an existing network.
			</p>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=60>
	 		<br>
	 		<p><b>IP Address Mode </b>
	 		<br>
	 		Select <b>DHCP</b> to get the IP settings from a DHCP server on your network. Select <b>Static</b> to use the IP settings specified on this page.
	 		</p>
	 		<p><b>IP Address </b>
	 		<br>
	 		The IP address of your bridge on the local area network. For example, 192.168.1.24 The address you choose must be consistent with the LAN settings of your router.
			</p>
	 		<p><b>Subnet Mask </b>
	 		<br>
	 		The subnet mask of the local area network
 			</p>
	 		<p><b>Default Gateway </b>
	 		<br>
	 		This is the IP address of the gateway or router that connects you to the internet.
 			</p>
 			<br>
 		</td>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>Device Name (NetBIOS Name) </b>
	 		<br>
	 		Device Name(NetBIOS NAME) allows you to configure this deice more easily when your network using TCP/IP protocol. You can enter the device name of the AP, instead of IP address, into your web browser to access for configuration. Recommend to change the device name if there&rsquo;s more than one D-Link devices within the subnet.
			</p>
 		</td>
 	</tr>
</table>
<h1>Wireless<a name=wireless></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>The wireless section is used to configure the wireless settings for your bridge. Note that some options in this section must agree with options selected for your wireless access point or wireless router.
 			</p><p>
 			To protect your privacy, use the wireless security mode to configure the wireless security features. This device supports three wireless security modes including: WEP, WPA-Personal, and WPA-Enterprise. WEP is the original wireless encryption standard. WPA provides a higher level of security. WPA-Personal does not require an authentication server. The WPA-Enterprise option does require a RADIUS authentication server.
 			</p>
 		</td>
	</tr>
  	<tr>
	 	<td height=59>
	 		<p><b>Enable Wireless</b>
	 			<br>
	 			This option turns off and on the wireless connection feature of the bridge. When you set this option, the following parameters are in effect.
			</p>
 		</td>
 	</tr>
  	<tr>
	 	<td height=59>
	 		<p><b>Wireless Network Name </b>
	 			<br>
	 			This is the name of the wireless access point that this station will associate to. Leave this field blank to associate to any access point.
			</p>
 		</td>
 	</tr>
  	<tr>
	 	<td height=59>
	 		<p><b>Enable Auto Channel Scan </b>
	 		<br>
	 			If you select this option, the bridge automatically finds the channel with least interference and uses that channel for wireless networking. If you disable this option, the bridge uses the channel that you specify with the following <b>Wireless Channel</b> option.
			</p>
 		</td>
 	</tr>
  	<tr>
	 	<td height=59>
	 		<p><b>Wireless Channel</b>
	 		<br>
	 			A wireless network uses specific channels in the wireless spectrum to handle communication between clients. Some channels in your area may have interference from other electronic devices. Your wireless bridge will use the channel that is used by the access point it associates with. But here you can select your channel preference to help optimize the performance and coverage of your wireless network.
	 		</p>
 		</td>
 	</tr>
  	<tr>
	 	<td height=59>
	 		<p><b>802.11 Band </b>
			Operating frequency band. Choose 2.4GHz for visibility to legacy devices and for longer range. Choose 5GHz for least interference; interference can hurt performance.
			</p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=59>
	 		<p><b>802.11 Mode</b>
	 			<br>
	 		If all of the wireless devices in your wireless network can connect in the same transmission mode, you can improve performance slightly by choosing the appropriate "Only" mode. If you have some devices that use a different transmission mode, choose the appropriate "Mixed" mode.
			</p>
 		</td>
 	</tr>
   	<tr>
	 	<td height=59>
	 		<p><b>Channel Width</b>
	 			<br>
	 		The "Auto 20/40 MHz" option is usually best. The other options are available for special circumstances.
			</p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=59>
	 		<p><b>Transmission Rate </b>
	 			<br>
	 			By default the fastest possible transmission rate will be selected. You have the option of selecting the speed if necessary.
			</p>
 		</td>
 	</tr>
   	<tr>
	 	<td height=59>
	 		<p><b>Number of Spatial Streams </b>
	 			<br>
	 		Selecting more than one spatial stream can increase throughput, but can in some cases decrease signal quality. Select the option that works best for your installation.
			</p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=59>
	 		<p><b>Security Mode </b>
	 			<br>
	 			Unless one of these encryption modes is selected, wireless transmissions to and from your wireless network can be easily intercepted and interpreted by unauthorized users.
			</p>
 		</td>
 	</tr>
   	<tr>
	 	<td height=59>
	 		<p><b>WEP</b>
	 		<br>
	 		A method of encrypting data for wireless communication intended to provide the same level of privacy as a wired network. WEP is not as secure as WPA encryption. To gain access to a WEP network, you must know the key. The key is a string of characters that you create. When using WEP, you must determine the level of encryption. The type of encryption determines the key length. 128-bit encryption requires a longer key than 64-bit encryption. Keys are defined by entering in a string in HEX (hexadecimal - using characters 0-9, A-F) or ASCII (American Standard Code for Information Interchange - alphanumeric characters) format. ASCII format is provided so you can enter a string that is easier to remember. The ASCII string is converted to HEX for use over the network. Four keys can be defined so that you can change keys easily. A default key is selected for use on the network.
			</p>
 		</td>
 	</tr>
	</table>
 	<div class="box">
 	<table border=0 cellspacing=0 cellpadding=0 width=700>
  	<tr>
	 	<td height=59>
	 		<p><b>Example: </b>
	 		<br>
	 		64-bit hexadecimal keys are exactly 10 characters in length. (12345678FA is a valid string of 10 characters for 64-bit encryption.)
			128-bit hexadecimal keys are exactly 26 characters in length. (456FBCDF123400122225271730 is a valid string of 26 characters for 128-bit encryption.)
			64-bit ASCII keys are up to 5 characters in length (DMODE is a valid string of 5 characters for 64-bit encryption.)
			128-bit ASCII keys are up to 13 characters in length (2002HALOSWIN1 is a valid string of 13 characters for 128-bit encryption.)
			</p>
 		</td>
 	</tr>
 	</table>
	</div>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
  	<tr>
	 	<td>
	 		Note that, if you enter fewer characters in the WEP key than required, the remainder of the key is automatically padded with zeros.
 		</td>
 	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>WPA-Personal</b>
	 		<br>
	 		This option uses Wi-Fi Protected Access with a Pre-Shared Key (PSK).
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>WPA Mode: </b>
	 		WPA is the older standard; select this option if the Access Point that will be used with the bridge only support the older standard. WPA2 is the newer implementation of the stronger IEEE 802.11i security standard. With the <b>WPA2</b> option, the bridge tries WPA2 first, but falls back to WPA if the client only supports WPA. With the <b>WPA2 Only</b> option, the bridge associates only with clients that also support WPA2 security.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>Cipher Type:</b>
	 		 The encryption algorithm used to secure the data communication. <b>TKIP</b> (Temporal Key Integrity Protocol) provides per-packet key generation and is based on WEP. <b>AES</b> (Advanced Encryption Standard) is a very secure block based encryption. With the <b>TKIP or AES</b> option, the bridge negotiates the cipher type with the access point, and uses AES when available.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=10>
	 		<p><b>Group Key Update Interval:</b>
	 		The amount of time before the group key used for broadcast and multicast data is changed.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>Pre-Shared Key: </b>
	 		The key is entered as a pass-phrase of up to 63 alphanumeric characters in ASCII (American Standard Code for Information Interchange) format at both ends of the wireless connection. It cannot be shorter than eight characters, although for proper security it needs to be of ample length and should not be a commonly known phrase. This phrase is used to generate session keys that are unique for each wireless client.
			</p>
 		</td>
 	</tr>
	</table>
 	<div class="box">
 	<table border=0 cellspacing=0 cellpadding=0 width=700>
  	<tr>
	 	<td height=30>
	 		<p><b>Example: </b>
	 		<br>
	 		Wireless Networking technology enables ubiquitous communication
	 		</p>
 		</td>
 	</tr>
 	</table>
	</div>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=40>
	 		<p><b>Site Survey </b><br>
	 		The site survey section allows you to view all the access points that can be heard by your wireless bridge.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=40>
	 		<p><b>SSID </b><br>
	 		The network name that is used by this access point.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=40>
	 		<p><b>BSSID </b><br>
	 		The Ethernet ID (MAC address) of the access point.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=40>
	 		<p><b>Channel </b><br>
	 		The wireless channel that this access point is operating on.
			</p>
 		</td>
 	</tr>
  	<tr>
	 	<td height=40>
	 		<p><b>Mode </b><br>
	 		The transmission standard being used by the access point. Values are 11a, 11b, or 11g for 802.11a, 802.11b, or 802.11g respectively.
			</p>
 		</td>
 	</tr>
  	<tr>
	 	<td height=40>
	 		<p><b>Privacy </b><br>
	 		The wireless security mode of the access point.
			</p>
 		</td>
 	</tr>
  	<tr>
	 	<td height=40>
	 		<p><b>Signal</b><br>
	 		This is a relative measure of signal quality. The value is expressed as a percentage of theoretical best quality. Signal quality can be reduced by distance, by interference from other radio-frequency sources (such as cordless telephones or neighboring wireless networks), and by obstacles between the bridge and the access point.
			</p>
 		</td>
 	</tr>
  	<tr>
	 	<td height=20>
	 		<b>Wi-Fi Protected Setup</b>
 		</td>
 	</tr>
<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
 		<td width="10"></td>
	 	<td height=20>
	 		<p><b>Enable </b>
	 		Enable the Wi-Fi Protected Setup feature.
	 		</p>
	 	</td>
	<tr>
</table> 
	<table border=0 cellspacing=0 cellpadding=0 width=750>
  	<tr>
	 	<td height=20>
	 		<b>Wireless Mac Cloning</b>
 		</td>
 	</tr>
	<tr>
	 	<td height=20>
	 		<p><b>Enable </b>
	 		If MAC clone function is enabled, before the device forwards a packet which is generated by an Ethernet port station, the source MAC address of the packet will be replaced by the clone MAC address; Otherwise, the packet source MAC address will not be changed.
	 		</p>
	 	</td>
	<tr>
	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
	 	<td height=20>
	 		<p><b>Mac Source </b>
	 		Auto or manually select the clone MAC address.
	 		</p>
	 	</td>
	<tr>
	</table>		
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
	 	<td height=20>
	 		<p><b>Mac Address </b>
	 		the mac address selected by mac clone function.
	 		</p>
	 	</td>
	<tr>
	</table>	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
	 	<td height=20>
	 		<p><b>Scan</b>
	 		The Scan button will help to discover the MAC address of all ethernet port stations.
	 		</p>
	 	</td>
	<tr>	
   </table>
   
  
	
</table>
<?if($cfg_ap_mode=="0"){echo "-->\n";}?>
