<h1>Device Information</h1>
<p>All of your network connection details are displayed on this page. 
The firmware version is also displayed here. <br></p>

