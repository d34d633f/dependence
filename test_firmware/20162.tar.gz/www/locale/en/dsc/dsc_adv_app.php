<h1>Application Rule</h1>
The Application Rules option is used to open single or multiple ports in your firewall
when the router senses data sent to the Internet on a outgoing "Trigger" port or port range.
Special Applications rules apply to all computers on your internal network.
<br><br>
