<h1>Network Setting</h1>
Use this section to configure the internal network settings of your router and also to configure
the built-in DHCP server tp assign IP address to the computers on your network.
The IP address that is configured here is the IP address that you use to access the Web-based
management interface. If you change the IP address here, you may need to adjust your PC's
network settings to access the network again.
<p>
