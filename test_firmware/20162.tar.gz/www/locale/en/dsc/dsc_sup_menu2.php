<?
$spt_bsc_url="spt_bsc.php";
$spt_adv_url="spt_adv.php";
$spt_tools_url="spt_tools.php";
$spt_st_url="spt_st.php";
$spt_faq_url="spt_faq.php";

$font_color="#000000";
?>
<h1>SUPPORT MENU</h1>
<table width=75% border=0 cellspacing=0 cellpadding=0>
<tr><td><span class="style6">Setup</span></td></tr>
<tr><td>
	<ul>
	<li><a href=<?=$spt_bsc_url?>#001 target=_blank><font color=<?=$font_color?>>Setup Wizard</font></a></li>
	<li><a href=<?=$spt_bsc_url?>#02_1 target=_blank><font color=<?=$font_color?>>Wireless Settings</font></a></li>
	<li><a href=<?=$spt_bsc_url?>#02 target=_blank><font color=<?=$font_color?>>WAN Settings</font></a></li>
	<li><a href=<?=$spt_bsc_url?>#03 target=_blank><font color=<?=$font_color?>>LAN Settings</font></a></li>
	<li><a href=<?=$spt_bsc_url?>#04 target=_blank><font color=<?=$font_color?>>DHCP Server</font></a></li>
	</ul>
</td></tr>
<tr><td><span class="style6">Advanced</span></td></tr>
<tr><td>
	<ul>
	<li><a href=<?=$spt_adv_url?>#05 target=_blank><font color=<?=$font_color?>>Virtual Server</font></a></li>
	<li><a href=<?=$spt_adv_url?>#06 target=_blank><font color=<?=$font_color?>>Special Applications</font></a></li>
	<li><a href=<?=$spt_adv_url?>#07 target=_blank><font color=<?=$font_color?>>Filters</font></a></li>
	<li><a href=<?=$spt_adv_url?>#08 target=_blank><font color=<?=$font_color?>>Firewall Rules</font></a></li>
	<li><a href=<?=$spt_adv_url?>#09 target=_blank><font color="<?=$font_color?>">DMZ</font></a></li>
	<li><a href=<?=$spt_adv_url?>#09_1 target=_blank><font color="<?=$font_color?>">Wireless Performance</font></a></li>
	</ul>
</td></tr>
<tr><td><span class="style6">Tools</span></td></tr>
<tr><td>
	<ul>
	<li><a href=<?=$spt_tools_url?>#11 target=_blank><font color=<?=$font_color?>>Administrator Settings</font></a></li>
	<li><a href=<?=$spt_tools_url?>#10 target=_blank><font color=<?=$font_color?>>System Time</font></a></li>
	<li><a href=<?=$spt_tools_url?>#12 target=_blank><font color=<?=$font_color?>>System Settings</font></a></li>
	<li><a href=<?=$spt_tools_url?>#13 target=_blank><font color=<?=$font_color?>>Firmware Upgrade</font></a></li>
	<li><a href=<?=$spt_tools_url?>#14 target=_blank><font color=<?=$font_color?>>Miscellaneous Items</font></a></li>
	<li><a href=<?=$spt_tools_url?>#15 target=_blank><font color=<?=$font_color?>>Cable Test</font></a></li>
	</ul>
</td></tr>
<tr><td><span class="style6">Status</span></td></tr>
<tr><td>
	<ul>
	<li><a href=<?=$spt_st_url?>#15 target=_blank><font color=<?=$font_color?>>Device Information</font></a></li>
	<li><a href=<?=$spt_st_url?>#16 target=_blank><font color=<?=$font_color?>>Log</font></a></li>
	<li><a href=<?=$spt_st_url?>#17 target=_blank><font color=<?=$font_color?>>Traffic Statistics</font></a></li>
	<li><a href=<?=$spt_st_url?>#17_1 target=_blank><font color=<?=$font_color?>>Connected Wireless Client List</font></a></li>
	</ul>
</td></tr>
<tr><td valign=top>
<span class="style6"><a href=<?=$spt_faq_url?> target=_blank><font color=<?=$font_color?>>FAQs</font></a></span>
</td></tr>
</table>
