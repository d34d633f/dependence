<h1>Step 1: Name your Wireless Network</h1>
<p>Your wireless network needs a name so it can be easily recognized by wireless clients. For security purposes, it is highly recommended to change the pre-configured network name of [dlink].</p>
