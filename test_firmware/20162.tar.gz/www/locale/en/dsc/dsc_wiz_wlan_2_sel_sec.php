<h1>Step 2: Secure your Wireless Network</h1>
<p>This wizard will guide you through a step-by-step process to configure your new D-Link router and connect to the Internet.</p>
<p>In order to protect your network from hackers and unauthorized users, it is highly recommended you choose one of the following wireless network security settings.<br>
<br>
There are three levels of wireless security -Good Security, Better Security, or Best Security. The level you choose depends on the security features your wireless adapters support.<br>
</p>
