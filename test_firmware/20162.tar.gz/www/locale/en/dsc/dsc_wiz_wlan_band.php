<h1>Set Wireless Band</h1>
<p><b>Please select one of the following bands.</b></p>
