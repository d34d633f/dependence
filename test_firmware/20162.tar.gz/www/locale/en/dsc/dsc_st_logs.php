<h1>View Log</h1>
Log Settings.<p>
