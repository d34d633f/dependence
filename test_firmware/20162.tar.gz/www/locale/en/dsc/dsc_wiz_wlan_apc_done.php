<h1>Save Settings Succeeded</h1>
<center>
<p>Saving Changes.</p>
<!--
	 and Restarting.</p>
<p>If you changed the IP address of the Access Point <br>
 you will need to change the IP address in your <br>
  browser before accessing the configuration Web site again.</p>
-->
</center>
