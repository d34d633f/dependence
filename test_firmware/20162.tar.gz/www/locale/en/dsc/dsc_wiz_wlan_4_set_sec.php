<h1>Welcome to the D-Link Wireless Setup Wizard</h1>
<p>The WPA (Wi-Fi Protected Access) key must meet one of the following guidelines</p>
<?
/*
anchor($G_WIZ_PREFIX_WLAN."/wireless/");
$auth		=query("authentication");

if($auth=="3")
{
	echo "<h1>Step 3: Set your WPA Personal Passphrase</h1>\n";
	echo "<p>Once you have selected your security level - you will need to set a WPA Personal Passphrase.</p>\n";
}

else if($auth=="5")
{
	echo "<h1>Step 3: Set your WPA2 Personal Passphrase</h1>\n";
	echo "<p>Once you have selected your security level - you will need to set a WPA2 Personal Passphrase.</p>\n";

}
*/
?>