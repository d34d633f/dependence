<h1>Traffic manager</h1>
Traffic Manager gives you control of your network traffic, increasing the efficiency of your<br>
network and reducing your overall bandwidth requirements . 
<p>
