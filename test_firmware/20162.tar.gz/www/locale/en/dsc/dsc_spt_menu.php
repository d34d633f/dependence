<?
$spt_bsc_url="spt_bsc.php";
$spt_adv_url="spt_adv.php";
$spt_tools_url="spt_tools.php";
$spt_st_url="spt_st.php";
$spt_faq_url="spt_faq.php";

$font_color="#000000";
?>
<h1>SUPPORT MENU</h1>
<table width=75% border=0 cellspacing=0 cellpadding=0>
<tr><td><span class="style6">Setup Help</span></td></tr>
<tr><td>
	<ul>
	<li><a href=<?=$spt_bsc_url?>#wizard target=_blank><font color=<?=$font_color?>><?=$m_menu_bsc_wizard?></font></a></li>
<?if($cfg_ap_mode=="0"){echo "<!--\n";}?>
	<li><a href=<?=$spt_bsc_url?>#wireless target=_blank><font color=<?=$font_color?>><?=$m_menu_bsc_wlan?></font></a></li>
<?if($cfg_ap_mode=="0"){echo "-->\n";}?>
	<li><a href=<?=$spt_bsc_url?>#lan target=_blank><font color=<?=$font_color?>><?=$m_menu_bsc_lan?></font></a></li>
	</ul>
</td></tr>
<tr><td><span class="style6">Advanced Help</span></td></tr>
<tr><td>
	<ul>
<?if($cfg_ap_mode=="1"){echo "<!--\n";}?>		
	<li><a href=<?=$spt_adv_url?>#filter target=_blank><font color="<?=$font_color?>"><?=$m_menu_adv_acl?></font></a></li>	
<?if($cfg_ap_mode=="1"){echo "-->\n";}?>
	<li><a href=<?=$spt_adv_url?>#performance target=_blank><font color="<?=$font_color?>"><?=$m_menu_adv_wlan?></font></a></li>
	<!--li><a href=<?=$spt_adv_url?>#04 target=_blank><font color=<?=$font_color?>>Port Forwarding</font></a></li-->
	<!--li><a href=<?=$spt_adv_url?>#05 target=_blank><font color=<?=$font_color?>>Application Rules</font></a></li-->
	<!--li><a href=<?=$spt_adv_url?>#06 target=_blank><font color=<?=$font_color?>>Network Filter</font></a></li-->
	<!--li><a href=<?=$spt_adv_url?>#07 target=_blank><font color=<?=$font_color?>>Website Filter</font></a></li-->
	<!--li><a href=<?=$spt_adv_url?>#08 target=_blank><font color="<?=$font_color?>">Firewall Settings</font></a></li-->
<?if($cfg_ap_mode=="1"){echo "<!--\n";}?>	
	<li><a href=<?=$spt_adv_url?>#wlan_partition target=_blank><font color="<?=$font_color?>"><?=$m_menu_adv_wlan_partition?></font></a></li>
	<li><a href=<?=$spt_adv_url?>#dhcp target=_blank><font color="<?=$font_color?>"><?=$m_menu_adv_dhcp?></font></a></li>
<?if($cfg_ap_mode=="1"){echo "-->\n";}?>
	<li><a href=<?=$spt_adv_url?>#qos target=_blank><font color="<?=$font_color?>"><?=$m_menu_adv_qos?></font></a></li>
<?if($cfg_ap_mode=="1"){echo "<!--\n";}?>	
	<li><a href=<?=$spt_adv_url?>#trafficmgr target=_blank><font color="<?=$font_color?>"><?=$m_menu_adv_trafficmgr?></font></a></li>
	<li><a href=<?=$spt_adv_url?>#schedule target=_blank><font color="<?=$font_color?>"><?=$m_menu_adv_schedule?></font></a></li>
<?if($cfg_ap_mode=="1"){echo "-->\n";}?>
<!--
	<?
	if(query("/web/display/dhcp")=="1")
	{
		echo "<li><a href=".$spt_adv_url."#10 target=_blank><font color=".$font_color.">DHCP Server</font></a></li>";
	}
	?>
	<?
	if(query("/web/display/mssid")=="1")
	{
		echo "<li><a href=".$spt_adv_url."#mssid target=_blank><font color=".$font_color.">Multi-SSID</font></a></li>";
	}
	
	if(query("/web/display/group")=="1")
	{
		echo "<li><a href=".$spt_adv_url."#group target=_blank><font color=".$font_color.">User Limit</font></a></li>";
	}	
	
		echo "<li><a href=".$spt_adv_url."#wtp target=_blank><font color=".$font_color.">WLAN Switch</font></a></li>";
	
	?>	
	-->
	</ul>
</td></tr>
<tr><td><span class="style6">Maintenance Help</span></td></tr>
<tr><td>
	<ul>
	<li><a href=<?=$spt_tools_url?>#admin target=_blank><font color=<?=$font_color?>><?=$m_menu_tools_admin?></font></a></li>
	<!--li><a href=<?=$spt_tools_url?>#12 target=_blank><font color=<?=$font_color?>>Time</font></a></li-->
<?if(query("/web/display/ntp")=="0"){echo "<!--\n";}?>
	<li><a href=<?=$spt_tools_url?>#time target=_blank><font color=<?=$font_color?>><?=$m_menu_tools_time?></font></a></li>
<?if(query("/web/display/ntp")=="0"){echo "-->\n";}?>
	<li><a href=<?=$spt_tools_url?>#system target=_blank><font color=<?=$font_color?>><?=$m_menu_tools_system?></font></a></li>
	<li><a href=<?=$spt_tools_url?>#firmware target=_blank><font color=<?=$font_color?>><?=$m_menu_tools_firmware?></font></a></li>
	
	</ul>
</td></tr>
<tr><td><span class="style6">Status Help</span></td></tr>
<tr><td>
	<ul>
	<li><a href=<?=$spt_st_url?>#device target=_blank><font color=<?=$font_color?>><?=$m_menu_st_device?></font></a></li>
<?if($cfg_ap_mode=="1"){echo "<!--\n";}?>
	<li><a href=<?=$spt_st_url?>#client target=_blank><font color=<?=$font_color?>><?=$m_menu_st_wlan?></font></a></li>
<?if($cfg_ap_mode=="1"){echo "-->\n";}?>
	<li><a href=<?=$spt_st_url?>#log target=_blank><font color=<?=$font_color?>><?=$m_menu_st_log?></font></a></li>
<?if($cfg_ap_mode=="1"){echo "<!--\n";}?>
	<li><a href=<?=$spt_st_url?>#stats target=_blank><font color=<?=$font_color?>><?=$m_menu_st_stats?></font></a></li>
<?if($cfg_ap_mode=="1"){echo "-->\n";}?>
	</ul>
</td></tr>
</table>
