<h1>Firmware</h1>
<!--There may be new firmware for your <?query("/sys/modelname");?> to improve functionality and performance.<br>
<a href=<?query("/sys/url");?> target=_blank>Click here to check for an upgrade on our support site.</a><br>
<br>
To upgrade the firmware, locate the upgrade file on the local hard drive with the Browse button. Once you have found the file to be used, click the Save Settings below to start the firmware upgrade.<br><br>
-->
Use the Firmware section to install the latest firmware code to improve functionality and performance. <br><br>