<h1>Port Forwarding Rules </h1>
The Port Forwarding option is used to open a single port or a range of ports through your firewall and redirect data through those ports to a single PC on your network.
<p>
