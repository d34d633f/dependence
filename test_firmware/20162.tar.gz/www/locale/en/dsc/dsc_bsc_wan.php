<h1>Internet Connection</h1>
Use this section to configure your Internet Connection type.
There are several connection types to choose from: Static IP, DHCP, PPPoE, PPTP, L2TP, and BigPond.
If you are unsure of your connection method, please contact your Internet Service Provider.
<br><br>
<strong>Note: </strong> If using the PPPoE option,
you will need to remove or disable any PPPoE client software on your computers.
<p>
