<h1>Set Username and Password Connection (BigPond)</h1>
<p>To set up this connection you will need to have a Username and Password from
your Internet Service Provider. You also need BigPond IP adress.
If you do not have this information, please contact your ISP.</p>
