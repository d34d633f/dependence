<h1>MAC Address Filter</h1>
<!--The <?query("/sys/modelname");?> can be setup to deny or only allow access to wireless clients with the listed MAC addresses. -->
The MAC (Media Access Controller) Address filter option is used to control 
network access based on the MAC Address of the network adapter. A MAC address 
is a unique ID assigned by the manufacturer of the network adapter. 
This feature can be configured to ALLOW or DENY network access.
<p>
