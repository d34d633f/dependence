<h1>DHCP Connection (Dynamic IP Address)</h1>
<p>To set up this connection, please make sure that you are connected to the D-Link Router
with the PC that was originally connected to your broadband connection.
If you are, then click the Clone MAC button to copy your computer's MAC Address to the D-Link Router.</p>
