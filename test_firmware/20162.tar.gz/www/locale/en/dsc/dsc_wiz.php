<H1 align="left">Welcome to the D-Link Setup Wizard</H1>
<!--div align="left"><span class="box_msg">This wizard will guide you through a step-by-step process to configure your new D-Link router and connect to the Internet.</span></div-->
