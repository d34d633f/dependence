<h1>FAST ETHERNET VIRTUAL CABLE TESTER(VCT)</h1>
Cable Test is advanced feature that integrates a LAN cable tester on every Ethernet port on the router.
