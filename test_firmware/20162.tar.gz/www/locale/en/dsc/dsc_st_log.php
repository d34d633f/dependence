<h1>Logs</h1>
View the logs. You can define the event levels to view.
