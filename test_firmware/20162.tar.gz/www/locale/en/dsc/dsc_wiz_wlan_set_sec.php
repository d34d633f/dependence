<h1>Set Your Wireless Security Password</h1>
<p id="m_enter_key" name="m_enter_key" style="display:none">Please enter the wireless password to establish wireless connection.</p>
<p id="m_do_next" name="m_do_next" style="display:none">To continue, click Next.</p>
