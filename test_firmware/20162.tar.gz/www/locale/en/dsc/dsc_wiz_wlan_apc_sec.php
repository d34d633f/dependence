<h1>Select Wireless Security Mode</h1>
<center><p>Please select the wireless security mode.</p>
