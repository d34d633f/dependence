<h1>Step 3: Configure your Internet Connection</h1>
<p align="left">Please select the Internet connection type below:</p>
