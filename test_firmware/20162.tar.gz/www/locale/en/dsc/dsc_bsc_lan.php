<h1>Network Settings</h1>
Use this section to configure the internal network settings of your access point and also to configure the built-in DHCP Server to assign IP addresses to the computers on your network. The IP Address that is configured here is the IP Address that you use to access the Web-based management interface. If you change the IP Address here, you may need to adjust your PC's network settings to access the network again. 
<p>
