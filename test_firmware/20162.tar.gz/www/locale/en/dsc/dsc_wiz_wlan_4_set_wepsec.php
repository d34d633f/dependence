<h1>Welcome to the D-Link Wireless Setup Wizard</h1>
<p>The WEP (Wired Equivalent Privacy) key must meet one of the following guidelines : </p>
