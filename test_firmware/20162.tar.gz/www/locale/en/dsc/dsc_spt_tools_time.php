<tr>
<td height=33><b>Time<font size=4> <a name=time></a></font></b>
<p>The Time Configuration settings are used by the Access Point for synchronizing scheduled services and system logging activities. You will need to set the time zone corresponding to your location. The time can be set manually or the device can connect to a NTP (Network Time Protocol) server to retrieve the time. You may also set Daylight Saving dates and the system time will automatically adjust on those dates. </p>
<p><strong><em>Time Zone - </em></strong>Select the Time Zone for the region you are in. </p>
<p><strong><em>Daylight Saving - </em></strong>If the region you are in observes Daylight Savings Time, enable this option and specify the Starting and Ending Month, Week, Day, and Time for this time of the year. </p>
<p><strong><em>Automatic Time Configuration - </em></strong>Enter the NTP server which you would like the <?query("/sys/modelname");?> to synchronize its time with. Also, select the interval at which the <?query("/sys/modelname");?> will communicate with the specified NTP server. </p>
<strong><em>Set the Date and Time Manually - </em></strong>Select this option if you would like to specify the time manually. You must specify the Year, Month, Day, Hour, Minute, and Second, or you can click the Copy Your Computer's Time Settings button to copy the system time from the computer being used to access the management interface. </td>
</tr>
<tr>
<td height=2>&nbsp;</td>
</tr>
<tr>
<td height=2>&nbsp;</td>
</tr>
