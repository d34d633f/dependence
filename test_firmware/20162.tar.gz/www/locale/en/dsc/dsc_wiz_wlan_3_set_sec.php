<h1>Step 3: Set your Wireless Security Password</h1>
<p>Once you have selected your security level - you will need to set a wireless security password. With this password, a unique security key will be generated. </p>
