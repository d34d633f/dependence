<h1>Internet Connection</h1>
There are 2 ways to setup your intenet connection. You can use the Web-based
Quick Router Setup wizard or you can manually configure the connection.
<br>
