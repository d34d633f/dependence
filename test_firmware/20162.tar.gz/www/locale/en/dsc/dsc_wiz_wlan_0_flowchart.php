<!--h1 align="left">Welcome to the D-Link Wireless Network Setup Wizard</h1>
<p>This wizard will guide you through a step-by-step process to setup your wireless network and make it secure.</p>
<br>
<center>
<table>
<tr>
	<td>
		<UL>
		<LI>Step 1: Set your new password
		<LI>Step 2: Set the SSID and Channel
		<LI>Step 3: Secure your Wireless Network
		<LI>Step 4: Set your Wireless Security Password
	</td>
</tr>
</table>
</center>
<br><br-->
<h1>SET YOUR DEVICE NAME</h1>
<p>Enter the Device Name of the AP. Recommand to change the Device Name if 
there're more than one D-Link devices within the subnet. Click <b>Next</b> to continue.</p>

