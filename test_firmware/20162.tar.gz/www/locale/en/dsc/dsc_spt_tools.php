<head>
<link rel="stylesheet" href="/model/router.css" type="text/css">
</head>
<?
$empty_row="<tr><td height=20>&nbsp;</td></tr>";
?>

<h1>Admin <a name=admin></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>The Admin option is used to set a password for access to the Web-based management. By default there is no password configured. It is highly recommended that you create a password to keep your new access point secure.</p>
 		</td>
	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>Admin Password </b>
	 		<br>
	 		Enter a password for the user "admin", who will have full access to the Web-based management interface.
			</p>
 		</td>
 	</tr>
</table>
<h1>Time <a name=time></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
	 <tr>
 		<td>
 			<br><p>The Time Configuration option allows you to configure, update, and maintain the correct time on the access point's internal system clock. From this section you can set the time zone that you are in and set the Time Server. Daylight saving time can also be configured to automatically adjust the time when needed. </p>
 		</td>
	</tr>
	<tr>
	 	<td height=30></a>
	 		<br>
	 		<b>Time Configuration</b>
	 		<br><br>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=150>
	 		<b>Current Time </b>
	 		<br>
	 		Displays the time currently maintained by the access point. If this is not correct, use the following options to configure the time correctly.
	 		<br><br>
	 		<b>Time Zone </b>
	 		<br>
	 		Select your local time zone from pull-down menu.
			<br><br>
	 		<b>Enable Daylight Saving</b>
	 		<br>
	 		Check this option if your location observes daylight saving time.
 			<br><br>
	 		<b>Daylight Saving Offset </b>
	 		<br>
	 		Select the time offset, if your location observes daylight saving time.
			<br><br>
			<b>DST Start and DST End </b>
	 		<br>
	 		Select the starting and ending times for the change to and from daylight saving time. For example, suppose for DST Start you select Month="Oct", Week="3rd", Day="Sun" and Time="2am". This is the same as saying: "Daylight saving starts on the third Sunday of October at 2:00 AM."
			<br><br>
 		</td>
 	</table>
 	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>Set the Date and Time Manually </b>
	 		<br>
	 		If you do not have the NTP Server option in effect, you can either manually set the time for your access point here, or you can click the "Copy Your Computer's Time Settings" button to copy the time from the computer you are using. (Make sure that computer's time is set correctly.)
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>Note: </b>
	 		If the access point loses power for any reason, it cannot keep its clock running, and will not have the correct time when it is started again. To maintain correct time for schedules and logs, either you must enter the correct time after you restart the access point, or you must enable the NTP Server option.
			</p>
 		</td>
 	</tr>
 </table>
<h1>System  <a name=system></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
	 <tr>
 		<td>
 			<br><p>This section allows you to manage the access point's configuration settings, reboot the access point, and restore the access point to the factory default settings. Restoring the unit to the factory default settings will erase all settings, including any rules that you've created.</p>
 		</td>
	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>Save To Local Hard Drive</b>
	 		<br>
	 		This option allows you to save the access point's configuration to a file on your computer. Be sure to save the configuration before performing a firmware upgrade.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>Load From Local Hard Drive </b>
	 		<br>
	 		Use this option to restore previously saved access point configuration settings.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>Restore To Factory Default </b>
	 		<br>
	 		This option restores all configuration settings back to the settings that were in effect at the time the access point was shipped from the factory. Any settings that have not been saved will be lost. If you want to save your access point configuration settings, use the Save Settings option above.
			</p>
 		</td>
 	</tr>

 	 <tr>
	 	<td height=59>
	 		<p><b>Reboot The Device </b>
	 		<br>
	 		This restarts the access point. Useful for restarting when you are not near the device.
			</p>
 		</td>
 	</tr>
 </table>
<h1>Firmware <a name=firmware></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
	 <tr>
 		<td>
 			<br><p>Use the Firmware section to install the latest firmware code to improve functionality and performance. </p>
 		</td>
	</tr>
	<tr>
	 	<td height=30></a>
	 		<br>
	 		To upgrade the firmware, follow these steps:
	 		<br><br>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=50>
	 		<ol>
	 		<li>Click the <b>Browse</b> button to locate the upgrade file on your computer.</li>
	 		<br>
	 		<li>Once you have found the file to be used, click the <b>Upload</b> button below to start the firmware upgrade process. This can take a minute or more. </li>
	 		<br>
	 		<li>Wait for the access point to reboot. This can take another minute or more.</li>
	 		<br>
	 		<li>Confirm updated firmware revision on status page. </li>
	 		<br>
	 		</ol>
 		</td>
 	</table>
 	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	 <tr>
	 	<td height=59>
	 		<p><b>Firmware Information</b>
	 		<br>
	 		Here are displayed the version numbers of the firmware currently installed in your access point and the most recent upgrade that is available.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>Firmware Upgrade </b>
	 		<br>
	 		<b>Note: </b>Firmware upgrade cannot be performed from a wireless device. To perform an upgrade, ensure that you are using a PC that is connected to the access point by wire.
			<br><br>
			<b>Note: </b>Some firmware upgrades reset the configuration options to the factory defaults. Before performing an upgrade, be sure to save the current configuration from the <a href="tools_admin.php">Maintenance &rarr; Admin</a> screen.
			</p>
 		</td>
 	</tr>
	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=50>
	 		<b>Upload  </b>
	 		<br>
	 		Once you have a firmware update on your computer, use this option to browse for the file and then upload the information into the access point.

</table>