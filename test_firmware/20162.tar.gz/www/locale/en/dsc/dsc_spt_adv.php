<head>
<link rel="stylesheet" href="/model/router.css" type="text/css">
</head>
<?
$empty_row="<tr><td height=20>&nbsp;</td></tr>";
?>
<?if($cfg_ap_mode=="1"){echo "<!--\n";}?>
<h1>MAC Address Filter (Network Filter) <a name=filter></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>The MAC address filter section can be used to filter network access by machines based on the unique MAC addresses of their network adapter(s). It is most useful to prevent unauthorized wireless devices from connecting to your network. A MAC address is a unique ID assigned by the manufacturer of the network adapter. </p>
 		</td>
	</tr>
	<tr>
	 	<td height=30>
	 		<br>
	 		<b>256 -- MAC Filtering Rules </b>
	 		<br><br>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=100>
	 		<p><b>Configure MAC Filtering </b>
	 		<br>
	 		When "OFF" is selected, MAC addresses are not used to control network access. When &rsquo;ALLOW&rsquo; is selected, only computers with MAC addresses listed in the MAC Address List are granted network access. When "DENY" is selected, any computer with a MAC address listed in the MAC Address List is refused access to the network.
	 		</p>
	 		<p><b>MAC Address </b>
	 		<br>
	 		Enter the MAC address of the desired device. Computers that have obtained an IP address from the access point's DHCP server will be in the DHCP Client List. Select a device from the drop-down menu, then click the arrow to add that device's MAC address to the list.
			</p>
	 		<p><b>Delete</b>
	 		<br>
	 		Click the "Delete" icon to remove the MAC address from the MAC Filtering list.
 			</p>
 			<br>
 		</td>
 	</table>
 	<h1>Advanced Wireless <a name=performance></a></h1>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>Transmit Power</b>
	 		<br>
	 		Normally the wireless transmitter operates at 100% power. In some circumstances, however, there might be a need to isolate specific frequencies to a smaller area. By reducing the power of the radio, you can prevent transmissions from reaching beyond your corporate/home office or designated wireless area.
			</p>
 		</td>
 	</tr>

 	<tr>
	 	<td height=59>
	 		<p><b>Beacon Period </b>
	 		<br>
	 		Beacons are packets sent by a wireless access point to synchronize wireless devices. Specify a Beacon Period value between 20 and 500. The default value is set to 100 milliseconds.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>DTIM Interval </b>
	 		<br>
	 		A DTIM is a countdown informing clients of the next window for listening to broadcast and multicast messages. When the wireless access point has buffered broadcast or multicast messages for associated clients, it sends the next DTIM with a DTIM Interval value. Wireless clients detect the beacons and awaken to receive the broadcast and multicast messages. The default value is 1. Valid settings are between 1 and 15.
			</p>
 		</td>
 	</tr>
 	<tr>
 		<td height=59>
 			<p><b>RTS Threshold </b>
 			<br>
			When an excessive number of wireless packet collisions are occurring, wireless performance can be improved by using the RTS/CTS (Request to Send/Clear to Send) handshake protocol. The wireless transmitter will begin to send RTS frames (and wait for CTS) when data frame size in bytes is greater than the RTS Threshold. This setting should remain at its default value of 2346 bytes.
			</p>
		</td>
	</tr>
	<tr>
 		<td height=59>
 			<p><b>Fragmentation Threshold </b>
 			<br>
			Wireless frames can be divided into smaller units (fragments) to improve performance in the presence of RF interference and at the limits of RF coverage. Fragmentation will occur when frame size in bytes is greater than the Fragmentation Threshold. Setting the Fragmentation value too low may result in poor performance.
			</p>
		</td>
	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>WMM</b>
	 		<br>
	 		Enabling WMM can help control latency and jitter when transmitting multimedia content over a wireless connection.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>Short GI </b>
	 		<br>
			Using a short (400ns) guard interval can increase throughput. However, it can also increase error rate in some installations, due to increased sensitivity to radio-frequency reflections. Select the option that works best for your installation.
			</p>
		</td>
	</tr>
	</table>
 	<h1>WLAN Partition<a name=#wlan_partition></a></h1>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>Internal Station Connection</b>
	 		<br>
	 		The Internal Station Connection default value is "allow," which allows stations to inter-communicate by connecting to a target AP. By disabling this function, wireless stations cannot exchange data through the AP.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>Ethernet to WLAN Access </b>
	 		<br>
	 		The Ethernet to WLAN Access default value is "allow," which allows data flow from the Ethernet to wireless stations connected to the AP. By disabling this function, all data from the Ethernet to associated wireless devices is blocked while wireless stations can still send data to the Ethernet through the AP.
			</p>
 		</td>
 	</tr>
</table>
	<h1>DHCP Server<a name=#dhcp></a></h1>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>DHCP Server</b>
	 		<br>
	 		DHCP stands for Dynamic Host Control Protocol. The DHCP server assigns IP addresses to devices on the
			network that request them. These devices must be set to &quot;Obtain the IP address automatically&quot;.
			By default, the DHCP Server is disabled on the <?query("/sys/modelname");?>. The DHCP address pool contains
			the range of the IP address that will automatically be assigned to the clients on the network.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>DHCP Reservation</b>
	 		<br>
	 		Enter the &quot;Computer Name&quot;, &quot;IP Address&quot; and &quot;MAC Address&quot; manually for
			the PC that you desire to have the AP to statically assign the same IP to or choose the PC from
			the drop down menu which shows current DHCP clients.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=59>
			<p>
			<strong><em>Starting IP address</em></strong> The starting IP address for the DHCP server's IP assignment.<br>
			<strong><em>Ending IP address</em></strong> The ending IP address for the DHCP server's IP assignment.<br>
			<strong><em>Lease Time</em></strong> The length of time in minutes for the IP lease.
			</p>	
			<p>
			Dynamic DHCP client computers connected to the unit will have their information displayed in the
			Dynamic DHCP Client Table. The table will show the Host Name, IP Address, MAC Address, and Expired
			Time of the DHCP lease for each client computer.
			</p>
 		</td>
 	</tr>
</table>

 	<h1>QoS<a name=#qos></a></h1>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>QoS stands for Quality of Service for Wireless Intelligent Stream Handling, a technology developed to enhance your experience of using a wireless network by prioritizing the traffic of different applications. Enable this option to allow QoS to prioritize the traffic. There are two options available for the special application.</p>
 		</td>
	</tr>
	<tr>
	 	<td height=30>
	 		<b>QoS</b>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Enable QoS</b>
	 		<br>
	 		Enable this option if you want to allow QoS to prioritize your traffic.
 			<br>
 		</td>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>QoS Type</b>
	 		<br>
	 		There are two options available for your special application.
 			<br>
 		</td>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
	 	<td height=30>
	 		<b>Port QoS</b>
 		</td>
 	</tr>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>LAN Port1,Port2,Port3 and Port4 Priority</b>
	 		<br>
	 		There are four priorities level for all Lan Ports, which are defined as following:  
 			<ul>
 				<li>Voice.</li>
 				<li>Video.</li>
 				<li>Best Effort.</li>
 				<li>Background. </li>
 			</ul>			
			The priorities level value we assigned is that 1 for Background, 3 for Best Effort, 5 for Video and 7 for Vioce.			
 		</td>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
	 	<td height=30>
	 		<b>Advanced QoS</b>
 		</td>
 	</tr>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>

	 		<p><b>Wireless to Ethernet </b>
	 		<br>
			The value that you enter here will indicate Wireless to Ethernet speed. When wireless mode acts as access point, you can set 51200kbps as a default value.
 			<br>
			when wireless mode setup is 11b only, the default speed value is 4196 kbit/sec; and 16384kbit/sec when wireless setup is 11a or 11g; 71680 kbit/sec when wireless mode setup is 11n.
			<br>
 		</td>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Ethernet to Wireless</b>
	 		<br>
			The value that you enter here will indicate Ethernet to Wireless speed. When wireless mode acts as access point, you can set 51200kbps as a default value.						
 			<br>
 			When wireless mode setup is 11b only, the default speed value is 4196 kbit/sec; and 16384kbit/sec when wireless setup is 11a or 11g; 71680 kbit/sec when wireless mode setup is 11n.
			<br>
 		</td>
 	</table>	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>ACK/DHCP/ICMP/DNS Priority</b>
	 		<br>
			 Denote a priority value which will apply for ACK,DHCP,ICMP,DNS packet delivering.
 			<br>
 		</td>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Web Traffic Priority</b>
	 		<br>
			 Denote a priority value which will apply for http packet delivering.
 			<br>
 		</td>
 	</table>		
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Mail Traffic Priority</b>
	 		<br>
			 Denote a priority value which will apply for some packets, which related with mail traffic, delivering.
 			<br>
 		</td>
 	</table>		
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Ftp Traffic Priority</b>
	 		<br>
			 Denote a priority value which will apply for ftp packet delivering.
 			<br>
 		</td>
 	</table>			
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Other Traffic Priority</b>
	 		<br>
			 Denote a priority value which will apply for other packets delivering.
 			<br>
 		</td>
 	</table>				
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b></b>
	 		<br>
			Normally the device transmits application data packets with the wireless to ethernet speed and ethernet to wireless speed, we can regard the two speeds as system transmission bandwidth, and based on assigned priorities, all applications will share the whole system bandwidth.
 			<br>
 		</td>
 	</table>	
	


 	<h1>Traffic Manager<a name=#trafficmgr></a></h1>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>
			Via Traffic Manager, you can control the bandwidth of the device by setting, wireless to ethernet speed and/or ethernet to wireless speed. It is also possible to add/del rules for different clients. For such clients which are not listed on the rule table, you may choose to deny or forward packets for them.		
			
			</p>
 		</td>
	</tr>
	<tr>
	 	<td height=30>
	 		<b>Traffic Manager</b>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Enable Taffic Manager</b>
	 		<br>
	 		Enable this option to allow traffic control.
 			<br>
 		</td>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Unlisted Clients Traffic</b>
	 		<br>
	 		There are two options available for Unlisted Clients Traffic: deny or forward.
 			<br>
 		</td>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Ethernet to Wireless</b>
	 		<br>
	 		Which indicates the MAX bandwidth from Ethernet to Wireless for the device.
 			<br>
 		</td>
 	</table>	
	
<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Wireless to Ethernet</b>
	 		<br>
	 		Which indicates the MAX bandwidth from Wireless to Ethernet for the device.
 			<br>
 		</td>
 	</table>	

	<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
	 	<td height=30>
	 		<b>Add Traffic Manager Rule</b>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Name</b>
	 		<br>
	 		The name of the rule.
 			<br>
 		</td>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Client IP(optional)</b>
	 		<br>
	 		The IP address assigned to the client.
 			<br>
 		</td>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Client Mac(optional)</b>
	 		<br>
	 		The Mac address assigned to the client.<br>For each rule being added, mac address and IP address stands for unique client, and at least one of them should be filled in.
 			<br>
 		</td>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Ethernet to Wireless </b>
	 		<br>
	 		Which denotes the available bandwidth for client data delivering from Ethernet to Wireless .
 			<br>
 		</td>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Wireless to Ethernet</b>
	 		<br>
	 		Which denotes the available bandwidth for client data delivering from Wireless to Ethernet.
 			<br>
 		</td>
 	</table>	

 	<h1>Schedule<a name=#schedule></a></h1>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>Wireless schedule</b>
	 		<br>
	 		<?query("/sys/modelname");?>'s radio can be scheduled by week or by individual days.
			</p>
 		</td>
 	</tr> 	
	</table>

<?if($cfg_ap_mode=="1"){echo "-->\n";}?>
<?if($cfg_ap_mode=="0"){echo <!--\n";}?>
<h1>Advanced Wireless <a name=performance></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>Transmit Power </b>
	 		<br>
	 		Normally the wireless transmitter operates at 100% power. In some circumstances, however, there might be a need to isolate specific frequencies to a smaller area. By reducing the power of the radio, you can prevent transmissions from reaching beyond your corporate/home office or designated wireless area.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>RTS Threshold </b>
	 		<br>
	 		When an excessive number of wireless packet collisions are occurring, wireless performance can be improved by using the RTS/CTS (Request to Send/Clear to Send) handshake protocol. The wireless transmitter will begin to send RTS frames (and wait for CTS) when data frame size in bytes is greater than the RTS Threshold. This setting should remain at its default value of 2346 bytes.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>Fragmentation Threshold </b>
	 		<br>
	 		Wireless frames can be divided into smaller units (fragments) to improve performance in the presence of RF interference and at the limits of RF coverage. Fragmentation will occur when frame size in bytes is greater than the Fragmentation Threshold. Setting the Fragmentation value too low may result in poor performance.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>Short GI </b>
	 		<br>
	 		Using a short (400ns) guard interval can increase throughput. However, it can also increase error rate in some installations, due to increased sensitivity to radio-frequency reflections. Select the option that works best for your installation.
			</p>
 		</td>
 	</tr>
</table>
	<h1>QoS<a name=#qos></a></h1>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>QoS stands for Quality of Service for Wireless Intelligent Stream Handling, a technology developed to enhance your experience of using a wireless network by prioritizing the traffic of different applications. Enable this option to allow QoS to prioritize the traffic. There are two options available for the special application.</p>
 		</td>
	</tr>
	<tr>
	 	<td height=30>
	 		<b>QoS</b>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Enable QoS</b>
	 		<br>
	 		Enable this option if you want to allow QoS to prioritize your traffic.
 			<br>
 		</td>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>QoS Type</b>
	 		<br>
	 		There are two options available for your special application.
 			<br>
 		</td>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
	 	<td height=30>
	 		<b>Port QoS</b>
 		</td>
 	</tr>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>LAN Port1,Port2,Port3 and Port4 Priority</b>
	 		<br>
	 		There are four priorities level for all Lan Ports, which are defined as following:  
 			<ul>
 				<li>Voice.</li>
 				<li>Video.</li>
 				<li>Best Effort.</li>
 				<li>Background. </li>
 			</ul>			
			The priorities level value we assigned is that 1 for Background, 3 for Best Effort, 5 for Video and 7 for Vioce.			
 		</td>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
	 	<td height=30>
	 		<b>Advanced QoS</b>
 		</td>
 	</tr>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>

	 		<p><b>Wireless to Ethernet </b>
	 		<br>
			The value that you enter here will indicate Wireless to Ethernet speed. When wireless mode acts as access point, you can set 51200kbps as a default value.
 			<br>
			when wireless mode setup is 11b only, the default speed value is 4196 kbit/sec; and 16384kbit/sec when wireless setup is 11a or 11g; 71680 kbit/sec when wireless mode setup is 11n.
			<br>
 		</td>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Ethernet to Wireless</b>
	 		<br>
			The value that you enter here will indicate Ethernet to Wireless speed. When wireless mode acts as access point, you can set 51200kbps as a default value.						
 			<br>
 			When wireless mode setup is 11b only, the default speed value is 4196 kbit/sec; and 16384kbit/sec when wireless setup is 11a or 11g; 71680 kbit/sec when wireless mode setup is 11n.
			<br>
 		</td>
 	</table>	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>ACK/DHCP/ICMP/DNS Priority</b>
	 		<br>
			 Denote a priority value which will apply for ACK,DHCP,ICMP,DNS packet delivering.
 			<br>
 		</td>
 	</table>
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Web Traffic Priority</b>
	 		<br>
			 Denote a priority value which will apply for http packet delivering.
 			<br>
 		</td>
 	</table>		
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Mail Traffic Priority</b>
	 		<br>
			 Denote a priority value which will apply for some packets, which related with mail traffic, delivering.
 			<br>
 		</td>
 	</table>		
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Ftp Traffic Priority</b>
	 		<br>
			 Denote a priority value which will apply for ftp packet delivering.
 			<br>
 		</td>
 	</table>			
	
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b>Other Traffic Priority</b>
	 		<br>
			 Denote a priority value which will apply for other packets delivering.
 			<br>
 		</td>
 	</table>				
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=30>
	 		<p><b></b>
	 		<br>
			Normally the device transmits application data packets with the wireless to ethernet speed and ethernet to wireless speed, we can regard the two speeds as system transmission bandwidth, and based on assigned priorities, all applications will share the whole system bandwidth.
 			<br>
 		</td>
 	</table>
	
 	<?if($cfg_ap_mode=="1"){echo <!--\n";}?>
	<h1>Schedule<a name=#schedule></a></h1>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>Wireless schedule</b>
	 		<br>
	 		<?query("/sys/modelname");?>'s radio can be scheduled by week or by individual days.
			</p>
 		</td>
 	</tr> 	
	</table>
	<?if($cfg_ap_mode=="1"){echo "-->\n";}?>
	
<?if($cfg_ap_mode=="0"){echo "-->\n";}?>
