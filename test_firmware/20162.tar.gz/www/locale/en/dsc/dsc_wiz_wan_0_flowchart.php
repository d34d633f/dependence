<h1>Welcome to the D-Link Setup Wizard</h1>
<p>This wizard will guide you through a step-by-step process to configure your new D-Link router and connect to the Internet.</p>
<table align="center">
<tr>
	<td width="334" height="81">
	<ul>
		<li>Step 1: Set your Password</li>
		<li>Step 2: Select your Time Zone</li>
		<li>Step 3: Configure your Internet Connection</li>
		<li>Step 4: Save Settings and Connect</li>
	</ul>
	</td>
</tr>
</table>
