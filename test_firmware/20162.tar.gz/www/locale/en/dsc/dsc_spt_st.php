<head>
<link rel="stylesheet" href="/model/router.css" type="text/css">
</head>
<?
$empty_row="<tr><td height=20>&nbsp;</td></tr>";
?>
<?if($cfg_ap_mode=="1"){echo "<!--\n";}?>
<h1>Device Info <a name=device></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>All of your network connection details are displayed on the Device Info page. The firmware version is also displayed here. </p>
 		</td>
	</tr>

	<tr>
	 	<td height=59>
	 		<p><b>Wireless LAN </b>
	 		<br>
	 		This area of the screen reflects configuration settings from the <a href="bsc_wlan.php">Setup  &rarr;  Wireless Settings</a> page. The <b>MAC Address</b> is the factory-assigned identifier of the wireless card.
			</p>
			<br>
 		</td>
 	</tr>
 </table>
<h1>Wireless  <a name=client></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>The wireless section allows you to view the wireless clients that are connected to your wireless access point.</p>
			<br>
 		</td>
	</tr>
 	 <tr>
	 	<td height=30>
	 		<p><b>MAC Address </b>
	 		<br>
	 		The Ethernet ID (MAC address) of the wireless client.
			</p>
 		</td>
 	</tr>

 	 <tr>
	 	<td height=59>
	 		<p><b>UpTime</b>
	 		<br>

			</p>
 		</td>
 	</tr>

 	 <tr>
	 	<td height=59>
	 		<p><b>Mode</b>
	 		<br>
	 		The transmission standard being used by the client. Values are 11a, 11b, or 11g for 802.11a, 802.11b, or 802.11g respectively.
			</p>
 		</td>
 	</tr>

 	 <tr>
	 	<td height=59>
	 		<p><b>Signal </b>
	 		<br>
	 		This is a relative measure of signal quality. The value is expressed as a percentage of theoretical best quality. Signal quality can be reduced by distance, by interference from other radio-frequency sources (such as cordless telephones or neighboring wireless networks), and by obstacles between the access point and the wireless device.
			</p>
 		</td>
 	</tr>
 </table>
<h1>Logs  <a name=log></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>The access point automatically logs (records) events of possible interest in its internal memory. If there is not enough internal memory for all events, logs of older events are deleted, but logs of the latest events are retained. The Logs option allows you to define the level of events to view.</p>
 		</td>
	</tr>
	<tr>
	 	<td height=30>
	 		<br>
	 		<p><b>What to View</b>
	 		<br>
	 		Select the level of events that you want to view.
			</p>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=50>
	 		<ul>
	 		<li>System Activity </li>
	 		<br>
	 		<li>Wireless Activity </li>
	 		<br>
	 		<li>Notice </li>
	 		<br>
	 		</ul>
 		</td>
 	</table>
 	<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
	 	<td height=59>
	 		<p><b>Log Server/IP Address </b>
	 		<br>
	 		If you want to record log events on a remote System Log Server, enter the Log Server's IP address here.
			</p>
 		</td>
 	</tr>
	<tr>
	 	<td height=59>
	 		<p><b>Apply Log Settings Now </b>
	 		<br>
	 		Click this button after changing Log Options to make them effective and permanent.
			</p>
 		</td>
 	</tr>
	<tr>
	 	<td height=59>
	 		<p><b>Refresh </b>
	 		<br>
	 		Clicking this button refreshes the display of log entries. There may be new events since the last time you accessed the log.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=59>
	 		<p><b>Clear </b>
	 		<br>
	 		Clicking this button erases all log entries.
			</p>
 		</td>
 	</tr>
	<tr>
	 	<td height=30>
	 		<p><b>Save Log </b>
	 		<br>
	 		Select this option to save the bridge log to a file on your computer.
			</p>
 		</td>
 	</tr>
 </table>
<h1>Statistics   <a name=stats></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>The Statistics page displays all of the LAN, WAN, and Wireless packet transmit and receive statistics.</p>
 		</td>
	</tr>
 	<tr>
	 	<td height=40>
	 		<p><b>TX Packets</b>
	 		<br>
	 		The number of packets sent from the access point.
			</p>
 		</td>
 	</tr>

 	 <tr>
	 	<td height=40>
	 		<p><b>RX Packets </b>
	 		<br>
	 		The number of packets received by the access point.
			</p>
 		</td>
 	</tr>

 	 <tr>
	 	<td height=40>
	 		<p><b>TX Packets Dropped </b>
	 		<br>
	 		The number of packets that were dropped while being sent, due to errors, collisions, or access point resource limitations.
			</p>
 		</td>
 	</tr>

  	<tr>
	 	<td height=40>
	 		<p><b>RX Packets Dropped </b>
	 		<br>
	 		The number of packets that were dropped while being received, due to errors, collisions, or access point resource limitations.
			</p>
 		</td>
 	</tr>
	<tr>
	 	<td height=40>
	 		<p><b>Tx Packets Bytes</b>
	 		<br>
			The number in bytes of packets sent from the access point.
			</p>
 		</td>
 	</tr>
	<tr>
	 	<td height=40>
	 		<p><b>Rx Packets Bytes</b>
	 		<br>
			The number in bytes of packets received by the access point.
			</p>
 		</td>
 	</tr>
</table>
<?if($cfg_ap_mode=="1"){echo "-->\n";}?>

<?if($cfg_ap_mode=="0"){echo "<!--\n";}?>
<h1>Device Info <a name=device></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td  height=30>
 			<p>All of your network connection details are displayed on the Device Info page. The firmware version is also displayed here. </p>
 		</td>
	</tr>
</table>
<h1>Logs  <a name=log></a></h1>
<table border=0 cellspacing=0 cellpadding=0 width=750>
 	<tr>
 		<td>
 			<br><p>The bridge automatically logs (records) events of possible interest in its internal memory. If there is not enough internal memory for all events, logs of older events are deleted, but logs of the latest events are retained. The Logs option allows you to view the bridge logs. You can define what types of events you want to view and the level of events to view. This bridge also has external Syslog Server support so you can send the log files to a computer on your network that is running a Syslog utility. </p>
 		</td>
	</tr>
	<tr>
	 	<td height=30>
	 		<br>
	 		<p><b>What to View</b>
	 		<br>
	 		Select the level of events that you want to view.
			</p>
 		</td>
 	</tr>
 	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=750>
 		<td width="10"></td>
	 	<td height=50>
	 		<ul>
	 		<li>System Activity </li>
	 		<br>
	 		<li>Wireless Activity </li>
	 		<br>
	 		<li>Notice  </li>
	 		<br>
	 		</ul>
 		</td>
 	</table>
 	<table border=0 cellspacing=0 cellpadding=0 width=750>
	<tr>
	 	<td height=30>
	 		<p><b>Apply Log Settings Now </b>
	 		<br>
	 		Click this button after changing Log Options to make them effective and permanent.
			</p>
 		</td>
 	</tr>
	<tr>
	 	<td height=30>
	 		<p><b>Refresh </b>
	 		<br>
	 		Clicking this button refreshes the display of log entries. There may be new events since the last time you accessed the log.
			</p>
 		</td>
 	</tr>
 	<tr>
	 	<td height=30>
	 		<p><b>Clear </b>
	 		<br>
	 		Clicking this button erases all log entries.
			</p>
 		</td>
 	</tr>
	<tr>
	 	<td height=30>
	 		<p><b>Save Log </b>
	 		<br>
	 		Select this option to save the bridge log to a file on your computer.
			</p>
 		</td>
 	</tr>
 </table>
<?if($cfg_ap_mode=="0"){echo "-->\n";}?>

