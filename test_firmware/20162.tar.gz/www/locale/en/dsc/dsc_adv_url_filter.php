<h1>Website Filtering Rules </h1>
The Website Filter option allows you to set-up a list of Websites that the users on your network will either be allowed or denied access to.
<p>

