<h1>Select Configuration Method</h1>
<p><b>Please select one of the following configuration methods and click next to continue.</b></p>
