<h1>Qos</h1>
QoS prioritizes the traffic of various wireless applications. 
<p>
