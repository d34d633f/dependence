<h1>SET YOUR NEW PASSWORD</h1>
<p>You may change the <b>admin</b> account password by entering in a new password. 
Click <b>Next</b> to continue.</p>
