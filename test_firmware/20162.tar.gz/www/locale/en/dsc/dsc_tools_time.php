<h1>Time</h1>
The Time Configuration option allows you to configure, update, 
and maintain the correct time on the internal system clock.
From this section you can set the time zone that you are in and set 
the NTP (Network Time Protocol) Server. Daylight Saving can also
be configured to automatically adjust the time when needed.
<br><br>
