<?
/* DAP-1522 */
$m_none = "NONE";
$m_wep  = "WEP";
$m_wpa  = "WPA";
$m_wpa2 = "WPA2";
?>
