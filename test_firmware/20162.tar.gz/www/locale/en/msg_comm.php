<?
$a_quit_wiz		="Do you want to abandon all changes you made to this wizard";//"Quit Setup Wizard and discard settings?";

$m_pre_title		="D-Link Corporation | WIRELESS ACCESS POINT | ";
$TITLE			=$m_pre_title."HOME";
$m_product_page		="Product Page";
$m_hw_ver		="Hardware Version";
$m_fw_ver		="Firmware Version";
$m_copyright		="Copyright &copy; 2011 D-Link Corporation, Inc.";

$m_nochg_title		="No Changed";
$m_nochg_dsc		="Settings is not changed.";
$m_saving_title		="Saving";
$m_saving_dsc		="The settings are saving and taking effect. <br><br> Please wait ...";
$m_scan_title		="Scan";
$m_scan_dsc		="Scanning ... <br><br> Please wait ...";
/* message for button.------------------------------------------*/
$m_back			="Back";
$m_continue		="Continue";
$m_prev		="Prev";
$m_retry		="Retry";

$m_save_settings	="Save Settings";
$m_no_save_settings	="Don't Save Settings";

$m_prev			="Prev";
$m_next			="Next";
$m_cancel		="Cancel";
$m_save			="Save";
$m_connect		="Connect";
$m_clear		="Clear";
$m_exit			="Exit";
/* ------------------------------------------------------------*/
// week day and time
$m_sun			="Sun";
$m_mon			="Mon";
$m_tue			="Tue";
$m_wed			="Wed";
$m_thu			="Thu";
$m_fri			="Fri";
$m_sat			="Sat";
$m_am			="AM";
$m_pm			="PM";

/* ------------------------------------------------------------*/


$m_name			="Name";

$m_user_name		="User Name";
$m_password		="Password";

$m_ipaddr		="IP Address";
$m_port			="Port";
$m_schedule		="Schedule";
$m_traffic_type		="Traffic Type";
$m_macaddr		="MAC Address";

$m_always		="Always";
$m_never		="Never";

$m_auto			="Auto";
$m_none			="None";

$m_disable		="Disable";
$m_enable		="Enable";

$m_disabled		="Disabled";
$m_enabled		="Enabled";

$m_edit			="Edit";
$m_del			="Delete";

/* ------------------------------------------------------------*/

$m_expired    		="Expired"; 

?>
