<?
$rgdb_mode	= query("/wireless/ap_mode");

$m_title_ap_mode	= "Access Point Mode";
$m_desc_ap_mode		= "Use this to disable NAT on the router and turn it into an Access Point.";
$m_enable_ap_mode	= "Enable Access Point Mode";

if($rgdb_mode=="0")
{
	$m_title_lan_type	= "Access Point Settings";
}
else
{
	$m_title_lan_type	= "LAN Settings";
}

$m_desc_lan_type	= "Use this section to configure the internal network settings of your access point. The IP Address that is configured here is the IP Address that you use to access the Web-based management interface. If you change the IP Address here, you may need to adjust your PC&acute;s network settings to access the network again. ";

$m_lan_type	= "LAN Connection Type";
$m_static_ip	= "Static IP";
$m_dhcp		= "Dynamic IP (DHCP)";

$m_title_static	= "Static IP Address LAN Connection Type";
$m_desc_static	= "Enter the static address information.";

$m_ipaddr	="Access Point IP Address";
$m_subnet	= "Subnet Mask";
$m_gateway	= "Default Gateway";
$m_macaddr	= "MAC Address";
$m_optional	= "(optional)";

$m_title_dhcp	= "Dynamic IP (DHCP) LAN Connection Type";
$m_desc_dhcp	= "Use this Internet connection type if your Internet Service Provider (ISP) ".
		"didn't provide you with IP Address information and/or a username and password.";
$m_desc_dhcp    = "IP Address information.";

$m_host_name		= "Host Name";
$m_always_on		= "Always-on";
$m_manual		= "Manual";
$m_on_demand		= "Connect-on demand";

$__info_from_isp	= "Enter the information provided by your Internet Service Provider (ISP).";


$m_retype_pwd		= "Retype Password";
$m_pppoe_svc_name	= "Service Name";
$m_minutes		= "Minutes";

$m_dynamic_ip		= "Dynamic IP";
$m_static_ip		= "Static IP";
$m_server_ip		= "Server IP/Name";

$m_auth_server	= "Auth Server";
$m_login_server = "Login Server IP/Name";

$a_invalid_ip		= "Invalid IP address !";
$a_invalid_netmask	= "Invalid subnet mask !";
$a_invalid_gateway	= "Invalid gateway address !";
$a_invalid_mac		= "Invalid MAC address !";
$a_invalid_mtu		= "Invalid MTU value !";
$a_invalid_hostname	= "Invalid host name !";
$a_invalid_username	= "Invalid user name !";
$a_password_mismatch	= "The confirm password does not match the new password !";
$a_invalid_idletime	= "Invalid idle time !";

$a_srv_in_different_subnet	= "Invalid server IP address ! The server and router addresses should be in the same network.";
$a_gw_in_different_subnet	= "Invalid gateway IP address ! The gateway and router addresses should be in the same network.";
$a_server_empty		= "Server IP/Name can not be empty !";
$a_account_empty	= "Account can not be empty !";

$m_title_device_name ="DEVICE NAME (NETBIOS NAME)";
$m_device_name ="Device Name";
$a_empty_device ="The Device Name field cannot be blank.";
$a_first_blank_device="There are some invalid characters in the Device Name field. Please check it.";
$a_invalid_device="The first character can't be blank.";

$m_title_green_eth="Green Ethernet";
$m_status="Status";
$m_enable="Enable";
$m_disable="Disable";
?>
