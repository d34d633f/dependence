<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIRELESS";
/* ---------------------------------------------------------------------- */
$m_context_title		="QoS";
$m_context_pri_title		="Priority Classifiers";
$m_context_add_title		="Add QoS Rule";
$m_context_edit_title		="Edit QoS Rule";
$m_context_qos_title		="QoS Rules ";
/*    QOS  */
$m_enable		="Enable QoS";
$m_QOS_Type             ="QoS Type";
$m_PriorityByLanPort    ="Priority by LAN Port";
$m_PriorityByProtocol   ="Priority by Protocol";
/*   Advance QOS        */
$m_context_AdvanceQos_title     ="Advanced QoS";
$m_context_PortPriority_title   ="Port QoS";
$m_advanceQos                   ="Advanced QoS";
$m_UplinkTraffic = "Ethernet to Wireless";
$m_DownlinkTraffic = "Wireless to Ethernet";
$m_AUI_Priority                 ="ACK/DHCP/ICMP/DNS Priority";
$m_web_Priority                 ="Web Traffic Priority";
$m_mail_Priority                ="Mail Traffic Priority";
$m_ftp_Priority                 ="Ftp Traffic Priority";
$m_other_Priority               ="Other Traffic Priority";
$m_PriorityHigh                 ="High";
$m_PriorityMedium		="Medium";
$m_PriorityLow			="Low";
$m_PriLimit 		        ="Limit";


$m_LanPort_1st          ="LAN Port 1 Priority";
$m_LanPort_2nd          ="LAN Port 2 Priority";
$m_LanPort_3rd          ="LAN Port 3 Priority";
$m_LanPort_4th          ="LAN Port 4 Priority";

$m_QOS_Type             ="QOS Type";
$m_PriorityByLanPort    ="Priority by LAN Port";
$m_PriorityByProtocol   ="Priority by Protocol";
/*   Advance QOS        */
$m_context_AdvanceQos_title     ="Advance Qos";
$m_context_PortPriority_title   ="Port Qos";
$m_advanceQos                   ="Advance QOS";
$m_UplinkTraffic = "Ethernet to Wireless";
$m_DownlinkTraffic = "Wireless to Ethernet";
$m_AUI_Priority                 ="ACK/DHCP/ICMP/DNS Priority";
$m_web_Priority                 ="Web Traffic Priority";
$m_mail_Priority                ="Mail Traffic Priority";
$m_ftp_Priority                 ="Ftp Traffic Priority";
$m_other_Priority               ="Other Traffic Priority";
$m_PriorityHigh                 ="High";
$m_PriorityMedium		="Medium";
$m_PriorityLow			="Low";
$m_PriLimit 		        ="Limit";


$m_LanPort_1st          ="LAN Port 1 Priority";
$m_LanPort_2nd          ="LAN Port 2 Priority";
$m_LanPort_3rd          ="LAN Port 3 Priority";
$m_LanPort_4th          ="LAN Port 4 Priority";

$m_http		="HTTP";
$m_auto		="Automatic";
$m_auto_msg	="(default if not matched by anything else) ";
$m_name		="Name";
$m_priority		="Priority";
$m_bk		="Background";
$m_be		="Best Effort";
$m_vi		="Video";
$m_vo		="Voice";
$m_protocol	="Protocol";
$m_any		="Any";
$m_tcp		="TCP";
$m_udp		="UDP";
$m_both		="Both";
$m_icmp		="ICMP";
$m_other		="Other";
$m_host_1_ip	="Host 1 IP Range";
$m_host_1_port		="Host 1 Port Range";
$m_host_2_ip		="Host 2 IP Range";
$m_host_2_port		="Host 2 Port Range";
$m_b_add		="Add";
$m_b_cancel		="Clear";
$protocol_port	="Protocol / Ports";
$a_rule_del_confirm	="Are you sure you want to delete ";
$m_r_bk		="Background";
$m_r_be		="Best Effort";
$m_r_vi		="Video";
$m_r_vo		="Voice";
$a_rule_state_confirm ="Are you sure that you want to enable/disable ";
$a_invalid_name		= "There are some invalid characters in the Name field. Please check it.";
$a_first_blank_name		= "The first character can't be blank.";
$a_invalid_ip		= "Invalid IP address !";
$a_invalid_ip_range		= "Invalid IP address Range !";
$a_invalid_port		= "Invalid Port !";
$a_invalid_port_range		= "Invalid Port Range !";
$a_invalid_value_for_limit  ="Invalid value for the limit !";
$a_empty_value_for_limit	="Please input for the limit!";
$a_empty_value_for_speed	="Please input value for the rate!";
$a_invalid_value_for_speed	="Invalid value for the rate !";
/*$		="";*/
?>
