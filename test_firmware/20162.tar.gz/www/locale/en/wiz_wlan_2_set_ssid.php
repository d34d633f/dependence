<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIZARD";
/* ---------------------------------------------------------------------- */
$a_empty_ssid	="The SSID field cannot be blank.";
$a_invalid_ssid	="There are some invalid characters in the SSID field. Please check it.";
$a_first_blank_ssid		= "The first character can't be blank.";

$m_wlan_ssid_msg ="Give your network a name, using up to 32 characters.";
$m_wlan_ssid	="Network Name (SSID) : ";
$m_wlan_channel ="Channel";
$m_wlan_auto_channel ="Auto Channel Scan";

$m_automatically ="Automatically assign a network key (Recommended)";
$m_automatically_msg ="To prevent outsiders from accessing your network, the AP will automatically assign a security key (also called WEP or WPA key) to your network.";
$m_manually ="Manually assign a network key";
$m_manually_msg ="Use this option if your prefer to create your own key.";

$m_use_wpa = "Use WPA encryption instead of WEP ";
$m_use_wpa_msg = "(WPA is stronger than WEP and all D-Link wireless client adapters <br>support WPA).";
$m_band	="802.11 Band";
$m_2.4G	="2.4GHz";
$m_5G	="5GHz";
?>
