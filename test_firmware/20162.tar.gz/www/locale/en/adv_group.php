<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."";
/* ---------------------------------------------------------------------- */
$m_context_title	="User Limit Settings(For AP Mode Only) ";
$m_limit_state	="User Limit";
$m_disable	="Disable";
$m_enable	="Enable";
$m_limit	="User Limit (0 - 64) ";

$a_empty_limit_num	="The User Limit cannot be blank.";
$a_invalid_limit_num	="The range of 'User Limit' is from 0 to 64.";
?>