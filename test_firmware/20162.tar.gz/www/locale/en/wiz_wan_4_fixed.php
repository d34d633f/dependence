<?
$m_netmask	= "Subnet Mask";
$m_gateway_addr	= "Gateway Address";
$m_primary_dns	= "Primary DNS Address";
$m_secondary_dns= "Secondary DNS Address";

$a_invalid_ip		= "Invalid IP address !";
$a_invalid_netmask	= "Invalid subnet mask !";
?>
