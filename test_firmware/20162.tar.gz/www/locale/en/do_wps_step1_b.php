<?
$m_pin				= "PIN";
$m_connect			= "Connect";
$m_pbc				= "PBC";//"PUSH BUTTON";
$m_virtual_button	= "Virtual Push Button";

$m_wps_pin_desc	=	"Please Enter the above PIN information into your Acces Point and click the below<br>".
					" \"Connect\" button.";
$m_wps_pbc_desc =	"Please press the push button on your wireless device and press the \"Connect\" button<br>".
					"below within 120 seconds";//"If the wireless device you are adding to your wireless network has both options ".
					//"available, you may use the Virtual Push Button if you prefer.";
$m_wps_pbc_comment ="(The Virtual Push Button acts the same as the physical Push Button on the router)";

$a_invalid_pin	=	"Invalid PIN number.";
$m_prev	="Prev";
$m_exit ="Exit";
$m_gen_pin 		= "Generate New PIN";
$m_reset_pin	= "Reset PIN to Default";

$a_reset_wps_pin		= "Are you sure to Reset PIN to Default?";
$a_gen_new_wps_pin		= "Are you sure to Generate a New PIN?";

?>
