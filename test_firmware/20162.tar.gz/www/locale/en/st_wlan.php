<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIRELESS";
/* ---------------------------------------------------------------------- */
$client_num = "0";
for("/runtime/stats/wireless/client")
{
	$client_num = $@;
}

$m_context_title_wlan	="Number Of Wireless Clients : ".$client_num;
$m_context_wds_title_wlan	="WDS Information";
$m_conn_time		="UpTime";
$m_signal			="Signal (%)";
$m_mode			="Mode";
$m_days			="days";
$m_hrs			="hours";
$m_mins			="minutes";
$m_secs			="seconds";
$m_ssid			="SSID";
$m_pri		="Primary SSID";
$m_ms1		="Multi-SSID 1";
$m_ms2		="Multi-SSID 2";
$m_ms3		="Multi-SSID 3";
$m_ms4		="Multi-SSID 4";
$m_ms5		="Multi-SSID 5";
$m_ms6		="Multi-SSID 6";
$m_ms7		="Multi-SSID 7";
?>
