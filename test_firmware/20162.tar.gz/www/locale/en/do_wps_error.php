<?
$m_wps_msg				= "The WPS function is currently set to disable. Click \"Yes\" to enable it or \"No\" to exit the wizard.";
$m_no					=" No ";
$m_yes					=" Yes ";
?>
