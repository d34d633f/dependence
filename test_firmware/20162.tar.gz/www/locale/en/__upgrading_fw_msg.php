The F/W is updating ...<br><br>
Please <font color=red><b>DO NOT POWER OFF</b></font> the device.<br><br>
And please wait for
<input type='Text' readonly name='WaitInfo' value='150' size='2' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
seconds...
