<?
$m_context_title	="WLAN Partition Settings";
$m_internal_station_connection	="Internal Station Connection";
$m_etherne_to_wlan	="Ethernet to WLAN Access";
$m_allow	="Allow";
$m_deny	="Deny";
?>
