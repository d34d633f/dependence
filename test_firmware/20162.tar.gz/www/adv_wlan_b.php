<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME		="adv_wlan_b";
$MY_MSG_FILE	=$MY_NAME.".php";
$CATEGORY		="adv";
/* --------------------------------------------------------------------------- */
if ($ACTION_POST!="")
{
	require("/www/model/__admin_check.php");

	$db_dirty=0;
	anchor("/wireless");
	if(query("txpower")			!=$tx_power)		{set("txpower", $tx_power);			$db_dirty++;}

	if(query("rtslength")		!=$rts)				{set("rtslength", $rts);			$db_dirty++;}
	if(query("fraglength")		!=$frag)			{set("fraglength", $frag);			$db_dirty++;}
	if(query("shortguardinterval")		!=$short_gi_mode)		{set("shortguardinterval", $short_gi_mode);		$db_dirty++;}

	if($db_dirty > 0)	{$SUBMIT_STR="submit WLAN";}
	else				{$SUBMIT_STR="";}

	$NEXT_PAGE=$MY_NAME;
	if($SUBMIT_STR!="")	{require($G_SAVING_URL);}
	else				{require($G_NO_CHANGED_URL);}
}

/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
/* --------------------------------------------------------------------------- */
// get the variable value from rgdb.
anchor("/wireless");
$tx_power	=query("txpower");
$rts		=query("rtslength");
$frag		=query("fraglength");
$short_gi	=query("shortguardinterval");
/* --------------------------------------------------------------------------- */
?>

<script>
/* page init functoin */
function init()
{
	var f=get_obj("frm");

	select_index(f.tx_power, "<?=$tx_power?>");

	f.rts.value="<?=$rts?>";
	f.frag.value="<?=$frag?>";
	
	f.short_gi.checked = <? if ($short_gi=="1") {echo "true";} else {echo "false";} ?>;

}
/* parameter checking */
function check()
{
	var f=get_obj("frm");
	
	if(!is_in_range(f.rts.value,256,2346))
	{
		alert("<?=$a_invalid_rts?>");
		if(f.rts.value=="") f.rts.value=2346;
		field_select(f.rts);
		return false;
	}
	
	if(!is_in_range(f.frag.value,1500,2346))
	{
		alert("<?=$a_invalid_frag?>");
		if(f.frag.value=="") f.frag.value=2346;
		field_select(f.frag);
		return false;
	}

	f.short_gi_mode.value=(f.short_gi.checked?1:0);
	
	return true;
}
/* cancel function */
function do_cancel()
{
	self.location.href="<?=$MY_NAME?>.php?random_str="+generate_random_str();
}

</script>
<body onload="init();" <?=$G_BODY_ATTR?>>
<form name="frm" id="frm" method="post" action="<?=$MY_NAME?>.php" onsubmit="return check();">
<input type="hidden" name="ACTION_POST" value="SOMETHING">
<?require("/www/model/__banner.php");?>
<?require("/www/model/__menu_top.php");?>
<table <?=$G_MAIN_TABLE_ATTR?> height="100%">
<tr valign=top>
	<td <?=$G_MENU_TABLE_ATTR?>>
	<?require("/www/model/__menu_left.php");?>
	</td>
	<td id="maincontent">
		<div id="box_header">
		<?
		require($LOCALE_PATH."/dsc/dsc_".$MY_NAME.".php");
		echo $G_APPLY_CANEL_BUTTON;
		?>
		</div>
<!-- ________________________________ Main Content Start ______________________________ -->
		<div class="box">
			<h2><?=$m_context_title?></h2>
			<table width=525>
			<tr>
				<td class=br_tb><?=$m_tx_power?> :</td>
				<td>
				<select name="tx_power">
				<option value="1">100%</option>
				<option value="2">50%</option>
				<option value="3">25%</option>
				<option value="4">12.5%</option>
				</select>
				</td>
			</tr>	
			<tr>
				<td class=br_tb><?=$m_rts?> :</td>
				<td><input maxlength=4 name=rts size=4 value=""><?=$m_dsc_rts?></td>
			</tr>
			<tr>
				<td class=br_tb><?=$m_frag?> :</td>
				<td><input maxlength=4 name=frag size=4 value=""><?=$m_dsc_frag?></td>
			</tr>			
			<tr>
				<td class=br_tb><?=$m_short_gi?> :</td>
				<td><input name="short_gi" id="short_gi" type="checkbox" onclick="" value="1"></td>
			</tr>													
			</table>
		</div>
		<input type=hidden name=preamble_type value="">
		<input type=hidden name=cts_mode value="">
		<input type=hidden name=wmm_mode value="">
		<input type=hidden name=igmp_mode value="">	
		<input type=hidden name=short_gi_mode value="">	
<!-- ________________________________  Main Content End _______________________________ -->
	</td>
	<td <?=$G_HELP_TABLE_ATTR?>><?require($LOCALE_PATH."/help/h_".$MY_NAME.".php");?></td>
</tr>
</table>
<?require("/www/model/__tailer.php");?>
</form>
</body>
</html>
