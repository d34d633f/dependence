<?
echo "<!--\n";
echo "$ACTION_POST=".$ACTION_POST."\n";
$rgdb_mode	= query("/wireless/ap_mode");

if($ACTION_POST=="1_password")
{
	echo "password=".$password."\n";
	if ($password != $G_DEF_PASSWORD)
	{
		set($G_WIZ_PREFIX_WLAN."/password",$password);
	}
}
else if($ACTION_POST == "configuration")
{
	if($final_configuration == 0) // Auto
	{
		if($rgdb_mode == 0)
		{
			set("/runtime/wiz/configuration","0");
			set($G_WIZ_PREFIX_WLAN."/wireless/ssid","dlink");
			set($G_WIZ_PREFIX_WLAN."/wireless/band","0"); //The default band is 11g.
			set($G_WIZ_PREFIX_WLAN."/wireless/channel","6");
			set($G_WIZ_PREFIX_WLAN."/wireless/autochannel","0");
			set($G_WIZ_PREFIX_WLAN."/wireless/authentication","7");
			set($G_WIZ_PREFIX_WLAN."/wireless/full_secret",$final_auto_secret);
			set($G_WIZ_PREFIX_WLAN."/wireless/wpa/passphraseformat","1");
			$WIZ_NEXT="5_auto_sec_saving";
		}
		else
		{
			$WIZ_NEXT="do_wps_step1_b";
		}
	}
	else // Manual
	{
		if($rgdb_mode == 0) // AP
		{
			set("/runtime/wiz/configuration","1");
			$WIZ_NEXT="2_set_ssid";
		}
		else //APC
		{
			$WIZ_NEXT="wiz_wlan_apc_set_ssid";
		}
	}
}
else if($ACTION_POST=="2_set_ssid")
{
	echo "$ssid=".$ssid."\n";
	echo "$final_band=".$final_band."\n";
	echo "$final_channel=".$final_channel."\n";
	echo "$final_autochann=".$final_autochann."\n";
	echo "full_secret=".$full_secret."\n";

	set($G_WIZ_PREFIX_WLAN."/wireless/ssid",$ssid);
	set($G_WIZ_PREFIX_WLAN."/wireless/band",$final_band);
	set($G_WIZ_PREFIX_WLAN."/wireless/channel",$final_channel);
	set($G_WIZ_PREFIX_WLAN."/wireless/autochannel",$final_autochann);

	if($auto_sec==0 && $use_wpa!=1)
	{
		set("/runtime/wiz/auto_wep_psk","0"); //auto , wep key
		set($G_WIZ_PREFIX_WLAN."/wireless/authentication","0");
		set($G_WIZ_PREFIX_WLAN."/wireless/full_sec_type","2"); //hex
		set($G_WIZ_PREFIX_WLAN."/wireless/full_sec_size","128"); //128 bit
		set($G_WIZ_PREFIX_WLAN."/wireless/full_secret",$full_secret);
		$WIZ_NEXT="5_auto_sec_saving";
	}
	else if($auto_sec==0 && $use_wpa==1)
	{
		set("/runtime/wiz/auto_wep_psk","1"); //auto , psk key
		set($G_WIZ_PREFIX_WLAN."/wireless/authentication","7");
		set($G_WIZ_PREFIX_WLAN."/wireless/full_secret",$full_secret);
		set($G_WIZ_PREFIX_WLAN."/wireless/wpa/passphraseformat","1");
		$WIZ_NEXT="5_auto_sec_saving";
	}
	else if($auto_sec==1 && $use_wpa!=1)
	{
		set("/runtime/wiz/auto_wep_psk","2"); //not auto , wep key
		set($G_WIZ_PREFIX_WLAN."/wireless/authentication","0");
		$WIZ_NEXT="4_set_wepsec";
	}
	else
	{
		set("/runtime/wiz/auto_wep_psk","3"); //not auto , psk key
		set($G_WIZ_PREFIX_WLAN."/wireless/authentication","7");
		$WIZ_NEXT="4_set_sec";
	}
}
else if($ACTION_POST=="3_sel_sec")
{
	anchor($G_WIZ_PREFIX_WLAN."/wireless/");
	/*authentication : 0:open system, 1:share key, 2: WPA, 3: WPA-PSK, 4: WPA2, 5: WPA2-PSK, 6: WPA-AUTO, 7: WPA-AUTO-PSK,
			   8:802.1X
	  wepmode: 0:disable, 1:wep, 2:tkip, 3: aes, 4: tkip+aes
	*/
	if($sec_type==5)	{set("authentication","5"); $WIZ_NEXT="4_set_sec";	}
	else if($sec_type==3)	{set("authentication","3"); $WIZ_NEXT="4_set_sec";	}
	else if($sec_type==1)	{set("authentication","0"); $WIZ_NEXT="4_set_wepsec";	}
	else			{set("authentication","0"); set("wpa/wepmode","0");	$WIZ_NEXT="5_saving";	}
}
else if($ACTION_POST=="4_set_sec")
{
	anchor($G_WIZ_PREFIX_WLAN."/wireless");
	set("secret",$secret);
	set("full_secret",$full_secret);
	set("wpa/wepmode","4");
	set("wpa/passphraseformat", $passphraseformat);
}
else if($ACTION_POST=="4_set_wepsec")
{
	anchor($G_WIZ_PREFIX_WLAN."/wireless");
	set("full_sec_type",$full_sec_type);
	set("full_sec_size",$full_sec_size);
	set("secret",$secret);
	set("full_secret",$full_secret);
	set("wpa/wepmode","1");

}
else if($ACTION_POST=="5_saving" || $ACTION_POST=="5_auto_sec_saving")
{
	anchor($G_WIZ_PREFIX_WLAN);
	$password=query("password");
	if ($password != $G_DEF_PASSWORD)
	{
		set("/sys/user:1/password", $password);
		echo "set password=".$password."\n";
	}

	$device_name=query($G_WIZ_PREFIX_WLAN."/netbios/name");
	set("/netbios/name",$device_name);
	anchor($G_WIZ_PREFIX_WLAN."/wireless");
	$ssid=query("ssid");
	$band=query("band");
	$channel=query("channel");
	$autochann=query("autochannel");
	$auth=query("authentication");
	$full_sec_type=query("full_sec_type");
	$full_sec_size=query("full_sec_size");
	$full_secret=query("full_secret");
	$passphraseformat=query("wpa/passphraseformat");

	anchor("/wireless");
	set("ssid",$ssid);
	set("band",$band);
	set("channel",$channel);
	set("autochannel",$autochann);
	if($band == 0) {set("wlmode","5");}
	else {set("wlmode","8");}
	if($auth=="0")
	{
		echo "full_secert=".$full_secret;
		if($full_secret=="")	//open with none wep
		{
			set("authentication","0");	set("wpa/wepmode","0");
		}
		else			//open with 128 bits wep
		{
			set("authentication", "0");	set("wpa/wepmode", "1");
			set("keylength", $full_sec_size);	set("keyformat", $full_sec_type);
			set("defkey","1");		set("wepkey:1", $full_secret);
			set("wps/configured", 1);
		}
	}
	else if($auth=="3" || $auth=="5" || $auth=="7")
	{
		set("authentication",$auth);
		set("wpa/wepmode","4");
		set("wpa/wpapsk",$full_secret);
		set("wpa/passphraseformat", $passphraseformat);
		set("wps/configured", 1);
	}
}
else if($ACTION_POST=="apc_set_ssid")
{
	set($G_WIZ_PREFIX_WLAN."/wireless/ssid",$ssid);

	$WIZ_NEXT="apc_sec";

}
else if($ACTION_POST=="apc_sec")
{
	anchor($G_WIZ_PREFIX_WLAN."/wireless/");
	if($sec_type==5)
	{
		set("authentication","5"); $WIZ_NEXT="set_apc_sec";

	}
	else if($sec_type==3)	{set("authentication","3"); $WIZ_NEXT="set_apc_sec";	}
	else if($sec_type==1)	{set("authentication","0"); set("wpa/wepmode","1");	 $WIZ_NEXT="set_apc_wepsec";	}
	else
	{
		anchor($G_WIZ_PREFIX_WLAN);
		$password=query("password");
		echo "set password=".$password."\n";
		if ($password != $G_DEF_PASSWORD)
		{
			set("/sys/user:1/password", $password);
			echo "set password=".$password."\n";
		}

		$device_name=query($G_WIZ_PREFIX_WLAN."/netbios/name");
		set("/netbios/name",$device_name);
		anchor($G_WIZ_PREFIX_WLAN."/wireless");
		$ssid=query("ssid");
		$band=query("band");
		$channel=query("channel");

		anchor("/wireless");
		set("ssid",$ssid);
		//set("band",$band);
		//set("channel",$channel);
		set("autochannel","1");
		set("authentication","0");
		set("wpa/wepmode","0");
		$WIZ_NEXT="apc_done";
	}
}
else if($ACTION_POST=="set_apc_wepsec")
{
	anchor($G_WIZ_PREFIX_WLAN);
	$password=query("password");
	echo "set password=".$password."\n";
	if ($password != $G_DEF_PASSWORD)
	{
		set("/sys/user:1/password", $password);
		echo "set password=".$password."\n";
	}

	$device_name=query($G_WIZ_PREFIX_WLAN."/netbios/name");
	set("/netbios/name",$device_name);
	anchor($G_WIZ_PREFIX_WLAN."/wireless");
	$ssid=query("ssid");
	$band=query("band");
	$channel=query("channel");

	anchor("/wireless");
	set("ssid",$ssid);
	set("autochannel","1");
	set("authentication", "0");
	set("wpa/wepmode", "1");
	set("keylength", $full_sec_size);
	set("keyformat", $full_sec_type);
	set("defkey","1");
	set("wepkey:1", $full_secret);

}
else if($ACTION_POST=="site_survey")
{
	set("/runtime/web/wireless/ssid",$ssid);
	set("/runtime/web/wireless/auth",$auth);
	$device_name=query($G_WIZ_PREFIX_WLAN."/netbios/name");
	set("/netbios/name",$device_name);
}
else if($ACTION_POST=="set_apc_sec")
{
	anchor($G_WIZ_PREFIX_WLAN);
	$password=query("password");
	if ($password != $G_DEF_PASSWORD)
	{
		set("/sys/user:1/password", $password);
		echo "set password=".$password."\n";
	}

	$device_name=query($G_WIZ_PREFIX_WLAN."/netbios/name");
	set("/netbios/name",$device_name);
	anchor($G_WIZ_PREFIX_WLAN."/wireless");
	$ssid=query("ssid");
	$band=query("band");
	$channel=query("channel");
	$auth=query("authentication");

	anchor("/wireless");
	set("ssid",$ssid);
	set("autochannel","1");
	set("authentication",$auth);
	if($band == 0)
	{set("wlmode","5");}
	else
	{set("wlmode","8");}

	set("wpa/wepmode","4");
	set("wpa/wpapsk",$full_secret);
	set("wpa/passphraseformat", $passphraseformat);
}
else if($ACTION_POST=="0_flowchart")
{
	anchor($G_WIZ_PREFIX_WLAN."/netbios/");
	set("name",$device_name);
}
else if($ACTION_POST=="band")
{
	anchor("/wireless");
	set("band",$band);
}
else if($ACTION_POST == "sel_sec")
{
	set("/runtime/web/wireless/auth", $auth);
}
else if($ACTION_POST == "step2_pin" || $ACTION_POST == "step2_pbc")
{
	if($rgdb_mode == 0) // AP
	{
	}
	else
	{
		anchor($G_WIZ_PREFIX_WLAN);
		$password=query("password");
		if ($password != $G_DEF_PASSWORD)
		{
			set("/sys/user:1/password", $password);
			echo "set password=".$password."\n";
		}
		$device_name=query($G_WIZ_PREFIX_WLAN."/netbios/name");
		set("/netbios/name",$device_name);
	}
}
else if($ACTION_POST == "apc_go_back_to_set_ssid")
{
	$WIZ_NEXT="wiz_wlan_apc_set_ssid";
}
echo "$WIZ_NEXT=".$WIZ_NEXT."\n";
echo "-->\n";
?>
