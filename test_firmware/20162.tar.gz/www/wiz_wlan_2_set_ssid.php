<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME		="wiz_wlan_2_set_ssid";
$MY_MSG_FILE	=$MY_NAME.".php";

$MY_ACTION		="2_set_ssid";
$WIZ_PREV		="configuration";
//$WIZ_NEXT		="3_sel_sec";
/* --------------------------------------------------------------------------- */
if ($ACTION_POST!="")
{
	require("/www/model/__admin_check.php");
	require("/www/__wiz_wlan_action.php");
	$ACTION_POST="";
	require("/www/wiz_wlan_".$WIZ_NEXT.".php");
	exit;
}

/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
/* --------------------------------------------------------------------------- */
// get the variable value from rgdb.
$db_ssid_path=$G_WIZ_PREFIX_WLAN."/wireless/ssid";
$db_ssid=get("j",$db_ssid_path);
if($db_ssid=="") {$db_ssid=get("j","/wireless/ssid");}
$db_band=query("/wireless/band");
$db_channel=query("/wireless/channel");
$cfg_autochann=query("/wireless/autochannel");
/* --------------------------------------------------------------------------- */
?>

<script>
<?require("/www/md5.js");?>
/* page init functoin */
function init()
{
	var f=get_obj("frm");
	f.ssid.value="<?=$db_ssid?>";
	if("<?=$db_band?>"=="0") f.band[0].checked = true;
	else                     f.band[1].checked = true;
	on_check_bandstatus();
	if(f.band[0].checked)
		select_index(f.channel_g, "<?=$cfg_channel?>");
	else
		select_index(f.channel_a, "<?=$cfg_channel?>");

	f.autochann.checked = true;
	f.auto_sec[0].checked=true;
	f.use_wpa.checked=true;

	on_check_autochann();
}
/* parameter checking */
function check()
{
	var f=get_obj("frm");
	if(is_blank(f.ssid.value)==true)
	{
		alert("<?=$a_empty_ssid?>");
		f.ssid.focus();
		return false;
	}

	if(first_blank(f.ssid.value))
	{
		alert("<?=$a_first_blank_ssid?>");
		f.ssid.select();
		return false;
	}

	if(strchk_unicode(f.ssid.value)==true)
	{
		alert("<?=$a_invalid_ssid?>");
		f.ssid.select();
		return false;
	}


	if(f.auto_sec[0].checked)
	{
		if(f.use_wpa.checked)
			f.full_secret.value=generate_psk(get_random_num());
		else
			f.full_secret.value=create_wep_key128(get_random_num(),"128");
	}

	f.final_band.value			=(f.band[0].checked?0:1);

	if(f.final_band.value == 0)
		f.final_channel.value = f.channel_g.value;
	else if(f.final_band.value == 1)
		f.final_channel.value = f.channel_a.value;

	f.final_autochann.value = (f.autochann.checked==false) ? 0 : 1;
	return true;
}

function on_check_autochann()
{
	var f = get_obj("frm");

	if(f.band[0].checked)
		f.channel_g.disabled = f.autochann.checked;
	else
		f.channel_a.disabled = f.autochann.checked;

	//if(f.autochann.checked) f.autochann.value = 1;
	//else f.autochann.value = 0;
}

function go_prev()
{
	self.location.href="<?=$POST_ACTION?>?TARGET_PAGE=<?=$WIZ_PREV?>";
}

function get_random_num()
{
	var rand_number = Math.round(Math.random()*20);
	var rand_key="";

	if(rand_number < 2)
		get_random_num();

	for(var i=0 ; i < rand_number ; i++)
	{
		rand_key+= get_random_char();
	}

	return rand_key;

}

function create_wep_key128(passpharse, pharse_len)
{
	var pseed2 = "";
	var md5_str = "";
	var count;


	for(var i = 0; i < 64; i++)
	{
		count = i % pharse_len;
		pseed2 += passpharse.substring(count, count+1);
	}

	md5_str = calcMD5(pseed2);

	return md5_str.substring(0, 26).toUpperCase();
}

function get_random_char()
{
	var number_list = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	var number = Math.round(Math.random()*62);

	return(number_list.substring(number, number + 1));
}
function generate_psk(key)
{
	var i = key.length;

	if (key.length < 8)
	{
		for (; i < 8; i++)
		{
			key += get_random_char();
		}
	}

	return key;
}

function on_check_bandstatus()
{
	var f=get_obj("frm")

	get_obj("get_11a_channel").style.display = "none";
	get_obj("get_11g_channel").style.display = "none";

	if(f.band[1].checked)
	{
		get_obj("get_11a_channel").style.display = "";
	}
	else
	{
		get_obj("get_11g_channel").style.display = "";
	}
	on_check_autochann();
}
</script>
<body onload="init();" <?=$G_BODY_ATTR?>>
<form name="frm" id="frm" method="post" action="<?=$POST_ACTION?>" OnSubmit="return check();">
<input type="hidden" name="ACTION_POST" value="<?=$MY_ACTION?>">
<input type="hidden" name="TARGET_PAGE" value="<?=$MY_ACTION?>">
<input type=hidden name="full_secret" value="">
<input type=hidden name="final_band" value="">
<input type=hidden name="final_channel" value="">
<input type=hidden name="final_autochann" value="">
<?require("/www/model/__banner.php");?>
<table <?=$G_MAIN_TABLE_ATTR?>>
<tr valign=top>
	<td width=10%></td>
	<td id="maincontent" width=80%>
		<br>
		<div id="box_header">
		<? require($LOCALE_PATH."/dsc/dsc_".$MY_NAME.".php"); ?>
<!-- ________________________________ Main Content Start ______________________________ -->
		<br>
	<table width=95%>
		<tr>
			<td height=30><?=$m_wlan_ssid_msg?></td>
			<td></td>
		</tr>
	</table>
	<table width=95%>
		<tr>
			<td class=r_tb width=20% height=30><?=$m_wlan_ssid?></td>
			<td><input type="text" name="ssid" size="20" maxlength="32"></td>
		</tr>
		<tr>
			<td class=r_tb width=40% height=30><?=$m_band?></td>
			<td>
				<input type=radio name=band value=0 onclick="on_check_bandstatus()"><?=$m_2.4G?>
				<input type=radio name=band value=1 onclick="on_check_bandstatus()"><?=$m_5G?>
			</td>
		</tr>
		<tr>
			<td class=r_tb width=40% height=30><?=$m_wlan_channel?></td>
			<td>
				<div id="get_11a_channel" style="display:none">
					<select name="channel_a" id="channel_a">
						<?require("/www/bsc_wlan_11a_channel.php");?>
					</select>
				</div>
				<div id="get_11g_channel" style="display:none">
					<select name="channel_g" id="channel_g">
						<?require("/www/bsc_wlan_11g_channel.php");?>
					</select>
				</div>
			</td>
		</tr>
		<tr>
			<td class=r_tb width=40% height=30><?=$m_wlan_auto_channel?></td>
			<td>
				<input type="checkbox" name="autochann" id="autochann" onclick="on_check_autochann()">
			</td>
		</tr>
	</table>

	<table width=95%>
		<tr>
			<td height=30><input type=radio name=auto_sec value=0></td>
			<td><?=$m_automatically?></td>
		</tr>
		<tr>
			<td></td>
			<td height=30><?=$m_automatically_msg?></td>
		</tr>
		<tr>
			<td height=30><input type=radio name=auto_sec value=1></td>
			<td><?=$m_manually?></td>
		</tr>
		<tr>
			<td></td>
			<td height=30><?=$m_manually_msg?></td>
		</tr>
		<tr>
			<td><input name="use_wpa" id="use_wpa" type="checkbox" value="1"></td>
			<td height=30><?=$m_use_wpa?><?=$m_use_wpa_msg?></td>
		</tr>
	</table>
		<br>
		<center><script>prev("");next("");exit();</script></center>
		<br>
<!-- ________________________________  Main Content End _______________________________ -->
		</div>
		<br>
	</td>
	<td width=10%></td>
</tr>
</table>
<?require("/www/model/__tailer.php");?>
</form>
</body>
</html>
