<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME		="bsc_wlan";
$MY_MSG_FILE	=$MY_NAME.".php";
$CATEGORY		="bsc";
/* --------------------------------------------------------------------------- */
$def_password	="XxXxXxXx";
$support_wps= query("/runtime/func/wps");
if ($support_wps==1) { require("/www/__bsc_wlan_wps_action.php"); }

/* The following is mapping rules for 802.11 Mode,Authentication,Security and Cipher*/
/* Established by Freddy 2010/11/19
====================================
Type: 802.11 Mode
Our database: /wireless/wlmode 
Variable: cfg_mode
2.4GHz:(11g)
			g Only:1
			bg mixed:2
			b Only:3
			n only:4
			bgn mixed:5
			gn mixed:6

5GHz:(11a)
		a only:7
		na mixed:8
		n Only:9
====================================

====================================								
Type: Cipher/Security
Our database: /wireless/wpa/wepmode ---- related to cfg_cipher
Variable: cfg_cipher and security_type
<-------cfg_cipher value---------->
No security:0
WEP:1
WPA:
		TKIP:2
		AES:3
		AUTO:4
<-------cfg_cipher value---------->

<------security_type value-------->
No security:0
WEP:1
WPA:2
EAP:3
<------security_type value-------->
====================================   

====================================
Type: Authentication
Our database: /wireless/authentication
Variable: cfg_auth

WEP: 
				OPEN:0
				SHARED:1
				
WPA-PSK:
				WPA Only:3
				WPA2 Only:5
				WPA/WPA2:7

WPA-EAP:
				WPA Only:2
				WPA2 Only:4
				WPA/WPA2:6
====================================
*/
if ($ACTION_POST!="")
{
	require("/www/model/__admin_check.php");
	echo "<!--\n";
	echo "f_enable=".			$f_enable.			"\n";
	echo "f_wps_enable=".		$f_wps_enable.		"\n";
	echo "f_ssid=".				$f_ssid.			"\n";
	echo "f_band=".				$f_band.			"\n";
	echo "f_mode=".				$f_mode.			"\n";
	echo "f_channel=".			$f_channel.			"\n";
	echo "f_auto_channel=".		$f_auto_channel.	"\n";
	echo "f_channel_width=".	$f_channel_width.	"\n";
	echo "f_ap_hidden=".		$f_ap_hidden.		"\n";
	echo "f_transmission_rate=".$f_transmission_rate."\n";
	echo "f_authentication=".	$f_authentication.	"\n";
	echo "f_cipher=".			$f_cipher.			"\n";
	echo "f_wep_len=".			$f_wep_len.			"\n";
	echo "f_wep_format=".		$f_wep_format.		"\n";
	echo "f_wep_def_key=".		$f_wep_def_key.		"\n";
	echo "f_wep1=".				$f_wep1.			"\n";
	echo "f_wep2=".				$f_wep2.			"\n";
	echo "f_wep3=".				$f_wep3.			"\n";
	echo "f_wep4=".				$f_wep4.			"\n";
	echo "f_wep=".				$f_wep.				"\n";
	echo "f_wpa_psk_type=".     $f_wpa_psk_type.    "\n";
	echo "f_wpa_psk=".			$f_wpa_psk.			"\n";
	echo "f_radius_ip1=".		$f_radius_ip1.		"\n";
	echo "f_radius_port1=".		$f_radius_port1.	"\n";
	echo "f_radius_secret1=".	$f_radius_secret1.	"\n";
	echo "f_macclone_enable=".	$f_macclone_enable.	"\n";
	echo "f_macclone_macaddress=".	$f_macclone_macaddress.	"\n";
	
	echo "-->\n";

	$db_dirty=0;
	$wps_cfg=0;
	
	anchor("/wireless");
	if(query("enable")!=$f_enable)	{set("enable",$f_enable); $db_dirty++;}
	if($f_enable=="1")
	{
		if(query("ssid")		!= $f_ssid)				{set("ssid",		$f_ssid);			$db_dirty++; $wps_cfg++; }
		if(query("band")		!= $f_band)				{set("band",		$f_band);			$db_dirty++; $wps_cfg++; }
		if(query("wlmode")		!= $f_mode)				{set("wlmode",		$f_mode);			$db_dirty++; $wps_cfg++; }
		if(query("channel")		!= $f_channel)			{set("channel",		$f_channel);		$db_dirty++;}
		if(query("autochannel")	!= $f_auto_channel)		{set("autochannel",	$f_auto_channel);	$db_dirty++;}
		if(query("cwmmode")		!= $f_channel_width)	{set("cwmmode",		$f_channel_width);		$db_dirty++;}
		if(query("ssidhidden")		!= $f_ap_hidden)		{set("ssidhidden",		$f_ap_hidden);		$db_dirty++;}
		if(query("fixedrate")		!= $f_transmission_rate )	{set("fixedrate",		$f_transmission_rate );		$db_dirty++;}
		if(query("authentication")	!= $f_authentication)	{set("authentication",	$f_authentication);	$db_dirty++; $wps_cfg++; }
		if(query("wpa/wepmode")	!= $f_cipher)			{set("wpa/wepmode",	$f_cipher);			$db_dirty++; $wps_cfg++; }

		if($f_cipher=="1")	//wep key
		{
			if(query("keylength")	!= $f_wep_len)			{set("keylength",	$f_wep_len);		$db_dirty++; $wps_cfg++;}
			if(query("keyformat")	!= $f_wep_format)		{set("keyformat",	$f_wep_format);		$db_dirty++; $wps_cfg++;}
			if(query("defkey")	!= $f_wep_def_key)		{set("defkey",	$f_wep_def_key);	$db_dirty++; $wps_cfg++;}
			if(query("wepkey:1")	!= $f_wep1)			{set("wepkey:1",	$f_wep1); 		$db_dirty++; $wps_cfg++;}
			if(query("wepkey:2")	!= $f_wep2)			{set("wepkey:2",	$f_wep2); 		$db_dirty++; $wps_cfg++;}
			if(query("wepkey:3")	!= $f_wep3)			{set("wepkey:3",	$f_wep3);		$db_dirty++; $wps_cfg++;}
			if(query("wepkey:4")	!= $f_wep4)			{set("wepkey:4",	$f_wep4);		$db_dirty++; $wps_cfg++;}
		}
		if($f_authentication=="2" || $f_authentication=="4" || $f_authentication=="6")	// wpa series
		{
			if(query("wpa/grp_rekey_interval")		!= $f_grp_key_interval)			{set("wpa/grp_rekey_interval",		$f_grp_key_interval);			$db_dirty++;  $wps_cfg++;}
			if(query("wpa/radiusserver")	!= $f_radius_ip1)	{set("wpa/radiusserver",	$f_radius_ip1);		$db_dirty++;  $wps_cfg++;}
			if(query("wpa/radiusport")		!= $f_radius_port1)	{set("wpa/radiusport",		$f_radius_port1);	$db_dirty++;  $wps_cfg++;}
			if($f_radius_secret1 != $def_password)
			{
				if(query("wpa/radiussecret") != $f_radius_secret1){set("wpa/radiussecret",	$f_radius_secret1);	$db_dirty++;  $wps_cfg++;}
			}
		}
		else if($f_authentication=="3" || $f_authentication=="5" || $f_authentication=="7")// wpa psk series
		{
			if(query("ap_mode") !="1")
			{
				if(query("wpa/grp_rekey_interval")		!= $f_grp_key_interval)			{set("wpa/grp_rekey_interval",		$f_grp_key_interval);			$db_dirty++;  $wps_cfg++;}
			}
			if(query("wpa/wpapsk") != $f_wpa_psk)	{set("wpa/wpapsk", $f_wpa_psk);	set("wpa/passphraseformat", $f_wpa_psk_type); $db_dirty++;  $wps_cfg++;}
		}
		if ($support_wps==1)
		{
			anchor("/wireless/wps");
			if($wps_cfg > 0)							{set("configured", "1");}
			if(query("enable")	!=$f_wps_enable)		{set("enable",	 $f_wps_enable);	$db_dirty++;}
			if(query("/wireless/ap_mode") == "0")
			{
				if(query("apsetuplocked")	!=$f_wps_lock_enable)		{set("apsetuplocked",	 $f_wps_lock_enable);	$db_dirty++;}
			}
		}
		
		if(query("/wireless/ap_mode") == "1")
		{
			if(query("/wireless/macclone/mode")	!=$f_macclone_macsource)		{set("/wireless/macclone/mode",	 $f_macclone_macsource);	$db_dirty++;}				        
			if(query("/wireless/macclone/enable")	!=$f_macclone_enable)		{set("/wireless/macclone/enable",	 $f_macclone_enable);	$db_dirty++;}
			
			if($f_macclone_macsource == 1)
			{
				if(query("/wireless/macclone/mac")	!=$f_macclone_macaddress)		{set("/wireless/macclone/mac",	 $f_macclone_macaddress);	$db_dirty++;}
			}
		}
	}
	if($db_dirty > 0)	{$SUBMIT_STR="submit WLAN";}

	//exit;
	$NEXT_PAGE=$MY_NAME;
	if($SUBMIT_STR!="")
	{
		require($G_SAVING_URL);
	}
	else
	{
		require($G_NO_CHANGED_URL);
	}
}

/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
require("/www/comm/__js_ip.php");
/* --------------------------------------------------------------------------- */
//get the variable value from rgdb.
anchor("/wireless/macclone");
$cfg_macclone_macaddress = query("mac");
//get mac source value as manual after mat scan,alix zhao 2008.07.28
if(query("/web/display/matscan")== "0")
{
  $cfg_macclone_enable = query("enable");
  $cfg_macclone_macsource = query("mode");
}
else
{
  $cfg_macclone_enable = query("/web/display/matscan");
  $cfg_macclone_macsource = query("/web/display/matscan");
}

if(query("/wireless/ap_mode") == "0") {$m_ap_mode = "Access Point";}
else{ $m_ap_mode = "Bridge Mode"; }

anchor("/wireless");
$cfg_enable	= query("enable");
if(query("/wireless/web_temp/site_survey_connect")=="1")
{
	$tmp = "";
	for("/runtime/wireless/apscanlistinfo/apcscan")
	{
		$tmp = $@;
		if($@ == query("/wireless/web_temp/ckssidnum"))
		{
			$cfg_ssid = get("j", "ssid");
		}
	}
	/* for ap scan */
	set("/wireless/web_temp/site_survey_connect","0");
}
else
{
	$cfg_ssid		= get("j", "ssid");
}
$cfg_band		= query("band");
$cfg_mode	= query("wlmode");
$cfg_channel	= query("channel");
$cfg_autochann	= query("autochannel");
$cfg_ap_mode = query("/wireless/ap_mode"); //AP = 0, APC = 1;
$cfg_channel_width	= query("cwmmode");
$cfg_fixedrate	= query("fixedrate");
$cfg_ssidhidden	= query("ssidhidden");
$cfg_auth		= query("authentication");
$cfg_cipher		= query("wpa/wepmode");
if		($cfg_cipher=="0")					{$security_type="0";}
else if	($cfg_cipher=="1")					{$security_type="1";}

if($cfg_auth=="2" || $cfg_auth=="4" || $cfg_auth=="6") {$security_type="3";}
else if ($cfg_auth=="3" || $cfg_auth=="5" || $cfg_auth=="7") {$security_type="2";}

$cfg_wep_length = query("keylength");
$cfg_wep_format = query("keyformat");
$wep_prefix="hex_wep_128_";
$cfg_wep_index	= query("defkey");
$cfg_wep1		= get("j","wepkey:1");
$cfg_wep2		= get("j","wepkey:2");
$cfg_wep3		= get("j","wepkey:3");
$cfg_wep4		= get("j","wepkey:4");

$cfg_radius_ip1		= query("wpa/radiusserver");
$cfg_radius_port1	= query("wpa/radiusport");
if(query("wpa/radiussecret")=="")	{$cfg_radius_sec1= "";}
else {$cfg_radius_sec1=$def_password;}

$cfg_acc_display		= query("/web/display/acct");
if(query("/web/display/acct") =="1")
{
	$cfg_acc_state		= query("wpa/acctstate");
	$cfg_acc_srv		= query("wpa/acctserver");
	$cfg_acc_port	= query("wpa/acctport");
	if(query("wpa/acctsecret")=="")	{$cfg_acc_sec= "";}
	else {$cfg_acc_sec=$def_password;}
}

if(query("wpa/wpapsk")==""){$cfg_wpapsk="";}
else {$cfg_wpapsk=query("wpa/wpapsk");} // for Passphrase fool-proof

$key_interval  	= query("wpa/grp_rekey_interval");
$td1			="<td class='r_tb' width='180' height='20'>";
$td2			="<td class='l_tb'>";
$symbol			=" :&nbsp;";
$ccode			= query("/runtime/nvram/countrycode");

/*--for mac clone --------------------------------------------------*/
$f_macclone_enable = query("/wireless/macclone/enable");
$f_macclone_macaddress = query("/wireless/macclone/mac");
$f_macclone_macsource = query("/wireless/macclone/mode");
/* --------------------------------------------------------------------------- */

?>

<?if ($support_wps==1) { require("/www/__bsc_wlan_wps_js.php"); }?>
<script type="text/javascript">

function reload_page()
{
	/*
	var str="/bsc_wlan.xgi?";
	str+=exe_str("submit SCAN");
	self.location.href=str;
	*/
}

function do_matscan()
{
	var f_final	=get_obj("final_form");	
	var str="/bsc_wlan.xgi?";
	str+=exe_str("submit MACCLONESCAN");
	self.location.href=str;	
}

function on_check_enable()//alix
{
	var f=get_obj("frm");
	var f_wps=get_obj("frm_wps");
	get_obj("wireless_enable").style.display = "";
	get_obj("show_security_mode").style.display = "none";
	get_obj("show_wep").style.display = "none";
	get_obj("show_wpa").style.display = "none";
	get_obj("psk_setting").style.display = "none";
	get_obj("eap_setting").style.display = "none";
	get_obj("wps_setting").style.display = "none";
	get_obj("StationMac").style.display = "none";

	if(f.enable.checked == true)
	{
		fields_disabled(f, false);
		f.ssid.disabled = false;
	
		if(<?=$cfg_ap_mode?> == 1) // apc mode
		{
			f.band[0].disabled = true;
			f.band[1].disabled = true;
			f.autochann.checked = true;
			f.autochann.disabled = true;
			f.channel_width.disabled = true;
			f.visibility_status[0].checked = true;
			f.visibility_status[0].disabled = true;
			f.visibility_status[1].disabled = true;
			f.apc_80211_mode.disabled = true;
			get_obj("StationMac").style.display = "";
		}
		else // ap mode
		{
			f.band[0].disabled = false;
			f.band[1].disabled = false;
			f.autochann.disabled = false;
			f.visibility_status[0].disabled = false;
		  f.visibility_status[1].disabled = false;
		}
		
		get_obj("show_security_mode").style.display = "";
		get_obj("wps_setting").style.display = "";
		on_check_bandstatus();
	}
	else
	{
		fields_disabled(f, true);
		f.enable.disabled=false;
	}
	
	<?if ($support_wps==1) {echo "enable_disable_wps();\n";}?>
}

function init()//alix zhao
{
	var f=get_obj("frm");
	var f_wep = get_obj("frm_wep");
	var f_wpa = get_obj("frm_wpa");
	var f_wps=get_obj("frm_wps");
	var f_macclone	=get_obj("frm_macclone");

	f.enable.checked = <? if($cfg_enable==1) {echo "true";} else {echo "false";} ?>;
	f.ssid.value = "<?=$cfg_ssid?>";

	var apc_band_box = get_obj("apc_band_box");
	if(<?=$cfg_ap_mode?>==0) // ap mode
	{
		apc_band_box.style.display = "none";
		if(<?=$cfg_band?>==0) f.band[0].checked=true;
		else f.band[1].checked=true;
	}
	else
	{
		apc_band_box.style.display = "";
		f.apc_band.checked = true;
		f.apc_band.disabled = true;
		
    //initialize the macaddress content
		f_macclone.tmpmac.value	 = "<?=$cfg_macclone_macaddress?>";
		document.getElementById("aclmac1").value = f_macclone.tmpmac.value.charAt(0)+f_macclone.tmpmac.value.charAt(1);	
		document.getElementById("aclmac2").value = f_macclone.tmpmac.value.charAt(3)+f_macclone.tmpmac.value.charAt(4);
		document.getElementById("aclmac3").value = f_macclone.tmpmac.value.charAt(6)+f_macclone.tmpmac.value.charAt(7);
		document.getElementById("aclmac4").value = f_macclone.tmpmac.value.charAt(9)+f_macclone.tmpmac.value.charAt(10);
		document.getElementById("aclmac5").value = f_macclone.tmpmac.value.charAt(12)+f_macclone.tmpmac.value.charAt(13);		
		document.getElementById("aclmac6").value = f_macclone.tmpmac.value.charAt(15)+f_macclone.tmpmac.value.charAt(16);	
		f_macclone.macclonemacsource.value	 = "<?=$cfg_macclone_macsource?>";	
    on_macclone_enable();	    
	}

	f.autochann.checked = <? if ($cfg_autochann==1) {echo "true";} else {echo "false";}?>;
	
	if(<?=$cfg_ap_mode?> == 1) //apc
	{
		select_index(f.channel_width, 1);
		select_index(f.apc_80211_mode,10);
		if(<?=$cfg_band?>==1) //band = 5G
		{
			get_obj("get_11a_channel").style.display = "";
			get_obj("get_11na_transmission_rate").style.display = "";
			select_index(f.transmission_rate_11na,31);
			select_index(f.channel_a, <?=$cfg_channel?>);
		}
		else
		{
			get_obj("get_11g_channel").style.display = "";
			get_obj("get_11ngb_transmission_rate").style.display = "";
			select_index(f.transmission_rate_11ngb,31);
			select_index(f.channel_g, <?=$cfg_channel?>);
		}
	}
	else // ap mode
	{
		select_index(f.channel_width, <?=$cfg_channel_width?>);
		if(<?=$cfg_band?>==1) //band = 5G
		{
			if(<?=$cfg_mode?> == 10)//It is abgn mode of apc.
				select_index(f.mode_80211_11a,8);
			else
				select_index(f.mode_80211_11a,<?=$cfg_mode?>);
			get_obj("get_11a_channel").style.display = "";
			select_index(f.channel_a, <?=$cfg_channel?>);
		
			if(<?=$cfg_mode?> == 7) // mode = 802.11a only
			{
				get_obj("get_11a_transmission_rate").style.display = "";
				select_index(f.transmission_rate_11a,<?=$cfg_fixedrate?>);
			}
			else
			{
				if(<?=$cfg_mode?> == 8) // mode =  Mixed 802.11na
		 		{
					get_obj("get_11na_transmission_rate").style.display = "";
					select_index(f.transmission_rate_11na,<?=$cfg_fixedrate?>);
				}
				else if (<?=$cfg_mode?> == 9)// mode = 802.11n only
				{
					get_obj("get_11n_transmission_rate").style.display = "";
					select_index(f.transmission_rate_11n,<?=$cfg_fixedrate?>);
				}
			}
		}
		else //band = 2.4G
		{
			if(<?=$cfg_mode?> == 10)//It is abgn mode of apc.
				f.mode_80211_11g.value="5";
			else
				f.mode_80211_11g.value="<?=$cfg_mode?>";
			get_obj("get_11g_channel").style.display = "";
			select_index(f.channel_g, <?=$cfg_channel?>);
			
			if(<?=$cfg_mode?> == 1) // mode = 802.11g only
			{
				get_obj("get_11g_transmission_rate").style.display = "";
				select_index(f.transmission_rate_11g,<?=$cfg_fixedrate?>);
			}
			else if(<?=$cfg_mode?> == 2) // mode = Mixed 802.11bg
			{
				get_obj("get_11gb_transmission_rate").style.display = "";
				select_index(f.transmission_rate_11gb,<?=$cfg_fixedrate?>);
			}
			else if(<?=$cfg_mode?> == 3) // mode = 802.11b only
			{
				get_obj("get_11b_transmission_rate").style.display = "";
				select_index(f.transmission_rate_11b,<?=$cfg_fixedrate?>);
			}
			else if(<?=$cfg_mode?> == 4) // mode = 802.11n only
			{
				get_obj("get_11n_transmission_rate").style.display = "";
				select_index(f.transmission_rate_11n,<?=$cfg_fixedrate?>);
			}
			else if(<?=$cfg_mode?> >= 5)//Mixed 802.11bgn
			{
				get_obj("get_11ngb_transmission_rate").style.display = "";
				select_index(f.transmission_rate_11ngb,<?=$cfg_fixedrate?>);
			}
			else if (<?=$cfg_mode?> >= 6)//Mixed 802.11gn
			{
				get_obj("get_11ng_transmission_rate").style.display = "";
				select_index(f.transmission_rate_11ng,<?=$cfg_fixedrate?>);
			}
		}
	}
	
	if(<?=$cfg_ssidhidden?>==0)
		f.visibility_status[0].checked=true;
	else
		f.visibility_status[1].checked=true;
	
	/* If we may choose the n mode, then we should remove wep option.*/
	if(<?=$cfg_ap_mode?> == 0) // ap mode
	{
	   if(((<?=$cfg_band?>==0) && <?=$cfg_mode?> == 4) || ((<?=$cfg_band?>==1)  && <?=$cfg_mode?> == 9))
		 		f.security_type_ap_11n.value = "<?=$security_type?>";
		 else
		 		f.security_type_ap.value = "<?=$security_type?>";		
	}
	else // apc mode
	{
		f.security_type_apc.value = "<?=$security_type?>"
	}
	
	select_index(f_wep.auth_type,	<?=$cfg_auth?>);
	if(<?=$cfg_wep_length?> == 64) //64bit
	{
		if(<?=$cfg_wep_format?> == 2)// hex
			select_index(f_wep.wep_key_len_type,1);
		else // ascii
			select_index(f_wep.wep_key_len_type,2);
	}
	else// 128 bit
	{
		if(<?=$cfg_wep_format?> == 2)// hex
			select_index(f_wep.wep_key_len_type,3);
		else // ascii
			select_index(f_wep.wep_key_len_type,4);
	}
	select_index(f_wep.wep_def_key,<?=$cfg_wep_index?>);

	if(<?=$cfg_wep_index?> == 1)
	{
		f_wep.wep_key_value.value = "<?=$cfg_wep1?>";
		f_wep.verify_wep_key_value.value = "<?=$cfg_wep1?>";
	}
	else if(<?=$cfg_wep_index?> == 2)
	{
		f_wep.wep_key_value.value = "<?=$cfg_wep2?>";
		f_wep.verify_wep_key_value.value = "<?=$cfg_wep2?>";
	}
	else if(<?=$cfg_wep_index?> == 3)
	{
		f_wep.wep_key_value.value = "<?=$cfg_wep3?>";
		f_wep.verify_wep_key_value.value = "<?=$cfg_wep3?>";
	}
	else
	{
		f_wep.wep_key_value.value = "<?=$cfg_wep4?>";
		f_wep.verify_wep_key_value.value = "<?=$cfg_wep4?>";
	}

	select_index(f_wpa.cipher_type,	<?=$cfg_cipher?>);

	if(<?=$cfg_auth?> == 2  || <?=$cfg_auth?> == 3 )
		f_wpa.wpa_mode.value = 2;
	else if(<?=$cfg_auth?> == 4 || <?=$cfg_auth?> == 5)
		f_wpa.wpa_mode.value = 1;
	else if(<?=$cfg_auth?> == 6 || <?=$cfg_auth?> == 7)
		f_wpa.wpa_mode.value = 0;

	f_wpa.wpapsk1.value		="<?=$cfg_wpapsk?>";
	f_wpa.srv_ip1.value		="<?=$cfg_radius_ip1?>";
	f_wpa.srv_port1.value	="<?=$cfg_radius_port1?>";
	f_wpa.srv_sec1.value	="<?=$cfg_radius_sec1?>";
	f_wpa.grp_key_interval.value  ="<?=$key_interval?>";
	on_check_enable();
}

function check()//alix
{
	var f	=get_obj("frm");
	var f_wep	=get_obj("frm_wep");
	var f_wpa	=get_obj("frm_wpa");
	var f_wps=get_obj("frm_wps");
	var f_final	=get_obj("final_form");
	var f_macclone	=get_obj("frm_macclone");
	var final_sec = 0;

	var err_wep_1  ="<?=$a_invalid_wep1?>";
	var err_wep_2  ="<?=$a_invalid_wep2?>";
	var err_wep_3  ="<?=$a_invalid_wep3?>";
	var err_wep_4  ="<?=$a_invalid_wep4?>";

	f_final.f_enable.value	="";
	if(<?=$support_wps ?>==1)	f_final.f_wps_enable.value = "";
	if(<?=$support_wps ?>==1) f_final.f_wps_lock_enable.value = "";

	f_final.f_ssid.value			="";
	f_final.f_channel.value			="";
	f_final.f_band.value			="";
	f_final.f_mode.value			="";
	f_final.f_auto_channel.value	="";
	f_final.f_channel_width.value	="";
	f_final.f_transmission_rate.value	="";
	f_final.f_ap_hidden.value		="";
	f_final.f_authentication.value	="";
	f_final.f_cipher.value			="";
	f_final.f_wep_len.value			="";
	f_final.f_wep_format.value		="";
	f_final.f_wep_def_key.value		="";
	f_final.f_wep1.value			="";
	f_final.f_wep2.value			="";
	f_final.f_wep3.value			="";
	f_final.f_wep4.value			="";
	f_final.f_wep.value				="";
	f_final.f_wpa_psk.value			="";
	f_final.f_radius_ip1.value		="";
	f_final.f_radius_port1.value	="";
	f_final.f_radius_secret1.value	="";
	f_final.f_grp_key_interval.value="";

	if(f.enable.checked)	{	f_final.f_enable.value="1";	}
	else	{	f_final.f_enable.value="0";		return f_final.submit();}

	if(<?=$support_wps ?>==1)
	{
		 f_final.f_wps_enable.value = (f_wps.wps_enable.checked ? 1:0);
		 if(<?=$cfg_ap_mode ?> == 0)
		 {
		 		f_final.f_wps_lock_enable.value = (f_wps.wps_lock_enable.checked ? 1:0);
		 }
	}

	if(is_blank(f.ssid.value))
	{
		alert("<?=$a_empty_ssid?>");
		f.ssid.focus();
		return false;
	}

	if(first_blank(f.ssid.value))
	{
		alert("<?=$a_first_blank_ssid?>");
		f.ssid.select();
		return false;
	}

	if(strchk_unicode(f.ssid.value))
	{
		alert("<?=$a_invalid_ssid?>");
		f.ssid.select();
		return false;
	}
	f_final.f_ssid.value = f.ssid.value;
	
	var band_value;
	if(<?=$cfg_ap_mode?> == 1) //apc
	{
		band_value = <?=$cfg_band?>;
	}
	else
	{
		band_value = (f.band[0].checked? 0:1);
	}
	
	f_final.f_band.value	= band_value;

	if(<?=$cfg_ap_mode?> == 1) //apc
	{
		f_final.f_mode.value = f.apc_80211_mode.value;
	}
	else
	{
		if(band_value == 1)//band = 5G
			f_final.f_mode.value = f.mode_80211_11a.value;
		else
			f_final.f_mode.value = f.mode_80211_11g.value;	
	}
	
	f_final.f_auto_channel.value	=(f.autochann.checked ? "1":"0");

	if(band_value == 1)
		f_final.f_channel.value = f.channel_a.value;
	else if(f_final.f_band.value == 0)
		f_final.f_channel.value = f.channel_g.value;

	
	if(<?=$cfg_ap_mode?> == 1) //apc mode
	{
		if(band_value == 0)//2.4G
			f_final.f_transmission_rate.value = f.transmission_rate_11ngb.value;
		else
			f_final.f_transmission_rate.value = f.transmission_rate_11na.value;
	}
	else // ap mode
	{
		if(band_value == 1) //band = 5G
		{
			if(f.mode_80211_11a.value == 7) // mode = 802.11a
				f_final.f_transmission_rate.value = f.transmission_rate_11a.value;
			else if(f.mode_80211_11a.value == 8)// mode = Mixed 802.11na
				f_final.f_transmission_rate.value = f.transmission_rate_11na.value;
			else // mode = 802.11n
				f_final.f_transmission_rate.value = f.transmission_rate_11n.value;
		}
		else //band = 2.4G
		{
			if(f.mode_80211_11g.value == 3) // mode = 802.11b
				f_final.f_transmission_rate.value = f.transmission_rate_11b.value;
			else if(f.mode_80211_11g.value == 1) // mode = 802.11g
				f_final.f_transmission_rate.value = f.transmission_rate_11g.value;
			else if(f.mode_80211_11g.value == 4) // mode = 802.11n
				f_final.f_transmission_rate.value = f.transmission_rate_11n.value;
			else if(f.mode_80211_11g.value == 2) // mode = Mixed 802.11gb
				f_final.f_transmission_rate.value = f.transmission_rate_11gb.value;
			else if(f.mode_80211_11g.value == 6) // mode = Mixed 802.11ng
				f_final.f_transmission_rate.value = f.transmission_rate_11ng.value;
			else // mode = Mixed 802.11ngb
				f_final.f_transmission_rate.value = f.transmission_rate_11ngb.value;
		}
	}
	
	if(<?=$cfg_ap_mode?> == 1) //apc
	{
		f_final.f_channel_width.value = f.channel_width.value;	
		final_sec = f.security_type_apc.value;
	}
	else
	{
		if((band_value == 0 && (f.mode_80211_11g.value == 4 || f.mode_80211_11g.value == 5 || f.mode_80211_11g.value == 6)) ||
		   (band_value == 1 && (f.mode_80211_11a.value == 8 || f.mode_80211_11a.value == 9)) )
				f_final.f_channel_width.value = f.channel_width.value;
		else
				f_final.f_channel_width.value = "0";
			
		if((band_value == 0 && f.mode_80211_11g.value == 4) ||
			 (band_value == 1 && f.mode_80211_11a.value == 9))
			final_sec = f.security_type_ap_11n.value;
		else
			final_sec = f.security_type_ap.value;
			
			if(final_sec == 3)//If user chooses WPA-EAP, then we should disable wps function.
				f_final.f_wps_enable.value = 0;
	}
	
	f_final.f_ap_hidden.value	= (f.visibility_status[0].checked?"0":"1");
	
	if(final_sec==0)
	{
		f_final.f_authentication.value="0";
		f_final.f_cipher.value="0";
	}
	else if(final_sec==1)
	{
		if( f_wep.wep_key_value.value =="")
		{
			alert("<?=$a_empty_defkey?>");
			f_wep.wep_key_value.focus();
			return false;
		}

		var i,j ,test_char ;
		if(f_wep.wep_key_len_type.value == 1 || f_wep.wep_key_len_type.value == 3) //hex
		{
			for(j=0; j<f_wep.wep_key_value.value.length; j++)
			{
				test_char=f_wep.wep_key_value.value.charAt(j);
				if( (test_char >= '0' && test_char <= '9') ||
					(test_char >= 'a' && test_char <= 'f') ||
					(test_char >= 'A' && test_char <= 'F'))
					continue;

				alert("<?=$a_valid_hex_char?>");
				f_wep.wep_key_value.select();
				return false;
			}
			if(f_wep.wep_key_len_type.value == 1) //64bit
			{
				// check length
				if(f_wep.wep_key_value.value.length!=10)
				{
					alert("<?=$a_invalid_wep_key_length?>");
					f_wep.wep_key_value.focus();
					return false;
				}
			}
			else //128 bit
			{
				if(f_wep.wep_key_value.value.length!=26)
				{
					alert("<?=$a_invalid_wep_key_length?>");
					f_wep.wep_key_value.focus();
					return false;
				}
			}

		}
		else //ascii
		{
			if(strchk_unicode(f_wep.wep_key_value.value))
			{
				alert("<?=$a_valid_asc_char?>");
				f_wep.wep_key_value.select();
				return false;
			}

			if(f_wep.wep_key_len_type.value == 2) //64bit
			{
				// check length
				if(f_wep.wep_key_value.value.length != 5)
				{
					alert("<?=$a_invalid_wep_key_length?>");
					f_wep.wep_key_value.focus();
					return false;
				}
			}
			else //128 bit
			{
				if(f_wep.wep_key_value.value.length != 13)
				{
					alert("<?=$a_invalid_wep_key_length?>");
					f_wep.wep_key_value.focus();
					return false;
				}
			}
		}
		
		if(f_wep.wep_key_value.value!=f_wep.verify_wep_key_value.value)
		{
			alert("<?=$a_wep_key_not_matched?>");
			f_wep.wep_key_value.select();
			return false;
		}

		//Ralink chip setting:
		//0: Hexadecimal
		//1: ASCII
		if(f_wep.wep_key_len_type.value == 1) // 64bit, hex
		{
			f_final.f_wep_format.value = "2";
			f_final.f_wep_len.value = "64";
		}
		else if(f_wep.wep_key_len_type.value == 2) // 64bit, ascii
		{
			f_final.f_wep_format.value = "1";
			f_final.f_wep_len.value = "64";
		}
		else if(f_wep.wep_key_len_type.value == 3) // 128bit, hex
		{
			f_final.f_wep_format.value = "2";
			f_final.f_wep_len.value = "128";
		}
		else // 128bit, ascii
		{
			f_final.f_wep_format.value = "1";
			f_final.f_wep_len.value = "128";
		}

		/* PaPa add WEP KEY check for DAP-1522 end */
		// assign final post variables
		f_final.f_authentication.value	=f_wep.auth_type.value;
		f_final.f_cipher.value			="1";
		f_final.f_wep_def_key.value		=f_wep.wep_def_key.value;
		i = f_final.f_wep_def_key.value	;
		eval("f_final.f_wep"+i+".value=f_wep.wep_key_value.value");
	}
	else if(final_sec == 2) // psk
	{
		if(f_wpa.wpapsk1.value.length == 64)
		{
			var test_char,j;
			for(j=0; j<f_wpa.wpapsk1.value.length; j++)
			{
				test_char=f_wpa.wpapsk1.value.charAt(j);
				if( (test_char >= '0' && test_char <= '9') ||
						(test_char >= 'a' && test_char <= 'f') ||
						(test_char >= 'A' && test_char <= 'F'))
					continue;

				alert("<?=$a_invalid_psk_hex?>");
				f_wpa.wpapsk1.select();
				return false;
			}
			f_final.f_wpa_psk_type.value="2";
		}
		else
		{
			if(f_wpa.wpapsk1.value.length <8 || f_wpa.wpapsk1.value.length > 63)
			{
				alert("<?=$a_invalid_psk_len?>");
				f_wpa.wpapsk1.value="";
				f_wpa.wpapsk1.select();
				return false;
			}
			if(strchk_unicode(f_wpa.wpapsk1.value))
			{
				alert("<?=$a_invalid_psk?>");
				f_wpa.wpapsk1.select();
				return false;
			}
			f_final.f_wpa_psk_type.value="1";
		}

		if(<?=$cfg_ap_mode?> != 1)	// apmode != apc
		{
			if(is_blank(f_wpa.grp_key_interval.value) ||is_blank_in_string(f_wpa.grp_key_interval.value)||isNaN(f_wpa.grp_key_interval.value) || (f_wpa.grp_key_interval.value < 300) || (f_wpa.grp_key_interval.value > 9999999))
			{
				alert("<?=$a_invalid_key_interval?>");
				f_wpa.grp_key_interval.focus();
				return false;
			}
		}
		if(f_wpa.wpa_mode.value == 2)// WPA Only
			f_final.f_authentication.value="3";//3: WPA-PSK
		else if(f_wpa.wpa_mode.value == 1)// WPA2 Only
			f_final.f_authentication.value="5";//5: WPA2-PSK
		else //WPA Auto
			f_final.f_authentication.value="7";//7: WPA-PSK + WPA2-PSK

		f_final.f_cipher.value = f_wpa.cipher_type.value;
		f_final.f_grp_key_interval.value = f_wpa.grp_key_interval.value;
		f_final.f_wpa_psk.value = f_wpa.wpapsk1.value;

	}
	else //eap
	{
		if(!is_valid_ip(f_wpa.srv_ip1.value,0))
		{
			alert("<?=$a_invalid_radius_ip1?>");
			f_wpa.srv_ip1.select();
			return false;
		}
		if(is_blank(f_wpa.srv_port1.value))
		{
			alert("<?=$a_invalid_radius_port1?>");
			f_wpa.srv_port1.focus();
			return false;
		}
		if(!is_valid_port_str(f_wpa.srv_port1.value))
		{
			alert("<?=$a_invalid_radius_port1?>");
			f_wpa.srv_port1.select();
			return false;
		}
		if(is_blank(f_wpa.srv_sec1.value))
		{
			alert("<?=$a_empty_radius_sec1?>");
			f_wpa.srv_sec1.focus();
			return false;
		}
		if(strchk_unicode(f_wpa.srv_sec1.value))
		{
			alert("<?=$a_invalid_radius_sec1?>");
			f_wpa.srv_sec1.select();
			return false;
		}
		if(is_blank(f_wpa.grp_key_interval.value) ||is_blank_in_string(f_wpa.grp_key_interval.value)|| isNaN(f_wpa.grp_key_interval.value)|| f_wpa.grp_key_interval.value < 300 || f_wpa.grp_key_interval.value > 9999999)
		{
			alert("<?=$a_invalid_key_interval?>");
			f_wpa.grp_key_interval.focus();
			return false;
		}
		if(f_wpa.wpa_mode.value == 2)// WAP Only
			f_final.f_authentication.value="2";//2:WPA-EAP
		else if(f_wpa.wpa_mode.value == 1)// WAP2 Only
			f_final.f_authentication.value="4";//4:WPA2-EAP
		else//WAP Auto
			f_final.f_authentication.value="6";//6:(WPA + WPA2)-EAP

		f_final.f_cipher.value =f_wpa.cipher_type.value;
		f_final.f_grp_key_interval.value=f_wpa.grp_key_interval.value;
		f_final.f_radius_ip1.value =f_wpa.srv_ip1.value;
		f_final.f_radius_port1.value =f_wpa.srv_port1.value;
		f_final.f_radius_secret1.value =f_wpa.srv_sec1.value;

	}
	if(<?=$cfg_ap_mode?> == 1)	// apmode != apc  alix zhao
	{
		f_final.f_macclone_enable.value	=(f_macclone.maccloneenable.checked ? 1:0);
		f_final.f_macclone_macsource.value = f_macclone.macclonemacsource.value;			
		if(f_final.f_macclone_enable.value == 1 && f_final.f_macclone_macsource.value == 1)
		{
			for(i=1;i<=6;i++)
			{
				var acl_mac=eval("f_macclone.aclmac"+i+".value");
				if(is_blank(acl_mac) || !is_valid_mac(acl_mac))
				{
					alert("<?=$a_invalid_mac?>");
					eval("f_macclone.aclmac"+i+".focus()");
					return false;			
				}
				if (acl_mac.length == 1) eval("f.aclmac"+i+".value= '0'+acl_mac");
			}
			acl_mac = f_macclone.aclmac1.value+":"+f_macclone.aclmac2.value+":"+f_macclone.aclmac3.value+":"+f_macclone.aclmac4.value+":"+f_macclone.aclmac5.value+":"+f_macclone.aclmac6.value;
			acl_mac = acl_mac.toUpperCase(acl_mac);
			if(true == is_BroadcastorMulticast(f_macclone.aclmac1.value))
			{
					alert("<?=$a_invalid_mac?>");
					eval("f_macclone.aclmac"+1+".focus()");
					return false;					
			}
	
	   	if(acl_mac == "00:00:00:00:00:00")
	    {
				alert("<?=$a_invalid_mac?>");
				eval("f_macclone.aclmac"+1+".focus()");
				return false;				
			}
	
			f_final.f_macclone_macaddress.value	= acl_mac;
		}
	}
	f_final.submit();
}

function on_check_bandstatus()
{
	var f=get_obj("frm");
	
	get_obj("get_11a_80211_mode").style.display = "none";
	get_obj("get_11g_80211_mode").style.display = "none";
	get_obj("get_apc_80211_mode").style.display = "none";
	
	get_obj("get_11a_channel").style.display = "none";
	get_obj("get_11g_channel").style.display = "none";
	
	var band_value;
	if(<?=$cfg_ap_mode?> == 1) //apc
	{
		band_value = <?=$cfg_band?>;
		if(band_value == 0)// 2.4GHz
			get_obj("get_11g_channel").style.display = "";
		else
			get_obj("get_11a_channel").style.display = "";
		get_obj("get_apc_80211_mode").style.display = "";
		select_index(f.apc_80211_mode,10);
	}
	else
	{
		band_value = (f.band[0].checked? 0:1);
		if(band_value == 0)// 2.4GHz
		{
			get_obj("get_11g_channel").style.display = "";
			get_obj("get_11g_80211_mode").style.display = "";
			f.mode_80211_11g.disabled = false;
		}
		else// 5GHz
		{
			get_obj("get_11a_channel").style.display = "";
			get_obj("get_11a_80211_mode").style.display = "";
			f.mode_80211_11a.disabled = false;
		}
	}
		
	on_change_80211_mode();
	on_check_autochann();
	change_wlan_channel();
}
function on_change_80211_mode()
{
	var f = get_obj("frm");
	var f_wpa = get_obj("frm_wpa");
	var band_value;

	get_obj("get_11a_transmission_rate").style.display = "none";
	get_obj("get_11b_transmission_rate").style.display = "none";
	get_obj("get_11g_transmission_rate").style.display = "none";
	get_obj("get_11n_transmission_rate").style.display = "none";
	get_obj("get_11na_transmission_rate").style.display = "none";
	get_obj("get_11gb_transmission_rate").style.display = "none";
	get_obj("get_11ng_transmission_rate").style.display = "none";
	get_obj("get_11ngb_transmission_rate").style.display = "none";
	get_obj("show_channel_width").style.display = "none";
	f_wpa.cipher_type.disabled = false;
	
	if(<?=$cfg_ap_mode?> == 1) //apc mode
	{
		band_value = <?=$cfg_band?>;
		if(f.apc_80211_mode.value == 10) // mode = Mixed 802.11abgn
		{
			get_obj("get_apc_sec").style.display = "";
			get_obj("get_apc_sec_11n").style.display = "none";
			get_obj("show_channel_width").style.display = "";
			
			if(band_value == 1)//band = 5G
			{
				get_obj("get_11na_transmission_rate").style.display = "";
				f.transmission_rate_11na.disabled = true;
				select_index(f.transmission_rate_11na,31);
			}
			else//band = 2.4G
			{
					get_obj("get_11ngb_transmission_rate").style.display = "";
					f.transmission_rate_11ngb.disabled = true;
					select_index(f.transmission_rate_11ngb,31);
			}
		}
	}
	else // ap mode
	{
		get_obj("get_ap_sec").style.display = "";
		get_obj("get_ap_sec_11n").style.display = "none";
		band_value = (f.band[0].checked? 0:1);
		
		if(band_value == 1) //band = 5G
		{
			if(f.mode_80211_11a.value == 7) // mode = 802.11a only
			{
				get_obj("get_11a_transmission_rate").style.display = "";
				f.transmission_rate_11a.disabled = false;
			}
			else if (f.mode_80211_11a.value == 8) // mode = 802.11na
			{
				get_obj("get_11na_transmission_rate").style.display = "";
				get_obj("show_channel_width").style.display = "";
				f.transmission_rate_11na.disabled = false;
				f.channel_width.disabled = false;
			}
			else if(f.mode_80211_11a.value == 9) // mode = 802.11n only
			{
				get_obj("get_ap_sec").style.display = "none";
				get_obj("get_ap_sec_11n").style.display = "";
				get_obj("get_11n_transmission_rate").style.display = "";
				get_obj("show_channel_width").style.display = "";
				f_wpa.cipher_type.disabled = true;
				f_wpa.cipher_type.value = 3;
				f.transmission_rate_11n.disabled = false;
				f.channel_width.disabled = false;
			}
		}
		else //band = 2.4G
		{
			if(f.mode_80211_11g.value == 1) // mode = 802.11g only
			{
				get_obj("get_11g_transmission_rate").style.display = "";
				f.transmission_rate_11g.disabled = false;
			}
			else if(f.mode_80211_11g.value == 2) // mode = Mixed 802.11bg
			{
				get_obj("get_11gb_transmission_rate").style.display = "";
				f.transmission_rate_11gb.disabled = false;
			}
			else if(f.mode_80211_11g.value == 3) // mode = 802.11b only
			{
				get_obj("get_11b_transmission_rate").style.display = "";
				f.transmission_rate_11b.disabled = false;
			}
			else if(f.mode_80211_11g.value == 4) // mode = 802.11n only
			{
				get_obj("get_ap_sec").style.display = "none";
				get_obj("get_ap_sec_11n").style.display = "";
				get_obj("get_11n_transmission_rate").style.display = "";
				get_obj("show_channel_width").style.display = "";
				
				f_wpa.cipher_type.disabled = true;
				f_wpa.cipher_type.value = 3;
				f.channel_width.disabled = false;
				f.transmission_rate_11n.disabled = false;
			}
			else if (f.mode_80211_11g.value == 5)//mode = Mixed 802.11bgn
			{
				get_obj("get_11ngb_transmission_rate").style.display = "";
				get_obj("show_channel_width").style.display = "";
				f.channel_width.disabled = false;
				f.transmission_rate_11ngb.disabled = false;
			}
			else if(f.mode_80211_11g.value == 6)//Mixed 802.11gn
			{
				get_obj("get_11ng_transmission_rate").style.display = "";
				get_obj("show_channel_width").style.display = "";
				f.channel_width.disabled = false;
				f.transmission_rate_11ng.disabled = false;
			}
		}
	}
	on_change_security_type();
}

function on_check_autochann()
{
	var f = get_obj("frm");
	
	if(<?=$cfg_ap_mode?> == 1) //apc mode
	{
		f.channel_a.disabled = true;
		f.channel_g.disabled = true;
	}
	else // ap mode
	{
		if(f.band[1].checked)
			f.channel_a.disabled = f.autochann.checked;
		else
			f.channel_g.disabled = f.autochann.checked;
	}
}

function on_Click_SSID_Status()
{
	<?if ($support_wps==1) {echo "enable_disable_wps();\n";}?>
}

function do_scan()
{
	var f_final	=get_obj("final_form");
	<?set("/wireless/web_temp/scan/first_scan","");?>
	options="toolbar=0,status=0,menubar=0,scrollbars=1,resizable=1,width=600,height=400";
	window.open("bsc_site_survey.php","site_survey",options);
}

function on_change_security_type()
{
	var f=get_obj("frm");
	var f_wep=get_obj("frm_wep");
	var f_wpa=get_obj("frm_wpa");
	var sec_type;

	get_obj("show_wep").style.display = "none";
	get_obj("show_wpa").style.display = "none";
	get_obj("psk_setting").style.display = "none";
	get_obj("eap_setting").style.display = "none";
	get_obj("wps_setting").style.display = "";
	
	if(<?=$cfg_ap_mode?> == 1) //apc mode
	{
		if(f.apc_80211_mode.value == 10) // mode = Mixed 802.11abgn
		{
			sec_type = f.security_type_apc.value;
		}
	}
	else //ap mode
	{
		/* If we may choose the n mode, then we should remove wep option.*/
		if((f.band[0].checked && f.mode_80211_11g.value == 4) ||
			 (f.band[1].checked && f.mode_80211_11a.value == 9))
		{
				sec_type = f.security_type_ap_11n.value;
		}
		else
		{
				sec_type = f.security_type_ap.value;
		}
	}
	
	if(sec_type == 1) // wep mode
	{
		get_obj("show_wep").style.display = "";
		if(<?=$cfg_ap_mode?> == 1) // apc
		{
			f_wep.auth_type.disabled = true;
			f_wep.auth_type.value = 0;
		}
	}
	else if(sec_type == 2) // wpa-psk mode
	{
		get_obj("show_wpa").style.display = "";
		get_obj("psk_setting").style.display = "";
		if(<?=$cfg_ap_mode?> == 1)
		{
			f_wpa.grp_key_interval.disabled = true;
			f_wpa.grp_key_interval.value="";
		}
	}
	else if(sec_type == 3) // wpa-eap mode
	{
		get_obj("show_wpa").style.display = "";
		get_obj("eap_setting").style.display = "";
		get_obj("wps_setting").style.display = "none";
	}
}

function chg_wep_type()
{
	var f=get_obj("frm_wep");
	var frm=get_obj("frm");
	var i, j;
	var key_temp1,key_temp2,key_temp3,key_temp4,key_temp;

	get_obj("hex_wep_64").style.display		= "none";
	get_obj("hex_wep_128").style.display	= "none";
	get_obj("asc_wep_64").style.display		= "none";
	get_obj("asc_wep_128").style.display	= "none";
	get_obj("hex_wep_128").style.display = "";

	key_temp1 =	"<?=$cfg_wep1?>";
	key_temp2 =	"<?=$cfg_wep2?>";
	key_temp3 =	"<?=$cfg_wep3?>";
	key_temp4 =	"<?=$cfg_wep4?>";

	if(f.wep_key_len.value=="128")
	{
		for(i=1;i<=4; i++)
		{
			key_temp = eval("key_temp"+i+"");

			if( key_temp.length == "13")
			{
				eval("key_temp"+i+"= ASCIIToHex(key_temp)");
			}
		}
		f.<?=$wep_prefix?>1.value =	key_temp1;
		f.<?=$wep_prefix?>2.value =	key_temp2;
		f.<?=$wep_prefix?>3.value = key_temp3;
		f.<?=$wep_prefix?>4.value =	key_temp4;

	}
	else
	{
		for(i=1;i<=4; i++)
		{
			key_temp = eval("key_temp"+i+"");

			if(key_temp.length == 5)
			{
				eval("key_temp"+i+"= ASCIIToHex(key_temp)");
			}
		}
		f.<?=$wep_prefix?>1.value =	key_temp1;
		f.<?=$wep_prefix?>2.value =	key_temp2;
		f.<?=$wep_prefix?>3.value = key_temp3;
		f.<?=$wep_prefix?>4.value =	key_temp4;
	}
}

function chg_wep_def_key()
{
	var f=get_obj("frm_wep");
}

function append_zero(len)
{
	var x_zero="";
	var i=0;
	for(i=0; i<len;i++)
	{
		x_zero+="0";
	}
	return x_zero;
}

function chg_wep_len_type()
{
	var f=get_obj("frm_wep");

	f.wep_key_value.value ="";
	f.verify_wep_key_value.value ="";
}

function do_cancel()
{
	self.location.href="<?=$MY_NAME?>.php?random_str="+generate_random_str();
}

function on_macclone_enable() // alix zhao,2008.06.17
{
	var f=get_obj("frm_macclone");
	if(f.maccloneenable.checked == false)
	{
	   f.aclmac1.disabled = true;
	   f.aclmac2.disabled = true;
	   f.aclmac3.disabled = true;
	   f.aclmac4.disabled = true;
	   f.aclmac5.disabled = true;
	   f.aclmac6.disabled = true;
	   f.macclonemacsource.disabled = true;
	   f.scan.disabled = true;
	}
	else
	{
	   f.macclonemacsource.disabled = false;
	   Clickmacmode();
	}
}

function Clickmacmode()
{
	var f=get_obj("frm_macclone");
	if(f.macclonemacsource.value == 0)
	{
	   f.aclmac1.disabled = true;
	   f.aclmac2.disabled = true;
	   f.aclmac3.disabled = true;
	   f.aclmac4.disabled = true;
	   f.aclmac5.disabled = true;
	   f.aclmac6.disabled = true;
	   f.scan.disabled = true;
	}
	else 
	{
     f.aclmac1.disabled = false;
	   f.aclmac2.disabled = false;
	   f.aclmac3.disabled = false;
	   f.aclmac4.disabled = false;
	   f.aclmac5.disabled = false;
	   f.aclmac6.disabled = false;
	   f.scan.disabled = false;	
	}
}

function change_wlan_channel()
{
	var f=get_obj("frm");
	
	var band_value;
	if(<?=$cfg_ap_mode?> == 1) //apc mode
	{
		band_value = <?=$cfg_band?>;
		f.channel_width.disabled=true;
	}
	else
	{
		band_value = (f.band[0].checked?0:1);
		f.channel_width.disabled=false;
	}
	
	if((band_value == 0 && (f.channel_g.value==12 || f.channel_g.value==13)) || 
	   (band_value == 1 && (f.channel_a.value==140 || f.channel_a.value==165)))
	{
		f.channel_width.disabled=true;
		f.channel_width.value=0;
	}
}

</script>
<? require("/www/bsc_wlan_print.php");?>

<body onLoad="init();" <?=$G_BODY_ATTR?>>
<form name="final_form" id="final_form" method="post" action="<?=$MY_NAME?>.php">
<input type="hidden" name="ACTION_POST"			value="final">
<input type="hidden" name="f_enable"			value="">
<input type="hidden" name="f_wps_enable"		value="">
<input type="hidden" name="f_wps_lock_enable"	value="">
<input type="hidden" name="f_ssid"				value="">
<input type="hidden" name="f_channel"			value="">
<input type="hidden" name="f_band"				value="">
<input type="hidden" name="f_mode"				value="">
<input type="hidden" name="f_auto_channel"		value="">
<input type="hidden" name="f_transmission_rate"	value="">
<input type="hidden" name="f_channel_width"		value="">
<input type="hidden" name="f_wmm_enable"		value="">
<input type="hidden" name="f_ap_hidden"			value="">
<input type="hidden" name="f_authentication"	value="">
<input type="hidden" name="f_cipher"			value="">
<input type="hidden" name="f_wep_len"			value="">
<input type="hidden" name="f_wep_format"		value="">
<input type="hidden" name="f_wep_def_key"		value="">
<input type="hidden" name="f_wep1"				value="">
<input type="hidden" name="f_wep2"				value="">
<input type="hidden" name="f_wep3"				value="">
<input type="hidden" name="f_wep4"				value="">
<input type="hidden" name="f_wep"				value="">
<input type="hidden" name="f_wpa_psk_type"		value="">
<input type="hidden" name="f_wpa_psk"			value="">
<input type="hidden" name="f_radius_ip1"		value="">
<input type="hidden" name="f_radius_port1"		value="">
<input type="hidden" name="f_radius_secret1"	value="">
<input type="hidden" name="f_grp_key_interval"	value="">
<input type="hidden" name="f_macclone_enable"		value="">
<input type="hidden" name="f_macclone_macaddress" id="f_macclone_macaddress" value="">
<input type="hidden" name="f_macclone_macsource"  id="f_macclone_macsource" value="">
<input type="hidden" name="matMacManual" id="matMacManual" value="">
<!--input type="hidden" name="f_wps_configured"	value=""-->
</form>
<?require("/www/model/__banner.php");?>
<?require("/www/model/__menu_top.php");?>
<table <?=$G_MAIN_TABLE_ATTR?> height="100%">
<tr valign=top>
	<td <?=$G_MENU_TABLE_ATTR?>>
	<?require("/www/model/__menu_left.php");?>
	</td>
	<td id="maincontent">
		<div id="box_header">
		<?
		require($LOCALE_PATH."/dsc/dsc_".$MY_NAME.".php");
		?>
		<script>apply('check()'); echo ("&nbsp;"); cancel('');</script>
		</div>
<!-- ________________________________ Main Content Start ______________________________ -->
		<form name="frm" id="frm" method="post" action="<?=$MY_NAME?>.php" onSubmit="return false;">
		<div class="box">
			<h2><?=$m_title_wireless_setting?></h2>
		<div id="wireless_enable" style="display:none">
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<td height="10"></td>
				<td></td>
			</tr>

			<tr>
				<?=$td1?><b><?=$m_wlan_mode?><?=$symbol?></b></td>
				<?=$td2?><b><?=$m_ap_mode?></b>&nbsp;&nbsp;&nbsp;&nbsp;
<?if($cfg_ap_mode=="0"){echo "<!--\n";}?>
				<input type="button" value="<?=$m_b_scan?>" name="scan" onClick="do_scan()">
<?if($cfg_ap_mode=="0"){echo "-->\n";}?>
				</td>
			</tr>

			<tr>
				<?=$td1?><b><?=$m_enable_wireless?><?=$symbol?></b></td>
				<?=$td2?>
					<input name="enable" id="enable" type="checkbox" onClick="on_check_enable()" value="1">
				</td>
			</tr>
			<tr>
				<?=$td1?><b><?=$m_wlan_name?><?=$symbol?></b></td>
				<?=$td2?>
					<input name="ssid" id="ssid" type="text" size="20" maxlength="32" value="">
					&nbsp;<?=$m_wlan_name_comment?>
				</td>
			</tr>

			<tr>
				<?=$td1?><b><?=$m_band?><?=$symbol?></b></td>
				<?=$td2?>
				<input type=radio name=band value=0 onClick="on_check_bandstatus()"><?=$m_2.4G?>
				<input type=radio name=band value=1 onClick="on_check_bandstatus()"><?=$m_5G?>
				<span id="apc_band_box" name="apc_band_box"><input type="radio" name="apc_band" value=""><?=$m_2.4G?>/<?=$m_5G?></span>
				</td>
			</tr>
			</table>

			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<?=$td1?><b><?=$m_80211_mode?><?=$symbol?></b></td>
				<?=$td2?>
					<div id="get_11a_80211_mode" style="display:none">
						<script>print_11a_80211_mode();</script>
					</div>
					<div id="get_11g_80211_mode" style="display:none">
						<script>print_11g_80211_mode();</script>
					</div>
					<div id="get_apc_80211_mode">
						<select id="apc_80211_mode" disabled="true"><option value="10">Mixed 802.11 abgn</option></select>
					</div>
					</div>
				</td>
			</tr>
			</table>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<?=$td1?><b><?=$m_enable_auto_channel?><?=$symbol?></b></td>
				<?=$td2?>
					<input name="autochann" id="autochann" type="checkbox" onClick="on_check_autochann()" value="1">
				<td>
			</tr>
			</table>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<?=$td1?><b><?=$m_wlan_channel?><?=$symbol?></b></td>
				<?=$td2?>
				<div id="get_11a_channel" style="display:none">
					<select name="channel_a" id="channel_a" onChange="change_wlan_channel()">
						<?require("/www/bsc_wlan_11a_channel.php");?>
					</select>
				</div>
				<div id="get_11g_channel" style="display:none">
					<select name="channel_g" id="channel_g" onChange="change_wlan_channel()">
						<?require("/www/bsc_wlan_11g_channel.php");?>
					</select>
				</div>
				</td>
			</tr>
			</table>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<?=$td1?><b><?=$m_transmission_rate?><?=$symbol?></b></td>
				<?=$td2?>
				<div id="get_11a_transmission_rate" style="display:none">
					<select name="transmission_rate_11a" id="transmission_rate_11a">
						<option value="31"><?=$m_tx_best?></option>
						<script>print_transmission_rate(1);</script>
					</select>
					&nbsp;<?=$m_tx_mbit?>
				</div>
				<div id="get_11b_transmission_rate" style="display:none">
					<select name="transmission_rate_11b" id="transmission_rate_11b">
						<option value="31"><?=$m_tx_best?></option>
						<script>print_transmission_rate(2);</script>
					</select>
					&nbsp;<?=$m_tx_mbit?>
				</div>
				<div id="get_11g_transmission_rate" style="display:none">
					<select name="transmission_rate_11g" id="transmission_rate_11g">
						<option value="31"><?=$m_tx_best?></option>
						<script>print_transmission_rate(3);</script>
					</select>
					&nbsp;<?=$m_tx_mbit?>
				</div>
				<div id="get_11n_transmission_rate" style="display:none">
					<select name="transmission_rate_11n" id="transmission_rate_11n">
						<option value="31"><?=$m_tx_best?></option>
						<!--script>print_transmission_rate(4);</script-->
					</select>
					&nbsp;<?=$m_tx_mbit?>
				</div>
				<div id="get_11na_transmission_rate" style="display:none">
					<select name="transmission_rate_11na" id="transmission_rate_11na">
						<option value="31"><?=$m_tx_best?></option>
						<!--script>print_transmission_rate(4);</script>
						<script>print_transmission_rate(1);</script-->
					</select>
					&nbsp;<?=$m_tx_mbit?>
				</div>
				<div id="get_11gb_transmission_rate" style="display:none">
					<select name="transmission_rate_11gb" id="transmission_rate_11gb">
						<option value="31"><?=$m_tx_best?></option>
						<script>print_transmission_rate(3);</script>
						<script>print_transmission_rate(2);</script>
					</select>
					&nbsp;<?=$m_tx_mbit?>
				</div>
				<div id="get_11ng_transmission_rate" style="display:none">
					<select name="transmission_rate_11ng" id="transmission_rate_11ng">
						<option value="31"><?=$m_tx_best?></option>
						<!--script>print_transmission_rate(4);</script>
						<script>print_transmission_rate(3);</script-->
					</select>
					&nbsp;<?=$m_tx_mbit?>
				</div>
				<div id="get_11ngb_transmission_rate" style="display:none">
					<select name="transmission_rate_11ngb" id="transmission_rate_11ngb">
						<option value="31"><?=$m_tx_best?></option>
						<!--script>print_transmission_rate(4);</script>
						<script>print_transmission_rate(3);</script>
						<script>print_transmission_rate(2);</script-->
					</select>
					&nbsp;<?=$m_tx_mbit?>
				</div>
				</td>
			</tr>
			</table>
			<div id="show_channel_width" style="display:none">
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<?=$td1?><b><?=$m_channel_width?><?=$symbol?></b></td>
				<?=$td2?>
					<select name="channel_width" id="channel_width">
						<option value="0"><?=$m_cw_20?></option>
						<option value="1"><?=$m_cw_auto?></option>
					</select>
				</td>
			</tr>
			</table>
			</div>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<?=$td1?><b><?=$m_visibility_status ?><?=$symbol?></b></td>
				<?=$td2?>
				<input type=radio name=visibility_status value=0 onClick="on_Click_SSID_Status()"><?=$m_visible?>
				<input type=radio name=visibility_status value=1 onClick="on_Click_SSID_Status()"><?=$m_invisible?>
				</td>
			</tr>
			</table>
		</div>
		</div>

		<div class="box" id="show_security_mode" style="display:none">
			<h2><?=$m_title_wireless_security?></h2>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<?=$td1?><b><?=$m_security_mode?><?=$symbol?></b></td>
				<?=$td2?>
				<div id="get_ap_sec" style="display:none">
					<script>print_ap_sec();</script>
				</div>
				<div id="get_apc_sec" style="display:none">
					<script>print_apc_sec();</script>
				</div>
				<div id="get_ap_sec_11n" style="display:none">
					<script>print_ap_sec_11n();</script>
				</div>
				<div id="get_apc_sec_11n" style="display:none">
					<script>print_apc_sec_11n();</script>
				</div>
				</td>
			</tr>
			</table>
		</div>
		</form>

		<!-- ****************************no wep*******************************************-->
		<form name="frm_nowep" id="frm_nowep" method="post" action="<?=$MY_NAME?>.php">
		<input type="hidden" name="ACTION_POST" value="NOWEP">
		</form>

		<!-- **************************** wep  *******************************************-->
		<form name="frm_wep" id="frm_wep" method="post" action="<?=$MY_NAME?>.php">
		<input type="hidden" name="ACTION_POST" value="WEP">
		<div class="box" id="show_wep" style="display:none">
			<h2><?=$m_title_wep?></h2>
			<!--?require($LOCALE_PATH."/bsc_wlan_msg1.php");?-->
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<!--tr>
				<?=$td1?><b><?=$m_wep_key_len?><?=$symbol?></b></td>
				<?=$td2?>
					<select id="wep_key_len" name="wep_key_len" size=1 onChange="chg_wep_type()">
						<option value="64"><?=$m_64bit_hex_wep?></option>
						<option value="128"><?=$m_128bit_hex_wep?></option>
					</select>&nbsp;<?=$m_wep_length_msg?>
				</td>
			</tr-->
			<!--tr>
				<?=$td1?><b><?=$m_key_type?><?=$symbol?></b></td>
				<?=$td2?>
					<select id="wep_key_type_back" name="wep_key_type_back" onChange="chg_wep_type()">
						<option value="2"><?=$m_hex?></option>
						<option value="1"><?=$m_ascii?></option>
					</select>
				</td>
			</tr-->
			<tr>
				<?=$td1?><b><?=$m_wep_key_len?><?=$symbol?></b></td>
				<?=$td2?>
					<select id="wep_key_len_type" name="wep_key_len_type" onChange="chg_wep_len_type()">
						<option value="1"><?=$m_hex_h?></option>
						<option value="2"><?=$m_hex_a?></option>
						<option value="3"><?=$m_ascii_h?></option>
						<option value="4"><?=$m_ascii_a?></option>
					</select>
				</td>
			</tr>

			<tr>
				<?=$td1?><b><?=$m_wep_key_value?><?=$symbol?></b></td>
				<?=$td2?>
					<input name="wep_key_value" id="wep_key_value" type="text" size="26" maxlength="26" value="">
				</td>
			</tr>

			<tr>
				<?=$td1?><b><?=$m_verify_wep_key_value?><?=$symbol?></b></td>
				<?=$td2?>
					<input name="verify_wep_key_value" id="verify_wep_key_value" type="text" size="26" maxlength="26" value="">
				</td>
			</tr>
			</table>
<!--
			<div id="hex_wep_64"	style="display:none"><script>print_keys("hex_wep_64_","10");</script></div>
			<div id="hex_wep_128"	style="display:none"><script>print_keys("hex_wep_128_","26");</script></div>
			<div id="asc_wep_64"	style="display:none"><script>print_keys("asc_wep_64_","5");</script></div>
			<div id="asc_wep_128"	style="display:none"><script>print_keys("asc_wep_128_","13");</script></div>
-->
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<?=$td1?><b><?=$m_default_wep_key?><?=$symbol?></b></td>
				<?=$td2?>
					<select name="wep_def_key" id="wep_def_key" onChange="chg_wep_def_key()">
						<option value="1"><?=$m_wep_key?> 1</option>
						<option value="2"><?=$m_wep_key?> 2</option>
						<option value="3"><?=$m_wep_key?> 3</option>
						<option value="4"><?=$m_wep_key?> 4</option>
					</select>
				</td>
			</tr>

			<tr>
				<?=$td1?><b><?=$m_auth_type?><?=$symbol?></b></td>
				<?=$td2?>
					<select name="auth_type" id="auth_type">
						<option value="0"><?=$m_open?></option>
						<option value="1"><?=$m_shared_key?></option>
					</select>
				</td>
			</tr>
			</table>
		</div>
		</form>

		<!-- **************************** WPA, WPA2, WPA2-auto *********************************-->
		<form name="frm_wpa" id="frm_wpa" method="post" action="<?=$MY_NAME?>.php">
		<input type="hidden" name="ACTION_POST" value="WPA">
		<div class="box" id="show_wpa" style="display:none">
			<h2><?=$m_title_wpa?></h2>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
			<tr>
				<?=$td1?><b><?=$m_wpa_mode?><?=$symbol?></b></td>
				<?=$td2?>
					<select name="wpa_mode" id="wpa_mode">
						<option value="0"><?=$m_wpa_auto?></option>
						<option value="1"><?=$m_wpa2_only?></option>
						<option value="2"><?=$m_wpa_only?></option>
					</select>
				</td>
			</tr>
			<tr>
				<?=$td1?><b><?=$m_cipher_type?><?=$symbol?></b></td>
				<?=$td2?>
					<select name="cipher_type">
					<option value="2"><?=$m_tkip?></option>
					<option value="3"><?=$m_aes?></option>
					<option value="4"><?=$m_cipher_auto?></option>
					</select>
				</td>
			</tr>
			<tr>
				<?=$td1?><b><?=$m_grp_key_interval?><?=$symbol?></b></td>
				<?=$td2?>
					<input type="text" id="grp_key_interval" name="grp_key_interval" size="8" maxlength="7" value="">
					&nbsp;<?=$m_wpa_grp_key_msg?>
				</td>
			</tr>
			</table>
		</div>
		<!-- **************************** PSK *********************************-->
		<div class="box" id="psk_setting" style="display:none">
			<h2><?=$m_title_pre_shared_key?></h2>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
				<tr>
					<?=$td1?><b><?=$m_passphrase?><?=$symbol?><b></td>
					<?=$td2?>
						<input type="text" id="wpapsk1" name="wpapsk1" size="40" maxlength="64" value="">
					</td>
				</tr>
			</table>
		</div>
		<!-- **************************** EAP *********************************-->
		<div class="box" id="eap_setting" style="display:none">
			<h2><?=$m_title_eap?></h2>
			<table cellpadding="1" cellspacing="1" border="0" width="525">
				<!--tr>
					<?=$td1?><b><?=$m_auth_timeout?><?=$symbol?><b></td>
					<?=$td2?>
						<input id="auth_timeout" name="auth_timeout" maxlength=10 size=10 value="">
					&nbsp;<?=$m_auth_timeout_msg?>
					</td>
				</tr-->
				<tr>
					<?=$td1?><b><?=$m_radius1?> <?=$m_ipaddr?><?=$symbol?><b></td>
					<?=$td2?>
						<input id="srv_ip1" name="srv_ip1" maxlength=15 size=15 value="">
					</td>
				</tr>
				<tr>
					<?=$td1?><b><?=$m_radius1?> <?=$m_port?><?=$symbol?><b></td>
					<?=$td2?>
					<input type="text" id="srv_port1" name="srv_port1" size="8" maxlength="5" value="">
					</td>
				</tr>
				<tr>
					<?=$td1?><b><?=$m_radius1?> <?=$m_shared_sec?><?=$symbol?><b></td>
					<?=$td2?>
					<input type="password" id="srv_sec1" name="srv_sec1" size="50" maxlength="64" value="">
					</td>
				</tr>
			</table>
		</div>
		</form>

		<form name="frm_wps" id="frm_wps" method="post" action="<?=$MY_NAME?>.php" onSubmit="return false;">
		<? if ($support_wps==1) { require("/www/bsc_wlan_wps.php"); } ?>
		</form>
	
		<form name="frm_macclone" id="frm_macclone" method="post" action="<?=$MY_NAME?>.php" onSubmit="return false;">
		<div class="box" id="StationMac" style="display:none">
			<h2><?=$m_title_StationMac?></h2>
			<table cellpadding="1" cellspacing="1" border="0" width="525">

			<tr>
				<?=$td1?><b><?=$m_StationMac?><?=$symbol?></b></td>
				<?=$td2?>
				<input name="maccloneenable" id="maccloneenable" type="checkbox" onClick="on_macclone_enable()" value="1" <? if($cfg_macclone_enable =="1"){echo " checked";} ?>>
				</td>
			</tr>
			<tr>
				<?=$td1?><b><?=$m_mac_source?><?=$symbol?></b></td>
				<?=$td2?>
					<select name="macclonemacsource" id="macclonemacsource" onChange="Clickmacmode()">
						<option value="0"><?=$m_macsource_auto?></option>
						<option value="1"><?=$m_macsource_manual?></option>
					</select>
				</td>
			</tr>			
			<tr>
					<?=$td1?><b><?=$m_StationMacManual?><?=$symbol?><b></td>
				    <?=$td2?>
					<input type="hidden" name="tmpmac" id="tmpmac" value="">
<!--                <input type=text name="aclmac1"  id="aclmac1" size=1 maxlength=2  value='' onkeyup= "move_mac(1,aclmac1,aclmac2)">	:				
                    <input type=text name="aclmac2"  id="aclmac2" size=1 maxlength=2  value='' onkeyup= "move_mac(2,aclmac2,aclmac3)">	:				
                    <input type=text name="aclmac3"  id="aclmac3" size=1 maxlength=2  value='' onkeyup= "move_mac(3,aclmac3,aclmac4)">	:			
                    <input type=text name="aclmac4"  id="aclmac4" size=1 maxlength=2  value='' onkeyup= "move_mac(4,aclmac4,aclmac5)">	:				
                    <input type=text name="aclmac5"  id="aclmac5" size=1 maxlength=2  value='' onkeyup= "move_mac(5,aclmac5,aclmac6)">	:
                    <input type=text name="aclmac6"  id="aclmac6" size=1 maxlength=2  value='' onkeyup= "move_mac(6,aclmac6,aclmac6)">					-->
					<script>print_mac("aclmac");</script>
					</td>
			</tr>
			
			<tr>
				<td height="25"></td>
				<td></td>
			</tr>	
						
			<tr>
				<?=$td1?>
				</td>			
				<?=$td2?>&nbsp;&nbsp;&nbsp;
				<input type="button" value="<?=$m_bmat_scan?>" name="scan" id="scan" onClick="do_matscan()">
				</td>
			</tr>
			
			<tr>
				<td height="18"></td>
				<td></td>
			</tr>										


			<tr>
					<?=$td1?><b><b></td>
				    <?=$td2?>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Port&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MAC Address					
					</td>
			</tr>			
				
			<tr>
				<td class='r_tb' width='10' height='20'>
				</td>
				<?=$td2?>
            		<iframe src="mat_survey.php" name="matsite_survey"  width="200" marginwidth="0" height="150" marginheight="0" align="middle" scrolling="auto">
            		</iframe>				
				</td>
				<td width="95">
				</td>								
								
			</tr>
			
			</table>
			
		</div>		
		</form>
		
		
<!-- ________________________________  Main Content End _______________________________ -->
	</td>
	<td <?=$G_HELP_TABLE_ATTR?>><?require($LOCALE_PATH."/help/h_".$MY_NAME.".php");?></td>
</tr>
</table>
<?require("/www/model/__tailer.php");?>
</body>
</html>
