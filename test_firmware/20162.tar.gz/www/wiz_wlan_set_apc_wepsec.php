<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME		="wiz_wlan_set_apc_wepsec";
$MY_MSG_FILE	=$MY_NAME.".php";

$MY_ACTION		="set_apc_wepsec";
$WIZ_PREV		="apc_sec";
$WIZ_NEXT		="apc_done";
/* --------------------------------------------------------------------------- */
if ($ACTION_POST!="")
{
	require("/www/model/__admin_check.php");
	require("/www/__wiz_wlan_action.php");
	$ACTION_POST="";
	require("/www/wiz_wlan_".$WIZ_NEXT.".php");
	exit;
}

/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
/* --------------------------------------------------------------------------- */
// get the variable value from rgdb.
anchor($G_WIZ_PREFIX_WLAN."/wireless");
$db_secret=query("secret");
$db_auth=query("authentication");
$db_kettype=query("full_sec_type");
$db_keysize=query("full_sec_size");

/* --------------------------------------------------------------------------- */
?>

<script>
<?require("/www/md5.js");?>
/* page init functoin */
function init()
{
	var f=get_obj("frm");

	f.secret.value="<?=$db_secret?>";
	select_index(f.wep_key_type,	"<?=$db_kettype?>");
	
	select_index(f.wep_key_type,	"<?=$db_keysize?>");
/*	
	var db_keysize="<?=$db_keysize?>";
	if(db_keysize==128)	f.sec_size[1].checked=true;
	else				f.sec_size[0].checked=true;
*/			
	ChangeMaxLength();
	// init here ...
}
function get_random_char()
{
	var number_list = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	var number = Math.round(Math.random()*62);
	
	return(number_list.substring(number, number + 1));
}
function generate_psk(key)
{
	var i = key.length;
	
	if (key.length < 8)
	{
		for (; i < 8; i++)
		{
			key += get_random_char();
		}
	}
	return key;
}
function create_wep_key128(passpharse, pharse_len)
{
	var pseed2 = "";
	var md5_str = "";
	var count;
	
	
	for(var i = 0; i < 64; i++)
	{
		count = i % pharse_len;
		pseed2 += passpharse.substring(count, count+1);
	}
	
	md5_str = calcMD5(pseed2); 
	
	return md5_str.substring(0, 26).toUpperCase(); 
}

function ChangeMaxLength()
{
	var f=get_obj("frm");
	
    if(f.sec_size.selectedIndex == 0) //64
    {	
    	if(f.wep_key_type.selectedIndex == 0) //HEX
        {

        	f.secret.focus();
			f.secret.maxLength=10;
	    }
	  	else //ASCII
	  	{
	        f.secret.focus();
	        f.secret.maxLength = 5;
	    } 
	}    
	
    if(f.sec_size.selectedIndex == 1) //128
    {	
    	if(f.wep_key_type.selectedIndex == 0)//HEX
        { 
        	f.secret.focus();
			f.secret.maxLength=26;
	    }
	  	else //128
	  	{
	        f.secret.focus();
	        f.secret.maxLength =13;
	    } 
	} 	   
    		
}

function check_key()
{
	var f=get_obj("frm");
	
	if(f.secret.value == "" )
    {
    	alert("<?=$a_no_secret?>");
	    return false;
    }
    
    if(f.wep_key_type.selectedIndex == 0)
    {	
		if(f.sec_size.selectedIndex == 0)//64 bits
    	{	
	    	if(f.secret.value.length!=0)
         	{
            	if(f.secret.value.length!=10)
        	    {
			    	alert("<?=$a_10_hex_secret?>");
          		    f.secret.select();
         	        return false;
         	    }
			    if(!HexCheck2(f.secret.value))
		        {
              	    alert("<?=$a_hex_secret?>");
              	    f.secret.select();
       	            return false;
       	        }       	       
       	    }
	    }

      	if(f.sec_size.selectedIndex == 1)//128 bits
	    {
	  	 	if(f.secret.value.length!=0)
       	    {
        		if(f.secret.value.length!=26)
        	    {
         	    	alert("<?=$a_26_hex_secret?>");
         	        f.secret.select();
        	        return false;
        	    }
          	    if(!HexCheck2(f.secret.value))
         	    {
          	        alert("<?=$a_hex_secret?>");
                    f.secret.select();
       	            return false;
       	        }
            }
	    }	
	}	
	
	if(f.wep_key_type.selectedIndex == 1)
    {	
		if(f.sec_size.selectedIndex == 0)//64 bits
    	{	
	    	if(f.secret.value.length!=0)
         	{
            	if(f.secret.value.length!=5)
        	    {
			    	alert("<?=$a_5_ascii_secret?>");
          		    f.secret.select();
         	        return false;
         	    }     	       
       	    }
	    }

      	if(f.sec_size.selectedIndex == 1)//128 bits
	    {
	  	 	if(f.secret.value.length!=0)
       	    {
        		if(f.secret.value.length!=13)
        	    {
         	    	alert("<?=$a_13_ascii_secret?>");
         	        f.secret.select();
        	        return false;
        	    }
            }
	    }	
		
		if(!ASCIICheck(f.secret.value))
		{
		    alert("<?=$a_ascii_invalid_character?>");
		    return false;
		}	    
	}    
	
	return true;	
}

/* parameter checking */
function check()
{
	var f=get_obj("frm");
	
	//check_key();
	//alert(check_key());
	if(!check_key())
		return false;
	/*
	if(f.secret.value.length < 2)
	{
		alert("<?=$a_invliad_secret?>");
		f.secret.focus();
		return false;
	}
	*/
	f.full_sec_type.value=f.wep_key_type.value;
	f.full_sec_size.value=f.sec_size.value;
	f.full_secret.value=f.secret.value;
	return true;
}
function go_prev()
{
	self.location.href="wiz_wlan.php?TARGET_PAGE=<?=$WIZ_PREV?>";
}
</script>
<body onload="init();" <?=$G_BODY_ATTR?>>
<form name="frm" id="frm" method="post" action="<?=$POST_ACTION?>" OnSubmit="return check();">
<input type="hidden" name="ACTION_POST" value="<?=$MY_ACTION?>">
<input type="hidden" name="TARGET_PAGE" value="<?=$MY_ACTION?>">
<?require("/www/model/__banner.php");?>
<table <?=$G_MAIN_TABLE_ATTR?>>
<tr valign=top>
	<td width=10%></td>
	<td id="maincontent" width=80%>
		<br>
		<div id="box_header">
		<? require($LOCALE_PATH."/dsc/dsc_".$MY_NAME.".php"); ?>
<!-- ________________________________ Main Content Start ______________________________ -->
			<table width=95%>
			<tr>
				<td width=25% class=r_tb><?=$m_key_type?></td>
				<td>
					<select id="wep_key_type" name="wep_key_type" onChange="ChangeMaxLength()">
						<option value="2"><?=$m_hex?></option>
						<option value="1"><?=$m_ascii?></option>
					</select>
					<input type=hidden name="full_sec_type" value="">
				</td>
			</tr>
			<tr>
				<td width=25% class=r_tb><?=$m_wlan_size?></td>
				<td>
					<select id="sec_size" name="sec_size" onChange="ChangeMaxLength()">
						<option value="64"><?=$sec_size_64_dsc?></option>
						<option value="128"><?=$sec_size_128_dsc?></option>
					</select>
					<input type=hidden name="full_sec_size" value="">
				</td>
			</tr>			
			<!--tr>
				<td width=25% class=r_tb><?=$m_wlan_size?>
				<td><input type=radio name="sec_size" value=64 onClick="ChangeMaxLength()">
				<?=$sec_size_64_dsc?>
				<input type=radio name="sec_size" value=128 onClick="ChangeMaxLength()">
				<?=$sec_size_128_dsc?>
				<input type=hidden name="full_sec_size" value="">	
				</td>				
			</tr-->
			
			<tr>
				<td width=40% class=r_tb><?=$m_wlan_password?></td>
				<td><input type=text name=secret maxlength=26 size=25></td>
				<input type=hidden name="full_secret" value="">
			</tr>
			</table>
		<br>
		<center><script>prev("");next("");exit();</script></center>
		<br>
<!-- ________________________________  Main Content End _______________________________ -->
		</div>
		<br>
	</td>
	<td width=10%></td>
</tr>
</table>
<?require("/www/model/__tailer.php");?>
</form>
</body>
</html>
