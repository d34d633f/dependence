<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<link rel="stylesheet" href="/model/router.css" type="text/css">
</head>
<script text="text/script">
function ClickMenu(num)
{
	var Ssid = parent.document.getElementById("ssid");
	var SSIDString = document.getElementById("ck_ssid"+num).value;

	if(Ssid != null)
    {
        Ssid.value = SSIDString;
    }
}
</script>
<body>
<form>
<center>
<?
$ss_border_style = "style=\"border-style:none;\"";
?>
<table cellspacing="0" cellpadding="0" border="1" width="100%" style="position:relative;left:0px;top:0px;z-index:1">
	<tr style="position:fixed;display:block;overflow:block;float:left;">
		<td width="37%" id="TitleBar" <?=$ss_border_style?>>
			<font id="SSTableFont">SSID</font>
		</td>
		<td width="20%" id="TitleBar" <?=$ss_border_style?>>
			<font id="SSTableFont">BSSID</font>
		</td>
		<td width="4%" id="TitleBar" <?=$ss_border_style?>>
			<font id="SSTableFont">CH</font>
		</td>
		<td width="18%" id="TitleBar" <?=$ss_border_style?>>
			<font id="SSTableFont">Security</font>
		</td>
		<td width="8%" id="TitleBar" <?=$ss_border_style?>>
			<font id="SSTableFont">Signal</font>
		</td>
		<td width="14%" id="TitleBar" <?=$ss_border_style?>>
			<font id="SSTableFont">Type</font>
		</td>
		<td width="5%" id="TitleBar" <?=$ss_border_style?>>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</td>
	</tr>
<table>
<table cellspacing="0" cellpadding="0" border="1" width="100%">
	<tr style="table-layout:fixed;">
		<td width="37%">&nbsp;</td>
		<td width="18%">&nbsp;</td>
		<td width="3%">&nbsp;</td>
		<td width="17%">&nbsp;</td>
		<td width="7%">&nbsp;</td>
		<td width="13%">&nbsp;</td>
		<td width="4%">&nbsp;</td>
	</tr>
<?
$tmp = "";
for("/runtime/wireless/apscanlistinfo/apcscan")
{
	$tmp = $@;

	echo "<tr id=\"cHand\">\n";
	echo "<td id=\"show_line\">".get("h","ssid")."</td>\n";
	echo "<td>".query("mac:")."</td>\n";
	echo "<td>".query("chan:")."</td>\n";
	echo "<td>".query("auth:")."</td>\n";
	echo "<td>".query("rssi:".)."%</td>\n";
	echo "<td>".query("type:".)."</td>\n";
	echo "<td><input type=radio name=stable onclick=\"ClickMenu(".$@.")\"></td>\n";
	echo "<input type=\"hidden\" id=\"ck_ssid".$@."\" name=\"ssid\" value=\"".get("h","ssid")."\">\n";
	echo "<input type=\"hidden\" id=\"ck_chan".$@."\" name=\"ch\" value=\"".query("chan:")."\">\n";
	echo "</tr>\n";
}
?>
</table>
</center>
</form>
</body>
</html>
