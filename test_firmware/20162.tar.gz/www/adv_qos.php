<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME		="adv_qos";
$MY_MSG_FILE	=$MY_NAME.".php";
$CATEGORY		="adv";
/* --------------------------------------------------------------------------- */
if ($ACTION_POST!=""|| $rule_del_id!="")
{
	require("/www/model/__admin_check.php");
	echo "<!--\n";
	echo "ACTION_POST=".			$ACTION_POST.			"\n";
	echo "f_qos_enable=".			$f_qos_enable.			"\n";
	echo "f_qos_type=".			$f_qos_type.			"\n";	
	echo "f_AdvanceQod_Enable=".			$f_AdvanceQod_Enable.			"\n";
	echo "f_LanPort_1st=".					$f_LanPort_1st.				"\n";
	echo "f_priority=".				$f_priority.			"\n";
	echo "f_protocol=".				$f_protocol.			"\n";
	echo "f_protocol_select=".		$f_protocol_select.		"\n";
	echo "f_DownlinkTraffic=".		$f_DownlinkTraffic.		"\n";
	echo "f_UplinkTraffic=".		$f_UplinkTraffic.		"\n";
	echo "f_LanPort_1st=".		$f_LanPort_1st.		"\n";
	echo "-->\n";
    anchor("/qos");
		$db_dirty=0;
              $db_typechanged=0;
              $db_enablechanged=0;
		if(query("enable")!=$f_qos_enable)	{$db_enablechanged=1;set("enable",$f_qos_enable); $db_dirty++;}
		if(query("qostype")!=$f_qos_type)	{$db_typechanged=1;set("qostype",$f_qos_type); $db_dirty++;}
		if($f_qos_enable=="1")
		{
		  if($f_qos_type == 1)//when qos type setup as by protocol,alix zhao
		  {
		if(query("bandwidth/downstream")!=$f_DownlinkTraffic)	{set("bandwidth/downstream",$f_DownlinkTraffic); $db_dirty++;}
		if(query("bandwidth/upstream")!=$f_UplinkTraffic)	    {set("bandwidth/upstream",  $f_UplinkTraffic); $db_dirty++;}
		
		if(query("protocol/aui/priority")!=$f_AUI_Priority)	{set("protocol/aui/priority",$f_AUI_Priority); $db_dirty++;}
		if(query("protocol/aui/limit")!=$f_AUIlimit)	{set("protocol/aui/limit",$f_AUIlimit); $db_dirty++;}
		
		if(query("protocol/web/priority")!=$f_web_Priority)	{set("protocol/web/priority",$f_web_Priority); $db_dirty++;}
		if(query("protocol/web/limit")!=$f_weblimit)	{set("protocol/web/limit",$f_weblimit); $db_dirty++;}
		
		if(query("protocol/mail/priority")!=$f_mail_Priority) {set("protocol/mail/priority",$f_mail_Priority); $db_dirty++;}
		if(query("protocol/mail/limit")!=$f_maillimit)	{set("protocol/mail/limit",$f_maillimit); $db_dirty++;}		
		
		if(query("protocol/ftp/priority")!=$f_ftp_Priority)	{set("protocol/ftp/priority",$f_ftp_Priority); $db_dirty++;}
		if(query("protocol/ftp/limit")!=$f_ftplimit)	{set("protocol/ftp/limit",$f_ftplimit); $db_dirty++;}
		
		if(query("protocol/other/priority")!=$f_other_Priority)	{set("protocol/other/priority",$f_other_Priority); $db_dirty++;}
		if(query("protocol/other/limit")!=$f_otherlimit)	{set("protocol/other/limit",$f_otherlimit); $db_dirty++;}
		
		  }
		 else if($f_qos_type == 0)//setup port priority,alix zhao
		 {
		if(query("port/port1priority")!=$f_LanPort_1st)	{set("port/port1priority",$f_LanPort_1st); $db_dirty++;}
		if(query("port/port2priority")!=$f_LanPort_2nd)	{set("port/port2priority",$f_LanPort_2nd); $db_dirty++;}
		if(query("port/port3priority")!=$f_LanPort_3rd)	{set("port/port3priority",$f_LanPort_3rd); $db_dirty++;}
		if(query("port/port4priority")!=$f_LanPort_4th)	{set("port/port4priority",$f_LanPort_4th); $db_dirty++;}
		 } 
		  
	 }


		if($db_dirty > 0)	
		{
		 if($db_typechanged == 1 )
		 	{$SUBMIT_STR="submit WLAN"; } //if switch qos type need re-start wlan module to setting driver paras.harry
               else if($db_enablechanged==1 && $f_qos_type==0)
                     {$SUBMIT_STR="submit WLAN"; } //if switch qos type need re-start wlan module to setting driver paras.harry
		 else
		       { $SUBMIT_STR="submit QOS";}
		}
		else				{$SUBMIT_STR="";}

	$NEXT_PAGE=$MY_NAME;
	if($SUBMIT_STR!="")	{require($G_SAVING_URL);}
	else				{require($G_NO_CHANGED_URL);}
}

/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
require("/www/comm/__js_ip.php");
/* --------------------------------------------------------------------------- */
// get the variable value from rgdb.
anchor("/qos");
$cfg_qos_enable = query("enable");
$cfg_Qos_Type   = query("qostype");


if($cfg_Qos_Type ==){

  set("qostype",0);
 
  set("protocol/aui/priority",0);
  set("protocol/web/priority",2 );
  set("protocol/mail/priority",1);
  set("protocol/ftp/priority",3);
  set("protocol/other/priority",3);
  
  set("port/port1priority",1);
  set("port/port2priority",3);
  set("port/port3priority",5);
  set("port/port4priority",7); 
  
}
$cfg_LanPort_1st = query("port/port1priority");
$cfg_LanPort_2nd = query("port/port2priority");
$cfg_LanPort_3rd = query("port/port3priority");
$cfg_LanPort_4th = query("port/port4priority");

$cfg_DownlinkTraffic = query("bandwidth/downstream");
$cfg_UplinkTraffic = query("bandwidth/upstream");


$cfg_AUI_Priority = query("protocol/aui/priority");
$cfg_AUIlimit = query("protocol/aui/limit");

$cfg_web_Priority = query("protocol/web/priority");
$cfg_weblimit = query("protocol/web/limit");

$cfg_mail_Priority = query("protocol/mail/priority");
$cfg_maillimit = query("protocol/mail/limit");

$cfg_ftp_Priority = query("protocol/ftp/priority");
$cfg_ftplimit = query("protocol/ftp/limit");

$cfg_other_Priority = query("protocol/other/priority");
$cfg_otherlimit = query("protocol/other/limit");
anchor("/trafficmgr");
$cfg_TrafficMgr_enable = query("enable");
if($cfg_TrafficMgr_enable==){
$cfg_TrafficMgr_enable = 0;
}

?>

<script>
/* page init functoin */
function init()
{
	on_check_enable();
	on_change_QosType();
}
function on_change_QosType()
{
	var frm = get_obj("frm");
	get_obj("show_Port_Priority").style.display = "none";
	get_obj("show_AdvanceQos_title").style.display = "none";
	switch (frm.Qos_Type.value)
	{
	case "1":	   
		get_obj("show_AdvanceQos_title").style.display = "";				
		break;
	case "0":
		if(<?=$cfg_TrafficMgr_enable?> == 1 && frm.qos_enable.checked == true){	//alix zhao
	    alert("QOS Type can not be priority by lan port for the reason \r\n that Traffic Manager enabled!");
		frm.Qos_Type.selectedIndex = 1;	
		get_obj("show_AdvanceQos_title").style.display = "";				
		return false;
		}
		get_obj("show_Port_Priority").style.display = "";
		break;
	}
}
function on_check_advQos()
{

	var frm = get_obj("frm");

	if(frm.AdvanceQodEnable.checked == true){
;

	}
	else
	{
;

	}
}
/* parameter checking */
function check()
{
	var f=get_obj("frm");
	var f_final = get_obj("final_form");
	var ip_s, ip_e;

	f_final.f_qos_enable.value	=(f.qos_enable.checked ? 1:0);
	f_final.f_qos_type.value    = f.QOS_Type.value;
	

	if(f_final.f_qos_enable.value == "1" && f_final.f_qos_type.value == 1)//checking priority by protocol,alix
	{
	/*
	if(f.f_DownlinkTraffic.value == "" && f.f_UplinkTraffic.value == "")
	{		
	alert("<?=$a_empty_value_for_speed?>");
	f.f_DownlinkTraffic.select();
	return false;	         
    	}
	*/
	if(f.f_DownlinkTraffic.value != "")	
	{ 
	if(!is_digit(f.f_DownlinkTraffic.value))
	{		
	alert("<?=$a_invalid_value_for_speed?>");
	f.f_DownlinkTraffic.select();
	return false;	         
    	}
	else if(f.f_DownlinkTraffic.value<1024 || f.f_DownlinkTraffic.value>1024*120 || (isNaN(f.f_DownlinkTraffic.value)))
	{
	alert("<?=$a_invalid_value_for_speed?>");
	f.f_DownlinkTraffic.select();
	return false;	
	}
	}
	
	if(f.f_UplinkTraffic.value != "") //Ethernet to wireless speed checking
	{
	if(!is_digit(f.f_UplinkTraffic.value)) 
	{		
	alert("<?=$a_invalid_value_for_speed?>");
	f.f_UplinkTraffic.select();
	return false;	         
    	}
	else if(f.f_UplinkTraffic.value<1024 || f.f_UplinkTraffic.value>1024*120 || (isNaN(f.f_UplinkTraffic.value)))
	{
	alert("<?=$a_invalid_value_for_speed?>");
	f.f_UplinkTraffic.select();
	return false;	
	}	
	}
	
	if(f.AUIlimit.value == "") //AUI limit checking
	{		
	alert("<?=$a_empty_value_for_limit?>");
	f.AUIlimit.select();
	return false;	         
        }
	else if(f.AUIlimit.value<1 || f.AUIlimit.value>100 || (isNaN(f.AUIlimit.value)))
	{
	alert("<?=$a_invalid_value_for_limit?>");
	f.AUIlimit.select();
	return false;	
	}
	
	if(f.weblimit.value == "")	//web limit checking
	{		
	alert("<?=$a_empty_value_for_limit?>");
	f.weblimit.select();
	return false;	         
        }
	else if(f.weblimit.value<1 || f.weblimit.value>100 || (isNaN(f.weblimit.value)))
	{
	alert("<?=$a_invalid_value_for_limit?>");
	f.weblimit.select();
	return false;	
	}

	if(f.maillimit.value == "")	//mail limit ckecking
	{		
	alert("<?=$a_empty_value_for_limit?>");
	f.maillimit.select();
	return false;	         
        }
	else if(f.maillimit.value<1 || f.maillimit.value>100 || (isNaN(f.maillimit.value)))
	{
	alert("<?=$a_invalid_value_for_limit?>");
	f.maillimit.select();
	return false;	
	}

	if(f.ftplimit.value == "")	//ftp limit checking
	{		
	alert("<?=$a_empty_value_for_limit?>");
	f.ftplimit.select();
	return false;	         
        }
	else if(f.ftplimit.value<1 || f.ftplimit.value>100 || (isNaN(f.ftplimit.value)))
	{
	alert("<?=$a_invalid_value_for_limit?>");
	f.ftplimit.select();
	return false;	
	}
	
	if(f.otherlimit.value == "")	//other limit checking 
	{		
	alert("<?=$a_empty_value_for_limit?>");
	f.otherlimit.select();
	return false;	         
        }
	else if(f.otherlimit.value<1 || f.otherlimit.value>100 || (isNaN(f.otherlimit.value)))
	{
	alert("<?=$a_invalid_value_for_limit?>");
	f.otherlimit.select();
	return false;	
	}
	
	f_final.f_DownlinkTraffic.value  = f.f_DownlinkTraffic.value;
	f_final.f_UplinkTraffic.value    = f.f_UplinkTraffic.value;
	
	f_final.f_AUI_Priority.value     = f.AUI_Priority.value;	
	f_final.f_web_Priority.value     = f.web_Priority.value;
	f_final.f_mail_Priority.value    = f.mail_Priority.value;
	f_final.f_ftp_Priority.value     = f.ftp_Priority.value;
	f_final.f_other_Priority.value   = f.other_Priority.value;
	
	f_final.f_AUIlimit.value         = f.AUIlimit.value;
	f_final.f_weblimit.value    	 = f.weblimit.value;
	f_final.f_maillimit.value    	 = f.maillimit.value;
	f_final.f_ftplimit.value    	 = f.ftplimit.value;
	f_final.f_otherlimit.value    	 = f.otherlimit.value;
		
	}
	
	if(f_final.f_qos_enable.value == "1" && f_final.f_qos_type.value == 0){//checking priority by protocol,alix
	f_final.f_LanPort_1st.value    = f.LanPort_1st.value;
	f_final.f_LanPort_2nd.value    = f.LanPort_2nd.value;
	f_final.f_LanPort_3rd.value    = f.LanPort_3rd.value;
	f_final.f_LanPort_4th.value    = f.LanPort_4th.value;
	}

	f_final.submit();
}

/* cancel function */
function do_cancel()
{
	self.location.href="<?=$MY_NAME?>.php?random_str="+generate_random_str();
}

function on_check_enable()
{
	var f=get_obj("frm");
	on_change_QosType();

	if(f.qos_enable.checked == true)
	{
		fields_disabled(f, false);

	}
	else
	{
		fields_disabled(f, true);
		f.qos_enable.disabled=false;
	}
}

</script>
<body onLoad="init();" <?=$G_BODY_ATTR?>>
<form name="final_form" id="final_form" method="post" action="<?=$MY_NAME?>.php">
<input type="hidden" name="ACTION_POST" value="SOMETHING">
<input type="hidden" name="f_qos_enable" value="">
<input type="hidden" name="f_qos_type" value="">
<input type="hidden" name="f_DownlinkTraffic" value="">
<input type="hidden" name="f_UplinkTraffic" value="">
<input type="hidden" name="f_AUI_Priority" value="">
<input type="hidden" name="f_AUIlimit" value="">
<input type="hidden" name="f_web_Priority" value="">
<input type="hidden" name="f_weblimit" value="">
<input type="hidden" name="f_mail_Priority" value="">
<input type="hidden" name="f_maillimit" value="">
<input type="hidden" name="f_ftp_Priority" value="">
<input type="hidden" name="f_ftplimit" value="">
<input type="hidden" name="f_other_Priority" value="">
<input type="hidden" name="f_otherlimit" value="">

<input type="hidden" name="f_LanPort_1st" value="">
<input type="hidden" name="f_LanPort_2nd" value="">
<input type="hidden" name="f_LanPort_3rd" value="">
<input type="hidden" name="f_LanPort_4th" value="">

</form>

<?require("/www/model/__banner.php");?>
<?require("/www/model/__menu_top.php");?>
<table <?=$G_MAIN_TABLE_ATTR?> height="100%">
<tr valign=top>
	<td <?=$G_MENU_TABLE_ATTR?>>
	<?require("/www/model/__menu_left.php");?>
	</td>
	<td id="maincontent">
		<div id="box_header">
		<?
		require($LOCALE_PATH."/dsc/dsc_".$MY_NAME.".php");
		?>
		<script>apply('check()'); echo ("&nbsp;"); cancel('');</script>
		</div>
<!-- ________________________________ Main Content Start ______________________________ -->
		<form name="frm" id="frm" method="post" action="<?=$MY_NAME?>.php" onsubmit="return false;">
		<input type="hidden" name="rule_edit"		value="">
		<div class="box">
			<h2><?=$m_context_title?></h2>
			<table width=525>
			<tr>
				<td class=br_tb width=40%><?=$m_enable?> :</td>
				<td><input name="qos_enable" id="qos_enable" type="checkbox" onClick="on_check_enable();"  value="1" <?if($cfg_qos_enable =="1"){echo " checked";}?>></td>
			</tr>
<!-- alix zhao added for QOS type ,2008.5.7-->
                        <tr>
				<td class=br_tb width=40%><?=$m_QOS_Type?> :</td>
				<td>
				<select name="QOS_Type" id="Qos_Type" onChange="on_change_QosType()">
				<option value="0"<? if ($cfg_Qos_Type==0) {echo " selected";} ?>><?=$m_PriorityByLanPort?></option>
				<option value="1"<? if ($cfg_Qos_Type==1) {echo " selected";} ?>><?=$m_PriorityByProtocol?></option>
				</select>
				</td>
			</tr>
			
			</table>
		</div>
		<div class="box" id="show_Port_Priority" style="display:none">
			<h2><?=$m_context_PortPriority_title?></h2>
			<table width=525>

			<tr>
				<td class=br_tb width=40%><?=$m_LanPort_1st?> :</td>
				<td>
				<select name="LanPort_1st" id="LanPort_1st">
				<option value="7" <? if ($cfg_LanPort_1st==7) {echo " selected";} ?>><?=$m_vo?></option>
				<option value="5" <? if ($cfg_LanPort_1st==5) {echo " selected";} ?>><?=$m_vi?></option>
				<option value="3" <? if ($cfg_LanPort_1st==3) {echo " selected";} ?>><?=$m_be?></option>
				<option value="1" <? if ($cfg_LanPort_1st==1) {echo " selected";} ?>><?=$m_bk?></option>				
				</select>
				</td>
			</tr>
			<tr>
				<td class=br_tb width=35%><?=$m_LanPort_2nd?> :</td>
				<td>
				<select name="LanPort_2nd" id="LanPort_2nd">
				<option value="7" <? if ($cfg_LanPort_2nd==7) {echo " selected";} ?>><?=$m_vo?></option>
				<option value="5" <? if ($cfg_LanPort_2nd==5) {echo " selected";} ?>><?=$m_vi?></option>
				<option value="3" <? if ($cfg_LanPort_2nd==3) {echo " selected";} ?>><?=$m_be?></option>
				<option value="1" <? if ($cfg_LanPort_2nd==1) {echo " selected";} ?>><?=$m_bk?></option>			
				</select>
				</td>
			</tr>
			<tr>
				<td class=br_tb width=35%><?=$m_LanPort_3rd?> :</td>
				<td>
				<select name="LanPort_3rd" id="LanPort_3rd">
				<option value="7" <? if ($cfg_LanPort_3rd==7) {echo " selected";} ?>><?=$m_vo?></option>
				<option value="5" <? if ($cfg_LanPort_3rd==5) {echo " selected";} ?>><?=$m_vi?></option>
				<option value="3" <? if ($cfg_LanPort_3rd==3) {echo " selected";} ?>><?=$m_be?></option>
				<option value="1" <? if ($cfg_LanPort_3rd==1) {echo " selected";} ?>><?=$m_bk?></option>			
				</select>
				</td>
			</tr>
			<tr>
				<td class=br_tb width=35%><?=$m_LanPort_4th?> :</td>
				<td>
				<select name="LanPort_4th" id="LanPort_4th">
				<option value="7" <? if ($cfg_LanPort_4th==7) {echo " selected";} ?>><?=$m_vo?></option>
				<option value="5" <? if ($cfg_LanPort_4th==5) {echo " selected";} ?>><?=$m_vi?></option>
				<option value="3" <? if ($cfg_LanPort_4th==3) {echo " selected";} ?>><?=$m_be?></option>
				<option value="1" <? if ($cfg_LanPort_4th==1) {echo " selected";} ?>><?=$m_bk?></option>			
				</select>
				</td>
			</tr>
			</table>
		</div>		

<!--advance QOS setup parameters   alix -->			
		<div class="box" id="show_AdvanceQos_title" style="display:none">
			<h2><?=$m_context_AdvanceQos_title?></h2>
			<table width=525>
			<!--
			<tr>
				<td class=br_tb width="35%"><?=$m_advanceQos?> :</td>
				<td><input name="AdvanceQod" id="AdvanceQodEnable" type="checkbox" onClick="on_check_advQos();"  value="1" <?if($cfg_AdvanceQod_Enable =="1"){echo " checked";}?>></td>
			</tr>
-->

			<tr>
				<td class=br_tb width=40%><?=$m_UplinkTraffic?> :</td>
				<td><input maxlength=6 name="f_DownlinkTraffic" id="f_DownlinkTraffic" size=6 value="<?=$cfg_DownlinkTraffic?>">kbits/sec 
				<? 
				if($cfg_DownlinkTraffic == ""){ 
				$wlmode = query("/wireless/wlmode");
	      		$bw_11n = query("/wireless/cwmmode");   
				if ($bw_11n=="")    {$bw_11n    ="0";}
	      		if ($wlmode=="3") {
				$UPSTREAM=4196;
				$DOWNSTREAM=4196;
				echo ",default:4196 kbits/sec";			
				}/*b only: 4 Mbps*/
 	      		else if ($wlmode=="1"||$wlmode=="2"||$wlmode=="7") {
				$UPSTREAM=16384;
				$DOWNSTREAM=16384;
				echo ",default:16384 kbits/sec";			
				}/*a/g: 16 Mbps*/
             	else if ($bw_11n=="1") {
				$UPSTREAM=71680;
				$DOWNSTREAM=71680;
				echo ",default:71680 kbits/sec";			
				}/*20/40MHz: 70 Mbps*/
             	else{
				$UPSTREAM=51200;
				$DOWNSTREAM=51200;
				echo ",default:51200 kbits/sec";			
				}/*20/40MHz: 50 Mbps*/				
				}
				?>
				</td>
			</tr>
			<tr>
				<td class=br_tb width=40%><?=$m_DownlinkTraffic?> :</td>
				<td><input maxlength=6 name="f_UplinkTraffic" id="f_UplinkTraffic" size=6 value="<?=$cfg_UplinkTraffic?>">kbits/sec 
				<? 
				if($cfg_DownlinkTraffic == ""){ 
				$wlmode = query("/wireless/wlmode");
	      		$bw_11n = query("/wireless/cwmmode");   
				if ($bw_11n=="")    {$bw_11n    ="0";}
	      		if ($wlmode=="3") {
				echo ",default:4196 kbits/sec";			
				}/*b only: 4 Mbps*/
 	      		else if ($wlmode=="1"||$wlmode=="2"||$wlmode=="7") {
				echo ",default:16384 kbits/sec";			
				}/*a/g: 16 Mbps*/
             	else if ($bw_11n=="1") {
				echo ",default:71680 kbits/sec";			
				}/*20/40MHz: 70 Mbps*/
             	else{
				echo ",default:51200 kbits/sec";			
				}/*20/40MHz: 50 Mbps*/				
				}
				?>
				</td>
			</tr>
                        <tr>
				<td class=br_tb width=40%><?=$m_AUI_Priority?> :</td>
				<td>
				<select name="AUI_Priority" id="AUI_Priority" >
				<option value="0" <? if ($cfg_AUI_Priority==0) {echo " selected";} ?>><?=$m_vo?></option>
				<option value="1" <? if ($cfg_AUI_Priority==1) {echo " selected";} ?>><?=$m_vi?></option>
				<option value="2" <? if ($cfg_AUI_Priority==2) {echo " selected";} ?>><?=$m_be?></option>
				<option value="3" <? if ($cfg_AUI_Priority==3) {echo " selected";} ?>><?=$m_bk?></option>			
				</select>
				<?=$m_PriLimit?> :
				<input maxlength=3 name="AUIlimit" id="AUIlimit" size=3 value="<?=$cfg_AUIlimit?>">%</td>				
			</tr>			
                        <tr>
				<td class=br_tb width=40%><?=$m_web_Priority?> :</td>
				<td>
				<select name="web_Priority" id="web_Priority" >
				<option value="0" <? if ($cfg_web_Priority==0) {echo " selected";} ?>><?=$m_vo?></option>
				<option value="1" <? if ($cfg_web_Priority==1) {echo " selected";} ?>><?=$m_vi?></option>
				<option value="2" <? if ($cfg_web_Priority==2) {echo " selected";} ?>><?=$m_be?></option>
				<option value="3" <? if ($cfg_web_Priority==3) {echo " selected";} ?>><?=$m_bk?></option>			
				</select>
				
				<?=$m_PriLimit?> :
				<input maxlength=3 name="weblimit" id="weblimit" size=3 value="<?=$cfg_weblimit?>">%</td>				
			</tr>		
                        <tr>
				<td class=br_tb width=40%><?=$m_mail_Priority?> :</td>
				<td>
				<select name="mail_Priority" id="mail_Priority" >
				<option value="0" <? if ($cfg_mail_Priority==0) {echo " selected";} ?>><?=$m_vo?></option>
				<option value="1" <? if ($cfg_mail_Priority==1) {echo " selected";} ?>><?=$m_vi?></option>
				<option value="2" <? if ($cfg_mail_Priority==2) {echo " selected";} ?>><?=$m_be?></option>
				<option value="3" <? if ($cfg_mail_Priority==3) {echo " selected";} ?>><?=$m_bk?></option>			
				
				</select>
				
				<?=$m_PriLimit?> :
				<input maxlength=3 name="maillimit" id="maillimit" size=3 value="<?=$cfg_maillimit?>">%</td>				
			</tr>					
                        <tr>
				<td class=br_tb width=40%><?=$m_ftp_Priority?> :</td>
				<td>
				<select name="ftp_Priority" id="ftp_Priority" >
				<option value="0" <? if ($cfg_ftp_Priority==0) {echo " selected";} ?>><?=$m_vo?></option>
				<option value="1" <? if ($cfg_ftp_Priority==1) {echo " selected";} ?>><?=$m_vi?></option>
				<option value="2" <? if ($cfg_ftp_Priority==2) {echo " selected";} ?>><?=$m_be?></option>
				<option value="3" <? if ($cfg_ftp_Priority==3) {echo " selected";} ?>><?=$m_bk?></option>			
				
				</select>
				
				<?=$m_PriLimit?> :
				<input maxlength=3 name="ftplimit" id="ftplimit" size=3 value="<?=$cfg_ftplimit?>">%</td>				
			</tr>		
                        <tr>
				<td class=br_tb width=40%><?=$m_other_Priority?> :</td>
				<td>
				<select name="other_Priority" id="other_Priority" >
				<option value="0" <? if ($cfg_other_Priority==0) {echo " selected";} ?>><?=$m_vo?></option>
				<option value="1" <? if ($cfg_other_Priority==1) {echo " selected";} ?>><?=$m_vi?></option>
				<option value="2" <? if ($cfg_other_Priority==2) {echo " selected";} ?>><?=$m_be?></option>
				<option value="3" <? if ($cfg_other_Priority==3) {echo " selected";} ?>><?=$m_bk?></option>			
				</select>
				<?=$m_PriLimit?> :
				<input maxlength=3 name="otherlimit" id="otherlimit" size=3 value="<?=$cfg_otherlimit?>">%</td>				
			</tr>			
									
			</table>
		</div>


<!-- ________________________________  Main Content End _______________________________ -->
	</td>
	<td <?=$G_HELP_TABLE_ATTR?>><?require($LOCALE_PATH."/help/h_".$MY_NAME.".php");?></td>
</tr>
</table>
<?require("/www/model/__tailer.php");?>
</form>
</body>
</html>
