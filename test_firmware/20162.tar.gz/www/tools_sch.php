<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME		="tools_sch";
$MY_MSG_FILE	=$MY_NAME.".php";
$CATEGORY		="tools";
/* --------------------------------------------------------------------------- */
$router=query("/runtime/router/enable");
if ($router=="1")
{
	if ($ACTION_POST!="" || $del_id!="")
	{
		require("/www/model/__admin_check.php");

		echo "<!--\n";
		echo "sch_name=".$sch_name."\n";
		echo "save_id=".$save_id."\n";
		echo "unique_id=".$unique_id."\n";
		echo "sch_b_day=".$sch_b_day."\n";
		echo "sch_e_day=".$sch_e_day."\n";
		echo "sch_time_start=".$sch_time_start."\n";
		echo "sch_time_end=".$sch_time_end."\n";
		echo "-->\n";

		$adv_port_rules=10;
		// find out which service used this schedule. (search by unique_id)
		// ($unique_id=="" means edit or delete.)
		if($unique_id=="")
		{
			$i=1;
			if($del_id!="")	{	$unique_id=query("/sys/schedule/entry:".$del_id."/id";	}
			else			{	$unique_id=query("/sys/schedule/entry:".$save_id."/id");}

			// adv virtual server,  adv port forwarding
			$id_used=0;
			while($i<=$adv_port_rules)
			{
				$prefix="/nat/vrtsrv/entry:".$i."/";
				if(query($prefix."enable")=="1" && query($prefix."schedule_id")==$unique_id)
				{
					$id_used=1;
					$i=$adv_port_rules;
				}
				$i++;
			}
			if($id_used=="1"){$SUBMIT_STR=$SUBMIT_STR."; submit RG_VSVR";}
		}

		$db_dirty=0;
		if($del_id!="")
		{
			// Only the schedule is not used by other application, then we can delete it.
			if($SUBMIT_STR=="")
			{
				del("/sys/schedule/entry:".$del_id);
				$db_dirty++;
			}
		}
		else
		{
			if($unique_id		!=""){set("/sys/schedule/entry:".$save_id."/id",$unique_id);$db_dirty++;}
			anchor("/sys/schedule/entry:".$save_id);
			if(query("name")		!=$sch_name)		{set("name",		$sch_name);			$db_dirty++;}
			if(query("beginday")	!=$sch_b_day)		{set("beginday",	$sch_b_day);		$db_dirty++;}
			if(query("endday")		!=$sch_e_day)		{set("endday",		$sch_e_day);		$db_dirty++;}
			if(query("begintime")	!=$sch_time_start)	{set("begintime",	$sch_time_start);	$db_dirty++;}
			if(query("endtime")		!=$sch_time_end)	{set("endtime",		$sch_time_end);		$db_dirty++;}
		}
		if($db_dirty>0 && $SUBMIT_STR==""){$SUBMIT_STR=";";}
		$NEXT_PAGE=$MY_NAME;
		if($db_dirty>0)	{require($G_SAVING_URL);}
		else			{require($G_NO_CHANGED_URL);}
	}
}
/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
echo "<script>\n";
require("/www/comm/__js_select.php");
echo "</script>\n";
/* --------------------------------------------------------------------------- */
// get the variable value from rgdb.

/* --------------------------------------------------------------------------- */
?>

<script>
var used_sch=[''<?
for("/nat/vrtsrv/entry")
{
	$uni_id=query("uniqueid");
	if($uni_id!="" && $uni_id!="0"){echo ",'".$uni_id."'";}
}
?>];
var sch_list=[['index','uniqueid','name','begintime','endtime','beginday','endday']<?
$sch_num=0;
for("/sys/schedule/entry")
{
	$sch_num++;
	echo ",\n	['".$@."','".query("id")."','".query("name")."','".query("begintime")."','".query("endtime")."','".query("beginday")."','".query("endday")."']";
}
?>];
/* page init functoin */
function init()
{
	var f=get_obj("frm");
<?
if($edit_id=="")
{
	$save_id=1;
	$unique_id=0;
	for("/sys/schedule/entry")
	{
		$save_id++;
		if(query("id")>$unique_id){$unique_id=query("id");}
	}
	$unique_id++;
}
else
{
	$save_id=$edit_id;
	anchor("/sys/schedule/entry:".$edit_id);
	echo "f.sch_name.value=\"";	get("j","name"); echo "\";\n";
	
	$b_day=query("beginday");
	$e_day=query("endday");
	$div_day=$e_day-$b_day;
	if($div_day==6)
	{
		echo "f.week_or_days.checked=true;\n";
		echo "display_fields('week');\n";
	}
	else
	{
		echo "select_index(f.begin_day,'".$b_day."');\n";
		echo "select_index(f.end_day,'".$e_day."');\n";
	}
	$begintime=query("begintime");
	$endtime=query("endtime");
	if($begintime=="00:00" && $endtime=="23:59")
	{
		echo "f.all_day.checked=true;\n";
		echo "display_fields('time');\n";
	}
	if($begintime!="")
	{
		if($endtime==""){$endtime="00:00";}
		echo "fill_time_fields('".$begintime."','".$endtime."');\n";
	}
}
if($router!="1"){echo "fields_disabled(f,true);\n";}
?>
}
function fill_time_fields(begintime,endtime)
{
	var f=get_obj("frm");
	var tmp_time, hr, am_pm;
	tmp_time=begintime.split(":");
	hr=decstr2int(tmp_time[0]);
	if(hr>12)	{am_pm="pm";	hr-=12;	}
	else		{am_pm="am";			}
	select_index(f.s_am_pm, am_pm);
	f.s_hr.value=(hr==0?"00":hr);
	f.s_min.value=(tmp_time[1]==""?"00":tmp_time[1]);

	tmp_time=endtime.split(":");
	hr=decstr2int(tmp_time[0]);
	if(hr>12)	{am_pm="pm";	hr-=12;	}
	else		{am_pm="am";			}
	select_index(f.e_am_pm, am_pm);
	f.e_hr.value=(hr==0?"00":hr);
	f.e_min.value=(tmp_time[1]==""?"00":tmp_time[1]);
}
/* parameter checking */
function check()
{
	var f=get_obj("frm");
	if(is_blank(f.sch_name.value)==true)
	{
		alert("<?=$a_invalid_sch_name?>");
		f.sch_name.focus();
		return false;
	}
	if(f.week_or_days.checked)	{f.sch_b_day.value="0";					f.sch_e_day.value="6";	}
	else						{f.sch_b_day.value=f.begin_day.value;	f.sch_e_day.value=f.end_day.value;	}
	if(f.all_day.checked==false)
	{
		var s_hr_s, s_hr_e, s_pm_min, e_hr_s, e_hr_e, e_pm_min, s_time, e_time, s_def, e_def;
		if(f.s_am_pm.value=="pm"){s_hr_s=1;s_hr_e=12; s_pm_min=720;s_def="12";}else{s_hr_s=0;s_hr_e=11;s_pm_min=0;s_def="00";}
		if(f.e_am_pm.value=="pm"){e_hr_s=1;e_hr_e=12; e_pm_min=720;e_def="12";}else{e_hr_s=0;e_hr_e=11;e_pm_min=0;e_def="00";}

		if(!is_in_range(f.s_hr.value,s_hr_s,s_hr_e)){alert("<?=$a_invalid_time?>"); field_select(f.s_hr,s_def);	return false;}
		if(!is_in_range(f.s_min.value,0,59))		{alert("<?=$a_invalid_time?>"); field_select(f.s_min,"00");	return false;}
		
		if(!is_in_range(f.e_hr.value,e_hr_s,e_hr_e)){alert("<?=$a_invalid_time?>"); field_select(f.e_hr,e_def);	return false;}
		if(!is_in_range(f.e_min.value,0,59))		{alert("<?=$a_invalid_time?>"); field_select(f.e_min,"00");	return false;}
		
		s_time =  decstr2int(f.s_hr.value)*60 +		decstr2int(f.s_min.value)+s_pm_min;
		e_time = (decstr2int(f.e_hr.value)%12)*60 + decstr2int(f.e_min.value)+e_pm_min;
		if(s_time>=e_time){alert("<?=$a_invalid_start_time?>");	f.s_hr.select();	return false;}
		
		f.sch_time_start.value = (decstr2int(f.s_hr.value)+decstr2int(s_def));
		if(f.sch_time_start.value<10)	f.sch_time_start.value ="0"+f.sch_time_start.value;
		if(f.s_min.value.length==1)	f.s_min.value="0"+f.s_min.value;
		
		f.sch_time_end.value = (decstr2int(f.e_hr.value)+decstr2int(e_def));
		if(f.sch_time_end.value<10)	f.sch_time_end.value ="0"+f.sch_time_end.value;
		if(f.e_min.value.length==1)	f.e_min.value="0"+f.e_min.value;

		f.sch_time_start.value		= f.sch_time_start.value+":"+f.s_min.value;
		f.sch_time_end.value		= f.sch_time_end.value+":"+f.e_min.value;
	}
	else
	{
		f.sch_time_start.value="00:00";
		f.sch_time_end.value="23:59";
	}
	var div_day=0;
	div_day =decstr2int(f.sch_e_day.value)-decstr2int(f.sch_b_day.value);
	div_day2=decstr2int(f.sch_b_day.value)-decstr2int(f.sch_e_day.value);
	if((f.week_or_days.checked==true || div_day==6 || div_day2==1) && f.sch_time_start.value=="00:00" && f.sch_time_end.value=="23:59")
	{
		alert("<?=$a_invalid_schedule?>");
		return false;
	}
	
	for(i=1; i <= <?=$sch_num?>; i++)
	{
		if("<?=$edit_id?>"!=sch_list[i][0])
		{
			if(f.sch_name.value==sch_list[i][2])
			{
				alert("<?=$a_same_name_record?>");
				f.sch_name.select();
				return false;
			}
			if(f.sch_b_day.value==sch_list[i][5]			&& f.sch_e_day.value==sch_list[i][6]
				&& f.sch_time_start.value==sch_list[i][3]	&& f.sch_time_end.value==sch_list[i][4])
			{
				alert("<?=$a_same_time_record?>");
				f.s_hr.select();
				return false;
			}
		}
	}
	f.save_id.value="<?=$save_id?>";
	f.unique_id.value="<?=$unique_id?>";
	return true;
}
/* cancel function */
function do_cancel()
{
	self.location.href="<?=$MY_NAME?>.php?random_str="+generate_random_str();
}
function display_day_fields()
{
	var f=get_obj("frm");
	if(f.week_or_days.checked)	dis=true;
	else						dis=false;
	f.begin_day.disabled = f.end_day.disabled = dis;
}
function display_time_fields()
{
	var f=get_obj("frm");
	if(f.all_day.checked)	dis=true;
	else					dis=false;
	f.s_hr.disabled=f.s_min.disabled=f.s_am_pm.disabled=dis;
	f.e_hr.disabled=f.e_min.disabled=f.e_am_pm.disabled=dis;

}
function display_fields(from)
{
	var f=get_obj("frm");
	if(from=="week")
	{
		if(f.week_or_days.checked)	{f.all_day.disabled=true;		f.all_day.checked=false;}
		else						{f.all_day.disabled=false;}
	}
	else if(from=="time")
	{
		if(f.all_day.checked)		{f.week_or_days.disabled=true;	f.week_or_days.checked=false;}
		else						{f.week_or_days.disabled=false;}
	}
	display_day_fields();
	display_time_fields();
}
function print_del(id)
{
	var str="";
	var used=false;
	for(i=1;i<used_sch.length; i++)
	{
		if(sch_list[id][1]==used_sch[i])	used=true;
	}
	if(used)	str="<img src='/pic/delete_g.jpg'>";
	else		str="<a href='javascript:del_confirm(\""+id+"\")'><img src='/pic/delete.jpg' border=0></a>";
	document.write(str);
}
function del_confirm(id)
{
	if(confirm("<?=$a_del_confirm?>")==false) return;
	self.location.href="<?=$MY_NAME?>.php?del_id="+id;
}
</script>
<body onload="init();" <?=$G_BODY_ATTR?>>
<form name="frm" id="frm" method="post" action="<?=$MY_NAME?>.php" onsubmit="return check();";>

<input type="hidden" name="ACTION_POST"		value="1">
<input type="hidden" name="sch_b_day"		value="">
<input type="hidden" name="sch_e_day"		value="">
<input type="hidden" name="sch_time_start"	value="">
<input type="hidden" name="sch_time_end"	value="">
<input type="hidden" name="save_id"			value="">
<input type="hidden" name="unique_id"		value="">

<?require("/www/model/__banner.php");?>
<?require("/www/model/__menu_top.php");?>
<table <?=$G_MAIN_TABLE_ATTR?> height="100%">
<tr valign=top>
	<td <?=$G_MENU_TABLE_ATTR?>>
	<?require("/www/model/__menu_left.php");?>
	</td>
	<td id="maincontent">
		<div id="box_header">
		<?
		require($LOCALE_PATH."/dsc/dsc_".$MY_NAME.".php");
		echo $G_APPLY_CANEL_BUTTON;
		?>
		</div>
<!-- ________________________________ Main Content Start ______________________________ -->
		<?$m_colon="&nbsp;:&nbsp;";?>
		<div class="box">
			<h2><?=$m_add_sch_title?></h2>
			<table>
			<tr>
				<td width=30% class=br_tb><?=$m_name?><?=$m_colon?></td>
				<td><input type="text" name="sch_name" size="20" maxlength="16"></td>
			</tr>
			<tr>
				<td class=br_tb><?=$m_days?><?=$m_colon?></td>
				<td><input type="checkbox" name="week_or_days" value="week" onclick="display_fields('week')"><?=$m_all_week?>&nbsp;</td>
			</tr>
			<tr>
				<td></td>
				<td><script>print_week("begin_day");echo(" <?=$m_to?> ");print_week("end_day");</script></td>
			</tr>
			<tr>
				<td class=br_tb><?=$m_all_day?><?=$m_colon?></td>
				<td><input type="checkbox" name="all_day" onclick="display_fields('time')"></td>
			</tr>
			<tr>
				<td class=br_tb><?=$m_s_time?><?=$m_colon?></td>
				<td>
				<input type="text" name="s_hr" size="2" maxlength="2"><?=$m_colon?>
				<input type="text" name="s_min" size="2" maxlength="2">
				<script>print_am("s_am_pm");</script>
				<?=$m_time_dsc?>
				</td>
			</tr>
			<tr>
				<td class=br_tb><?=$m_e_time?><?=$m_colon?></td>
				<td>
				<input type="text" name="e_hr" size="2" maxlength="2"><?=$m_colon?>
				<input type="text" name="e_min" size="2" maxlength="2">
				<script>print_am("e_am_pm");</script>
				<?=$m_time_dsc?>
				</td>
			</tr>
			</table>
		</div>

		<div class="box">
			<h2><?=$m_lst_sch_title?></h2>
			<table width=96%>
			<tr>
				<td class=bc_tb width=30%><?=$m_name?></td>
				<td class=bc_tb width=40%><?=$m_days?></td>
				<td class=bc_tb width=20%><?=$m_time_frame?></td>
				<td class=bc_tb width=10%></td>
			</tr>
			<?
			for("/sys/schedule/entry")
			{
				$name=query("name");
				$day_num=0;
				$0=$m_sun;	$1=$m_mon;	$2=$m_tue;	$3=$m_wed;	$4=$m_thu;	$5=$m_fri;	$6=$m_sat;
				$b_day		=query("beginday");
				$e_day		=query("endday");
				$begintime	=query("begintime");
				$endtime	=query("endtime");
				$div_day=$e_day-$b_day;
				if($div_day==6)	{$q_day=$m_all_week;}
				else			{$q_day=$$b_day." ~ ".$$e_day;}
				if($begintime=="00:00" && $endtime=="23:59")	{$q_time=$m_all_day;}
				else											{$q_time=$begintime." ~ ".$endtime;}
				$td_h="<td class=c_tb>";
				$td_rh="<td class=r_tb>";
				$td_t="</td>";
				if($edit_id==$@){echo "<tr bgcolor=yellow>\n";}
				else {echo "<tr>\n";}
				echo $td_h.$name.$td_t."\n";
				echo $td_h.$q_day.$td_t."\n";
				echo $td_h.$q_time.$td_t."\n";
				if($router=="1")
				{
					echo $td_rh."<a href='".$MY_NAME.".php?edit_id=".$@."'><img src='/pic/edit.jpg' border=0></a>&nbsp;";
					echo "<script>print_del('".$@."');</script>".$td_t."\n";
				}
//				echo "<a href='".$MY_NAME.".php?del_id='".$@."'>".$m_del."</a>".$td_t."\n";
				echo "</tr>\n";
			}
			?>
			</table>
		</div>
<!-- ________________________________  Main Content End _______________________________ -->
	</td>
	<td <?=$G_HELP_TABLE_ATTR?>><?require($LOCALE_PATH."/help/h_".$MY_NAME.".php");?></td>
</tr>
</table>
<?require("/www/model/__tailer.php");?>
</form>
</body>
</html>
