<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME		="wiz_wlan_apc_set_ssid";
$MY_MSG_FILE	=$MY_NAME.".php";
$MY_ACTION		="apc_set_ssid";
$WIZ_PREV		= "configuration";
/*$WIZ_NEXT		="1_set_ssid";*/
/* --------------------------------------------------------------------------- */

if($ACTION_POST!="")
{
	require("/www/model/__admin_check.php");
	require("/www/__wiz_wlan_action.php");

	$ACTION_POST="";
	echo "<script>self.location.href=\"wiz_wlan.php?TARGET_PAGE=".$WIZ_NEXT."\"</script>";
	exit;
}
/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
/* --------------------------------------------------------------------------- */
$db_ssid_path=$G_WIZ_PREFIX_WLAN."/wireless/ssid";
$db_ssid=get("j",$db_ssid_path);
?>
<script>
/* page init functoin */
function init()
{
	var f=get_obj("frm");
	f.ssid.value="<?=$db_ssid?>";
	/*
	f.band[1].checked=true;
	on_check_bandstatus();
	*/
}
/* parameter checking */
function check()
{
	var f=get_obj("frm");

	if(is_blank(f.ssid.value)==true)
	{
		alert("<?=$a_empty_ssid?>");
		f.ssid.focus();
		return false;
	}

	if(first_blank(f.ssid.value))
	{
		alert("<?=$a_first_blank_ssid?>");
		f.ssid.select();
		return false;
	}
	
	if(strchk_unicode(f.ssid.value)==true)
	{
		alert("<?=$a_invalid_ssid?>");
		f.ssid.select();
		return false;
	}
/*	
	f.final_band.value			=(f.band[0].checked?0:1);
	
	if(f.final_band.value == 0)
		f.final_channel.value = f.channel_g.value;
	else if(f.final_band.value == 1)
		f.final_channel.value = f.channel_a.value;		
*/
}

function go_prev()
{
	self.location.href="wiz_wlan.php?TARGET_PAGE=<?=$WIZ_PREV?>";
}

function do_scan()
{
	var f=get_obj("frm")
	var str="";
	
	f.f_scan_value.value="1";
	str="/wiz_wlan_site_survey.xgi?";
	str+=exe_str("submit SCAN");
	self.location.href=str;
}

function on_check_bandstatus()
{
	var f=get_obj("frm")
	
	get_obj("get_11a_channel").style.display = "none";	
	get_obj("get_11g_channel").style.display = "none";		
	
	if(f.band[1].checked)
	{
		get_obj("get_11a_channel").style.display = "";	
		f.channel_a.disabled = true;
	}
	else
	{	
		get_obj("get_11g_channel").style.display = "";	
		f.channel_g.disabled = true;
	}
	
	f.channel.disabled = true;
}



</script>
<body onload="init();" <?=$G_BODY_ATTR?>>
<form name="frm" id="frm" method="post" action="<?=$POST_ACTION?>" onsubmit="return check();">
<input type="hidden" name="ACTION_POST" value="<?=$MY_ACTION?>">
<input type="hidden" name="TARGET_PAGE" value="<?=$MY_ACTION?>">
<input type="hidden" name="f_scan_value"		value="">
<input type=hidden name="final_band" value="">
<input type=hidden name="final_channel" value="">
<?require("/www/model/__banner.php");?>
<table <?=$G_MAIN_TABLE_ATTR?>>
<tr valign=top>
	<td width=10%></td>
	<td id="maincontent" width=80%>
		<br>
		<div id="box_header">
		<? require($LOCALE_PATH."/dsc/dsc_".$MY_NAME.".php"); ?>
<!-- ________________________________ Main Content Start ______________________________ -->
		<table align="center">
		<tr>
			<td class="r_tb"><?=$m_ssid?></td>
			<td class="l_tb">
				<input type=text id=ssid name=ssid size=20 maxlength=32 value="">
				<td><input type="button" value="<?=$m_b_scan?>" name="scan" onclick="do_scan()"></td>
			</td>
		</tr>
		<!--tr>
			<td class=r_tb width=40% height=30><?=$m_band?></td>
			<td>
				<input type=radio name=band value=0 onclick="on_check_bandstatus()"><?=$m_2.4G?>
				<input type=radio name=band value=1 onclick="on_check_bandstatus()"><?=$m_5G?>
			</td>
		</tr>
		<tr>
			<td class=r_tb width=40% height=30><?=$m_wlan_channel?></td>
			<td>
				<div id="get_11a_channel" style="display:none">
					<select name="channel_a" id="channel_a">
						<?require("/www/bsc_wlan_11a_channel.php");?>
					</select>
				</div>
				<div id="get_11g_channel" style="display:none">
					<select name="channel_g" id="channel_g">
						<?require("/www/bsc_wlan_11g_channel.php");?>	
					</select>		
				</div>	
			</td>	
		</tr-->
		
		</table>
		<!--table align="center">
			<tr>
				<td class=r_tb></td>
				<td><input type="button" value="<?=$m_b_scan?>" name="scan" onclick="do_scan()"></td>
			</tr>
			<tr>
				<td>
					<table border="1" cellspacing="3">
						<tr>
							<td width="23">
								&nbsp;
							</td>	
							<td width="50" id="TitleBar">
								<font id="SSTableFont">Type</font>
							</td>								
							<td width="30" id="TitleBar">
								<font id="SSTableFont">CH</font>
							</td>	
							<td width="50" id="TitleBar">
								<font id="SSTableFont">Signal</font>
							</td>								
							<td width="100" id="TitleBar">
								<font id="SSTableFont">BSSID</font>
							</td>	
							<td width="70" id="TitleBar">
								<font id="SSTableFont">Security</font>
							</td>	
							<td width="100" id="TitleBar">
								<font id="SSTableFont">SSID</font>
							</td>	
						</tr>
					</table>	
				</td>
			</tr>	
			<tr>
				<td>
            		<iframe src="wiz_site_survey.php" name="site_survey" width="495" marginwidth="0" height="150" marginheight="0" align="middle" scrolling="auto">
            		</iframe>
            	</td>
            </tr>																																																				
			</table-->	
		<br>
		<center><script>prev("");next("");exit();</script></center>
		<br>
<!-- ________________________________  Main Content End _______________________________ -->
		</div>
		<br>
	</td>
	<td width=10%></td>
</tr>
</table>
<?require("/www/model/__tailer.php");?>
</form>
</body>
</html>
