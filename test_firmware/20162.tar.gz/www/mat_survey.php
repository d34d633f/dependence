<html>
<head>	
<link rel="stylesheet" href="/model/router.css" type="text/css">
</head>
<script text="text/script">
function ClickMenu(num)
{

	var matMacManual = parent.document.getElementById("matMacManual");
	var macString = document.getElementById("ck_mac"+num).value;
	if(matMacManual != null)
    {
        matMacManual.value = macString;
    }
	parent.document.getElementById("aclmac1").value = matMacManual.value.charAt(0)+matMacManual.value.charAt(1);
	parent.document.getElementById("aclmac2").value = matMacManual.value.charAt(3)+matMacManual.value.charAt(4);
	parent.document.getElementById("aclmac3").value = matMacManual.value.charAt(6)+matMacManual.value.charAt(7);
	parent.document.getElementById("aclmac4").value = matMacManual.value.charAt(9)+matMacManual.value.charAt(10);
	parent.document.getElementById("aclmac5").value = matMacManual.value.charAt(12)+matMacManual.value.charAt(13);		
	parent.document.getElementById("aclmac6").value = matMacManual.value.charAt(15)+matMacManual.value.charAt(16);
		
}


</script>
<body>
<form>
<table>
<?
$tmp = "";

for("/runtime/stats/mat_client")
{
	$tmp = $@;
	$phyportnum = query("port:");
	if($phyportnum == 1){
		$phyportnum = 4;
		}
	else if($phyportnum == 2){
		$phyportnum = 3;
		}
	else if($phyportnum == 3){
		$phyportnum = 2;
		}
	else if($phyportnum == 4){
		$phyportnum = 1;
		}
	echo "<tr>\n";
	echo "<td  width='30' height='20'><input type=radio name=stable id=\"ck_stable".$@."\" onclick=\"ClickMenu(".$@.")\"></td>\n";	
	echo "<td  width=\"30\">".$phyportnum."</td>\n";
	echo "<input type=\"hidden\" id=\"ck_port".$@."\" name=\"port\" value=\"".$phyportnum."\">\n";
	echo "<td  width=\"120\">".query("mac:")."</td>\n";
	echo "<input type=\"hidden\" id=\"ck_mac".$@."\" name=\"mac\" value=\"".query("mac:")."\">\n";
	echo "</tr>\n";
}
?>
</table>
</form>
</body>
</html>