#!/bin/sh
iwpriv ra0 set ResetCounter=1
exit 0
