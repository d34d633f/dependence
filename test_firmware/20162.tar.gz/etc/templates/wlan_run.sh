#!/bin/sh
echo [$0] $1 ... > /dev/console
TROOT="/etc/templates"
case "$1" in
start|restart)
	[ -f /var/run/wlan_stop.sh ] && sh /var/run/wlan_stop.sh > /dev/console
	rgdb -s /web/display/matscan 0     
  rgdb -A $TROOT/wifi/wlan_run.php -V generate_start=0 > /var/run/wlan_stop.sh
	rgdb -A $TROOT/wifi/wlan_run.php -V generate_start=1 > /var/run/wlan_start.sh
	sh /var/run/wlan_start.sh > /dev/console
	sh /etc/templates/qos.sh restart > /dev/console
	sh /etc/templates/trafficmgr.sh restart > /dev/console
	;;
stop)
	if [ -f /var/run/wlan_stop.sh ]; then
		sh /var/run/wlan_stop.sh > /dev/console
		rm -f /var/run/wlan_stop.sh
	fi
	;;
*)
	echo "usage: wlan.sh {start|stop|restart}" > /dev/console
	;;
esac
