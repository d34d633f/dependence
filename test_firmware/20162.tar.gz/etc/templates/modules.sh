#!/bin/sh
case "$1" in
insmod)
	insmod /lib/modules/ip_conntrack_proto_esp_m.o
	insmod /lib/modules/ip_conntrack_ike_m.o
	insmod /lib/modules/ip_conntrack_esp_m.o
	insmod /lib/modules/ip_nat_proto_esp_m.o
	insmod /lib/modules/ip_nat_ike_m.o
	insmod /lib/modules/ip_nat_esp_m.o
	;;
rmmod)
	rmmod ip_nat_esp_m
	rmmod ip_nat_ike_m
	rmmod ip_nat_proto_esp_m
	rmmod ip_conntrack_esp_m
	rmmod ip_conntrack_ike_m
	rmmod ip_conntrack_proto_esp_m
	;;
esac
