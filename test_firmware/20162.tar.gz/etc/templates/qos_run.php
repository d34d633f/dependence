#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");

/* detect interface */
$WANDEV = query("/runtime/layout/wanif");
$WLANDEV = query("/runtime/layout/wlanif");
echo "echo -n Interface is wanif=".$WANDEV." wlanif=".$WLANDEV." \n";
if ( $WANDEV=="" || $WLANDEV=="" ){ echo "echo ... Error!!! \n";exit; }else{ echo "echo ... OK \n"; }

/* tc debug */
$TC="echo tc";
$TC="tc";
$K=kbps;
$K=kbit;

$VCONFIG="vconfig";
$VCONFIG_DEV="eth0";

/* main */
if ($generate_start==1)
{
	echo "echo Start QOS system ... \n";

	$wlan_enable = query("/wireless/enable");
	$wlanapmode = query("/wireless/ap_mode");
	//if ($wlan_enable != "1" || $wlanapmode != "0")
	if ($wlan_enable != "1") /* enable in bridge mode */
	{ echo "echo QOS is disabled, because WLAN setting. \n";exit; }
	
	/*----------------------------------------------------------------------------*/
	$QOS_ENABLE  = query("/qos/enable");
	$qostype = query("/qos/qostype");
/*
	if ( $QOS_ENABLE!=1||$qostype!=0){ 

		$PORTPRISTAT =1;//("/runtime/stats/qos/portpristat");
	 	if($PORTPRISTAT==1) {
			echo "brctl delif br0 eth0.1 \n";
			echo "brctl delif br0 eth0.2 \n";
			echo "brctl delif br0 eth0.3 \n";
			echo "brctl delif br0 eth0.4 \n";
			echo "ifconfig eth0.1 down\n";
			echo "ifconfig eth0.2 down\n";
			echo "ifconfig eth0.3 down\n";
			echo "ifconfig eth0.4 down\n";
			
			echo $VCONFIG." rem eth0.1\n";
			echo $VCONFIG." rem eth0.2\n";
			echo $VCONFIG." rem eth0.3\n";
			echo $VCONFIG." rem eth0.4\n";
      
			echo "ifconfig eth0 down \n";
			echo "initportpri -i 0 \n";
			echo "sleep 3 \n";
			echo "ifconfig eth0 up \n";
			echo "brctl addif br0 eth0 \n";
			echo "rgdb -i -s /runtime/stats/qos/portpristat 0\n";
		}
	}
*/

	/*-- qos by protocol --*/
	if($qostype == 1){

		/* process node */
		//$QOS_ENABLE  = query("/qos/enable");
		if ( $QOS_ENABLE!=1 ){ echo "echo QOS is disabled. \n";exit; }	
		$SET_UPSTREAM    = query("/qos/bandwidth/upstream");
		$SET_DOWNSTREAM  = query("/qos/bandwidth/downstream");
		//if ( $SET_DOWNSTREAM==0 || $SET_DOWNSTREAM=="" ){ $SET_DOWNSTREAM=102400; }
		//if ( $SET_UPSTREAM==0   || $SET_UPSTREAM==""   ){ $SET_UPSTREAM=102400; }

		/*--------------Set up QoS bandwidth for different wireless mode-------------*/

		$wlmode	= query("/wireless/wlmode");
		$bw_11n	= query("/wireless/cwmmode");	if ($bw_11n=="")	{$bw_11n	="0";}
		if ($wlmode=="3")
			{$UPSTREAM=4196;$DOWNSTREAM=4196;}/*b only: 4 Mbps*/
		else if ($wlmode=="1"||$wlmode=="2"||$wlmode=="7")
			{$UPSTREAM=16384;$DOWNSTREAM=16384;}/*a/g: 16 Mbps*/
		else if ($bw_11n=="1")
			{$UPSTREAM=71680;$DOWNSTREAM=71680;}/*20/40MHz: 70 Mbps*/
		else
			{$UPSTREAM=51200;$DOWNSTREAM=51200;}/*20/40MHz: 50 Mbps*/

		if($SET_UPSTREAM!=0 && $SET_UPSTREAM!="" )
			{$UPSTREAM = $SET_UPSTREAM;}
		if($SET_DOWNSTREAM!=0 && $SET_DOWNSTREAM!="" )
    		{$DOWNSTREAM = $SET_DOWNSTREAM;}

		echo "echo QOS=".$QOS_ENABLE." UPSTREAM=".$UPSTREAM." DOWNSTREAM=".$DOWNSTREAM." \n";
		/*---------------------------------------------------------------------------------*/

		$PRIO_ALL	= $UPSTREAM ;

		$ack_max	= query("/qos/protocol/aui/limit");
		if($ack_max == "" || $ack_max > 100){ $ack_max = 100; }
		$ack_prio	= query("/qos/protocol/aui/priority");
		if($ack_prio == "" ){ $ack_prio = 3; }

		$web_max	= query("/qos/protocol/web/limit");
		if($web_max == "" || $web_max > 100){ $web_max = 100; }
		$web_prio	= query("/qos/protocol/web/priority");
		if($web_prio == "" ){ $web_prio = 3; }

		$mail_max	= query("/qos/protocol/mail/limit");
		if($mail_max == "" || $mail_max > 100){ $mail_max = 100; }
		$mail_prio	= query("/qos/protocol/mail/priority");
		if($mail_prio == "" ){ $mail_prio = 3; }

		$ftp_max	= query("/qos/protocol/ftp/limit");
		if($ftp_max == "" || $ftp_max > 100){ $ftp_max = 100; }
		$ftp_prio	= query("/qos/protocol/ftp/priority");
		if($ftp_prio == "" ){ $ftp_prio = 3; }

		$other_max	= query("/qos/protocol/other/limit");
		if($other_max == "" || $other_max > 100){ $other_max = 100; }
		$other_prio	= query("/qos/protocol/other/priority");
		if($other_prio == "" ){ $other_prio = 3; }

		$percent	= 4 - $ack_prio;
		$ACK_MIN	= $PRIO_ALL * 5 * $percent / 100 ;
		$ACK_MAX	= $PRIO_ALL * $ack_max / 100 ;
		if($ACK_MIN > $ACK_MAX){ $ACK_MIN = $ACK_MAX; }
		if($ACK_MIN == 0){ $ACK_MIN = 1; }
		if($ACK_MAX == 0){ $ACK_MAX = 1; }

		$percent	= 4 - $web_prio;
		$WEB_MIN	= $PRIO_ALL * 5 * $percent / 100 ;
		$WEB_MAX	= $PRIO_ALL * $web_max / 100 ;
		if($WEB_MIN > $WEB_MAX){ $WEB_MIN = $WEB_MAX; }
		if($WEB_MIN == 0){ $WEB_MIN = 1; }
		if($WEB_MAX == 0){ $WEB_MAX = 1; }

		$percent	= 4 - $mail_prio;
		$MAIL_MIN	= $PRIO_ALL * 5 * $percent / 100 ;
		$MAIL_MAX	= $PRIO_ALL * $mail_max / 100 ;
		if($MAIL_MIN > $MAIL_MAX){ $MAIL_MIN = $MAIL_MAX; }
		if($MAIL_MIN == 0){ $MAIL_MIN = 1; }
		if($MAIL_MAX == 0){ $MAIL_MAX = 1; }

		$percent	= 4 - $ftp_prio;
		$FTP_MIN	= $PRIO_ALL * 5 * $percent / 100 ;
		$FTP_MAX	= $PRIO_ALL * $ftp_max / 100 ;
		if($FTP_MIN > $FTP_MAX){ $FTP_MIN = $FTP_MAX; }
		if($FTP_MIN == 0){ $FTP_MIN = 1; }
		if($FTP_MAX == 0){ $FTP_MAX = 1; }

		$percent	= 4 - $other_prio;
		$OTHER_MIN	= $PRIO_ALL * 5 * $percent / 100 ;
		$OTHER_MAX	= $PRIO_ALL * $other_max / 100 ;
		if($OTHER_MIN > $OTHER_MAX){ $OTHER_MIN = $OTHER_MAX; }
		if($OTHER_MIN == 0){ $OTHER_MIN = 1; }
		if($OTHER_MAX == 0){ $OTHER_MAX = 1; }

		/* dispatch packet to 'other' queue default */
		echo $TC." qdisc add dev ".$WANDEV." handle 1: root htb default 15 \n";

		//echo $TC." class add dev ".$WANDEV." parent 1:0 classid 1:1 htb rate ".$PRIO_ALL.$K." ceil ".$PRIO_ALL.$K." burst 100k cburst 100k \n";
		echo $TC." class add dev ".$WANDEV." parent 1:0 classid 1:1 htb rate ".$PRIO_ALL.$K." ceil ".$PRIO_ALL.$K." \n";

		echo $TC." class add dev ".$WANDEV." parent 1:1 classid 1:11 htb prio ".$ack_prio."  rate ".$ACK_MIN.$K." ceil ".$ACK_MAX.$K." \n";
		echo $TC." class add dev ".$WANDEV." parent 1:1 classid 1:12 htb prio ".$web_prio."  rate ".$WEB_MIN.$K." ceil ".$WEB_MAX.$K." \n";
		echo $TC." class add dev ".$WANDEV." parent 1:1 classid 1:13 htb prio ".$mail_prio."  rate ".$MAIL_MIN.$K." ceil ".$MAIL_MAX.$K." \n";
		echo $TC." class add dev ".$WANDEV." parent 1:1 classid 1:14 htb prio ".$ftp_prio."  rate ".$FTP_MIN.$K." ceil ".$FTP_MAX.$K." \n";
		echo $TC." class add dev ".$WANDEV." parent 1:1 classid 1:15 htb prio ".$other_prio."  rate ".$OTHER_MIN.$K." ceil ".$OTHER_MAX.$K." \n";

		echo $TC." qdisc add dev ".$WANDEV." parent 1:11 handle 110: pfifo \n";
		echo $TC." qdisc add dev ".$WANDEV." parent 1:12 handle 120: pfifo \n";
		echo $TC." qdisc add dev ".$WANDEV." parent 1:13 handle 130: pfifo \n";
		echo $TC." qdisc add dev ".$WANDEV." parent 1:14 handle 140: pfifo \n";
		echo $TC." qdisc add dev ".$WANDEV." parent 1:15 handle 150: pfifo \n";


		//$PRIO_ALL=$downlink ;
		$PRIO_ALL=$DOWNSTREAM ;

		$percent	= 4 - $ack_prio;
		$ACK_MIN	= $PRIO_ALL * 5 * $percent / 100 ;
		$ACK_MAX	= $PRIO_ALL * $ack_max / 100 ;
		if($ACK_MIN > $ACK_MAX){ $ACK_MIN = $ACK_MAX; }
		if($ACK_MIN == 0){ $ACK_MIN = 1; }
		if($ACK_MAX == 0){ $ACK_MAX = 1; }

		$percent	= 4 - $web_prio;
		$WEB_MIN	= $PRIO_ALL * 5 * $percent / 100 ;
		$WEB_MAX	= $PRIO_ALL * $web_max / 100 ;
		if($WEB_MIN > $WEB_MAX){ $WEB_MIN = $WEB_MAX; }
		if($WEB_MIN == 0){ $WEB_MIN = 1; }
		if($WEB_MAX == 0){ $WEB_MAX = 1; }

		$percent	= 4 - $mail_prio;
		$MAIL_MIN	= $PRIO_ALL * 5 * $percent / 100 ;
		$MAIL_MAX	= $PRIO_ALL * $mail_max / 100 ;
		if($MAIL_MIN > $MAIL_MAX){ $MAIL_MIN = $MAIL_MAX; }
		if($MAIL_MIN == 0){ $MAIL_MIN = 1; }
		if($MAIL_MAX == 0){ $MAIL_MAX = 1; }

		$percent	= 4 - $ftp_prio;
		$FTP_MIN	= $PRIO_ALL * 5 * $percent / 100 ;
		$FTP_MAX	= $PRIO_ALL * $ftp_max / 100 ;
		if($FTP_MIN > $FTP_MAX){ $FTP_MIN = $FTP_MAX; }
		if($FTP_MIN == 0){ $FTP_MIN = 1; }
		if($FTP_MAX == 0){ $FTP_MAX = 1; }

		$percent	= 4 - $other_prio;
		$OTHER_MIN	= $PRIO_ALL * 5 * $percent / 100 ;
		$OTHER_MAX	= $PRIO_ALL * $other_max / 100 ;
		if($OTHER_MIN > $OTHER_MAX){ $OTHER_MIN = $OTHER_MAX; }
		if($OTHER_MIN == 0){ $OTHER_MIN = 1; }
		if($OTHER_MAX == 0){ $OTHER_MAX = 1; }

		/* dispatch packet to 'other' queue default */
		echo $TC." qdisc add dev ".$WLANDEV." handle 2: root htb default 15 \n";

		//echo $TC." class add dev ".$WLANDEV." parent 2:0 classid 2:1 htb rate ".$PRIO_ALL.$K." ceil ".$PRIO_ALL.$K." burst 100k cburst 100k \n";
		echo $TC." class add dev ".$WLANDEV." parent 2:0 classid 2:1 htb rate ".$PRIO_ALL.$K." ceil ".$PRIO_ALL.$K." \n";

		echo $TC." class add dev ".$WLANDEV." parent 2:1 classid 2:11 htb prio ".$ack_prio."  rate ".$ACK_MIN.$K." ceil ".$ACK_MAX.$K." \n";
		echo $TC." class add dev ".$WLANDEV." parent 2:1 classid 2:12 htb prio ".$web_prio."  rate ".$WEB_MIN.$K." ceil ".$WEB_MAX.$K." \n";
		echo $TC." class add dev ".$WLANDEV." parent 2:1 classid 2:13 htb prio ".$mail_prio."  rate ".$MAIL_MIN.$K." ceil ".$MAIL_MAX.$K." \n";
		echo $TC." class add dev ".$WLANDEV." parent 2:1 classid 2:14 htb prio ".$ftp_prio."  rate ".$FTP_MIN.$K." ceil ".$FTP_MAX.$K." \n";
		echo $TC." class add dev ".$WLANDEV." parent 2:1 classid 2:15 htb prio ".$other_prio."  rate ".$OTHER_MIN.$K." ceil ".$OTHER_MAX.$K." \n";

		echo $TC." qdisc add dev ".$WLANDEV." parent 2:11 handle 110: pfifo \n";
		echo $TC." qdisc add dev ".$WLANDEV." parent 2:12 handle 120: pfifo \n";
		echo $TC." qdisc add dev ".$WLANDEV." parent 2:13 handle 130: pfifo \n";
		echo $TC." qdisc add dev ".$WLANDEV." parent 2:14 handle 140: pfifo \n";
		echo $TC." qdisc add dev ".$WLANDEV." parent 2:15 handle 150: pfifo \n";

	    /*Classifiers*/

		/* adv qos rule */
		/* ack/dhcp/dns/icmp */
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match ip protocol 6 0xff match u8 0x05 0x0f at 0 match u16 0x0000 0xffc0 at 2 match u8 0x10 0xff at 33 flowid 1:11\n";
	
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match u8 0x01 0xff at 9 flowid 1:11\n";
	
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match ip protocol 17 0xff match ip sport 67 0 flowid 1:11\n";
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match ip protocol 17 0xff match ip dport 67 0 flowid 1:11\n";
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match ip protocol 17 0xff match ip sport 546 0 flowid 1:11\n";
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match ip protocol 17 0xff match ip dport 546 0 flowid 1:11\n";
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match ip protocol 17 0xff match ip sport 68 0 flowid 1:11\n";
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match ip protocol 17 0xff match ip dport 68 0 flowid 1:11\n";
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match ip protocol 17 0xff match ip sport 547 0 flowid 1:11\n";
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match ip protocol 17 0xff match ip dport 547 0 flowid 1:11\n";
	
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match ip sport 53 0 flowid 1:11\n";
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 300 u32 match ip dport 53 0 flowid 1:11\n";
	
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match ip protocol 6 0xff match u8 0x05 0x0f at 0 match u16 0x0000 0xffc0 at 2 match u8 0x10 0xff at 33 flowid 2:11\n";
	
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match u8 0x01 0xff at 9 flowid 2:11\n";
	
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match ip protocol 17 0xff match ip sport 67 0 flowid 2:11\n";
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match ip protocol 17 0xff match ip dport 67 0 flowid 2:11\n";
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match ip protocol 17 0xff match ip sport 546 0 flowid 2:11\n";
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match ip protocol 17 0xff match ip dport 546 0 flowid 2:11\n";
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match ip protocol 17 0xff match ip sport 68 0 flowid 2:11\n";
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match ip protocol 17 0xff match ip dport 68 0 flowid 2:11\n";
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match ip protocol 17 0xff match ip sport 547 0 flowid 2:11\n";
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match ip protocol 17 0xff match ip dport 547 0 flowid 2:11\n";
	
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match ip sport 53 0 flowid 2:11\n";
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 300 u32 match ip dport 53 0 flowid 2:11\n";
	
		/* web traffic (port 80 443 3128 8080) */
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 210 u32 match ip protocol 6 0xff match ip sport 80 0 flowid 1:12\n";
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 210 u32 match ip protocol 6 0xff match ip dport 80 0 flowid 1:12\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 210 u32 match ip protocol 6 0xff match ip sport 8080 0 flowid 1:12\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 210 u32 match ip protocol 6 0xff match ip dport 8080 0 flowid 1:12\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 210 u32 match ip protocol 6 0xff match ip sport 443 0 flowid 1:12\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 210 u32 match ip protocol 6 0xff match ip dport 443 0 flowid 1:12\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 210 u32 match ip protocol 6 0xff match ip sport 3128 0 flowid 1:12\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 210 u32 match ip protocol 6 0xff match ip dport 3128 0 flowid 1:12\n";
	
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 210 u32 match ip protocol 6 0xff match ip sport 80 0 flowid 2:12\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 210 u32 match ip protocol 6 0xff match ip dport 80 0 flowid 2:12\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 210 u32 match ip protocol 6 0xff match ip sport 8080 0 flowid 2:12\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 210 u32 match ip protocol 6 0xff match ip dport 8080 0 flowid 2:12\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 210 u32 match ip protocol 6 0xff match ip sport 443 0 flowid 2:12\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 210 u32 match ip protocol 6 0xff match ip dport 443 0 flowid 2:12\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 210 u32 match ip protocol 6 0xff match ip sport 3128 0 flowid 2:12\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 210 u32 match ip protocol 6 0xff match ip dport 3128 0 flowid 2:12\n";
	
		/* mail traffic (port 25 110 465 995) */
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 220 u32 match ip protocol 6 0xff match ip sport 25 0 flowid 1:13\n";
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 220 u32 match ip protocol 6 0xff match ip dport 25 0 flowid 1:13\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 220 u32 match ip protocol 6 0xff match ip sport 110 0 flowid 1:13\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 220 u32 match ip protocol 6 0xff match ip dport 110 0 flowid 1:13\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 220 u32 match ip protocol 6 0xff match ip sport 465 0 flowid 1:13\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 220 u32 match ip protocol 6 0xff match ip dport 465 0 flowid 1:13\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 220 u32 match ip protocol 6 0xff match ip sport 995 0 flowid 1:13\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 220 u32 match ip protocol 6 0xff match ip dport 995 0 flowid 1:13\n";
	
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 220 u32 match ip protocol 6 0xff match ip sport 25 0 flowid 2:13\n";
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 220 u32 match ip protocol 6 0xff match ip dport 25 0 flowid 2:13\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 220 u32 match ip protocol 6 0xff match ip sport 110 0 flowid 2:13\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 220 u32 match ip protocol 6 0xff match ip dport 110 0 flowid 2:13\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 220 u32 match ip protocol 6 0xff match ip sport 465 0 flowid 2:13\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 220 u32 match ip protocol 6 0xff match ip dport 465 0 flowid 2:13\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 220 u32 match ip protocol 6 0xff match ip sport 995 0 flowid 2:13\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 220 u32 match ip protocol 6 0xff match ip dport 995 0 flowid 2:13\n";
	
		/* ftp traffic (port 20 21) not dynamic port! */
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 230 u32 match ip protocol 6 0xff match ip sport 20 0 flowid 1:14\n";
		echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 230 u32 match ip protocol 6 0xff match ip dport 20 0 flowid 1:14\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 230 u32 match ip protocol 6 0xff match ip sport 21 0 flowid 1:14\n";
    	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 230 u32 match ip protocol 6 0xff match ip dport 21 0 flowid 1:14\n";
	
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 230 u32 match ip protocol 6 0xff match ip sport 20 0 flowid 2:14\n";
		echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 230 u32 match ip protocol 6 0xff match ip dport 20 0 flowid 2:14\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 230 u32 match ip protocol 6 0xff match ip sport 21 0 flowid 2:14\n";
    	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 230 u32 match ip protocol 6 0xff match ip dport 21 0 flowid 2:14\n";
	
		/* default dispatch to other traffic */
	}
	else /* priority by port */
	{
		if ( $QOS_ENABLE!=1 ){ echo "echo QOS is disabled. \n";exit; }	

		$PORTPRISTAT =0;//query("/runtime/stats/qos/portpristat");
	 	if($PORTPRISTAT==1) { exit; }
     	// echo "echo Enable Priority base on Port... ".$PORTPRISTAT."\n";
   
		$lan1priority= query("/qos/port/port1priority");
		$lan2priority= query("/qos/port/port2priority");
		$lan3priority= query("/qos/port/port3priority");
		$lan4priority= query("/qos/port/port4priority");
		if($lan1priority==""){$lan1priority="1"; }
		if($lan2priority==""){$lan2priority="3"; }
		if($lan3priority==""){$lan3priority="5"; }
		if($lan4priority==""){$lan4priority="7"; }
		echo $VCONFIG." add eth0 1\n";
		echo $VCONFIG." add eth0 2\n";
		echo $VCONFIG." add eth0 3\n";
		echo $VCONFIG." add eth0 4\n";
		echo "ifconfig eth0.1 up\n";
		echo "ifconfig eth0.2 up\n";
		echo "ifconfig eth0.3 up\n";
		echo "ifconfig eth0.4 up\n";
		echo $VCONFIG." set_ingress_map ".$VCONFIG_DEV.".1 ".$lan1priority." ".$lan1priority." \n";
		echo $VCONFIG." set_ingress_map ".$VCONFIG_DEV.".2 ".$lan2priority." ".$lan2priority." \n";
		echo $VCONFIG." set_ingress_map ".$VCONFIG_DEV.".3 ".$lan3priority." ".$lan3priority." \n";
		echo $VCONFIG." set_ingress_map ".$VCONFIG_DEV.".4 ".$lan4priority." ".$lan4priority." \n";

		echo $VCONFIG." set_egress_map eth0.1 0 ".$lan1priority." \n";
		echo $VCONFIG." set_egress_map eth0.2 0 ".$lan2priority." \n";
		echo $VCONFIG." set_egress_map eth0.3 0 ".$lan3priority."  \n";
		echo $VCONFIG." set_egress_map eth0.4 0 ".$lan4priority." \n";
       
		echo "brctl delif br0 eth0\n";
		echo "ifconfig eth0 down \n";       
		echo  "initportpri -i ".$lan1priority.$lan2priority.$lan3priority.$lan4priority." \n";
		//echo  "sleep 5 \n";
		echo  "sleep 1 \n";
     
		// echo "ifconfig br0 up \n";
		echo "ifconfig eth0 up \n";
		echo "brctl delif br0 eth0.1 \n";
		echo "brctl delif br0 eth0.2 \n";
		echo "brctl delif br0 eth0.3 \n";
		echo "brctl delif br0 eth0.4 \n";
		echo "brctl delif br0 ra0 \n";
		echo "brctl addif br0 eth0.1 \n";
		echo "brctl addif br0 eth0.2 \n";
		echo "brctl addif br0 eth0.3 \n";
		echo "brctl addif br0 eth0.4 \n";
		echo "brctl addif br0 ra0 \n";
		echo  "rgdb -i -s /runtime/stats/qos/portpristat 1\n";
    
		exit;
	}

}
else
{
	echo "echo Stop QOS system ... \n";

	echo .$TC." qdisc del dev ".$WANDEV." root \n";
	echo .$TC." qdisc del dev ".$WLANDEV." root \n";

	//ELBOX_PROGS_PRIV_RT2860V2_PRIORITYBYPORT
	$PORTPRISTAT =1;//query("/runtime/stats/qos/portpristat");
	if($PORTPRISTAT==1) {
		echo "brctl delif br0 eth0.1 \n";
		echo "brctl delif br0 eth0.2 \n";
		echo "brctl delif br0 eth0.3 \n";
		echo "brctl delif br0 eth0.4 \n";
      
		echo "ifconfig eth0.1 down\n";
		echo "ifconfig eth0.2 down\n";
		echo "ifconfig eth0.3 down\n";
		echo "ifconfig eth0.4 down\n";
     
		echo $VCONFIG." rem eth0.1\n";
		echo $VCONFIG." rem eth0.2\n";
		echo $VCONFIG." rem eth0.3\n";
		echo $VCONFIG." rem eth0.4\n";
       
		echo "ifconfig eth0 down \n";
		echo  "initportpri -i 0 \n";
		echo  "sleep 3 \n";
		echo "ifconfig eth0 up \n";
		echo "brctl delif br0 ra0 \n";
		echo "brctl addif br0 eth0 \n";
		echo "brctl addif br0 ra0 \n";
		echo "echo enable > /proc/net/br_igmp_ap_br0 \n";
		echo "echo setwl ra0 > /proc/net/br_igmp_ap_br0 \n";
		echo  "rgdb -i -s /runtime/stats/qos/portpristat 0\n";
		/* echo "/etc/templates/wlan.sh restart \n";*/
		//ELBOX_PROGS_PRIV_RT2860V2_PRIORITYBYPORT end
	}

	exit;
}

?>
