#!/bin/sh 
echo [$0] ... > /dev/console
APMODE=`rgdb -g /wireless/ap_mode`
if [ "$APMODE" = "1" ]; then
iwlist ra0 scanning
sleep 1
else
iwpriv ra0 set SiteSurvey=1
sleep 7
iwpriv ra0 get_site_survey
fi
