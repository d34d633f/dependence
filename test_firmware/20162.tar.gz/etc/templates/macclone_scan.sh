#!/bin/sh 
echo [$0] ... > /dev/console
  brctl scanlanmacs br0
  rgdb -s /web/display/matscan  1
sleep 1
