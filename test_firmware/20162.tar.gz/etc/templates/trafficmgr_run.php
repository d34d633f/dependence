#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");

/* detect interface */
$WANDEV = query("/runtime/layout/tc_wanif");
$WLANDEV = query("/runtime/layout/tc_wlanif");
echo "echo -n Interface is wanif=".$WANDEV." wlanif=".$WLANDEV." \n";
if ( $WANDEV=="" || $WLANDEV=="" ){ echo "echo ... Error!!! \n";exit; }else{ echo "echo ... OK \n"; }

$TC="tc";
$K=kbit;

$create_eth2wlan = "/var/run/create_eth2wlan";
$create_wlan2eth = "/var/run/create_wlan2eth";
$tm_eth2wlan = "/var/run/tm_eth2wlan";
$tm_wlan2eth = "/var/run/tm_wlan2eth";

/* main */
if ($generate_start==1)
{
	echo "echo Start traffic manager system ... \n";
	
	/* process node */
	$ENABLE  = query("/trafficmgr/enable");
	if ( $ENABLE!=1 )
	{ 
		echo "echo traffic manager is disabled. \n";
		echo "rmmod tcdev \n";
		exit;
	}	

	$wlan_enable = query("/wireless/enable");
	$wlanapmode = query("/wireless/ap_mode");
	if ($wlan_enable != "1" || $wlanapmode != "0")
	{
		echo "echo Traffic manager is disabled, because WLAN setting. \n";
		echo "rmmod tcdev \n";
		exit;
	}

	$qosenable = query("/qos/enable");
	$qostype = query("/qos/qostype");
	if ($qosenable == 1 && $qostype == 0)
	{
		echo "echo Traffic manager is disabled, because QOS setting. \n";
		echo "rmmod tcdev \n";
		exit;
	}

	/* load virtual device */
	echo "insmod /lib/modules/tcdev.o \n";
	echo "ifconfig ".$WANDEV." up \n";
	echo "ifconfig ".$WLANDEV." up \n";

	/*--------------Set up bandwidth for different wireless mode----------------------*/
	$wlmode	= query("/wireless/wlmode");
	$bw_11n	=query("/wireless/cwmmode");	if ($bw_11n=="")	{$bw_11n	="0";}
	if ($wlmode=="3")
	{$LINK=4196;}/*b only: 4 Mbps*/
	else if ($wlmode=="1"||$wlmode=="2"||$wlmode=="7")
	{$LINK=16384;}/*a/g: 16 Mbps*/
	else if ($bw_11n=="1")
	{$LINK=716800;}/*20/40MHz: 70 Mbps*/
	else
	{$LINK=51200;}/*20/40MHz: 50 Mbps*/
	/*------------------------------------------------------------------------------------*/

	$WLAN2ETH  = query("/trafficmgr/wirelesstoeth0");
	$ETH2WLAN  = query("/trafficmgr/eth0towireless");
	if ( $WLAN2ETH==0 || $WLAN2ETH=="" ){ $WLAN2ETH=$LINK;	}
	if ( $ETH2WLAN==0 || $ETH2WLAN=="" ){ $ETH2WLAN=$LINK;	}

	echo "echo enable=".$ENABLE." WLAN2ETH=".$WLAN2ETH." ETH2WLAN=".$ETH2WLAN." \n";

	/*---------------Create queues------------------------------------------------------*/
	echo $TC." qdisc add dev ".$WANDEV." root handle 1: htb default 165 ;\n";
	echo $TC." class add dev ".$WANDEV." parent 1: classid 1:1 htb rate ".$WLAN2ETH.$K." ceil ".$WLAN2ETH.$K." burst 250k cburst 250k ;\n";

	echo $TC." qdisc add dev ".$WLANDEV." root handle 2: htb default 165 ;\n";
	echo $TC." class add dev ".$WLANDEV." parent 2: classid 2:1 htb rate ".$ETH2WLAN.$K." ceil ".$ETH2WLAN.$K." burst 250 cburst 250k ;\n";
	
	$index = 0;
	$all_wlan2eth = 0;
	$all_eth2wlan = 0;

	echo "rm ".$create_eth2wlan." ".$create_wlan2eth." ".$tm_eth2wlan." ".$tm_wlan2eth." \n ";

	/*---- query rules into 2 temp file /var/run/tm_eth2wlan tm_wlan2eth ----*/
	for("/trafficmgr/rule/index")
	{
		$index++;
		//if($index > 64){exit;}
		if($index <= 64) // not support break ...
		{

		$wlan2eth=query("/trafficmgr/rule/index:".$index."/wirelesstoeth0");
		$eth2wlan=query("/trafficmgr/rule/index:".$index."/eth0towireless");
		$ip=query("/trafficmgr/rule/index:".$index."/clientip");
		$mac=query("/trafficmgr/rule/index:".$index."/clientmac");
		
		if($ip == "" && $mac == ""){exit;} /* error */
		if($wlan2eth == "" && $eth2wlan == ""){exit;} /* error */

		/* client's limit can't larger than whole limit */
		if($wlan2eth >= $WLAN2ETH) { $wlan2eth = $WLAN2ETH; }
		if($eth2wlan >= $ETH2WLAN) { $eth2wlan = $ETH2WLAN; }
		
		if($ip == 0 || $ip == "")
		{
			$ip = "0.0.0.0";
		}
		if($mac == 0 || $mac == "")
		{
			$mac = "00:00:00:00:00:00";
		}

		if($wlan2eth != 0 && $wlan2eth != "")
		{
			echo "echo ".$wlan2eth."	".$ip."	".$mac."	 >> ".$tm_wlan2eth." \n";
			$all_wlan2eth += $wlan2eth;
		}
		
		if($eth2wlan != 0 && $eth2wlan != "")
		{
			echo "echo ".$eth2wlan."	".$ip."	".$mac." >> ".$tm_eth2wlan." \n";
			$all_eth2wlan += $eth2wlan;
		}

		}
		
	}
	
	/* sort and add line(prio) num */
	echo "sort ".$tm_wlan2eth." > /var/run/tm_tmp\n";
	echo "mv /var/run/tm_tmp ".$tm_wlan2eth." \n";
	echo "sort ".$tm_eth2wlan." > /var/run/tm_tmp\n";
	echo "mv /var/run/tm_tmp ".$tm_eth2wlan." \n";
	echo "grep -n . ".$tm_wlan2eth." | sed 's/:/	/' > /var/run/tm_tmp \n";
	echo "mv /var/run/tm_tmp ".$tm_wlan2eth." \n";
	echo "grep -n . ".$tm_eth2wlan." | sed 's/:/	/' > /var/run/tm_tmp \n";
	echo "mv /var/run/tm_tmp ".$tm_eth2wlan." \n";
	
	/* create ETH2WLAN queues and filters, line num is the filter priority */
	echo "echo while read prio limit ip mac >> ".$create_eth2wlan." \n";
	echo "echo do >> ".$create_eth2wlan." \n";
	echo "echo { >> ".$create_eth2wlan." \n";
	//echo "echo	".$TC." class add dev ".$WANDEV " parent 1:1 classid 1:1$prio htb prio 8 rate ".$wlan2eth.$K." ceil ".$wlan2eth.$K. \n" >> /var/run/tm_createqueue";
	echo "echo \"	\"".$TC." class add dev ".$WLANDEV." parent 2:1 classid 2:1'\"$prio\"' htb prio 8 rate '\"$limit\"'".$K." ceil '\"$limit\"'".$K." burst 200k cburst 200k >> ".$create_eth2wlan." \n";
	echo "echo \"	\"opt_src_ip='\"\"' >> ".$create_eth2wlan." \n";
	echo "echo \"	\"opt_dst_ip='\"\"' >> ".$create_eth2wlan." \n";
	echo "echo \"	\"opt_src_mac='\"\"' >> ".$create_eth2wlan." \n";
	echo "echo \"	\"opt_dst_mac='\"\"' >> ".$create_eth2wlan." \n";
	/* ip filter option */
	echo "echo \"	\"if [ '\"$ip\"' != \\\"0.0.0.0\\\" ] >> ".$create_eth2wlan." \n";
	echo "echo \"	\"then >> ".$create_eth2wlan." \n";
	echo "echo \"		\"opt_src_ip='\"match ip src $ip/0\"' >> ".$create_eth2wlan." \n";
	echo "echo \"		\"opt_dst_ip='\"match ip dst $ip/0\"' >> ".$create_eth2wlan." \n";
	echo "echo \"	\"fi >> ".$create_eth2wlan." \n";
	/* mac filter option */
	echo "echo \"	\"if [ '\"$mac\"' != \\\"00:00:00:00:00:00\\\" ] >> ".$create_eth2wlan." \n";
	echo "echo \"	\"then >> ".$create_eth2wlan." \n";
	echo "echo \"		\"tfmgr_mac='\"$mac\"' >> ".$create_eth2wlan." \n";
	echo "echo \"		\"tfmgr_mac1='`echo $tfmgr_mac | cut -c1-2`'  >> ".$create_eth2wlan." \n";
	echo "echo \"		\"tfmgr_mac2='`echo $tfmgr_mac | cut -c4-5`'  >> ".$create_eth2wlan." \n";
	echo "echo \"		\"tfmgr_mac3='`echo $tfmgr_mac | cut -c7-8`'  >> ".$create_eth2wlan." \n";
	echo "echo \"		\"tfmgr_mac4='`echo $tfmgr_mac | cut -c10-11`'  >> ".$create_eth2wlan." \n";
	echo "echo \"		\"tfmgr_mac5='`echo $tfmgr_mac | cut -c13-14`'  >> ".$create_eth2wlan." \n";
	echo "echo \"		\"tfmgr_mac6='`echo $tfmgr_mac | cut -c16-17`'  >> ".$create_eth2wlan." \n";	
	echo "echo \"		\"opt_dst_mac='`echo match u8 0x$tfmgr_mac1 0xFF at -14 match u8 0x$tfmgr_mac2 0xFF at -13 match u8 0x$tfmgr_mac3 0xFF at -12 match u8 0x$tfmgr_mac4 0xFF at -11 match u8 0x$tfmgr_mac5 0xFF at -10 match u8 0x$tfmgr_mac6 0xFF at -9`' >> ".$create_eth2wlan." \n";
	echo "echo \"		\"opt_src_mac='`echo match u8 0x$tfmgr_mac1 0xFF at -8 match u8 0x$tfmgr_mac2 0xFF at -7 match u8 0x$tfmgr_mac3 0xFF at -6 match u8 0x$tfmgr_mac4 0xFF at -5 match u8 0x$tfmgr_mac5 0xFF at -4 match u8 0x$tfmgr_mac6 0xFF at -3`' >> ".$create_eth2wlan." \n";
	echo "echo \"	\"fi >> ".$create_eth2wlan." \n";
	/* add filter */
	echo "echo \"	\"".$TC." filter add dev ".$WLANDEV." protocol ip parent 2: prio '$prio' u32 '$opt_src_ip' '$opt_src_mac' flowid 2:1'$prio' >> ".$create_eth2wlan." \n";
	echo "echo \"	\"".$TC." filter add dev ".$WLANDEV." protocol ip parent 2: prio '$prio' u32 '$opt_dst_ip' '$opt_dst_mac' flowid 2:1'$prio' >> ".$create_eth2wlan." \n";
	echo "echo } >> ".$create_eth2wlan." \n";
	echo "echo done >> ".$create_eth2wlan." \n";
	
	echo "sh ".$create_eth2wlan." < ".$tm_eth2wlan." \n";
	
	
	/* create WLAN2ETH queues and filters, line num is the filter priority */
	echo "echo while read prio limit ip mac >> ".$create_wlan2eth." \n";
	echo "echo do >> ".$create_wlan2eth." \n";
	echo "echo { >> ".$create_wlan2eth." \n";
	echo "echo \"	\"".$TC." class add dev ".$WANDEV." parent 1:1 classid 1:1'\"$prio\"' htb prio 8 rate '\"$limit\"'".$K." ceil '\"$limit\"'".$K." burst 200k cburst 200k >> ".$create_wlan2eth." \n";
	echo "echo \"	\"opt_src_ip='\"\"' >> ".$create_wlan2eth." \n";
	echo "echo \"	\"opt_dst_ip='\"\"' >> ".$create_wlan2eth." \n";
	echo "echo \"	\"opt_src_mac='\"\"' >> ".$create_wlan2eth." \n";
	echo "echo \"	\"opt_dst_mac='\"\"' >> ".$create_wlan2eth." \n";
	/* ip filter option */
	echo "echo \"	\"if [ '\"$ip\"' != \\\"0.0.0.0\\\" ] >> ".$create_wlan2eth." \n";
	echo "echo \"	\"then >> ".$create_wlan2eth." \n";
	echo "echo \"		\"opt_src_ip='\"match ip src $ip/0\"' >> ".$create_wlan2eth." \n";
	echo "echo \"		\"opt_dst_ip='\"match ip dst $ip/0\"' >> ".$create_wlan2eth." \n";
	echo "echo \"	\"fi >> ".$create_wlan2eth." \n";
	/* mac filter option */
	echo "echo \"	\"if [ '\"$mac\"' != \\\"00:00:00:00:00:00\\\" ] >> ".$create_wlan2eth." \n";
	echo "echo \"	\"then >> ".$create_wlan2eth." \n";
	echo "echo \"		\"tfmgr_mac='\"$mac\"' >> ".$create_wlan2eth." \n";
	echo "echo \"		\"tfmgr_mac1='`echo $tfmgr_mac | cut -c1-2`'  >> ".$create_wlan2eth." \n";
	echo "echo \"		\"tfmgr_mac2='`echo $tfmgr_mac | cut -c4-5`'  >> ".$create_wlan2eth." \n";
	echo "echo \"		\"tfmgr_mac3='`echo $tfmgr_mac | cut -c7-8`'  >> ".$create_wlan2eth." \n";
	echo "echo \"		\"tfmgr_mac4='`echo $tfmgr_mac | cut -c10-11`'  >> ".$create_wlan2eth." \n";
	echo "echo \"		\"tfmgr_mac5='`echo $tfmgr_mac | cut -c13-14`'  >> ".$create_wlan2eth." \n";
	echo "echo \"		\"tfmgr_mac6='`echo $tfmgr_mac | cut -c16-17`'  >> ".$create_wlan2eth." \n";	
	echo "echo \"		\"opt_dst_mac='`echo match u8 0x$tfmgr_mac1 0xFF at -14 match u8 0x$tfmgr_mac2 0xFF at -13 match u8 0x$tfmgr_mac3 0xFF at -12 match u8 0x$tfmgr_mac4 0xFF at -11 match u8 0x$tfmgr_mac5 0xFF at -10 match u8 0x$tfmgr_mac6 0xFF at -9`' >> ".$create_wlan2eth." \n";
	echo "echo \"		\"opt_src_mac='`echo match u8 0x$tfmgr_mac1 0xFF at -8 match u8 0x$tfmgr_mac2 0xFF at -7 match u8 0x$tfmgr_mac3 0xFF at -6 match u8 0x$tfmgr_mac4 0xFF at -5 match u8 0x$tfmgr_mac5 0xFF at -4 match u8 0x$tfmgr_mac6 0xFF at -3`' >> ".$create_wlan2eth." \n";
	echo "echo \"	\"fi >> ".$create_wlan2eth." \n";
	/* add filter */
	echo "echo \"	\"".$TC." filter add dev ".$WANDEV." protocol ip parent 1: prio '$prio' u32 '$opt_src_ip' '$opt_src_mac' flowid 1:1'$prio' >> ".$create_wlan2eth." \n";
	echo "echo \"	\"".$TC." filter add dev ".$WANDEV." protocol ip parent 1: prio '$prio' u32 '$opt_dst_ip' '$opt_dst_mac' flowid 1:1'$prio' >> ".$create_wlan2eth." \n";
	echo "echo } >> ".$create_wlan2eth." \n";
	echo "echo done >> ".$create_wlan2eth." \n";
	
	echo "sh ".$create_wlan2eth." < ".$tm_wlan2eth." \n";
	
	/*--- the default queue ---*/
	$default_index = 65;
	if($all_wlan2eth >= $WLAN2ETH){
		$default_wlan2eth = 1;
	}
	else{
		$default_wlan2eth = $WLAN2ETH - $all_wlan2eth;
	}
	if($all_eth2wlan >= $ETH2WLAN){
		$default_eth2wlan = 1;
	}
	else{
		$default_eth2wlan = $ETH2WLAN - $all_eth2wlan;
	}

	echo $TC." class add dev ".$WANDEV." parent 1:1 classid 1:1".$default_index." htb prio 8 rate ".$default_wlan2eth.$K." ceil ".$WLAN2ETH.$K." burst 200k cburst 200k  \n";

	echo $TC." class add dev ".$WLANDEV." parent 2:1 classid 2:1".$default_index." htb prio 8 rate ".$default_eth2wlan.$K." ceil ".$ETH2WLAN.$K." burst 200k cburst 200k  \n";

	/*--- forword unlisted client? ----*/
	$forward_unlist = query("/trafficmgr/unlistclientstraffic"); /* 0 - deny , 1 - forward */
	if($forward_unlist == 0)
	{
		echo $TC." filter add dev ".$WANDEV." parent 1: protocol ip prio ".$default_index." u32 match u8 00 00 flowid 1:1".$default_index." police rate 1bps burst 1 drop \n";
		echo $TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio ".$default_index." u32 match u8 00 00 flowid 2:1".$default_index." police rate 1bps burst 1 drop \n";
	}

}
else
{
	echo "echo Stop traffic manager system ... \n";
	echo $TC." qdisc del dev ".$WANDEV." root \n";
	echo $TC." qdisc del dev ".$WLANDEV." root \n";
	echo "rmmod tcdev \n";
	echo "rm ".$create_eth2wlan." ".$create_wlan2eth." ".$tm_eth2wlan." ".$tm_wlan2eth." \n ";
}

?>
