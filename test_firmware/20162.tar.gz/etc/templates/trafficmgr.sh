#!/bin/sh
echo [$0] $1 ... > /dev/console
TROOT="/etc/templates"
[ ! -f $TROOT/trafficmgr_run.php ] && exit 0
case "$1" in
start|restart)
	[ -f /var/run/trafficmgr_stop.sh ] && sh /var/run/trafficmgr_stop.sh > /dev/console
	xmldbc -A $TROOT/trafficmgr_run.php -V generate_start=1 > /var/run/trafficmgr_start.sh
	xmldbc -A $TROOT/trafficmgr_run.php -V generate_start=0 > /var/run/trafficmgr_stop.sh
	sleep 2
	sh /var/run/trafficmgr_start.sh > /dev/console
	;;
stop)
	if [ -f /var/run/trafficmgr_stop.sh ]; then
		sh /var/run/trafficmgr_stop.sh > /dev/console
		rm -f /var/run/trafficmgr_stop.sh
	fi
	;;
*)
	echo "usage: trafficmgr.sh {start|stop|restart}"
	;;
esac
