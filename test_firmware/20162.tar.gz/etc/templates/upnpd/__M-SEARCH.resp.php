<?
echo "HTTP/1.1 200 OK\r\n";
echo "CACHE-CONTROL: max-age=".$MAXAGE."\r\n";
echo "DATE: ".$DATE."\r\n";
echo "EXT:\r\n";
echo "LOCATION: ".$LOCATION."\r\n";
echo "SERVER: ".$SERVER."\r\n";
echo "ST: ".$ST."\r\n";
echo "USN: ".$USN."\r\n";
echo "\r\n";
?>
