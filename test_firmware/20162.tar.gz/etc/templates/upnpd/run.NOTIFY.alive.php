<?
require("/etc/templates/troot.php");
$NTS = "ssdp:alive";
require($template_root."/upnpd/__NOTIFY.alivebye.php");
?>
