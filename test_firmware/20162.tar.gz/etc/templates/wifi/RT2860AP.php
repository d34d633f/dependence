<?
/******************************************************************************************************************** 
 *	NOTE: 
 *		This configuration generator is based on Ralink RT2800 Linux SoftAP Drv1.5.0.0 Release Note and User's Guide.	 
 *		Package Name : 2007_0801_RT2860_Linux_SoftAP_Drv1.5.0.0.tgz
 ********************************************************************************************************************/
$wlan_mac   =query("/runtime/nvram/wlanmac");
$wlan_ip	=query("/lan/ethernet/ip");
$ccode		=query("/runtime/nvram/countrycode");
if ($ccode=="")	{$ccode = "840";}
$templates_path	="/etc/templates/wifi/";

/* -------------------------------------------- get config ----------------------------------------*/
/***************************************************** 
	mean of node path in xmldb:
	/wireless		<==	wlan 		(BG-band)
	/wlan/inf:2		<== wlan guest 	(BG-band)
	/wlan/inf:3		<== wlan 		(A-band)
	/wlan/inf:4		<== wlan guest 	(A-band)
*****************************************************/
anchor("/wireless");
$outdoor	=query("outdoor");	if( $outdoor=="" ) { $outdoor = "0"; }
/*
	Note:
	For 1.40 firmware version of DAP-1522 doesn't support DFS channels due to Ralink's DFS issue. So 
	Dlink decides to disable DFS channels of all regions. Hence, below regions included DFS channels 
	will be changed. If someday will enable DFS function, we will uncomment the below codes out.
	Except speical country cases: IL, TW, RU
	Added by Freddy 2011/01/12

//country code
if ($ccode == "392") { $c_region = "1"; $c_regionA = "1";$c_string="JP";}
//AU: Australia (36)
else if ($ccode == "36")	{$c_region="1";$c_regionA = "10";$c_string="AU";}
//CA: Canada (124)
else if ($ccode == "124")	{$c_region="0";$c_regionA = "10";$c_string="CA";}
//CN: China (156)
else if ($ccode == "156")	{$c_region="1";$c_regionA = "4";$c_string="CN";}
//DE: Germany (276)
else if ($ccode == "276")	{$c_region="1";$c_regionA = "1";$c_string="DE";}
//LA: Latin America (777)
else if ($ccode == "777")	{$c_region="0";$c_regionA = "5";$c_string="LA";}
//TW: Taiwan (158)
else if ($ccode == "158")	{$c_region="0";$c_regionA = "15";$c_string="TW";}
//GB: United Kingdom (826)
else if ($ccode == "826")	{$c_region="1";$c_regionA = "1";$c_string="GB";}
//RU: RUSSIA FEDERATION (643)
else if ($ccode == "643")	{$c_region="1";$c_regionA = "13";$c_string="RU";}	//RU_20090504 added by harry
//KR: Korea (410)
else if ($ccode == "410")	{$c_region="1";$c_regionA = "14";$c_string="KR";}	//KR_20090504 added by harry
//IL: Isreal (376)
else if ($ccode == "376") {$c_region="1";$c_regionA = "2";$c_string="IL";} //IL_201009 added by erial
//US: United States (840)
else {$c_region="0";$c_regionA = "10";$c_string="US";}
*/

//country code //NO DFS Channels in below regions.
if ($ccode == "392") { $c_region = "1"; $c_regionA = "6";$c_string="JP";}
//AU: Australia (36)
else if ($ccode == "36")	{$c_region="1";$c_regionA = "10";$c_string="AU";}
//CA: Canada (124)
else if ($ccode == "124")	{$c_region="0";$c_regionA = "10";$c_string="CA";}
//CN: China (156)
else if ($ccode == "156")	{$c_region="1";$c_regionA = "4";$c_string="CN";}
//DE: Germany (276)
else if ($ccode == "276")	{$c_region="1";$c_regionA = "6";$c_string="DE";}
//LA: Latin America (777)
else if ($ccode == "777")	{$c_region="0";$c_regionA = "5";$c_string="LA";}
//TW: Taiwan (158)
else if ($ccode == "158")	{$c_region="0";$c_regionA = "15";$c_string="TW";}
//GB: United Kingdom (826)
else if ($ccode == "826")	{$c_region="1";$c_regionA = "6";$c_string="GB";}
//RU: RUSSIA FEDERATION (643)
else if ($ccode == "643")	{$c_region="1";$c_regionA = "13";$c_string="RU";}	//RU_20090504 added by harry
//KR: Korea (410)
else if ($ccode == "410")	{$c_region="1";$c_regionA = "16";$c_string="KR";}	//KR_20090504 added by harry
//IL: Isreal (376)
else if ($ccode == "376") {$c_region="1";$c_regionA = "2";$c_string="IL";} //IL_201009 added by erial
//US: United States (840)
else {$c_region="0";$c_regionA = "10";$c_string="US";}

/* 802.11h */
$ieee80211h_en = query("ieee80211h/enable"); if ($ieee80211h_en=="")	{$ieee80211h_en="0";}
if ($ccode=="392")	{ $rdregion="JAP_W53"; $ieee80211h_en="1";}/*JP*/
else if ($ccode=="826")	{ $rdregion="CE"; $ieee80211h_en="1";}/*EU*/
else if ($ccode=="840")	{ $rdregion="FCC";$ieee80211h_en="0";}/*US*//*Disable DFS*/
else if ($ccode=="124")	{ $rdregion="FCC";$ieee80211h_en="0";}/*CA*//*Disable DFS*/
else if ($ccode=="158")	{ $rdregion="FCC";$ieee80211h_en="0";}/*TW*//*Disable DFS*/
else if ($ccode=="36") { $rdregion="CE"; $ieee80211h_en="0";}/*AU*//*Disable DFS*/
else if ($ccode=="643") { $rdregion="FCC"; $ieee80211h_en="0";}/*RU*/ /*RU_20090504 added by harry*/
else if ($ccode=="410") { $rdregion="CE"; $ieee80211h_en="1";}/*KR*/
else if ($ccode=="376") { $rdregion="CE"; $ieee80211h_en="0";}/*IL: Disable DFS*/
		
$carrierdetect	=query("ieee80211h/carrierdetect");	if ($carrierdetect=="") {$carrierdetect="0";}
if ($ccode=="392") {$carrierdetect="1";}

$b_intval	= query("beaconinterval"); if ($b_intval=="")	{$b_intval	="100";}
$dtim = query("dtim"); if ($dtim=="") {$dtim ="1";}
$rtslength	= query("rtslength"); if ($rtslength=="")	{$rtslength	="2346";}
$fraglength	= query("fraglength"); if ($fraglength==""){$fraglength="2346";}

$wlmode	= query("/wireless/wlmode");
$wmm = query("wmm/enable");
$w11nonly="0";
/* Ralink Chip
typedef enum _RT_802_11_PHY_MODE {
    PHY_11BG_MIXED = 0,
    PHY_11B,
    PHY_11A,
    PHY_11ABG_MIXED,
    PHY_11G,
#ifdef DOT11_N_SUPPORT
    PHY_11ABGN_MIXED,   // both band   5
    PHY_11N_2_4G,       // 11n-only with 2.4G band      6
    PHY_11GN_MIXED, // 2.4G band      7
    PHY_11AN_MIXED, // 5G  band       8
    PHY_11BGN_MIXED,    // if check 802.11b.      9
    PHY_11AGN_MIXED,    // if check 802.11b.      10
    PHY_11N_5G,         // 11n-only with 5G band        11
#endif // DOT11_N_SUPPORT //
} RT_802_11_PHY_MODE;
*/
if($wlmode=="1"/*11g*/) {$wlan_mode="4"; $basic_rate="351";}
else if ($wlmode=="2"/*11g/b*/) {$wlan_mode="0"; $basic_rate="15";}
else if ($wlmode=="3"/*11b*/) {$wlan_mode="1"; $basic_rate="3";}
else if ($wlmode=="4"/*11n 2.4G*/) {$wlan_mode="6"; $w11nonly="1";$basic_rate="15";$wmm = "1";}
else if ($wlmode=="5"/*11n/g/b*/) {$wlan_mode="9"; $basic_rate="15";$wmm = "1";}
else if ($wlmode=="6"/*11n/g 2.4G*/) {$wlan_mode="7"; $basic_rate="15";$wmm = "1";}
else if ($wlmode=="7"/*11a*/) {$wlan_mode="2"; $basic_rate="";}
else if ($wlmode=="8"/*11a/n*/) {$wlan_mode="8"; $basic_rate="";$wmm = "1";}
else if ($wlmode=="9"/*11n 5G*/) {$wlan_mode="11"; $w11nonly="1";$basic_rate="";$wmm = "1";}
else {$wlan_mode="9"; $basic_rate="15";$wmm = "1";}/*others default:11n/g/b*/

if ($wlanmode=="1") {$WMM_PAR="11b";}
else {$WMM_PAR="11ag";}
$txburst="1";

if ($wmm=="1"){$txburst="0";}
/* 11n bandwidth and extension channel */
/* bandwidth: 0:20MHz 1:20/40 MHz*/
$bw_11n	= query("cwmmode");	if ($bw_11n=="") {$bw_11n	="0";}
if ($bw_11n=="1")
{
	$ht_bw="1";
	$ht_extcha=0;
}
else
{
	$ht_bw="0";
}

$auto_ch = query("autochannel"); if ($auto_ch=="") {$auto_ch	="0";}
$channel = query("channel");

if ($auto_ch=="1")
{
	$channel ="";  /* If auto channel is enabled, channel value should not to be set */
} 
else if ($channel=="") 
{
  if ($wlmode=="7" || $wlmode=="8" || $wlmode=="9")
  { $channel="64";   /* for n only, a+n or a only, we set default channle is 64 */  }
  else
  { $channel="6";    /* else, we set default channel is 6 */   }
}

/* -------- RT2860AP.dat -------*/
echo "Default"."\n";	/* The word of "Default" must not be removed. */
/* for A-Band, set CountryRegionABand. */
/* for BG-Band, set CountryRegion. */
echo "CountryRegionABand=".$c_regionA."\n";
echo "CountryRegion=".$c_region."\n";
echo "CountryCode=".$c_string."\n";
echo "WirelessMode=".$wlan_mode."\n";
echo "W11Nonly=".$w11nonly."\n";
if ($basic_rate != "") { echo "BasicRate=".$basic_rate."\n";}
/* 802.11h for A-band only*/
if ($wlmode == "7" || $wlmode == "8" || $wlmode == "9")
{
	$DfsLowerLimit=query("ieee80211h/DfsLowerLimit");	if ($DfsLowerLimit=="")	{$DfsLowerLimit="0";}
	$DfsUpperLimit=query("ieee80211h/DfsUpperLimit");	if ($DfsUpperLimit=="")	{$DfsUpperLimit="2500";}
	$FixDfsLimit=query("ieee80211h/FixDfsLimit");	if ($FixDfsLimit=="")	{$FixDfsLimit="1";}
	$AvgRssiReq=query("ieee80211h/AvgRssiReq");	if ($AvgRssiReq=="") {$AvgRssiReq="75";}
	$csperiod	= query("ieee80211h/csperiod"); if ($csperiod=="") {$csperiod="6";}
	echo "IEEE80211H=".$ieee80211h_en."\n";	
	echo "CSPeriod=".$csperiod."\n";
	echo "RDRegion=".$rdregion."\n";
	echo "CarrierDetect=".$carrierdetect."\n";
	echo "DfsLowerLimit=".$DfsLowerLimit."\n";
	echo "DfsUpperLimit=".$DfsUpperLimit."\n";
	echo "FixDfsLimit=".$FixDfsLimit."\n";
	echo "AvgRssiReq=-".$AvgRssiReq."\n";
}

echo "AutoChannelSelect=".$auto_ch."\n";
echo "Channel=".$channel."\n";
echo "BeaconPeriod=".$b_intval."\n";
echo "DtimPeriod=".$dtim."\n";
echo "RTSThreshold=".$rtslength."\n";
echo "FragThreshold=".$fraglength."\n";

/* -------------------------------------------- get config ----------------------------------------*/
/* tx power */
/*Workaround: Ralink didn't support Tx power control when enable WiFitest flag.
 *            Because their tx power will be too strong in short range and impact 
 *            throughput to fail WiFi test. So we will disable WiFitest flag to make
 *            Tx Power Control working.*/

$wifi_test="0";
$txpower=query("txpower");
if ($txpower=="2")	{$txpower="45";}
else if ($txpower=="3")	{$txpower="25";}
else if ($txpower=="4")	{$txpower="10";}
else if ($txpower=="5")	{$txpower="5";}
else {$txpower="95"; $wifi_test="1";}
/* -------- RT2860AP.dat -------*/
/**********************************************************************************************
 * for passing the WiFi test in secter 4.2.3.2.2. 
 * The default value of preamble in Ralink driver is auto (long preamble).
 * When the preamble is long preamble, the result of 4.2.3.2 MA8 is 
 * 3.543/3.430 (Broadcom-G, Intel-B(RTS-256), but the throughput must more than 4.140/2.253.
 * Ralink said to set the preamble as short to pass this item.
 * (set the TxPreabmle=1.)
 **********************************************************************************************/
echo "TxPreamble=1\n";
echo "TxPower=".$txpower."\n";
echo "WiFiTest=".$wifi_test."\n";
/* -------------------------------------------- get config ----------------------------------------*/
/* 11n short guard interval */
$s_gi_11n = query("shortguardinterval");
if ($s_gi_11n=="") {$s_gi_11n	="0";}

/* -------- RT2860AP.dat -------*/
/* HT (11n) */
echo "HT_HTC=0\n";
echo "HT_RDG=1\n";
echo "HT_LinkAdapt=0\n";
echo "HT_OpMode=0\n";
echo "HT_MpduDensity=4\n";
echo "HT_AutoBA=1\n";
echo "HT_AMSDU=1\n";
echo "HT_BAWinSize=16\n";
echo "HT_STBC=0\n";
echo "HT_GI=".$s_gi_11n."\n";
echo "HT_BW=".$ht_bw."\n";
if ($ht_bw=="1"){ echo "HT_EXTCHA="	.$ht_extcha	."\n";}

/* bridge */
/*WLAN_partition*/
$EthToSTA=query("/wireless/e_partition");	if ($EthToSTA=="1")	{$no_forwarding_eth="1";}	else {$no_forwarding_eth="0";}
$STAtoSTA=query("/wireless/w_partition");	if ($STAtoSTA=="1")	{$no_forwarding="1";}	else {$no_forwarding="0";}
echo "EthToSTA=".$no_forwarding_eth."\n";
echo "NoForwarding=".$no_forwarding."\n";
echo "NoForwardingBTNBSSID=1\n";

/* -------------------------------------------- get config ----------------------------------------*/
/* NOTE: For dual band (ex: G-WLBARAGN), 
		 access control lists were stored in the same node path (/wireless/acl/mac:id).  */
/* Access Control List */
$acl_policy=query("/wireless/acl/mode");
if ($acl_policy=="") {$acl_policy="0";}

$acl_div="";
$acl_index=0;
/* -------- RT2860AP.dat -------*/
echo "AccessPolicy0=".$acl_policy."\n";
if($acl_policy!="0")
{
	echo "AccessControlList0=";
	for("/wireless/acl/mac")
	{
		$acl_index++;
		$acl_path="/wireless/acl/mac:".$acl_index;
	    $acl_str="";
		$acl_str=$acl_str.$acl_div.query($acl_path);
		$acl_div=";";
		echo $acl_str;
	}
	echo "\n";
}

$qos_enable=query("/qos/enable");
$qos_type=query("/qos/qostype");
if($qos_enable=="1"&&$qos_type==0)
{
   echo "PriorityByPort=1\n";
}
else
{
   echo "PriorityByPort=0\n";
}

/* Single/Multi-BSSID */
echo  "ShortSlot=1\n";   /*patch for LegacyG issue*/
require($templates_path."dat_mbssid.php"); 
/* -------- RT2860AP.dat end -------*/
?>
