#!/bin/sh
echo [$0] ... > /dev/console
<? 

	/* read and set mac clone parameter */
	$mac_clone_enable = query("/wireless/macclone/enable");
	if($mac_clone_enable == 0) //no enable, use ap'mac 
	{
		echo "brctl setmatmode br0 2 \n";
	}
	else
	{
		$mac_clone_mode = query("/wireless/macclone/mode");
		if($mac_clone_mode == 1) //manual
		{
			$manual_addr = query("/wireless/macclone/mac");
			echo "brctl setmatmode br0 1 \n";
			echo "brctl setmataddr br0 ".$manual_addr." \n";
		}
		else //auto
		{
			echo "brctl setmatmode br0 0 \n";
		}
	}

	echo "xmldbc -A /etc/templates/wifi/RT2860STA.php > /var/run/RT2860.dat\n";
	echo "sleep 1\n";
  echo "ifconfig ra0 down\n";
	echo "brctl delif br0 ra0\n";
	echo "rmmod rt2860v2_sta\n";
	echo "rmmod rt2860v2_ap\n" ;
	echo "insmod /lib/modules/rt2860v2_sta.o\n";
	echo "sleep 1\n";
	echo "brctl apmode br0 1\n";
	echo "sleep 1\n";
	echo "ifconfig ra0 txqueuelen 1000\n";
	echo "sleep 1\n";
	echo "ifconfig ra0 up\n";
	echo "sleep 1\n";
	echo "brctl addif br0 ra0\n";

	/* eric add, 2008/08/25, renew uuid when change mac,(WPS compatibility issue) */
	echo "wlanmac=`rgdb -i -g /runtime/macclone/mac`\n";
	echo "if [ \"$wlanmac\" = \"\" ]; then\n";
	echo "wlanmac=`rgdb -i -g /runtime/layout/wanmac`\n";
	echo "fi\n";
	echo "xmldbc -i -s /runtime/upnpdev/root:1/uuid `genuuid -s WFADevice -m $wlanmac `\n";
	/* eric end */

	$auth_mode = query("/wireless/authentication");
	if($auth_mode == 2 || $auth_mode == 4 || $auth_mode == 6)
	{
		set("/wireless/authentication","0");
		set("/wireless/wpa/wepmode","0");
		$auth_mode = 0;
	}
  
	if ($auth_mode > 1 || query("/wireless/wps/enable")=="1")
	 {
		$wpa_supplicant_conf = "/var/run/wpa_supplicant.conf";
    require($TROOT."/wifi/wpa_supplicant_used.php");
		echo "wpa_supplicant -ira0 -c ".$wpa_supplicant_conf." -Dralink -w &\n";
	}

	echo "wlxmlpatch -S ra0 /runtime/stats/wireless RADIO_ON RADIO_BLINK RT2800 > /dev/console &\n";

	/* The PM(Gloria) told us not to help user enabling wps when the apc that is unconfigured state at power on.
	   added by Freddy 
	*/
	/*
	if(query("/wireless/wps/enable")=="1")
	{
		$wps_configured = query("/wireless/wps/configured");        
		if( $wps_configured == "0" || $wps_configured == "")
		{	
			echo "sleep 3\n";
			echo "/etc/templates/wps.sh pin\n"> /dev/console &\n";
		}
	}
	*/
?>	
