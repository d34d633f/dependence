<?
$ccode = query("/runtime/nvram/countrycode");
if ($ccode=="")
{
    $ccode = "840";
}

/*
	Note:
	For 1.40 firmware version of DAP-1522 doesn't support DFS channels due to Ralink's DFS issue. So 
	Dlink decides to disable DFS channels of all regions. Hence, below regions included DFS channels 
	will be changed. If someday will enable DFS function, we will uncomment the below codes out.
	Added by Freddy 2011/01/12

//country code
if ($ccode == "392") { $c_region = "1"; $c_regionA = "1";$c_string="JP";}
//AU: Australia (36)
else if ($ccode == "36")	{$c_region="1";$c_regionA = "10";$c_string="AU";}
//CA: Canada (124)
else if ($ccode == "124")	{$c_region="0";$c_regionA = "10";$c_string="CA";}
//CN: China (156)
else if ($ccode == "156")	{$c_region="1";$c_regionA = "4";$c_string="CN";}
//DE: Germany (276)
else if ($ccode == "276")	{$c_region="1";$c_regionA = "1";$c_string="DE";}
//LA: Latin America (777)
else if ($ccode == "777")	{$c_region="0";$c_regionA = "5";$c_string="LA";}
//TW: Taiwan (158)
else if ($ccode == "158")	{$c_region="0";$c_regionA = "15";$c_string="TW";}
//GB: United Kingdom (826)
else if ($ccode == "826")	{$c_region="1";$c_regionA = "1";$c_string="GB";}
//RU: RUSSIA FEDERATION (643)
else if ($ccode == "643")	{$c_region="1";$c_regionA = "13";$c_string="RU";}	//RU_20090504 added by harry
//KR: Korea (410)
else if ($ccode == "410")	{$c_region="1";$c_regionA = "14";$c_string="KR";}	//KR_20090504 added by harry
//IL: Isreal (376)
else if ($ccode == "376") {$c_region="1";$c_regionA = "2";$c_string="IL";} //IL_201009 added by erial
//US: United States (840)
else {$c_region="0";$c_regionA = "10";$c_string="US";}
*/

//country code //NO DFS Channels in below regions.
if ($ccode == "392") { $c_region = "1"; $c_regionA = "6";$c_string="JP";}
//AU: Australia (36)
else if ($ccode == "36")	{$c_region="1";$c_regionA = "10";$c_string="AU";}
//CA: Canada (124)
else if ($ccode == "124")	{$c_region="0";$c_regionA = "10";$c_string="CA";}
//CN: China (156)
else if ($ccode == "156")	{$c_region="1";$c_regionA = "4";$c_string="CN";}
//DE: Germany (276)
else if ($ccode == "276")	{$c_region="1";$c_regionA = "6";$c_string="DE";}
//LA: Latin America (777)
else if ($ccode == "777")	{$c_region="0";$c_regionA = "5";$c_string="LA";}
//TW: Taiwan (158)
else if ($ccode == "158")	{$c_region="0";$c_regionA = "15";$c_string="TW";}
//GB: United Kingdom (826)
else if ($ccode == "826")	{$c_region="1";$c_regionA = "6";$c_string="GB";}
//RU: RUSSIA FEDERATION (643)
else if ($ccode == "643")	{$c_region="1";$c_regionA = "13";$c_string="RU";}	//RU_20090504 added by harry
//KR: Korea (410)
else if ($ccode == "410")	{$c_region="1";$c_regionA = "16";$c_string="KR";}	//KR_20090504 added by harry
//IL: Isreal (376)
else if ($ccode == "376") {$c_region="1";$c_regionA = "2";$c_string="IL";} //IL_201009 added by erial
//US: United States (840)
else {$c_region="0";$c_regionA = "10";$c_string="US";}

/* 802.11h */
$ieee80211h_en	=query("/wireless/ieee80211h/enable");	if ($ieee80211h_en=="")	{$ieee80211h_en="0";}
$csperiod		=query("/wireless/ieee80211h/csperiod");	if ($csperiod=="")		{$csperiod="6";}
if ($ccode=="392")	{ $rdregion="JAP_W53"; $ieee80211h_en="1";}/*JP*/
else if ($ccode=="826")	{ $rdregion="CE"; $ieee80211h_en="1";}/*EU*/
else if ($ccode=="840")	{ $rdregion="FCC";$ieee80211h_en="0";}/*US*//*Disable DFS*/
else if ($ccode=="124")	{ $rdregion="FCC";$ieee80211h_en="0";}/*CA*//*Disable DFS*/
else if ($ccode=="158")	{ $rdregion="CE";$ieee80211h_en="0";}/*TW*//*Disable DFS*/
else if ($ccode=="36") { $rdregion="CE"; $ieee80211h_en="0";}/*AU*//*Disable DFS*/
else if ($ccode=="643") { $rdregion="CE"; $ieee80211h_en="0";}/*RU*/ /*RU_20090504 added by harry*/
else if ($ccode=="410") { $rdregion="CE"; $ieee80211h_en="1";}/*KR*/
else if ($ccode=="376") { $rdregion="CE"; $ieee80211h_en="0";}/*IL: Disable DFS*/
	
$carrierdetect	=query("ieee80211h/carrierdetect");	if ($carrierdetect=="") {$carrierdetect="1";}
if ($ccode=="392")	{$carrierdetect="1";}
$DfsLowerLimit		=query("ieee80211h/DfsLowerLimit");	if ($DfsLowerLimit=="")	{$DfsLowerLimit="0";}
$DfsUpperLimit		=query("ieee80211h/DfsUpperLimit");	if ($DfsUpperLimit=="")	{$DfsUpperLimit="2500";}
$FixDfsLimit		=query("ieee80211h/FixDfsLimit");	if ($FixDfsLimit=="")	{$FixDfsLimit="1";}
$AvgRssiReq		=query("ieee80211h/AvgRssiReq");	if ($AvgRssiReq=="")	{$AvgRssiReq="75";}	

$debug = query("/wireless/ralink/debug");
if ($debug==""){$debug = "0";}

/* The word of "Default" must not be removed. */
echo "Default"."\n";	
echo "Debug=".$debug."\n";

/* for A-Band, set CountryRegionABand. */
/* for BG-Band, set CountryRegion. */
echo "CountryRegion=".$c_region."\n";
echo "CountryRegionABand=".$c_regionA."\n";
echo "CountryCode=".$c_string."\n";


echo "FixedTxMode=0\n";
echo "TxRate=0\n";
echo "WirelessMode=5\n"; /*ABGNMixed*/
echo "Channel=0\n";
echo "BasicRate=15\n";
echo "BeaconPeriod=100\n";
echo "DtimPeriod=1\n";
echo "TxPower=100\n";
echo "DisableOLBC=0\n";
echo "BGProtection=0\n";
echo "TxAntenna=\n";
echo "RxAntenna=\n";
echo "TxPreamble=0\n";
echo "RTSThreshold=2347\n";
echo "FragThreshold=2346\n";
echo "TxBurst=1\n";
echo "PktAggregate=1\n";
echo "TurboRate=0\n";
echo "WmmCapable=1\n";

$qos_enable=query("/qos/enable");
$qos_type=query("/qos/qostype");
if($qos_enable==1&&$qos_type==0)
{
   echo "PriorityByPort=1\n";
}
else
{
   echo "PriorityByPort=0\n";
}

echo "APAifsn=3;7;1;1\n";
echo "APCwmin=4;4;3;2\n";
echo "APCwmax=6;10;4;3\n";
echo "APTxop=0;0;94;47\n";
echo "APACM=0;0;0;0\n";
echo "BSSAifsn=3;7;2;2\n";
echo "BSSCwmin=4;4;3;2\n";
echo "BSSCwmax=10;10;4;3\n";
echo "BSSTxop=0;0;94;47\n";
echo "BSSACM=0;0;0;0\n";
echo "AckPolicy=0;0;0;0\n";
echo "APSDCapable=0\n";
echo "DLSCapable=0\n";
echo "NoForwarding=0\n";
echo "NoForwardingBTNBSSID=0\n";
echo "HideSSID=0\n";
echo "ShortSlot=1\n";
echo "AutoChannelSelect=0\n";
echo "PreAuth=0\n";

/* For DFS test */
echo "IEEE80211H=".$ieee80211h_en."\n";	
echo "CSPeriod=".$csperiod."\n";
echo "RDRegion=".$rdregion."\n";
echo "CarrierDetect=".$carrierdetect."\n";
echo "DfsLowerLimit=".$DfsLowerLimit."\n";	
echo "DfsUpperLimit=".$DfsUpperLimit."\n";
echo "FixDfsLimit=".$FixDfsLimit."\n";
echo "AvgRssiReq=-".$AvgRssiReq."\n";

/* auth and encrytption */
/* auth_type:
	 0:open system, 1:share key,
	 2: WPA, 3: WPA-PSK, 
	 4: WPA2, 5: WPA2-PSK, 
	 6: WPA + WPA2, 7: WPA-PSK + WPA2-PSK,
	 8:802.1X 
*/
/*Cipher Type*/
$cipher = query("/wireless/wpa/wepmode");
/*Authentication*/
$auth_mode = query("/wireless/authentication");
if($cipher == 0)
{
	 echo "EncrypType=NONE\n";
	 echo "AuthMode=OPEN\n";
}
else if($cipher == 1)
{

	echo "EncrypType=WEP\n";
	if($auth_mode == 0){ echo "AuthMode=OPEN\n";}
	else if($auth_mode == 1){ echo "AuthMode=SHARED\n";}
	$defkey_index = query("/wireless/defkey");
	$keyformat = query("/wireless/keyformat");
	
	/*Default Key*/
	/*WEP Key*/
	
	//Ralink chip driver setting:
	//0: Hexadecimal
	//1: ASCII
	if($keyformat == 2){$keytype = 0;}
	else {$keytype = 1;}
	
	echo "DefaultKeyID=".$defkey_index."\n";
	echo "Key1Type=".$keytype."\n";
	echo "Key2Type=".$keytype."\n";
	echo "Key3Type=".$keytype."\n";
	echo "Key4Type=".$keytype."\n";
	
	echo "Key1Str=".query("/wireless/wepkey:1")."\n";
	echo "Key2Str=".query("/wireless/wepkey:2")."\n";
	echo "Key3Str=".query("/wireless/wepkey:3")."\n";
	echo "Key4Str=".query("/wireless/wepkey:4")."\n";
}
else/*WPA / WPA2*/
{
	if($cipher==2){ echo "EncrypType=TKIP\n";}
	else if ($cipher==3){ echo "EncrypType=AES\n";}
	else if ($cipher==4){ echo "EncrypType=TKIPAES\n";}
	else { echo "EncrypType=TKIPAES\n";}
	
	if($auth_mode == 3){ echo "AuthMode=WPAPSK\n";}
	else if($auth_mode == 5){ echo "AuthMode=WPA2PSK\n";}
	else if($auth_mode == 7){ echo "AuthMode=WPAPSKWPA2PSK\n";}
	else{ echo "AuthMode=WPAPSKWPA2PSK\n";}
	
	if(query("/wireless/wpa/wpapsk") != ""){ echo "WPAPSK1=".query("/wireless/wpa/wpapsk")."\n";}
	else { echo "WPAPSK1=12345678\n";}
	
	echo "WPAPSK2=\n";
	echo "WPAPSK3=\n";
	echo "WPAPSK4=\n";
	echo "WPAPSK5=\n";
	echo "WPAPSK6=\n";
	echo "WPAPSK7=\n";
	echo "WPAPSK8=\n";
}

/* SSID */
echo "SSID=".query("/wireless/ssid")."\n";
echo "BssidNum=1\n";
echo "HSCounter=0\n";
echo "HT_HTC=1\n";
echo "HT_RDG=1\n";
echo "HT_LinkAdapt=0\n";
echo "HT_OpMode=0\n";
echo "HT_MpduDensity=5\n";
echo "HT_EXTCHA=1\n";
echo "HT_BW=1\n";
echo "HT_AutoBA=1\n";
echo "HT_BADecline=0\n";
echo "HT_AMSDU=0\n";
echo "HT_BAWinSize=64\n";

$s_gi_11n = query("/wireless/shortguardinterval");
if ($s_gi_11n==""){$s_gi_11n = "0";}
echo "HT_GI=".$s_gi_11n."\n";

echo "HT_STBC=1\n";
echo "HT_MCS=33\n";
echo "HT_TxStream=2\n";
echo "HT_RxStream=2\n";
echo "WscConfMode=0\n";
echo "WscConfStatus=1\n";
echo "AccessPolicy0=0\n";
echo "AccessControlList0=\n";
echo "AccessPolicy1=0\n";
echo "AccessControlList1=\n";
echo "AccessPolicy2=0\n";
echo "AccessControlList2=\n";
echo "AccessPolicy3=0\n";
echo "AccessControlList3=\n";
echo "WdsEnable=0\n";
echo "WdsEncrypType=NONE\n";
echo "WdsList=\n";
echo "WdsKey=\n";
echo "RADIUS_Server=\n";
echo "RADIUS_Port=1812\n";
echo "RADIUS_Key=\n";
echo "RADIUS_Acct_Server=\n";
echo "RADIUS_Acct_Port=1813\n";
echo "RADIUS_Acct_Key=\n";
echo "own_ip_addr=\n";
echo "Ethifname=\n";
echo "EAPifname=\n";
echo "PreAuthifname=\n";
echo "session_timeout_interval=0\n";
echo "idle_timeout_interval=0\n";
echo "WiFiTest=0\n";
echo "TGnWifiTest=0\n";
echo "ApCliEnable=0\n";
echo "ApCliSsid=\n";
echo "ApCliBssid=\n";
echo "ApCliAuthMode=\n";
echo "ApCliEncrypType=\n";
echo "ApCliWPAPSK=\n";
echo "ApCliDefaultKeyId=0\n";
echo "ApCliKey1Type=0\n";
echo "ApCliKey1Str=\n";
echo "ApCliKey2Type=0\n";
echo "ApCliKey2Str=\n";
echo "ApCliKey3Type=0\n";
echo "ApCliKey3Str=\n";
echo "ApCliKey4Type=0\n";
echo "ApCliKey4Str=\n";
?>