#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */

	$TROOT="/etc/templates";
	$wireless_conf = "/var/run/RT2860.dat";
	$ap_igmp_pid = "/var/run/ap_igmp.pid";
	$wlanif  	= query("/runtime/layout/wlanif");
	$wlanmac 	= query("/runtime/nvram/wlanmac");
	if (query("/runtime/router/enable")=="0")
	{	
		$wlanip = query("/runtime/wan/inf:1/ip"); 
	}
	else
	{	
		$wlanip	= query("/lan/ethernet/ip"); 
	}
	$authtype	= query("/wireless/authentication");
	$mbssid		= query("/wireless/multi/state");
	$wps_enable	= query("/wireless/wps/enable");
  $wlanapmode = query("/wireless/ap_mode");
	$wlan2lan	= query("/wireless/bridge/wlan2lan"); if ($wlan2lan!="0")	{$wlan2lan="1";}
	$igmp = query("/wireless/igmp");
	if ($generate_start==1)
	{
		echo "echo Start WLAN interface ".$wlanif." ... > /dev/console\n";
		if (query("/wireless/enable")!=1)
		{
			echo "echo WLAN is disabled ! > /dev/console\n";
			/* Turn off the WLAN LED when wireless is off */
			/*echo "usockc /var/run/fresetd_unixsock RADIO_A_OFF\n";	*/
			exit;
		}
		/*
		Update our wireless state. Don't move the code to other position.
		*/
		echo "rgdb -i -s /runtime/wireless/state 1\n";
		
		if ($wlanapmode==1)
		{
				/*harry add for apc do not support dhcp server*/
			$lanif=query("/runtime/layout/lanif");
                   $dhcpd_if=query("/runtime/layout/lanif");
                   $dhcpd_clearleases=0;
                   $generate_start=0;  
			require("/etc/templates/troot.php");
                   require($template_root."/dhcp/dhcpd.php");
                   /*harry add end*/     
			require($TROOT."/wifi/__wlan_apcmode.php");
			exit;
		}
		/*harry add for apc do not support dhcp server,if switch to apmode from apc, then try to restart it*/
    $dhcpd_if=query("/runtime/layout/lanif");
    $dhcpd_clearleases=0;
    $generate_start=1;
    require("/etc/templates/troot.php");
    require($template_root."/dhcp/dhcpd.php");
            /*harry add end*/
		/* Generate Ralink RT2860 wireless driver configuration file*/
		echo "xmldbc -A ".$TROOT."/wifi/RT2860AP.php > ".$wireless_conf."\n";

		/* re-insert wireless module. */
		require($TROOT."/wifi/restart_wlan_driver.php");

		/* bridge to lan */
		echo "echo ".$wlan2lan." > /proc/net/br_forward_br0\n";

		if ($mbssid == "1")
		{ echo "brctl setfdctrl br0 ra1 off\n";	}

		if ($igmp!=""){	echo "brctl igmp_snooping br0 ".$igmp."\n"; }
		else {	echo "rgdb -s /wireless/igmp 0\n";	}

		/* eric add, 2008/08/25, renew uuid when change back from bridge mode
		 * (WPS compatibility issue) */
		echo "xmldbc -i -s /runtime/upnpdev/root:1/uuid `genuuid -s WFADevice -m ".$wlanmac." `\n";

    if (query("/wireless/wps/enable")=="1") { echo "/etc/templates/wps.sh pre_setie\n"; }

		/* Enable WPS ? */
		$HAPD_wps = 0;	
		if (query("/runtime/func/wps")==1)
		{
			if (query("/wireless/wps/enable")==1)
			{
				$HAPD_wps = 1;
				$HAPD_eapuserfile = "/var/run/hostapd.wps.eap_user";
			}
		}

 	 /* Generate config file for hostapd */
		$HAPD_interface = $wlanif;
		$HAPD_bridge    = "br0";/*$lanif;*/
		$HAPD_conf      = "/var/run/hostapd.".$HAPD_interface.".conf";
		anchor("/wireless");
		require($TROOT."/wifi/hostapd_used.php");
		$hostapd_conf   = $HAPD_conf;
		/*if ($authtype > 1){*/
			echo "hostapd ".$hostapd_conf." &\n";
		/*}*/

		/* Turn on the WLAN LED when wireless is ready. */
		echo "usockc /var/run/fresetd_unixsock RADIO_A_ON\n";
		if (query("/wireless/wps/enable")=="1") { echo "/etc/templates/wps.sh setie\n"; }
		/*echo "/etc/templates/mbssid.sh\n";*/

		//echo "wlxmlpatch -l > /dev/console &\n";
		echo "wlxmlpatch -S ra0 /runtime/stats/wireless RADIO_ON RADIO_BLINK RT2800 > /dev/console &\n";
  	if ($igmp == "1")
		{
   		echo "echo enable > /proc/net/br_igmp_ap_br0\n";
	  	echo "echo setwl ra0 > /proc/net/br_igmp_ap_br0\n";
			echo "ap_igmp &> /dev/console\n";
			echo "echo $! > ".$ap_igmp_pid."\n";
		}	
	}
	else
	{
		echo "echo Stop WLAN interface ... > /dev/console\n";
		if (query("/wireless/enable")!=1)
		{
			echo "echo WLAN is disabled ! > /dev/console\n";
			exit;
		}
		/*
		Update our wireless state. Don't move the code to other position.
		*/
		echo "rgdb -i -s /runtime/wireless/state 0\n";
		echo "killall wlxmlpatch\n";
		if (query("/wireless/wps/enable")=="1") { echo "killall wps > /dev/console\n"; }
		echo "killall wpa_supplicant > /dev/null 2>&1\n";
		echo "killall hostapd > /dev/null 2>&1\n";

		if ($mbssid == "1")
		{	echo "ifconfig ra1 down\n";	}
		echo "killall rt2860apd\n";
		echo "killall -SIGKILL wscd\n";
		/*if (query("/runtime/wps/setting/done") == "1"){
			set("/runtime/wps/setting/done","0");
		}else{
		echo "usockc /var/run/fresetd_unixsock WPS_NONE\n";
		}*/
		echo "ifconfig ".$wlanif." down\n";
		if ($igmp == "1"&&$wlanapmode==0)
		{
			echo "echo disable > /proc/net/br_igmp_ap_br0\n";
			echo "echo unsetwl ra0 > /proc/net/br_igmp_ap_br0\n";
			echo "brctl igmp_snooping br0 0\n";
			echo "if [ -f ".$ap_igmp_pid." ]; then\n";
			echo "kill \`cat ".$ap_igmp_pid."\` > /dev/null 2>&1\n";
			echo "rm -f ".$ap_igmp_pid."\n";
			echo "fi\n\n";
		}
	}
?>
