#!/bin/sh
<?
/*Check if schedule is enable*/
if (query("/schedule/enable")==1)
{
    echo "service WLAN stop\n";
    $enable_flag="0";
    for("/schedule/rule/index")
    {
        if ($enable_flag=="0")
        {
        if(query("/schedule/rule/index:".$@."/enable")==1)
        {
            $Servd_cmd="service WLAN schedule";
            $enable_flag="1";
            $sun=query("/schedule/rule/index:".$@."/sun");
            $mon=query("/schedule/rule/index:".$@."/mon");
            $tue=query("/schedule/rule/index:".$@."/tue");
            $wed=query("/schedule/rule/index:".$@."/wed");
            $thu=query("/schedule/rule/index:".$@."/thu");
            $fri=query("/schedule/rule/index:".$@."/fri");
            $sat=query("/schedule/rule/index:".$@."/sat");
            
            $allday=query("/schedule/rule/index:".$@."/allday");
            $starttime=query("/schedule/rule/index:".$@."/starttime");
            $endtime=query("/schedule/rule/index:".$@."/endtime");
            $wirelesson=query("/schedule/rule/index:".$@."/wirelesson");
            
            if ($wirelesson!="1")
            {
                $Servd_cmd=$Servd_cmd."!";
            }
            $Servd_cmd=$Servd_cmd." ";
            $dot="0";
            if ($sun=="1") {$Servd_cmd=$Servd_cmd."Sun";$dot="1";}
            if ($mon=="1") 
            {   
                if ($dot==1) {$Servd_cmd=$Servd_cmd.",";}
                $Servd_cmd=$Servd_cmd."Mon";$dot="1";
            }
            if ($tue=="1") 
            {   
                if ($dot==1) {$Servd_cmd=$Servd_cmd.",";}
                $Servd_cmd=$Servd_cmd."Tue";$dot="1";
            }
            if ($wed=="1") 
            {   
                if ($dot==1) {$Servd_cmd=$Servd_cmd.",";}
                $Servd_cmd=$Servd_cmd."Wed";$dot="1";
            }
            if ($thu=="1") 
            {   
                if ($dot==1) {$Servd_cmd=$Servd_cmd.",";}
                $Servd_cmd=$Servd_cmd."Thu";$dot="1";
            }
            if ($fri=="1") 
            {   
                if ($dot==1) {$Servd_cmd=$Servd_cmd.",";}
                $Servd_cmd=$Servd_cmd."Fri";$dot="1";
            }
            if ($sat=="1") 
            {   
                if ($dot==1) {$Servd_cmd=$Servd_cmd.",";}
                $Servd_cmd=$Servd_cmd."Sat";$dot="1";
            }
            if ($allday=="1")
            {$Servd_cmd=$Servd_cmd." 00:00 24:00";}
            else
            {$Servd_cmd=$Servd_cmd." ".$starttime." ".$endtime;}   
        }
        }
    }
    if($enable_flag=="1")
    {
        echo $Servd_cmd;
    }
    else
    {
        echo "service WLAN start\n";
    }
}
else
{
    echo "service WLAN stop\n";
    echo "service WLAN start\n";
}


?>