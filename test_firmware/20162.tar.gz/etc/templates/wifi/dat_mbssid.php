<?
/*Primary SSID part*/
/* Count the BSSID number */
$bssid_num = 1;
$mbssid_en=query("/wireless/multi/state");
if ($mbssid_en=="1") {$bssid_num=2;}
echo "BssidNum=".$bssid_num ."\n";
echo "SSID=".query("/wireless/ssid")."\n";
echo "HideSSID=".query("/wireless/ssidhidden")."\n";

$STR_1X="";
$Fixedrateindex = "";
$tmp_wlanmode	= query("/wireless/wlmode"); if($tmp_wlanmode=="")	{$tmp_wlanmode	="8";} /* default wlanmode 802.11an */
$tmp_txrate	= query("/wireless/fixedrate"); if ($tmp_txrate=="")	{$tmp_txrate	="0";}
if ($tmp_wlanmode=="1"/*11g*/ || $tmp_wlanmode=="3"/*11b*/ || $tmp_wlanmode=="7"/*11a*/){$Fixedrateindex = "1";}
if ($Fixedrateindex=="1" ) /* 11b only, or 11g only or 11a only */
{
	/* Ralink is no more support txtrae parameter, 
	 * instead, tx rate is set by  "WirelessMode" and "HT_MCS" combination.		*/
	/*          11B                     11G and 11A                        		*/
	/*--------------------------------------------------------------------------*/
	if($tmp_txrate == "0"	||$tmp_txrate == "4")	{$tmp_mcs_index = 0; }
	else if ($tmp_txrate == "1"	|| $tmp_txrate == "5") {$tmp_mcs_index = 1; }
	else if ($tmp_txrate == "2"	|| $tmp_txrate == "6") {$tmp_mcs_index = 2; }
	else if ($tmp_txrate == "3"	|| $tmp_txrate == "7") {$tmp_mcs_index = 3; }
	else if ($tmp_txrate == "8") {$tmp_mcs_index = 4; }
	else if ($tmp_txrate == "9") {$tmp_mcs_index = 5; }
	else if ($tmp_txrate == "10") {$tmp_mcs_index = 6; }
	else if ($tmp_txrate == "11") {$tmp_mcs_index = 7; }
	else {$tmp_mcs_index = 33;}/* set default as "auto" */
}
else	/* other mixed mode, so set the mcs as "auto". */
{
	$tmp_mcs_index="33";
}
echo "HT_MCS=".$tmp_mcs_index."\n";

/* auth and encrytption */
/* auth_type:
	 0:open system, 1:share key,
	 2: WPA, 3: WPA-PSK, 
	 4: WPA2, 5: WPA2-PSK, 
	 6: WPA + WPA2, 7: WPA-PSK + WPA2-PSK,
	 8:802.1X 
*/
/*Cipher Type*/
$cipher = query("/wireless/wpa/wepmode");
/*Authentication*/
$auth_mode = query("/wireless/authentication");
if($cipher == 0)
{
	 echo "EncrypType=NONE\n";
	 echo "AuthMode=OPEN\n";
}
else if($cipher == 1)
{
	echo "EncrypType=WEP\n";
	
	if($auth_mode == 0){echo "AuthMode=OPEN\n";}
	else if($auth_mode == 1){ echo "AuthMode=SHARED\n"; }
	
	$defkey_index = query("/wireless/defkey");
	$keyformat = query("/wireless/keyformat");
	/*Default Key*/
	/*WEP Key*/
	
	//Ralink chip driver setting:
	//0: Hexadecimal
	//1: ASCII
	if($keyformat == 2){$keytype = 0;}
	else {$keytype = 1;}
	
	echo "DefaultKeyID=".$defkey_index."\n";
	echo "Key1Type=".$keytype."\n";
	echo "Key2Type=".$keytype."\n";
	echo "Key3Type=".$keytype."\n";
	echo "Key4Type=".$keytype."\n";
	echo "Key1Str=".query("/wireless/wepkey:1")."\n";
	echo "Key2Str=".query("/wireless/wepkey:2")."\n";
	echo "Key3Str=".query("/wireless/wepkey:3")."\n";
	echo "Key4Str=".query("/wireless/wepkey:4")."\n";
}
else/*WPA / WPA2*/
{
	if($cipher==2){ echo "EncrypType=TKIP\n";}
	else if ($cipher==3){ echo "EncrypType=AES\n";}
	else if ($cipher==4){ echo "EncrypType=TKIPAES\n";}
		
	if($auth_mode == 3){ echo "AuthMode=WPAPSK\n";}
	else if($auth_mode == 5){ echo "AuthMode=WPA2PSK\n";}
	else if($auth_mode == 7){ echo "AuthMode=WPAPSKWPA2PSK\n";}
	else if ($auth_mode == 2){ echo "AuthMode=WPA\n"; $need_radius="1";}
	else if($auth_mode == 4){ echo "AuthMode=WPA2\n"; $need_radius="1";}
	else if($auth_mode == 6){ echo "AuthMode=WPA1WPA2\n"; $need_radius="1";}
}	
	
/*if ($STR_1X!="")
{
	echo "IEEE8021X="		.$STR_1X			."\n";
}
if ($need_radius=="1")
{
	anchor("/wlan/inf:3/wpa/radius:1");
	$STR_RADIUS_SRV	=query("host");
	$STR_RADIUS_PORT=query("port");
	$STR_KEY		=query("secret");
	echo "RADIUS_Server="	.$STR_RADIUS_SRV	."\n";
	echo "RADIUS_Port="		.$STR_RADIUS_PORT	."\n";
	echo "RADIUS_Key=".		.$STR_KEY			."\n";
}
if ($need_radius=="1" || $need_psk=="1")
{
	anchor("/wlan/inf:3");
	$rekey_interval =query("wpa/grp_rekey_interval");
	$pmk_period     =query("wpa/pmkperiod");    if ($pmk_period=="")    {$pmk_period="10";}
	$rekey_method   =query("wpa/rekeymethod");  if ($rekey_method=="")  {$rekey_method="DISABLE";}
	echo "RekeyInterval="	.$rekey_interval	."\n";
	echo "RekeyMethod="		.$rekey_method		."\n";
	echo "PMKCachePeriod="	.$pmk_period		."\n";
	echo "own_ip_addr="		.$wlan_ip			."\n";
}*/

/* WMM */
echo "WmmCapable=".$wmm."\n";
echo "TxBurst=".$txburst."\n";
/***********************************************************************************
 * Ralink:
 *	1. no matter wmm is diabled or enabled, the WMM parameters should be set.
 *	2. Both of parameter for STA and AP have to be set. (from Ralink)
 ***********************************************************************************/
/* AP */
echo "APAifsn=3;7;1;1\n";
echo "APCwmin=4;4;3;2\n";
echo "APCwmax=6;10;4;3\n";
if($WMM_PAR=="11b")	{	echo "APTxop=0;0;188;102\n";}
else { echo "APTxop=0;0;94;47\n";}
echo "APACM=0;0;0;0\n";
/* STA */
echo "BSSAifsn=3;7;2;2\n";
echo "BSSCwmin=4;4;3;2\n";
echo "BSSCwmax=10;10;4;3\n";
if($WMM_PAR=="11b")	{	echo "BSSTxop=0;0;188;102\n";}
else { echo "BSSTxop=0;0;94;47\n";}
echo "BSSACM=0;0;0;0\n";
echo "AckPolicy=0;0;0;0\n";
echo "APSDCapable=1\n";
?>
