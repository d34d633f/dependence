#!/bin/sh
type=`rgdb -g /wan/rg/inf:1/etherlinktype`
gtype=`rgdb -g /wan/rg/inf:1/greenethernet`
[ "$type" = "" ] && type=0
echo Set WAN port media type $type > /dev/console
slinktype -i 4 -d "$type" > /dev/console
sleep 2
[ "$gtype" = "" ] && gtype=1
echo Set WAN port greenethernet type $gtype > /dev/console
greenethernet -i  "$gtype"  > /dev/console
sleep 1
