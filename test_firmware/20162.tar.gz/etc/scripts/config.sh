#!/bin/sh
nvram=`cat /etc/config/nvram`
image_sign=`cat /etc/config/image_sign`

case "$1" in
start)
	echo "Mounting proc and var ..."
	mount -t proc none /proc
	mount -t ramfs ramfs /var
	mkdir -p /var/etc /var/log /var/run /var/state /var/tmp /var/etc/ppp /var/etc/config
	echo -n > /var/etc/resolv.conf
	echo -n > /var/TZ

	# UNIX 98 pty
	mknod -m666 /dev/pts/0 c 136 0
	mknod -m666 /dev/pts/1 c 136 1


	echo "Inserting modules ..." > /dev/console
	#echo "Inserting Rebootm ..." > /dev/console
	#insmod /lib/modules/rebootm.ko
	# ethernet driver
	# wireless driver

	# get the country code for madwifi, default is fcc.
	ccode=`devdata get -e countrycode`
	[ "$ccode" = "" ] && ccode="840"

	env_wlan=`devdata get -e wlanmac`
	[ "$env_wlan" = "" ] && env_wlan="00:13:10:d1:00:02"

	# prepare db...
	echo "Start xmldb ..." > /dev/console
	xmldb -n $image_sign -t > /dev/console &
	sleep 1
	/etc/scripts/misc/profile.sh get
	/etc/templates/timezone.sh set
	
	#  syslogd_2007_02_02 , Jordan recover log message
	touch /var/log/messages
	rgdb -i -s /runtime/log/first_init "1"
	rgdb -i -s /runtime/log/Remote_log_init "1"
	/etc/templates/logs.sh
	rgdb -i -s /runtime/log/first_init "0"

	echo "Inserting modules ..." > /dev/console
	# Software I2C module for switch RTL8366SR
	insmod si2c.o

	# bring up network devices
	env_wan=`rgdb -i -g /runtime/layout/wanmac`
	[ "$env_wan" = "" ] && env_wan="00:13:10:d1:00:01"
	ifconfig eth0 hw ether $env_wan up
	rgdb -i -s /runtime/wan/inf:1/mac "$env_wan"

	# bring up loopback interface
	ifconfig lo up

	brctl addbr br0 	> /dev/console
	brctl stp br0 off	> /dev/console
	brctl setfd br0 0	> /dev/console

	;;
stop)
	umount /tmp
	umount /proc
	umount /var
	;;
esac
