<?
anchor("/sys");
set("modelname",	"DAP-1522");
set("devicename",	"D-Link Wireless Access Point");
set("modeldescription",	"Wireless N Access Point");
set("vendor",		"D-Link");
set("url",		"http:\/\/www.dlink.com");
set("ipaddr",		"192.168.0.1");
set("netmask",		"255.255.255.0");
set("startip",		"192.168.0.100");
set("endip",		"192.168.0.199");
set("ssid",		"dlink");

set("locale",					"en");
set("authtype",		"s");

set("/function/no_jumpstart", "1");
set("/function/normal_g", "1");
set("/function/bridgemode", "1");

set("/nat/vrtsrv/max_rules",		"10");
set("/nat/porttrigger/max_rules",	"10");
set("/security/macfilter/max_rules",	"10");
set("/security/urlblocking/max_rules",	"20");

/* web_upnp, added by Enos, 2008/01/31 , setnodes.php */
set("/function/httpd_upnp", "1");
/*dhcp_server, added by Erial */
set("/lan/dhcp/server/pool:1/staticdhcp/max_client", "16");
set("/runtime/func/static_dhcp",    "1");

/*information for hidden page , added by Erial */
set("wlandriverver","rt2860 v2.0.0.0");
set("kernel_version","Linux version 2.4.30"); 
?>
