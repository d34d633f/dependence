<?
$bverrev = fread("/etc/config/buildrev");
$lanmac	= query("/runtime/nvram/lanmac");
$wanmac	= query("/runtime/nvram/wanmac");
$hwrev	= query("/runtime/nvram/hwrev");
$pin	= query("/runtime/nvram/pin");
$ccode	= query("/runtime/nvram/countrycode");
/* sanity check */
if ($lanmac == "")	{ $lanmac="00:de:fa:15:00:01"; }
if ($wanmac == "")	{ $wanmac="00:de:fa:15:00:02"; }
if ($hwrev  == "")	{ $hwrev="N/A"; }
if ($ccode  == "") 	{$ccode = "840";}
/* SET nodes */
/* -- layout */

anchor("/runtime/layout");
set("wanmac",		$wanmac);
set("lanmac",		$lanmac);
set("wlanmac",		$lanmac);
set("wanif",		"eth0");
set("lanif",		"br0");
set("wlanif",		"ra0");
set("countrycode",	$ccode);
/* -- traffic manager dev -- */
set("tc_wanif",     "v_eth0");
set("tc_wlanif",    "v_ra0");

/* -- sys info*/
if ($ccode == "840") {
	$regdomain = "fcc";
} else if ($ccode == "392") {
	$regdomain = "mkk";
} else {
	$regdomain = "etsi";
}
set("/sys/regdomain", $regdomain);
set("/runtime/sys/info/dummy", "");
anchor("/runtime/sys/info");
set("hardwareversion",$hwrev);
set("firmwareverreve",$bverrev);

/* -- WPS pin */
set("/runtime/wps/pin",$pin);
/* -- others */
set("/sys/telnetd","true");
set("/sys/sessiontimeout","180");
set("/proc/web/sessionum","8");
set("/proc/web/authnum","6");
?>
