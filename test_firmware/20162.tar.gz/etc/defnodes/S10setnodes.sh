#!/bin/sh
echo [$0] ... > /dev/console

nvram=`		cat /etc/config/nvram`
imagesign=`	cat /etc/config/image_sign`
buildver=`	cat /etc/config/buildver`
buildrev=`	cat /etc/config/buildrev`
buildno=`	cat /etc/config/buildno`
builddate=`	cat /etc/config/builddate`

# Prepare MAC addresses

xmldbc -x /runtime/nvram/flashspeed				"get:devdata get -e flashspeed"
xmldbc -x /runtime/nvram/pin					"get:devdata get -e pin"
xmldbc -x /runtime/nvram/wanmac					"get:devdata get -e wanmac"
xmldbc -x /runtime/nvram/wlanmac				"get:devdata get -e wlanmac"
xmldbc -x /runtime/nvram/hwrev					"get:devdata get -e hwrev"
xmldbc -x /runtime/nvram/countrycode			"get:devdata get -e countrycode"

# Set firmware version
rgdb -i -s "/runtime/sys/info/firmwareversion"	"$buildver"
rgdb -i -s "/runtime/sys/info/firmwarebuildno"	"$buildno"
rgdb -i -s "/runtime/sys/info/firmwarebuildate"	"$builddate"
rgdb -i -s "/runtime/sys/info/firmwarebuildrev" "$buildrev"
rgdb -i -s "/runtime/layout/image_sign"			"$imagesign"

rgdb -A /etc/defnodes/__flashspeed.php -V "flashspeed=$fspeed"

