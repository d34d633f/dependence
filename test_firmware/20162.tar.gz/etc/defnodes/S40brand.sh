#!/bin/sh

# added by Enos, 2008/01/31 , wps
xmldbc -x /runtime/genuuid "get:genuuid -r"
xmldbc -x /runtime/genpin  "get:wps -g"

# added by Enos, 2008/01/31 , upnp_wfa.sh
LANMAC=`rgdb -i -g /runtime/layout/wanmac`
xmldbc -i -s /runtime/upnpdev/root:1/uuid `genuuid -s WFADevice -m $LANMAC`
xmldbc -i -s /runtime/upnpdev/root:2/uuid `genuuid -s WLANAccessPointDevice -m $LANMAC`

