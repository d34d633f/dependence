//BRS_01_checkNet.html
bh_internet_checking="Internetkapcsolat ellenőrzése; kérem, várjon …"


//BRS_02_genieHelp.html
bh_config_net_connection="Internetkapcsolat konfigurálása"

bh_connection_further_action="Még nincs csatlakozva az internethez."

bh_want_genie_help="Szeretné, hogy a NETGEAR genie a segítségére legyen?"

bh_yes_mark="Igen"

bh_no_genie_help="Nem, magam szeretném konfigurálni az internetkapcsolatot."

bh_no_genie_help_confirm="Az internetkapcsolat konfigurálása hálózati tapasztalatot igényel. Biztosan ezt kívánja tenni?"

bh_have_saved_copy="Az útválasztó beállításait egy fájlba mentettem, és most szeretném visszaállítani az útválasztót azokra a beállításokra."

bh_next_mark="Tovább"


//BRS_03A_detcInetType.html
bh_detecting_connection="Internetkapcsolat azonosítása"

bh_plz_wait_process="A folyamat eltarthat egy-két percig; kérem, várjon..."


//BRS_03A_A_noWan.html
bh_no_cable="Nincs Ethernet kábel csatlakoztatva az útválasztó internetes portjához."

bh_wizard_setup_nowan_check="Ellenőrizze, hogy a kábel megfelelő módon van-e csatlakoztatva a szélessávú modem portjához, illetve az útválasztó internetes portjához."

bh_click_try_again="Ellenőrizze az Ethernet kábelt, majd kattintson a <b>Próbálja újra</b> opcióra."

bh_try_again="Próbálja újra"


//BRS_03A_B_pppoe.html
bh_pppoe_connection="A rendszer PPPoE DSL internetkapcsolatot azonosított"

bh_enter_info_below="Adja meg lentebb a szükséges adatokat."

bh_pppoe_login_name="Felhasználónév"
bh_ddns_passwd="Jelszó"


//BRS_03A_B_pppoe_reenter.html
bh_ISP_namePasswd_error="Hibás internetszolgáltatói felhasználónév vagy jelszó"

bh_enter_info_again="Adja meg újra a szükséges adatokat."


//BRS_03A_C_pptp.html
bh_pptp_login_name="Bejelentkezés"

bh_pptp_connection="A rendszer PPTP internetkapcsolatot azonosított"

bh_basic_pptp_servip="Kiszolgáló címe"

bh_sta_routes_gtwip="Átjáró IP-címe"

bh_basic_pptp_connection_id="Kapcsolat azonosítója/neve"

//BRS_03A_F_l2tp.html
bh_l2tp_connection="A rendszer L2TP internetkapcsolatot azonosított"

//BRS_03A_D_bigpond.html
bh_bpa_connection="A rendszer BigPond internetkapcsolatot azonosított"

bh_basic_bpa_auth_serv="Hitelesítési kiszolgáló"

bh_basic_pppoe_idle="Üresjárati időkorlát (perc)"


//BRS_03A_E_IP_problem_staticIP.html
bh_no_internet_ip="Probléma az internetkapcsolat azonosításával"

bh_no_internet_ip2="Probléma az internetkapcsolat azonosításával – IP-cím"

bh_no_internet_ip3="Probléma az internetkapcsolat azonosításával – MAC-cím"

bh_if_have_static_ip="Internetszolgáltatója statikus (fix) IP-címet bocsátott rendelkezésére? Ez <b>nagyon ritka</b> eset. "

bh_yes_correct="Igen. Internetszolgáltatóm statikus (fix) IP-címet bocsátott rendelkezésemre."

bh_not_have_static_ip="Nem, internetszolgáltatóm nem bocsátott rendelkezésemre statikus (fix) IP-címet."

bh_do_not_know="Nem tudom. "

bh_select_option="Válasszon ki egy opciót, majd a folytatáshoz kattintson a <b>Tovább</b> gombra."

bh_select_an_option="Előbb válasszon a lehetőségek közül."


//BRS_03A_E_IP_problem_staticIP_A_inputIP.html
bh_fix_ip_setting="Statikus (fix) internetes IP-beállítások"

bh_enter_ip_setting="Adja meg az internetszolgáltatójától kapott statikus (fix) IP-címet, majd a folytatáshoz kattintson a <b>Tovább</b> gombra."

bh_info_mark_ip="IP-cím"
//var bh_info_mark_ip="Saját IP-cím"
bh_info_mark_mask="Alhálózati maszk"

bh_constatus_defgtw="Alapértelmezett átjáró"

bh_preferred_dns="Preferált DNS kiszolgáló"

bh_alternate_dns="Helyettesítő DNS kiszolgáló"

bh_basic_int_third_dns="Harmadik DNS"

//BRS_03A_E_IP_problem.html
bh_genie_cannot_find_ip="Ennek oka valószínűleg a következő esetek valamelyike:"
bh_genie_cannot_find_ip_reason1="1.  A modem nem volt megfelelően újraindítva a kábelezési lépés során."
bh_genie_cannot_find_ip_reason1_desc="A probléma megoldásához indítsa újra a modemet (kapcsolja ki, majd be). Ha a modem akkumulátorral működik, újraindításához szükség lehet az akkumulátor eltávolítására, majd visszahelyezésére. Az újraindítást követően várjon 2 percet a modem teljes elindulásáig."
bh_genie_cannot_find_ip_reason2="2.  A sárga Ethernet kábel nincs teljesen csatlakoztatva, illetve rossz helyre van csatlakoztatva."
bh_genie_cannot_find_ip_reason2_desc="A probléma megoldásához győződjön meg arról, hogy a sárga Ethernet kábel megfelelően csatlakoztatva van a szélessávú modem portjához és az útválasztó internetes portjához."

bh_select_no_IP_option="Válassza ki az alábbi opciók egyikét, majd folytatáshoz kattintson a <b>Tovább</b> gombra:"
bh_select_no_IP_option1="Éppen elindítottam a modemet, és vártam 2 percig."
bh_select_no_IP_option2="Ethernet kábellel oldottam meg egy problémát."
bh_select_no_IP_option3="A fentiek egyike sem."


//BRS_03A_E_IP_problem_staticIP_B_macClone.html
bh_use_pc_mac="Ha előzőleg számítógéppel vagy egy másik útválasztóval csatlakozott az internethez, a NETGEAR genie a már előzőleg használt MAC-címet használhatja."

bh_mac_in_product_label="A MAC-cím egy egyedi szám.  A számítógép, illetve az útválasztó MAC-címe a terméklapon található."

bh_enter_mac="Adja meg a MAC-címet."

bh_mac_format="(formátum: AABBCCDDEEFF)"


//BRS_03B_haveBackupFile.html
bh_settings_restoration="Az útválasztó beállításainak visszaállítása "

bh_browser_file="Tallózzon az útválasztó beállításainak korábban elmentett biztonsági mentés fájljára, majd a folytatáshoz kattintson a <b>Tovább</b> gombra."

bh_back_mark="Vissza"


//BRS_03B_haveBackupFile_fileRestore.html
bh_settings_restoring="Az útválasztó beállításainak visszaállítása"

bh_plz_waite_restore="Ez eltarthat néhány percig; kérem, várjon …"


//BRS_04_applySettings.html
bh_apply_connection="Az internetkapcsolat beállításainak alkalmazása"

bh_plz_waite_apply_connection="A folyamat eltarthat egy-két percig; kérem, várjon..."


//BRS_05_networkIssue.html
bh_netword_issue="Hálózati csatlakozási probléma"

bh_cannot_connect_internet="A jelenlegi beállításokkal az útválasztó nem tud az internethez kapcsolódni."

bh_plz_reveiw_items="Kérjük, tekintse át a következőket:"

bh_cable_connection="- Ellenőrizze, hogy a kábelek csatlakozása megfelelő-e. Kövesse az útválasztó telepítési útmutatójának utasításait."

bh_modem_power_properly="- Ellenőrizze, hogy a szélessávú modem megfelelő módon van-e csatlakoztatva. Ha akkumulátorral működtetett modemmel rendelkezik, a modem újraindításához távolítsa el az akkumulátort, majd helyezze vissza."

bh_try_again_or_manual_config="Szeretné, hogy a NETGEAR genie újra próbálja?"

bh_I_want_manual_config="Nem. Magam szeretném konfigurálni az internetkapcsolatot."

bh_manual_config_connection="Magam szeretném konfigurálni az internetkapcsolatot"


//BRS_success.html
bh_congratulations="Gratulálunk!"

bh_connect_success_1="A csatlakozás az internethez sikeresen megtörtént."

bh_connect_success_2="Ez az útválasztó a következő előre megadott beállításokkal rendelkezik: egyedi vezeték nélküli hálózati név (SSID) és "

bh_network_key="hálózati kulcs (jelszó)"

bh_rollover_help_text="Az útválasztó WPA2-PSK vezeték nélküli biztonsággal van eleve ellátva a hálózat illetéktelen hozzáférés elleni védelme érdekében. Vezeték nélküli hálózatra való csatlakozáshoz hálózati kulcsot (jelszót) kell megadnia. Az előzetesen megadott beállítások a készülék egyedi adatai, akár a gyári szám.  Ha szeretné ezeket módosítani, később megteheti ezt az útválasztó webes felhasználói felületének Vezeték nélküli beállítások képernyőjén."

bh_success_no_wireless_security_1 ="A vezeték nélküli biztonság nem engedélyezett ezen az útválasztón. A NETGEAR nyomatékosan ajánlja, hogy "
bh_success_no_wireless_security_2 ="kattintson ide"
bh_success_no_wireless_security_3 =" engedélyezze a vezeték nélküli biztonságot és a hálózat védelmét."

bh_wirless_name="Vezeték nélküli hálózat neve (SSID)"

bh_wireless="Vezeték nélküli"

bh_wpa_wpa2_passpharse="Hálózati kulcs (jelszó)"

bh_save_settings="Save router settings"

bh_print_this="Nyomtatás"


bh_take_to_internet="Továbblépés az internetre"

bh_plz_wait_moment="Kérem, várjon egy pillanatig..."

//the string for not_support_print is temporary.
bh_not_support_print="A számítógép nem támogatja a nyomtatót."
//already exist
bh_login_name_null="A felhasználó neve nem lehet üres."
bh_password_error="Érvénytelen jelszó."
bh_idle_time_null="Kérem, adja meg az üresjárati időt.\n"
bh_invalid_idle_time="Érvénytelen üresjárati idő. Kérem, adjon meg megfelelő számot.\n"
bh_invalid_myip="Érvénytelen IP-cím. Kérem, adja meg újra, vagy hagyja üresen."
bh_invalid_gateway="Érvénytelen átjáró IP-cím. Kérem, adja meg újra.\n"
bh_bpa_invalid_serv_name="Érvénytelen a hitelesítő kiszolgáló IP-címe."
bh_invalid_servip_length="A címkék max. 63 karaktert tartalmazhatnak.\n"
bh_invalid_ip="Érvénytelen IP-cím. Kérem, adja meg újra."
bh_invalid_mask="Érvénytelen alhálózati maszk. Kérem, adja meg újra.\n"
bh_same_subnet_ip_gtw="Az IP-címnek és az átjáró címének egyazon alhálózatban kell lennie.\n"
bh_same_lan_wan_subnet="A LAN IP-címe és a WAN IP-címe nem lehet egyazon alhálózatban.\n"
bh_filename_null="A fájlnév nem lehet üres."
bh_not_correct_file="Kérem, rendelje hozzá a megfelelő fájlt. A fájlformátum *."
bh_ask_for_restore="Figyelmeztetés \nA beállítások visszaállítása a konfigurációs fájlból törli a jelenlegi beállításokat. \nBiztosan ezt kívánja tenni?"
bh_invalid_primary_dns="Érvénytelen elsődleges DNS-cím. Kérem, adja meg újra.\n"
bh_invalid_second_dns="Érvénytelen másodlagos DNS-cím. Kérem, adja meg újra.\n"
hb_invalid_third_dns="Érvénytelen harmadlagos DNS-cím. Kérem, adja meg újra."
bh_dns_must_specified="Meg kell adnia DNS-címet."
bh_invalid_mac="Érvénytelen MAC-cím."
bh_failure_head="Hiba"
bh_few_second="A képernyő néhány másodperc múlva automatikusan az előző képernyőre vált..."

bh_important="Fontos frissítés"
bh_wanlan_conflict_info="Az internetszolgáltatóval való ütközés elkerülése érdekében útválasztójának IP-címe a következőre módosult: "
bh_continue_mark="Folytatás"


//readySHARE remote strings
remote_share_head="ReadySHARE Cloud"

ready_share_info1="A ReadySHARE Cloud funkció interneten keresztüli, távoli hozzáférést biztosít az útválasztó USB-portjához csatlakoztatott USB-tárolóeszközhöz."
how_setup_ready_share="A ReadySHARE Cloud telepítése"
ready_share_step1="1. lépés: egy ReadySHARE Cloud fiókra van szükség. Ha még nem rendelkezik ilyennel,<a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>kattintson ide</a> a létrehozáshoz."
ready_share_step2="2. lépés: ezen az oldalon adja meg ReadySHARE Cloud felhasználónevét és jelszavát az útválasztó és a fiókjával hozzá csatlakoztatott USB-eszköz regisztrálásához."
ready_share_step3="3. lépés: fiókjával jelentkezzen be ismét a <a class='linktype' target='_blank' href='http://readyshare.netgear.com/'>http://readyshare.netgear.com/</a> weboldalra. Ekkor látnia kell az útválasztóhoz csatlakoztatott USB-eszközt."
ready_share_step4="4. lépés: első alkalommal a rendszer egy Windows kliens letöltésére kéri, amely a számítógép és az útválasztó USB-eszköze közötti biztonságos kapcsolat létrehozásához szükséges. Jelentkezzen be ebbe a kliensbe, és máris bárhonnan hozzáférhet az USB-eszközhöz."
ready_share_set_note="<b>Megjegyzés:</b> a kliens nélkül csak böngészheti az USB-eszköz tartalmát, ám nem nyithatja meg, illetve nem módosíthatja a fájlokat."
ready_share_start="Kezdje el a műveletet most a ReadySHARE Cloud engedélyezéséhez"
ready_share_get_account="Ha még nem rendelkezik ReadySHARE Cloud fiókkal, <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>kattintson ide</a>"
username="Felhasználónév"
key_passphrase="Jelszó"
register="Regisztráció"
register_note="<b>Megjegyzés:</b> az internetkapcsolat a regisztráció megszüntetésig él."
help_center="Súgó központ"
help_show_hide="Súgó központ mutatása/elrejtése"

resister_user="A ReadySHARE Cloud a következő felhasználóhoz van regisztrálva:"
access_storage_method="A fenti 2~4. lépés végrehajtásával bárhonnan hozzáférhet a tárolóhoz."
unregister_info="A ReadySHARE Cloud egy másik felhasználóhoz való regisztrálásához kattintson a <B>Regisztráció megszüntetése (Unregister)</B> opcióra."
unregister="Regisztráció törlése"

result_register_ok="Regisztráció sikeresen végrehajtva"
result_register_fail="Regisztráció sikertelen"
result_unreg_ok="Regisztráció megszüntetése sikeresen végrehajtva"
result_unreg_fail="Regisztráció megszüntetése sikertelen"


