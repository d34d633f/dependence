#!/bin/sh

# Should start syslog server also and before klog, later it will be killed and restarted by translator.
# Error check needed?

ncecho 'Starting System Logger.     '
${SYSLOGD} -O ${LOG_FILE} -s ${LOG_SIZE} -b ${NO_OF_OLD_LOGS} -D -S
cecho green '[DONE]'


ncecho 'Starting Kernel Logger.     '
${KLOGD} -c ${KLOGD_LOG_LEVEL}
cecho green '[DONE]'


if [ ${PLATFORM} ]; then
insmod /lib/modules/proc_mods/proc_gpio.ko
insmod /lib/modules/activity_led/activity_led.ko
/usr/bin/set_manuinfo
/usr/bin/reset_button &
fi

echo 23 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio23/direction
echo 24 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio24/direction
echo 25 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio25/direction
echo 26 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio26/direction
echo 3 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio3/direction
