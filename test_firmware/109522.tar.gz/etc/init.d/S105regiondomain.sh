#!/bin/sh

FCC_BUILD=0
ENABLE=1
if [ ${FCC_BUILD} == ${ENABLE} ];then
PRODUCT=`printmd | grep -i ProductId | cut -d ' ' -f 3`
if [ ${PRODUCT} == "WNDAP350" ] || [ ${PRODUCT} == "wndap350" ] || [ ${PRODUCT} == "WNDAP620" ] || [ ${PRODUCT} == "wndap620" ] || [ ${PRODUCT} == "WNDAP930" ] || [ ${PRODUCT} == "wndap930" ] || [ ${PRODUCT} == "WND930" ] || [ ${PRODUCT} == "wnd930" ];then
ncecho 'Checking region domain info     '
else
return
fi
if [ ${PRODUCT} == "WNDAP350" ] || [ ${PRODUCT} == "wndap350" ] || [ ${PRODUCT} == "WNDAP620" ] || [ ${PRODUCT} == "wndap620" ];then
new_region_domain=3
elif [ ${PRODUCT} == "WND930" ] || [ ${PRODUCT} == "wnd930" ] || [ ${PRODUCT} == "WNDAP930" ] || [ ${PRODUCT} == "wndap930" ];then
new_region_domain=4
else
return
fi
#ACQUILA_CODE_BASE
if [ ${PRODUCT} == "WNDAP660" ] || [ ${PRODUCT} == "wndap660" ] || [ ${PRODUCT} == "WNDAP620" ] || [ ${PRODUCT} == "wndap620" ] || [ ${PRODUCT} == "WND930" ] || [ ${PRODUCT} == "wnd930" ] || [ ${PRODUCT} == "WNDAP930" ] || [ ${PRODUCT} == "wndap930" ];then
unitedstates=841
else
unitedstates=840
fi
#ARIES_CODE_BASE
if [ ${PRODUCT} == "WNAP210V2" ] || [ ${PRODUCT} == "WNAP210v2" ] || [ ${PRODUCT} == "WNAP210" ] || [ ${PRODUCT} == "wnap210V2" ] || [ ${PRODUCT} == "wnap210v2" ] || [ ${PRODUCT} == "wnap210" ];then
cannada=124
else
cannada=5001
fi
#endif
#new country code for  unitedstates and cannada
unitedstates2=843
cannada2=5004

regioninfo=$(/usr/bin/printmd | grep reginfo | cut -d ' ' -f3)
countrycode=$(conf_get system:basicSettings:sysCountryRegion | cut -d ':' -f3 | cut -d ' ' -f2 )

if [ $regioninfo = $new_region_domain ];then
if [ $countrycode = $unitedstates ];then
conf_set system:basicSettings:sysCountryRegion $unitedstates2
sleep 2
conf_save
sleep 2
echo "rebooting $PRODUCT to load with proper region domain"
reboot
elif [ $countrycode = $cannada ];then
conf_set system:basicSettings:sysCountryRegion $cannada2
sleep 2
conf_save
sleep 2
echo "rebooting $PRODUCT to load with proper region domain"
reboot
else
# do nothing
echo '[DONE]'
echo ""
fi

#old region code (0,1,2)
else
if [ $countrycode = $unitedstates2 ];then
conf_set system:basicSettings:sysCountryRegion $unitedstates
sleep 2
conf_save
sleep 2
echo "rebooting $PRODUCT to load with proper region domain"
reboot
elif [ $countrycode = $cannada2 ];then
conf_set system:basicSettings:sysCountryRegion $cannada
sleep 2
conf_save
sleep 2
echo "rebooting $PRODUCT to load with proper region domain"
reboot
else
#do nothing
echo  '[DONE]'
echo ""
fi
fi
fi
