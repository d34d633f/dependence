<?php
	@include('sessionCheck.inc');
	if("WND930"==$_REQUEST['product']) {
		exec("wr_mfg_data -p ".$_REQUEST['product']);								//This will work on Board...
		echo $_REQUEST['product'];
    }
?>
