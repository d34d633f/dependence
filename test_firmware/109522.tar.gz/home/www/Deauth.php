<?php
@include('sessionCheck.inc');
$opm=$_REQUEST["opmode"];
if($_REQUEST['macAddress'])
{
	$MACADDRESS = array_filter(explode(",",$_REQUEST['macAddress']));
		$x=count($MACADDRESS);
		for($i=1;$i<=$x;$i++){	
			$mac = str_replace("\'","",$MACADDRESS[$i]);
			$mac1 = str_replace("-",":", $mac);
			$macPattern  = '/^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$/';
			if(preg_match($macPattern,$mac1) && !strpos($mac1,' ')){
			if($opm == 'wlan0')			
			exec(" /usr/local/sbin/wlanconfig wifi0vap0 rougeap_deauth_mac ".$mac1);
			else
			exec(" /usr/local/sbin/wlanconfig wifi1vap0 rogueap_deauth_mac ".$mac1);
		}					
	}
	}
	unset($MACADDRESS);
	unset($str);
?>
