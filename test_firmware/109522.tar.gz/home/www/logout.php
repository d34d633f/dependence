<?php
    if ($_REQUEST['logout']=='logout') {
		session_start();
		if ($_REQUEST['emptySession'] == false) {
			$sd = explode(',',@file_get_contents('/tmp/sessionid'));
			if ($sd[0] == session_id()){
				@unlink('/tmp/sessionid');
				exec('rm -rf /tmp/sess_*');
				if(isset($_COOKIE[session_name()])) { 
					// Delete the session cookie 
					setcookie(session_name(), "", time() - 1);
				}
				session_destroy();
			}
		}
		exec('rm -rf /tmp/sess_*');
		if(isset($_COOKIE[session_name()])) {                                                                                           
			// Delete the session cookie 
			setcookie(session_name(), "", time() - 1);                                                                              
		}
		session_destroy();
		echo 'logoutok';
	}
	else {
		echo 'failed';
	}
?>
