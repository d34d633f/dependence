<?php /* Smarty version 2.6.18, created on 2011-12-19 16:08:58
         compiled from AdvancedEthernetLLDP.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'input_row', 'AdvancedEthernetLLDP.tpl', 15, false),)), $this); ?>
	<tr>
		<td>	
			<table class="tableStyle">
				<tr>
					<td colspan="3"><script>tbhdr('Ethernet LLDP','ethernetLLDP')</script></td>
				</tr>
				<tr>
					<td class="subSectionBodyDot">&nbsp;</td>
					<td class="spacer100Percent paddingsubSectionBody">
						<table class="tableStyle">
							<?php $this->assign('ethLLDP', $this->_tpl_vars['data']['basicSettings']['lldpStatus']); ?>
							<?php echo smarty_function_input_row(array('label' => 'Ethernet LLDP','id' => 'LLDP','name' => "system[basicSettings][lldpStatus]",'type' => 'radio','options' => "1-Enable,0-Disable",'value' => $this->_tpl_vars['ethLLDP'],'selectCondition' => "==".($this->_tpl_vars['ethLLDP'])), $this);?>
					
						</table>
					</td>
					<td class="subSectionBodyDotRight">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" class="subSectionBottom"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td class="spacerHeight21"></td>
	</tr>
	
	<script language="javascript">
	<!--
			<?php if ($this->_tpl_vars['config']['CLIENT']['status']): ?>
				<?php if (( $this->_tpl_vars['config']['TWOGHZ']['status'] && $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan0']['apMode'] == 5 ) || ( $this->_tpl_vars['config']['FIVEGHZ']['status'] && $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan1']['apMode'] == 5 )): ?>
					Form.disable(document.dataForm);
				<?php endif; ?>
			<?php endif; ?>
			
	-->
	</script>
	