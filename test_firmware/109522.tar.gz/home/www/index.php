#!/usr/bin/php
<?
$ipAdd = explode(' ', conf_get('system:monitor:ipAddress'));
if($_SERVER['HTTP_HOST'] != $ipAdd[1]) {
    die('Your Request is not Correct!');
} else {
require_once 'common.php';

$GUIobject = new webGUI($template,empty($_REQUEST['page'])?'main':$_REQUEST['page']);

$GUIobject->setNavigation();

if ($GUIobject->sessionEnabled()) {
	
	$GUIobject->doAction();

	$GUIobject->getData();
}

$GUIobject->setTemplateName();
	
$GUIobject->setTemplateVars();

$GUIobject->displayTemplate();
}
?>
