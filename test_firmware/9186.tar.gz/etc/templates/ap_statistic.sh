#!/bin/sh
echo [$0] ... > /dev/console
statistic &> /dev/console
