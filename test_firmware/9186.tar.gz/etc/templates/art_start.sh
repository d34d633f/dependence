#!/bin/sh
echo [$0] ... > /dev/console 
	echo Start art module ... > /dev/console

#	APBAND=`rgdb -g /wlan/ch_mode`

#	if [ "$APBAND" = "1" ]; then 
#	    echo Stop normal wireless 11na ... > /dev/console
# 	    [ -f /var/run/wlan_a_stop.sh ] && sh /var/run/wlan_a_stop.sh 
#	else 
#	    echo Stop normal wireless 11ng ... > /dev/console
#	    [ -f /var/run/wlan_g_stop.sh ] && sh /var/run/wlan_g_stop.sh 
#	fi
	echo Stop normal wireless ... > /dev/console
	[ -f /etc/templates/wlan.sh ] && sh /etc/templates/wlan.sh stop
	sleep 8	#wait for removing ath_pci module
	echo Download art module ... > /dev/console
	cd /tmp
	tftp -l $1 -g $3
	tftp -l $2 -g $3
	echo insmode  art module ... > /dev/console
	mknod /dev/dk0 c 63 0
	mknod /dev/caldata b 31 6
#	insmod /lib/modules/art.ko
	insmod $2
#	/lib/modules/mdk_client.out &
	chmod 555 $1
	./$1 &


