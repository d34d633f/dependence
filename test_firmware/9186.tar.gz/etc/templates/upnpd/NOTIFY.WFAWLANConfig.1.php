<? /* vi: set sw=4 ts=4: */
require("/etc/templates/upnpd/__NOTIFY.req.event.php");
?>
<e:propertyset xmlns:e="urn:schemas-upnp-org:event-1-0">
	<e:property>
		<APStatus>0</APStatus>
		<STAStatus>0</STAStatus>
		<WLANEvent></WLANEvent>
	</e:property>
</e:propertyset>
