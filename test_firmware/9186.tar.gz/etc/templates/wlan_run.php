#!/bin/sh
echo [$0] ... > /dev/console
<?
$WLAN = "/wlan/inf:1";
$wlan_ap_operate_mode = query($WLAN."/ap_mode");
require("/etc/templates/troot.php");
$wlanif = query("/runtime/layout/wlanif");
$wlanmac= query("/runtime/layout/wlanmac");
$countrycode= query("/runtime/nvram/countrycode");
$wlxmlpatch_pid = "/var/run/wlxmlpatch.pid";
$ap_igmp_pid = "/var/run/ap_igmp.pid";
if ($generate_start==1)
{
	echo "echo Start WLAN interface ".$wlanif." ... > /dev/console\n";

	if ($wlan_ap_operate_mode!=0 ) /* jack for fool proof*/
	{
		echo "echo not pure AP mode , so disable AP ARRAY ... > /dev/console\n";
	  	echo "rgdb -s /wlan/inf:1/aparray_enable 0  \n";	 
		echo "killall neapc > /dev/console\n";  		
		echo "rgdb -i -d /runtime/wlan/inf:1/ap_array_members/list \n";
		echo "rgdb -i -d /runtime/wlan/inf:1/slaver_record \n";
		echo "rgdb -i -d /runtime/wlan/inf:1/arrayslaver/list \n";
		echo "rgdb -i -d /runtime/wlan/inf:1/arraymaster/list \n";
		echo "rgdb -i -d /runtime/wlan/inf:1/scan_table \n";
	}      
	
	/* common cmd */
	$IWPRIV="iwpriv ".$wlanif;
	$IWCONF="iwconfig ".$wlanif;

	if (query($WLAN."/enable")!=1)
	{
		echo "echo WLAN is disabled ! > /dev/console\n";
		exit;
	}

        if ($countrycode!="")	{echo "iwpriv wifi0 setCountryID ".$countrycode."\n";}
        else			{echo "iwpriv wifi0 setCountryID 840\n";}

//---------------------apc mode start---------------------------	
	if ($wlan_ap_operate_mode==1)
	{
		$clonetype = query($WLAN."/macclone/type");
        	if ($clonetype==1)/*auto*/
		{
            		echo "brctl setcloneaddr br0 00:00:00:00:00:00\n";
			echo "brctl clonetype br0 1\n";
            		echo "brctl apc br0 1\n";
            		echo "cloned\n";
	        	exit;
	    	}
		else/*Disable and Manual*/
		{
			require($template_root."/__wlan_apcmode.php");
			exit;
		}
	}
//---------------------apc mode end----------------------------	
//---------------------apr mode start---------------------------	
/*	else if ($wlan_ap_operate_mode==2)
	{
		require($template_root."/__wlan_aprmode.php");
		exit;
	}*/
//---------------------apr mode end----------------------------	
//---------------------wds mode start---------------------------	
        if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
	{
		require($template_root."/__wlan_wdsmode.php");
		exit;
	}	
//---------------------wds mode end----------------------------	
	
//---------------------ap mode start---------------------------	
	// Disable IPv6 on wireless interface
	echo "echo \"1\" > /proc/sys/net/ipv6/conf/wifi0/disable_ipv6;\n";

	anchor("/wlan/inf:1");
	$channel = query("channel");         if (query("autochannel")==1) { $channel=0; }
	$bintval = query("beaconinterval");
	$cwmmode = query("cwmmode");
	$shortgi = query("shortgi");
	$g_mode = query("wlmode");
	$ssidhidden = query("ssidhidden");
	$dtim       = query("dtim");
	$wmmenable  = query("wmm/enable");
	$assoclimitenable   = query("assoc_limit/enable");
	$assoclimitnumber   = query("assoc_limit/number");
	$igmpsnoop = query("igmpsnoop");
	$wpartition = query("w_partition");
	$epartition = query("e_partition");
	$ethlink = query("ethlink");
	$fixedrate  = query("fixedrate");
	$mcastrate  = query("mcastrate_g");/*add for mcast rate by yuda*/
	$autochannel = query("autochannel");
	$ampdu		= query("ampdu");
	$ampduframe	= query("ampdusframes");
	$ampdulimit	= query("ampdulimit");
	$ampdmin	= query("ampdmin");		
	$aniena		= query("aniena");
	$acktimeout	= query("acktimeout_g");
	$txpower    = query("txpower");
	$multi_pri_state = query("multi/pri_by_ssid");
	$pri_bit = query("pri_bit");
	$zonedefence = query("zonedefence");

	//Create the instance	
	echo "ifconfig wifi0 hw ether ".$wlanmac."\n";
	echo "wlanconfig ".$wlanif." create wlandev wifi0 wlanmode ap\n";
//	echo "ifconfig ".$wlanif." hw ether ".$wlanmac."\n";

	// Disable IPv6 on wireless interface
	echo "echo \"1\" > /proc/sys/net/ipv6/conf/".$wlanif."/disable_ipv6;\n";

	//Disable Background Scan
	//echo $IWPRIV." bgscan 0\n";	/*not_yet*/
	//set debug mode output
	echo "iwpriv wifi0 HALDbg 0x0\n";
	echo "iwpriv wifi0 ATHDebug 0x0\n";
	echo $IWPRIV." dbgLVL 0x0\n";
	//common RF setting start
	echo "ifconfig ".$wlanif." txqueuelen 1000\n";
	echo "ifconfig wifi0 txqueuelen 1000\n";
	echo $IWPRIV." shortgi ".$shortgi." \n";

	if($autochannel==0)
	{
		if($channel>14)
		{
			$channel=6;
		}
	}

/*   erial mark start
	 $wepmode = query("/wlan/inf:1/wpa/wepmode");
    if ($wepmode==1 || $wepmode==2){
        if($g_mode == 2) {echo $IWPRIV." mode 11G\n";}
        else if($g_mode == 1) {echo $IWPRIV." mode 11G\n";}
        else if($g_mode == 3) {echo $IWPRIV." mode 11B\n";}
        else{
			if ($cwmmode == 0){
				echo $IWPRIV." mode 11NGHT20\n";
				echo $IWPRIV." htweptkip 0\n";
			}
			else{//cwmmode=1
				if($autochannel==1){
				echo $IWPRIV." mode 11NGHT40\n";
				echo $IWPRIV." htweptkip 0\n";
				}
				else{
					if($channel<5){//channel 1~4
						echo $IWPRIV." mode 11NGHT40PLUS\n";
						echo $IWPRIV." htweptkip 0\n";
					}
					else{//channel 5~11
						echo $IWPRIV." mode 11NGHT40MINUS\n";
						echo $IWPRIV." htweptkip 0\n";
					}
				}
			}
		}           
    }else{	erial mark end*/
        //(20) 1:11g only, 2.b/g mode 3:11b only, 4:only n  5:b/g/n mix, 6:g/n mix
	if ($cwmmode == 0)
	{
        	if($g_mode == 5)	{echo $IWPRIV." mode 11NGHT20\n";}
            	else if($g_mode == 6) 	{echo $IWPRIV." mode 11NGHT20\n";}
            	else if($g_mode == 4)	{echo $IWPRIV." mode 11NGHT20\n";}
            	else if($g_mode == 2)	{echo $IWPRIV." mode 11G\n";}
            	else if($g_mode == 1) 	{echo $IWPRIV." mode 11G\n";}
            	else if($g_mode == 3) 	{echo $IWPRIV." mode 11B\n";}
            	else			{echo $IWPRIV." mode 11NGHT20\n";}
        }
        //5--->11bgn 6-->11gn 4--->only n	
        else//cwmmode=1 HT20/40 mode
	{
        	if($autochannel==1)	{echo $IWPRIV." mode 11NGHT40\n";}//autochannel enable
            	else//autochannel disable
		{ 
                	if($channel<5)	{echo $IWPRIV." mode 11NGHT40PLUS\n";}//channel 1~4
                	else if($channel<=11){echo $IWPRIV." mode 11NGHT40MINUS\n";}//channel 5~11
			else		{echo $IWPRIV." mode 11NGHT20\n";}//channel 12,13 for JP
            	}
        }
/*}erial mark */
	//if in one of the 11NG bands that require ANI processing
	if($g_mode > 3)		{echo "iwpriv wifi0 ForBiasAuto 1\n";}
    	//Set Aggregation State
	if ($ampdu!="")		{echo "iwpriv wifi0 AMPDU ".$ampdu."\n";}
	else			{echo "iwpriv wifi0 AMPDU 1 \n";}
	//set number of sub-frames in an ampdu
	if ($ampduframe!="")	{echo "iwpriv wifi0 AMPDUFrames ".$ampduframe."\n";}	
	else			{echo "iwpriv wifi0 AMPDUFrames 32 \n";}
	//set ampdu limit
	if ($ampdulimit!="")	{echo "iwpriv wifi0 AMPDULim ".$ampdulimit."\n";}
	else			{echo "iwpriv wifi0 AMPDULim 50000 \n";}
	/*	
	if ($ampdumin!="")    {echo $IWPRIV." ampdumin ".$ampdumin."\n";    }
	else {echo $IWPRIV." ampdumin 32768 \n";}*/
	//1:11g only, 2.b/g mode 3:11b only, 4:only n  5:b/g/n mix, 6:g/n mix
	if($g_mode == 1)
	{
		echo "iwpriv ath0 puren 0\n";
		echo "iwpriv ath0 pureg 1\n";
	}
	else if($g_mode == 2)
	{
		echo "iwpriv ath0 puren 0\n";
		echo "iwpriv ath0 pureg 0\n";
	}		
	else if($g_mode == 4){
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 1\n";
		}
	else if($g_mode == 5)
	{
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 0\n";
	}
	else if($g_mode == 6)
	{
		echo "iwpriv ath0 pureg 1\n";
		echo "iwpriv ath0 puren 0\n";
	} 
	else
	{
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 0\n";
	}
	// set SSID and frequency
	//erial_acs_201009
	//echo $IWCONF." essid \"".get("s","/wlan/inf:1/ssid")."\" freq ".$channel."\n"; 
        if($channel == 0) 
	{
		echo $IWCONF." essid \"".get("s","/wlan/inf:1/ssid")."\" \n";
		echo "iwpriv ath0 acs 1\n";
	}
        else {echo $IWCONF." essid \"".get("s","/wlan/inf:1/ssid")."\" freq ".$channel."\n";}

	echo $IWCONF." mode master \n";
	//Set the chain masks
	echo "iwpriv wifi0 txchainmask 3\n";//2T
	echo "iwpriv wifi0 rxchainmask 3\n";//2R
	// common RF setting end

	if ($ssidhidden!="")		{echo $IWPRIV." hide_ssid ".$ssidhidden."\n";}
	if ($dtim!="")			{echo $IWPRIV." dtim_period ".$dtim."\n";}
	if ($wmmenable>0)		{echo $IWPRIV." wmm 1\n";}
	else		        	{echo $IWPRIV." wmm 0\n";}
	if($assoclimitenable==1)	{echo $IWPRIV." assocenable 1\n";}
	else				{echo $IWPRIV." assocenable 0\n";}
	if($assoclimitnumber!="")	{echo $IWPRIV." assocnumber ".$assoclimitnumber."\n";}
	if ($epartition!="")		{echo "brctl e_partition br0 ".$epartition."\n";}
	else  				{echo "brctl e_partition br0 0\n"; }
	if ($wpartition==2)  /* guest mode*/
	{ 
	    	echo $IWPRIV." w_partition 1 \n"; 	      
        	echo "brctl w_partition br0 ".$wlanif." 1 \n"; 
	}
	else if ($wpartition==1)  
	{ 
	    	echo $IWPRIV." w_partition 1 \n"; 	  
	    	echo "brctl w_partition br0 ".$wlanif." 0 \n";
	}
	else            
	{ 
	    	echo $IWPRIV." w_partition 0\n"; 
	    	echo "brctl w_partition br0 ".$wlanif." 0 \n";
	}
	/*erial mark
	if ($cwmmode == 1){
		if($autochannel==0){
			if($channel<5){
				echo "iwpriv ath0 extoffset 1\n";
			}
			else{
				echo "iwpriv ath0 extoffset -1\n";
			}
		}
	}erial mark*/
	//echo $IWPRIV." cwmmode ".$cwmmode."\n"; /*not support*/
	if ($aniena!="")	{echo "iwpriv wifi0 ANIEna ".$aniena."\n"; }
	else 			{echo "iwpriv wifi0 ANIEna 0 \n";}

	echo $IWPRIV." doth 1\n";//erial_acs_201009
	/*erial mark
	echo "iwpriv ath0 staextoffset 0\n";*/
	echo $IWPRIV." countryie 1\n";

	//echo "echo 1 > /proc/sys/dev/ath/htdupieenable\n";
	/*erial mark	
	echo "echo 2 > /proc/sys/dev/ath/hal/forceBias\n";*/
	if($bintval!="")	{echo $IWPRIV." bintval ".$bintval."\n";}
	else			{echo $IWPRIV." bintval 100\n";	}	
//2009_07_02 sandy++++	
	if($g_mode == 5 || $g_mode == 4)
	{
		  $fixedrate = 31;
		  set($WLAN."/fixedrate", $fixedrate);
	}
//2009_07_02 sandy----	
	/*0==1M;1==2M;2==5.5M;3==11M;4==6M;5==9M;6==12M;7==18M;8==24M;9==36M;10==48M;11==54M*/ 
	if  ($fixedrate<0)           {echo "iwpriv wifi0 fixedrate 0\n";}
	else if  ($fixedrate<12)     {echo "iwpriv wifi0 fixedrate ".$fixedrate."\n";}
	else                         {echo "iwpriv wifi0 fixedrate 31\n";}
	echo "iwpriv wifi0 acktimeout ".$acktimeout."\n";
	echo "brctl apc br0 0"."\n";
	echo $IWPRIV." apband 0\n"; //show ap band in wireless driver
	echo "sleep 1\n";
	require($template_root."/__wlan_acl.php");
        if ($multi_pri_state == 1) 
	{ 
        	echo $IWPRIV." pristate 1\n";
        	echo $IWPRIV." pribit ".$pri_bit."\n"; 
        }
	else
	{
		echo $IWPRIV." pristate 0\n";
	}		
/*add for mcast rate by yuda start*/
	if($mcastrate!=0){
    	if($mcastrate==1){
    		echo $IWPRIV." mcast_rate 1000\n";
    	}
    	else if($mcastrate==2){
    		echo $IWPRIV." mcast_rate 2000\n";
    	}
    	else if($mcastrate==3){
    		echo $IWPRIV." mcast_rate 5500\n";
    	}
    	else if($mcastrate==4){
    		echo $IWPRIV." mcast_rate 11000\n";
    	}
    	else if($mcastrate==5){
    		echo $IWPRIV." mcast_rate 6000\n";
    	}
    	else if($mcastrate==6){
    		echo $IWPRIV." mcast_rate 9000\n";
    	}
    	else if($mcastrate==7){
    		echo $IWPRIV." mcast_rate 12000\n";
    	}
    	else if($mcastrate==8){
    		echo $IWPRIV." mcast_rate 18000\n";
    	}
    	else if($mcastrate==9){
    		echo $IWPRIV." mcast_rate 24000\n";
    	}
    	else if($mcastrate==10){
    		echo $IWPRIV." mcast_rate 36000\n";
    	}
    	else if($mcastrate==11){
    		echo $IWPRIV." mcast_rate 48000\n";
    	}
    	else if($mcastrate==12){
    		echo $IWPRIV." mcast_rate 54000\n";
    	}
    	else if($mcastrate==13){
    		echo $IWPRIV." mcast_rate 6500\n";
    	}
    	else if($mcastrate==14){
    		echo $IWPRIV." mcast_rate 13000\n";
    	}
    	else if($mcastrate==15){
    		echo $IWPRIV." mcast_rate 19500\n";
    	}
    	else if($mcastrate==16){
    		echo $IWPRIV." mcast_rate 26000\n";
    	}
    	else if($mcastrate==17){
    		echo $IWPRIV." mcast_rate 39000\n";
    	}
    	else if($mcastrate==18){
    		echo $IWPRIV." mcast_rate 52000\n";
    	}
    	else if($mcastrate==19){
    		echo $IWPRIV." mcast_rate 58500\n";
    	}
    	else if($mcastrate==20){
    		echo $IWPRIV." mcast_rate 65000\n";
    	}
    	else if($mcastrate==21){
    		echo $IWPRIV." mcast_rate 78000\n";
    	}
    	else if($mcastrate==22){
    		echo $IWPRIV." mcast_rate 104000\n";
    	}
    	else if($mcastrate==23){
    		echo $IWPRIV." mcast_rate 117000\n";
    	}
    	else if($mcastrate==24){
    		echo $IWPRIV." mcast_rate 130000\n";
    	}
     	else {
    		echo $IWPRIV." mcast_rate 11000\n";
    	}   	
    	}        
    	/*add for mcast rate by yuda end*/
         $auth_mode = query($WLAN."/authentication");
	if ($auth_mode>1){  
		/*remove device up */
	}
	else {
	    require($template_root."/__auth_openshared.php"); 	
	}
    	if ($zonedefence==1){
		echo $IWPRIV." zonedefence 1\n";
		require($template_root."/zonedefence.php");
	}    
	else{
		echo $IWPRIV." zonedefence 0\n";
	}
	/* erial mark
	$DFStestmode = query("/wlan/inf:1/dfstest");
	if ($DFStestmode==1)
	{  
	    echo "radartool usenol 0\n"; 
	}
        */
    	require($template_root."/multi_ssid_run.php");  /* Jack add 13/11/08 init_MSSID_before_WDS multi-ssid should be init before WDS_VAP */
        
        echo "rgdb -i -s /runtime/stats/wireless/led11g 1\n";
}//if ($generate_start==1) end
else
{
	echo "echo Stop WLAN interface ... > /dev/console\n";
	
	// multi-ssid must be normal AP mode. /* Jack add multi_ssid 31/03/07 */
	$multi_total_state = query($WLAN."/multi/state");
	$igmpsnoop = query($WLAN."/igmpsnoop");
	if ($multi_total_state == 1)
	{
		if ($wlan_ap_operate_mode!=0 && $wlan_ap_operate_mode!=3 && $wlan_ap_operate_mode!=4) /*    WDS_OVER_MULTI_SSID*/
		{
			echo "echo multi-ssid must be normal AP mode! > /dev/console\n";
			set($WLAN."/ap_mode", 0);
		}
	}
	if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
	{
		require($template_root."/__wlan_wdsmode.php");
		exit;
	}
	if (query($WLAN."/enable")!=1)
	{
		echo "echo WLAN is disabled ! > /dev/console\n";
		exit;
	}
	
	echo "if [ -f ".$wlxmlpatch_pid." ]; then\n";
	echo "kill \`cat ".$wlxmlpatch_pid."\` > /dev/null 2>&1\n";
	echo "rm -f ".$wlxmlpatch_pid."\n";
	echo "fi\n\n";
	if ($wlan_ap_operate_mode==2){		echo "killall wlxmlpatch\n";	}
	/* IGMP Snooping dennis 2008-01-29 start */
	if ($igmpsnoop == 1){
		echo "echo disable > /proc/net/br_igmp_ap_br0\n";
		echo "echo unsetwl ath0 > /proc/net/br_igmp_ap_br0\n";
		echo "brctl igmp_snooping br0 0\n";
		echo "if [ -f ".$ap_igmp_pid." ]; then\n";
		echo "kill \`cat ".$ap_igmp_pid."\` > /dev/null 2>&1\n";
		echo "rm -f ".$ap_igmp_pid."\n";
		echo "fi\n\n";
	}
	/* IGMP Snooping dennis 2008-01-29 end */

	/* Stop hostapd */
	$HAPD_conf	= "/var/run/hostapd.".$wlanif."conf";
	echo "rm -f ".$HAPD_conf."\n";
//	echo "brctl e_partition br0 0\n";
	/* Stop wpa_supplicant */
	$wpa_supplicant_conf 	= "/var/run/wpa_supplicant.".$wlanif.".conf";
	echo "rm -f ".$wpa_supplicant_conf."\n";

	echo "brctl apc br0 0"."\n";
	echo "ifconfig ".$wlanif." down\n";
	echo "sleep 2\n";
	echo "brctl delif br0 ".$wlanif."\n";
	echo "sleep 1\n";
	echo "iwconfig ath0 key off"."\n"; // must add key off
	echo "VAPLIST=`iwconfig | grep ath | cut -b 1-5`\n";
	echo "for i in $VAPLIST\n";
	echo "do\n";
	echo "echo killing $i\n";
	echo "wlanconfig $i destroy\n";
	echo "done\n";
	//echo "wlanconfig ".$wlanif." destroy\n";
	if ($wlan_ap_operate_mode==2){	echo "wlanconfig ath1 destroy\n"; }
	echo "rmmod ath_pktlog\n";
	echo "sleep 2\n";
	echo "rmmod umac\n";
	echo "sleep 2\n";
	echo "rmmod ath_dev\n";
	echo "rmmod ath_rate_atheros\n";
	echo "rmmod ath_hal\n";
	echo "rmmod asf\n";
	echo "rmmod adf\n";
	/*
	jacky the gpio control is for dap2553 not for dap2360
	echo "gpioc -o 20 \n";
	echo "gpioc -c 20 \n";
	echo "gpioc -d 20 \n";
	*/
	echo "rgdb -i -s /runtime/stats/wireless/led11g 0\n";
	

}
?>
