<?

$head_bsc = "Basic Settings";

$title_bsc_wlan ="Wireless Settings";
$bsc_wlan_msg ="Allow you to change the wireless settings to fit an existing wireless network or".
 " to customize your wireless network.";
$bsc_wireless_band ="Wireless Band";
if($TITLE=="DAP-1353" || $TITLE=="DAP-2360")
{
	$bsc_wireless_band_msg ="Operating frequency band. Choose 2.4GHz for visibility to legacy devices".
	" and for longer range.";
}
else
{
$bsc_wireless_band_msg ="Operating frequency band. Choose 2.4GHz for visibility to legacy devices".
" and for longer range. Choose 5GHz for least interference; interference can hurt performance. This ".
"AP will operate one band at a time.";
}
$bsc_application="Application";
$bsc_application_msg="This option allows the user to choose for indoor or outdoor mode at the 5G Band.";
$bsc_mode = "Mode";
if($TITLE=="DAP-1353")
{
$bsc_mode_msg = "Select a function mode to configure your wireless network. Function modes include".
" Access Point, WDS (Wireless Distribution System) with AP, WDS,  Wireless Client and AP Repeater. Function modes are designed to support various wireless".
" network topology and applications.";
}
else
{
$bsc_mode_msg = "Select a function mode to configure your wireless network. Function modes include"." Access Point, WDS (Wireless Distribution System) with AP, WDS,  Wireless Client. Function modes are designed to support various wireless"." network topology and applications.";
}
$bsc_network_name = "Network Name (SSID)";
$bsc_network_name_msg = "Also known as the Service Set Identifier, this is the name designated for".
" a specific wireless local area network (WLAN). The factory default setting is \"dlink\". The SSID ".
"can be easily changed to connect to an existing wireless network or to establish a new wireless network.";
$bsc_ssid_visibility = "SSID Visibility";
$bsc_ssid_visibility_msg = "Indicate whether or not the SSID of your wireless network will be broadcasted. ".
"The default value of SSID Visibility is set to \"Enable,\" which allow wireless clients to detect the wireless ".
"network. By changing this setting to \"Disable,\" wireless clients can no longer detect the wireless network and can".
" only connect if they have the correct SSID entered.";
$bsc_auto_channel="Auto Channel Selection";
$bsc_auto_channel_msg="If you check Auto Channel Scan, everytime when AP is booting up, the AP will automatically find the best channel".
" to use. This is enabled by default.";
$bsc_channel="Channel";
$bsc_channel_msg ="Indicate the channel setting for the ".query("/sys/hostname").". By default, the AP is set to Auto".
" Channel Scan. The Channel can be changed to fit the channel setting for an existing wireless".
" network or to customize the wireless network.";
$bsc_channel_width="Channel Width";
if($TITLE == "DAP-1353" || $TITLE == "DAP-2360")
{
$bsc_channel_width_msg="Allows selection of the channel width you would like to operate in.20 MHz and Auto 20/40MHz allow both 802.11n ".
"and non-802.11n wireless devices on your network when the wireless mode is Mixed 802.11 b/g/n in 2.4G.802.11n ".
"wireless devices are allowed to transmit data using 40 MHz when the channel width is Auto 20/40 MHz";
}
else
{
$bsc_channel_width_msg="Allows selection of the channel width you would like to operate in.20 MHz and Auto 20/40MHz allow both 802.11n ".
"and non-802.11n wireless devices on your network when the wireless mode is Mixed 802.11 b/g/n in 2.4G and Mixed 802.11 a/n in 5G.802.11n ".
"wireless devices are allowed to transmit data using 40 MHz when the channel width is Auto 20/40 MHz";
}
$bsc_authentication="Authentication";
$bsc_authentication_msg="For added security on a wireless network, data encryption can be enabled. ".
"There are several available Authentications type can be selected. The default value for".
" Authentication is set to \"Open System\".";
$bsc_open_sys="Open System";
$bsc_open_sys_msg="For Open System authentication, only the wireless clients with the same WEP key ".
"will be able to communicate on the wireless network. The Access Point will remain visible to all ".
"devices on the network.";
$bsc_shared_key="Shared Key";
$bsc_shared_key_msg="For Shared Key authentication, the Access Point cannot be seen on the wireless ".
"network except to the wireless clients that share the same WEP key.";
$bsc_personal_type="WPA-Personal/WPA2-Personal/WPA-Auto-Personal";
$bsc_personal_type_msg="Wi-Fi Protected Access authorizes and authenticates users onto the wireless ".
"network. It uses TKIP encryption to protect the network through the use of a pre-shared key. WPA and".
" WPA2 uses different algorithm. WPA-Auto allows both WPA and WPA2. ";
$bsc_periodrical_change_key="Periodical change key";
$bsc_periodrical_change_key_msg="The ".query("/sys/hostname")." supports periodical change key. Periodical change key can ".
"generate WPA random key which start at time of activated from. Administrator can use email to get current key and Periodical change key information.";
$bsc_enterprise_type="WPA-Enterprise/ WPA2-Enterprise/ WPA-Auto-Enterprise";
$bsc_enterprise_type_msg="Wi-Fi Protected Access authorizes and authenticates users onto the wireless network. ".
"WPA uses stronger security than WEP and is based on a key that changes automatically at a regular interval.".
" It requires a RADIUS server in the network. WPA and WPA2 uses different algorithm. WPA-Auto allows both WPA and WPA2.";
$bsc_8021x_type="802.1x";
$bsc_8021x_type_msg="If you use 802.1x you do not need to supply a WEP key. This is an access control system ".
"used for Ethernet and wireless networks and a key is generated automatically from a server or switch. In ".
"order to use 802.1x you must have the system running on implementing PAE. After applying the settings and ".
"restarting the Access Point, you must choose to use a radius server or a local server or switch for ".
"Authentication. Use the Encryption menu to select where authentication information comes from and what size key to use.";
$bsc_network_access="Network Access Protection";
$bsc_network_access_msg="Network Access Protection (NAP) is a feature of Windows Server 2008. NAP ".
"controls access to network resources based on a client computer's identity and compliance with corporate governance policy.".
" NAP allows network administrators to define granular levels of network access based on who a client is, the groups to which ".
"the client belongs, and the degree to which that client is compliant with corporate governance policy. If a client is not".
" compliant, NAP provides a mechanism to automatically bring the client back into compliance and then dynamically increase its level of network access.";
$bsc_mac_clone = "MAC Clone";
$bsc_mac_clone_msg = "Assign a mac address to the AP which is set to APC mode, for the communication with another AP as a network card. You can entry any address or choose an address in the scan list if select \"manually\". \"Auto\" means to assign the first mac address in that AP detected.";

$title_bsc_lan = "LAN Settings";
$title_bsc_lan_msg = "Also referred as private settings, LAN settings allow you to configure ".
"the LAN interface of the ".query("/sys/hostname").". The LAN IP address is private to your internal network and ".
"is not visible to Internet. The default IP address is 192.168.0.50 with a subnet mask of 255.255.255.0.";
$bsc_get_ip_from = "Get IP From";
$bsc_get_ip_from_msg = "The factory default setting is \"Static IP (Manual)\" which allows the IP address ".
"of the ".query("/sys/hostname")." to be manually configured in accordance to the applied local area network. Enable \"Dynamic".
" IP (DHCP)\" to allow the DHCP host to automatically assign the Access Point an IP address that conforms to the applied local area network.";
$bsc_ip_address = "IP Address";
$bsc_ip_address_msg = "The default IP address is 192.168.0.50. It can be modified to conform to an existing local ".
"area network. Please note that the IP address of each device in the wireless local area network must be within the".
" same IP address range and subnet mask. Take the default ".query("/sys/hostname")."'s IP address as an example, each station ".
"associated with the AP must be configured with a unique IP address falling in the range of 192.168.0.*. \"*\" ranges".
" from 1 to 254 but is 50 in this case.";
$bsc_submask = "Subnet Mask";
$bsc_submask_msg = "A mask used to determine what subnet an IP address belongs to. The default subnet setting is 255.255.255.0.";
$bsc_gateway = "Default Gateway";
$bsc_gateway_msg = "Specify the gateway IP address of the local network.";


$head_adv ="Advanced Settings";

$title_adv_per = "Performance";
$title_adv_per_msg = "You can customize the network radio to fit your needs by tuning radio parameters in".
" the performance section. Performance functions are designed for advanced users who are familiar with 802.11".
" wireless networks and radio configuration.";
$adv_wireless = "Wireless";
$adv_wireless_msg ="This option allows the user to enable or disable the wireless function.";
$adv_wireless_mode ="Wireless Mode";
if($TITLE=="DAP-1353" || $TITLE=="DAP-2360")
{
	$adv_wireless_mode_msg ="This function allows you to select different combination of clients".
	" that can be supported.Please note that when backwards compatibility is enabled for legacy ".
	"(802.11g/b) clients, degradation of 802.11n wireless performance is expected.";
}
else
{
$adv_wireless_mode_msg ="This function allows you to select different combination of clients".
" that can be supported.Please note that when backwards compatibility is enabled for legacy ".
"(802.11a/g/b) clients, degradation of 802.11n wireless performance is expected.";
}

$adv_date_rate="Data Rate";
$adv_date_rate_msg="Indicates the base transfer rate of wireless adapters on the wireless local area network (WLAN). The ".
"access point will adjust the base transfer rate depending on the base rate of the connected device. If there are obstacles".
" or interference, the AP will step down the data rate.";
$adv_beacon = "Beacon Interval (25-500)";
$adv_beacon_msg = "Beacons are packets sent by an access point to synchronize a wireless network. Setting a higher beacon".
" interval can help to save the power of a wireless client while setting a lower one can help a wireless client connect ".
"to an access point faster. A setting of 100 milliseconds is recommended for most users.";
$adv_dtim="DTIM Interval (1-15)";
$adv_dtim_msg="DTIM Interval specifies the number of AP beacons between each Delivery Traffic Indication Message ".
"(DTIM). It informs associated stations of the next window for listening to broadcast and multicast messages. You".
" can specify a DTIM value range from 1 to 15. The AP will send the next DTIM with the specified DTIM value to stations".
" if there is any buffered broadcast or multicast message. Stations hear the beacons and get ready to receive the broadcast ".
"or multicast messages. The default value for DTIM interval is 1.";
$adv_transmit_power="Transmit Power";
$adv_transmit_power_msg="This setting determines the power level of the wireless transmission. Transmitting power can be ".
"adjusted to eliminate overlapping of wireless area coverage between two access points where interference is a major concern.".
" The options are 100% (default), 50% (-3dB), 25% (-6dB), or 12.5% (-9dB). For example, if wireless coverage is intended for".
" half of the area, then select \"50%\" as the option.";
$adv_wmm="WMM (Wi-Fi Multimedia)";
$adv_wmm_msg="The Wi-Fi Multimedia feature improves the user experience for audio, video and voice applications over a ".
"Wi-Fi network. WMM is based on a subset of the IEEE 802.11e WLAN QoS standard. Enabling this feature improves the user".
" experience for audio and video applications over a Wi-Fi.";
$adv_ack_timeout="Ack TimeOut";
if(query("/runtime/web/display/ack_timeout_range")=="0")
{
	if($TITLE=="DAP-1353" || $TITLE=="DAP-2360")
	{
		$adv_ack_timeout_msg="You can specify an Ack Timeout value range from 48~200 in 2.4GHz to effectively".
	" optimize the throughput over long distance links. The unit is in microseconds (&micro;s). The default value is set to 25&micro;s in 2.4GHz.";
	}
	else
	{
	$adv_ack_timeout_msg="You can specify an Ack Timeout value range from 48~200 in 2.4GHz and 25~200 in 5GHz to effectively".
" optimize the throughput over long distance links. The unit is in microseconds (&micro;s). The default value is set to 25&micro;s in 2.4GHz and 48&micro;s in 5GHz.";
}
	
}
else
{
	if($TITLE=="DAP-1353" || $TITLE=="DAP-2360")
	{
		$adv_ack_timeout_msg="You can specify an Ack Timeout value range from 64~200 in 2.4GHz to effectively".
	" optimize the throughput over long distance links. The unit is in microseconds (&micro;s). The default value is set to 64&micro;s in 2.4GHz.";
	}
else
{
	$adv_ack_timeout_msg="You can specify an Ack Timeout value range from 64~200 in 2.4GHz and 50~200 in 5GHz to effectively".
	" optimize the throughput over long distance links. The unit is in microseconds (&micro;s). The default value is set to 64&micro;s in 2.4GHz and 50&micro;s in 5GHz.";
}

}

$adv_short_gi="Short GI";
$adv_short_gi_msg="Using a short (400ns) guard interval can increase throughput. However, it can also increase error rates in some installations due".
" to increased sensitivity to radio-frequency reflections. Select the option that works best for your installation.";
$adv_igmp="IGMP Snooping";
$adv_igmp_msg="Internet Group Management Protocol (IGMP) snooping allows the AP to recognize IGMP queries and reports sent between routers and an ".
"IGMP host (wireless STA). When IGMP snooping is enabled, the AP will forward multicast packets to IGMP host based on IGMP messages passing through the AP.";
$adv_link_integrality="Link Integrality";
$adv_link_integrality_msg="If the Ethernet connection between the LAN and the AP is disconnected, the \"Link Integrity\" option ".
"when enabled will cause the wireless client to automatically disassociate from the AP.";
$adv_connection_limit="Connection Limit";
if(query("/runtime/web/display/utilization") !="0")
{
	$utilization_string="or the network utilization of this AP exceeds the percentage that you specify,";
}
else
{
	$utilization_string=" ";
}
$adv_connection_limit_msg="Connection limit is an option for load balancing. It allows you to share the wireless network traffic".
" and client using multiple ".query("/sys/hostname")."s. If this function is enabled, when the number of users exceeds the \"user limit\",".
"".$utilization_string."  the AP will not allow clients to associate with this AP.";
$adv_user_limit ="User Limit (0-64)";
$adv_user_limit_msg ="Set the maximum amount of users allowed per access point. \"20\" is recommended for the typical user.";
$adv_network_utilization="Network Utilization";
$adv_network_utilization_msg="Set the maximum utilization of this access point for service. The ".query("/sys/hostname")." will not let any new ".
"client associate with the AP if the utilization exceeds the value the user specified. \"100%\" is recommended.";
$adv_mcast_rate="Multicast rate";
if($TITLE=="DAP-1353" || $TITLE=="DAP-2360")
{
$adv_mcast_rate_msg="Multicast rate can adjust multicast's packet data rate. Multicast rate supports AP mode, Multi-SSID and WDS with AP mode.";
}
else
{
$adv_mcast_rate_msg="Multicast rate can adjust multicast's packet data rate. Multicast rate supports".
" AP mode (2.4Ghz and 5Ghz), Multi-SSID and WDS with AP mode.";
}

$title_adv_mssid="Multi-SSID";
/*$title_adv_mssid_msg="Multiple SSIDs are only supported in AP mode. One primary SSID and at most seven guest SSIDs ".
"can be configured to allow virtual segregation stations which share the same channel.";*/
if(query("/runtime/web/display/mssid_index4")==1)
{
	$title_adv_mssid_msg="One primary SSID and at most three guest SSIDs ".
	"can be configured to allow virtual segregation stations which share the same channel.";
}
else
{
$title_adv_mssid_msg="One primary SSID and at most seven guest SSIDs ".
"can be configured to allow virtual segregation stations which share the same channel.";
}
$adv_mssid_msg1="Furthermore, you can enable the VLAN State to allow the ".query("/sys/hostname")." to work with VLAN-supported switches or other devices.";
//$adv_mssid_msg2="When the Primary SSID is set to Open System without encryption, the Guest SSIDs can only be set to no encryption, WEP, WPA-Personal or WPA2-Personal.";
//$adv_mssid_msg3="When the Primary SSID's security is set to Open or Shared System WEP key, the Guest SSIDs can be set to use no encryption, use three other WEP keys, WPA-Personal, or WPA2-Personal.";
//$adv_mssid_msg4="When the Primary SSID's security is set to WPA-Personal, WPA2-Personal, or WPA-Auto-Personal, slot 2 and slot 3 are used. The Guest SSIDs can be set to use no encryption, WEP, or WPA-Personal.";
//$adv_mssid_msg5="When the Primary SSID's security is set to WPA-Enterprise, WPA2-Enterprise, or WPA-Auto-Enterprise, the Guest SSIDs can be set to use any security.";

$title_adv_vlan="VLAN";
$title_adv_vlan_msg="The ".query("/sys/hostname")." supports VLANs. VLANs can be created with a Name and VID. Mgmt (TCP stack), LAN, Primary / Multiple SSID and WDS Connection can be assigned to".
" VLAN as they are physical ports. Any packet that enters the ".query("/sys/hostname")." without a VLAN tag will have a VLAN tag inserted with a PVID.";

$title_adv_intrusion="Intrusion";
$title_adv_intrusion_msg="The ".query("/sys/hostname")." allows users to set up wireless intrusion protection.";

$title_adv_scheduling="Schedule";
$title_adv_scheduling_msg="".query("/sys/hostname")."'s radio can be scheduled by week or by individual days.";

$title_adv_qos="QoS";
$title_adv_qos_msg="QoS stands for Quality of Service for Wireless Intelligent Stream Handling, a technology developed to enhance the experience of using a wireless network by".
" prioritizing the traffic of different applications.";
$adv_enable_qoS="QoS(Quality of Service)";
$adv_enable_qoS_msg="Enable this option if you want to allow QoS to prioritize your traffic.";
$adv_enable_qoS_msg1="Priority Classifiers";
$adv_http="HTTP";
$adv_http_msg="Allows the access point to recognize HTTP transfers for many common audio and video streams and prioritize them above other traffic. Such".
" streams are frequently used by digital media players.";
$adv_automatic="Automatic";
$adv_automatic_msg="When enabled, this option causes the access point to automatically attempt to prioritize traffic streams that".
" it doesn't otherwise recognize, based on the behavior that the streams exhibit. This acts to de-prioritize streams that exhibit ".
"bulk transfer characteristics, such as file transfers, while leaving interactive traffic, such as gaming or VoIP, running at a normal priority.";
$adv_qos_rule="Add Qos Rules";
$adv_qos_rule_msg="A QoS Rule identifies a specific message flow and assigns a priority to that flow. For most applications, the priority classifiers ".
"ensure the right priorities and specific QoS Rules are not required.";
$adv_qos_rule_msg1="QoS supports overlaps between rules. If more than one rule matches a specific message flow, the rule with the highest priority will be used.";
$adv_name="Name";
$adv_name_msg="Create a name for the rule that is meaningful to you.";
$adv_priority="Priority";
$adv_priority_msg="The priority of the message flow is entered here. Four priorities are defined:";
$adv_priority_msg1="* BK: Background (least urgent).";
$adv_priority_msg2="* BE: Best Effort.";
$adv_priority_msg3="* VI: Video.";
$adv_priority_msg4="* VO: Voice (most urgent).";
$adv_protocol="Protocol";
$adv_protocol_msg="The protocol used by the messages.";
$adv_host_1_ip="Host 1 IP Range";
$adv_host_1_ip_msg="The rule applies to a flow of messages for which one computer's IP address ".
"falls within the range set here.";
$adv_host_1_port="Host 1 Port Range";
$adv_host_1_port_msg="The rule applies to a flow of messages for which host 1's port number is within the range set here.";
$adv_host_2_ip="Host 2 IP Range";
$adv_host_2_ip_msg="The rule applies to a flow of messages for which the other computer's IP address falls within the range set here.";   
$adv_host_2_port="Host 2 Port Range";
$adv_host_2_port_msg="The rule applies to a flow of messages for which host 2's port number is within the range set here.";
   
$title_adv_url="Web Redirection";
$title_adv_url_msg="";
$adv_enable_url="Enable Web Redirection";
$adv_enable_url_msg="This check box allows the user to enable the Web Redirection function.";
$adv_url_username="User Name";  
$adv_url_username_msg="Enter a user name to authenticate user access to the Web Redirection.";  
$adv_url_password="Password";
$adv_url_password_msg="Enter a password to authenticate user access to the Web Redirection.";
$adv_url_status="Status";
$adv_url_status_msg="Use the drop-down menu to toggle between enabling and disabling the Web Redirection.";
$adv_url_account_list="Web Redirection Account List";
$adv_url_account_list_msg="After enabling Status, enter a User Name and a Password in the Add Web Redirection Account section,".
" and then click the Save button. The newly-created Web Redirection will appear in this Web Redirection Account List.".
" Use the radio buttons to enable or disable the Web Redirection account, or click the icon in the delete column to remove the Web Redirection account.";
   
$title_adv_arp_spoofing="ARP Spoofing Prevention";
$title_adv_arp_spoofing_msg="The ARP Spoofing Prevention feature allows users to add IP/MAC address mapping to prevent arp spoofing attack.";
$adv_arp_spoofing="ARP Spoofing Prevention";
$adv_arp_spoofing_msg="This check box allows you to enable the arp spoofing prevention function.";
$adv_gateway_ip="Gateway IP Address";
$adv_gateway_ip_msg="Enter a gateway IP address.";
$adv_gateway_mac="Gateway MAC Address";
$adv_gateway_mac_msg="Enter a gateway MAC address."; 

$title_adv_ap_array="AP Array";
$title_adv_ap_array_msg="An AP array is a set of devices on a network that are organized into a single group to increase ease of management.";
$adv_enable_array="Enable AP Array"; 
$adv_enable_array_msg="This check box allows the user to enable the AP array function. The three modes that are available are Master, ".
"Backup Master, and Slave. APs in the same array will use the same configuration. The configuration will sync the Master AP to the ".
"Slave AP and the Backup Master AP when a Slave AP and a Backup Master AP join the AP array.";
$adv_ap_array_name="AP Array Name";
$adv_ap_array_name_msg="Enter a user-selected name for the AP array you have created.";
$adv_ap_array_pwd="AP Array Password";
$adv_ap_array_pwd_msg="Enter a user-selected password that will be used to access the AP array you have created.";
$adv_scan_ap_array_list="Scan AP Array List";
$adv_scan_ap_array_list_msg="Click this button to initiate a scan of all the available APs currently on the network.";
$adv_ap_array_list="AP Array List";
$adv_ap_array_list_msg="This table displays the current AP array status for the following parameters: Array Name,".
" Master IP, MAC, Master, Backup Master, Slave, and Total.";
$adv_current_array_members="Current Members";
$adv_current_array_members_msg="This table displays all the current array members. The ".query("/sys/hostname")." AP array".
" feature supports up to eight AP array members.";
$adv_syn_parameters="Synchronized Parameters";
$adv_syn_parameters_msg="Choose Synchronized Parameters of  AP Array . Click \"Clear all \"  button to clear all Synchronized Parameters .";

$title_adv_int_radius_server="Internal RADIUS Server";
$title_adv_int_radius_server_msg="The ".query("/sys/hostname")." has a built-in RADIUS server.";
$adv_user_name="User Name";
$adv_user_name_msg="Enter a user name to authenticate user access to the internal RADIUS server.";
$adv_pwd="Password"; 
$adv_pwd_msg="Enter a password to authenticate user access to the internal RADIUS server.";
$adv_status="Status";
$adv_status_msg="Use the drop-down menu to toggle between enabling and disabling the internal RADIUS server.";
$adv_radius_account_list="RADIUS Account List";
$adv_radius_account_list_msg="After enabling Status, enter a User Name and a Password in the ".
"Add RADIUS Account section, and then click the Save button. The newly-created internal RADIUS ".
"will appear in this RADIUS Account List. Use the radio buttons to enable or disable the ".
"RADIUS account, or click the icon in the delete column to remove the RADIUS account.";    

$head_dhcp="DHCP Server";
$head_dhcp_msg="DHCP (Dynamic Host Control Protocol) Server assigns IP addresses to stations requesting IP addresses while logging in ".
"to the wireless network. Stations must be configured as a DHCP client in order to obtain IP addresses automatically. The default value for DHCP Server control is \"disabled\".";

$title_dhcp_dynamic_pool="Dynamic Pool Settings";
$title_dhcp_dynamic_pool_msg="The DHCP address pool defines the range of the IP address that can be assigned to stations in the network.".
" A Dynamic Pool allows wireless stations to receive an available IP with lease time control.";
$dhcp_server_control="DHCP Server Control";
$dhcp_server_control_msg="The default setting for DHCP Server is disable.";
$dhcp_ip_assigned="IP Assigned From";
$dhcp_ip_assigned_msg="User can specify the beginning of the pool of IP addresses available to wireless stations.";
$dhcp_range_of_pool="The Range of Pool (1-254)";
$dhcp_range_of_pool_msg="Users can specify the range of IP addresses that are available. IP addresses are increments of the IP address specified in the \"IP Assigned From\" field.";
$dhcp_submask="Subnet Mask";
$dhcp_submask_msg="Define the subnet mask of the IP address specified in the \"IP Assigned From\" field.";
$dhcp_gateway="Gateway";
$dhcp_gateway_msg="Specify the Gateway IP address for the wireless network.";
$dhcp_wins="WINS";
$dhcp_wins_msg="Specify the WINS IP address for the wireless network.";
$dhcp_dns="DNS";
$dhcp_dns_msg="Specify the DNS IP address for the wireless network.";
$dhcp_domain="Domain Name";
$dhcp_domain_msg="Specify the Domain Name for the wireless network.";
$dhcp_lease_time="Lease Time";
$dhcp_lease_time_msg="Users can define stations associating durations by specifying IP address lease time.";

$title_dhcp_static_pool="Static Pool Settings";
$title_dhcp_static_pool_msg="The DHCP address pool defines the range of IP addresses that can be assigned to".
" stations on the network. A Static Pool allows wireless stations to receive an available IP without time control.";
$host_name="Host Name";
$host_name_msg="Create a name for the rule that is meaningful to you.";
$dhcp_assigned_ip="Assigned IP";
$dhcp_assigned_ip_msg="Specify the IP address to be assigned for a station with a MAC address specified in \"Assigned MAC Address\" field.";
$dhcp_assigned_mac="Assigned MAC Address";
$dhcp_assigned_mac_msg="Specify the MAC address of the station requesting association.";

$title_dhcp_current_ip="Current IP Mapping";
$title_dhcp_current_ip_msg="A listing includes MAC addresses, IP addresses, and lease times of wireless stations ".
"associated with the ".query("/sys/hostname")." by a DHCP Server using Dynamic Pools or Static Pools.";


$head_filters="Filters";
$head_filters_msg="The filter function includes MAC address filtering and a wireless LAN partition. MAC address filtering blocks ".
"or accepts association by identifying specified MAC addresses. Wireless LAN partition can accept or reject access from wireless or wired networks.";

$title_filters_wireless_access="Wireless Access Settings";
$filters_wireless_band="Wireless Band";
if($TITLE=="DAP-1353" || $TITLE=="DAP-2360")
{
	$filters_wireless_band_msg="Operating frequency band. Choose 2.4 GHz for visibility to legacy devices and for longer ranges. ".
	"This part will follow the basic wireless setting.";
}
else
{
$filters_wireless_band_msg="Operating frequency band. Choose 2.4 GHz for visibility to legacy devices and for longer ranges. Choose 5 GHz for the".
" least interference.This part will follow the basic wireless setting.";
}
$filters_acl_list="Access Control List";
$filters_acl_list_msg= "Can be configured to deny or only allow wireless stations association by filtering MAC addresses. By selecting \"Accept\"".
",can only be associated with MAC addresses listed in the Authorization table. By selecting \"Reject\",will only disassociate with MAC addresses listed.";
$filters_acl_mac = "MAC Address";
$filters_acl_mac_msg = "Enter a MAC address.";
$filters_acl_client_information="Current Client Information";
$filters_acl_client_information_msg="Displays the associated clients SSID, MAC, band, authentication method and signal strength for the ".query("/sys/hostname")." network.";
$filters_acl_upload_download="Wireless MAC ACL File Upload and Download";
$filters_acl_upload_download_msg="Browse to the ACL file from the local drive then click \"Open\" and \"Upload\" ".
"to upload the ACL list to the Access Point. You can also download the ACL file to your local drive by clicking".
" \"Download ACL File\". The first line of the ACL file indicates the access control policy (Disable/Accept/Reject). ".
"The number of the ACL entries is up to 256.";

$title_filters_wlan_partition="WLAN Partition";
$filters_internal_station="Internal Station Connection";
$filters_internal_station_msg="The default value is \"Enable,\" which allows stations to inter-communicate by connecting to a target AP.<\br>".
"Enable: Allows stations to connect to other stations connected to their own SSID and other SSIDs on the access point.<\br>".
"Disable: Stations cannot connect to other stations connected to their own SSID, but can connect to stations connected to other SSIDs on the access point.<\br>".
"Guest: Stations cannot connect to other stations connected to their own SSID or other SSIDs on the access point.";
$filters_eth_to_wlan="Ethernet to WLAN Access";
$filters_eth_to_wlan_msg="The default value is \"Enable\", which allows data flow from the Ethernet to wireless stations connected to the AP. By disabling this function, ".
"all multicast and broadcast packets from the Ethernet to associated wireless devices are blocked , except DHCP's.";

$head_traffic_control="Traffic Control";
$head_traffic_control_msg="The traffic control feature allows users to manage uplink and downlink settings, Quality of Service (QoS) settings, and to enable, add, modify, and delete traffic manager rules.";

$title_traffic_updownlink_st="Uplink/Downlink Setting";
$title_traffic_updownlink_st_msg="The uplink/downlink setting allows users to customize the downlink and uplink interfaces including specifying downlink/uplink bandwidth rates in Mbits per second. These values are also used ".
"in the QoS and Traffic Manager windows.";

$title_traffic_qos="QoS";
$title_traffic_qos_msg="QoS stands for Quality of Service for Wireless Intelligent Stream Handling, a technology developed to enhance the experience of using a wireless network by prioritizing the traffic of different applications".
". The ".query("/sys/hostname")." supports four priority levels.";

$traffic_qos_enable="Enable";
$traffic_qos_enable_msg="Tick this check box to allow QoS to prioritize your traffic. Use the drop-down menus to select the four levels of priority. Click the Save button when you are finished.";
$traffic_qos_down_banwidth="Downlink Bandwidth";
$traffic_qos_down_banwidth_msg="The downlink bandwidth in Mbits per second. This value is entered in the Uplink/Downlink Setting window.";
$traffic_qos_up_banwidth="Uplink Bandwidth";
$traffic_qos_up_banwidth_msg="The uplink bandwidth in Mbits per second. This value is entered in the Uplink/Downlink Setting window.";

$title_traffic_manager="Traffic Manager";
$title_traffic_manager_msg="The traffic manager feature allows users to create traffic management rules that specify how to deal with listed client traffic and specify ".
"downlink/uplink speed for new traffic manager rules.";

$traffic_traffic_manager="Traffic Manager";
$traffic_traffic_manager_msg="This check box allows you to enable the traffic manager function.";
$traffic_unlisted_clients_traffic="Unlisted Clients Traffic";
$traffic_unlisted_clients_traffic_msg="Toggle the radio buttons between Deny and Forward to determine how to deal with unlisted client traffic.";
$traffic_down_bandwidth="Downlink Bandwidth";
$traffic_down_bandwidth_msg="The downlink bandwidth in Mbits per second. This value is entered in the Uplink/Downlink Setting window.";
$traffic_up_bandwidth="Uplink Bandwidth";
$traffic_up_bandwidth_msg="The uplink bandwidth in Mbits per second. This value is entered in the Uplink/Downlink Setting window.";
$traffic_name="Name";
$traffic_name_msg="Enter a name for the new traffic manager rule being defined.";
$traffic_client_ip="Client IP (optional)";
$traffic_client_ip_msg="Enter a client IP address. This is optional.";
$traffic_client_mac="Client MAC (optional)";
$traffic_client_mac_msg="Enter a client MAC address if desired. This is optional.";
$traffic_down_speed="Downlink Speed";
$traffic_down_speed_msg="Enter a downlink speed in Mbits per second.";
$traffic_up_speed="Uplink Speed";
$traffic_up_speed_msg="Enter an uplink speed in Mbits per second.";

$head_st="Status";

$title_st_dev_info="Device Information";
if(query("/runtime/web/display/status/cpu")=="0")
{
	$title_st_dev_info_msg="This page displays the current information like firmware version, Ethernet and wireless parameters.";
}
else
{
	$title_st_dev_info_msg="This page displays the current information like firmware version, Ethernet and wireless parameters, as well as the information regarding CPU and ".
"memory utilization.";
}

$title_st_cli_info="Client Information";
$title_st_cli_info_msg="This page displays the associated clients SSID, MAC, band, authentication method, signal strength, and power saving mode for the ".query("/sys/hostname")." network.";

$title_st_wds_info="WDS Information";
$title_st_wds_info_msg="This page displays the access points SSID, MAC, band, authentication method, signal strength, and status for the ".query("/sys/hostname")."'s Wireless Distribution System network.";


$head_statistics="Stats";

$title_st_ethernet="Ethernet";
$title_st_ethernet_msg="Displays wired interface network traffic information.";

$title_st_wlan="WLAN";
$title_st_wlan_msg="Displays transmitted frame, received frame and frame error information for the AP network.";


$head_log="Log";
$head_log_msg="Records log events on a remote system log server and reveal web page.";

$title_log_view="View Log";
$title_log_view_msg="The AP's embedded memory holds logs here. The log information includes but is not limited to the following ".
"items: cold start AP, upgrading firmware, client associate and disassociate with AP, and web login. The web page holds up to 500 logs.";

$title_log_set="Log Settings";
$title_log_set_msg="Enter the log server's IP address to send the log to that server. Check or uncheck System Activity, Wireless Activity, ".
"or Notice to specify what kind of log type you want it to log.";
$title_email="Email Notification";
$title_email_msg="Support Simple Mail Transfer Protocol for log schedule and periodical change key. It can not support Gmail SMTP port 465.".
" Please set to Gmail SMTP port 25 or 587.";
$title_email_schedule="Email Log Schedule";
$title_email_schedule_msg="Use the pull-down menu to set the e-mail log schedule.";


$head_mt="Maintenance";

$title_mt_admin="Administrator Settings";
$mt_limit_admin_vid="Limit Administrator VLAN ID";
$mt_limit_admin_vid_msg="Packets with VLAN tags that have the same VID will permit the administrator to login.";
$mt_limit_admin_ip="Limit Administrator IP Range";
$mt_limit_admin_ip_msg="Enter an IP address pool in which the administrator is allowed to login from.";
$title_mt_sysname="System Name Settings";
$mt_sysname="System Name";
$mt_sysname_msg="An administratively assigned name for the ".query("/sys/hostname").". ";
$mt_location="Location";
$mt_location_msg="The physical location of the ".query("/sys/hostname").".";
$title_mt_login="Login Settings";
$mt_username="Login Name";
$mt_username_msg="You can customize the user name as an".
" administrator of the ".query("/sys/hostname").". The default login name is \"admin\" with no password configured.";
$mt_oldpass="Old Password";
$mt_oldpass_msg="Enter the old password.";
$mt_newpass="New Password";
$mt_newpass_msg="Enter a password in this field. The password is case-sensitive. \"A\" ".
"is a different character than \"a.\" The length should be between 0 and 64 characters.";
$mt_conpass="Confirm Password";
$mt_conpass_msg="Type the password again to confirm it.";
$title_mt_console="Console Settings";
$mt_status="Status";
$mt_status_msg="Enable or disable console.";
$mt_console_protocol="Console Protocol";
$mt_console_protocol_msg="Choose Telnet or SSH.";
$mt_timeout="Timeout";
$mt_timeout_msg="Select the time out period.";
$title_mt_snmp="SNMP Settings";
$mt_st_snmp="Status";
$mt_st_snmp_msg="Enable or disable SNMP.";
$mt_public_comm="Public Community String";
$mt_public_comm_msg="Enter the public community string for SNMP.";
$mt_private_comm="Private Community String";
$mt_private_comm_msg="Enter the private community string for SNMP.";
$mt_trap="Trap Status";
$mt_trap_msg="Enable or disable Trap.";
$mt_trap_serv="Trap Server IP";
$mt_trap_serv_msg="The IP address of the SNMP manager to receive".
" traps sent from the wireless access point.";
$title_mt_pingctrl="Ping Control Setting";
$mt_ping_st="Status";
$mt_ping_st_msg="Ping works by sending ICMP \"echo request\" packets to the target host and listening for ICMP echo response replies. By ".
"disabling the Ping control setting, this AP will not respond to the ICMP echo request packets. The default is enabled.";

$title_mt_fw="Firmware and SSL Certification Upload";
$title_mt_fw_msg="Firmware and SSL Certification Upload";
$title_mt_fw_msg1="You can upload files to the access point.";
$mt_upload_fw="Upload Firmware from Local Hard Drive";
$mt_upload_fw_msg="The current firmware version is displayed above the file location field. After the latest firmware is downloaded,".
" click on the \"Browse\" button to locate the new firmware. Once the file is selected, click on the \"Open\" and \"Upload\" button to begin ".
"updating the firmware. Please don't turn the power off while upgrading.";
$mt_upload_ssl="Upload SSL Certification from Local Hard Drive";
$mt_upload_ssl_msg="After you have downloaded a SSL certification to your local drive, click \"Browse\" Select the certification and click ".
"\"Open\" and \"Upload\" to complete the upgrade.";
$mt_upload_language = "Language Pack Upgrade";
$mt_upload_language_msg = "The current Language Pack version is displayed above the file location field.. After the Language Pack ".
"is downloaded, click on the \"Browse\" button to locate the Language Pack. Once the file is selected, click on the \"Open\" and ".
"\"Upload\" button to begin updating the Language. Please don't turn the power off while upgrading.";

$_title_mt_config="Configuration File";
$mt_config="Configuration File Upload and Download";
$mt_config_msg="You can upload and download configuration files of the access point.";
$mt_upload_config="Upload Configuration File";
$mt_upload_config_msg="Browse to the saved configuration file you have in local drive and click \"Open\" and \"Upload\" to update the configuration.";
$mt_download_config="Download Configuration File";
$mt_download_config_msg="Click \"Download\" to save the current configuration file to your local disk. Note that if you save one configuration".
" file with the administrator's password now, after resetting your ".query("/sys/hostname")." and then updating to this saved configuration file, the password will be gone.";

$title_mt_time="Time and Date";
$title_mt_time_msg="Enter the NTP server IP, choose the time zone, and enable or disable daylight saving time.";
$auto_time = "Automatic Time Configuration";
$auto_time_msg = "Enable NTP get the date and time from a NTP server.";
$date_and_time_manu = "Set the Date and Time Manually";
$date_and_time_manu_msg = "You can set the date and time manually or copy your computer's time to AP.";

$head_config ="Configuration";
$config_save_activate="Save and Activate";
$config_save_activate_msg="Click\" Save and Activate  \" to save all settings and re-activate the system.";
$config_discard_change="Discard change";
$config_discard_change_msg="Click \"Discard change \" to discard the settings"; 

$head_sys = "System";
$title_sys = "System Settings";
$sys_apply_restart = "Restart The Device";
$sys_apply_restart_msg = "Click on Restart to restart the device.";
$sys_apply_restore = "Restore to Factory Default Settings.";
$sys_apply_restore_msg = "Click on Restore to reset to factory default settings.";
$sys_clear_language = "Clear Language pack";
$sys_clear_language_msg = "Click on clear to reset language to default settings.";
?>
