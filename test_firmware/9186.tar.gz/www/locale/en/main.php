<?
$basic_setting = "Basic Settings";
$basic_wireless= "Wireless";
$basic_lan	="LAN";
$basic_ipv6	="IPv6";
$adv_setting = "Advanced Settings";
$adv_perf = "Performance";
$adv_group = "Grouping";
$adv_mssid = "Multi-SSID";
$adv_8021q = "VLAN";
$adv_tr069v3 = "Tr069v3";
$adv_rogue_ap = "Intrusion";
$adv_scheduling = "Schedule";
$adv_arp_spoofing = "ARP Spoofing Prevention";
$adv_radiusserver = "Internal RADIUS Server";
$adv_ctrl = "Traffic Control";
$adv_ctrl_setting = "Uplink/Downlink Settings";
$adv_qos = "QoS";
$adv_ctrl_qos = "QoS";
$adv_ctrl_trafficmanage = "Traffic Manager";
$adv_wtp = "WLAN Switch";
$bsc_capwap = "CAPWAP";
$adv_dhcp = "DHCP Server";
$adv_dhcp_dynamic = "Dynamic Pool Settings";
$adv_dhcp_static = "Static Pool Settings";
$adv_dhcp_list = "Current IP Mapping List";
$adv_filter = "Filters";
$adv_filter_acl = "Wireless MAC ACL";
$adv_filter_partition = "WLAN Partition";
$adv_radiusclient = "Radiusclient";
$adv_ap_array = "AP Array";
$adv_url_redir = "Web Redirection";
$adv_mcast = "Multicast Rate";
$st_setting = "Status";
$st_device = "Device Information";
$st_client = "Client Information";
$st_wds_client = "WDS Information";
$st_stats = "Stats";
$st_stats_ethernet = "Ethernet";
$st_stats_wlan = "WLAN";
$st_log = "Log";
$st_log_view = "View Log";
$st_log_setting = "Log Settings";
$tool_admin = "Administration Settings";
$cfg_ipv6 = query("/inet/entry:1/ipv6/valid");
if($cfg_ipv6==1)
{
	$tool_fw = "Firmware Upload";
}
else
{
$tool_fw = "Firmware and SSL Certification Upload";
}
$tool_config = "Configuration File";
$tool_sntp = "Time and Date";
$logout_msg = "&nbsp;&nbsp;The current browser connection will<br>&nbsp;&nbsp;be disconnected if you click <b>here</b>.";
?>
