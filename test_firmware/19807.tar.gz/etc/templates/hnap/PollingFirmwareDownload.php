HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/trace.php"; 

$result = "OK";
$percentage = 0;

$default_firmware_size = 10*1024*1024;

$fw_path = "/var/firmware.seama";

$fw_downloading_flag_path = "/runtime/FWDownloadingFlag";

if (isfile($fw_path)!= "1")
{
	$result = "ERROR";
	TRACE_error("The firmware file is not existed!");
}

if ($result == "OK")
{
	if (get("",$fw_downloading_flag_path) == "1")
	{
		//download is in processing.
		$exec_path = "/runtime/runcmd";
		setattr($exec_path,  "get", "ls -l ".$fw_path);
		$file_result = get ("", $exec_path);
		del ($exec_path);
		$current_size = scut($file_result, 4, "");
		$percentage = $current_size * 100 / $default_firmware_size;

		if ($percentage > 95 )
		{
			//it is not downloaded completed.
			$percentage = 95;
		}
	}
	else
	{
		$percentage = 100;
	}
	
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
<soap:Body>
	<PollingFirmwareDownloadResponse xmlns="http://purenetworks.com/HNAP1/">
		<PollingFirmwareDownloadResult><?=$result?></PollingFirmwareDownloadResult>
		<DownloadPercentage><?=$percentage?></DownloadPercentage>
	</PollingFirmwareDownloadResponse>
</soap:Body>
</soap:Envelope>
