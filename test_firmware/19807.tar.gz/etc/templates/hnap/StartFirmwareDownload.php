HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/trace.php"; 

$result = "OK";

// We use the flag to indicate that the downloading is in processing or not.
$fwDownloadingFlag = "/runtime/FWDownloadingFlag";

if (get("",$fwDownloadingFlag) == "1")
{
	TRACE_error("Download is in processing.");
	$result = "ERROR";
}

//check the network status.
if ($result == "OK")
{
	$path_inf_wan1 = XNODE_getpathbytarget("", "inf", "uid", $WAN1, 0);
	$wan1_phyinf = get("",$path_inf_wan1."/phyinf");
	$path_run_phyinf_wan1 = XNODE_getpathbytarget("/runtime", "phyinf", "uid", $wan1_phyinf, 0);
	$status = get("",$path_run_phyinf_wan1."/linkstatus");
	if( $status != "0" && $status != "")
	{ $statusStr = "CONNECTED"; }
	else 
	{ $statusStr = "DISCONNECTED"; }

	if ($statusStr == "CONNECTED")
	{
		$result = "OK";
	}
	else
	{
		TRACE_error("Internet is not connected.");
		$result = "ERROR";
	}
}

//write the shell script file to execute the firmware check and download.
if ($result == "OK")
{
	$fwinfo_file = "/tmp/fwinfo.xml";
	$check_fw_cmd = "/etc/events/checkfw.sh";
	$fw_path = "/var/firmware.seama";
	$fw_download_url_path = "/runtime/firmware/FWDownloadUrl";

	// Set the downloading flag as 1 to indicate the firmware is downloading and this node will be deleted after download is completed.
TRACE_error("fwDownloadingFlag=".$fwDownloadingFlag);

	set ($fwDownloadingFlag, "1");

	fwrite("w",$ShellPath, "#!/bin/sh\n");
	fwrite("a",$ShellPath, "echo [$0] > /dev/console\n");
	$cmd = $check_fw_cmd;
	fwrite("a",$ShellPath, $cmd." > /dev/console\n");
	$fwinfo_file = "/tmp/fwinfo.xml";
	$cmd = "if [ -e \"".$fwinfo_file."\" ] ; then";
	fwrite("a",$ShellPath, $cmd." \n");
	$cmd = "echo \"Starting download firmware.\"";
	fwrite("a",$ShellPath, $cmd." > /dev/console\n");

	$cmd = "wget -O ". $fw_path . " `xmldbc -g ".$fw_download_url_path."`";
	fwrite("a",$ShellPath, $cmd." > /dev/console\n");
	$cmd = "fi";
	fwrite("a",$ShellPath, $cmd."\n");
	$cmd = "xmldbc -X ".$fwDownloadingFlag;
	fwrite("a",$ShellPath, $cmd." > /dev/console\n");
}
else
{
	fwrite("w",$ShellPath, "#!/bin/sh\n");
	fwrite("a",$ShellPath, "echo [$0] > /dev/console\n");
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
<soap:Body>
	<StartFirmwareDownloadResponse xmlns="http://purenetworks.com/HNAP1/">
		<StartFirmwareDownloadResult><?=$result?></StartFirmwareDownloadResult>
	</StartFirmwareDownloadResponse>
</soap:Body>
</soap:Envelope>
