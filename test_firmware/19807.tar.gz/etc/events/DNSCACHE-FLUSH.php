<?
foreach ("/runtime/inf")
{
	del("dnscache");
}
?>
