<?
include "/htdocs/phplib/trace.php";
include "/etc/services/IP6TABLES/ip6twan.php";
IP6TWAN_build_command("WAN-1");
?>
