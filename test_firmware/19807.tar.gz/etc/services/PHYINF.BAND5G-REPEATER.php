<?
include "/etc/services/PHYINF/phywifi.php";
wificonfig("BAND5G-REPEATER");
?>
