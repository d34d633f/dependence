var tos_check="You may use the Service only if you agree to the following terms of service each time you access the Service.";
var tos="Terms of Service (TOS) \
\n\n \
Access to WiFi. \
\n\n \
The Service is a free public service. Your access to the Service may be blocked, suspended, or terminated at any time for any reason including, but not limited to, violation of this Agreement, disruption of access to other users or networks, or violation of applicable laws or regulations. You must accept this Agreement each time you use the Service and it is your responsibility to review it for any changes each time.  This is an open wireless network.  No network communication is 100% secure. \
\n\n \
Please remember: NO network communication should be considered private or protected. We reserves the right to reduce throughput or access as need be. \
\n\n \
Acceptable Use of the Service. \
\n\n \
Your use of the Service and any activities conducted online through the Service shall not violate any applicable law or regulation, or any third party. We cannot accept any responsibility for any injury or loss that results from inaccurate, unsuitable, offensive, or illegal Internet communications. \
\n\n \
Disclaimer. \
\n\n \
You acknowledge (i) that the Service may not be uninterrupted or error-free; (ii) that viruses or other harmful applications may be available through the Service; (iii) that does not guarantee the security of the Service and that unauthorized third parties may access your computer or files or otherwise monitor your connection. \
\n\n \
THE USE OF THE SERVICE FOR THE FOLLOWING ACTIVITIES IS PROHIBITED: \
\n\n \
Spamming and Invasion of Privacy of Others, Violating Intellectual Property Law, Transmitting Obscene or Indecent Speech or Materials, Transmitting Defamatory or Abusive Language, Hacking or Distribution of Internet Viruses, Worms, Trojan Horses, or Other Destructive Activities.";
