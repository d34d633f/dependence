<!--# exec cgi /bin/mjson wifi_sta @=wifi0_vap* up=1 nawds_mode=0 -->
