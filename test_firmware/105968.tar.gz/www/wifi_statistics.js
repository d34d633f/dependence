<!--# exec cgi /bin/mjson wifi_device_statistics -->
