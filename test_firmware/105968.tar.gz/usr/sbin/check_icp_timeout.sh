connect_list=$(uci get misc.captive_portal.connect_list 2>&-)
auth_timeout=$(uci get cameo.captive_portal.auth_timeout 2>&-)
time_now=$(date +%s)

remove_allow_list()
{
	# $1=mac $2=iface $3=timeout #
	ebtables -t broute -D internal_captive_portal -i $2 -s $1 -j RETURN  # if, mac
	ebtables -t broute -D internal_captive_portal -d $1 -j RETURN # mac
	ebtables -D internal_captive_portal -i $2 -s $1 -j ACCEPT # if, mac
	uci del_list misc.captive_portal.connect_list=$1_$2_$3
	uci commit misc
}

#main
if [ ! "$auth_timeout" = "" -a ! "$auth_timeout" = "0" ];then
	is_timeout=$(( $auth_timeout * 60))
	for data in $connect_list
	do
		get_mac=$(echo ${data} | cut -d '_' -f 1)
		get_if=$(echo ${data} | cut -d '_' -f 2)
		get_list_time=$(echo ${data} | cut -d '_' -f 3)
		time_cmp=$(( $get_list_time + $is_timeout ))

		if [ $time_now -gt $time_cmp ]; then
			remove_allow_list $get_mac $get_if $get_list_time
		fi
	done
fi
