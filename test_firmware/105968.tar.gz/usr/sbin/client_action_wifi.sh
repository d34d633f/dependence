#!/bin/sh

echo "$1 - $2" > /dev/console

if [ "$2" = "DISCONNECTED" ]; then
	ifconfig br-lan 192.168.10.100
        /etc/init.d/dnsmasq restart 
fi

