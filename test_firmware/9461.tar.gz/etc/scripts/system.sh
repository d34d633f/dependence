#!/bin/sh
case "$1" in
start)
	echo "start Layout ..."	> /dev/console
	/etc/scripts/layout.sh start	> /dev/console
	echo "start LAN ..."		> /dev/console
	/etc/templates/lan.sh start	> /dev/console
	echo "start web server ..."                 
	/etc/templates/webs.sh start    > /dev/console
	sh /etc/templates/limitedadmin.sh	>	/dev/console
	mkdir /var/servd	>	/dev/console
	servd&	>	/dev/console
	echo "start fresetd ..."	> /dev/console
	fresetd &
	echo "enable LAN ports ..."	> /dev/console
	/etc/scripts/enlan.sh		> /dev/console
	echo " Generate channel table according to the country code..."	> /dev/console
	genchanneltable		> /dev/console
	echo " Generate VLAN table according to the port..."	> /dev/console
	genVLANTableByPort	> /dev/console
	echo "start WAN ..."		> /dev/console
	/etc/scripts/misc/setwantype.sh	> /dev/console
	/etc/templates/wan.sh start	> /dev/console
	if [ "`rgdb -i -g /cloud/enable`" = 0 ]; then
	/etc/templates/cloud_brnf.sh    > /dev/console
 echo "start WLAN ..."		> /dev/console
 /etc/templates/wlan.sh start	> /dev/console
	else
	echo "start CLOUD COMMAND ..."     > /dev/console
	/etc/templates/cloud_init.sh   > /dev/console
	fi
	echo "start stunnel ..."
	/etc/templates/stunnel.sh start > /dev/console
	echo "start telnet daemon ..." > /dev/console
	rgdb -s /sys/telnetd true	> /dev/console
	/etc/scripts/misc/telnetd.sh	> /dev/console
	echo "start DHCP server"    > /dev/console
	/etc/templates/dhcpd.sh		> /dev/console
 echo "start NetBIOS ..."     > /dev/console
sh /etc/templates/netbios.sh start    > /dev/console
echo "start Ethlink ..."     > /dev/console
ethlink &> /dev/console
	;;
stop)
	echo "stop WAN ..."		> /dev/console
	/etc/templates/wan.sh stop	> /dev/console
	echo "stop fresetd ..."	> /dev/console
	killall fresetd
	echo "stop WLAN ..."		> /dev/console
	/etc/templates/wlan.sh stop	> /dev/console
	echo "stop LAN ..."		> /dev/console
	/etc/templates/lan.sh stop	> /dev/console
	echo "reset layout ..."	> /dev/console
	/etc/scripts/layout.sh	stop	> /dev/console
	;;
restart)
	sleep 3
	$0 stop
	$0 start
	;;
*)
	echo "Usage: system.sh {start|stop|restart}"
	;;
esac
exit 0
