#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");

/* detect interface */
$WANDEV = query("/runtime/layout/wanif");
$WLANDEV = query("/runtime/layout/wlanif");
echo "echo -n Interface is wanif=".$WANDEV." wlanif=".$WLANDEV." \n";
if ( $WANDEV=="" || $WLANDEV=="" ){ echo "echo ... Error!!! \n";exit; }else{ echo "echo ... OK \n"; }

/* tc debug */
$TC="echo tc";
$TC="tc";
$K=kbps;
$K=kbit;

/* main */
if ($generate_start==1)
{
	echo "echo Start QOS system ... \n";
	
	/* process node */
	$QOS_ENABLE  = query("/qos/enable");
	if ( $QOS_ENABLE!=1 ){ echo "echo QOS is disabled. \n";exit; }	
	$UPSTREAM    = query("/qos/bandwidth/upstream");
	$DOWNSTREAM  = query("/qos/bandwidth/downstream");
	if ( $DOWNSTREAM==0 || $DOWNSTREAM=="" ){ $DOWNSTREAM=102400; }
	if ( $UPSTREAM==0   || $UPSTREAM==""   ){ $UPSTREAM=102400; }
/*--------------Set up QoS bandwidth for different wireless mode----------------------*/
$wlan_enable = query("/wlan/inf:1/enable");
$wlanapmode = query("/wlan/inf:1/ap_mode");
if ($wlan_enable != "1" || $wlanapmode != "0")
{ echo "echo QOS is disabled, because WLAN setting. \n";exit; }

$wlmode	= query("/wlan/inf:1/wlmode");
$bw_11n	=query("/wlan/inf:1/cwmmode");	if ($bw_11n=="")	{$bw_11n	="0";}

if ($wlmode=="2"||$wlmode=="7")
{$UPSTREAM=16384;$DOWNSTREAM=16384;}/*a/g: 16 Mbps*/
else if ($bw_11n=="1")
{$UPSTREAM=71680;$DOWNSTREAM=71680;}/*20/40MHz: 70 Mbps*/
else
{$UPSTREAM=51200;$DOWNSTREAM=51200;}/*20MHz: 50 Mbps*/

	echo "echo QOS=".$QOS_ENABLE." UPSTREAM=".$UPSTREAM." DOWNSTREAM=".$DOWNSTREAM." \n";
/*------------------------------------------------------------------------------------*/

	/*----------------------------------------------------------------------------*/
	$PRIO_ALL=$UPSTREAM ;
	$PRIO0_MAX=$PRIO_ALL * 90 / 100 ;
	$PRIO1_MAX=$PRIO_ALL * 80 / 100 ;
	$PRIO2_MAX=$PRIO_ALL * 75 / 100 ;
	$PRIO3_MAX=$PRIO_ALL * 70 / 100 ;
	$PRIO0_MIN=$PRIO_ALL * 55 / 100 ;
	$PRIO1_MIN=$PRIO_ALL * 30 / 100 ;
	$PRIO2_MIN=$PRIO_ALL * 10 / 100 ;
	$PRIO3_MIN=$PRIO_ALL * 5 / 100 ;

	echo $TC." qdisc add dev ".$WANDEV." handle 1: root htb default 3 \n";
	echo $TC." class add dev ".$WANDEV." parent 1:0 classid 1:1 htb rate ".$PRIO_ALL.$K." burst 100k cburst 100k \n";
	echo $TC." class add dev ".$WANDEV." parent 1:1 classid 1:40 htb prio 0  rate ".$PRIO0_MIN.$K." ceil ".$PRIO0_MAX.$K." burst 50k cburst 50k \n";
	echo $TC." class add dev ".$WANDEV." parent 1:1 classid 1:41 htb prio 3  rate ".$PRIO1_MIN.$K." ceil ".$PRIO1_MAX.$K." burst 50k cburst 50k \n";
	echo $TC." class add dev ".$WANDEV." parent 1:1 classid 1:42 htb prio 5  rate ".$PRIO2_MIN.$K." ceil ".$PRIO2_MAX.$K." \n";
	echo $TC." class add dev ".$WANDEV." parent 1:1 classid 1:43 htb prio 7  rate ".$PRIO3_MIN.$K." ceil ".$PRIO3_MAX.$K." \n";
	echo $TC." qdisc add dev ".$WANDEV." parent 1:40 handle 400: pfifo limit 50 \n";
	echo $TC." qdisc add dev ".$WANDEV." parent 1:41 handle 410: pfifo limit 30 \n";
	echo $TC." qdisc add dev ".$WANDEV." parent 1:42 handle 420: pfifo limit 15 \n";
	echo $TC." qdisc add dev ".$WANDEV." parent 1:43 handle 430: pfifo limit 5 \n";

	$PRIO_ALL=$DOWNSTREAM ;
	$PRIO0_MAX=$PRIO_ALL * 90 / 100 ;
	$PRIO1_MAX=$PRIO_ALL * 80 / 100 ;
	$PRIO2_MAX=$PRIO_ALL * 75 / 100 ;
	$PRIO3_MAX=$PRIO_ALL * 70 / 100 ;
	$PRIO0_MIN=$PRIO_ALL * 55 / 100 ;
	$PRIO1_MIN=$PRIO_ALL * 30 / 100 ;
	$PRIO2_MIN=$PRIO_ALL * 10 / 100 ;
	$PRIO3_MIN=$PRIO_ALL * 05 / 100 ;

	echo $TC." qdisc add dev ".$WLANDEV." handle 2: root htb default 3 \n";
	echo $TC." class add dev ".$WLANDEV." parent 2:0 classid 2:1 htb rate ".$PRIO_ALL.$K." burst 100k cburst 100k \n";
	echo $TC." class add dev ".$WLANDEV." parent 2:1 classid 2:40 htb prio 0  rate ".$PRIO0_MIN.$K." ceil ".$PRIO0_MAX.$K." burst 50k cburst 50k \n";
	echo $TC." class add dev ".$WLANDEV." parent 2:1 classid 2:41 htb prio 3  rate ".$PRIO1_MIN.$K." ceil ".$PRIO1_MAX.$K." burst 50k cburst 50k \n";
	echo $TC." class add dev ".$WLANDEV." parent 2:1 classid 2:42 htb prio 5  rate ".$PRIO2_MIN.$K." ceil ".$PRIO2_MAX.$K." \n";
	echo $TC." class add dev ".$WLANDEV." parent 2:1 classid 2:43 htb prio 7  rate ".$PRIO3_MIN.$K." ceil ".$PRIO3_MAX.$K." \n";
	echo $TC." qdisc add dev ".$WLANDEV." parent 2:40 handle 400: pfifo limit 50 \n";
	echo $TC." qdisc add dev ".$WLANDEV." parent 2:41 handle 410: pfifo limit 30 \n";
	echo $TC." qdisc add dev ".$WLANDEV." parent 2:42 handle 420: pfifo limit 15 \n";
	echo $TC." qdisc add dev ".$WLANDEV." parent 2:43 handle 430: pfifo limit 5 \n";
	/*----------------------------------------------------------------------------*/

    /*Classifiers*/
    $HTTP  = query("/qos/classifiers/http");
    $AUTO  = query("/qos/classifiers/auto");
  
    if ($HTTP==1)
    {
        /*Filter TCP/IP port 80/8080 to priority VO*/
        echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 100 u32 match ip sport 80 1 flowid 1:40 \n";
        echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 100 u32 match ip dport 80 1 flowid 1:40 \n";
        echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 100 u32 match ip sport 80 1 flowid 2:40 \n";
        echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 100 u32 match ip dport 80 1 flowid 2:40 \n";
        echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 100 u32 match ip sport 8080 1 flowid 1:40 \n";
        echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 100 u32 match ip dport 8080 1 flowid 1:40 \n";
        echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 100 u32 match ip sport 8080 1 flowid 2:40 \n";
        echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 100 u32 match ip dport 8080 1 flowid 2:40 \n";        
    }
    if ($AUTO==1)
    {
        /*Filter TCP/IP port 20/21 to priority BK*/
        echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 110 u32 match ip sport 21 1 flowid 1:43 \n";
        echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 110 u32 match ip sport 20 1 flowid 1:43 \n";
        echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 110 u32 match ip dport 21 1 flowid 1:43 \n";
        echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 110 u32 match ip dport 20 1 flowid 1:43 \n";
        echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 110 u32 match ip sport 21 1 flowid 2:43 \n";
        echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 110 u32 match ip sport 20 1 flowid 2:43 \n";
        echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 110 u32 match ip dport 21 1 flowid 2:43 \n";
        echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 110 u32 match ip dport 20 1 flowid 2:43 \n";
        /*TOS*/
        /*VO: DSCP HEX = 0x38 || 0x30*/
        echo .$TC." filter add dev ".$WANDEV." parent 1: protocol all prio 111 u32 match ip tos 0xC0 0xC0 flowid 1:40 \n";
	    echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol all prio 111 u32 match ip tos 0xC0 0xC0 flowid 2:40 \n";
	    /*VI: DSCP HEX = 0x18 || 0x00*/
	    echo .$TC." filter add dev ".$WANDEV." parent 1: protocol all prio 112 u32 match ip tos 0x80 0xC0 flowid 1:41 \n";
	    echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol all prio 112 u32 match ip tos 0x80 0xC0 flowid 2:41 \n";
	    /*BE: our default is BE, so we won't pick up BE, DSCP HEX = 0x18 || 0x00*/
	    /*BK: DSCP HEX = 0x10 || 0x08*/
	    echo .$TC." filter add dev ".$WANDEV." parent 1: protocol all prio 113 u32 match ip tos 0x40 0xE0 flowid 1:43 \n";
	    echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol all prio 113 u32 match ip tos 0x40 0xE0 flowid 2:43 \n";
	    echo .$TC." filter add dev ".$WANDEV." parent 1: protocol all prio 114 u32 match ip tos 0x20 0xE0 flowid 1:43 \n";
	    echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol all prio 114 u32 match ip tos 0x20 0xE0 flowid 2:43 \n";
    }    
 
	/*----------------------------------------------------------------------------*/
	/*echo .$TC." filter add dev ".$WANDEV." parent 1: protocol all prio 1 u32 match ip tos 0x00 0xE0 flowid 1:40 \n";
	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol all prio 1 u32 match ip tos 0x00 0xE0 flowid 2:40 \n";

	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol all prio 1 u32 match ip tos 0x80 0xE0 flowid 1:41 \n";
	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol all prio 1 u32 match ip tos 0x80 0xE0 flowid 2:41 \n";
	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol all prio 1 u32 match ip tos 0x40 0xE0 flowid 1:42 \n";
	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol all prio 1 u32 match ip tos 0x40 0xE0 flowid 2:42 \n";
	echo .$TC." filter add dev ".$WANDEV." parent 1: protocol all prio 1 u32 match ip tos 0x20 0xE0 flowid 1:43 \n";
	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol all prio 1 u32 match ip tos 0x20 0xE0 flowid 2:43 \n";*/
	/*----------------------------------------------------------------------------*/

	/*----------------------------------------------------------------------------*/
	/*Default priotity will be Best Effect*/
    echo .$TC." filter add dev ".$WANDEV."  parent 1: protocol all prio 240 u32 match u8 00 00 at 0 flowid 1:42 \n";
    echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol all prio 240 u32 match u8 00 00 at 0 flowid 2:42 \n";
	/*echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio 100 u32  match ip src 0.0.0.0/0 flowid 1:43 \n";
	echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio 100 u32  match ip dst 0.0.0.0/0 flowid 2:43 \n";*/
	/*----------------------------------------------------------------------------*/

	/*-----------------------------------------------------*/
	/*echo "echo ".$QOS_ENABLE." ".$UPSTREAM." ".$DOWNSTREAM." > /proc/fastnat/qos \n";
	echo "echo -1 > /proc/fastnat/formqossupport \n";*/
	/*-----------------------------------------------------*/
	/*----QoS Rule Part-------------------------------------------*/
	/*$qosrule_enable=query("/qos/rule/enable");*/
	/*echo "echo qosrune_enable=".$qosrune_enable." \n";*/
    /*if ($qosrule_enable==1)*/
    /*{*/
       /*echo "echo start for loop \n";*/
        $index1=0;
        for ("/qos/rule/index")
        {
            $index1++;
            if ($index1 >= 64){exit;}
    	    $rule_enable = query("/qos/rule/index:".$index1."/state");
    	    /*echo "echo index=".$index1." rule_enable=".$rule_enable." \n";*/
    	    if ($rule_enable=="1")
    	    {
    	        $opts="";
    	        $opts1="";
    	        $opts2="";
    	        $protocol = query("/qos/rule/index:".$index1."/protocol");
    	        if ($protocol=="") 
    	        {
    	           /* echo "echo $protocol==NULL \n";*/
    	            exit;
    	        }
    	        if ($protocol<=255) 
    	        {
    	            $opts=$opts." match ip protocol ".$protocol." 0xff";
    	        }
    	        $host1ip = query("/qos/rule/index:".$index1."/host1/startip");
    	        $host1iprange = query("/qos/rule/index:".$index1."/host1/iprange");
    	        $host1port = query("/qos/rule/index:".$index1."/host1/startport");
    	        $host1portrange = query("/qos/rule/index:".$index1."/host1/portrange");
    	        $host2ip = query("/qos/rule/index:".$index1."/host2/startip");
    	        $host2iprange = query("/qos/rule/index:".$index1."/host2/iprange");
    	        $host2port = query("/qos/rule/index:".$index1."/host2/startport");
    	        $host2portrange = query("/qos/rule/index:".$index1."/host2/portrange");
    	       /* echo "echo host1ip=".$host1ip." host1iprange=".$host1iprange." \n";*/
    	       /* echo "echo host2ip=".$host2ip." host2iprange=".$host2iprange." \n";*/
    	       /* echo "echo host1port=".$host1port." host1portrange=".$host1portrange." \n";*/
    	       /* echo "echo host2port=".$host2port." host2portrange=".$host2portrange." \n";*/
    	        if ($host1ip!=""&& $host1iprange!="")
    	        {  	        
    	            $opts1=$opts1." match ip dst ".$host1ip."/".$host1iprange;
    	            $opts2=$opts2." match ip src ".$host1ip."/".$host1iprange;
    	        }
    	        if ($host1port!=""&& $host1portrange!="")
    	        {
    	            $opts1=$opts1." match ip dport ".$host1port." ".$host1portrange;
    	            $opts2=$opts2." match ip sport ".$host1port." ".$host1portrange;
    	        }
    	        
    	        if ($host2ip!=""&& $host2iprange!="")
    	        {  	        
    	            $opts1=$opts1." match ip src ".$host2ip."/".$host2iprange;
    	            $opts2=$opts2." match ip dst ".$host2ip."/".$host2iprange;
    	        }
    	        if ($host2port!=""&& $host2portrange!="")
    	        {
    	            $opts1=$opts1." match ip sport ".$host2port." ".$host2portrange;
    	            $opts2=$opts2." match ip dport ".$host2port." ".$host2portrange;
    	        }
    	        $priority=query("/qos/rule/index:".$index1."/priority");
    	        if ($priority=="") 
    	        {
    	            /*#echo "echo $priority==NULL \n";*/
    	            exit; 
    	        }
    	        echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio ".$index1." u32 ".$opts."".$opts1." flowid 1:4".$priority." \n";
    	        echo .$TC." filter add dev ".$WANDEV." parent 1: protocol ip prio ".$index1." u32 ".$opts."".$opts2." flowid 1:4".$priority." \n";
    	        echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio ".$index1." u32 ".$opts."".$opts1." flowid 2:4".$priority." \n";
    	        echo .$TC." filter add dev ".$WLANDEV." parent 2: protocol ip prio ".$index1." u32 ".$opts."".$opts2." flowid 2:4".$priority." \n";
            }/*End of if ($rule_enable=="1")*/
        }/*End of for ("/qos/rule/index")*/
    /*}*//*End of if ($qosrule_enable==1)*/


}
else
{
	echo "echo Stop QOS system ... \n";
	echo .$TC." qdisc del dev ".$WANDEV." root \n";
	echo .$TC." qdisc del dev ".$WLANDEV." root \n";
	/*echo "echo 0 > /proc/fastnat/qos \n";*/
}

?>
