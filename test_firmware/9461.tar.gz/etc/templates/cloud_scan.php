#!/bin/sh
<?
$cloud_info = "/tmp/cloud/cloud_scan";
$apscan_path="/runtime/wlan/inf:1/apscanlistinfo/apscan";
fwrite($cloud_info, "-----------scan info-----------\n");
for("/runtime/wlan/inf:1/apscanlistinfo/apscan")
{
	$ssid=query($apscan_path.":".$@."/ssid");
	$bssid=query($apscan_path.":".$@."/mac");
	$channel=query($apscan_path.":".$@."/chan");
	$security=query($apscan_path.":".$@."/auth");
	
	fwrite2( $cloud_info, "SSID: ".$ssid."\n");
	fwrite2($cloud_info, "BSSID: ".$bssid."\n");
	fwrite2($cloud_info, "Channel: ".$channel."\n");
	fwrite2($cloud_info, "Security: ".$security."\n");
	fwrite2($cloud_info, "\n");
}
	
?>		