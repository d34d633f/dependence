<? /* vi: set sw=4 ts=4: */
anchor("/wlan/inf:1");
   for("/wlan/inf:1/zonedefence_ip/ipaddr")
       {
        $ipaddr=query("/wlan/inf:1/zonedefence_ip/ipaddr:".$@);
        echo "iwpriv ".$wlanif." add_ip ".$ipaddr."\n"; 	
	   }
		echo "iwpriv ".$wlanif." maccmd 2\n"; //set acl to DENY
   
														   
?>
