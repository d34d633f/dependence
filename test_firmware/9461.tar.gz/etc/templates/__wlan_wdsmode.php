<? /* vi: set sw=4 ts=4: */
$WLAN_g="/wlan/inf:1";  // b, g, n band
//$WLAN_a="/wlan/inf:2"  // a band
$WLAN_a=$WLAN_g;  // a, g band use the same config.
$band	= query("/wlan/ch_mode");  // "1" #1--->a   0---> b,g,n
$wlxmlpatch_primary_pid = "/var/run/wlxmlpatch.pid";
$ap_igmp_pid = "/var/run/ap_igmp.pid";
$A_BAND = 1;  // 1--->a   
$G_BAND = 0;  // 0---> b,g,n

if ($band == 1)  // a band
{
    $WLAN = $WLAN_a;
    $a_mode = query($WLAN."/wlmode");
}
else
{
    $WLAN = $WLAN_g; 
    $g_mode = query($WLAN."/wlmode");    
}

$ap_mode	= query($WLAN."/ap_mode");  // "1" #1--->a   0---> b,g,n
if ($ap_mode == 4)  // WDS without AP // WDSwithoutAP_bug_0321
{    $withoutap = 1; }
else  // ($WLAN == 3)  WDS with AP
{    $withoutap = 0; }


if ($generate_start==1)
{    
	echo "echo Start WLAN interface ".$wlanif." ... > /dev/console\n";
		if (query("/wlan/inf:1/enable")!=1)
		{
			echo "echo WLAN is disabled ! > /dev/console\n";
			exit;
		}
	/* common cmd */
	$IWPRIV="iwpriv ".$wlanif;
	$IWCONF="iwconfig ".$wlanif;
	/* insmod driver modules & common settings */
	$INSMOD="insmod /lib/modules/";
	echo $INSMOD."ath_hal.ko\n";
	echo $INSMOD."wlan.ko\n";
	echo $INSMOD."ath_rate_atheros.ko\n";
	echo $INSMOD."ath_dfs.ko\n";
	echo $INSMOD."ath_dev.ko\n";
	echo $INSMOD."ath_ahb.ko\n";
	echo $INSMOD."wlan_xauth.ko\n";
	echo $INSMOD."wlan_ccmp.ko\n";
	echo $INSMOD."wlan_tkip.ko\n";
	echo $INSMOD."wlan_wep.ko\n";
	echo $INSMOD."wlan_acl.ko\n";
	echo $INSMOD."ath_pktlog.ko\n";
	echo "ifconfig wifi0 hw ether ".$wlanmac."\n";
	if ($countrycode!=""){
		echo "iwpriv wifi0 setCountryID ".$countrycode."\n";
	}
	else{
		echo "iwpriv wifi0 setCountryID 840\n";
	}
	echo "wlanconfig ".$wlanif." create wlandev wifi0 wlanmode ap\n";
	echo "ifconfig ".$wlanif." hw ether ".$wlanmac."\n";
	
	anchor("/wlan/inf:1");
	$channel = query("channel");         if (query("autochannel")==1) { $channel=0; }
	$bintval = query("beaconinterval");
	$cwmmode = query("cwmmode");
	$shortgi = query("shortgi");
	$g_mode = query("wlmode");
	$ssid = query("ssid");
	$ssidhidden = query("ssidhidden");
	$dtim       = query("dtim");
	$wmmenable  = query("wmm/enable");
	$assoclimitenable   = query("assoc_limit/enable");
	$assoclimitnumber   = query("assoc_limit/number");
	$igmpsnoop = query("igmpsnoop");
	$wpartition = query("w_partition");
	$epartition = query("e_partition");
	$ethlink = query("ethlink");
	$fixedrate  = query("fixedrate");
	$mcastrate_a  = query("/wlan/inf:1/mcastrate_a");/*add for mcast rate by yuda*/
	$mcastrate_g  = query("/wlan/inf:1/mcastrate_g");/*add for mcast rate by yuda*/
	$autochannel = query("autochannel");
	$ampdu		= query("ampdu");
	$ampduframe	= query("ampdusframes");
	$ampdulimit	= query("ampdulimit");
	$aniena		= query("aniena");
	$acktimeout_a = query("acktimeout_a");
	$acktimeout_g	= query("acktimeout_g");
	$txpower    = query("txpower");
	$multi_pri_state = query("multi/pri_by_ssid");
	$wds_pri_bit = query("pri_bit");
	$wepmode = query("/wlan/inf:1/wpa/wepmode");	
	$zonedefence = query("zonedefence");


	
	echo $IWPRIV." bgscan 0\n";
	echo "iwpriv wifi0 HALDbg 0\n";
	echo $IWPRIV." dbgLVL 0x100\n";
	
	if ($band == $A_BAND)	
	{
	 	$wepmode = query("/wlan/inf:1/wpa/wepmode");
        //	if($wepmode==1 || $wepmode==2|| $channel==165){//1:WEP, 2:TKIP
	//		echo $IWPRIV." mode 11A\n";
	//	} else {
			if ($cwmmode == 0){
				if($a_mode == 7) {echo $IWPRIV." mode 11A\n";}
				else {echo $IWPRIV." mode 11NAHT20\n";}
			}
			else{
			     if($autochannel==1){//autochannel enable
				echo $IWPRIV." mode 11NAHT40\n";
                                //echo $IWPRIV." chextoffset 0\n";// use ic->extoffset to decide extension channel
                                //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
			     }
			     else{
		                if($channel==36||$channel==44||$channel==52||$channel==60||$channel==100||$channel==108||$channel==116||$channel==124||$channel==132||$channel==149||$channel==157){
                                   echo $IWPRIV." mode 11NAHT40PLUS\n";	
                                   //echo $IWPRIV." chextoffset 2\n";// use ic->extoffset to decide extension channel
                                   //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
				   echo $IWPRIV." extoffset 1\n";
                                 }     
                                else if($channel==40||$channel==48||$channel==56||$channel==64||$channel==104||$channel==112||$channel==120||$channel==128||$channel==136||$channel==153||$channel==161){
                                   echo $IWPRIV." mode 11NAHT40MINUS\n";
                                   //echo $IWPRIV." chextoffset 3\n";// use ic->extoffset to decide extension channel
                                   //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
				   echo $IWPRIV." extoffset -1\n";
                                }
                                else if($channel==140||$channel==165){ // channel 140, 165 does not support 40MHz channel width
			           $cwmmode = 0;
			           set("/wlan/inf:1/cwmmode",$cwmmode);
			           echo $IWPRIV." mode 11NAHT20\n";
		                }
                               else{
                                   echo $IWPRIV." mode 11NAHT20\n";
                               }
		       }
		}
	//	}	

	
    }
	else //gband
	{
//		if ($wepmode==1 || $wepmode==2){
//			echo $IWPRIV." mode 11G\n";
//		} else 
		if ($channel == 14)    {
    		     echo $IWPRIV." mode 11B\n";
		}else{
		  if ($cwmmode == 0){
            	      if($g_mode == 5) {echo $IWPRIV." mode 11NGHT20\n";}
            	      else if($g_mode == 4) {echo $IWPRIV." mode 11NGHT20\n";}
            	      else if($g_mode == 2) {echo $IWPRIV." mode 11G\n";}
            	      else {echo $IWPRIV." mode 11NGHT20\n";}
         	} else{//cwmmode=1 HT20/40 mode
            	    if($autochannel==1){//autochannel enable
	                echo $IWPRIV." mode 11NGHT40\n";
                        //echo $IWPRIV." chextoffset 0\n";// use ic->extoffset to decide extension channel
                        //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
	            }
	            else{ //autochannel disable
			if($channel<5){//channel 1~4
				echo $IWPRIV." mode 11NGHT40PLUS\n";
                        	//echo $IWPRIV." chextoffset 2\n";// use ic->extoffset to decide extension channel
	                        //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
				echo $IWPRIV." extoffset 1\n";
			}
                        else if($channel >= 5 && $channel <= 11){//channel 5~11
                              echo $IWPRIV." mode 11NGHT40MINUS\n";
                        	//echo $IWPRIV." chextoffset 3\n";// use ic->extoffset to decide extension channel
	                        //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
				echo $IWPRIV." extoffset -1\n";
                        }
                        else  //channel 12,13 for JP
                        {   
                	               $cwmmode = 0;
			                set("/wlan/inf:1/cwmmode",$cwmmode);
			                echo $IWPRIV." mode 11NGHT20\n";
		        } 
	            }
	        }

		}

    }

	if ($ssidhidden!="")    { echo $IWPRIV." hide_ssid ".$ssidhidden."\n"; }
	if ($dtim!="")          { echo $IWPRIV." dtim_period ".$dtim."\n"; }
	
	if ($wmmenable>0)       { echo $IWPRIV." wmm 1\n"; }
	else                    { echo $IWPRIV." wmm 0\n"; }
	if($assoclimitenable == 1)
		{echo $IWPRIV." assocenable 1\n";}
	else
		{echo $IWPRIV." assocenable 0\n";}
	if ($assoclimitnumber!="")          { echo $IWPRIV." assocnumber ".$assoclimitnumber."\n"; }
/* w_partition 2009-06-01 start */	
	if ($wpartition==2)  /* guest mode*/
	{ 
	    echo $IWPRIV." w_partition 1 \n"; 	      
        echo "brctl w_partition br0 ath0 1 \n"; 
	}
	else if ($wpartition==1)  
	{ 
	    echo $IWPRIV." w_partition 1 \n"; 	  
	    echo "brctl w_partition br0 ath0 0\n";
	}
	else            
	{ 
	    echo $IWPRIV." w_partition  0\n"; 
	    echo "brctl w_partition br0 ath0 0\n";
	}
	/* w_partition 2009-06-01 end */
	
	if ($epartition!="")  { echo "brctl e_partition br0 ".$epartition."\n";}
	else            { echo "brctl e_partition br0 0\n"; }

	echo "ifconfig ath0 txqueuelen 1000\n";
	echo "ifconfig wifi0 txqueuelen 1000\n";
	echo $IWPRIV." shortgi 1\n";
	if($g_mode > 3){ echo "iwpriv wifi0 ForBiasAuto 1\n";}
	//echo "iwpriv ath0 staextoffset 0\n";
	echo $IWPRIV." countryie 1\n";
	echo $IWPRIV." doth 0\n";
	
	echo $IWPRIV." cwmmode ".$cwmmode."\n";
        if ($ampdu!="")    {echo "iwpriv wifi0 AMPDU ".$ampdu."\n";}
        else {echo "iwpriv wifi0 AMPDU 1 \n";}
        if ($ampduframe!="")    {echo "iwpriv wifi0 AMPDUFrames ".$ampduframe."\n";	}
        else {echo "iwpriv wifi0 AMPDUFrames 32 \n";}
        if ($ampdulimit!="")    {echo "iwpriv wifi0 AMPDULim ".$ampdulimit."\n";	}
        else {echo "iwpriv wifi0 AMPDULim 50000 \n";}
        if ($aniena!="")    {echo "iwpriv wifi0 ANIEna ".$aniena."\n";	}
        else {echo " iwpriv wifi0 ANIEna 0 \n";}

	if ($band == $A_BAND)	
	{
		//8--->NA mix 9--> only n
		if($a_mode == 8){
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 0\n";
		}
		else if($a_mode == 9){
		echo "iwpriv ath0 puren 1\n";
		}		
		else{
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 0\n";
		}
        echo "iwpriv wifi0 acktimeout ".$acktimeout_a."\n";
        require($template_root."/__wlan_acl_a.php");
        echo "iwpriv ath0 apband 1 \n";
        }else
        {
	//1:11g only, 2.b/g mode 3:11b only, 4:only n  5:b/g/n mix, 6:g/n mix
		if($g_mode == 1){
		echo "iwpriv ath0 puren 0\n";
		echo "iwpriv ath0 pureg 1\n";
		}
		else if($g_mode == 2){
		echo "iwpriv ath0 puren 0\n";
		echo "iwpriv ath0 pureg 0\n";
		}		
		else if($g_mode == 4){
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 1\n";
		}
		else if($g_mode == 5){
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 0\n";
		}
		else if($g_mode == 6){
		echo "iwpriv ath0 pureg 1\n";
		echo "iwpriv ath0 puren 0\n";
		} 
		else{
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 0\n";
		}
	echo "iwpriv wifi0 acktimeout ".$acktimeout_g."\n";
	require($template_root."/__wlan_acl_g.php");
        echo "iwpriv ath0 apband 0 \n";

	}	
	//echo "iwpriv ath0 pureg 0\n";
	//echo "iwpriv ath0 puren 0\n";


	echo "iwconfig ath0 essid \"".get("s",$WLAN."/ssid")."\" mode master \n";
	echo "iwconfig ath0 freq ".$channel."\n";
	echo "iwpriv wifi0 txchainmask 5\n";
	echo "iwpriv wifi0 rxchainmask 5\n";

	echo "echo 1 > /proc/sys/dev/ath/htdupieenable\n";
	if($bintval!=""){
		echo $IWPRIV." bintval ".$bintval."\n";
	}
	else{
		echo $IWPRIV." bintval 100\n";
	}	

	echo $INSMOD."wlan_scan_ap.ko\n";

	if ($band == $A_BAND)
	{
		 /*0==6M;1==9M;2==12M;3==18M;4==24M;5==36M;6==48M;7==54M*/
		if  ($fixedrate<0)           {echo "iwpriv wifi0 fixedrate 0\n";}
		else if  ($fixedrate<8)      {echo "iwpriv wifi0 fixedrate ".$fixedrate."\n";}
		else                            {echo "iwpriv wifi0 fixedrate 31\n";}
	}
	else{
		/*0==1M;1==2M;2==5.5M;3==11M;4==6M;5==9M;6==12M;7==18M;8==24M;9==36M;10==48M;11==54M*/ 
		if  ($fixedrate<0)           {echo "iwpriv wifi0 fixedrate 0\n";}
		else if  ($fixedrate<12)      {echo "iwpriv wifi0 fixedrate ".$fixedrate."\n";}
		else                            {echo "iwpriv wifi0 fixedrate 31\n";}
	}
		/*add for mcast rate by yuda start*/
		if ($band == $A_BAND){
			if($mcastrate_a!=0){
			if($mcastrate_a==1){
				echo "iwpriv ath0 mcast_rate 6000\n";
				}
    			else if($mcastrate_a==2){
    				echo "iwpriv ath0 mcast_rate 9000\n";
    			}
    			else if($mcastrate_a==3){
    				echo "iwpriv ath0 mcast_rate 12000\n";
    			}
    			else if($mcastrate_a==4){
    				echo "iwpriv ath0 mcast_rate 18000\n";
    			}
    			else if($mcastrate_a==5){
    				echo "iwpriv ath0 mcast_rate 24000\n";
    			}
    			else if($mcastrate_a==6){
    				echo "iwpriv ath0 mcast_rate 36000\n";
    			}
    			else if($mcastrate_a==7){
    				echo "iwpriv ath0 mcast_rate 48000\n";
    			}
    			else if($mcastrate_a==8){
    				echo "iwpriv ath0 mcast_rate 54000\n";
    			}
    			else if($mcastrate_a==9){
    				echo "iwpriv ath0 mcast_rate 6500\n";
    			}
    			else if($mcastrate_a==10){
    				echo "iwpriv ath0 mcast_rate 13000\n";
    			}
    			else if($mcastrate_a==11){
    				echo "iwpriv ath0 mcast_rate 19500\n";
    			}
    			else if($mcastrate_a==12){
    				echo "iwpriv ath0 mcast_rate 26000\n";
    			}
    			else if($mcastrate_a==13){
    				echo "iwpriv ath0 mcast_rate 39000\n";
    			}
    			else if($mcastrate_a==14){
    				echo "iwpriv ath0 mcast_rate 52000\n";
    			}
    			else if($mcastrate_a==15){
    				echo "iwpriv ath0 mcast_rate 58500\n";
    			}
    			else if($mcastrate_a==16){
    				echo "iwpriv ath0 mcast_rate 65000\n";
    			}
    			else if($mcastrate_a==17){
    				echo "iwpriv ath0 mcast_rate 78000\n";
    			}
    			else if($mcastrate_a==18){
    				echo "iwpriv ath0 mcast_rate 104000\n";
    			}
    			else if($mcastrate_a==19){
    				echo "iwpriv ath0 mcast_rate 117000\n";
    			}
    			else if($mcastrate_a==20){
    				echo "iwpriv ath0 mcast_rate 130000\n";
    			}
    			else {
    				echo "iwpriv ath0 mcast_rate 6000\n";
    			}
    			}
    		}
    		if ($band == $G_BAND) {
    			if($mcastrate_g!=0){
    			if($mcastrate_g==1){
    				echo "iwpriv ath0 mcast_rate 1000\n";
    			}
    			else if($mcastrate_g==2){
    				echo "iwpriv ath0 mcast_rate 2000\n";
    			}
    			else if($mcastrate_g==3){
    				echo "iwpriv ath0 mcast_rate 5500\n";
    			}
    			else if($mcastrate_g==4){
    				echo "iwpriv ath0 mcast_rate 11000\n";
    			}
    			else if($mcastrate_g==5){
    				echo "iwpriv ath0 mcast_rate 6000\n";
    			}
    			else if($mcastrate_g==6){
    				echo "iwpriv ath0 mcast_rate 9000\n";
    			}
    			else if($mcastrate_g==7){
    				echo "iwpriv ath0 mcast_rate 12000\n";
    			}
    			else if($mcastrate_g==8){
    				echo "iwpriv ath0 mcast_rate 18000\n";
    			}
    			else if($mcastrate_g==9){
    				echo "iwpriv ath0 mcast_rate 24000\n";
    			}
    			else if($mcastrate_g==10){
    				echo "iwpriv ath0 mcast_rate 36000\n";
    			}
    			else if($mcastrate_g==11){
    				echo "iwpriv ath0 mcast_rate 48000\n";
    			}
    			else if($mcastrate_g==12){
    				echo "iwpriv ath0 mcast_rate 54000\n";
    			}
    			else if($mcastrate_g==13){
    				echo "iwpriv ath0 mcast_rate 6500\n";
    			}
    			else if($mcastrate_g==14){
		    		echo "iwpriv ath0 mcast_rate 13000\n";
		    	}
		    	else if($mcastrate_g==15){
		    		echo "iwpriv ath0 mcast_rate 19500\n";
    			}
    			else if($mcastrate_g==16){
    				echo "iwpriv ath0 mcast_rate 26000\n";
    			}
    			else if($mcastrate_g==17){
    				echo "iwpriv ath0 mcast_rate 39000\n";
    			}
    			else if($mcastrate_g==18){
    				echo "iwpriv ath0 mcast_rate 52000\n";
    			}
    			else if($mcastrate_g==19){
    				echo "iwpriv ath0 mcast_rate 58500\n";
    			}
    			else if($mcastrate_g==20){
    				echo "iwpriv ath0 mcast_rate 65000\n";
    			}
    			else if($mcastrate_g==21){
    				echo "iwpriv ath0 mcast_rate 78000\n";
    			}
    			else if($mcastrate_g==22){
    				echo "iwpriv ath0 mcast_rate 104000\n";
    			}
    			else if($mcastrate_g==23){
    				echo "iwpriv ath0 mcast_rate 117000\n";
    			}
    			else if($mcastrate_g==24){
    				echo "iwpriv ath0 mcast_rate 130000\n";
    			}
     			else {
    				echo "iwpriv ath0 mcast_rate 11000\n";
    			}   	   
    			}     
    		}
    			
		/*add for mcast rate by yuda end*/	
	/* authentication mode
	 *	0:open, 1:shared, 2:WPA, 3:WPA-PSK, 4:WPA2,
	 *	5:WPA2-PSK, 6:WPA+WPA2, 7:WPA-PSK + WPA2-PSK, 8:802.1x
	 */
	 if ($band == $A_BAND)
	 {
	          require($template_root."/__auth_openshared_a.php"); 
	  }else{
                require($template_root."/__auth_openshared_g.php"); 
          }
	if ($multi_pri_state == 1) 
	{ 
		echo "iwpriv ath0 pristate 1\n";
		echo "iwpriv ath0 pribit ".$wds_pri_bit."\n";
	}
        if ($zonedefence==1){
                echo $IWPRIV." zonedefence 1\n";
        //require($template_root."/zonedefence.php");
        }
        else{
                echo $IWPRIV." zonedefence 0\n";
        }
	
    	require($template_root."/multi_ssid_run.php");  /* Jack add 13/11/08 init_MSSID_before_WDS multi-ssid should be init before WDS_VAP */


	$lan_mac = query("/runtime/layout/lanmac");
        anchor($WLAN);
        $auth_mode	= query("authentication");
        $keylength	= query("keylength");
        $defkey	= query("defkey");
      if($defkey==1){
           $keyformat  = query("wepkey:1/keyformat");
	   }
	  else if($defkey==2){
	        $keyformat  = query("wepkey:2/keyformat");
	   }
	 else if($defkey==3){
	        $keyformat  = query("wepkey:3/keyformat");
	   }
	 else if($defkey==4){
	        $keyformat  = query("wepkey:4/keyformat");
	  }
	 else{
	        $keyformat  = query("wepkey:1/keyformat");
	  }
        $wepmode	= query("wpa/wepmode");
        $index=7;
        $index_mac=0;
        $up_ath_cnt=0;
        $W_PATH=$WLAN."/";
	$ssid = query($WLAN."/ssid");
	$wpapsk = query($WLAN."/wpa/wpapsk");
        for ($WLAN."/wds/list/index")
        {      
            $index++;     
            $index_mac++;   
            $path="/wirelss/";
            $wds_mac = query($WLAN."/wds/list/index:".$index_mac."/mac");  
            if ($wds_mac!="")  
            {                  	
		   $up_ath_cnt++;
		    echo "\necho Add WDS ath".$index."... > /dev/console\n";
                    echo "wlanconfig ath".$index." create wlandev wifi0 wlanmode ap\n";
                    echo "iwpriv ath".$index." bgscan 0"."\n";
                    /*iwconfig*/
                    echo "ifconfig ath".$index." txqueuelen 1000\n";
                    //echo "iwconfig ath".$index." channel ".$channel."\n";   
                                    
                    echo "echo 1 > /proc/sys/dev/ath/htdupieenable\n";                
                  //  echo "iwpriv ath".$index." apmode 0"."\n";
                    if ($shortgi!="")    
                    {echo "iwpriv ath".$index." shortgi ".$shortgi."\n";	}
                    if ($ampdmin!="")    {echo "iwpriv ath".$index." ampdumin ".$ampdmin."\n";	}
                    else {echo "iwpriv ath".$index." ampdumin 32768\n";	}
                   
                    
                    echo "iwpriv ath".$index." wds 1\n";
                    echo "iwpriv ath".$index." wdsprobereq 1"."\n";
	            echo "iwpriv ath".$index." wdsalpha 1"."\n";
	            echo "iwpriv ath".$index." wdsaddmac ".$wds_mac."\n";
	            if($withoutap == 1 ) { echo "iwpriv ath".$index." wdswithoutap 1"."\n";}
	            else                 { echo "iwpriv ath".$index." wdswithoutap 0"."\n"; }	
                    if ($multi_pri_state == 1) { echo "iwpriv ath".$index." pribit ".$wds_pri_bit."\n";}                 
                    /*iwpriv*/
	    if ($band == $A_BAND)	
	    {
	 	$wepmode = query("/wlan/inf:1/wpa/wepmode");
//        	if($wepmode==1 || $wepmode==2|| $channel==165){//1:WEP, 2:TKIP
//	            echo "iwpriv ath".$index." mode 11A\n";
//		} else
//		{
			if ($cwmmode == 0){
				if($a_mode == 7) {echo "iwpriv ath".$index." mode 11A\n";}
				else {echo "iwpriv ath".$index." mode 11NAHT20\n";}
			}
			else{
			     if($autochannel==1){//autochannel enable
					echo "iwpriv ath".$index." mode 11NAHT40\n";
                                //echo "iwpriv ath".$index." chextoffset 0\n";// use ic->extoffset to decide extension channel
                                //echo "iwpriv ath".$index." chwidth 2\n";// override with 40MHz channel width
			     }
			     else{
		                if($channel==36||$channel==44||$channel==52||$channel==60||$channel==100||$channel==108||$channel==116||$channel==124||$channel==132||$channel==149||$channel==157){
                                   echo "iwpriv ath".$index." mode 11NAHT40PLUS\n";
                                //echo "iwpriv ath".$index." chextoffset 2\n";// use ic->extoffset to decide extension channel
                                //echo "iwpriv ath".$index." chwidth 2\n";// override with 40MHz channel width
				echo $IWPRIV." extoffset 1\n";
                                 }     
                                else if($channel==40||$channel==48||$channel==56||$channel==64||$channel==104||$channel==112||$channel==120||$channel==128||$channel==136||$channel==153||$channel==161){
                                   echo "iwpriv ath".$index." mode 11NAHT40MINUS\n";
                                //echo "iwpriv ath".$index." chextoffset 3\n";// use ic->extoffset to decide extension channel
                                //echo "iwpriv ath".$index." chwidth 2\n";// override with 40MHz channel width
				echo $IWPRIV." extoffset -1\n";
                                }
                                else if($channel==140||$channel==165){ // channel 140, 165 does not support 40MHz channel width
			           $cwmmode = 0;
			           set("/wlan/inf:1/cwmmode",$cwmmode);
			           echo "iwpriv ath".$index." mode 11NAHT20\n";
		                }
                               else{
                                   echo "iwpriv ath".$index." mode 11NAHT20\n";
                               }
		       }
//		}
	}	
	if($a_mode == 8){
        	echo "iwpriv ath".$index." pureg 0\n";
        	echo "iwpriv ath".$index." puren 0\n";
         }
     	else if($a_mode == 9){
        	echo "iwpriv ath".$index." puren 1\n";
         }
    	else{
        	echo "iwpriv ath".$index." pureg 0\n";
        	echo "iwpriv ath".$index." puren 0\n";
         }
    	echo "iwpriv ath".$index." apband 1\n"; //show ap band in wireless driver
    }
	else //gband
	{
//		if ($wepmode==1 || $wepmode==2){
//			echo "iwpriv ath".$index." mode 11G\n";
//		} else 
		if ($channel == 14)    {
    		     echo "iwpriv ath".$index." mode 11B\n";
		}else{
		  if ($cwmmode == 0){
            	      if($g_mode == 5) {echo "iwpriv ath".$index." mode 11NGHT20\n";}
            	      else if($g_mode == 4) {echo "iwpriv ath".$index." mode 11NGHT20\n";}
            	      else if($g_mode == 2) {echo "iwpriv ath".$index." mode 11G\n";}
            	      else {echo "iwpriv ath".$index." mode 11NGHT20\n";}
         	} else{//cwmmode=1 HT20/40 mode
            	    if($autochannel==1){//autochannel enable
	                echo "iwpriv ath".$index." mode 11NGHT40\n";
                        //echo "iwpriv ath".$index." chextoffset 0\n";// use ic->extoffset to decide extension channel
                        //echo "iwpriv ath".$index." chwidth 2\n";// override with 40MHz channel width
	            }
	            else{ //autochannel disable
			if($channel<5){//channel 1~4
				echo "iwpriv ath".$index." mode 11NGHT40PLUS\n";
                        	//echo "iwpriv ath".$index." chextoffset 2\n";// use ic->extoffset to decide extension channel
	                        //echo "iwpriv ath".$index." chwidth 2\n";// override with 40MHz channel width
				echo $IWPRIV." extoffset 1\n";
			}
                        else if($channel >= 5 && $channel <= 11){//channel 5~11
                              echo "iwpriv ath".$index." mode 11NGHT40MINUS\n";
                        	//echo "iwpriv ath".$index." chextoffset 3\n";// use ic->extoffset to decide extension channel
	                        //echo "iwpriv ath".$index." chwidth 2\n";// override with 40MHz channel width
				echo $IWPRIV." extoffset -1\n";
                        }
                        else  //channel 12,13 for JP
                        {   
                	               $cwmmode = 0;
			                set("/wlan/inf:1/cwmmode",$cwmmode);
			                echo "iwpriv ath".$index." mode 11NGHT20\n";
		        } 
	            }
	        }

		}
 		 //1:11g only, 2.b/g mode 3:11b only, 4:only n  5:b/g/n mix, 6:g/n mix
                if($g_mode == 1)
                {
                        echo "iwpriv ath".$index." puren 0\n";
                        echo "iwpriv ath".$index." pureg 1\n";
                }
                else if($g_mode == 2)
                {
                        echo "iwpriv ath".$index." puren 0\n";
                        echo "iwpriv ath".$index." pureg 0\n";
                }
                else if($g_mode == 4){
                        echo "iwpriv ath".$index." pureg 0\n";
                        echo "iwpriv ath".$index." puren 1\n";
                        }
                else if($g_mode == 5)
                {
                        echo "iwpriv ath".$index." pureg 0\n";
                        echo "iwpriv ath".$index." puren 0\n";
                }
                else if($g_mode == 6)
                {
                        echo "iwpriv ath".$index." pureg 1\n";
                        echo "iwpriv ath".$index." puren 0\n";
                }
                else
                {
                        echo "iwpriv ath".$index." pureg 0\n";
                        echo "iwpriv ath".$index." puren 0\n";
                }

	    	echo "iwpriv ath".$index." apband 0\n"; //show ap band in wireless driver  
    	}	 
                echo "iwpriv ath".$index." countryie 1\n"; 	
                echo "iwpriv ath".$index." doth 0\n"; 
                echo "iwpriv ath".$index." extprotspac 0\n";
     
               if ($cwmmode!="")    {echo "iwpriv ath".$index." cwmmode ".$cwmmode."\n";}
	         
	            if ($dtim!="")          {echo "iwpriv ath".$index." dtim_period ".$dtim."\n"; }   // for each VAP. (WDS - ath0) jack.
	            /* w_partition 2008-03-22 start */
	            if ($wpartition!="")    {echo "iwpriv ath".$index." w_partition ".$wpartition."\n"; }   // for Mssid1, WDS-ath0 jack.
	            else                    {echo "iwpriv ath".$index." w_partition  0\n"; }  
	            /* w_partition 2008-03-22 end */            
	            echo "iwpriv ath".$index." bintval ".$bintval."\n";
	            /*  add txpower will cause : Mode:Master  Frequency:2.462 GHz  Access Point: Not-Associated  Jack add 06/05/08 
	            echo "iwlist ath".$index." txpower\n";     // for all MSSID, WDS-ath0, jack. need to check value �Q����
	            echo "sh /etc/templates/txpower.sh\n";  // for all MSSID, WDS, jack.    command: iwpriv ath0 txpower 12.    iwconfig ath0.
                                */
	            if ($wmmenable>0)       { echo "iwpriv ath".$index." wmm 1"."\n"; }
	            else                    { echo "iwpriv ath".$index." wmm 0\n"; }
    
                    if ($auth_mode==1 || $auth_mode==0 )  /*shared key or open*/  
                    {                    
                        echo "iwpriv ath".$index." authmode 1\n";
    	                if ($wepmode==1)
    	                {            
                               /*
    	 		    *	For ASCII string:
    	                    *		iwconfig ath0 key s:"ascii" [1]
    	                    *	For Hex string:
    	                    *		iwconfig ath0 key "1234567890" [1]
    	                    */
    	                    echo "iwpriv ath".$index." ampdu 0\n";
    	                    if ($keyformat==1)	{ $iw_keystring="s:\"".get("s",$W_PATH."wepkey:".$defkey)."\" [".$defkey."]";}
    	                    else				{ $iw_keystring="\"".query($W_PATH."wepkey:".$defkey)."\" [".$defkey."]"; }
    	                    echo "iwconfig ath".$index." key ".$iw_keystring."\n";
    	                    if ($auth_mode==1)	{ echo "iwpriv ath".$index." authmode 2; "."iwconfig ath".$index." key ".$iw_keystring."\n"; }
    		        	}
    		        	echo "iwconfig ath".$index." essid \"".get("s",$W_PATH."ssid")."\" mode master \n";
    		        	echo "iwconfig ath".$index." freq ".$channel."\n";
	//					echo "ifconfig ath".$index." up\n";
						 /* IGMP Snooping dennis 2008-01-29 start*/
					//	 if($withoutap == 0 ){//wds with ap mode
					//	 	if ($igmpsnoop == "1"){
					//			echo "echo enable > /proc/net/br_igmp_ap_br0\n";
					//		 	echo "echo setwl ath".$index." > /proc/net/br_igmp_ap_br0\n";
					//			echo "ap_igmp &> /dev/console\n";
					//			echo "echo $! > /var/run/ap_igmp_".$index.".pid\n";
					//			}
					//		if ($igmpsnoop!=""){ echo "brctl igmp_snooping br0 ".$igmpsnoop."\n"; }
					//		else {  echo "brctl igmp_snooping br0 0\n";  }
					//	 }
						 /* IGMP Snooping dennis 2008-01-29 end */

                    }else if ($auth_mode==3 || /*wpa-psk*/ 
                              $auth_mode==5 || /*wpa2-psk*/  
                              $auth_mode==7 || /*wpa-auto-psk*/     
                              $auth_mode==2 || /*wpa-eap*/ 
                              $auth_mode==4 || /*wpa2-eap*/  
                              $auth_mode==6) /*wpa-auto-eap*/           
                    {            	
			$hostapd_conf	= "/var/run/hostapd".$index.".conf_wds";
			$hostapd_pid	= "/var/run/hostapd".$index.".pid_wds";
			fwrite($hostapd_conf,
				"interface=ath".$index."\n".
				"bridge=br0\n".
				"driver=madwifi\n".
				"logger_syslog=0\n".
				"logger_syslog_level=0\n".
				"logger_stdout=0\n".
				"logger_stdout_level=0\n".
				"debug=0\n".
				"eapol_key_index_workaround=0\n".
				"wds_enable=1\n".
				"wds_mac=".$wds_mac."\n".
				"ssid=".$ssid."\n".
				"wpa=2\n".
				"wpa_group_rekey=0\n".
				"wpa_key_mgmt=WPA-PSK\n".
				"wpa_passphrase=".$wpapsk."\n".
				"wpa_pairwise=CCMP\n");
				
			$wpa_supplicant_conf = "/var/run/wpa_supplicant".$index.".conf_wds";
			$wpa_supplicant_pid = "/var/run/wpa_supplicant".$index.".pid_wds";
			fwrite($wpa_supplicant_conf,
				"ap_scan=2\n".
				"wds_enable=1\n".
				"wds_mac=".$wds_mac."\n".
				"network={\n".
				"ssid=\"".$ssid."\"\n".
				"scan_ssid=1\n".
				"key_mgmt=WPA-PSK\n".
				"psk=\"".$wpapsk."\"\n".
				"proto=RSN\n".
				"pairwise=CCMP\ngroup=CCMP\n".
				"}\n");
			 echo "iwconfig ath".$index." essid \"".get("s",$W_PATH."ssid")."\" mode master \n";
       echo "iwconfig ath".$index." freq ".$channel."\n";
               	    } // end of wpa-psk and eap           
               
                       
             }     // end of if ($wds_mac!="") 
        }// end of for
        if($up_ath_cnt > 0)
        {
            echo "brctl stp br0 1 \n";    
        }
        
        //INCLUDE_WDSMODE_INFO_start
        if($index_mac !=0)
        {
            set("/runtime".$WLAN."/wds/devicenum", $index_mac);
            set("/runtime".$WLAN."/wds/wdsinfostatus", 1);  
        } 

} // end of ($generate_start==1)
else
{    
	$igmpsnoop = query("/wlan/inf:1/igmpsnoop");
	echo "echo Stop WLAN WDS interface ".$wlanif." ... > /dev/console\n";
	
	$index=7; 
	$index_mac=0;	
    echo "brctl stp br0 0 \n";

	for ($WLAN."/wds/list/index")
	{      
        	$index++; 
        	$index_mac++;
        	$wds_mac = query($WLAN."/wds/list/index:".$index_mac."/mac");  
        	if ($wds_mac!="")  
        	{    
	            echo "\necho kill WDS ath".$index."... > /dev/console\n"; 
	            
	            /* Stop wlxmlpatch_pid */	            
/* Jack add 13/02/08 +++ wlxmlpatch_v2*/
                $index_tmp = $index-7;
		        $wlxmlpatch_pid	= "/var/run/wlxmlpatch".$index_tmp.".pid_wds";
                echo "if [ -f ".$wlxmlpatch_pid." ]; then\n";
                echo "kill \`cat ".$wlxmlpatch_pid."\` > /dev/null 2>&1\n";
                echo "rm -f ".$wlxmlpatch_pid."\n";
                echo "fi\n\n";
/* Jack add 13/02/08 --- wlxmlpatch_v2*/
        	   /* IGMP Snooping dennis 2008-01-29 start */
			    if($withoutap == 0 ){//wds with ap mode
					if($igmpsnoop == 1 ){
				echo "echo disable > /proc/net/br_igmp_ap_br0\n";
				echo "brctl igmp_snooping br0 0\n";
				echo "echo unsetwl ath".$index." > /proc/net/br_igmp_ap_br0\n";
			   }
			   }
			   /* IGMP Snooping dennis 2008-01-29 end */
	            echo "ifconfig ath".$index." down"."\n";  
		        echo "sleep 2\n";  
		    	/* destroy and remove wireless */
		    	echo "brctl delif br0 ath".$index."\n";
		      /*  echo "iwpriv ath".$index." wdsalpha 0"."\n";*/
	
				/* Stop hostapd */
	          	/*$hostapd_pid = "/var/run/hostapd".$index.".pid_wds";*/
	          	$hostapd_conf	= "/var/run/hostapd".$index.".conf_wds";
				echo "rm -f ".$hostapd_conf."\n";
				echo "kill -9 `ps | grep ".$hostapd_conf." | grep -v grep | cut -b 1-5`\n";
				/*echo "rm -f ".$hostapd_conf."\n";
	           	echo "if [ -f ".$hostapd_pid." ]; then\n";
		    	echo "kill -9 \`cat ".$hostapd_pid."\` > /dev/null 2>&1\n";
		    	echo "rm -f ".$hostapd_pid."\n";
		    	echo "fi\n\n";*/
	
	        	/* Stop wpa_supplicant */
	          	/*$wpa_supplicant_pid = "/var/run/wpa_supplicant".$index.".pid_wds";*/
	          	$wpa_supplicant_conf = "/var/run/wpa_supplicant".$index.".conf_wds";
				echo "rm -f ".$wpa_supplicant_conf."\n";
				echo "kill -9 `ps | grep wpa_supplicant | grep ath".$index." | grep -v grep | cut -b 1-5`\n";
	           	/*echo "if [ -f ".$wpa_supplicant_pid." ]; then\n";
		    	echo "kill -9 \`cat ".$wpa_supplicant_pid."\` > /dev/null 2>&1\n";
		    	echo "rm -f ".$wpa_supplicant_pid."\n";
		    	echo "fi\n\n";	*/

				/* IGMP Snooping dennis 2008-01-29 start */
				if($withoutap == 0 ){//wds with ap mode
					if($igmpsnoop == 1 ){
					echo "if [ -f /var/run/ap_igmp_".$index.".pid ]; then\n";
					echo "kill \`cat /var/run/ap_igmp_".$index.".pid\` > /dev/null 2>&1\n";
					echo "rm -f /var/run/ap_igmp_".$index.".pid\n";
					echo "fi\n\n";
				}
				}

		    	echo "iwconfig ath".$index." key off"."\n"; // must add key off
		        echo "sleep 1\n";  
		    	echo "wlanconfig ath".$index." destroy"."\n";  
	    	}  // end of ($wds_mac!="")
	}  // end of for

	            /* Stop wlxmlpatch_primary_pid */
/* Jack modify 13/02/08 +++ wlxmlpatch_v2*/
        echo "if [ -f ".$wlxmlpatch_primary_pid." ]; then\n";
        echo "kill \`cat ".$wlxmlpatch_primary_pid."\` > /dev/null 2>&1\n";
        echo "rm -f ".$wlxmlpatch_primary_pid."\n";
        echo "fi\n\n";
/* Jack modify 13/02/08 --- wlxmlpatch_v2*/

        set("/runtime".$WLAN."/wds/wdsinfostatus", 0); //INCLUDE_WDSMODE_INFO


	if (query("/wlan/inf:1/enable")!=1)
	{
		echo "echo WLAN is disabled ! > /dev/console\n";
		exit;
	}
	
	// jack, \\1.54.45.230\project\andy\2590-4448\boards\wapnd02\apps\wireless\__wlan_wdsmode.php  
	// jack, modify sh, then load r004, and then r005 by WEB, than test , crash or not.......
	echo "brctl e_partition br0 0\n";
	/* IGMP Snooping dennis 2008-01-29 start */
	if($withoutap == 0 ){//wds with ap mode
	echo "echo disable > /proc/net/br_igmp_ap_br0\n";
	echo "echo unsetwl ath0 > /proc/net/br_igmp_ap_br0\n";
	echo "brctl igmp_snooping br0 0\n";
	}
	/* IGMP Snooping dennis 2008-01-29 end */
	echo "brctl apmode br0 0"."\n";

	echo "ifconfig ".$wlanif." down\n";
	echo "sleep 2\n";
	echo "brctl delif br0 ".$wlanif."\n";
	echo "sleep 1\n";
	/* Stop hostapd */
	$HAPD_conf	= "/var/run/hostapd.".$wlanif.".conf";
	echo "rm -f ".$HAPD_conf."\n";
	echo "kill -9 `ps | grep ".$HAPD_conf." | grep -v grep | cut -b 1-5`\n";
	/*$HAPD_pid  = "/var/run/hostapd.".$wlanif.".pid";
	echo "if [ -f ".$HAPD_pid." ]; then\n";
	echo "kill -9 \`cat ".$HAPD_pid."\` > /dev/null 2>&1\n";
	echo "rm -f ".$HAPD_pid."\n";
	echo "rm -f ".$HAPD_conf."\n";
	echo "fi\n\n";*/
	 /* IGMP Snooping dennis 2008-01-29 start */
	 if($withoutap == 0 ){//wds with ap mode
	 echo "if [ -f ".$ap_igmp_pid." ]; then\n";
	 echo "kill \`cat ".$ap_igmp_pid."\` > /dev/null 2>&1\n";
	 echo "rm -f ".$ap_igmp_pid."\n";
	 echo "fi\n\n";
	 }
	/* IGMP Snooping dennis 2008-01-29 end */
	echo "iwconfig ".$wlanif." key off\n";
	echo "wlanconfig ".$wlanif." destroy\n";
	echo "sleep 1\n";
	if($wlan_ap_operate_mode==1)    { echo "rmmod wlan_scan_sta"." > /dev/null 2>&1\n";  }
	else { echo "rmmod wlan_scan_ap"." > /dev/null 2>&1\n"; }
	echo "rmmod ath_pktlog"." > /dev/null 2>&1\n";
	echo "sleep 2\n";
	echo "rmmod wlan_acl"." > /dev/null 2>&1\n";
	echo "rmmod wlan_wep"." > /dev/null 2>&1\n";
	echo "rmmod wlan_tkip"." > /dev/null 2>&1\n";
	echo "rmmod wlan_ccmp"." > /dev/null 2>&1\n";
	echo "rmmod wlan_xauth"." > /dev/null 2>&1\n";
	echo "sleep 2\n";
	echo "rmmod ath_ahb"." > /dev/null 2>&1\n";
	echo "sleep 2\n";
	echo "rmmod ath_dev"." > /dev/null 2>&1\n";
	echo "rmmod ath_dfs"." > /dev/null 2>&1\n";
	echo "rmmod ath_rate_atheros"." > /dev/null 2>&1\n";
	echo "rmmod wlan"." > /dev/null 2>&1\n";
	echo "rmmod ath_hal"." > /dev/null 2>&1\n";
	
	if ($band == $A_BAND)	
	{
		echo "gpioc -o 19 \n";
		echo "gpioc -d 19 \n";
		echo "gpioc -c 19 \n";
                echo "rgdb -i -s /runtime/stats/wireless/led11a 0\n";
         	
        }         
	else
	{ 
		echo "gpioc -o 19 \n";
	        echo "gpioc -d 19 \n";
	        echo "gpioc -c 19 \n";
	        echo "rgdb -i -s /runtime/stats/wireless/led11g 0\n";
	}
	
	
}  // end of else ($generate_start!=1)

?>
