#!/bin/sh
echo [$0] ... > /dev/console
<?
/* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");
$generate_start=1;
$webredirect_mode = 0;
$webredirect_mode = query("/wlan/inf:1/webredirect/enable");
$wan_lan_sta_ip=query("/runtime/webredirect/wan_lan_sta_ip");

//echo "echo Web Redirect is running... > /dev/console\n";
set("/runtime/webredirect/client_add","0");	
set("/runtime/webredirect/client_del","0");

if($webredirect_mode==1) 
{	
	echo "webredirect &> /dev/console\n";
	echo "echo $! > /var/run/webredirect.pid\n";
		
	echo "brctl webredirect br0 1 \n";
	echo "brctl setapip br0 ".$wan_lan_sta_ip."\n";
	
	$ct_num = 0;
	$ms_num = 0;
	$all_num = 0;
	
	for("/wlan/inf:1/multi/index")
	{
		if(query("state") !="0")
		{
			for("/runtime/stats/wlan/inf:1/mssid:".$@."/client")
			{
				$ms_num = $ms_num+1;
			}
		}		
	}

	for("/runtime/stats/wlan/inf:1/client")
	{
		$ct_num = $ct_num+1;
	}	

	$all_num = $ms_num + $ct_num;
	//echo "echo ".$all_num." ".$ms_num." ".$ct_num."... > /dev/console\n";	
	echo "brctl webredirect_ctnum br0 ".$all_num." ".$ms_num." ".$ct_num."\n";

	if($ms_num != 0)
	{
		for("/wlan/inf:1/multi/index")
		{
			$ms_index = $@;
			$ms_state = query("state");
			set("/runtime/webredirect/ms:".$ms_index."/state",$ms_state);
			if($ms_state !="0")
			{
				for("/runtime/stats/wlan/inf:1/mssid:".$ms_index."/client")
				{
					$mc_index = $@;
					$mc_mac  = query("/runtime/stats/wlan/inf:1/mssid:".$ms_index."/client:".$mc_index."/mac");
					$wr_flag = query("/runtime/stats/wlan/inf:1/mssid:".$ms_index."/client:".$mc_index."/wr_flag");	
					//echo "echo 1-1  ".$mc_index." -- ".$mc_mac." -- ".$wr_flag." ... > /dev/console\n";	

					for("/runtime/webredirect/ms:".$ms_index."/client")
					{
						$wrm_idx = $@;
						$wrm_mac  = query("/runtime/webredirect/ms:".$ms_index."/client:".$wrm_idx."/mac");
						$wrm_flag  = query("/runtime/webredirect/ms:".$ms_index."/client:".$wrm_idx."/wr_flag");
						//echo "echo 1-2  ".$mc_index." -- ".$wrm_idx." -- ".$wrm_mac." -- ".$wrm_flag."... > /dev/console\n";	

						//if($wrm_flag != "" )
						//{
							if($mc_mac  == $wrm_mac)
							{
								//echo "echo 1-2-1  mc_mac= ".$mc_mac." wrc_mac=".$wrm_mac."... > /dev/console\n";	
								set("/runtime/stats/wlan/inf:1/mssid:".$ms_index."/client:".$mc_index."/wr_flag",$wrm_flag);
							}									
						//}
					}
					$wr_flag = query("/runtime/stats/wlan/inf:1/mssid:".$ms_index."/client:".$mc_index."/wr_flag");	

					if($mc_mac != "")
					{
						if($wr_flag == "")
						{
							$wr_flag = 0;	
						}
						//echo "echo Web Redirect is running ".$mc_index." ".$mc_mac." ".$wr_flag." ".$ms_index."... > /dev/console\n";
						echo "brctl webredirect_ct br0 ".$mc_index." ".$mc_mac." ".$wr_flag." ".$ms_index."\n";
					}				
					
				}
			}		
		}
		
		for("/runtime/webredirect/ms")
		{
			del("/runtime/webredirect/ms:".$@);
		}
		
		for("/wlan/inf:1/multi/index")
		{
			$index = $@;
			if(query("state") !="0")
			{
				for("/runtime/stats/wlan/inf:1/mssid:".$index."/client")
				{
					$mac  = query("/runtime/stats/wlan/inf:1/mssid:".$index."/client:".$@."/mac");
					$flag = query("/runtime/stats/wlan/inf:1/mssid:".$index."/client:".$@."/wr_flag");
					//echo "echo 1-3  ".$index." -- ".$@." -- ".$mac." -- ".$flag.".. > /dev/console\n";	

					set("/runtime/webredirect/ms:".$index."/client:".$@."/mac",$mac);
					set("/runtime/webredirect/ms:".$index."/client:".$@."/wr_flag",$flag);
				}
			}
		}	
	}	
	else
	{
		for("/runtime/webredirect/ms")
		{
			del("/runtime/webredirect/ms:".$@);
		}		
	}
	
	if($ct_num != 0)
	{		
		for("/runtime/stats/wlan/inf:1/client")
		{
			$client_idx = $@;
			$client_mac  = query("/runtime/stats/wlan/inf:1/client:".$client_idx."/mac");
			$wr_flag = query("/runtime/stats/wlan/inf:1/client:".$client_idx."/wr_flag");
			//echo "echo 2-1 ".$client_idx." -- ".$client_mac." -- ".$wr_flag."... > /dev/console\n";	
			for("/runtime/webredirect/client")
			{
				$wrc_idx = $@;
				$wrc_mac  = query("/runtime/webredirect/client:".$wrc_idx."/mac");
				$wrc_flag  = query("/runtime/webredirect/client:".$wrc_idx."/wr_flag");
				//echo "echo 2-2 ".$wrc_idx." -- ".$wrc_mac." -- ".$wrc_flag."... > /dev/console\n";	

				//if($wrc_flag != "")
				//{
					if($client_mac  == $wrc_mac)
					{
						//echo "echo 2-2-1  client_mac= ".$client_mac." wrc_mac=".$wrc_mac."... > /dev/console\n";	
						set("/runtime/stats/wlan/inf:1/client:".$client_idx."/wr_flag",$wrc_flag);
					}
				//}
			}
			
			$cc_index = $client_idx + $ms_num;
			$wr_flag = query("/runtime/stats/wlan/inf:1/client:".$client_idx."/wr_flag");

			if($client_mac != "")
			{
				if($wr_flag == "")
				{
					$wr_flag = 0;	
				}
				//echo "echo Web Redirect is running ".$cc_index." ".$client_mac." ".$wr_flag."... > /dev/console\n";
				echo "brctl webredirect_ct br0 ".$cc_index." ".$client_mac." ".$wr_flag." 0\n";
			}
		}
		
		for("/runtime/webredirect/client")
		{
			del("/runtime/webredirect/client:".$@);
		}

		for("/runtime/stats/wlan/inf:1/client")
		{
			$mac  = query("/runtime/stats/wlan/inf:1/client:".$@."/mac");
			$flag = query("/runtime/stats/wlan/inf:1/client:".$@."/wr_flag");
			//echo "echo 2-3 ".$@." ".$mac." ".$flag."... > /dev/console\n";	
			
			set("/runtime/webredirect/client:".$@."/mac",$mac);
			set("/runtime/webredirect/client:".$@."/wr_flag",$flag);
		}	
	}
	else
	{
		for("/runtime/webredirect/client")
		{
			del("/runtime/webredirect/client:".$@);
		}		
	}

}
else
{
	echo "brctl webredirect br0 0 \n";
}

?>
