#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */
/* Jack add for stop/start multi_ssid 09/03/07 */

$WLAN_g = "/wlan/inf:1";  // b, g, n band
//$WLAN_a = "/wlan/inf:2";  // a band
$WLAN_a = $WLAN_g;  // a, g band use the same config.
$band	= query("/wlan/ch_mode");  // "1" #1--->a   0---> b,g,n
$A_BAND = 1;  // 1--->a   
$G_BAND = 0;  // 0---> b,g,n
$WLAN = $WLAN_g; 
$a_mode = 0;
$g_mode = 0; 

if ($band == $A_BAND)	// 11A band
{ 	    
	$WLAN = $WLAN_a;
	$a_mode = query($WLAN."/wlmode");
}
else            // 11b,g,n band
{ 
	$WLAN = $WLAN_g;      
    $g_mode = query($WLAN."/wlmode"); 
}
$igmpsnoop = query("/wlan/inf:1/igmpsnoop");
$multi_ssid_path = $WLAN."/multi";
$cwmmode = query($WLAN."/cwmmode");
$channel = query($WLAN."/channel"); 
$bintval = query($WLAN."/beaconinterval");
$autochannel = query($WLAN."/autochannel");     

if ($autochannel==1) { $channel=0; }
$multi_total_state = query($multi_ssid_path."/state");  

if ($generate_start==1)
{
	if ($multi_total_state == 1)
	{
	    if (query($WLAN."/enable")!=1)
	    {
		    echo "echo WLAN is disabled ! > /dev/console\n";
		    exit;
	    }     
	    $multicast_limit = query($WLAN."/multicast_bwctrl");/* dennis 2006-06-25 multicast bwctrl */
	    $multi_ssid_amount=0;    /* Jack add 17/04/07 MULTI_SSID_CLIENT_INFO */
	    
	    $index=0; 
/* dennis 2006-06-25 multicast bwctrl start */
    $index1=0;
    $ssid_counter=1; //1-->ath0
    for ($multi_ssid_path."/index")
    {
    	$index1++;
    	$multi_ind_state1 = query($multi_ssid_path."/index:".$index1."/state");
	    /*add schedule for multi-ssid by yuda start*/
	    $schedule_enable=query("/schedule/enable");
	    if ($schedule_enable==1)
	    {
	    	if(query($multi_ssid_path."/index:".$index."/schedule_rule_state")==1)
	    	{
	    		$multi_ind_schedule_state = query($multi_ssid_path."/index:".$index."/schedule_state");
	    	}
	    	else
	    	{
	    		$multi_ind_schedule_state = 1;
	    	}
	    }
	    else
	    {
	    	$multi_ind_schedule_state = 1;
	    }
	    /*add schedule for multi-ssid by yuda end*/	      

    	if ($multi_ind_state1==1 && $multi_ind_schedule_state == 1)  //add $multi_ind_schedule_state for schedule for multi-ssid by yuda 
    	{
    		$ssid_counter++;
    	}
    }
    
    $denominator = $multicast_limit/$ssid_counter;
     /* dennis 2006-06-25 multicast bwctrl end */      
	for ($multi_ssid_path."/index")
	{      
	    $index++;     
	    $IWPRIV="iwpriv ath".$index;
	    $multi_ind_state = query($multi_ssid_path."/index:".$index."/state");  
	    /*add schedule for multi-ssid by yuda start*/
	    $schedule_enable=query("/schedule/enable");
	    if ($schedule_enable==1)
	    {
	    	if(query($multi_ssid_path."/index:".$index."/schedule_rule_state")==1)
	    	{
	    		$multi_ind_schedule_state = query($multi_ssid_path."/index:".$index."/schedule_state");
	    	}
	    	else
	    	{
	    		$multi_ind_schedule_state = 1;
	    	}
	    }
	    else
	    {
	    	$multi_ind_schedule_state = 1;
	    }
	    /*add schedule for multi-ssid by yuda end*/	      
	        set("/runtime".$WLAN."/multi_ssid/index:".$index."/state", 0);  /* Jack add 17/04/07 MULTI_SSID_CLIENT_INFO */
	    if ($multi_ind_state==1 && $multi_ind_schedule_state == 1)  //add $multi_ind_schedule_state for schedule for multi-ssid by yuda 
	    { 
		    if($iapp_state == 1){ /* Added by Enos , IAPP_20070620 */
	           $iapp_interface = $iapp_interface." ath".$index;
	        }        
	        $multi_ssid = query($multi_ssid_path."/index:".$index."/ssid");//query($multi_ssid_path."/index:".$index."/ssid");
	        $multi_ssid_hidden = query($multi_ssid_path."/index:".$index."/ssid_hidden");
	        $multi_wmm = query($multi_ssid_path."/index:".$index."/wmm/enable");  
	            $multi_wpartition = query($multi_ssid_path."/index:".$index."/w_partition");
	            
			$fixedrate  = query($WLAN."/fixedrate");
			$mcastrate_a  = query("/wlan/inf:1/mcastrate_a");/*add for mcast rate by yuda*/
			$mcastrate_g  = query("/wlan/inf:1/mcastrate_g");/*add for mcast rate by yuda*/
			$assoclimitenable   = query($WLAN."/assoc_limit/enable");
			$assoclimitnumber   = query($WLAN."/assoc_limit/number");
			$shortgi   = query($WLAN."/shortgi");
			$wpartition = query($WLAN."/w_partition");
			$ampdu      = query($WLAN."/ampdu");
			$ampduframe = query($WLAN."/ampdusframes");
			$ampdulimit = query($WLAN."/ampdulimit");
			$ampdmin    = query($WLAN."/ampdmin");
			$aniena     = query($WLAN."/aniena");
			$dtim       = query($WLAN."/dtim");	
			$multi_cipher = query($multi_ssid_path."/index:".$index."/cipher");	
		$multi_pri_state = query($multi_ssid_path."/pri_by_ssid"); 
		$multi_pri_bit = query($multi_ssid_path."/index:".$index."/pri_bit");
	        echo "\necho Add multi-ssid ath".$index."... > /dev/console\n";
	        echo "wlanconfig ath".$index." create wlandev wifi0 wlanmode ap\n";
	        // ifconfig ath0 hw ether 00:05:5d:56:26:20 // jack test
	        // iwpriv ath0 bgscan 0; printf("  \n"); // jack test
	        // iwpriv ath0 dbgLVL 0x100 // jack test
                   if ($band == $A_BAND)	
	                {
	                    if($autochannel==0)
	                    {
	                	    if($channel < 36)
	                	    {
	                		    $channel=36;
	                	    }
	                    }
                    }
                    else
                    {
	                    if($autochannel==0)
	                    {
	                	if($channel>14){
	                		$channel=6;
	                	}
	                }
                    }


         /* wlmode: 0=turbo, 1:11g only, 2.b/g mode 3:11b only, 4:only n  5:b/g/n mix, 6:g/n mix */
	/* protmode: 0:disable n/g promode  1:enable n/g promode  */
	/*apmode 0:b/g/n 1:only g 2:only B (3:only n) 4:b/g mode    pureg 1: no support b 0:have support B mode*/
                 //echo $IWPRIV." chextoffset 1\n";// default to no extension channel present
                 //echo $IWPRIV." chwidth 1\n";// default to 20MHz channel width

		if ($band == $A_BAND)	// A mode
		{ 
       		 //	if($wepmode==1 || $wepmode==2|| $channel==165){//1:WEP, 2:TKIP
	       	//	     echo $IWPRIV." mode 11A\n";
		//	} else {
				if ($cwmmode == 0){
					if($a_mode == 7) {echo $IWPRIV." mode 11A\n";}
					else {echo $IWPRIV." mode 11NAHT20\n";}
				}
				else{
					if($autochannel==1){//autochannel enable
						echo $IWPRIV." mode 11NAHT40\n";
                                        //echo $IWPRIV." chextoffset 0\n";// use ic->extoffset to decide extension channel
                                        //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
					}
					else{
						if($channel==36||$channel==44||$channel==52||$channel==60||$channel==100||$channel==108||$channel==116||$channel==124||$channel==132||$channel==149||$channel==157){
							echo $IWPRIV." mode 11NAHT40PLUS\n";
               		                         //echo $IWPRIV." chextoffset 2\n";// use ic->extoffset to decide extension channel
               		                         //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
						}
						else if($channel==40||$channel==48||$channel==56||$channel==64||$channel==104||$channel==112||$channel==120||$channel==128||$channel==136||$channel==153||$channel==161){
							echo $IWPRIV." mode 11NAHT40MINUS\n";
	                                        //echo $IWPRIV." chextoffset 3\n";// use ic->extoffset to decide extension channel
       		                                 //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
						}
       		                                else if($channel==140||$channel==165){ // channel 140, 165 does not support 40MHz channel width
							$cwmmode = 0;
							set("/wlan/inf:1/cwmmode",$cwmmode);
							echo $IWPRIV." mode 11NAHT20\n";
						}
						else{
							echo $IWPRIV." mode 11NAHT20\n";
						}
					}
				}
//			}
		
	}
	else  // BGN mode
	{
	//	if ($wepmode==1 || $wepmode==2){
	//		echo $IWPRIV." mode 11G\n";
	//	} else 
		if ($channel == 14)    {
    		     echo $IWPRIV." mode 11B\n";
		}else{
			if ($cwmmode == 0){
				if($g_mode == 5) {echo $IWPRIV." mode 11NGHT20\n";}
				else if($g_mode == 4) {echo $IWPRIV." mode 11NGHT20\n";}
				else if($g_mode == 2) {echo $IWPRIV." mode 11G\n";}
				else {echo $IWPRIV." mode 11NGHT20\n";}
			}
			else{//cwmmode=1 HT20/40 mode
				if($autochannel==1){//autochannel enable
					echo $IWPRIV." mode 11NGHT40\n";
                                        //echo $IWPRIV." chextoffset 0\n";// use ic->extoffset to decide extension channel
                                        //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
				}
                                 else{
					if($channel<5){//channel 1~4
						echo $IWPRIV." mode 11NGHT40PLUS\n";
                                        //echo $IWPRIV." chextoffset 2\n";// use ic->extoffset to decide extension channel
                                        //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
					}
                                    else if($channel >= 5 && $channel <= 11){//channel 5~11
                                        echo $IWPRIV." mode 11NGHT40MINUS\n";
                                        //echo $IWPRIV." chextoffset 3\n";// use ic->extoffset to decide extension channel
                                        //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
                                    }
                                    else  //channel 12,13 for JP
                                    {   
                	                $cwmmode = 0;
			                set("/wlan/inf:1/cwmmode",$cwmmode);
			                echo $IWPRIV." mode 11NGHT20\n";
		                    } 
                              }
                       }
		}
	
	}  // end of BGN

	                
	        
	        if ($multi_ssid_hidden!="")    { echo $IWPRIV." hide_ssid ".$multi_ssid_hidden."\n"; }
	        if ($dtim!="")          { echo $IWPRIV." dtim_period ".$dtim."\n"; }
	        
	        if ($multi_wmm!="")       { echo $IWPRIV." wmm ".$multi_wmm."\n"; }
	        else                    { echo $IWPRIV." wmm 0\n"; }
	        
	        if($assoclimitenable == 1)
	        	{echo $IWPRIV." assocenable 1\n";}
	        else
	        	{echo $IWPRIV." assocenable 0\n";}
	        if ($assoclimitnumber!="")          { echo $IWPRIV." assocnumber ".$assoclimitnumber."\n"; }
	        	                /* w_partition 2008-03-22 start */
	                /* Jack add 11/11/08 +++ */  
	                if ($multi_wpartition==2)   /* guest mode,  */
	                {
	                    echo "iwpriv ath".$index." w_partition 1 \n"; 	                    
                        echo "brctl w_partition br0 ath".$index."  1 \n";  
	                }   // for Mssid1, WDS-ath0 jack.
	                else if ($multi_wpartition==1) 
	                {
	                		echo "iwpriv ath".$index." w_partition 1 \n";             
                        echo "brctl w_partition br0 ath".$index." 0 \n";   	  	
	                }  
	                else                    
	                {
	                    echo "iwpriv ath".$index." w_partition  0\n";                   
                        echo "brctl w_partition br0 ath".$index." 0 \n";    
	                }
	                
	                /* Jack add 11/11/08 --- */  
	                  
	                /* w_partition 2008-03-22 end */   
	        echo "ifconfig ath".$index." txqueuelen 1000\n";        
	        echo "iwpriv ath".$index." shortgi ".$shortgi." \n";        
	        
	        if ($cwmmode == 1){
	        	if($autochannel==0){
	                if ($band == $A_BAND)	
	                {
			            if($channel==36||$channel==44||$channel==52||$channel==60||$channel==100||$channel==108||$channel==116||$channel==124||$channel==132||$channel==149||$channel==157){
			            	echo "iwpriv ath".$index." extoffset 1\n";
			            }
			            else{
			            	echo "iwpriv ath".$index." extoffset -1\n";
			            }
	        		}
	        		else
	        		{	        		    
	        		if($channel<5){
	        			echo "iwpriv ath".$index." extoffset 1\n";
	        		}
	        		else{
	        			echo "iwpriv ath".$index." extoffset -1\n";
	        		}
	        	}
	        }   
	        }   
	        echo $IWPRIV." cwmmode ".$cwmmode."\n";  
	       	
			echo "iwpriv wifi0 AMPDU ".$ampdu."\n";
			echo "iwpriv wifi0 AMPDUFrames ".$ampduframe."\n";
			echo "iwpriv wifi0 AMPDULim ".$ampdulimit."\n";
			echo "iwpriv ath".$index." ampdumin ".$ampdmin."\n";
			echo "iwpriv wifi0 ANIEna ".$aniena."\n";

	        
	        if ($band == $A_BAND)	
	        {
	            if($a_mode == 8){
	            	echo "iwpriv ath".$index." pureg 0\n";
	            	echo "iwpriv ath".$index." puren 0\n";
	            	}
	            else if($a_mode == 9){
	            	echo "iwpriv ath".$index." puren 1\n";
	            	}		
	            else{
	            	echo "iwpriv ath".$index." pureg 0\n";
	            	echo "iwpriv ath".$index." puren 0\n";
	            	}
	            if($autochannel==0){
		            if($channel < 36)
			        {
			        $channel=36;
			        }
	            }
	            echo "iwpriv ath".$index." apband 1\n"; //show ap band in wireless driver
	        }
	        else
	        {
	            if($g_mode == 1){
	            	echo "iwpriv ath".$index."  puren 0\n";
	            	echo "iwpriv ath".$index."  pureg 1\n";
	            	}
	            else if($g_mode == 2){
	            	echo "iwpriv ath".$index."  puren 0\n";
	            	echo "iwpriv ath".$index."  pureg 0\n";
	            	}		
	            else if($g_mode == 4){
	            	echo "iwpriv ath".$index."  pureg 0\n";
	            	echo "iwpriv ath".$index."  puren 1\n";
	            	}
	            else if($g_mode == 5){
	            	echo "iwpriv ath".$index."  pureg 0\n";
	            	echo "iwpriv ath".$index."  puren 0\n";
	            	}
	            else if($g_mode == 6){
	            	echo "iwpriv ath".$index."  pureg 1\n";
	            	echo "iwpriv ath".$index."  puren 0\n";
	            	}
	            else{
	            	echo "iwpriv ath".$index."  pureg 0\n";
	            	echo "iwpriv ath".$index."  puren 0\n";
	            	}
	            if($autochannel==0){
	            	if($channel > 14)
	            		{
	            		$channel=6;
	            		}
	            }
	            echo "iwpriv ath".$index." apband 0\n"; //show ap band in wireless driver
	        }
	        
	        echo $IWPRIV." countryie 1\n";	
	        echo "iwconfig ath".$index." essid \"".get("s",$multi_ssid_path."/index:".$index."/ssid")."\" mode master \n";
	   	    echo "iwconfig ath".$index." freq ".$channel."\n";
	        echo $IWPRIV." bintval ".$bintval."\n";   // Atheros suggest 400 is a better value for MSSID. jack test
	       	if ($band == $A_BAND){
				/*0==6M;1==9M;2==12M;3==18M;4==24M;5==36M;6==48M;7==54M*/
				if  ($fixedrate<0)           {echo "iwpriv wifi0 fixedrate 0\n";}
				else if  ($fixedrate<8)      {echo "iwpriv wifi0 fixedrate ".$fixedrate."\n";}
				else                            {echo "iwpriv wifi0 fixedrate 31\n";}
			}
			else{
				/*0==1M;1==2M;2==5.5M;3==11M;4==6M;5==9M;6==12M;7==18M;8==24M;9==36M;10==48M;11==54M*/
				if  ($fixedrate<0)           {echo "iwpriv wifi0 fixedrate 0\n";}
				else if  ($fixedrate<12)      {echo "iwpriv wifi0 fixedrate ".$fixedrate."\n";}
				else                            {echo "iwpriv wifi0 fixedrate 31\n";}
			}
		/*add for mcast rate by yuda start*/
		if ($band == $A_BAND){
			if($mcastrate_a!=0){
			if($mcastrate_a==1){
				echo $IWPRIV." mcast_rate 6000\n";
				}
    			else if($mcastrate_a==2){
    				echo $IWPRIV." mcast_rate 9000\n";
    			}
    			else if($mcastrate_a==3){
    				echo $IWPRIV." mcast_rate 12000\n";
    			}
    			else if($mcastrate_a==4){
    				echo $IWPRIV." mcast_rate 18000\n";
    			}
    			else if($mcastrate_a==5){
    				echo $IWPRIV." mcast_rate 24000\n";
    			}
    			else if($mcastrate_a==6){
    				echo $IWPRIV." mcast_rate 36000\n";
    			}
    			else if($mcastrate_a==7){
    				echo $IWPRIV." mcast_rate 48000\n";
    			}
    			else if($mcastrate_a==8){
    				echo $IWPRIV." mcast_rate 54000\n";
    			}
    			else if($mcastrate_a==9){
    				echo $IWPRIV." mcast_rate 6500\n";
    			}
    			else if($mcastrate_a==10){
    				echo $IWPRIV." mcast_rate 13000\n";
    			}
    			else if($mcastrate_a==11){
    				echo $IWPRIV." mcast_rate 19500\n";
    			}
    			else if($mcastrate_a==12){
    				echo $IWPRIV." mcast_rate 26000\n";
    			}
    			else if($mcastrate_a==13){
    				echo $IWPRIV." mcast_rate 39000\n";
    			}
    			else if($mcastrate_a==14){
    				echo $IWPRIV." mcast_rate 52000\n";
    			}
    			else if($mcastrate_a==15){
    				echo $IWPRIV." mcast_rate 58500\n";
    			}
    			else if($mcastrate_a==16){
    				echo $IWPRIV." mcast_rate 65000\n";
    			}
    			else if($mcastrate_a==17){
    				echo $IWPRIV." mcast_rate 78000\n";
    			}
    			else if($mcastrate_a==18){
    				echo $IWPRIV." mcast_rate 104000\n";
    			}
    			else if($mcastrate_a==19){
    				echo $IWPRIV." mcast_rate 117000\n";
    			}
    			else if($mcastrate_a==20){
    				echo $IWPRIV." mcast_rate 130000\n";
    			}
    			else {
    				echo $IWPRIV." mcast_rate 6000\n";
    			}
    			}
    		}
    		if ($band == $G_BAND) {
    			if($mcastrate_g!=0){
    			if($mcastrate_g==1){
    				echo $IWPRIV." mcast_rate 1000\n";
    			}
    			else if($mcastrate_g==2){
    				echo $IWPRIV." mcast_rate 2000\n";
    			}
    			else if($mcastrate_g==3){
    				echo $IWPRIV." mcast_rate 5500\n";
    			}
    			else if($mcastrate_g==4){
    				echo $IWPRIV." mcast_rate 11000\n";
    			}
    			else if($mcastrate_g==5){
    				echo $IWPRIV." mcast_rate 6000\n";
    			}
    			else if($mcastrate_g==6){
    				echo $IWPRIV." mcast_rate 9000\n";
    			}
    			else if($mcastrate_g==7){
    				echo $IWPRIV." mcast_rate 12000\n";
    			}
    			else if($mcastrate_g==8){
    				echo $IWPRIV." mcast_rate 18000\n";
    			}
    			else if($mcastrate_g==9){
    				echo $IWPRIV." mcast_rate 24000\n";
    			}
    			else if($mcastrate_g==10){
    				echo $IWPRIV." mcast_rate 36000\n";
    			}
    			else if($mcastrate_g==11){
    				echo $IWPRIV." mcast_rate 48000\n";
    			}
    			else if($mcastrate_g==12){
    				echo $IWPRIV." mcast_rate 54000\n";
    			}
    			else if($mcastrate_g==13){
    				echo $IWPRIV." mcast_rate 6500\n";
    			}
    			else if($mcastrate_g==14){
		    		echo $IWPRIV." mcast_rate 13000\n";
		    	}
		    	else if($mcastrate_g==15){
		    		echo $IWPRIV." mcast_rate 19500\n";
    			}
    			else if($mcastrate_g==16){
    				echo $IWPRIV." mcast_rate 26000\n";
    			}
    			else if($mcastrate_g==17){
    				echo $IWPRIV." mcast_rate 39000\n";
    			}
    			else if($mcastrate_g==18){
    				echo $IWPRIV." mcast_rate 52000\n";
    			}
    			else if($mcastrate_g==19){
    				echo $IWPRIV." mcast_rate 58500\n";
    			}
    			else if($mcastrate_g==20){
    				echo $IWPRIV." mcast_rate 65000\n";
    			}
    			else if($mcastrate_g==21){
    				echo $IWPRIV." mcast_rate 78000\n";
    			}
    			else if($mcastrate_g==22){
    				echo $IWPRIV." mcast_rate 104000\n";
    			}
    			else if($mcastrate_g==23){
    				echo $IWPRIV." mcast_rate 117000\n";
    			}
    			else if($mcastrate_g==24){
    				echo $IWPRIV." mcast_rate 130000\n";
    			}
     			else {
    				echo $IWPRIV." mcast_rate 11000\n";
    			}   	   
    			}     
    		}
    			
		/*add for mcast rate by yuda end*/

	        /* aclmode 0:disable, 1:allow all of the list, 2:deny all of the list */
	        echo "iwpriv ath".$index." maccmd 3\n";   // flush the ACL database.
	        $aclmode=query($WLAN."/acl/mode");
		    //echo "echo aclmode:  ".$aclmode."  ... > /dev/console\n";
	        if      ($aclmode == 1)     { echo "iwpriv ath".$index."  maccmd 1\n"; }
	        else if ($aclmode == 2)     { echo "iwpriv ath".$index."  maccmd 2\n"; }
	        else                        { echo "iwpriv ath".$index."  maccmd 0\n"; }
	        if ($aclmode == 1 || $aclmode == 2)
	        {
	           for($WLAN."/acl/mac")
	           {
	            $mac=query($WLAN."/acl/mac:".$@);
	             echo "iwpriv ath".$index." addmac ".$mac."\n";//wtpmacenable 2007-09-13 dennis
	           }
	        }
            $zonedefencemode=query($WLAN."/zonedefence");    
			if ($zonedefencemode == 1){
				 echo "iwpriv ath".$index."  zonedefence 1\n";
				 for("/wlan/inf:1/zonedefence_ip/ipaddr")
               	 {
                	 $ipaddr=query("/wlan/inf:1/zonedefence_ip/ipaddr:".$@);
                  	 echo "iwpriv ".$wlanif." add_ip ".$ipaddr."\n";
               	 }
                
			}
			else {
				 echo "iwpriv ath".$index."  zonedefence 0\n";
			}	
	                /* Jack add 20/04/07 MULTI_SSID_FILTER --- */

             	    //echo "brctl setbwctrl br0 ath".$index." ".$denominator."\n";// dennis 2006-06-25 multicast bwctrl
	                $multi_ssid_amount++;  /* Jack add 17/04/07 MULTI_SSID_CLIENT_INFO */
	    	        set("/runtime".$WLAN."/multi_ssid/index:".$index."/state", 1);  /* Jack add 17/04/07 MULTI_SSID_CLIENT_INFO */
	         /*2008_07_14_allen,multi-ssid priority*/
                 if ($multi_pri_state == 1) {
			echo $IWPRIV." pristate 1\n";
			echo $IWPRIV." pribit ".$multi_pri_bit."\n";
		 }else { echo $IWPRIV." pristate 0\n"; }
	         }     // end of ($multi_ind_state==1) 
	    }// end of for
   		//echo "brctl setbwctrl br0 ath0 ".$denominator."\n"; // dennis 2006-06-25 multicast bwctrl
	        /* Jack add 17/04/07 MULTI_SSID_CLIENT_INFO +++ */
	        if($multi_ssid_amount !=0)
	        {
	    	    set("/runtime".$WLAN."/multi_ssid/multi_ssid_infostatus", 1);  
	    	    set("/runtime".$WLAN."/multi_ssid/devicenum", $multi_ssid_amount);  
	        } 
	        
	} // end of ($multi_total_state == 1)
	if($iapp_state == 1){
		echo "iappd -f br0".$iapp_interface." &\n"; /* added by Enos , IAPP_20070620 */
	}
} // end of ($generate_start==1)
else
{
	
	if($iapp_state == 1){
		echo "killall iappd\n"; /* added by Enos , IAPP_20070620 */
	}
	if ($multi_total_state == 1)
	{       
	    if (query($WLAN."/enable")!=1)
	    {
		    echo "echo WLAN is disabled ! > /dev/console\n";
		    exit;
	    }
	    $index=0; 
	    for ($WLAN."/multi/index")
	    {      
	    $index++;     
	        /*add schedule for multi-ssid by yuda start*/
	        $schedule_enable=query("/schedule/enable");
	        if ($schedule_enable==1)
	        {
	        	if(query($multi_ssid_path."/index:".$index."/schedule_rule_state")==1)
	        	{
	        		$multi_ind_schedule_state = query($multi_ssid_path."/index:".$index."/schedule_state");
	        	}
	        	else
	        	{
	        		$multi_ind_schedule_state = 1;
	        	}     	
	        }
	        else
	        {
	        	$multi_ind_schedule_state = 1;
	        }
	        
	        /*add schedule for multi-ssid by yuda end*/	    
	        $multi_ind_state = query($multi_ssid_path."/index:".$index."/state");  
	        if ($multi_ind_state==1 && $multi_ind_schedule_state == 1)  //add $multi_ind_schedule_state for schedule for multi-ssid by yuda  
	        {          
	            echo "\necho kill multi-ssid ath".$index."... > /dev/console\n";       
	            /*$hostapd_pid = "/var/run/hostapd0".$index.".pid";*/
	            $hostapd_conf = "/var/run/hostapd0".$index.".conf";
		        echo "rm -f ".$hostapd_conf."\n";
		        
	            /*echo "if [ -f ".$hostapd_pid." ]; then\n";*/
				echo "kill -9 `ps | grep ".$hostapd_conf." | grep -v grep | cut -b 1-5`\n";
		        /*echo "kill -9 \`cat ".$hostapd_pid."\` > /dev/null 2>&1\n";
		        echo "rm -f ".$hostapd_pid."\n";
		        echo "fi\n\n";*/
		        
	            /* Stop wlxmlpatch_pid */	            
/* Jack add 13/02/08 +++ wlxmlpatch_v2*/
		        $wlxmlpatch_pid	= "/var/run/wlxmlpatch".$index.".pid_mssid";
                echo "if [ -f ".$wlxmlpatch_pid." ]; then\n";
                echo "kill \`cat ".$wlxmlpatch_pid."\` > /dev/null 2>&1\n";
                echo "rm -f ".$wlxmlpatch_pid."\n";
                echo "fi\n\n";
/* Jack add 13/02/08 --- wlxmlpatch_v2*/
				if ($igmpsnoop == 1){
				echo "echo disable > /proc/net/br_igmp_ap_br0\n";
				echo "brctl igmp_snooping br0 0\n";
				echo "echo unsetwl ath".$index." > /proc/net/br_igmp_ap_br0\n";
				echo "if [ -f /var/run/ap_igmp_".$index.".pid ]; then\n";
				echo "kill \`cat /var/run/ap_igmp_".$index.".pid\` > /dev/null 2>&1\n";
				echo "rm -f /var/run/ap_igmp_".$index.".pid\n";
				echo "fi\n\n";
				}

		        echo "ifconfig ath".$index." down"."\n";  
		        echo "iwconfig ath".$index." key off"."\n"; 
		        echo "wlanconfig ath".$index." destroy"."\n";  
		    }  // end of ($multi_ind_state==1)
		}  // end of for
	} // end of ($multi_total_state == 1)
}  // end of else ($generate_start!=1)
?>
