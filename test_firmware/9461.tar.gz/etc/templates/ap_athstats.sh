#!/bin/sh
echo [$0] ... > /dev/console
athstats >/dev/console
athstats 1 > /dev/console
