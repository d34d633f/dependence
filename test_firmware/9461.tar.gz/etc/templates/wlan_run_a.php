<?
	$WLAN = $WLAN_a;
	$wlan_ap_operate_mode = query($WLAN."/ap_mode");
	require("/etc/templates/troot.php");
	$wlanif = query("/runtime/layout/wlanif");
	$wlanmac= query("/runtime/layout/wlanmac");
	$countrycode= query("/runtime/nvram/countrycode");
	$wlxmlpatch_pid = "/var/run/wlxmlpatch.pid";
	$ap_igmp_pid = "/var/run/ap_igmp.pid";
if ($generate_start==1)
{
	echo "echo Start WLAN interface ".$wlanif." ... > /dev/console\n";

	 if ($wlan_ap_operate_mode!=0 )  /* jack for fool proof*/
	  {
			 echo "echo not pure AP mode, so disable AP ARRAY ... > /dev/console\n";
	  	 echo "rgdb -s /wlan/inf:1/aparray_enable 0  \n";	  	 
			echo "killall neapc> /dev/console\n";  		
			echo "rgdb -i -d /runtime/wlan/inf:1/ap_array_members/list \n";
			echo "rgdb -i -d /runtime/wlan/inf:1/slaver_record \n";
			echo "rgdb -i -d /runtime/wlan/inf:1/arrayslaver/list \n";
			echo "rgdb -i -d /runtime/wlan/inf:1/arraymaster/list \n";
			echo "rgdb -i -d /runtime/wlan/inf:1/scan_table \n";
	  } 
	/* common cmd */
	$IWPRIV="iwpriv ".$wlanif;
	$IWCONF="iwconfig ".$wlanif;
	echo "rgdb -i -s /runtime/stats/wireless/led11a 0\n";
	echo "rgdb -i -s /runtime/stats/wireless/led11g 0\n";
	if (query("/wlan/inf:1/enable")!=1)
	{
		echo "echo WLAN is disabled ! > /dev/console\n";
		exit;
	}
	/*for JP //OUTDOOR_APPS_JP +++ */
	$is_outdoor = query("/wlan/application");
			/*if ($is_outdoor == "")
		{
			echo "rgdb -s /wlan/application 0\n"; // DAP-2553 default is indoor. DAP-3520 default is outdoor. //
			$is_outdoor = "0";
		}*/
			if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
			{
				if ($countrycode==392 && $is_outdoor==1 )
				{
						set($WLAN."/ap_mode", 0);
						echo "echo Because japan outdoor has no WDS DFS channel, so WDS change to Pure AP mode! > /dev/console\n";
						$wlan_ap_operate_mode = query($WLAN."/ap_mode");
				}
			}		
		//echo "echo wlan_ap_operate_mode is ".$wlan_ap_operate_mode." ... > /dev/console\n";
	/*for JP //OUTDOOR_APPS_JP --- */
	//---------------------apc mode start---------------------------
	if ($wlan_ap_operate_mode==1)
	{
		$clonetype = query("/wlan/inf:1/macclone/type");
        if ($clonetype==1){/*auto*/
            echo "brctl setcloneaddr br0 00:00:00:00:00:00\n";
            echo "brctl clonetype br0 1\n";
            echo "brctl apmode br0 1\n";
            echo "cloned\n";
	        exit;
	    }else{/*Disable and Manual*/
		require($template_root."/__wlan_apcmode_a.php");
		exit;
	}
	}
	//----------------------apc mode end----------------------------
        if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
	{
		require($template_root."/__wlan_wdsmode.php");
		exit;
	}	
		
	/* insmod driver modules & common settings */
	$INSMOD="insmod /lib/modules/";
	echo $INSMOD."ath_hal.ko\n";
	echo $INSMOD."wlan.ko\n";
	echo $INSMOD."ath_rate_atheros.ko\n";
	echo $INSMOD."ath_dfs.ko\n";
	echo $INSMOD."ath_dev.ko\n";
	echo $INSMOD."ath_ahb.ko\n";
	echo $INSMOD."wlan_xauth.ko\n";
	echo $INSMOD."wlan_ccmp.ko\n";
	echo $INSMOD."wlan_tkip.ko\n";
	echo $INSMOD."wlan_wep.ko\n";
	echo $INSMOD."wlan_acl.ko\n";
	echo $INSMOD."ath_pktlog.ko\n";
	echo "ifconfig wifi0 hw ether ".$wlanmac."\n";
	if ($countrycode!=""){
		echo "iwpriv wifi0 setCountryID ".$countrycode."\n";
	}
	else{
		echo "iwpriv wifi0 setCountryID 840\n";
		}
	echo "wlanconfig ".$wlanif." create wlandev wifi0 wlanmode ap\n";
	echo "ifconfig ".$wlanif." hw ether ".$wlanmac."\n";
	
	anchor("/wlan/inf:1");
	$channel = query("channel");         if (query("autochannel")==1) { $channel=0; }
	$bintval = query("beaconinterval");
	$cwmmode = query("cwmmode");
	$shortgi = query("shortgi");
	$a_mode = query("wlmode");
	$ssidhidden = query("ssidhidden");
	$dtim       = query("dtim");
	$wmmenable  = query("wmm/enable");
	$assoclimitenable   = query("assoc_limit/enable");
	$assoclimitnumber   = query("assoc_limit/number");
	$igmpsnoop = query("igmpsnoop");
	$wpartition = query("w_partition");
	$epartition = query("e_partition");
	$ethlink = query("ethlink");
	$fixedrate  = query("fixedrate");
	$mcastrate  = query("mcastrate_a");/*add for mcast rate by yuda*/
	$autochannel = query("autochannel");
	$ampdu		= query("ampdu");
	$ampduframe	= query("ampdusframes");
	$ampdulimit	= query("ampdulimit");
	$aniena		= query("aniena");
	$acktimeout_a = query("acktimeout_a");
	$txpower    = query("txpower");
	$multi_pri_state = query("multi/pri_by_ssid");
	$pri_bit = query("pri_bit");
	$zonedefence = query("zonedefence");

	echo $IWPRIV." bgscan 0\n";
	echo "iwpriv wifi0 HALDbg 0\n";
	echo $IWPRIV." dbgLVL 0x100\n";
	echo "ifconfig ath0 txqueuelen 1000\n";
	echo "ifconfig wifi0 txqueuelen 1000\n";
	echo $IWPRIV." shortgi ".$shortgi." \n";

	//echo "iwpriv ath0 mode 11NAHT40MINUS\n";
	if($autochannel==0){
		if($channel<36)
		{
			$channel=36;
		}
	}
    $wepmode = query("/wlan/inf:1/wpa/wepmode");
       if ($cwmmode == 0){
            if($a_mode == 7) {echo $IWPRIV." mode 11A\n";}
            else {echo $IWPRIV." mode 11NAHT20\n";}
        }
        else{//cwmmode=1 HT20/40 mode
            if($autochannel==1){//autochannel enable
                echo $IWPRIV." mode 11NAHT40\n";
                //echo $IWPRIV." chextoffset 0\n";// use ic->extoffset to decide extension channel
                //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
            }
            else{ //autochannel disable
                if($channel==36||$channel==44||$channel==52||$channel==60||$channel==100||$channel==108||$channel==116||$channel==124||$channel==132||$channel==149||$channel==157){
                    echo $IWPRIV." mode 11NAHT40PLUS\n";				
                    //echo $IWPRIV." chextoffset 2\n";// use ic->extoffset to decide extension channel
                    //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
                }
                else if($channel==40||$channel==48||$channel==56||$channel==64||$channel==104||$channel==112||$channel==120||$channel==128||$channel==136||$channel==153||$channel==161){
                    echo $IWPRIV." mode 11NAHT40MINUS\n";				
                    //echo $IWPRIV." chextoffset 3\n";// use ic->extoffset to decide extension channel
                    //echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
                }
                else if($channel==140||$channel==165){ // channel 140, 165 does not support 40MHz channel width
				$cwmmode = 0;
				set("/wlan/inf:1/cwmmode",$cwmmode);
				echo $IWPRIV." mode 11NAHT20\n";
			}
                else{
                    echo $IWPRIV." mode 11NAHT20\n";
                }
            }
        }  
        if ($ssidhidden!="")    { echo $IWPRIV." hide_ssid ".$ssidhidden."\n"; }
	if ($dtim!="")          { echo $IWPRIV." dtim_period ".$dtim."\n"; }
	
	if ($wmmenable>0)       { echo $IWPRIV." wmm 1\n"; }
	else                    { echo $IWPRIV." wmm 0\n"; }
	if($assoclimitenable == 1)
		{echo $IWPRIV." assocenable 1\n";}
	else
		{echo $IWPRIV." assocenable 0\n";}
	if ($assoclimitnumber!="")          { echo $IWPRIV." assocnumber ".$assoclimitnumber."\n"; }

	/* w_partition 2008-03-22 start */
	if ($wpartition==2)  /* guest mode*/
	{ 
	    echo $IWPRIV." w_partition 1 \n"; 	      
        echo "brctl w_partition br0 ath0 1 \n"; 
	}
	else if ($wpartition==1)  
	{ 
	    echo $IWPRIV." w_partition 1 \n"; 	  
	    echo "brctl w_partition br0 ath0 0\n";
	}
	else            
	{ 
	    echo $IWPRIV." w_partition  0\n"; 
	    echo "brctl w_partition br0 ath0 0\n";
	}
	/* w_partition 2008-03-22 end */	

	if ($epartition!="")  { echo "brctl e_partition br0 ".$epartition."\n";}
	else            { echo "brctl e_partition br0 0\n"; }
	

	//echo "ifconfig ath0 txqueuelen 1000\n";
	//echo "ifconfig wifi0 txqueuelen 1000\n";
//	echo $IWPRIV." shortgi 1\n";
	if ($cwmmode == 1){
		if($autochannel==0){
			if($channel==36||$channel==44||$channel==52||$channel==60||$channel==100||$channel==108||$channel==116||$channel==124||$channel==132||$channel==149||$channel==157){
				echo "iwpriv ath0 extoffset 1\n";
			}
			else{
				echo "iwpriv ath0 extoffset -1\n";
			}
		}
	}
//sandy 2009_7_02+++++	
	if ($channel!=0) 
	{
		if ($channel==165 || $channel==140)
		{
			if($cwmmode==1)
			{
			    $cwmmode=0;
			    set("/wlan/inf:1/cwmmode", $cwmmode);
			}	
		}				
	}
//---------------------	
	echo $IWPRIV." cwmmode ".$cwmmode."\n";
	if ($ampdu!="")    {echo "iwpriv wifi0 AMPDU ".$ampdu."\n";}
	else {echo "iwpriv wifi0 AMPDU 1 \n";}

	if ($ampduframe!="")    {echo "iwpriv wifi0 AMPDUFrames ".$ampduframe."\n"; }	
	else {echo "iwpriv wifi0 AMPDUFrames 32 \n";}
	
	if ($ampdulimit!="")    {echo "iwpriv wifi0 AMPDULim ".$ampdulimit."\n";    }
	else {echo "iwpriv wifi0 AMPDULim 50000 \n";}
	
	if ($aniena!="")    {echo "iwpriv wifi0 ANIEna ".$aniena."\n";  }
	else {echo " iwpriv wifi0 ANIEna 0 \n";}
	//8--->NA mix 9--> only n
	if($a_mode == 8){
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 0\n";
		}
	else if($a_mode == 9){
		echo "iwpriv ath0 puren 1\n";
		}		
	else{
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 0\n";
		}
	//echo "iwpriv ath0 pureg 0\n";
	//echo "iwpriv ath0 puren 0\n";
	//echo "iwpriv ath0 staextoffset 0\n";
	echo $IWPRIV." countryie 1\n";
	echo $IWPRIV." doth 1\n";	
	echo "iwconfig ath0 essid \"".get("s","/wlan/inf:1/ssid")."\"  mode master \n";
	echo "iwconfig ath0 freq ".$channel."\n";
	echo "iwpriv wifi0 txchainmask 5\n";
	echo "iwpriv wifi0 rxchainmask 5\n";

	echo "echo 1 > /proc/sys/dev/ath/htdupieenable\n";

	if($bintval!=""){
	echo $IWPRIV." bintval ".$bintval."\n";
	}
	else{
	echo $IWPRIV." bintval 100\n";
	}	
	echo $INSMOD."wlan_scan_ap.ko\n";
//2009_07_02 sandy++++	
	if($a_mode == 8 || $a_mode == 9)
	{
		  $fixedrate = 31;
		  set("/wlan/inf:1/fixedrate", $fixedrate);
	}
//2009_07_02 sandy----	
	/*0==6M;1==9M;2==12M;3==18M;4==24M;5==36M;6==48M;7==54M*/
	if  ($fixedrate<0)           {echo "iwpriv wifi0 fixedrate 0\n";}
	else if  ($fixedrate<8)      {echo "iwpriv wifi0 fixedrate ".$fixedrate."\n";}
	else                            {echo "iwpriv wifi0 fixedrate 31\n";}
	echo "iwpriv wifi0 acktimeout ".$acktimeout_a."\n";
	echo "brctl apmode br0 0"."\n";
	echo "iwpriv ath0 apband 1\n"; //show ap band in wireless driver
	echo "sleep 1\n";
	require($template_root."/__wlan_acl_a.php");
        if ($multi_pri_state == 1) {
        	echo $IWPRIV." pristate 1\n"; 
        	echo $IWPRIV." pribit ".$pri_bit."\n"; 
        }	
        /*add for mcast rate by yuda start */
        if($mcastrate!=0){
    	if($mcastrate==1){
    		echo $IWPRIV." mcast_rate 6000\n";
    	}
    	else if($mcastrate==2){
    		echo $IWPRIV." mcast_rate 9000\n";
    	}
    	else if($mcastrate==3){
    		echo $IWPRIV." mcast_rate 12000\n";
    	}
    	else if($mcastrate==4){
    		echo $IWPRIV." mcast_rate 18000\n";
    	}
    	else if($mcastrate==5){
    		echo $IWPRIV." mcast_rate 24000\n";
    	}
    	else if($mcastrate==6){
    		echo $IWPRIV." mcast_rate 36000\n";
    	}
    	else if($mcastrate==7){
    		echo $IWPRIV." mcast_rate 48000\n";
    	}
    	else if($mcastrate==8){
    		echo $IWPRIV." mcast_rate 54000\n";
    	}
    	else if($mcastrate==9){
    		echo $IWPRIV." mcast_rate 6500\n";
    	}
    	else if($mcastrate==10){
    		echo $IWPRIV." mcast_rate 13000\n";
    	}
    	else if($mcastrate==11){
    		echo $IWPRIV." mcast_rate 19500\n";
    	}
    	else if($mcastrate==12){
    		echo $IWPRIV." mcast_rate 26000\n";
    	}
    	else if($mcastrate==13){
    		echo $IWPRIV." mcast_rate 39000\n";
    	}
    	else if($mcastrate==14){
    		echo $IWPRIV." mcast_rate 52000\n";
    	}
    	else if($mcastrate==15){
    		echo $IWPRIV." mcast_rate 58500\n";
    	}
    	else if($mcastrate==16){
    		echo $IWPRIV." mcast_rate 65000\n";
    	}
    	else if($mcastrate==17){
    		echo $IWPRIV." mcast_rate 78000\n";
    	}
    	else if($mcastrate==18){
    		echo $IWPRIV." mcast_rate 104000\n";
    	}
    	else if($mcastrate==19){
    		echo $IWPRIV." mcast_rate 117000\n";
    	}
    	else if($mcastrate==20){
    		echo $IWPRIV." mcast_rate 130000\n";
    	}
    	else {
    		echo $IWPRIV." mcast_rate 6000\n";
    	}        
    	}
    	/*add for mcast rate by yuda end */
        $auth_mode = query("/wlan/inf:1/authentication");
	if ($auth_mode>1){  
		/*remove device up */
	}
	else {
		
	     require($template_root."/__auth_openshared_a.php"); 
	   

	}
    if ($zonedefence==1){
		echo $IWPRIV." zonedefence 1\n";
	//	require($template_root."/zonedefence.php");
	}    
	else{
		echo $IWPRIV." zonedefence 0\n";
	}
	$DFStestmode = query("/wlan/inf:1/dfstest");
	if ($DFStestmode==1)
	{  
	    echo "radartool usenol 0\n"; 
	}
        
    require($template_root."/multi_ssid_run.php");  /* Jack add 13/11/08 init_MSSID_before_WDS multi-ssid should be init before WDS_VAP */
        
}//if end
else
{
	echo "echo Stop WLAN interface ... > /dev/console\n";
	
	// multi-ssid must be normal AP mode. /* Jack add multi_ssid 31/03/07 */
	$multi_total_state = query($WLAN."/multi/state");
	$igmpsnoop = query("/wlan/inf:1/igmpsnoop");
	if ($multi_total_state == 1)
	{
		if ($wlan_ap_operate_mode!=0 && $wlan_ap_operate_mode!=3 && $wlan_ap_operate_mode!=4) /*    WDS_OVER_MULTI_SSID*/
		{
			echo "echo multi-ssid must be normal AP mode! > /dev/console\n";
			set($WLAN."/ap_mode", 0);
		}
	}
	
	/*for JP //OUTDOOR_APPS_JP +++ */
	if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
			{				
				$is_outdoor = query("/wlan/application");
				if ($countrycode==392 && $is_outdoor==1 )
				{
						set($WLAN."/ap_mode", 0);
						echo "echo Because japan outdoor has no WDS DFS channel, so WDS change to Pure AP mode! > /dev/console\n";
						$wlan_ap_operate_mode = query($WLAN."/ap_mode");
				}
			}		
	/*for JP //OUTDOOR_APPS_JP --- */
	
	if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
	{
		require($template_root."/__wlan_wdsmode.php");
		exit;
	}
	if (query("/wlan/inf:1/enable")!=1)
	{
		echo "echo WLAN is disabled ! > /dev/console\n";
		exit;
	}
	
	echo "if [ -f ".$wlxmlpatch_pid." ]; then\n";
	echo "kill \`cat ".$wlxmlpatch_pid."\` > /dev/null 2>&1\n";
	echo "rm -f ".$wlxmlpatch_pid."\n";
	echo "fi\n\n";
	/* IGMP Snooping dennis 2008-01-29 start */
	if ($igmpsnoop == 1){
	echo "echo disable > /proc/net/br_igmp_ap_br0\n";
	echo "echo unsetwl ath0 > /proc/net/br_igmp_ap_br0\n";
	echo "brctl igmp_snooping br0 0\n";
	echo "if [ -f ".$ap_igmp_pid." ]; then\n";
	echo "kill \`cat ".$ap_igmp_pid."\` > /dev/null 2>&1\n";
	echo "rm -f ".$ap_igmp_pid."\n";
	echo "fi\n\n";
	}
	/* IGMP Snooping dennis 2008-01-29 end */

	/* Stop hostapd */
	$HAPD_conf  = "/var/run/hostapd.".$wlanif.".conf";
	/*$HAPD_pid  = "/var/run/hostapd.".$wlanif.".pid";
	echo "if [ -f ".$HAPD_pid." ]; then\n";
	echo "kill -9 \`cat ".$HAPD_pid."\` > /dev/null 2>&1\n";
	echo "rm -f ".$HAPD_pid."\n";
	echo "rm -f ".$HAPD_conf."\n";
	echo "fi\n\n";*/
	echo "rm -f ".$HAPD_conf."\n";
	echo "kill -9 `ps | grep ".$HAPD_conf." | grep -v grep | cut -b 1-5`\n";
	     
	/* Stop wpa_supplicant */
	$wpa_supplicant_conf    = "/var/run/wpa_supplicant.conf";
	/*$wpa_supplicant_pid    = "/var/run/wpa_supplicant.pid";
	echo "if [ -f ".$wpa_supplicant_pid." ]; then\n";
	echo "kill -9 \`cat ".$wpa_supplicant_pid."\` > /dev/null 2>&1\n";
	echo "rm -f ".$wpa_supplicant_pid."\n";
	echo "rm -f ".$wpa_supplicant_conf."\n";
	echo "fi\n\n";*/
	echo "rm -f ".$wpa_supplicant_conf."\n";
	echo "kill -9 `ps | grep wpa_supplicant | grep ath0 | grep -v grep | cut -b 1-5`\n";
	echo "brctl apmode br0 0"."\n";
	echo "ifconfig ".$wlanif." down\n";
	echo "sleep 2\n";
	echo "brctl delif br0 ".$wlanif."\n";
	echo "sleep 1\n";
	echo "iwconfig ath0 key off"."\n"; // must add key off
	echo "wlanconfig ".$wlanif." destroy\n";
	if($wlan_ap_operate_mode==1)    { echo "rmmod wlan_scan_sta"."\n";  }
	else { echo "rmmod wlan_scan_ap\n"; }
	echo "rmmod ath_pktlog\n";
	echo "sleep 2\n";
	echo "rmmod wlan_acl\n";
	echo "rmmod wlan_wep\n";
	echo "rmmod wlan_tkip\n";
	echo "rmmod wlan_ccmp\n";
	echo "rmmod wlan_xauth\n";
	echo "sleep 2\n";
	echo "rmmod ath_ahb\n";
	echo "sleep 2\n";
	echo "rmmod ath_dev\n";
	echo "rmmod ath_dfs\n";
	echo "rmmod ath_rate_atheros\n";
	echo "rmmod wlan\n";
	echo "rmmod ath_hal\n";
	echo "sleep 1\n";
	echo "rmmod wlan_wep\n";
	echo "rmmod wlan\n";
	echo "gpioc -o 19 \n";
	echo "gpioc -c 19 \n";
	echo "gpioc -d 19 \n";	
	echo "rgdb -i -s /runtime/stats/wireless/led11a 0\n";
	echo "rgdb -i -s /runtime/stats/wireless/led11g 0\n";
}
?>
