#!/bin/sh
<?
/*Check if schedule is enable*/
$schedule_enable=query("/schedule/enable");
$multi_ssid_state=query("/wlan/inf:1/multi/state");

if($schedule_enable==1)
{
	echo "rgdb -i -s /schedule/wlan_restart 0\n";
	echo "service WLAN stop\n";
	echo "service SSID0 stop\n";
	$index=1;
	for("/wlan/inf:1/multi/index")
	{
		echo "service SSID".$index." stop\n";
		$index++;
	}
		
	for("/wlan/inf:1/multi/index")
	{
		echo "rgdb -i -s /wlan/inf:1/multi/index:".$@."/schedule_rule_state 0\n";
	}
	echo "rgdb -i -s /wlan/inf:1/multi/index:0/schedule_rule_state 0\n";
	$enable_flag="0";
	$enable_flag0="0";
    	if($multi_ssid_state==1)
	{
		for("/schedule/rule/index")
		{
			if(query("/schedule/rule/index:".$@."/enable")==1)
			{
				$enable_flag="1";
				$sun=query("/schedule/rule/index:".$@."/sun");
				$mon=query("/schedule/rule/index:".$@."/mon");
				$tue=query("/schedule/rule/index:".$@."/tue");
				$wed=query("/schedule/rule/index:".$@."/wed");
				$thu=query("/schedule/rule/index:".$@."/thu");
				$fri=query("/schedule/rule/index:".$@."/fri");
				$sat=query("/schedule/rule/index:".$@."/sat");
            
				$allday=query("/schedule/rule/index:".$@."/allday");
				$starttime=query("/schedule/rule/index:".$@."/starttime");
				$endtime=query("/schedule/rule/index:".$@."/endtime");
				$wirelesson=query("/schedule/rule/index:".$@."/wirelesson");
				$ssidnum=query("/schedule/rule/index:".$@."/ssidnum");
				if($ssidnum=="0")
				{
					$enable_flag0="1";
				}
				
				$Servd_ssid_cmd="service SSID".$ssidnum." schedule_o";
				if ($wirelesson!="1") {$Servd_ssid_cmd=$Servd_ssid_cmd."!";}
            			$Servd_ssid_cmd=$Servd_ssid_cmd." ";
            			$dot="0";
            			if ($sun=="1") {
            				$Servd_ssid_cmd=$Servd_ssid_cmd."Sun";$dot="1";
            			}
            			if ($mon=="1") 
            			{   
            				if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            				$Servd_ssid_cmd=$Servd_ssid_cmd."Mon";$dot="1";
            			}
            			if ($tue=="1") 
            			{   
            				if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            				$Servd_ssid_cmd=$Servd_ssid_cmd."Tue";$dot="1";
           			}
            			if ($wed=="1") 
            			{   
            				if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            				$Servd_ssid_cmd=$Servd_ssid_cmd."Wed";$dot="1";
            			}
            			if ($thu=="1") 
            			{   
            				if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            				$Servd_ssid_cmd=$Servd_ssid_cmd."Thu";$dot="1";
            			}
            			if ($fri=="1") 
            			{   
            				if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            				$Servd_ssid_cmd=$Servd_ssid_cmd."Fri";$dot="1";
            			}
            			if ($sat=="1") 
            			{   
            				if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            				$Servd_ssid_cmd=$Servd_ssid_cmd."Sat";$dot="1";
            			}
            			if ($allday=="1")
            			{
            				$Servd_ssid_cmd=$Servd_ssid_cmd." 00:00 24:00";
    				}
    				else
    				{
    					$Servd_ssid_cmd=$Servd_ssid_cmd." ".$starttime." ".$endtime;
    				}
			}
    			if($enable_flag=="1")
    			{
    					echo $Servd_ssid_cmd."\n";
    					echo "rgdb -i -s /wlan/inf:1/multi/index:".$ssidnum."/schedule_rule_state 1\n";
			}

    		}
		if($enable_flag0=="0" || $enable_flag=="0")
		{
			echo "service WLAN restart\n";
		}    	
    	}
    	else 
    	{
    		$enable_flag="0";
    		for("/schedule/rule/index")
    		{
    			if ($enable_flag=="0" && query("/schedule/rule/index:".$@."/ssidnum")=="0")
    			{
    				if(query("/schedule/rule/index:".$@."/enable")==1)
    				{
					$enable_flag="1";
					$sun=query("/schedule/rule/index:".$@."/sun");
					$mon=query("/schedule/rule/index:".$@."/mon");
					$tue=query("/schedule/rule/index:".$@."/tue");
					$wed=query("/schedule/rule/index:".$@."/wed");
					$thu=query("/schedule/rule/index:".$@."/thu");
					$fri=query("/schedule/rule/index:".$@."/fri");
					$sat=query("/schedule/rule/index:".$@."/sat");
            
					$allday=query("/schedule/rule/index:".$@."/allday");
					$starttime=query("/schedule/rule/index:".$@."/starttime");
					$endtime=query("/schedule/rule/index:".$@."/endtime");
					$wirelesson=query("/schedule/rule/index:".$@."/wirelesson");
					$ssidnum=query("/schedule/rule/index:".$@."/ssidnum");

					$Servd_ssid_cmd="service SSID".$ssidnum." schedule_o";
					if ($wirelesson!="1") {$Servd_ssid_cmd=$Servd_ssid_cmd."!";}
            				$Servd_ssid_cmd=$Servd_ssid_cmd." ";
            				$dot="0";
            				if ($sun=="1") {
            					$Servd_ssid_cmd=$Servd_ssid_cmd."Sun";$dot="1";
            				}
            				if ($mon=="1") 
            				{   
            					if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            					$Servd_ssid_cmd=$Servd_ssid_cmd."Mon";$dot="1";
            				}
            				if ($tue=="1") 
            				{   
            					if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            					$Servd_ssid_cmd=$Servd_ssid_cmd."Tue";$dot="1";
           				}
            				if ($wed=="1") 
            				{   
            					if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            					$Servd_ssid_cmd=$Servd_ssid_cmd."Wed";$dot="1";
            				}
            				if ($thu=="1") 
            				{   
            					if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            					$Servd_ssid_cmd=$Servd_ssid_cmd."Thu";$dot="1";
            				}
            				if ($fri=="1") 
            				{   
            					if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            					$Servd_ssid_cmd=$Servd_ssid_cmd."Fri";$dot="1";
            				}
            				if ($sat=="1") 
            				{   
            					if ($dot==1) {$Servd_ssid_cmd=$Servd_ssid_cmd.",";}
            					$Servd_ssid_cmd=$Servd_ssid_cmd."Sat";$dot="1";
            				}
            				if ($allday=="1")
            				{
            					$Servd_ssid_cmd=$Servd_ssid_cmd." 00:00 24:00";
    					}
    					else
    					{
    						$Servd_ssid_cmd=$Servd_ssid_cmd." ".$starttime." ".$endtime;
    					}
        			}
        			if($enable_flag=="1" && query("/schedule/rule/index:".$@."/ssidnum")=="0")
        			{
        				echo $Servd_ssid_cmd."\n";
        				echo "rgdb -i -s /wlan/inf:1/multi/index:".$ssidnum."/schedule_rule_state 1\n";
        			}
        		}
        	}
        	if($enable_flag=="0")
        	{
        		echo "service SSID0 restart\n";
        	}
        }
}
else
{
    echo "service WLAN restart\n";
}


?>