#!/bin/sh
echo [$0] ... > /dev/console

case "$1" in
tocm)
	ipmode=`rgdb -g /wan/rg/inf:1/mode`
	ip=`rgdb -g /wan/rg/inf:1/static/ip`
	netmask=`rgdb -g /wan/rg/inf:1/static/netmask`
	gateway=`rgdb -g /wan/rg/inf:1/static/gateway`
	primarydns=`rgdb -g /dnsRelay/server/primarydns`
	secondarydns=`rgdb -g /dnsRelay/server/secondarydns`
	
	rm /var/run/rgdb.xml
	rm /var/run/rgdb.xml.gz
	rgdb -D /var/run/rgdb.xml
	gzip /var/run/rgdb.xml
	devconf put -n /dev/mtdblock/: -f /var/run/rgdb.xml.gz 
	if [ "$?" = "0" ]; then
		echo "ok" > /dev/console
	else
		echo "failed" > /dev/console
	fi
	mfc cloud_freset
	rgdb -s /wan/rg/inf:1/mode $ipmode
	rgdb -s /wan/rg/inf:1/static/ip $ip
	rgdb -s /wan/rg/inf:1/static/netmask $netmask
	rgdb -s /wan/rg/inf:1/static/gateway $gateway
	rgdb -s /dnsRelay/server/primarydns $primarydns
	rgdb -s /dnsRelay/server/secondarydns $secondarydns
	rgdb -s /cloud/enable 1
	/etc/scripts/misc/profile.sh put
	reboot
	;;
tolm)
	devconf get -n /dev/mtdblock/: -f /var/run/rgdb.xml.gz
	if [ "$?" != "0" ]; then
		echo "CAN NOT get devive config, generate default!" > /dev/console
		ipmode=`rgdb -g /wan/rg/inf:1/mode`
		ip=`rgdb -g /wan/rg/inf:1/static/ip`
		netmask=`rgdb -g /wan/rg/inf:1/static/netmask`
		gateway=`rgdb -g /wan/rg/inf:1/static/gateway`
		primarydns=`rgdb -g /dnsRelay/server/primarydns`
		secondarydns=`rgdb -g /dnsRelay/server/secondarydns`
		/etc/scripts/misc/profile.sh reset
		rgdb -s /wan/rg/inf:1/mode $ipmode
		rgdb -s /wan/rg/inf:1/static/ip $ip
		rgdb -s /wan/rg/inf:1/static/netmask $netmask
		rgdb -s /wan/rg/inf:1/static/gateway $gateway
		rgdb -s /dnsRelay/server/primarydns $primarydns
		rgdb -s /dnsRelay/server/secondarydns $secondarydns
		rgdb -s /cloud/enable 0
		/etc/scripts/misc/profile.sh put
	else
		ipmode=`rgdb -g /wan/rg/inf:1/mode`
		ip=`rgdb -g /wan/rg/inf:1/static/ip`
		netmask=`rgdb -g /wan/rg/inf:1/static/netmask`
		gateway=`rgdb -g /wan/rg/inf:1/static/gateway`
		primarydns=`rgdb -g /dnsRelay/server/primarydns`
		secondarydns=`rgdb -g /dnsRelay/server/secondarydns`
		
		devconf put -f /var/run/rgdb.xml.gz
		if [ "$?" = "0" ]; then
			echo "ok" > /dev/console
		else
			echo "failed" > /dev/console
		fi
		rm /var/run/rgdb.xml
		rm /var/run/rgdb.xml.gz
		/etc/scripts/misc/profile.sh get
		rgdb -s /wan/rg/inf:1/mode $ipmode
		rgdb -s /wan/rg/inf:1/static/ip $ip
		rgdb -s /wan/rg/inf:1/static/netmask $netmask
		rgdb -s /wan/rg/inf:1/static/gateway $gateway
		rgdb -s /dnsRelay/server/primarydns $primarydns
		rgdb -s /dnsRelay/server/secondarydns $secondarydns
		/etc/scripts/misc/profile.sh put
	fi
	reboot
	;;
delconf)
	devconf del -n /dev/mtdblock/:
	;;
*)
	echo "usage: cloud_lan.sh {set} {static|dynamic}"
	echo "cloud_lan.sh {get}"
	;;
esac

