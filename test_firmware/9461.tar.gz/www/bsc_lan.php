<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME      = "bsc_lan";
$MY_MSG_FILE  = $MY_NAME.".php";
$MY_ACTION    = $MY_NAME;
$NEXT_PAGE    = "bsc_lan";
set("/runtime/web/help_page",$MY_NAME);
/* --------------------------------------------------------------------------- */
if($ACTION_POST != "")
{
	require("/www/model/__admin_check.php");
	require("/www/__action_bsc.php");
	$ACTION_POST = "";
	exit;
}

/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
set("/runtime/web/next_page",$first_frame);
require("/www/comm/__js_ip.php");
/* --------------------------------------------------------------------------- */
// get the variable value from rgdb.
echo "<!--debug\n";
if($lan_type_reload == 1 || $lan_type_reload == 2) // change lan type
{
	$cfg_lan_type = $lan_type_reload;
}
else // first init
{
	$cfg_lan_type = query("/wan/rg/inf:1/mode");
}

if($cfg_lan_type == 1)
{
	echo "anchor static\n";
	anchor("/wan/rg/inf:1/static");
}
else
{
	echo "anchor dhcp\n";
	anchor("/runtime/wan/inf:1");
}
$cfg_ipaddr = query("ip");
$cfg_ipmask = query("netmask");
$cfg_gw     = query("gateway");
$cfg_dns1 = query("/dnsRelay/server/primarydns");
$cfg_dns2 = query("/dnsRelay/server/secondarydns");
$runtime_dns = query("/runtime/web/display/dns");
$cfg_netbios = query("/netbios/name");
$cfg_cloud = query("/cloud/enable");


echo "lan_type_reload = ". $lan_type_reload ."\n";
echo "cfg_lan_type = ". $cfg_lan_type ."\n";
echo "cfg_ipaddr = ". $cfg_ipaddr ."\n";
echo "cfg_ipmask = ". $cfg_ipmask ."\n";
echo "cfg_gw = ". $cfg_gw ."\n";
echo "cfg_dns1 = ". $cfg_dns1 ."\n";
echo "cfg_dns2 = ". $cfg_dns2 ."\n";
echo "-->";
/* --------------------------------------------------------------------------- */
?>

<?
echo $G_TAG_SCRIPT_START."\n";
require("/www/model/__wlan.php");
?>

function check_disable_items()
{
	var f = get_obj("frm");

	if(f.lantype.selectedIndex == 0) // static
	{
		f.ipaddr.disabled  = false;
		f.ipmask.disabled  = false;
		f.gateway.disabled = false;
		f.netbios.disabled = false;
	}
	else // dhcp
	{
		f.ipaddr.disabled  = true;
		f.ipmask.disabled  = true;
		f.gateway.disabled = true;
		f.netbios.disabled = true;
	}
}

function on_change_lan_type(s)
{
	self.location.href = "<?=$MY_NAME?>.php?lan_type_reload=" + s.value;
}

/* page init functoin */
function init()
{
	var f = get_obj("frm");
	// 1: static, 2: dhcp
	select_index(f.lantype, "<?=$cfg_lan_type?>");

	f.ipaddr.value  = "<?=$cfg_ipaddr?>";
	f.ipmask.value  = "<?=$cfg_ipmask?>";
	f.netbios.value = "<?=$cfg_netbios?>";
	if("<?=$cfg_gw?>" == "0.0.0.0")
	{
		f.gateway.value = "";
	}
	else
	{
		f.gateway.value = "<?=$cfg_gw?>";
	}
	f.dns1.value  = "<?=$cfg_dns1?>";
	f.dns2.value  = "<?=$cfg_dns2?>";
	check_disable_items();
}

/* parameter checking */
function check()
{
	var f = get_obj("frm");

	switch(f.lantype.value)
	{
		case "1":
			if(!is_valid_ip3(f.ipaddr.value, 0))
			{
				alert("<?=$a_invalid_ip?>");
				field_focus(f.ipaddr, "**");
				return false;
			}
			if(invalid_ip_mask(f.ipaddr.value, f.ipmask.value)==false)
			{
				alert("<?=$a_invalid_ip?>");
				field_focus(f.ipaddr, "**");
				return false;
			}
/*			if(!is_valid_ip(f.ipaddr.value, 0))
			{
				alert("<?=$a_invalid_ip?>");
				field_focus(f.ipaddr, "**");
				return false;
			}
*/
			if (!is_valid_mask(f.ipmask.value))
			{
				alert("<?=$a_invalid_netmask?>");
				field_focus(f.ipmask, "**");
				return false;
			}
			if(!is_blank(f.gateway.value))
			{
				if (!is_valid_ip3(f.gateway.value, 0))
				{
					alert("<?=$a_invalid_gateway?>");
					field_focus(f.gateway, "**");
					return false;
				}
				if(invalid_ip_mask(f.gateway.value, f.ipmask.value)==false)
				{
					alert("<?=$a_invalid_gateway?>");
					field_focus(f.gateway, "**");
					return false;
				}
			}
				if(is_blank(f.netbios.value))
				{
					alert("<?=$a_invalid_netbios?>");
					field_focus(f.netbios, "**");
					return false;
				}
				else
				{
					if(strchk_hostname(f.netbios.value)==false)
					{
						alert("<?=$a_invalid_netbios?>");
						field_focus(f.netbios, "**");
						return false;
					}
				}
			break;

		case "2": // dhcp
			break;

		default:
			return false;
	}
	if(!is_blank(f.dns1.value))
	{
		if (!is_valid_ip(f.dns1.value, 0))
		{
			alert("<?=$a_invalid_dns?>");
			field_focus(f.dns1, "**");
			return false;
		}
	}
	if(!is_blank(f.dns2.value))
	{
		if (!is_valid_ip(f.dns2.value, 0))
		{
			alert("<?=$a_invalid_dns?>");
			field_focus(f.dns2, "**");
			return false;
		}
	}
	return true;
}

function submit()
{
	if(check()) get_obj("frm").submit();
}

<?=$G_TAG_SCRIPT_END?>

<body <?=$G_BODY_ATTR?> onload="init();">

<form name="frm" id="frm" method="post" action="<?=$MY_NAME?>.php" onsubmit="return false;">

<input type="hidden" name="ACTION_POST" value="<?=$MY_ACTION?>">

<table id="table_frame" border="0"<?=$G_TABLE_ATTR_CELL_ZERO?>>
	<tr>
		<td valign="top">
			<table id="table_header" <?=$G_TABLE_ATTR_CELL_ZERO?>>
			<tr>
				<td id="td_header" valign="middle"><?=$m_context_title?></td>
			</tr>
			</table>
<!-- ________________________________ Main Content Start ______________________________ -->
			<table id="table_set_main"  border="0"<?=$G_TABLE_ATTR_CELL_ZERO?>>
				<tr>
					<td id="td_left" width="150">
						<?=$m_lan_type?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("lantype", [1,2], ["<?=$m_static_ip?>","<?=$m_dhcp?>"], "on_change_lan_type(this)");<?=$G_TAG_SCRIPT_END?>
					</td>
				</tr>
				<tr>
					<td id="td_left">
						<?=$m_ipaddr?>
					</td>
					<td id="td_right">
						<input type="text" class="text" id="ipaddr" name="ipaddr" class="flatL" size="15" maxlength="15" value="" />
					</td>
				</tr>
				<tr>
					<td id="td_left">
						<?=$m_subnet?>
					</td>
					<td id="td_right">
						<input type="text" class="text" id="ipmask" name="ipmask" class="flatL" size="15" maxlength="15" value="" />
					</td>
				</tr>
				<tr>
					<td id="td_left">
						<?=$m_gateway?>
					</td>
					<td id="td_right">
						<input type="text" class="text" id="gateway" name="gateway" class="flatL" size="15" maxlength="15" value="" />
					</td>
				</tr>
				<tr>
					<td id="td_left">
						<?=$m_netbios?>
					</td>
					<td id="td_right">
						<input type="text" class="text" id="netbios" name="netbios" class="flatL" size="15"maxlength="15" value="" />
					</td>
				</tr>
				<tr>
					<td id="td_left">
						<?=$m_dns1?>	
					</td>
					<td id="td_right">
						<input type="text" class="text" id="dns1" name="dns1" class="flatL" size="15" maxlength="15" value="" />
					</td>
				</tr>
				<tr>
					<td id="td_left">
						<?=$m_dns2?>
					</td>
					<td id="td_right">
						<input type="text" class="text" id="dns2" name="dns2" class="flatL" size="15" maxlength="15" value="" />
					</td>
				</tr>
			</table>
<?=$G_APPLY_BUTTON?>
<!-- ________________________________  Main Content End _______________________________ -->
		</td>
	</tr>
</table>

</form>
</body>
</html>
