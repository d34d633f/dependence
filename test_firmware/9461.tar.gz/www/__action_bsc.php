<?
$AUTH_GROUP=fread("/var/proc/web/session:".$sid."/user/group");
if ($AUTH_GROUP!="0") {require("/www/permission_deny.php");exit;}
if($ACTION_POST == "bsc_cloud")
{
	echo "<!--\n";
	echo "f_cloud = ". $f_cloud ."\n";
	echo "-->\n";
	
	$SUBMIT_STR = "";
    $dirty = 0;

	if(query("/cloud/enable") != $f_cloud){set("/cloud/enable", $f_cloud); $dirty++;}

	if($dirty > 0)
    {
        set("/runtime/web/sub_str",$SUBMIT_STR);
        set("/runtime/web/submit/cloud", 1);
		set("/runtime/web/submit/reboot", 1);
    }

    set("/runtime/web/next_page",$ACTION_POST);
	require($G_SAVING_URL);

}
else if($ACTION_POST == "bsc_lan")
{
	echo "<!--\n";
	echo "lantype = ". $lantype ."\n";
	echo "ipaddr = ". $ipaddr ."\n";
	echo "ipmask = ". $ipmask ."\n";
	echo "gateway = ". $gateway ."\n";
	echo "-->\n";

	$SUBMIT_STR = "";
	$dirty = 0;

	$mode = "/wan/rg/inf:1/mode";
	$dhcp_srv_enable = query("/lan/dhcp/server/enable");
	if(query($mode) != $lantype)
	{
		$dirty++; set($mode, $lantype);
		set("/runtime/web/check/change_ip", 1);	
	}

	if ($lantype == 1) // static ip
	{
		$entry="/wan/rg/inf:1/static/";
		if (query($entry."ip")      != $ipaddr)  
		{
			$dirty++; set($entry."ip", $ipaddr);
			set("/runtime/web/check/change_ip", 1);
/*victor modify for dennis 2009-2-20 start*/			
			if($dhcp_srv_enable=="1")
			{
//				set("/runtime/web/submit/dhcpd_restart", 1);
				set("/runtime/web/submit/dhcpd", 1); //shelley 10-04-28
				set("/runtime/web/submit/dhcp_compare", 1);
			}
/*victor modify for dennis 2009-2-20 end*/	
		}
		if (query($entry."netmask") != $ipmask)  {$dirty++; set($entry."netmask", $ipmask);}
		if (query($entry."gateway") != $gateway) {$dirty++; set($entry."gateway", $gateway);}
		if (query("/netbios/name") != $netbios)  {$dirty++; set("/netbios/name", $netbios);}
	}
		if (query("/dnsRelay/server/primarydns") != $dns1)  {$dirty++; set("/dnsRelay/server/primarydns", $dns1);}
		if (query("/dnsRelay/server/secondarydns") != $dns2)  {$dirty++; set("/dnsRelay/server/secondarydns", $dns2);}
	

	if($dirty > 0)
	{
		/*victor modify for enos 2009-11-9 start*/	
		$change_ip = query("/runtime/web/check/change_ip");
		if($change_ip== 1)
		{
			set("/runtime/web/submit/wlan", 1);
		}
		/*victor modify for enos 2009-11-9 start*/	
		if(query("/sys/stunnel/enable") == "1") {/*$SUBMIT_STR="; submit WAN; submit CONSOLE; submit STUNNEL";*/set("/runtime/web/submit/stunnel", 1);set("/runtime/web/submit/console", 1);set("/runtime/web/submit/wan", 1);}
		else {/*$SUBMIT_STR=";submit WAN;submit CONSOLE";*/set("/runtime/web/submit/console", 1);set("/runtime/web/submit/wan", 1);}
		set("/runtime/web/sub_str",$SUBMIT_STR);
		set("/runtime/web/submit/wan", 1);
		set("/runtime/web/submit/console", 1);
	}

	set("/runtime/web/next_page",$ACTION_POST);
	/*if($dirty > 0) {*/require($G_SAVING_URL);/*}
	else                  {require($G_NO_CHANGED_URL);}*/
}
else if($ACTION_POST == "bsc_wlan")
{
	echo "<!--\n";
	echo "f_scan_value = ". $f_scan_value ."\n";
	echo "band = ". $f_band ."\n";
	echo "mode = ". $f_mode ."\n";
	echo "ssid = ". $f_ssid ."\n";
	echo "ap_hidden = ". $f_ap_hidden ."\n";	
	echo "auto_ch_scan = ". $f_auto_ch_scan ."\n";
	echo "f_chan = ". $f_chan ."\n";
	echo "f_auth = ". $f_auth ."\n";	
	echo "f_cipher = ". $f_cipher ."\n";
	echo "keytype = ". $f_keytype ."\n";
	echo "keysize = ". $f_keysize ."\n";
	echo "defkey = ". $f_defkey ."\n";
	echo "key = ". $f_key ."\n";
	echo "gkui = ". $f_gkui ."\n";
	echo "radius_srv_1 = ". $f_radius_srv_1 ."\n";
	echo "radius_port_1 = ". $f_radius_port_1 ."\n";
	echo "radius_sec_1 = ". $f_radius_sec_1 ."\n";
	echo "radius_srv_2 = ". $f_radius_srv_2 ."\n";
	echo "radius_port_2 = ". $f_radius_port_2 ."\n";
	echo "radius_sec_2 = ". $f_radius_sec_2 ."\n";	
	echo "acc_mode = ". $f_acc_mode ."\n";
	echo "acc_srv_1 = ". $f_acc_srv_1 ."\n";
	echo "acc_port_1 = ". $f_acc_port_1 ."\n";
	echo "acc_sec_1 = ". $f_acc_sec_1 ."\n";
	echo "acc_srv_2 = ". $f_acc_srv_2 ."\n";
	echo "acc_port_2 = ". $f_acc_port_2 ."\n";
	echo "acc_sec_2 = ". $f_radius_sec_2 ."\n";			
	echo "passphrase = ". $f_passphrase ."\n";	
	echo "nap_enable = ".$f_nap_enable."\n";
	echo "f_enable_rekey = ". $f_enable_rekey ."\n";	
	echo "f_time_interuol = ".$f_time_interuol."\n";
	echo "-->\n";

	$SUBMIT_STR = "";
	$dirty = 0;
        $scan_flag=0;
	$limit_dirty=0;
    $url_dirty=0;    
	$array_dirty=0;
	if($f_scan_value == "1" || $f_scan_mac_value== "1")
	{
		set("/runtime/web/check_scan_value", 1);
		set("/wlan/inf:1/instruction",0);//add for dennis to difference at apc scan or instruction scan
		$scan_flag=1;
		$dirty++;	
		if(query("/runtime/web/wlan/ch_mode")	!=$f_band)	{set("/runtime/web/wlan/ch_mode", $f_band);	$dirty++;}
	
		if($f_band == 0) //11g
		{
			anchor("/runtime/web/wlan/inf:1");
		}
		else //11a
		{
			//anchor("/runtime/web/wlan/inf:2");
			anchor("/runtime/web/wlan/inf:1");
		}			
	}
	else
	{
		if(query("/wlan/ch_mode")	!=$f_band)	
		{
			set("/wlan/ch_mode", $f_band);	
			if($f_band == 0) //11g
			{
				set("/wlan/inf:1/wlmode", 5);	//Mixed n,g,b
				set("/wlan/inf:1/fixedrate",31);				
			}
			else
			{
				set("/wlan/inf:1/wlmode", 8);	//Mixed n,a
				set("/wlan/inf:1/fixedrate",31);
			}
			$dirty++;
		}
	
		if($f_band == 0) //11g
		{
			anchor("/wlan/inf:1");
		}
		else //11a
		{
			//anchor("/wlan/inf:2");
			anchor("/wlan/inf:1");
		}			
	}
		
	if(query("ap_mode")	!=$f_mode)	
	{
		set("ap_mode", $f_mode);
		if($f_mode==1)
		{
			set("/sys/adminlimit/status", 0);
			$limit_dirty++;
		}
		if($f_scan_value != "1" && $f_scan_mac_value!= "1")
		{
			set("/runtime/ui/apmode_status", "changed");	
		}
		$dirty++;
	}
        if(query("/wlan/application")	!=$f_application)	{set("/wlan/application", $f_application);	$dirty++;}		
	if(query("ssid")	!=$f_ssid)	{set("ssid", $f_ssid);	$dirty++;}
	if(query("ssidhidden")	!=$f_ap_hidden)	{set("ssidhidden", $f_ap_hidden);	$dirty++;}
	if(query("autochannel")	!=$f_auto_ch_scan)	{set("autochannel", $f_auto_ch_scan);	$dirty++;}
	if($f_auto_ch_scan != 1)
	{	
		if(query("channel")	!=$f_chan)	{set("channel", $f_chan);	$dirty++;}
	}
	if(query("cwmmode")	!=$f_channel_width)	{set("cwmmode", $f_channel_width);	$dirty++;}
	if($f_mode != 0)
	{
		set("assoc_limit/enable",0);
		set("/wlan/inf:1/aparray_enable","0");$array_dirty++;
		if($f_mode == 1) //apc
		{
			if($f_band == 0) {set("wlmode",5);} // 11g, mode = mixed n,g,b
			else {set("wlmode",	8);} // 11a, mode = mixed n,a
			
			set("fixedrate",31);
			set("/qos/enable",0);
			set("w_partition",0);
			set("e_partition",0);
			set("/lan/dhcp/server/enable",0);
			set("/schedule/enable",0);
		}
		if($f_mode == 1 || $f_mode == 2 || $f_mode == 4) //if AP Mode is not 'Access Point' or 'WDS with AP', MSSID , VLAN should be disabled
		{
			set("multi/state",	0);
			set("/sys/vlan_state",	0);
			set("igmpsnoop",0);			
		}
	}
	if($f_mode == 1 || $f_mode == 4)//apc and wds mcastrate must disabled
	{
		set("mcastrate_g",0);
		set("mcastrate_a",0);
		if(query("/wlan/inf:1/webredirect/enable")	!= 0)	{set("webredirect/enable",	0);	$url_dirty++;}//Web Redirectionmust close in APC and wds with ap  mode
	}
	if($f_mode == 3 || $f_mode == 4) //wds with ap, wds
	{
		if(query("wds/list/index:1/mac")	!= $f_wds_mac1)	{set("wds/list/index:1/mac",	$f_wds_mac1);	$dirty++;}
		if(query("wds/list/index:2/mac")	!= $f_wds_mac2)	{set("wds/list/index:2/mac",	$f_wds_mac2);	$dirty++;}
		if(query("wds/list/index:3/mac")	!= $f_wds_mac3)	{set("wds/list/index:3/mac",	$f_wds_mac3);	$dirty++;}
		if(query("wds/list/index:4/mac")	!= $f_wds_mac4)	{set("wds/list/index:4/mac",	$f_wds_mac4);	$dirty++;}
		if(query("wds/list/index:5/mac")	!= $f_wds_mac5)	{set("wds/list/index:5/mac",	$f_wds_mac5);	$dirty++;}
		if(query("wds/list/index:6/mac")	!= $f_wds_mac6)	{set("wds/list/index:6/mac",	$f_wds_mac6);	$dirty++;}
		if(query("wds/list/index:7/mac")	!= $f_wds_mac7)	{set("wds/list/index:7/mac",	$f_wds_mac7);	$dirty++;}
		if(query("wds/list/index:8/mac")	!= $f_wds_mac8)	{set("wds/list/index:8/mac",	$f_wds_mac8);	$dirty++;}
	}
	if(query("authentication")	!=$f_auth)	{set("authentication", $f_auth);	$dirty++;}
	if(query("wpa/wepmode")	!=$f_cipher)	{set("wpa/wepmode", $f_cipher);	$dirty++;}	
	if($f_auth == 0 || $f_auth == 1 || $f_auth == 8) //open, shared, both
	{
		if($f_cipher == 1)
		{	
			if(query("defkey")	!=$f_defkey)	{set("defkey", $f_defkey);	$dirty++;}
			if($f_defkey == 1)
			{
				if(query("wepkey:1/keylength")	!=$f_keysize)	{set("wepkey:1/keylength", $f_keysize);	$dirty++;}	
				if(query("wepkey:1/keyformat")	!=$f_keytype)	{set("wepkey:1/keyformat", $f_keytype);	$dirty++;}	
				if(query("wepkey:1")	!=$f_key)	{set("wepkey:1", $f_key);	$dirty++;}	
			}
			else if($f_defkey == 2)
			{
				if(query("wepkey:2/keylength")	!=$f_keysize)	{set("wepkey:2/keylength", $f_keysize);	$dirty++;}	
				if(query("wepkey:2/keyformat")	!=$f_keytype)	{set("wepkey:2/keyformat", $f_keytype);	$dirty++;}	
				if(query("wepkey:2")	!=$f_key)	{set("wepkey:2", $f_key);	$dirty++;}	
			}	
			else if($f_defkey == 3)
			{
				if(query("wepkey:3/keylength")	!=$f_keysize)	{set("wepkey:3/keylength", $f_keysize);	$dirty++;}	
				if(query("wepkey:3/keyformat")	!=$f_keytype)	{set("wepkey:3/keyformat", $f_keytype);	$dirty++;}	
				if(query("wepkey:3")	!=$f_key)	{set("wepkey:3", $f_key);	$dirty++;}	
			}
			else if($f_defkey == 4)
			{
				if(query("wepkey:4/keylength")	!=$f_keysize)	{set("wepkey:4/keylength", $f_keysize);	$dirty++;}	
				if(query("wepkey:4/keyformat")	!=$f_keytype)	{set("wepkey:4/keyformat", $f_keytype);	$dirty++;}	
				if(query("wepkey:4")	!=$f_key)	{set("wepkey:4", $f_key);	$dirty++;}	
			}	

			for("multi/index")
			{
				$check_ms_index = query("wep_key_index");
				if($check_ms_index == $f_defkey)
				{
					set("wep_keylength",	$f_keysize);	$dirty++;
					set("wep_keyformat",	$f_keytype);	$dirty++;
					set("wep_key",			$f_key);		$dirty++;			
				}
			}														
		}
	}
	else if($f_auth == 2 || $f_auth == 4 || $f_auth == 6 || $f_auth == 9) //eap or 802.1x
	{
		if(query("/runtime/web/display/nap_serverr") !="0")
		{		
			if(query("/sys/vlan_mode")	!= $f_nap_enable)	
			{
				set("/sys/vlan_mode", $f_nap_enable);	$dirty++;
				if($f_nap_enable==1)
				{
					if(query("/sys/adminlimit/status")==1){set("/sys/adminlimit/status", 0);$limit_dirty++;}/*limit_admin_status*/
					if(query("/sys/adminlimit/status")==3){set("/sys/adminlimit/status", 2);$limit_dirty++;}/*limit_admin_status*/
				}
				}
		}
		if($f_auth != 9)	//802.1x don't have the follow settings
		{
			if($f_mode == 1)//eap apc setting 
			{
				if(query("wpa/eap_phase1")	!= $f_apc_eap_method)	{set("wpa/eap_phase1", $f_apc_eap_method);	$dirty++;}
				if(query("wpa/eap_phase2")	!= $f_apc_inner_auth)	{set("wpa/eap_phase2", $f_apc_inner_auth);	$dirty++;}
				if(query("wpa/eap_identity")	!= $f_apc_eap_username)	{set("wpa/eap_identity", $f_apc_eap_username);	$dirty++;}
				if(query("wpa/eap_passwd")	!= $f_apc_eap_password)	{set("wpa/eap_passwd", $f_apc_eap_password);	$dirty++;}
			}
		if(query("/runtime/web/display/nap_serverr") !="0")
		{		
			if(query("/sys/vlan_mode")	!= $f_nap_enable)	{set("/sys/vlan_mode", $f_nap_enable);	$dirty++;}
		}
		if(query("wpa/grp_rekey_interval")	!=$f_gkui)	{set("wpa/grp_rekey_interval", $f_gkui);	$dirty++;}
                }
		else	//802.1x key update interval
		{
			if(query("d_wep_rekey_interval")	!=$f_kui)	{set("d_wep_rekey_interval", $f_kui);	$dirty++;}
		}

		if(query("/runtime/web/display/local_radius_server") !="0") //Remote or Local RADIUS Server
		{		
			if(query("wpa/embradius/state")	!= $f_radius_type)	{set("wpa/embradius/state", $f_radius_type);	$dirty++;}
		}
		
		
		
                if($f_radius_type == 0 || $f_radius_type == "")
		{
		if(query("wpa/radiusserver")	!=$f_radius_srv_1)	{set("wpa/radiusserver", $f_radius_srv_1);	$dirty++;}	
		if(query("wpa/radiusport")	!=$f_radius_port_1)	{set("wpa/radiusport", $f_radius_port_1);	$dirty++;}	
		if(query("wpa/radiussecret")	!=$f_radius_sec_1)	{set("wpa/radiussecret", $f_radius_sec_1);	$dirty++;}	
		if(query("/runtime/web/display/backup_radius_server") !="0")	
		{
			if(query("wpa/b_radiusserver")	!=$f_radius_srv_2)	{set("wpa/b_radiusserver", $f_radius_srv_2);	$dirty++;}	
			if(query("wpa/b_radiusport")	!=$f_radius_port_2)	{set("wpa/b_radiusport", $f_radius_port_2);	$dirty++;}	
			if(query("wpa/b_radiussecret")	!=$f_radius_sec_2)	{set("wpa/b_radiussecret", $f_radius_sec_2);	$dirty++;}	
		}	
		
		if(query("/runtime/web/display/accounting_server") != "0")
		{		
			if(query("wpa/acctstate")	!=$f_acc_mode)	{set("wpa/acctstate", $f_acc_mode);	$dirty++;}	
			if($f_acc_mode == 1)
			{
				if(query("wpa/acctserver")	!=$f_acc_srv_1)	{set("wpa/acctserver", $f_acc_srv_1);	$dirty++;}	
				if(query("wpa/acctport")	!=$f_acc_port_1)	{set("wpa/acctport", $f_acc_port_1);	$dirty++;}	
				if(query("wpa/acctsecret")	!=$f_acc_sec_1)	{set("wpa/acctsecret", $f_acc_sec_1);	$dirty++;}	
				if(query("wpa/b_acctserver")	!=$f_acc_srv_2)	{set("wpa/b_acctserver", $f_acc_srv_2);	$dirty++;}	
				if(query("wpa/b_acctport")	!=$f_acc_port_2)	{set("wpa/b_acctport", $f_acc_port_2);	$dirty++;}	
				if(query("wpa/b_acctsecret")	!=$f_acc_sec_2)	{set("wpa/b_acctsecret", $f_acc_sec_2);	$dirty++;}					
			}
		}					
         	}
	}
	else //psk
	{
		if($f_mode != 1) // not apc
		{
			if(query("wpa/grp_rekey_interval")	!=$f_gkui)	{set("wpa/grp_rekey_interval", $f_gkui);	$dirty++;}
		}	
		if(query("wpa/wpapsk")	!=$f_passphrase)	{set("wpa/wpapsk", $f_passphrase);	$dirty++;}		
		if(query("autorekey/ssid/enable")	!=$f_enable_rekey)	{set("autorekey/ssid/enable", $f_enable_rekey);	$dirty++;}		
		if(query("autorekey/starttime")	!=$f_start_time)	{set("autorekey/starttime", $f_start_time);	$dirty++;}		
		if(query("autorekey/startweek")	!=$f_start_week)	{set("autorekey/startweek", $f_start_week);	$dirty++;}		
		if(query("autorekey/time")	!=$f_time_interuol)	{set("autorekey/time", $f_time_interuol);	$dirty++;}		
		$cfg_ntp_enable=query("/time/syncwith");/*disabled=0,enabled=2*/
		if($cfg_ntp_enable!=2)
		{
			$XGISET_STR="setPath=/runtime/time/";
			$XGISET_STR=$XGISET_STR."&date=".$f_date;
			$XGISET_STR=$XGISET_STR."&time=".$f_time;
			$XGISET_STR=$XGISET_STR."&endSetPath=1";
		}
	}					
	if($f_mac_enable ==0)
	{
		if (query("macclone/type") != 0)		{$dirty++; set("macclone/type", 0);}
	}
	else
	{
		if($f_mac_source==1)
		{
			if (query("macclone/type") != 1)		{$dirty++; set("macclone/type", 1);}
		}
		else
		{
			if (query("macclone/type") != 2)		{$dirty++; set("macclone/type", 2);}
		}
	}	
	if (query("macclone/addr") != $f_clone_mac)		{$dirty++; set("macclone/addr", $f_clone_mac);}									
	$ap_wlmode = query("/wlan/inf:1/wlmode");				
	if($f_cipher == 2 || $f_cipher == 1)
	{	
		if($ap_wlmode==4)
		{
			set("wlmode",5);
		}
		else if($ap_wlmode==9)
		{
			set("wlmode",8);
		}
	}
	if($dirty > 0)
	{
		if($f_scan_value == "1")
		{
			if($f_mode == 3 || $f_mode == 4)
			{
				$SUBMIT_STR="submit WDS_SCAN";
			}
			else
			{
				$SUBMIT_STR="submit SCAN";
			}	
		}
		else if($f_scan_mac_value == "1")
		{
			$SUBMIT_STR="submit MAC_SCAN";
		}
		else
		{
				//$SUBMIT_STR="submit WLAN";
				if($f_enable_rekey==1)
				{
					set("/runtime/web/msg_autorekey", "display");
				}
				if($url_dirty > 0)
				{
					set("/runtime/web/submit/webredirect", 1);
				}
				if($limit_dirty > 0)
				{
					set("/runtime/web/submit/limit", 1);
				}
				if($array_dirty > 0)
				{
					set("/runtime/web/submit/ap_array","1");
				}
				set("/runtime/web/submit/wlan", 1);
		}	
		set("/runtime/web/sub_str",$SUBMIT_STR);
		set("/runtime/web/sub_xgi_str",$XGISET_STR);
	}

	set("/runtime/web/next_page",$ACTION_POST);
	if($SUBMIT_STR!="" && $scan_flag=="1")	{require($G_SCAN_URL);}
	else /*if($dirty > 0 && $f_scan_value!="1")*/
	{require($G_SAVING_URL);}	
	//else				{require($G_NO_CHANGED_URL);}
}

?>
