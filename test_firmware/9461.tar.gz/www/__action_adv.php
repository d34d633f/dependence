<?
$AUTH_GROUP=fread("/var/proc/web/session:".$sid."/user/group");
if ($AUTH_GROUP!="0") {require("/www/permission_deny.php");exit;}
if($ACTION_POST == "adv_rogue")
{
	echo "<!--\n";
	echo "f_detect = ". $f_detect ."\n";	
	echo "f_type = ". $f_type ."\n";
	echo "-->\n";

	$SUBMIT_STR = "";
	$dirty = 0;
	if($f_detect == "1")
	{
		$dirty++;
		set("/wlan/inf:1/instruction",1);//add for dennis to difference at apc scan or instruction scan
		$SUBMIT_STR="submit SCAN;submit COMP";
	}
	else
	{
		anchor("/runtime/wlan/inf:1/rogue_ap");
		$i=0;
		$runtime_client = 0;
		for("/runtime/wlan/inf:1/rogue_ap/client")
		{
			$runtime_client++;
		}		
		while($i< $runtime_client)
		{
			$index=$i+1;
			$client_idx	= "client_idx".$index;
			$band		= query("/runtime/wlan/inf:1/rogue_ap/client:".$index."/band");
			$chan		= query("/runtime/wlan/inf:1/rogue_ap/client:".$index."/channel");
			$ssid		= query("/runtime/wlan/inf:1/rogue_ap/client:".$index."/ssid");
			$mac		= query("/runtime/wlan/inf:1/rogue_ap/client:".$index."/mac");
			$time		= query("/runtime/wlan/inf:1/rogue_ap/client:".$index."/time");
			$time_str	= query("/runtime/wlan/inf:1/rogue_ap/client:".$index."/time_str");
			$status		= query("/runtime/wlan/inf:1/rogue_ap/client:".$index."/status");

			if($$client_idx == 1)
			{
				set("client:".$index."/type", $f_type);

				$j = 1;
				for("/wlan/inf:1/rogue_ap/client")
				{
					if($mac == query("mac"))
					{
						set("/runtime/wlan/inf:1/rogue_ap/client:".$index."/index", $@);
					}	
									
					$j++;
				} 
			
				$fresh_rogue_list_index = query("/runtime/wlan/inf:1/rogue_ap/client:".$index."/index");

				if($f_type != 0 )
				{
					
					if($fresh_rogue_list_index == 0)
					{
						$fresh_rogue_list_index = $j;
					}
					
					set("/wlan/inf:1/rogue_ap/client:".$fresh_rogue_list_index."/type", $f_type);
					set("/wlan/inf:1/rogue_ap/client:".$fresh_rogue_list_index."/band", $band);
					set("/wlan/inf:1/rogue_ap/client:".$fresh_rogue_list_index."/channel", $chan);
					set("/wlan/inf:1/rogue_ap/client:".$fresh_rogue_list_index."/ssid", $ssid);
					set("/wlan/inf:1/rogue_ap/client:".$fresh_rogue_list_index."/mac",  $mac);
					set("/wlan/inf:1/rogue_ap/client:".$fresh_rogue_list_index."/time", $time);		
					set("/wlan/inf:1/rogue_ap/client:".$fresh_rogue_list_index."/time_str", $time_str);				
					set("/wlan/inf:1/rogue_ap/client:".$fresh_rogue_list_index."/status", $status);			

				}
				else if($f_type == 0 && $fresh_rogue_list_index != 0)
				{
					del("/wlan/inf:1/rogue_ap/client:".$fresh_rogue_list_index);	
				}			
				$dirty ++;
			}
			$i++;
		}
		
	}
	
	if($dirty > 0)
	{
		
		//$SUBMIT_STR="COMMIT";
		set("/runtime/web/submit/commit",1);
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}	
		
		
	set("/runtime/web/sub_str",$SUBMIT_STR);
	set("/runtime/web/next_page",$ACTION_POST);
	if($dirty > 0 && $f_detect=="1")	{require($G_SCAN_URL);}
	else /*if($dirty > 0 && $f_detect!="1")*/	{require($G_SAVING_URL);}	
	//else				{require($G_NO_CHANGED_URL);}	
}	
else if($ACTION_POST == "adv_perf")
{
	echo "<!--\n";
	echo "wl_enable 	= ". $wl_enable ."\n";	
	echo "f_wlmode 		= ". $f_wlmode ."\n";
	echo "f_rate 			= ". $f_rate ."\n";
	echo "bi 			= ". $bi ."\n";
	echo "dtim 			= ". $dtim ."\n";
	echo "frag 			= ". $frag ."\n";
	echo "rts 			= ". $rts ."\n";
	echo "power 		= ". $power ."\n";
	echo "wmm 			= ". $wmm ."\n";
	echo "ack_timeout 	= ". $ack_timeout ."\n";
	echo "shortgi 		= ". $shortgi ."\n";
	echo "limit_state 	= ". $limit_state ."\n";
	echo "limit_num 	= ". $limit_num ."\n";
	echo "utilization 	= ". $utilization  ."\n";
	echo "igmp 			= ". $igmp ."\n";
	echo "link_integrality  =".$link_integrality."\n";
	echo "-->\n";	
	
	$SUBMIT_STR = "";
	$dirty = 0;		
	
	$cfg_ap_band = query("/wlan/ch_mode");
	
	if($cfg_ap_band == 0 ) //11g
	{
		anchor("/wlan/inf:1");	
	}
	else
	{
		//anchor("/wlan/inf:2");
		anchor("/wlan/inf:1");
	}	
	
	$cfg_ap_mode = query("ap_mode");
	
	if(query("enable")	!=$wl_enable)	{set("enable", $wl_enable);	$dirty++;}
	if($wl_enable != 0)
	{	
        // if(query("ethlink") != $link_integrality)    {set("ethlink", $link_integrality);	$dirty++;}
		if(query("wlmode")	!=$f_wlmode)	{set("wlmode", $f_wlmode);	$dirty++;}
		if($f_wlmode == 1 || $f_wlmode == 2 || $f_wlmode == 3 || $f_wlmode == 7)
		{
			set("cwmmode", 0);	$dirty++;
		}
		
		if($f_wlmode ==2 || $f_wlmode ==7)
		{
			if(query("fixedrate")	!=$f_rate)	{set("fixedrate", $f_rate);	$dirty++;}
		}
		else
		{
			if(query("fixedrate")	!=31)	{set("fixedrate", 31);	$dirty++;}
		}
		if(query("fraglength")	!=$frag)	{set("fraglength", $frag);	$dirty++;}
		if(query("rtslength")	!=$rts)		{set("rtslength", $rts);	$dirty++;}
		if(query("txpower")	!=$power)		{set("txpower", $power);	$dirty++;}
		if(query("wmm/enable")	!=$wmm)		{set("wmm/enable", $wmm);	$dirty++;}
		if($cfg_ap_band == 0 ) //11g
		{
			if(query("acktimeout_g") != $ack_timeout)    {set("acktimeout_g", $ack_timeout);	$dirty++;}
		}
		else
		{
			if(query("acktimeout_a") != $ack_timeout)    {set("acktimeout_a", $ack_timeout);	$dirty++;}
		}	
		if(query("shortgi")	!=$shortgi)		{set("shortgi", $shortgi);	$dirty++;}

		if($cfg_ap_mode == 0) //access point
		{
			
			if(query("assoc_limit/enable")	!=$limit_state)	{set("assoc_limit/enable", $limit_state);	$dirty++;}
			if($limit_state == 1)
			{
				if(query("assoc_limit/number")	!=$limit_num)	{set("assoc_limit/number", $limit_num);	$dirty++;}		
				if(query("wlan_bytes_lim")	!=$utilization)			{set("wlan_bytes_lim", $utilization);	$dirty++;}			
			}
		}
		if($cfg_ap_mode != 1) //not apc		
		{
			if(query("beaconinterval")	!=$bi)	{set("beaconinterval", $bi);	$dirty++;}
			if(query("dtim")	!=$dtim)		{set("dtim", $dtim);	$dirty++;}
			if(query("igmpsnoop")	!=$igmp)		{set("igmpsnoop", $igmp);	$dirty++;}	
		}		
		if(query("mcastrate_a")	!=$f_mrate_a)	{set("mcastrate_a", $f_mrate_a);	$dirty++;}				
		if(query("mcastrate_g")	!=$f_mrate_g)	{set("mcastrate_g", $f_mrate_g);	$dirty++;}			
	}
	
	if($dirty > 0)
	{
		//$SUBMIT_STR="COMMIT";
			//$SUBMIT_STR="submit WLAN";	
		set("/runtime/web/submit/wlan", 1);	
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}	
	
	set("/runtime/web/next_page",$ACTION_POST);
	/*if($dirty > 0) {*/require($G_SAVING_URL);/*}
	else                  {require($G_NO_CHANGED_URL);}	*/
}

else if($ACTION_POST == "adv_mssid")
{
	echo "<!--\n";
	echo "f_mssid_del 	= ". $f_mssid_del  ."\n";
	echo "mssid_enable	= ". $mssid_enable  ."\n";
	echo "priority_enable	= ". $priority_enable  ."\n";
	echo "priority	= ". $priority  ."\n";
	echo "-->\n";
	//exit;
	$SUBMIT_STR = "";
	$dirty = 1;			
	
	$cfg_ap_band = query("/wlan/ch_mode");
	
	if($cfg_ap_band == 0 ) //11g
	{
		anchor("/wlan/inf:1");	
	}
	else
	{
		//anchor("/wlan/inf:2");
		anchor("/wlan/inf:1");
	}	
	if($f_mssid_del != "")
	{
		$dirty++;

		set("multi/index:".$f_mssid_del."/state",0);	
		
	}
	else if($f_add != "") //add
	{
		if($index != 0)
		{
			if(query("multi/state")	!= $mssid_enable)	{set("multi/state",	$mssid_enable);			$dirty++;}
		}
		if($mssid_enable == 1)
		{
			if(query("multi/state")	!= $mssid_enable)	{set("multi/state",	$mssid_enable);			$dirty++;}
			if($index == 0 && query("/runtime/web/display/priority") == 1)
			{
				if(query("multi/pri_by_ssid")	!= $priority_enable)	{set("multi/pri_by_ssid",	$priority_enable);			$dirty++;}
				if($priority_enable == 1)
				{
					if(query("pri_bit")	!= $priority)	{set("pri_bit",	$priority);			$dirty++;}	
				}
			}
			if(query("/runtime/web/display/mssid_support_sharedkey") == 0)//mssid not support Shared Key	
			{		
				if(query("authentication") == 1) //Shared Key
				{
					set("authentication", 0); $dirty++;//open
				}
			}
			
			if(query("ap_mode") == 1 || query("ap_mode") == 2 || query("ap_mode") == 4) // not access point, wds with ap
			{
				set("ap_mode", 0);$dirty++;
			}
		} 
		else
		{
			if(query("/sys/vlan_state") == 1)
			{
				set("/sys/vlan_state",	0);	$dirty++;	
			}
		}
				
		if($index != 0 && $mssid_enable == 1)
		{
			if(query("multi/index:".$index."/state")	!= 1)	{set("multi/index:".$index."/state",	1);			$dirty++;}	
			if(query("multi/index:".$index."/ssid")	!= $ssid)	{set("multi/index:".$index."/ssid",	$ssid);	$dirty++;}
			if(query("multi/index:".$index."/ssid_hidden")	!=$ap_hidden)	{set("multi/index:".$index."/ssid_hidden", $ap_hidden);	$dirty++;}
			if(query("multi/index:".$index."/auth")	!=$f_auth)	{set("multi/index:".$index."/auth", $f_auth);	$dirty++;}
			if(query("multi/pri_by_ssid")	!= $priority_enable)	{set("multi/pri_by_ssid",	$priority_enable);			$dirty++;}

			if(query("/runtime/web/display/priority") == 1 && $priority_enable == 1)
			{
				if(query("multi/index:".$index."/pri_bit")	!= $priority)	{set("multi/index:".$index."/pri_bit",	$priority);	$dirty++;}
			}
			if(query("multi/index:".$index."/wmm/enable")	!= $wmm)	{set("multi/index:".$index."/wmm/enable",	$wmm);	$dirty++;}
			if(query("multi/index:".$index."/cipher")	!=$f_cipher)	{set("multi/index:".$index."/cipher", $f_cipher);	$dirty++;}	
	
			if($f_auth == 0 || $f_auth == 1 || $f_auth == 8) //open, shared, both
			{
				if($f_cipher == 1)
				{
					if(query("multi/index:".$index."/wep_key_index")	!=$defkey)	{set("multi/index:".$index."/wep_key_index", $defkey);	$dirty++;}	
					
					if($defkey == 1)
					{
						if(query("wepkey:1/keylength")	!=$keysize)	{set("wepkey:1/keylength", $keysize);	$dirty++;}	
						if(query("wepkey:1/keyformat")	!=$keytype)	{set("wepkey:1/keyformat", $keytype);	$dirty++;}	
						if(query("wepkey:1")	!=$key)	{set("wepkey:1", $key);	$dirty++;}	
					}
					else if($defkey == 2)
					{
	
						if(query("wepkey:2/keylength")	!=$keysize)	{set("wepkey:2/keylength", $keysize);	$dirty++;}	
						if(query("wepkey:2/keyformat")	!=$keytype)	{set("wepkey:2/keyformat", $keytype);	$dirty++;}	
						if(query("wepkey:2")	!=$key)	{set("wepkey:2", $key);	$dirty++;}	
					}	
					else if($defkey == 3)
					{
						if(query("wepkey:3/keylength")	!=$keysize)	{set("wepkey:3/keylength", $keysize);	$dirty++;}	
						if(query("wepkey:3/keyformat")	!=$keytype)	{set("wepkey:3/keyformat", $keytype);	$dirty++;}	
						if(query("wepkey:3")	!=$key)	{set("wepkey:3", $key);	$dirty++;}	
					}
					else if($defkey == 4)
					{
						if(query("wepkey:4/keylength")	!=$keysize)	{set("wepkey:4/keylength", $keysize);	$dirty++;}	
						if(query("wepkey:4/keyformat")	!=$keytype)	{set("wepkey:4/keyformat", $keytype);	$dirty++;}	
						if(query("wepkey:4")	!=$key)	{set("wepkey:4", $key);	$dirty++;}	
					}	
															
				}			
			}
			else if($f_auth == 2 || $f_auth == 4 || $f_auth == 6 || $f_auth == 9) //eap or 802.1x
			{	
				if($f_auth != 9)	//802.1x don't have the follow settings
			        {	
				        if(query("multi/index:".$index."/interval")	!=$gkui)	{set("multi/index:".$index."/interval", $gkui);	$dirty++;}
                         	}
				else	//802.1x key update interval
				{
					if(query("multi/index:".$index."/d_wep_rekey_interval")	!=$kui)	{set("multi/index:".$index."/d_wep_rekey_interval", $kui);	$dirty++;}					
				}

				if(query("/runtime/web/display/local_radius_server") !="0") //Remote or Local RADIUS Server
				{							
					if(query("multi/index:".$index."/embradius_state")	!= $radius_type)	{set("multi/index:".$index."/embradius_state", $radius_type);}
				}
                if($radius_type == 0 || $f_radius_type == ""){
				if(query("multi/index:".$index."/radius_server")	!=$radius_srv_1)	{set("multi/index:".$index."/radius_server", $radius_srv_1);	$dirty++;}	
				if(query("multi/index:".$index."/radius_port")	!=$radius_port_1)	{set("multi/index:".$index."/radius_port", $radius_port_1);	$dirty++;}	
				if(query("multi/index:".$index."/radius_secret")	!=$radius_sec_1)	{set("multi/index:".$index."/radius_secret", $radius_sec_1);	$dirty++;}	
				if(query("/runtime/web/display/backup_radius_server") !="0")
				{
					if(query("multi/index:".$index."/b_radius_server")	!=$radius_srv_2)	{set("multi/index:".$index."/b_radius_server", $radius_srv_2);	$dirty++;}	
					if(query("multi/index:".$index."/b_radius_port")	!=$radius_port_2)	{set("multi/index:".$index."/b_radius_port", $radius_port_2);	$dirty++;}	
					if(query("multi/index:".$index."/b_radius_secret")	!=$radius_sec_2)	{set("multi/index:".$index."/b_radius_secret", $radius_sec_2);	$dirty++;}	
				}	
				
				if(query("/runtime/web/display/accounting_server") != "0")
				{
					if(query("multi/index:".$index."/acct_state")	!=$acc_mode)	{set("multi/index:".$index."/acct_state", $acc_mode);	$dirty++;}	
					if($acc_mode == 1)
					{
						if(query("multi/index:".$index."/acct_server")	!=$acc_srv_1)	{set("multi/index:".$index."/acct_server", $acc_srv_1);	$dirty++;}	
						if(query("multi/index:".$index."/acct_port")	!=$acc_port_1)	{set("multi/index:".$index."/acct_port", $acc_port_1);	$dirty++;}	
						if(query("multi/index:".$index."/acct_secret")	!=$acc_sec_1)	{set("multi/index:".$index."/acct_secret", $acc_sec_1);	$dirty++;}	
						if(query("multi/index:".$index."/b_acct_server")	!=$acc_srv_2)	{set("multi/index:".$index."/b_acct_server", $acc_srv_2);	$dirty++;}	
						if(query("multi/index:".$index."/b_acct_port")	!=$acc_port_2)	{set("multi/index:".$index."/b_acct_port", $acc_port_2);	$dirty++;}	
						if(query("multi/index:".$index."/b_acct_secret")	!=$acc_sec_2)	{set("multi/index:".$index."/b_acct_secret", $acc_sec_2);	$dirty++;}					
					}	
				}				
			}	
			}	
			else //psk
			{
	
				if(query("multi/index:".$index."/interval")	!=$gkui)	{set("multi/index:".$index."/interval", $gkui);	$dirty++;}
				if(query("multi/index:".$index."/passphrase")	!=$passphrase)	{set("multi/index:".$index."/passphrase", $passphrase);	$dirty++;}		
			    if(query("/runtime/web/display/autorekey")==1)
                {
				if(query("multi/index:".$index."/autorekey/enable")	!=$f_enable_rekey)	{set("multi/index:".$index."/autorekey/enable", $f_enable_rekey);	$dirty++;}		
				if(query("autorekey/time")	!=$f_time_interuol)	{set("autorekey/time", $f_time_interuol);	$dirty++;}
			    	if(query("autorekey/starttime")	!=$f_start_time)	{set("autorekey/starttime", $f_start_time);	$dirty++;}		
			    	if(query("autorekey/startweek")	!=$f_start_week)	{set("autorekey/startweek", $f_start_week);	$dirty++;}		
			    }
			}	
		}	
	}		
	else
	{
		if(query("multi/state")	!= $mssid_enable)	{set("multi/state",	$mssid_enable);			$dirty++;}

		if($mssid_enable == 1)
		{	
			$dirty++;
			if(query("/runtime/web/display/priority") == 1)
			{
				if(query("multi/pri_by_ssid")	!= $priority_enable)	{set("multi/pri_by_ssid",	$priority_enable);			$dirty++;}
			}
			if(query("/runtime/web/display/mssid_support_sharedkey") == 0)//mssid not support Shared Key	
			{				
				if(query("authentication") == 1) //Shared Key
				{
					set("authentication", 0); $dirty++;//open
				}
			}
			
			if(query("ap_mode") == 1 || query("ap_mode") == 2 || query("ap_mode") == 4) // not access point, wds with ap
			{
				set("ap_mode", 0);$dirty++;
			}
		} 
		else
		{
			if(query("/sys/vlan_state") == 1)
			{
				set("/sys/vlan_state",	0);	$dirty++;	
			}
		}
	}
		
	if($dirty > 0)
	{
		if($f_add != "" || $f_mssid_del != "")
		{
			//$SUBMIT_STR="COMMIT";
			for("multi/index")
			{
				if(query("autorekey/enable")=="1")
				{
					set("/runtime/web/msg_autorekey", "display");
				}
			}
			set("/runtime/web/submit/commit",1);
		}
		else
		{
			//$SUBMIT_STR="submit WLAN";
			set("/runtime/web/submit/wlan", 1);
		}
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}	
	
	set("/runtime/web/next_page",$ACTION_POST);
	/*if($dirty > 0) {*/require($G_SAVING_URL);/*}
	else                  {require($G_NO_CHANGED_URL);}	*/
}

else if($ACTION_POST == "adv_partition")
{
	echo "<!--\n";
	echo "isc	= ". $isc  ."\n";
	echo "isc1	= ". $f_isc1  ."\n";
	echo "isc2	= ". $f_isc2  ."\n";
	echo "isc3	= ". $f_isc3 ."\n";
	echo "isc4	= ". $f_isc4."\n";
	echo "isc5	= ". $f_isc5  ."\n";
	echo "isc6	= ". $f_isc6  ."\n";
	echo "isc7	= ". $f_isc7 ."\n";
	echo "ewa	= ". $ewa  ."\n";
	echo "-->\n";	
	
	$SUBMIT_STR = "";
	$dirty = 0;		
	
	$cfg_ap_band = query("/wlan/ch_mode");
	
	if($cfg_ap_band == 0 ) //11g
	{
		anchor("/wlan/inf:1");	
	}
	else
	{
		//anchor("/wlan/inf:2");
		anchor("/wlan/inf:1");
	}	
	if(query("ethlink") != $link_integrality)    {set("ethlink", $link_integrality);	$dirty++;}
	if(query("w_partition")	!=$f_isc)	{set("w_partition", $f_isc);			$dirty++;}
	if(query("multi/index:1/w_partition")	!=$f_isc1)	{set("multi/index:1/w_partition", $f_isc1);			$dirty++;}
	if(query("multi/index:2/w_partition")	!=$f_isc2)	{set("multi/index:2/w_partition", $f_isc2);			$dirty++;}
	if(query("multi/index:3/w_partition")	!=$f_isc3)	{set("multi/index:3/w_partition", $f_isc3);			$dirty++;}
	if(query("multi/index:4/w_partition")	!=$f_isc4)	{set("multi/index:4/w_partition", $f_isc4);			$dirty++;}
	if(query("multi/index:5/w_partition")	!=$f_isc5)	{set("multi/index:5/w_partition", $f_isc5);			$dirty++;}
	if(query("multi/index:6/w_partition")	!=$f_isc6)	{set("multi/index:6/w_partition", $f_isc6);			$dirty++;}
	if(query("multi/index:7/w_partition")	!=$f_isc7)	{set("multi/index:7/w_partition", $f_isc7);			$dirty++;}
	if(query("e_partition")	!=$ewa)	{set("e_partition", $ewa);			$dirty++;}
	
	if($dirty > 0)
	{
		
			//$SUBMIT_STR="submit WLAN";	
		set("/runtime/web/submit/wlan", 1);		
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}	
	
	set("/runtime/web/next_page",$ACTION_POST);
	/*if($SUBMIT_STR != "") {*/require($G_SAVING_URL);/*}
	else                  {require($G_NO_CHANGED_URL);}	*/
}
else if($ACTION_POST == "adv_acl")
{
	echo "<!--\n";
	echo "acl_type	= ". $acl_type  ."\n";
	echo "f_acl_del	= ". $f_acl_del  ."\n";
	echo "-->\n";	
	
	$SUBMIT_STR = "";
	$dirty = 1;		
	
	$cfg_ap_band = query("/wlan/ch_mode");
	
	if($cfg_ap_band == 0 ) //11g
	{
		anchor("/wlan/inf:1");	
	}
	else
	{
		//anchor("/wlan/inf:2");
		anchor("/wlan/inf:1");
	}
		
	if($f_acl_del!="")//del
	{
		$dirty++;
		$acl_entry = 0;
		for("acl/mac"){$acl_entry++;}
		if($acl_entry== 1)
		{
			set("acl/mode", 0);		
		}	
		del("acl/mac:".$f_acl_del);	
	}	
	else if($f_client_info_mac_add != "")
	{
		$dirty++;
		set("acl/mode", 2);		
		$acl_num=1;
		for("acl/mac"){$acl_num++;}
		if(query("acl/mac:".$acl_num)	!=$hacl_mac)	{set("acl/mac:".$acl_num,	$hacl_mac);		$dirty++;}				
	}	
	else if($f_add != "") //add
	{
		if(query("acl/mode")	!=$acl_type)	
		{
			set("acl/mode", $acl_type);	
			if($acl_type!=2)
			{
			//	set("zonedefence",0);/*close zone defence*/
			}
			$dirty++;
		}				
		
		if($acl_type != 0 && $hacl_mac != 0)
		{
			$acl_num=1;
			for("acl/mac"){$acl_num++;}
			if(query("acl/mac:".$acl_num)	!=$hacl_mac)	{set("acl/mac:".$acl_num,	$hacl_mac);		$dirty++;}				
		}
	}
	else //apply
	{
		if(query("acl/mode")	!=$acl_type)	
		{
			set("acl/mode", $acl_type);	
			if($acl_type!=2)
			{
			//	set("zonedefence",0);/*close zone defence*/
			}
			$dirty++;
		}				
	}
	
	if($dirty > 0)
	{
		if($f_add != "" || $f_client_info_mac_add != "" || $f_acl_del!="")
		{
			//$SUBMIT_STR= "COMMIT";
			set("/runtime/web/submit/commit",1);
		}
		else
		{
			//$SUBMIT_STR="submit WLAN";
			set("/runtime/web/submit/wlan", 1);
		}
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}	
	
	set("/runtime/web/next_page",$ACTION_POST);
	/*if($dirty > 0) {*/require($G_SAVING_URL);/*}
	else                  {require($G_NO_CHANGED_URL);}	*/
}
else if($ACTION_POST == "adv_schedule")
{
	echo "<!--\n";

	echo "-->\n";		

	$SUBMIT_STR = "";
	$dirty = 0;		
	
	anchor("/schedule");

	if($f_entry_del!="")
	{
		$dirty++;
		del("rule/index:".$f_entry_del);	
		/*$i=1;
		for("/schedule/rule/index")
		{
			set("/schedule/rule/index:".$i."/enable", 0);
			$i++;
		}
		$i--;
		set("rule/index:".$i."/enable", 1);$dirty++;*/
	}
	else
	{
		
		if($f_add_value != "")
		{
			if($entry_edit !="")
	{
		
				/*$i = 1;
		for("/schedule/rule/index")
		{
			set("/schedule/rule/index:".$i."/enable", 0);
			$i++;
					}*/
				//	$schedule_index="schedule_index".$entry_edit;
		set("rule/index:".$entry_edit."/enable", 1);$dirty++;
				if(query("rule/index:".$entry_edit."/ssidnum")	!= $index)	{set("rule/index:".$entry_edit."/ssidnum",	$index);	$dirty++;}
		if(query("rule/index:".$entry_edit."/name")	!= $name)	{set("rule/index:".$entry_edit."/name",	$name);	$dirty++;}
		if(query("rule/index:".$entry_edit."/sun")	!= $sun)	{set("rule/index:".$entry_edit."/sun",	$sun);	$dirty++;}
		if(query("rule/index:".$entry_edit."/mon")	!= $mon)	{set("rule/index:".$entry_edit."/mon",	$mon);	$dirty++;}
		if(query("rule/index:".$entry_edit."/tue")	!= $tue)	{set("rule/index:".$entry_edit."/tue",	$tue);	$dirty++;}
		if(query("rule/index:".$entry_edit."/wed")	!= $wed)	{set("rule/index:".$entry_edit."/wed",	$wed);	$dirty++;}
		if(query("rule/index:".$entry_edit."/thu")	!= $thu)	{set("rule/index:".$entry_edit."/thu",	$thu);	$dirty++;}
		if(query("rule/index:".$entry_edit."/fri")	!= $fri)	{set("rule/index:".$entry_edit."/fri",	$fri);	$dirty++;}
		if(query("rule/index:".$entry_edit."/sat")	!= $sat)	{set("rule/index:".$entry_edit."/sat",	$sat);	$dirty++;}

		if(query("rule/index:".$entry_edit."/allday")	!= $all_day)	{set("rule/index:".$entry_edit."/allday",	$all_day);	$dirty++;}

		if($all_day != 1)
		{
			if(query("rule/index:".$entry_edit."/starttime")	!= $f_start_time)	{set("rule/index:".$entry_edit."/starttime",	$f_start_time);	$dirty++;}
			if(query("rule/index:".$entry_edit."/endtime")	!= $f_end_time)	{set("rule/index:".$entry_edit."/endtime",	$f_end_time);	$dirty++;}
			if(query("rule/index:".$entry_edit."/overnight")  != $overnight) {set("rule/index:".$entry_edit."/overnight",  $overnight);$dirty++;}
		}
				//if(query("rule/index:".$entry_edit."/wirelesson")	!= $wireless)	{set("rule/index:".$entry_edit."/wirelesson",	$wireless);	$dirty++;}
	}
			else
	{
		$dirty++;
		set("enable",	1);	
		
		$i = 1;
		for("/schedule/rule/index")
		{
							/*set("/schedule/rule/index:".$i."/enable", 0);*/
			$i++;
		}
		set("rule/index:".$i."/enable", 1);
		set("rule/index:".$i."/ssidnum", $index);
		set("rule/index:".$i."/name", $name);
		set("rule/index:".$i."/sun", $sun);
		set("rule/index:".$i."/mon", $mon);
		set("rule/index:".$i."/tue", $tue);
		set("rule/index:".$i."/wed", $wed);
		set("rule/index:".$i."/thu", $thu);
		set("rule/index:".$i."/fri", $fri);
		set("rule/index:".$i."/sat", $sat);
		set("rule/index:".$i."/allday", $all_day);	
		
		if($all_day != 1)
		{
			set("rule/index:".$i."/starttime", $f_start_time);	
			set("rule/index:".$i."/endtime", $f_end_time);	
			set("rule/index:".$i."/overnight", $overnight);
		}
				set("rule/index:".$i."/wirelesson", 1);
	
	}
		}
		else
		{
			if(query("enable")	!= $schedule_status)	{set("enable",	$schedule_status);	$dirty++;}
			for("/schedule/rule/index")
			{
				$schedule_index	= "schedule_index".$@;
				if(query("enable")	!= $$schedule_index)	{set("enable",$$schedule_index);	$dirty++;}
			
				/*if($f_sce_idx == $@)
				{
					set("/schedule/rule/index:".$@."/enable", 1);$dirty++;
				}
				else
				{
					set("/schedule/rule/index:".$@."/enable", 0);$dirty++;
				}*/
			}
		}
	}
	if($dirty > 0)
	{
		
		//$SUBMIT_STR="submit WLAN";
		set("/runtime/web/submit/wlan", 1);
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}	
	
	set("/runtime/web/next_page",$ACTION_POST);
	/*if($dirty > 0) {*/require($G_SAVING_URL);/*}
	else                  {require($G_NO_CHANGED_URL);}		*/
}
else if($ACTION_POST == "adv_qos")
{
	echo "<!--\n";
	echo "ACTION_POST=".			$ACTION_POST.			"\n";
	echo "f_qos_enable=".			$f_qos_enable.			"\n";
	echo "http=".					$http.				"\n";
	echo "auto=".					$auto.				"\n";
	echo "rule_enable=".			$rule_enable.			"\n";
	echo "name=".					$name.				"\n";
	echo "priority=".				$priority.			"\n";
	echo "protocol=".				$protocol.			"\n";
	echo "protocol_select=".		$protocol_select.		"\n";
	echo "-->\n";	
//	exit;
	$SUBMIT_STR = "";
	$dirty = 0;		
	if($f_rule_del!="")
	{
		del("/qos/rule/index:".$f_rule_del);
		$dirty++;
	}
	else
	{
		if(query("/qos/enable")!=$f_qos_enable)	{set("/qos/enable",$f_qos_enable); $dirty++;}
		if(query("/qos/rule/enable")!=$f_qos_enable)	{set("/qos/rule/enable",$f_qos_enable); $dirty++;}

		if($f_qos_enable=="1")
		{
			if(query("/qos/classifiers/http")!=$http)	{set("/qos/classifiers/http",$http); $dirty++;}
			if(query("/qos/classifiers/auto")!=$auto)	{set("/qos/classifiers/auto",$auto); $dirty++;}

			$i=0;
			$qos_rule = 0;
			for("/qos/rule/index")
			{
				$qos_rule++;
			}		
			while($i< $qos_rule)
			{
				$index=$i+1;
				$rule_state	= "rule_state".$index;
				if(query("index:".$index."/state")!=$$rule_state){set("index:".$index."/state",$$rule_state);	$dirty++;}
				$i++;	
			}

			$qos_num=1;
			if($rule_edit !="")
			{
				$qos_num=$rule_edit;
			}
			else if($f_add == "1" && $rule_edit =="")
			{		
				for("/qos/rule/index"){$qos_num++;}
			}
			
			anchor("/qos/rule");
			if($f_add == "1")
			{
				set("/qos/rule/index:".$qos_num."/state",1);	$dirty++;
				if(query("index:".$qos_num."/name")!=$name){set("index:".$qos_num."/name",$name);	$dirty++;}
				if(query("index:".$qos_num."/priority")!=$priority){set("index:".$qos_num."/priority",$priority);	$dirty++;}
				if(query("index:".$qos_num."/protocol")!=$protocol){set("index:".$qos_num."/protocol",$protocol);	$dirty++;}
				if(query("index:".$qos_num."/protocoltype")!=$protocol_select){set("index:".$qos_num."/protocoltype",$protocol_select);	$dirty++;}
				if(query("index:".$qos_num."/host1/startip")!=$host_1_ip_s){set("index:".$qos_num."/host1/startip",$host_1_ip_s);	$dirty++;}
				if(query("index:".$qos_num."/host1/endip")!=$host_1_ip_e){set("index:".$qos_num."/host1/endip",$host_1_ip_e);	$dirty++;}
				if(query("index:".$qos_num."/host1/iprange")!=$f_host_1_ip_r){set("index:".$qos_num."/host1/iprange",$f_host_1_ip_r);	$dirty++;}
				if(query("index:".$qos_num."/host2/startip")!=$host_2_ip_s){set("index:".$qos_num."/host2/startip",$host_2_ip_s);	$dirty++;}
				if(query("index:".$qos_num."/host2/endip")!=$host_2_ip_e){set("index:".$qos_num."/host2/endip",$host_2_ip_e);	$dirty++;}
				if(query("index:".$qos_num."/host2/iprange")!=$f_host_2_ip_r){set("index:".$qos_num."/host2/iprange",$f_host_2_ip_r);	$dirty++;}
	
				if($protocol_select == "1" || $protocol_select == "2" || $protocol_select == "3")
				{
					if(query("index:".$qos_num."/host1/startport")!=$host_1_port_s){set("index:".$qos_num."/host1/startport",$host_1_port_s);	$dirty++;}
					if(query("index:".$qos_num."/host1/endport")!=$host_1_port_e){set("index:".$qos_num."/host1/endport",$host_1_port_e);	$dirty++;}
					if(query("index:".$qos_num."/host1/portrange")!=$f_host_1_port_r){set("index:".$qos_num."/host1/portrange",$f_host_1_port_r);	$dirty++;}
					if(query("index:".$qos_num."/host2/startport")!=$host_2_port_s){set("index:".$qos_num."/host2/startport",$host_2_port_s);	$dirty++;}
					if(query("index:".$qos_num."/host2/endport")!=$host_2_port_e){set("index:".$qos_num."/host2/endport",$host_2_port_e);	$dirty++;}
					if(query("index:".$qos_num."/host2/portrange")!=$f_host_2_port_r){set("index:".$qos_num."/host2/portrange",$f_host_2_port_r);	$dirty++;}
				}
			}
		}
	}	

	if($dirty > 0)
	{
		//$SUBMIT_STR= "COMMIT";
		//$SUBMIT_STR="submit QOS";
		set("/runtime/web/submit/qos", 1);
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}	

	
	set("/runtime/web/next_page",$ACTION_POST);
	/*if($dirty > 0) {*/require($G_SAVING_URL);/*}
	else                  {require($G_NO_CHANGED_URL);}	*/	
}
else if($ACTION_POST == "adv_8021q")
{
	echo "<!--\n";
	echo "ACTION_POST=".			$ACTION_POST.			"\n";
	echo "f_vlan=".			$f_vlan.			"\n";
	echo "f_rule_del=".			$f_rule_del.			"\n";
	echo "-->\n";	
	
	$SUBMIT_STR = "";
	$dirty = 0;		
	$dirty_wlan = 0;	
	$limit_dirty = 0;
	
	if(query("/sys/vlan_state")!=$f_vlan)	
	{
		set("/sys/vlan_state",$f_vlan); 
		if (query("/sys/vlan_mode")!= 1) 
		{
			$dirty++;
		}
		else
		{
			$dirty++;
			$dirty_wlan++;
		}
		if($f_vlan == 1)
		{
			if(query("/sys/adminlimit/status")==1){set("/sys/adminlimit/status", 0);$limit_dirty++;}/*limit_admin_status*/
			if(query("/sys/adminlimit/status")==3){set("/sys/adminlimit/status", 2);$limit_dirty++;}/*limit_admin_status*/
		}
	}
	if($f_vlan == 1)
	{
		if(query("/wlan/inf:1/multi/state") != 1 )
		{
			set("/wlan/inf:1/multi/state",	1);	
			$dirty_wlan++;
		}
	
		if(query("/runtime/web/display/mssid_support_sharedkey") == 0)//mssid not support Shared Key	
		{			
			if(query("/wlan/inf:1/authentication") == 1) //Shared Key
			{
				set("/wlan/inf:1/authentication", 0); //open
				$dirty_wlan++;
			}
		}	
		
		if(query("/wlan/inf:1/ap_mode") == 1 || query("/wlan/inf:1/ap_mode") == 2 || query("/wlan/inf:1/ap_mode") == 4) // not access point, wds with ap
		{
			set("/wlan/inf:1/ap_mode", 0);
			$dirty_wlan++;
		}	
		
		if($dirty_wlan != 0)	
		{
			set("/runtime/web/check/vlan/mssid_enable", 1);
		}
	}
	
	if($f_vlan == 1)
	{
		if($f_rule_del!="")
		{
			$dirty++;
			if(query("/sys/group_vlan/index:".$f_rule_del."/sys:1/egress") == 2 && $f_pvid_auto == 1)
			{
				if(query("/sys/vlan_id") == query("/sys/group_vlan/index:".$f_rule_del."/group_vid"))
				{
					$del_admin_vid = 1;
					for("/sys/group_vlan/index")
					{
						if($@!=$f_rule_del)
						{
							if(query("/sys/group_vlan/index:".$@."/sys:1/egress") == 2)
							{
								$del_admin_vid = query("/sys/group_vlan/index:".$@."/group_vid");
							}
						}
					}
					set("/sys/vlan_id",$del_admin_vid);$dirty++;
				}
			}
					
			if(query("/sys/group_vlan/index:".$f_rule_del."/eth:1/egress") == 2 && $f_pvid_auto == 1)
			{
				if(query("/lan/ethernet/vlan_id") == query("/sys/group_vlan/index:".$f_rule_del."/group_vid"))
				{
					$del_eth_vid = 1;
					for("/sys/group_vlan/index")
					{
						if($@!=$f_rule_del)
						{
							if(query("/sys/group_vlan/index:".$@."/eth:1/egress") == 2)
							{
								$del_eth_vid = query("/sys/group_vlan/index:".$@."/group_vid");
							}
						}
					}
					set("/lan/ethernet/vlan_id",$del_eth_vid);$dirty++;
				}
			}	
			
			$del_ath_idx = 1;
			while($del_ath_idx < 17)
			{
				if(query("/sys/group_vlan/index:".$f_rule_del."/ath:".$del_ath_idx."/egress") == 2 && $f_pvid_auto == 1)
				{	
					if($del_ath_idx == 1)
					{
						if(query("/wlan/inf:1/vlan_id") == query("/sys/group_vlan/index:".$f_rule_del."/group_vid"))
						{
							$del_ath_vid = 1;
							for("/sys/group_vlan/index")
							{
								if($@!=$f_rule_del)
								{
									if(query("/sys/group_vlan/index:".$@."/ath:1/egress") == 2)
									{
										$del_ath_vid = query("/sys/group_vlan/index:".$@."/group_vid");
									}
								}
							}
							set("/wlan/inf:1/vlan_id",$del_ath_vid);$dirty++;
						}
					}
					else if($del_ath_idx > 1 && $del_ath_idx < 9)
					{
						$multi_idx = $del_ath_idx - 1;
						
						if(query("/wlan/inf:1/multi/index:".$multi_idx."/vlan_id") == query("/sys/group_vlan/index:".$f_rule_del."/group_vid"))
						{
							$del_ath_vid = 1;
							for("/sys/group_vlan/index")
							{
								if($@!=$f_rule_del)
								{
									if(query("/sys/group_vlan/index:".$@."/ath:".$del_ath_idx."/egress") == 2)
									{
										$del_ath_vid = query("/sys/group_vlan/index:".$@."/group_vid");
									}
								}
							}
							set("/wlan/inf:1/multi/index:".$multi_idx."/vlan_id",$del_ath_vid);$dirty++;
						}						
					}
					else if($del_ath_idx > 8 && $del_ath_idx < 17)
					{
						$w_index = $del_ath_idx - 8;
						
						if(query("/wlan/inf:1/wds/index:".$w_index."/vlan_id") == query("/sys/group_vlan/index:".$f_rule_del."/group_vid"))
						{
							$del_ath_vid = 1;
							for("/sys/group_vlan/index")
							{
								if($@!=$f_rule_del)
								{
									if(query("/sys/group_vlan/index:".$@."/ath:".$del_ath_idx."/egress") == 2)
									{
										$del_ath_vid = query("/sys/group_vlan/index:".$@."/group_vid");
									}
								}
							}
							set("/wlan/inf:1/wds/index:".$w_index."/vlan_id",$del_ath_vid);$dirty++;
						}						
					}					
				}					
				$del_ath_idx++;
			}

			del("/sys/group_vlan/index:".$f_rule_del);	
		}				
		if($f_apply =="rule_add")
		{
			$index=1;
			
			if($f_rule_edit !="")
			{
				$index = $f_rule_edit;
			}
			else
			{
				for("/sys/group_vlan/index")
				{
					$index++;
				}
			}	

			if($f_rule_edit =="")
			{
				if(query("/sys/group_vlan/index:".$index."/group_vid")!=$f_vid)	{set("/sys/group_vlan/index:".$index."/group_vid",$f_vid); $dirty++;}
			}
			if(query("/sys/group_vlan/index:".$index."/group_name")!=$f_ssid)	{set("/sys/group_vlan/index:".$index."/group_name",$f_ssid); $dirty++;}
			
			if(query("/sys/group_vlan/index:".$index."/sys:1/egress")!=$f_sys_egress)	{set("/sys/group_vlan/index:".$index."/sys:1/egress",$f_sys_egress); $dirty++;}
			
			if($f_pvid_auto == 1)
			{
				if($f_sys_egress == 2)
				{	
					set("/sys/vlan_id",$f_vid);$dirty++;
				}
				else if($f_sys_egress != 2 && $f_rule_edit !="")
				{
					if(query("/sys/vlan_id") == query("/sys/group_vlan/index:".$f_rule_edit."/group_vid"))
					{
						$edit_admin_vid = 1;
						for("/sys/group_vlan/index")
						{
							if($@!=$f_rule_edit)
							{
								if(query("/sys/group_vlan/index:".$@."/sys:1/egress") == 2)
								{
									$edit_admin_vid = query("/sys/group_vlan/index:".$@."/group_vid");
								}
							}
						}
						set("/sys/vlan_id",$edit_admin_vid);$dirty++;						
					}
				}
			}
						
			if(query("/sys/group_vlan/index:".$index."/eth:1/egress")!=$f_eth_egress)	{set("/sys/group_vlan/index:".$index."/eth:1/egress",$f_eth_egress); $dirty++;}
			
			if($f_pvid_auto == 1)
			{
				if($f_eth_egress == 2)
				{
					set("/lan/ethernet/vlan_id",$f_vid);$dirty++;
				}	
				else if($f_sys_egress != 2 && $f_rule_edit !="")
				{
					if(query("/lan/ethernet/vlan_id") == query("/sys/group_vlan/index:".$f_rule_edit."/group_vid"))
					{
						$edit_eth_vid = 1;
						for("/sys/group_vlan/index")
						{
							if($@!=$f_rule_edit)
							{
								if(query("/sys/group_vlan/index:".$@."/eth:1/egress") == 2)
								{
									$edit_eth_vid = query("/sys/group_vlan/index:".$@."/group_vid");
								}
							}
						}
						set("/lan/ethernet/vlan_id",$edit_eth_vid);$dirty++;
					}
				}					
			}			
			
			$ath_idx = 1;
			$ssid_flag=query("/runtime/web/display/mssid_index4");
			$flag=5;
			while($ath_idx< 17)
			{
				if ($ssid_flag=="1")
				{
					if($ath_idx==5)
					{
						$ath_idx=$ath_idx+4;
						while($flag <= 12 )
						{
							set("/sys/group_vlan/index:".$index."/ath:".$flag."/egress",1);
							$flag++;
						}
					}
				$ath_egress	= "f_ath".$ath_idx."_egress";
				if(query("/sys/group_vlan/index:".$index."/ath:".$ath_idx."/egress")!=$$ath_egress)	{set("/sys/group_vlan/index:".$index."/ath:".$ath_idx."/egress",$$ath_egress); $dirty++;}
				}
				else
				{
				$ath_egress	= "f_ath".$ath_idx."_egress";
				if(query("/sys/group_vlan/index:".$index."/ath:".$ath_idx."/egress")!=$$ath_egress)	{set("/sys/group_vlan/index:".$index."/ath:".$ath_idx."/egress",$$ath_egress); $dirty++;}
				}
				if(query("/sys/group_vlan/index:".$index."/ath:".$ath_idx."/egress")!=$$ath_egress)	{set("/sys/group_vlan/index:".$index."/ath:".$ath_idx."/egress",$$ath_egress); $dirty++;}
				
				if($f_pvid_auto == 1)
				{
					if($$ath_egress == 2)
					{
						if($ath_idx == 1)
						{
							set("/wlan/inf:1/vlan_id",$f_vid); $dirty++;
						}
						else if($ath_idx > 1 && $ath_idx < 9)
						{
							$ms_idx = $ath_idx-1;
							set("/wlan/inf:1/multi/index:".$ms_idx."/vlan_id",$f_vid); $dirty++;
						}
						else if($ath_idx > 8 && $ath_idx < 17)
						{
							$wds_idx = $ath_idx-8;
							set("/wlan/inf:1/wds/index:".$wds_idx."/vlan_id",$f_vid); $dirty++;
						}
					}
					else if($$ath_egress != 2 && $f_rule_edit !="")
					{
						if($ath_idx == 1)
						{
							if(query("/wlan/inf:1/vlan_id") == query("/sys/group_vlan/index:".$f_rule_edit."/group_vid"))
							{
								$edit_ath_vid = 1;
								for("/sys/group_vlan/index")
								{
									if($@!=$f_rule_edit)
									{
										if(query("/sys/group_vlan/index:".$@."/ath:1/egress") == 2)
										{
											$edit_ath_vid = query("/sys/group_vlan/index:".$@."/group_vid");
										}
									}
								}
								set("/wlan/inf:1/vlan_id",$edit_ath_vid);$dirty++;
							}
						}	
						else if($ath_idx > 1 && $ath_idx < 9)
						{
							$multi_idx = $ath_idx - 1;
							if(query("/wlan/inf:1/multi/index:".$multi_idx."/vlan_id") == query("/sys/group_vlan/index:".$f_rule_edit."/group_vid"))
							{
								$edit_ath_vid = 1;
								for("/sys/group_vlan/index")
								{
									if($@!=$f_rule_edit)
									{
										if(query("/sys/group_vlan/index:".$@."/ath:".$ath_idx."/egress") == 2)
										{
											$edit_ath_vid = query("/sys/group_vlan/index:".$@."/group_vid");
										}
									}
								}
								set("/wlan/inf:1/multi/index:".$multi_idx."/vlan_id",$edit_ath_vid);$dirty++;
							}								
						}	
						else if($ath_idx > 8 && $ath_idx < 17)
						{						
							$w_index = $ath_idx - 8;								
							if(query("/wlan/inf:1/wds/index:".$w_index."/vlan_id") == query("/sys/group_vlan/index:".$f_rule_edit."/group_vid"))
							{
								$edit_ath_vid = 1;
								for("/sys/group_vlan/index")
								{
									if($@!=$f_rule_edit)
									{
										if(query("/sys/group_vlan/index:".$@."/ath:".$ath_idx."/egress") == 2)
										{
											$edit_ath_vid = query("/sys/group_vlan/index:".$@."/group_vid");
										}
									}
								}
								set("/wlan/inf:1/wds/index:".$w_index."/vlan_id",$edit_ath_vid);$dirty++;
							}								
						}										
					}				
				}					
				if ($ssid_flag=="1")
				{
					if($ath_idx==12)
					{
						$ath_idx+=4;	
					}		
				}
				$ath_idx++;
			}
		}

		if($f_apply =="rule")
		{
			$dirty++;
		}

		if($f_apply =="pvid")
		{
			$dirty++;
			if(query("/sys/auto_set_pvid")!=$f_pvid_auto)	{set("/sys/auto_set_pvid",$f_pvid_auto); $dirty++;}
	
			if($f_pvid_auto == 0)
			{
				if(query("/sys/vlan_id")!=$f_admin_pvid)	{set("/sys/vlan_id",$f_admin_pvid); $dirty++;}
				if(query("/lan/ethernet/vlan_id")!=$f_eth_pvid)	{set("/lan/ethernet/vlan_id",$f_eth_pvid); $dirty++;}
				if(query("/wlan/inf:1/vlan_id")!=$f_pri_pvid)	{set("/wlan/inf:1/vlan_id",$f_pri_pvid); $dirty++;}
					
				$ms_index = 1;
				while($ms_index< 9)
				{
					$ms_pvid_value	= "f_ms_".$ms_index."_pvid";
					if(query("/wlan/inf:1/multi/index:".$ms_index."/vlan_id")!=$$ms_pvid_value)	{set("/wlan/inf:1/multi/index:".$ms_index."/vlan_id",$$ms_pvid_value); $dirty++;}
					$ms_index++;
				}
				
				$wds_index = 1;
				while($wds_index< 9)
				{
					$wds_pvid_value	= "f_wds_".$wds_index."_pvid";
					if(query("/wlan/inf:1/wds/index:".$wds_index."/vlan_id")!=$$wds_pvid_value)	{set("/wlan/inf:1/wds/index:".$wds_index."/vlan_id",$$wds_pvid_value); $dirty++;}
					$wds_index++;
				}
			}
			else
			{
				$pvid_auto_admin_vid = 1;
				for("/sys/group_vlan/index")
				{
					if(query("/sys/group_vlan/index:".$@."/sys:1/egress") == 2)
					{
						$pvid_auto_admin_vid = query("/sys/group_vlan/index:".$@."/group_vid");
					}
				}
				set("/sys/vlan_id",$pvid_auto_admin_vid);$dirty++;
					

				$del_eth_vid = 1;
				for("/sys/group_vlan/index")
				{
					if(query("/sys/group_vlan/index:".$@."/eth:1/egress") == 2)
					{
						$del_eth_vid = query("/sys/group_vlan/index:".$@."/group_vid");
					}
				}
				set("/lan/ethernet/vlan_id",$del_eth_vid);$dirty++;
				
				$pvid_auto_ath_idx = 1;
				while($pvid_auto_ath_idx < 17)
				{
					if($pvid_auto_ath_idx == 1)
					{
						$pvid_auto_ath_vid = 1;
						for("/sys/group_vlan/index")
						{
							if(query("/sys/group_vlan/index:".$@."/ath:1/egress") == 2)
							{
								$pvid_auto_ath_vid = query("/sys/group_vlan/index:".$@."/group_vid");
							}
						}
						set("/wlan/inf:1/vlan_id",$pvid_auto_ath_vid);$dirty++;
					}
					else if($pvid_auto_ath_idx > 1 && $pvid_auto_ath_idx < 9)
					{
						$multi_idx = $pvid_auto_ath_idx - 1;
						$pvid_auto_ath_vid = 1;
						for("/sys/group_vlan/index")
						{
							if(query("/sys/group_vlan/index:".$@."/ath:".$pvid_auto_ath_idx."/egress") == 2)
							{
								$pvid_auto_ath_vid = query("/sys/group_vlan/index:".$@."/group_vid");
							}
						}
						set("/wlan/inf:1/multi/index:".$multi_idx."/vlan_id",$pvid_auto_ath_vid);$dirty++;				
					}
					else if($pvid_auto_ath_idx > 8 && $pvid_auto_ath_idx < 17)
					{
						$w_index = $pvid_auto_ath_idx - 8;
						$pvid_auto_ath_vid = 1;
						for("/sys/group_vlan/index")
						{
							if(query("/sys/group_vlan/index:".$@."/ath:".$pvid_auto_ath_idx."/egress") == 2)
							{
								$pvid_auto_ath_vid = query("/sys/group_vlan/index:".$@."/group_vid");
							}
						}
						set("/wlan/inf:1/wds/index:".$w_index."/vlan_id",$pvid_auto_ath_vid);$dirty++;					
					}								
					$pvid_auto_ath_idx++;
				}
			}
		}
	}
	
	if($dirty > 0)
	{
		if($limit_dirty > 0)
		{
			set("/runtime/web/submit/limit", 1);
		}
		if($f_apply =="rule_add" || $f_rule_del!="")
		{
			//$SUBMIT_STR="submit VLAN_PORT_LIST";
			set("/runtime/web/submit/vlan", 1);
			set("/runtime/web/submit/vlanportlist", 1);
		}	
		else
		{
			if(query("/runtime/web/check/vlan/mssid_enable") == 1 || $dirty_wlan > 0)
			{
				//$SUBMIT_STR="submit WLAN;submit VLAN_PORT_LIST";
				set("/runtime/web/submit/wlan", 1);
				set("/runtime/web/submit/vlanportlist", 1);
			}
			else
			{
				//$SUBMIT_STR="submit VLAN;submit VLAN_PORT_LIST";
				set("/runtime/web/submit/vlan", 1);
				set("/runtime/web/submit/vlanportlist", 1);
			}
		}
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}	

	
	set("/runtime/web/next_page",$ACTION_POST);
	/*if($dirty > 0) {*/require($G_SAVING_URL);/*}
	else                  {require($G_NO_CHANGED_URL);}		*/
}
else if($ACTION_POST == "adv_wtp")
{
	echo "<!--\n";
	echo "ACTION_POST=".			$ACTION_POST.			"\n";
	echo "-->\n";	
	
	$SUBMIT_STR = "";

	if($f_wtp_del!="")//del
	{
		$dirty++;
		del("/sys/wtp/acstatic/ip:".$f_wtp_del);	
	}	
	else if($f_add != "") //add
	{
		if(query("/sys/wtp/enable")	!=$f_wtp_enable)	{set("/sys/wtp/enable", $f_wtp_enable);	$dirty++;}				
		
		$ip_num=1;
		for("/sys/wtp/acstatic/ip"){$ip_num++;}
		if(query("/sys/wtp/acstatic/ip:".$ip_num)	!=$ac_ipaddr)	{set("/sys/wtp/acstatic/ip:".$ip_num,	$ac_ipaddr);		$dirty++;}				
	}
	else //apply
	{
		$dirty++;
		if(query("/sys/wtp/enable")	!=$f_wtp_enable)	{set("/sys/wtp/enable", $f_wtp_enable);	$dirty++;}				
	}
		
	if($dirty > 0)
	{
		if($f_add != "" || $f_wtp_del!="")
		{
			//$SUBMIT_STR= "COMMIT";
			set("/runtime/web/submit/commit",1);
		}
		else
		{
			//$SUBMIT_STR="submit WTP";
			set("/runtime/web/submit/wtp", 1);
		}		
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}	

	
	set("/runtime/web/next_page",$ACTION_POST);
	/*if($dirty > 0) {*/require($G_SAVING_URL);/*}
	else                  {require($G_NO_CHANGED_URL);}		*/
}		
/*victor modify 2009-1-7 start*/
else if($ACTION_POST == "adv_ap_array")
{
	echo "<!--\n";
	echo "ACTION_POST=".			$ACTION_POST.			"\n";
	echo "-->\n";	
	
	$SUBMIT_STR = "";
	$dirty=0;
	$limit_dirty=0;
	if($f_scan_value == "1")
	{
		set("/runtime/web/check_scan_value", 1);
		set("/runtime/web/ap_array/scan",1);
		$dirty++;	
		anchor("/runtime/web/wlan/inf:1");
	}
	else
	{
		anchor("/wlan/inf:1");
	}
	if(query("aparray_enable")	!=$f_ap_array_enable)	
	{
		set("aparray_enable", $f_ap_array_enable);	$dirty++;
		if($f_ap_array_enable==1)
		{
			set("/sys/adminlimit/status", 0);
			$limit_dirty++;
		}
	}				
	if(query("arrayrole_original")	!=$f_role)	{set("arrayrole_original", $f_role);	$dirty++;}			
	if(query("arrayname")	!=$ap_array_name)	{set("arrayname", $ap_array_name);	$dirty++;}			
	if(query("aparray_password")	!=$ap_array_pwd)	{set("aparray_password", $ap_array_pwd);	$dirty++;}			
	if($f_scan_value != "1")
	{
		anchor("/aparray/sync");
	}
	if(query("ssid")	!=$bsc_network_name)	{set("ssid", $bsc_network_name);	$dirty++;}				
	if(query("ssidhidden")	!=$bsc_ssid_visibility)	{set("ssidhidden", $bsc_ssid_visibility);	$dirty++;}			
	if(query("autochannel")	!=$bsc_auto_chann)	{set("autochannel", $bsc_auto_chann);	$dirty++;}			
	if(query("channelwidth")	!=$bsc_channel_width)	{set("channelwidth", $bsc_channel_width);	$dirty++;}			
	if(query("security")	!=$bsc_security)	{set("security", $bsc_security);	$dirty++;}				
	if(query("band")	!=$bsc_band)	{set("band", $bsc_band);	$dirty++;}							
	if(query("fixedrate")	!=$adv_data_rate)	{set("fixedrate", $adv_data_rate);	$dirty++;}			
	if(query("beaconinterval")	!=$adv_beacon_interval)	{set("beaconinterval", $adv_beacon_interval);	$dirty++;}			
	if(query("dtim")	!=$adv_dtim)	{set("dtim", $adv_dtim);	$dirty++;}			
	if(query("txpower")	!=$adv_transmit_power)	{set("txpower", $adv_transmit_power);	$dirty++;}				
	if(query("wmm")	!=$adv_wmm_wifi)	{set("wmm", $adv_wmm_wifi);	$dirty++;}			
	if(query("acktimeout")	!=$adv_ack_timeout)	{set("acktimeout", $adv_ack_timeout);	$dirty++;}			
	if(query("shortgi")	!=$adv_short_gi)	{set("shortgi", $adv_short_gi);	$dirty++;}			
	if(query("igmpsnoop")	!=$adv_igmp)	{set("igmpsnoop", $adv_igmp);	$dirty++;}				
	if(query("connectionlimit")	!=$adv_conn_limit)	{set("connectionlimit", $adv_conn_limit);	$dirty++;}			
	if(query("linkintegrity")	!=$adv_link_integrity)	{set("linkintegrity", $adv_link_integrity);	$dirty++;}			
	if(query("multi/ssid")	!=$mssid)	{set("multi/ssid", $mssid);	$dirty++;}			
	if(query("multi/ssid_hidden")	!=$mssid_visibility)	{set("multi/ssid_hidden", $mssid_visibility);	$dirty++;}				
	if(query("multi/security")	!=$msecurity)	{set("multi/security", $msecurity);	$dirty++;}			
	if(query("multi/wmm")	!=$mwmm)	{set("multi/wmm", $mwmm);	$dirty++;}			
	if(query("qos")	!=$qos_setting)	{set("qos", $qos_setting);	$dirty++;}			
	if(query("vlan")	!=$vlan)	{set("vlan", $vlan);	$dirty++;}				
	if(query("schedule")	!=$schedule_settings)	{set("schedule", $schedule_settings);	$dirty++;}			
	if(query("time")	!=$time_date)	{set("time", $time_date);	$dirty++;}			
	if(query("log")	!=$log_setting)	{set("log", $log_setting);	$dirty++;}			
	if(query("adminlimit")	!=$limit_admin)	{set("adminlimit", $limit_admin);	$dirty++;}				
	if(query("system")	!=$sys_name_setting)	{set("system", $sys_name_setting);	$dirty++;}			
	if(query("consoleprotocol")	!=$console_setting)	{set("consoleprotocol", $console_setting);	$dirty++;}			
	if(query("snmp")	!=$snmp_setting)	{set("snmp", $snmp_setting);	$dirty++;}			
	if(query("pingctl")	!=$ping_control_setting)	{set("pingctl", $ping_control_setting);	$dirty++;}				
	if(query("dhcp")	!=$dhcp_svr_setting)	{set("dhcp", $dhcp_svr_setting);	$dirty++;}			
	if(query("login")	!=$login_setting)	{set("login", $login_setting);	$dirty++;}			
	if(query("acl")	!=$adv_acl)	{set("acl", $adv_acl);	$dirty++;}			
	if($dirty > 0)
	{
		if($f_scan_value == "1")
		{
			/*$SUBMIT_STR="submit COMMIT";*/	
			$SUBMIT_STR="submit AP_ARRAY_SCAN"; 
		}
		else
		{
			/*$SUBMIT_STR="submit AP_ARRAY";*/
			set("/runtime/web/submit/ap_array",1);
			if($limit_dirty > 0)
			{
				set("/runtime/web/submit/limit", 1);
			}	
		}	
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}

	
	set("/runtime/web/next_page",$ACTION_POST);
	if($dirty > 0 && $f_scan_value=="1")	{require($G_SCAN_URL);}
	else /* if($SUBMIT_STR!="" && $f_scan_value!="1")*/	{require($G_SAVING_URL);}	
	/*else				{require($G_NO_CHANGED_URL);}*/
}
else if($ACTION_POST == "adv_url")
{
	echo "<!--\n";
	echo "ACTION_POST=".			$ACTION_POST.			"\n";
	echo "-->\n";	

	$dirty=0;
	$SUBMIT_STR = "";
	$dirty_limit = 0;
	if($action=="add")
	{
		$s=1;
		for("/wlan/inf:1/webredirect/index")
		{
			$s++;
		}
		anchor("/wlan/inf:1/webredirect");
		set("index:".$s."/name",$r_name);
		set("index:".$s."/passwd",$r_password);
		set("index:".$s."/enable",$account_status);
		$dirty++;
	}
	
	if($action=="edit")
	{
		anchor("/wlan/inf:1/webredirect");
		if(query("index:".$which_edit."/name")!=$r_name){set("index:".$which_edit."/name",$r_name);$dirty++;}
		if(query("index:".$which_edit."/passwd")!=$r_password){set("index:".$which_edit."/passwd",$r_password);$dirty++;}
		if(query("index:".$which_edit."/enable")!=$account_status){set("index:".$which_edit."/enable",$account_status);$dirty++;}
	}

	if($action=="delete")
	{
		del("/wlan/inf:1/webredirect/index:".$which_delete);
		$dirty++;
	}
	else
	{
		if(query("/wlan/inf:1/webredirect/enable")!=$url_enable)
		{
			set("/wlan/inf:1/webredirect/enable",$url_enable);
			$dirty++;
			if($url_enable == 1)
			{
				if(query("/sys/adminlimit/status")==1){set("/sys/adminlimit/status", 0);$limit_dirty++;}/*limit_admin_status*/
				if(query("/sys/adminlimit/status")==3){set("/sys/adminlimit/status", 2);$limit_dirty++;}/*limit_admin_status*/
			}
		}
	}
	if($action=="save")
	{	
		for("/wlan/inf:1/webredirect/index")
		{
			$account_status	= "a_s".$@;
			if(query("enable")!=$$account_status){set("enable",$$account_status);$dirty++;}
			$dirty++;
		}
	}	
		
	if($dirty > 0)
	{
		//$SUBMIT_STR="submit COMMIT";
		//set("/runtime/web/submit/commit", 1);
		if($limit_dirty > 0)
		{
			set("/runtime/web/submit/limit", 1);
		}	
		set("/runtime/web/submit/webredirect", 1);
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}

	set("/runtime/web/next_page",$MY_NAME);
	/*if($dirty > 0) {*/require($G_SAVING_URL);/*}
	else				{require($G_NO_CHANGED_URL);}*/
}	
/*victor modify 2009-1-7 end*/
		
else if($ACTION_POST == "adv_mcast")
{
	echo "<!--\n";
	echo "ACTION_POST=".			$ACTION_POST.			"\n";
	echo "-->\n";	
	
	$SUBMIT_STR = "";
	$dirty=0;	
	anchor("/wlan/inf:1");
	if(query("mcastrate_a")	!=$f_mcast_a)	{set("mcastrate_a", $f_mcast_a);	$dirty++;}				
	if(query("mcastrate_g")	!=$f_mcast_g)	{set("mcastrate_g", $f_mcast_g);	$dirty++;}			
	if($dirty > 0)
	{
		set("/runtime/web/submit/wlan", 1);		
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}
	set("/runtime/web/next_page",$ACTION_POST);
	require($G_SAVING_URL);
}
else if($ACTION_POST == "adv_arpspoofing")
{
	$dirty=0;
	$SUBMIT_STR="";
	
	if(query("/arpspoofing/enable")!=$arp_state){set("/arpspoofing/enable",$arp_state);$dirty++;}
	if($action=="add")
	{
		$s=1;
		for("/arpspoofing/static/index")
		{
			$s++;
		}
		anchor("/arpspoofing/static");
		set("index:".$s."/ip",$ip_addr);
		set("index:".$s."/mac",$harp_mac);
		$dirty++;
	}
	
	if($action=="edit")
	{
		anchor("/arpspoofing/static");
		if(query("index:".$which_edit."/ip")!=$r_name){set("index:".$which_edit."/ip",$ip_addr);$dirty++;}
		if(query("index:".$which_edit."/mac")!=$r_password){set("index:".$which_edit."/mac",$harp_mac);$dirty++;}
	}
	
	if($action=="delete")
	{
		del("/arpspoofing/static/index:".$which_delete);
		$dirty++;
	}
	if($action=="delete_all")
	{
		del("/arpspoofing/static");
		$dirty++;
	}
  
	if($dirty > 0)
	{	
		//$SUBMIT_STR="submit COMMIT";
		//set("/runtime/web/submit/commit", 1);
		set("/runtime/web/submit/arpspoofing", 1);
		set("/runtime/web/sub_str",$SUBMIT_STR);
	}	

	set("/runtime/web/next_page",$MY_NAME);
	/*if($dirty > 0) {*/require($G_SAVING_URL);/*}
	else                  {require($G_NO_CHANGED_URL);}	*/
}		
?>
