<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME      = "st_stats_wl";
$MY_MSG_FILE  = $MY_NAME.".php";
$MY_ACTION    = $MY_NAME;
$NEXT_PAGE    = "st_stats_wl";
set("/runtime/web/help_page",$MY_NAME);
/* --------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
/* --------------------------------------------------------------------------- */
// get the variable value from rgdb.
if($check_clear == "")
{
	$check_clear = 0;	
}
set("/runtime/stats/wireless/statistic/clear",$check_clear);

$cfg_T_Packet=query("/runtime/stats/wireless/showtx/packets");
$cfg_T_Bytes=query("/runtime/stats/wireless/showtx/bytes");
$cfg_T_Dropped_Packet=query("/runtime/stats/wireless/showtx/drop");
$cfg_T_Retry=query("/runtime/stats/wireless/showtx/retry");
$cfg_R_Packet=query("/runtime/stats/wireless/showrx/packets");
$cfg_R_Bytes=query("/runtime/stats/wireless/showrx/bytes");
$cfg_R_Dropped_Packet=query("/runtime/stats/wireless/showrx/drop");
$cfg_R_CRC=query("/runtime/stats/wireless/showrx/crcerr");
$cfg_R_Decryption_Error=query("/runtime/stats/wireless/showrx/crypterr");
$cfg_R_MIC_Error=query("/runtime/stats/wireless/showrx/micerr");
$cfg_R_PHY_Error=query("/runtime/stats/wireless/showrx/phyerr");
/* --------------------------------------------------------------------------- */
?>

<?
echo $G_TAG_SCRIPT_START."\n";
require("/www/model/__wlan.php");
?>
/* page init functoin */
function init()
{
    var f = get_obj("frm");
   	var str="";
   	str+="st_stats_wl.xgi?"+generate_random_str();
    <?
   	$st_flag=query("/runtime/stats/wireless/statisitc/flag");
	$refresh_count = query("/runtime/web/refresh_count");
	$refresh_flag = query("/runtime/web/refresh_flag");
	if($refresh_count=="")
		{$refresh_count ="0";}
	if($refresh_flag=="")
		{$refresh_flag ="2";}
	if($st_flag=="")
		{$st_flag="1";}
	if($st_flag=="1")
	{	
	if($AUTH_GROUP=="0")
	{
		
		echo "str+=exe_str(\"submit ST_ATH_STATS\");\n";
		echo "str+=exe_str(\"submit ST_PACK_REFRESH;submit SLEEP 1\");\n";
		if($check_clear == 1)
		{		
			echo "self.location.href=str;\n";
		}	
		
		$refresh_count = $refresh_count+1;
		set("/runtime/web/refresh_count",$refresh_count);

		if($refresh_flag > $refresh_count)
		{
				echo "f.refresh.disabled = true;\n";
				echo "f.clear.disabled = true;\n";
			echo "self.location.href=str;\n";
		}			
		else 	
		{
				echo "f.refresh.disabled = false;\n";
				echo "f.clear.disabled = false;\n";
			$refresh_flag = $refresh_count+2;
			set("/runtime/web/refresh_flag",$refresh_flag);			
		}

	}	
	}
	else
	{
		echo "do_refresh();";
	}
	?>	
}
/* parameter checking */
function do_refresh()
{
	var f = get_obj("frm");
	f.refresh.disabled = true;
	f.clear.disabled= true;
	self.location.href="<?=$MY_MSG_FILE?>";
}
/* cancel function */
function do_clear()
{
	var f = get_obj("frm");
	f.refresh.disabled = true;
	f.clear.disabled= true;
	self.location.href = "st_stats_wl.php?random="+generate_random_str()+"&check_clear=1";
}

<?=$G_TAG_SCRIPT_END?>
<body <?=$G_BODY_ATTR?> onload="init();">
<form name="frm" id="frm" method="post" action="<?=$MY_NAME?>.php">
<input type="hidden" name="ACTION_POST" value="<?=$MY_ACTION?>">
<!-- ________________________________ Main Content Start ______________________________ -->
<table id="table_frame" border="0"<?=$G_TABLE_ATTR_CELL_ZERO?>>
	<tr>
		<td valign="top" align="center">
			<table id="table_header" <?=$G_TABLE_ATTR_CELL_ZERO?>>
			<tr>
				<td id="td_header" valign="middle"><?=$msg_title?></td>
			</tr>
			</table>
			<table width="98%"  border="0" <?=$G_TABLE_ATTR_CELL_ZERO?>>
				<tr>
					<td  colspan="2" height="16" align="right">
						<input type="button" name="clear" value="<?=$msg_clear?>" onClick="do_clear();">
						<input type="button" name="refresh" value="<?=$msg_refresh?>" onClick="do_refresh();">
					</td>
				</tr>
				<tr>
					<td bgcolor="#cccccc" colspan="2" height="16"><b><?=$msg_t_title?></b></td>
				</tr>
				<tr>
					<td width="45%" id="td_left">
						<?=$msg_t_msg1?>
					</td>
					<td id="td_right"><?=$cfg_T_Packet?>
					</td>
				</tr>
				<tr>
					<td width="45%" id="td_left">
						<?=$msg_t_msg2?>
					</td>
					<td id="td_right">
						<?=$cfg_T_Bytes?>
					</td>
				</tr>
				<tr>
					<td width="45%" id="td_left">
						<?=$msg_t_msg3?>
					</td>
					<td id="td_right">
						<?=$cfg_T_Dropped_Packet?>
					</td>
				</tr>
				<tr>
					<td width="45%" id="td_left">
						<?=$msg_t_msg4?>
					</td>
					<td id="td_right">
						<?=$cfg_T_Retry?>
					</td>
				</tr>
				<tr>
					<td bgcolor="#cccccc" colspan="2" height="16"><b><?=$msg_r_title?></b></td>
				</tr>
				<tr>
					<td width="45%" id="td_left">
						<?=$msg_r_msg1?>
					</td>
					<td id="td_right">
						<?=$cfg_R_Packet?>
					</td>
				</tr>
				<tr>
					<td width="45%" id="td_left">
						<?=$msg_r_msg2?>
					</td>
					<td id="td_right">
						<?=$cfg_R_Bytes?>
					</td>
				</tr>
				<tr>
					<td width="45%" id="td_left">
						<?=$msg_r_msg3?>
					</td>
					<td id="td_right">
						<?=$cfg_R_Dropped_Packet?>
					</td>
				</tr>
<? if(query("/runtime/web/display/stat_wl") !="1")	{echo "<!--";} ?>				
				<tr>
					<td width="45%" id="td_left">
						<?=$msg_r_msg4?>
					</td>
					<td id="td_right">
						<?map("/runtime/stats/wireless/showrx/crcerr","",0);?>
					</td>
				</tr>
				<tr>
					<td width="45%" id="td_left">
						<?=$msg_r_msg5?>
					</td>
					<td id="td_right">
						<?=$cfg_R_Decryption_Error?>
					</td>
				</tr>
				<tr>
					<td width="45%" id="td_left">
						<?=$msg_r_msg6?>
					</td>
					<td id="td_right">
						<?=$cfg_R_MIC_Error?>
					</td>
				</tr>
				<tr>
					<td width="45%" id="td_left">
						<?=$msg_r_msg7?>
					</td>
					<td id="td_right">
						<?=$cfg_R_PHY_Error?>
					</td>
				</tr>
<? if(query("/runtime/web/display/stat_wl") !="1")	{echo "-->";} ?>					
			</table>				
<!-- ________________________________  Main Content End _______________________________ -->
		</td>
	</tr>
</table>
</form>
</body>
<script>


</script>
</html>
