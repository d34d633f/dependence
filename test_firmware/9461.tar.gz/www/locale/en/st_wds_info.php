<?
$m_context_title = "WDS Information";
$m_client_info = "WDS Information";
$m_st_association  = "Station association with 11";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "Band";
$m_auth = "Authentication";
$m_signal = "Signal";
$m_power = "Power Saving Mode";
$m_wpa		= "WPA-";
$m_wpa2		= "WPA2-";
$m_wpa_auto		= "WPA2-Auto-";
$m_eap		= "Enterprise";
$m_psk		= "Personal";
$m_wep		="WEP";
$m_shared	="Shared Key";
$m_disabled		="Disable";
$m_channel = "Channel";
$m_name = "Name";
$m_status = "Status";
$wds = "W";
$m_on = "On";
$m_off = "Off";
$m_open = "Open System";
?>