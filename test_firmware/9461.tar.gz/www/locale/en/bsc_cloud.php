<?
$m_context_title = "Cloud Manager";
$m_enable_cloud = "Enable Cloud Manager";
$a_change_cloud = "System will reboot if you enable/disable cloud manager!\\n Do you want to reboot now?";
?>
