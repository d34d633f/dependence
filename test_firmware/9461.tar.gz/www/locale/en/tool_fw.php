<?
$runtime_ipv6 = query("/runtime/web/display/ipv6");
/*$cfg_cloud = query("/cloud/enable");
if($cfg_cloud=="1")
{*/
	$m_context_title = "Firmware Upload";
/*}
else
{
$m_context_title = "Firmware and SSL Certification Upload";
}*/
$m_upload_fw_title ="Update Firmware From Local Hard Drive";
$m_firmware_version	="Firmware Version";
$m_upload_firmware_file	="Upload Firmware From File";	
$m_upload_lang_title ="Language Pack Upgrade";	
$m_upload_lang_file	="Upload";	
$m_upload_ssl_titles = "Update SSL Certification From Local Hard Drive";
$m_upload_certificatee_file	= "Upload Certificate From File";	
$m_upload_key_file	= "Upload Key From File";	
$m_b_fw_upload = "Upload";
$m_upload_wapi_title = "Update AS and AP Certification From Local Hard Drive";
$m_upload_ascert_file = "Upload AS Certificate From File :";
$m_upload_apcert_file = "Upload AP Certificate From File :";
$a_blank_fw_file= "Empty file is not accepted!";
$a_format_error_file =" File format error! Please try again!";
$a_reboot_device = "Please reboot the device for updete SSL key setting!";
$a_reboot_device_cert = "Please reboot the device for updete AP Certification setting!";
?>
