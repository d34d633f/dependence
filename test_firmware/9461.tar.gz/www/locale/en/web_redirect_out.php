<?

$m_context_title	="Authentication Success";
$m_redirect_success	="Authentication Success";
$m_pls_cls_win ="Please close this window and open a new one to access Internet";
$m_thank_u ="Thank you";
$m_ok ="OK";

?>
