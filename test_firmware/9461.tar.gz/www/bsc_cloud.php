<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME      = "bsc_cloud";
$MY_MSG_FILE  = $MY_NAME.".php";
$MY_ACTION    = $MY_NAME;
$NEXT_PAGE    = "bsc_cloud";
set("/runtime/web/help_page",$MY_NAME);
/* --------------------------------------------------------------------------- */
if($ACTION_POST != "")
{
    require("/www/model/__admin_check.php");
    require("/www/__action_bsc.php");
    $ACTION_POST = "";
    exit;
}

/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
set("/runtime/web/next_page",$first_frame);
require("/www/comm/__js_ip.php");
/* --------------------------------------------------------------------------- */
// get the variable value from rgdb.
echo "<!--debug\n";
$cfg_cloud = query("/cloud/enable");
echo "-->";
/* --------------------------------------------------------------------------- */
?>
<?
echo $G_TAG_SCRIPT_START."\n";
require("/www/model/__wlan.php");
?>

function init()
{
	
}

function on_change_cloud()
{
	var f=get_obj("frm");
	if(confirm("<?=$a_change_cloud?>")==true)
  {
	var str="";
    str="/sys_cfg_valid.xgi?";
    str+=exe_str("submit CLOUD_SET");
    parent.location.href=str;
  }
	else
	{
		if("<?=$cfg_cloud?>" == 1)
		{
			f.cloud.checked=true;
		}
		else
		{
			f.cloud.checked=false;
		}
	}
}

/*function check()
{
	var f=get_obj("frm");
	if(f.cloud.checked)
	{
		f.f_cloud.value = 1;
	}
	else
	{
		f.f_cloud.value = 0;
	}
	return true;
}*/

function submit()
{
	if(check())	get_obj("frm").submit();
}
<?=$G_TAG_SCRIPT_END?>

<body <?=$G_BODY_ATTR?> onload="init();">

<form name="frm" id="frm" method="post" action="<?=$MY_NAME?>.php" onsubmit="return false;">

<input type="hidden" name="ACTION_POST" value="<?=$MY_ACTION?>">
<input type="hidden" name="f_cloud" value="">

<table id="table_frame" border="0"<?=$G_TABLE_ATTR_CELL_ZERO?>>
    <tr>
        <td valign="top">
            <table id="table_header" <?=$G_TABLE_ATTR_CELL_ZERO?>>
            <tr>
                <td id="td_header" valign="middle"><?=$m_context_title?></td>
            </tr>
            </table>
<!-- ________________________________ Main Content Start ______________________________ -->
            <table id="table_set_main"  border="0"<?=$G_TABLE_ATTR_CELL_ZERO?>>
                <tr>
                    <td id="td_left" width="150">
                        <?=$m_enable_cloud?>
                    </td>
                    <td>
                        <input type="checkbox" name="cloud" id="cloud" value="" <? if($cfg_cloud == 1) {echo "checked";} ?> onClick="on_change_cloud();">
                    </td>
                </tr>
			</table>
<!--?=$G_APPLY_BUTTON?-->
<!-- ________________________________  Main Content End _______________________________ -->
        </td>
    </tr>
</table>
