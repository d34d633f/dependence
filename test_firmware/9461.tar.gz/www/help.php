<?
/* vi: set sw=4 ts=4: */
$MY_NAME      = "help";
$MY_MSG_FILE  = $MY_NAME.".php";

require("/www/model/__html_head.php");
$cfg_cloud = query("/cloud/enable");
$cfg_wlan_domain = query("/runtime/layout/countrycode");
$help_page = query("/runtime/web/help_page");
echo $G_TAG_SCRIPT_START."\n";
?>
function init()
{
	location.href="help.php#<?=$help_page?>";
}

<?
echo $G_TAG_SCRIPT_END."\n";
?>


<body onload="init();" <?=$G_BODY_ATTR?>>
<form name="frm" id="frm">
<center>
<table <?=$G_MAIN_TABLE_ATTR?>>
<tr valign="middle" align="center">
	<td>
		
		
		<table id="table_header" cellspacing="0" cellpadding="0">
			<tr>
				<td id="td_header"><?=$head_bsc?></td>
			</tr>	
		</table>
		<table id="table_set_main"  border="0"  cellspacing="5" cellpadding="5">					
			<tr>
				<td class="help_title_td"><?=$title_bsc_cloud?><a name="bsc_cloud"></a></td>
			</tr>
			<tr>
				<td><?=$bsc_cloud_msg?></td>
			</tr>
<? if($cfg_cloud ==1) {echo "<!--";}?>
			<tr>
				<td class="help_title_td"><?=$title_bsc_wlan?><a name="bsc_wlan"></a></td>
			</tr>
			<tr>
				<td><?=$bsc_wlan_msg?></td>
			</tr>
			<tr>
				<td>
					<b><?=$bsc_wireless_band?></b><br>
					<?=$bsc_wireless_band_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_mode?></b><br>
					<?=$bsc_mode_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_network_name?></b><br>
					<?=$bsc_network_name_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_ssid_visibility?></b><br>
					<?=$bsc_ssid_visibility_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_auto_channel?></b><br>
					<?=$bsc_auto_channel_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_channel?></b><br>
					<?=$bsc_channel_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_channel_width?></b><br>
					<?=$bsc_channel_width_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_authentication?></b><br>
					<?=$bsc_authentication_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_open_sys?></b><br>
					<?=$bsc_open_sys_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_shared_key?></b><br>
					<?=$bsc_shared_key_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_personal_type?></b><br>
					<?=$bsc_personal_type_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$bsc_enterprise_type?></b><br>
					<?=$bsc_enterprise_type_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
                    <b><?=$bsc_8021x_type?></b><br>
                    <?=$bsc_8021x_type_msg?>
                </td>
            </tr>	
			<tr>
				<td>
					<b><?=$bsc_network_access?></b><br>
					<?=$bsc_network_access_msg?>	
				</td>	
			</tr>				
			<tr>
				<td>
					<b><?=$bsc_mac_clone?></b><br>
					<?=$bsc_mac_clone_msg?>
				</td>
			</tr>
<? if($cfg_cloud ==1) {echo "-->";}?>
			<tr>
				<td class="help_title_td"><?=$title_bsc_lan?><a name="bsc_lan"></a></td>
			</tr>
			<tr>
				<td><?=$title_bsc_lan_msg?></td>
			</tr>		
			<tr>
				<td>
					<b><?=$bsc_get_ip_from?></b><br>
					<?=$bsc_get_ip_from_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_ip_address?></b><br>
					<?=$bsc_ip_address_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_submask?></b><br>
					<?=$bsc_submask_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$bsc_gateway?></b><br>
					<?=$bsc_gateway_msg?>	
				</td>	
			</tr>									
			<tr>
                <td>
                    <b><?=$bsc_netbios?></b><br>
                    <?=$bsc_netbios_msg?>
                </td>
            </tr>
			<tr>
                <td>
                    <b><?=$bsc_dns?></b><br>
                    <?=$bsc_dns_msg?>
                </td>
            </tr>
		</table>	
<? if($cfg_cloud ==1) {echo "<!--";}?>
		<table id="table_header" cellspacing="0" cellpadding="0">
			<tr>
				<td id="td_header"><?=$head_adv?></td>
			</tr>	
		</table>		
		<table id="table_set_main"  border="0"  cellspacing="5" cellpadding="5">					
			<tr>
				<td class="help_title_td"><?=$title_adv_per?><a name="adv_perf"></a></td>
			</tr>
			<tr>
				<td><?=$title_adv_per_msg?></td>
			</tr>
			<tr>
				<td>
					<b><?=$adv_wireless?></b><br>
					<?=$adv_wireless_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_wireless_mode?></b><br>
					<?=$adv_wireless_mode_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_date_rate?></b><br>
					<?=$adv_date_rate_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_beacon?></b><br>
					<?=$adv_beacon_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_dtim?></b><br>
					<?=$adv_dtim_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_transmit_power?></b><br>
					<?=$adv_transmit_power_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_wmm?></b><br>
					<?=$adv_wmm_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_ack_timeout?></b><br>
					<?=$adv_ack_timeout_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_short_gi?></b><br>
					<?=$adv_short_gi_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_igmp?></b><br>
					<?=$adv_igmp_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_connection_limit?></b><br>
					<?=$adv_connection_limit_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_user_limit?></b><br>
					<?=$adv_user_limit_msg?>	
				</td>	
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_adv_mssid?><a name="adv_mssid"></a></td>
			</tr>
			<tr>
				<td><?=$title_adv_mssid_msg?></td>
			</tr>
			<tr>
				<td><?=$adv_mssid_msg1?></td>
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_adv_vlan?><a name="adv_8021q"></a></td>
			</tr>
			<tr>
				<td><?=$title_adv_vlan_msg?></td>
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_adv_intrusion?><a name="adv_rogue"></a></td>
			</tr>
			<tr>
				<td><?=$title_adv_intrusion_msg?></td>
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_adv_scheduling?><a name="adv_schedule"></a></td>
			</tr>
			<tr>
				<td><?=$title_adv_scheduling_msg?></td>
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_adv_qos?><a name="adv_qos"></a></td>
			</tr>
			<tr>
				<td><?=$title_adv_qos_msg?></td>
			</tr>
			<tr>
				<td>
					<b><?=$adv_enable_qoS?></b><br>
					<?=$adv_enable_qoS_msg?><br>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_enable_qoS_msg1?></b><br>
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_http?></b><br>
					<?=$adv_http_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_automatic?></b><br>
					<?=$adv_automatic_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_qos_rule?></b><br>
					<?=$adv_qos_rule_msg?>	
				</td>	
			</tr>
			<tr>
				<td><?=$adv_qos_rule_msg1?></td>
			</tr>
			<tr>
				<td>
					<b><?=$adv_name?></b><br>
					<?=$adv_name_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_priority?></b><br>
					<?=$adv_priority_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$adv_priority_msg1?><br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$adv_priority_msg2?><br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$adv_priority_msg3?><br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$adv_priority_msg4?><br>
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_protocol?></b><br>
					<?=$adv_protocol_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_host_1_ip?></b><br>
					<?=$adv_host_1_ip_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_host_1_port?></b><br>
					<?=$adv_host_1_port_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_host_2_ip?></b><br>
					<?=$adv_host_2_ip_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_host_2_port?></b><br>
					<?=$adv_host_2_port_msg?>	
				</td>	
			</tr>

		</table>
		<table id="table_header" cellspacing="0" cellpadding="0">
			<tr>
				<td id="td_header"><?=$head_dhcp?></td>
			</tr>	
		</table>		
		<table id="table_set_main"  border="0"  cellspacing="5" cellpadding="5">					
			<tr>
				<td><?=$head_dhcp_msg?></td>
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_dhcp_dynamic_pool?><a name="adv_dhcpd"></a></td>
			</tr>
			<tr>
				<td><?=$title_dhcp_dynamic_pool_msg?></td>
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_server_control?></b><br>
					<?=$dhcp_server_control_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_ip_assigned?></b><br>
					<?=$dhcp_ip_assigned_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_range_of_pool?></b><br>
					<?=$dhcp_range_of_pool_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_submask?></b><br>
					<?=$dhcp_submask_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_gateway?></b><br>
					<?=$dhcp_gateway_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_wins?></b><br>
					<?=$dhcp_wins_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_dns?></b><br>
					<?=$dhcp_dns_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_domain?></b><br>
					<?=$dhcp_domain_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_lease_time?></b><br>
					<?=$dhcp_lease_time_msg?>	
				</td>	
			</tr>					
			<tr>
				<td class="help_title_td"><?=$title_dhcp_static_pool?><a name="adv_dhcps"></a></td>
			</tr>
			<tr>
				<td><?=$title_dhcp_static_pool_msg?></td>
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_assigned_ip?></b><br>
					<?=$dhcp_assigned_ip_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_assigned_mac?></b><br>
					<?=$dhcp_assigned_mac_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_submask?></b><br>
					<?=$dhcp_submask_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_gateway?></b><br>
					<?=$dhcp_gateway_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_wins?></b><br>
					<?=$dhcp_wins_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_dns?></b><br>
					<?=$dhcp_dns_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$dhcp_domain?></b><br>
					<?=$dhcp_domain_msg?>	
				</td>	
			</tr>
			
			<tr>
				<td class="help_title_td"><?=$title_dhcp_current_ip?><a name="adv_dhcpl"></a></td>
			</tr>
			<tr>
				<td><?=$title_dhcp_current_ip_msg?></td>
			</tr>
		</table>
		<table id="table_header" cellspacing="0" cellpadding="0">
			<tr>
				<td id="td_header"><?=$head_filters?></td>
			</tr>	
		</table>		
		<table id="table_set_main"  border="0"  cellspacing="5" cellpadding="5">					
			<tr>
				<td><?=$head_filters_msg?></td>
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_filters_wireless_access?><a name="adv_acl"></a></td>
			</tr>
			<tr>
				<td>
					<b><?=$filters_wireless_band?></b><br>
					<?=$filters_wireless_band_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$filters_acl_list?></b><br>
					<?=$filters_acl_list_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$filters_acl_mac?></b><br>
					<?=$filters_acl_mac_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$filters_acl_client_information?></b><br>
					<?=$filters_acl_client_information_msg?>	
				</td>	
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_filters_wlan_partition?><a name="adv_partition"></a></td>
			</tr>
			<tr>
				<td>
					<b><?=$filters_wireless_band?></b><br>
					<?=$filters_wireless_band_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$adv_link_integrality?></b><br>
					<?=$adv_link_integrality_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$filters_eth_to_wlan?></b><br>
					<?=$filters_eth_to_wlan_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$filters_internal_station?></b><br>
					<?=$filters_internal_station_msg?>	
				</td>	
			</tr>
		</table>
<? if($cfg_cloud ==1) {echo "-->";}?>
		<table id="table_header" cellspacing="0" cellpadding="0">
			<tr>
				<td id="td_header"><?=$head_st?></td>
			</tr>	
		</table>
		<table id="table_set_main"  border="0"  cellspacing="5" cellpadding="5">					
			<tr>
				<td class="help_title_td"><?=$title_st_dev_info?><a name="st_device"></a></td>
			</tr>
			<tr>
				<td><?=$title_st_dev_info_msg?></td>
			</tr>			
<? if($cfg_cloud !=1) {echo "<!--";}?>
	        <tr>
				<td>
                	<b><?=$title_bsc_cloud_status?></b><br>
                	<?=$bsc_cloud_status_msg?>
				</td>
            </tr>
<? if($cfg_cloud !=1) {echo "-->";}?>
<? if($cfg_cloud ==1) {echo "<!--";}?>
			<tr>
				<td class="help_title_td"><?=$title_st_cli_info?><a name="st_info"></a></td>
			</tr>
			<tr>
				<td><?=$title_st_cli_info_msg?></td>
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_st_wds_info?><a name="st_wds_info"></a></td>
			</tr>
			<tr>
				<td><?=$title_st_wds_info_msg?></td>
			</tr>
		</table>
		<table id="table_header" cellspacing="0" cellpadding="0">
			<tr>
				<td id="td_header"><?=$head_statistics?></td>
			</tr>	
		</table>
		<table id="table_set_main"  border="0"  cellspacing="5" cellpadding="5">					
			<tr>
				<td class="help_title_td"><?=$title_st_ethernet?><a name="st_stats_lan"></a></td>
			</tr>
			<tr>
				<td><?=$title_st_ethernet_msg?></td>
			</tr>					
			<tr>
				<td class="help_title_td"><?=$title_st_wlan?><a name="st_stats_wl"></a></td>
			</tr>
			<tr>
				<td><?=$title_st_wlan_msg?></td>
			</tr>
		</table>
		<table id="table_header" cellspacing="0" cellpadding="0">
			<tr>
				<td id="td_header"><?=$head_log?></td>
			</tr>	
		</table>
		<table id="table_set_main"  border="0"  cellspacing="5" cellpadding="5">					
			<tr>
				<td><?=$head_log_msg?></td>
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_log_view?><a name="st_log"></a></td>
			</tr>
			<tr>
				<td><?=$title_log_view_msg?></td>
			</tr>			
			<tr>
				<td class="help_title_td"><?=$title_log_set?><a name="st_logs"></a></td>
			</tr>
			<tr>
				<td><?=$title_log_set_msg?></td>
			</tr>
<? if($cfg_cloud ==1) {echo "-->";}?>
		</table>
		<table id="table_header" cellspacing="0" cellpadding="0">
			<tr>
				<td id="td_header"><?=$head_mt?></td>
			</tr>	
		</table>
		<table id="table_set_main"  border="0"  cellspacing="5" cellpadding="5">					
<? if($cfg_cloud ==1) {echo "<!--";}?>
			<tr>
				<td class="help_title_td"><?=$title_mt_admin?><a name="tool_admin"></a></td>
			</tr>
			<tr>
				<td>
					<b><?=$mt_limit_admin_vid?></b><br>
					<?=$mt_limit_admin_vid_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$mt_limit_admin_ip?></b><br>
					<?=$mt_limit_admin_ip_msg?>	
				</td>	
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_mt_sysname?></td>
			</tr>
			<tr>
				<td>
					<b><?=$mt_sysname?></b><br>
					<?=$mt_sysname_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$mt_location?></b><br>
					<?=$mt_location_msg?>	
				</td>	
			</tr>
<? if($cfg_cloud ==1) {echo "-->";}?>
			<tr>
				<td class="help_title_td"><?=$title_mt_login?></td>
			</tr>
			<tr>
				<td>
					<b><?=$mt_username?></b><br>
					<?=$mt_username_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$mt_oldpass?></b><br>
					<?=$mt_oldpass_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$mt_newpass?></b><br>
					<?=$mt_newpass_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$mt_conpass?></b><br>
					<?=$mt_conpass_msg?>	
				</td>	
			</tr>
			<tr>
                <td class="help_title_td"><?=$title_mt_fw2?><a name="tool_fw"></a></td>
            </tr>
            <tr>
                <td>
                    <b><?=$title_mt_fw_msg2?></b><br>
                    <?=$title_mt_fw_msg1?>
                </td>
            </tr>
			<tr>
				<td>
					<b><?=$mt_upload_fw?></b><br>
					<?=$mt_upload_fw_msg?>	
				</td>	
			</tr>
<? if($cfg_cloud ==1) {echo "<!--";}?>
			<tr>
				<td>
					<b><?=$mt_upload_language?></b><br>
					<?=$mt_upload_language_msg?>	
				</td>	
			</tr>						
			<tr>
				<td class="help_title_td"><?=$_title_mt_config?><a name="tool_config"></a></td>
			</tr>
			<tr>
				<td>
					<b><?=$mt_config?></b><br>
					<?=$mt_config_msg?>	
				</td>
			</tr>
			<tr>
				<td>
					<b><?=$mt_upload_config?></b><br>
					<?=$mt_upload_config_msg?>	
				</td>
			</tr>
			<tr>
				<td>
					<b><?=$mt_download_config?></b><br>
					<?=$mt_download_config_msg?>	
				</td>
			</tr>
			<tr>
				<td class="help_title_td"><?=$title_mt_time?><a name="tool_sntp"></a></td>
			</tr>
			<tr>
				<td>
					<?=$title_mt_time_msg?>	
				</td>
			</tr>
<? if($cfg_cloud ==1) {echo "-->";}?>
		</table>
		<table id="table_header" cellspacing="0" cellpadding="0">
			<tr>
				<td id="td_header"><?=$head_config?></td>
			</tr>	
		</table>
		<table id="table_set_main"  border="0"  cellspacing="5" cellpadding="5">					
			<tr>
				<td>
					<b><?=$config_save_activate?></b><br>
					<?=$config_save_activate_msg?>	
				</td>	
			</tr>
			<tr>
				<td>
					<b><?=$config_discard_change?></b><br>
					<?=$config_discard_change_msg?>	
				</td>	
			</tr>
		</table>	
		<table id="table_header" cellspacing="0" cellpadding="0">
			<tr>
				<td id="td_header"><?=$head_sys?></td>
			</tr>	
		</table>
		<table id="table_set_main"  border="0"  cellspacing="5" cellpadding="5">					
			<tr>
				<td class="help_title_td"><?=$title_sys?><a name="sys_setting"></a></td>
			</tr>
			<tr>
				<td>
					<b><?=$sys_apply_restart?></b><br>
					<?=$sys_apply_restart_msg?>	
				</td>	
			</tr>	
			<tr>
				<td>
					<b><?=$sys_apply_restore?></b><br>
					<?=$sys_apply_restore_msg?>	
				</td>	
			</tr>			
<? if($cfg_cloud ==1) {echo "<!--";}?>				
			<tr>
				<td>
					<b><?=$sys_clear_language?></b><br>
					<?=$sys_clear_language_msg?>	
				</td>	
			</tr>					
<? if($cfg_cloud ==1) {echo "-->";}?>	
		</table>	
	</td>
</tr>		
</table>
</center>
</form>
</body>
</html>
