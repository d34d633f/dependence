#!/bin/sh
	gpiod &

