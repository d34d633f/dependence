HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
$mode = query("/runtime/hnap/SetWizardWlanMode/mode");
$currentmode = query("/device/wirelessmode");
$layout = "bridge";

function set_wlan_phyinf_active($target_wlan_uid, $enable)
{
        $active = "0";
        if($enable == "true")   $active = "1";
        else				$active = "0";

        $path_target_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $target_wlan_uid, 0);
        set($path_target_wlan."/active", $active);
}


set("/device/layout", $layout);
set("/device/wirelessmode", $mode);

fwrite("w",$ShellPath, "#!/bin/sh\n");
if($mode == $currentmode && $mode!="WirelessAp")
	fwrite("a",$ShellPath, 'event WPSPBC.PUSH\n');
else
{
	if($mode=="WirelessAp")
	{	
		set_wlan_phyinf_active($WLAN1, "true");
		set_wlan_phyinf_active($WLAN2, "true");
		set_wlan_phyinf_active($WLAN_APCLIENT, "false");
		set_wlan_phyinf_active($WLAN2_APCLIENT, "false");
		fwrite("a",$ShellPath, "xmldbc -k wizardwps\n");
	}
	else if($mode=="WirelessClient")
	{
		set("/wifi/entry:9/opmode", "STA"); 

		set_wlan_phyinf_active($WLAN1, "false");
		set_wlan_phyinf_active($WLAN2, "false");
		set_wlan_phyinf_active($WLAN_APCLIENT, "true");
		set_wlan_phyinf_active($WLAN2_APCLIENT, "true");
		//do wps
		fwrite("a",$ShellPath, "xmldbc -k wizardwps\n");
		fwrite("a",$ShellPath, 'xmldbc -t wizardwps:30:"event WPSPBC.PUSH"\n');
	}
	else if($mode=="WirelessRepeaterExtender")
	{
		set("/wifi/entry:9/opmode", "REPEATER"); 

		set_wlan_phyinf_active($WLAN1, "true");
		set_wlan_phyinf_active($WLAN2, "true");
		set_wlan_phyinf_active($WLAN_APCLIENT, "true");
		set_wlan_phyinf_active($WLAN2_APCLIENT, "true");
		//do wps
		fwrite("a",$ShellPath, "xmldbc -k wizardwps\n");
		fwrite("a",$ShellPath, 'xmldbc -t wizardwps:30:"event WPSPBC.PUSH"\n');
	}
	fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");
	fwrite("a",$ShellPath, "service PHYINF.WIFI restart\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/restartwlan 1\n");
	fwrite("a",$ShellPath, "xmldbc -k renewwlanstatus\n");
	fwrite("a",$ShellPath, 'xmldbc -t renewwlanstatus:30:"xmldbc -X /runtime/restartwlan"\n');
}

fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
set("/runtime/hnap/dev_status", "ERROR");


?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
<soap:Body>
<SetWizardWlanModeResponse xmlns="http://purenetworks.com/HNAP1/">
<SetWizardWlanModeResult>OK</SetWizardWlanModeResult>
</SetWizardWlanModeResponse>
</soap:Body>
</soap:Envelope>
