<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}

include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/trace.php";
include "/htdocs/webinc/config.php";

$wait_time = "2";
$retry_number = 12;

$result = "OK";

$action = query ("/runtime/hnap/GetCurrentInternetStatus/InternetStatus");

if ($action == "true")
{
	$action = "trigger";
}
else if ($action == "false")
{
	$action = "get";
}
else
{
	$action = "";
	$result = "ERROR";
}

TRACE_debug("1 $action = ".$action."");
TRACE_debug("1 $result = ".$result."");

$layout = query("/device/layout");
if($layout=="router") { $INF = $WAN1; }
else { $INF = $BR1; }

$path_inf = XNODE_getpathbytarget("", "inf", "uid", $INF, 0);
$phyinf = query($path_inf."/phyinf");
$path_run_phyinf = XNODE_getpathbytarget("/runtime", "phyinf", "uid", $phyinf, 0);

$wirelessmode = query("/device/wirelessmode");
if($wirelessmode == "WirelessHotspot" || $wirelessmode == "WirelessHotspotExtender" || $wirelessmode == "WirelessClient" || $wirelessmode == "WirelessRepeaterExtender")
{
	$rp_phyinf_wlan1 = XNODE_getpathbytarget("runtime", "phyinf", "uid", $WLAN_APCLIENT, 0);
	$rp_phyinf_wlan2 = XNODE_getpathbytarget("runtime", "phyinf", "uid", $WLAN2_APCLIENT, 0);
	//$rp_phyinf_wlan3 = XNODE_getpathbytarget("runtime", "phyinf", "uid", $WLAN3_APCLIENT, 0);
	
	//if($rp_phyinf_wlan1!="") $rp_phyinf_wlan = $rp_phyinf_wlan1;
	//else if($rp_phyinf_wlan2!="") $rp_phyinf_wlan = $rp_phyinf_wlan2;
	//else if($rp_phyinf_wlan3!="") $rp_phyinf_wlan = $rp_phyinf_wlan3;
	
	$connstatus1 = query($rp_phyinf_wlan1."/media/status");
	$connstatus2 = query($rp_phyinf_wlan2."/media/status");
	//TRACE_debug("connstatus1=".$connstatus1.",connstatus2=".$connstatus2."\n");
	if($connstatus1 == "Connected" || $connstatus2 == "Connected")
	{
		$status =1;
	}
	else
	{
		$status =0;
	}
}
else
{
	$status = get("",$path_run_phyinf."/linkstatus");
}

if( $status != "0" && $status != "")
{ $statusStr = "CONNECTED"; }
else 
{
	$statusStr = "DISCONNECTED";
	$result = "OK_NOTCONNECTED";
}


TRACE_debug("2 $action = ".$action."");
TRACE_debug("2 $result = ".$result."");
TRACE_debug("2 $status = ".$status."");
TRACE_debug("2 $statusStr = ".$statusStr."");

if ($result == "OK")
{
	if ($action == "trigger")
	{
		$cmd = "dnsquery -p -t 2 -d mydlink.com -d dlink.com -d dlink.com.cn -d dlink.com.tw -d google.com -d www.mydlink.com -d www.dlink.com -d www.dlink.com.cn -d www.dlink.com.tw -d www.google.com";
		setattr("/runtime/command", "get", $cmd ." > /var/cmd.result &");
		unlink("/var/cmd.result");
		get("x", "/runtime/command");

		$result = "OK_DETECTING_".$wait_time;

		TRACE_debug("3 trigger $result = ".$result."");
	}
	else
	{
		if (isfile("/var/cmd.result") == 1)
		{
			// make sure the file is existed.
			$ping_result = fread("","/var/cmd.result");

			if (strstr($ping_result, "Internet detected.") == "")
			{
				TRACE_debug("4 ping result");
				$retry_count = query ("/runtime/hnap1/retryCount");
				if ($retry_count == "") { $retry_count = 0; }
				$retry_count ++;
				if ($retry_count < $retry_number) 
				{ 
					$result = "OK_DETECTING_".$wait_time;
					set ("/runtime/hnap1/retryCount", $retry_count);
					//<---Workaround. If we use dnsquery continuely, the result file /var/cmd.result would be empty sometime.
					// It's bug but we don't why now. For this condition, any more detecting action is useless unless we use dnsquery again.
					if($retry_count==3 || $retry_count==5 || $retry_count==10)
					{
						unlink("/var/cmd.result");
						get("x", "/runtime/command");
					}
					//-->
				}
				else 
				{
					$result = "OK_NOTCONNECTED";
					del("/runtime/hnap1/retryCount");
					unlink("/var/cmd.result");
				}
			}
			else
			{
				$result = "OK_CONNECTED";
				del("/runtime/hnap1/retryCount");
				unlink("/var/cmd.result");
			}
		}
		else
		{
				TRACE_debug("4 Internet detected");
				$retry_count = query ("/runtime/hnap1/retryCount");
				if ($retry_count == "") { $retry_count = 0; }
				$retry_count ++;
				if ($retry_count < $retry_number)
				{
					$result = "OK_DETECTING_".$wait_time;
					set ("/runtime/hnap1/retryCount", $retry_count);
				}
				else
				{
					//if the file is not existed, it should return an error.
					$result = "ERROR";
				}
		}
	}
}

?>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
		<GetCurrentInternetStatusResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetCurrentInternetStatusResult><?=$result?></GetCurrentInternetStatusResult>
		</GetCurrentInternetStatusResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>
