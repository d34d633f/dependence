HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/inf.php";
include "/htdocs/phplib/trace.php";
include "/htdocs/webinc/config.php";

$nodebase = "/runtime/hnap/SetVlanSettings";
$path_vlan = "/device/vlan";

$result = "OK";

//$active			=	query($nodebase."/active");
//$priority		=	query($nodebase."/priority");
$managePortVid	=	query($nodebase."/managePortVid");

//if($active=="1")	{set($path_vlan."/active", "1");}
//else				{set($path_vlan."/active", "0");}
//if($priority!="")		{set($path_vlan."/priority", $priority);}
if($managePortVid!="")	{set($path_vlan."/managePortVid", $managePortVid);}

//Move original vlan to "/runtime/hnap/SetRadiusSettings/vlan_old"
$vlan_seqno = get("", $path_vlan."/seqno");
if($vlan_seqno=="")	$vlan_seqno=1;
$vlan_count = 0;
set($nodebase."/vlan_old", "");
movc($path_vlan, $nodebase."/vlan_old");
set($path_vlan."/max", 8);
set($path_vlan."/count", $vlan_count);
set($path_vlan."/seqno", $vlan_seqno);

$managePortVid	=	query($nodebase."/managePortVid");
if($managePortVid!="")	set($path_vlan."/managePortVid", $managePortVid);
else	set($path_vlan."/managePortVid","1");
set($path_vlan."/priority","1");
set($path_vlan."/defaultPortVid","1");

foreach($nodebase."/entry")
{
	$hnap_entry_path = $nodebase."/entry:".$InDeX;
	$vlan_entry_path = $path_vlan."/entry:".$InDeX;
	
	//If the vlan name is new, the responded vlan uid is also new. If the vlan name is old, it has responded vlan uid.
	$vlan_old_path = XNODE_getpathbytarget($nodebase."/vlan_old", "entry", "description", query($hnap_entry_path."/description"), 0); 
	if($vlan_old_path!="") {$vlan_uid = query($vlan_old_path."/uid");}
	else
	{   
			$vlan_uid = "VLAN-".$vlan_seqno;
			$vlan_seqno++;
	}  
	
	//$uid	=	query($hnap_entry_path."/uid");
	$uid	=	$vlan_uid;
	$name	=	query($hnap_entry_path."/description");
	$vid	=	query($hnap_entry_path."/vid");
	$priority	=	query($hnap_entry_path."/priority");
	
	TRACE_debug("$uid=".$uid.", $name=".$name.", $vid=".$vid.", $priority=".$priority);
	set($vlan_entry_path."/uid", $uid);
	set($vlan_entry_path."/description", $name);
	set($vlan_entry_path."/vid", $vid);
	set($vlan_entry_path."/priority", $priority);

	$vlan_count++;
	set($path_vlan."/seqno", $vlan_seqno);
	set($path_vlan."/count", $vlan_count);
}

if($result == "OK")
{
	fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");
	fwrite("a",$ShellPath, "service DEVICE.VLAN restart > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
    <SetVlanSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
      <SetVlanSettingsResult><?=$result?></SetVlanSettingsResult>
    </SetVlanSettingsResponse>
  </soap:Body>
</soap:Envelope>