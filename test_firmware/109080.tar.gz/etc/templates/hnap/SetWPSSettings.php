HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/trace.php";

$phyinf1 = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN1, 0);
$phyinf2 = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN2, 0);
$wifi1 = XNODE_getpathbytarget("/wifi", "entry", "uid", query($phyinf1."/wifi"), 0);
$wifi2 = XNODE_getpathbytarget("/wifi", "entry", "uid", query($phyinf2."/wifi"), 0);

$phyinf4 = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN_APCLIENT, 0);  // wisp ,apc use same wifi with different phyinf
$wifi4 = XNODE_getpathbytarget("/wifi", "entry", "uid", query($phyinf4."/wifi"), 0);

$smart_en = query("/device/features/smartconnect");//When smart connect enabled, change 2.4G WPS setting only
$dev_pin = get("","/runtime/hnap/SetWPSSettings/WPS/DEV_PIN");
$reset = get("","/runtime/hnap/SetWPSSettings/WPS/ResetToUnconfigured");
$pin = get("","/runtime/hnap/SetWPSSettings/WPS/WPSPIN");
$pbc = get("","/runtime/hnap/SetWPSSettings/WPS/WPSPBC");
$wps_enable = get("","/runtime/hnap/SetWPSSettings/WPS/enable");   //used in dap1665 2015new ui
$pbc_en = get("","/runtime/hnap/SetWPSSettings/WPS/ENABLEPBC");
$pin_en = get("","/runtime/hnap/SetWPSSettings/WPS/ENABLEPIN");
$aplock_enable = get("","/runtime/hnap/SetWPSSettings/WPS/aplock");  //used in dap1665 2015new ui
$aplock_runtime=query("/runtime/wps/setting/aplocked");  //traveller add for ten times wifi auto lock
$wps_enableclient = get("","/runtime/hnap/SetWPSSettings/WPS/enableclient");  //used in dap1665 2015new ui
$WirelessMode = query("/runtime/hnap/SetOperationMode/CurrentOPMode");

$result = "ERROR_ACTION";


$aplock_runtime=query("/runtime/wps/setting/aplocked");
if($aplock_runtime=="1")        $aplock_runtime="1";
else                    $aplock_runtime="0";

if( $aplock_enable =="false" &&  $aplock_runtime == 1) //unlock hostapd status by web
{
	set("/runtime/wps/setting/aplocked",0); //unlock wps pin
}


fwrite("w",$ShellPath, "#!/bin/sh\n");

TRACE_debug("$WirelessMode ".$WirelessMode."");
TRACE_debug("$wps_enable ".$wps_enable."");
TRACE_debug("$aplock_enable ".$aplock_enable."");
TRACE_debug("$wps_enableclient ".$wps_enableclient."");
TRACE_debug("$wifi1 ".$wifi1."");
TRACE_debug("$wifi2 ".$wifi2."");
TRACE_debug("$wifi4 ".$wifi4."");

if( $WirelessMode == "WirelessClient" ||$WirelessMode == "WirelessHotspot" )
{
	//set wifi-sta wifi-sta5
	if(wifi4!= "")
	{
		if($wps_enableclient == "true")
		{
			set($wifi4."/wps/enable", 1);
		}
		else
		{
			set($wifi4."/wps/enable", 0);
		}

		if ($aplock_enable == "true")
		{			
       			set($wifi4."/wps/locksecurity", 1);
		}
		else
		{
       			set($wifi4."/wps/locksecurity", 0);
		}
		
	}
	$result = "SUCCESS";
}
else if( $WirelessMode == "WirelessRepeaterExtender"  ||$WirelessMode == "WirelessAp" || $WirelessMode == "WirelessHotspotExtender" || $WirelessMode == "WirelessBridgeWithAp")
{
	//set ap and wifi-sta
	if($wifi1!="")
	{
		if($wps_enable == "true")
		{
			set($wifi1."/wps/enable", 1);
		}
		else
		{
			set($wifi1."/wps/enable", 0);
		}

		if ($aplock_enable == "true")
		{			
			set($wifi1."/wps/locksecurity", 1);
		}
		else
		{			
			set($wifi1."/wps/locksecurity", 0);
		}
	}
	
	if($wifi2!="" && $smart_en == "0" )
	{
		if($wps_enable == "true")
		{
			set($wifi2."/wps/enable", 1);
		}
		else
		{
			set($wifi2."/wps/enable", 0);
		}

		if ($aplock_enable == "true")
		{			
       			set($wifi2."/wps/locksecurity", 1);
		}
		else
		{
       			set($wifi2."/wps/locksecurity", 0);
		}
	}

	if(wifi4!= "")
	{
		if($wps_enable == "true")
		{
			set($wifi4."/wps/enable", 1);
		}
		else
		{
			set($wifi4."/wps/enable", 0);
		}

		if ($aplock_enable == "true")
		{			
       			set($wifi4."/wps/locksecurity", 1);
		}
		else
		{
       			set($wifi4."/wps/locksecurity", 0);
		}
	}
	$result = "SUCCESS";
}
else
{
    fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:xsd="http://www.w3.org/2001/XMLSchema"
    xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <soap:Body>
        <SetWPSSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
            <SetWPSSettingResult><?=$result?></SetWPSSettingResult>
        </SetWPSSettingsResponse>
    </soap:Body>
</soap:Envelope>

