<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/trace.php"; 

$path_vlan = "/device/vlan";

$active			=	query($path_vlan."/active");
$priority		=	query($path_vlan."/priority");
$managePortVid	=	query($path_vlan."/managePortVid");
$defaultPortVid = query($path_vlan."/defaultPortVid");
if($managePortVid=="")	$managePortVid=1;	//set to defaule vlan id

function GetVLANInfo($path)
{
	$vlan_entry_path=$path;
	//TRACE_debug("\n vlan_entry_path=".$vlan_entry_path."\n");
	//$phyinf=query($vlan_entry_path."/phyinf");	
	$uid=query($vlan_entry_path."/uid");
	//TRACE_debug("\n phyinf=".$phyinf.",uid=".$uid."\n");
	//if($phyinf=="" || $uid=="")	{return;}	//it's wrong.
	// get ssid
	//$path_phyinf = XNODE_getpathbytarget("", "phyinf", "uid", $phyinf, 0);	
	//$path_wifi = XNODE_getpathbytarget("/wifi", "entry", "uid", query($path_phyinf."/wifi"), 0);
	//$ssid = query($path_wifi."/ssid");
		
	//$active=query($vlan_entry_path."/active");	if($active=="")	{$active=0;}
	$vid=query($vlan_entry_path."/vid");	if($vid=="")	{$vid=1;}	//set to defaule vlan id
	$priority=query($vlan_entry_path."/priority");	if($priority=="")	{$priority=0;}
	//$display = query($vlan_entry_path."/display");	if($display=="")	{$display=0;}
	//$description = query($vlan_entry_path."/description");
	$description = get("x",$vlan_entry_path."/description");
	echo "			<entry>\n";
	echo "				<uid>".$uid."</uid>\n";
	//echo "				<active>".$active."</active>\n";
	//echo "				<display>".$display."</display>\n";
	//echo "				<phyinf>".$phyinf."</phyinf>\n";
	//echo "				<ssid>".$ssid."</ssid>\n";	
	echo "				<description>".$description."</description>\n";
	echo "				<vid>".$vid."</vid>\n";
	echo "				<priority>".$priority."</priority>\n";
	echo "			</entry>\n";
}
?>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
		<GetVlanSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetVlanSettingsResult>OK</GetVlanSettingsResult>
				 <active><?=$active?></active>
				 <priority><?=$priority?></priority>
				 <managePortVid><?=$managePortVid?></managePortVid>
				 <defaultPortVid><?=$defaultPortVid?></defaultPortVid>
			<?
				foreach($path_vlan."/entry")
				{
					GetVLANInfo($path_vlan."/entry:".$InDeX);
				}
			?>
		</GetVlanSettingsResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>
