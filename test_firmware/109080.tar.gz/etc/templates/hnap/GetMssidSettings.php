<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/encrypt.php";
include "/htdocs/phplib/trace.php"; 

$WLAN1 = "BAND24G-1.1";
$MSSID_24_1 = "BAND24G-1.2";
$MSSID_24_2 = "BAND24G-1.3";
$MSSID_24_3 = "BAND24G-1.4";
$MSSID_5_1	= "BAND5G-1.2";
$MSSID_5_2	= "BAND5G-1.3";
$MSSID_5_3	= "BAND5G-1.4";

$phyinf_path = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN1, 0);
$wifi_path = XNODE_getpathbytarget("/wifi", "entry", "uid", query($phyinf_path."/wifi"), 0);
$isolation = query($wifi_path."/acl/isolation");

function GetMssidInfo($uid)
{
	$phyinf_path = XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);	
	$wifi = query($phyinf_path."/wifi");	
	$wifi_path = XNODE_getpathbytarget("/wifi", "entry", "uid", $wifi, 0);

	$display = query($phyinf_path."/display");
	if($display=="") $display="0";

	$vlan = query($phyinf_path."/vlan");

	$sch = query($phyinf_path."/schedule");
	if($sch!="") { $schedule = XNODE_getschedulename($sch); }
	else {$schedule = "Always";}

//	$ssid = query($wifi_path."/ssid");
	$ssid = get("x",$wifi_path."/ssid");
//	$visibility = query($wifi_path."/ssidhidden");	

	$active = query($phyinf_path."/active");

	$authtype=query($wifi_path."/authtype");
	$encrypt=query($wifi_path."/encrypt");
	$radius1=query($wifi_path."/nwkey/eap/radius:1");
	$radius2=query($wifi_path."/nwkey/eap/radius:2");
	$key="";
	
	if($authtype=="WEP")
	{
		$key=get("",$wifi_path."/nwkey/wep/key");
	}
	else
	{   
		$key=get("",$wifi_path."/nwkey/psk/key");
	}   
	echo "			<entry>\n";
	echo "				<uid>".$uid."</uid>\n";
	echo "				<display>".$display."</display>\n";
	echo "				<ssid>".$ssid."</ssid>\n";
	echo "				<active>".$active."</active>\n";
	echo "				<authtype>".$authtype."</authtype>\n";
	echo "				<encrypt>".$encrypt."</encrypt>\n";
	echo "				<key>".AES_Encrypt128($key)."</key>\n";
	echo "				<radius>".$radius1."</radius>\n";
	echo "				<radius>".$radius2."</radius>\n";
	echo "				<visibility>".map($wifi_path."/ssidhidden", "1", "false", "*", "true")."</visibility>\n";	
	echo "				<vlan>".$vlan."</vlan>\n";
	echo "				<schedule>".$schedule."</schedule>\n";
	echo "			</entry>\n";
}
?>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
		<GetMssidSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetMssidSettingsResult>OK</GetMssidSettingsResult>
				<isolation><?=$isolation?></isolation>
			<?
					GetMssidInfo($MSSID_24_1);
					GetMssidInfo($MSSID_24_2);
					GetMssidInfo($MSSID_24_3);
					GetMssidInfo($MSSID_5_1);
					GetMssidInfo($MSSID_5_2);
					GetMssidInfo($MSSID_5_3);
			?>
		</GetMssidSettingsResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>
