HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";

fwrite("a",$ShellPath, "xmldbc -k wizardwps\n");
fwrite("a",$ShellPath, "event WPS.STOP > /dev/console\n");

//set("/runtime/hnap/dev_status", "ERROR");

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
<soap:Body>
<SetWizardstopwpsResponse xmlns="http://purenetworks.com/HNAP1/">
<SetWizardstopwpsResult>OK</SetWizardstopwpsResult>
</SetWizardstopwpsResponse>
</soap:Body>
</soap:Envelope>
