HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";

function checkAvailableOPMode($RaID, $CurOPMode)
{
	if($CurOPMode=="WirelessBridge" && $FEATURE_NOAPMODE != 1)
	{return "true";}
	else if($CurOPMode=="WirelessRouter" || $CurOPMode=="WirelessHotspot" ||$CurOPMode=="WirelessHotspotExtender")// && get("", "/runtime/device/router/mode") != "")
	{return "true";}
	else if($CurOPMode=="WirelessAp" || $CurOPMode=="WirelessRepeaterExtender" || $CurOPMode=="WirelessBridge" || $CurOPMode=="WirelessBridgeWithAp" || $CurOPMode=="WirelessClient")
	{return "true";}
	return "false";
}

function disableMssid($uid)
{
	$path_phyinf_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);
	set($path_phyinf_wlan."/active", "0");
}

function GetCurrentOPModeFromDevice($RaID)
{
	if(get("", "/device/layout")=="router")
	{
		$ret = "WirelessRouter";
	}
	else if(get("", "/device/layout")=="bridge")
	{
		if(query("/device/op_mode")=="repeater_ext")
			{$ret="WirelessRepeaterExtender";}
		else
			{$ret = "WirelessBridge";}
	}
	return $CurOPMode;
}

function set_wlan_phyinf_active($target_wlan_uid, $enable)
{
        $active = "0";
        if($enable == "true")   $active = "1";
        else				$active = "0";

        $path_target_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $target_wlan_uid, 0);
        set($path_target_wlan."/active", $active);
}

$layout = "router";
$result = "OK";

$RadioID = query("/runtime/hnap/SetOperationMode/RadioID");
$CurrentOPMode = query("/runtime/hnap/SetOperationMode/CurrentOPMode");
$DeviceMode = query("/device/wirelessmode");
$ModeChanged = '0';
if($CurrentOPMode != $DeviceMode)
	$ModeChanged = '1';

if($RadioID!="RADIO_2.4GHz" && $RadioID!="RADIO_2.4G_Guest" && $RadioID!="RADIO_5GHz" && $RadioID!="RADIO_5G_Guest" && $RadioID!="RADIO_5GHz_2" && $RadioID!="RADIO_5GHz_2_Guest")
{$result = "ERROR_BAD_RADIOID";}
else if(checkAvailableOPMode($RadioID, $CurrentOPMode)!="true")
{$result = "ERROR_BAD_CurrentOPMode";}
//else if(GetCurrentOPModeFromDevice($RadioID) != $CurrentOPMode)

else if($CurrentOPMode=="WirelessAp")  // Must same as SetWanSetting.php
{	$layout = "bridge";}
else if($CurrentOPMode == "WirelessBridge")
{	$layout = "bridge";}
else if($CurrentOPMode=="WirelessBridgeWithAp")
{	$layout = "bridge";}
else if($CurrentOPMode=="WirelessClient")
{	$layout = "bridge";}
else if($CurrentOPMode=="WirelessRepeaterExtender")
{	$layout = "bridge";}
else if($CurrentOPMode=="WirelessRouter")
{	$layout = "router";}
else if($CurrentOPMode=="WirelessHotspot")
{	$layout = "router";}
else if($CurrentOPMode=="WirelessHotspotExtender")
{	$layout = "router";}
else
	$result = "ERROR";

//if current is not ap mode, disable all mssid
if($CurrentOPMode!="WirelessAp")
{
	disableMssid("BAND24G-1.2");	
	disableMssid("BAND24G-1.3");	
	disableMssid("BAND24G-1.4");	
	disableMssid("BAND5G-1.2");	
	disableMssid("BAND5G-1.3");	
	disableMssid("BAND5G-1.4");
}

// dhcp server only can enable on ap mode and wisp repeater/client mode(router mode) for dap1665 
if($CurrentOPMode!="WirelessAp" && $layout != "router")
{
	$path_inf_br = XNODE_getpathbytarget("", "inf", "uid", "BRIDGE-1", 0);
	set($path_inf_br."/dhcps4", "");
}
if($CurrentOPMode!="WirelessAp")
{
	$path_dhcps = XNODE_getpathbytarget("dhcps4", "entry", "uid", "DHCPS4-1", 0);
	set($path_dhcps."/router", "");
	set($path_dhcps."/dns/count", "0");
	del($path_dhcps."/dns/entry");
	del($path_dhcps."/dns/entry");
}

$layout_old = get("", "/device/layout");

$reboot = get("","/runtime/device/reboot");
if($layout_old != $layout)
{
	$reboot = "1";
}
else if($reboot == "1")
{
	$reboot = "1";
}
else
{
	$reboot = "0";
}

if($result == "OK")
{
	set("/device/layout", $layout);
	set("/device/wirelessmode", $CurrentOPMode);

	set("/runtime/device/reboot", $reboot);
	

	if($CurrentOPMode=="WirelessClient")
	{
		set("/wifi/entry:9/opmode", "STA"); 
		
		set_wlan_phyinf_active($WLAN1, "false");
		set_wlan_phyinf_active($WLAN2, "false");

		set_wlan_phyinf_active($WLAN_WDS, "false");
		set_wlan_phyinf_active($WLAN2_WDS, "false");
	}
	else if($CurrentOPMode=="WirelessHotspot")
	{
		set("/wifi/entry:9/opmode", "STA"); 
		
		set_wlan_phyinf_active($WLAN1, "false");
		set_wlan_phyinf_active($WLAN2, "false");

		set_wlan_phyinf_active($WLAN_WDS, "false");
		set_wlan_phyinf_active($WLAN2_WDS, "false");
	}
	else if($CurrentOPMode=="WirelessHotspotExtender")
	{
		set("/wifi/entry:9/opmode", "REPEATER"); 
		
		set_wlan_phyinf_active($WLAN_WDS, "false");
		set_wlan_phyinf_active($WLAN2_WDS, "false");
	}
	else if($CurrentOPMode=="WirelessRepeaterExtender")
	{
		set("/wifi/entry:9/opmode", "REPEATER"); 
		
		set_wlan_phyinf_active($WLAN_WDS, "false");
		set_wlan_phyinf_active($WLAN2_WDS, "false");
	}
	else if($CurrentOPMode == "WirelessBridge")
	{
		set_wlan_phyinf_active($WLAN_APCLIENT, "false");
		set_wlan_phyinf_active($WLAN2_APCLIENT, "false");

		//set_wlan_phyinf_active($WLAN1, "false");
		//set_wlan_phyinf_active($WLAN2, "false");
	}
	else if($CurrentOPMode=="WirelessBridgeWithAp")
	{
		set_wlan_phyinf_active($WLAN_APCLIENT, "false");
		set_wlan_phyinf_active($WLAN2_APCLIENT, "false");
	}
	else if($CurrentOPMode=="WirelessAp")
	{
		set_wlan_phyinf_active($WLAN_APCLIENT, "false");
		set_wlan_phyinf_active($WLAN2_APCLIENT, "false");

		set_wlan_phyinf_active($WLAN_WDS, "false");
		set_wlan_phyinf_active($WLAN2_WDS, "false");
	}
	
	if($ModeChanged == '1')
	{
		$path_inf_br3 = XNODE_getpathbytarget("", "inf", "uid", $BR3, 0);
		$path_inf_br4 = XNODE_getpathbytarget("", "inf", "uid", $BR4, 0);
		if($CurrentOPMode=="WirelessAp")
		{
			set($path_inf_br3."/active", "1");
		}
		else
		{
			set($path_inf_br3."/active", "0");
			set($path_inf_br4."/active", "0");
		}
	}
	$result = "ok";
}

TRACE_debug("result=".$result);
TRACE_debug("layout_old=".$layout_old);
TRACE_debug("layout=".$layout);

TRACE_debug("CurrentOPMode=".$CurrentOPMode);

TRACE_debug("reboot=".$reboot);

fwrite("w",$ShellPath, "#!/bin/sh\n");
if($result == "ok")
{
	fwrite("a",$ShellPath, "echo \"[$0]-->Operation mode is Changed\" > /dev/console\n");
/*	if($layout_old != $layout)
	{
		fwrite("a",$ShellPath, "service DEVICE.LAYOUT restart\n");
	}
	
	if($CurrentOPMode=="WirelessHotspotExtender")
	{
		fwrite("a",$ShellPath, "xmldbc -k wisppppoe\n");
		fwrite("a",$ShellPath, 'xmldbc -t wisppppoe:30:"service WAN restart > /dev/console"\n');
	}
*/	
	fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	fwrite("a",$ShellPath, "service ENLAN restart > /dev/console\n");


	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console\n");
}
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<SetOperationModeResponse xmlns="http://purenetworks.com/HNAP1/">
			<SetOperationModeResult><? echo $result; ?></SetOperationModeResult>
		</SetOperationModeResponse>
	</soap:Body>
</soap:Envelope>
