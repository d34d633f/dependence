<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/trace.php"; 

$path_radius = "/device/radius";
function GetRadiusInfo($path)
{
	$uid	=	query($path."/uid");
	$name	=	query($path."/description");
	$server	=	query($path."/server");
	$port	=	query($path."/port");
	$secret =	query($path."/secret");
	
	echo "			<entry>\n";
	echo "				<uid>".$uid."</uid>\n";
	echo "				<name>".$name."</name>\n";
	echo "				<server>".$server."</server>\n";
	echo "				<port>".$port."</port>\n";
	echo "				<secret>".$secret."</secret>\n";
	echo "			</entry>\n";
}
?>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
		<GetRadiusSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetRadiusSettingsResult>OK</GetRadiusSettingsResult>				
<?
foreach($path_radius."/entry")
{
	GetRadiusInfo($path_radius."/entry:".$InDeX);
}
?>
		</GetRadiusSettingsResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>
