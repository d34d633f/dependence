<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}

include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/encrypt.php";

$result = "OK";

$WLAN_WDS_24 = $WLAN_WDS;
$WLAN_WDS_5 = $WLAN2_WDS;
$WLAN_AP_24 = "BAND24G-1.1";
$WLAN_AP_5 = "BAND5G-1.1";

function GetWdsList($uid)
{	

	$phyinf_path = XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);	
	$wifi = query($phyinf_path."/wifi");	
	$wifi_path = XNODE_getpathbytarget("/wifi", "entry", "uid", $wifi, 0);

	TRACE_debug("uid=".$uid.",phyinf_path=".$phyinf_path.",wifi_path=".$wifi_path);

	$active=query($phyinf_path."/active");
	$ssid=get("x",$wifi_path."/ssid");
	$auth=query($wifi_path."/authtype");
	$encrypt=query($wifi_path."/encrtype");
	$key=get("",$wifi_path."/nwkey/psk/key");
	$freq=query($phyinf_path."/media/freq");

	//get channel, bandwidth and 802.11 mode	
	if($freq == "2.4" || $freq == "24")
		$host_phyinf_path = XNODE_getpathbytarget("", "phyinf", "uid", "BAND24G-1.1", 0);
	else
		$host_phyinf_path = XNODE_getpathbytarget("", "phyinf", "uid", "BAND5G-1.1", 0);
	TRACE_debug("freq=".$freq.",host_phyinf_path=".$host_phyinf_path);

	$channel = query($host_phyinf_path."/media/channel");
	$wlmode = query($host_phyinf_path."/media/wlmode");
	$width = query($host_phyinf_path."/media/dot11n/bandwidth");
	if( $width == "20" )
	{ $bandwidth = "20"; }
	else if( $width == "40" )
	{ $bandwidth = "40"; }
	else if( $width == "80" )
	{ $bandwidth = "80"; }
	else if( $width == "20+40" )
	{ $bandwidth = "0"; }
	else if( $width == "20+40+80" )
	{ $bandwidth = "1"; }
	else
	{ $bandwidth = "0"; }	

	echo "			<Wdslist>\n";
	echo "				<uid>".$uid."</uid>\n";	
	echo "				<active>".$active."</active>\n";
	echo "				<ssid>".$ssid."</ssid>\n";
	echo "				<wlmode>".$wlmode."</wlmode>\n";
	echo "				<channel>".$channel."</channel>\n";
	echo "				<bandwidth>".$bandwidth."</bandwidth>\n";
	echo "				<encrypt>".$encrypt."</encrypt>\n";
	echo "				<key>".AES_Encrypt128($key)."</key>\n";
	foreach($wifi_path."/wds/entry")
	{
		$wds_list_path = $wifi_path."/wds/entry:".$InDeX;
		TRACE_debug("wds_list_path=".$wds_list_path);
		$active = query($wds_list_path."/active");
		$description = query($wds_list_path."/description");
		$mac = query($wds_list_path."/mac");	
		echo "				<entry>\n";
		echo "					<description>".$description."</description>\n";
		echo "					<active>".$active."</active>\n";
		echo "					<mac>".$mac."</mac>\n";
		echo "				</entry>\n";
	}
	echo "			</Wdslist>\n";
}

?>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
		<GetWDSsettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetWDSsettingsResult><?=$result?></GetWDSsettingsResult>
<?
GetWdsList($WLAN_WDS_24);
GetWdsList($WLAN_WDS_5);
?>	
		</GetWDSsettingsResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>
