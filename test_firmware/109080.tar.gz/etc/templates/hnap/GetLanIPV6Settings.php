<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/trace.php";
include "/htdocs/webinc/config.php";

//$lan = $LAN4;   // IPv6 Default Lan is LAN-4.
$lan = $BR4;
function GetLanIPV6Info($uid)
{
	$path_inf = XNODE_getpathbytarget("", "inf", "uid", $uid, 0);
	$path_inet = XNODE_getpathbytarget("/inet", "entry", "uid", query($path_inf."/inet"), 0);

	$path_run_inf = XNODE_getpathbytarget("/runtime", "inf", "uid", $uid, 0);
	$path_run_inet = $path_run_inf."/inet";	

	$mode = query($path_inet."/ipv6/mode");
	if($mode == "")	$mode="LL";
	echo "		<mode>".$mode."</mode>\n";
	TRACE_debug("[GetLanIPV6Info] $uid=".$uid.", $mode=".$mode);

	if($mode=="LL")
	{
		$path_rphy = XNODE_getpathbytarget("/runtime", "phyinf", "uid", query($path_inf."/phyinf"), 0);
		$linklocal_addr = query($path_rphy."/ipv6/link/ipaddr");
		$linklocal_prefix = query($path_rphy."/ipv6/link/prefix");
		TRACE_debug("[GetLanIPV6Info] $linklocal_addr=".$linklocal_addr.", $linklocal_prefix=".$linklocal_prefix);
		echo "				<ipaddr>".$linklocal_addr."</ipaddr>\n";
	}
	if($mode=="AUTO")
	{
		$dns1	=	query($path_inet."/ipv6/dns/entry:1");
		$dns2	=	query($path_inet."/ipv6/dns/entry:2");
		$count	=	query($path_inet."/ipv6/dns/count");
		
		$dns1_run	=	query($path_run_inet."/ipv6/dns:1");
		$dns2_run	=	query($path_run_inet."/ipv6/dns:2");
		$count_run	=	query($path_run_inet."/ipv6/dns/count");
		$gateway_run = 	query($path_run_inet."/ipv6/gateway");
		
		TRACE_debug("[GetLanIPV6Info] $dns1=".$dns1.", $dns2=".$dns2);
		echo "				<count>".$count."</count>\n";
		if($dns1!="")
			echo "				<dns>".$dns1."</dns>\n";
		if($dns2!="")
			echo "				<dns>".$dns2."</dns>\n";
			
		TRACE_debug("[GetLanIPV6Info] $dns1_run=".$dns1_run.", $dns2_run=".$dns2_run);	
		
		echo "				<count_home>".$count_run."</count_home>\n";
		if($dns1_run!="")
			echo "				<dns_home>".$dns1_run."</dns_home>\n";
		if($dns1_run!="")
			echo "				<dns_home>".$dns2_run."</dns_home>\n";
			
		echo "				<gateway_home>".$gateway_run."</gateway_home>\n";
			
	}
	if($mode=="STATIC")
	{
		$ipaddr	=	query($path_inet."/ipv6/ipaddr");
		$prefix	=	query($path_inet."/ipv6/prefix");
		$gateway	=	query($path_inet."/ipv6/gateway");
		$dns1	=	query($path_inet."/ipv6/dns/entry:1");
		$dns2	=	query($path_inet."/ipv6/dns/entry:2");
		$count	=	query($path_inet."/ipv6/dns/count");
		
		$ipaddr_run	=	query($path_run_inet."/ipv6/ipaddr");
		$prefix_run	=	query($path_run_inet."/ipv6/prefix");
		$gateway_run	=	query($path_run_inet."/ipv6/gateway");
		$dns1_run	=	query($path_run_inet."/ipv6/dns:1");
		$dns2_run	=	query($path_run_inet."/ipv6/dns:2");
		$count_run	=	query($path_run_inet."/ipv6/dns/count");
		
		TRACE_debug("[GetLanIPV6Info] $ipaddr=".$ipaddr.", $prefix=".$prefix.", $gateway=".$gateway.", $dns1=".$dns1.", $dns2=".$dns2);
		echo "				<ipaddr>".$ipaddr."</ipaddr>\n";
		echo "				<prefix>".$prefix."</prefix>\n";
		echo "				<gateway>".$gateway."</gateway>\n";
		echo "				<count>".$count."</count>\n";
		if($dns1!="")
			echo "				<dns>".$dns1."</dns>\n";
		if($dns2!="")
			echo "				<dns>".$dns2."</dns>\n";
						
		TRACE_debug("[GetLanIPV6Info] $ipaddr_run=".$ipaddr_run.", $prefix_run=".$prefix_run.", $gateway_run=".$gateway_run.", $dns1_run=".$dns1_run.", $dns2_run=".$dns2_run);
		echo "				<ipaddr_home>".$ipaddr_run."</ipaddr_home>\n";
		echo "				<prefix_home>".$prefix_run."</prefix_home>\n";
		echo "				<gateway_home>".$gateway_run."</gateway_home>\n";
		echo "				<count_home>".$count_run."</count_home>\n";
		if($dns1_run!="")
			echo "				<dns_home>".$dns1_run."</dns_home>\n";
		if($dns1_run!="")
			echo "				<dns_home>".$dns2_run."</dns_home>\n";
	}
}
?>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
		<GetLanIPV6SettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetLanIPV6SettingsResult>OK</GetLanIPV6SettingsResult>
			<? GetLanIPV6Info($lan); ?>
		</GetLanIPV6SettingsResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>
