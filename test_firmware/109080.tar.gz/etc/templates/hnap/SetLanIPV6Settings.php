HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/inf.php";
include "/htdocs/phplib/trace.php";
include "/htdocs/webinc/config.php";

$nodebase = "/runtime/hnap/SetLanIPV6Settings";

$result = "OK";

//$lan = $LAN4;   // IPv6 Default Lan is LAN-4.
$lan = $BR4;

$path_inf = XNODE_getpathbytarget("", "inf", "uid", $lan, 0);
$path_inet = XNODE_getpathbytarget("/inet", "entry", "uid", query($path_inf."/inet"), 0);

$mode = query($nodebase."/mode");

$ipaddr = "";
$prefix = "";
$gateway = "";
$dns1 = "";
$dns2 = "";
$count = "";
$active = "0";
if($mode=="AUTO")
{
	$active = "1";
	$dns1	=	query($nodebase."/dns:1");
	$dns2	=	query($nodebase."/dns:2");
	$count	=	query($nodebase."/count");
	TRACE_debug("[SetLanIPV6Info] $mode=".$mode.", $dns1=".$dns1.", $dns2=".$dns2);
}
if($mode=="STATIC")
{
	$active = "1";
	$ipaddr	=	query($nodebase."/ipaddr");
	$prefix	=	query($nodebase."/prefix");
	$gateway=	query($nodebase."/gateway");
	$dns1	=	query($nodebase."/dns:1");
	$dns2	=	query($nodebase."/dns:2");
	$count	=	query($nodebase."/count");
	TRACE_debug("[SetLanIPV6Info] $mode=".$mode.", $ipaddr=".$ipaddr.", $prefix=".$prefix.", $gateway=".$gateway.", $dns1=".$dns1.", $dns2=".$dns2);
}
set($path_inf."/active", $active);
set($path_inet."/ipv6/mode", $mode);
set($path_inet."/ipv6/ipaddr", $ipaddr);
set($path_inet."/ipv6/prefix", $prefix);
set($path_inet."/ipv6/gateway", $gateway);
set($path_inet."/ipv6/dns/entry:1", $dns1);
set($path_inet."/ipv6/dns/entry:2", $dns2);
set($path_inet."/ipv6/dns/count", $count);

if($result == "OK")
{
	fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");
	fwrite("a",$ShellPath, "phpsh /etc/events/INF-RESTART.php PREFIX=BRIDGE > /dev/console\n");//Event "LAN.RESTART"
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
    <SetLanIPV6SettingsResponse xmlns="http://purenetworks.com/HNAP1/">
      <SetLanIPV6SettingsResult><?=$result?></SetLanIPV6SettingsResult>
    </SetLanIPV6SettingsResponse>
  </soap:Body>
</soap:Envelope>
