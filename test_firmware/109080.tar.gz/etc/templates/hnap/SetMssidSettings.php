HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/inf.php";
include "/htdocs/phplib/trace.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/encrypt.php";

$nodebase = "/runtime/hnap/SetMssidSettings";
$WLAN1 = "BAND24G-1.1";
$MSSID_24_1 = "BAND24G-1.2";
$MSSID_24_2 = "BAND24G-1.3";
$MSSID_24_3 = "BAND24G-1.4";
$MSSID_5_1	= "BAND5G-1.2";
$MSSID_5_2	= "BAND5G-1.3";
$MSSID_5_3	= "BAND5G-1.4";

$result = "OK";
$isolation		=	query($nodebase."/isolation");
$wlan1_phyinf_path = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN1, 0);
$wlan1_wifi_path = XNODE_getpathbytarget("/wifi", "entry", "uid", query($wlan1_phyinf_path."/wifi"), 0);
if($isolation=="1")	{set($wlan1_wifi_path."/acl/isolation", "1");}
else				{set($wlan1_wifi_path."/acl/isolation", "0");}

function clean_display($uid)
{
	$phyinf_path = XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);
	set($phyinf_path."/display","0");
	set($phyinf_path."/active","0");
}

clean_display($MSSID_24_1);
clean_display($MSSID_24_2);
clean_display($MSSID_24_3);
clean_display($MSSID_5_1);
clean_display($MSSID_5_2);
clean_display($MSSID_5_3);

foreach($nodebase."/entry")
{
	$entry_path = $nodebase."/entry:".$InDeX;

	$uid = query($entry_path."/uid");
	$phyinf_path = XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);
	$wifi_path = XNODE_getpathbytarget("/wifi", "entry", "uid", query($phyinf_path."/wifi"), 0);

	$active		= query($entry_path."/active");
	$ssid		= query($entry_path."/ssid");
	$encrypt	= query($entry_path."/encrypt");
	$authtype	= query($entry_path."/authtype");
	$key		= query($entry_path."/key");
	$key = AES_Decrypt128($key);
//	$visibility	= query($entry_path."/visibility");
	
	if( query($entry_path."/visibility") == "false" )
	{ $visibility = "1"; }
	else
	{ $visibility = "0"; }
	
	$vlan		= query($entry_path."/vlan");
	$schedule	= query($entry_path."/schedule");
	$radius1	= query($entry_path."/radius:1");
	$radius2	= query($entry_path."/radius:2");
	$dislpay	= "1";
	
	TRACE_debug("$entry_path=".$entry_path);
	TRACE_debug("$phyinf=".$uid.", $active=".$active.", $ssid=".$ssid.",$vlan=".$vlan.", $schedule=".$schedule);

	set($phyinf_path."/display", $dislpay);
//	set($phyinf_path."/schedule", $schedule);
	if($schedule!="Always")
	{
		$sch = XNODE_getscheduleuid($schedule);
		set($phyinf_path."/schedule",$sch);
	}
	else
	{
		set($phyinf_path."/schedule","");
	}

	set($wifi_path."/ssid", $ssid);
	set($wifi_path."/ssidhidden", $visibility);
	set($phyinf_path."/active", $active);
	set($phyinf_path."/vlan", $vlan);
	TRACE_debug("$authtype=".$authtype);
	if($authtype=="None")
	{
		set($wifi_path."/authtype","OPEN");
		set($wifi_path."/encrtype","NONE");
	}
	if($authtype=="WEP")
	{
		$weplen=query($entry_path."/weplen");
		//$key=query($wifi_path."/nwkey/wep/key");
		if( $weplen == "WEP-64" )
        {
			$weplen = 64;
		}
		else if( $weplen == "WEP-128" )
		{
			$weplen = 128;
		}
		else
		{
			$result = "ERROR_ENCRYPTION_NOT_SUPPORTED";
		}
		if( $key == "" )
		{ $result = "ERROR_ILLEGAL_KEY_VALUE"; }
		else
		{
				$keyLen = strlen($key);
				if(isprint($key)==1 && $keyLen==5 && $wepLen==64) { $ascii = "1";}
				else if(isprint($key)==1 && $keyLen==13 && $wepLen==128) { $ascii = "1";}
				else if(isxdigit($key)==1 && $keyLen==10 && $wepLen==64) { $ascii = "0";}
				else if(isxdigit($key)==1 && $keyLen==26 && $wepLen==128) { $ascii = "0";}
				else {$result = "ERROR_ILLEGAL_KEY_VALUE";}
		}
		if($result == "OK")
		{
				set($wifi_path."/wps/configured", "1");
				set($wifi_path."/authtype", "SHARED");
				set($wifi_path."/encrtype","WEP");
				set($wifi_path."/nwkey/wep/size", $weplen);
				set($wifi_path."/nwkey/wep/ascii", $ascii);
				set($wifi_path."/nwkey/wep/defkey", "1");
				$defKey = query($wifi_path."nwkey/wep/defkey");
				set($wifi_path."/nwkey/wep/key:".$defKey, $key);
		}
	}
	if($authtype=="WPA/WPA2-Personal")
	{
		//$key=get("x",$wifi_path."/nwkey/psk/key");
		if( $key == "" )
		{
				$result = "ERROR_ILLEGAL_KEY_VALUE";
		}
		if($result == "OK")
		{
				set($wifi_path."/wps/configured", "1");
				set($wifi_path."/authtype","WPA+2PSK");
				set($wifi_path."/encrtype","TKIP+AES");
				set($wifi_path."/nwkey/wep/ascii","1");
				set($wifi_path."/nwkey/psk/key",$key);
				set($wifi_path."/nwkey/psk/passphrase", "1");
				set($wifi_path."/nwkey/wpa/groupintv","3600");
		}
	}
	if($authtype=="WPA/WPA2-Enterprise")
	{TRACE_debug("$radius1=".$radius1);
				set($wifi_path."/wps/configured", "1");
				set($wifi_path."/authtype","WPA+2");
				set($wifi_path."/encrtype","TKIP+AES");
				set($wifi_path."/nwkey/wep/ascii","1");
				set($wifi_path."/nwkey/eap/radius:1",$radius1);
				set($wifi_path."/nwkey/eap/radius:2",$radius2);
				set($wifi_path."/nwkey/psk/passphrase", "1");
				set($wifi_path."/nwkey/wpa/groupintv","3600");
	}

}

if($result == "OK")
{
	fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");
	fwrite("a",$ShellPath, "service PHYINF.WIFI restart > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
    <SetMssidSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
      <SetMssidSettingsResult><?=$result?></SetMssidSettingsResult>
    </SetMssidSettingsResponse>
  </soap:Body>
</soap:Envelope>