<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}

include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/inf.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/trace.php"; 

$result="OK";
$layout=query("/device/layout");
if($layout=="router")
$LAN = $LAN1;
else
$LAN = $BR1;

$path_inf_lan1 = XNODE_getpathbytarget("", "inf", "uid", $LAN, 0);
$lan1_inet = get("", $path_inf_lan1."/inet");
$path_inet_lan1 = XNODE_getpathbytarget("inet", "entry", "uid", $lan1_inet, 0);
$dhcps4_lan1 = query($path_inf_lan1."/dhcps4");
if($dhcps4_lan1=="") {$dhcps4_lan1="DHCPS4-1";} //If $dhcps4_lan1 is empty, it means the dhcp server in LAN1 is disabled.
$path_dhcps4_lan1 = XNODE_getpathbytarget("dhcps4", "entry", "uid", $dhcps4_lan1, 0);
TRACE_debug("path_inf_lan1=".$path_inf_lan1);
TRACE_debug("path_inet_lan1=".$path_inet_lan1);
TRACE_debug("path_dhcps4_lan1=".$path_dhcps4_lan1);

//get lan connection type, 1:static 0:dynamic
$type=query($path_inet_lan1."/ipv4/static");

$hostname = get("", "/device/hostname");
if(get("", $path_inf_lan1."/dns4") != "")	$dnsr = "true";
else										$dnsr = "false";

if($type == "1")
{
	$ipaddress = get("", $path_inet_lan1."/ipv4/ipaddr");
	$subnetmask = get("", $path_inet_lan1."/ipv4/mask");
	if($subnetmask!="") $subnetmask=ipv4int2mask($subnetmask);
}
else
{
	$ipaddress = get("", "runtime/inf/inet/ipv4/ipaddr");
	$subnetmask = get("", "runtime/inf/inet/ipv4/mask");
	if($subnetmask!="") $subnetmask=ipv4int2mask($subnetmask);
}

$gateway = get("", $path_inet_lan1."/ipv4/gateway");
$dns1 = get("", $path_inet_lan1."/ipv4/dns/entry");
$dns2 = get("", $path_inet_lan1."/ipv4/dns/entry:2");
$local_domain_name = query($path_dhcps4_lan1."/domain");
$start = get("", $path_dhcps4_lan1."/start");
$end = get("", $path_dhcps4_lan1."/end");
$dhcpgateway = get("", $path_dhcps4_lan1."/router");
$dhcpdns1 = get("", $path_dhcps4_lan1."/dns/entry");
$dhcpdns2 = get("", $path_dhcps4_lan1."/dns/entry:2");
$leasetime = get("", $path_dhcps4_lan1."/leasetime")/60;
if(get("", $path_dhcps4_lan1."/broadcast") == "yes")		$broadcast = "true";
else																										$broadcast = "false";

?>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
<GetNetworkSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
	<GetNetworkSettingsResult><?=$result?></GetNetworkSettingsResult>
		<Type><?=$type?></Type>
		<IPAddress><?=$ipaddress?></IPAddress>
		<SubnetMask><?=$subnetmask?></SubnetMask>		
		<Gateway><?=$gateway?></Gateway>		
		<PrimaryDNS><?=$dns1?></PrimaryDNS>		
		<SecondaryDNS><?=$dns2?></SecondaryDNS>
		<DeviceName><?=$hostname?></DeviceName>
		<LocalDomainName><?=$local_domain_name?></LocalDomainName>
		<IPRangeStart><?=$start?></IPRangeStart>
		<IPRangeEnd><?=$end?></IPRangeEnd>
		<DHCPGateway><?=$dhcpgateway?></DHCPGateway>
		<DHCPDNS1><?=$dhcpdns1?></DHCPDNS1>
		<DHCPDNS2><?=$dhcpdns2?></DHCPDNS2>
		<LeaseTime><?=$leasetime?></LeaseTime>
		<Broadcast><?=$broadcast?></Broadcast>
		<DNSRelay><?=$dnsr?></DNSRelay>
	</GetNetworkSettingsResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>
