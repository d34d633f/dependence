HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/encrypt.php";

$nodebase="/runtime/hnap/SetWDSsettings";
$result = "OK";

$RadioID = query($nodebase."/RadioID");
if($RadioID=="RADIO_2.4GHz")
{
	$wlan_host=$WLAN1;
	$wlan=$WLAN_WDS;
	$band="2.4GHz";
}
if($RadioID=="RADIO_5GHz")
{
	$wlan_host=$WLAN2;
	$wlan=$WLAN2_WDS;
	$band="5GHz";
}

$count = 0;
TRACE_debug("RadioID=".$RadioID.",wlan_host=".$wlan_host.",wlan=".$wlan);

$path_phyinf_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $wlan, 0);
$path_wlan_wifi = XNODE_getpathbytarget("/wifi", "entry", "uid", query($path_phyinf_wlan."/wifi"), 0);
$path_phyinf_wlanhost = XNODE_getpathbytarget("", "phyinf", "uid", $wlan_host, 0);
$path_wlanhost_wifi = XNODE_getpathbytarget("/wifi", "entry", "uid", query($path_phyinf_wlanhost."/wifi"), 0);

$active = query($nodebase."/active");
$opmode = query($nodebase."/opmode");
$ssid =  query($nodebase."/ssid");
$channel =  query($nodebase."/channel");
$width =  query($nodebase."/channelWidth");
if( $width == "20" )
{ $bandWidth = "20"; }
else if( $width == "40" )
{ $bandWidth = "40"; }
else if( $width == "80" )
{ $bandWidth = "80"; }
else if( $width == "0")
{ $bandWidth = "20+40"; }
else if( $width == "1")
{ $bandWidth = "20+40+80"; }
$mode =  query($nodebase."/mode");
$Key = query($nodebase."/key");
$Key = AES_Decrypt128($Key);
$authtype = query($nodebase."/authtype");
$encrtype = query($nodebase."/encrtype");
TRACE_debug("active=".$active.",opmode=".$opmode.",ssid=".$ssid);
if($opmode=="WirelessBridgeWithAp")	
set($path_wlan_wifi."/opmode","WDS+AP");
else
set($path_wlan_wifi."/opmode","WDS");
set($path_phyinf_wlan."/active", $active);
set($path_wlan_wifi."/ssid",$ssid );
set($path_phyinf_wlanhost."/active", $active);
set($path_wlan_wifi."/wps/configured", "1");
set($path_wlan_wifi."/authtype",$authtype );
set($path_wlan_wifi."/encrtype",$encrtype);	
set($path_wlan_wifi."/nwkey/psk/passphrase", "1");
set($path_wlan_wifi."/nwkey/psk/key",$Key);
//set to primary inf
set($path_phyinf_wlanhost."/media/channel", $channel);
set($path_phyinf_wlanhost."/media/wlmode", $mode);
set($path_phyinf_wlanhost."/media/dot11n/bandwidth", $bandWidth);

//delete all wds entry
set($nodebase."/wds_old", "");
movc($path_wlan_wifi."/wds", $nodebase."/wds_old");
set($path_wlan_wifi."/wds/max", 4);
set($path_wlan_wifi."/wds/count", 0);

foreach($nodebase."/entry")
{
	$path = $nodebase."/entry:".$InDeX;
	$active =  query($path."/active");
	$freq =  query($path."/freq");
	$description =  query($path."/description");
	$mac =  query($path."/mac");
	$remotemac =  query($path."/remotemac");	
	TRACE_debug("freq=".$freq.",description=".$description.",mac=".$mac);
	
	if($freq==$band)
	{
		$count++;
		set($path_wlan_wifi."/wds/count",$count);
		$path_entry = $path_wlan_wifi."/wds/entry:".$count;	
		set($path_entry."/active",$active);
		set($path_entry."/description",$description);
		set($path_entry."/mac",$mac);
		set($path_entry."/remotemac",$remotemac);
	}
}

fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "echo \"[$0]-->WDS Change\" > /dev/console\n");
if( $result == "OK" )
{
	fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -k \"HNAP_".$SRVC_WLAN."\"\n");
	fwrite("a",$ShellPath, "xmldbc -t \"HNAP_".$SRVC_WLAN.":5:service ".$SRVC_WLAN." restart\"\n");
	//fwrite("a",$ShellPath, "xmldbc -k \"HNAP_BRIDGE\"\n");
	//fwrite("a",$ShellPath, "xmldbc -t \"HNAP_BRIDGE:2:service BRIDGE restart\"\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error, so we do nothing...\" > /dev/console");
}
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <SetWDSsettingsResponse xmlns="http://purenetworks.com/HNAP1/">
      <SetWDSsettingsResult><?=$result?></SetWDSsettingsResult>
    </SetWDSsettingsResponse>
  </soap:Body>
</soap:Envelope>
