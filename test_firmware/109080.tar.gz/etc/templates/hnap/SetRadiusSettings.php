HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/inf.php";
include "/htdocs/phplib/trace.php";
include "/htdocs/webinc/config.php";

$nodebase = "/runtime/hnap/SetRadiusSettings";
$path_radius = "/device/radius";

$result = "OK";

//Move original radius to "/runtime/hnap/SetRadiusSettings/radius_old"
$radius_seqno = get("", $path_radius."/seqno");
if($radius_seqno=="")	$radius_seqno=1;
$radius_count = 0;
set($nodebase."/radius_old", "");
movc($path_radius, $nodebase."/radius_old");
set($path_radius."/seqno", $radius_seqno);
set($path_radius."/max", 4);
set($path_radius."/count", $radius_count);

foreach($nodebase."/entry")
{
	$hnap_entry_path = $nodebase."/entry:".$InDeX;
	$radius_entry_path = $path_radius."/entry:".$InDeX;
	
	//If the radius name is new, the responded radius uid is also new. If the radius name is old, it has responded radius uid.
	$radius_old_path = XNODE_getpathbytarget($nodebase."/radius_old", "entry", "description", query($hnap_entry_path."/name"), 0); 
	if($radius_old_path!="") {$radius_uid = query($radius_old_path."/uid");}
	else
	{   
			$radius_uid = "RADIUS-".$radius_seqno;
			$radius_seqno++;
	}  
	
	//$uid	=	query($hnap_entry_path."/uid");
	$uid	=	$radius_uid;
	$name	=	query($hnap_entry_path."/name");
	$server	=	query($hnap_entry_path."/server");
	$port	=	query($hnap_entry_path."/port");
	$secret =	query($hnap_entry_path."/secret");
	
	TRACE_debug("$uid=".$uid.", $name=".$name.", $server=".$server.", $port=".$port.", $secret=".$secret);
	set($radius_entry_path."/uid", $uid);
	set($radius_entry_path."/description", $name);
	set($radius_entry_path."/server", $server);
	set($radius_entry_path."/port", $port);
	set($radius_entry_path."/secret", $secret);

	$radius_count++;
	set($path_radius."/seqno", $radius_seqno);
	set($path_radius."/count", $radius_count);
}

if($result == "OK")
{
	fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");
	//fwrite("a",$ShellPath, "service DEVICE.VLAN restart > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
    <SetRadiusSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
      <SetRadiusSettingsResult><?=$result?></SetRadiusSettingsResult>
    </SetRadiusSettingsResponse>
  </soap:Body>
</soap:Envelope>