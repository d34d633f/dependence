HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";

$reboot = get("", "/runtime/device/reboot");
$CurrentOPMode = query("/runtime/hnap/SetOperationMode/CurrentOPMode");
$result = "REBOOT";

TRACE_debug("result=".$result);
TRACE_debug("CurrentOPMode=".$CurrentOPMode);
TRACE_debug("reboot=".$reboot);

if($result=="REBOOT")
{
	fwrite("a",$ShellPath, "echo \"[$0]-->Operation reboot\" > /dev/console\n");

	if($reboot == "1")
	{
		fwrite("a",$ShellPath, "service DEVICE.LAYOUT restart\n");
	}
	if($CurrentOPMode=="WirelessHotspotExtender")
	{
		fwrite("a",$ShellPath, "xmldbc -k wisppppoe\n");
		fwrite("a",$ShellPath, 'xmldbc -t wisppppoe:30:"service WAN restart > /dev/console"\n');
	}
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console\n");
}
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
<soap:Body>
<SetOperationRebootResponse xmlns="http://purenetworks.com/HNAP1/">
<SetOperationRebootResult>OK</SetOperationRebootResult>
</SetOperationRebootResponse>
</soap:Body>
</soap:Envelope>