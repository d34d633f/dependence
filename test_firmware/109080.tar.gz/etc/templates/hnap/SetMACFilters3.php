HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
include "/htdocs/phplib/trace.php"; 
include "/htdocs/phplib/xnode.php";

echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
$rlt="OK";
$nodebase="/runtime/hnap/SetMACFilters3/";
$enable=query($nodebase."enable");
$MAC=query($nodebase."mac");

if($enable=="1")
	$action = "add_acl_table";
else
	$action = "rm_acl_table";
if($MAC=="")
	$rlt="err";
TRACE_debug("$rlt=".$rlt.",$action=".$action.",$MAC=".$MAC);
if($rlt == "OK")
{	
	set("/runtime/acl/action", $action); 
	set("/runtime/acl/mac", $MAC); 
	fwrite("a",$ShellPath, "event MACACL  > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
}
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <SetMACFilters3Response xmlns="http://purenetworks.com/HNAP1/">
      <SetMACFilters3Result><?=$rlt?></SetMACFilters3Result>
    </SetMACFilters3Response>
  </soap:Body>
</soap:Envelope>
