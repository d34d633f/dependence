HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";

function ChangeToBoolvalue($value)
{
        if($value == "1") return "true";
        else return "false";
}

$result = "OK";
$enable = get("","/runtime/hnap/SetSmartconnectSettings/Enabled");
$enable_gz = get("","/runtime/hnap/SetSmartconnectSettings/GZ_Enabled");

$current_enable = query("/device/features/smartconnect");
$current_enable_gz = query("/device/features/smartconnect_gz");

$current_enable = ChangeToBoolvalue($current_enable);
$current_enable_gz = ChangeToBoolvalue($current_enable_gz);

if($enable=="")
{
	$enable = query("/device/features/smartconnect");
	$enable = ChangeToBoolvalue($enable);
}

if($enable_gz=="")
{
	$enable_gz = query("/device/features/smartconnect_gz");
	$enable_gz = ChangeToBoolvalue($enable_gz);
}

$path_guest = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN1_GZ, 0);
$guest_is_active = query($path_guest."/active");	

if($enable == "true")
{
	set("/device/features/smartconnect", 1);
	if ($enable_gz == "true")
	{
		set("/device/features/smartconnect_gz", 1);
	}
	else if ($enable_gz == "false")
	{
		set("/device/features/smartconnect_gz", 0);
	}
}
else
{
	set("/device/features/smartconnect", 0);
	set("/device/features/smartconnect_gz", 0);
}

if($current_enable != $enable || $current_enable_gz != $enable_gz) $result = "REBOOT";

fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "echo [$0] > /dev/console\n");
fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");
fwrite("a",$ShellPath, "xmldbc -k \"HNAP_SMARTCONNECT\"\n");
fwrite("a",$ShellPath, "xmldbc -t \"HNAP_SMARTCONNECT:3:service SMARTCONNECT restart\"\n");
fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
set("/runtime/hnap/dev_status", "ERROR");

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
<soap:Body>
<SetSmartconnectSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
	<SetSmartconnectSettingsResult><?=$result?></SetSmartconnectSettingsResult>
</SetSmartconnectSettingsResponse>
</soap:Body>
</soap:Envelope>

