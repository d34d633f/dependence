#!/bin/sh
echo [$0]: $1 ... > /dev/console
layout=`xmldbc -w /device/layout`   
if [ "$layout" == "router" ]; then
	if [ -f "/var/run/LAN-1.UP" ]; then
		service UPNP.LAN-1 restart
	else
		sleep 20
		service UPNP.LAN-1 restart
	fi
else
	if [ -f "/var/run/BRIDGE-1.UP" ]; then
		service INFSVCS.BRIDGE-1 restart
	else
		sleep 20
		service INFSVCS.BRIDGE-1 restart
	fi
fi

#workaround to fix UPNP-alive issue.
