#!/bin/sh
consolepwd
exit 0
