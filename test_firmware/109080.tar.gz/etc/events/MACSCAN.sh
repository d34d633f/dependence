#!/bin/sh
brctl showmacs br0 > /dev/null
exit 0
