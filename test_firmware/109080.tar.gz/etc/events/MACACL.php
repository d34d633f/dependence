<?
$acl_action = query("/runtime/acl/action");
if ($acl_action != "")
{
       	$acl_list = query("/runtime/acl/mac");
	if($acl_list != "")
	{
	        $mac = cut($acl_list, "0", ":");
	        $mac = $mac.cut($acl_list, "1", ":");
	        $mac = $mac.cut($acl_list, "2", ":");
	        $mac = $mac.cut($acl_list, "3", ":");
	        $mac = $mac.cut($acl_list, "4", ":");
	        $mac = $mac.cut($acl_list, "5", ":");
		if(isfile("/var/run/BAND24G-1.1.UP")==1){echo 'iwpriv wlan1 '.$acl_action.' '.$mac.'\n';}
		if(isfile("/var/run/BAND24G-1.2.UP")==1){echo 'iwpriv wlan1-va0 '.$acl_action.' '.$mac.'\n';}
		if(isfile("/var/run/BAND24G-1.3.UP")==1){echo 'iwpriv wlan1-va1 '.$acl_action.' '.$mac.'\n';}
		if(isfile("/var/run/BAND24G-1.4.UP")==1){echo 'iwpriv wlan1-va2 '.$acl_action.' '.$mac.'\n';}
		if(isfile("/var/run/BAND5G-1.1.UP")==1){echo 'iwpriv wlan0 '.$acl_action.' '.$mac.'\n';}
		if(isfile("/var/run/BAND5G-1.2.UP")==1){echo 'iwpriv wlan0-va0 '.$acl_action.' '.$mac.'\n';}
		if(isfile("/var/run/BAND5G-1.3.UP")==1){echo 'iwpriv wlan0-va1 '.$acl_action.' '.$mac.'\n';}
		if(isfile("/var/run/BAND5G-1.4.UP")==1){echo 'iwpriv wlan0-va2 '.$acl_action.' '.$mac.'\n';}
	}
}
set("/runtime/acl/action","");
set("/runtime/acl/mac","");
?>
