<?
include "/etc/services/PHYINF/phywifi.php";
phyinf_active("BAND5G-1.3");
?>
