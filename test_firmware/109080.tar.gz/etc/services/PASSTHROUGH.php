<?
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/phyinf.php";

fwrite(w, $START, "#!/bin/sh\n");
fwrite(w, $STOP, "#!/bin/sh\n");

$layout = query("/device/layout");
$wirelessmode = query("/device/wirelessmode");


if ($layout == "router")
{
	fwrite(a,$START,'brctl addif br0 pwlan0\n');
	fwrite(a,$START,'ifconfig pwlan0 up\n');
}

fwrite(a, $START,'exit 0\n');
fwrite(a, $STOP, 'exit 0\n');
?>
