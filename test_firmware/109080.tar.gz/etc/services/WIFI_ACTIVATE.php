<?
include "/htdocs/phplib/xnode.php";
include "/etc/services/WIFI/function.php";

function needsch($uid)
{
	/* Get schedule setting */
	$base = XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);
	$sch = query($base."/schedule");
	if ($sch=="" || $sch=="Always")	{$needsch = "0";}
	else	{$needsch = "1";}
	if (query($base."/active")=="0") {$needsch = "0";}
	return $needsch;
}

function schcmd($uid)
{
	/* Get schedule setting */
	$p = XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);
	$sch = XNODE_getschedule($p);
	$schid =  query($p."/schedule");
	if ($sch=="") $cmd = "start";
	else	{$cmd = XNODE_getschedule2013cmd($schid);}
	return $cmd;
}

function set_runtime_insch($uid, $value)
{
	/* Get schedule setting */
	$p = XNODE_getpathbytarget("/runtime", "phyinf", "uid", $uid, 0);
	if ($p!="")	{$cmd = "xmldbc -s ".$p."/insch ".$value;}
	else	{$cmd = "";}
	return $cmd;
}
/********************************************************************/
fwrite("w",$START, "#!/bin/sh\n");
fwrite("w", $STOP, "#!/bin/sh\n");

if(needsch("BAND24G-1.1")=="1"){
	fwrite("a",$START,"ifconfig ".devname("BAND24G-1.1")." down\n");
	fwrite("a",$START,"ifconfig ".devname("WIFI-STA")." down\n");
	fwrite("a",$START,"ifconfig ".devname("WIFI-WDS")." down\n");
	fwrite("a",$START,set_runtime_insch("BAND24G-1.1","0")." \n");
	fwrite("a",$START,set_runtime_insch("WIFI-STA","0")." \n");
	fwrite("a",$START,set_runtime_insch("WIFI-WDS","0")." \n");
	fwrite("a",$START,"service PHYINF.BAND24G-1.1_ACTIVE  ".schcmd("BAND24G-1.1")."\n");
	fwrite("a",$START,"service PHYINF.WIFI-STA_ACTIVE  ".schcmd("BAND24G-1.1")."\n");		
	fwrite("a",$START," PHYINF.WIFI-WDS_ACTIVE  ".schcmd("BAND24G-1.1")."\n");

	fwrite("a",$STOP,"service PHYINF.BAND24G-1.1_ACTIVE stop\n\n");
	fwrite("a",$STOP,"service PHYINF.WIFI-STA_ACTIVE stop\n\n");		
	fwrite("a",$STOP," PHYINF.WIFI-WDS_ACTIVE stop\n\n");	


}

if(needsch("BAND5G-1.1")=="1"){
	fwrite("a",$START,"ifconfig ".devname("BAND5G-1.1")." down\n");
	fwrite("a",$START,"ifconfig ".devname("WIFI-STA5G")." down\n");
	fwrite("a",$START,"ifconfig ".devname("WIFI-WDS5G")." down\n");
	fwrite("a",$START,set_runtime_insch("BAND5G-1.1","0")." \n");
	fwrite("a",$START,set_runtime_insch("WIFI-STA5G","0")." \n");
	fwrite("a",$START,set_runtime_insch("WIFI-WDS5G","0")." \n");
	fwrite("a",$START,"service PHYINF.BAND5G-1.1_ACTIVE  ".schcmd("BAND5G-1.1")."\n");
	fwrite("a",$START,"service PHYINF.WIFI-STA5G_ACTIVE  ".schcmd("BAND5G-1.1")."\n");		
	fwrite("a",$START," PHYINF.WIFI-WDS5G_ACTIVE  ".schcmd("BAND5G-1.1")."\n");

	fwrite("a",$STOP,"service PHYINF.BAND5G-1.1_ACTIVE stop\n\n");
	fwrite("a",$STOP,"service PHYINF.WIFI-STA5G_ACTIVE stop\n\n");		
	fwrite("a",$STOP," PHYINF.WIFI-WDS5G_ACTIVE stop\n\n");	
}

if(needsch("BAND24G-1.2")=="1"){
	fwrite("a",$START,"ifconfig ".devname("BAND24G-1.2")." down\n");
	fwrite("a",$START,set_runtime_insch("BAND24G-1.2","0")." \n");
	fwrite("a",$START,"service PHYINF.BAND24G-1.2_ACTIVE  ".schcmd("BAND24G-1.2")."\n");
	fwrite("a",$STOP,"service PHYINF.BAND24G-1.2_ACTIVE stop\n\n");
	}

if(needsch("BAND24G-1.3")=="1"){
	fwrite("a",$START,"ifconfig ".devname("BAND24G-1.3")." down\n");
	fwrite("a",$START,set_runtime_insch("BAND24G-1.3","0")." \n");
	fwrite("a",$START,"service PHYINF.BAND24G-1.3_ACTIVE  ".schcmd("BAND24G-1.3")."\n");
	fwrite("a",$STOP,"service PHYINF.BAND24G-1.3_ACTIVE stop\n\n");
	}

if(needsch("BAND24G-1.4")=="1"){
	fwrite("a",$START,"ifconfig ".devname("BAND24G-1.4")." down\n");
	fwrite("a",$START,set_runtime_insch("BAND24G-1.4","0")." \n");
	fwrite("a",$START,"service PHYINF.BAND24G-1.4_ACTIVE  ".schcmd("BAND24G-1.4")."\n");
	fwrite("a",$STOP,"service PHYINF.BAND24G-1.4_ACTIVE stop\n\n");
	}

if(needsch("BAND5G-1.2")=="1"){
	fwrite("a",$START,"ifconfig ".devname("BAND5G-1.2")." down\n");
	fwrite("a",$START,set_runtime_insch("BAND5G-1.2","0")." \n");
	fwrite("a",$START,"service PHYINF.BAND5G-1.2_ACTIVE  ".schcmd("BAND5G-1.2")."\n");
	fwrite("a",$STOP,"service PHYINF.BAND5G-1.2_ACTIVE stop\n\n");
	}

if(needsch("BAND5G-1.3")=="1"){
	fwrite("a",$START,"ifconfig ".devname("BAND5G-1.3")." down\n");
	fwrite("a",$START,set_runtime_insch("BAND5G-1.3","0")." \n");
	fwrite("a",$START,"service PHYINF.BAND5G-1.3_ACTIVE  ".schcmd("BAND5G-1.3")."\n");
	fwrite("a",$STOP,"service PHYINF.BAND5G-1.3_ACTIVE stop\n\n");
	}

if(needsch("BAND5G-1.4")=="1"){
	fwrite("a",$START,"ifconfig ".devname("BAND5G-1.4")." down\n");
	fwrite("a",$START,set_runtime_insch("BAND5G-1.4","0")." \n");
	fwrite("a",$START,"service PHYINF.BAND5G-1.4_ACTIVE  ".schcmd("BAND5G-1.4")."\n");
	fwrite("a",$STOP,"service PHYINF.BAND5G-1.4_ACTIVE stop\n\n");
	}

fwrite("a",$START,	"exit 0\n");
fwrite("a",$STOP,	"exit 0\n");
?>
