<?
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/phyinf.php";

fwrite(w, $START, "#!/bin/sh\n");
fwrite(w, $STOP, "#!/bin/sh\n");

$layout = query("/device/layout");
$wirelessmode = query("/device/wirelessmode");


if ($layout == "router")
{
	$band24_p = XNODE_getpathbytarget("/runtime","phyinf","uid","WIFI-STA",0);
	$band5_p =  XNODE_getpathbytarget("/runtime","phyinf","uid","WIFI-STA5G",0);

	//Connected Disabled Scanning
	$band24_status = query($band24_p."/media/status");
	$band5_status = query($band5_p."/media/status");

	TRACE_debug("$band24_p = ".$band24_p."");
	TRACE_debug("$band5_p = ".$band5_p."");
	TRACE_debug("$band24_status = ".$band24_status."");
	TRACE_debug("$band5_status = ".$band5_status."");
	TRACE_debug("$layout = ".$layout."");
	TRACE_debug("$wirelessmode = ".$wirelessmode."");
	
	//fwrite(a,$START,'brctl addif br0 pwlan0\n');
	//fwrite(a,$START,'ifconfig pwlan0 up\n');
	fwrite(a,$START,'echo 0 > /proc/custom_Passthru\n');
	fwrite(a,$START,'echo 0 > /proc/custom_Passthru_wlan\n');
	
	// /device/passthrough
	if( $wirelessmode == "WirelessHotspotExtender" )
	{
		if( $band24_status == "Connected")
		{
			fwrite(a,$START,'echo 26 > /proc/custom_Passthru_wlan\n');
		}
		else if( $band5_status == "Connected")
		{
			fwrite(a,$START,'echo 10 > /proc/custom_Passthru_wlan\n');
		}
	}
	else if( $wirelessmode == "WirelessHotspot" )
	{
		if( $band24_status == "Connected")
		{
			fwrite(a,$START,'echo 18 > /proc/custom_Passthru_wlan\n');
		}
		else if( $band5_status == "Connected")
		{
			fwrite(a,$START,'echo 2 > /proc/custom_Passthru_wlan\n');
		}		
	}

	//fwrite(a,$STOP,'brctl delif br0 pwlan0\n');
	//fwrite(a,$STOP,'ifconfig pwlan0 down\n');
	//fwrite(a,$STOP,'echo 0 > /proc/custom_Passthru_wlan\n');
}

fwrite(a, $START,'exit 0\n');
fwrite(a, $STOP, 'exit 0\n');
?>
