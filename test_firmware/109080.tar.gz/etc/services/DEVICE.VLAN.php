<?
//include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/phyinf.php";
include "/htdocs/phplib/trace.php";

fwrite("w",$START, "#!/bin/sh\n");
fwrite("w", $STOP, "#!/bin/sh\n");

function startcmd($cmd)	{fwrite(a,$_GLOBALS["START"], $cmd."\n");}
function stopcmd($cmd)	{fwrite(a,$_GLOBALS["STOP"], $cmd."\n");}
function error($err)    {startcmd("exit ".$err); stopcmd("exit ".$err); return $err;}
$wirelessmode = query("/device/wirelessmode");
if($wirelessmode!="WirelessAp")
{
	return error(0);
}
else
{
$vconfig_file = "/var/linux_vlan_reinit";
$bridge = "br0";
$eth= "eth0";
$eth_mac = query("/runtime/devdata/lanmac");
$vlan_active = query("/device/vlan/active");  // 0,1  VLAN����
$vlan_priority = query("/device/vlan/priority"); // 0,1 802.1P����
$managePortVid = query("/device/vlan/managePortVid"); //1-4096
$defaultPortVid = query("/device/vlan/defaultPortVid");
$final_vid = 0; // counter for enable disable vlan

function get_vlan_vid($uid)
{
	$phyinf_path=XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);
	$active=query($phyinf_path."/active");	
	if($active=="" || $active=="0")	return 0;

	$vlan_uid=query($phyinf_path."/vlan");
	$vlan_path=XNODE_getpathbytarget("/device/vlan", "entry", "uid", $vlan_uid, 0);
	
	if($vlan_path=="")	return 0;

	$vid=query($vlan_path."/vid");	
	TRACE_debug("[DEVICE.VLAN]: uid=".$uid.",vid=".$vid);
	if($vid!="")	return $vid;
	else return 0;
}

function get_vlan_pri($uid)
{
	$phyinf_path=XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);
	$active=query($phyinf_path."/active");	
	if($active=="" || $active=="0")	return 0;

	$vlan_uid=query($phyinf_path."/vlan");
	$vlan_path=XNODE_getpathbytarget("/device/vlan", "entry", "uid", $vlan_uid, 0);
	
	if($vlan_path=="")	return 0;

	$pri=query($vlan_path."/priority");	
	TRACE_debug("[DEVICE.VLAN]: uid=".$uid.",vid=".$vid);
	if($pri!="")	return $pri;
	else return 0;
}

// 1-8 ,enable or not
//$wifi1_status = query("/device/vlan/entry:1/active");
//$wifi2_status = query("/device/vlan/entry:2/active");
//$wifi3_status = query("/device/vlan/entry:3/active");
//$wifi4_status = query("/device/vlan/entry:4/active");
//$wifi5_status = query("/device/vlan/entry:5/active");
//$wifi6_status = query("/device/vlan/entry:6/active");
//$wifi7_status = query("/device/vlan/entry:7/active");
//$wifi8_status = query("/device/vlan/entry:8/active");

//uid to check active or not
$wifi1_uid = "BAND24G-1.1";
$wifi2_uid = "BAND24G-1.2";
$wifi3_uid = "BAND24G-1.3";
$wifi4_uid = "BAND24G-1.4";
$wifi5_uid = "BAND5G-1.1";
$wifi6_uid = "BAND5G-1.2";
$wifi7_uid = "BAND5G-1.3";
$wifi8_uid = "BAND5G-1.4";

//inf name to set cmd
$wifi1_inf = "wlan1";
$wifi2_inf = "wlan1-va0";
$wifi3_inf = "wlan1-va1";
$wifi4_inf = "wlan1-va2";
$wifi5_inf = "wlan0";
$wifi6_inf = "wlan0-va0";
$wifi7_inf = "wlan0-va1";
$wifi8_inf = "wlan0-va2";

//vid for set cmd
//$wifi1_vid = query("/device/vlan/entry:1/vid");
//$wifi2_vid = query("/device/vlan/entry:2/vid");
//$wifi3_vid = query("/device/vlan/entry:3/vid");
//$wifi4_vid = query("/device/vlan/entry:4/vid");
//$wifi5_vid = query("/device/vlan/entry:5/vid");
//$wifi6_vid = query("/device/vlan/entry:6/vid");
//$wifi7_vid = query("/device/vlan/entry:7/vid");
//$wifi8_vid = query("/device/vlan/entry:8/vid");
$wifi1_vid = get_vlan_vid($wifi1_uid);
$wifi2_vid = get_vlan_vid($wifi2_uid);
$wifi3_vid = get_vlan_vid($wifi3_uid);
$wifi4_vid = get_vlan_vid($wifi4_uid);
$wifi5_vid = get_vlan_vid($wifi5_uid);
$wifi6_vid = get_vlan_vid($wifi6_uid);
$wifi7_vid = get_vlan_vid($wifi7_uid);
$wifi8_vid = get_vlan_vid($wifi8_uid);

//pri for set cmd
$wifi1_pri = get_vlan_pri($wifi1_uid);
$wifi2_pri = get_vlan_pri($wifi2_uid);
$wifi3_pri = get_vlan_pri($wifi3_uid);
$wifi4_pri = get_vlan_pri($wifi4_uid);
$wifi5_pri = get_vlan_pri($wifi5_uid);
$wifi6_pri = get_vlan_pri($wifi6_uid);
$wifi7_pri = get_vlan_pri($wifi7_uid);
$wifi8_pri = get_vlan_pri($wifi8_uid);

$final_vid = $wifi1_vid + $wifi2_vid + $wifi3_vid + $wifi4_vid + $wifi5_vid + $wifi6_vid + $wifi7_vid + $wifi8_vid;

if($final_vid ==0 &&  $managePortVid == 1) // no inf select and manage vid no change
{
	return error(0);
}

//PHP����
function wifi_check($uid)
{
	$wifi_enable = 0;

	foreach("/phyinf")
	{
		if(query("active") == "1" && query("uid") == $uid )
		{
			$wifi_enable = 1;
		}
	}
	return $wifi_enable;
}

//bash�����ͺ���
startcmd("default_vid=".$defaultPortVid."");
startcmd("manage_vid=".$managePortVid."");
startcmd("directory=\"/var/vlangroup\"");
startcmd("LAN1_PORT_MASK=0x01");
startcmd("CPU_PORT_MASK=0x40");

startcmd("vlan_group_set()");
startcmd("{");
startcmd("	port_member_mask=0x0");
startcmd("	port_tagged_mask=0x0");
	
//startcmd("	echo \"$1 is arg\"");
startcmd("	for LINE in `cat $directory/$file`");
startcmd("	do");
//startcmd("        echo $LINE");
startcmd("		if [ \"$LINE\" -le \"4\" ]");
startcmd("		then");
startcmd("			#let \"port_member_mask |= $((1 << 14+$LINE))\"  # 2.4g ,bit 15~18");
startcmd("			let \"temp = 1 << 14+$LINE\"");
startcmd("			let \"port_member_mask |= temp\"");
//startcmd("			echo \"2.4g\"");
startcmd("		fi");

startcmd("		if [ \"$LINE\" -ge \"5\" ]");
startcmd("		then");
startcmd("			#let \"port_member_mask |= $((1 << 4+$LINE))\" # 5g ,bit 9~12");
startcmd("			let \"temp = 1 << 4+$LINE\"");
startcmd("			let \"port_member_mask |= temp\"");
//startcmd("			echo \"5g\"");
startcmd("		fi");		
startcmd("	done");
	
//startcmd("	#echo $port_member_mask");
//startcmd("	if [ \"$1\" -eq \"$manage_vid\" ]");
//startcmd("	then");
startcmd("	let \"port_member_mask |= CPU_PORT_MASK\"");		
//startcmd("	fi");
startcmd("	let \"port_member_mask |= LAN1_PORT_MASK\"");
startcmd("	port_member_mask=`printf \"%x\" $port_member_mask`");
//startcmd("	echo $port_member_mask");
	
startcmd("	if [ \"$1\" -eq \"$default_vid\" ]");
startcmd("	then");
startcmd("		port_tagged_mask=40");
startcmd("	else");
startcmd("		port_tagged_mask=41");
//startcmd("		port_tagged_mask=$port_member_mask");
startcmd("	fi");
	
//startcmd("	echo $port_tagged_mask");
	
startcmd("	echo \"echo $1 > /proc/net/vlan/groupIndex\"");
startcmd("	echo \"echo \"1,$port_member_mask,$port_tagged_mask,$1,1\" > /proc/net/vlan/vlanGroup\"");
startcmd("	echo $1 > /proc/net/vlan/groupIndex");
startcmd("	echo \"1,$port_member_mask,$port_tagged_mask,$1,1\" > /proc/net/vlan/vlanGroup");
startcmd("}");

//start clean
startcmd("echo \"0 0 1\" > /proc/net/vlan/vlanEnable");
startcmd("echo \"1 1 1\" > /proc/net/vlan/vlanEnable");
//startcmd("route del -net 192.168.1.0 netmask 255.255.255.0");
//startcmd("route add -net 192.168.1.0 netmask 255.255.255.0 dev br0");
startcmd("brctl delif br0 wlan0 2>/dev/null");
startcmd("brctl delif br0 wlan0-va0 2>/dev/null");
startcmd("brctl delif br0 wlan0-va1 2>/dev/null");
startcmd("brctl delif br0 wlan0-va2 2>/dev/null");
startcmd("brctl delif br0 wlan0-va3 2>/dev/null");
startcmd("brctl delif br0 wlan1 2>/dev/null");
startcmd("brctl delif br0 wlan1-va0 2>/dev/null");
startcmd("brctl delif br0 wlan1-va1 2>/dev/null");
startcmd("brctl delif br0 wlan1-va2 2>/dev/null");
startcmd("brctl delif br0 wlan1-va3 2>/dev/null");
startcmd("brctl delif br0 eth0");
startcmd("brctl delif br0 eth1");

//group����
startcmd("rm -rf /var/vlangroup");
startcmd("mkdir -p /var/vlangroup");
//1
if(wifi_check($wifi1_uid) == 1)
{
if($wifi1_vid == 0)
{
	$wifi1_vid = $defaultPortVid;
}
startcmd("echo 1 >> /var/vlangroup/".$wifi1_vid."");
startcmd("vconfig add ".$wifi1_inf." ".$wifi1_vid."");
startcmd("ifconfig ".$wifi1_inf.".".$wifi1_vid." up");
startcmd("brctl addif br0 ".$wifi1_inf.".".$wifi1_vid."");
stopcmd("ifconfig ".$wifi1_inf.".".$wifi1_vid." down");
stopcmd("vconfig rem ".$wifi1_inf.".".$wifi1_vid."");
stopcmd("brctl addif br0 ".$wifi1_inf."");
}
//2
if(wifi_check($wifi2_uid) == 1)
{
if($wifi2_vid == 0)
{
	$wifi2_vid = $defaultPortVid;
}
startcmd("echo 2 >> /var/vlangroup/".$wifi2_vid."");
startcmd("vconfig add ".$wifi2_inf." ".$wifi2_vid."");
startcmd("ifconfig ".$wifi2_inf.".".$wifi2_vid." up");
startcmd("brctl addif br0 ".$wifi2_inf.".".$wifi2_vid."");
stopcmd("ifconfig ".$wifi2_inf.".".$wifi2_vid." down");
stopcmd("vconfig rem ".$wifi2_inf.".".$wifi2_vid."");
stopcmd("brctl addif br0 ".$wifi2_inf."");
}
//3
if(wifi_check($wifi3_uid) == 1)
{
if($wifi3_vid == 0)
{
	$wifi3_vid = $defaultPortVid;
}
startcmd("echo 3 >> /var/vlangroup/".$wifi3_vid."");
startcmd("vconfig add ".$wifi3_inf." ".$wifi3_vid."");
startcmd("ifconfig ".$wifi3_inf.".".$wifi3_vid." up");
startcmd("brctl addif br0 ".$wifi3_inf.".".$wifi3_vid."");
stopcmd("ifconfig ".$wifi3_inf.".".$wifi3_vid." down");
stopcmd("vconfig rem ".$wifi3_inf.".".$wifi3_vid."");
stopcmd("brctl addif br0 ".$wifi3_inf."");
}
//4
if(wifi_check($wifi4_uid) == 1)
{
if($wifi4_vid == 0)
{
	$wifi4_vid = $defaultPortVid;
}
startcmd("echo 4 >> /var/vlangroup/".$wifi4_vid."");
startcmd("vconfig add ".$wifi4_inf." ".$wifi4_vid."");
startcmd("ifconfig ".$wifi4_inf.".".$wifi4_vid." up");
startcmd("brctl addif br0 ".$wifi4_inf.".".$wifi4_vid."");
stopcmd("ifconfig ".$wifi4_inf.".".$wifi4_vid." down");
stopcmd("vconfig rem ".$wifi4_inf.".".$wifi4_vid."");
stopcmd("brctl addif br0 ".$wifi4_inf."");
}
//5
if(wifi_check($wifi5_uid) == 1)
{
if($wifi5_vid == 0)
{
	$wifi5_vid = $defaultPortVid;
}
startcmd("echo 5 >> /var/vlangroup/".$wifi5_vid."");
startcmd("vconfig add ".$wifi5_inf." ".$wifi5_vid."");
startcmd("ifconfig ".$wifi5_inf.".".$wifi5_vid." up");
startcmd("brctl addif br0 ".$wifi5_inf.".".$wifi5_vid."");
stopcmd("ifconfig ".$wifi5_inf.".".$wifi5_vid." down");
stopcmd("vconfig rem ".$wifi5_inf.".".$wifi5_vid."");
stopcmd("brctl addif br0 ".$wifi5_inf."");
}
//6
if(wifi_check($wifi6_uid) == 1 )
{
if($wifi6_vid == 0)
{
	$wifi6_vid = $defaultPortVid;
}
startcmd("echo 6 >> /var/vlangroup/".$wifi6_vid."");
startcmd("vconfig add ".$wifi6_inf." ".$wifi6_vid."");
startcmd("ifconfig ".$wifi6_inf.".".$wifi6_vid." up");
startcmd("brctl addif br0 ".$wifi6_inf.".".$wifi6_vid."");
stopcmd("ifconfig ".$wifi6_inf.".".$wifi6_vid." down");
stopcmd("vconfig rem ".$wifi6_inf.".".$wifi6_vid."");
stopcmd("brctl addif br0 ".$wifi6_inf."");
}
//7
if(wifi_check($wifi7_uid) == 1 )
{
if($wifi7_vid == 0)
{
	$wifi7_vid = $defaultPortVid;
}
startcmd("echo 7 >> /var/vlangroup/".$wifi7_vid."");
startcmd("vconfig add ".$wifi7_inf." ".$wifi7_vid."");
startcmd("ifconfig ".$wifi7_inf.".".$wifi7_vid." up");
startcmd("brctl addif br0 ".$wifi7_inf.".".$wifi7_vid."");
stopcmd("ifconfig ".$wifi7_inf.".".$wifi7_vid." down");
stopcmd("vconfig rem ".$wifi7_inf.".".$wifi7_vid."");
stopcmd("brctl addif br0 ".$wifi7_inf."");
}
//8
if(wifi_check($wifi8_uid) == 1)
{
if($wifi8_vid == 0)
{
	$wifi8_vid = $defaultPortVid;
}
startcmd("echo 8 >> /var/vlangroup/".$wifi8_vid."");
startcmd("vconfig add ".$wifi8_inf." ".$wifi8_vid."");
startcmd("ifconfig ".$wifi8_inf.".".$wifi8_vid." up");
startcmd("brctl addif br0 ".$wifi8_inf.".".$wifi8_vid."");
stopcmd("ifconfig ".$wifi8_inf.".".$wifi8_vid." down");
stopcmd("vconfig rem ".$wifi8_inf.".".$wifi8_vid."");
stopcmd("brctl addif br0 ".$wifi8_inf."");
}

//������Ŀ¼����GROUP
startcmd("for file in `ls $directory`");
startcmd("do");
startcmd("        if [ -d $directory/$file ]");
startcmd("        then");
startcmd("                echo $file is dir");
startcmd("        else");
startcmd("                echo $file is file");
startcmd("                vlan_group_set \"$file\"");
//set eth vconfig for group
startcmd("                vconfig add eth0 $file");
startcmd("                ifconfig eth0.$file hw ether ".$eth_mac."");
startcmd("                ifconfig eth0.$file up");
startcmd("                brctl addif br0 eth0.$file");
startcmd("        fi");
startcmd("done");

//traveller add ,when no inf bind with manage vid ,create a manage group for web access
if($managePortVid != 1) // manage vid changed
{
if( $wifi1_vid != $managePortVid && $wifi2_vid != $managePortVid && $wifi3_vid != $managePortVid && $wifi4_vid != $managePortVid &&
	$wifi5_vid != $managePortVid && $wifi6_vid != $managePortVid && $wifi7_vid != $managePortVid && $wifi8_vid != $managePortVid )  //no inf bind manage group
{
startcmd("vconfig add eth0 ".$managePortVid."");
startcmd("ifconfig eth0.".$managePortVid." hw ether ".$eth_mac."");
startcmd("ifconfig eth0.".$managePortVid." up");
startcmd("brctl addif br0 eth0.".$managePortVid."");
startcmd("echo ".$managePortVid." > /proc/net/vlan/groupIndex");
startcmd("echo \"1,41,41,".$managePortVid.",1\" > /proc/net/vlan/vlanGroup");

stopcmd("ifconfig eth0.".$managePortVid." down");
stopcmd("vconfig rem eth0.".$managePortVid."");
}
}

//������Ŀ¼����GROUP
stopcmd("directory=\"/var/vlangroup\"");
stopcmd("for file in `ls $directory`");
stopcmd("do");
stopcmd("        if [ -d $directory/$file ]");
stopcmd("        then");
stopcmd("                echo $file is dir");
stopcmd("        else");
stopcmd("                echo $file is file");
//stopcmd("                vlan_group_set \"$file\"");
//set eth vconfig for group
stopcmd("                ifconfig eth0.$file down");
stopcmd("                vconfig rem eth0.$file");
stopcmd("        fi");
stopcmd("done");
	
//set pvid,eth use default vid
startcmd("echo \"".$defaultPortVid.",1,1,1,1,1,1,1,".$managePortVid.",".$wifi5_vid.",".$wifi6_vid.",".$wifi7_vid.",".$wifi8_vid.",0,0,".$wifi1_vid.",".$wifi2_vid.",".$wifi3_vid.",".$wifi4_vid.",0,0,\" > /proc/net/vlan/pvid");	
//startcmd("iptables -I INPUT 1 -p tcp --dport 80 -m vlanid ! --vid-value ".$managePortVid." -j DROP");
startcmd("iptables -I INPUT 1 -m vlanid ! --vid-value ".$managePortVid." -j DROP");

//this is realtek bug ,the default group must reset at the last ,so the eth pvid can be right or it will be the last group vid
startcmd("if [ -f $directory/".$defaultPortVid." ]");
startcmd("then");
startcmd("	file=".$defaultPortVid."");
startcmd("	vlan_group_set \"$file\"");
startcmd("else");  //if no inf is in default vlan ,setup default vlan
startcmd("	vconfig add eth0 1");
startcmd("	ifconfig eth0.1 up");
startcmd("	brctl addif br0 eth0.1");
startcmd("	echo \"echo ".$defaultPortVid." > /proc/net/vlan/groupIndex\"");
startcmd("	echo \"echo \"1,41,40,".$defaultPortVid.",1\" > /proc/net/vlan/vlanGroup\"");
startcmd("	echo ".$defaultPortVid." > /proc/net/vlan/groupIndex");
startcmd("	echo \"1,41,40,".$defaultPortVid.",1\" > /proc/net/vlan/vlanGroup");
startcmd("fi");

//set 802.1p
//echo '5,0,0,0,0,0,0,0,0,6,0,0,0,0,0,7,0,0,0,0,0' > /proc/net/vlan/priority

startcmd("echo \"0,0,0,0,0,0,0,0,0,".$wifi5_pri.",".$wifi6_pri.",".$wifi7_pri.",".$wifi8_pri.",0,0,".$wifi1_pri.",".$wifi2_pri.",".$wifi3_pri.",".$wifi4_pri.",0,0\" > /proc/net/vlan/priority");

startcmd("event WANPORT.LINKDOWN");
startcmd("event WANPORT.LINKUP");
//################stop cmd
	
//stop
//stopcmd("iptables -D INPUT -p tcp --dport 80 -m vlanid ! --vid-value ".$managePortVid." -j DROP");
stopcmd("if [ -f $directory/".$defaultPortVid." ]");
stopcmd("then");
stopcmd("	echo \"no inf in default vlan\"");
stopcmd("else"); //no file ,we need del if manual
stopcmd("	ifconfig eth0.1 down");
stopcmd("	vconfig rem eth0.1");
stopcmd("fi");
stopcmd("iptables -t filter -F INPUT");
stopcmd("brctl addif br0 eth0");
stopcmd("rm -rf /var/vlangroup");
stopcmd("echo \"0 0 1\" > /proc/net/vlan/vlanEnable");
//stopcmd("route del -net 192.168.1.0 netmask 255.255.255.0");
//stopcmd("route add -net 192.168.1.0 netmask 255.255.255.0 dev br0");

stopcmd("event WANPORT.LINKDOWN");
stopcmd("event WANPORT.LINKUP");
/* Done */
fwrite("a",$START, "exit 0\n");
fwrite("a", $STOP, "exit 0\n");
}
?>
