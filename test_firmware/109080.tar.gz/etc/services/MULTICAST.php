<? /* vi: set sw=4 ts=4: */
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/phyinf.php";
include "/htdocs/phplib/xnode.php";


$iproxy = query("/device/multicast/igmpproxy");
$we		= query("/device/multicast/wifienhance");
$layout = query("/runtime/device/layout");

$mldproxy   = query("/device/multicast/mldproxy");
$we6		= query("/device/multicast/wifienhance6");

fwrite("w",$START, "#!/bin/sh\n");
fwrite("w",$STOP,  "#!/bin/sh\n");


if($layout=="bridge")
{
	//realtek ipv4 igmpsnooping
	if($iproxy=="1")
	{
		fwrite("a",$START, "echo 1 > /proc/br_igmpsnoop \n");
	}
	else
	{
		fwrite("a",$START, "echo 0 > /proc/br_igmpsnoop \n");
	}

	//realtek ipv6 igmpsnooping
	if($mldproxy=="1")
	{
		fwrite("a",$START, "echo 1 > /proc/br_mldsnoop \n");
	}
	else
	{
		fwrite("a",$START, "echo 0 > /proc/br_mldsnoop \n");
	}	
}

fwrite("a",$START, "exit 0\n");
fwrite("a",$STOP,  "exit 0\n");
?>
