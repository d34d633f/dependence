<?
include "/etc/services/PHYINF/phywifi.php";
phyinf_active("WIFI-STA");
?>
