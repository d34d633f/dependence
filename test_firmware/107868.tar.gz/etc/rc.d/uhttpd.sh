#!/bin/sh

#[ -f /usr/local/sbin/boa ] || exit 0
#[ -f /etc/resolv.conf ] || exit 0

RETVAL=0
prog="uhttpd"
PID_FILE="/var/run/uhttpd.pid"

ETHER_IF=`nvram get lan_ifname`

start() {
	# Start daemons.
	echo $"Starting $prog: "
	${prog} -w ${ETHER_IF}
	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting down $prog: "
	if [ -e ${PID_FILE} ]; then
		kill `cat ${PID_FILE}`
		rm -f ${PID_FILE}
	fi
	RETVAL=$?
	echo
	return $RETVAL
}

pidfile() {
	pid_num=`ps | grep uhttpd| grep -v grep | head -n 1 | awk '{print $1}'`
	echo "$pid_num" > ${PID_FILE}
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  pidfile)
	pidfile
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

