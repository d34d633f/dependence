# Blink WPS LED according to LED_STATE

echo "### wps led $1 $2 ####"

TIME_OUT=120
INPROGRESS_INTERVAL=500000      # 0.5s
CLIENT_INTERVAL=1000000      # 1s
ERROR_INTERVAL=100000           # 0.1s
ERROR_TIMEOUT=50               # 50 * 0.1s = 5s
OVERLAP_PAUSE_INTERVAL=500000   # 0.5s
OVERLAP_BLINK_TIMEOUT=10        # 10 * 0.1s = 1s
SUCCESS_INTERVAL=30000000       # 30s

LED_on='echo 2 > /proc/simple_config/simple_config_led'
LED_off='echo 1 > /proc/simple_config/simple_config_led'

wps_stop_command='echo stop > /proc/simple_config/wps'
PID_file=/var/run/wps_led.pid

if [ "$(nvram get endis_wl_radio)" = "0" ]; then
	exit
fi	

[ "$(nvram get LED_ON_OFF)" = "off" ] && exit 0

if [ -f $PID_file ]; then
	echo "kill old file"
	kill $(cat $PID_file) 2> /dev/console
	eval $LED_on
fi

echo "$$" > $PID_file

i=0
LED_busy=no


case "$1" in
	WPS_START)
		TIMEOUT_=$(($2 * 1000000 / $INPROGRESS_INTERVAL))
		ON_INTERVAL=$INPROGRESS_INTERVAL
		OFF_INTERVAL=$INPROGRESS_INTERVAL
		;;
	WPS_FAIL)
		TIMEOUT_=$ERROR_TIMEOUT
		ON_INTERVAL=$ERROR_INTERVAL
		OFF_INTERVAL=$ERROR_INTERVAL
		;;
	WPS_OVER)
		TIMEOUT_=0
		eval $LED_on
		;;
	WPS_CLIENT)
		TIMEOUT_=$(($TIME_OUT * 1000000 / $CLIENT_INTERVAL))
		ON_INTERVAL=$CLIENT_INTERVAL
		OFF_INTERVAL=$CLIENT_INTERVAL
		;;
	WPS_PIN_ATK)
		TIMEOUT_="9999"
		ON_INTERVAL=$ERROR_INTERVAL
		OFF_INTERVAL="900000"
		;;	
	*)
		TIMEOUT_=0
		;;
esac

while [ "$i" -lt "$TIMEOUT_" -o "$TIMEOUT_" = "9999" ]
do
	if [ "$(nvram get LED_ON_OFF)" = "off" ]; then
		eval $LED_off
		exit 0
	fi
	
	if [ $LED_busy = "no" ]; then
		eval $LED_on
		LED_busy=yes
		usleep $ON_INTERVAL
	else
		eval $LED_off
		LED_busy=no
		usleep $OFF_INTERVAL
	fi
	i=$(($i+1))

done


if [ -f /tmp/wscd_lock_stat ]; then
	ON_INTERVAL=$ERROR_INTERVAL
	OFF_INTERVAL="900000"
	while [ 1 ]
	do
		if [ "$(nvram get LED_ON_OFF)" = "off" ]; then
			eval $LED_off
			exit 0
		fi
		if [ $LED_busy = "no" ]; then
			eval $LED_on
			LED_busy=yes
			usleep $ON_INTERVAL
		else
			eval $LED_off
			LED_busy=no
			usleep $OFF_INTERVAL
		fi	
	done
fi

eval $LED_on

