#!/bin/sh

update_v1() {
   nvram set wl_radius_encryption_mode="2"
   nvram set wl_8021x="off"
   nvram set blk_svc_on="0"

}
#update_v2() {
#  nvram set lasergun="pewpewpew"
#}

nvram_last_ver=$1
nvram_current_ver=`nvram get nvram_ver`
if [ "x$nvram_current_ver" = "x" ]; then
	nvram_current_ver="0";
fi	

if [ "$nvram_current_ver" -lt "$nvram_last_ver" ];then
  tmp_ver=$nvram_current_ver
  while [ "$tmp_ver" != "$nvram_last_ver" ]
  do
    tmp_ver=$(($tmp_ver+1)) 
    update_v$tmp_ver
  done
  
  nvram set nvram_ver=$nvram_last_ver
  nvram commit
#  echo "nvram update to version $tmp_ver from version $nvram_current_ver"
#else
 # echo "nvram version is up to date: version $1"
fi
