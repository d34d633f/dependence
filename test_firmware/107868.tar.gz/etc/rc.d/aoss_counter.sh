# !/bin/sh

ECHO=/bin/echo
NVRAM=/usr/sbin/nvram                                                                                                          
AOSS_LED=/usr/sbin/aoss-led

Time=0
WAIT_TIME=1800

SetTimer()
{
    DEF_TOUT=${1:-10};
    if [ "${DEF_TOUT}" -ne "0" ];then
        sleep "${DEF_TOUT}" && kill -s 14 $$ &
        CHPROCIDS="${CHPROCIDS} $!"
        TIMEORIC=$!
    fi
}
AlarmHandler()
{
    #echo "Got SIGALARM"
    if [ "`${NVRAM} get AOSS_ERROR_STATUS`" != "1"  -o "`cat /tmp/led_security_status`" != "error" ]; then
		nvram unset AOSS_ERROR_STATUS
      exit 1
    else
    	#${ECHO} 33 > /proc/tc3162/led_security
		if [ "`ps -ef|grep 'aoss_led error'|grep -v grep|head -1|awk '{print $1}'`" = "" ];then
			${AOSS_LED} error
		fi
    fi
}
aoss_error_led()
{
    CHPROCIDS=$$
    ${ECHO} "${CHPROCIDS}" >/tmp/aossCounter
    trap AlarmHandler 14
    $PROG &
    Time=$((${Time}+2))
    while [ "${Time}" -lt "${WAIT_TIME}" ]
    do
        SetTimer 2
        wait $!
        Time=$((${Time}+2))
    done
    nvram unset AOSS_ERROR_STATUS
    #${ECHO} 01 > /proc/tc3162/led_security
	${AOSS_LED} enabled
    exit 1
}
aoss_error_led
exit 1  
