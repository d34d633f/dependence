#!/bin/sh

PLC_MAC=`artmtd -r wanmac | cut -c 10-`
ETH_MAC=`artmtd -r lanmac | cut -c 10-`
WPS_PIN=`artmtd -r wpspin | cut -c 9-`

nvram set plc_MAC=$PLC_MAC

nvram set wps_pin=$WPS_PIN
