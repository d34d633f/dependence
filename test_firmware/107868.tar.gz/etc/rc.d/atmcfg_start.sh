#!/bin/sh

RETVAL=0

if [ $# != 1 ] ; then
	echo "usage: $0 [start|stop|restart] "
	exit 0
fi

i=$2

ALL_VPI="0 8 1 0 0 0 8 0 0 0 0 1 1 8 8 8 0 2 8 8 1 8 0 8 0"
ALL_VCI="35 35 32 33 40 66 75 32 34 38 100 33 50 32 48 67 50 32 34 36 47 64 101 81 103"
DF_VPI=0
DF_VCI=35
lan_ifname=`nvram get lan_ifname`
wan_hwifname=`nvram get wan_hwifname`
wan_hwaddr=`nvram get wan_hwaddr`
router_disable=`nvram get router_disable`

start() {

   echo $"Starting atmcfg: "

   ATMQOS=`nvram get AdslQoS`
   ENCAP=`nvram get atmEncaptype`
   MULTIPLEX=`nvram get AdslMultiplexing`
   PCR=`nvram get AdslQoSPcrRate`
   SCR=`nvram get AdslQoSScrRate`
   MBS=`nvram get AdslQoSMbsRate`
   VPI=`nvram get AdslVpi`
   VCI=`nvram get AdslVci`

	if [ $ATMQOS = "ubr" ]; then
		PCR_V=""
	elif [ $ATMQOS = "cbr" ]; then
      PCR_V="-p $PCR "
   elif [ $ATMQOS = "vbr" ]; then
      PCR_V="-p $PCR -q $SCR "
	fi

   # Only bridge mode
   if [ "$ENCAP" = "4" ]; then   
      if [ "$MULTIPLEX" = "0" ]; then    # LLC mode
         ENCAP_T="-e 0"
      elif [ "$MULTIPLEX" = "1" ]; then  # VC-Mux mode
         ENCAP_T="-e 1"    
      fi
   fi

   # RFC 1483 bridge mode, dhcp or static mode
   if [ "$ENCAP" = "1" ] || [ "$ENCAP" = "5" ]; then   
      if [ "$MULTIPLEX" = "0" ]; then    # LLC mode
         ENCAP_T="-e 0"
      elif [ "$MULTIPLEX" = "1" ]; then  # VC-Mux mode
         ENCAP_T="-e 1"    
      fi
   fi

   # pppoe mode
   if [ "$ENCAP" = "2" ]; then   
      if [ "$MULTIPLEX" = "0" ]; then    # LLC mode
         ENCAP_T="-e 0"
      elif [ "$MULTIPLEX" = "1" ]; then  # VC-Mux mode
         ENCAP_T="-e 1" 
      fi
   fi

   # RFC 1483 routed mode
   if [ "$ENCAP" = "0" ]; then   
      if [ "$MULTIPLEX" = "0" ]; then    # LLC mode
         ENCAP_T="-e 2"
      elif [ "$MULTIPLEX" = "1" ]; then  # VC-Mux mode
         ENCAP_T="-e 3"    
      fi
   fi

   if [ "$ENCAP" != "3" ]; then    # not pppoa mode

      nvram set wan_hwifname=nas0
      echo "br2684ctl -c 0 $ENCAP_T -t $ATMQOS $PCR_V -a 0.$VPI.$VCI"
      br2684ctl -c 0 $ENCAP_T -t $ATMQOS $PCR_V -a 0.$VPI.$VCI &
      echo $! > /var/run/nas0.pid
  
      sleep 1

      if [ "$router_disable" -ne "0" ]; then         
         wan_mtu=`nvram get wan_dhcp_mtu`
         if [ "$wan_mtu" = "0" ]; then
            ifconfig $wan_hwifname mtu 1500
         else
            ifconfig $wan_hwifname mtu $wan_mtu
         fi
         brctl addif $lan_ifname $wan_hwifname 	
	   fi

      echo "ifconfig nas0 hw ether $wan_hwaddr"
      /sbin/ifconfig nas0 hw ether $wan_hwaddr
      #echo "ifconfig nas0 mtu $(nvram get wan_dhcp_mtu)"
      #/sbin/ifconfig nas0 mtu $(nvram get wan_dhcp_mtu) 
      /sbin/ifconfig nas0 0.0.0.0
   fi
   
   RETVAL=$?
	echo
	return $RETVAL
}


stop() {

   echo $"Stoping atmcfg: "

   if [ -f /var/run/nas0.pid ] ; then
      kill -9 `cat /var/run/nas0.pid`
      rm /var/run/nas0.pid
   fi
   
   RETVAL=$?
	echo
	return $RETVAL
}


detauto() {

   index=0
   for TESTVCI in $ALL_VCI
   do
      DSLLINK_STATUS=/tmp/dslStatus/dslLink_status
      if [ -f $DSLLINK_STATUS ]; then
         dsl_status=`cat $DSLLINK_STATUS`
         if [ $dsl_status != "1" ]; then
            echo "dsl not link"
            return $RETVAL
         fi
      else
          echo "dsl not link"
          return $RETVAL
      fi

      AdslAutoDetect=`nvram get AdslAutoDetect`
      if [ "$AdslAutoDetect" = "0" ]; then
         return $RETVAL
      fi

      index=$(($index+1))
      TESTVPI=`echo $ALL_VPI | cut -d " " -f $index`

      echo $"Starting detect index=$index ($TESTVPI/$TESTVCI)"
      echo "br2684ctl -c 0 -e 0 -t ubr -a 0.$TESTVPI.$TESTVCI"
      br2684ctl -c 0 -e 0 -t ubr -a 0.$TESTVPI.$TESTVCI &
      echo $! > /var/run/nas0.pid
      sleep 1
      /sbin/ifconfig nas0 0.0.0.0

      atmcmd oam --start $TESTVPI.$TESTVCI f5 --type etoe --repetition 3 --timeout 1000
      sleep 3
      atmcmd oam --stop $TESTVPI.$TESTVCI f5
      result=`cat /proc/tc3162/oam_ping`
      if [ "$result" = "1" ]; then      
         /usr/sbin/nvram set AdslVci=$TESTVCI
         /usr/sbin/nvram set AdslVpi=$TESTVPI
         nvram commit
         stop
         start
         RETVAL=$?
         echo
         return $RETVAL
      else
         stop
      fi
   done

   /usr/sbin/nvram set AdslVci=$DF_VCI
   /usr/sbin/nvram set AdslVpi=$DF_VPI
   nvram commit
   start

}


# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  detauto)
   stop
   detauto
   ;;
  *)
	echo $"Usage: $0 {start|stop|restart} "
	exit 1
esac

exit $RETVAL
