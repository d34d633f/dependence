#!/bin/sh
#echo "run pre_upnp.sh ..."

WSC_DISABLE=`nvram get wsc_disable`
LAN_MAC=$(nvram get lan_hwaddr | sed -n 's/://gp')
WAN_PROTO=`nvram get wan_proto`
device_name=`nvram get netbiosname` 
#echo "device_name: $device_name"

#for IGD device
mkdir -p /var/linuxigd
cp /etc/tmp/picsdesc.skl /var/linuxigd/picsdesc.skl.1
cp /etc/tmp/picsdesc.xml /var/linuxigd/picsdesc.xml.1

/bin/sed -e 's/ee1234cc5678/'${LAN_MAC}'/g' -e 's/JWNR2000/'"${device_name}"'/g' /var/linuxigd/picsdesc.skl.1 > /var/linuxigd/picsdesc.skl
/bin/sed -e 's/ee1234cc5678/'${LAN_MAC}'/g' -e 's/JWNR2000/'"${device_name}"'/g' /var/linuxigd/picsdesc.xml.1 > /var/linuxigd/picsdesc.xml

if [ "$WAN_PROTO" = "pptp" -o "$WAN_PROTO" = "pppoe" ]; then
     /bin/sed -e 's/WANIPConnection/WANPPPConnection/g' /var/linuxigd/picsdesc.skl > /var/linuxigd/picsdesc.skl.2
	 /bin/sed -e 's/WANIPConn1/WANPPPConn1/g' /var/linuxigd/picsdesc.skl.2 > /var/linuxigd/picsdesc.skl.1
	 /bin/sed -e 's/wanipcn.xml/wanpppcn.xml/g' /var/linuxigd/picsdesc.skl.1 > /var/linuxigd/picsdesc.skl
	 /bin/sed -e 's/WANIPConnection/WANPPPConnection/g' /var/linuxigd/picsdesc.xml > /var/linuxigd/picsdesc.xml.2
	 /bin/sed -e 's/WANIPConn1/WANPPPConn1/g' /var/linuxigd/picsdesc.xml.2 > /var/linuxigd/picsdesc.xml.1
	 /bin/sed -e 's/wanipcn.xml/wanpppcn.xml/g' /var/linuxigd/picsdesc.xml.1 > /var/linuxigd/picsdesc.xml
else
    /bin/sed -e 's/WANPPPConnection/WANIPConnection/g' /var/linuxigd/picsdesc.skl > /var/linuxigd/picsdesc.skl.2
	/bin/sed -e 's/WANPPPConn1/WANIPConn1/g' /var/linuxigd/picsdesc.skl.2 > /var/linuxigd/picsdesc.skl.1
	/bin/sed -e 's/wanpppcn.xml/wanipcn.xml/g' /var/linuxigd/picsdesc.skl.1 > /var/linuxigd/picsdesc.skl
	/bin/sed -e 's/WANPPPConnection/WANIPConnection/g' /var/linuxigd/picsdesc.xml > /var/linuxigd/picsdesc.xml.2
	/bin/sed -e 's/WANPPPConn1/WANIPConn1/g' /var/linuxigd/picsdesc.xml.2 > /var/linuxigd/picsdesc.xml.1
	/bin/sed -e 's/wanpppcn.xml/wanipcn.xml/g' /var/linuxigd/picsdesc.xml.1 > /var/linuxigd/picsdesc.xml 
fi
rm /var/linuxigd/picsdesc.skl.1
rm /var/linuxigd/picsdesc.xml.1

#for WFA device
mkdir -p /var/wps
cp /etc/rc.d/simplecfg* /var/wps

cp /etc/rc.d/wscd.conf /var/wps/wscd.conf.1
cp /etc/rc.d/wscd_config /tmp/wscd_config.1

/bin/sed -e 's/aabbccddeeff/'${LAN_MAC}'/g' /var/wps/wscd.conf.1 > /var/wps/wscd.conf
rm /var/wps/wscd.conf.1

#/bin/sed -e 's/aabbccddeeff/'${LAN_MAC}'/g' /tmp/wscd_config.1 > /tmp/wscd_config
/bin/sed -e 's/aabbccddeeff/'${LAN_MAC}'/g' /tmp/wscd_config.1 > /tmp/wscd_config.2
rm /tmp/wscd_config.1

#generate random port
rnd_seed=`cat /proc/stat | grep intr | awk '{print $2}'`
echo "$rnd_seed" > /dev/urandom
tmp_rnd_num=`dd if=/dev/urandom bs=1 count=1 2>/dev/null | hexdump -d | head -1 | awk '{print 0+$NF}'`
rnd_num=$((${tmp_rnd_num}%10000))
rnd_port=$((${rnd_num} + 50000))

/bin/sed -e 's/57788/'${rnd_port}'/g' /tmp/wscd_config.2 > /tmp/wscd_config
rm /tmp/wscd_config.2

