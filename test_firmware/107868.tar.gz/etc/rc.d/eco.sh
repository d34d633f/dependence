#!/bin/sh

#[ -f /usr/sbin/ripd ] || exit 0

RETVAL=0

start() {
	# Start eco.
	ledcontrol -n power -s off
	ledcontrol -n eco -s on
	#ledcontrol -n service -s off
   /usr/sbin/sigto_infoHdl 45   # send signal to infoHdl to handle site is not expired
	echo bb804104=003F003F > /proc/mem_write
	echo bb804108=043F003F > /proc/mem_write
	echo bb80410c=083F003F > /proc/mem_write
	echo bb804110=0c3F003F > /proc/mem_write
	echo bb804114=103F003F > /proc/mem_write
	echo 202 > /proc/gpio	#off LEDs of switch
	
	RETVAL=$?
	return $RETVAL
}

restore() {
	# Stop eco.
	ledcontrol -n power -s on
	ledcontrol -n eco -s off
  	#ledcontrol -n service -s on
   /usr/sbin/sigto_infoHdl 44   # send signal to infoHdl to handle site is expired 
	echo bb804104=007F003F > /proc/mem_write
	echo bb804108=047F003F > /proc/mem_write
	echo bb80410c=087F003F > /proc/mem_write
	echo bb804110=0c7F003F > /proc/mem_write
	echo bb804114=107F003F > /proc/mem_write
	echo 201 > /proc/gpio	#restore LEDs of switch
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  restore)
	restore
	;;
  restart|reload)
	restore
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

