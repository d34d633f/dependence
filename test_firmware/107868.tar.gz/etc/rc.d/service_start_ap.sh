#!/bin/sh

RETVAL=0
HTTPD_INIT_PROG="/etc/rc.d/uhttpd.sh"
UDHCPD_INIT_PROG="/etc/rc.d/udhcpd.sh"
UDHCPC_INIT_PROG="/etc/rc.d/udhcpc.sh"
DNSMASQ_INIT_PROG="/etc/rc.d/dnsmasq.sh"
NTPCLIENT_INIT_PROG="/etc/rc.d/ntpclient.sh"
UPNP_INIT_PROG="/etc/rc.d/upnp.sh"
SYSLOGD_INIT_PROG="/etc/rc.d/syslogd.sh"
DROPBEAR_INIT_PROG="/etc/rc.d/dropbear.sh"
TELNETD_INIT_PROG="/etc/rc.d/telnetd.sh"
SNMPD_INIT_PROG="/etc/rc.d/snmpd.sh"
RESET_BUTTON_PROG="/etc/rc.d/resetbutton.sh"
RIPD_INIT_PROG="/etc/rc.d/ripd.sh"
QOS_INIT_PROG="/etc/rc.d/qos.sh"
ROUTING_PROG="/etc/rc.d/routing.sh"
LLTD_PROG="/etc/rc.d/lltd.sh"
SIP_ALG_PROG="/etc/rc.d/sip_alg.sh"
TC_PROG="/etc/rc.d/TC.sh"
NET_SCAN="/etc/rc.d/net_scan.sh"
SCHE_PROG="/etc/rc.d/cmdsched.sh"
DNS_HIJACK="/etc/rc.d/dns_hijack.sh"
NETBIOS_INIT_PROG="/etc/rc.d/netbios.sh"

route_dns_renew()
{
		router=`/usr/sbin/nvram get wan_default_gateway`
		interface=`nvram get lan_ifname`
		if [ "x$router" != "x" ]; then
			route del default gw $router dev $interface
		fi
		router=`/usr/sbin/nvram get wan_gateway`
		if [ "x$router" != "x" ]; then
			route add default gw $router dev $interface
		fi
		${DNSMASQ_INIT_PROG} restart
}

route_dns_release()
{
		router=`/usr/sbin/nvram get wan_default_gateway`
		interface=`nvram get lan_ifname`
		if [ "x$router" != "x" ]; then
			route del default gw $router dev $interface
		fi
		${DNSMASQ_INIT_PROG} stop
}

start() {
		# Start daemons.
		echo $"Starting Service: "
		${HTTPD_INIT_PROG} start
		${SYSLOGD_INIT_PROG} start
		${UPNP_INIT_PROG} start
		${NET_SCAN} start
		${LLTD_PROG} start
		if [ "$(nvram get wan_proto)" = "dhcp" ]; then
			${UDHCPC_INIT_PROG} start
		else
			route_dns_renew
		fi
		${NETBIOS_INIT_PROG} start
		#${TELNETD_INIT_PROG} reload
		#/usr/sbin/getdeviceinfo &
		/usr/sbin/telnetenable
	
		RETVAL=$?
		echo
		return $RETVAL
}

stop() {
		# Stop daemons.
		echo $"Shutting Service: "
		${HTTPD_INIT_PROG} stop

			${UDHCPC_INIT_PROG} stop
			route_dns_release

		#${TELNETD_INIT_PROG} stop
		#killall getdeviceinfo
		${NETBIOS_INIT_PROG} stop
		
		${SYSLOGD_INIT_PROG} stop
		${UPNP_INIT_PROG} stop
		${LLTD_PROG} stop
		${NET_SCAN} stop
		killall telnetenable
  	
		RETVAL=$?
		echo
		return $RETVAL
}

ui_start() {
	# Start daemons.
	echo $"Starting Service: "
		if [ "$(nvram get wan_proto)" = "dhcp" ]; then
			${UDHCPC_INIT_PROG} start
		else
			route_dns_renew
		fi
		
		#${TELNETD_INIT_PROG} reload
		#/usr/sbin/getdeviceinfo &
		/usr/sbin/telnetenable
	${UPNP_INIT_PROG} start
	${NET_SCAN} start
	RETVAL=$?
	echo
	return $RETVAL
}

ui_stop() {
	# Stop daemons.
	echo $"Shutting Service: "
	#${UDHCPD_INIT_PROG} stop
	${DNSMASQ_INIT_PROG} stop
	${UPNP_INIT_PROG} stop
	#${RIPD_INIT_PROG} stop
	#${ROUTING_PROG} stop
	${NET_SCAN} stop


			${UDHCPC_INIT_PROG} stop
			route_dns_release
			
		#${TELNETD_INIT_PROG} stop
		#killall getdeviceinfo
		killall telnetenable
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  start_ui)
	ui_start
	;;
  stop_ui)
	ui_stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

