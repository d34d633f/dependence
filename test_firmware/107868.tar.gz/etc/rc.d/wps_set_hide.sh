#!/bin/sh

BCAST="$(nvram get endis_ssid_broadcast)"
if [ "$BCAST" = "0" ]; then
#echo "############################### delay 30 secs################"
		iwpriv ath0 hide_ssid 1
fi		