#!/bin/sh

#[ -f /usr/sbin/ripd ] || exit 0

lan_ifname=`nvram get lan_ifname`
pvlan=`nvram get nv_endis_pvlan`
pvlan_port1=`nvram get nv_PVLAN_port1`
pvlan_port2=`nvram get nv_PVLAN_port2`
pvlan_port3=`nvram get nv_PVLAN_port3`
pvlan_port4=`nvram get nv_PVLAN_port4`

RETVAL=0

start() {
	# Start port based VLAN.
	if [ "$pvlan" = "Enable" ]; then
		echo 1 > /proc/rtk_vlan_support
		eth2_up=`ifconfig | grep eth2`
		if [ "x$eth2_up" = "x" ]; then 
			ifconfig eth2 up 2> /dev/null
			ifconfig eth3 up 2> /dev/null
			ifconfig eth4 up 2> /dev/null
			brctl addif $lan_ifname eth2 2> /dev/null
			brctl addif $lan_ifname eth3 2> /dev/null
			brctl addif $lan_ifname eth4 2> /dev/null
		fi
		g_no=`echo $pvlan_port1 | cut -c2`
		if [ "$g_no" != "" ]; then
			Group$g_no eth0
		fi
		g_no=`echo $pvlan_port2 | cut -c2`
		if [ "$g_no" != "" ]; then
			Group$g_no eth2
		fi
		g_no=`echo $pvlan_port3 | cut -c2`
		if [ "$g_no" != "" ]; then
			Group$g_no eth3
		fi
		g_no=`echo $pvlan_port4 | cut -c2`
		if [ "$g_no" != "" ]; then
			Group$g_no eth4
		fi
	fi

	RETVAL=$?
	return $RETVAL
}

stop() {
	# Stop port based VLAN.
	echo 0 > /proc/rtk_vlan_support
	#brctl delif br0 eth2
	#brctl delif br0 eth3
	#brctl delif br0 eth4
	#ifconfig eth2 down
	#ifconfig eth3 down
	#ifconfig eth4 down

	RETVAL=$?
	echo
	return $RETVAL
}

Group1() {
	echo "1 1 1 0 4091 0 0" > /proc/$1/mib_vlan
}

Group2() {
	echo "1 1 1 0 4092 0 0" > /proc/$1/mib_vlan
}

Group3() {
	echo "1 1 1 0 4093 0 0" > /proc/$1/mib_vlan
}

Group4() {
	echo "1 1 1 0 4094 0 0" > /proc/$1/mib_vlan
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

