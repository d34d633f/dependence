#!/bin/sh
. /etc/rc.d/tools.sh
iptables="iptables"
drop="DROP"
accept="ACCEPT"
reject="REJECT"
Added="-A"

lan_ifname=`nvram get lan_ifname`
wan_ifname=`nvram get wan_ifname`
local LAN_IPADDR=`nvram get lan_ipaddr`


#input: LAN_masklen
dos_firewall_advance()
{
	if [ $# != 1 ]; then
		echo "#Error dos_firewall_advance() needs LAN_masklen as arugment!"
		return;
	fi

	local wan_default_iface="0"
	local wan_ipaddr=`nvram get wan${wan_default_iface}_ipaddr`
	local lan_subnet=`nvram get lan_netmask`
	local masklen=`print_masklen $lan_subnet`

#	$iptables $Added syn-flood -m limit --limit 50/s --limit-burst 50 -j RETURN
#	$iptables $Added syn-flood -m log --log-prefix "[DoS Attack : Syn-Flood]" -j DROP
	
#-----------------FORWARD CHAIN----------------------------------
	#V1.0.0.2: add match spiDoS cover spi firewall #1, #5, #6, #10, #11, #12, #14,
	#(#6 echo-chargen needs additional command to enable). Use the new match to make
	# the iptables clean and simple.
	#2, 3, 4 are protected by linux itself. #7, #13 not implement yet...

	#echo templ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	$iptables $Added fwd_dos_mangle -t mangle -m spiDoS --WANIfName $wan_ifname --lan-addr/mask $LAN_IPADDR/$1 -j DROP
	$iptables $Added fwd_dos_EchoChargen -m spiDoS --WANIfName $wan_ifname --echo-chargen 0xf -j DROP

#	$iptables $Added fwd_dos_input -p tcp --syn -j syn-flood #9
#	$iptables $Added fwd_dos_mangle -t mangle -p tcp -j DROP
	#$iptables $Added fwd_dos_mangle -t mangle -i $wan_ifname -m spiadvDoS -p tcp -j DROP

	#Attack 13 ---> TCP Port Scan
	$iptables $Added fwd_dos_mangle -t mangle -m spiTcpScan --WANIfName $wan_ifname --check -j DROP
	$iptables -I POSTROUTING 1 -t mangle -s $LAN_IPADDR/$masklen -m spiTcpScan --WANIfName $wan_ifname --count -j DROP

	#following three rules are not SPI FIREWALL issue...  moved into forward_init chain.
	#$iptables $Added fwd_dos_mangle -t mangle -o $wan_ifname -p tcp --tcp-flags RST RST -m state --state NEW -j DROP
	#$iptables $Added fwd_dos_mangle -t mangle -o $wan_ifname -p tcp --tcp-flags ACK ACK -m state --state NEW -j DROP
	#$iptables $Added fwd_dos_mangle -t mangle -o $wan_ifname -p tcp --tcp-flags FIN FIN -m state --state NEW -j DROP

#-----------------INPUT CHAIN----------------------------------
#	$iptables $Added input_dos -p tcp --syn -j syn-flood
#	$iptables $Added input_dos -p tcp -j DROP
	#$iptables $Added input_dos -i $wan_ifname -m spiadvDoS -j DROP -p tcp

	$iptables $Added input_dos -m spiDoS --WANIfName $wan_ifname --lan-addr/mask $LAN_IPADDR/$1 -j DROP
	$iptables $Added input_dos -m spiDoS --WANIfName $wan_ifname --echo-chargen  0xf -j DROP

	#v1.0.0.2: keep this..
	# Attack 12 ---> UDP Port Scan
		#$iptables $Added output_dos -p icmp --icmp-type 3 -j DROP #icmp-type 3 -> Destination Unreachable


	#Attack 13 ---> TCP Port Scan 20090826 lloyd: the rule may block remote management...so close it..
	#$iptables $Added input_dos -m spiTcpScan --WANIfName $wan_ifname --check -j DROP

}

