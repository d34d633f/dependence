#!/bin/sh

IPV6_PASS=`nvram get ipv6_pass`
WAN_IFNAME=`nvram get wan_ifname`
WAN_HWIFNAME=`nvram get wan_hwifname`
LAN_IFNAME=`nvram get lan_ifname`
MODULE=/lib/modules/2.6.30/ipv6pass.ko

PPPoE_PASS=`nvram get PPPoEPassThrough_enable`

start() {
	echo "Set IPv6 passthrough module..."

	if [ "$IPV6_PASS" = "1" ]; then
		if ! lsmod |grep $MODULE > /dev/null; then \
			echo "insert $MODULE kernel module"; \
			insmod $MODULE wan_ifname=$WAN_IFNAME lan_ifname=$LAN_IFNAME wan_hwifname=$WAN_HWIFNAME; \
			echo 1 > /proc/rtk_promiscuous
		fi
	fi

	RETVAL=$?
	return $RETVAL
}

stop() {

	echo "remove $MODULE kernel module"
	rmmod $MODULE
	if [ "$PPPoE_PASS" = "1" ] then
		echo 1 > /proc/rtk_promiscuous
	else
		echo 0 > /proc/rtk_promiscuous
	fi

	RETVAL=$?
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

