#!/bin/sh


# Configure /etc/udhcpd.conf via nvram

#[ -f /sbin/udhcpd ] || exit 0
#[ -f /etc/udhcpd.conf ] || exit 0
#dhcprelay=`nvram get DHCPRelayEnabled`

RETVAL=0
prog="udhcpd"
relayprog="dhcprelay"

PID_FILE="/var/run/udhcpd.pid"
CONFIG_FILE="/var/udhcpd.conf"

lan_ifname=`nvram get lan_ifname`
wan_ifname=`nvram get wan_hwifname`

lan_proto=`nvram get lan_proto`
dhcp_start=`nvram get dhcp_start`
dhcp_end=`nvram get dhcp_end`
subnet=`nvram get lan_netmask`
lan_ipaddr=`nvram get lan_ipaddr`
domain=`nvram get wan_domain`
leasetime=`nvram get dhcp_lease`
dhcp_route=`nvram get dhcp_route`
dhcp_dns=`nvram get dhcp_dns`
wds_enable=`nvram get wds_endis_fun`
wds_mode=`nvram get wds_repeater_basic`
win_server=`nvram get dhcp_wins`
relay_server=`nvram get dhcp_relay_server`

manual_ip() {
        num=1
	entry=`nvram get reservation$num`
	while [ "$entry" != "" ];
        do
		ip=`echo $entry | awk -F" " '{print $1}'`
		mac=`echo $entry | awk -F" " '{print $2}'`
      action=`echo $entry | awk -F" " '{print $3}'`
      if [ "$action" = "1" ]; then           
         echo "static_lease $mac $ip" >> $CONFIG_FILE        
      fi
      num=$(($num+1))
		entry=`nvram get reservation$num`
      done
}

start() {

   if [ "$lan_proto" = "relay" ]; then
      ${relayprog} ${lan_ifname} ${wan_ifname} ${relay_server} &
      exit 0
   fi

	[ -e ${PID_FILE} ] && exit 0
   num=1
	# Start daemons.
	echo $"Starting $prog: "
	echo "start		$dhcp_start" > $CONFIG_FILE
	echo "end		$dhcp_end" >> $CONFIG_FILE
	echo "interface		$lan_ifname" >> $CONFIG_FILE
	echo "remaining		yes" >> $CONFIG_FILE
	echo "lease_file	/tmp/udhcpd.leases" >> $CONFIG_FILE
	#echo "auto_time		5" >> $CONFIG_FILE
	echo "pidfile		$PID_FILE" >> $CONFIG_FILE
	echo "option	subnet	$subnet" >> $CONFIG_FILE
   if [ "$dhcp_route" = "" ]; then
      echo "option	router	$lan_ipaddr" >> $CONFIG_FILE
   else
      echo "option	router	$dhcp_route" >> $CONFIG_FILE
   fi
   if [ "$dhcp_dns" = "0.0.0.0 0.0.0.0 0.0.0.0" ]; then
      echo "option	dns	$lan_ipaddr" >> $CONFIG_FILE
   else
      for i in $dhcp_dns; do
			if [  "$i" != "0.0.0.0" ];then
            if [ $num = "1" ]; then
                dns1="$i"
            elif [ $num = "2" ]; then
                dns2="$i"
            else
                dns3="$i"
            fi

            num=$(($num+1))
			fi
		done

      if [ "$dns1" != "" ]; then
         if [ "$dns2" = "" ]; then
            echo "option	dns	$dns1" >> $CONFIG_FILE
         elif [ "$dns3" = "" ]; then
            echo "option	dns	$dns1, $dns2" >> $CONFIG_FILE
         else
            echo "option	dns	$dns1, $dns2, $dns3" >> $CONFIG_FILE
         fi        
      fi      
   fi

   if [ "$domain" != "" ]; then
      echo "option	domain	$domain" >> $CONFIG_FILE
   fi

	if [ "$leasetime" = "0" ]; then		#lease time = 2 day
		echo "option	lease	$((2880*60))" >> $CONFIG_FILE	
	else	
		echo "option	lease	$(($leasetime*60))" >> $CONFIG_FILE	#half hours to seconds	
	fi

   if [ "$win_server" != "" ]; then
      echo "option wins $win_server" >> $CONFIG_FILE	
   fi

	manual_ip
	
	if [ "$lan_proto" = "dhcp" ]; then
		${prog} ${CONFIG_FILE} &
	fi
	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting down $prog: "
	#if [ -e ${PID_FILE} ]; then
	#	kill `cat ${PID_FILE}`
	#	rm -f ${PID_FILE}
	#fi
   killall -9 dhcprelay
	killall -9 udhcpd
	if [ -e ${PID_FILE} ]; then
		rm -f ${PID_FILE}
	fi
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
  if [ "$wds_enable" = "1" -a "$wds_mode" = "0" ]; then
  	echo "wds in repeater mode, no dhcpd on"
  else
  	start
  fi
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

