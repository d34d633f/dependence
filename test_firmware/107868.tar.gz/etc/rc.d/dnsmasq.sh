#!/bin/sh

RETVAL=0

ROUTE="/sbin/route"
prog="dnsmasq"
wan_phy_mode=`nvram get wan_phy_mode`
WAN_INTFS="1 2 3 4 5 6 7 8"

find_wan()  #$1: lan group
{
     lan_group=$1
     find_wan=`nvram get interface_group_map | cut -d":" -f $lan_group | grep "wan"`
     if [ "x$find_wan" != "x" ]; then
          temp=$find_wan
          for i in $WAN_INTFS
          do
              wan=`echo $temp | grep "wan$i"`
              if [ "x$wan" != "x" ]; then
                   find_wan=$i
                   break
              fi
         done
     fi
     echo $find_wan
}

if [ "$wan_phy_mode" = "adsl" ]; then
	lan_iface=$2
        LAN=br${lan_iface}
	wan_iface=`find_wan ${lan_iface}`
fi

PID_FILE="/var/run/dnsmasq${lan_iface}.pid"
CONFIG_FILE="/var/resolv${lan_iface}.conf"
PARENTAL_CONTROL_CONFIG="/tmp/parentalcontrol.conf"
INTERFACE=`nvram get lan${lan_iface}_ifname`
wan_ifname=`nvram get wan${wan_iface}_ifname`
wan_ipaddr=`nvram get wan${wan_iface}_default_ipaddr`
wan_netmask=`nvram get wan${wan_iface}_default_netmask`
gateway=`nvram get wan${wan_iface}_default_gateway`


wan_proto=`nvram get wan${wan_iface}_proto`
auto_dns=`nvram get wan_autodns`
wan_domain=`nvram get wan_domain`
static_dns=`nvram get pptp_get_dns_assign`
dyn_pptpl2tp_dhcp_state="$2"	#it could be from dyn_pptp.sh or dyn_l2tp.sh
PC_enable=`nvram get ParentalControl`
PC_TABLE=`nvram get ParentalControl_table`

PRE_SET_FLAG=0
#pppoe
pppoe_demand=`nvram get wan_pppoe_demand`
#pptp
dy_pptp=`nvram get dy_pptp`
pptp_demand=`nvram get wan_pptp_demand`
#l2tp
dy_l2tp=`nvram get dy_l2tp`
l2tp_demand=`nvram get wan_l2tp_demand`

if [ "$wan_proto" = "pppoe" -a "$pppoe_demand" = "1" ] || 
	[ "$wan_proto" = "pptp" -a "$dy_pptp" = "0" -a "$pptp_demand" = "1" ] ||
	[ "$wan_proto" = "l2tp" -a "$dy_l2tp" = "0" -a "$l2tp_demand" = "1" ]; then
		PRE_SET_FLAG=1
fi

case "$wan_proto" in
	static|dhcp|ipoa)
		wan_ether_dns_assign=`nvram get wan${wan_iface}_ether_dns_assign`
		if [ "$wan_ether_dns_assign" = "1" ]; then
			auto_dns="0"
			dns1=`nvram get wan${wan_iface}_ether_dns1`
		 	dns2=`nvram get wan${wan_iface}_ether_dns2`
			wan_dns="$dns1 $dns2"
		else
			auto_dns="1"
		fi
		;;
	pppoe|pppoa)
		wan_pppoe_dns_assign=`nvram get wan${wan_iface}_pppoe_dns_assign`
		if [ "$wan_pppoe_dns_assign" = "1" ]; then
			auto_dns="0"
			dns1=`nvram get wan${wan_iface}_ether_dns1`
		 	dns2=`nvram get wan${wan_iface}_ether_dns2`
			wan_dns="$dns1 $dns2"
		else
			auto_dns="1"
		fi
		;;
	pptp)
		wan_pptp_dns_assign=`nvram get wan${wan_iface}_pptp_dns_assign`
		if [ "$wan_pptp_dns_assign" = "1" ]; then
			auto_dns="0"
			dns1=`nvram get wan${wan_iface}_ether_dns1`
		 	dns2=`nvram get wan${wan_iface}_ether_dns2`
			wan_dns="$dns1 $dns2"
		else
			auto_dns="1"
		fi
		;;
	l2tp)
		wan_l2tp_dns_assign=`nvram get wan${wan_iface}_l2tp_dns_assign`
		if [ "$wan_l2tp_dns_assign" = "1" ]; then
			auto_dns="0"
			dns1=`nvram get wan${wan_iface}_ether_dns1`
		 	dns2=`nvram get wan${wan_iface}_ether_dns2`
			wan_dns="$dns1 $dns2"
		else
			auto_dns="1"
		fi
		;;
    *)
esac
						
start() {
	# Start daemons.
	echo $"Starting $prog ${LAN}:"

        if [ "$auto_dns" = "0" -a "$dyn_pptpl2tp_dhcp_state" != "1" ]; then  
		dns=$wan_dns               
                if [ "$wan_proto" = "pptp" -o "$wan_proto" = "l2tp" ]; then  
		    if [ "$wan_phy_mode" != "adsl" ]; then
			dns=`nvram get wan0_dns` 
		    else
			dns=`nvram get wan${wan_iface}_dns` 
		    fi
                fi  
        else  
            if [ "$wan_phy_mode" != "adsl" ]; then
		dns=`nvram get wan0_dns` 
    	    else
		dns=`nvram get wan${wan_iface}_dns` 
	    fi
	fi 

	nvram set wan${wan_iface}_default_dns="$dns" 
	MAX_DNS_NUM=3
	count=0
	echo search $wan_domain > $CONFIG_FILE
	#echo nameserver 127.0.0.1 >> $CONFIG_FILE
	if [ -z "$dns" ]; then
		if [ "$PRE_SET_FLAG" = "1" ]; then 
			echo "nameserver 206.82.202.46		#netgear" >> $CONFIG_FILE
		else
			echo "No nameserver in /var/resolv.conf"
		fi
	else
		for i in $dns; do
		  if [ "$count" -lt "$MAX_DNS_NUM" ]; then
			    echo nameserver $i >> $CONFIG_FILE
			    count=$(($count+1))
			else
			    break
			fi
		done
	fi
	#${prog} -h -n -i ${INTERFACE} -r ${CONFIG_FILE}
	# NETGEAR SPEC: Cache should not be implemented
	# add dnsmasq parameter "-c 0"
	if [ "$PC_enable" = "1" ]; then
		echo "$PC_TABLE" > $PARENTAL_CONTROL_CONFIG
		${prog} -h -n -c 0 -i ${INTERFACE} -x ${PID_FILE} -r ${CONFIG_FILE} -P ${PARENTAL_CONTROL_CONFIG}
	else
		${prog} -h -n -c 0 -i ${INTERFACE} -x ${PID_FILE} -r ${CONFIG_FILE}
	fi

	if [ "$wan_phy_mode" = "adsl" ] && [ "x$gateway" != "x" ]; then
		count=0
		for i in $dns; do
                        if [ "$wan_netmask" = "255.255.255.255" ]; then
                            echo "route add -host $i gw $gateway dev $wan_ifname"                                    
                            route add -host $i gw $gateway dev $wan_ifname 2> /dev/null      
                        else
                            area-ck $i $wan_ipaddr $wan_netmask
                            if [ "$?" = "0" ]; then  # dns server ip is not at wan ip domain
                                echo "route add -host $i gw $gateway dev $wan_ifname"                                    
                                route add -host $i gw $gateway dev $wan_ifname 2> /dev/null                                    
                            fi					
                        fi
		done
	fi

	RETVAL=$?
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting down $prog ${LAN}:"

	if [ "$wan_phy_mode" = "adsl" ]; then
		count=0
		dns=`nvram get wan${wan_iface}_default_dns` 

		for i in $dns; do
			echo "route del -host $i gw $gateway dev $wan_ifname"
			route del -host $i gw $gateway dev $wan_ifname 2> /dev/null
		done
	fi

	if [ -e ${PID_FILE} ]; then
		kill `cat ${PID_FILE}`
		rm -f ${PID_FILE}
	fi
	#killall -9 dnsmasq
	#rm -f ${PID_FILE}
	rm -f ${CONFIG_FILE}
	RETVAL=$?
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

