#!/bin/sh

les_test_type="$2"

start() 
{	
	if [ "$les_test_type" = "1" ];  then #led power test
		echo "Power test START!!!"
		
		echo  104 > /proc/gpio #power led reverse
		sleep 1
		echo  104 > /proc/gpio
		sleep 1
		echo  104 > /proc/gpio
		sleep 1
		echo  104 > /proc/gpio
	fi
	
	if [ "$les_test_type" = "2" ];  then #led service test
		echo "Service test START!!!"
		
		echo  114 > /proc/gpio #service led reverse
		sleep 1
		echo  114 > /proc/gpio
		sleep 1
		echo  114 > /proc/gpio
		sleep 1
		echo  114 > /proc/gpio
	fi
	
	if [ "$les_test_type" = "3" ];  then #led eco test
		echo "ECO test START!!!"
		
		echo  124 > /proc/gpio #eco led reverse
		sleep 1
		echo  124 > /proc/gpio
		sleep 1
		echo  124 > /proc/gpio
		sleep 1
		echo  124 > /proc/gpio
	fi
}

stop()
{
	echo "test STOP!!!"
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit 1

