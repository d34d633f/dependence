#!/bin/sh

. /etc/rc.d/tools.sh

lan_ifname=`nvram get lan_ifname`
lan_hwifname=`nvram get lan_hwifname`
wan_hwifname=`nvram get wan_hwifname` #PLC Device
router_disable=`nvram get router_disable`


lan_hwaddr=`nvram get lan_hwaddr`
#ifconfig eth0 up
ifconfig lo 127.0.0.1 netmask 255.0.0.0 up

ifconfig $lan_ifname down
brctl delbr $lan_ifname
brctl addbr $lan_ifname
brctl setfd $lan_ifname 0
brctl stp $lan_ifname 0

#Use as Access Point
# To avoid to change mac address on br0, there are 2 ways as the followings,
# 1. changed eth1 hwaddr equal to eth0 
# 2. brctl addif br0 eth1, brctl addif br0 eth0

IPADDR=`nvram get wan_ipaddr`
SUBNET=`nvram get wan_netmask`


brctl addif $lan_ifname $lan_hwifname
ifconfig $lan_hwifname up

#add by kenny for bring up plc device(eth0) and bridge with br0
brctl addif $lan_ifname $wan_hwifname
ifconfig $wan_hwifname up
#end of add

ifconfig $lan_ifname promisc

echo "Configuring LAN , lan_ifname = $lan_ifname ........"
ifconfig $lan_ifname down
ifconfig $lan_ifname $IPADDR netmask $SUBNET up


echo "### phy down for NETGEAR request ###"
echo 33 > /proc/driver/net_sw
	

