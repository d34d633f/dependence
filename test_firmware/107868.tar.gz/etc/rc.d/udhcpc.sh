#!/bin/sh

#[ -f /sbin/udhcpc ] || exit 0
[ -f /etc/udhcpc/udhcpc.script ] || exit 0

RETVAL=0
prog="udhcpc"
PID_FILE="/var/run/udhcpc.pid"
SCRIPT_FILE="/etc/udhcpc/udhcpc.script"
BIGPOND_INIT_PROG="/etc/rc.d/heartbeat.sh"

WANIP_CHECK="/etc/rc.d/check_wanip_success.sh"

lan_ifname=$(nvram get lan_ifname)
lan_ip=$(nvram get lan_ipaddr)

#hostname=`nvram get wan_hostname`
hostname=`nvram get netbiosname`
if [ -z $hostname ]; then
   AP_NAME=`nvram get AirStation_name`
	hostname="-h ${AP_NAME}"
else
	hostname="-h ${hostname}"
fi

manual=$2

start() {
	# Start daemons.
	echo $"Starting $prog: "

	if [ "$(nvram get wan_proto)" = "dhcp" ]; then
			echo "${prog} -i ${lan_ifname} -p ${PID_FILE} -s ${SCRIPT_FILE} ${hostname} -r $lan_ip &"
			${prog} -R -i ${lan_ifname} -p ${PID_FILE} -s ${SCRIPT_FILE} ${hostname} -r $lan_ip &		
	fi		
	
	RETVAL=$?
	echo

   #killall check_wanip_success.sh
  
   #$WANIP_CHECK &

	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting down $prog: "
	if [ -e ${PID_FILE} ]; then
		killall -9 udhcpc
	fi
	#killall -9 bpalogin
	rm -f ${PID_FILE}
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

