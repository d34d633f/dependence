#!/bin/sh

RETVAL=0

echo "running cmdap.sh"

router_disable=`nvram get router_disable`

start() {

	#/etc/rc.d/pre_upnp.sh
	/etc/rc.d/lltd.sh restart
	/etc/rc.d/lan_start_ap.sh
	echo 32 > /proc/driver/net_sw
  /etc/rc.d/wlan_ath.sh start
  dniPlcd &
  /etc/rc.d/service_start_ap.sh start_ui 

	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
 
	sleep 1
	echo 33 > /proc/driver/net_sw      # phy down 
	/etc/rc.d/service_start_ap.sh stop_ui
  /etc/rc.d/wlan_ath.sh stop
  killall dniPlcd

        
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

