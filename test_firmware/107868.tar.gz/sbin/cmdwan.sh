#!/bin/sh

RETVAL=0
UDHCPC_INIT_PROG="/etc/rc.d/udhcpc.sh"
FIXED_INIT_PROG="/etc/rc.d/static.sh"
MULTI_PPPOE_INIT_PROG="/etc/rc.d/multi-pppoe.sh"
PPPOE_INIT_PROG="/etc/rc.d/pppoe.sh"
PPPOA_INIT_PROG="/etc/rc.d/pppoa.sh"

wan_proto=`nvram get wan_proto`
manual=$2
NVRAM="/usr/sbin/nvram"

nvram set manual_start=$manual
mulpppoe_select=`nvram get mulpppoe_select`
wan0_ipaddr=`nvram get wan0_ipaddr`
wan1_ipaddr=`nvram get wan1_ipaddr`
FletsPreset=`nvram get FletsPreset`
wan0_ifname=`ifconfig | grep ppp0 | awk -F" " '{print $1}'`
wan1_ifname=`ifconfig | grep ppp1 | awk -F" " '{print $1}'`

start() {
	# Start daemons.
	echo $"Starting WAN: "

   wl_radio=`nvram get endis_wl_radio`
   router_disable=`nvram get router_disable`

   /etc/rc.d/set_wan_ifname.sh
	wanif=`nvram get wan_hwifname`

   nvram unset wan0_ipaddr
   nvram unset wan0_netmask
   nvram unset wan0_gateway
   nvram unset wan0_dns
   nvram unset wan_default_ipaddr
   nvram unset wan_default_netmask
   nvram unset wan_default_gateway

   #/sbin/ledcontrol -n internet_ng -s off
   #/sbin/ledcontrol -n internet_ok -s off 
   #killall diagLed_hdl
   #/sbin/ledcontrol -n system_ok -s on
   #/sbin/ledcontrol -n system_ng -s off

   if [ "$router_disable" -ne "0" ]; then
		return $RETVAL
	fi	

   DSLLINK_STATUS=/tmp/dslStatus/dslLink_status
   if [ -f $DSLLINK_STATUS ]; then
      dsl_status=`cat $DSLLINK_STATUS`
      if [ $dsl_status != "1" ]; then
         echo "dsl not link"
         return $RETVAL
      fi
   else
       echo "dsl not link"
       return $RETVAL
   fi        
   
   if [ "$wan_proto" != "pppoa" ]; then      
      route add -host 255.255.255.255 metric 0 dev $wanif
   fi
		
   cat /proc/uptime | sed 's/ .*//' > /tmp/WAN_RE_uptime

	case "$wan_proto" in	
		static)         
			${FIXED_INIT_PROG} start
			;;
		dhcp|bigpond)		
			echo `nvram get wan_hostname` > /proc/sys/kernel/hostname
			${UDHCPC_INIT_PROG} start $manual
			;;
		pppoe)
			${PPPOE_INIT_PROG} start $manual
			;;
      pppoa)
			${PPPOA_INIT_PROG} start $manual
			;;
		*)

			echo $"Usage: $0 {start|stop|restart}"
	esac

	RETVAL=$?
	echo
	return $RETVAL
}

stop() {
	# Stop daemons.
	echo $"Shutting WAN: "

	/etc/rc.d/ntpclient.sh stop
	/etc/rc.d/spi_dos.sh stop
	/etc/rc.d/igmpproxy.sh stop
	${UDHCPC_INIT_PROG} stop
   ${FIXED_INIT_PROG} stop

   ${PPPOE_INIT_PROG} stop
   ${PPPOA_INIT_PROG} stop

  	echo 2 > /proc/fast_nat
	RETVAL=$?
	echo
	return $RETVAL
}

# See how we were called.
case "$1" in
  start)
	start
	;;
  stop)
	stop
	;;
  restart|reload)
	stop
	sleep 1
	start
	RETVAL=$?
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $RETVAL

