/*
 *	var index = cf.WRegion.selectedIndex;
	index=parseInt(index)+1;
 *	this is for one more region, select.
*/
//bug 23854:The dialogue of DFS channel is not implemented
function check_dfs()
{
	var cf = document.forms[0]; 
	var each_info = dfs_info.split(':');
	var channel_info;

	var channel = cf.w_channel_an;
        var ch_index = channel.selectedIndex;
        var ch_name = channel.options[ch_index].text;
	var ch_value = channel.options[ch_index].value;

	for ( i=0; i<each_info.length; i++ )
	{
		channel_info = each_info[i].split(' '); //channel; channel_flag; channe_priflag; left_time
		var sec = channel_info[3]%60;		//change left time format
		var min = parseInt(channel_info[3]/60);
		if( ch_value == channel_info[0] )
		{
			alert("$using_dfs_1" + min + "$using_dfs_2" + sec + "$using_dfs_3");
			return false;
		}
	}	

	//if the channel is allowed to use, show warning message
	//var AChannel_name = new Array("0", "36", "40", "44", "48", "52(DFS)", "56(DFS)", "60(DFS)", "64(DFS)", "100(DFS)", "104(DFS)", "108(DFS)", "112(DFS)", "116(DFS)", "120(DFS)", "124(DFS)", "128(DFS)", "132(DFS)", "136(DFS)", "140(DFS)", "149", "153", "157", "161", "165");
	//bug 23934:modify the channel selection in HT40 mode,eg:show "36+40" instead of "36",so use the value of channel to judge the warning message
	var AChannel_name = new Array("0", "36", "40", "44", "48", "52", "56", "60", "64", "100", "104", "108", "112", "116", "120", "124", "128", "132", "136", "140", "149", "153", "157", "161", "165");

	if(dfs_channel2_router_flag == 1)
	{
		for( i=5; i<=19; i++ )
		{
			if( AChannel_name[i] == ch_value)
			{
				return confirm("$select_dfs");
			}	
		}
	}

	return true;
}
function set_ap_security(cf,tag)
{  
//	var browser=eval ( '"' + top.location + '"' );
	var keytype;
/*	if  ( lan_dhcp == 1 && dns_hijack != 1)
	{
		judge_browser(cf,browser);
	}
*/

		ssid = document.forms[0].wlan_ap_wifi.value;
	    parent.wlan_ap_wifi=ssid;
		//var space_flag=0;
		if (dns_hijack==1)
		{
			var len=ssid.length;
			if(len>28)
					ssid=ssid.substring(0,28);
			document.forms[0].wlan_ca_ap_wifi.value= ssid +"_EXT";
		}
		if(ssid == "")
	    {
	        alert("$ssid_null");
	        return false;
	    }
		for(i=0;i<ssid.length;i++)
	    {
	        if(isValidChar_space(ssid.charCodeAt(i))==false)
	        {
	            alert("$ssid_not_allowed");
	            return false;
	        }
	    }
		    /*for(i=0;i<ssid.length;i++)
	        {
	            	if(ssid.charCodeAt(i)!=32)
	                	space_flag++;
	        }
			if(space_flag==0)
			{
				alert(ssid_null);
	        	return false;
			}*/
	document.forms[0].wlan_ap_wifi.value=document.forms[0].wlan_ap_wifi.value.replace(/&lt;/g,'<');
	document.forms[0].wlan_ap_wifi.value=document.forms[0].wlan_ap_wifi.value.replace(/&gt;/g,'>');
	document.forms[0].wlan_ca_ap_wifi.value=document.forms[0].wlan_ca_ap_wifi.value.replace(/&lt;/g,'<');
	document.forms[0].wlan_ca_ap_wifi.value=document.forms[0].wlan_ca_ap_wifi.value.replace(/&gt;/g,'>');
	if(tag == 1)
	{
		if(cf.hidden_sec_ap_type.value==2)
	    {
			//if(checkwep_byid(cf)==false)
			//	return false;
	        cf.hidden_sec_ap_type.value=2;
			cf.ap_sec_wpaphrase_len.value=getObj1('weppassphrase_id').value.length;
			cf.sec_auth.value=2;
			cf.hidden_sec_keylen.value=getObj1("keylen_id").value;
			for(i=1;i<5;i++)
			{
				if(eval("getObj1('wepkeyno_id"+i+"').checked")==true)
				{
					var tt=i-1
					cf.hidden_wepkeyno.value=tt;
					
				}
			}
			cf.hidden_passphrasestr.value=getObj1("weppassphrase_id").value;
			cf.hidden_wepkey1.value=getObj1("key1_id").value;
			cf.hidden_wepkey2.value=getObj1("key2_id").value;
			cf.hidden_wepkey3.value=getObj1("key3_id").value;
			cf.hidden_wepkey4.value=getObj1("key4_id").value;
			cf.sec_phrase.value=getObj1("weppassphrase_id").value;
			var len1=document.getElementById("key1_id").value.length;
			var len2=document.getElementById("key2_id").value.length;
			var len3=document.getElementById("key3_id").value.length;
			var len4=document.getElementById("key4_id").value.length;
			if(getObj1("keylen_id").value == 5)
				keytype=5;
			else
				keytype=13;
			
				for(i=0;i<keytype;i++)
				{
					if(((getObj1('wepkeyno_id1').checked == true) && (len1 == keytype)) || ((getObj1('wepkeyno_id2').checked == true) && (len2 == keytype)) || ((getObj1('wepkeyno_id3').checked == true) && (len3 == keytype)) || ((getObj1('wepkeyno_id4').checked == true) && (len4 == keytype)))
						cf.key_type.value=1;
					else
						cf.key_type.value=0;
				}
			if(old_sectype==2 && dns_hijack==0)
				alert("$wep_same_security")
	        cf.submit();
	    }
		else if(cf.hidden_sec_ap_type.value!=1)
		{        
			if(cf.hidden_sec_ap_type.value==3)
				cf.ap_sec_wpaphrase.value=getObj1("textWpaPwdPhrase1").value;
			else if(cf.hidden_sec_ap_type.value==4)
				cf.ap_sec_wpaphrase.value=getObj1("textWpaPwdPhrase2").value;
			else if(cf.hidden_sec_ap_type.value==5)
				cf.ap_sec_wpaphrase.value=getObj1("textWpaPwdPhrase3").value;
	        if( checkpsk_ca_manual(cf)== false)
	            return false;
			cf.ap_sec_wpaphrase_len.value=cf.ap_sec_wpaphrase.value.length;
	        cf.hidden_wpa_ap_psk.value = cf.ap_sec_wpaphrase.value;
			
	        cf.submit();
		}
		else
			cf.submit();
    }
	else
	{
		cf.wlan_channel.value=parent.scan_channel;
		if(cf.hidden_sec_ap_type.value==2)
	    {
			//if(checkwep_byid(cf)==false)
			//	return false;

            if(getObj1("wepkeyno_id1").checked == true)
			{
				cf.ap_wepkeyno.value = 1;
			}
			if(getObj1("wepkeyno_id2").checked == true)
	        {
        	    cf.ap_wepkeyno.value = 2;
	        }
			if(getObj1("wepkeyno_id3").checked == true)
            {
                cf.ap_wepkeyno.value = 3;
            }
			if(getObj1("wepkeyno_id4").checked == true)
            {
                cf.ap_wepkeyno.value = 4;
            }
			
			cf.hidden_sec_ap_type.value=2;
			cf.ap_sec_wpaphrase_len.value=cf.ap_sec_phrase.length;
			cf.ap_sec_keylen.value=getObj1("keylen_id").value;
			cf.ap_wepkey1.value=getObj1("key1_id").value;
			cf.ap_wepkey2.value=getObj1("key2_id").value;
			cf.ap_wepkey3.value=getObj1("key3_id").value;
			cf.ap_wepkey4.value=getObj1("key4_id").value;
			cf.ap_sec_phrase.value=getObj1("weppassphrase_id").value;
			var len1=document.getElementById("key1_id").value.length;
			var len2=document.getElementById("key2_id").value.length;
			var len3=document.getElementById("key3_id").value.length;
			var len4=document.getElementById("key4_id").value.length;
			if(getObj1("keylen_id").value == 5)
				keytype=5;
			else
				keytype=13;
			
				for(i=0;i<keytype;i++)
				{
					if(((getObj1('wepkeyno_id1').checked == true) && (len1 == keytype)) || ((getObj1('wepkeyno_id2').checked == true) && (len2 == keytype)) || ((getObj1('wepkeyno_id3').checked == true) && (len3 == keytype)) || ((getObj1('wepkeyno_id4').checked == true) && (len4 == keytype)))
						cf.key_type.value=1;
					else
						cf.key_type.value=0;
				}
			if(old_sectype==2 && dns_hijack==0)
				alert("$wep_same_security")
	        cf.submit();
	    }
		else if (cf.hidden_sec_ap_type.value!=1)
		{        
	        if( checkpsk_ca_fixed(cf)== false)
	            return false;
			cf.ap_sec_wpaphrase_len.value=getObj1("textWpaPwdPhrase").value.length;
	        cf.hidden_wpa_ap_psk.value = cf.ap_sec_phrase.value;
			
	        cf.submit();
		}
		else
			cf.submit();
	}
}

function key_value(cf)
{
	getObj("weppassphrase_id").value=document.getElementsByName("weppassphrase")[0].value;
	getObj("key1_id").value=document.getElementsByName("wepkey1")[0].value;
	getObj("key2_id").value=document.getElementsByName("wepkey2")[0].value;
	getObj("key3_id").value=document.getElementsByName("wepkey3")[0].value;
	getObj("key4_id").value=document.getElementsByName("wepkey4")[0].value;
	getObj("textWpaPwdPhrase1").value=document.getElementsByName("sec_wpaphrase1")[0].value;
	getObj("textWpaPwdPhrase2").value=document.getElementsByName("sec_wpaphrase2")[0].value;
	getObj("textWpaPwdPhrase3").value=document.getElementsByName("sec_wpaphrase3")[0].value;
}

function match_security_mode(cf)
{    
/*	var browser=eval ( '"' + top.location + '"' );
	
	if  ( lan_dhcp == 1 && dns_hijack != 1 )
	{
		judge_browser_nochange(cf,browser);
	}
 */ if(parent.ap_list_reset=="manual")
		location.href="ca_apclient_manual.html";
	else
	{
		var each_info= parent.ap_list_reset;
		
		if(parent.ssid_null_tag == "n")
		{
			var loca=each_info[1].indexOf("&nbsp;");
			each_info[1]=each_info[1].substring(0,loca);
		}
		each_info[1]=each_info[1].replace(/&lt;/g,'<');
		each_info[1]=each_info[1].replace(/&gt;/g,'>');
	//	get_before=each_info[4].split('|');
	 //   each_info[4]=get_before[0];
	 
	// alert("each_info[4]="+each_info[4]);
	    if(each_info[4]=="WPA/WPA2-PSK")
		{
			cf.hidden_sec_ap_type.value=5;
			//alert("mix"+cf.hidden_sec_ap_type.value);
		}	//location.href="ca_apclient_wl_wpa.html";
		else if(each_info[4]=="WPA2-PSK")
		{
			cf.hidden_sec_ap_type.value=4;
			//alert("wpa2"+cf.hidden_sec_ap_type.value);
		}
		else if(each_info[4]=="WPA-PSK")
		{
			cf.hidden_sec_ap_type.value=3;	
			//alert("wpa"+cf.hidden_sec_ap_type.value);
		}
		else if(each_info[4]=="WEP")
		{
			cf.hidden_sec_ap_type.value=2;
			//alert("WEP"+cf.hidden_sec_ap_type.value);
		}
			//location.href="ca_apclient_wl_wep.html";
		else if(each_info[4]=="OFF")
		{		
			cf.hidden_sec_ap_type.value=1;
			//alert("off"+cf.hidden_sec_ap_type.value);
				   if (dns_hijack==1)
				   {
						var len=each_info[1].length;
								if(len>28)
									each_info[1]=each_info[1].substring(0,28);
						document.forms[0].wlan_ca_ap_wifi.value= each_info[1] + "_EXT";;
				   }

        }
		//alert("end"+cf.hidden_sec_ap_type.value);

		cf.wlan_ap_wifi.value=each_info[1];
		if( each_info[1] == "&nbsp;&nbsp;" )
		{
		location.href="ca_apclient_manual.html";	
		return true;
		}			
		cf.submit();
   }
}


function check_ca_wlan()
{
	var cf=document.forms[0];
	var ssid;

	
	if(cf.use_same_sec.checked == false)
	{
		    ssid = getObj1("ESSID").value;
		    cf.hidden_enable_ap_transmit.value=0;
			if(ssid == "")
	        {
	                alert("$ssid_null");
	                return false;
	        }
			for(i=0;i<ssid.length;i++)
	        {
	                if(isValidChar_space(ssid.charCodeAt(i))==false)
	                {
	                        alert(ssid + "$ssid_not_allowed");
	                        return false;
	                }
	        }
		
			cf.hidden_wlan_ssid.value=getObj1("ESSID").value;
			cf.hidden_same_sec.value=0;
					
			if(getObj1("type_id2").checked== true)
			{
				
				if( checkwep_byid(cf)== false)
					return false;
				cf.hidden_sec_type.value=2;
			}
			else if(getObj1("type_id3").checked == true)
			{
				
				if( checkpsk1(cf)== false)
					return false;
				if(confirm('$wpa_tkip_pop_message') == false)
					return false;
				cf.hidden_sec_type.value=3;
				cf.hidden_wpa_psk.value = getObj1("textWpaPwdPhrase1").value;
			}
			else if(getObj1("type_id4").checked == true)
			{

				if( checkpsk1(cf)== false)
					return false;
				cf.hidden_sec_type.value=4;
				cf.hidden_wpa_psk.value = getObj1("textWpaPwdPhrase2").value;
			}	
			else if(getObj1("type_id5").checked == true)
			{

				if( checkpsk1(cf)== false)
					return false;
				if(confirm('$wpa_mixed_pop_message') == false)
					return false;
				cf.hidden_sec_type.value=5;
				cf.hidden_wpa_psk.value = getObj1("textWpaPwdPhrase3").value;
			}	
			else
				cf.hidden_sec_type.value=1;
			//WEP
			if(getObj1("keylen_id").value == "")
				cf.hidden_sec_keylen.value = 5;
			else
				cf.hidden_sec_keylen.value = getObj1("keylen_id").value;
			
			if(getObj1("wepkeyno_id1").checked == true)
			    keyno_wep=1;
			else if(getObj1("wepkeyno_id2").checked == true)
			    keyno_wep=2;
			else if(getObj1("wepkeyno_id3").checked == true)
			    keyno_wep=3;
			else
				keyno_wep=4;
				
			cf.hidden_wepkeyno.value = keyno_wep;
			cf.hidden_wepkey1.value = getObj1("key1_id").value;
			cf.hidden_wepkey2.value = getObj1("key2_id").value;
			cf.hidden_wepkey3.value = getObj1("key3_id").value;
			cf.hidden_wepkey4.value = getObj1("key4_id").value;
			if(getObj1("weppassphrase_id").value!="")
				cf.hidden_weppassphrase.value = getObj1("weppassphrase_id").value;
			//WEP END	
			cf.sec_wpaphrase_len.value=cf.hidden_wpa_psk.value.length;
	}
	else
	{
		if(old_sectype == 2)
		{
			cf.hidden_sec_type.value=2;	
			cf.hidden_wepkeyno.value = wl_temp_keyno;
		}
		else if(old_sectype == 3)
		{
			if(confirm('$wpa_tkip_pop_message') == false)
                return false;
			cf.hidden_sec_type.value=3;
			cf.hidden_wpa_psk.value = get_wpa1;
		}
		else if(old_sectype == 4)
		{
			cf.hidden_sec_type.value=4;
			cf.hidden_wpa_psk.value = get_wpa2;
		}
		else if(old_sectype == 5)
		{
			if(confirm('$wpa_mixed_pop_message') == false)
                return false;
			cf.hidden_sec_type.value=5;
			cf.hidden_wpa_psk.value = get_wpas;
		}
		else
			cf.hidden_sec_type.value=1;
		
		cf.hidden_same_sec.value=1;
		cf.sec_wpaphrase_len.value=cf.hidden_wpa_psk.value.length;
		//WEP
		cf.hidden_sec_keylen.value = key_length;
		//cf.hidden_wepkeyno.value = 1;
		if(key_length == 5)
		{
			cf.hidden_wepkey1.value = wl_key1;
			cf.hidden_wepkey2.value = wl_key2;
			cf.hidden_wepkey3.value = wl_key3;
			cf.hidden_wepkey4.value = wl_key4;
		}
		else if(key_length == 13)
		{
            cf.hidden_wepkey1.value = wl_key1;
            cf.hidden_wepkey2.value = wl_key2;
            cf.hidden_wepkey3.value = wl_key3;
            cf.hidden_wepkey4.value = wl_key4;
		}
		//WEP END
		document.forms[0].hidden_wlan_ssid.value=getObj1("ESSID").value;
	}
	return true;	
}

function chgCh(from)
{   
	if (from == 2)
	{
		var cf = document.forms[0];
		setChannel();
	}
	else
	{
		setwlan_mode();
		setChannel();
	}
}

function setwlan_mode()
{
	var cf = document.forms[0];
	var index = cf.WRegion.selectedIndex;
	index=parseInt(index)+1;
	var currentMode = cf.opmode.selectedIndex;

	if (index == 7 || index == 8) {
		cf.opmode.options.length = 2;
		cf.opmode.options[0].text = wlan_mode_54;
		cf.opmode.options[1].text = wlan_mode_130;
		cf.opmode.options[0].value = "1";
		cf.opmode.options[1].value = "2";
		if (currentMode <= 1)
			cf.opmode.selectedIndex = currentMode;
		else
			cf.opmode.selectedIndex = 1;
	} else {
		cf.opmode.options.length = 3;
		cf.opmode.options[0].text = wlan_mode_54;
		cf.opmode.options[1].text = wlan_mode_130;
		cf.opmode.options[2].text = wlan_mode_300;
		cf.opmode.options[0].value = "1";
		cf.opmode.options[1].value = "2";
		cf.opmode.options[2].value = "3";
		cf.opmode.selectedIndex = currentMode;
	}
	return;
}

function setChannel()
{
	var cf = document.forms[0];
	var index = cf.WRegion.selectedIndex;
	index=parseInt(index)+1;
	var chIndex = cf.w_channel.selectedIndex;
	var currentMode = cf.opmode.selectedIndex;
	var endChannel;


		endChannel = FinishChannel[index];
	if (FinishChannel[index]==14 && cf.opmode.selectedIndex!=0)
		cf.w_channel.options.length = endChannel - StartChannel[index];
	else
		cf.w_channel.options.length = endChannel - StartChannel[index] + 2;

	cf.w_channel.options[0].text = "$auto_mark";
	cf.w_channel.options[0].value = 0;

	for (var i = StartChannel[index]; i <= endChannel; i++) {
		if (i==14 && cf.opmode.selectedIndex!=0)
			continue;
		cf.w_channel.options[i - StartChannel[index] + 1].value = i;
		cf.w_channel.options[i - StartChannel[index] + 1].text = (i < 10)? "0" + i : i;
	}
	cf.w_channel.selectedIndex = ((chIndex > -1) && (chIndex < cf.w_channel.options.length)) ? chIndex : 0 ;


	

}

function chgChA(from)
{   
	var cf = document.forms[0];
	if (from == 2)
	{
		setAChannel(cf.w_channel_an);
	}
	else
	{
		setAwlan_mode();
		setAChannel(cf.w_channel_an);
	}
}

function setAwlan_mode()
{
	var cf = document.forms[0];
	var index = cf.WRegion.selectedIndex;
	index=parseInt(index)+1;
	var currentMode = cf.opmode_an.selectedIndex;

	if (index == 6 || index == 10 ) {     //Israel, Middle East
		cf.opmode_an.options.length = 2;
		cf.opmode_an.options[0].text = wlan_mode_54;
		cf.opmode_an.options[1].text = wlan_mode_130;
		cf.opmode_an.options[0].value = "1";
		cf.opmode_an.options[1].value = "2";
		if (currentMode <= 1)
			cf.opmode_an.selectedIndex = currentMode;
		else
			cf.opmode_an.selectedIndex = 1;
		cf.w_channel_an.disabled=false;
		cf.opmode_an.disabled=false;			
	}

	else{
		cf.opmode_an.options.length = 3;
		cf.opmode_an.options[0].text = wlan_mode_54;
		cf.opmode_an.options[1].text = wlan_mode_130;
		cf.opmode_an.options[2].text = wlan_mode_300;
		cf.opmode_an.options[0].value = "1";
		cf.opmode_an.options[1].value = "2";
		cf.opmode_an.options[2].value = "3";
		cf.opmode_an.selectedIndex = currentMode;
		cf.w_channel_an.disabled=false;
		cf.opmode_an.disabled=false;		
	}
	return;
}
function setAChannel(channel)
{
	var cf = document.forms[0];
	var index = cf.WRegion.selectedIndex;
	index=parseInt(index)+1;
	var chIndex = channel.selectedIndex;
	var chValue = channel.options[chIndex].value;
	var currentMode = cf.opmode_an.selectedIndex;	
	var endChannel;
   if(dfs_channel_router_flag == 1){
	var AChannel = new Array(0, 36, 40, 44, 48, 52, 56, 60, 64, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 149, 153, 157, 161, 165);

	channel.options[0].text = "$auto_mark";
	channel.options[0].value = 0;	 
 	
	if( index == 8 )                //Korean
	{
		endChannel = 18; //19 channel, from 36 to 136
		channel.options.length = 24;
		for( i = 1; i<= endChannel; i++ )
		{
			channel.options[i].value = AChannel[i];
			channel.options[i].text = AChannel[i];
		}
		if( currentMode == 0 || currentMode == 1 )
		{
			channel.options[19].value = channel.options[19].text = 140;
			channel.options[20].value = channel.options[20].text = 149;
			channel.options[21].value = channel.options[21].text = 153;
			channel.options[22].value = channel.options[22].text = 157;
			channel.options[23].value = channel.options[23].text = 161;
		}
		else
		{
			channel.options.length = 23;
			channel.options[19].value = channel.options[19].text = 149;
			channel.options[20].value = channel.options[20].text = 153;
			channel.options[21].value = channel.options[21].text = 157;
			channel.options[22].value = channel.options[22].text = 161;
		}
	}
	else if( index == 2 )               //Asia
	{
		channel.options.length = 5;
		channel.options[1].value = channel.options[1].text = 149;
		channel.options[2].value = channel.options[2].text = 153;
		channel.options[3].value = channel.options[3].text = 157;
		channel.options[4].value = channel.options[4].text = 161;
		if( currentMode == 0 || currentMode == 1 )		//not 300Mbps
		{
			channel.options.length = 6;
			channel.options[5].value = channel.options[5].text = 165;		
		}	
	}
	else if( index == 1 || index == 3 || index == 4 || index == 9 || index == 11 || index == 12 )
	{//Africa,Australia, Canada, Mexico, South America,United States
		endChannel = 18; //19 channel, from 36 to 136
		channel.options.length = 25;
		for( i = 1; i<= endChannel; i++ )
		{
			channel.options[i].value = AChannel[i];
			channel.options[i].text = AChannel[i];
		}		
		if( currentMode == 0 || currentMode == 1 )
		{
			channel.options[19].value = channel.options[19].text = 140;
			channel.options[20].value = channel.options[20].text = 149;
			channel.options[21].value = channel.options[21].text = 153;
			channel.options[22].value = channel.options[22].text = 157;
			channel.options[23].value = channel.options[23].text = 161;
			channel.options[24].value = channel.options[24].text = 165;
		}
		else
		{
			channel.options.length = 23;
			channel.options[19].value = channel.options[19].text = 149;
			channel.options[20].value = channel.options[20].text = 153;
			channel.options[21].value = channel.options[21].text = 157;
			channel.options[22].value = channel.options[22].text = 161;
		}
	}
	else if( index == 5 || index == 7 ) //Europe, Japan
	{
		endChannel = 18; //19 channel, from 36 to 136
		channel.options.length = 19;
		for( i = 1; i<= endChannel; i++ )
		{
			channel.options[i].value = AChannel[i];
			channel.options[i].text = AChannel[i];
		}	
		if( currentMode != 2 )
		{
			channel.options.length = 20;
			channel.options[19].value = channel.options[19].text = 140;
		}
	}
	else if( index == 6 || index == 10 ) //Israel, Middle East
	{
		endChannel = 8; // Japan 9channel, from 36 to 64
		channel.options.length = 9;
		for( i = 1; i<= endChannel; i++ )
		{
			channel.options[i].value = AChannel[i];
			channel.options[i].text = AChannel[i];
		}
	}
   }
   else{	
	//      var AChannel = new Array(0, 36, 40, 44, 48, 149, 153, 157, 161, 165);
	var AChannel = new Array(36, 40, 44, 48, 149, 153, 157, 161, 165);

	var BChannel = new Array(36, 40, 44, 48, 52, 56, 60, 64, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 149, 153, 157, 161, 165);

	if( index == 12 || index == 3 || index == 4 || index == 9 || index == 11 )// 10->11 11->12 12->10
	{										   //middle east move up two line
		if( currentMode != 2 )
		{
			endChannel = 9;
			channel.options.length = 9;
		}
		else
		{
			endChannel = 8;
			channel.options.length = 8;
		}
		for( i = 0; i< endChannel; i++ )
		{
			channel.options[i].value = AChannel[i];
			channel.options[i].text = AChannel[i];
		}
	}
	else if( index == 8 )
	{
		endChannel = 8;
		channel.options.length = 8;
		
		for( i = 0; i< endChannel; i++ )
		{
			channel.options[i].value = AChannel[i];
			channel.options[i].text = AChannel[i];
		}
	}
        else if( index == 2 )               //Asia :090403 changed,and prevenient format is the same with 12,3,4,9,11
        {
                channel.options.length = 4;
                channel.options[0].value = channel.options[0].text = 149;
                channel.options[1].value = channel.options[1].text = 153;
                channel.options[2].value = channel.options[2].text = 157;
                channel.options[3].value = channel.options[3].text = 161;
                if( currentMode == 0 || currentMode == 1 )              //not 300Mbps
                {
                        channel.options.length = 5;
                        channel.options[4].value = channel.options[4].text = 165;
                }
        }
	else
	{
		endChannel = 4;
		channel.options.length = 4;
		for( i = 0; i< endChannel; i++ )
		{
			channel.options[i].value = AChannel[i];
			channel.options[i].text = AChannel[i];
		}
	
	}
	if(dfs_channel2_router_flag == 1)//bug 25665:DFS channel should be supported in Canada, Europe and Austrilia
		{
			if( index == 5 )
			{
				if( currentMode != 2 )
				{
					endChannel = 19;
					channel.options.length = 19;
					for( i = 0; i< 4; i++ )
					{
						channel.options[i].value = BChannel[i];
						channel.options[i].text = BChannel[i];
					}
					for( i = 4; i< endChannel; i++ )
					{
						channel.options[i].value = BChannel[i];
						channel.options[i].text = BChannel[i]+'(DFS)';
					}
				}
				else
				{	//bug 23934:modify the channel selection in HT40 mode
					channel.options.length = 9;
					channel.options[0].value = 36;
					channel.options[0].text = '36+40';
					channel.options[1].value = 44;
					channel.options[1].text = '44+48';
					channel.options[2].value = 52;
					channel.options[2].text = '52+56(DFS)';
					channel.options[3].value = 60;
					channel.options[3].text = '60+64(DFS)';
					channel.options[4].value = 100;
					channel.options[4].text = '100+104(DFS)';
					channel.options[5].value = 108;
					channel.options[5].text = '108+112(DFS)';
					channel.options[6].value = 116;
					channel.options[6].text = '116+120(DFS)';
					channel.options[7].value = 124;
					channel.options[7].text = '124+128(DFS)';
					channel.options[8].value = 132;
					channel.options[8].text = '132+136(DFS)';
				}
				
			}

			else if(index == 3)//bug 23853:NETGEAR correct the DFS channel list for Austrilia
			{				
				if( currentMode != 2 )
				{
					endChannel = 12;
					channel.options.length = 20;
					for( i = 0; i< 4; i++ )
					{
						channel.options[i].value = BChannel[i];
						channel.options[i].text = BChannel[i];
					}
					for( i = 4; i< endChannel; i++ )
					{
						channel.options[i].value = BChannel[i];
						channel.options[i].text = BChannel[i]+'(DFS)';
					}
					channel.options[12].value = 116;
					channel.options[13].value = 136;
					channel.options[14].value = 140;
					channel.options[12].text = 116+'(DFS)';
					channel.options[13].text = 136+'(DFS)';
					channel.options[14].text = 140+'(DFS)';
					channel.options[15].value = channel.options[15].text = 149;
					channel.options[16].value = channel.options[16].text = 153;
					channel.options[17].value = channel.options[17].text = 157;
					channel.options[18].value = channel.options[18].text = 161;
					channel.options[19].value = channel.options[19].text = 165;
				}
				else
				{
					channel.options.length = 9;
					channel.options[0].value = 36;
					channel.options[0].text = '36+40';
					channel.options[1].value = 44;
					channel.options[1].text = '44+48';
					channel.options[2].value = 52;
					channel.options[2].text = '52+56(DFS)';
					channel.options[3].value = 60;
					channel.options[3].text = '60+64(DFS)';
					channel.options[4].value = 100;
					channel.options[4].text = '100+104(DFS)';
					channel.options[5].value = 108;
					channel.options[5].text = '108+112(DFS)';
					channel.options[6].value = 132;
					channel.options[6].text = '132+136(DFS)';
					channel.options[7].value = 149;
					channel.options[7].text = '149+153';
					channel.options[8].value = 157;
					channel.options[8].text = '157+161';
				}
			}
		}
   }	
	channel.selectedIndex = ((chIndex > -1) && (chIndex < channel.options.length)) && ( chValue == channel.value )? chIndex : 0 ;	
}
function checkpskw(passphrase, passphrase_len)
{
	var len = passphrase.value.length;
	if ( len == 64 )
	{
		for(i=0;i<len;i++)
		{
			if(isValidHex(passphrase.value.charAt(i))==false)
			{
				alert(notallowpassps);
				return false;
			}
		}
	}
	else
	{
		if(len < 8 )
		{
	        	alert(passphrase_short8);
		        return false;
		} 
		if(len > 63){
			alert(passphrase_long63);
			return false;
		}
		for(i=0;i<passphrase.value.length;i++)
		{
			if(isValidChar_space(passphrase.value.charCodeAt(i))==false)
			{
				alert(notallowpassps);
				return false;
			}
		}
	}
	passphrase_len.value=len;
	return true;
}

function wizard_exit()
{
	//if(wizard_configure == "1")
	//check ssid
	window.onbeforeunload = null;
	if(current_ssid != default_ssid)
	{
		top.location.href="spbu_no_hijack_close.htm";
	}
	else
	{
		alert(SPBU_34);
		//window.open('','_top','');   
        //top.window.close(); 
		//if the browser doesn't support window.close, we direct page to logout page
		top.location.href="LGO_logout_spbu.htm";
	}
}

function confirm_spbu()
{
	window.onbeforeunload = function (){
		return SPBU_31;
	}

	//check ssid
	var ssid_bgn = document.forms[0].ssid.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
	if(ssid_bgn == "")
	{
		alert(ssid_null);
		return false;
	}
	
	for(i=0;i<ssid_bgn.length;i++)
	{
		if(isValidChar_space(ssid_bgn.charCodeAt(i))==false)
		{
			alert(ssid_not_allowed);
			return false;
		}
	}
	
	//check passphrase
	if(document.forms[0].security_type[3].checked == true || document.forms[0].security_type[4].checked == true)
	{
		if( checkpskw(document.forms[0].passphrase, document.forms[0].wl_sec_wpaphrase_len)== false)
			return false;
	}
	
	//
	ssid_conf = document.forms[0].ssid.value;
	var f_head="<font size=3 color=#66cc00>";
	var f_tail="</font>";
	var ssid_conf_inner=f_head+ssid_conf+f_tail;
	//getObj("view_ssid").innerHTML=ssid_conf;
	getObj("view_ssid").innerHTML=ssid_conf_inner;
	
	//check the ssid has been change or not by user
	if(ssid_conf == default_ssid)
	{	
		alert(SPBU_33);
		return false;
	}
	
	if(document.forms[0].security_type[0].checked == true)
		passphrase_conf = "";
	else if(document.forms[0].security_type[1].checked == true)
	{	
		passphrase_conf = document.forms[0].passphrase.value;
		document.getElementById("wpa2").style.display="none";
	}
	else
	{	
		passphrase_conf = document.forms[0].passphrase.value;
		document.getElementById("wpas").style.display="none";
	}
	
	//getObj("view_passphrase").innerHTML=passphrase_conf;
	var passphrase_conf_inner=f_head+passphrase_conf+f_tail;
	getObj("view_passphrase").innerHTML=passphrase_conf_inner;
	
	var btn = document.getElementById("btn_div_back");	
	var btn_text = document.createTextNode(SPBU_5_bh_back_mark);
	btn.appendChild(btn_text);
	
	var btn_2 = document.getElementById("btn_div_apply");	
	var btn_text_2 = document.createTextNode(SPBU_6_bh_apply_mark);
	btn_2.appendChild(btn_text_2);
	
	var btns_container_div_back = document.getElementById("btnsContainer_div_back");
	btns_container_div_back.onclick = function() 
	{
		window.onbeforeunload = null;
		location.href="wiz_WLG_wireless_spbu.htm";
	}
	
	var btns_container_div_apply = document.getElementById("btnsContainer_div_apply");
	btns_container_div_apply.onclick = function() 
	{
		if( check_wlan())
			document.forms[0].submit();
	}
	
	document.getElementById("setup_1").style.display="none";
	document.getElementById("buttons_div_adv").style.display="none";
	document.getElementById("page_title_g").style.display="none";
	document.getElementById("setting").style.display="none";
	document.getElementById("ssid").style.display="none";
	document.getElementById("security_type_1").style.display="none";
	document.getElementById("security_type_2").style.display="none";
	document.getElementById("security_type_3").style.display="none";
	document.getElementById("view").style.display="none";
	document.getElementById("buttons_div_02").style.display="none";
	
	document.getElementById("setup_2").style.display="";
	document.getElementById("page_title_g_confirm_1").style.display="";
	document.getElementById("page_title_g_confirm_2").style.display="";
	document.getElementById("confirm").style.display="";
	document.getElementById("confirm_before").style.display="";
	document.getElementById("buttons_div_back").style.display="";
	
	if(document.forms[0].security_type[0].checked == true)
	{	
		var warning = document.getElementById("btn_div_warning");	
		var warning_text = document.createTextNode(SPBU_7);
		warning.appendChild(warning_text);
		document.getElementById("security_warning").style.display="";
		document.getElementById("confirm_before").style.display="none";
		document.getElementById("confirm_after").style.display="";
	}
}

/*function check_security_type()
{
	var warning = document.getElementById("btn_div_warning");	
	var warning_text = document.createTextNode(SPBU_7);
	warning.appendChild(warning_text);
	document.getElementById("security_warning").style.display="";
	document.getElementById("confirm_before").style.display="none";
	document.getElementById("confirm_after").style.display="";
		
	var btns_container_div_apply = document.getElementById("btnsContainer_div_apply");
	btns_container_div_apply.onclick = function() 
	{
		if( check_wlan())
			document.forms[0].submit();
	}
}*/

function check_wlan()
{
	if( check_dfs() == false)
	{
		return false;
	}

	var cf=document.forms[0];
	var ssid_bgn = document.forms[0].ssid.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
	//var space_flag=0;
	var haven_wpe=0;

	var wla1_ssid=document.forms[0].wla1ssid.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
	var wlg1_ssid=document.forms[0].wlg1ssid.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
	
	if( wps_progress_status == "2" || wps_progress_status == "3" || wps_progress_status == "start" )
	{
		alert(wps_in_progress);
		return false;
	}

	if(ssid_bgn == "")
	{
		alert(ssid_null);
		return false;
	}
	
	if(ssid_bgn == wlg1_ssid)
	{
		alert(ssid_not_allowed_same);
		return false;
	}
	
	for(i=0;i<ssid_bgn.length;i++)
	{
		if(isValidChar_space(ssid_bgn.charCodeAt(i))==false)
		{
			alert(ssid_not_allowed);
			return false;
		}
	}
	
	cf.wl_ssid.value = ssid_bgn;
	
	if(cf.enable_isolation.checked == true)
		cf.wl_endis_wireless_isolation.value="1";
	else
		cf.wl_endis_wireless_isolation.value="0";

	//16400
	if(cf.ssid_bc.checked == true)
		cf.wl_enable_ssid_broadcast.value="1";
	else
		cf.wl_enable_ssid_broadcast.value="0";


/*
	if( v_model_type != "ALARM")	
	{	if( cf.ssid_bc.checked == false )
		{
			if (confirm(SWSW11) == false )
				return false;
		}
	}
*/
	if(module_type != "spbu")
	{
		if( cf.security_type[0].checked == true    )
		{
			if (confirm(SWSW12) == false )
				return false;
		}
		
		if( cf.security_type[1].checked == true || cf.security_type[2].checked == true   )
		{
			if (confirm(SWSW02) == false )
				return false;
		}
	}	

	cf.opmode_bg.value=cf.opmode.value;
	cf.wl_WRegion.value = cf.WRegion.value;
	if ( wds_endis_fun == 1 )
	{
		if ( cf.w_channel.selectedIndex == 0 )
		{
			alert(wds_auto_channel);
			return false;
		}
	}
	cf.wl_hidden_wlan_channel.value = cf.w_channel.value;

	if(cf.security_type[1].checked == true)
	{
		if( checkwep(cf)== false)
			return false;
		cf.wl_hidden_sec_type.value=2;
		for(i=0;i<cf.passphraseStr.value.length;i++)
		{
			if(isValidChar_space(cf.passphraseStr.value.charCodeAt(i))==false)
			{
				alert(notallowpassp);
				return false;
			}
		}
	}
	else if(cf.security_type[2].checked == true)
	{
		if( checkpskw(cf.passphrase, cf.wl_sec_wpaphrase_len)== false)
			return false;
		cf.wl_hidden_sec_type.value=3;
		cf.wl_hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}
	else if(cf.security_type[3].checked == true)
	{
		if( checkpskw(cf.passphrase, cf.wl_sec_wpaphrase_len)== false)
			return false;
		cf.wl_hidden_sec_type.value=4;
		cf.wl_hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}	
	else if(cf.security_type[4].checked == true)
	{
		if( checkpskw(cf.passphrase, cf.wl_sec_wpaphrase_len)== false)
			return false;
		cf.wl_hidden_sec_type.value=5;
		cf.wl_hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}	
	
	else
		cf.wl_hidden_sec_type.value=1;


	//When user selects WPA-PSK(TKIP)+150Mbps and WPA-PSK(TKIP)+300Mbps, set wl_simple_mode=1,Bug No.19591
	//or select "WPA-PSK [TKIP] + WPA2-PSK [AES]"+150Mbps and "WPA-PSK [TKIP] + WPA2-PSK [AES]"+300Mbps 
	if((cf.opmode.value=="2") || (cf.opmode.value=="3"))
	{
	    if(cf.security_type[1].checked == true || cf.security_type[2].checked == true)
		{
			//if(confirm("$wlan_tkip_300_150") == false)
			//{
			//	return false;
			//}

			cf.wl_hidden_wlan_mode.value = "1"; //save for wl_simple_mode

		}
		else if(cf.security_type[3].checked == true)
		{
			if(guest_mode_flag == 1)
			{
				if(confirm(guest_tkip_300_150) == false)
				{
					return false;
				}
				cf.wl_hidden_wlan_mode.value = "1"; 
			}
			else if(guest_mode_flag == 2)
			{
				if(confirm(guest_tkip_aes_300_150) == false)
				{
					return false;	
				}		
				cf.wl_hidden_wlan_mode.value = cf.opmode.value;	
			}
			else
				cf.wl_hidden_wlan_mode.value = cf.opmode.value;	
		}
		else if(cf.security_type[4].checked == true)
		{
			if(confirm(wlan_tkip_aes_300_150) == false)
			{
				return false;	
			}
			
			cf.wl_hidden_wlan_mode.value = cf.opmode.value;
		}

		else
		{
			if(guest_mode_flag == 1)
			{
				if(confirm(guest_tkip_300_150) == false)
				{
					return false;
				}
				cf.wl_hidden_wlan_mode.value = "1";
			}
			else
				cf.wl_hidden_wlan_mode.value = cf.opmode.value;
		}
	}
	else
	{
		cf.wl_hidden_wlan_mode.value = cf.opmode.value;
	}

	var flad_op = false;
	if(parent.mode_is_300 == 1 && wl_disablecoext != 1 && (cf.opmode.value!="1") && (cf.opmode.value!="2"))
	{
	    flad_op = true;
	     alert(msg);
	}
	
	cf.wl_mode.value = cf.opmode.value;
	var haven_alert = '0';
	if(cf.security_type[1].checked == true)
	{
        	if ( cf.authAlgm.value == 1 && endis_wl_radio == 1)
        	{
			cf.hidden_endis_wl_wps.value=0;
			cf.hidden_endis_wla_wps.value=0;
			haven_alert = '1';
                	if (!confirm(wep_or_wps))
	                	return false;
        	}
		
		if(an_router_flag == 1)	
			alert(wep_just_one_ssid+"(2.4GHz/5GHz)");
		else if(guest_router_flag == 1)
			alert(wep_just_one_ssid);
	}		


	
	if(an_router_flag == 1)
	{		
		var ssid_an = document.forms[0].ssid_an.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
		if( ssid_an == "")
		{
			alert(ssid_null);
			return false;
		}
		if(ssid_bgn == wlg1_ssid || ssid_bgn == wla1_ssid || ssid_an == wlg1_ssid || ssid_an == wla1_ssid)
		{
			alert(ssid_not_allowed_same);
			return false;
		}
		for(i=0;i<ssid_an.length;i++)
		{
			if(isValidChar_space(ssid_an.charCodeAt(i))==false)
			{
				alert(ssid_not_allowed);
				return false;
			}
		}

		
		cf.wla_ssid.value = ssid_an;

		//16400
		if(cf.ssid_bc_an.checked == true)
			cf.wla_enable_ssid_broadcast.value="1";
		else
			cf.wla_enable_ssid_broadcast.value="0";
		if(cf.enable_isolation_an.checked == true)
			cf.wla_endis_wireless_isolation.value="1";
		else
			cf.wla_endis_wireless_isolation.value="0";
		if(cf.enable_video.checked == true)
			cf.hidden_enable_video.value=1;
		else
			cf.hidden_enable_video.value=0;	
/*
		if ( wla_wds_endis_fun == 1 )
		{
			if ( cf.w_channel_an.selectedIndex == 0 )
			{
				alert("$wds_auto_channel");
				return false;
			}
		}	
*/
		cf.wla_hidden_wlan_channel.value = cf.w_channel_an.value;
			
		//for a/n
		if(cf.security_type_an[1].checked == true)
		{
			if( checkwep_a(cf)== false)
				return false;
			cf.wla_hidden_sec_type.value=2;
	                for(i=0;i<cf.passphraseStr_an.value.length;i++)
	                {
	                        if(isValidChar_space(cf.passphraseStr_an.value.charCodeAt(i))==false)
	                        {
	                                alert(notallowpassp);
	                                return false;
	                        }
	                }
		}
		else if(cf.security_type_an[2].checked == true)
		{
			if( checkpskw(cf.passphrase_an, cf.wla_sec_wpaphrase_len)== false)
				return false;
			cf.wla_hidden_sec_type.value=3;
			cf.wla_hidden_wpa_psk.value = cf.passphrase_an.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
		}
		else if(cf.security_type_an[3].checked == true)
		{
			if( checkpskw(cf.passphrase_an, cf.wla_sec_wpaphrase_len)== false)
				return false;
			cf.wla_hidden_sec_type.value=4;
			cf.wla_hidden_wpa_psk.value = cf.passphrase_an.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
		}	
		else if(cf.security_type_an[4].checked == true)
		{
			if( checkpskw(cf.passphrase_an, cf.wla_sec_wpaphrase_len)== false)
				return false;
			cf.wla_hidden_sec_type.value=5;
			cf.wla_hidden_wpa_psk.value = cf.passphrase_an.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
		}	

		else
			cf.wla_hidden_sec_type.value=1;

		//5GHz a/n : When user selects WPA-PSK(TKIP)+150Mbps and WPA-PSK(TKIP)+300Mbps, set wl_simple_mode=1,Bug No.19591
		//or select "WPA-PSK [TKIP] + WPA2-PSK [AES]"+150Mbps and "WPA-PSK [TKIP] + WPA2-PSK [AES]"+300Mbps 
		if((cf.opmode_an.value=="2") || (cf.opmode_an.value=="3"))
		{
			if(cf.security_type_an[1].checked == true)
				cf.wla_hidden_wlan_mode.value = "1"; //save for wla_simple_mode
			else if(cf.security_type_an[2].checked == true)
			{
				//if(confirm("$wlan_tkip_300_150") == false)
				//{
					//return false;
				//}

				cf.wla_hidden_wlan_mode.value = "1"; //save for wla_simple_mode
			}
			else if(cf.security_type_an[3].checked == true)
			{
				if(wla_guest_mode_flag == 1)
				{
					if(confirm(guest_tkip_300_150) == false)
					{
						return false;
					}
					cf.wla_hidden_wlan_mode.value = "1"; 
				}
				else if(wla_guest_mode_flag == 2)
				{
					if(confirm(guest_tkip_aes_300_150) == false)
					{
						return false;	
					}	
					cf.wla_hidden_wlan_mode.value = cf.opmode_an.value;	
				}
				else
					cf.wla_hidden_wlan_mode.value = cf.opmode_an.value;	
			}
			else if(cf.security_type_an[4].checked == true)
			{
				if(confirm(wlan_tkip_aes_300_150) == false)
				{
					return false;	
				}
			
				cf.wla_hidden_wlan_mode.value = cf.opmode_an.value;
			}
	
			else
			{
				if(wla_guest_mode_flag == 1)
				{
					if(confirm(guest_tkip_300_150) == false)
					{
						return false;
					}
					cf.wla_hidden_wlan_mode.value = "1";
				}
				else
					cf.wla_hidden_wlan_mode.value = cf.opmode_an.value;
			}
		}
		else
		{
			cf.wla_hidden_wlan_mode.value = cf.opmode_an.value;
		}
		
		
	if(parent.mode_is_300 == 1 && wl_disablecoext != 1 && (cf.opmode_an.value!="1") && (cf.opmode_an.value!="2"))
	{
	   if(flad_op != true)
	     alert(msg);
	
	}
	
		
		countryIndex=cf.WRegion.value;
		//if( (countryIndex == 6 || countryIndex == 12) && !confirm("$notSupportWLA") )
		if( (countryIndex == 5 || countryIndex == 11) && !confirm(notSupportWLA) )
			return false;

		//cf.wla_hidden_wlan_mode.value = cf.opmode_an.value;
		
		if(cf.security_type_an[1].checked == true && endis_wla_radio == 1)
		{
		        if ( cf.authAlgm_an.value == 1)
	                {
				cf.hidden_endis_wl_wps.value=0;
				cf.hidden_endis_wla_wps.value=0;
				if(haven_alert == '0')
	                        	if (!confirm(wep_or_wps))
	                                	return false;
	                }
		
			if(cf.security_type[1].checked == false)
				alert(wep_just_one_ssid+"(2.4GHz/5GHz)");
	        }
		var channel_a=cf.w_channel_an.value;
		var country=cf.wl_WRegion.value;
		//transmit power control, according to the change of country, change values of wl_txctrl and wla_txctrl.
		//wlan_txctrl(cf, wl_txctrl_web, wla_txctrl_web, channel_a, country);

	}
	
	window.onbeforeunload = null;
	return true;	
}

function check_wlan_guest(type)
{
	var cf=document.forms[0];
	var ssid = document.forms[0].gssid.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
	var ssid_an = document.forms[0].ssid_an.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
	//var space_flag=0;
	cf.s_gssid.value=ssid;
	cf.s_gssid_an.value=ssid_an;
	var wl_ssid=document.forms[0].wlssid.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
	var wla_ssid=document.forms[0].wlassid.value.replace(/\\/g,"\\\\\\\\").replace(/`/g,"\\\\\\`").replace(/"/g,"\\\"");
	if(ssid == "")
	{
		alert("$ssid_null");
		return false;
	}
	if(ssid_an == "")
	{
		alert("$ssid_null");
		return false;
	}
        if(ssid == wl_ssid || ssid == wla_ssid)
        {
                alert("$ssid_not_allowed_same");
                return false;
        }
		if(ssid_an == wl_ssid || ssid_an == wla_ssid)
        {
                alert("$ssid_not_allowed_same");
                return false;
        }
	for(i=0;i<ssid.length;i++)
	{
		if(isValidChar_space(ssid.charCodeAt(i))==false)
		{
			alert(ssid + "$ssid_not_allowed");
			return false;
		}
	}
	for(i=0;i<ssid_an.length;i++)
	{
		if(isValidChar_space(ssid_an.charCodeAt(i))==false)
		{
			alert(ssid_an + "$ssid_not_allowed");
			return false;
		}
	}


	if(cf.enable_bssid.checked == true)
		cf.hidden_enable_guestNet.value=1;
	else
		cf.hidden_enable_guestNet.value=0;
	if(cf.enable_bssid_an.checked == true)
		cf.hidden_enable_guestNet_an.value=1;
	else
		cf.hidden_enable_guestNet_an.value=0;
		
	if(cf.enable_ssid_bc.checked == true)
		cf.hidden_enable_ssidbro.value=1;
	else
		cf.hidden_enable_ssidbro.value=0;
	if(cf.enable_ssid_bc_an.checked == true)
		cf.hidden_enable_ssidbro_an.value=1;
	else
		cf.hidden_enable_ssidbro_an.value=0;
		
	if(cf.enable_video_an.checked == true)
		cf.hidden_enable_video_an.value=1;
	else
		cf.hidden_enable_video_an.value=0;
	if(cf.enable_isolation_an.checked == true)
		cf.wla_guest_endis_wireless_isolation.value="1";
	else
		cf.wla_guest_endis_wireless_isolation.value="0";
	
	if(cf.enable_isolate.checked == true)
		cf.wlg_guest_endis_wireless_isolation.value="1";
	else
		cf.wlg_guest_endis_wireless_isolation.value="0";

	if(cf.allow_access.checked == true)
		cf.hidden_allow_guest.value=1;
	else
		cf.hidden_allow_guest.value=0;
	if(cf.allow_access_an.checked == true)
		cf.hidden_allow_guest_an.value=1;
	else
		cf.hidden_allow_guest_an.value=0;
	
	cf.wl_hidden_wlan_mode.value = wl_simple_mode;
	cf.wl_hidden_wlan_mode_an.value = wl_simple_mode_an;
	
	if(cf.security_type[1].checked == true)
	{
		cf.hidden_guest_network_mode_flag.value=0;
		cf.wl_hidden_wlan_mode.value = "1";
		if( checkwep(cf)== false)
			return false;
		cf.hidden_sec_type.value=2;
		for(i=0;i<cf.passphraseStr.value.length;i++)
		{
			if(isValidChar_space(cf.passphraseStr.value.charCodeAt(i))==false)
			{
				alert("$notallowpassp");
				return false;
			}
		}

		//if(parent.an_router_flag == 1)
			//alert("$wep_just_one_ssid"+"(2.4GHz/5GHz)");
		//else
			alert("$wep_just_one_ssid");
	}
	else if(cf.security_type[2].checked == true)
	{
		if( checkpsk(cf.passphrase, cf.sec_wpaphrase_len)== false)
			return false;


		cf.hidden_guest_network_mode_flag.value=1;
		cf.wl_hidden_wlan_mode.value = "1";

		cf.hidden_sec_type.value=3;
		cf.hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}
	else if(cf.security_type[3].checked == true)
	{
		cf.hidden_guest_network_mode_flag.value=0;
		if( checkpsk(cf.passphrase, cf.sec_wpaphrase_len)== false)
			return false;
		cf.hidden_sec_type.value=4;
		cf.hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}	
	else if(cf.security_type[4].checked == true)
	{
		if( checkpsk(cf.passphrase, cf.sec_wpaphrase_len)== false)
			return false;
		
		if(wl_simple_mode != "1")
        {
			if(confirm("$wlan_tkip_aes_300_150") == false)
			{
				cf.hidden_guest_network_mode_flag.value=0;
				return false;
			}
		}
		cf.hidden_guest_network_mode_flag.value=2;
		cf.wl_hidden_wlan_mode.value = wl_simple_mode;

		cf.hidden_sec_type.value=5;
		cf.hidden_wpa_psk.value = cf.passphrase.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}	

	else
		cf.hidden_sec_type.value=1;
		
	if(cf.security_type_an[1].checked == true)
	{
		cf.hidden_guest_network_mode_flag_an.value=0;
		cf.wl_hidden_wlan_mode_an.value = "1";
		if( checkwep_a(cf)== false)
			return false;
		cf.hidden_sec_type_an.value=2;
		for(i=0;i<cf.passphraseStr_an.value.length;i++)
		{
			if(isValidChar_space(cf.passphraseStr_an.value.charCodeAt(i))==false)
			{
				alert("$notallowpassp");
				return false;
			}
		}

		//if(parent.an_router_flag == 1)
			alert("$wep_just_one_ssid"+"(2.4GHz/5GHz)");
		//else
			//alert("$wep_just_one_ssid");
	}
	else if(cf.security_type_an[2].checked == true)
	{
		if( checkpsk(cf.passphrase_an, cf.sec_wpaphrase_len_an)== false)
			return false;

	
		cf.hidden_guest_network_mode_flag_an.value=1;
		cf.wl_hidden_wlan_mode_an.value = "1";

		cf.hidden_sec_type_an.value=3;
		cf.hidden_wpa_psk_an.value = cf.passphrase_an.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}
	else if(cf.security_type_an[3].checked == true)
	{
		cf.hidden_guest_network_mode_flag_an.value=0;
		if( checkpsk(cf.passphrase_an, cf.sec_wpaphrase_len_an)== false)
			return false;
		cf.hidden_sec_type_an.value=4;
		cf.hidden_wpa_psk_an.value = cf.passphrase_an.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}	
	else if(cf.security_type_an[4].checked == true)
	{
		if( checkpsk(cf.passphrase_an, cf.sec_wpaphrase_len_an)== false)
			return false;
		
		if(wl_simple_mode_an != "1")
        {
			if(confirm("$wlan_tkip_aes_300_150") == false)
			{
				cf.hidden_guest_network_mode_flag_an.value=0;
				return false;
			}
		}
		cf.hidden_guest_network_mode_flag_an.value=2;
		cf.wl_hidden_wlan_mode_an.value = wl_simple_mode_an;

		cf.hidden_sec_type_an.value=5;
		cf.hidden_wpa_psk_an.value = cf.passphrase_an.value.replace(/\\/g,"\\\\").replace(/`/g,"\\`").replace(/"/g,"\\\"");
	}	

	return true;
}
