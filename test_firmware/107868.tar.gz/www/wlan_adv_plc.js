function checkadv(form)
{
	if(form.enable_power_saving.selectedIndex == "0")
		form.wl_enable_power_saving.value = "1";
	else if(form.enable_power_saving.selectedIndex == "1")
                form.wl_enable_power_saving.value = "0";				
				
	if(form.enable_LED.selectedIndex == "0")
		form.wl_enable_LED.value = "on";
	else if(form.enable_LED.selectedIndex == "1")
                form.wl_enable_LED.value = "off";
		
	//transmit power control
	//wlan_txctrl(form, form.tx_power_ctrl.value, form.tx_power_ctrl_an.value, wla_channel, country);

	form.submit();
	//return true;
}
