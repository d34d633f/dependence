function initIndex()
{
	var page_body = document.getElementsByTagName("body");
	
	page_body.onload = loadValue();

	changeUrl();
}

function loadValue()
{	
	var content_frame = document.getElementById("content_frame");
	
	if( module_type ==  "spbu" && blank_state == "0")
		content_frame.setAttribute("src", "BRS_01_checkNet_ping_spbu.html");
	else if( module_type ==  "spbu" && blank_state == "1")
		content_frame.setAttribute("src", "wiz_WLG_wireless_spbu.htm");
	else
	{
		if( goto_check_internet ==  "1" )
			content_frame.setAttribute("src", "BRS_01_checkNet_ping.html");
		else
			content_frame.setAttribute("src", "wiz_start.html");
	}
	
//	showFirmVersion("none");
}

function changeUrl()
{
	if((dns_hijack == "1") && (this.location.hostname != lanip && this.location.hostname.indexOf("mywifiext.net") == -1 && this.location.hostname.indexOf("mywifiext.com") == -1))
		this.location.hostname = lanip;
}

addLoadEvent(initIndex);
