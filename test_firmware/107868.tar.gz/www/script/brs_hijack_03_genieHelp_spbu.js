function initPage()
{
	var head_tag  = document.getElementsByTagName("h1");
	
	var connect_text = document.createTextNode(SWP005);
	head_tag[0].appendChild(connect_text);
	
	var paragraph = document.getElementById("message_1");
	var paragraph_text;

	paragraph_text = document.createTextNode(SPBU_13);
	paragraph.appendChild(paragraph_text);
	
	var paragraph_2 = document.getElementById("message_2");
	var paragraph_text_2;

	paragraph_text_2 = document.createTextNode(SPBU_14);
	paragraph_2.appendChild(paragraph_text_2);
	
	var paragraph_3 = document.getElementById("message_3");
	var paragraph_text_3;

	paragraph_text_3 = document.createTextNode(SPBU_15);
	paragraph_3.appendChild(paragraph_text_3);
	
	var paragraph_4 = document.getElementById("message_4");
	var paragraph_text_4;

	paragraph_text_4 = document.createTextNode(SPBU_16);
	paragraph_4.appendChild(paragraph_text_4);
	
	var choices_div = document.getElementById("choices_div");
	var choices = choices_div.getElementsByTagName("input");
	
	var choices_text = document.createTextNode(bh_yes_mark);
	insertAfter(choices_text, choices[0]);
	
	choices_text = document.createTextNode(bh_have_saved_copy);
	insertAfter(choices_text, choices[2]);
	
	
}

addLoadEvent(initPage);
