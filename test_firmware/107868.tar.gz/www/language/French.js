//BRS_01_checkNet.html

var wiz_start_genie_re="Oui.";
var bh_config_wireless_setting="Configuration des paramètres sans fil";
var genie_wireless_set_info="NETGEAR genie a détecté un réseau sans fil existant.";
var select_choice="Sélectionnez les paramètres sans fil de votre choix pour ce périphérique :";
var use_router_setting="Utilisation des paramètres identiques à mon réseau sans fil existant. Cette option est recommandée.";
var use_manual_setting="Configuration d'un nouveau réseau sans fil. Je comprends qu'un périphérique sans fil doit être connecté manuellement à ce nouveau réseau.";
var SWP0011="Confirmation :";
var SWP0012="Confirmez les paramètres sans fil, puis cliquez sur le bouton Suivant. Vous êtes actuellement connecté via une connexion sans fil. Après avoir cliqué sur Suivant, la connexion sans fil sera interrompue, reconnectez-vous en utilisant les nouveaux paramètres, puis continuez l'installation.";
var range_ext="Nouveaux paramètres du périphérique :";
var SWP005="Aucune connexion Internet détectée";
var network_checking="Vérification de la connexion réseau...";
var wireless_net_det="Réseau sans fil existant détecté";
var quit="Quitter";
var bh_try_again="Réessayer";
var no_device_det_1 ="NETGEAR genie ne parvient pas à obtenir les informations du réseau sans fil existant.";
var no_device_det_2 ="Souhaitez-vous que l'assistant NETGEAR genie vérifie de nouveau ?";
var wiz_start_manual="Non. Je souhaite configurer les paramètres sans fil moi-même.";
var LPC028="Vérifiez la connexion Internet de votre routeur.";
var sec_phr_g="Mot de passe sans fil";
var h_wlan="<body bgColor=#0099cc><P><font size=\"4\"><B>Aide Param&egrave;tres du r&eacute;seau sans fil</B></font></p> <p></p><p><b>REMARQUE&nbsp;:</b> pour assurer la conformit&eacute; et la compatibilit&eacute; des produits similaires se trouvant dans votre zone, vous devez configurer correctement le canal et la r&eacute;gion de fonctionnement. </p><p>Positionnement du peripherique pour optimiser la connectivit&eacute; sans fil </p><p>La distance de fonctionnement ou la port&eacute;e de votre connexion sans fil peuvent varier consid&eacute;rablement en fonction de l'endroit o&ugrave; se trouve le peripherique. Pour de meilleurs r&eacute;sultats, placez votre peripherique&nbsp;: </p><ul><li> Pr&egrave;s du centre de l'espace o&ugrave; seront plac&eacute;s vos ordinateurs, </li><li> Dans un espace sur&eacute;lev&eacute;, tel que des &eacute;tag&egrave;res hautes, </li><li> Loin de sources d'interf&eacute;rence, telles que les ordinateurs, les micro-ondes et les t&eacute;l&eacute;phones sans fil, </li><li> Avec l'antenne correctement orient&eacute;e vers le haut, </li><li> Loin des surfaces m&eacute;talliques de grande taille. </li></ul><p></p><p><b>Remarque&nbsp;:</b> si vous ne respectez pas ces instructions, la qualit&eacute; de transmission peut se d&eacute;t&eacute;riorer consid&eacute;rablement ou il peut devenir impossible d'&eacute;tablir une connexion sans fil au peripherique.</p><hr><a name=\"network\"></a><p><b>R&eacute;seau sans fil</b></p><p>Nom (SSID) </p><p> Saisissez une valeur comprenant jusqu'&agrave; 32&nbsp;caract&egrave;res alphanum&eacute;riques. Tous les appareils sans fil de votre r&eacute;seau doivent utiliser le m&ecirc;me nom (SSID). Le SSID par d&eacute;faut est Netgear_EXT, mais NETGEAR vous conseille fortement de modifier votre nom de r&eacute;seau sans fil (SSID). Cette valeur est &eacute;galement sensible &agrave; la casse. Par exemple, <i>NETGEAR</i> n'est pas la m&ecirc;me chose que <i>netgear.</i> </p><p> R&eacute;gion </p><p> S&eacute;lectionnez votre r&eacute;gion dans la liste d&eacute;roulante. Ce champ correspond &agrave; la r&eacute;gion de fonctionnement &agrave; laquelle l'interface sans fil est destin&eacute;e. L'utilisation du peripherique dans une autre r&eacute;gion que celle indiqu&eacute;e ici peut &ecirc;tre interdite par la loi. Si votre pays ou r&eacute;gion n'est pas dans la liste, veuillez v&eacute;rifier avec l'administration locale ou visitez notre site Internet pour obtenir plus d'informations sur les canaux &agrave; utiliser. </p><p> Canal </p><p>Ce champ d&eacute;termine la fr&eacute;quence de fonctionnement qui sera utilis&eacute;e. Aucune modification du canal sans fil ne devrait &ecirc;tre requise, sauf en cas d'interf&eacute;rences avec un autre point d'acc&egrave;s se trouvant &agrave; proximit&eacute;.</p><p><P>Mode</P>Selectionnez le mode sans fil que vous souhaitez utiliser. Les options disponibles sont:<UL><LI>Jusqu'a 54 Mbits/s. Mode Legacy, avec une vitesse maximum de 54 Mbits/s pour les reseaux b/g.<LI>Jusqu'a 130 Mbits/s. Mode Neighbor-Friendly par defaut, avec une vitesse maximum de 130 Mbits/s pour les reseaux sans fils voisins.<LI>Jusqu'a 300 Mbits/s. Mode Performance, avec une vitesse maximum du Wireless-N de 300 Mbits/s.</LI></UL><P>Le parametre par defaut est <b>Jusqu'a 145 Mbits/s</b>. De cette facon, toutes les stations sans fil 11b, 11g et 11n sont acceptees. </P><HR><A name=security></A><p><b>Options de securite</b></p><UL><LI>Non - Pas de chiffrement des donnees<LI>WEP (Wired Equivalent Privacy) : utiliser le chiffrement des donnees a 64 ou 128 bits.<br><b>Remarque </b>: la fonction Wi-Fi Protected Setup est desactivee lorsque la securite est parametree sur l'authentification WEP ou WPA-PSK [TKIP].<LI>WPA-PSK [TKIP] - Wi-Fi Protected Access with Pre-Shared Key : utiliser le chiffrement standard WPA-PSK avec le type de chiffrement TKIP<LI>WPA2-PSK [AES] - Wi-Fi Protected Access version 2 with Pre-Shared Key : utiliser le chiffrement standard WPA2-PSK avec le type de chiffrement AES<LI>WPA-PSK [TKIP] + WPA2-PSK [AES] - Permettre aux clients d'utiliser WPA-PSK [TKIP] ou WPA2-PSK [AES]</LI></UL><p>Pour un fonctionnement optimal de NETGEAR WN511B ou d’autres adaptateurs sans fil beneficiant d'un reseau correctement protege, NETGEAR conseille de modifier l’option de securite de votre reseau XWN5001 en WPA2-PSK.<HR><A name=wep></A><p><b>Chiffrement de securite (WEP)  </b></p><P>Type d'authentification <p>Generalement, la valeur par defaut Automatique peut etre conservee. Si cela echoue, selectionnez la valeur appropriee – ? Systeme ouvert ? ou ? Cle partagee ?. Consultez la documentation de votre carte sans fil pour voir la methode a utiliser.<p>Niveau de chiffrement <p>Selectionnez le niveau de chiffrement WEP : <UL><LI>chiffrement 64 bits (parfois appele 40 bits) <LI>chiffrement 128 bits </LI></UL><HR><A name=wepkey></A><p><b>Cle de chiffrement de securite (WEP)</b></p><p>Si le WEP est active, vous pouvez programmer manuellement ou automatiquement les quatre cles de chiffrement des donnees. Ces valeurs doivent etre identiques sur tous les ordinateurs et points d'acces de votre reseau. <p>Creation automatique de cle (phrase d'authentification) <p>Saisissez un mot ou un groupe de caracteres d'imprimerie dans le champ Phrase d'authentification, puis cliquez sur le bouton Creer pour configurer automatiquement la ou les cle(s) WEP. Si le niveau de chiffrement est configure sur 64 bits, les quatre champs de cle se verront attribuer une cle chacun. Si le niveau de chiffrement est configure sur 128 bits, alors seule le champ de la cle WEP selectionnee sera automatiquement renseigne avec les valeurs de cle. <p>Mode de saisie manuelle <p>Selectionnez une cle parmi les quatre proposees et saisissez les informations sur la cle WEP correspondant a votre reseau dans le champ de cle selectionne. <p>Pour le chiffrement WEP a 64 bits - Saisissez 10 caracteres hexadecimaux (toute combinaison de caracteres compris entre 0 et 9, et entre A et F). <p>Pour le chiffrement WEP a 128 bits - Saisissez 26 caracteres hexadecimaux (toute combinaison de caracteres compris entre 0 et 9, et entre A et F). <p>N'oubliez pas de cliquer sur Appliquer pour sauvegarder les parametres de ce menu.</P><HR><A name=wpa-psk></A><p><b>Chiffrement de securite (WPA-PSK)</b></p><p>Lorsque cette option est selectionnee, vous devez utiliser le chiffrement TKIP et saisir la phrase d'authentification WPA (cle reseau). Saisissez un mot ou un groupe de caracteres d'imprimerie dans le champ Phrase d'authentification. La phrase d'identification doit comporter entre 8 et 63 caracteres ASCII ou 64 caracteres hexadecimaux. Exemple de valeurs hexadecimales : <br>0, 1, 2, ..., 8, 9, A, B, C, D, E et F. <p>N'oubliez pas de cliquer sur Appliquer pour sauvegarder les parametres. </p><HR><A name=wpa2-psk></A><p><b>Chiffrement de securite (WPA2-PSK)</b></p><p>WPA2 est une version plus recente de WPA. Selectionnez uniquement cette option si tous les clients sans fil sur votre reseau prennent en charge WPA2. Lorsque cette option est selectionnee, vous devez utiliser le chiffrement AES et saisir la phrase d'authentification WPA (cle reseau). Saisissez un mot ou un groupe de caracteres d'imprimerie dans le champ Phrase d'authentification. La phrase d'identification doit comporter entre 8 et 63 caracteres ASCII ou 64 caracteres hexadecimaux. Exemple de valeurs hexadecimales : <br>0, 1, 2, ..., 8, 9, A, B, C, D, E et F. </p><HR><A name=wpa-psk+wpa2-psk></A><p><b>Chiffrement de securite (WPA-PSK + WPA2-PSK)  </b></p><p>Cette selection permet aux clients d'utiliser WPA (avec TKIP, les paquets de diffusion utilisent egalement TKIP) ou WPA2 (avec AES). Lorsque cette option est selectionnee, le chiffrement doit etre TKIP + AES. La phrase d'authentification WPA (cle reseau) doit egalement etre saisie. Pour maximiser les performances sans fil, les clients tels que WN511B doivent se connecter a ce peripherique a l'aide du chiffrement WPA2 (avec AES). Pour les clients qui se connectent au moyen du chiffrement WPA-PSK (avec TKIP), la vitesse sans fil maximale sera conforme a la norme 802.11g. Saisissez un mot ou un groupe de caracteres d'imprimerie dans le champ Phrase d'authentification. La phrase d'identification doit comporter entre 8 et 63 caracteres ASCII ou 64 caracteres hexadecimaux. Exemple de valeurs hexadecimales : <br>0, 1, 2, ..., 8, 9, A, B, C, D, E et F. <HR><p><b>Sauvegarder ou annuler les modifications</b></p><p>Cliquez sur <b>Appliquer</b> pour que vos modifications prennent effet. <br>Cliquez sur <b>Annuler</b> pour retablir les parametres anterieurs. </p></body>";

var help_center="Centre d'aide";
var help_show_hide="Afficher/masquer le centre d'aide";
var sec_wpa_mode="Mode WPA :";
var auto_mark="Automatique";
var guest_wire_iso="Activer l'isolation sans fil";
var adva_wlan_ssid_broadcast="Activer la diffusion du SSID";
var cancel_mark="Annuler";
var apply_mark="Appliquer";

var wlan_network_mark="Réseau sans-fil ";
var wlan_mark_ssid="Nom (SSID)";
var wlan_mark_reg="Région";
var wlan_mark_chan="Canal";
var wlan_mark_mode="Mode";
var wlan_mark_gb="b et g";
var wlan_mark_go="g seulement";
var wlan_mark_bo="b seulement";
var wlan_mark_turbog=" 108 Mbits/s auto ";
var wlan_mode_54="Jusqu'à 54 Mbps" ;
var wlan_mode_65="Jusqu'à 65 Mbps" ;
var wlan_mode_130="Jusqu'à 130 Mbps" ;
var wlan_mode_145="Jusqu'à 145 Mbps" ;
var wlan_mode_150="Jusqu'à 150 Mbps" ;
var wlan_mode_300="Jusqu'à 300 Mbps" ;
var wlan_wlacl="Liste d'accès des clients sans-fil";
var wir_wning ="Conformément aux directives de la Wi-Fi Alliance sur la cohabitation des fréquences 40 MHz et 20 MHz, le débit de service de votre produit peut tomber à 20 MHz même si vous sélectionnez le mode « Jusqu'à %s Mbit/s ». Un tel débit correspond généralement à des performances de %s Mbit/s.";

var sec_type="Options de sécurité";
var sec_off="Aucune";
var sec_wep="WEP";
var sec_wpa="WPA-PSK [TKIP]";
var sec_wpa2="WPA2-PSK [AES]";
var sec_wpas="WPA-PSK [TKIP] + WPA2-PSK [AES]";
var sec_pr_wpa="Options de sécurité (WPA-PSK)";
var sec_pr_wpa2="Options de sécurité (WPA2-PSK)";
var sec_pr_wpas="Options de sécurité (WPA-PSK + WPA2-PSK)";
var sec_auth="Type d'authentification";
var sec_auto="Automatique";
var sec_share="Clef Partagée";
var sec_enc="Niveau d'encryption";
var sec_64="64-bit";
var sec_128="128-bit";
var sec_enc_head="Security Encryption (WEP)";
var sec_key="Options de sécurité (WEP) Key";
var sec_key1="Clef 1";
var sec_key2="Clef 2";
var sec_key3="Clef 3";
var sec_key4="Clef 4";
var sec_phr="PassPhrase";
var sec_863_or_64h="(8 à 63 caractères ou 64 valeurs hexadécimales)";
var wep_or_wps="Sécurité WEP avec une authentification Auto/Clef partagée ne fonctionne pas avec le WPS. Le WPS est donc indisponible. Voulez-vous continuer ?";
var wep_just_one_ssid="La sécurité WEP peut être prise en charge par un seul SSID de chaque bande";


var bh_internet_checking="Vérification de la connexion Internet. Veuillez patienter...";

var SB011="Si tous vos périphériques client utilisent d'autres paramètres sans fil, vous pouvez <font id=\"a\" onclick=\"click_here();\">cliquer ici</font> pour remplacer les paramètres prédéfinis par les paramètres existants.";

//BRS_02_genieHelp.html
var bh_config_net_connection="Configuration de la connexion Internet";

var bh_connection_further_action="Vous n'êtes pas encore connecté à Internet.";

var bh_want_genie_help="Souhaitez-vous obtenir l'aide de l'assistant NETGEAR genie ?";

var bh_yes_mark="Oui";

var bh_no_genie_help="Non, je souhaite configurer la connexion Internet moi-même.";

var bh_no_genie_help_confirm="Configurer la connexion Internet nécessite une bonne connaissance des réseaux. Etes-vous sûr ?"

var bh_have_saved_copy="J'ai enregistré les paramètres du routeur dans un fichier et je souhaite restaurer ces paramètres pour le routeur."

var bh_next_mark="Suivant";


//BRS_03A_detcInetType.html
var bh_detecting_connection="Détection de la connexion Internet";

var bh_plz_wait_process="Ce processus peut prendre une ou deux minutes, veuillez patienter...";


//BRS_03A_A_noWan.html
var bh_no_cable="Aucun câble Ethernet n'est branché au port Internet du routeur.";

var bh_wizard_setup_nowan_check="Assurez-vous que le câble est correctement branché au port du modem haut débit et au port Internet du routeur.";

var bh_click_try_again="Une fois que vous avez vérifié le câble Ethernet, cliquez sur <b>Réessayer</b>.";

var bh_try_again="Réessayer";


//BRS_03A_B_pppoe.html
var bh_pppoe_connection="Connexion Internet DSL PPPoE détectée";

var bh_enter_info_below="Saisissez les informations requises ci-dessous.";

var bh_pppoe_login_name="Identifiant";
var bh_ddns_passwd="Mot de passe";


//BRS_03A_B_pppoe_reenter.html
var bh_ISP_namePasswd_error="Nom d'utilisateur ou mot de passe ISP incorrect";

var bh_enter_info_again="Saisissez à nouveau les informations requises.";


//BRS_03A_C_pptp.html
var bh_pptp_login_name="Identifiant";

var bh_pptp_connection="Connexion Internet PPTP détectée";

var bh_basic_pptp_servip="Adresse du serveur";

var bh_sta_routes_gtwip="Adresse IP de la passerelle";

var bh_basic_pptp_connection_id="Nom d'identification";

//BRS_03A_F_l2tp.html
var bh_l2tp_connection="L2TP Internet Connection Detected";

//BRS_03A_D_bigpond.html
var bh_bpa_connection="Connexion Internet BigPond détectée"; 

var bh_basic_bpa_auth_serv="Serveur d'authentification";

var bh_basic_pppoe_idle="Temps d'inactivité (en minutes)";


//BRS_03A_E_IP_problem_staticIP.html
var bh_no_internet_ip="Problème lors de la détection de la connexion Internet";

var bh_no_internet_ip2="Problème lors de la détection de la connexion Internet - Adresse IP";

var bh_no_internet_ip3="Problème lors de la détection de la connexion Internet - Adresse MAC";

var bh_if_have_static_ip="Votre fournisseur d'accès Internet (FAI) vous a-t-il attribué une adresse IP fixe (statique) ? Ce déploiement spécifique est <b>très rare</b>. ";

var bh_yes_correct="Oui. Mon FAI m'a attribué une adresse IP fixe (statique).";

var bh_not_have_static_ip="Non, je n'ai reçu aucune adresse IP fixe (statique) de mon FAI.";

var bh_do_not_know="Je ne sais pas. ";

var bh_select_option="Sélectionnez une option, puis cliquez sur <b>Suivant</b> pour continuer.";

var bh_select_an_option="Sélectionnez d'abord une option.";


//BRS_03A_E_IP_problem_staticIP_A_inputIP.html
var bh_fix_ip_setting="Paramètres de l'adresse IP Internet fixe";

var bh_enter_ip_setting="Saisissez les paramètres de l'adresse IP fixe que votre FAI vous a attribuée, puis cliquez sur <b>Suivant</b> pour continuer.";

var bh_info_mark_ip="Adresse IP";
//var bh_info_mark_ip="Mon adresse IP";
var bh_info_mark_mask="Masque de sous-réseau";

var bh_constatus_defgtw="Passerelle par défaut";

var bh_preferred_dns="Serveur DNS préféré";

var bh_alternate_dns="Serveur DNS secondaire";

var bh_basic_int_third_dns="DNS tiers";

//BRS_03A_E_IP_problem.html
var bh_genie_cannot_find_ip="Cela est probablement dû à l'une des raisons suivantes :";
var bh_genie_cannot_find_ip_reason1="1.  Le modem n'a pas été réinitialisé pendant l'étape de connexion des câbles.";
var bh_genie_cannot_find_ip_reason1_desc="Pour résoudre ce problème, réinitialisez le modem (éteignez-le et rallumez-le). Pour réinitialiser un modem disposant d'une batterie de secours, vous devrez peut-être retirer puis réinsérer la batterie. Après la réinitialisation, patientez 2 minutes que le démarrage du modem soit terminé."; 
var bh_genie_cannot_find_ip_reason2="2.  Le câble Ethernet jaune n'est pas correctement inséré ou est inséré au mauvais endroit.";
var bh_genie_cannot_find_ip_reason2_desc="Pour résoudre ce problème, assurez-vous que le câble Ethernet jaune est correctement branché au modem haut débit et au port Internet du routeur.";

var bh_select_no_IP_option="Sélectionnez l'une des options ci-dessous, puis cliquez sur <b>Suivant</b> pour continuer :";
var bh_select_no_IP_option1="Je viens de réinitialiser le modem et j'ai patienté 2 minutes.";
var bh_select_no_IP_option2="J'ai résolu un problème avec le câble Ethernet.";
var bh_select_no_IP_option3="Aucun de ces cas.";


//BRS_03A_E_IP_problem_staticIP_B_macClone.html
var bh_use_pc_mac="Si vous avez précédemment connecté votre service Internet à un ordinateur ou à un autre routeur, l'assistant NETGEAR genie peut utiliser la même adresse MAC qui fonctionnait auparavant.";

var bh_mac_in_product_label="Une adresse MAC est un nombre unique.  L'adresse MAC de l'ordinateur ou du routeur est indiquée sur l'étiquette du produit.";

var bh_enter_mac="Saisissez l'adresse MAC ici.";

var bh_mac_format="(format AABBCCDDEEFF)";


//BRS_03B_haveBackupFile.html
var bh_settings_restoration="Restaurer les paramètres du routeur ";

var bh_browser_file="Sélectionnez le fichier de sauvegarde des paramètres du routeur que vous avez préalablement enregistré, puis cliquez sur <b>Suivant</b> pour continuer.";

var bh_back_mark="Précédent";


//BRS_03B_haveBackupFile_fileRestore.html
var bh_settings_restoring="Restauration des paramètres du routeur"; 

var bh_plz_waite_restore="Ce processus peut prendre quelques minutes. Veuillez patienter...";


//BRS_04_applySettings.html
var bh_apply_connection="Application des paramètres de connexion Internet";

var bh_plz_waite_apply_connection="Ce processus peut prendre une ou deux minutes, veuillez patienter...";


//BRS_05_networkIssue.html
var bh_netword_issue="Problème de connexion au réseau";

var bh_cannot_connect_internet="Le routeur ne peut pas se connecter à Internet avec les paramètres actuels.";

var bh_plz_reveiw_items="Vérifiez les éléments suivants :";

var bh_cable_connection="- Assurez-vous que les connexions câblées sont correctes. Reportez-vous au guide d'installation du routeur pour obtenir des instructions.";

var bh_modem_power_properly="- Assurez-vous que votre modem haut débit a été correctement réinitialisé. Si votre modem dispose d'une batterie de secours, retirez et réinsérez la batterie pour réinitialiser votre modem.";

var bh_try_again_or_manual_config="Souhaitez-vous que l'assistant NETGEAR genie réessaye ?";

var bh_I_want_manual_config="Non. Je souhaite configurer la connexion Internet moi-même."; 

var bh_manual_config_connection="Je souhaite configurer la connexion Internet moi-même.";


//BRS_success.html
var bh_congratulations="Félicitations !";

var bh_connect_success_1="Vous êtes à présent connecté à Internet."

var bh_connect_success_2="Ce routeur est préconfiguré avec le nom de réseau sans fil (SSID) unique et ";

var bh_network_key="la clé réseau (mot de passe) suivants.";

var bh_rollover_help_text="Votre routeur est préconfiguré avec la sécurité sans fil WPA2-PSK afin de protéger votre réseau contre tout accès non autorisé. Pour vous connecter au réseau sans fil, vous devez saisir la clé réseau (mot de passe). Ces paramètres prédéfinis sont uniques à ce périphérique, à l'image d'un numéro de série.  Vous pouvez les modifier ultérieurement dans l'écran Paramètres sans fil de l'interface Web du routeur."; 

var bh_success_no_wireless_security_1 = "La sécurité sans fil n'est pas activée sur ce routeur. NETGEAR vous recommande vivement de ";
var bh_success_no_wireless_security_2 = "cliquez ici";
var bh_success_no_wireless_security_3 =  " pour activer la sécurité sans fil et protéger votre réseau.";

var bh_wirless_name="Nom du réseau sans fil (SSID)"

var bh_wireless="Sans fil";

var bh_wpa_wpa2_passpharse="Clé réseau (mot de passe)"; 

var bh_save_settings="Save router settings";

var bh_print_this="Imprimer cette page";


var bh_take_to_internet="Aller sur Internet";

var bh_plz_wait_moment="Veuillez patienter quelques instants...";

//the string for not_support_print is temporary.
var bh_not_support_print="L'ordinateur ne prend pas en charge d'imprimante.";
//already exist
var bh_login_name_null="Le nom d'utilisateur ne peut être vide!";
var bh_password_error="Mot de passe non valide!";
var bh_idle_time_null="Veuillez saisir le temps d'inactivité.\n";
var bh_invalid_idle_time="La dur&eacute;e d'inactivit&eacute; n'est pas valide, saisissez une valeur num&eacute;rique.\n";
var bh_invalid_myip="Adresse IP non valide, saisssez à nouveau ou laissez vide.";
var bh_invalid_gateway="L'adresse IP de la passerelle n'est pas valide, saisssez à nouveau!";
var bh_bpa_invalid_serv_name="Adresse IP du serveur d'authentification non valide.";
var bh_invalid_servip_length="Les étiquettes doivent contenir 63 caractères maximum.\n";
var bh_invalid_ip="Adresse IP non valide, saisssez à nouveau!";
var bh_invalid_mask="Masque de sous-réseau non valide, saisssez à nouveau!\n";
var bh_same_subnet_ip_gtw="L'adresse IP du routeur et l'adresse IP de la passerelle doivent &ecirc;tre dans le m&ecirc;me sous-r&eacute;seau.\n"
var bh_same_lan_wan_subnet=" Les adresses IP du réseau local et IP WAN ne doivent pas être dans le même sous-réseau. "
var bh_filename_null="Le nom de fichier ne peut &ecirc;tre vide!";
var bh_not_correct_file="Saisissez un nom de fichier correct. le format du fichier est *.";
var bh_ask_for_restore="Attention!\nRestaurer le param&eacute;trage depuis un fichier de configuration effacera tous les param&eacute;trages actuels.\nVoulez-vous r&eacute;ellement le faire?";
var bh_invalid_primary_dns="Adresse IP du DNS primaire non valide, saisssez à nouveau.\n";
var bh_invalid_second_dns="Adresse IP du DNS secondaire non valide, saisssez à nouveau.\n";
var hb_invalid_third_dns="Invalid third DNS address. Please enter it again.\n";
var bh_dns_must_specified="Une adresse DNS doit être spécifiée.";
var bh_invalid_mac="Adresse MAC non valide.";
var bh_failure_head="Echec";
var bh_few_second="Cette page reviendra automatiquement à la précédente dans quelques secondes...";

var bh_important="Mise à jour importante";
var bh_wanlan_conflict_info="Pour éviter tout conflit avec votre fournisseur d'accès à Internet, l'adresse IP de votre routeur est désormais ";
var bh_continue_mark="Continuer";

var sec_phr="PassPhrase";
var sec_type="Options de sécurité";
var sec_off="Aucune";
var sec_wep="WEP";
var sec_wpa="WPA-PSK [TKIP]";
var sec_wpa2="WPA2-PSK [AES]";
var sec_wpas="WPA-PSK [TKIP] + WPA2-PSK [AES]";
var wlan_mark_ssid="Nom (SSID)";
var wlan_mark="Paramètres du réseau sans-fil";
//readySHARE remote strings
var remote_share_head="ReadySHARE Cloud"

var ready_share_info1="La fonction ReadySHARE Cloud permet d'accéder à distance via Internet à un périphérique de stockage USB connecté au port USB de votre routeur."
var how_setup_ready_share="Configuration de ReadySHARE Cloud"
var ready_share_step1="Etape 1 : vous devez disposer d'un compte ReadySHARE. Si vous n'en possédez pas, <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>cliquez ici</a> pour en créer un."
var ready_share_step2="Etape 2 : sur cette page, saisissez vos nom d'utilisateur et mot de passe ReadySHARE Cloud pour enregistrer votre routeur et le périphérique USB connecté à celui-ci sur votre compte."
var ready_share_step3="Etape 3 : connectez-vous à nouveau à l'adresse <a class='linktype' target='_blank' href='http://readyshare.netgear.com/'>http://readyshare.netgear.com/</a> avec votre compte. Le périphérique USB connecté à votre routeur doit s'afficher."
var ready_share_step4="Etape 4 : lors de la première utilisation, vous êtes invité à télécharger un client Windows qui permet de sécuriser la connexion entre votre PC et le périphérique USB du routeur. Connectez-vous à ce client ; vous pourrez ensuite accéder au périphérique USB où que vous soyez."
var ready_share_set_note="<b>Remarque :</b> sans ce client, vous serez en mesure de visualiser le contenu de votre périphérique USB, mais vous ne pourrez ni ouvrir ni modifier les fichiers."
var ready_share_start="Activez ReadySHARE Cloud dès maintenant"
var ready_share_get_account="Si vous ne disposez pas de compte ReadySHARE Cloud, <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>cliquez ici</a> pour en créer un"
var username="Nom d'utilisateur"
var key_passphrase="Mot de passe"
var register="Enregistrer"
var register_note="<b>Remarque :</b> la connexion Internet restera active jusqu'à l'annulation de l'enregistrement."
var help_center="Centre d'aide"
var help_show_hide="Afficher/masquer le centre d'aide"

var resister_user="ReadySHARE Cloud est enregistré par un utilisateur"
var access_storage_method="Suivez les étapes 2 à 4 ci-dessus pour accéder au périphérique de stockage où que vous soyez."
var unregister_info="Cliquez sur <B>Annuler l'enregistrement</B> pour enregistrer ReadySHARE Cloud avec un autre utilisateur."
var unregister="Annuler l'enregistrement"

var result_register_ok="Enregistrement terminé."
var result_register_fail="Echec de l'enregistrement."
var result_unreg_ok="Annulation de l'enregistrement terminée."
var result_unreg_fail="Echec de l'annulation de l'enregistrement."



//for wireless check string
var wps_in_progress="Le processus WPS est en cours, veuillez appliquer les modifications ultrieurement."
var ssid_null="Le SSID ne peut être vide!"
var ssid_not_allowed_same="SSID dupliqu, veuillez en choisir un autre."
var ssid_not_allowed="Ce caractère n'est pas autorisé dans le SSID."
var SWSW02="L'authentification de sécurité WEP ou WPA-PSK [TKIP] ne peut pas fonctionner avec le WPS. Le WPS va devenir inaccessible. Voulez-vous continuer ?"
var SWSW11="La diffusion du SSID est requise pour le fonctionnement du WPS. Si vous procédez à cette modification, le WPS va devenir inaccessible. Voulez-vous continuer ?"
var SWSW12="Etes-vous sûr de ne vouloir activer aucune sécurité sans fil sur votre réseau ? Ce paramètre est généralement utilisé pour les points d'accès sans fil d'accès public."
var wds_auto_channel="La fonction de répéteur sans-fil ne peut être utilisée avec la fonction de sélection automatique de canal.\nChangez vos paramètres de canal avant d'activer le mode répéteur sans-fil. "
var notallowpassp="Ce caractère n'est pas autorisé dans la phrase d'authentification."
var guest_tkip_300_150="WPA-PSK [TKIP] en réseau invités fonctionne UNIQUEMENT en mode \"Jusqu'à 54 Mbit/s\" (Legacy G), pas en mode N."
var guest_tkip_aes_300_150="NETGEAR recommande d'utiliser WPA2-PSK [AES] en réseau invités pour obtenir une assistance de débit N complète."
var wlan_tkip_aes_300_150="IMPORTANT\nWPA-PSK [TKIP] fonctionne uniquement en débit « jusqu'à 54 Mbit/s », pas en débit N.\nNETGEAR recommande d'utiliser WPA2-PSK [AES] pour obtenir une assistance de débit N complète."
var notSupportWLA="Israël et les pays du Moyen-Orient ne prennent pas en charge le 802.11a. Si vous sélectionnez cette option, le a/n sans fil sera désactivé. Continuer ?"
var passphrase_short8="Passphrase trop courte, elle doit avoir un minimum de 8 caractères."
var passphrase_long63="Passphrase trop longue, elle doit avoir un maximum de 63 caractères."

