//BRS_01_checkNet.html

var h_wlan="<body bgColor=#0099cc><P><font size=4><B>Wireless Help</B></font></P><P><B>NOTE:</B> To ensure proper agency compliance and compatibility between similar products in your area; the operating channel &amp; region must be set correctly. <P><B>Placement of the Device to Optimize Wireless Connectivity</B><P>The operating distance or range of your wireless connection can vary significantly based on the physical placement of the Device. For best result,  place your Device:<UL><LI>Near the center of the area in which your PCs will operate,<LI>In an elevated location such as a high shelf,<LI>Away from potential sources of interference, such as PCs, microwave ovens, and   cordless phones,<LI>Away from large metal surfaces. </LI></UL><P><B>Note:</B> Failure to follow these guidelines can result in significant performance degradation or inability to wirelessly connect to the device.</P><HR><A name=network></A><P><B>Wireless Network</B></P><P>Name (SSID)<P>Enter a value of up to 32 alphanumeric characters. The same Name (SSID) must be assigned to all wireless devices in your network. The default SSID is Netgear_EXT, but NETGEAR strongly recommends that you change your network's Name (SSID) to a different value. This value is also case-sensitive. For example, <I>NETGEAR</I> is not the same as <I>NETGEAr</I>.<P>Region<P>Select your region from the drop-down list. This field displays the region of operation for which the wireless interface is intended. It may not be legal to operate the Device in a region other than the region shown here. If your country or region is not listed, please check with your local government agency or check our website for more information on which channels to use.<P>Channel<P>This field determines which operating frequency will be used. It should not be necessary to change the wireless channel unless you notice interference problems with another nearby access point.</P><P>Mode<P>Select the desired wireless mode. The options are:<UL><LI>Up to 54 Mbps - Legacy Mode with maximum speed of up to 54 Mbps for b/g networks.<LI>Up to 130 Mbps - Neighbor Friendly Mode - Default speed up to 130 Mbps in presence of neighboring wireless networks.<LI>Up to 300 Mbps - Performance Mode - Maximum Wireless-N speed up to 300 Mbps.</LI></UL><P>The default is \"Up to 145Mbps\", which allows all 11b and 11g and 11n wireless stations. </P><HR><A name=security></A><P><B>Security Options</B></P><UL><LI>None - no data encryption<LI>WEP - Wired Equivalent Privacy, use WEP 64- or 128-bit data encryption<br><b>Note:</b> &nbsp; Wi-Fi Protected Setup function is disabled when the security setting is WEP or WPA-PSK [TKIP] authentication.  <LI>WPA-PSK [TKIP] - Wi-Fi Protected Access with Pre-Shared Key, use WPA-PSK standard encryption with TKIP encryption type<LI>WPA2-PSK [AES] - Wi-Fi Protected Access version 2 with Pre-Shared Key, use WPA2-PSK standard encryption with the AES encryption type<LI>WPA-PSK [TKIP] + WPA2-PSK [AES] - Allow clients using either WPA-PSK [TKIP] or WPA2-PSK [AES]</LI></UL><p>To achieve the best performance with NETGEAR WN511B or other wireless adapters under robust security network, NETGEAR recommends that you change your XWN5001 network's security option to WPA2-PSK. <HR><A name=wep></A><P><B>Security Encryption (WEP)</B><P>Authentication Type<P>Normally this can be left at the default value of \"Automatic.\" If that fails, select the appropriate value - \"Open System\" or \"Shared Key\" Check your wireless card's documentation to see what method to use.  <P>Encryption Strength <P>Select the WEP Encryption level:<UL>  <LI>64-bit (sometimes called 40-bit) encryption  <LI>128-bit encryption </LI></UL><HR><A name=wepkey></A><P><B>Security Encryption (WEP) Key</B></P><P>If WEP is enabled, you can manually or automatically program the four data encryption keys. These values must be identical on all PCs and Access Points in your network.<P>Automatic Key Generation (Passphrase)<P>Enter a word or group of printable characters in the Passphrase box and click the Generate button to automatically configure the WEP Key(s). If  encryption strength is set to 64 bit, then each of the four key boxes will automatically be populated with key values. If encryption strength is set to 128 bit, then only the selected WEP key box will automatically be populated with key values.<P>Manual Entry Mode<P>Select which of the four keys will be used, and enter the matching WEP key information for your network in the selected key box.<P>For 64-bit WEP - Enter ten hexadecimal digits (any combination of 0-9, A-F). <P>For 128-bit WEP - Enter twenty-six hexadecimal digits (any combination of 0-9, A-F).<P>Be sure to click Apply to save your settings in this menu.</P><HR><A name=wpa-psk></A><P><B>Security Encryption (WPA-PSK)</B></P><P>If selected, you must use TKIP encryption, and enter the WPA passphrase (Network key). Enter a word or group of printable characters in the Passphrase box. The Passphrase must be constituted of either 8 to 63 ASCII characters or exactly 64 hex digits. A hex digit is one of the following characters: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E, and F.<P>Be sure to click Apply to save your settings. </p><HR><A name=wpa2-psk></A><P><B>Security Encryption (WPA2-PSK)</B></P><P>WPA2 is a newer version of WPA. Only select this if all the wireless clients in your network support WPA2. If selected, you must use AES encryption, and enter the WPA passphrase (Network key). Enter a word or group of printable characters in the Passphrase box. The Passphrase must be constituted of either 8 to 63 ASCII characters or exactly 64 hex digits. A hex digit is one of the following characters: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E, and F.<HR><A name=\"wpa-psk+wpa2-psk\"></A><P><B>Security Encryption (WPA-PSK + WPA2-PSK)</B></P><P>This selection allows clients to use either WPA (with TKIP, broadcast packets also use TKIP.) or WPA2 (with AES). If selected, encryption must be TKIP + AES. The WPA passphrase (Network key) must also be entered. To reach maximum wireless performance, the client like WN511B must connect to this device using WPA2(with AES) .  For clients connecting in WPA-PSK( with TKIP), the maximum wireless speed will be at 802.11g. Enter a word or group of printable characters in the Passphrase box. The Passphrase must be constituted of either 8 to 63 ASCII characters or exactly 64 hex digits. A hex digit is one of the following characters: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E, and F. <HR><P><B>To Save Or Cancel Changes</B></P><P>Click <B>Apply</B> to have your changes take effect. <BR>Click <B>Cancel</B>to return to the previous settings. </P></body>";

var help_center="Help Center";
var help_show_hide="Show/Hide Help Center";
var sec_wpa_mode="WPA Mode:";
var auto_mark="Auto";
var guest_wire_iso="Enable Wireless Isolation";
var adva_wlan_ssid_broadcast="Enable SSID Broadcast";
var cancel_mark="Cancel";
var apply_mark="Apply";

//spbu
var wlan_network_mark_spbu="Wireless Network";
var wlan_mark_ssid_spbu="Name (SSID)";

var wlan_network_mark="Wireless Network";
var wlan_mark_ssid="Name (SSID)";
var wlan_mark_reg="Region";
var wlan_mark_chan="Channel";
var wlan_mark_mode="Mode";
var wlan_mark_gb="b and g";
var wlan_mark_go="g only";
var wlan_mark_bo="b only";
var wlan_mark_turbog="Auto 108 Mbps";
var wlan_mode_54="Up to 54 Mbps";
var wlan_mode_65="Up to 65 Mbps";
var wlan_mode_130="Up to 130 Mbps";
var wlan_mode_145="Up to 145 Mbps";
var wlan_mode_150="Up to 150 Mbps";
var wlan_mode_300="Up to 300 Mbps";
var wlan_wlacl="Wireless Card Access List";
var wir_wning = "Per Wi-Fi Alliance guidelines for 40 Mhz and 20 Mhz coexistence, even if you select \'Up to %sMbps\' mode, your product’s service rate might drop to 20 Mhz. This typically corresponds to %s Mbps performance.";

var sec_type="Security Options";
var sec_off="None";
var sec_wep="WEP";
var sec_wpa="WPA-PSK [TKIP]";
var sec_wpa2="WPA2-PSK [AES]";
var sec_wpas="WPA-PSK [TKIP] + WPA2-PSK [AES]";
var sec_pr_wpa="Security Options (WPA-PSK)";
var sec_pr_wpa2="Security Options (WPA2-PSK)";
var sec_pr_wpas="Security Options (WPA-PSK + WPA2-PSK)";
var sec_auth="Authentication Type";
var sec_auto="Automatic";
var sec_share="Shared Key";
var sec_enc="Encryption Strength";
var sec_64="64-bit";
var sec_128="128-bit";
var sec_enc_head="Security Encryption (WEP)";
var sec_key="Security Encryption (WEP) Key";
var sec_key1="Key 1";
var sec_key2="Key 2";
var sec_key3="Key 3";
var sec_key4="Key 4";
var sec_phr="Passphrase";
var sec_phr_g="Wireless Password";
var sec_863_or_64h="(8-63 characters or 64 hex digits)";
var wep_or_wps="WEP security with shared key authentication does not work with WPS. WPS will be inaccessible. Do you want to continue?";
var wep_just_one_ssid="The WEP security can only be supported on one SSID of each band";

var bh_internet_checking="Checking the Internet connection; please wait ...";

var network_checking="Checking the network connection...";

var SB011="If you have an existing wireless settings used by all client devices, you can <font id=\"a\" onclick=\"click_here();\">click here</font> to update the pre-set settings to the existing one.";

//BRS_02_genieHelp.html
var bh_config_net_connection="Configuring the Internet Connection";

var bh_config_wireless_setting="Configuring the Wireless Settings";

var SWP005="No Internet connection detected.";

var SWP0011="Confirmation:";

var SWP0012="Confirm the wireless settings, then click Next button. You are currently connected wirelessly. After clicking Next, you will loss wireless connection, re-connect using the new settings then continue the setup.";


var range_ext="Device new settings:";

var LPC028="Check your router's internet connection.";

var bh_connection_further_action="You are not yet connected to the Internet.";

var bh_want_genie_help="Do you want NETGEAR Genie to help?";

var genie_wireless_set_info="NETGEAR genie has detected an existing wireless network.";

var select_choice="Select your choice of wireless settings on this device:";

var use_router_setting="Use the same settings in my existing wireless network. This is recommended.";

var use_manual_setting="Set up a new wireless network. I understand that wireless device would need to be manually connected to this new network.";

var bh_yes_mark="Yes";

var wiz_start_genie="Do you want the Wizard to check for a NETGEAR WiFi router to extend its WiFi signal seamlessly at your home?";

var wiz_start_genie_re="Yes.";

var wiz_start_manual="No. I would like to configure the wireless settings myself.";

var bh_no_genie_help="No, I want to configure the Internet connection myself.";

var bh_no_genie_wireless_help="No, I want to configure the wireless setting myself.";

var bh_no_genie_help_confirm="Configuring the Internet connection requires networking experience. Are you sure?";

var bh_have_saved_copy="I have saved the router settings in a file and I want to restore the router to those settings.";

var bh_next_mark="Next";

var OTH002="Close";

var WP0006="Close Window";

//BRS_03A_detcInetType.html
var bh_detecting_connection="Detecting the Internet Connection";

var bh_plz_wait_process="This process can take a minute or two; please wait...";


//BRS_03A_A_noWan.html
var bh_no_cable="No Ethernet Cable Is Plugged into the Router Internet Port";

var bh_wizard_setup_nowan_check="Make sure that the cable is securely plugged into both the broadband modem port and the router Internet port.";

var bh_click_try_again="After you have checked the Ethernet cable, click <b>Try again</b>.";

var bh_try_again="Try again";

var quit="Quit";

//BRS_03A_B_pppoe.html
var bh_pppoe_connection="PPPoE DSL Internet Connection Detected";

var bh_enter_info_below="Enter the required information below.";

var bh_pppoe_login_name="User Name";
var bh_ddns_passwd="Password";


//BRS_03A_B_pppoe_reenter.html
var bh_ISP_namePasswd_error="Incorrect ISP User Name or Password";

var bh_enter_info_again="Enter the required information again.";


//BRS_03A_C_pptp.html
var bh_pptp_login_name="Login";

var bh_pptp_connection="PPTP Internet Connection Detected";

var bh_basic_pptp_servip="Server Address";

var bh_sta_routes_gtwip="Gateway IP Address";

var bh_basic_pptp_connection_id="Connection ID/Name";

//BRS_03A_F_l2tp.html
var bh_l2tp_connection="L2TP Internet Connection Detected";

//BRS_03A_D_bigpond.html
var bh_bpa_connection="BigPond Internet Connection Detected"; 

var bh_basic_bpa_auth_serv="Authentication Server"

var bh_basic_pppoe_idle="Idle Time-Out(in minutes)"


//BRS_03A_E_IP_problem_staticIP.html
var bh_no_internet_ip="Problem Detecting the Internet Connection";

var bh_no_internet_ip2="Problem Detecting the Internet Connection - IP Address";

var bh_no_internet_ip3="Problem Detecting the Internet Connection - MAC Address";

var bh_if_have_static_ip="Did your Internet Service Provider (ISP) assign to you a fixed (static) IP address? This is a <b>very rare</b> special deployment. ";

var bh_yes_correct="Yes. My ISP assigned a fixed (static) IP address to me.";

var bh_not_have_static_ip="No, I did not get a fixed (static) IP address from my ISP.";

var bh_do_not_know="I don't know. ";

var bh_select_option="Select an option and click <b>Next</b> to proceed.";

var bh_select_an_option="Select an option first.";


//BRS_03A_E_IP_problem_staticIP_A_inputIP.html
var bh_fix_ip_setting="Fixed Internet IP Settings";

var bh_enter_ip_setting="Enter the fixed IP settings assigned by your Internet Service Provider and click <b>Next</b> to proceed.";

var bh_info_mark_ip="IP Address";
//var bh_info_mark_ip="My IP Address";
var bh_info_mark_mask="Subnet Mask";

var bh_constatus_defgtw="Default Gateway";

var bh_preferred_dns="Preferred DNS Server";

var bh_alternate_dns="Alternate DNS Server";

var bh_basic_int_third_dns="Third DNS"

//BRS_03A_E_IP_problem.html
var bh_genie_cannot_find_ip="This is most likely due to one of the following reasons:";
var bh_genie_cannot_find_ip_reason1="1.  The modem was not power cycled during the cabling step.";
var bh_genie_cannot_find_ip_reason1_desc="To solve this problem, power cycle the modem (turn it off and on). To power cycle a modem with battery backup, you might need to remove and reinsert its battery. After the power cycle, wait 2 minutes for the modem to completely start up."; 
var bh_genie_cannot_find_ip_reason2="2.  The yellow Ethernet cable is not fully inserted, or is inserted in the wrong place.";
var bh_genie_cannot_find_ip_reason2_desc="To solve this problem, make sure that the yellow Ethernet cable is securely plugged in to the broadband modem port and the router Internet port.";

var bh_select_no_IP_option="Select one of the options below and click <b>Next</b> to proceed:";
var bh_select_no_IP_option1="I just power cycled the modem and waited for 2 minutes.";
var bh_select_no_IP_option2="I corrected a problem with the Ethernet cable.";
var bh_select_no_IP_option3="None of the above.";


//BRS_03A_E_IP_problem_staticIP_B_macClone.html
var bh_use_pc_mac="If you previously connected to your Internet service with a computer or another router,  NETGEAR Genie can use the same MAC address that worked before.";

var bh_mac_in_product_label="A MAC address is a unique number.  You can find the MAC address of the computer or router on its product label.";

var bh_enter_mac="Enter the MAC address here.";

var bh_mac_format="(format AABBCCDDEEFF)";


//BRS_03B_haveBackupFile.html
var bh_settings_restoration="Restore Router Settings ";

var bh_browser_file="Browse to the router settings backup file you previously saved, and click <b>Next</b> to proceed.";

var bh_back_mark="Back";


//BRS_03B_haveBackupFile_fileRestore.html
var bh_settings_restoring="Restoring Router Settings"; 

var bh_plz_waite_restore="This process can take a few minutes; please wait …";


//BRS_04_applySettings.html
var bh_apply_connection="Applying Internet Connection Settings";

var bh_plz_waite_apply_connection="This process can take a minute or two; please wait...";


//BRS_05_networkIssue.html
var bh_netword_issue="Network Connection Issue";

var bh_cannot_connect_internet="The router cannot connect to the Internet with the current settings.";

var bh_plz_reveiw_items="Please review the following items:";

var bh_cable_connection="- Check that the cable connections are correct. Refer to the router Installation Guide for instructions.";

var bh_modem_power_properly="- Check that your broadband modem is power cycled correctly. If you have a battery-backed modem, remove and reinsert the battery to power cycle your modem.";

var bh_try_again_or_manual_config="Do you want NETGEAR Genie to try again?";

var bh_I_want_manual_config="No. I want to configure the Internet connection myself."; 

var bh_manual_config_connection="I want to configure the Internet connection myself";


//BRS_success.html
var bh_congratulations="Congratulations!";

var bh_connect_success_1="You are successfully connected to the Internet.";

var bh_connect_success_2="This router is preset with the following unique wireless network name (SSID) and ";

var bh_network_key="network key (password)";

var bh_rollover_help_text="Your router is preset with WPA2-PSK wireless security to protect your network from unwanted access. To join the wireless network, you must enter the network key (password). These preset settings are unique to this device, like a serial number.  If you want to change them, you can do so later in the Wireless Settings screen on the router web GUI."; 

var bh_success_no_wireless_security_1 = "Wireless security is not enabled on this router. NETGEAR highly recommends that you ";
var bh_success_no_wireless_security_2 = "click here";
var bh_success_no_wireless_security_3 =  " to enable wireless security and protect your network.";

var bh_wirless_name="Wireless Network Name (SSID)";

var bh_wireless="Wireless";

var bh_wpa_wpa2_passpharse="Network Key (Password)"; 

var bh_save_settings="Save router settings";

var bh_print_this="Print this";


var bh_take_to_internet="Take me to the Internet";

var bh_plz_wait_moment="Please wait a moment...";

//the string for not_support_print is temporary.
var bh_not_support_print="Computer does not support a printer.";
//already exist
var bh_login_name_null="User name cannot be blank.";
var bh_password_error="Invalid password.";
var bh_idle_time_null="Please enter idle time.\n";
var bh_invalid_idle_time="Invalid idle time. Please enter a correct number.\n";
var bh_invalid_myip="Invalid IP address. Please enter it again, or leave it blank.";
var bh_invalid_gateway="Invalid gateway IP address. Please enter it again.";
var bh_bpa_invalid_serv_name="Invalid authentication server IP address.";
var bh_invalid_servip_length="The labels should be 63 characters or less.\n";
var bh_invalid_ip="Invalid IP address. Please enter it again.";
var bh_invalid_mask="Invalid subnet mask. Please enter it again.\n";
var bh_same_subnet_ip_gtw="The IP address and gateway IP address must be in the same subnet.\n";
var bh_same_lan_wan_subnet="The LAN IP address and WAN IP address must not be in the same subnet.";
var bh_filename_null="File name cannot be blank.";
var bh_not_correct_file="Please assign the correct file. The file format is *.";
var bh_ask_for_restore="Warning! \nRestoring settings from a configuration file will erase all of the current settings. \nAre you sure you want to do this?";
var bh_invalid_primary_dns="Invalid primary DNS address. Please enter it again.\n";
var bh_invalid_second_dns="Invalid secondary DNS address. Please enter it again.\n";
var hb_invalid_third_dns="Invalid third DNS address. Please enter it again.\n";
var bh_dns_must_specified="DNS address must be specified.";
var bh_invalid_mac="Invalid MAC address.";
var bh_failure_head="Failure";
var bh_few_second="This screen will automatically return to the previous screen in a few seconds...";

var bh_important="Important Update";
var bh_wanlan_conflict_info="To avoid a conflict with your Internet Service Provider, your router's IP address has been updated to ";
var bh_continue_mark="Continue";
var router_setting_list="Router Settings:";
var copy_router_setting="Do you want to copy router setting? ";
var hijack_announcement_1="The Wireless Wizard Setup found a NETGEAR router with the below settings. You can apply the same settings to the ";
var hijack_announcement_2="to make it a wireless extended for your router, or you can change the settings to create a separate wireless networks.";
var no_device_det_1 = "NETGEAR genie is not able to get existing wireless network information.";
var no_device_det_2 = "Do you want NETGEAR genie to check again?";
var no_security = " Security Type Null " ;
var wlan_mark="Wireless Settings";
var wireless_net_det="Existing Wireless Network Detected";

//readySHARE remote strings
var remote_share_head="ReadySHARE Cloud"

var ready_share_info1="The ReadySHARE Cloud feature gives you remote access over the Internet to a USB storage device that is connected to your router's USB port"
var how_setup_ready_share="How to Set Up ReadySHARE Cloud"
var ready_share_step1="Step 1: You need a ReadySHARE Cloud account. If you do not have one, <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>click here</a> to get one."
var ready_share_step2="Step 2: On this page, enter your ReadySHARE Cloud user name and password to register your router and the USB device that is connected to it with your account."
var ready_share_step3="Step 3: Log back into <a class='linktype' target='_blank' href='http://readyshare.netgear.com/'>http://readyshare.netgear.com</a> with your account. You should see the USB device that is connected to your router."
var ready_share_step4="Step 4: The first time, you are asked to download a Windows client, which is used to make a secure connection from your PC to the router's USB device. Log into this client and you can access the USB device from anywhere."
var ready_share_set_note="<b>Note:</b> Without this client, you can browse your USB device contents but you cannot open files or make changes to them."
var ready_share_start="Start now to enable ReadySHARE Cloud"
var ready_share_get_account="if you don't have a ReadySHARE Cloud account <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>click here</a> to get one."
var username="Username"
var key_passphrase="Password"
var register="Register"
var register_note="<b>Note</b>: Internet will be kept active until unregistered."
var help_center="Help Center"
var help_show_hide="Show/Hide Help Center"

var resister_user="ReadySHARE Cloud is registered with user"
var access_storage_method="You can follow step 2~4 above to access the storage from anywhere."
var unregister_info="Click <b>Unregister</b> to register ReadySHARE Cloud with a different user."
var unregister="Unregister"

var result_register_ok="Registration completed successfully"
var result_register_fail="Registration failed"
var result_unreg_ok="Unregistration completed successfully"
var result_unreg_fail="Unregistration failed"

//for wireless check string
var wps_in_progress="WPS process is in progress, please apply the changes later."
var ssid_null="SSID cannot be blank."
var ssid_not_allowed_same="The SSID is duplicate, please change to another one."
var ssid_not_allowed="Character is not allowed in SSID."
var SWSW11="WPS requires SSID broadcasting in order to work. If you make this change, WPS will become inaccessible. Do you want to continue?"
var SWSW12="Are you sure that you do not want any wireless security on your network? This setting is typically used for wireless hot spots that are open to public access. Do you want to continue?"
var SWSW02="WEP or WPA-PSK [TKIP] security authentication cannot work with WPS. WPS is going to become inaccessible. Do you want to continue?"
var wds_auto_channel="The wireless repeating function cannot be used with Auto Channel.\nPlease change your channel settings before you enable the wireless repeating function."
var notallowpassp="Character is not allowed in passphrase."
var guest_tkip_300_150="WPA-PSK [TKIP] in Guest Network ONLY operates at \"Up to 54Mbps\" (legacy G) mode, not N mode."
var guest_tkip_aes_300_150="NETGEAR recommends that you use WPA2-PSK [AES] in Guest Network to get full N rate support."
var wlan_tkip_aes_300_150="IMPORTANT\nWPA-PSK [TKIP] may only operate at \"Up to 54Mbps\" rate, not N rate.\nNETGEAR recommends that you use WPA2-PSK [AES] to get full N rate support."
var notSupportWLA="Israel and Middle East do not support 802.11a, if you select this, wireless a/n will be shut down, do you want to continue?"
var passphrase_short8="Insufficient passphrase length. It should be a minimum of 8 characters long."
var passphrase_long63="The passphrase is too long. The maximum length is 63 characters."

//SPBU
var SPBU_1="Confirmation:"
var SPBU_2="Confirm the wireless settings."
var SPBU_3="Device new settings"
var SPBU_4="ATTENTION: The unit will restart after you click \"Apply Settings\""
var SPBU_5_bh_back_mark="Back";
var SPBU_6_bh_apply_mark="Apply Settings";
var SPBU_7="WARNING: You have set Opened Network, This is a risk operation mode. Click \"Back\" to change the settings"
var SPBU_8="Applying Settings!"
var SPBU_9="The unit is restarting. Wait about 30 seconds…If you want to connect "
var SPBU_10="wirelessly, re-connect using the new settings:"
var SPBU_11="Click \"<b>Finish</b>\" when your network connection is ready"
var SPBU_12="Finish"
var SPBU_13="As you are connected, your wireless setting were correctly applied. Check your Internet "
var SPBU_14="Gateway connection status., make sure the “Internet” LED is on."
var SPBU_15="Click “Quit” if you want to complete settings wizard without Internet Connection. This windows "
var SPBU_16="will be closed"
var SPBU_17="Range Extender set up successfully!"
var SPBU_18="Your Internet Connection is Ready!"
var SPBU_19="\"WIFI_EXT\" only accepted factory mode. Please <br>select a different Network Name"
var SPBU_20="For “up to full N rate”. Some old device may not <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;support this security mode"
var SPBU_21="WPA-PSK may only operate at <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\"up to G\" rate, not N"
var SPBU_22="Advance Configuration"
var SPBU_23="Exit"
var SPBU_24="Wireless Network Name (SSID)"
var SPBU_25="Wireless Password"
var SPBU_26="Try again";
var SPBU_27="Quit";
var SPBU_28="Name (SSID)";
var SPBU_29="Verifying Internet Connection"
var SPBU_30="Next";
var SPBU_31="You have attempted to leave the installation wizard. Are you sure?";
var SPBU_32="Your browser doesn't support window close function."
var SPBU_33="\"WIFI_EXT\" only  accepted factory  mode. Please select a different Network Name";
var SPBU_34="The installation wizard is incomplete. Will restart on the next browser page opening";
var SPBU_35="Installation wizard will be disable once you enter the advance settings . To re-launch the Installation wizard again, visit http://mywifiext.net";
var SPBU_36="Thank you for using the NETGEAR Web-based Device Configuration Utility. "
var SPBU_37="Goodbye"
var SPBU_38="Logout"