//BRS_01_checkNet.html

var wiz_start_genie_re="Ja.";
var bh_config_wireless_setting="Konfiguration af trådløse indstillinger";
var genie_wireless_set_info="NETGEAR genie har registreret et eksisterende trådløst netværk.";
var select_choice="Vælg dit valg af trådløse indstillinger på enheden:";
var use_router_setting="Brug de samme indstillinger i mit eksisterende trådløse netværk. Dette anbefales.";
var use_manual_setting="Konfiguration af et nyt trådløst netværk: Jeg er indforstået med, at den trådløse enhed skal tilsluttes manuelt til det nye netværk.";
var SWP0011="Bekræftelse:";
var SWP0012="Bekræft trådløse indstillinger, og klik derefter på knappen Næste. Du har i øjeblikket trådløs forbindelse. Når du har klikket på Næste, mister du den trådløse forbindelse. Opret forbindelse igen ved hjælp af de nye indstillinger, og fortsæt derefter konfigurationen.";
var range_ext="Nye enhedsindstillinger:";
var SWP005="Der er ikke fundet nogen internetforbindelse.";
var network_checking="Kontrollerer netværksforbindelsen...";
var wireless_net_det="Eksisterende trådløst netværk registreret";
var quit="Afslut";
var bh_try_again="Prøv igen";
var no_device_det_1 ="NETGEAR genie kan ikke få oplysninger om eksisterende trådløse netværk.";
var no_device_det_2 ="Vil du have NETGEAR genie til at kontrollere igen?";
var wiz_start_manual="Side nr. Jeg vil gerne selv konfigurere de trådløse indstillinger.";
var LPC028="Kontroller internetforbindelsen til din router.";
var sec_phr_g="Adgangskode til trådløs forbindelse";

















var h_wlan="<body bgColor=#0099cc><P><font size=\"4\"><B>Hjalp til tradlost (Wireless)</B></font></P><P><B>BEMARK:</B> For at sikre overensstemmelse med godkendelser og kompatibilitet mellem lignende produkter i dit omrade skal driftskanal og omrade vare indstillet korrekt.. <P><B>Placering af enheden for at optimere tradlos forbindelse</B><P>Din tradlose forbindelses rakkevidde kan variere betydeligt alt efter enhedens fysiske placering. For at opna det bedste resultat skal enheden placeres:<UL><LI>Tat pa midten af det omrade, hvor pc'erne skal benyttes.<LI>Pa et hojt sted, som f.eks. pa en hylde.<LI>Vak fra potentielle interferenskilder, som f.eks. pc'er, mikrobolgeovne og tradlose telefoner.<LI>Vak fra store metaloverflader. </LI></UL><P><B>Bemark:</B> Hvis du ikke folger disse retningslinjer, kan resultatet vare en betydeligt darligere ydeevne, eller at der ikke kan opnas tradlos forbindelse til enheden.</P><HR><A name=network></A><P><B>Tradlost netvark (Wireless Network)</B></P><P>Navn (SSID) (Name (SSID))<P>Angiv en vardi pa op til 32 alfanumeriske tegn. Det samme navn (SSID) skal vare tildelt alle tradlose enheder i dit netvark. Standard-SSID er Netgear_EXT, men NETGEAR anbefaler pa det kraftigste, at du andrer dit netvarks navn (SSID) til en anden vardi. Denne vardi kender forskel pa store og sma bogstaver. NETGEAR er for eksempel ikke det samme som NETGEAr.<P>Region<P>Valg dit omrade fra rullelisten. Dette felt viser den driftsregion, som det tradlose interface er tiltankt. Det er muligvis ikke lovligt at drive enheden i en anden region end den region, der vises her. Hvis dit land eller din region ikke vises pa listen, skal du kontakte dine lokale myndigheder eller se NETGEAR-webstedet for at fa flere oplysninger om, hvilke kanaler du skal bruge.<P>Kanal (Channel)<P> Dette felt afgor, hvilken driftsfrekvens der bruges. Det bor ikke vare nodvendigt at andre den tradlose kanal, medmindre du bemarker interferensproblemer med et andet narliggende access point.</P><P>Tilstand (Mode)</P>Valg den tradlose tilstand, du onsker at bruge. Valgmulighederne er:<UL><LI>Op til 54 Mbps (Up to 54 Mbps). Legacy-tilstand med en maksimal hastighed pa op til 54 Mbps for b/g netvark.<LI>Op til 130 Mbps - Nabovenlig tilstand - Standardhastighed pa op til 130 Mbps under tilstedevarelse af narliggende tradlose netvark.<LI>Op til 300 Mbps - Performance-tilstand med maksimal Tradlose-N-hastighed pa op til 300 Mbps.</LI></UL><P>Standardindstillingen er <b>Op til 145 Mbps</b>, som tillader alle 11b, 11g og 11n tradlose stationer. </P><HR><A name=security></A><p><b>Sikkerhedsindstillinger</b></p><UL><LI>Ingen - ingen datakryptering<LI>WEP - Wired Equivalent Privacy, brug WEP 64- eller 128-bit datakryptering<br><b>Bemark: </b> Funktionen Wi-Fi Protected Setup er deaktiveret, nar indstillingen sikkerhedsindstillingen er WEP- eller WPA-PSK [TKIP]-godkendelse.<LI>WPA-PSK [TKIP] - Wi-Fi Protected Access med forhandsdelt nogle, brug WPA-PSK-standardkryptering med TKIP-krypteringstypen<LI>WPA2-PSK [AES] - Wi-Fi Protected Access version 2 med forhandsdelt nogle, brug WPA2-PSK-standardkryptering med krypteringstypen AES<LI>WPA-PSK [TKIP] + WPA2-PSK [AES] - Tillad klienter, der bruger enten WPA-PSK [TKIP] eller WPA2-PSK [AES].</LI></UL><p>For at opna den bedste ydelse med NETGEAR WN511B eller andre tradlose adaptere i robuste sikkerhedsnetvark anbefaler NETGEAR, at du andrer dit XWN5001 netvarks sikkerhedsindstilling til WPA2-PSK.</p><HR><A name=wep></A><p><b>Sikkerhedskryptering (WEP)  </b></p><P>Godkendelsestype <p>Normalt kan man anvende standardvardien Automatisk. Hvis dette fejler, valg den relevante vardi - \"Open System\" (Abent system) eller \"Shared Key\" (Delt nogle). Tjek dokumentationen for dit tradlose kort for at se hvilken metode der anvendes.tvark med Delt nogle.<p>Krypteringsstyrke <p>Valg krypteringsniveauet WEP: <UL><LI>64-bit (somme tider kaldet 40-bit) kryptering <LI>128-bit kryptering </LI></UL><HR><A name=wepkey></A><p><b>Sikkerhedskrypteringsnogle (WEP)</b></p><p>Hvis WEP er aktiveret, kan du programmere de fire datakrypteringsnogler manuelt eller automatisk. Disse vardier skal vare identiske pa alle pc'er og adgangspunkter i dit netvark. <p>Automatisk generering af nogle (Adgangskode) <p>Indtast et ord eller en gruppe tegn, der kan udskrives, i boksen Adgangskode, og klik pa knappen Generer for automatisk at konfigurere WEP-noglen eller -noglerne. Hvis krypteringsstyrken er sat til 64 bit, vil hver af de fire noglebokse automatisk blive udfyldt med noglevardier. Hvis krypteringsstyrken er sat til 128 bit,  sa vil kun den valgte WEP-nogleboks automatisk udfyldes med noglevardier.<p>Manuel indtastningstilstand <p>Valg hvilken af de fire nogler, der skal bruges, og indtast de tilsvarende WEP-nogleoplysninger for dit netvark i det valgte noglefelt. <p>For 64-bit WEP - Indtast ti hexadecimale cifre (enhver kombination af 0-9, A-F). <p>For 128-bit WEP - Indtast 26 hexadecimale cifre (enhver kombination af 0-9, A-F). <p>Sorg for at klikke pa Anvend for at gemme dine indstillinger i denne menu.</P><HR><A name=wpa-psk></A><p><b>Sikkerhedskryptering (WPA-PSK)</b></p><p>Hvis dette er valgt, skal du bruge TKIP-kryptering og angive WPA-adgangskoden (netvarksnogle). Indtast et ord eller en gruppe tegn, der kan udskrives, i feltet Adgangskode. Adgangskoden skal besta af enten 8 til 63 ASCII-tegn eller nojagtigt 64 hex-cifre. Et hex-ciffer er et af folgende tegn: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E og F. <p>Sorg for at klikke pa Anvend for at gemme dine indstillinger. </p><HR><A name=wpa2-psk></A><p><b>Sikkerhedskryptering (WPA2-PSK)</b></p><p>WPA2 er en nyere version af WPA. Valg kun dette, hvis alle de tradlose klienter i dit netvark understotter WPA2. Hvis dette er valgt, skal du bruge AES-kryptering og angive WPA-adgangskoden (netvarksnogle). Indtast et ord eller en gruppe tegn, der kan udskrives, i feltet Adgangskode. Adgangskoden skal besta af enten 8 til 63 ASCII-tegn eller nojagtigt 64 hex-cifre. Et hex-ciffer er et af folgende tegn: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E og F. </p><HR><A name=wpa-psk+wpa2-psk></A><p><b>Sikkerhedskryptering (WPA-PSK + WPA2-PSK)  </b></p><p>Denne valgmulighed tillader klienter at bruge enten WPA (med TKIP, udsendelsespakker bruger ogsa TKIP) eller WPA2 (med AES). Hvis dette er valgt, skal krypteringen vare TKIP + AES. WPA-adgangskoden (netvarksnogle) skal ogsa indtastes. For at opna maksimal tradlos ydeevne skal klienter som WN511B tilsluttes til denne enhed ved hjalp af WPA2 (med AES). For klienter, der tilslutter i WPA-PSK (med TKIP), vil den maksimale tradlose hastighed vare 802.11g. Indtast et ord eller en gruppe tegn, der kan udskrives, i feltet Adgangskode. Adgangskoden skal besta af enten 8 til 63 ASCII-tegn eller nojagtigt 64 hex-cifre. Et hex-ciffer er et af folgende tegn: <br>0, 1, 2, ..., 8, 9, A, B, C, D, E og F. <HR><p><b>Sadan gemmes eller annulleres andringer</b></p><p>Klik pa <b>Anvend</b> for at fa dine andringer til at trade i kraft. <br>Klik pa <b>Annuller</b> for at ga tilbage til de forrige indstillinger. </p></body>";

var help_center="Hjælp";
var help_show_hide="Vis/skjul Hjælp";
var sec_wpa_mode="WPA-tilstand:";
var auto_mark="Automatisk";
var guest_wire_iso="Aktiver trådløs isolation";
var adva_wlan_ssid_broadcast="Aktiver SSID-udsendelse";
var cancel_mark="Annuller"
var apply_mark="Anvend";

var wlan_network_mark="Trådløst netværk";
var wlan_mark_ssid="Navn (SSID)";
var wlan_mark_reg="Region";
var wlan_mark_chan="Kanal";
var wlan_mark_mode="Tilstand";
var wlan_mark_gb="b og g";
var wlan_mark_go="kun g";
var wlan_mark_bo="kun b";
var wlan_mark_turbog="Auto 108 Mbps";
var wlan_mode_54="Op til 54 Mbps";
var wlan_mode_65="Op til 65 Mbps";
var wlan_mode_130="Op til 130 Mbps";
var wlan_mode_145="Op til 145 Mbps";
var wlan_mode_150="Op til 150 Mbps";
var wlan_mode_300="Op til 300 Mbps";
var wlan_wlacl="Oversigt over adgang med trådløse kort";
var wir_wning = "Efter Wi-Fi Alliances retningslinjer for sameksistens af 40 MHz 20 MHz kan dit produkts ydelseshastighed falde til 20 MHz, selv om du vælger tilstanden \'Op til %s Mbps\'. Dette svarer typisk til en ydelse på %s Mbps.";

var sec_type="Sikkerhedsindstillinger";
var sec_off="Ingen";
var sec_wep="WEP";
var sec_wpa="WPA-PSK (TKIP)";
var sec_wpa2="WPA2-PSK (AES)";
var sec_wpas="WPA-PSK (TKIP) + WPA2-PSK (AES)";
var sec_pr_wpa="Sikkerhedsindstillinger (WPA-PSK)";
var sec_pr_wpa2="Sikkerhedsindstillinger (WPA2-PSK)";
var sec_pr_wpas="Sikkerhedsindstillinger (WPA-PSK + WPA2-PSK)";
var sec_auth="Godkendelsestype";
var sec_auto="Automatisk";
var sec_share="Delt nøgle";
var sec_enc="Krypteringsstyrke";
var sec_64="64-bit";
var sec_128="128-bit";
var sec_enc_head="Sikkerhedskryptering (WEP)";
var sec_key="Sikkerhedskrypteringsnøgle (WEP)";
var sec_key1="Nøgle 1";
var sec_key2="Nøgle 2";
var sec_key3="Nøgle 3";
var sec_key4="Nøgle 4";
var sec_phr="Adgangskode";
var sec_863_or_64h="(8–63 tegn eller 64 hex-cifre)";
var wep_or_wps="WEP-sikkerhed med automatisk godkendelse af delt nøgle fungerer ikke med WPS. WPS vil ikke være tilgængeligt. Ønsker du at fortsætte?";
var wep_just_one_ssid="The WEP security can only be supported on one SSID of each band";

var bh_internet_checking="Kontrol af internetforbindelsen; vent ...";

var SB011="Hvis du har eksisterende trådløse indstillinger, der anvendes af alle klientenheder, kan du <font id=\"a\" onclick=\"click_here();\">click here</font> for at opdatere de forudindstillede indstillinger til den eksisterende.";

//BRS_02_genieHelp.html
var bh_config_net_connection="Konfigurerer internetforbindelsen";

var bh_connection_further_action="Du er endnu ikke tilsluttet til internettet.";

var bh_want_genie_help="Ønsker du, at NETGEAR Genie skal hjælpe?";

var bh_yes_mark="Ja";

var bh_no_genie_help="Nej, jeg vil selv konfigurere internetforbindelsen.";

var bh_no_genie_help_confirm="Det kræver erfaring med netværk at konfigurere internetforbindelsen. Er du sikker?"

var bh_have_saved_copy="Jeg har gemt routerens indstillinger i en fil, og jeg vil gendanne routerens indstillinger til disse indstillinger."

var bh_next_mark="Næste";


//BRS_03A_detcInetType.html
var bh_detecting_connection="Registrerer internetforbindelsen";

var bh_plz_wait_process="Denne proces kan tage et minut eller to, vent venligst...";


//BRS_03A_A_noWan.html
var bh_no_cable="Der er ikke tilsluttet et Ethernet-kabel til routerens internetport";

var bh_wizard_setup_nowan_check="Sørg for, at kablet er sikkert tilsluttet til både porten på bredbåndsmodemmet og routerens internetport.";

var bh_click_try_again="Når du har kontrolleret Ethernet-kablet, skal du klikke på <b>Prøv igen</b>.";

var bh_try_again="Prøv igen";


//BRS_03A_B_pppoe.html
var bh_pppoe_connection="PPPoE DSL-internetforbindelse registreret";

var bh_enter_info_below="Indtast de nødvendige oplysninger nedenfor.";

var bh_pppoe_login_name="Brugernavn";
var bh_ddns_passwd="Adgangskode";


//BRS_03A_B_pppoe_reenter.html
var bh_ISP_namePasswd_error="Forkert ISP-brugernavn eller adgangskode";

var bh_enter_info_again="Indtast de nødvendige oplysninger igen.";


//BRS_03A_C_pptp.html
var bh_pptp_login_name="Login";

var bh_pptp_connection="PPTP-internetforbindelse registreret";

var bh_basic_pptp_servip="Serveradresse";

var bh_sta_routes_gtwip="Gateway-IP-adresse";

var bh_basic_pptp_connection_id="Forbindelses-id/Navn";

//BRS_03A_F_l2tp.html
var bh_l2tp_connection="L2TP Internet Connection Detected";

//BRS_03A_D_bigpond.html
var bh_bpa_connection="BigPond-internetforbindelse registreret"; 

var bh_basic_bpa_auth_serv="Godkendelsesserver";

var bh_basic_pppoe_idle="Timeoutgrænse for inaktivitet (i minutter)";


//BRS_03A_E_IP_problem_staticIP.html
var bh_no_internet_ip="Problem med registrering af internetforbindelsen";

var bh_no_internet_ip2="Problem med registrering af internetforbindelsen - IP-adresse";

var bh_no_internet_ip3="Problem med registrering af internetforbindelsen - MAC-adresse";

var bh_if_have_static_ip="Tildelte din internetudbyder (ISP) dig en fast (statisk) IP-adresse? Det er en <b>meget sjælden</b> særlig implementering. ";

var bh_yes_correct="Ja. Min ISP tildelte mig en fast (statisk) IP-adresse.";

var bh_not_have_static_ip="Nej, jeg har ikke fået en fast (statisk) IP-adresse fra min internetudbyder.";

var bh_do_not_know="Det ved jeg ikke. ";

var bh_select_option="Vælg en indstilling og klik på <b>Næste</b> for at fortsætte.";

var bh_select_an_option="Vælg en indstilling først.";


//BRS_03A_E_IP_problem_staticIP_A_inputIP.html
var bh_fix_ip_setting="Faste IP-indstillinger på internettet";

var bh_enter_ip_setting="Indtast de faste IP-indstillinger, der er tildelt af din internetudbyder, og klik på <b>Næste</b> for at fortsætte.";

var bh_info_mark_ip="IP-adresse";
//var bh_info_mark_ip="Min IP-adresse";
var bh_info_mark_mask="Subnetmaske";

var bh_constatus_defgtw="Standard gateway";

var bh_preferred_dns="Foretrukket DNS-server";

var bh_alternate_dns="Alternativ DNS-server";

var bh_basic_int_third_dns="Tredje DNS";

//BRS_03A_E_IP_problem.html
var bh_genie_cannot_find_ip="Det skyldes sandsynligvis en af følgende årsager:";
var bh_genie_cannot_find_ip_reason1="1.  Der blev ikke tændt og slukket for modemet under kabelføringstrinnet.";
var bh_genie_cannot_find_ip_reason1_desc="For at løse dette problem, skal du tænde og slukke modemet. For at tænde og slukke et modem med batteribackup skal du måske fjerne og genindsætte dets batteri. Efter at der er tændt og slukket skal du vente i to minutter på, at modemet starter igen."; 
var bh_genie_cannot_find_ip_reason2="2.  Det gule Ethernet-kabel er ikke sat helt i, eller det er sat i det forkerte sted.";
var bh_genie_cannot_find_ip_reason2_desc="For at løse dette problem skal du kontrollere, at det gule Ethernet-kabel er sat helt i bredbåndsmodemporten og routerens internetport.";

var bh_select_no_IP_option="Vælg en af indstillingerne herunder og klik på <b>Næste</b> for at fortsætte:";
var bh_select_no_IP_option1="Jeg har lige tændt og slukket modemet og ventet i 2 minutter.";
var bh_select_no_IP_option2="Jeg rettede et problem med Ethernet-kablet.";
var bh_select_no_IP_option3="Ingen af disse.";


//BRS_03A_E_IP_problem_staticIP_B_macClone.html
var bh_use_pc_mac="Hvis du tidligere tilsluttede til din internettjeneste med en computer eller en anden router,  kan NETGEAR Genie bruge den samme MAC-adresse, som tidligere har fungeret.";

var bh_mac_in_product_label="En MAC-adresse er et entydigt nummer.  Du kan finde computerens eller routerens MAC-adresse på produktetiketten.";

var bh_enter_mac="Indtast MAC-adressen her.";

var bh_mac_format="(format AABBCCDDEEFF)";


//BRS_03B_haveBackupFile.html
var bh_settings_restoration="Gendan routerindstillinger";

var bh_browser_file="Gå til backupfilen med routerindstillinger, som du tidligere har gemt, og klik på <b>Næste</b> for at fortsætte.";

var bh_back_mark="Tilbage";


//BRS_03B_haveBackupFile_fileRestore.html
var bh_settings_restoring="Gendanner routerindstillinger"; 

var bh_plz_waite_restore="Denne proces kan tage nogle minutter; vent …";


//BRS_04_applySettings.html
var bh_apply_connection="Anvender indstillinger for internetforbindelse";

var bh_plz_waite_apply_connection="Denne proces kan tage et minut eller to, vent venligst...";


//BRS_05_networkIssue.html
var bh_netword_issue="Problem med netværksforbindelse";

var bh_cannot_connect_internet="Routeren kan ikke opnå forbindelse til internettet med de aktuelle indstillinger.";

var bh_plz_reveiw_items="Kontroller følgende elementer:";

var bh_cable_connection="- Kontroller, at kabelforbindelserne er korrekte. Se installationsvejledningen til routeren for at få instruktioner.";

var bh_modem_power_properly="- Kontroller, at der er tændt og slukket korrekt for dit bredbåndsmodem. Hvis du har et modem med batteribackup, skal du fjerne og genindsætte batteriet for at tænde og slukke for dit modem.";

var bh_try_again_or_manual_config="Ønsker du, at NETGEAR Genie skal forsøge igen?";

var bh_I_want_manual_config="Nej. Jeg vil selv konfigurere internetforbindelsen."; 

var bh_manual_config_connection="Jeg vil selv konfigurere internetforbindelsen.";


//BRS_success.html
var bh_congratulations="Tillykke!";

var bh_connect_success_1="Du har nu oprettet forbindelse til internettet."

var bh_connect_success_2="Denne router er forudindstillet med det følgende entydige trådløse netværksnavn (SSID) og ";

var bh_network_key="netværksnøgle (adgangskode)";

var bh_rollover_help_text="Din router er forudindstillet med WPA2-PSK trådløs sikkerhed til at beskytte dit netværk mod uønsket adgang. For at få adgang til det trådløse netværk skal du indtaste netværksnøglen (adgangskoden). Disse forudindstillede indstillinger er entydige på denne enhed, som et serienummer.  Hvis du vil ændre dem, kan du gøre det senere på skærmen Trådløse indstillinger i routerens brugergrænseflade."; 

var bh_success_no_wireless_security_1 = "Trådløs sikkerhed er ikke aktiveret på denne router. NETGEAR anbefaler kraftigt, at du ";
var bh_success_no_wireless_security_2 = "klik her";
var bh_success_no_wireless_security_3 =  " for at aktivere trådløs sikkerhed og beskytte dit netværk.";

var bh_wirless_name="Navn på trådløst netværk (SSID)"

var bh_wireless="Trådløs";

var bh_wpa_wpa2_passpharse="Netværksnøgle (adgangskode)"; 

var bh_save_settings="Save router settings";

var bh_print_this="Udskriv dette";


var bh_take_to_internet="Tag mig til internettet";

var bh_plz_wait_moment="Vent et øjeblik...";

//the string for not_support_print is temporary.
var bh_not_support_print="Computeren understøtter ikke en printer.";
//already exist
var bh_login_name_null="Brugernavn må ikke være tomt.";
var bh_password_error="Ugyldig adgangskode.";
var bh_idle_time_null="Indtast tomgangstid.\n";
var bh_invalid_idle_time="Ugyldig tomgangstid. Indtast et korrekt nummer.\n";
var bh_invalid_myip="Ugyldig IP-adresse. Indtast den igen, eller lad feltet stå tomt.";
var bh_invalid_gateway="Ugyldig gateway-IP-adresse. Indtast den igen.";
var bh_bpa_invalid_serv_name="Ugyldig godkendelse af servers IP-adresse.";
var bh_invalid_servip_length="Etiketten skal være på 63 tegn eller mindre.\n";
var bh_invalid_ip="Ugyldig IP-adresse. Indtast den igen.";
var bh_invalid_mask="Ugyldig undernetmaske. Indtast den igen.\n";
var bh_same_subnet_ip_gtw="IP-adressen og gateway-IP-adressen skal være i samme undernet.\n";
var bh_same_lan_wan_subnet="LAN-IP-adressen og WAN-IP-adressen må ikke være i samme undernet.\n";
var bh_filename_null="Filnavn må ikke være tomt.";
var bh_not_correct_file="Tildel den korrekte fil. Filformatet er *.";
var bh_ask_for_restore="Advarsel! \nGendannelse af indstillinger fra en konfigurationsfil vil slette de aktuelle indstillinger. \nEr du sikker på, at du vil fortsætte?";
var bh_invalid_primary_dns="Ugyldig primær DNS-adresse. Indtast den igen.\n";
var bh_invalid_second_dns="Ugyldig sekundær DNS-adresse. Indtast den igen.\n";
var hb_invalid_third_dns="Invalid third DNS address. Please enter it again.\n";
var bh_dns_must_specified="Der skal angives en DNS-adresse.";
var bh_invalid_mac="Ugyldig MAC-adresse.";
var bh_failure_head="Fejl";
var bh_few_second="Skærmen vil automatisk vise det forrige skærmbillede efter et par sekunder…";

var bh_important="Vigtig opdatering";
var bh_wanlan_conflict_info="For at undgå konflikt med din internetudbyder er routerens IP-adresse blevet opdateret til ";
var bh_continue_mark="Fortsæt";
var wlan_mark="Trådløse indstillinger" ;
var wlan_mark_ssid="Navn (SSID)" ;
var sec_type="Sikkerhedsindstillinger";
var sec_off="Ingen";
var sec_wep="WEP";
var sec_wpa="WPA-PSK (TKIP)";
var sec_wpa2="WPA2-PSK (AES)";
var varsec_wpas="WPA-PSK (TKIP) + WPA2-PSK (AES)";
var sec_phr="Adgangskode" ;
//readySHARE remote strings
var remote_share_head="ReadySHARE Cloud"

var ready_share_info1="Funktionen ReadySHARE Cloud giver ekstern adgang via Internettet til en USB-lagringsenhed, der er sluttet til din routers USB-port."
var how_setup_ready_share="Sådan konfigureres ReadySHARE Cloud"
var ready_share_step1="Trin 1: Du har behov for en ReadySHARE Cloud-konto. Hvis du ikke har en <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=enhed'>, skal du klikke her</a> for at få en."
var ready_share_step2="Trin 2: På denne side skal du angive dit ReadySHARE Cloud-brugernavn og -adgangskode for at registrere din router og den USB-enhed, som er sluttet til den med din konto."
var ready_share_step3="Trin 3: Log igen på <a class='linktype' target='_blank' href='http://readyshare.netgear.com/'>http://readyshare.netgear.com/</a> med din konto. Du bør kunne se den USB-enhed, som er sluttet til din router."
var ready_share_step4="Trin 4: Første gang bliver du anmodet om at hente en Windows klient, der anvendes til at oprette en sikker forbindelse fra din pc til routerens USB-enhed. Log på denne klient, og du har adgang til USB-enheden fra et vilkårligt sted."
var ready_share_set_note="<b>Bemærk!</b> Uden denne klient kan du gennemse indholdet på din USB-enhed, men du kan ikke åbne filer eller foretage ændringer af dem"
var ready_share_start="Start nu for at aktivere ReadySHARE Cloud"
var ready_share_get_account="Hvis du ikke har en ReadySHARE Cloud-konto, skal du <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>klikke her</a> for at få en"
var username="Brugernavn"
var key_passphrase="Adgangskode"
var register="Registrer"
var register_note="<b>Bemærk!</b> Internet-forbindelsen vil være aktiv, indtil den afregistreres."
var help_center="Hjælp"
var help_show_hide="Vis/skjul Hjælp"

var resister_user="ReadySHARE Cloud se registra con un usuario"
var access_storage_method="Du kan følge trin 2~4 ovenfor for at få adgang til lageret overalt."
var unregister_info="Klik på <B>Afregistrer</B> for at registrere ReadySHARE Cloud med en anden bruger."
var unregister="Afregistrer"

var result_register_ok="Registreringen er udført"
var result_register_fail="Registreringen mislykkedes"
var result_unreg_ok="Afregistreringen er udført"
var result_unreg_fail="Afregistreringen mislykkedes"



//for wireless check string
var wps_in_progress="WPS-processen er i gang, anvend ændringerne senere."
var ssid_null="SSID må ikke være tom."
var ssid_not_allowed="Tegnet er ikke tilladt i SSID"
var ssid_not_allowed_same="SSID'et er duplikeret. Skift til et andet."
var SWSW02="WEP- eller WPA-PSK [TKIP]-sikkerhedsgodkendelse fungerer ikke med WPS. WPS vil blive utilgængelig. Ønsker du at fortsætte?"
var SWSW11="WPS kræver SSID-udsendelse for at fungere. Hvis du ændre dette, vil WPS blive utilgængelig. Ønsker du at fortsætte?"
var SWSW12="Er du sikker på, at du ikke vil have trådløs sikkerhed på dit netværk? Denne indstilling bruges typisk til trådløse hotspots, som er åbne for offentlig adgang. Ønsker du at fortsætte?"
var wds_auto_channel="Den trådløse gentagende funktion kan ikke benyttes sammen med Auto Channel.\nÆndr kanalindstillingerne, før du aktiverer den trådløse gentagende funktion. "
var notallowpassp="Tegnet er ikke tilladt i adgangskoden."
var guest_tkip_300_150="WPA-PSK [TKIP] i gæstenetværk virker KUN i tilstanden \"Op til 54Mbps\" (legacy G), ikke i N-tilstand."
var guest_tkip_aes_300_150="NETGEAR anbefaler, at du bruger WPA2-PSK [AES] i gæstenetværk for at få fuld understøttelse af N-hastighed."
var wlan_tkip_aes_300_150="VIGTIGT\nWPA-PSK [TKIP] fungerer muligvis kun ved hastigheden \"Op til 54Mbps\", ikke N-hastighed.\nNETGEAR anbefaler, at du bruger WPA2-PSK [AES] til at få fuld understøttelse af N-hastighed."
var notSupportWLA="Israel og mellemøsten understøtter ikke 802.11a, så hvis du vælger dette, lukkes trådløs a/n ned. Vil du fortsætte?"
var passphrase_short8="Adgangskoden er for kort. Den skal være på mindst 8 tegn."
var passphrase_long63="Adgangskoden er for lang. Den må maks. være på 63 tegn!"
