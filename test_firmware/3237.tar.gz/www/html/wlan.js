/*
function chgCh(from)
{   
    if ( from == 2 )
    {
        var cf = document.forms[0];
        //cf.only_mode.value = "1";
        //cf.submit();
		setChannel();
    }
    else
    {
        setwlan_mode();
        setChannel();
    }
}

function setwlan_mode()
{
	var cf = document.forms[0];
	var index = cf.wlan_coun.selectedIndex;
	var currentMode = cf.wlan_mode.selectedIndex;

	if (index == 7 || index == 8) {
		cf.wlan_mode.options.length = 2;
		cf.wlan_mode.options[0].text = "Up to 54Mbps";
		cf.wlan_mode.options[1].text = "Up to 145Mbps";
		cf.wlan_mode.options[0].value = "1";
		cf.wlan_mode.options[1].value = "2";
		if (currentMode <= 1)
			cf.wlan_mode.selectedIndex = currentMode;
		else
			cf.wlan_mode.selectedIndex = 1;
	} else {
		cf.wlan_mode.options.length = 3;
		cf.wlan_mode.options[0].text = "Up to 54Mbps";
		cf.wlan_mode.options[1].text = "Up to 65Mbps";
		cf.wlan_mode.options[2].text = "Up to 150Mbps";
		cf.wlan_mode.options[0].value = "1";
		cf.wlan_mode.options[1].value = "2";
		cf.wlan_mode.options[2].value = "3";
		cf.wlan_mode.selectedIndex = currentMode;
	}
	return;
}
*/
function setChannel()
{
	var cf = document.forms[0];
	var index = cf.wlan_coun.selectedIndex;
	var chIndex = cf.wlan_chan.selectedIndex;
	var currentMode = cf.wlan_mode.selectedIndex;
	var endChannel;

	//alert(currentMode+" "+index);
/*
	if ( currentMode == 2 && (index == 4 || index == 9 || index == 11 ))
		endChannel = 7;	
	else if ( currentMode == 2 )
		endChannel = 9;
	else
*/
//	if( currentMode == 2)
//		endChannel = 7;
//	else
		endChannel = FinishChannel[index];
	
	if (FinishChannel[index]==14 && cf.wlan_mode.selectedIndex!=0)
		cf.wlan_chan.options.length = endChannel - StartChannel[index];
	else
		cf.wlan_chan.options.length = endChannel - StartChannel[index] + 2;

	cf.wlan_chan.options[0].text = "Auto";
	cf.wlan_chan.options[0].value = 0;

	for (var i = StartChannel[index]; i <= endChannel; i++) {
		if (i==14 && cf.wlan_mode.selectedIndex!=0)
			continue;
		cf.wlan_chan.options[i - StartChannel[index] + 1].value = i;
		cf.wlan_chan.options[i - StartChannel[index] + 1].text = (i < 10)? "0" + i : i;
	}
	cf.wlan_chan.selectedIndex = ((chIndex > -1) && (chIndex < cf.wlan_chan.options.length)) ? chIndex : 0 ;
}


function check_wlan()
{
	var cf=document.forms[0];
        var ssid = document.forms[0].wlan_ssid.value;
        var space_flag=0
		if(ssid == "")
        {
                alert(ssid_null);
                return false;
        }
        //if(ssid.toLowerCase() == "any")
        //{
        //        alert(ssid + ssid_not_allowed);
        //        return false;
        //}
		for(i=0;i<ssid.length;i++)
        {
                if(isValidChar_space(ssid.charCodeAt(i))==false)
                {
                        alert(ssid + ssid_not_allowed);
                        return false;
                }
        }
	    for(i=0;i<ssid.length;i++)
        {
            	if(ssid.charCodeAt(i)!=32)
                	space_flag++;
        }
		if(space_flag==0)
		{
			alert(ssid_null);
        	return false;

		}
	if(cf.wlan_coun.selectedIndex == 0)
	{
		alert(coun_select);
		return false;
	}		
	if ( wds_endis_fun == 1 )
	{
		if ( cf.wlan_chan.selectedIndex == 0 )
		{
			alert("Auto Channel cannot be used with Wireless Repeating Function.");
			return false;
		}
	}
	if(cf.sec_type[1].checked == true)
	{
		if( checkwep(cf)== false)
			return false;
		cf.hidden_sec_type.value=2;
	}
	else if(cf.sec_type[2].checked == true)
	{
		if( checkpsk(cf)== false)
			return false;
		cf.hidden_sec_type.value=3;
		cf.hidden_wpa_psk.value = cf.sec_wpaphrase.value.replace(/\ /g, "&nbsp;");
	}
	else if(cf.sec_type[3].checked == true)
	{
		if( checkpsk(cf)== false)
			return false;
		cf.hidden_sec_type.value=4;
		cf.hidden_wpa_psk.value = cf.sec_wpaphrase.value.replace(/\ /g, "&nbsp;");
	}	
	else if(cf.sec_type[4].checked == true)
	{
		if( checkpsk(cf)== false)
			return false;
		cf.hidden_sec_type.value=5;
		cf.hidden_wpa_psk.value = cf.sec_wpaphrase.value.replace(/\ /g, "&nbsp;");
	}	
	else
		cf.hidden_sec_type.value=1;
	/*if ( cf.wlan_mode.selectedIndex == 2 )
	{
		cf.hidden_wlan_mode.value = cf.wlan_width.value;
	}
	else*/
		cf.hidden_wlan_mode.value = cf.wlan_mode.value;
	if ( (ssid != old_ssid) || (cf.hidden_sec_type.value != old_sectype) )
		cf.wps_change_flag.value = 5;
	return true;	
}
