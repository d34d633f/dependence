PRE_LANGUAGE_TABLE=/tmp/pre_language_table
IMPORT_LANGUAGE_TABLE=/tmp/language_table.tar.gz
config_change()
{
	#$nvram set Enable_GUIStringTable=$1
	echo "$1" > /tmp/b
	jp_multi=$($nvram get jp_multiPPPoE)

	$nvram set GUI_Region=$1
	$nvram set run_refresh="yes"
	# if switch to Japanese, open multiPPPoe value, 1 for up, 0 for dow.
	#config_mp_status "$1"
	if [ "$jp_multi" = "1" ];then
		$nvram set jp_multiPPPoE=0
		$nvram set internet_ppp_type=0
        fi

}
config_mp_status()
{
	    $nvram set jp_multiPPPoE=0
		$nvram set internet_ppp_type=0
	#a=$($nvram get jp_multiPPPoE)
	#echo "jp_multiPPPoE=$a" > /tmp/a
}
config_not_jp()
{
	$nvram set jp_multiPPPoE=0
}
language_table_upgrade()
{
	local offset=0
        [ "$1" != "" ] && offset=$1
        dd if=$PRE_LANGUAGE_TABLE of=$IMPORT_LANGUAGE_TABLE bs=1 skip=$offset
	/bin/rm -rf $PRE_LANGUAGE_TABLE
	/sbin/language_table save
	/sbin/language_table reload
	sleep 1
}

setRegion()
{
	case "$1" in
		English | German | Russian | Spanish | Polish | French | Italian | Swedish | Danish | Dutch | Greek | Norwegian | Czech | Slovenian | Portuguese | Hungarian | Romanian | Finnish | Slovak)
			$nvram set wl_country=4
			$nvram set wl_country_code=4
		;;
		Chinese)
			$nvram set wl_country=1
			$nvram set wl_country_code=1
		;;
		Korean)
			$nvram set wl_country=7
			$nvram set wl_country_code=7
		;;
		*)
			$nvram set wl_country=4
			$nvram set wl_country_code=4
		;;
	esac
	$nvram set wl_hidden_channel=0
	$nvram set wl_simple_mode=2
}
