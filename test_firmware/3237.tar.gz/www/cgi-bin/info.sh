show_mode() 
{
	case "$1" in
		3)
			echo -n wlan_mode_300
		;;
		2)
			echo -n wlan_mode_145
		;;
		1)
			echo -n wlan_mode_54
		;;
	        4)
		    	echo -n wlan_mode_300
		;;
        	5)
            		echo -n wlan_mode_300
	        ;;	
		6)
			echo -n wlan_mode_300
		;;	
		*)	
			echo -n wlan_mode_54
		;;
	esac
}

show_on_off()
{
	case "$1" in
		0)
			echo -n off_mark
			;;
		1)
			echo -n on_mark
			;;
		*)
			echo -n off_mark
			;;
	esac 
}
show_wps()
{
	case "$1" in
		1)
			echo -n "not_configured"
		;;
		5)
			echo -n "configured"
		;;
		*)
			echo -n "not_configured"
		;;
	esac	
}
show_region() #$1: country number
{
    case "$1" in
        0)
            echo -n coun_af
            ;;
        1)
            echo -n coun_as
            ;;
        2)
            echo -n coun_au
            ;;
        3)
            echo -n coun_ca
            ;;
        4)
            echo -n coun_eu
            ;;
        5)
	    	echo -n coun_is
	    ;;
        6)
            echo -n coun_jp
            ;;
        7)
            echo -n coun_ko
            ;;
	8)
            echo -n coun_mx
            ;;
        9)
            echo -n coun_sa
            ;;
        10)
            echo -n coun_us
            ;;
	11)
	    echo -n coun_middle_east
	    ;;
        *)    
	    echo -n coun_eu
            ;;
    esac
}

show_enc()
{
    case "$1" in
        2)
            echo -n r_wep
            ;;
        3)
            echo -n r_wpa
            ;;
        4)
            echo -n r_wpa2
            ;;
        5)
            echo -n r_wpas
            ;;
        *)
            echo -n r_off
            ;;
    esac
}
show_channel() #$1 for info_get_channel, $2 for gmode
{
	local pri_channel sec_channel tmp_channel
	if [ "$2" -eq 3 -o "$2" -eq 4 -o "$2" -eq 5 -o "$2" -eq 6 ];then
		if [ "$1" = 0 ];then
			tmp_channel=$(iwlist ath0 channel | grep "Frequency" | awk '/Channel/{print $5}' | awk -F"\)" '{print $1}')
		else
			tmp_channel=$1
		fi
		if [ "x$tmp_channel" != "x" ];then
			if [ "$tmp_channel" -le 6 ];then
				pri_channel=$tmp_channel
				sec_channel=$(($tmp_channel+4))
			else
				pri_channel=$tmp_channel
				sec_channel=$(($tmp_channel-4))
			fi	
			if [ "$1" = 0 ];then	
				echo -n "Auto( $pri_channel(p)+$sec_channel(s) )"		
			else
				echo -n "$pri_channel(p) + $sec_channel(s)"
			fi
		else
			echo -n "--"
		fi
	else
		if [ "$1" = 0 ];then
			tmp_channel=$(iwlist ath0 channel | grep "Frequency" | awk '/Channel/{print $5}' | awk -F"\)" '{print $1}')
			if [ "x$tmp_channel" != "x" ];then
				echo -n "Auto($tmp_channel)"
			else
				echo -n "--"
			fi
		else
			echo -n "$1"
		fi
	fi	
}

config_show_statistic()
{
	$nvram set timereset="$1"
}
