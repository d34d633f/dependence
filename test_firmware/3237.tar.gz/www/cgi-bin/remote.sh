config_remote()
{
	$nvram set remote_endis=$1
	$nvram set remote_access="$2"
	$nvram set remote_iplist="$3"
	$nvram set remote_port=$4
	#$nvram set endis_telnet=$5
	$nvram set forfirewall="remote_management"
}
