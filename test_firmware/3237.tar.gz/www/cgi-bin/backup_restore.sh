#!/bin/sh
MODULE_NAME=$(cat /module_name)
MODULE_VERSON=$(cat /firmware_version)
MODULE_REGION=$(cat /firmware_region)
TMP_CONF_FILE="/tmp/tmp_configs_file"
TMP_FILE="/tmp/AABBCCXXYY"
CONFIG_LRP="/tmp/configs.tar.gz"
CONFIG_DIR="/tmp/configs"
INFO_FILE="/tmp/config.info"
CONFIG_MTD_LOCK="/tmp/config-mtd.lock"
CONFIG_IMG_FILE="/tmp/NETGEAR_$MODULE_NAME.cfg"

generate_config_file_bin()
{
	#lockfile $CONFIG_MTD_LOCK
	cd /tmp
	rm -f $CONFIG_LRP >/dev/null 2>&1
	. /www/cgi-bin/encrypt.sh
	tar -cf configs.tar.gz configs/*
	generate_info
	cat $INFO_FILE $CONFIG_LRP > $CONFIG_IMG_FILE
	rm -rf $CONFIG_LRP $INFO_FILE
	append_check $CONFIG_IMG_FILE
	. /www/cgi-bin/encrypt.sh
	#rm -f $CONFIG_MTD_LOCK $CONFIG_IMG_FILE 
}

generate_info()
{
        local pad_size info_length
        rm -f $INFO_FILE
        echo "device:NETGEAR_$MODULE_NAME.cfg" > $INFO_FILE
        echo "version:$MODULE_VERSON" >> $INFO_FILE
        echo "region:$MODULE_REGION" >> $INFO_FILE
	
	tmp_path=$(echo $INFO_FILE | sed 's/\//\\\//g')
        [ -f $INFO_FILE ] && info_length=$(wc -c $INFO_FILE | sed "s/$tmp_path//")
        pad_size=$(( 128 - $info_length  ))
        dd if=/dev/zero bs=1 count=$pad_size >> $INFO_FILE  2>/dev/null
}

append_check() # $1 is the file need to add checksum
{
        local ret_value=0

	check_var=$(/sbin/checksum -i "$1" | sed 's/checksum = //' | sed 's/,.*//')
        if [ "$check_var" != "0x00" ]; then
                hex2int_var=$(printf "%03o\n" $check_var)
                echo -n -e '\'$hex2int_var >> "$1"
        else
                dd if=/dev/zero bs=1 count=1 >> $tmp_file 2>/dev/null
		ret_value=100
        fi

        return $ret_value
}

