config_wlan() #$1:ssid $2:broadcast 1--enable 0--disable
              #$3:country 0~11 $4:channel $5:mode 0--b 1--auto 2--g $6:rate 0~12
{
    local rate_var
    $nvram set wl_ssid="$1"
    $nvram set wl_closed=$2
    $nvram set wl_country=$3
    $nvram set wl_country_code=$3
	$nvram set wl_channel=$4
    $nvram set wl_simple_mode=$5
    case "$6" in
	1)
	    rate_var=1000000
	    ;;
	2)
	    rate_var=2000000
	    ;;
	3)
	    rate_var=5500000
	    ;;
	4)
	    rate_var=11000000
	    ;;
	5)
	    rate_var=6000000
	    ;;
	6)
	    rate_var=9000000
	    ;;
	7)
	    rate_var=12000000
	    ;;
	8)
	    rate_var=18000000
	    ;;
	9)
	    rate_var=24000000
	    ;;
	10)
	    rate_var=36000000
	    ;;
	11)
	    rate_var=48000000
	    ;;
	12)
	    rate_var=54000000
	    ;;
	*)
	    rate_var=auto
	    ;;
    esac
    $nvram set wl_rate=$rate_var
}

config_secoff()
{
    $nvram set wl_sectype=0
}

config_secwep() #$1: authentication 0--mix 1--open 2--share 
                #$2: wep key length 5,13
                #$3: wep key number 1,2,3,4 
                #$4~$7: wep key 1~4
{
    $nvram set wl_sectype=1
    $nvram set wl_auth=$1
    $nvram set key_length=$2
    $nvram set wl_key=$3
    $nvram set wl_key1=$4
    $nvram set wl_key2=$5
    $nvram set wl_key3=$6
    $nvram set wl_key4=$7
    if [ "$2" = "13" ]; then
	$nvram set wep_64_key1=$4
	$nvram set wep_64_key2=$5
	$nvram set wep_64_key3=$6
	$nvram set wep_64_key4=$7
    else
	$nvram set wep_128_key1=$4
        $nvram set wep_128_key2=$5
        $nvram set wep_128_key3=$6
        $nvram set wep_128_key4=$7
    fi
}

config_secwpa() #$1: security type: 2--wpa-psk 3--wpa2-psk 4--wpas-psk
                #$2: passphrase
{
    $nvram set wl_sectype=$1
    if [ $1 -eq 2 ]; then
	$nvram set wl_wpa1_psk="$2"
    elif [ $1 -eq 3 ]; then
	$nvram set wl_wpa2_psk="$2"
    else
	$nvram set wl_wpas_psk="$2"
    fi
}
