config_ether()
{
        #While Parental Control enabled, if use dns from ISP or not use the OpenDNS's dns, then disable Parental Control
        parental_control=$($nvram get ParentalControl)
        if [ "$parental_control" = "1" ];then
                if [ "$7" = "0" ];then
                        $nvram set ParentalControl="0"
                else
                        if [ "$8" = "208.67.222.222" -a "$9" = "208.67.220.220" ];then :          
                        elif [ "$8" = "208.67.220.220" -a "$9" = "208.67.222.222" ];then :
                        else
                                $nvram set ParentalControl="0"
                        fi
                fi
        fi

	$nvram set internet_type="1"
	$nvram set wan_hostname="$1"
	$nvram set wan_domain="$2"
	$nvram set wan_ether_wan_assign=$3
	$nvram set wan_ipaddr=$4
	$nvram set wan_netmask=$5
	$nvram set wan_gateway=$6
	$nvram set wan_ether_dns_assign=$7
	$nvram set wan_ether_dns1=$8
	$nvram set wan_ether_dns2=$9	
	$nvram set wan_ether_mac_assign=${10}
	if [ "${10}" = "2" ];then
		$nvram set wan_ether_this_mac=${11}
	fi
	$nvram set static_conflict=${12}
	if [ $3 -eq 0 ];then
		$nvram set wan_proto="dhcp"	
	else 
		$nvram set wan_proto="static"
	fi
	$nvram set change_wan_type=${13}
	$nvram set run_test="${14}"
}
