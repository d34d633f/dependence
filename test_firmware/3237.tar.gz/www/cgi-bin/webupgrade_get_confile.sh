#!/bin/sh 
. /www/cgi-bin/functions.sh
FIRMWARE_OR_LANGUAGE=$1
. /www/cgi-bin/webupgrade.sh

oc echo "do webupgrade_get_confile" 
oc echo "FIRMWARE_OR_LANGUAGE=$FIRMWARE_OR_LANGUAGE"

prepare_for_upgrade

check_wan_link ()
{
	return 0
}

#if ! check_wan_link ; then
#	giveup_webupgrade_in_download_control_file $STATUS_WAN_LINK_ERROR
#fi

#write_webupgrade_status_of_download_control_file $STATUS_INITIALIZING
write_webupgrade_status_of_download_control_file $STATUS_0_PERCENT
check_webupgrade_cancelled_in_download_control_file
oc rm -f /tmp/$CTL_FILE
if ! oc /bin/snarf "$NETGEAR_SITE_1$CTL_FILE_FULLNAME" "/tmp/$CTL_FILE"; then
	#/sbin/iconv /tmp/$CTL_FILE 
	check_webupgrade_cancelled_in_download_control_file
	write_webupgrade_status_of_download_control_file $STATUS_33_PERCENT
	#if ! oc /bin/snarf "$NETGEAR_SITE_2$CTL_FILE_FULLNAME" "/tmp/$CTL_FILE"; then
		#write_webupgrade_status_of_download_control_file $STATUS_66_PERCENT
		#check_webupgrade_cancelled_in_download_control_file
		#if ! oc /bin/snarf "$NETGEAR_SITE_3$CTL_FILE_FULLNAME" "/tmp/$CTL_FILE"; then
			rm -f /tmp/determine_wan_success
			echo "" > /tmp/determine_wan_fail
			echo "2" > /tmp/language_change_status # 1: No Internet Connection 2: Download failed
			giveup_webupgrade_in_download_control_file $STATUS_DOWNLOAD_ERROR
		#fi
	#fi
fi
/sbin/iconv /tmp/$CTL_FILE
write_webupgrade_status_of_download_control_file $STATUS_100_PERCENT
oc echo "got $CTL_FILE successfully !" 

oc echo "1,FIRMWARE_OR_LANGUAGE=$FIRMWARE_OR_LANGUAGE"

prepare_ctl_file_cln "/tmp/$CTL_FILE" $CTL_FILE_CLN

oc echo "2,FIRMWARE_OR_LANGUAGE=$FIRMWARE_OR_LANGUAGE"

if [ "$FIRMWARE_OR_LANGUAGE" = "language" ];then
	if ! get_ctl_file_language_table_parameters $CTL_FILE_CLN ; then
		echo "2" > /tmp/language_change_status # 1: No Internet Connection 2: Download failed
		giveup_webupgrade_in_download_control_file $STATUS_CONTROL_FILE_ERROR
	fi
else
	if ! get_ctl_file_image_parameters $CTL_FILE_CLN ; then
		giveup_webupgrade_in_download_control_file $STATUS_CONTROL_FILE_ERROR
	fi
fi

oc echo "3,FIRMWARE_OR_LANGUAGE=$FIRMWARE_OR_LANGUAGE"

oc echo "image_file=$g_image_file_fullname"
oc echo "image_file_size=$g_image_file_size"
oc echo "old_version=$g_image_ver_old"
oc echo "new_version=$g_image_ver_new"
oc echo "language_old_version=$g_language_ver_old"
oc echo "language_new_version=$g_language_ver_new"

if [ "$FIRMWARE_OR_LANGUAGE" = "language" ];then
	if ! is_newer $g_language_ver_new $g_language_ver_old ; then
		giveup_webupgrade_in_download_control_file $STATUS_NO_NEWER_VER_ERROR
	fi	
else	
	if ! is_newer $g_image_ver_new $g_image_ver_old ; then
		giveup_webupgrade_in_download_control_file $STATUS_NO_NEWER_VER_ERROR
	fi
fi	

write_webupgrade_status_of_download_control_file $STATUS_FINISH

