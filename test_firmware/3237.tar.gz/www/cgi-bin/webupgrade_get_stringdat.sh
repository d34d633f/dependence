#!/bin/sh
. /www/cgi-bin/functions.sh
. /www/cgi-bin/webupgrade.sh

oc echo "do webupgrade_get_stringdat"

oc rm -f "/tmp/$DAT_FILE" "$upgrade_info_file"

write_webupgrade_status_of_download_stringtable_date_file $STATUS_0_PERCENT
check_webupgrade_cancelled_in_download_stringtable_dat_file
if ! oc /bin/snarf "$NETGEAR_SITE_1$DAT_FILE_FULLNAME" "/tmp/$DAT_FILE"; then
       #/sbin/iconv /tmp/$DAT_FILE
       check_webupgrade_cancelled_in_download_stringtable_dat_file
       write_webupgrade_status_of_download_stringtable_date_file $STATUS_33_PERCENT
       #if ! oc /bin/snarf "$NETGEAR_SITE_2$DAT_FILE_FULLNAME" "/tmp/$DAT_FILE"; then
               #write_webupgrade_status_of_download_stringtable_date_file $STATUS_66_PERCENT
               #check_webupgrade_cancelled_in_download_stringtable_dat_file
               #if ! oc /bin/snarf "$NETGEAR_SITE_3$DAT_FILE_FULLNAME" "/tmp/$DAT_FILE"; then
                       giveup_webupgrade_in_download_string_dat_file $STATUS_DOWNLOAD_ERROR
               #fi
       #fi
fi
/sbin/iconv /tmp/$DAT_FILE
write_webupgrade_status_of_download_stringtable_date_file $STATUS_100_PERCENT
oc echo "got $DAT_FILE successfully !"

write_webupgrade_status_of_download_stringtable_date_file $STATUS_FINISH

