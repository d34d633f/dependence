//These settings will override common settings
function DeviceInfo()
{
	this.bridgeMode = true;
	this.featureVPN = true;
	
	this.helpVer = "0100";
}
