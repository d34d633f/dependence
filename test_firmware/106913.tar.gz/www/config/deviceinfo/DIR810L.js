//These settings will override common settings
function DeviceInfo()
{
	this.bridgeMode = false;
	this.featureVPN = false;

	this.featureSharePort = false;
	this.featureDLNA = false;
	this.featureUPNPAV = false;
	this.featureSmartConnect = false;

	this.featureMyDlink = true;

	this.helpVer = "";
}
