//These settings will override common settings
function DeviceInfo()
{
	this.bridgeMode = true;
	this.featureVPN = true;

	this.featureSharePort = true;
	this.featureDLNA = false;
	this.featureUPNPAV = false;
	this.featureSmartConnect = false;

	this.featureMyDlink = true;

	this.helpVer = "";
}
