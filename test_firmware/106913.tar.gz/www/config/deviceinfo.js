//These settings will override common settings
function DeviceInfo()
{
	this.bridgeMode = true;
	this.featureVPN = true;

	this.featureSharePort = false;
	this.featureDLNA = false;
	this.featureUPNPAV = false;
	this.featureSmartConnect = false;
	
	this.featureMyDlink = false;
	this.featureWPS = true;
	this.featurePoeMac = true;
	this.featureRappiDDNS = true;

	this.helpVer = "";
}
