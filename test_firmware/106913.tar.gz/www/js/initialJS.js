/* Initial Javascript - JavaScript (Timmy Hsieh)*/
/* Code Number: 130916							*/

document.write('<script type="text/javascript" charset="utf-8" src="/js/comm.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/hmac_md5.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/libajax.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/hnap.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/i18n.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/pagetool.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/checkTimeout.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/includeLang.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/AES.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/configuration/DeviceConfig.js"></script>');


// for all page

window.onload = function(){
	if(document.getElementById('Get_Help'))
		document.getElementById('Get_Help').innerHTML = '';
}