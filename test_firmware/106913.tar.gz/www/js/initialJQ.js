/* Initial Javascript - JQuery (Timmy Hsieh)	*/
/* Code Number: 130916							*/
document.write('<script type="text/javascript" charset="utf-8" src="/js/jquery-1.8.2.min.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/jquery.selectbox-0.2_new.js"></script>');