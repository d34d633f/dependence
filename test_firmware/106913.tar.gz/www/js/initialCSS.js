/* Initial Javascript - CSS (Timmy Hsieh)	*/
/* Code Number: 130916						*/
document.write('<link rel=stylesheet type="text/css" href="css/style_pages.css" media="all" />');
