/* Initial Javascript - CSS (Timmy Hsieh)	*/
/* Code Number: 131218						*/
document.write('<link rel=stylesheet type="text/css" href="demo/css/style_h_Demo.css" media="all" />');
