<?php

$res = `echo '' > /tmp/log/messages`;

?>
