<?php /* Smarty version 2.6.18, created on 2008-07-03 06:30:03
         compiled from SecuritySettings.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'input_row', 'SecuritySettings.tpl', 44, false),array('function', 'ip_field', 'SecuritySettings.tpl', 48, false),array('modifier', 'regex_replace', 'SecuritySettings.tpl', 65, false),)), $this); ?>
	
	
	
	<tr>
		<td>
			<table class="tableStyle">
				<tr>
					<td colspan="3"><script>tbhdr('Security Settings','securitySettings')</script></td>
				</tr>
				<tr>
					<td class="subSectionBodyDot">&nbsp;</td>
					<td class="spacer100Percent paddingsubSectionBody">
						<table class="tableStyle">
							<?php echo smarty_function_input_row(array('label' => 'Network Authentication','id' => 'authenticationType','name' => $this->_tpl_vars['parentStr']['vapSettings']['vapSettingTable']['wlan0']['vap0']['authenticationType'],'type' => 'select','options' => $this->_tpl_vars['authenticationTypeList'],'selected' => $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['authenticationType'],'onchange' => "DisplaySettings(this.value);"), $this);?>


							<?php echo smarty_function_input_row(array('label' => 'Data Encryption','id' => 'key_size_11g','name' => 'encryptionType','type' => 'select','options' => $this->_tpl_vars['encryptionTypeList'],'selected' => $this->_tpl_vars['encryptionSel'],'onchange' => "if ($('authenticationType').value=='0') DisplaySettings('1',this.value,1); setEncryption(this.value,$('authenticationType').value);"), $this);?>


							<?php echo smarty_function_ip_field(array('id' => 'encryption','name' => $this->_tpl_vars['parentStr']['vapSettings']['vapSettingTable']['wlan0']['vap0']['encryption'],'type' => 'hidden','value' => $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['encryption']), $this);?>

							<?php if (! ( $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['authenticationType'] == 1 || ( $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['authenticationType'] == 0 && $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['encryption'] != 0 ) )): ?>
								<?php echo smarty_function_ip_field(array('id' => 'wepKeyType','name' => $this->_tpl_vars['parentStr']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyType'],'type' => 'hidden','value' => $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyType'],'disabled' => 'true'), $this);?>

							<?php else: ?>
								<?php echo smarty_function_ip_field(array('id' => 'wepKeyType','name' => $this->_tpl_vars['parentStr']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyType'],'type' => 'hidden','value' => $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyType']), $this);?>

							<?php endif; ?>
							<?php if (! ( $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['authenticationType'] == 1 || ( $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['authenticationType'] == 0 && $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['encryption'] != 0 ) )): ?>
								<?php $this->assign('hideWepRow', "style=\"display: none;\" disabled='true'"); ?>
								<?php $this->assign('disableWepRow', "disabled='true'"); ?>
							<?php endif; ?>

							<?php if (! ( $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['authenticationType'] == 16 || $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['authenticationType'] == 32 || $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['authenticationType'] == 48 )): ?>
								<?php $this->assign('hideWPARow', "style=\"display: none;\" disabled='true'"); ?>
							<?php endif; ?>
							<tr mode="1" <?php echo $this->_tpl_vars['hideWepRow']; ?>
>
								<td class="DatablockLabel">Passphrase</td>
								<td class="DatablockContent">
									<input class="input" size="20" maxlength="39" id="wepPassPhrase" name="<?php echo $this->_tpl_vars['parentStr']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepPassPhrase']; ?>
" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepPassPhrase'])) ? $this->_run_mod_handler('regex_replace', true, $_tmp, "/(.)/", '*') : smarty_modifier_regex_replace($_tmp, "/(.)/", '*')); ?>
" type="text" label="Passphrase"  onfocus="if(/^\*<?php echo '{1,}$'; ?>
/.test(this.value)) this.value='';setActiveContent();" validate="Presence, <?php echo '{ isMasked: \'wepPassPhrase\', allowQuotes: false, allowSpace: false }'; ?>
" onkeydown="setActiveContent();" masked="true" onchange="this.setAttribute('masked',(this.value != '')?false:true); $('wepPassPhrase_hidden').value='';">&nbsp;
									<input name="szPassphrase_button" style="text-align: center;" value="Generate Keys" onclick="gen_11g_keys()" type="button">
									<input type="hidden" id="wepPassPhrase_hidden" value="<?php echo $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepPassPhrase']; ?>
">
								</td>
							</tr>
							<tr mode="1" <?php echo $this->_tpl_vars['hideWepRow']; ?>
>
								<td class="DatablockLabel">Key 1&nbsp;<input id="keyno_11g1" name="<?php echo $this->_tpl_vars['parentStr']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyNo']; ?>
" value="1" <?php if ($this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyNo'] == '1'): ?>checked="checked"<?php endif; ?> type="radio" onclick="setActiveContent();" <?php echo $this->_tpl_vars['disableWepRow']; ?>
></td>
								<td class="DatablockContent">
									<input class="input" size="20" id="wepKey1" name="system['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKey1']" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKey1'])) ? $this->_run_mod_handler('regex_replace', true, $_tmp, "/(.)/", '*') : smarty_modifier_regex_replace($_tmp, "/(.)/", '*')); ?>
" type="text" label="WEP Key 1" validate="<?php echo 'Presence, { onlyIfChecked: \'keyno_11g1\' }^HexaDecimal,{ isMasked: \'wepKey1\' }^Length,{ isWep: true }'; ?>
" onkeydown="setActiveContent();" masked="true" onchange="this.setAttribute('masked',false);" onfocus="if(/^\*<?php echo '{1,}$'; ?>
/.test(this.value)) this.value='';setActiveContent();">
								</td>
							</tr>
							<tr mode="1" <?php echo $this->_tpl_vars['hideWepRow']; ?>
>
								<td class="DatablockLabel">Key 2&nbsp;<input id="keyno_11g2" name="<?php echo $this->_tpl_vars['parentStr']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyNo']; ?>
" value="2" <?php if ($this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyNo'] == '2'): ?>checked="checked"<?php endif; ?> type="radio" onclick="setActiveContent();" <?php echo $this->_tpl_vars['disableWepRow']; ?>
></td>
								<td class="DatablockContent">
									<input class="input" size="20" id="wepKey2" name="system['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKey2']" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKey2'])) ? $this->_run_mod_handler('regex_replace', true, $_tmp, "/(.)/", '*') : smarty_modifier_regex_replace($_tmp, "/(.)/", '*')); ?>
" type="text" label="WEP Key 2" validate="<?php echo 'Presence, { onlyIfChecked: \'keyno_11g2\' }^HexaDecimal,{ isMasked: \'wepKey2\' }^Length,{ isWep: true }'; ?>
" onkeydown="setActiveContent();" masked="true" onchange="this.setAttribute('masked',false);" onfocus="if(/^\*<?php echo '{1,}$'; ?>
/.test(this.value)) this.value='';setActiveContent();">
								</td>
							</tr>
							<tr mode="1" <?php echo $this->_tpl_vars['hideWepRow']; ?>
>
								<td class="DatablockLabel">Key 3&nbsp;<input id="keyno_11g3" name="<?php echo $this->_tpl_vars['parentStr']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyNo']; ?>
" value="3" <?php if ($this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyNo'] == '3'): ?>checked="checked"<?php endif; ?> type="radio" onclick="setActiveContent();" <?php echo $this->_tpl_vars['disableWepRow']; ?>
></td>
								<td class="DatablockContent">
									<input class="input" size="20" id="wepKey3" name="system['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKey3']" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKey3'])) ? $this->_run_mod_handler('regex_replace', true, $_tmp, "/(.)/", '*') : smarty_modifier_regex_replace($_tmp, "/(.)/", '*')); ?>
" type="text" label="WEP Key 3" validate="<?php echo 'Presence, { onlyIfChecked: \'keyno_11g3\' }^HexaDecimal,{ isMasked: \'wepKey3\' }^Length,{ isWep: true }'; ?>
" onkeydown="setActiveContent();" masked="true" onchange="this.setAttribute('masked',false);" onfocus="if(/^\*<?php echo '{1,}$'; ?>
/.test(this.value)) this.value='';setActiveContent();">
								</td>
							</tr>
							<tr mode="1" <?php echo $this->_tpl_vars['hideWepRow']; ?>
>
								<td class="DatablockLabel">Key 4&nbsp;<input id="keyno_11g4" name="<?php echo $this->_tpl_vars['parentStr']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyNo']; ?>
" value="4" <?php if ($this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKeyNo'] == '4'): ?>checked="checked"<?php endif; ?> type="radio" onclick="setActiveContent();" <?php echo $this->_tpl_vars['disableWepRow']; ?>
></td>
								<td class="DatablockContent">
									<input class="input" size="20" id="wepKey4" name="system['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKey4']" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['wepKey4'])) ? $this->_run_mod_handler('regex_replace', true, $_tmp, "/(.)/", '*') : smarty_modifier_regex_replace($_tmp, "/(.)/", '*')); ?>
" type="text" label="WEP Key 4" validate="<?php echo 'Presence, { onlyIfChecked: \'keyno_11g4\' }^HexaDecimal,{ isMasked: \'wepKey4\' }^Length,{ isWep: true }'; ?>
" onkeydown="setActiveContent();" masked="true" onchange="this.setAttribute('masked',false);" onfocus="if(/^\*<?php echo '{1,}$'; ?>
/.test(this.value)) this.value='';setActiveContent();">
								</td>
							</tr>
							<tr mode="16" <?php echo $this->_tpl_vars['hideWPARow']; ?>
>
								<td class="DatablockLabel">WPA Passphrase (Network Key)</td>
								<td class="DatablockContent">
									<input id="wpa_psk" class="input" size="28" maxlength="63" name="<?php echo $this->_tpl_vars['parentStr']['vapSettings']['vapSettingTable']['wlan0']['vap0']['presharedKey']; ?>
" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['presharedKey'])) ? $this->_run_mod_handler('regex_replace', true, $_tmp, "/(.)/", '*') : smarty_modifier_regex_replace($_tmp, "/(.)/", '*')); ?>
" onfocus="if(/^\*<?php echo '{1,}$'; ?>
/.test(this.value)) this.value='';this.masked=false" type="text" label="WPA Passphrase (Network Key)" validate="Presence,<?php echo ' { allowQuotes: false, allowSpace: false }'; ?>
^Length,<?php echo '{minimum: 8}'; ?>
" onkeydown="setActiveContent();" masked="true" onchange="this.setAttribute('masked',false);" onfocus="if(/^\*<?php echo '{1,}$'; ?>
/.test(this.value)) this.value='';setActiveContent();">
								</td>
							</tr>
							<?php $this->assign('clientSeparation', $this->_tpl_vars['data']['vapSettings']['vapSettingTable']['wlan0']['vap0']['clientSeparation']); ?>
							<?php echo smarty_function_input_row(array('label' => 'Wireless Client Security Separation','id' => "station-isolation-id",'name' => $this->_tpl_vars['parentStr']['vapSettings']['vapSettingTable']['wlan0']['vap0']['clientSeparation'],'type' => 'radio','options' => "1-Yes,0-No",'selectCondition' => "==".($this->_tpl_vars['clientSeparation'])), $this);?>

						</table>
					</td>
					<td class="subSectionBodyDotRight">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" class="subSectionBottom">&nbsp;</td>
				</tr>
			</table>
		</td>
	</tr>
	<input type="hidden" id="radiusEnabled" value="<?php if ($this->_tpl_vars['data']['info802dot1x']['authinfo']['priRadIpAddr'] == '0.0.0.0'): ?>false<?php else: ?>true<?php endif; ?>">
	<script language="javascript">
	<!--
	
	<?php if (( ( $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan0']['apMode'] == '1' || $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan0']['apMode'] == '4' ) && ( $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan0']['radioStatus'] == '1' ) ) || ( $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan0']['radioStatus'] == '0' )): ?>
		<?php $this->assign('checkWlan0ApStatus', "disabled='disabled'"); ?>
		<?php $this->assign('checkEditDisable', "disabled='disabled'"); ?>		
	<?php endif; ?>
	<?php if (( ( $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan1']['apMode'] == '1' || $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan1']['apMode'] == '4' ) && ( $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan1']['radioStatus'] == '1' ) ) || ( $this->_tpl_vars['data']['wlanSettings']['wlanSettingTable']['wlan1']['radioStatus'] == '0' )): ?>
		<?php $this->assign('checkWlan1ApStatus', "disabled='disabled'"); ?>
		<?php $this->assign('checkEditDisable', "disabled='disabled'"); ?>
	<?php endif; ?>	
	<?php if ($this->_tpl_vars['checkEditDisable'] != ''): ?>		
		Form.disable(document.dataForm);		
	<?php endif; ?>
-->	
	</script>
	