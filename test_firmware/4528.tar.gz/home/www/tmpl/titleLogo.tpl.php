<?php /* Smarty version 2.6.18, created on 2008-02-21 19:12:46
         compiled from titleLogo.tpl */ ?>
<?php echo '<?xml'; ?>
 version="1.0"<?php echo '?>'; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="include/css/default.css" type="text/css" />
</head>
<body>
<table class="tableStyle" height="100%">
	<tr class="topAlign">
	    <td class="leftEdge">&nbsp;</td>
	    <td valign="top">
			<table class="tableStyle">
				<tr>
					<td style="width: 8px;"><img src="images/clear.gif" width="8"/></td>
					<td colspan="2">
						<table class="tableStyle">
							<tr>
								<td class="logoNetGear space50Percent topAlign"><img src="images/clear.gif" width="149" height="62"/></td>
								<td class="vertionImage spacer50Percent topAlign rightHAlign"><img src="images/clear.gif" width="205" height="62"/></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	    <td class="rightEdge">&nbsp;</td>
	</tr>
</table>
<!--<table id="headerLogo tableStyle">
          <tr>
            <td class="logoNetGear space50Percent topAlign"><img src="images/clear.gif" width="149" height="62"/></td>
            <td class="vertionImage spacer50Percent topAlign rightHAlign"><img src="images/clear.gif" width="205" height="62"/></td>
          </tr>
</table>-->
</body>
</html>