<?php /* Smarty version 2.6.18, created on 2008-02-13 10:31:39
         compiled from sample_datablock.tpl */ ?>
		<td>	
			<table class="tableStyle">
				<tr>
					<td colspan="3"><script>tbhdr('DHCP Server Configuration','dhcpServerConfiguration')</script></td>
				</tr>
				<tr>
					<td class="subSectionBodyDot">&nbsp;</td>
					<td class="spacer100Percent paddingsubSectionBody">
						<table class="tableStyle">
							<tr>
								<td class="font10Bold padding4Top">Ping Packet Count</td>
								<td class="padding4Top"><input name="serverIP1" id="serverIP1" type="text" class="input" value="1" onKeyPress="setActiveContent()" validate="Presence"/>
								</td>
							</tr>
						</table>
					</td>
					<td class="subSectionBodyDotRight">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" class="subSectionBottom">&nbsp;</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td class="spacerHeight21"></td>
	</tr>