<?php /* Smarty version 2.6.18, created on 2008-02-14 10:12:29
         compiled from footer.tpl */ ?>
<?php echo '<?xml'; ?>
 version="1.0"<?php echo '?>'; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="background-color: #FFA400; padding: 0px; margin: 0px;">
<head>
<link rel="stylesheet" href="include/css/default.css" type="text/css">
<link rel="stylesheet" href="include/css/layout.css" type="text/css">
</head>
<body style="margin: 0px; padding: 0px;">
<table class="tableStyle">
  <tr>
    <td class="leftCopyrightFooter"><img src="../App_themes/NG/images/clear.gif" width="11" height="9"/></td>
    <td class="middleCopyrightDivider"><table class="blue10 tableStyle">
        <tr class="topAlign">
          <td>Copyright &copy; 1996-2007 Netgear &reg;</td>
        </tr>
    </table></td>
    <td class="rightCopyrightFooter"><img src="../App_themes/NG/images/clear.gif" width="11" height="9"/></td>
  </tr>
</table>
 	<!--<div id="footer">Copyright &copy; 1996-2007 Reserved</div>-->
</body>
</html>