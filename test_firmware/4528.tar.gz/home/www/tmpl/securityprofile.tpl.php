<?php /* Smarty version 2.6.18, created on 2007-10-22 05:25:24
         compiled from securityprofile.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'data_header', 'securityprofile.tpl', 4, false),array('function', 'input_row', 'securityprofile.tpl', 11, false),)), $this); ?>
	<table align="left" class="datablockMain">
		<tr>
			<td>
				<?php echo smarty_function_data_header(array('label' => 'Profile Definition'), $this);?>

				<table class="datablock" align="left">
					<tr>
						<td>
							<div  id="BlockContent">
								<table class="BlockContent">
								<?php if ($this->_tpl_vars['navigation']['9'] != 'wdsprofile'): ?>
									<?php echo smarty_function_input_row(array('label' => 'Profile Name','id' => 'vapProfileName','name' => $this->_tpl_vars['parentStr']['vapProfileName'],'type' => 'text','value' => $this->_tpl_vars['data']['vapProfileName']), $this);?>


									<?php echo smarty_function_input_row(array('label' => "Wireless Network Name (SSID)",'id' => 'ssid','name' => $this->_tpl_vars['parentStr']['ssid'],'type' => 'text','value' => $this->_tpl_vars['data']['ssid'],'size' => '20','maxlength' => '32'), $this);?>


									<?php $this->assign('hideNetworkName', $this->_tpl_vars['data']['hideNetworkName']); ?>
									<?php echo smarty_function_input_row(array('label' => "Broadcast Wireless Network Name (SSID)",'id' => 'broadcastSSID','name' => $this->_tpl_vars['parentStr']['hideNetworkName'],'type' => 'radio','options' => "0-Yes,1-No",'selectCondition' => "!=".($this->_tpl_vars['hideNetworkName'])), $this);?>

								<?php else: ?>
									<?php echo smarty_function_input_row(array('label' => 'Profile Name','id' => 'wdsProfileName','name' => $this->_tpl_vars['parentStr']['wdsProfileName'],'type' => 'text','value' => $this->_tpl_vars['data']['wdsProfileName']), $this);?>


									<?php echo smarty_function_input_row(array('label' => 'Remote MAC Address','id' => 'remoteMacAddress','name' => $this->_tpl_vars['parentStr']['remoteMacAddress'],'type' => 'text','value' => $this->_tpl_vars['data']['remoteMacAddress']), $this);?>

								<?php endif; ?>
								</table>
							</div>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td class="separator"></td>
		</tr>
		<tr>
			<td>
				<?php echo smarty_function_data_header(array('label' => 'Authentication Settings'), $this);?>

				<table class="datablock" align="left">
					<tr>
						<td>
							<div  id="BlockContent">
								<table class="BlockContent">
									<?php if ($this->_tpl_vars['navigation']['9'] != 'wdsprofile'): ?>
										<?php $this->assign('authenticationTypeLabel', $this->_tpl_vars['parentStr']['authenticationtype']); ?>
									<?php else: ?>
										<?php $this->assign('authenticationTypeLabel', $this->_tpl_vars['parentStr']['wdsAuthenticationtype']); ?>
									<?php endif; ?>
									<?php echo smarty_function_input_row(array('label' => 'Network Authentication','id' => 'auth_11g','name' => $this->_tpl_vars['authenticationTypeLabel'],'type' => 'select','options' => $this->_tpl_vars['authenticationTypeList'],'selected' => $this->_tpl_vars['data']['authenticationType'],'onchange' => "DisplaySettings(this.value);"), $this);?>


									<tr>
										<td class="DatablockLabel">Data Encryption</td>
										<td class="DatablockContent">
											<select name="<?php echo $this->_tpl_vars['parentStr']['wepKeyType']; ?>
" id="key_size_11g" onchange="if ($('auth_11g').value=='0') DisplaySettings('wep',1);">
												<option value="0">None</option>
												<option value="40">64 bits WEP</option>
												<option value="104">128 bits WEP</option>
												<option value="128">152 bits WEP</option>
											</select>
										</td>
									</tr>
									<tr mode="1" style="display: none;">
										<td class="DatablockLabel">Passphrase</td>
										<td class="DatablockContent">
											<input class="num" size="20" name="<?php echo $this->_tpl_vars['parentStr']['wepPassPhrase']; ?>
" value="<?php echo $this->_tpl_vars['data']['wepPassPhrase']; ?>
" type="text">&nbsp;
											<input name="szPassphrase_button" style="text-align: center;" value="Generate Keys" onclick="gen_11g_keys()" type="button">
										</td>
									</tr>
									<tr mode="1" style="display: none;">
										<td class="DatablockLabel">Key 1&nbsp;<input id="keyno_11g" name="<?php echo $this->_tpl_vars['parentStr']['wepKeyNo']; ?>
" value="1" checked="checked" type="radio"></td>
										<td class="DatablockContent">
											<input class="num" size="20" name="<?php echo $this->_tpl_vars['parentStr']['wepKey1']; ?>
" value="<?php echo $this->_tpl_vars['data']['wepKey1']; ?>
" type="text">&nbsp;
										</td>
									</tr>
									<tr mode="1" style="display: none;">
										<td class="DatablockLabel">Key 2&nbsp;<input id="keyno_11g" name="<?php echo $this->_tpl_vars['parentStr']['wepKeyNo']; ?>
" value="2" type="radio"></td>
										<td class="DatablockContent">
											<input class="num" size="20" name="<?php echo $this->_tpl_vars['parentStr']['wepKey2']; ?>
" value="<?php echo $this->_tpl_vars['data']['wepKey2']; ?>
" type="text">&nbsp;
										</td>
									</tr>
									<tr mode="1" style="display: none;">
										<td class="DatablockLabel">Key 3&nbsp;<input id="keyno_11g" name="<?php echo $this->_tpl_vars['parentStr']['wepKeyNo']; ?>
" value="3" type="radio"></td>
										<td class="DatablockContent">
											<input class="num" size="20" name="<?php echo $this->_tpl_vars['parentStr']['wepKey3']; ?>
" value="<?php echo $this->_tpl_vars['data']['wepKey3']; ?>
" type="text">&nbsp;
										</td>
									</tr>
									<tr mode="1" style="display: none;">
										<td class="DatablockLabel">Key 4&nbsp;<input id="keyno_11g" name="<?php echo $this->_tpl_vars['parentStr']['wepKeyNo']; ?>
" value="4" type="radio"></td>
										<td class="DatablockContent">
											<input class="num" size="20" name="<?php echo $this->_tpl_vars['parentStr']['wepKey4']; ?>
" value="<?php echo $this->_tpl_vars['data']['wepKey4']; ?>
" type="text">&nbsp;
										</td>
									</tr>
									<tr mode="16" style="display: none;">
										<td class="DatablockLabel">WPA Passphrase (Network Key)</td>
										<td class="DatablockContent">
											<input id="wpa_psk" size="28" maxlength="64" name="<?php echo $this->_tpl_vars['parentStr']['presharedKey']; ?>
" value="<?php echo $this->_tpl_vars['data']['presharedKey']; ?>
" type="text">
										</td>
									</tr>
								<?php if ($this->_tpl_vars['navigation']['9'] != 'wdsprofile'): ?>
									<?php $this->assign('clientSeparation', $this->_tpl_vars['data']['clientSeparation']); ?>
									<?php echo smarty_function_input_row(array('label' => 'Wireless Client Security Separation','id' => "station-isolation-id",'name' => $this->_tpl_vars['parentStr']['clientSeparation'],'type' => 'radio','options' => "1-Yes,0-No",'selectCondition' => "!=".($this->_tpl_vars['clientSeparation'])), $this);?>


									<?php echo smarty_function_input_row(array('label' => 'VLAN ID','id' => 'vlan_id','name' => $this->_tpl_vars['parentStr']['vlanID'],'type' => 'text','value' => $this->_tpl_vars['data']['vlanID'],'size' => '4','maxlength' => '4'), $this);?>

								<?php endif; ?>
								</table>
							</div>
						</td>
					</tr>
				</table>
			</td>
		</tr>				
	</table>
	<script language="javascript">
	<!--
		$('mode7').value='';
	-->
	</script>