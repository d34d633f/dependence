<?php /* Smarty version 2.6.18, created on 2008-03-08 10:14:47
         compiled from RogueAPList.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'sortable_header_row', 'RogueAPList.tpl', 33, false),array('modifier', 'replace', 'RogueAPList.tpl', 48, false),)), $this); ?>
	<tr id="wlan1">
		<td>	
			<table class="tableStyle">
				<tr>
					<td>
						<table class="tableStyle">
							<tr>
								<td colspan="3">
									<table class='tableStyle'>
										<tr>
											<td colspan='2' class='subSectionTabTopLeft spacer60Percent font12BoldBlue'>Unknown AP List</td>
											<td class='subSectionTabTopRight spacer40Percent'>
												<input type="image" src="images/refresh_on.gif" name="refresh" id="refresh" value="Refresh" onclick="doSubmit('cancel');" style="margin-right: 2px;">
												<input type="image" id="save_unknown_1" src="images/save_on.gif" value="Save" onclick="$('unknownApListForm0').submit();return false;" style="margin-right: 2px;">
												<a href='javascript: void(0);' onclick="showHelp('Unknown AP List','unknownAPList');"><img src='images/help_icon.gif' width='12' height='12' title='Click for help'/></a></td>
										</tr>
										<tr>
											<td colspan='3' class='subSectionTabTopShadow'></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td class="subSectionBodyDot">&nbsp;</td>
								<td class="spacer100Percent paddingsubSectionBody" style="padding: 0px;">
									<table class="tableStyle">
										<tr>
											<td>
												<div  id="BlockContentTable">
													<table class="BlockContentTable" id="unknownList">
														<thead>
															<tr>
																<?php echo smarty_function_sortable_header_row(array('sortable' => 'false','tableid' => 'unknownList','rowid' => '0','content' => "#"), $this);?>

																<?php echo smarty_function_sortable_header_row(array('sortable' => 'true','tableid' => 'unknownList','rowid' => '1','content' => 'MAC Address'), $this);?>

																<?php echo smarty_function_sortable_header_row(array('sortable' => 'true','tableid' => 'unknownList','rowid' => '2','content' => 'SSID'), $this);?>

																<?php echo smarty_function_sortable_header_row(array('sortable' => 'true','tableid' => 'unknownList','rowid' => '3','content' => 'Privacy'), $this);?>

																<?php echo smarty_function_sortable_header_row(array('sortable' => 'true','tableid' => 'unknownList','rowid' => '4','content' => 'Channel'), $this);?>

																<?php echo smarty_function_sortable_header_row(array('sortable' => 'true','tableid' => 'unknownList','rowid' => '5','content' => 'Rate'), $this);?>

																<?php echo smarty_function_sortable_header_row(array('sortable' => 'true','tableid' => 'unknownList','rowid' => '6','content' => "Beacon Int."), $this);?>

																<?php echo smarty_function_sortable_header_row(array('sortable' => 'true','tableid' => 'unknownList','rowid' => '7','content' => "# of Beacons"), $this);?>

																<?php echo smarty_function_sortable_header_row(array('sortable' => 'true','tableid' => 'unknownList','rowid' => '8','last' => 'true','content' => 'Last Beacon'), $this);?>

															</tr>
														</thead>
														<tbody>
														<?php $_from = $this->_tpl_vars['data']['monitor']['apList']['unknownApTable']['wlan0']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['unknownAP'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['unknownAP']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
        $this->_foreach['unknownAP']['iteration']++;
?>
															<tr <?php if ($this->_foreach['unknownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>>
																<td <?php if ($this->_foreach['unknownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo $this->_foreach['unknownAP']['iteration']; ?>
</td>
																<td <?php if ($this->_foreach['unknownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo ((is_array($_tmp=$this->_tpl_vars['key'])) ? $this->_run_mod_handler('replace', true, $_tmp, '-', ':') : smarty_modifier_replace($_tmp, '-', ':')); ?>
</td>
																<td <?php if ($this->_foreach['unknownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo $this->_tpl_vars['value']['unknownApSsid']; ?>
</td>
																<td <?php if ($this->_foreach['unknownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo $this->_tpl_vars['value']['unknownApPrivacy']; ?>
</td>
																<td <?php if ($this->_foreach['unknownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo $this->_tpl_vars['value']['unknownApChannel']; ?>
</td>
																<td <?php if ($this->_foreach['unknownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo $this->_tpl_vars['value']['unknownApRate']; ?>
</td>
																<td <?php if ($this->_foreach['unknownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo $this->_tpl_vars['value']['unknownApBeaconInterval']; ?>
</td>
																<td <?php if ($this->_foreach['unknownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo $this->_tpl_vars['value']['unknownApNumBeacons']; ?>
</td>
																<td <?php if ($this->_foreach['unknownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo $this->_tpl_vars['value']['unknownApLastBeacon']; ?>
</td>
															</tr>
														<?php 
															$this->_tpl_vars['unknownApList0'].= str_replace('-',':',$this->_tpl_vars['key']) . ',';
														 ?>
														<?php endforeach; else: ?>
															<script language="javascript">
															<!--
																<?php if ($this->_tpl_vars['ifaceString'] == 'wlan1'): ?>
																$('save_unknown_1').disabled=true;
																$('save_unknown_1').src = 'images/save_off.gif';
																<?php endif; ?>
															-->
															</script>
														<?php endif; unset($_from); ?>
														</tbody>
													</table>
												</div>
											</td>
										</tr>
									</table>
								</td>
								<td class="subSectionBodyDotRight">&nbsp;</td>
							</tr>
							<tr>
								<td colspan="3" class="subSectionBottom">&nbsp;</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td class="spacerHeight21"></td>
				</tr>
				<tr>
					<td>
						<table class="tableStyle">
							<tr>
								<td colspan="3">
									<table class='tableStyle'>
										<tr>
											<td colspan='2' class='subSectionTabTopLeft spacer60Percent font12BoldBlue'>Known AP List</td>
											<td class='subSectionTabTopRight spacer40Percent'>
												<input type="image" src="images/refresh_on.gif" name="refresh" id="refresh" value="Refresh" onclick="doSubmit('cancel');" style="margin-right: 2px;">
												<input type="image" id="save_known_1" src="images/save_on.gif" value="Save" onclick="$('knownApListForm0').submit();return false;" style="margin-right: 2px;">
												<a href='javascript: void(0);' onclick="showHelp('Known AP List','knownAPList');"><img src='images/help_icon.gif' width='12' height='12' title='Click for help'/></a></td>
										</tr>
										<tr>
											<td colspan='3' class='subSectionTabTopShadow'></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td class="subSectionBodyDot">&nbsp;</td>
								<td class="spacer100Percent paddingsubSectionBody" style="padding: 0px;">
									<table class="tableStyle">				
										<tr>
											<td>
												<div  id="BlockContentTable">
													<table class="BlockContentTable" id="knownList">
														<thead>
															<tr>
																<?php echo smarty_function_sortable_header_row(array('sortable' => 'false','tableid' => 'knownList','rowid' => '0','content' => "#"), $this);?>

																<?php echo smarty_function_sortable_header_row(array('sortable' => 'true','tableid' => 'knownList','rowid' => '1','content' => 'MAC Address'), $this);?>

																<?php echo smarty_function_sortable_header_row(array('sortable' => 'true','tableid' => 'knownList','rowid' => '2','content' => 'SSID'), $this);?>

																<?php echo smarty_function_sortable_header_row(array('sortable' => 'true','tableid' => 'knownList','rowid' => '3','last' => 'true','content' => 'Channel'), $this);?>

															</tr>
														</thead>
														<tbody>
															<?php $_from = $this->_tpl_vars['data']['monitor']['apList']['knownApTable']['wlan0']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['knownAP'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['knownAP']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
        $this->_foreach['knownAP']['iteration']++;
?>
																<tr <?php if ($this->_foreach['knownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>>
																	<td <?php if ($this->_foreach['knownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo $this->_foreach['knownAP']['iteration']; ?>
</td>
																	<td <?php if ($this->_foreach['knownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo ((is_array($_tmp=$this->_tpl_vars['key'])) ? $this->_run_mod_handler('replace', true, $_tmp, '-', ':') : smarty_modifier_replace($_tmp, '-', ':')); ?>
</td>
																	<td <?php if ($this->_foreach['knownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo $this->_tpl_vars['value']['knownApSsid']; ?>
</td>
																	<td <?php if ($this->_foreach['knownAP']['iteration']%2 == 0): ?>class="Alternate"<?php endif; ?>><?php echo $this->_tpl_vars['value']['knownApChannel']; ?>
</td>
																</tr>
															<?php 
																$this->_tpl_vars['knownApList0'].= str_replace('-',':',$this->_tpl_vars['key']) . ',';
															 ?>
															<?php endforeach; else: ?>
																<script language="javascript">
																<!--
																	<?php if ($this->_tpl_vars['ifaceString'] == 'wlan1'): ?>
																	$('save_known_1').disabled=true;
																	$('save_known_1').src = 'images/save_off.gif';
																	<?php endif; ?>
																-->
																</script>
															<?php endif; unset($_from); ?>
														</tbody>
													</table>
												</div>
											</td>
										</tr>
									</table>
								</td>
								<td class="subSectionBodyDotRight">&nbsp;</td>
							</tr>
							<tr>
								<td colspan="3" class="subSectionBottom">&nbsp;</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	

<script language="javascript">
<!--
-->
</script>
</form>
<form name="unknownApListForm0" id="unknownApListForm0" action="saveTable.php" method="post">
<input type="hidden" name="ApList" value="<?php echo $this->_tpl_vars['unknownApList0']; ?>
">
</form>
<form name="knownApListForm0" id="knownApListForm0" action="saveTable.php" method="post">
<input type="hidden" name="ApList" value="<?php echo $this->_tpl_vars['knownApList0']; ?>
">
</form>