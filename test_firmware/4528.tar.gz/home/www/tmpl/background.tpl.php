<?php /* Smarty version 2.6.18, created on 2008-02-14 08:41:34
         compiled from background.tpl */ ?>
<?php echo '<?xml'; ?>
 version="1.0"<?php echo '?>'; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="background-color: #FFA400; padding: 0px; margin: 0px;">
<head>
<link rel="stylesheet" href="include/css/default.css" type="text/css">
</head>
<body style="background-color: #FFA400;">
<table class="tableStyle" height="100%"><tr><td  
<?php 
if (isset($_GET['left']) && $_GET['left'] == true) {
	echo 'class="leftEdge"';
}
else if (isset($_GET['right']) && $_GET['right'] == true) {
	echo 'class="rightEdge"';
}
 ?>
 height="100%"><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /></td></tr></table>
</body>
</html>