<?php /* Smarty version 2.6.18, created on 2007-12-19 20:12:23
         compiled from topCurve.tpl */ ?>
<?php echo '<?xml'; ?>
 version="1.0"<?php echo '?>'; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript" src="include/scripts/prototype.js"></script>
<script type="text/javascript" src="include/scripts/scriptaculous.js"></script>
<script type="text/javascript" src="include/scripts/prototype-ext.js"></script>
<link rel="stylesheet" href="include/css/style.css" type="text/css">
<link rel="stylesheet" href="include/css/layout.css" type="text/css">
</head>
<body>
	<div id="container">
		<div id="topCurve">&nbsp;</div>
	</div>
<script language="javascript">
<!--
	new Effect.Corner($('topCurve'), "top");
-->
</script>
</body>
</html>