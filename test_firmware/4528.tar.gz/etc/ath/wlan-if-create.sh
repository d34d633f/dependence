#!/bin/sh
#this script assumes that the bridge interface br0 is already created

wlanconfig wifi0vap0 create wlandev wifi0 wlanmode ap

wlanconfig wifi0wds0 create wlandev wifi0 wlanmode swds
wlanconfig wifi0wds1 create wlandev wifi0 wlanmode swds
wlanconfig wifi0wds2 create wlandev wifi0 wlanmode swds
wlanconfig wifi0wds3 create wlandev wifi0 wlanmode swds
wlanconfig wifi0wds4 create wlandev wifi0 wlanmode swds
wlanconfig wifi0wds5 create wlandev wifi0 wlanmode swds
