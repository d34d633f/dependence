//BRS_01_checkNet.html
var bh_internet_checking="インターネット接続をチェックしています。; お待ちください…"


//BRS_02_genieHelp.html
var bh_config_net_connection="インターネット接続を設定しています。"

var bh_connection_further_action="まだインターネットに接続していません。"

var bh_want_genie_help="NETGEAR genieをご利用になりますか？"

var bh_yes_mark="はい。"

var bh_no_genie_help="いいえ。インターネット接続を自分で設定します。"

var bh_no_genie_help_confirm="インターネット接続を設定するには、ネットワーク設定の経験が必要です。 よろしいですか？"

var bh_have_saved_copy="保存してあるルータ設定を使用して、設定を復元します。"

var bh_next_mark="次へ"


//BRS_03A_detcInetType.html
var bh_detecting_connection="インターネット接続を検出しています。"

var bh_plz_wait_process="このプロセスには1～2分かかります。お待ちください..."


//BRS_03A_A_noWan.html
var bh_no_cable="ルータのインターネットポートにイーサネットケーブルが接続されていません。"

var bh_wizard_setup_nowan_check="ケーブルがブロードバンドモデムポートとルータインターネットポートの両方にしっかりと接続されていることを確認してください。"

var bh_click_try_again="イーサネットケーブルを確認した後、<b>［やり直す］</b>をクリックしてください。"

var bh_try_again="やり直す"


//BRS_03A_B_pppoe.html
var bh_pppoe_connection="PPPoE DSLインターネット接続が検出されました。"

var bh_enter_info_below="必要な情報を以下に力してください。"

var bh_pppoe_login_name="ユーザ名"
var bh_ddns_passwd="パスワード"


//BRS_03A_B_pppoe_reenter.html
var bh_ISP_namePasswd_error="プロバイダのユーザ名とパスワードが間違っています。"

var bh_enter_info_again="必要な情報をもう一度入力してください。"


//BRS_03A_C_pptp.html
var bh_pptp_login_name="ログイン";

var bh_pptp_connection="PPTPインターネット接続が検出されました。"

var bh_basic_pptp_servip="サーバアドレス"

var bh_sta_routes_gtwip="ゲートウェイ IP アドレス"

var bh_basic_pptp_connection_id="接続 ID/名前"

//BRS_03A_F_l2tp.html
var bh_l2tp_connection="L2TPインターネット接続が検出されました。"

//BRS_03A_D_bigpond.html
var bh_bpa_connection="BigPondインターネット接続が検出されました"

var bh_basic_bpa_auth_serv="認証サーバ"

var bh_basic_pppoe_idle="アイドルタイムアウト (分)"


//BRS_03A_E_IP_problem_staticIP.html
var bh_no_internet_ip="インターネット接続を検出中に問題が生じました"

var bh_no_internet_ip2="インターネット接続を検出中に問題が生じました - IPアドレス"

var bh_no_internet_ip3="インターネット接続を検出中に問題が生じました - MACアドレス"

var bh_if_have_static_ip="ご利用のサービスプロバイダは、あなたに固定 (スタティック) IPアドレスを提供していますか？ 多くの場合、IPアドレスは固定ではなく、プロバイダから自動的に配布されます。 "

var bh_yes_correct="はい。 プロバイダから固定 (スタティック) IPアドレスを割り当てられています。"

var bh_not_have_static_ip="いいえ。プロバイダから固定 (スタティック) IPアドレスは取得していません。"

var bh_do_not_know="わかりません。 "

var bh_select_option="オプションを選択し、<b>［次へ］</b>をクリックします。"

var bh_select_an_option="まずオプションを選択してください。"


//BRS_03A_E_IP_problem_staticIP_A_inputIP.html
var bh_fix_ip_setting="固定インターネットIP設定"

var bh_enter_ip_setting="インターネットプロバイダから提供された固定IP設定を入力し、<b>［次へ］</b>をクリックします。"

var bh_info_mark_ip="IPアドレス"
//var bh_info_mark_ip="マイ IP アドレス";
var bh_info_mark_mask="サブネットマスク"

var bh_constatus_defgtw="デフォルトゲートウェイ"

var bh_preferred_dns="推奨されるDNSサーバ"

var bh_alternate_dns="別のDNSサーバ"

var bh_basic_int_third_dns="3つ目のDNS"

//BRS_03A_E_IP_problem.html
var bh_genie_cannot_find_ip="次の理由が原因である可能性があります："
var bh_genie_cannot_find_ip_reason1="1.  モデムの電源が入っていません。"
var bh_genie_cannot_find_ip_reason1_desc="この問題を解決するには、ブロードバンドモデムの電源を一旦切り、再起動してください。ご利用のモデムがバッテリー利用の場合、バッテリーを一度取り外してから再度挿入し、モデムの電源を入れなおしてください。"
var bh_genie_cannot_find_ip_reason2="2.  イーサネットケーブルが完全に接続されていないか、または間違った場所に接続されています。"
var bh_genie_cannot_find_ip_reason2_desc="この問題を解決するには、イーサネットケーブルがブロードバンドモデムポートとルータのインターネットポートの両方にしっかりと接続されていることを確認してください。"

var bh_select_no_IP_option="以下からいずれかのオプションを選択し、<b>［次へ］</b>をクリックします：";
var bh_select_no_IP_option1="モデムの電源を入れなおし、2分間待ちました。"
var bh_select_no_IP_option2="イーサネットケーブルの問題を修正しました。"
var bh_select_no_IP_option3="いずれでもない"

var bh_do_cycle_modem="モデムの電源を入れなおし、2分間待ちました。"

var bh_not_cycle_modem="I corrected a problem with the Ethernet cable."


//BRS_03A_E_IP_problem_staticIP_B_macClone.html
var bh_use_pc_mac="コンピュータまたは他のルータでインターネットサービスに接続したことがある場合、NETGEAR genieは以前使用したものと同じMACアドレスを使用することができます。"

var bh_mac_in_product_label="MACアドレスは機器固有の番号です。  コンピュータやルータのMACアドレスは製品ラベルに記載されています。"

var bh_enter_mac="ここにMACアドレスを入力します。"

var bh_mac_format="(書式：AABBCCDDEEFF)"


//BRS_03B_haveBackupFile.html
var bh_settings_restoration="ルータ設定の復元"

var bh_browser_file="以前に保存したルータ設定のバックアップファイルを選択し、<b>［次へ］</b>をクリックします。";

var bh_back_mark="戻る"


//BRS_03B_haveBackupFile_fileRestore.html
var bh_settings_restoring="ルータ設定を復元中"

var bh_plz_waite_restore="このプロセスには数分かかります。お待ちください …"


//BRS_04_applySettings.html
var bh_apply_connection="インターネット接続設定を適用する"

var bh_plz_waite_apply_connection="このプロセスには1～2分かかります。お待ちください..."


//BRS_05_networkIssue.html
var bh_netword_issue="ネットワーク接続の問題"

var bh_cannot_connect_internet="ルータは現在の設定ではインターネットに接続できません。"

var bh_plz_reveiw_items="以下のアイテムをご覧ください。"

var bh_cable_connection="- 正しくケーブル接続されているか確認してください。 ルータのインストールガイドをご参照ください。"

var bh_modem_power_properly="- ブロードバンドモデムの電源を一旦切り、再起動してください。ご利用のモデムがバッテリー利用の場合、バッテリーを一度取り外してからもう一度挿入し、モデムの電源を入れなおしてください。"

var bh_try_again_or_manual_config="もう一度NETGEAR Ginieをご利用になりますか？"

var bh_I_want_manual_config="いいえ。インターネット接続を自分で設定します。"

var bh_manual_config_connection="インターネット接続を自分で設定します。"


//BRS_success.html
var bh_congratulations="おめでとうございます！"

var bh_connect_success_1="インターネットに接続しました。"

var bh_connect_success_2="このルータは次のワイヤレスネットワーク名 (SSID) であらかじめ設定されており、 "

var bh_network_key="ネットワークキー (パスワード)"

var bh_rollover_help_text="ご利用のルータには、不正なアクセスからネットワークを保護するためのWPA2-PSKワイヤレスセキュリティが設定されています。 このワイヤレスネットワークに接続するには、ネットワークキー (パスワード) が必要になります。 初期設定のネットワークキー（パスワード）は、シリアルナンバーのようにこのルータ固有のものです。  変更したい場合は、ルータ管理画面のワイヤレス設定画面で行えます。"

var bh_success_no_wireless_security_1="ワイヤレスセキュリティはこのルータでは有効になっていません。 NETGEARは、ワイヤレスセキュリティを有効にし、"
var bh_success_no_wireless_security_2="ここをクリック"
var bh_success_no_wireless_security_3="ネットワークを保護することを推奨します。"

var bh_wirless_name="ワイヤレスネットワーク名 (SSID)"

var bh_wireless="ワイヤレス"

var bh_wpa_wpa2_passpharse="ネットワークキー (パスワード)"

var bh_save_settings="ルータ設定を保存"

var bh_print_this="これを印刷"


var bh_take_to_internet="インターネットに接続する"

var bh_plz_wait_moment="しばらくお待ちください..."

//the string for not_support_print is temporary.
var bh_not_support_print="コンピュータはプリンタに対応していません。"
//already exist
var bh_login_name_null="ユーザ名は空欄にできません。"
var bh_password_error="無効なパスワードです。"
var bh_idle_time_null="アイドル時間を入力してください。\n"
var bh_invalid_idle_time="無効なアイドル時間です。 正しい数値を入力してください。\n"
var bh_invalid_myip="無効なIPアドレスです。 もう一度入力するか、空白にしてください"
var bh_invalid_gateway="無効なゲートウェイIPアドレスです。 もう一度入力してください。"
var bh_bpa_invalid_serv_name="無効な認証サーバIPアドレスです。"
var bh_invalid_servip_length="ラベルは63文字以下で設定してください。\n"
var bh_invalid_ip="無効なIPアドレスです。 もう一度入力してください。"
var bh_invalid_mask="無効なサブネットマスクです。 もう一度入力してください。\n"
var bh_same_subnet_ip_gtw="IPアドレスとゲートウェイIPアドレスは同じサブネットに設定してください。\n"
var bh_same_lan_wan_subnet="LAN IPアドレスとWAN IPアドレスは同じサブネットに設定しないでください。"
var bh_filename_null="ファイル名は空欄にできません。"
var hb_invalid_third_dns="サードDNSアドレスが無効です。再度入力してください"
var bh_not_correct_file="正しいファイルを割り当ててください。 ファイル形式は *. です"
var bh_ask_for_restore="警告！ \n設定ファイルを復元すると、現在の設定をすべて消去します。 \n実行してよろしいですか？"
var bh_invalid_primary_dns="無効なプライマリDNSアドレスです。 もう一度入力してください。\n"
var bh_invalid_second_dns="無効なセカンダリDNSアドレスです。 もう一度入力してください。\n"
var bh_dns_must_specified="DNSアドレスを指定してください。"
var bh_invalid_mac="無効なMACアドレスです。"
var bh_failure_head="エラー"
var bh_few_second="この画面は数秒後に前の画面に戻ります..."

var bh_important="重要な更新"
var bh_wanlan_conflict_info="プロバイダとの競合を避けるため、ご利用のルータのIPアドレスを次のように更新してください："
var bh_wanlan_conflict_info2="ポート転送やIPアドレスの予約など各種サービスを利用するためには、ルータの設定でIPアドレスを更新する必要があります。"
var bh_continue_mark="続ける"
var bh_same_server_wan_ip="マイIPアドレスはサーバアドレスと同じにはできません。"

//readySHARE remote strings
var remote_share_head="ReadySHARE クラウド"

var ready_share_info1="ReadySHARE クラウド機能を使うと、ルータのUSBポートに接続されているUSBストレージ機器へ、インターネットからリモートアクセスできます。"
var how_setup_ready_share="ReadySHARE クラウドの設定方法"
var ready_share_step1="Step 1：ReadySHARE クラウドのアカウントが必要です。 アカウントをお持ちでない方は、<a href ='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>こちらをクリック</a>してアカウントを作成してください。"
var ready_share_step2="Step 2：ここでは、ReadySHARE クラウドのユーザ名とパスワードを入力し、ルータとUSB機器を登録します。"
var ready_share_step3="Step 3：アカウントを使って、もう一度<a  href='http://readyshare.netgear.com/'>http://readyshare.netgear.com/</a>にログインします。 初期設定では、ルータに接続されたUSB機器が表示されます"
var ready_share_step4="Step 4：初めてログインする時は、PCからルータのUSB機器へ安全な接続を確立するためのWindowsクライアントをダウンロードするよう案内されます。 このクライアントをインストールしてにログインすると、どこからでもUSBデバイスにアクセスできるようになります。"
var ready_share_set_note="<b>注意：</b> このクライアントをダウンロードしない場合は、ブラウザを使ってUSBデバイスのコンテンツにアクセスすることができますが、ファイルを開いたり、ファイル内容に変更を加えたりすることはできません。"
var ready_share_start="今すぐReadySHARE クラウドを有効にする"
var ready_share_get_account="ReadySHARE クラウドアカウントをお持ちでない場合は、こちらからご登録ください。"
var username="ユーザ名"
var key_passphrase="パスワード"
var register="登録"
var register_note="<b>注意:</b> 登録を解除するまで、インターネット接続は有効なままになります。"
var help_center="ヘルプセンター"
var help_show_hide="ヘルプセンターを表示/隠す"

var resister_user="ReadySHARE クラウドはユーザ登録して使用します。"
var access_storage_method="上記 Step 2～4 に沿って設定することで、どこからでもストレージにアクセスすることができるようになります。"
var unregister_info="<B>［登録解除］</B>をクリックすると、ReadySHARE クラウドに別のユーザとして登録することができます。"
var unregister="登録解除"

var result_register_ok="登録が完了しました。"
var result_register_fail="登録できませんでした。"
var result_unreg_ok="登録解除が完了しました。"
var result_unreg_fail="登録解除できませんでした。"

//WIZ_sel_3g_adsl.htm
var bh_connection_mode="接続モードを選択する"

var bh_ethernet_connection="常にイーサネット接続を使用します。"

var bh_mobile_broadband_connection="常にモバイルブロードバンド接続を使う"

var bh_multi_wan_connection="Failover Mode"

//config_3g_wait_page.htm
var bh_umts_3g_mode="モバイルブロードバンドUSBモデムを検出しています"

//detect_succ_hsdpa.htm
var bh_detect_hsdpa_msg="Please Enter Service Provider Information"
var bh_detect_hsdpa_msg1="Please select the <b>Internet Service Provider</b> and then click <b>next</b>."
var bh_detect_hsdpa_msg2="If your mobile broadband Service Provider is not in pulldown list, please select <b>Other</b>."
var bh_country_3g="国"
var bh_basic_intserv_provider="インターネットサービスプロバイダ"
var bh_access_number_3g="アクセス番号"
//country list
var bh_coun_austrilia="オーストラリア"
var bh_coun_austria="オーストリア"
var bh_coun_belgium="ベルギー"
var bh_coun_brazil="ブラジル"
var bh_coun_chile="チリ"
var bh_coun_china="中国"
var bh_coun_finland="フィンランド"
var bh_coun_germany="ドイツ"
var bh_coun_hk="香港"
var bh_coun_italy="イタリア"
var bh_coun_netherlands="オランダ"
var bh_coun_newzealand="ニュージーランド"
var bh_coun_norway="ノルウェー"
var bh_coun_peru="ペルー"
var bh_coun_russia="ロシア"
var bh_coun_singapore="シンガポール"
var bh_coun_south_africa="南アフリカ"
var bh_coun_sweden="スウェーデン"
var bh_coun_tw="台湾"
var bh_coun_uk="イギリス"
var bh_coun_usa="USA"

//detect_not.htm
var bh_unable_detect_msg="モデムを検出できません。"
var bh_unable_detect_msg1="No a mobile broadband USB Modem adapter detected."
var bh_want_try_again="Do you want to try again?"

//detect_no_sim.htm
var bh_detect_not_simcard="SIMカードが検出されませんでした。"
var bh_detect_not_simcard_msg1="以下のいずれかの問題があると考えられます。"
var bh_detect_not_simcard_msg2="SIMカードが検出されませんでした。"
var bh_detect_not_simcard_msg3="SIMカードが正しくインストールされているか確認してください。"
var bh_detect_not_simcard_msg4="SIMが拒否されました。"
var bh_detect_not_simcard_msg5="SIMカードが有効か確認してください。"
var bh_quit_mark="終了"
