function add_item()
{

}

function select_item(option, value)
{
	if( option == value )
		document.write(' selected ');
}

function change_path(path)
{
	var i,save_file,vol_path,tmp_str,new_str;
	var pos = path.indexOf("/",5);

	if( pos == -1)
	{
		save_file = "";
		vol_path = path;
	}
	else
	{
		save_file = path.substr(pos);
		vol_path = path.substr(0,pos);
	}

	for(i=0; i<sda_num; i++)
	{
		var sda_str = eval('sda_U' + i);
		var e_info = sda_str.split('*');
		if( vol_path == e_info[0] )
		{
			vol_path = e_info[1];
			break;
		}
	}

	if(pos == -1)
		tmp_str=""+vol_path+":/"+save_file+"";
	else
		tmp_str=""+vol_path+":"+save_file+"";

	new_str = tmp_str.replace(/\//g,"\\");

	return new_str;
}

function get_ids(cf,method)
{
	var i = 0;
	var objs = document.getElementsByName("chbx_item");
	for( i=0; i< objs.length; i++ )
	{
		if( objs[i].checked == true )
		{
			var each_info = objs[i].value.split('*');
			var id = each_info[0];
			var stat = each_info[1];
			var show_id = i+1;
			if(method == "pause")
			{
				if( stat != "$greendl_common_showStatusConnecting"  && stat != "$greendl_common_showStatusDownloading" && stat != "$greendl_common_showStatusUSBfull")
				{
					alert("Can't "+method+" task "+show_id+" because it's status is "+stat);
					return false;
				}
			}
			else if(method == "resume")
			{
				if( stat != "$greendl_common_showStatusPaused")
				{
					alert("Can't "+method+" task "+show_id+" because it's status is "+stat);
					return false;
				}
			}
			if( cf.select_ids.value == "" )
				cf.select_ids.value = id;
			else
				cf.select_ids.value = cf.select_ids.value + " " + id;
		}
	}		
	if( cf.select_ids.value == "")
	{	
		alert("$greendl_common_alert_noSelect\n");
		return false;
	}

	return true;
}

function pause_download(cf)
{
	//if( top.green_download_item_num > 0 )
	//{
		if( get_ids(cf,"pause") == false )
			return false;

		if( cf.select_ids_queuen.value != "" )
		{
			alert("$greendl_common_alert_queuen_wrong_action_1\n");
			return false;
		}

		cf.submit_flag.value = "pause_download";
		cf.submit();
	//}
}

function start_download(cf)
{
	//if( top.green_download_item_num > 0 )
	//{
		if( get_ids(cf,"start") == false )
			return false;

		if( cf.select_ids.value == "" && top.green_download_item_num < fileTP_max_concurrent_tasks )
		{
			var index_blank = cf.select_ids_queuen.value.indexOf(" ");

			if( index_blank >= 0 )
			{
				alert("$greendl_common_alert_queuen_wrong_action_3\n");
				return;
			}
		}
		else if( cf.select_ids_queuen.value != "" )
		{
			alert("$greendl_common_alert_queuen_wrong_action_2\n");
			return false;
		}

	cf.submit_flag.value = "start_download";
	cf.submit();
	//}
}

function refresh_download(cf)
{
	cf.submit_flag.value = "refresh_download";
	cf.submit();
}

function resume_download(cf)
{
	//if( top.green_download_item_num > 0 )
	//{
		if( get_ids(cf,"resume") == false )
			return false;

		if( cf.select_ids.value == "" && top.green_download_item_num < fileTP_max_concurrent_tasks )
		{
			var index_blank = cf.select_ids_queuen.value.indexOf(" ");
			if( index_blank >= 0 )
			{
				alert("$greendl_common_alert_queuen_wrong_action_3\n");
				return;
			}
		}
		else if( cf.select_ids_queuen.value != "" )
		{
			alert("$greendl_common_alert_queuen_wrong_action_2\n");
			return false;
		}

        cf.submit_flag.value = "resume_download";
        cf.submit();
	//}
}

function remove_item(cf)
{
	//if( top.green_download_item_num > 0 )
	//{
		if( get_ids(cf,"remove") == false )
			return false;
        cf.submit_flag.value = "remove_download";
        cf.submit();

	//}
}

function remove_history(cf)
{
	cf.submit_flag.value = "remove_history";
	cf.submit();
}

function change_priority(id, cf, sel, pre)
{
	cf.select_ids.value = id;
	cf.priority_val.value = sel.value;
	cf.submit_flag.value = "change_priority";
	cf.submit();
}

function open_browser(form)
{
	form.submit_flag.value="file_browser_open";
	form.submit();
}
function close_browser(form)
{
    form.submit_flag.value="browser_close";
    form.submit();
}

var greenErrorHandling = function(cf) {
	var is_fail = 0;

	if(mlnet_error == "1" && confirm("$greendl_seed_alreay_exist") == true)
		is_fail = 1;
	else if(mlnet_error == "2" && confirm("$greendl_file_alreay_exist") == true)
		is_fail = 1;
	else if(mlnet_error == "3" && confirm("$greendl_insufficient_space") == true)
		is_fail = 1;
	else if(mlnet_error == "4")
		alert("$greendl_fail_connection");
	else if(mlnet_error == "5")
		alert("$greendl_ftp_authenticate_fail");
	else if(mlnet_error == "6")
		alert("$greendl_not_correct_magnet_link");
	else if(mlnet_error == "7")
		alert("$greendl_partition_not_read");

	if(is_fail == 1) {
		cf.submit_flag.value="green_download_fail";
		cf.action="/apply.cgi?/GREEN_basic.htm timestamp=" + ts;
		cf.submit();
	}
}

