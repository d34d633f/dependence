function setGray(cf)
{
	if( cf.enable_autorefresh_status.checked )
		cf.refresh_time.disabled = false;
	else
		cf.refresh_time.disabled = true;
}

function show_Graypage()
{
	var cf=document.forms[0];
	if(disk_num == 0)
	{
		document.getElementById("max_id1").style.color="gray";
		document.getElementById("max_id2").style.color="gray";
		document.getElementById("max_id3").style.color="gray";
		document.getElementById("max_id4").style.color="gray";
		document.getElementById("max_id5").style.color="gray";
		document.getElementById("max_id6").style.color="gray";
		document.getElementById("max_id7").style.color="gray";
		document.getElementById("max_id8").style.color="gray";
		document.getElementById("max_id9").style.color="gray";
		cf.max_tasks.disabled = true;
		cf.Cancel.disabled = true;
		cf.Apply.disabled = true;
		cf.edit.disabled = true;
		cf.Cancel.className ="common_gray_bt";
		cf.Apply.className ="common_gray_bt";
		cf.edit.className ="edit_gray_bt";
		cf.green_download_max_downrate.disabled = true;
		cf.green_download_max_uprate.disabled = true;
		cf.enable_autorefresh_status.disabled = true;
		cf.send_email_noti.disabled = true;

		if(enable_autorefresh_status == "1")
			cf.refresh_time.disabled = true;
	}
	else
	{
		document.getElementById("max_id1").style.color="black";
		document.getElementById("max_id2").style.color="black";
		document.getElementById("max_id3").style.color="black";
		document.getElementById("max_id4").style.color="black";
		document.getElementById("max_id5").style.color="black";
		document.getElementById("max_id6").style.color="black";
		document.getElementById("max_id7").style.color="black";
		document.getElementById("max_id8").style.color="black";	
		document.getElementById("max_id9").style.color="black";
		cf.max_tasks.disabled = false;
		cf.Cancel.disabled = false;
		cf.Apply.disabled = false;
		cf.Cancel.className ="cancel_bt";
		cf.Apply.className ="apply_bt";
		cf.green_download_max_downrate.disabled = false;
		cf.green_download_max_uprate.disabled = false;
		cf.enable_autorefresh_status.disabled = false;
		cf.send_email_noti.disabled = false;
	}
}

function chg_max_task()
{
	var cf=document.forms[0];
	var max_tasks = cf.max_tasks.value;
	var i;
	var choose=document.getElementById("max_tasks");

	for(i=0; i<top.green_downloading_item_num; i++)
	{
		choose.options[i].disabled=true;
	}
	for(i=top.green_downloading_item_num; i<8; i++)
	{
		choose.options[i].disabled=false;
	}
}
