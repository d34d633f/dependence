
function disable_array(items, dis)
{
	for(var l=0; l< items.length; l++)
	{
		items[l].disabled = dis;
	}
}

function gray_by_ser(type)
{

	queue_lists = getElementsByTagAndName("div","queue_list");
	adds = document.getElementsByName("add_list_bt");
	deletes= document.getElementsByName("delete_list_bt");
	clears = document.getElementsByName("clear_list_bt");
	if(type == 1 )
	{
		document.getElementById("ser_tr1").style.color="gray";
		document.getElementById("ser_tr2").style.color="gray";
		document.getElementById("ser_tr3").style.color="gray";
		disable_array(queue_lists, true);
		disable_array(adds, true);
		disable_array(deletes, true);
		disable_array(clears, true);
		for(var q=0; q<queue_lists.length; q++)
		{
			c_nodes = queue_lists[q].childNodes;
			for(var g=0; g<c_nodes.length; g++)
			{
				c_nodes[g].className="grey_DragBox";
			}
		}
	}
	else
	{
		document.getElementById("ser_tr1").style.color="black";
		document.getElementById("ser_tr2").style.color="black";
		document.getElementById("ser_tr3").style.color="black";
		disable_array(queue_lists, false);
		disable_array(adds, false);
		disable_array(deletes, false);
		disable_array(clears, false);
		for(var q=0; q<queue_lists.length; q++)
		{
			c_nodes = queue_lists[q].childNodes;
			for(var g=0; g<c_nodes.length; g++)
			{
				c_nodes[g].className="DragBox";
			}
		}	
	}
}


function gray_by_ip(type)
{
	prioritys = document.getElementsByName("priority");
	table_trs = document.getElementById("table_ip").getElementsByTagName('tr');
	if(type == 1 )
	{
//		document.getElementById("ip_1").style.color="gray";
//		document.getElementById("ip_2").style.color="gray";
		disable_array(prioritys, true);
		
		for( t=0; t<table_trs.length; t++)
			table_trs[t].getElementsByTagName('td')[3].style.color="gray";
		
	}
	else{
//		document.getElementById("ip_1").style.color="black";
//		document.getElementById("ip_2").style.color="black";
		disable_array(prioritys, false);
		for( t=0; t<table_trs.length; t++)
			table_trs[t].getElementsByTagName('td')[3].style.color="black";
	}
}

function gray_fast_lane(type)
{
	fastlane_radios = document.getElementsByName("fastlane");
	table_trs = document.getElementById("table_ip").getElementsByTagName('tr');
	if(type == 1)
	{
		disable_array(fastlane_radios, true);
		for( t=0; t<table_trs.length; t++)
			table_trs[t].getElementsByTagName('td')[4].style.color="gray";	
	}
	else{
		disable_array(fastlane_radios, false);
		for( t=0; t<table_trs.length; t++)
			table_trs[t].getElementsByTagName('td')[4].style.color="black";	
	}
}

function gray_qos_type(type)
{
	qqos_type_name = document.getElementsByName("qqos_type");
	
	if(type == 1)
	{
		document.getElementById("q_type").style.color="gray";

		disable_array(qqos_type_name, true);	
	}
	else{
		document.getElementById("q_type").style.color="black";

		disable_array(qqos_type_name, false);
	}
}

function enable_qqos()
{
	cf = document.forms[0];
	
	if( cf.enable_quick_qos.checked == true )
	{
		cf.hid_enable_quick_qos.value = "1";
		gray_qos_type(0);

                document.getElementById("dev_1").style.color="black";
                document.getElementById("dev_2").style.color="black";

		if( cf.hid_qqos_type.value == "0" )
			gray_by_ser(0);
		else
			gray_by_ser(1);

		if( cf.hid_qqos_type.value == "1" )
			gray_by_ip(0);
		else
			gray_by_ip(1);

		if( cf.hid_qqos_type.value == "2" )
			gray_fast_lane(0);
		else
			gray_fast_lane(1);

	}
	else{
		cf.hid_enable_quick_qos.value="0"
		gray_by_ser(1);
		gray_by_ip(1);
		gray_fast_lane(1);
		
		gray_qos_type(1);
		
		document.getElementById("dev_1").style.color="gray";
		document.getElementById("dev_2").style.color="gray";
	}
}

function change_qqos_type(type)
{
	cf = document.forms[0];

	cf.hid_qqos_type.value = type;

	if(type == 0 )
	{
                gray_by_ser(0);
                gray_by_ip(1);
                gray_fast_lane(1);

	}
	else if( type == 1 )
	{
                gray_by_ser(1);
                gray_by_ip(0);
                gray_fast_lane(1);
	}
	else{
                gray_by_ser(1);
                gray_by_ip(1);
                gray_fast_lane(0);
	}
}

function create_one_rule(n, value)
{
	cf = document.forms[0];
	value = value.replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&#40;/g,"(").replace(/&#41;/g,")").replace(/&#34;/g,'\"').replace(/&#39;/g,"'").replace(/&#35;/g,"#").replace(/&#38;/g,"&");
	one_rule = document.createElement('input');
	one_rule.type = "hidden";
	one_rule.name = "hid_qos_list"+n;
	one_rule.value=""+value+"";
	cf.appendChild(one_rule);
}

/*
find o_value from "l_name list".
If find it, change the priority value (each_info[3]) to p_value
*/
function find_qos_item_details(o_value, l_name, l_num, p_value, compare_type,  num)
{// o_value: service name, l_name: config list name, l_num: list number, p_value: priory value (queue num) , num: hid_qos_list num
// compare_type: 2: applications name or on-line game name, 8: mac address

	cf = document.forms[0];
	for( var x =1; x <=l_num; x=(new_qos_flag == 1) ? x+2 : x+1)
	{// edit a exist item
		var str = eval(l_name+x);
		var each_info = str.split(' ');
		if( o_value == each_info[compare_type]) //each_info[2]applications name or on-line game name, each_info[8]: mac address
		{// find a exist item
			num++;
			var i_value = each_info[0];
			// change the priority value. 
			for( var t=1; t< each_info.length; t++)
			{
				if( t == 3 )
					i_value = i_value + ' ' + p_value; // change each_info[3] to p_value
				else
					i_value = i_value + ' ' + each_info[t];
			}
			create_one_rule(num, i_value);
			if( new_qos_flag == 1)
			{// new qos, every rule have 2 configs
				num++;
				var str2 = eval(l_name+(x+1));

				if( str2 == "0" )
					i_value = "0";
				else{
					each_info = str2.split(' ');
					i_value = each_info[0];
					for( t=1; t< each_info.length; t++)
					{
						if( t == 3 )
							i_value = i_value + ' ' + p_value; // // change each_info[3] to p_value
						else
							i_value = i_value + ' ' + each_info[t];
					}
				}
				create_one_rule(num, i_value);
			}
			break;
		}

	}
	return num;
}

/*
when I change qos by service, "LAN Port" and "MAC" qos list not need change.
just find them and save: add_other_types_old_qos_items("23", n) 
when I change qos by device, "application", "on-line gaming" and "LAN Port" qos list not need change.
just find then and save: add_other_types_old_qos_items("012", n)

multitype: 0: applycation, 1: on-line game, 2: LAN Port, 3 MAC address
*/
function add_other_types_old_qos_items(multi_type, num)
{
	var cf = document.forms[0];

	for(var i=1; i<=qos_array_num ; i=(new_qos_flag == 1) ? i+2 : i+1)
	{
		var str = eval("qosArray"+i);
		var each_info = str.split(' ');
		if(multi_type.indexOf(each_info[1])!= -1)
		{
			num++;
			create_one_rule(num, str);
			if(new_qos_flag == 1)
			{
				num++;
				var str2 = eval("qosArray"+(i+1));
				create_one_rule(num, str2);
			}
		}
	}

	return num;
}

function check_quick_qos()
{
	var cf = document.forms[0];
	var n = 0; // hid_qos_list number

	if(cf.hid_enable_quick_qos.value == '1')
	{// enable quick qos
		if(cf.hid_qqos_type.value == '0')
		{// add qos by service, change advanced/setup/qos configs
			queue_lists = getElementsByTagAndName("div", "queue_list");
			for( var i = 0; i < 4; i ++ )
			{//every queue list
				oql = queue_lists[i];
				for(var j = 0; j< oql.childNodes.length; j++)
				{// every qos item 
					childnode = oql.childNodes[j];
					node_value = childnode.getAttribute('val0_name');
					node_app_type = childnode.getAttribute('val2_app_name');

					// find the same service qos item in "qosArray"
					if( node_app_type == "Add" )//if this is a manully add qos rule, compare qos rule name
						c_n = find_qos_item_details(node_value, "qosArray", qos_array_num, i, 0, n);
					else// if this is a exist service qos rule, compare with service name
						c_n = find_qos_item_details(node_app_type, "qosArray", qos_array_num, i, 2, n);

					if( c_n == n ) // not find in "qosArray", find the service qos item in default qos values qosDftArray
						c_n = find_qos_item_details(node_value, "qosDftArray", qos_dft_array_num,i, 2, n);

					n = c_n;
				}
			}

			//Add LAN & MAC items / "23": 2: LAN port 3: MAC
			c_n = add_other_types_old_qos_items("23", n); 
			n = c_n;
		}
		else if( cf.hid_qqos_type.value == '1')
		{// add qos by device
			prioritys = document.getElementsByName("priority");

			//"012": 0: application, 1: on-line game, 2: LAN port
			c_n = add_other_types_old_qos_items("012", n);
			n = c_n;
			for(i=0;i<attach_array.length;i++)
			{
				priority_value = prioritys[i].value;
				// finding mac address from qosArray
				c_n = find_qos_item_details(attach_mac_array[i], "qosArray", qos_array_num, priority_value, 8, n);
				if( c_n == n ) // "qosArray" list not have this mac, add a new mac qos rule
				{
					n++;
		                        var def_name=attach_mac_array[i].substring(9,11)+attach_mac_array[i].substring(12,14)+attach_mac_array[i].substring(15,17);
                		        var policy_name='Pri_MAC_'+def_name;

					i_value = policy_name + ' 3 ---- '+ priority_value +' ---- ---- ---- '+ attach_name_array[i] +' '+ attach_mac_array[i];
					create_one_rule(n, i_value);
					if(new_qos_flag == 1)
					{
						n++;
						create_one_rule(n, i_value);
					}
				}
				else
					n=c_n;
			}
		}
		else if( cf.hid_qqos_type.value == '2')
		{// add fast lane
			var fasts = document.getElementsByName("fastlane");

			if(fasts.length == 1 )
			{
				if(cf.fastlane.checked == true)
					cf.fastlane_dev.value = attach_mac_array[0];
			}
			else
			{
				for(i=0; i< fasts.length; i++)
				{
					if(fasts[i].checked == true)
						cf.fastlane_dev.value = attach_mac_array[i];
				}
			}

		}

		if( cf.wps_fastlane[0].checked == true )
			cf.hid_wps_fastlen.value = "wps";
		else
			cf.hid_wps_fastlen.value = "fastlane";
	}
}

function change_service_name_show(name)
{
                if(name=="IP_Phone")
                        new_name="$qos_ipphone";
                else if(name=="Skype")
                        new_name="$qos_skype";
                else if(name=="Netgear_EVA")
                        new_name="$qos_netgear";
		else if(name=="Vonage_IP_Phone")
			new_name="$qos_vonage";
                else if(name=="Google_Talk")
                        new_name="$qos_google";
                else if(name=="MSN_messenger")
                        new_name="$qos_msn";
                else if(name=="Yahoo_messenger")
                        new_name="$qos_yahoo";
                else if(name=="Netmeeting")
                        new_name="$qos_netmeeting";
                else if(name=="AIM")
                        new_name="$qos_aim";
                else if(name=="SlindStream")
                        new_name="$qos_slingstream";
                else if(name=="SSH")
                        new_name="$block_ser_setup_ssh";
                else if(name=="Telnet")
                        new_name="$block_ser_setup_telnet";
                else if(name=="VPN")
                        new_name="$qos_vpn";
                else if(name=="On_line_Game")
                        new_name="On-line Game";
                else if(name=="FTP")
                        new_name="$ftp_mark";
                else if(name=="SMTP")
                        new_name="$block_ser_setup_smtp";
		else if(name=="PPlive")
			new_name="$qos_pplive";
		else if(name=="WWW")
			new_name="$qos_www";
		else if(name=="DNS")
			new_name="$block_ser_setup_dns";
		else if(name=="ICMP")
			new_name="$qos_icmp";
		else if(name=="eMule")
			new_name="$qos_emule";
		else if(name=="Kazaa")
			new_name="$qos_kazaa";
		else if(name=="Gnutella")
			new_name="$qos_gnutella";
		else if(name=="bt_azureus")
			new_name="$qos_bt_azureus";
		else if(name=="Counter-Strike")
			new_name="$qos_counter_strike";
		else if(name=="Age-of-Empires")
			new_name="$qos_ageof_empires";
		else if(name=="Everquest")
			new_name="$qos_everquest";
		else if(name=="Quake-2")
			new_name="$qos_quake2";
		else if(name=="Quake-3")
			new_name="$qos_quake3";
		else if(name=="Unreal-Tourment")
			new_name="$qos_unreal";
		else if(name=="Warcraft")
			new_name="$qos_warcraft";
		else if(name=="Thunder")
			new_name="$qos_pr_thunder";
		else if(name=="QQ_xuanfeng")
			new_name="$qos_pr_qq_xuanfeng";
		else if(name=="LOL")
			new_name="$qos_pr_lol";
		else if(name=="YY_yuyin")
			new_name="$qos_pr_yy";
		else if(name=="Tonghuashun")
			new_name="$qos_pr_tonghuashun";
		else if(name=="Dazhihui")
			new_name="$qos_pr_dazhihui";
		else if(name=="sipnet.ru")
			new_name="$qos_ru_sipnet";
                else
                        new_name=name;
                return new_name;
}


