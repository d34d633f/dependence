<?
$m_html_title="アップロード";
$m_context_title="アップロード";
$m_context="システムエラーです!!!<br>再試行してください。";
$m_button_dsc="戻る";
?>
