<?
$m_context_title = "無線パーティション";
$m_isc = "内部ステーション接続";
$m_guest = "ゲストモード";
$m_ewa = "イーサネットからのWLANアクセス";
$m_enable = "有効";
$m_disable = "無効";
$m_band = "無線帯域";
$m_band_5G = "5GHz";
$m_band_2.4G = "2.4GHz";
$m_pri_ssid = "プライマリSSID";
$m_ms_ssid1 = "マルチSSID 1";
$m_ms_ssid2 = "マルチSSID 2";
$m_ms_ssid3 = "マルチSSID 3";
$m_ms_ssid4 = "マルチSSID 4";
$m_ms_ssid5 = "マルチSSID 5";
$m_ms_ssid6 = "マルチSSID 6";
$m_ms_ssid7 = "マルチSSID 7";
?>
