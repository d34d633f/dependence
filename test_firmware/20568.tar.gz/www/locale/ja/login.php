<?
$a_invalid_user_name	="ユーザ名を入力してください。";

$m_html_title		="ログイン";
$m_context_title	="ログイン";
$m_login_router		="ルータにログインする:";
$m_login_ap		="アクセスポイントにログインする:";
$m_log_in		=" ログイン ";
?>
