<?
$ssid_flag = query("/runtime/web/display/mssid_index4");
$m_context_title = "システム情報";
$m_model_name	= "モデル名";
$m_sys_time	="システムの時刻";
$m_up_time	="システム稼動時間";
$m_firm_version	="ファームウェアバージョン";
$m_ip	="IPアドレス";
$m_mac	="MACアドレス";
if($ssid_flag == "1")
{
	$m_mssid	="SSID 1~3";
}
else
{
$m_mssid	="SSID 1~7";
}
$m_ap_mode ="動作モード";
$m_days = "曜日";
$m_sysname = "システム名";
$m_location = "位置";
$m_ap = "アクセスポイント";
$m_wireless_client = "ワイヤレスクライアント";
$m_wds_ap = "WDS with AP";
$m_wds = "WDS";
?>
