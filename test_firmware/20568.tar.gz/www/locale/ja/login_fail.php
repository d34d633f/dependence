<?
$m_html_title	= "ログイン失敗";
$m_context_title= "ログイン失敗";
$m_context	= "ユーザ名またはパスワードが間違っています。";
$m_button_dsc	= "再ログイン";
?>
