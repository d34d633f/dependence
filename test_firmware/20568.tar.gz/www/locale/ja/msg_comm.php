<?
$m_user_name		="ユーザ名";
$m_password		="パスワード";
$m_continue		="継続";
$m_nochg_title		="変更なし";
$m_nochg_dsc		="設定は変更されていません。";
$m_saving_title		="保存中";
$m_saving_dsc		="設定を保存し、有効中。";
$m_saving_dsc_wait = "お待ちください...";
$m_saving_dsc_change_ip = "約10秒待ち、設定した新しいIPアドレスを使用してデバイスにアクセスしてください。";
$m_scan_title		="スキャン";
$m_detect_title	="検知";
$m_scan_dsc		="スキャン中... <br><br>お待ちください...";
$m_clear = "クリア";

$TITLE=query("/sys/hostname");
$first_frame = "home_sys";
$m_logo_title	=query("/sys/hostname");
?>
