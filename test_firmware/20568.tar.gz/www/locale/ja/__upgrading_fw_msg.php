ファームウェアの更新中です...<br><br>
<font color=red><b>を切らずに</b></font>デバイスの電源.<br><br>
<input type='text' readonly name='WaitInfo' value='150' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
秒間お待ちください...
