<?
$version_no=query("/runtime/sys/info/firmwareverreve");
$build_no=query("/runtime/sys/info/firmwarebuildno");

$m_context_title	="バージョン";

$m_context = "バージョン: ".$version_no."<br><br>ビルド番号: ".$build_no."<br><br>";
$m_context = $m_context."システムを更新: <script>document.write(shortTime());</script>";

$m_days		= "曜日";
$m_button_dsc	=$m_continue;
?>
