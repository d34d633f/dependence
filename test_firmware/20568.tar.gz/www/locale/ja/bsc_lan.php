<?
$m_context_title = "LAN設定";

$m_lan_type  = "IPアドレス取得";
$m_static_ip = "スタティックIP（手動）";
$m_dhcp      = "ダイナミックIP（DHCP）";

$m_ipaddr    = "IPアドレス";
$m_subnet    = "サブネットマスク";
$m_gateway   = "デフォルトゲートウェイ";

$a_invalid_ip= "無効なIPアドレスです!";
$a_invalid_netmask= "無効なサブネットマスクです!";
$a_invalid_gateway= "無効なゲートウェイIPアドレスです!";
$a_connect_new_ip = "新しいIPアドレスで接続してください!";
?>
