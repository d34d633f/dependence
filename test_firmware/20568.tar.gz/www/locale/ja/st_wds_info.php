<?
$m_context_title = "WDS情報";
$m_client_info = "WDS情報";
$m_st_association  = "11とのステーションアソシエーション";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "帯域";
$m_auth = "認証";
$m_signal = "信号";
$m_power = "省電力モード";
$m_wpa		= "WPA-";
$m_wpa2		= "WPA2-";
$m_wpa_auto		= "WPA2-(自動)";
$m_eap		= "エンタープライズ";
$m_psk		= "パーソナル";
$m_open		="オープンシステム";
$m_shared	="共有キー";
$m_disabled		="無効";
$m_channel = "チャネル";
$m_name = "名前";
$m_status = "ステータス";
$wds = "W";
$m_on = "On";
$m_off = "Off";
$m_none = "なし";
?>
