<?
$m_context_title = "ファームウェアおよびSSL証明書のアップロード";

$m_upload_fw_title ="ローカルハードドライブからファームウェアをアップロード";
$m_firmware_version	="ファームウェアバージョン";
$m_upload_firmware_file	="ファイルからファームウェアをアップロード";	
$m_upload_lang_title ="言語ファイル（日本語化対応）のアップグレード";	
$m_upload_lang_file	="アップロード";	
$m_upload_ssl_titles = "ローカルハードドライブからSSL証明書をアップロード";
$m_upload_certificatee_file	= "ファイルから証明書をアップロード";	
$m_upload_key_file	= "ファイルからキーをアップロード";	
$m_b_fw_upload = "アップロード";
$a_blank_fw_file= "空のファイルを使用することはできません!";
$a_format_error_file ="ファイルフォーマットのエラーです!再試行してください!";
?>
