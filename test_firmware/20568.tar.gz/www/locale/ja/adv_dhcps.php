<?
$MAX_RULES=query("/lan/dhcp/server/pool:1/staticdhcp/max_client");
if ($MAX_RULES==""){$MAX_RULES=25;}	
$m_context_title = "スタティックプール設定";
$m_srv_enable = "機能の有効/無効";
$m_disable = "無効";
$m_enable = "有効";
$m_dhcp_srv = "DHCPサーバ制御";
$m_dhcp_pool = "スタティックプール設定";
$m_computer_name = "コンピュータ名";
$m_ipaddr = "割り当てられたIPアドレス";
$m_macaddr = "割り当てられたMACアドレス";
$m_ipmask = "サブネットマスク";
$m_gateway = "ゲートウェイ";
$m_wins = "Wins";
$m_dns = "DNS";
$m_m_domain_name = "ドメイン名";
$m_on = "ON";
$m_off = "OFF";
$m_status_enable = "ステータス";
$m_mac = "MACアドレス";
$m_ip = "IPアドレス";
$m_state = "状態";
$m_edit = "編集";
$m_del = "削除";

$a_invalid_host		= "コンピュータ名が不正です！";
$a_invalid_ip		= "無効なIPアドレスが指定されました!";
$a_invalid_mac		= "無効なMACアドレスが指定されました!";
$a_max_mac_num = "アクセスコントロールリストの最大登録数は".$MAX_RULES."件です!";
$a_same_mac = "このMACアドレスはすでに使用されています。\\n MACアドレスを変更してください。";
$a_invalid_netmask	= "無効なサブネットマスクです!";
$a_invalid_gateway	="無効なゲートウェイです!";
$a_invalid_wins	= "無効なWINSサーバです!";
$a_invalid_dns	="無効なDNSサーバです!";
$a_invalid_domain_name	= "無効なドメイン名です!";
$a_invalid_lease_time	= "無効なDHCPリース時間です!";
$a_entry_del_confirm = "本当にこのエントリを削除しますか？";
?>
