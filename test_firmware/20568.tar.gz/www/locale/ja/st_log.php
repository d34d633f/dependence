<?
$m_context_title	= "ログの表示";

$m_first_page	= "最初のページ";
$m_last_page	= "最後のページ";
$m_previous	= "前へ";
$m_next		= "次へ";
$m_clear	= "クリア";

$m_time		= "時間";
$m_type		= "プライオリティ";//"Type";
$m_message	= "メッセージ";
$m_page		= "ページ";
$m_of		= "ページ目";
?>
