<?
$m_html_title="ログアウト";
$m_context_title="ログアウト";
$m_context="正常にログアウトしました";
$m_button_dsc="ログインページに戻る";
?>
