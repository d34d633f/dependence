<?
$m_context_title = "システム設定";
$m_reboot		=" デバイスの再起動";
$m_b_reboot		=" 再起動";
$m_factory_reset	="工場出荷時の状態に戻す";
$m_b_restore		="復元";
$m_clear_lang_pack ="言語ファイルをクリアにする"; 
$m_clear ="片付ける";
$a_sure_to_clear_lang ="言語ファイルをクリアにしますか？";
$a_sure_to_factory_reset="工場出荷時状態への復元?";
$a_sure_to_reboot	="アクセスポイントを再起動しますか?";

?>
