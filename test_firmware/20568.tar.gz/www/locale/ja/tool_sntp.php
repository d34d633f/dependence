<?
$m_context_title = "日付.時刻設定";
$m_time_config_title = "時刻設定";
$m_auto_time_config_title = "自動時刻設定";
$m_set_date_time_title = "手動で日付と時刻を設定する";
$m_time				= "現在の時刻";
$m_time_zone			= "タイムゾーン";
$m_enable_daylight_saving	= "夏時間を有効にする";

$m_title_ntp	= "自動時刻設定";
$m_enable_ntp		= "NTPサーバの有効化";
$m_interval		= "間隔";
$m_ntp_server		= "NTPサーバ";
$m_select_ntp_server	= "NTPサーバの選択";

$m_current_time	= "日付と時刻";
$m_year		= "年";
$m_month	= "月";
$m_day		= "日";
$m_days		= "曜日";
$m_hour		= "時";
$m_minute	= "分";
$m_second	= "秒";
$m_copy_pc_time	= "コンピュータの時刻設定をコピーする";
$m_daylight_saving_offset	="夏時間オフセット";
$m_daylight_saving_date	="夏時間指定日";
$m_week ="週";
$m_day_of_week = "曜日";
$m_dst_start = "夏時間開始";
$m_dst_end = "夏時間終了";
$m_jan = "1月";
$m_feb = "2月";
$m_mar = "3月";
$m_apr = "4月";
$m_may = "5月";
$m_jun = "6月";
$m_jul = "7月";
$m_aug = "8月";
$m_sep = "9月";
$m_oct = "10月";
$m_nov = "11月";
$m_dec = "12月";
$m_1st = "1番";
$m_2nd = "2番";
$m_3rd = "3番";
$m_4th = "4番";
$m_5th = "5番";
$m_sun = "日";
$m_mon = "月";
$m_tue = "火";
$m_wed = "水";
$m_thu = "木";
$m_fri = "金";
$m_sat = "土";
$m_am = " 午前";
$m_pm = " 午後";


$a_invalid_ntp_server	= "無効なNTPサーバです!";
?>
