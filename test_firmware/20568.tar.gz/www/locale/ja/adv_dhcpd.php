<?
$m_context_title = "ダイナミックプール設定";
$m_srv_enable = "機能の有効/無効";
$m_disable = "無効";
$m_enable = "有効";
$m_dhcp_srv = "DHCPサーバ制御";
$m_dhcp_pool = "ダイナミックプール設定";
$m_ipaddr = "IP割り当て範囲";
$m_iprange = "アドレスプールの範囲（1-254）";
$m_ipmask = "サブネットマスク";
$m_gateway = "ゲートウェイ";
$m_wins = "WINS";
$m_dns = "DNS";
$m_m_domain_name = "ドメイン名";
$m_m_lease_time = "リース時間（60-31536000秒）";
$m_on = "ON";
$m_off = "OFF";
$m_status_enable = "ステータス";
$m_index = "インデックス";
$m_pri_ssid = "プライマリSSID";
$m_ms_ssid1 = "SSID 1";
$m_ms_ssid2 = "SSID 2";
$m_ms_ssid3 = "SSID 3";
$m_ms_ssid4 = "SSID 4";
$m_ms_ssid5 = "SSID 5";
$m_ms_ssid6 = "SSID 6";
$m_ms_ssid7 = "SSID 7";
$m_ssid = "SSID";
$m_multi_dhcp = "マルチDHCP制御";
$m_multi_dhcp_enable ="マルチDHCP機能の有効/無効";
$m_multi_srv_enable ="マルチDHCPサーバの有効/無効";
$m_multi_dhcp_srv = "マルチDHCPサーバ制御";
$m_index="インデックス";


$a_invalid_ip		= "無効なIPアドレスです!";
$a_invalid_ip_range	= "無効なIPアドレス範囲です!";
$a_invalid_netmask	= "無効なサブネットマスクです!";
$a_invalid_gateway	="無効なゲートウェイです!";
$a_invalid_wins	= "無効なWINSサーバです!";
$a_invalid_dns	="無効なDNSサーバです!";
$a_invalid_domain_name	= "無効なドメイン名です!";
$a_invalid_lease_time	= "無効なDHCPリース時間です!";

?>
