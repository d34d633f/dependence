<?
$m_context_title	= "ログ設定";
$m_log_setting_title = "ログ設定";
$m_log_ip	=  "ログサーバ/IPアドレス";
$m_log_type = "ログタイプ";
$m_system_activity	=  "システム動作";
$m_wireless_activity	=  "無線動作";
$m_notice	=  "通知";
$m_smtp_setting_title = "Eメール通知";
$m_smtp = "Eメール通知";
$m_enable = "有効";
$m_smtp_ip = "メールサーバアドレス";
$m_smtp_from_email = "メール送信元";
$m_smtp_to_email = "メール送信先";
$m_email_log_schedule_title = "ログのメール送信スケジュール";
$m_log_schedule = "スケジュール";
$m_log_schedule_msg = "時間指定またはログ満杯時";
$m_smtp_name = "ユーザ名";
$m_smtp_password ="パスワード";
$m_smtp_confirm_password ="パスワード確認";
$m_smtp_port = "SMTPポート";

$a_invalid_log_ip		= "無効なサーバ/IPアドレスです!";
$a_invalid_smtp_ip		= "無効なメールサーバ/IPアドレスです!";
$a_empty_user_name	="ユーザ名を入力してください。";
$a_invalid_user_name	="ユーザ名に無効な文字が含まれています。再度確認してください。";
$a_first_blank_user_name	= "ユーザ名の最初の文字に空白を使用することはできません。";
$a_invalid_new_password	="パスワードに無効な文字が含まれています。再度確認してください。";
$a_password_not_matched	="パスワードと確認用パスワードが一致しません。";
$a_invalid_smtp_port = "無効なSMTPポートです!";
?>
