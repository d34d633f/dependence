<?
$tool_admin = "管理設定";
$tool_fw = "ファームウェアおよびSSL証明書のアップロード";
$tool_config = "設定ファイル";
$tool_sntp = "時刻と日付";
$logout_msg = "&nbsp;&nbsp;ここをクリックすると、現在のブラウザ接続は切断されます。";
?>
