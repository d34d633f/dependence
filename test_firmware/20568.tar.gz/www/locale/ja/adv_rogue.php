<?
$m_context_title = "無線不正侵入防止";
$m_b_detect = "検知";
$m_ap_list_title = "APリスト";
$m_type = "タイプ";
$m_band = "帯域";
$m_channel = "チャネル";
$m_ssid = "SSID";
$m_mac = "BSSID";
$m_last_seem = "最後に検知されたAP";
$m_status = "ステータス";
$m_b_valid = "有効として設定";
$m_b_neighborhood = "ネイバーとして設定";
$m_b_rogue = "不正として設定";
$m_b_new = "新規として設定";
$m_all_valid = "すべての新しいアクセスポイントを有効なアクセスポイントとして登録する";
$m_all_rogue = "すべての新しいアクセスポイントを不正アクセスポイントとして登録する";
$m_valid = "有効";
$m_neighborhood = "ネイバー";
$m_rogue = "不正";
$m_new = "新規";
$m_a = "A";
$m_b = "B";
$m_g = "G";
$m_n = "N";
$m_days = "日";
$m_all = "すべて";
$m_up = "アップ";
$m_down = "ダウン";

$a_max_list = "このタイプのリストの最大登録数は64件です! \\n";
$a_can_add_num = "追加できます";
$a_entry = " エントリ";
$a_no_click = "クリックされていません!";
?>
