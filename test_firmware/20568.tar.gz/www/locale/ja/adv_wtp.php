<?
$m_context_title = "WLANスイッチ設定";
$m_wtp_title = "無線ターミネーションポイント設定";
$m_connect_title = "接続情報";
$m_wtp_enable = "WTPの有効化";
$m_wtp_name = "WTP名";
$m_wtp_location = "WTP位置情報";
$m_ac_ip = "WLANスイッチIP";
$m_ac_name = "WLANスイッチ名";
$m_ac_ipaddr = "WLANスイッチIPアドレスAddress";
$m_ac_ip_list_title = "WLANスイッチアドレスリスト";
$m_id = "ID";
$m_ip = "IPアドレス";
$m_del = "削除";

$a_wtp_del_confirm		= "本当にこのIPアドレスを削除しますか？";
$a_same_wtp_ip	= "このIPアドレスはすでに登録されています。\\n 他のIPアドレスに変更してください。";
$a_invalid_ip		= "無効なIPアドレスです!";
$a_max_ip_table		= "WLANスイッチアドレスリストの最大登録数は8件です!";
?>
