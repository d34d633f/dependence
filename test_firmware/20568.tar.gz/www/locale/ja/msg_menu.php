<?
// category
$m_menu_top_bsc		="設定";
$m_menu_top_adv		="詳細";
$m_menu_top_tools	="メンテナンス";
$m_menu_top_st		="ステータス";
$m_menu_top_spt		="サポート";

// basic
$m_menu_bsc_wizard      ="ウィザード";
$m_menu_bsc_internet	="インターネット";
$m_menu_bsc_wlan	="無線設定";
$m_menu_bsc_lan		="LAN設定";

// advanced
$m_menu_adv_vrtsrv	="仮想サーバ";
$m_menu_adv_port	="ポートフォワーディング";
$m_menu_adv_app		="アプリケーションルール";
$m_menu_adv_mac_filter	="ネットワークフィルタ";
$m_menu_adv_acl		="フィルタ";
$m_menu_adv_url_filter	="Webサイトフィルタ";
$m_menu_adv_dmz		="ファイアウォール設定";
$m_menu_adv_wlan	="パフォーマンス";
$m_menu_adv_network	="詳細ネットワークNETWORK";
$m_menu_adv_dhcp	="DHCPサーバ";
$m_menu_adv_mssid	="マルチSSID";
$m_menu_adv_group	="ユーザ数制限";
$m_menu_adv_wtp		="WLANスイッチ";
$m_menu_adv_wlan_partition	="WLANパーティション";

// tools
$m_menu_tools_admin	="デバイス管理";
$m_menu_tools_time	="時間";
$m_menu_tools_system	="システム";
$m_menu_tools_firmware	="ファームウェア";
$m_menu_tools_misc	="各種";
$m_menu_tools_ddns	="DDNS";
$m_menu_tools_vct	="システムチェック";
$m_menu_tools_sch	="スケジュール";
$m_menu_tools_log_setting	="ログ設定";

// status
$m_menu_st_device	="デバイス情報";
$m_menu_st_log		="ログ";
$m_menu_st_stats	="統計情報";
$m_menu_st_wlan		="クライアント情報";

// support
$m_menu_spt_menu	="メニュー";

$m_logout	="ログアウト";

$m_menu_home	="ホーム";
$m_menu_tool	="メンテナンス";
$m_menu_config	="設定";
$m_menu_sys	="システム";
$m_menu_logout	="ログアウト";
$m_menu_help	="ヘルプ";

$m_menu_tool_admin	="管理者設定";
$m_menu_tool_fw	="ファームウェアおよびSSL証明書のアップロード";
$m_menu_tool_config	="設定ファイル";
$m_menu_tool_sntp	="SNTP";

$m_menu_config_save	="保存し有効にする";
$m_menu_config_discard	="変更内容を破棄";

$a_config_discard ="すべての変更内容は破棄されます。続けますか？";

?>
