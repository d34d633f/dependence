<?
$m_context_title	="&nbsp";
$m_context		="<strong>管理者</strong>アカウントからのみ変更が可能です。";
$m_button_dsc		=$m_continue;
?>
