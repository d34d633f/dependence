<?
$m_html_title="間違ったなファームウェアイメージです";
$m_context_title="間違ったなファームウェアイメージです";
$m_context="選択したファイルはイメージファイルではありません。";
$m_button_dsc=$m_continue;
?>
