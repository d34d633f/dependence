<?
$m_context_title = "クライアント情報";
$m_client_info = "クライアント情報";
$m_st_association  = "ステーション接続";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "帯域";
$m_auth = "認証";
$m_signal = "信号";
$m_power = "省電力モード";
$m_multi_ssid = "マルチSSID";
$m_primary_ssid = "プライマリSSID";
$m_on = "On";
$m_off = "Off";
?>
