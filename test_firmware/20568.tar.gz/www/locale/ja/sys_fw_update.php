<?
$m_menu_upgrade_fw = "<font face=\"Arial\" color=\"red\" size=2>".
					 "<font face=\"Arial\" size=2>".
					 .query("/sys/hostname").
					 "が物理的に破損する恐れがあるため、本プロセス中はデバイスの電源を切らないでください。（ブラウザが自動的にWebページをリダイレクトしない場合は、更新ボタンをクリックしてください。）</font>";
					 
$m_upload_fw = "ファームウェアをアップロード中...";
$m_verify_fw = "ファームウェアを確認中...";
$m_upgrad_device = "デバイスのアップグレード中...";
$m_reboot_device = "デバイスを再起動中...";

$a_upgrade_fw_fail_msg = "ファームウェアのアップグレードに失敗しました。ファームウェアをリロードして、再度アップグレードを行ってください。";

?>
