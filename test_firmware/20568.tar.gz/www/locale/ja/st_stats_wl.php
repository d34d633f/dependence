<?

$msg_title="WLANトラフィック統計情報";
$msg_t_title="送信カウント";
$msg_t_msg1="送信パケット数";
$msg_t_msg2="送信バイト数";
$msg_t_msg3="廃棄パケット数";
$msg_t_msg4="送信リトライ数";
$msg_r_title="受信カウント";
$msg_r_msg1="受信パケット数";
$msg_r_msg2="受信バイト数";
$msg_r_msg3="廃棄パケット数";
$msg_r_msg4="受信CRC数";
$msg_r_msg5="受信復号化エラー数";
$msg_r_msg6="受信MICエラー数";
$msg_r_msg7="受信PHYエラー数";
$msg_clear="クリア";
$msg_refresh="更新";




?>
