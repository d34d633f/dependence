<?
$m_context_title = "設定ファイルのアップロードとダウンロード";
$m_save_cfg = "ローカルハードドライブに設定をロードする";
$m_save = "ダウンロード";
$m_load_cfg = "ファイルのアップロード";
$m_b_load = "アップロード";
$m_upload_config_title = "設定ファイルのアップロード";
$m_download_config_title = "設定ファイルのダウンロード";

$a_empty_cfg_file_path	="アップロードを行う保存済み設定ファイルを選択してください。";
$a_error_cfg_file_path	="ファイルフォーマットのエラーです!再試行してください!";
$a_sure_to_reload_cfg	="ファイルから設定をロードしますか？";
?>
