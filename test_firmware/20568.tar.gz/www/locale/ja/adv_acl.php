<?
$m_context_title = "無線MACアドレス ACL設定";
$m_acl_type = "アクセスコントロールリスト";
$m_disable = "無効";
$m_accept = "許可";
$m_reject = "拒否";
$m_wmac = "MACアドレス";
$m_id = "ID";
$m_del = "削除";
$m_wband = "無線帯域";
$m_band_5G = "5GHz";
$m_band_2.4G = "2.4GHz";
$m_ssid = "SSID";
$m_mac = "MACアドレス";
$m_band = "帯域";
$m_auth = "認証";
$m_signal = "信号";
$m_power = "省電力モード";
$m_multi_ssid = "マルチSSID";
$m_primary_ssid = "プライマリSSID";
$m_clirnt_info = "現在のクライアント情報";
$m_b_add = " 追加 ";

$a_acl_del_confirm		= "本当にこのMACアドレスを削除しますか？";
$a_same_acl_mac	= "そのMACアドレスはすでに使用されています。\\n 他のMACアドレスを指定してください。";
$a_invalid_mac		= "無効なMACアドレスです!";
$a_max_acl_mac		= "アクセスコントロールリストの最大登録数は256件です!";

?>
