<?
$m_context_title = "現在のIPアドレスリスト";
$m_host_name = "ホスト名";
$m_mac = "バインディングMACアドレス";
$m_ip = "割り当てられたIPアドレス";
$m_time = "リース時間";
$m_dynamic_pools = "現在のDHCPダイナミックプール";
$m_static_pools = "現在のDHCPスタティックプール";
$m_days			="曜日";
$m_hrs			="時";
$m_mins			="分";
$m_secs			="秒";
?>
