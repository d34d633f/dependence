<?
$m_html_title="セッションフル";
$m_context_title="セッションフル";
$m_context="ログインセッションが最大数に達しました。再試行してください。";
$m_button_dsc="再ログイン";
?>
