<?
$m_context_title = "パフォーマンス設定";
$m_wl_enable = "無線";
$m_disable = "無効";
$m_enable  = "有効";
$m_off = "Off";
$m_on  = "On";
$m_wlmode = "無線モード";
$m_wlmode_n_g_b = "802.11n、802.11g、802.11b混在";
$m_wlmode_n_g = "802.11n、802.11g混在";
$m_wlmode_g_b = "802.11g、802.11b混在";
$m_wlmode_n = "802.11nのみ";
$m_wlmode_n_a = "802.11n、802.11a混在";
$m_wlmode_a = "802.11aのみ";
$m_rate = "データ速度";
$m_best	= "最高（最大300）";
$m_best_54	= "最高（最大54）";
$m_54	= "54";
$m_48	= "48";
$m_36	= "36";
$m_24	= "24";
$m_18	= "18";
$m_12	= "12";
$m_9	= "9";
$m_6	= "6";
$m_11	= "11";
$m_5.5	= "5.5";
$m_2	= "2";
$m_1	= "1";
$m_beacon_interval	="ビーコン間隔（25-500）";
$m_rts			="RTS閾値（256-2346）";
$m_frag			="フラグメント閾値（256-2346）";
$m_dtim			="DTIM間隔（1-15）";
$m_power = "送信電力";
$m_ms = "(&マイクロ;秒)";

$m_wmm = "WMM（Wi-Fiマルチメディア）";
$m_shortgi = "ショートガードインターバル";
$m_limit_state = "接続制限";
$m_limit_num = "ユーザ数制限（0-64）";
$m_utilization = "ネットワーク使用率";
$m_0 = "0";
$m_10 = "10";
$m_20 = "20";
$m_30 = "30";
$m_40 = "40";
$m_50 = "50";
$m_60 = "60";
$m_70 = "70";
$m_80 = "80";
$m_90 = "90";
$m_100 = "100";
$m_180 = "180";
$m_25 = "25";
$m_12.5 = "12.5";
$m_igmp = "IGMPスヌーピング";
$m_link_integrality="リンクインテグリティ";
$m_ack_timeout="ACKタイムアウト";
$m_mbps = "(Mbps)";
if(query("/runtime/web/display/ack_timeout_range")=="0")
{
$m_ack_timeout_g_msg = " (2.4GHz, 48~200)";
$m_ack_timeout_a_msg = " (5GHz, 25~200)";
	$a_invalid_ack_timeoutg ="ACKタイムアウトの範囲は48-200です。";
	$a_invalid_ack_timeouta ="ACKタイムアウトの範囲は25-200です。";
}
else
{
	$m_ack_timeout_g_msg = " (2.4GHz, 64~200)";
	$m_ack_timeout_a_msg = " (5GHz, 50~200)";
	$a_invalid_ack_timeoutg ="Kタイムアウトの範囲は60-200です。";
	$a_invalid_ack_timeouta ="ACKタイムアウトの範囲は50-200です。";
}
$a_invalid_bi		="ビーコン間隔の範囲は25-500です。";
$a_invalid_rts		="RTS閾値の範囲は256-2346です。";
$a_invalid_frag		="フラグメント閾値の範囲は256-2346です。";
$a_invalid_dtim		="DTIM間隔の範囲は1-15です。";
$a_invalid_limit_num	="ユーザ数制限の範囲は0-64です。";

?>
