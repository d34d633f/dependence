<?
$m_context_title	="&nbsp";
$m_context		="Nur das <strong>Adminkonto</strong> kann die Einstellungen ändern.";
$m_button_dsc		=$m_continue;
?>
