<?
$m_html_title	= "Anmeldung fehlgeschlagen";
$m_context_title= "Anmeldung fehlgeschlagen";
$m_context	= "Benutzername oder Kennwort inkorrekt.";
$m_button_dsc	= "Erneut anmelden";
?>
