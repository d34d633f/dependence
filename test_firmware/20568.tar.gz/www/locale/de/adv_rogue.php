<?
$m_context_title = "Angriffsschutz im drahtlosen Datenverkehr";
$m_b_detect = "Erkennen";
$m_ap_list_title = "AP-Liste";
$m_type = "Typ";
$m_band = "Band";
$m_channel = "CH";
$m_ssid = "SSID";
$m_mac = "BSSID";
$m_last_seem = "Zuletzt gesehen";
$m_status = "Status";
$m_b_valid = "Auf 'Gültig' setzen";
$m_b_neighborhood = "Auf 'Nachbarschaft' setzen";
$m_b_rogue = "Auf 'Rogue' setzen";
$m_b_new = "Auf 'Neu' setzen";
$m_all_valid = "Alle neuen Access Points als gültige Access Points kennzeichnen";
$m_all_rogue = "Alle neuen Access Points als Rogue (d.h. nicht autorisierte) Access Points kennzeichnen";
$m_valid = "Gültig";
$m_neighborhood = "Nachbar";
$m_rogue = "Rogue (nicht autorisiert)";
$m_new = "Neu";
$m_a = "A";
$m_b = "B";
$m_g = "G";
$m_n = "N";
$m_days = "Tage";
$m_all = "Alle";
$m_up = "Nach oben";
$m_down = "Nach unten";

$a_max_list = "Die maximale Anzahl dieser Typenliste ist 64!  \\n";
$a_can_add_num = "Hinzugefügt werden können ";
$a_entry = "  Eingabe";
$a_no_click = "Keine Klickeingabe!";
?>
