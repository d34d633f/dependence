<?
$m_html_title="Hochladen";
$m_context_title="Hochladen";
$m_context="Systemfehler!!!<br>Versuchen Sie es noch einmal.";
$m_button_dsc="Zurück";
?>
