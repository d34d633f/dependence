<?
$m_html_title="Sitzung voll";
$m_context_title="Sitzung voll";
$m_context="Die Anmeldesitzung ist voll.  Versuchen Sie es bitte später noch einmal.";
$m_button_dsc="Erneut anmelden";
?>
