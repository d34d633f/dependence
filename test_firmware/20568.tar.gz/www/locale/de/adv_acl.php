<?
$m_context_title = "Drahtlose MAC ACL-Einstellungen";
$m_acl_type = "Access Control List (ACL/Zugriffssteuerungsliste)";
$m_disable = "Deaktivieren";
$m_accept = "Akzeptieren";
$m_reject = "Ablehnen";
$m_wmac = "MAC-Adresse";
$m_id = "Kennung";
$m_del = "Löschen";
$m_wband = "Frequenzband";
$m_band_5G = "5GHz";
$m_band_2.4G = "2.4GHz";
$m_ssid = "SSID";
$m_mac = "MAC-Adresse";
$m_band = "Band";
$m_auth = "Authentifizierung";
$m_signal = "Signal";
$m_power = "Stromsparmodus";
$m_multi_ssid = "MULTI-SSID ";
$m_primary_ssid = "Primäre SSID";
$m_clirnt_info = "Aktuelle Client-Informationen";
$m_b_add = " Hinzufügen ";

$a_acl_del_confirm		= "Möchten Sie diese MAC-Adresse wirklich löschen?";
$a_same_acl_mac	= "Ein Eintrag mit derselben MAC-Adresse existiert bereits.\\n Ändern Sie bitte die MAC-Adresse.";
$a_invalid_mac		= "Ungültige MAC-Adresse!";
$a_max_acl_mac		= "Die maximale Anzahl von Access Control Lists (Zugriffssteuerungslisten) ist 256!";

?>
