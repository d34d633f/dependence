<?
$m_context_title = "WDS-Informationen";
$m_client_info = "WDS-Informationen";
$m_st_association  = "Stationszuweisung mit 11";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "Band";
$m_auth = "Authentifizierung";
$m_signal = "Signal";
$m_power = "Stromsparmodus";
$m_wpa		= "WPA-";
$m_wpa2		= "WPA2-";
$m_wpa_auto		= "WPA2-Auto-";
$m_eap		= "Enterprise";
$m_psk		= "Personal";
$m_open		="Open System";
$m_shared	="Shared Key";
$m_disabled		="Deaktivieren";
$m_channel = "Kanal";
$m_name = "Name";
$m_status = "Status";
$wds = "W";
$m_on = "Ein";
$m_off = "Aux";
$m_none = "Kein";
?>
