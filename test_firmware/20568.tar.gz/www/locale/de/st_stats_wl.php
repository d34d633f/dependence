<?

$msg_title="WLAN-Datenverkehrstatistik";
$msg_t_title="Gesendet";
$msg_t_msg1="Gesendete Pakete";
$msg_t_msg2="Gesendete Bytes";
$msg_t_msg3="Verlorene Pakete";
$msg_t_msg4="Erneut gesendet";
$msg_r_title="Empfangen";
$msg_r_msg1="Empfangene Pakete";
$msg_r_msg2="Empfangene Bytes";
$msg_r_msg3="Verlorene Pakete";
$msg_r_msg4="Empfangen / Zykl. Redundanzprüfungen";
$msg_r_msg5="Empfangen / Verschlüsselungsfehler";
$msg_r_msg6="Empfangen / MIC-Fehler";
$msg_r_msg7="Empfangen / PHY-Fehler";
$msg_clear="Entfernen";
$msg_refresh="Aktualisieren";




?>
