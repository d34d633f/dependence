<?
$m_context_title = "Partition für Funkdaten";
$m_isc = "Verbindung über interne Station";
$m_guest = "Gastmodus";
$m_ewa = "Ethernet-to-WLAN-Zugriff";
$m_enable = "Aktivieren";
$m_disable = "Deaktivieren";
$m_band = "Frequenzband";
$m_band_5G = "5GHz";
$m_band_2.4G = "2.4GHz";
$m_pri_ssid = "Primäre SSID";
$m_ms_ssid1 = "Multi-SSID 1";
$m_ms_ssid2 = "Multi-SSID 2";
$m_ms_ssid3 = "Multi-SSID 3";
$m_ms_ssid4 = "Multi-SSID 4";
$m_ms_ssid5 = "Multi-SSID 5";
$m_ms_ssid6 = "Multi-SSID 6";
$m_ms_ssid7 = "Multi-SSID 7";
?>
