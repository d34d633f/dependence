<?
$a_invalid_user_name	="Geben Sie bitte den Benutzernamen ein.";

$m_html_title		="ANMELDEN";
$m_context_title	="Anmeldem";
$m_login_router		="Am Router anmelden:";
$m_login_ap		="Am Access Point anmelden:";
$m_log_in		=" Anmeldem ";
?>
