<?
$m_context_title = "LAN-Einstellungen";

$m_lan_type  = "IP abrufen von";
$m_static_ip = "Statische IP (Manuell)";
$m_dhcp      = "Dynamische IP (DHCP)";

$m_ipaddr    = "IP-Adresse";
$m_subnet    = "Subnetzmaske";
$m_gateway   = "Standard-Gateway";

$a_invalid_ip= "Ungültige IP-Adresse!";
$a_invalid_netmask= "Ungültige Subnetzmaske!";
$a_invalid_gateway= "Ungültige Gateway-Adresse!";
$a_connect_new_ip = "Mit neuer IP-Adresse verbinden!";
?>
