<?
$m_context_title = "Firmware- und SSL-Zertifizierung hochladen";

$m_upload_fw_title ="Firmware von lokaler Festplatte aktualisieren";
$m_firmware_version	="Firmware-Version";
$m_upload_firmware_file	="Firmware von Datei hochladen";	
$m_upload_lang_title ="SPRACHPAKET-UPGRADE";	
$m_upload_lang_file	="Hochladen";	
$m_upload_ssl_titles = "SSL-Zertifizierung von der lokalen Festplatte aktualisieren";
$m_upload_certificatee_file	= "Zertifikat von Datei hochladen";	
$m_upload_key_file	= "Schlüssel von Datei hochladen";	
$m_b_fw_upload = "Hochladen";
$a_blank_fw_file= "Leere Datei kann nicht akzeptiert werden!";
$a_format_error_file =" Fehler im Dateiformat. Versuchen Sie es bitte erneut!";
?>
