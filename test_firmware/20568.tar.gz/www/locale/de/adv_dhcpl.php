<?
$m_context_title = "Aktuelle IP-Liste";
$m_host_name = "Host-Name";
$m_mac = "MAC-Adressenbindung";
$m_ip = "Zugewiesene IP-Adresse";
$m_time = "Lease-Zeit";
$m_dynamic_pools = "Aktuelle dynamische DHCP-Pools";
$m_static_pools = "Aktuelle statische DHCP-Pools";
$m_days			="Tage";
$m_hrs			="Stunden";
$m_mins			="Minuten";
$m_secs			="Sekunden";
?>
