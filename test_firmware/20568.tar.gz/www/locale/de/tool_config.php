<?
$m_context_title = "Konfigurationsdatei hoch- bzw. herunterladen";
$m_save_cfg = "Einstellungen auf die lokale Festplatte laden";
$m_save = "Herunterladen";
$m_load_cfg = "Datei hochladen";
$m_b_load = "Hochladen";
$m_upload_config_title = "Konfigurationsdatei hochladen";
$m_download_config_title = "Konfigurationsdatei herunterladen";

$a_empty_cfg_file_path	="Wählen Sie bitte eine gespeicherte Konfigurationsdatei zum Hochladen.";
$a_error_cfg_file_path	="Fehler im Dateiformat. Versuchen Sie es bitte erneut.";
$a_sure_to_reload_cfg	="Einstellungen aus Datei laden?";
?>
