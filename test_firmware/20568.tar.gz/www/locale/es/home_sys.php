<?
$ssid_flag = query("/runtime/web/display/mssid_index4");
$m_context_title = "Información del sistema";
$m_model_name	= "Nombre de modelo";
$m_sys_time	="Hora del sistema";
$m_up_time	="Tiempo de actividad";
$m_firm_version	="Versión de firmware";
$m_ip	="Dirección IP";
$m_mac	="Dirección MAC";
if($ssid_flag == "1")
{
	$m_mssid	="SSID 1~3";
}
else
{
$m_mssid	="SSID 1~7";
}
$m_ap_mode ="Modo de funcionamiento";
$m_days = "Días";
$m_sysname = "Nombre del sistema";
$m_location = "Ubicación";
$m_ap = "Punto de acceso";
$m_wireless_client = "Cliente inalámbrico";
$m_wds_ap = "WDS con AP";
$m_wds = "WDS";
?>
