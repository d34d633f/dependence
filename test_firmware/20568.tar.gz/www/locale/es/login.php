<?
$a_invalid_user_name	="Introduzca el nombre de usuario.";

$m_html_title		="INICIO DE SESIóN";
$m_context_title	="INICIO DE SESIóN";
$m_login_router		="Iniciar sesión en el router:";
$m_login_ap		="Inicio de sesión en el punto de acceso:";
$m_log_in		="INICIO DE SESIóN ";
?>
