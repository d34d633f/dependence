<?
$m_context_title = "Parámetros de ACL para MAC inalámbrico";
$m_acl_type = "Lista de control de acceso";
$m_disable = "Desactivar";
$m_accept = "Aceptar";
$m_reject = "Rechazar";
$m_wmac = "Dirección MAC";
$m_id = "ID";
$m_del = "Borrar";
$m_wband = "Banda de Frecuencia inalámbrica";
$m_band_5G = "5 GHz";
$m_band_2.4G = "2,4 GHz";
$m_ssid = "SSID";
$m_mac = "Dirección MAC";
$m_band = "Banda de Frecuencia";
$m_auth = "Autenticación";
$m_signal = "Señal";
$m_power = "Modo de ahorro de energía";
$m_multi_ssid = "MULTI-SSID ";
$m_primary_ssid = "SSID primaria";
$m_clirnt_info = "Información del cliente actual";
$m_b_add = "Añadir";

$a_acl_del_confirm		= "¿Está seguro de que desea eliminar esta dirección MAC?";
$a_same_acl_mac	= "Hay una entrada existente con la misma dirección MAC.\\nCambie la dirección MAC.";
$a_invalid_mac		= "Dirección MAC no válida.";
$a_max_acl_mac		= "El número máximo de la lista de control de acceso es 256.";

?>
