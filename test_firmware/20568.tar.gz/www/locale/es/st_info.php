<?
$m_context_title = "Información del cliente";
$m_client_info = "Información del cliente";
$m_st_association  = "Asociación de la estación";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "Banda de Frecuencia";
$m_auth = "Autenticación";
$m_signal = "Señal";
$m_power = "Modo de ahorro de energía";
$m_multi_ssid = "MULTI-SSID ";
$m_primary_ssid = "SSID primaria";
$m_on = "Activado";
$m_off = "Desactivado";
?>
