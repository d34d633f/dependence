<?
$m_context_title = "Parámetros de LAN";

$m_lan_type  = "Obtener IP de";
$m_static_ip = "IP estática (manual)";
$m_dhcp      = "IP dinámica (DHCP)";

$m_ipaddr    = "Dirección IP";
$m_subnet    = "Máscara de subred";
$m_gateway   = "Puerta de enlace predeterminada";

$a_invalid_ip= "Dirección IP no válida.";
$a_invalid_netmask= "Máscara de subred no válida.";
$a_invalid_gateway= "Dirección de puerta de enlace no válida.";
$a_connect_new_ip = "Conecte con la nueva dirección IP.";
?>
