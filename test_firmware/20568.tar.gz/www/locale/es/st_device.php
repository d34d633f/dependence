<?
$ssid_flag = query("/runtime/web/display/mssid_index4");
$m_context_title = "Información del dispositivo";
$m_ethernet = "Ethernet";
$m_wireless = "Inalámbrico";
$m_2.4g = "(2,4 GHz)";
$m_5g = "(5 GHz)";
$m_status = "Estado del dispositivo";
$m_fw_version = "Versión de firmware";
$m_eth_mac = "Dirección MAC Ethernet";
$m_wlan_mac = "Dirección MAC inalámbrica";
$m_ap_array = "AP Arrary";
$m_role = "Role";
$m_master = "Master";
$m_backup_master = "Backup Master";
$m_slave = "Slave";
$m_location = "Ubicación";
$m_pri = "Principal";
if($ssid_flag == "1")
{
	$m_ms	="SSID 1~3";
}
else
{
$m_ms = "SSID 1~7";
}
$m_ip = "Dirección IP";
$m_mask = "Máscara de subred";
$m_gate = "Puerta de enlace";
$m_na = "N/D";
$m_ssid = "Nombre de red (SSID)";
$m_channel = "Canal";
$m_rate = "Velocidad de los datos";
$m_sec = "Seguridad";
$m_bits		= "bits";
$m_tkip		= "TKIP";
$m_aes		= "AES";
$m_cipher_auto	= "Automática";
$m_wpa		= "WPA-";
$m_wpa2		= "WPA2-";
$m_wpa_auto		= "WPA2-Auto-";
$m_eap		= "Enterprise/";
$m_psk		= "Personal /";
$m_open		="Abrir /";
$m_shared	="Clave compartida  /";
$m_disabled		="Desactivar";
$m_cpu = "Utilización de la CPU";
$m_memory = "Utilización de la memoria";
$m_none = "Ninguno";
$m_auto  ="Automática";
$m_54	= "54";
$m_48	= "48";
$m_36	= "36";
$m_24	= "24";
$m_18	= "18";
$m_12	= "12";
$m_9	= "9";
$m_6	= "6";
$m_11	= "11";
$m_5	= "5.5";
$m_2	= "2";
$m_1	= "1";
?>
