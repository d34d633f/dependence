<?
$m_context_title = "Parámetros de grupo dinámico";
$m_srv_enable = "Función Activar/Desactivar";
$m_disable = "Desactivar";
$m_enable = "Activar";
$m_dhcp_srv = "Control del servidor DHCP";
$m_dhcp_pool = "Parámetros de grupo dinámico";
$m_ipaddr = "IP asignada desde";
$m_iprange = "Rango  del grupo (1-254)";
$m_ipmask = "Máscara de subred";
$m_gateway = "Puerta de enlace";
$m_wins = "WINS";
$m_dns = "DNS";
$m_m_domain_name = "Nombre de dominio";
$m_m_lease_time = "Tiempo de validez (60 - 31.536.000 seg.)";
$m_on = "ACTIVADO";
$m_off = "DESACTIVADO";
$m_status_enable = "Estado";
$m_index = "índice";
$m_pri_ssid = "SSID primaria";
$m_ms_ssid1 = "SSID 1";
$m_ms_ssid2 = "SSID 2";
$m_ms_ssid3 = "SSID 3";
$m_ms_ssid4 = "SSID 4";
$m_ms_ssid5 = "SSID 5";
$m_ms_ssid6 = "SSID 6";
$m_ms_ssid7 = "SSID 7";
$m_ssid = "SSID";
$m_multi_dhcp = "Control de DHCP múltiple";
$m_multi_dhcp_enable ="Activar/Desactivar DHCP múltiple";
$m_multi_srv_enable ="Activar/Desactivar servidor DHCP múltiple";
$m_multi_dhcp_srv = "Control del servidor DHCP múltiple";
$m_index="índice";


$a_invalid_ip		= "Dirección IP no válida.";
$a_invalid_ip_range	= "Rango de IP no válido.";
$a_invalid_netmask	= "Máscara de subred no válida.";
$a_invalid_gateway	="Puerta de enlace no válida.";
$a_invalid_wins	= "Wins no válido.";
$a_invalid_dns	="DNS no válido.";
$a_invalid_domain_name	= "Nombre de dominio no válido.";
$a_invalid_lease_time	= "Tiempo de validez de DHCP no válido.";

?>
