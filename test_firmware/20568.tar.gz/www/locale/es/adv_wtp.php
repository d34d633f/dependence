<?
$m_context_title = "Parámetros de interruptor WLAN";
$m_wtp_title = "Parámetros de punto de terminación inalámbrico";
$m_connect_title = "Información de conexión";
$m_wtp_enable = "Activar WTP";
$m_wtp_name = "Nombre de WTP";
$m_wtp_location = "Datos de ubicación de WTP";
$m_ac_ip = "IP de interruptor WLAN";
$m_ac_name = "Nombre de interruptor WLAN";
$m_ac_ipaddr = "Dirección IP de interruptor WLAN";
$m_ac_ip_list_title = "Lista de direcciones de interruptor WLAN";
$m_id = "ID";
$m_ip = "Dirección IP";
$m_del = "Borrar";

$a_wtp_del_confirm		= "¿Está seguro de que desea eliminar esta dirección IP?";
$a_same_wtp_ip	= "Hay una entrada existente con la misma dirección IP.\\n Cambie la dirección IP.";
$a_invalid_ip		= "Dirección IP no válida.";
$a_max_ip_table		= "El número máximo de la lista de dirección de interruptor WLAN es 8.";
?>
