﻿<?
$m_context_title = "Parámetros del sistema";
$m_reboot		="Reiniciar el dispositivo";
$m_b_reboot		=" Reiniciar ";
$m_factory_reset	="Restablecer los parámetros predeterminados de fábrica";
$m_b_restore		="Restablecer";
$m_clear_lang_pack ="Borrar paquete de idioma"; 
$m_clear ="Borrar";
$a_sure_to_clear_lang ="¿Borrar el paquete de idioma ?";
$a_sure_to_factory_reset="¿Restablecer los parámetros predeterminados de fábrica?";
$a_sure_to_reboot	="¿Reiniciar el punto de acceso?";

?>
