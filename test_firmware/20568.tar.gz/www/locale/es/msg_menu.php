<?
// category
$m_menu_top_bsc		="Configuración";
$m_menu_top_adv		="Opciones avanzadas";
$m_menu_top_tools	="MANTENIMIENTO";
$m_menu_top_st		="Estado";
$m_menu_top_spt		="Soporte";

// basic
$m_menu_bsc_wizard      ="ASISTENTE";
$m_menu_bsc_internet	="INTERNET";
$m_menu_bsc_wlan	="CONFIGURACIóN INALáMBRICA";
$m_menu_bsc_lan		="CONFIGURACIóN DE LAN";

// advanced
$m_menu_adv_vrtsrv	="SERVIDOR VIRTUAL";
$m_menu_adv_port	="DIRECCIONAMIENTO DE PUERTO";
$m_menu_adv_app		="REGLAS DE LAS APLICACIONES";
$m_menu_adv_mac_filter	="FILTRO DE RED";
$m_menu_adv_acl		="FILTRO";
$m_menu_adv_url_filter	="FILTRO DE SITIO WEB";
$m_menu_adv_dmz		="PARáMETROS DEL CORTAFUEGOS";
$m_menu_adv_wlan	="RENDIMIENTO";
$m_menu_adv_network	="RED AVANZADA";
$m_menu_adv_dhcp	="SERVIDOR DHCP";
$m_menu_adv_mssid	="MULTI-SSID";
$m_menu_adv_group	="Límite de usuario";
$m_menu_adv_wtp		="Interruptor WLAN";
$m_menu_adv_wlan_partition	="Partición WLAN";

// tools
$m_menu_tools_admin	="Administración del dispositivo";
$m_menu_tools_time	="HORA";
$m_menu_tools_system	="SISTEMA";
$m_menu_tools_firmware	="FIRMWARE";
$m_menu_tools_misc	="VARIOS";
$m_menu_tools_ddns	="DDNS";
$m_menu_tools_vct	="COMPROBACIóN DEL SISTEMA";
$m_menu_tools_sch	="PROGRAMAS";
$m_menu_tools_log_setting	="PARáMETROS DE REGISTRO";

// status
$m_menu_st_device	="INFORMACIóN DEL DISPOSITIVO";
$m_menu_st_log		="REGISTRO";
$m_menu_st_stats	="Estadísticas";
$m_menu_st_wlan		="INFORMACIóN DEL CLIENTE";

// support
$m_menu_spt_menu	="MENú";

$m_logout	="Cierre de sesión";

$m_menu_home	="Inicio";
$m_menu_tool	="Mantenimiento";
$m_menu_config	="Configuración";
$m_menu_sys	="Sistema";
$m_menu_logout	="Cierre&nbsp;de&nbsp;sesión";
$m_menu_help	="Ayuda";

$m_menu_tool_admin	="Parámetros de administrador";
$m_menu_tool_fw	="Carga del firmware y la certificación SSL";
$m_menu_tool_config	="Archivo de configuración";
$m_menu_tool_sntp	="SNTP";

$m_menu_config_save	="Guardar y activar";
$m_menu_config_discard	="Desechar cambios";

$a_config_discard ="Se desecharán todos los cambios. ¿Desea continuar?";

?>
