<?
$m_html_title="Imagen de firmware equivocada";
$m_context_title="Imagen de firmware equivocada";
$m_context="El archivo seleccionado no es un archivo de imagen.";
$m_button_dsc=$m_continue;
?>
