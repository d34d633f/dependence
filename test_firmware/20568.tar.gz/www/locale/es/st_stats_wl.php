﻿<?

$msg_title="Estadísticas de tráfico WLAN";
$msg_t_title="Recuento transmitido";
$msg_t_msg1="Recuento de paquete transmitido";
$msg_t_msg2="Recuento de bytes transmitidos";
$msg_t_msg3="Recuento de paquete interrumpido";
$msg_t_msg4="Recuento de reintento transmitido";
$msg_r_title="Recuento recibido";
$msg_r_msg1="Recuento de paquete recibido";
$msg_r_msg2="Recuento de bytes recibidos";
$msg_r_msg3="Recuento de paquete interrumpido";
$msg_r_msg4="Recuento de CRC recibido";
$msg_r_msg5="Recuento de errores de descifrado recibidos";
$msg_r_msg6="Recuento de errores MIC recibidos";
$msg_r_msg7="Recuento de errores PHY recibidos";
$msg_clear="Borrar";
$msg_refresh="Actualizar";




?>
