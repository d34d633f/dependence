<?
$m_context_title = "Parámetros de fecha y hora";
$m_time_config_title = "Configuración de la hora";
$m_auto_time_config_title = "Configuración automática de la hora";
$m_set_date_time_title = "Establecer manualmente la fecha y la hora";
$m_time				= "Hora actual";
$m_time_zone			= "Zona horaria";
$m_enable_daylight_saving	= "Activar el horario de verano";

$m_title_ntp	= "Configuración automática de la hora";
$m_enable_ntp		= "Activar servidor NTP";
$m_interval		= "Intervalo";
$m_ntp_server		= "Servidor NTP";
$m_select_ntp_server	= "Seleccionar servidor NTP";

$m_current_time	= "Fecha y hora";
$m_year		= "Año";
$m_month	= "Mes";
$m_day		= "Día";
$m_days		= "Días";
$m_hour		= "Hora";
$m_minute	= "Minuto";
$m_second	= "Segundo";
$m_copy_pc_time	= "Copiar los parámetros horarios del ordenador";
$m_daylight_saving_offset	="Ajuste del horario de verano";
$m_daylight_saving_date	="Fechas del horario de verano";
$m_week ="Semana";
$m_day_of_week = "Día de la semana";
$m_dst_start = "Inicio de DST";
$m_dst_end = "Final de DST";
$m_jan = "Ene";
$m_feb = "Feb";
$m_mar = "Mar";
$m_apr = "Abr";
$m_may = "May";
$m_jun = "Jun";
$m_jul = "Jul";
$m_aug = "Ago";
$m_sep = "Sep";
$m_oct = "Oct";
$m_nov = "Nov";
$m_dec = "Dic";
$m_1st = "1o";
$m_2nd = "2o";
$m_3rd = "3o";
$m_4th = "4o";
$m_5th = "5o";
$m_sun = "Dom";
$m_mon = "Lun";
$m_tue = "Mar";
$m_wed = "Mié";
$m_thu = "Jue";
$m_fri = "Vie";
$m_sat = "Sáb";
$m_am = " a.m";
$m_pm = " p.m";


$a_invalid_ntp_server	= "Servidor NTP no válido.";
?>
