<?
$m_context_title = "Información WDS";
$m_client_info = "Información WDS";
$m_st_association  = "Asociación de la estación con 11";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "Banda de Frecuencia";
$m_auth = "Autenticación";
$m_signal = "Señal";
$m_power = "Modo de ahorro de energía";
$m_wpa		= "WPA-";
$m_wpa2		= "WPA2-";
$m_wpa_auto		= "WPA2-Auto-";
$m_eap		= "Empresa";
$m_psk		= "Personal";
$m_open		="Sistema abierto";
$m_shared	="Clave compartida";
$m_disabled		="Desactivar";
$m_channel = "Canal";
$m_name = "Nombre";
$m_status = "Estado";
$wds = "W";
$m_on = "Activado";
$m_off = "Desactivado";
$m_none = "Ninguno";
?>
