<?
$m_menu_upgrade_fw = "<font face=\"Arial\" color=\"red\" size=2>".
					 "<b>No apague el dispositivo durante este proceso. </b></font>".
					 "<font face=\"Arial\" size=2>Your Device During This Process.".
					 " Si lo hace, puede dañar físicamente su ".query("/sys/hostname").
					 ". (Si el explorador no se redirige a la página web automáticamente, ".
					 "pulse el botón Actualizar.)</font>";
					 
$m_upload_fw = "Cargando firmware ...";
$m_verify_fw = "Actualizando el dispositivo ...";
$m_upgrad_device = "Actualizando  ...";
$m_reboot_device = "Reiniciando el dispositivo ...";

$a_upgrade_fw_fail_msg = "Ha fallado la actualización del firmware, cargue de nuevo el firmware y vuelva a intentarlo.";

?>