<?
$m_html_title="Sesión completa";
$m_context_title="Sesión completa";
$m_context="La sesión de inicio de sesión está completa.  Inténtelo más tarde";
$m_button_dsc="Vuelva a iniciar la sesión";
?>
