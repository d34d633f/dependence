<?
$m_html_title="Cierre de sesión";
$m_context_title="Cierre de sesión";
$m_context="Ha salido de la sesión satisfactoriamente.";
$m_button_dsc="Volver a la página de inicio de sesión";
?>
