<?
$version_no=query("/runtime/sys/info/firmwareverreve");
$build_no=query("/runtime/sys/info/firmwarebuildno");

$m_context_title	="Versión ";

$m_context = "Versión : ".$version_no."<br><br>Número de build  : ".$build_no."<br><br>";
$m_context = $m_context."System Uptime : <script>document.write(shortTime());</script>";

$m_days		= "días";
$m_button_dsc	=$m_continue;
?>
