<?
$m_context_title = "Lista de IP actual";
$m_host_name = "Nombre de host";
$m_mac = "Vincular dirección MAC";
$m_ip = "Dirección IP asignada";
$m_time = "Tiempo de validez";
$m_dynamic_pools = "Grupos dinámicos DHCP actuales";
$m_static_pools = "Grupos estáticos DHCP actuales";
$m_days			="días";
$m_hrs			="horas";
$m_mins			="minutos";
$m_secs			="segundos";
?>
