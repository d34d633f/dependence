<?
$m_context_title = "Partición inalámbrica";
$m_isc = "Conexión de estación interna";
$m_guest = "Modo de invitados";
$m_ewa = "Acceso Ethernet a WLAN";
$m_enable = "Activar";
$m_disable = "Desactivar";
$m_band = "Banda de Frecuencia inalámbrica";
$m_band_5G = "5 GHz";
$m_band_2.4G = "2,4 GHz";
$m_pri_ssid = "SSID primaria";
$m_ms_ssid1 = "SSID 1";
$m_ms_ssid2 = "SSID 2";
$m_ms_ssid3 = "SSID 3";
$m_ms_ssid4 = "SSID 4";
$m_ms_ssid5 = "SSID 5";
$m_ms_ssid6 = "SSID 6";
$m_ms_ssid7 = "SSID 7";
?>
