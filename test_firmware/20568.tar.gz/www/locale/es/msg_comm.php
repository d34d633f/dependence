<?
$m_user_name		="Nombre de usuario";
$m_password		="Contraseña";
$m_continue		="Continuar";
$m_nochg_title		="Sin cambios";
$m_nochg_dsc		="Los parámetros no han cambiado.";
$m_saving_title		="Guardando";
$m_saving_dsc		="Los parámetros se guardan y surten efecto.";
$m_saving_dsc_wait = "Espere ...";
$m_saving_dsc_change_ip = "Espere 10 segundos y, a continuación, acceda al dispositivo con la nueva dirección IP.";
$m_scan_title		="Explorar";
$m_detect_title	="Detectar";
$m_scan_dsc		="Explorando ... <br><br> Espere ...";
$m_clear = "Borrar";

$TITLE=query("/sys/hostname");
$first_frame = "home_sys";
$m_logo_title	=query("/sys/hostname");
?>
