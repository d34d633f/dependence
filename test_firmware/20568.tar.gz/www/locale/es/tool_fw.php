<?
$m_context_title = "Carga del firmware y la certificación SSL";

$m_upload_fw_title ="Actualizar firmware desde la unidad de disco duro local";
$m_firmware_version	="Versión de firmware";
$m_upload_firmware_file	="Cargar firmware desde el archivo";
$m_upload_lang_title ="ACTUALIZACIóN DEL PAQUETE DE IDIOMA";
$m_upload_lang_file	="Cargar";
$m_upload_ssl_titles = "Actualizar la certificación SSL desde la unidad de disco duro local";
$m_upload_certificatee_file	= "Cargar certificado desde el archivo";
$m_upload_key_file	= "Cargar clave desde el archivo";
$m_b_fw_upload = "Cargar";
$a_blank_fw_file= "No se acepta un archivo vacío.";
$a_format_error_file ="Error de formato de archivo. Inténtelo de nuevo.";
?>
