<?
$m_context_title = "Protección frente a intrusiones inalámbricas";
$m_b_detect = "Detectar";
$m_ap_list_title = "Lista de AP";
$m_type = "Tipo";
$m_band = "Banda de Frecuencia";
$m_channel = "CH";
$m_ssid = "SSID";
$m_mac = "BSSID";
$m_last_seem = "Visto por última vez";
$m_status = "Estado";
$m_b_valid = "Establecer como válido";
$m_b_neighborhood = "Establecer como próximo";
$m_b_rogue = "Establecer como deshonesto";
$m_b_new = "Establecer como nuevo";
$m_all_valid = "Marcar todos los puntos de acceso nuevos como puntos de acceso válidos";
$m_all_rogue = "Marcar todos los puntos de acceso nuevos como puntos de acceso deshonestos";
$m_valid = "Válido";
$m_neighborhood = "Próximo";
$m_rogue = "Deshonesto";
$m_new = "Nuevo";
$m_a = "A";
$m_b = "B";
$m_g = "G";
$m_n = "N";
$m_days = "Días";
$m_all = "Todas";
$m_up = "Arriba";
$m_down = "Abajo";

$a_max_list = "El número máximo de esta lista de tipos es 64.\\n";
$a_can_add_num = "Puede añadir";
$a_entry = " entrada";
$a_no_click = "No se ha hecho clic para entrar.";
?>
