<?
$m_html_title	= "Error de inicio de sesión";
$m_context_title= "Error de inicio de sesión";
$m_context	= "El nombre o la contraseña de usuario son incorrectos.";
$m_button_dsc	= "Vuelva a iniciar la sesión";
?>
