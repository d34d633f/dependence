<?
$basic_setting = "Parámetros básicos";
$basic_wireless= "Inalámbrico";
$basic_lan	="LAN";
$adv_setting = "Parámetros de opciones avanzadas";
$adv_perf = "Rendimiento";
$adv_group = "Agrupamiento";
$adv_mssid = "Multi-SSID";
$adv_8021q = "VLAN";
$adv_rogue_ap = "Intrusión";
$adv_scheduling = "Programa";
$adv_qos = "Calidad de servicio";
$adv_wtp = "Interruptor WLAN";
$adv_dhcp = "Servidor DHCP";
$adv_dhcp_dynamic = "Parámetros de grupo dinámico";
$adv_dhcp_static = "Parámetros de grupo estático";
$adv_dhcp_list = "Lista de asignación de IP actual";
$adv_filter = "Filtros";
$adv_filter_acl = "ACL para MAC inalámbrico";
$adv_filter_partition = "Partición WLAN";
$st_setting = "Estado";
$st_device = "Información del dispositivo";
$st_client = "Información del cliente";
$st_wds_client = "Información WDS";
$st_stats = "Estados";
$st_stats_ethernet = "Ethernet";
$st_stats_wlan = "WLAN";
$st_log = "Registro";
$st_log_view = "Ver registro";
$st_log_setting = "Parámetros de registro";
$tool_admin = "Parámetros de administración";
$tool_fw = "Carga del firmware y la certificación SSL";
$tool_config = "Archivo de configuración";
$tool_sntp = "Fecha y hora";
$logout_msg = "&nbsp;&nbsp;TSe desconectará la conexión<br>&nbsp;&nbsp; actual del explorador si hace clic<b> aquí</b>.";
?>


