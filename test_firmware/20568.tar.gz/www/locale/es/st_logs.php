<?
$m_context_title	= "Parámetros de registro";
$m_log_setting_title = "Parámetros de registro";
$m_log_ip	=  "Servidor de registro/Dirección IP ";
$m_log_type = "Tipo de registro";
$m_system_activity	=  "Actividad del sistema";
$m_wireless_activity	=  "Actividad inalámbrica";
$m_notice	=  "Aviso";
$m_smtp_setting_title = "Notificación de correo electrónico";
$m_smtp = "Notificación de correo electrónico";
$m_enable = "Activar";
$m_smtp_ip = "Dirección del servidor de correo electrónico";
$m_smtp_from_email = "Dirección de remitente de correo electrónico";
$m_smtp_to_email = "Dirección de destino de correo electrónico";
$m_email_log_schedule_title = "Programa de registro de correo electrónico";
$m_log_schedule = "Programa";
$m_log_schedule_msg = "horas o cuando el registro esté lleno";
$m_smtp_name = "Nombre de usuario";
$m_smtp_password ="contraseña";
$m_smtp_confirm_password ="Confirmar contraseña";
$m_smtp_port = "Puerto SMTP";

$a_invalid_log_ip		= "Servidor de registro / dirección IP no válidos.";
$a_invalid_smtp_ip		= "Servidor de correo / dirección IP no válidos.";
$a_empty_user_name	="Introduzca el nombre de usuario.";
$a_invalid_user_name	="El nombre de usuario contiene caracteres no válidos. Compruébelo.";
$a_first_blank_user_name	= "El primer carácter del Nombre de usuario no puede estar en blanco.";
$a_invalid_new_password	="La contraseña contiene caracteres no válidos. Compruébelo.";
$a_password_not_matched	="La contraseña y la contraseña de confirmación no coinciden.";
$a_invalid_smtp_port = "Puerto SMTP no válido.";
?>
