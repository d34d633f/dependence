<?
$m_context_title = "Carga y descarga del archivo de configuración";
$m_save_cfg = "Cargar parámetros a la unidad de disco duro local";
$m_save = "Descargar";
$m_load_cfg = "Cargar archivo";
$m_b_load = "Cargar";
$m_upload_config_title = "Carga del archivo de configuración";
$m_download_config_title = "Descarga del archivo de configuración";

$a_empty_cfg_file_path	="Seleccione un archivo de configuración guardado para cargarlo.";
$a_error_cfg_file_path	="Error de formato de archivo. Inténtelo de nuevo.";
$a_sure_to_reload_cfg	="¿Cargar los parámetros desde el archivo?";
?>
