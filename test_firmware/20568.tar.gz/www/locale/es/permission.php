<?
$m_context_title	="&nbsp";
$m_context		=" Sólo la cuenta  <strong>admin</strong> puede cambiar los parámetros.";
$m_button_dsc		=$m_continue;
?>
