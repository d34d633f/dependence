<?
$tool_admin = "Parámetros de administración";
$tool_fw = "Carga del firmware y la certificación SSL";
$tool_config = "Archivo de configuración";
$tool_sntp = "Fecha y hora";
$logout_msg = "&nbsp;&nbsp;Se desconectará la conexión actual del explorador si hace clic <br>&nbsp;&nbsp; explorador si hace clic <b>aquí</b>.";
?>

