<?

$head_bsc = "Parámetros básicos";

$title_bsc_wlan ="Parámetros inalámbricos";
$bsc_wlan_msg ="Permite cambiar los parámetros inalámbricos para adaptarlos a una red inalámbrica existente o".
 "para personalizar su red inalámbrica.";
$bsc_wireless_band ="Banda de Frecuencia inalámbrica";
$bsc_wireless_band_msg ="Banda de frecuencia en funcionamiento. Elija 2,4 GHz para conseguir visibilidad de los dispositivos heredados y un rango más largo. ".
" Elija 5 GHz para conseguir menos interferencias; las interferencias pueden dañar el rendimiento. ".
" Este AP utilizará una banda de frecuencia a la vez.";
$bsc_mode = "Modo";
$bsc_mode_msg = "Seleccione un modo de funcionamiento para configurar su red inalámbrica.".
" Los modos de funcionamiento incluyen AP, WDS (Sistema de distribución inalámbrica) con AP, WDS y cliente inalámbrico. ".
" Los modos de funcionamiento están diseñados para admitir diversas topologías y aplicaciones de red inalámbrica.";
$bsc_network_name = "Nombre de red (SSID)";
$bsc_network_name_msg = "Conocido también como el Identificador configurado de servicio, éste es el nombre designado para una red de ".
"área local inalámbrica (WLAN) específica. El valor predeterminado de fábrica es \"dlink\". ".
"El SSID se puede cambiar fácilmente para conectarlo a una red inalámbrica existente o para establecer una nueva red inalámbrica.";
$bsc_ssid_visibility = "Visibilidad de SSID";
$bsc_ssid_visibility_msg = "Indicar si se difundirá o no el SSID de su red inalámbrica. El valor predeterminado de Visibilidad de ".
"SSID se establece en Activar, lo que permite a los clientes inalámbricos detectar la red inalámbrica. ".
"Al cambiar esta configuración a Desactivar, los clientes inalámbricos ya no pueden detectar la red ".
"inalámbrica y sólo pueden conectar si se introduce el SSID correcto.";
$bsc_auto_channel="Selección automática de canal";
$bsc_auto_channel_msg="Si marca Búsqueda automática de canal, cada vez que arranca el AP, ".
"el AP buscará automáticamente el mejor canal para utilizar. Está activada de forma predeterminada.";
$bsc_channel="Canal";
$bsc_channel_msg ="Indicar el parámetro del canal para el ".query("/sys/hostname").". De forma predeterminada, ".
"el AP se establece en Búsqueda automática de canal. Se puede cambiar el canal para que se adapte a ".
"una red inalámbrica existente o para personalizar la red inalámbrica.;";
$bsc_channel_width="Anchura de canal";
$bsc_channel_width_msg="Permite seleccionar la anchura de canal en la que desea trabajar. ".
"Seleccione 20 MHz si no está utilizando ningún cliente inalámbrico 802.11n. ".
"20/40 MHz automático le permite utilizar dispositivos inalámbricos 802.11n y que no sean 802.11n en su red;";
$bsc_authentication="Autenticación";
$bsc_authentication_msg="Para aumentar la seguridad de una red inalámbrica, ".
"puede activarse el cifrado de datos. Existen varios tipos de autenticaciones disponibles que se pueden seleccionar.".
"El valor predeterminado para Autenticación se establece en Sistema abierto.";
$bsc_open_sys="Sistema abierto";
$bsc_open_sys_msg="Para la autenticación Sistema abierto, sólo los clientes inalámbricos con la misma clave WEP se ".
"podrá comunicar en la red inalámbrica. El punto de acceso seguirá siendo visible para todos ".
"los dispositivos en la red.";
$bsc_shared_key="Clave compartida";
$bsc_shared_key_msg="Para la autenticación Clave compartida, el punto de acceso no puede ser visible en ".
"la red inalámbrica excepto para los clientes inalámbricos que comparten la misma clave WEP.";
$bsc_personal_type="WPA-Personal/WPA2-Personal/WPA-Auto-Personal";
$bsc_personal_type_msg="El acceso protegido Wi-Fi autoriza y autentifica usuarios para acceder".
" a la red inalámbrica. Utiliza cifrado TKIP para proteger la red mediante el ".
" uso de una clave precompartida. WPA y WPA2 utilizan algoritmos diferentes. WPA-Auto admite WPA y WPA2. ";
$bsc_enterprise_type="WPA-Enterprise/ WPA2-Enterprise/ WPA-Auto-Enterprise";
$bsc_enterprise_type_msg="El acceso protegido Wi-Fi autoriza y autentifica usuarios para acceder ".
"a la red inalámbrica. WPA utiliza una seguridad más potente que WEP y se basa en una clave que cambia automáticamente a intervalos regulares. ".
"Requiere un servidor RADIUS en la red. WPA y WPA2 utilizan algoritmos diferentes. WPA-Auto admite WPA y WPA2.";
$bsc_network_access="Protección de acceso a la red";
$bsc_network_access_msg="Protección de acceso a la red (NAP) es una característica de Windows Server 2008. NAP controla el acceso a los ".
"recursos de red en función de la identidad en un ordenador de cliente y del cumplimiento de la política de gestión corporativa. ".
"NAP permite a los administradores de red definir los niveles granulares de acceso a la red en función de la identidad del cliente, ".
"los grupos a los que pertenece el cliente y el grado de compatibilidad del cliente con la política de gestión corporativa. ".
"Si un cliente no es compatible, NAP proporciona un mecanismo para recuperar automáticamente la compatibilidad del cliente y, a continuación, aumentar dinámicamente su nivel de acceso a la red.";

$title_bsc_lan = "Parámetros de LAN";
$title_bsc_lan_msg = "Denominados también parámetros privados, los parámetros de LAN permiten configurar la interfaz de LAN del ".query("/sys/hostname").". ".
"La dirección IP de LAN es privada para su red interna y no está visible en Internet. La dirección IP predeterminada es ".
"192.168.0.50 con una máscara de subred de 255.255.255.0.";
$bsc_get_ip_from = "Obtener IP de";
$bsc_get_ip_from_msg = "El parámetro predeterminado de fábrica es \"IP estática (manual)\", que permite configurar manualmente la dirección IP del ".query("/sys/hostname").", ".
"de acuerdo con la red de área local aplicada. Active \"IP dinámica (DHCP)\" para permitir ".
"que el host DHCP asigne automáticamente una dirección IP al punto de acceso que cumpla con la red de área local aplicada.";
$bsc_ip_address = "Dirección IP";
$bsc_ip_address_msg = "La dirección IP predeterminada es 192.168.0.50. Se puede modificar para que cumpla con una red de área local existente. ".
"Tenga en cuenta que la dirección IP de cada dispositivo de la red de área local inalámbrica debe estar ".
"dentro del mismo rango de dirección IP y máscara de subred. ".
"Si se toma como ejemplo la dirección IP predeterminada del ".query("/sys/hostname").", cada estación asociada con el AP se debe configurar".
" con una dirección IP única que entre dentro del rango de 192.168.0.*. \"*\" va de 0 a 255, aunque en este caso es 50.";
$bsc_submask = "Máscara de subred";
$bsc_submask_msg = "Una máscara utilizada para determinar a qué subred pertenece una dirección IP. El parámetro de subred predeterminado es 255.255.255.0.";
$bsc_gateway = "Puerta de enlace predeterminada";
$bsc_gateway_msg = "Especificar la dirección IP de la puerta de enlace de la red local.";


$head_adv ="Parámetros de opciones avanzadas";

$title_adv_per = "Rendimiento";
$title_adv_per_msg = "Puede personalizar la radio de red para adaptarla a sus necesidades sintonizando los parámetros de la radio en la sección de ".
"rendimiento. Las funciones de rendimiento están diseñadas para usuarios avanzados que están familiarizados con la configuración ".
"de redes y radio inalámbricas 802.11.";
$adv_wireless = "Inalámbrico";
$adv_wireless_msg ="Esta opción permite al usuario activar o desactivar la función inalámbrica";
$adv_wireless_mode ="Modo inalámbrico";
$adv_wireless_mode_msg ="Esta función permite seleccionar las distintas combinaciones de clientes que se pueden admitir. ".
"Tenga en cuenta que, cuando está activada la compatibilidad retroactiva para los clientes heredados ".
"(802.11a/g/b), está prevista una degradación en el rendimiento inalámbrico del 802.11n.";
$adv_date_rate="Velocidad de los datos";
$adv_date_rate_msg="Indica la velocidad de transferencia básica de los adaptadores inalámbricos en la red de área local inalámbrica (WLAN). ".
"El punto de acceso ajustará la velocidad de transferencia básica dependiendo de la velocidad básica del dispositivo ".
"conectado. Si existen obstáculos o interferencias, el AP reducirá la velocidad de los datos";
$adv_beacon = "Intervalo de emisión de señales (25-500)";
$adv_beacon_msg = "Las emisiones de señales son paquetes enviados por un punto de acceso para sincronizar una red inalámbrica. ".
"La configuración de un intervalo de emisión de señales más alto ayudará a ahorrar la energía de un cliente inalámbrico mientras que la configuración de un intervalo más bajo ayudará a que un cliente inalámbrico conecte más rápidamente con un punto de acceso. ".
"Se recomienda una configuración de 100 milisegundos para la mayoría de los usuarios.";
$adv_dtim="Intervalo DTIM (1-15)";
$adv_dtim_msg="El intervalo DTIM especifica el numero de emisiones de señales de AP entre cada Mensaje de indicación del tráfico de envíos (DTIM). ".
"Informa a las estaciones asociadas de la siguiente ventana para escuchar los mensajes de difusión y multidifusión. Puede especificar ".
"un rango de valor DTIM de 1 a 15. El AP enviará el siguiente DTIM con el valor de DTIM especificado a las estaciones, si existe algún".
" mensaje de difusión o multidifusión en memoria. Las estaciones escuchan la emisión de señales y se preparan para recibir l".
" os mensajes de difusión y multidifusión. El valor predeterminado para intervalo DTIM es 1";
$adv_transmit_power="Potencia de transmisión";
$adv_transmit_power_msg="Este parámetro determina el nivel de potencia de la transmisión inalámbrica. La potencia de transmisión se puede ajustar para eliminar".
" la superposición de la cobertura de área inalámbrica entre dos puntos de acceso en los que las interferencias son un problema ".
" importante. Las opciones son 100% (predeterminado), 50% (-3dB), 25% (-6dB) o 12,5% (-9dB). Por ejemplo, ".
" si la cobertura inalámbrica está pensada para la mitad del área, seleccione la opción \"50%\".";
$adv_wmm="WMM (Multimedia Wi-Fi)";
$adv_wmm_msg="La característica Multimedia Wi-Fi mejora la experiencia del usuario en las aplicaciones ".
"de audio, vídeo y voz a través de una red Wi-Fi. WMM está basada en una subsección de la norma IEEE 802.11e de calidad de servicio ".
"(QoS) de WLAN. Activar esta característica mejora la experiencia del usuario para las aplicaciones de audio y vídeo a través de una Wi-Fi.";
$adv_ack_timeout="Tiempo de espera de aceptación";
if(query("/runtime/web/display/ack_timeout_range")=="0")
{
$adv_ack_timeout_msg="Puede especificar un rango del valor del Tiempo de espera de aceptación de 48~200 en".
" 2,4 GHz y de 25~200 en 5 GHz para mejorar eficazmente el rendimiento a través de enlaces de larga distancia. La unidad está en microsegundos (ms). El valor predeterminado se establece en 25 ms en 2,4 GHz y en 48 ms en 5 GHz.;";
}else
{
	$adv_ack_timeout_msg="Puede especificar un rango del valor del Tiempo de espera de aceptación de 64~200 en".
" 2,4 GHz y de 50~200 en 5 GHz para mejorar eficazmente el rendimiento a través de enlaces de larga distancia. La unidad está en microsegundos (ms). El valor predeterminado se establece en 64 ms en 2,4 GHz y en 50 ms en 5 GHz.;";
}
$adv_short_gi="GI corta";
$adv_short_gi_msg="La utilización de un intervalo de protección corto (400 ns) puede mejorar el rendimiento. No obstante, ".
"también puede aumentar la tasa de errores en algunas instalaciones, debido a la mayor sensibilidad a las reflexiones de radiofrecuencia. Seleccione la opción que funcione mejor en su instalación";
$adv_igmp="Fisgoneo de IGMP";
$adv_igmp_msg="El fisgoneo del Protocolo de administración de grupos de Internet (IGMP) permite al AP reconocer las consultas e informes de IGMP enviados entre los routers y un host IGMP (ESTADO inalámbrico). Cuando está activado el fisgoneo de IGMP, ".
"el AP enviará los paquetes multidifusión al host IGMP en función de los mensajes de IGMP que pasan a través del AP.";
$adv_link_integrality="Integridad del enlace";
$adv_link_integrality_msg="Si está desconectada la conexión Ethernet entre la LAN y el AP, ".
"la opción \"Integridad del enlace\", cuando está activada, hará que el cliente inalámbrico se disocie automáticamente del AP";
$adv_connection_limit="Límite de conexión";
if(query("/runtime/web/display/utilization") !="0")
{
	$utilization_string="o la utilización de red de este AP supera el porcentaje que se ha especificado,";
}
else
{
	$utilization_string=" ";
}
$adv_connection_limit_msg="El límite de conexión es una opción para equilibrar la carga. Permite compartir el tráfico y los clientes de la red inalámbrica utilizando varios ".query("/sys/hostname").". Si está activada esta función,cuando el número de usuarios supera el \"límite de ".
"usuario\"  ".$utilization_string.
"el AP no permitirá que los clientes se asocien con este AP";
$adv_user_limit ="Límite de usuario (0 -64)";
$adv_user_limit_msg ="Establezca la cantidad máxima de usuarios permitidos para cada punto de acceso.\"10\" es el valor recomendado para el usuario normal";
$adv_network_utilization="Utilización de la red";
$adv_network_utilization_msg="Establezca la utilización máxima de este punto de acceso para el servicio.El ".query("/sys/hostname")." no permitirá que ningún cliente ".
"nuevo se asocie con el AP si la utilización supera el valor especificado por el usuario. 100% es el valor recomendado.";

$title_adv_mssid="Multi-SSID";
$title_adv_mssid_msg="Los SSID múltiples sólo se admiten en el modo AP. Se pueden configurar un SSID primario y, ".
"como mucho, siete SSID invitados para admitir las estaciones de segregación virtuales que comparten el mismo canal.";
$adv_mssid_msg1="Además, puede activar el estado VLAN para permitir que el ".query("/sys/hostname")." funcione con conmutadores que admiten VLAN o con otros dispositivos.";
$adv_mssid_msg2="Cuando se establece el SSID primario en Sistema abierto sin cifrado, los SSID invitados sólo se pueden establecer en sin cifrado, WEP, WPA-Personal o WPA2-Personal.";
$adv_mssid_msg3="Cuando se establece la seguridad del SSID primario en la clave WEP de sistema abierto o compartido, los SSID invitados sólo se pueden establecer en sin cifrado, utilizar otras tres claves WEP, WPA-Personal o WPA2-Personal.";
$adv_mssid_msg4="Cuando se establece la seguridad del SSID primario en WPA-Personal, WPA2-Personal o WPA-Auto-Personal, se utilizan los espacios 2 y 3. Los SSID invitados se pueden establecer para utilizar sin cifrado, WEP o WPA-Personal.";
$adv_mssid_msg5="Cuando se establece la seguridad del SSID primario en WPA-Enterprise, WPA2-Enterprise o WPA-Auto-Enterprise, los SSID invitados se pueden establecer para utilizar cualquier tipo de seguridad.";

$title_adv_vlan="VLAN";
$title_adv_vlan_msg="El ".query("/sys/hostname")." admite las VLAN. Las VLAN se pueden crear con un nombre y un VID. Al VLAN se le pueden asignar los puertos de Gestión (pila TCP), LAN, SSID primario / múltiple y Conexión WDS ya que ".
"se trata de puertos físicos. A cualquier paquete que introduzca el ".query("/sys/hostname")." sin una marca VLAN se le insertará una marca VLAN con un PVID.";

$title_adv_intrusion="Protección frente a intrusiones inalámbricas";
$title_adv_intrusion_msg="El ".query("/sys/hostname")." permite que los usuarios establezcan la protección frente a intrusiones inalámbricas.";

$title_adv_scheduling="Programación";
$title_adv_scheduling_msg="La radio de ".query("/sys/hostname")." se puede programar por semana o por días individuales.";

$title_adv_qos="Calidad de servicio";
$title_adv_qos_msg="QoS significa Calidad de servicio para el manejo inteligente de secuencias inalámbricas, una tecnología desarrollada para mejorar la ".
"experiencia en la utilización de una red inalámbrica al asignar prioridades de tráfico a distintas aplicaciones.";
$adv_enable_qoS="Activar calidad de servicio (QoS)";
$adv_enable_qoS_msg="Active esta opción si desea permitir que la calidad de servicio (QoS) establezca la prioridad del tráfico.";
$adv_enable_qoS_msg1="Clasificadores de prioridad.";
$adv_http="HTTP";
$adv_http_msg="Permite al punto de acceso reconocer las transferencias HTTP para múltiples secuencias comunes de audio y vídeo y".
" darles prioridad sobre el resto del tráfico. Los reproductores de medios digitales utilizan con frecuencia dichas secuencias.";
$adv_automatic="Automático";
$adv_automatic_msg="Cuando está activada, esta opción hace que el punto de acceso intente automáticamente dar prioridad a las secuencias de tráfico que no ".
"reconoce de otro modo, en función del comportamiento que muestren las secuencias. Actúa para anular la prioridad de las secuencias que ".
"muestran características de transferencia completa, como transferencias de archivos, mientras deja el tráfico interactivo, como los juegos o VoIP, funcionando a una prioridad normal.";
$adv_qos_rule="Reglas de calidad de servicio (QoS)";
$adv_qos_rule_msg="Una regla de calidad de servicio (QoS) identifica un flujo de mensaje específico y asigna una prioridad a dicho flujo. Para la mayoría".
" de las aplicaciones, los clasificadores de prioridad aseguran las prioridades correctas y no se necesitan reglas de calidad de servicio (QoS) específicas.";
$adv_qos_rule_msg1="QoS admite superposiciones entre las reglas. Si coincide más de una regla con un flujo de mensajes específico, se utilizará la regla con la prioridad más alta.";
$adv_name="Nombre";
$adv_name_msg="Cree un nombre para la regla que signifique algo para usted.";
$adv_priority="Prioridad";
$adv_priority_msg="La prioridad del flujo de mensajes se introduce aquí. Se definen cuatro prioridades:";
$adv_priority_msg1="* BK: Background (Menos urgente).";
$adv_priority_msg2="* BE: Best Effort (Máximo esfuerzo).";
$adv_priority_msg3="* VI: vídeo.";
$adv_priority_msg4="* VO: voz (más urgente).";
$adv_protocol="Protocolo";
$adv_protocol_msg="El protocolo utilizado por los mensajes.";
$adv_host_1_ip="Rango IP de host 1";
$adv_host_1_ip_msg="La regla se aplica a un flujo de mensajes para el que la dirección IP de un".
" ordenador entra dentro del rango establecido aquí.";
$adv_host_1_port="Rango de puerto de host 1";
$adv_host_1_port_msg="La regla se aplica a un flujo de mensajes para el que el primer número de puerto de host está dentro del rango establecido aquí.";
$adv_host_2_ip="Rango IP de host 2";
$adv_host_2_ip_msg="La regla se aplica a un flujo de mensajes para el que la dirección IP del otro ordenador entra dentro del rango establecido aquí.";
$adv_host_2_port="Rango de puerto de host 2";
$adv_host_2_port_msg="La regla se aplica a un flujo de mensajes para el que el segundo número de puerto de host está dentro del rango establecido aquí.";
   

$head_dhcp="Servidor DHCP";
$head_dhcp_msg="El servidor DHCP (Protocolo de configuración de host dinámico) asigna las direcciones IP a las estaciones que solicitan direcciones IP".
" mientras inician sesión en la red inalámbrica. Las estaciones se deben configurar como un cliente DHCP con el fin de obtener automáticamente las direcciones IP. El valor predeterminado para el control del servidor DHCP es \"desactivado\".";

$title_dhcp_dynamic_pool="Parámetros de grupo dinámico";
$title_dhcp_dynamic_pool_msg="El grupo de direcciones DHCP define el rango de la dirección IP que se puede asignar a las estaciones en la red. Un grupo dinámico".
" permite a las estaciones inalámbricas recibir una IP disponible con control del tiempo de validez.";
$dhcp_ip_assigned="IP asignada desde";
$dhcp_ip_assigned_msg="El usuario puede especificar el comienzo del grupo de direcciones IP disponibles en las estaciones inalámbricas.";
$dhcp_range_of_pool="Rango  del grupo (1-254)";
$dhcp_range_of_pool_msg="Los usuarios pueden especificar el rango de las direcciones IP que están disponibles. Las direcciones IP son incrementos de la dirección IP especificada en el campo \"IP asignada desde\".";
$dhcp_submask="Máscara de subred";
$dhcp_submask_msg="Defina la máscara de subred de la dirección IP especificada en el campo \"IP asignada desde\.";
$dhcp_gateway="Puerta de enlace";
$dhcp_gateway_msg="Especifique la dirección de la puerta de enlace para la red inalámbrica.";
$dhcp_wins="WINS";
$dhcp_wins_msg="Especifique la dirección WINS para la red inalámbrica.";
$dhcp_dns="DNS";
$dhcp_dns_msg="Especifique la dirección DNS para la red inalámbrica.";
$dhcp_domain="Nombre de dominio";
$dhcp_domain_msg="Especifique la dirección de nombre de dominio para la red inalámbrica.";
$dhcp_lease_time="Tiempo de validez";
$dhcp_lease_time_msg="Los usuarios pueden definir las duraciones asociadas a las direcciones especificando el tiempo de validez de la dirección IP.";

$title_dhcp_static_pool="Parámetros de grupo estático";
$title_dhcp_static_pool_msg="El grupo de direcciones DHCP define el rango de las direcciones IP que se pueden asignar a las estaciones en la red. ".
"Un grupo estático permite a las estaciones inalámbricas recibir una IP disponible sin control del tiempo.";
$dhcp_assigned_ip="IP asignada";
$dhcp_assigned_ip_msg="Especifique la dirección IP que se va a asignar para una estación con una dirección MAC especificada en el campo \"Dirección MAC asignada\".";
$dhcp_assigned_mac="Dirección MAC asignada";
$dhcp_assigned_mac_msg="Especifique la dirección MAC de la asociación que solicita la estación.";

$title_dhcp_current_ip="Asignación de IP actual";
$title_dhcp_current_ip_msg="En una lista se incluyen las direcciones MAC, direcciones IP y tiempos de validez de las estaciones inalámbricas ".
"asociadas con el ".query("/sys/hostname")." mediante un servidor DHCP que utiliza grupos dinámicos o grupos estáticos.";


$head_filters="Filtros";
$head_filters_msg="La función de filtro incluye el filtrado de la dirección MAC y una partición de LAN inalámbrica. El filtrado de la dirección MAC bloquea o acepta la asociación identificando ".
"las direcciones MAC especificadas. La partición de LAN inalámbrica puede aceptar o rechazar el acceso de las redes inalámbricas o con cables.";

$title_filters_wireless_access="Parámetros de acceso inalámbrico";
$filters_wireless_band="Banda de Frecuencia inalámbrica";
$filters_wireless_band_msg="Banda de frecuencia en funcionamiento. Elija 2,4 GHz para conseguir visibilidad de los dispositivos heredados y de rangos más largos.".
" Elija 5 GHz para conseguir menos interferencias. Esta parte seguirá los parámetros inalámbricos básicos.";

$title_filters_wlan_partition="Partición WLAN";
$filters_internal_station="Conexión de estación interna";
$filters_internal_station_msg="El valor predeterminado es \"Activar\", que permite a las estaciones intercomunicarse mediante la conexión a un AP objetivo. Las estaciones inalámbricas no pueden intercambiar datos a través del AP cuando está desactivada esta opción.";
$filters_eth_to_wlan="Acceso Ethernet a WLAN";
$filters_eth_to_wlan_msg="El valor predeterminado es \"Activar\", que permite el flujo de datos desde Ethernet a las estaciones inalámbricas conectadas al AP. Al desactivar esta función, se bloquean la difusión de ".
"los datos desde Ethernet a los dispositivos inalámbricos asociados mientras que las estaciones inalámbricas pueden seguir enviando datos a Ethernet a través de AP.";


$head_st="Parámetros de estado";

$title_st_dev_info="Información del dispositivo";
$title_st_dev_info_msg="Esta página muestra la información actual, como la versión de firmware, Ethernet y los parámetros inalámbricos, así como la información relativa a la CPU y a la utilización de la memoria.";


$title_st_cli_info="Información del cliente";
$title_st_cli_info_msg="Esta página muestra el SSID, MAC, la banda, el método de autenticación, la potencia de la Señal y el modo de ahorro de energía de los clientes asociados para la red del ".query("/sys/hostname").".";

$title_st_wds_info="Información WDS";
$title_st_wds_info_msg="Esta página muestra el SSID, MAC, la banda, el método de autenticación, la potencia de la Señal y el modo de ahorro de energía de los puntos de acceso para la red del sistema de distribución inalámbrica del ".query("/sys/hostname").".";


$head_statistics="Estadísticas";

$title_st_ethernet="Estadísticas de tráfico Ethernet";
$title_st_ethernet_msg="Muestra la información del tráfico de red de la interfaz con cables.";

$title_st_wlan="Estadísticas de tráfico WLAN 802.11G";
$title_st_wlan_msg="Muestra la información de resultado, marco transmitido, marco recibido y error de marco WEP para la red de AP.";


$head_log="Registro";
$head_log_msg="Registra los eventos de registro en un servidor remoto de registro del sistema y muestra la página web.";

$title_log_view="Ver registro";
$title_log_view_msg="La memoria incorporada del AP mantiene aquí los registros. La información de registro incluye, aunque no de forma exclusiva, ".
"los elementos siguientes: AP de inicio en frío, firmware de actualización, asociación y disociación del cliente con el AP e inicio de sesión en la web. La página web mantiene hasta 500 registros.";

$title_log_set="Parámetros de registro";
$title_log_set_msg="Introduzca la dirección IP del servidor de registro para enviar el registro a dicho servidor. Marque o anule la marca ".
"de Actividad del sistema, Actividad inalámbrica o Aviso para especificar el tipo de registro que desea que se registre.";


$head_mt="Mantenimiento";

$title_mt_admin="Parámetros de administrador";
$mt_limit_admin_vid="Limitar el VID de administrador";
$mt_limit_admin_vid_msg="Los paquetes con marcas de VLAN que tienen el mismo VID permitirán que el administrador inicie la sesión.";
$mt_limit_admin_ip="Limitar el rango IP del administrador";
$mt_limit_admin_ip_msg="Introduzca un grupo de direcciones IP desde el que el administrador tenga permiso para iniciar la sesión.";
$title_mt_sysname="Parámetros de nombre del sistema";
$mt_sysname="Nombre del sistema";
$mt_sysname_msg="Un nombre asignado administrativamente para el ".query("/sys/hostname").".";
$mt_location="Ubicación";
$mt_location_msg="La ubicación física del ".query("/sys/hostname").".";
$title_mt_login="Parámetros de inicio de sesión";
$mt_username="Nombre de usuario";
$mt_username_msg="Puede personalizar el nombre de usuario como un administrador del ".query("/sys/hostname").". El nombre de usuario predeterminado ".
"es \"admin\", sin contraseña configurada.";
$mt_oldpass="contraseña antigua";
$mt_oldpass_msg="Introduzca la contraseña antigua.";
$mt_newpass="Nueva contraseña";
$mt_newpass_msg="Introduzca una contraseña en este campo. La contraseña distingue entre mayúsculas y minúsculas. \"A\" es un carácter diferente de \"a\" ".
"La longitud debe estar entre 0 y 12 caracteres.";
$mt_conpass="Confirmar nueva contraseña";
$mt_conpass_msg="Escriba de nuevo la contraseña para confirmarla.";
$title_mt_console="Parámetros de consola";
$mt_status="Estado";
$mt_status_msg="Active o desactive la consola.";
$mt_console_protocol="Protocolo de consola";
$mt_console_protocol_msg="Elija Telnet o SSH.";
$mt_timeout="Tiempo de espera";
$mt_timeout_msg="Seleccione el periodo de tiempo de espera.";
$title_mt_snmp="Parámetros SNMP";
$mt_st_snmp="Estado";
$mt_st_snmp_msg="Active o desactive el SNMP.";
$mt_public_comm="Cadena de comunidad pública";
$mt_public_comm_msg="Introduzca la cadena de comunidad pública para SNMP.";
$mt_private_comm="Cadena de comunidad privada";
$mt_private_comm_msg="Introduzca la cadena de comunidad privada para SNMP.";
$mt_trap="Estado de la trampa";
$mt_trap_msg="Active o desactive la trampa.";
$mt_trap_serv="IP de servidor de trampas";
$mt_trap_serv_msg="La dirección IP del gestor de SNMP para recibir las trampas ".
"enviadas desde el punto de acceso inalámbrico.";
$title_mt_pingctrl="Parámetros de control de Ping";
$mt_ping_st="Estado";
$mt_ping_st_msg="El ping funciona enviando paquetes de \"solicitud de eco\" ICMP al host objetivo y escuchando las respuestas de contestación de eco de ".
"ICMP. Al desactivar los parámetros de control de Ping, este AP no responderá a los paquetes de solicitud de eco ICMP. Está activado el valor predeterminado.";

$title_mt_fw="Firmware y SSL";
$title_mt_fw_msg="Carga del firmware y la certificación SSL";
$title_mt_fw_msg1="Puede cargar archivos en el punto de acceso.";
$mt_upload_fw="Cargar firmware desde la unidad de disco duro local";
$mt_upload_fw_msg="La versión de firmware actual se muestra encima del campo de ubicación de archivos. Después de descargar el firmware más actual, haga ".
"clic en el botón \"Examinar\" para localizar el nuevo firmware. Una vez seleccionado el archivo, haga clic en el botón \"Abrir\" y \"Aceptar\"".
" para comenzar la actualización del firmware. No apague la alimentación mientras está actualizando.";
$mt_upload_ssl="Cargar la certificación SSL desde la unidad de disco duro local";
$mt_upload_ssl_msg="Después de descargar una certificación SSL en su unidad local, haga clic en \"Examinar\"  Seleccione la certificación y haga clic en ".
"\"Abrir\" y en \"Cargar\" para completar la actualización.";

$_title_mt_config="Archivo de configuración";
$mt_config="Carga y descarga del archivo de configuración";
$mt_config_msg="Puede cargar y descargar los archivos de configuración del punto de acceso.";
$mt_upload_config="Carga del archivo de configuración";
$mt_upload_config_msg="Desplácese hasta el archivo de configuración que tiene guardado en su unidad local y haga clic en \"Abrir\" y \"Cargar\" para actualizar la configuración.";
$mt_download_config="Descarga del archivo de configuración";
$mt_download_config_msg="Haga clic en \"Descargar\" para guardar el archivo de configuración actual en su disco local. Tenga en cuenta que si guarda ahora un ".
"archivo de configuración con la contraseña de administrador, tras reiniciar su ".query("/sys/hostname")." y actualizar después a este archivo de configuración guardado, se perderá la contraseña.";

$title_mt_time="Fecha y hora";
$title_mt_time_msg="Introduzca la IP del servidor NTP, elija la zona horaria y active o desactive el horario de verano.";


$head_sys = "Sistema";
$title_sys = "Parámetros del sistema";
$sys_apply_restart = "Aplicar parámetros y Reiniciar";
$sys_apply_restart_msg = "Haga clic en Reiniciar para aplicar los parámetros y reiniciar.";
$sys_apply_restore = "Restablecer los parámetros predeterminados de fábrica.";
$sys_apply_restore_msg = "Haga clic en Restablecer para reiniciar en los parámetros predeterminados de fábrica.";


?>
