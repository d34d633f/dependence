<?
$msg_title="Estadísticas de tráfico Ethernet";
$msg_t_title="Recuento transmitido";
$msg_r_title="Recuento recibido";
$msg_T_Packet="Recuento de paquete transmitido";
$msg_T_Bytes="Recuento de bytes transmitidos";
$msg_T_Dropped_Packet="Recuento de paquete interrumpido";
$msg_R_Packet="Recuento de paquete recibido";
$msg_R_Bytes="Recuento de bytes recibidos";
$msg_R_Dropped_Packet="Recuento de paquete interrumpido";
$msg_R_Multicast_Packet="Recuento de paquete multidifusión recibido";
$msg_R_Broadcast_Packet="Recuento de paquete de difusión recibido";
$msg_Len_64="Recuento de paquete de longitud 64";
$msg_Len_65_127="Recuento de paquete de longitud 65~127.";
$msg_Len_128_255="Recuento de paquete de longitud 128~255.";
$msg_Len_256_511="Recuento de paquete de longitud 256~511.";
$msg_Len_512_1023="Recuento de paquete de longitud 512~1023.";
$msg_Len_1024_1518="Recuento de paquete de longitud 1024~1518.";
$msg_Len_1519_MAX="Recuento de paquete de longitud 1519~MáX.";
$msg_clear="Borrar";
$msg_refresh="Actualizar";
?>
