﻿Se está actualizando el F/W ...<br><br>
NO APAGUE <font color=red><b>el </b></font>dispositivo.<br><br>
Y espere durante
<input type='text' readonly name='WaitInfo' value='150' size='2' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>