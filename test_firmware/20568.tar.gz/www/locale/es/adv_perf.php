<?
$m_context_title = "Parámetros de rendimiento";
$m_wl_enable = "Inalámbrico";
$m_disable = "Desactivar";
$m_enable  = "Activar";
$m_off = "Desactivado";
$m_on  = "Activado";
$m_wlmode = "Modo inalámbrico";
$m_wlmode_n_g_b = "Mezcla de 802.11n, 802.11g y 802.11b";
$m_wlmode_n_g = "Mezcla de 802.11n y 802.11g";
$m_wlmode_g_b = "Mezcla de 802.11g y 802.11b";
$m_wlmode_n = "Sólo 802.11n";
$m_wlmode_n_a = "Mezcla de 802.11n y 802.11a";
$m_wlmode_a = "Sólo 802.11a";
$m_rate = "Velocidad de los datos";
$m_best	= "Mejor (hasta 300)";
$m_best_54	= "Mejor (hasta 54)";
$m_54	= "54";
$m_48	= "48";
$m_36	= "36";
$m_24	= "24";
$m_18	= "18";
$m_12	= "12";
$m_9	= "9";
$m_6	= "6";
$m_11	= "11";
$m_5.5	= "5.5";
$m_2	= "2";
$m_1	= "1";
$m_beacon_interval	="Intervalo de emisión de señales (25-500)";
$m_rts			="Umbral RTS (256-2346)";
$m_frag			="Fragmentación (256-2346)";
$m_dtim			="Intervalo DTIM (1-15)";
$m_power = "Potencia de transmisión";
$m_ms = "(&micro;s)";

$m_wmm = "WMM (Multimedia Wi-Fi)";
$m_shortgi = "GI corta";
$m_limit_state = "Límite de conexión";
$m_limit_num = "Límite de usuario (0 - 64)";
$m_utilization = "Utilización de la red";
$m_0 = "0";
$m_10 = "10";
$m_20 = "20";
$m_30 = "30";
$m_40 = "40";
$m_50 = "50";
$m_60 = "60";
$m_70 = "70";
$m_80 = "80";
$m_90 = "90";
$m_100 = "100";
$m_180 = "180";
$m_25 = "25";
$m_12.5 = "12.5";
$m_igmp = "Fisgoneo de IGMP";
$m_link_integrality="Integridad del enlace";
$m_ack_timeout="Tiempo de espera de aceptación";
$m_mbps = "(Mbps)";
if(query("/runtime/web/display/ack_timeout_range")=="0")
{
$m_ack_timeout_g_msg = " (2.4GHz, 48~200)";
$m_ack_timeout_a_msg = " (5GHz, 25~200)";
	$a_invalid_ack_timeoutg ="El rango del valor del tiempo de espera de aceptación es 48 ~ 200.";
	$a_invalid_ack_timeouta ="El rango del valor del tiempo de espera de aceptación es 48 ~ 200.";
}
else
{
	$m_ack_timeout_g_msg = " (2.4GHz, 64~200)";
	$m_ack_timeout_a_msg = " (5GHz, 50~200)";
	$a_invalid_ack_timeoutg ="El rango del valor del tiempo de espera de aceptación es 64 ~ 200.";
	$a_invalid_ack_timeouta ="El rango del valor del tiempo de espera de aceptación es 50 ~ 200.";
}
$a_invalid_bi		="El rango del valor del intervalo de emisión de señales es 25 ~ 500.";
$a_invalid_rts		="El rango del valor de umbral de RTS es 256 ~ 2.346.";
$a_invalid_frag		="El rango del valor de fragmentación es 256 ~ 2.346.";
$a_invalid_dtim		="El rango del valor del intervalo DTIM es 1~15.";
$a_invalid_limit_num	="El rango del 'Límite de usuario' es del 0 al 64.";

?>
