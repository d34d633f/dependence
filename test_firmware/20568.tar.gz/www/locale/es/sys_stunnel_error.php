﻿<?
$m_html_title="Cargar";
$m_context_title="Cargar";
$m_context="Error del sistema. !!!<br>Inténtelo de nuevo.";
$m_button_dsc="Atrás";
?>
