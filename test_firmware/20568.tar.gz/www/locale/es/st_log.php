<?
$m_context_title	= "Ver registro";

$m_first_page	= "Primera página";
$m_last_page	= "Última página";
$m_previous	= "Anterior";
$m_next		= "Siguiente";
$m_clear	= "Borrar";

$m_time		= "Hora";
$m_type		= "Prioridad";//"Type";
$m_message	= "Mensaje";
$m_page		= "Página";
$m_of		= "de";
?>
