<?
$MAX_RULES=query("/lan/dhcp/server/pool:1/staticdhcp/max_client");
if ($MAX_RULES==""){$MAX_RULES=25;}	
$m_context_title = "Parámetros de grupo estático";
$m_srv_enable = "Función Activar/Desactivar";
$m_disable = "Desactivar";
$m_enable = "Activar";
$m_dhcp_srv = "Control del servidor DHCP";
$m_dhcp_pool = "Parámetros de grupo estático";
$m_computer_name = "Nombre del ordenador";
$m_ipaddr = "IP asignada";
$m_macaddr = "Dirección MAC asignada";
$m_ipmask = "Máscara de subred";
$m_gateway = "Puerta de enlace";
$m_wins = "Wins";
$m_dns = "DNS";
$m_m_domain_name = "Nombre de dominio";
$m_on = "ACTIVADO";
$m_off = "DESACTIVADO";
$m_status_enable = "Estado";
$m_mac = "Dirección MAC";
$m_ip = "Dirección IP";
$m_state = "Estado";
$m_edit = "Editar";
$m_del = "Borrar";

$a_invalid_host		= "Nombre de ordenador no válido !";
$a_invalid_ip		= "Dirección IP no válida.";
$a_invalid_mac		= "Dirección MAC no válida.";
$a_max_mac_num = "El número máximo de la lista de control de acceso es xx ".$MAX_RULES."!";
$a_same_mac = "Hay una entrada existente con la misma dirección MAC.\\nCambie la dirección MAC.";
$a_invalid_netmask	= "Máscara de subred no válida.";
$a_invalid_gateway	="Puerta de enlace no válida.";
$a_invalid_wins	= "Wins no válido.";
$a_invalid_dns	="DNS no válido.";
$a_invalid_domain_name	= "Nombre de dominio no válido.";
$a_invalid_lease_time	= "Tiempo de validez de DHCP no válido.";
$a_entry_del_confirm = "¿Está seguro de que desea eliminar esta entrada?";
?>
