<?
$version_no=query("/runtime/sys/info/firmwareverreve");
$build_no=query("/runtime/sys/info/firmwarebuildno");

$m_context_title	="Versione ";

$m_context = "Versione : ".$version_no."<br><br>Numero di revisione : ".$build_no."<br><br>";
$m_context = $m_context."Tempo di attività sistema : <script>document.write(shortTime());</script>";

$m_days		= "giorni";
$m_button_dsc	=$m_continue;
?>
