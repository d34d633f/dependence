<?
// category
$m_menu_top_bsc		="Configurazione";
$m_menu_top_adv		="Avanzate";
$m_menu_top_tools	="MANUTENZIONE";
$m_menu_top_st		="Stato";
$m_menu_top_spt		="Supporto";

// basic
$m_menu_bsc_wizard      ="PROCEDURA GUIDATA";
$m_menu_bsc_internet	="INTERNET";
$m_menu_bsc_wlan	="CONFIGURAZIONE WIRELESS";
$m_menu_bsc_lan		="CONFIGURAZIONE LAN";

// advanced
$m_menu_adv_vrtsrv	="SERVER VIRTUALE";
$m_menu_adv_port	="INOLTRO PORTE";
$m_menu_adv_app		="REGOLE APPLICAZIONE";
$m_menu_adv_mac_filter	="FILTRO DI RETE";
$m_menu_adv_acl		="FILTRO";
$m_menu_adv_url_filter	="FILTRO SITI WEB";
$m_menu_adv_dmz		="IMPOSTAZIONI FIREWALL";
$m_menu_adv_wlan	="PRESTAZIONI";
$m_menu_adv_network	="RETE AVANZATA";
$m_menu_adv_dhcp	="SERVER DHCP";
$m_menu_adv_mssid	="SSID MULTIPLI";
$m_menu_adv_group	="Limite utenti";
$m_menu_adv_wtp		="Switch WLAN";
$m_menu_adv_wlan_partition	="Partizione WLAN";

// tools
$m_menu_tools_admin	="Amministrazione dispositivi";
$m_menu_tools_time	="ORA";
$m_menu_tools_system	="SISTEMA";
$m_menu_tools_firmware	="FIRMWARE";
$m_menu_tools_misc	="VARIE";
$m_menu_tools_ddns	="DDNS";
$m_menu_tools_vct	="VERIFICA SISTEMA";
$m_menu_tools_sch	="PIANIFICAZIONI";
$m_menu_tools_log_setting	="IMPOSTAZIONI LOG";

// status
$m_menu_st_device	="INFO DISPOSITIVO";
$m_menu_st_log		="LOG";
$m_menu_st_stats	="Statistiche";
$m_menu_st_wlan		="INFO CLIENT";

// support
$m_menu_spt_menu	="MENU";

$m_logout	="Disconnetti";

$m_menu_home	="Home";
$m_menu_tool	="Manutenzione";
$m_menu_config	="Configurazione";
$m_menu_sys	="Sistema";
$m_menu_logout	="Disconnetti";
$m_menu_help	="Guida";
$m_menu_tool_admin	="Impostazioni amministratore";
$m_menu_tool_fw	="Caricamento certificati SSL e firmware";
$m_menu_tool_config	="File di configurazione";
$m_menu_tool_sntp	="SNTP";

$m_menu_config_save	="Salva e attiva";
$m_menu_config_discard	="Cancella modifiche";

$a_config_discard ="Tutte le modifiche verranno cancellate. Continuare?";

?>
