<?

$msg_title="Statistiche traffico WLAN";
$msg_t_title="Totale trasmesso";
$msg_t_msg1="Totale pacchetti trasmessi";
$msg_t_msg2="Totale byte trasmessi";
$msg_t_msg3="Totale pacchetti cancellati";
$msg_t_msg4="Totale tentativi trasmissione";
$msg_r_title="Totale ricevuto";
$msg_r_msg1="Totale pacchetti ricevuti";
$msg_r_msg2="Totale byte ricevuti";
$msg_r_msg3="Totale pacchetti cancellati";
$msg_r_msg4="Totale CRC ricevuti";
$msg_r_msg5="Totale errori decrittografia ricevuti";
$msg_r_msg6="Totale errori MIC ricevuti";
$msg_r_msg7="Totale errori PHY ricevuti";
$msg_clear="Cancella";
$msg_refresh="Aggiorna";




?>
