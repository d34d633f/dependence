<?
$m_context_title = "Caricamento certificati SSL e firmware";

$m_upload_fw_title ="Aggiorna firmware da disco fisso locale";
$m_firmware_version	="Versione firmware";
$m_upload_firmware_file	="Carica firmware da file";	
$m_upload_lang_title ="Aggiornamento Language Pack";	
$m_upload_lang_file	="Carica";	
$m_upload_ssl_titles = "Aggiorna certificati SSL da disco fisso locale";
$m_upload_certificatee_file	= "Carica certificato da file";	
$m_upload_key_file	= "Carica chiave da file";	
$m_b_fw_upload = "Carica";
$a_blank_fw_file= "File vuoto non consentito.";
$a_format_error_file =" Formato di file errato. Riprovare.";
?>
