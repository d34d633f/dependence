<?
$tool_admin = "Impostazioni amministrazione";
$tool_fw = "Caricamento certificati SSL e firmware";
$tool_config = "File di configurazione";
$tool_sntp = "Data e ora";
$logout_msg = "&nbsp;&nbsp;La connessione al browser corrente verrà <br>&nbsp;&bsp;interrotta se si fa clic <b>qui</b>";
?>
