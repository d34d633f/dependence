<?
$m_html_title="Sessione completa";
$m_context_title="Sessione completa";
$m_context="Sessione di accesso completa. Riprovare più tardi.";
$m_button_dsc="Esegui nuovamente accesso";
?>
