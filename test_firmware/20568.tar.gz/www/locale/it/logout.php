<?
$m_html_title="Disconnetti";
$m_context_title="Disconnetti";
$m_context="Disconnessione effettuata correttamente.";
$m_button_dsc="Torna a pagina di accesso";
?>
