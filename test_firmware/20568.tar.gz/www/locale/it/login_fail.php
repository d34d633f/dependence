<?
$m_html_title	= "Accesso non riuscito";
$m_context_title= "Accesso non riuscito";
$m_context	= "Nome utente o password errata.";
$m_button_dsc	= "Esegui nuovamente accesso";
?>
