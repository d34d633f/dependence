iavvio del dispositivo in corso
<font color=red><b>NON SPEGNERE</b></font>il dispositivo.<br><br>
Attendere
<input type='Text' readonly name='WaitInfo' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
secondi...
