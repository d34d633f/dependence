<?
$m_context_title = "Elenco IP corrente";
$m_host_name = "Nome host";
$m_mac = "Indirizzo MAC di binding";
$m_ip = "Indirizzo IP assegnato";
$m_time = "Tempo di validità";
$m_dynamic_pools = "Pool dinamici DHCP correnti";
$m_static_pools = "Pool statici DHCP correnti";
$m_days			="giorni";
$m_hrs			="ore";
$m_mins			="minuti";
$m_secs			="secondi";
?>
