<?
$ssid_flag = query("/runtime/web/display/mssid_index4");
$m_context_title = "Informazioni sistema";
$m_model_name	= "Nome modello";
$m_sys_time	="Ora di sistema";
$m_up_time	="Tempo attività";
$m_firm_version	="Versione firmware";
$m_ip	="Indirizzo IP";
$m_mac	="Indirizzo MAC";
if($ssid_flag == "1")
{
	$m_mssid	="SSID 1~3";
}
else
{
$m_mssid	="SSID 1~7";
}
$m_ap_mode ="Modalità operativa";
$m_days = "Giorni";
$m_sysname = "Nome sistema";
$m_location = "Percorso";
$m_ap = "Punto di accesso";
$m_wireless_client = "Client wireless";
$m_wds_ap = "WDS con punto di accesso";
$m_wds = "WDS";
?>
