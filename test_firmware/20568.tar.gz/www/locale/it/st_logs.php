<?
$m_context_title	= "Impostazioni log";
$m_log_setting_title = "Impostazioni log";
$m_log_ip	=  "Server log/Indirizzo IP  ";
$m_log_type = "Tipo di log";
$m_system_activity	=  "Attività di sistema";
$m_wireless_activity	=  "Attività wireless";
$m_notice	=  "Nota";
$m_smtp_setting_title = "Notifica e-mail";
$m_smtp = "Notifica e-mail";
$m_enable = "Abilita";
$m_smtp_ip = "Indirizzo server di posta";
$m_smtp_from_email = "Indirizzo e-mail mittente";
$m_smtp_to_email = "Indirizzo e-mail destinatario";
$m_email_log_schedule_title = "Pianificazione invio log tramite email";
$m_log_schedule = "Pianificazione";
$m_log_schedule_msg = "ore o quando il log è pieno";
$m_smtp_name = "Nome utente";
$m_smtp_password ="Password";
$m_smtp_confirm_password ="Conferma password";
$m_smtp_port = "Porta SMTP";

$a_invalid_log_ip		= "Server log/Indirizzo IP non valido.";
$a_invalid_smtp_ip		= "Server posta/Indirizzo IP non valido.";
$a_empty_user_name	="Immettere il nome utente.";
$a_invalid_user_name	="Il nome utente contiene un carattere non valido. Controllarlo.";
$a_first_blank_user_name	= "Il primo carattere del nome utente non può essere vuoto.";
$a_invalid_new_password	="La password contiene un carattere non valido. Controllarlo.";
$a_password_not_matched	="I campi Password e Conferma password non coincidono.";
$a_invalid_smtp_port = "Porta SMTP non valida.";
?>
