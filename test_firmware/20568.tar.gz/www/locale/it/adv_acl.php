<?
$m_context_title = "Impostazioni ACL MAC wireless";
$m_acl_type = "Elenco di controllo di accesso (ACL)";
$m_disable = "Disabilita";
$m_accept = "Accetta";
$m_reject = "Rifiuta";
$m_wmac = "Indirizzo MAC";
$m_id = "ID";
$m_del = "Elimina";
$m_wband = "Banda wireless";
$m_band_5G = "5GHz";
$m_band_2.4G = "2.4GHz";
$m_ssid = "SSID";
$m_mac = "Indirizzo MAC";
$m_band = "Banda";
$m_auth = "Autenticazione";
$m_signal = "Segnale";
$m_power = "Modalità risparmio energetico";
$m_multi_ssid = "SSID multipli ";
$m_primary_ssid = "SSID primario";
$m_clirnt_info = "Informazioni su client corrente";
$m_b_add = "Aggiungi";

$a_acl_del_confirm		= "Eliminare questo indirizzo MAC?";
$a_same_acl_mac	= "Esiste già una voce con lo stesso Indirizzo MAC. \\n Modificare l'indirizzo MAC.";
$a_invalid_mac		= "Indirizzo MAC non valido.";
$a_max_acl_mac		= "Il numero massimo di elenchi di controllo di accesso è 256.";

?>
