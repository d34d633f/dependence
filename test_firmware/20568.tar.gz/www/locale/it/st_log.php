<?
$m_context_title	= "Visualizza log";

$m_first_page	= "Prima pagina";
$m_last_page	= "Ultima pagina";
$m_previous	= "Precedente";
$m_next		= "Successiva";
$m_clear	= "Cancella";

$m_time		= "Ora";
$m_type		= "Priorità ";//"Type";
$m_message	= "Messaggio";
$m_page		= "Pagina";
$m_of		= "di";
?>
