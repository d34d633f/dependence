<?
$m_menu_upgrade_fw = "<font face=\"Arial\" color=\"red\" size=2>".
					 "<b>Non spegnere </b></font>".
					 "<font face=\"Arial\" size=2>il dispositivo durante il processo.".
					 "In caso contrario ".query("/sys/hostname").
					 "potrebbe subire danni. (Se il browser non riporta automaticamente alla pagina Web,".
					 "fare clic su Aggiorna.)</font>";
					 
$m_upload_fw = "Aggiornamento firmware in corso…";
$m_verify_fw = "Verifica firmware in corso…";
$m_upgrad_device = "Aggiornamento dispositivo in corso…";
$m_reboot_device = "Riavvio dispositivo in corso…";

$a_upgrade_fw_fail_msg = "L'aggiornamento del firmware non è riuscito. Ricaricarlo e riprovare.";

?>
