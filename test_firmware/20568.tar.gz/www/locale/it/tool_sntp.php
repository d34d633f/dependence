<?
$m_context_title = "Impostazioni data e ora";
$m_time_config_title = "Configurazione ora";
$m_auto_time_config_title = "Configurazione ora automatica";
$m_set_date_time_title = "Impostazione manuale di data e ora";
$m_time				= "Ora attuale";
$m_time_zone			= "Fuso orario";
$m_enable_daylight_saving	= "Abilita aggiornamento ora legale";

$m_title_ntp	= "Configurazione ora automatica";
$m_enable_ntp		= "Abilita server NTP";
$m_interval		= "Intervallo";
$m_ntp_server		= "Server NTP";
$m_select_ntp_server	= "Seleziona server NTP";

$m_current_time	= "Data e ora";
$m_year		= "Anno";
$m_month	= "Mese";
$m_day		= "Giorno";
$m_days		= "Giorni";
$m_hour		= "Ora";
$m_minute	= "Minuto";
$m_second	= "Secondo";
$m_copy_pc_time	= "Copia ora dal computer";
$m_daylight_saving_offset	="Offset aggiornamento ora legale";
$m_daylight_saving_date	="Date aggiornamento ora legale";
$m_week ="Settimana";
$m_day_of_week = "Giorno della settimana";
$m_dst_start = "Inizio ora legale";
$m_dst_end = "Fine ora legale";
$m_jan = "gen";
$m_feb = "feb";
$m_mar = "mar";
$m_apr = "apr";
$m_may = "mag";
$m_jun = "giu";
$m_jul = "lug";
$m_aug = "ago";
$m_sep = "set";
$m_oct = "ott";
$m_nov = "nov";
$m_dec = "dic";
$m_1st = "1st";
$m_2nd = "2nd";
$m_3rd = "3rd";
$m_4th = "4th";
$m_5th = "5th";
$m_sun = "dom";
$m_mon = "lun";
$m_tue = "mar";
$m_wed = "mer";
$m_thu = "gio";
$m_fri = "ven";
$m_sat = "sab";
$m_am = " AM";
$m_pm = " PM";


$a_invalid_ntp_server	= "Server NTP non valido.";
?>
