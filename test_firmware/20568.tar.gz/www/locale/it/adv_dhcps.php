<?
$MAX_RULES=query("/lan/dhcp/server/pool:1/staticdhcp/max_client");
if ($MAX_RULES==""){$MAX_RULES=25;}	
$m_context_title = "Impostazioni pool statico";
$m_srv_enable = "Abilita/Disabilita funzione";
$m_disable = "Disabilita";
$m_enable = "Abilita";
$m_dhcp_srv = "Controllo server DHCP";
$m_dhcp_pool = "Impostazione pool statico";
$m_ipaddr = "IP assegnato";
$m_macaddr = "Indirizzo MAC assegnato";
$m_ipmask = "Subnet mask";
$m_gateway = "Gateway";
$m_wins = "WINS";
$m_dns = "DNS";
$m_m_domain_name = "Nome dominio";
$m_on = "ATTIVO";
$m_off = "NON ATTIVO";
$m_status_enable = "Stato";
$m_mac = "Indirizzo MAC";
$m_ip = "Indirizzo IP";
$m_state = "Stato";
$m_edit = "Modifica";
$m_del = "Elimina";

$m_computer_name = "Nome computer";

$a_invalid_host               = "Nome di computer non valido !";

$a_invalid_ip		= "Indirizzo IP non valido.";
$a_invalid_mac		= "Indirizzo MAC non valido.";
$a_max_mac_num = "Il numero massimo di elenchi di controllo di accesso è ".$MAX_RULES."!";
$a_same_mac = "Esiste già una voce con lo stesso Indirizzo MAC. \\n Modificare l'indirizzo MAC.";
$a_invalid_netmask	= "Subnet mask non valida.";
$a_invalid_gateway	="Gateway non valido.";
$a_invalid_wins	= "WINS non valido.";
$a_invalid_dns	="DNS non valido.";
$a_invalid_domain_name	= "Nome di dominio non valido.";
$a_invalid_lease_time	= "Tempo di validità DHCP non valido.";
$a_entry_del_confirm = "Eliminare questa voce?";
?>
