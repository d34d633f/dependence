<?
$m_context_title = "Partizione wireless";
$m_isc = "Connessione a stazione interna";
$m_guest = "Modalità Guest";
$m_pri_ssid = "SSID primario";
$m_ms_ssid1 = "SSID multipli 1";
$m_ms_ssid2 = "SSID multipli 2";
$m_ms_ssid3 = "SSID multipli 3";
$m_ms_ssid4 = "SSID multipli 4";
$m_ms_ssid5 = "SSID multipli 5";
$m_ms_ssid6 = "SSID multipli 6";
$m_ms_ssid7 = "SSID multipli 7";

$m_ewa = "Accesso Ethernet a WLAN";
$m_enable = "Abilita";
$m_disable = "Disabilita";
$m_band = "Banda wireless";
$m_band_5G = "5GHz";
$m_band_2.4G = "2.4GHz";
?>
