<?
$m_context_title = "Caricamento e download file di configurazione";
$m_save_cfg = "Carica impostazioni su disco fisso locale";
$m_save = "Scarica";
$m_load_cfg = "Carica file";
$m_b_load = "Carica";
$m_upload_config_title = "Carica file di configurazione";
$m_download_config_title = "Scarica file di configurazione";

$a_empty_cfg_file_path	="Selezionare un file di configurazione salvato da caricare.";
$a_error_cfg_file_path	="Formato di file errato. Riprovare.";
$a_sure_to_reload_cfg	="Caricare le impostazioni dal file?";
?>
