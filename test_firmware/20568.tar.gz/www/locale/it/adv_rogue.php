<?
$m_context_title = "Protezione da intrusioni wireless";
$m_b_detect = "Rileva";
$m_ap_list_title = "Elenco punti di accesso";
$m_type = "Tipo";
$m_band = "Banda";
$m_channel = "CH";
$m_ssid = "SSID";
$m_mac = "BSSID";
$m_last_seem = "Ultima rilevazione";
$m_status = "Stato";
$m_b_valid = "Impostato come valido";
$m_b_neighborhood = "Impostato come vicino";
$m_b_rogue = "Impostato come inaffidabile";
$m_b_new = "Impostato come nuovo";
$m_all_valid = "Contrassegna tutti i punti di accesso nuovi come validi";
$m_all_rogue = "Contrassegna tutti i punti di accesso nuovi come inaffidabili";
$m_valid = "Valido";
$m_neighborhood = "Vicino";
$m_rogue = "Inaffidabile";
$m_new = "Nuovo";
$m_a = "A";
$m_b = "B";
$m_g = "G";
$m_n = "N";
$m_days = "Giorni";
$m_all = "Tutti";
$m_up = "Su";
$m_down = "Giù";

$a_max_list =" Il numero massimo di questo elenco di tipi è 64! \\n";
$a_can_add_num = "È possibile aggiungere ";
$a_entry = " voce";
$a_no_click = "Nessuna voce selezionata.";
?>
