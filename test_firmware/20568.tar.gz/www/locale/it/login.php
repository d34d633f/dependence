<?
$a_invalid_user_name	="Immettere il nome utente.";

$m_html_title		="ACCESSO";
$m_context_title	="ACCESSO";
$m_login_router		="Accesso al router:";
$m_login_ap		="Accesso al punto di accesso:";
$m_log_in		=" ACCESSO ";
?>
