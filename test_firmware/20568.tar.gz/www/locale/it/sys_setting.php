<?
$m_context_title = "Impostazioni sistema";
$m_reboot		=" Riavvia dispositivo";
$m_b_reboot		=" Riavvia";
$m_factory_reset	="Ripristina impostazioni di default";
$m_b_restore		="Ripristina";
$m_clear_lang_pack ="Cancella language pack"; 
$m_clear ="Cancella";
$a_sure_to_clear_lang ="Cancella il language pack ?";
$a_sure_to_factory_reset="Ripristina impostazioni di default ?";
$a_sure_to_reboot	="Riavviare il punto di accesso ?";

?>
