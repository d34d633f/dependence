Aggiornamento del firmware in corso...<br><br>
NON SPEGNER<font color=red><b></b></font> il dispositivo.<br><br>
Attendere
<input type='text' readonly name='WaitInfo' value='150' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
secondi...
