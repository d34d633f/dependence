<?
$m_context_title	="&nbsp";
$m_context		="Solo l'account <b>admin</b> può modificare le impostazioni.";
$m_button_dsc		=$m_continue;
?>
