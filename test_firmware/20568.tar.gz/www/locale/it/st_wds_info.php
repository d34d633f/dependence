<?
$m_context_title = "Informazioni WDS";
$m_client_info = "Informazioni WDS";
$m_st_association  = "Associazione stazioni con 11";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "Banda";
$m_auth = "Autenticazione";
$m_signal = "Segnale";
$m_power = "Modalità risparmio energetico";
$m_wpa		= "WPA-";
$m_wpa2		= "WPA2-";
$m_wpa_auto		= "WPA2 automatico-";
$m_eap		= "aziendale";
$m_psk		= "personale";
$m_open		="Sistema aperto";
$m_shared	="Chiave condivisa";
$m_disabled		="Disabilita";
$m_channel = "Canale";
$m_name = "Nome";
$m_status = "Stato";
$wds = "W";
$m_on = "Attivo";
$m_off = "Non attivo";
$m_none = "Nessuno";
?>
