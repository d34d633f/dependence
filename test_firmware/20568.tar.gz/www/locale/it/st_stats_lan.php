<?
$msg_title="Statistiche traffico Ethernet";
$msg_t_title="Totale trasmesso";
$msg_r_title="Totale ricevuto";
$msg_T_Packet="Totale pacchetti trasmessi";
$msg_T_Bytes=" Totale byte trasmessi";
$msg_T_Dropped_Packet="Totale pacchetti cancellati";
$msg_R_Packet="Totale pacchetti ricevuti";
$msg_R_Bytes="Totale byte ricevuti";
$msg_R_Dropped_Packet="Totale pacchetti cancellati";
$msg_R_Multicast_Packet="Totale pacchetti multicast ricevuti";
$msg_R_Broadcast_Packet="Totale pacchetti broadcast ricevuti";
$msg_Len_64="Totale pacchetti con lunghezza 64";
$msg_Len_65_127="Totale pacchetti con lunghezza compresa tra 65~127";
$msg_Len_128_255="Totale pacchetti con lunghezza compresa tra 128~255";
$msg_Len_256_511="Totale pacchetti con lunghezza compresa tra 256~511";
$msg_Len_512_1023="Totale pacchetti con lunghezza compresa tra 512~1023";
$msg_Len_1024_1518="Totale pacchetti con lunghezza compresa tra 1024~1518";
$msg_Len_1519_MAX="Totale pacchetti con lunghezza compresa tra 1519 e valore massimo";
$msg_clear="Cancella";
$msg_refresh="Aggiorna";
?>
