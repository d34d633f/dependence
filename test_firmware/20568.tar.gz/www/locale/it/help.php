<?

$head_bsc = "Impostazioni di base";

$title_bsc_wlan ="Impostazioni wireless";
$bsc_wlan_msg ="Consente di modificare le impostazioni wireless per adattarle a una rete wireless esistente".
 " o per personalizzare la rete wireless.";
$bsc_wireless_band ="Banda wireless";
$bsc_wireless_band_msg ="Banda di frequenza operativa. Scegliere 2,4 GHz per garantire la visibilità dei dispositivi esistenti e per un intervallo maggiore. Scegliere 5 GHz per minori interferenze. Le interferenze possono influire negativamente sulle prestazioni. Il punto di accesso utilizzerà una banda alla volta.";
$bsc_mode = "Modalità";
$bsc_mode_msg = "Selezionare una modalità di funzionamento per configurare la rete wireless. Le modalità di funzionamento includono: Punto di accesso, WDS (Wireless Distribution System) con punto di accesso, WDS e Client wireless. Sono progettate in modo da supportare diverse applicazioni e topologie di rete wireless.";
$bsc_network_name = "Nome rete (SSID)";
$bsc_network_name_msg ="Noto anche come Service Set Identifier,indica il nome definito per una WLAN (Wireless Local Area Network) specifica. L'impostazione di default è \"dlink\", ma può essere facilmente modificato per connettersi a una rete wireless esistente o per definire una nuova rete wireless.";
$bsc_ssid_visibility = "Visibilità SSID";
$bsc_ssid_visibility_msg ="Indica se il SSID della rete wireless verrà o meno trasmesso. Il valore di default è Abilita e consente ai client wireless di rilevare la rete wireless. Se si modifica questo valore in Disabilita, i client wireless non potranno più rilevare la rete wireless e potranno connettersi solo immettendo il SSID corretto.";
$bsc_auto_channel="Selezione automatica canale";
$bsc_auto_channel_msg="Se si seleziona questa opzione, ogni volta che il punto di accesso viene avviato, individuerà automaticamente il canale più adatto. Per default, questa opzione è abilitata.";
$bsc_channel="Canale";
$bsc_channel_msg ="Indica l'impostazione del canale per ".query("/sys/hostname").". Per default, il punto di accesso è impostato su Selezione automatica canale. È possibile modificare l'impostazione del canale per adattarla a una rete wireless esistente oppure per personalizzare la rete wireless in uso.";
$bsc_channel_width="Ampiezza canale";
$bsc_channel_width_msg="Consente di selezionare l'ampiezza del canale entro cui operare. Selezionare 20 MHz se non si utilizzano client wireless 802.11n. Selezionare 20/40 MHz automatico se si desidera utilizzare sia dispositivi wireless 802.11n che non 802.11n nella rete.";
$bsc_authentication="Autenticazione";
$bsc_authentication_msg="Per una maggior protezione della rete wireless è possibile abilitare la crittografia dei dati. Sono disponibili diversi tipi di autenticazione che è possibile selezionare. Il valore di default di Autenticazione è impostato su \"Sistema aperto\".";
$bsc_open_sys="Sistema aperto";
$bsc_open_sys_msg="Se il tipo di autenticazione è Sistema aperto,nella rete wireless potranno comunicare solo i client wireless con la stessa chiave WEP. Il punto di accesso risulterà visibile a tutti i dispositivi della rete.";
$bsc_shared_key="Chiave condivisa";
$bsc_shared_key_msg="Se il tipo di autenticazione è Chiave condivisa, il punto di accesso sarà visibile nella rete wireless ai soli client wireless che condividono la stessa chiave WEP.";
$bsc_personal_type="WPA personale/WPA2 personale/WPA automatico personale";
$bsc_personal_type_msg="WPA (Wi-Fi Protected Access) consente di autorizzare e autenticare gli utenti nella rete wireless. Utilizza la crittografia TKIP per proteggere la rete tramite l'utilizzo di una chiave precondivisa. WPA e WPA2 utilizzano un algoritmo diverso. WPA automatico consente di utilizzare sia WPA che WPA2.";
$bsc_enterprise_type="WPA aziendale/WPA2 aziendale/WPA automatico aziendale";
$bsc_enterprise_type_msg="WPA (Wi-Fi Protected Access) consente di autorizzare e autenticare gli utenti nella rete wireless. Utilizza un livello di protezione più elevato rispetto a WEP e si basa su una chiave che cambia automaticamente a intervalli regolari. Richiede la presenza di un server RADIUS nella rete. WPA e WPA2 utilizzano un algoritmo diverso. WPA automatico consente di utilizzare sia WPA che WPA2.";
$bsc_network_access="Protezione accesso alla rete";
$bsc_network_access_msg="Protezione accesso alla rete è una funzionalità di Windows Server 2008 e controlla l'accesso alle risorse di rete sulla base dell'identità di un computer client e della conformità ai criteri di governance aziendali. Protezione accesso alla rete consente agli"." amministratori di rete di definire livelli granulari di accesso alla rete sulla base dell'identità di un client, dei gruppi cui appartiene e al grado di conformità del client ai criteri di governance aziendali. Se un client non è conforme, Protezione accesso alla rete offre un meccanismo per garantirne la conformità e incrementare dinamicamente il livello di accesso alla rete.";
$title_bsc_lan = "Impostazioni LAN";
$title_bsc_lan_msg ="Note anche come impostazioni private, le impostazioni LAN consentono di configurare l'interfaccia LAN 
di".query("/sys/hostname").".L'indirizzo IP della LAN è privato nell'ambito della rete interna, pertanto non è visibile in Internet. L'indirizzo IP di default è 192.168.0.50, mentre la subnet mask è 255.255.255.0.";
$bsc_get_ip_from = "Ottieni IP da";
$bsc_get_ip_from_msg = "L'impostazione di default è \"IP statico (manuale)\" e consente di configurare manualmente l'indirizzo IP di ".query("/sys/hostname")." in base ai requisiti della LAN utilizzata. Abilitare \"IP dinamico (DHCP)\" per consentire all'host DHCP di assegnare automaticamente al punto di accesso un indirizzo IP conforme alla LAN utilizzata.";
$bsc_ip_address = "Indirizzo IP";
$bsc_ip_address_msg = "L'indirizzo IP di default è 192.168.0.50. Può essere modificato in base ai requisiti di una LAN esistente. Si noti che l'indirizzo IP di ogni dispositivo della LAN wireless deve essere compreso nello stesso intervallo di indirizzi IP e subnet mask. Si consideri ad esempio l'indirizzo IP di default di ".query("/sys/hostname").". Ogni stazione associata al punto di accesso dovrà essere configurata con un indirizzo IP univoco compreso nell'intervallo 192.168.0.*. \"*\" è un numero compreso tra 0 e 255 ma in questo esempio è 50.";
$bsc_submask = "Subnet mask";
$bsc_submask_msg = "Mask utilizzata per stabilire la subnet a cui appartiene un indirizzo IP. L'impostazione di default è 255.255.255.0.";
$bsc_gateway = "Gateway di default";
$bsc_gateway_msg = "Specificare l'indirizzo IP del gateway della rete locale.";


$head_adv ="Impostazioni avanzate";

$title_adv_per = "Prestazioni";
$title_adv_per_msg = "È possibile personalizzare la radio della rete per adattarla alle proprie esigenze regolando i parametri della radio nella sezione delle prestazioni. Le funzioni di questa sezione sono destinate a utenti esperti che conoscono le reti wireless 802.11 e la configurazione della radio.";
$adv_wireless = "Wireless";
$adv_wireless_msg ="Questa opzione consente all'utente di abilitare o disabilitare la funzione wireless.";
$adv_wireless_mode ="Modalità wireless";
$adv_wireless_mode_msg ="Questa funzione consente di selezionare combinazioni diverse di client supportati. Si noti che quando si abilita la compatibilità con le versioni precedenti per i client legacy (802.11a/g/b), è possibile prevedere un deterioramento delle prestazioni della connessione wireless 802.11n.";
$adv_date_rate="Velocità dati";
$adv_date_rate_msg="Indica la velocità di trasferimento di base delle schede wireless nella WLAN (Wireless Local Area Network). Il punto di accesso regolerà tale velocità in base alla velocità di base del dispositivo collegato. In presenza di ostacoli o interferenze, la velocità dati verrà ridotta.";
$adv_beacon = "Intervallo beacon (25-500)";
$adv_beacon_msg = "I beacon sono pacchetti inviati da un punto di accesso per sincronizzare una rete wireless. L'impostazione di un valore più elevato per l'intervallo beacon consente di ridurre il consumo energetico di un client wireless, mentre un valore più basso consente a un client wireless di connettersi più rapidamente a un punto di accesso. L'impostazione consigliata per la maggior parte degli utenti è pari a 100 millisecondi.";
$adv_dtim="Intervallo DTIM (1-15)";
$adv_dtim_msg="L'intervallo DTIM consente di specificare il numero di beacon del punto di accesso tra ciascun DTIM (Delivery Traffic Indication Message). Informa i client della finestra successiva per l'ascolto di messaggi broadcast e multicast. È possibile specificare per l'intervallo DTIM un valore "."compreso tra 1 e 15. Il punto di accesso invierà alle stazioni il DTIM successivo con il valore specificato in presenza di messaggi broadcast o multicast memorizzati nel buffer. Le stazioni ascoltano i beacon e si preparano in modo da ricevere i messaggi broadcast o multicast. Il valore di default per Intervallo DTIM è 1.";
$adv_transmit_power="Potenza di trasmissione";
$adv_transmit_power_msg="Questa impostazione determina il livello di potenza della trasmissione wireless. È possibile regolare la potenza di trasmissione in modo da eliminare le sovrapposizioni nella copertura dell'area wireless tra due punti di accesso quando si desidera evitare interferenze. Le opzioni sono 100% (default), 50% (-3 dB), 25% (-6 dB) o 12,5% (-9 dB). Ad esempio, se la copertura wireless è destinata alla metà dell'area, selezionare \"50%\".";
$adv_wmm="WMM (Multimedia Wi-Fi)";
$adv_wmm_msg="Questa funzione consente di migliorare l'esperienza utente con le applicazioni audio, video e voce in una rete Wi-Fi. WMM è basato su un sottoinsieme dello standard QoS per WLAN IEEE 802.11e. Abilitare questa funzione per migliorare l'esperienza utente con le applicazioni audio e video in una rete Wi-Fi.";
$adv_ack_timeout="Timeout Ack";
if(query("/runtime/web/display/ack_timeout_range")=="0")
{
$adv_ack_timeout_msg="È possibile specificare per Timeout Ack un valore compreso tra 48 e 200 per la banda 2,4 GHz e tra 25 e 200 nella banda 5 GHz per ottimizzare efficacemente la velocità di trasmissione nel caso di collegamenti a lunga distanza. L'unità è espressa in microsecondi (ms). Il valore di default è impostato su 25 ms per la banda 2,4 GHz e su 48 ms per la banda 5 GHz.";
}
else
{
$adv_ack_timeout_msg="È possibile specificare per Timeout Ack un valore compreso tra 64 e 200 per la banda 2,4 GHz e tra 50 e 200 nella banda 5 GHz per ottimizzare efficacemente la velocità di trasmissione nel caso di collegamenti a lunga distanza. L'unità è espressa in microsecondi (ms). Il valore di default è impostato su 64 ms per la banda 2,4 GHz e su 50 ms per la banda 5 GHz.";
}
$adv_short_gi="GI breve";
$adv_short_gi_msg="Per aumentare la velocità, è possibile utilizzare un intervallo di guardia breve (400 ns). Tale valore può tuttavia incrementare il tasso di errore in alcune installazioni a causa della maggior sensibilità alle riflessioni del segnale a radiofrequenza. Selezionare l'opzione più appropriata per la propria installazione.";
$adv_igmp="Snooping IGMP";
$adv_igmp_msg="Lo snooping IGMP (Internet Group Management Protocol) consente al punto di accesso di riconoscere le query e i report IGMP inviati tra i router e un host IGMP (STA wireless). Quando lo snooping IGMP è abilitato, il punto di accesso inoltrerà i pacchetti multicast all'host IGMP sulla base dei messaggi IGMP tramite il punto di accesso.";
$adv_link_integrality="Integrità collegamenti";
$adv_link_integrality_msg="Se la connessione Ethernet tra la LAN e il punto di accesso viene interrotta, questa opzione consente di rimuovere automaticamente l'associazione tra il client wireless e il punto di accesso.";
$adv_connection_limit="Limite connessioni";

if(query("/runtime/web/display/utilization") !="0")
{
        $utilization_string="o l'utilizzo della rete di questo punto di accesso supera la percentuale specificata,";
}
else
{
$utilization_string=" ";
}

$adv_connection_limit_msg="Questa opzione viene utilizzata per il bilanciamento del carico. Consente di condividere il traffico della rete wireless e i client utilizzando più ".query("/sys/hostname").". Se questa funzione è abilitata, quando il numero di utenti supera il limite impostato ".$utilization_string." il punto di accesso non consentirà l'associazione tra i client e il punto di accesso.";
$adv_user_limit ="Limite utenti (0-64)";
$adv_user_limit_msg ="Consente di impostare il numero massimo di utenti consentiti per punto di accesso. \"10\" è il valore consigliato per un utente normale.";
$adv_network_utilization="Utilizzo rete";
$adv_network_utilization_msg="Consente di impostare l'utilizzo massimo del punto di accesso per il servizio. ".query("/sys/hostname")." non consentirà l'associazione di nuovi client con il punto di accesso se l'utilizzo supera il valore specificato dall'utente. Il valore consigliato è 100%.";
$title_adv_mssid="SSID multipli";
$title_adv_mssid_msg="Gli SSID multipli sono supportati solo nella modalità Punto di accesso. È possibile configurare un SSID primario e al massimo sette SSID guest per consentire stazioni di segregazione virtuali che condividono lo stesso canale.";
$adv_mssid_msg1="È inoltre possibile abilitare lo stato VLAN per consentire a ".query("/sys/hostname")." di operare con switch o altri dispositivi supportati da VLAN.";
$adv_mssid_msg2="Quando il SSID primario è impostato su Sistema aperto senza crittografia, i SSID guest possono essere impostati solo su nessuna crittografia, WEP, WPA personale o WPA2 personale.";
$adv_mssid_msg3="Quando la protezione del SSID primario è impostata su Sistema aperto o Chiave condivisa, i SSID guest possono essere impostati in modo da non utilizzare alcuna crittografia oppure utilizzare altre tre chiavi WEP, WPA personale o WPA2 personale.";
$adv_mssid_msg4="Quando la protezione del SSID primario è impostata su WPA personale, WPA2 personale o WPA automatico personale, vengono utilizzati gli slot 2 e 3. È possibile impostare i SSID guest in modo da non utilizzare alcuna crittografia oppure utilizzare WEP o WPA personale.";
$adv_mssid_msg5="Quando la protezione del SSID primario è impostata su WPA aziendale, WPA2 aziendale o WPA automatico aziendale, è possibile impostare i SSID guest in modo da utilizzare qualsiasi tipo di protezione.";
$title_adv_vlan="VLAN";
$title_adv_vlan_msg= "".query("/sys/hostname")." supporta l'utilizzo di VLAN. È possibile creare VLAN specificando un nome e un VID. È possibile assegnare a VLAN connessioni Gestione (stack TCP), LAN, SSID primario/SSID multipli e WDS poiché si tratta di porte fisiche. Per ogni pacchetto in ingresso tramite ".query("/sys/hostname")." e che non presenta un tag VLAN, verrà inserito un tag VLAN con un PVID.";
$title_adv_intrusion="Protezione da intrusioni wireless";
$title_adv_intrusion_msg="".query("/sys/hostname")." consente agli utenti di configurare la protezione da intrusioni wireless.";

$title_adv_scheduling="Pianificazione";
$title_adv_scheduling_msg="Pianificare la radio di ".query("/sys/hostname")." in base alla settimana o a singoli giorni.";

$title_adv_qos="QoS";
$title_adv_qos_msg="QoS è l'acronimo di Quality of Service, ovvero qualità del servizio per la gestione intelligente di flussi wireless, una tecnologia sviluppata per ottimizzare l'esperienza di utilizzo di una rete wireless mediante l'assegnazione di priorità al traffico delle diverse applicazioni.";
$adv_enable_qoS="Abilita QoS";
$adv_enable_qoS_msg="Abilitare questa opzione se si desidera consentire a QoS di assegnare priorità al traffico.";
$adv_enable_qoS_msg1="Classificatori di priorità.";
$adv_http="HTTP";
$adv_http_msg="Consente al punto di accesso di riconoscere i trasferimenti HTTP per numerosi flussi audio e video comuni e di assegnare loro una priorità maggiore rispetto ad altro traffico. Tali flussi vengono utilizzati di frequente da lettori multimediali digitali.";
$adv_automatic="Automatico";
$adv_automatic_msg="Quando questa opzione è abilitata, il punto di accesso tenta automaticamente di dare priorità ai flussi di traffico che non riconosce in altro modo, sulla base del comportamento di tali flussi. In questo modo viene assegnata una priorità inferiore ai flussi che presentano caratteristiche di trasferimento in massa, ad esempio i trasferimenti di file, lasciando che il traffico interattivo, quale quello delle applicazioni di gioco o VoIP, venga eseguito con priorità normale.";
$adv_qos_rule="Regole QoS";
$adv_qos_rule_msg="Una regola QoS consente di identificare un flusso di messaggi specifici e di assegnare una priorità a tale flusso. Per la maggior parte delle applicazioni i classificatori di priorità sono sufficienti a garantire le priorità corrette, pertanto non sono richieste regole QoS specifiche.";
$adv_qos_rule_msg1="QoS supporta l'utilizzo di regole sovrapposte. Se un flusso di messaggi specifico corrisponde a più regole, verrà utilizzata quella con la priorità maggiore.";
$adv_name="Nome";
$adv_name_msg="Creare un nome evocativo per la regola.";
$adv_priority="Priorità";
$adv_priority_msg="Campo in cui specificare la priorità del flusso dei messaggi. Vengono definite quattro priorità:";
$adv_priority_msg1="* BK: Background (meno urgente).";
$adv_priority_msg2="* BE: Best Effort.";
$adv_priority_msg3="* VI: Video.";
$adv_priority_msg4="* VO: Voce (più urgente).";
$adv_protocol="Protocollo";
$adv_protocol_msg="Protocollo utilizzato dai messaggi.";
$adv_host_1_ip="Intervallo IP host 1";
$adv_host_1_ip_msg="La regola si applica al flusso di messaggi per i quali l'indirizzo IP di un computer è compreso nell'intervallo impostato in questo campo.";
$adv_host_1_port="Intervallo porte host 1";
$adv_host_1_port_msg="La regola si applica al flusso di messaggi per i quali il numero di porta dell'host 1 è compreso nell'intervallo impostato in questo campo.";
$adv_host_2_ip="Intervallo IP host 2";
$adv_host_2_ip_msg="La regola si applica al flusso di messaggi per i quali l'indirizzo IP dell'altro computer è compreso nell'intervallo impostato in questo campo.";
$adv_host_2_port="Intervallo porte host 2";
$adv_host_2_port_msg="La regola si applica al flusso di messaggi per i quali il numero di porta dell'host 2 è compreso nell'intervallo impostato in questo campo.";
    

$head_dhcp="Server DHCP";
$head_dhcp_msg="Il server DHCP (Dynamic Host Control Protocol) consente di assegnare indirizzi IP alle stazioni che li richiedono durante l'accesso alla rete wireless. Per poter ottenere automaticamente gli indirizzi IP, è necessario configurare le stazioni come client DHCP. Il valore di default per il controllo Server DHCP è \"Disabilitato\".";
$title_dhcp_dynamic_pool="Impostazioni pool dinamico";
$title_dhcp_dynamic_pool_msg="Il pool di indirizzi DHCP consente di definire l'intervallo degli indirizzi IP che è possibile assegnare alle stazioni in rete. In un pool dinamico le stazioni wireless riceveranno un IP disponibile con il controllo del tempo di validità.";
$dhcp_ip_assigned="IP assegnato da";
$dhcp_ip_assigned_msg="L'utente può specificare l'inizio del pool di indirizzi IP disponibili per le stazioni wireless.";
$dhcp_range_of_pool="Intervallo pool (1-254)";
$dhcp_range_of_pool_msg="Gli utenti possono specificare l'intervallo di indirizzi IP disponibili. Tali indirizzi corrispondono agli incrementi dell'indirizzo IP specificato nel campo \"IP assegnato da\".";
$dhcp_submask="Subnet mask";
$dhcp_submask_msg="Consente di definire la subnet mask dell'indirizzo IP specificato nel campo \"IP assegnato da\".";
$dhcp_gateway="Gateway";
$dhcp_gateway_msg="Specifica l'indirizzo del gateway della rete wireless.";
$dhcp_wins="WINS";
$dhcp_wins_msg="Specifica l'indirizzo WINS della rete wireless.";
$dhcp_dns="DNS";
$dhcp_dns_msg="Specifica l'indirizzo DNS della rete wireless.";
$dhcp_domain="Nome dominio";
$dhcp_domain_msg="Specifica l'indirizzo del nome di dominio della rete wireless.";
$dhcp_lease_time="Tempo di validità";
$dhcp_lease_time_msg="Gli utenti possono definire la durata delle associazioni delle stazioni specificando il tempo di validità degli indirizzi IP.";

$title_dhcp_static_pool="Impostazioni pool statico";
$title_dhcp_static_pool_msg="Il pool di indirizzi DHCP consente di definire l'intervallo degli indirizzi IP che è possibile assegnare alle stazioni in rete. In un pool statico le stazioni wireless riceveranno un IP disponibile senza alcun controllo del tempo di validità.";
$dhcp_assigned_ip="IP assegnato";
$dhcp_assigned_ip_msg="Specifica l'indirizzo IP da assegnare a una stazione il cui indirizzo MAC è specificato nel campo \"Indirizzo MAC assegnato\".";
$dhcp_assigned_mac="Indirizzo MAC assegnato";
$dhcp_assigned_mac_msg="Specifica l'indirizzo MAC della stazione che richiede l'associazione.";

$title_dhcp_current_ip="Mapping IP corrente";
$title_dhcp_current_ip_msg="Un elenco include gli indirizzi MAC, gli indirizzi IP e i tempi di validità delle stazioni wireless associate a ".query("/sys/hostname")." tramite un server DHCP che utilizza pool dinamici o pool statici.";
$head_filters="Filtri";
$head_filters_msg="La funzione di filtro include il filtro degli indirizzi MAC e una partizione LAN wireless. Il filtro degli indirizzi MAC consente di bloccare o accettare l'associazione mediante l'identificazione di indirizzi MAC specificati. La partizione LAN wireless consente di accettare o rifiutare l'accesso da reti wireless o cablate.";
$title_filters_wireless_access="Impostazioni accesso wireless";
$filters_wireless_band="Banda wireless";
$filters_wireless_band_msg="Banda di frequenza operativa. Scegliere 2,4 GHz per garantire la visibilità dei dispositivi esistenti e per un intervallo maggiore. Scegliere 5 GHz per una minor interferenza. Per questa parte verrà utilizzata l'impostazione wireless di base.";
$title_filters_wlan_partition="Partizione WLAN";
$filters_internal_station="Connessione a stazione interna";
$filters_internal_station_msg="Il valore di default è \"Abilita\", che consente alle stazioni di comunicare tra loro connettendosi a un punto di accesso di destinazione. Se questa opzione è disabilitata, le stazioni wireless non possono scambiarsi dati tramite il punto di accesso.";
$filters_eth_to_wlan="Accesso Ethernet a WLAN";
$filters_eth_to_wlan_msg="Il valore predefinito è \"Abilita\", che consente di trasmettere il flusso dei dati da Ethernet alle stazioni wireless connesse al punto di accesso. Se si disabilita questa funzione, la trasmissione dei dati da Ethernet ai dispositivi wireless associati viene bloccata mentre le stazioni wireless sono ancora in grado di inviare dati a Ethernet tramite il punto di accesso.";
$head_st="Impostazioni stato";

$title_st_dev_info="Informazioni dispositivo";
$title_st_dev_info_msg="In questa pagina vengono visualizzate informazioni quali la versione del firmware, i parametri Ethernet e wireless, nonché informazioni sulla CPU e l'utilizzo della memoria.";
$title_st_cli_info="Informazioni client";
$title_st_cli_info_msg="In questa pagina vengono visualizzati client associati, SSID, MAC, banda, metodo di autenticazione, intensità del segnale e modalità di risparmio energetico per la rete ".query("/sys/hostname").".";

$title_st_wds_info="Informazioni WDS";
$title_st_wds_info_msg="In questa pagina vengono visualizzati punti di accesso, SSID, MAC, banda, metodo di autenticazione, intensità del segnale e modalità di risparmio energetico per la rete WDS di ".query("/sys/hostname").".";


$head_statistics="Statistiche";

$title_st_ethernet="Statistiche traffico Ethernet";
$title_st_ethernet_msg="Visualizza informazioni sul traffico di rete dell'interfaccia cablata.";

$title_st_wlan="Statistiche traffico 802.11G WLAN";
$title_st_wlan_msg="Visualizza la velocità di trasmissione, il numero di frame trasmessi, il numero di frame ricevuti e gli errori di frame WEP relativi alla rete del punto di accesso.";

$head_log="Log";
$head_log_msg="Registra gli eventi del log in un server dei log di sistema remoto e visualizza la pagina Web relativa.";

$title_log_view="Visualizza log";
$title_log_view_msg="Consente di visualizzare i log relativi alla memoria incorporata del punto di accesso. Le informazioni dei log includono tra l'altro i seguenti eventi: mancato avvio del punto di accesso, aggiornamento del firmware, associazione/rimozione dell'associazione del client con il punto di accesso, accesso tramite Web. La pagina Web può contenere fino a 500 log.";

$title_log_set="Impostazioni log";
$title_log_set_msg="Immettere l'indirizzo IP del server dei log a cui inviare il log. Selezionare o deselezionare Attività di sistema, Attività wireless o Nota per specificare il tipo di log da creare.";

$head_mt="Manutenzione";

$title_mt_admin="Impostazioni amministratore";
$mt_limit_admin_vid="Limita VID amministratore";
$mt_limit_admin_vid_msg="I pacchetti con tag VLAN che hanno lo stesso VID consentiranno all'amministratore di effettuare l'accesso.";
$mt_limit_admin_ip="Limita intervallo IP amministratore";
$mt_limit_admin_ip_msg="Immettere un pool di indirizzi IP da cui l'amministratore può eseguire l'accesso.";
$title_mt_sysname="Impostazioni nome sistema";
$mt_sysname="Nome sistema";
$mt_sysname_msg="Nome assegnato a ".query("/sys/hostname")." dall'amministratore.";
$mt_location="Percorso";
$mt_location_msg="Percorso fisico di ".query("/sys/hostname").".";
$title_mt_login="Impostazioni accesso";
$mt_username="Nome utente";
$mt_username_msg="È possibile personalizzare il nome utente come amministratore di ".query("/sys/hostname").". Il nome utente di default è \"admin\" senza alcuna password configurata.";
$mt_oldpass="Vecchia password";
$mt_oldpass_msg="Immettere la vecchia password.";
$mt_newpass="Nuova password";
$mt_newpass_msg="Immettere una password in questo campo. Per la password viene fatta distinzione tra maiuscole e minuscole, pertanto \"A\" è diverso da \"a\". La lunghezza deve essere compresa tra 0 e 12 caratteri.";
$mt_conpass="Conferma nuova password";
$mt_conpass_msg="Digitare nuovamente la password per confermarla.";
$title_mt_console="Impostazioni console";
$mt_status="Stato";
$mt_status_msg="Consente di abilitare o disabilitare la console.";
$mt_console_protocol="Protocollo console";
$mt_console_protocol_msg="Scegliere tra Telnet e SSH.";
$mt_timeout="Timeout";
$mt_timeout_msg="Selezionare il periodo di timeout.";
$title_mt_snmp="Impostazioni SNMP";
$mt_st_snmp="Stato";
$mt_st_snmp_msg="Consente di abilitare o disabilitare SNMP.";
$mt_public_comm="Stringa comunità pubblica";
$mt_public_comm_msg="Immettere la stringa di comunità pubblica per SNMP.";
$mt_private_comm="Stringa comunità privata";
$mt_private_comm_msg="Immettere la stringa di comunità privata per SNMP.";
$mt_trap="Stato trap";
$mt_trap_msg="Consente di abilitare o disabilitare Trap.";
$mt_trap_serv="IP server Trap";
$mt_trap_serv_msg="Indirizzo IP del gestore SNMP per la ricezione dei trap inviati dal punto di accesso wireless.";
$title_mt_pingctrl="Impostazione controllo ping";
$mt_ping_st="Stato";
$mt_ping_st_msg="Il ping invia i pacchetti di \"richiesta echo\" ICMP all'host di destinazione e rimane in ascolto delle risposte echo ICMP. Se si disabilita l'impostazione di controllo Ping, il punto di accesso non risponderà ai pacchetti di richiesta echo ICMP. Per default, questa impostazione è abilitata.";
$title_mt_fw="Firmware e SSL";
$title_mt_fw_msg="Caricamento certificati SSL e firmware";
$title_mt_fw_msg1="È possibile caricare file nel punto di accesso.";
$mt_upload_fw="Carica firmware da disco fisso locale";
$mt_upload_fw_msg="La versione corrente del firmware viene visualizzata sopra il campo relativo al percorso del file. Dopo il caricamento del firmware più recente, fare clic sul pulsante \"Sfoglia\" per individuare il nuovo firmware. Dopo aver selezionato il file, fare clic su \"Apri\" e \"OK\" per avviare l'aggiornamento del firmware. Non spegnere il sistema durante l'aggiornamento.";
$mt_upload_ssl="Carica certificati SSL da disco fisso locale";
$mt_upload_ssl_msg="Dopo aver scaricato un certificato SSL nell'unità locale, fare clic su \"Sfoglia\". Selezionare il certificato e fare clic su \"Apri\" e \"Carica\" per completare l'aggiornamento.";
$_title_mt_config="File di configurazione";
$mt_config="Caricamento e download file di configurazione";
$mt_config_msg="È possibile caricare e scaricare i file di configurazione del punto di accesso.";
$mt_upload_config="Carica file di configurazione";
$mt_upload_config_msg="Individuare e selezionare il file di configurazione salvato nell'unità locale e fare clic su \"Apri\" e \"Carica\" per aggiornare la configurazione.";
$mt_download_config="Scarica file di configurazione";
$mt_download_config_msg="Fare clic su \"Download\" per salvare il file di configurazione corrente nel disco locale. Si noti che se si salva un file di configurazione con la password dell'amministratore, dopo il ripristino di ".query("/sys/hostname")." e l'aggiornamento con il file di configurazione salvato, la password andrà persa.";
$title_mt_time="Data e ora";
$title_mt_time_msg="Immettere l'IP del server NTP, selezionare il fuso orario e abilitare o disabilitare l'ora legale.";


$head_sys = "Sistema";
$title_sys = "Impostazioni sistema";
$sys_apply_restart = "Applica impostazioni e riavvia";
$sys_apply_restart_msg = "Fare clic su Riavvia per applicare le impostazioni e riavviare il sistema.";
$sys_apply_restore = "Ripristina impostazioni di default";
$sys_apply_restore_msg = "Fare clic su Ripristina per ripristinare le impostazioni di default.";
?>
