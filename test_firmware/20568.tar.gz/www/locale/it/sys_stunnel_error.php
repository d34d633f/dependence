<?
$m_html_title="Carica";
$m_context_title="Carica";
$m_context="Errore di sistema. <br>Riprovare.";
$m_button_dsc="Indietro";
?>
