<?
$m_context_title = "Impostazioni prestazioni";
$m_wl_enable = "Wireless";
$m_disable = "Disabilita";
$m_enable  = "Abilita";
$m_off = "Non attivo";
$m_on  = "Attivo";
$m_wlmode = "Modalità wireless";
$m_wlmode_n_g_b = "Combinazione di 802.11n, 802.11g e 802.11b";
$m_wlmode_n_g = "Combinazione di 802.11n e 802.11g";
$m_wlmode_g_b = "Combinazione di 802.11g e 802.11b";
$m_wlmode_n = "Solo 802.11n";
$m_wlmode_n_a = "Combinazione di 802.11n e 802.11a";
$m_wlmode_a = "Solo 802.11a";
$m_rate = "Velocità dati";
$m_best	= "Massima (fino a 300)";
$m_best_54	= "Massima (fino a 54)";
$m_54	= "54";
$m_48	= "48";
$m_36	= "36";
$m_24	= "24";
$m_18	= "18";
$m_12	= "12";
$m_9	= "9";
$m_6	= "6";
$m_11	= "11";
$m_5.5	= "5.5";
$m_2	= "2";
$m_1	= "1";
$m_beacon_interval	="Intervallo beacon (25-500)";
$m_rts			="Soglia RTS (256-2346)";
$m_frag			="Frammentazione (256-2346)";
$m_dtim			="Intervallo DTIM (1-15)";
$m_power = "Potenza di trasmissione";
$m_ms = "(&micro;s)";

$m_wmm = "WMM (Multimedia Wi-Fi)";
$m_shortgi = "GI breve";
$m_limit_state = "Limite connessioni";
$m_limit_num = "Limite utenti (0 - 64)";
$m_utilization = "Utilizzo rete";
$m_0 = "0";
$m_10 = "10";
$m_20 = "20";
$m_30 = "30";
$m_40 = "40";
$m_50 = "50";
$m_60 = "60";
$m_70 = "70";
$m_80 = "80";
$m_90 = "90";
$m_100 = "100";
$m_180 = "180";
$m_25 = "25";
$m_12.5 = "12.5";
$m_igmp = "Snooping IGMP";
$m_link_integrality="Integrità collegamenti";
$m_ack_timeout="Timeout Ack";
$m_mbps = "(Mbps)";
if(query("/runtime/web/display/ack_timeout_range")=="0")
{
$m_ack_timeout_g_msg = " (2.4GHz, 48~200)";
$m_ack_timeout_a_msg = " (5GHz, 50~200)";
	$a_invalid_ack_timeoutg ="Il valore di Timeout Ack deve essere compreso tra 48 e 200.";
	$a_invalid_ack_timeouta ="Il valore di Timeout Ack deve essere compreso tra 50 e 200.";
}
else
{
	$m_ack_timeout_g_msg = " (2.4GHz, 64~200)";
	$m_ack_timeout_a_msg = " (5GHz, 25~200)";
	$a_invalid_ack_timeoutg ="Il valore di Timeout Ack deve essere compreso tra 64 e 200.";
	$a_invalid_ack_timeouta ="Il valore di Timeout Ack deve essere compreso tra 25 e 200.";
}
$a_invalid_bi		="Il valore di Intervallo beacon deve essere compreso tra 25 e 500.";
$a_invalid_rts		="Il valore di Soglia RTS deve essere compreso tra 256 e 2346.";
$a_invalid_frag		="Il valore di Frammentazione deve essere compreso tra 256 e 2346.";
$a_invalid_dtim		="Il valore di Intervallo DTIM deve essere compreso tra 1 e 15.";
$a_invalid_limit_num	="Il valore 'Limite utenti' deve essere compreso nell'intervallo 0 - 64.";

?>
