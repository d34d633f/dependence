<?
$m_html_title="Immagine firmware errata";
$m_context_title="Immagine firmware errata";
$m_context="Il file scelto non è un file di immagine.";
$m_button_dsc=$m_continue;
?>
