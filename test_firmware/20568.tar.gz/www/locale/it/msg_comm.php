<?
$m_user_name		="Nome utente";
$m_password		="Password";
$m_continue		="Continua";
$m_nochg_title		="Nessuna modifica";
$m_nochg_dsc		="Le impostazioni non sono state modificate.";
$m_saving_title		="Salvataggio in corso";
$m_saving_dsc		="Le impostazioni verranno salvate e diverranno effettive.";
$m_saving_dsc_wait = "Attendere…";
$m_saving_dsc_change_ip = "Attendere 10 secondi, quindi accedere al dispositivo con il nuovo indirizzo IP.";
$m_scan_title		="Scansione";
$m_detect_title	="Rileva";
$m_scan_dsc		="Scansione in corso ... <br><br> Attendere…";
$m_clear = "Cancella";

$TITLE=query("/sys/hostname");
$first_frame = "home_sys";
$m_logo_title	=query("/sys/hostname");
?>
