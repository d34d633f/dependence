<?
$m_context_title = "Impostazioni switch WLAN";
$m_wtp_title = "Impostazioni punto terminale wireless";
$m_connect_title = "Info connessione";
$m_wtp_enable = "Abilitazione WTP";
$m_wtp_name = "Nome WTP";
$m_wtp_location = "Dati posizione WTP";
$m_ac_ip = "IP switch WLAN";
$m_ac_name = "Nome switch WLAN";
$m_ac_ipaddr = "Indirizzo IP switch WLAN";
$m_ac_ip_list_title = "Elenco indirizzi switch WLAN";
$m_id = "ID";
$m_ip = "Indirizzo IP";
$m_del = "Elimina";

$a_wtp_del_confirm		= "Eliminare questo indirizzo IP?";
$a_same_wtp_ip	= "Esiste già una voce con lo stesso Indirizzo IP. \\n  Modificare l'indirizzo IP.";
$a_invalid_ip		= "Indirizzo IP non valido.";
$a_max_ip_table		= "Il numero massimo di elenchi di indirizzi switch WLAN IP è 8.";
?>
