<?
$m_context_title = "Informazioni client";
$m_client_info = "Informazioni client";
$m_st_association  = "Associazione stazioni";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "Banda";
$m_auth = "Autenticazione";
$m_signal = "Segnale";
$m_power = "Modalità risparmio energetico";
$m_multi_ssid = "SSID MULTIPLI ";
$m_primary_ssid = "SSID primario";
$m_on = "Attivo";
$m_off = "Non attivo";
?>
