<?
$m_context_title = "Impostazioni LAN";

$m_lan_type  = "Ottieni IP da";
$m_static_ip = "IP statico (manuale)";
$m_dhcp      = "IP dinamico (DHCP)";

$m_ipaddr    = "Indirizzo IP";
$m_subnet    = "Subnet mask";
$m_gateway   = "Gateway di default";

$a_invalid_ip= "Indirizzo IP non valido.";
$a_invalid_netmask= "Subnet mask non valida.";
$a_invalid_gateway= "Indirizzo del gateway non valido.";
$a_connect_new_ip = "Eseguire la connessione con il nuovo indirizzo IP.";
?>
