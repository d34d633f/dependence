<?
$m_context_title = "Configurações do Sistema";
$m_reboot		=" Reiniciar o Dispositivo";
$m_b_reboot		=" Reiniciar";
$m_factory_reset	="Restaurar para as configurações padrões de fábrica";
$m_b_restore		="Restaurar";
$m_clear_lang_pack ="Pacote de linguagem limpo";
$m_clear ="Limpo";
$a_sure_to_clear_lang ="Limpar pacote de linguagem ?";
$a_sure_to_factory_reset="Deseja restaurar para as configurações padrões de fábrica?";
$a_sure_to_reboot	="Reiniciar o Access Point?";

?>
