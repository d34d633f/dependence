<?
$msg_title="Estatísticas de tráfego da Ethernet";
$msg_t_title="Contagem de Transmissão";
$msg_r_title="Contagem de Recebidos";
$msg_T_Packet="Contagem de Pacotes Transmitidos";
$msg_T_Bytes="Contagem de Bytes Transmitidos";
$msg_T_Dropped_Packet="Contagem de Pacotes Excluídos";
$msg_R_Packet="Contagem de Pacotes Recebidos";
$msg_R_Bytes="Contagem de Bytes Recebidos";
$msg_R_Dropped_Packet="Contagem de Pacotes excluídos";
$msg_R_Multicast_Packet="Contagem de Pacotes Multicast Recebidos";
$msg_R_Broadcast_Packet="Contagem de Pacotes Broadcast Recebidos";
$msg_Len_64="Contagem de pacotes de tamanho de 64";
$msg_Len_65_127="Contagem de Pacotes de tamanho 65~127";
$msg_Len_128_255="Contagem de Pacotes de tamanho 128~255";
$msg_Len_256_511="Contagem de Pacotes de tamanho 256~511";
$msg_Len_512_1023="Contagem de Pacotes de tamanho 512~1023";
$msg_Len_1024_1518="Contagem de Pacotes de tamanho 1024~1518";
$msg_Len_1519_MAX="Contagem de Pacotes de tamanho máximo de 1519";
$msg_clear="Limpar";
$msg_refresh="Atualizar";
?>
