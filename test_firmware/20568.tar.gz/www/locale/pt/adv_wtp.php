<?
$m_context_title = "Configurações de Switch WLAN";
$m_wtp_title = "Configuração de Ponto de Terminação Wireless";
$m_connect_title = "Conectando Info";
$m_wtp_enable = "Habilitar WTP";
$m_wtp_name = "Nome WTP";
$m_wtp_location = "Dados de Localização WTP";
$m_ac_ip = "IP do Switch WLAN";
$m_ac_name = "Nome do Switch WLAN";
$m_ac_ipaddr = "Endereço de IP do Switch WLAN";
$m_ac_ip_list_title = "Lista de endereços do Switch WLAN";
$m_id = "ID";
$m_ip = "Endereço de IP";
$m_del = "Deletar";

$a_wtp_del_confirm		= "Você tem certeza que deseja deletar o endereço de IP?";
$a_same_wtp_ip	= "Já existe uma entrada com o mesmo endereço de IP. \\n Por favor troque o endereço de IP";
$a_invalid_ip		= "Endereço de IP inválido!";
$a_max_ip_table		= "O número máximo de lista de endereços no Switch WLAN é 8!";
?>
