<?
$version_no=query("/runtime/sys/info/firmwareverreve");
$build_no=query("/runtime/sys/info/firmwarebuildno");

$m_context_title	="Versão";

$m_context = "Versão : ".$version_no."<br><br>Número de Construção : ".$build_no."<br><br>";
$m_context = $m_context."Uptime de sistema: <script>document.write(shortTime());</script>";

$m_days		= "Dias";
$m_button_dsc	=$m_continue;
?>
