<?

$msg_title="Estatísticas do tráfego da WLAN";
$msg_t_title="Contagem de Transmitidos";
$msg_t_msg1="Contagem de Pacotes Transmitidos";
$msg_t_msg2="Contagem de Bytes Transmitidos";
$msg_t_msg3="Contagem de Pacotes Excluídos";
$msg_t_msg4="Contagem de Retransmissão";
$msg_r_title="Contagem de Recebimento";
$msg_r_msg1="Contagem de Pacotes Recebidos";
$msg_r_msg2="Contagem de Bytes Recebidos";
$msg_r_msg3="Contagem de Pacotes excluídos";
$msg_r_msg4="Contagem de Recebimento de CRC";
$msg_r_msg5="Contagem de Descrição de Erros recebidos";
$msg_r_msg6="Contagem de Erros de MIC recebidos";
$msg_r_msg7="Contagem de Erros PHY recebidos";
$msg_clear="Limpar";
$msg_refresh="Atualizar";




?>
