<?
$m_context_title = "Proteção de Intrusão Wireless";
$m_b_detect = "Detectar";
$m_ap_list_title = "Lista de AP";
$m_type = "Tipo";
$m_band = "Banda";
$m_channel = "CH";
$m_ssid = "SSID";
$m_mac = "BSSID";
$m_last_seem = "Ultimo Visto";
$m_status = "Status";
$m_b_valid = "Definir como Válido";
$m_b_neighborhood = "Definir como Vizinho";
$m_b_rogue = "Definir como Rogue";
$m_b_new = "Definir como novo";
$m_all_valid = "Marcar todos os novos Access Point como válidos";
$m_all_rogue = "Marcar todos os novos Access Point como Rogue";
$m_valid = "Válido";
$m_neighborhood = "Vizinho";
$m_rogue = "Rogue";
$m_new = "Novo";
$m_a = "A";
$m_b = "B";
$m_g = "G";
$m_n = "N";
$m_days = "Dias";
$m_all = "Todos";
$m_up = "Acima";
$m_down = "Abaixo";

$a_max_list = "Número máximo desta lista é 64!\\n";
$a_can_add_num = "Você pode adicionar";
$a_entry = " entrada";
$a_no_click = "Não foi registrado o click!";
?>
