<?
// category
$m_menu_top_bsc		="Configurar";
$m_menu_top_adv		="Avançado";
$m_menu_top_tools	="MANUTENÇÃO";
$m_menu_top_st		="Status";
$m_menu_top_spt		="Suporte";

// basic
$m_menu_bsc_wizard      ="ASSISTENTE";
$m_menu_bsc_internet	="INTERNET";
$m_menu_bsc_wlan	="CONFIGURAÇÃO WIRELESS";
$m_menu_bsc_lan		="CONFIGURAÇÃO DA LAN";

// advanced
$m_menu_adv_vrtsrv	="SERVIDOR VIRTUAL";
$m_menu_adv_port	="REDIRECIONAMENTO DE PORTAS";
$m_menu_adv_app		="REGRAS DE APLICAÇÕES";
$m_menu_adv_mac_filter	="FILTRO DE REDE";
$m_menu_adv_acl		="FILTRO";
$m_menu_adv_url_filter	="FILTRO DE WEBSITE";
$m_menu_adv_dmz		="CONFIGURAÇÕES DE FIREWALL";
$m_menu_adv_wlan	="PERFORMANCE";
$m_menu_adv_network	="REDE AVANÇADA";
$m_menu_adv_dhcp	="SERVIDOR DHCP";
$m_menu_adv_mssid	="MULTI-SSID";
$m_menu_adv_group	="Limite de Usuários";
$m_menu_adv_wtp		="Switch WLAN";
$m_menu_adv_wlan_partition	="Partição WLAN";

// tools
$m_menu_tools_admin	="Administração do Dispositivo";
$m_menu_tools_time	="HORA";
$m_menu_tools_system	="SISTEMA";
$m_menu_tools_firmware	="FIRMWARE";
$m_menu_tools_misc	="MISC";
$m_menu_tools_ddns	="DDNS";
$m_menu_tools_vct	="CHECAGEM DO SISTEMA";
$m_menu_tools_sch	="AGENDAMENTOS";
$m_menu_tools_log_setting	="CONFIGURAÇÕES DE LOG";

// status
$m_menu_st_device	="INFORMAÇÃO DO DISPOSITIVO";
$m_menu_st_log		="LOG";
$m_menu_st_stats	="Estatísticas";
$m_menu_st_wlan		="INFORMAÇÃO DO CLIENTE";

// support
$m_menu_spt_menu	="MENU";

$m_logout	="Logout";

$m_menu_home	="Página&nbsp;&nbsp;Principal";
$m_menu_tool	="Manutenção";
$m_menu_config	="Configuração";
$m_menu_sys	="Sistema";
$m_menu_logout	="Logout";
$m_menu_help	="Ajuda";

$m_menu_tool_admin	="Configurações Administrativas";
$m_menu_tool_fw	="Upload de Firmware e certificação SSL";
$m_menu_tool_config	="Arquivo de configuração";
$m_menu_tool_sntp	="SNTP";

$m_menu_config_save	="Salvar e ativar.";
$m_menu_config_discard	="Descartar mudanças";

$a_config_discard ="Todas as suas modificações vão ser descartadas! Continuar?";

?>
