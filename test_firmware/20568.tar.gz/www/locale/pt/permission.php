<?
$m_context_title	="&nbsp";
$m_context		="Apenas a conta <strong>admin</strong> pode alterar as configurações.";
$m_button_dsc		=$m_continue;
?>
