<?
$m_user_name		="Nome de usuário";
$m_password		="Senha";
$m_continue		="Continuar";
$m_nochg_title		="Sem Modificações";
$m_nochg_dsc		="Configurações não foram alteradas.";
$m_saving_title		="Salvando";
$m_saving_dsc		="As configurações estão sendo salvas e sendo ativadas.";
$m_saving_dsc_wait = "Por favor aguarde...";
$m_saving_dsc_change_ip = "Por favor aguarde 10 segundos, e então acesse o dispositivo com o novo endereço IP";
$m_scan_title		="Escanear";
$m_detect_title	="Detectar";
$m_scan_dsc		="Escaneando... <br><br> Por favor aguarde...";
$m_clear = "Limpar";

$TITLE=query("/sys/hostname");
$first_frame = "home_sys";
$m_logo_title	=query("/sys/hostname");
?>
