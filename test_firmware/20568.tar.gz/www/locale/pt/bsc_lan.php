<?
$m_context_title = "Configurações de LAN";

$m_lan_type  = "Pegar IP do";
$m_static_ip = "IP estático (Manual)";
$m_dhcp      = "IP Dinâmico (DHCP)";

$m_ipaddr    = "Endereço de IP";
$m_subnet    = "Máscara de Sub-Rede";
$m_gateway   = "Gateway Padrão";

$a_invalid_ip= "Endereço de IP inválido";
$a_invalid_netmask= "Máscara de Sub-Rede inválida!";
$a_invalid_gateway= "Endereço de Gateway inválido!";
$a_connect_new_ip = "Por favor conecte com o novo endereço de IP!";
?>
