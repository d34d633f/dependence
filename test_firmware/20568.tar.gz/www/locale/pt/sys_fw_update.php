<?
$m_menu_upgrade_fw = "<font face=\"Arial\" color=\"red\" size=2>".
					 "<b>Não desligue</b></font>".
					 "<font face=\"Arial\" size=2>o seu dispositivo durante este processo.".
					 "Desliga-lo pode acarretar danos físicos ao seu ".query("/sys/hostname").
					 ". (Se o browser não redirecioná-lo a página web automaticamente,".
					 "por favor pressione o botão atualizar.)</font>";
					 
$m_upload_fw = "Carregando Firmware...";
$m_verify_fw = "Verificando a Firmware...";
$m_upgrad_device = "Atualizando o Dispositivo...";
$m_reboot_device = "Reiniciando o Dispositivo...";

$a_upgrade_fw_fail_msg = "A atualização da firmware falhou, por favor recarregue a firmware e tente novamente.";

?>
