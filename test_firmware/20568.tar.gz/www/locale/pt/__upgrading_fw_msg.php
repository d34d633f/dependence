A Firmware esta sendo atualizada...<br><br>
Por <font color=red><b>favor NÃO desligue</b></font> o dispositivo.<br><br>
E aguarde
<input type='text' readonly name='WaitInfo' value='150' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
segundos...
