<?

$head_bsc = "Configurações Básicas";

$title_bsc_wlan ="Configurações Wireless";
$bsc_wlan_msg ="Permite que a configuração wireless seja alterada para anexar uma rede sem fio já existente ou para customizar sua rede wireless.";
$bsc_wireless_band ="Banda Wireless";
$bsc_wireless_band_msg ="Banda de Freqüência de operação. Escolha 2.4GHz para visibilidade  para dispositivos e para maior alcance. Escolha 5GHZ para menos interferência; Interferência pode prejudicar a performance. O AP irá operar em apenas uma banda por vez.";
$bsc_mode = "Modo";
$bsc_mode_msg = "Selecione um modo de funcionamento para configurar sua rede wireless. Modos de funcionamento inclui AP, WDS(Wireless Distribution System) com AP, WDS e cliente Wireless. Modos de funcionamento são desenvolvidos para suportar várias topologias e aplicações.";
$bsc_network_name = "Nome da Rede (SSID)";
$bsc_network_name_msg = "Também conhecido como Service Set Identifier, este é o nome especifico designado a uma rede local Wireless (WLAN). A configuração padrão de fábrica vem configurada como \"dlink\". O SSID pode ser facilmente alterado para conectar a uma rede wireless já exis.";
$bsc_ssid_visibility = "Visibilidade do SSID";
$bsc_ssid_visibility_msg = "Indica se o SSID da sua rede wireless irá ou não ser transmitido. O valor de visibilidade do SSID é Habilitado por padrão, o que permite que clientes wireless detectem as redes wireless. Alterando a configuração para Desabilitado, clientes wireless não poderão detectar redes wireless e somente poderão conectar se entrarem com o SSID correto na configuração.";
$bsc_auto_channel="Seleção automática de Canal";
$bsc_auto_channel_msg="Se for acionada a opção de escaner automático de canal, todas as vezes que o AP estiver iniciando, ele irá automaticamente encontrar o melhor canal para utilizar. E é habilitado por padrão.";
$bsc_channel="Canal";
$bsc_channel_msg ="Indica a configuração de canal para o ".query("/sys/hostname").". Por padrão, o AP esta definido para escanear automaticamente os canais. O canal pode ser trocado para trabalhar em uma configuração onde já exista uma rede wireless, ou então para customizar a sua própria re.";
$bsc_channel_width="Largura do Canal";
$bsc_channel_width_msg="Permite que seja selecionado a largura do canal que se deseje trabalhar. Selecione 20MHz caso não esteja utilizando nenhum cliente wireless 802.11n. Auto 20/40Mhz permite que seja utilizados equipamentos 802.11n e equipamentos que não sejam 802.11n na red.";
$bsc_authentication="Autenticação";
$bsc_authentication_msg="Para adicionar segurança em uma rede wireless, a encriptação dos dados deve ser habilitada. Existem diversos tipos de autenticação disponíveis para ser selecionadas. O valor padrão para autenticação esta definido como Sistema Aberto.";
$bsc_open_sys="Sistema Aberto";
$bsc_open_sys_msg="Para autenticação de Sistema aberto, apenas clientes wireless com a mesma chave WEP estarão aptos a se comunicar com a rede wireless. O access point permanecerá visível para todos os dispositivos na rede.";
$bsc_shared_key="Chave Compartilhada";
$bsc_shared_key_msg="Para autenticação de Chave compartilhada, o access point não poderá ser visualizado na rede wireless, exceto aos clientes wireless que compartilham a mesma chave WEP.";
$bsc_personal_type="WPA-Personal/WPA2-Personal/WPA-Auto-Personal";
$bsc_personal_type_msg="O WPA (Wi-Fi Protected Access) autoriza e autentica usuários em uma rede wireless. Ele usa encriptação TKIP para proteger a rede através da utilização de uma Chave Compartilhada. WPA e WPA2 usam algoritmos diferentes. WPA-Auto permite que ambos (WPA e WPA2).";
$bsc_enterprise_type="WPA-Enterprise/WPA2-Empresa/WPA-Auto-Enterprise";
$bsc_enterprise_type_msg="O WPA (Wi-Fi Protected Access) autoriza e autentica usuários em uma rede wireless. Ele usa encriptação TKIP para proteger a rede através da utilização de uma Chave Compartilhada. WPA e WPA2 usam algoritmos diferentes. WPA-Auto permite que ambos (WPA e WPA).";
$bsc_network_access="Proteção de Acesso a Rede";
$bsc_network_access_msg="Proteção de acesso a rede (NAP) é uma característica do Windows Server 2008. O NAP controla o acesso a recursos de redes baseados em identidades de computadores clientes  e de conformidade com a política de governança corporativa. O NAP permite que o administrador defina níveis granulares de acesso a rede baseado em identificação de clientes, "."grupos de clientes que desejam trabalhar juntos, e o grau de politica que cada cliente faz parte. Se um cliente não fizer parte das politicas, o NAP possui um mecanismo para trazer o cliente automaticamente para as políticas de gerenciamento e então dinamicamente acrescentar um nível de acesso a rede.";
$title_bsc_lan = "Configurações de LAN";
$title_bsc_lan_msg = "Também conhecido como configurações privadas, as configurações de LAN permitem que seja configurado a interface LAN do ".query("/sys/hostname").". O endereço de IP da LAN é privado a sua rede interna e não é visível para a internet. O endereço de IP padrão é 192.168.0.50 c.";
$bsc_get_ip_from = "Obtendo IP";
$bsc_get_ip_from_msg = "O padrão de fábrica configurado é \"IP estático (Manual)\" que permite que os endereços de IP do ".query("/sys/hostname")." sejam configurados manualmente de acordo com a rede local aplicada. Habilite o \"Dynamic IP (DHCP)\" para permitir que o host DHCP seja automaticamente a.";
$bsc_ip_address = "Endereço de IP";
$bsc_ip_address_msg = "O endereço de IP padrão é 192.168.0.50. Ele pode ser modificado conforme a existência de uma rede local. Note que o endereço de IP de cada dispositivo em uma rede local wireless devem estar com a mesma faixa de endereço IP e máscara. Tome como exemplo o e.";
$bsc_submask = "Máscara de Sub-rede";
$bsc_submask_msg = "A máscara usada para determinar a qual sub-rede um endereço IP pertence. A máscara de sub-rede padrão configurada é 255.255.255.0.";
$bsc_gateway = "Gateway Padrão";
$bsc_gateway_msg = "Especifique o endereço de IP do Gateway da rede local.";


$head_adv ="Configurações avançadas";

$title_adv_per = "Performance";
$title_adv_per_msg = "É possível customizar a rede para atender as necessidades, configurando parâmetros de radio na seção de performance. Funções de Performance são desenvolvidas para usuários avançados que são familiares com redes wireless 802.11 e configurações de radio.";
$adv_wireless = "Wireless";
$adv_wireless_msg ="Esta opção permite que o usuário habilite ou desabilite a função de wireless.";
$adv_wireless_mode ="Modo Wireless";
$adv_wireless_mode_msg ="Esta função Permite que seja selecionado uma combinação diferente de clientes que possam ser suportados. Note que quando a compatibilidade contrário é habilitada para clientes 802.11a/g/b, é esperado que haja uma degradação de performance na rede Wireless.";
$adv_date_rate="Taxa de Dados";
$adv_date_rate_msg="Indica a base de taxa de transferência de adaptadores wireless em uma rede local wireless (WLAN). O access point irá ajustar a base de taxa de transferência dependendo da taxa base do dispositivo conectado. Se houver obstáculos ou interferência, o AP irá.";
$adv_beacon = "Intervalo do Sinal (25-500)";
$adv_beacon_msg = "Sinais são pacotes enviados pelo AP para sincronizar uma rede wireless. Configurando um intervalo de sinal maior, pode ajudar a economizar a energia de um cliente wireless, enquanto configurar um intervalo menor pode ajudar um cliente wireless a conectar ao access point mais rápido. A configuração de 100Milisegundos é a mais recomendada para os usuários.";
$adv_dtim="Intervalo de DTIM (1-15)";
$adv_dtim_msg="o Intervalo de DTIM especifica o número de sinais do Ap entre cada mensagem de indicação de trafego de entrega (DTIM). Ele informa as estações associadas da próxima janela para receberem mensagens broadcast e multicast. É Possível especificar uma faixa de.";
$adv_transmit_power="Força de transmissão";
$adv_transmit_power_msg="Esta configuração determina o nível de força da transmissão wireless. A força de transmissão pode ser ajustada para eliminar sobreposição de cobertura de área de wireless entre dois access points onde a interferência é a maior preocupação. As opções são 1.";
$adv_wmm="WMM (Wi-Fi Multimídia)";
$adv_wmm_msg="A característica de Multimídia Wi-Fi acrescenta aos usuários experiência de áudio, vídeo e aplicações de voz sobre uma rede Wi-Fi. WMM é baseado em uma sub-definição do padrão IEEE 802.11e QoS para WLAN. Habilitando esta característica é acrescentado ao u.";
$adv_ack_timeout="Ack Timeout";
if(query("/runtime/web/display/ack_timeout_range")=="0")
{
$adv_ack_timeout_msg="Você pode especificar um faixa de valor de Ack Timeout entre 48 a 200 em 2.4GHz e 25 a 200 em 5GHz para efetivamente otimizar o throughput sobre links de longa distância. A unidade é em microssegundo(ms) O valor padrão é definido em 25ms em 2.4GHz e 48ms.";
}
else
{
$adv_ack_timeout_msg="Você pode especificar um faixa de valor de Ack Timeout entre 64 a 200 em 2.4GHz e 50 a 200 em 5GHz para efetivamente otimizar o throughput sobre links de longa distância. A unidade é em microssegundo(ms) O valor padrão é definido em 50ms em 2.4GHz e 64ms.";
}
$adv_short_gi="GI curto";
$adv_short_gi_msg="Usando um curto (400ns) intervalo de guarda é possível acrescentar throughput. Entretanto, é possível que as taxas de erros aumentem em algumas instalações devido ao aumento da sensibilidade das reflexões de radiofreqüência. Selecione a opção e trabalhe m.";
$adv_igmp="IGMP Snooping";
$adv_igmp_msg="Internet Group Management Protocol (IGMP) Snooping permite que o AP reconheça solicitações e notificações IGMP enviadas entre roteadores e um host IGMP (Wireless STA). Quando o IGMP Snooping é habilitado, o AP irá encaminhar pacotes multicast para o host.";
$adv_link_integrality="Integralidade do Link";
$adv_link_integrality_msg="Se a conexão ethernet entre a LAN e o AP estiver desconectada, a opção de  \"Link Integrity\" quando habilitada irá fazer com que os clientes wireless automaticamente se desassociem do AP.";
$adv_connection_limit="Limite de Conexão";
if(query("/runtime/web/display/utilization") !="0")
{
      $utilization_string="Se a função estiver habilitada,";
}
else
{
       $utilization_string=" ";
}

$adv_connection_limit_msg="Limite de Conexão é uma opção para balanceamento de carga. Ela permite compartilhar o tráfego da rede e dos clientes usando múltiplos ".query("/sys/hostname")." ".$utilization_string." quando o número de usuários exceder o limite de usuários ou quando a utilização.";
$adv_user_limit ="Limite de Usuários (0-64)";
$adv_user_limit_msg ="Defina a quantidade máxima de usuários permitidos por access point. \"10\" é o recomendado para usuários comuns.";
$adv_network_utilization="Utilização da Rede";
$adv_network_utilization_msg="Defina a utilização máxima do access point para serviço. O ".query("/sys/hostname")." não permitirá que nenhum cliente se associe ao AP se a utilização exceder o valor especificado pelo usuário. 100% é o recomendado.";

$title_adv_mssid="Multi-SSID";
$title_adv_mssid_msg="Múltiplos SSID's são suportados apenas no modo AP. Um SSID primário e até sete SSID convidados podem ser configurados para permitir a segregação das estações que compartilham o mesmo canal.";
$adv_mssid_msg1="Além disso, é possível habilitar o VLAN State para permitir que o ".query("/sys/hostname")." trabalhe com Switches que suportam VLAN ou outros dispositivos.";
$adv_mssid_msg2="Quando o SSID primário é definido para sistema aberto sem encriptação, os SSID's Convidados podem ser configurados apenas como sem encriptação, WEP, WPA-Personal ou WPA2-Personal.";
$adv_mssid_msg3="Quando a segurança do SSID primário é definida como Sistema Aberto ou Compartilhado e Chave WEP, os SSID's Convidados podem ser configurados para não usarem encriptação, usar três outras chaves WEP, WPA-Personal ou WPA2-Personal.";
$adv_mssid_msg4="Quando a segurança do SSID primário é definida como WPA-Personal, WPA2-Personal, ou WPA-Auto-Personal, os Slots 1 e 3 são usados. Os SSID's Convidados podem ser definidos como sem encriptação, WEP ou WPA-Personal.";
$adv_mssid_msg5="Quando a segurança do SSID primário é definida como WPA-Enterprise, WPA2-Enterprise ou WPA-Auto-Enterprise, os SSID's Convidados poderão ser definidos junto a qualquer tipo de segurança.";

$title_adv_vlan="VLAN";
$title_adv_vlan_msg="O ".query("/sys/hostname")." suporta VLAN's. As VLAN's podem ser criadas com um Nome e VID. Gerenciamento (TCP stack), LAN, Primária / Múltiplos SSID's e conexões WDS podem ser associadas a uma VLAN como se fossem portas físicas. Qualquer pacote que entre pelo ".query("/sys/hostname")." sem.";

$title_adv_intrusion="Proteção de Intruso Wireless";
$title_adv_intrusion_msg="O ".query("/sys/hostname")." permite usuários para definir proteção de intrusos wireless.";

$title_adv_scheduling="Agendamento";
$title_adv_scheduling_msg="O Rádio do ".query("/sys/hostname")." pode ser agendada por semana ou por dias individuais.";

$title_adv_qos="QoS";
$title_adv_qos_msg="QoS tende a Qualidade de Serviço para manipulação de stream wireless inteligente, uma tecnologia desenvolvida para aumentar a experiência de usar uma rede wireless priorizando o tráfego de diferentes aplicações.";
$adv_enable_qoS="Habilitar QoS";
$adv_enable_qoS_msg="Habilitar esta opção caso deseje permitir que o QoS priorize o trafego. ";
$adv_enable_qoS_msg1="Classificadores de Prioridade.";
$adv_http="HTTP";
$adv_http_msg="Permite que o Access Point reconheça transferências HTTP para os streamings de áudio e vídeo mais comuns e os priorize sobre outros tráfegos. Tais tipos de Streaming são frequentemente usados por media players digitais.";
$adv_automatic="Automático";
$adv_automatic_msg="Quando habilitada, esta opção faz com que o access point automaticamente priorize tráfegos de streaming que em outro momento não era reconhecido, é baseado na forma como tráfegos de streaming se comportam. ";
$adv_qos_rule="Regras de QoS";
$adv_qos_rule_msg="Uma regra de QoS identifica fluxo de mensagens e assinaturas atribuídas a prioridade do fluxo. Para a maioria das aplicações, o classificadores de prioridade garantem as prioridades corretas e regras especificas de QoS não são necessárias.";
$adv_qos_rule_msg1="QoS suporta sobreposição entre regras. Se mais de uma regra corresponder a um especifico fluxo de mensagens, a regra com a prioridade mais alta será usada.";
$adv_name="Nome";
$adv_name_msg="Crie um nome para a regra que deseja.";
$adv_priority="Prioridade";
$adv_priority_msg="A prioridade do fluxo de mensagem é inserida aqui. Quatro prioridades definidas como:";
$adv_priority_msg1="     * BK: Background (Menos Urgente).";
$adv_priority_msg2="     * BE: Melhor Escolha.";
$adv_priority_msg3="     * VI: Vídeo.";
$adv_priority_msg4="     * VO: Voz (Maior Prioridade)."
$adv_protocol="Protocolo";
$adv_protocol_msg="O protocolo usado pela mensagem.";
$adv_host_1_ip="Faixa de IP do Host 1";
$adv_host_1_ip_msg="A regra aplica a um fluxo de mensagens para o computador que o endereço IP estiver na faixa definida aqui.";
$adv_host_1_port="Faixa de Portas do Host 1";
$adv_host_1_port_msg="A regra aplica a um fluxo de mensagens para as portas dos Host's 1 que foram definidas aqui.";
$adv_host_2_ip="Faixa de IP do Host 2";
$adv_host_2_ip_msg="A regra aplica a um fluxo de mensagens para o computador que o endereço IP estiver na faixa definida aqui.";
$adv_host_2_port="Faixa de Portas do Host 2";
$adv_host_2_port_msg="A regra aplica a um fluxo de mensagens para as portas dos Host's 2 que foram definidas aqui.";
    

$head_dhcp="Servidor DHCP";
$head_dhcp_msg="O servidor DHCP associa endereços de IP a estações que requisitam endereços IP enquanto se registram em uma rede wireless. As estações devem ser configuradas como um cliente DHCP para que possa receber endereços de IP automaticamente. O valor padrão para.";

$title_dhcp_dynamic_pool="Configuração de associação Dinâmica";
$title_dhcp_dynamic_pool_msg="O endereço de associação DHCP define a faixa de endereços de IP que podem ser associadas a estações na rede. Uma associação dinâmica permite que estações wireless recebam  um endereço IP válido com controle de Lease Time.";
$dhcp_ip_assigned="IP associado do";
$dhcp_ip_assigned_msg="Usuários podem especificar o inicio da faixa  de endereços IP válidos a estações wireless.";
$dhcp_range_of_pool="A Faixa de Pool (1-254)";
$dhcp_range_of_pool_msg="Usuários podem especificar a faixa dos endereços de IP que são válidos. Endereços de IP são incrementados do endereço IP especificado no campo \"IP associado de\".";
$dhcp_submask="Máscara de Sub-rede";
$dhcp_submask_msg="Define a sub-rede de um endereços de IP especificado no campo \"IP associado de\".";
$dhcp_gateway="Gateway";
$dhcp_gateway_msg="Especifica o endereço do gateway para a rede wireless.";
$dhcp_wins="WINS";
$dhcp_wins_msg="Especifica o endereço de WINS para a rede wireless.";
$dhcp_dns="DNS";
$dhcp_dns_msg="Especifica o endereço DNS para a rede wireless.";
$dhcp_domain="Nome de Domínio";
$dhcp_domain_msg="Especifica o endereço de Nomes de Domínio para a rede wireless.";
$dhcp_lease_time="Lease Time";
$dhcp_lease_time_msg="Usuários podem definir o tempo de associação de endereço IP especificando o Lease Time.";

$title_dhcp_static_pool="Configurações de Range Estático";
$title_dhcp_static_pool_msg="O range de endereço DHCP define o range de endereços de IP que possam ser associados a estações na rede. Um range estático permite que estações wireless recebam um IP válido sem controle de tempo.";
$dhcp_assigned_ip="IP associado";
$dhcp_assigned_ip_msg="Especifique o endereço IP a ser associado a uma estação com um endereço MAC  especificado no campo \"Assigned MAC Address\".";
$dhcp_assigned_mac="Endereço MAC Associado";
$dhcp_assigned_mac_msg="Especifique o endereço MAC da estação a ser associada.";

$title_dhcp_current_ip="Mapeamento de IP Atual";
$title_dhcp_current_ip_msg="Uma Lista de endereço MAC, endereço de IP, e lease time das estações wireless associadas ao ".query("/sys/hostname")." pelo servidor DHCP usando range estático ou range dinâmico.";


$head_filters="Filtros";
$head_filters_msg="A função de filtro inclui o filtro de endereços MAC e partição de LAN wireless. O filtro de endereços MAC bloqueia ou libera acessos identificando os endereços MAC especificados.Partição de LAN wireless pode aceitar ou rejeitar acessos das redes wireless.";

$title_filters_wireless_access="Configurações de Acesso Wireless";
$filters_wireless_band="Banda Wireless";
$filters_wireless_band_msg="Freqüência de banda operacional. Escolha 2.4GHz para visibilidade para dispositivos e para distâncias mais longas. Escolha 5GHz para menos interferência. Esta parte irá seguir as configurações básicas de wireless.";

$title_filters_wlan_partition="Partição WLAN";
$filters_internal_station="Conexão de estação Interna";
$filters_internal_station_msg="O valor padrão é \"habilitado\", que permite que estações se comuniquem internamente ao se conectar ao AP alvo.  Estações wireless não poderão trocar dados através do AP quando a função estiver desabilitada.";
$filters_eth_to_wlan="Acesso da Ethernet para a WLAN.";
$filters_eth_to_wlan_msg="O valor padrão é \"habilitado\", que permite o fluxo de dados da ethernet para as estações wireless conectadas ao AP. Desabilitando esta função,  os dados de broadcast da ethernet para os dispositivos wireless associados é bloqueado enquanto as estações wir.";


$head_st="Configurações de Status";

$title_st_dev_info="Informação do Dispositivo";
$title_st_dev_info_msg="Esta página mostra a informação atual como versão de firmware, parâmetros ethernet e wireless, assim como informações de utilização da memória e da CPU.";

$title_st_cli_info="Informação do Cliente";
$title_st_cli_info_msg="Esta página mostra os clientes SSID associados, MAC, Banda, método de autenticação, força de sinal e modo de economia de energia para a rede do ".query("/sys/hostname").".";

$title_st_wds_info="Informação de WDS";
$title_st_wds_info_msg="Esta página mostra  o SSID, MAC, Banda, método de autenticação, força do sinal e modo de econômia de energia para o sistema de distribuição de rede wireless do ".query("/sys/hostname").".";


$head_statistics="Estatísticas";

$title_st_ethernet="Estatísticas do tráfego da Ethernet";
$title_st_ethernet_msg="Mostra  informações sobre o tráfego da interface de rede cabeada.";

$title_st_wlan="Estatísticas de Tráfego WLAN 802.11G";
$title_st_wlan_msg="Mostra o throughput, frames transmitidos, frames recebidos e informações sobre frames de erro WEP para redes wireless.";


$head_log="Log";
$head_log_msg="Grava log's de eventos em um servidor de sistema de Log's e revela uma página WEB.";

$title_log_view="Visualização de Log";
$title_log_view_msg="A memória interna dos AP's guarda os Log's. A informação de Log inclusa é.";

$title_log_set="Configurações de Log";
$title_log_set_msg="Entre com o endereço IP do servidor de Log para enviar os log's ao servidor. Marque ou Desmarque a Atividade do sistema, atividade wireless ou notificação específica de qual tipo de log que deseja obter informações.";


$head_mt="Manutenção";

$title_mt_admin="Configurações Administrativas";
$mt_limit_admin_vid="Limite de VID administradora";
$mt_limit_admin_vid_msg="Pacotes com Tag de VLAN que possuem o mesmo VID serão permitidos ao administrador que faça o login.";
$mt_limit_admin_ip="Limite de Faixas de IP administradores.";
$mt_limit_admin_ip_msg="Entre com um range de endereços  de IP que o administrador esteja permitido a acessar.";
$title_mt_sysname="Configurações de Nome do Sistema";
$mt_sysname="Nome do Sistema";
$mt_sysname_msg="Um nome administrativo de associação para o ".query("/sys/hostname").".";
$mt_location="Localização";
$mt_location_msg="Localização física do ".query("/sys/hostname").".";
$title_mt_login="Configurações Locais";
$mt_username="Nome de usuário";
$mt_username_msg="É possível customizar o nome de usuário como administrador do ".query("/sys/hostname").". O nome padrão é \"Admin\" e senha em branco.";
$mt_oldpass="Senha Antiga";
$mt_oldpass_msg="Coloque a senha antiga.";
$mt_newpass="Nova senha";
$mt_newpass_msg="Coloque a nova senha neste campo. As senhas são Case-Sentitive, portanto \"A\" é um caractere diferente de \"a\", o tamanho deve estar entre 0 e 12 caracteres.";
$mt_conpass="Confirmar nova senha";
$mt_conpass_msg="Digite novamente a senha para confirmá-la.";
$title_mt_console="Configurações de Console";
$mt_status="Status";
$mt_status_msg="Habilita ou desabilita o console.";
$mt_console_protocol="Protocolo de Console";
$mt_console_protocol_msg="Escolha entre Telnet ou SSH.";
$mt_timeout="Timeout";
$mt_timeout_msg="Escolha o período de tempo de expiração.";
$title_mt_snmp="Configurações SNMP";
$mt_st_snmp="Status";
$mt_st_snmp_msg="Habilita ou desabilita o SNMP.";
$mt_public_comm="String de comunidade pública";
$mt_public_comm_msg="Entre com a string de comunidade pública para o SNMP.";
$mt_private_comm="String de comunidade privada";
$mt_private_comm_msg="Entre com a string de comunidade privada para o SNMP.";
$mt_trap="Status da armadilha";
$mt_trap_msg="habilita ou desabilita a armadilha.";
$mt_trap_serv="IP do servidor de armadilha.";
$mt_trap_serv_msg="O endereço IP do gerenciador SNMP para receber armadilhas enviadas pelo access point.";
$title_mt_pingctrl="configuração de controle de Ping";
$mt_ping_st="Status";
$mt_ping_st_msg="O ping funciona enviando pacotes ICMP \"echo request\" ao host alvo e ouvindo as respostas de ICMP \"echo response\". Desabilitando a configuração de controle de ping, O AP não ira responder ao pacotes de ICMP echo request. O padrão é como habilitado.";

$title_mt_fw="Firmware e SSL";
$title_mt_fw_msg="Upload de firmware e certificações SSL";
$title_mt_fw_msg1="É possível  carregar arquivos ao Access Point";
$mt_upload_fw="Upload de Firmware do HD local";
$mt_upload_fw_msg="A versão de firmware atual  é mostrada acima do campo de localização do arquivo. Depois que a ultima versão de firmware for baixada, clique no botão \"Browse\" para encontrar a nova firmware, assim que selecionada clique em \"Open\" e \"OK\" para iniciar a atua.";
$mt_upload_ssl="Upload de Certificação SSL do HD local.";
$mt_upload_ssl_msg="Após realizar o download da certificação SSL ao seu disco local, clique em \"Browse\". Selecione a certificação e clique em \"Open\" e \"Upload\" para completar a atualização.";

$_title_mt_config="Arquivo de Configuração";
$mt_config="Download e Upload do arquivo de configuração";
$mt_config_msg="É possível realizar o download e upload das configurações realizadas no access point.";
$mt_upload_config="Upload de Arquivo de configuração";
$mt_upload_config_msg="Navegue até o arquivo de configuração salva no HD e clique em \"Open\" e \"Upload\" para carregar a configuração.";
$mt_download_config="Download de Arquivo de configuração";
$mt_download_config_msg="Click em \"Download\" para salvar o arquivo de configuração atual no seu HD. Note que se for salva uma configuração com um usuário e senha, Depois de resetar o ".query("/sys/hostname")." e depois atualizar o arquivo de configuração salva, a senha irá se perder.";

$title_mt_time="Hora e Data";
$title_mt_time_msg="Entre com o IP do servidor NTP,  escolha a zona, e habilite ou desabilite o horário de verão.";


$head_sys = "Sistema";
$title_sys = "Configurações do Sistema";
$sys_apply_restart = "Aplique as Configurações e Reinicie";
$sys_apply_restart_msg = "Clique no botão \"Restart\" para aplicar as configurações e reiniciar.";
$sys_apply_restore = "Restaurar para as configurações padrões de fábrica";
$sys_apply_restore_msg = "Clique em \"Restore\" para restaurar o equipamento as configurações padrões de fábrica.";


?>
