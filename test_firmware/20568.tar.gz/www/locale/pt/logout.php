<?
$m_html_title="Logout";
$m_context_title="Logout";
$m_context="O logout foi realizado com sucesso.";
$m_button_dsc="Retorne a página de Login";
?>
