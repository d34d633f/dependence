<?
$m_context_title	= "Visualização de Log";

$m_first_page	= "Primeira Página";
$m_last_page	= "Última Página";
$m_previous	= "Anterior";
$m_next		= "Próxima";
$m_clear	= "Limpar";

$m_time		= "Hora";
$m_type		= "Prioridade";//"Type";
$m_message	= "Mensagem";
$m_page		= "Página";
$m_of		= "de";
?>
