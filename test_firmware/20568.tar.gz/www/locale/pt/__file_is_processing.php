A operação está sendo realizada...<br><br>
Por<font color=red><b>favor não desligue</b></font> o dispositivo.<br><br>
Por favor aguarde por
<input type='text' readonly name='WaitInfo' value='150' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
segundos...
