<?
$m_context_title = "Informação do Cliente";
$m_client_info = "Informação do Cliente";
$m_st_association  = "Associação de estação";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "Banda";
$m_auth = "Autenticação";
$m_signal = "Sinal";
$m_power = "Modo de economia de energia";
$m_multi_ssid = "MULTI-SSID";
$m_primary_ssid = "SSID Primário";
$m_on = "Ligado";
$m_off = "Desligado";
?>
