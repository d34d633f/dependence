<?
$m_context_title = "Configurações de Hora e Data";
$m_time_config_title = "Configuração de Hora";
$m_auto_time_config_title = "Configuração Automática de Hora";
$m_set_date_time_title = "Defina a Data e Hora manualmente.";
$m_time				= "Hora Atual";
$m_time_zone			= "Zona de tempo";
$m_enable_daylight_saving	= "Habilitar horário de verão";

$m_title_ntp	= "Configuração Automática de Hora";
$m_enable_ntp		= "Habilitar Servidor NTP";
$m_interval		= "Intervalo";
$m_ntp_server		= "Servidor NTP";
$m_select_ntp_server	= "Selecionar Servidor NTP";

$m_current_time	= "Data e Hora";
$m_year		= "Ano";
$m_month	= "Mês";
$m_day		= "Dia";
$m_days		= "Dias";
$m_hour		= "Hora";
$m_minute	= "Minuto";
$m_second	= "Segundo";
$m_copy_pc_time	= "Usar configurações de hora do computador.";
$m_daylight_saving_offset	="Configuração de horário de verão";
$m_daylight_saving_date	="Datas do horário de verão";
$m_week ="Semana";
$m_day_of_week = "Dia da Semana";
$m_dst_start = "DST inicial";
$m_dst_end = "DST final";
$m_jan = "Jan";
$m_feb = "Fev";
$m_mar = "Mar";
$m_apr = "Abr";
$m_may = "Mai";
$m_jun = "Jun";
$m_jul = "Jul";
$m_aug = "Ago";
$m_sep = "Set";
$m_oct = "Out";
$m_nov = "Nov";
$m_dec = "Dez";
$m_1st = "1st";
$m_2nd = "2nd";
$m_3rd = "3rd";
$m_4th = "4th";
$m_5th = "5th";
$m_sun = "Dom";
$m_mon = "Seg";
$m_tue = "Ter";
$m_wed = "Qua";
$m_thu = "Qui";
$m_fri = "Sex";
$m_sat = "Sáb";
$m_am = " am";
$m_pm = " pm";


$a_invalid_ntp_server	= "Servidor NTP inválido !";
?>
