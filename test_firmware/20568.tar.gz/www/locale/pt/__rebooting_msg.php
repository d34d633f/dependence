O dispositivo está reiniciando...<br><br>
Por <font color=red><b>favor NÃO desligue</b></font> o dispositivo.<br><br>
E aguarde
<input type='Text' readonly name='WaitInfo' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
segundos...
