<?
$m_context_title = "Динамические установки пула адресов";
$m_srv_enable = "Функция Включить/Отключить";
$m_disable = "Отключить";
$m_enable = "Включить";
$m_dhcp_srv = "Сервер управления DHCP";
$m_dhcp_pool = "Динамические установки пула адресов";
$m_ipaddr = "IP-адрес, назначеный с";
$m_iprange = "Диапазон адресов (1-254)";
$m_ipmask = "Маска подсети";
$m_gateway = "Шлюз";
$m_wins = "WINS";
$m_dns = "DNS";
$m_m_domain_name = "Имя домена";
$m_m_lease_time = "Время аренды (60 - 31536000 сек)";
$m_on = "Включить";
$m_off = "Выключить";
$m_status_enable = "Состояние";
$m_index = "Индекс";
$m_pri_ssid = "Первичный SSID";
$m_ms_ssid1 = "SSID 1";
$m_ms_ssid2 = "SSID 2";
$m_ms_ssid3 = "SSID 3";
$m_ms_ssid4 = "SSID 4";
$m_ms_ssid5 = "SSID 5";
$m_ms_ssid6 = "SSID 6";
$m_ms_ssid7 = "SSID 7";
$m_ssid = "SSID";
$m_multi_dhcp = "Управление Multi DHCP";
$m_multi_dhcp_enable ="Влючить/Отключить Multi DHCP";
$m_multi_srv_enable ="Влючить/Отключить сервер Multi DHCP";
$m_multi_dhcp_srv = "Сервер управления Multi DHCP";
$m_index="Индекс";


$a_invalid_ip		= "Неверный IP-адрес!";
$a_invalid_ip_range	= "Неверный диапазон IP-адресов!";
$a_invalid_netmask	= "Неверная маска подсети !";
$a_invalid_gateway	="Неверный шлюз!";
$a_invalid_wins	= "Неверный Wins !";
$a_invalid_dns	="Неверный DNS !";
$a_invalid_domain_name	= "Неверное имя домена !";
$a_invalid_lease_time	= "Неверное время аренды DHCP!";

?>
