<?
$m_context_title = "Настройка ACL беспроводных MAC-адресов"
$m_acl_type = "Список контроля доступа"
$m_disable = "Отключить"
$m_accept = "Применить"
$m_reject = "Отказаться"
$m_wmac = "MAC-адрес"
$m_id = "ID"
$m_del = "Удалить"
$m_wband = "Беспроводной диапазон"
$m_band_5G = "5 ГГц"
$m_band_2.4G = "2.4 ГГц"
$m_ssid = "SSID"
$m_mac = "MAC-адрес"
$m_band = "Диапазон"
$m_auth = "Аутентификация"
$m_signal = "Сигнал"
$m_power = "Режим сохранения энергии"
$m_multi_ssid = "MULTI-SSID "
$m_primary_ssid = "Первичный SSID"
$m_clirnt_info = "Текущая информация клиента"
$m_b_add = " Add 

$a_acl_del_confirm		= "Вы уверены, что действительно хотите удалить этот MAC-адрес?"
$a_same_acl_mac	= "There is an existent entry with the same MAC Address.\\n Please change the MAC Address.
$a_invalid_mac		= "Неверный MAC-адрес!"
$a_max_acl_mac		= "Максимальное количество адресов в списке контроля доступа: 256!"

?>
