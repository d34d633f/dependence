<?
// category
$m_menu_top_bsc		="Установка";
$m_menu_top_adv		="Расширенные настройки";
$m_menu_top_tools	="ТЕХНИЧЕСКОЕ ОБСЛУЖИВАНИЕ";
$m_menu_top_st		="Состояние";
$m_menu_top_spt		="Поддержка";

// basic
$m_menu_bsc_wizard      ="МАСТЕР";
$m_menu_bsc_internet	="ИНТЕРНЕТ";
$m_menu_bsc_wlan	="БЕСПРОВОДНАЯ УСТАНОВКА";
$m_menu_bsc_lan		="УСТАНОВКА СЕТИ";

// advanced
$m_menu_adv_vrtsrv	="ВИРТУАЛЬНЫЙ СЕРВЕР";
$m_menu_adv_port	="ПЕРЕАДРЕСАЦИЯ ПОРТОВ";
$m_menu_adv_app		="ПРАВИЛА ПРИЛОЖЕНИЙ";
$m_menu_adv_mac_filter	="СЕТЕВОЙ ФИЛЬТР";
$m_menu_adv_acl		="ФИЛЬТР";
$m_menu_adv_url_filter	="ФИЛЬТР WEB-САЙТОВ";
$m_menu_adv_dmz		="НАСТРОЙКИ МЕЖСЕТЕВОГО ЭКРАНА";
$m_menu_adv_wlan	="ПРОИЗВОДИТЕЛЬНОСТЬ";
$m_menu_adv_network	="РАСШИРЕННЫЕ НАСТРОЙКИ СЕТИ";
$m_menu_adv_dhcp	="DHCP-СЕРВЕР";
$m_menu_adv_mssid	="MULTI-SSID";
$m_menu_adv_group	="Лимит пользователей";
$m_menu_adv_wtp		="Коммутатор WLAN";
$m_menu_adv_wlan_partition	="Разделение WLAN";

// tools
$m_menu_tools_admin	="Управление устройством";
$m_menu_tools_time	="ВРЕМЯ";
$m_menu_tools_system	="СИСТЕМА";
$m_menu_tools_firmware	="ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ";
$m_menu_tools_misc	="MISC";
$m_menu_tools_ddns	="DDNS";
$m_menu_tools_vct	="СИСТЕМНАЯ ПРОВЕРКА";
$m_menu_tools_sch	="РАСПИСАНИЕ";
$m_menu_tools_log_setting	="НАСТРОЙКИ ЖУРНАЛА РЕГИСТРАЦИИ";

// status
$m_menu_st_device	="ИНФОРМАЦИЯ ОБ УСТРОЙСТВЕ";
$m_menu_st_log		="ЖУРНАЛ РЕГИСТРАЦИИ";
$m_menu_st_stats	="Статистика";
$m_menu_st_wlan		="ИНФОРМАЦИЯ О КЛИЕНТЕ";

// support
$m_menu_spt_menu	="МЕНЮ";

$m_logout	="Выход из системы";

$m_menu_home	="Главная";
$m_menu_tool	="Техническое&nbsp;обслуживание";
$m_menu_config	="Конфигурация";
$m_menu_sys	="Система";
$m_menu_logout	="Выход&nbsp;из&nbsp;системы";
$m_menu_help	="Помощь";

$m_menu_tool_admin	="Настройки администратора";
$m_menu_tool_fw	="Загрузка программного обеспечения и сертификата SSL";
$m_menu_tool_config	="Конфигурационный файл";
$m_menu_tool_sntp	="SNTP";

$m_menu_config_save	="Сохранить и активировать";
$m_menu_config_discard	="Сброс изменений";

$a_config_discard ="Все изменения будут сброшены! Продолжить?";

?>
