<?
$m_context_title = "Настройки производительности";
$m_wl_enable = "Беспроводная сеть";
$m_disable = "Отключить";
$m_enable  = "Включить";
$m_off = "Выключить";
$m_on  = "Включить";
$m_wlmode = "Беспроводной режим";
$m_wlmode_n_g_b = "Смешанный: 802.11n, 802.11g и 802.11b";
$m_wlmode_n_g = "Смешанный: 802.11n и 802.11g";
$m_wlmode_g_b = "Смешанный 802.11g и 802.11b";
$m_wlmode_n = "Только 802.11n";
$m_wlmode_n_a = "Смешанный 802.11n, 802.11a";
$m_wlmode_a = "Только 802.11a";
$m_rate = "Скорость передачи данных";
$m_best	= "Наилучшая (до 300)";
$m_best_54	= "Наилучшая (до 54)";
$m_54	= "54";
$m_48	= "48";
$m_36	= "36";
$m_24	= "24";
$m_18	= "18";
$m_12	= "12";
$m_9	= "9";
$m_6	= "6";
$m_11	= "11";
$m_5.5	= "5.5";
$m_2	= "2";
$m_1	= "1";
$m_beacon_interval	="Интервал маяка (25-500)";
$m_rts			="Порог RTS (256-2346)";
$m_frag			="Фрагментация (256-2346)";
$m_dtim			="Интервал DTIM  (1-15)";
$m_power = "Мощность передачи";
$m_ms = "(&micro;s)";

$m_wmm = "WMM (Wi-Fi Multimedia)";
$m_shortgi = "Short GI";
$m_limit_state = "Лимит подключений";
$m_limit_num = "Лимит пользователей (0 - 64)";
$m_utilization = "Использование сети";
$m_0 = "0";
$m_10 = "10";
$m_20 = "20";
$m_30 = "30";
$m_40 = "40";
$m_50 = "50";
$m_60 = "60";
$m_70 = "70";
$m_80 = "80";
$m_90 = "90";
$m_100 = "100";
$m_180 = "180";
$m_25 = "25";
$m_12.5 = "12.5";
$m_igmp = "IGMP Snooping";
$m_link_integrality="Link Integrity";
$m_ack_timeout="Ack Time Out";
$m_mbps = "(Mbps)";
if(query("/runtime/web/display/ack_timeout_range")=="0")
{
$m_ack_timeout_g_msg = " (2.4GHz, 48~200)";
$m_ack_timeout_a_msg = " (5GHz, 25~200)";
	$a_invalid_ack_timeoutg ="Диапазон значений Ack TimeOut: 48 ~ 200.";
	$a_invalid_ack_timeouta ="Диапазон значений Ack TimeOut: 25 ~ 200.";
}
else
{
	$m_ack_timeout_g_msg = " (2.4GHz, 64~200)";
	$m_ack_timeout_a_msg = " (5GHz, 50~200)";
	$a_invalid_ack_timeoutg ="Диапазон значений Ack TimeOut: 64 ~ 200.";
	$a_invalid_ack_timeouta ="Диапазон значений Ack TimeOut: 50 ~ 200.";
}
$a_invalid_bi		="Диапазон значений интервала сигналов: 25 ~ 500.";
$a_invalid_rts		="Диапазон значений порога RTS: 256 ~ 2346.";
$a_invalid_frag		="Диапазон значений фрагментации 256 ~ 2346.";
$a_invalid_dtim		="Диапазон значений интервала DTIM: 1~15.";
$a_invalid_limit_num	="Диапазон 'лимита пользователей': от 0 до 64.";

?>
