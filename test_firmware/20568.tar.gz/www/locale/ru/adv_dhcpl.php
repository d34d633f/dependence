<?
$m_context_title = "Текущий список IP-адресов";
$m_host_name = "Имя хоста";
$m_mac = "Привязка MAC-адреса";
$m_ip = "Назначение IP-адреса";
$m_time = "Время аренды";
$m_dynamic_pools = "Текущий динамический пул DHCP";
$m_static_pools = "Текущий статический пул DHCP";
$m_days			="дней";
$m_hrs			="часов";
$m_mins			="минут";
$m_secs			="секунд";
?>
