<?
$m_context_title = "Настройка системы";
$m_reboot		=" Перезагрузка устройства";
$m_b_reboot		="Перезагрузка ";
$m_factory_reset	="Восстановление настроек по умолчанию ?";
$m_b_restore		="Restore";
$m_clear_lang_pack ="Удалить перевод интерфейса";
$m_clear ="Очистить";
$a_sure_to_clear_lang ="Удалить перевод интерфейса ?";
$a_sure_to_factory_reset="Восстановление настроек по умолчанию ?";
$a_sure_to_reboot	="Перезагрузить точку доступа ?";

?>
