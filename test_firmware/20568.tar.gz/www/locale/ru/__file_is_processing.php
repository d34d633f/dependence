Обработка действия Пожалуйста,<br><br>
Обработка действия Пожалуйста, <font color=red><b>НЕ ВЫКЛЮЧАЙТЕ</b></font>  устройство И пожалуйста,.<br><br>
подождите XX секунд.
<input type='text' readonly name='WaitInfo' value='150' size='2' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>

  