<?
$MAX_RULES=query("/lan/dhcp/server/pool:1/staticdhcp/max_client");
if ($MAX_RULES==""){$MAX_RULES=25;}	
$m_context_title = "Статические установки пула адресов";
$m_srv_enable = "Функция Включить/Отключить";
$m_disable = "Отключить";
$m_enable = "Включить";
$m_dhcp_srv = "Сервер управления DHCP";
$m_dhcp_pool = "Статические установки пула адресов";
$m_computer_name = "Имя Компьютера";
$m_ipaddr = "Назначенный IP-адрес";
$m_macaddr = "Назначенный MAC-адрес";
$m_ipmask = "Маска подсети";
$m_gateway = "Шлюз";
$m_wins = "Wins";
$m_dns = "DNS";
$m_m_domain_name = "Имя домена";
$m_on = "Включить";
$m_off = "Выключить";
$m_status_enable = "Состояние";
$m_mac = "MAC-адрес";
$m_ip = "IP-адрес";
$m_state = "Режим";
$m_edit = "Изменить";
$m_del = "Удалить";

$a_invalid_host		= "Некорректное Имя Компьютера !";
$a_invalid_ip		= "Неверный IP-адрес!";
$a_invalid_mac		= "Неверный MAC-адрес!";
$a_max_mac_num = "Максимальное количество адресов в списке управления доступом:".$MAX_RULES."!";
$a_same_mac = "Данный MAC-адрес уже есть.Пожалуйста, измените MAC-адрес.";
$a_invalid_netmask	= "Неверная маска подсети !";
$a_invalid_gateway	="Неверный шлюз!";
$a_invalid_wins	= "Неверный Wins !";
$a_invalid_dns	="Неверный DNS !";
$a_invalid_domain_name	= "Неверное имя домена !";
$a_invalid_lease_time	= "Неверное время аренды DHCP!";
$a_entry_del_confirm = "Вы уверены, что действительно хотите удалить эту запись?";
?>
