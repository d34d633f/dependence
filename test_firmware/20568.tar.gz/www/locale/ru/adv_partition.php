<?
$m_context_title = "Беспроводной раздел";
$m_isc = "Станция внутреннего соединения";
$m_guest = "Режим Guest";
$m_ewa = "Ethernet-доступ к WLAN";
$m_enable = "Включить";
$m_disable = "Отключить";
$m_band = "Беспроводной диапазон";
$m_band_5G = "5 ГГц";
$m_band_2.4G = "2.4 ГГц";
$m_pri_ssid = "Первичный SSID";
$m_ms_ssid1 = "SSID 1";
$m_ms_ssid2 = "SSID 2";
$m_ms_ssid3 = "SSID 3";
$m_ms_ssid4 = "SSID 4";
$m_ms_ssid5 = "SSID 5";
$m_ms_ssid6 = "SSID 6";
$m_ms_ssid7 = "SSID 7";
?>
