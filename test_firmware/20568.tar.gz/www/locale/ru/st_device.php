<?
$m_context_title = "Информация об устройстве";
$m_context_title = "Информация об устройстве";
$m_ethernet = "Ethernet";
$m_wireless = "Беспроводной";
$m_2.4g = "(2.4 ГГц)";
$m_5g = "(5 ГГц)";
$m_status = "Статус устройства";
$m_fw_version = "Версия программного обеспечения";
$m_eth_mac = "MAC-адрес Ethernet";
$m_wlan_mac = "Беспроводной MAC-адрес";
$m_ap_array = "AP Arrary";
$m_role = "Role";
$m_master = "Master";
$m_backup_master = "Backup Master";
$m_slave = "Slave";
$m_location = "Location";
$m_pri = "Первичный";
if($ssid_flag == "1")
{
	$m_ms	="SSID 1~3";
}
else
{
$m_ms = "SSID 1~7";
}
$m_ip = "IP-адрес";
$m_mask = "Маска подсети";
$m_gate = "Шлюз";
$m_na = "Недоступен";
$m_ssid = "Имя сети (SSID)";
$m_channel = "Канал";
$m_rate = "Скорость передачи данных";
$m_sec = "Безопасность";
$m_bits		= "биты";
$m_tkip		= "TKIP";
$m_aes		= "AES";
$m_cipher_auto	= "Автоматически";
$m_wpa		= "WPA-";
$m_wpa2		= "WPA2-";
$m_wpa_auto		= "WPA2-Auto-";
$m_eap		= "Enterprise/";
$m_psk		= "Personal /";
$m_open		="Открытый /";
$m_shared	="Разделяемый ключ /";
$m_disabled		="Отключить";
$m_cpu = "Использование процессора";
$m_memory = "Использование памяти";
$m_none = "Отсутствует";
$m_auto  ="Автоматически";
$m_54	= "54";
$m_48	= "48";
$m_36	= "36";
$m_24	= "24";
$m_18	= "18";
$m_12	= "12";
$m_9	= "9";
$m_6	= "6";
$m_11	= "11";
$m_5	= "5.5";
$m_2	= "2";
$m_1	= "1";
?>
