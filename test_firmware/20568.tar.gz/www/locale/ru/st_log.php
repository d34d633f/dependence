<?
$m_context_title	= "Обзор журнала регистрации";

$m_first_page	= "Первая страница";
$m_last_page	= "Последняя страница";
$m_previous	= "Предыдущая";
$m_next		= "Следующая";
$m_clear	= "Очистить";

$m_time		= "Время";
$m_type		= "Priority";//"Type
$m_message	= "Сообщение";
$m_page		= "Страница";
$m_of		= "of";
?>
