<?
$m_context_title = "Информация о клиенте";
$m_client_info = "Информация о клиенте";
$m_st_association  = "Станция соединения";
$m_ssid = "SSID";
$m_mac = "MAC-адрес";
$m_band = "Диапазон";
$m_auth = "Аутетнификация";
$m_signal = "Сигнал";
$m_power = "Режим сохранения энергии";
$m_multi_ssid = "MULTI-SSID ";
$m_primary_ssid = "Первичный SSID";
$m_on = "Включить";
$m_off = "Отключить";
?>
