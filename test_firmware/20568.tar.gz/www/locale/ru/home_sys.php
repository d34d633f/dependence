<?
$ssid_flag = query("/runtime/web/display/mssid_index4");
$m_context_title = "Информация о системе";
$m_model_name	= "Имя модели";
$m_sys_time	="Системное время";
$m_up_time	="Доступное время";
$m_firm_version	="Версия программного обеспечения";
$m_ip	="IP-адрес";
$m_mac	="MAC-адрес";
if($ssid_flag == "1")
{
	$m_mssid	="SSID 1~3";
}
else
{
$m_mssid	="SSID 1~7";
}
$m_ap_mode ="Режим работа";
$m_days = "Дни";
$m_sysname = "Имя системы";
$m_location = "Местоположение";
$m_ap = "Access Point";
$m_wireless_client = "Wireless client";
$m_wds_ap = "WDS with AP";
$m_wds = "WDS";
?>
