<?
$m_user_name		="Имя пользователя";
$m_password		="Пароль";
$m_continue		="Продолжить";
$m_nochg_title		="Изменений нет.";
$m_nochg_dsc		="Настройки не изменены";
$m_saving_title		="Сохранение";
$m_saving_dsc		="Настройки сохранены и вступят в силу.";
$m_saving_dsc_wait = "Пожалуйста, подождите ...";
$m_saving_dsc_change_ip = "Пожалуйста, подождите 10 секунд, после чего откроется доступ к устройству с новым IP-адресом.";
$m_scan_title		="Сканирование";
$m_detect_title	="Обнаружить";
$m_scan_dsc		="Сканирование ... <br><br> Пожалуйста, подождите ... ";
$m_clear = "Очистить";

$TITLE=query("/sys/hostname");
$first_frame = "home_sys";
$m_logo_title	=query("/sys/hostname");
?>
