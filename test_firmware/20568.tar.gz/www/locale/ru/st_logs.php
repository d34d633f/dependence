<?
$m_context_title	= "Настройка журнала регистрации";
$m_log_setting_title = "Настройка журнала регистрации";
$m_log_ip	=  "Сервер регистрации / IP-адрес";
$m_log_type = "Тип регистрации";
$m_system_activity	=  "Работа системы";
$m_wireless_activity	=  "Работа беспроводной сети";
$m_notice	=  "Примечание";
$m_smtp_setting_title = "Уведомление по электронной почте";
$m_smtp = "Уведомление по электронной почте";
$m_enable = "Включить";
$m_smtp_ip = "Адрес сервера электонной почты";
$m_smtp_from_email = "E-mail от";
$m_smtp_to_email = "на e-mail";
$m_email_log_schedule_title = "Расписание журнала электронной почты";
$m_log_schedule = "Расписание";
$m_log_schedule_msg = "часов или при полной авторизации";
$m_smtp_name = "Имя пользователя";
$m_smtp_password ="Пароль";
$m_smtp_confirm_password ="Подтвердите пароль";
$m_smtp_port = "Порт SMTP";

$a_invalid_log_ip		= "Неверный сервер регистрации / IP-адрес !";
$a_invalid_smtp_ip		= "Неверный почтовый сервер / IP-адрес !";
$a_empty_user_name	="Пожалуйста, введите имя пользователя";
$a_invalid_user_name	="В имени пользователя неверный символ. Пожалуйста, измените его.";
$a_first_blank_user_name	= "Первый символ не может быть пустым.";
$a_invalid_new_password	="В пароле содержится неверный символ. Пожалуйста, измените его.";
$a_password_not_matched	="Пароль и повторно введенный пароль не совпадают.";
$a_invalid_smtp_port = "Неверный SMTP порт !";
?>
