<?
$m_context_title = "Информация по WDS";
$m_client_info = "Информация по WDS";
$m_st_association  = "Станция соединена с  11";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "Диапазон";
$m_auth = "Аутентификация";
$m_signal = "Сигнал";
$m_power = "Режим сохранения энергии";
$m_wpa		= "WPA-";
$m_wpa2		= "WPA2-";
$m_wpa_auto		= "WPA2-Auto-";
$m_eap		= "Enterprise";
$m_psk		= "Personal";
$m_open		="Открытая система";
$m_shared	="Разделяемый ключ";
$m_disabled		="Отключить";
$m_channel = "Канал";
$m_name = "Имя ";
$m_status = "Статус";
$wds = "WDS";
$m_on = "Включить";
$m_off = "Отключить";
$m_none = "Никакой";
?>
