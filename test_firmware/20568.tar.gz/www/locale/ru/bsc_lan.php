<?
$m_context_title = "Настройки LAN";

$m_lan_type  = "Получить IP-адрес от";
$m_static_ip = "Статический IP-адрес (вручную)";
$m_dhcp      = "Динамический IP-адрес (DHCP)";

$m_ipaddr    = "IP-адрес";
$m_subnet    = "Маска подсети";
$m_gateway   = "Шлюз по умолчанию";

$a_invalid_ip= "Неверный IP-адрес!";
$a_invalid_netmask= "Неверная маска подсети !";
$a_invalid_gateway= "Неверный IP-адрес шлюза!";
$a_connect_new_ip = "Пожалуйста, подключитесь к новому IP-адресу !";
?>
