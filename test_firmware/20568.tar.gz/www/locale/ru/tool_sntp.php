<?
$m_context_title = "Настройки даты и времени";
$m_time_config_title = "Настройка времени";
$m_auto_time_config_title = "Автоматическая настройка времени";
$m_set_date_time_title = "Установить дату и время вручную";
$m_time				= "Текущее время";
$m_time_zone			= "Временная зона";
$m_enable_daylight_saving	= "Включить переход на летнее время (для сохранения энергии)";

$m_title_ntp	= "Автоматическая настройка времени";
$m_enable_ntp		= "Включить сервер NTP";
$m_interval		= "Интервал";
$m_ntp_server		= "NTP-сервер";
$m_select_ntp_server	= "Выбрать NTP-сервер";

$m_current_time	= "Дата и время";
$m_year		= "Год";
$m_month	= "Месяц";
$m_day		= "День";
$m_days		= "Дни";
$m_hour		= "Час";
$m_minute	= "Минута";
$m_second	= "Секунда";
$m_copy_pc_time	= "Скопировать настройки времени с компьютера";
$m_daylight_saving_offset	="Сдвинуть переход на летнее время";
$m_daylight_saving_date	="Данные ";
$m_week ="Неделя";
$m_day_of_week = "День недели";
$m_dst_start = "Начало летнего времени";
$m_dst_end = "Конец летнего времени";
$m_jan = "Январь";
$m_feb = "Февраль";
$m_mar = "Март";
$m_apr = "Апрель";
$m_may = "Май";
$m_jun = "Июнь";
$m_jul = "Июль";
$m_aug = "Август";
$m_sep = "Сентябрь";
$m_oct = "Октябрь";
$m_nov = "Ноябрь";
$m_dec = "Декабрь";
$m_1st = "1 часовой пояс";
$m_2nd = "2 часовой пояс";
$m_3rd = "3 часовой пояс";
$m_4th = "4 часовой пояс";
$m_5th = "5 часовой пояс";
$m_sun = "Воскресенье";
$m_mon = "Понедельник";
$m_tue = "Вторник";
$m_wed = "Среда";
$m_thu = "Четверг";
$m_fri = "Пятница";
$m_sat = "Суббота";
$m_am = "am";
$m_pm = "pm";


$a_invalid_ntp_server	= "Неверный NTP-сервер !";
?>
