<?
$m_context_title = "Настройки коммутатора WLAN";
$m_wtp_title = "Настройка конечной беспроводной точки";
$m_connect_title = "Информация о соединении";
$m_wtp_enable = "Включить WTP";
$m_wtp_name = "Имя WTP";
$m_wtp_location = "Данные о местоположении WTP";
$m_ac_ip = "IP-адрес коммутатора WLAN";
$m_ac_name = "Имя коммутатора WLAN";
$m_ac_ipaddr = "IP-адрес коммутатора WLAN";
$m_ac_ip_list_title = "Список IP-адресов коммутатора WLAN";
$m_id = "ID";
$m_ip = "IP-адрес";
$m_del = "Удалить";

$a_wtp_del_confirm		= "Вы действительно хотите удалить IP-адрес?";
$a_same_wtp_ip	= "Такой IP-адрес уже есть.\\nПожалуйста, изменине IP-адре.";
$a_invalid_ip		= "Неверный IP-адрес !";
$a_max_ip_table		= "Максимальное количество IP-адресов коммутатора WLAN в списке: 8!";
?>
