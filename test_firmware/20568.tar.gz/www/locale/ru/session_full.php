<?
$m_html_title="Сеанс заполнен";
$m_context_title="Сеанс заполнен";
$m_context="Авторизация session is full.  Пожалуйста, попробуйте позже";
$m_button_dsc="Авторизуйтесь снова";
?>
