<?
$m_context_title	="&nbsp";
$m_context		="Только аккуант <strong>администратора</strong> может изменить все настройки.";

$m_button_dsc		=$m_continue;
?>
