Устройство перезагружается Пожалуйста,<br><br>
НЕ <font color=red><b>ВЫКЛЮЧАЙТЕ устройство.</b></font> <br><br>
И пожалуйста, подождите
<input type='Text' readonly name='WaitInfo' size='2' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
секунд.
