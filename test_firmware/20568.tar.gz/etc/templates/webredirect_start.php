#!/bin/sh
echo [$0] ... > /dev/console
<?
/* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");
$generate_start=1;
$webredirect_mode = 0;
$webredirect_mode = query("/wlan/inf:1/webredirect/enable");

echo "echo Web Redirect is running... > /dev/console\n";
set("/runtime/webredirect/client_add","0");	
set("/runtime/webredirect/client_del","0");

if($webredirect_mode==1) 
{	
	echo "brctl webredirect br0 1 \n";
	
	$ct_num = 0;
	for("/runtime/stats/wlan/inf:1/client")
	{
		$ct_num = $ct_num+1;
	}
	
	echo "brctl webredirect_ctnum br0 ".$ct_num."\n";
	
	for("/runtime/stats/wlan/inf:1/client")
	{
		$client_idx = $@;
		$client_mac  = query("/runtime/stats/wlan/inf:1/client:".$client_idx."/mac");
		$wr_flag = query("/runtime/stats/wlan/inf:1/client:".$client_idx."/wr_flag");
		
		for("/runtime/webredirect/client")
		{
			$wrc_idx = $@;
			$wrc_mac  = query("/runtime/webredirect/client".$wrc_idx."/mac");
			$wrc_flag  = query("/runtime/webredirect/client".$wrc_idx."/wr_flag");
			if($client_mac  == $wrc_mac)
			{
				set("/runtime/stats/wlan/inf:1/client:".$client_idx."/wr_flag",$wrc_flag);
			}
		}
		
		if($client_mac != "")
		{
			if($wr_flag == "")
			{
				$wr_flag = 0;	
			}
			echo "brctl webredirect_ct br0 ".$@." ".$client_mac." ".$wr_flag."\n";
		}
	}
	
	for("/runtime/webredirect/client")
	{
		del("/runtime/webredirect/client:".$@);
	}
	
	
	for("/runtime/stats/wlan/inf:1/client")
	{
		$mac  = query("/runtime/stats/wlan/inf:1/client:".$@."/mac");
		$flag = query("/runtime/stats/wlan/inf:1/client:".$@."/wr_flag");
		set("/runtime/webredirect/client:".$@."/mac",$mac);
		set("/runtime/webredirect/client:".$@."/wr_flag",$flag);
	}	
}
else
{
	echo "brctl webredirect br0 0 \n";
}

?>
