<? /* vi: set sw=4 ts=4: */
anchor("/wlan/inf:1");
   for("/wlan/inf:1/zonedefence/ipaddr")
       {
        $ipaddr=query("/wlan/inf:1/zonedefence/ipaddr:".$@);
        echo "iwpriv ".$wlanif." add_ip ".$ipaddr."\n"; 	
	   }
   
														   
?>
