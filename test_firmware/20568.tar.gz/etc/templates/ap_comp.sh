#!/bin/sh
echo [$0] ... > /dev/console
iwlist ath0 compare 
