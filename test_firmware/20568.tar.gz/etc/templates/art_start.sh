#!/bin/sh
echo [$0] $1  ... > /dev/console 
	echo Start art module ... > /dev/console

	APBAND=`rgdb -g /wlan/ch_mode`

	if [ "$APBAND" = "1" ]; then 
	    echo Stop normal wireless 11na ... > /dev/console
 	    [ -f /var/run/wlan_a_stop.sh ] && sh /var/run/wlan_a_stop.sh 
	else 
	    echo Stop normal wireless 11ng ... > /dev/console
	    [ -f /var/run/wlan_g_stop.sh ] && sh /var/run/wlan_g_stop.sh 
	fi
	echo insmode  art module ... > /dev/console
	mknod /dev/dk0 c 63 0
	insmod /lib/modules/art.ko
	/lib/modules/mdk_client.out &


