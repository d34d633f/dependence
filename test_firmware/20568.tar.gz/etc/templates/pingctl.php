#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */

$pingctl = "/var/run/__pingctl.sh";
$pingctlstatus = query("/sys/pingctl");

fwrite($pingctl, "echo pingctl.sh...\n");
	
if ($pingctlstatus==1)
{

    fwrite2($pingctl, "brctl pingctl br0 enable\n");
}else{
    fwrite2($pingctl, "brctl pingctl br0 disable\n");
}
?>
# pingctl.php <<<

