#!/bin/sh
echo [$0] ... > /dev/console
<?
/* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");

$generate_start=0;

echo "echo Web Redirect is stop ! > /dev/console\n";

?>
