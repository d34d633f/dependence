#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */

$WLAN_g = "/wlan/inf:1";  // b, g, n band
$WLAN_a = $WLAN_g;  // a, g band use the same config.
$band	= query("/wlan/ch_mode");  // "1" #1--->a   0---> b,g,n
$A_BAND = 1;  // 1--->a   
$G_BAND = 0;  // 0---> b,g,n
$WLAN = $WLAN_g; 

if ($band == $A_BAND)	// 11A band 
{ 	    
	$WLAN = $WLAN_a;
}
else            // 11b,g,n band
{ 
	$WLAN = $WLAN_g;      
}
$multi_ssid_path = $WLAN."/multi";
$wds_path = $WLAN."/wds";
$sys = "/sys";
$eth = "/lan/ethernet";

$multi_total_state = query($multi_ssid_path."/state");  
$ap_mode	= query($WLAN."/ap_mode");  // "1" #1--->a   0---> b,g,n
$wlanif = query("/runtime/layout/wlanif");
$wlanmac= query("/runtime/layout/wlanmac");
$igmpsnoop = query("/wlan/inf:1/igmpsnoop");
$txpower    = query("/wlan/inf:1/txpower");
$ethlink = query("/wlan/inf:1/ethlink");
$wlxmlpatch_ap_pid = "/var/run/wlxmlpatch.pid";
$wlan_ap_operate_mode = query($WLAN."/ap_mode");
if ($ap_mode == 4)  // WDS without AP // WDSwithoutAP_bug_0321
{    $withoutap = 1; }
else  // ($WLAN == 3)  WDS with AP
{    $withoutap = 0; }



if ($generate_start==1)
{ 

    echo "echo Start WLAN interface ".$wlanif." ... > /dev/console\n";
	if (query("/wlan/inf:1/enable")!=1)
	{
	    echo "echo WLAN is disabled ! > /dev/console\n";
		exit;
	}
    if ($wlan_ap_operate_mode==1)
	{
		
	 echo "echo APC MODE  > /dev/console\n";	
		exit;
	}		
	
    $lan_mac = query("/runtime/layout/lanmac");
    anchor($WLAN);
    /* common cmd */
    $IWPRIV="iwpriv ".$wlanif;
    $IWCONF="iwconfig ".$wlanif;
    require("/etc/templates/troot.php");
    $auth_mode = query("/wlan/inf:1/authentication");
    $ap_igmp_pid = "/var/run/ap_igmp.pid";
   // $wlan_ap_operate_mode = query($WLAN."/ap_mode");
    $W_PATH=$WLAN."/";

//****************************Device UP*********************************************
   //~~~~~~~~~~APMDOE: ath0 up~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	

  // echo "ifconfig ath0 up\n";
	$auth_mode = query("/wlan/inf:1/authentication");
	if ($auth_mode>1){
	 echo $IWCONF." essid \"".get("s",$WLAN."/ssid")."\"\n";
	         require($template_root."/__auth_hostapd.php");
			 if($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4){
   echo "ifconfig ath0 up\n";
			 }
	     }
	     else {
		 echo "ifconfig ath0 up\n";
	         /*keep ori space */
	     }
	echo "sleep 6\n";

        
   //~~~~~~~~~MSSID : ath1-8 up~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	if ($multi_total_state == 1)
	{

	    $index=0; 
        $index1=0;
        for ($multi_ssid_path."/index")
	    {      
	        $index++;     
	        $IWPRIV="iwpriv ath".$index;
	        /*add schedule for multi-ssid by yuda start*/
	        $schedule_enable=query("/schedule/enable");
	        if ($schedule_enable==1)
	        {
	        	if(query($multi_ssid_path."/index:".$index."/schedule_rule_state")==1)
	        	{
	        		$multi_ind_schedule_state = query($multi_ssid_path."/index:".$index."/schedule_state");
	        	}
	        	else
	        	{
	        		$multi_ind_schedule_state = 1;
	        	}     	
	        }
	        else
	        {
	        	$multi_ind_schedule_state = 1;
	        }
	        
	        /*add schedule for multi-ssid by yuda end*/	    
	        
	        $multi_ind_state = query($multi_ssid_path."/index:".$index."/state");  
	        if ($multi_ind_state==1 && $multi_ind_schedule_state == 1)  //add $multi_ind_schedule_state for schedule for multi-ssid by yuda  
	        { 	            
                    echo "ifconfig ath".$index." up\n";
	                echo "brctl addif br0 ath".$index."\n";	
	        }  // end of if ($multi_ind_state==1)  
	    }  // end of for ($multi_ssid_path."/index")
    } // end of ($multi_total_state == 1)
        
        	
   //~~~~~~~~WDS: ath9-15 up~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
       if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
	{
		
	   $index=7;
           $index_mac=0;
           $up_ath_cnt=0;	

    
           for ($WLAN."/wds/list/index")
           {   
               $index++;     
               $index_mac++;   
               $wds_mac = query($WLAN."/wds/list/index:".$index_mac."/mac");  
               if ($wds_mac!="")  
               {   
               	 	$up_ath_cnt++;    
               	 
               	 	echo "\necho UP WDS ath".$index."... > /dev/console\n";
               	 
 			if ($auth_mode==1 || $auth_mode==0 )  /*shared key or open*/  
                   	 {                                  
			   	    echo "ifconfig ath".$index." up\n";
			}else if ($auth_mode==3 || /*wpa-psk*/ 
                                             $auth_mode==5 || /*wpa2-psk*/  
                                             $auth_mode==7 || /*wpa-auto-psk*/     
                                             $auth_mode==2 || /*wpa-eap*/ 
                                             $auth_mode==4 || /*wpa2-eap*/  
                                             $auth_mode==6 || /*wpa-auto-eap*/           
                                             $auth_mode==9) /*802.1x*/
                        {            	
			
			         echo "ifconfig ath".$index." up\n"; 
                        } // end of wpa-psk and eap 
			
			echo "brctl addif br0 ath".$index."\n";
			
               }//if ($wds_mac!="")  
	
	  }//  for ($WLAN."/wds/list/index")
	
	
	}   //($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
	
	
        
    //~~~~~~~~~~APMDOE: ath0 add to br~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	

       echo "brctl addif br0 ".$wlanif."\n";

        
        
        
        
        
//**********************************demon up*******************************************

   //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MMSID:demon up~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   

    if ($multi_total_state == 1)
	{
	    $index=0; 
        $index1=0;
        for ($multi_ssid_path."/index")
	    {      
	        $index++;     
	        $IWPRIV="iwpriv ath".$index;
	        /*add schedule for multi-ssid by yuda start*/
	        $schedule_enable=query("/schedule/enable");
	        if ($schedule_enable==1)
	        {
	        	if(query($multi_ssid_path."/index:".$index."/schedule_rule_state")==1)
	        	{
	        		$multi_ind_schedule_state = query($multi_ssid_path."/index:".$index."/schedule_state");
	        	}
	        	else
	        	{
	        		$multi_ind_schedule_state = 1;
	        	}     	
	        }
	        else
	        {
	        	$multi_ind_schedule_state = 1;
	        }
	        
	        /*add schedule for multi-ssid by yuda end*/	    
	        
	        $multi_ind_state = query($multi_ssid_path."/index:".$index."/state");  
	        
	        if ($multi_ind_state==1 && $multi_ind_schedule_state == 1)  //add $multi_ind_schedule_state for schedule for multi-ssid by yuda   
	        { 	                   
               	echo "\necho UP MSSID-demon ath".$index."... > /dev/console\n";
               	$multi_auth = query($multi_ssid_path."/index:".$index."/auth");
	            $multi_cipher = query($multi_ssid_path."/index:".$index."/cipher");
	            $multi_ssid = query($multi_ssid_path."/index:".$index."/ssid");//query($multi_ssid_path."/index:".$index."/ssid");
	                      
	            /* Jack add 13/02/08 +++ wlxmlpatch_v2*/
                $wlxmlpatch_pid	= "/var/run/wlxmlpatch".$index.".pid_mssid";
                echo "wlxmlpatch -S ath".$index." /runtime/stats/wlan/inf:1/mssid:".$index." RADIO_SSID1_ON RADIO_SSID1_BLINK MADWIFI > /dev/console &\n";
                echo "echo $! > ".$wlxmlpatch_pid."\n";
                /* Jack add 13/02/08 --- wlxmlpatch_v2*/
	                
	                
                /*security +++*/


	                if ($multi_auth==3 || /*wpa-psk*/ 
	                    $multi_auth==5 || /*wpa2-psk*/  
	                    $multi_auth==7 || /*wpa-auto-psk*/     
	                    $multi_auth==2 || /*wpa-eap*/ 
	                    $multi_auth==4 || /*wpa2-eap*/  
	                    $multi_auth==6 || /*wpa-auto-eap*/           
	                    $multi_auth==9) /*802.1x*/           
	                {            
	                    $multi_interval = query($multi_ssid_path."/index:".$index."/interval"); 
	                    $lanif  = query("/runtime/layout/lanif");  
	                    $hostapd_pid	= "/var/run/hostapd0".$index.".pid";          
	                    $hostapd_conf	= "/var/run/hostapd0".$index.".conf";
	                    if ($multi_auth==3 || $multi_auth==2)          {   $wpa_hostapd    = 1; } /*wpa*/
	                    else if ($multi_auth==5 || $multi_auth==4)     {   $wpa_hostapd    = 2; } /*wpa2*/
	                    else if ($multi_auth==7 || $multi_auth==6)     {   $wpa_hostapd    = 3; } /*wpa-auto*/
	                    else if ($multi_auth==9)     {   $wpa_hostapd    = 0; } /*802.1x*/
                     
	                    // open hostapd0x.conf                                     
	                    fwrite($hostapd_conf,
	                    	"interface=ath".$index."\n".
	                    	"bridge=".$lanif."\n".
	                    	"driver=madwifi\n".
	                    	"logger_syslog=0\n".
	                    	"logger_syslog_level=0\n".
	                    	"logger_stdout=0\n".
	                    	"logger_stdout_level=0\n".
	                    	"debug=0\n".
	                    	"eapol_key_index_workaround=0\n".
	                    	"ssid=".$multi_ssid."\n".
	                    	"wpa=".$wpa_hostapd."\n");	                    	
	                    
	                        // Group key rekey interval 
	                        if ($multi_interval!="")	{ fwrite2($hostapd_conf, "wpa_group_rekey=".$multi_interval."\n"); }
	                        
	                        // Cipher mode 
	                        if		($multi_cipher==2)	{ fwrite2($hostapd_conf, "wpa_pairwise=TKIP\n"); }
	                        else if	($multi_cipher==3)	{ fwrite2($hostapd_conf, "wpa_pairwise=CCMP\n"); }
	                        else if	($multi_cipher==4)	{ fwrite2($hostapd_conf, "wpa_pairwise=TKIP CCMP\n"); }
	                        
	                        /* 1. psk*/
	                        if ($multi_auth==3 || /*wpa-psk*/ 
	                            $multi_auth==5 || /*wpa2-psk*/  
	                            $multi_auth==7)   /*wpa-auto-psk*/  
	                        {
	                            // Passphrase //
	                        if(query("/wlan/inf:1/multi/index:".$index."/autorekey/enable")==1 && query("/runtime".$multi_ssid_path."/index:".$index."/passphrase")!="")//add for autoredey by yuda
	                        {
	                        	$multi_passphrase = query("/runtime".$multi_ssid_path."/index:".$index."/passphrase");
	                        }
	                        else if(query($multi_ssid_path."/index:".$index."/passphrase")!="")
	                        {
	                            	$multi_passphrase = query($multi_ssid_path."/index:".$index."/passphrase");
	                        }
	                        else
	                        {
	                        	$multi_passphrase = 00000000;
	                        }
	                        
	                            fwrite2($hostapd_conf,
	                        		"wpa_key_mgmt=WPA-PSK\n".
	                        		"wpa_passphrase=".$multi_passphrase."\n");
	                        }
	                        /* 2. eap*/
	                        else if ($multi_auth==2 || /*wpa-eap*/ 
	                                 $multi_auth==4 || /*wpa2-eap*/  
	                                 $multi_auth==6 || /*wpa-auto-eap*/ 
	                                 $multi_auth==9) /*802.1x*/ 
	                        {                          
	                            $multi_radius_server = query($multi_ssid_path."/index:".$index."/radius_server");
	                            $multi_radius_port = query($multi_ssid_path."/index:".$index."/radius_port");
	                            $multi_radius_secret = query($multi_ssid_path."/index:".$index."/radius_secret");                        

		                    	if($multi_auth!=9)
								{
									fwrite2($hostapd_conf,"wpa_key_mgmt=WPA-EAP\n");
								}

	                            /* RADIUS settings */
		                        fwrite2($hostapd_conf,
		                    	"ieee8021x=1\n".
		                    	"auth_server_addr=".$multi_radius_server."\n".
		                    	"auth_server_port=".$multi_radius_port."\n".
		                    	"auth_server_shared_secret=".$multi_radius_secret."\n"); 

					                $multi_b_radius_server = query($multi_ssid_path."/index:".$index."/b_radius_server");
	                            	$multi_b_radius_port = query($multi_ssid_path."/index:".$index."/b_radius_port");
	                            	$multi_b_radius_secret = query($multi_ssid_path."/index:".$index."/b_radius_secret"); 
	                            		                    	
					if($multi_b_radius_server!="" && $multi_b_radius_port!="" && $multi_b_radius_secret!="")
					{
						fwrite2($hostapd_conf,
								"auth_server_addr=".$multi_b_radius_server."\n".
								"auth_server_port=".$multi_b_radius_port."\n".
								"auth_server_shared_secret=".$multi_b_radius_secret."\n");
					}

					/* NAP Support */
					$VLAN_state = query("/sys/vlan_state");
					$NAP_enable	= query("/sys/vlan_mode");
					if ($VLAN_state == 1 && $NAP_enable!="")	{ fwrite2($hostapd_conf, "nap_enable=".$NAP_enable."\n");}

		                        /* accounting server   Jack add  multi_ssid 12/03/07 */	                         
			                    if (query($multi_ssid_path."/index:".$index."/acct_state")==1) /* accounting enable */
			                    {
			                    	fwrite2($hostapd_conf,
			                    		"own_ip_addr=".query("/wan/rg/inf:1/static/ip")."\n".
			                    		"nas_identifier=".query("/runtime/layout/lanmac")."\n".
			                    		"acct_server_addr=".query($multi_ssid_path."/index:".$index."/acct_server")."\n".
			                    		"acct_server_port=".query($multi_ssid_path."/index:".$index."/acct_port")."\n".
			                    		"acct_server_shared_secret=".query($multi_ssid_path."/index:".$index."/acct_secret")."\n");
			                    		
						$multi_b_acct_server = query($multi_ssid_path."/index:".$index."/b_acct_server");
		                            	$multi_b_acct_port = query($multi_ssid_path."/index:".$index."/b_acct_port");
		                            	$multi_b_acct_secret = query($multi_ssid_path."/index:".$index."/b_acct_secret"); 
			                    	
			                    	if($multi_b_acct_server!="" && $multi_b_acct_port!="" && $multi_b_acct_secret!="")
			                    	{
							fwrite2($hostapd_conf,
									"acct_server_addr=".$multi_b_acct_server."\n".
									"acct_server_port=".$multi_b_acct_port."\n".
									"acct_server_shared_secret=".$multi_b_acct_secret."\n");			                    		
			                    	}
			                    }
								/* Disable EAP reauthentication */
								fwrite2($hostapd_conf, "eap_reauth_period=0\n");

								/* Radius Retry Primary Interval */
								fwrite2($hostapd_conf, "radius_retry_primary_interval=600\n");

								/* 802.1x support for dynamic WEP keying */
								if ($multi_auth == 9)
								{
									$DyWepKeyLen	= query($multi_ssid_path."/index:".$index."/d_wepkeylen");
									$DyWepRKeyInt	= query($multi_ssid_path."/index:".$index."/d_wep_rekey_interval");
									/* Key lengths , 5 = 64-bit , 13 = 128-bit (default: 128-bit) */
									if ($DyWepKeyLen == 64)
									{
										fwrite2($hostapd_conf, "wep_key_len_unicast=5\n");
										fwrite2($hostapd_conf, "wep_key_len_broadcast=5\n");
									}
									else/* $DyWepKeyLen == 128 */
									{
										fwrite2($hostapd_conf, "wep_key_len_unicast=13\n");
										fwrite2($hostapd_conf, "wep_key_len_broadcast=13\n");
									}

									/* Rekeying period in seconds (default:300 secs) */
									if ($DyWepRKeyInt != "")	{	fwrite2($hostapd_conf, "wep_rekey_period=".$DyWepRKeyInt."\n");	}
								}

	                        }    		
	                        echo "echo Start hostapd ... > /dev/console\n";
	                        echo "hostapd ".$hostapd_conf." &\n";
							echo "sleep 1\n";
	                        /*echo "echo $! > ".$hostapd_pid."\n";  */
	                } // end of wpa-psk and eap                                
	                else if ($multi_auth==1 || $multi_auth==0 )  /*shared key or open*/  
	                {                    
	                    echo "iwpriv ath".$index." authmode 1\n"; // set auth as open system first.                
			            /*   Jack modify 24/04/07 multi_ssid_temp_soluation_no_shared_key*/
			        if ($multi_auth==1) 
			        { 
			        	echo "iwpriv ath".$index." authmode 2\n";
			        } 
		                if ($multi_cipher==1)
		                {            
	                        $multi_key_index = query($multi_ssid_path."/index:".$index."/wep_key_index"); 
                            	$wep_key_path = $WLAN."/wepkey:".$multi_key_index;
	                        $multi_keylength	= query($wep_key_path."/keylength");
	                        $multi_keyformat	= query($wep_key_path."/keyformat");
	                        $multi_key =          query($wep_key_path); 
	                        /*
		                    *	For ASCII string:
		                    *		iwconfig ath0 key s:"ascii" [1]
		                    *	For Hex string:
		                    *		iwconfig ath0 key "1234567890" [1]
		                    */
		                    if ($multi_keyformat==1)	
		                    { 
		                    	$iw_keystring="s:\"".$multi_key."\" [".$multi_key_index."]";
		                    }
		                    else
		                    { 
		                    	$iw_keystring=$multi_key." [".$multi_key_index."]";/*$iw_keystring="\"".query("wepkey:".$defkey)."\" [".$defkey."]"; */}
			                echo "iwconfig ath".$index." key ".$iw_keystring."\n"; 
			                echo "iwconfig ath".$index." key [".$multi_key_index."]\n"; 
			            }	
	                }
                /*security ---*/
                
                
                  /* IGMP Snooping dennis 2008-01-29 start*/
					if ($igmpsnoop == 1){
						echo "echo enable > /proc/net/br_igmp_ap_br0\n";
						echo "echo setwl ath".$index." > /proc/net/br_igmp_ap_br0\n";
						echo "ap_igmp &> /dev/console\n";
						echo "echo $! > /var/run/ap_igmp_".$index.".pid\n";
					}
					if ($igmpsnoop == 1){ echo "brctl igmp_snooping br0 ".$igmpsnoop."\n"; }
					else {  echo "brctl igmp_snooping br0 0\n";  }
				/* IGMP Snooping dennis 2008-01-29 end */
               
                
	        }  // end of if ($multi_ind_state==1)  
	    }  // end of for ($multi_ssid_path."/index")
    } // end of ($multi_total_state == 1)
        

   //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~WDS:demon up~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
       if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
	{

	
	   $index=7;
           $index_mac=0;
           $up_ath_cnt=0;	
           
 
           for ($WLAN."/wds/list/index")
           {   
               $index++;     
               $index_mac++;   
               $wds_mac = query($WLAN."/wds/list/index:".$index_mac."/mac");  
               if ($wds_mac!="")  
               {   
               	 	$up_ath_cnt++;    
               	 
               	 	echo "\necho UP WDS-demon ath".$index."... > /dev/console\n";
               	 
                        /* Jack add 13/02/08 +++ wlxmlpatch_v2*/
                        $index_tmp = $index-7;
		        $wlxmlpatch_pid	= "/var/run/wlxmlpatch".$index_tmp.".pid_wds";
		        echo "wlxmlpatch -S ath".$index." /runtime/stats/wlan/inf:1/wds:".$index_tmp." RADIO_SSID1_ON RADIO_SSID1_BLINK MADWIFI > /dev/console &\n";
		        echo "echo $! > ".$wlxmlpatch_pid."\n";
                        /* Jack add 13/02/08 --- wlxmlpatch_v2*/
                        
  		        /* IGMP Snooping dennis 2008-01-29 start*/
		      if($withoutap == 0 ){//wds with ap mode
		 	   if ($igmpsnoop == "1"){
		 	    echo "echo enable > /proc/net/br_igmp_ap_br0\n";
		 	    echo "echo setwl ath".$index." > /proc/net/br_igmp_ap_br0\n";
		 	    echo "ap_igmp &> /dev/console\n";
		 	    echo "echo $! > /var/run/ap_igmp_".$index.".pid\n";
		           }
		           if ($igmpsnoop!=""){ echo "brctl igmp_snooping br0 ".$igmpsnoop."\n"; }
		           else {  echo "brctl igmp_snooping br0 0\n";  }
		       }
			/* IGMP Snooping dennis 2008-01-29 end */
            if($withoutap == 1 ){
			    echo "brctl igmp_snooping br0 0\n";  
			}
			/* IGMP Snooping dennis 2008-01-29 end */

                        
                        
 			if ($auth_mode==1 || $auth_mode==0 )  /*shared key or open*/  
                   	 {     
                   	 	                             			 
			}else if ($auth_mode==3 || /*wpa-psk*/ 
                                             $auth_mode==5 || /*wpa2-psk*/  
                                             $auth_mode==7 || /*wpa-auto-psk*/     
                                             $auth_mode==2 || /*wpa-eap*/ 
                                             $auth_mode==4 || /*wpa2-eap*/  
                                             $auth_mode==6) /*wpa-auto-eap*/           
                        {           
                        	
                        	$wpa_supplicant_conf = "/var/run/wpa_supplicant".$index.".conf_wds";
			        $wpa_supplicant_pid = "/var/run/wpa_supplicant".$index.".pid_wds";
                        	$hostapd_conf	= "/var/run/hostapd".$index.".conf_wds";
			        $hostapd_pid	= "/var/run/hostapd".$index.".pid_wds";
                        	echo "HorS=\`rstrcmp -s ".$lan_mac." -S ".$wds_mac."`\n";
			        echo "if [ $HorS -ge 0 ] ; then\n";
			        echo "echo Start hostapd".$index."_wds ... > /dev/console\n";
                                echo "hostapd -B ".$hostapd_conf." &\n";
                                /*echo "echo $! > ".$hostapd_pid."\n";*/
                                echo "rm -f ".$wpa_supplicant_conf."\n";
			        echo "else\n";
			        echo "echo Start wpa_supplicant".$index."_wds ... > /dev/console\n";
			        echo "wpa_supplicant -i ath".$index." -c ".$wpa_supplicant_conf." -Dmadwifi -w -B\n";
			        /*echo "echo $! > ".$wpa_supplicant_pid."\n";*/
			        echo "rm -f ".$hostapd_conf."\n";
			// echo "ifconfig ath".$index." up\n"; 
			         echo "fi\n";
					 echo "sleep 1\n";

                        } // end of wpa-psk and eap 

		         

               }// if ($wds_mac!="")
	
	
	}//  for ($WLAN."/wds/list/index")
	

	} //      if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)  
   


        
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~APMODE:demon  up~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
	echo "wlxmlpatch -S ".$wlanif." /runtime/stats/wlan/inf:1 RADIO_SSID1_ON RADIO_SSID1_BLINK MADWIFI > /dev/console &\n";
	echo "echo $! > ".$wlxmlpatch_ap_pid."\n";
	//if($txpower>1){
	//	echo "iwlist ath0 txpower\n";
	//	echo "ifconfig ath0 down\n";
	//	echo "brctl delif br0 ".$wlanif."\n";
	//	echo "sh /etc/templates/txpower.sh\n";
	//	echo "ifconfig ath0 up\n";
	//	echo "brctl addif br0 ".$wlanif."\n";
	//	echo "sleep 5\n";
	//}

	/* IGMP Snooping dennis 2008-01-29 start*/
	//if ($igmpsnoop == 1){

	//		echo "brctl igmp_snooping br0 1\n";
	//		echo "echo enable > /proc/net/br_igmp_ap_br0\n";
	//		echo "echo setwl ath0 > /proc/net/br_igmp_ap_br0\n";
	//		echo "ap_igmp &> /dev/console\n";
	//		echo "echo $! > ".$ap_igmp_pid."\n";
	//	  	
	//	}
//	else{
//		echo "brctl igmp_snooping br0 0\n";
//	}
	/* IGMP Snooping dennis 2008-01-29 end */
	/* ethernet integration dennis2008-02-05 start */
//	if ($ethlink==1){
//		echo "brctl ethlink br0 ".$ethlink."\n";
//	}
//	else{
//		echo "brctl ethlink br0 0\n";
//	}
	/* ethernet integration dennis2008-02-05 end */
	
	
	/* authentication mode
	 *	0:open, 1:shared, 2:WPA, 3:WPA-PSK, 4:WPA2,
	 *	5:WPA2-PSK, 6:WPA+WPA2, 7:WPA-PSK + WPA2-PSK, 8:802.1x
	 */
	
      
	echo "iwlist ath0 compare\n";	
	if($txpower>1){
		echo "iwlist ath0 txpower\n";
	//	echo "ifconfig ath0 down\n";
	//	echo "brctl delif br0 ath0\n";
	//	echo "sh /etc/templates/txpower.sh\n";
	//	echo "ifconfig ath0 up\n";
	//	echo "brctl addif br0 ath0\n";
	//	echo "sleep 5\n";
	}
	/* IGMP Snooping dennis 2008-01-29 start*/
	if ($igmpsnoop == 1){
	echo "brctl igmp_snooping br0 1\n";
	echo "echo enable > /proc/net/br_igmp_ap_br0\n";
	echo "echo setwl ath0 > /proc/net/br_igmp_ap_br0\n";
	echo "ap_igmp &> /dev/console\n";
	echo "echo $! > ".$ap_igmp_pid."\n";
	}
	else{
	echo "brctl igmp_snooping br0 0\n";
	}
    /* IGMP Snooping dennis 2008-01-29 end */
	if ($ethlink==1){
	echo "brctl ethlink br0 ".$ethlink."\n";
	}
	else{
	echo "brctl ethlink br0 0\n";
	}

	if ($band == $A_BAND)	
	{
		echo "gpioc -o 19 \n";
		echo "gpioc -w 19 \n";
		echo "gpioc -e 19 \n";	
	  echo "rgdb -i -s /runtime/stats/wireless/led11a 1\n";
	}
	else
	{
		echo "gpioc -o 20 \n";
		echo "gpioc -w 20 \n";
		echo "gpioc -e 20 \n";	
    echo "rgdb -i -s /runtime/stats/wireless/led11g 1\n";
	}

} // end of ($generate_start==1)
else
{
    
	
}  // end of else ($generate_start!=1)
?>
