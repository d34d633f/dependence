#!/bin/sh
<? /* vi: set sw=4 ts=4: */
if ($SERVDSTART=="1")
{
	echo "rgdb -i -s /wlan/inf:1/multi/index:1/schedule_state 1\n";
	echo "service WLAN restart\n";

}
else
{
	echo "rgdb -i -s /wlan/inf:1/multi/index:1/schedule_state 0\n";
	$enable_flag="0";
	$index=1;
	if(query("/wlan/inf:1/multi/index:0/schedule_state")==1)
	{
		$enable_flag="1";
	}
	for("/wlan/inf:1/multi/index")
	{		
		if(query("/wlan/inf:1/multi/index:".$index."/schedule_state")==1)
		{
			$enable_flag="1";
		}
		$index++;
	}
	if(query("/wlan/inf:1/multi/index:0/schedule_rule_state")!="1")
	{
		$enable_flag="1";
	}	
	if($enable_flag=="1")
	{
		echo "service WLAN restart \n";
	}
	else
	{
		echo "service WLAN stop \n";
	}
}
?>
