<!--# exec cgi /bin/cmo_get_list wireless_ap_list 24g -->                                           
