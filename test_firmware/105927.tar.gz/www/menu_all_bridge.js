/**
 * menuObject
 *  - 
 * author: Moa Chung
 * date:   2013-08-22
 * notice: 
 */
function menuObject() {
	this.v4v6;
	this.usb;
	var changes_count = '<!--# uci_changes_count -->';
	//main
	var advanced_L1 =
		[
			{title:'_apply_discard',page:'adm_changes_bridge.asp'},
			{title:'_status',img:'but_network_status'},
			{title:'_system',img:'but_setup'},
			{title:'_wireless',img:'but_wireless'},
			{title:'_management',img:'but_administrator'}
		];
	var advanced_L2 = [
		//save&reload(0)
		[],
		//status(1)
		[
			{title:'_status',page:'adm_status_bridge.asp'},
			{title:'_conn_status',page:'w_connstatus.asp'}
		],
		//system(2)
		[
			{title:'device_mode',page:'adm_oper.asp'},
			{title:'_ip_set',page:'adm_ipset.asp'}
		],
		//wireless 5GHz(4)
		[
			{title:'_wireless_network',page:'w1_network_sta.asp'}
		],
		//Management(5)
		[
			{title:'_adminsttn',page:'adm_mgmt.asp'},
			{title:'_br_set',page:'adm_settings_bridge.asp'},
			{title:'_upload_firm',page:'adm_upload_fw.asp'},
			{title:'_system_log',page:'adm_syslog_bridge.asp'},
			{title:'_time_cap',page:'adm_time_bridge.asp'}
		]
	];

	this.build_structure = function(category, idx, sub_idx)
	{
		var content_main="";
		var which;
		var total;
		which = advanced_L1;
		//total = (this.usb?which.length:--which.length);
		total = which.length;
		content_main += '<div class="arrowlistmenu">';
//		content_main += '<div class="homenav" style="margin-bottom:20px;"></div>';
//		content_main += '<div class="borderbottom"> </div>';
		for(var i=0; i<total; i++)
		{
			var img_str = '', class_str = '', click_str = '', title_str = '';
			var title_lang;

			if (which[i].img)
				img_str = which[i].img;

			if (which[i].page)
				click_str = 'onclick="menuObject.animoa(this,\''+ which[i].page +'\');"';
			else
				click_str = 'onclick="menuObject.animoa(this);"';

			if (i == idx) {
				class_str = 'class="menuheader expandable openheader"';
				if (img_str)
					img_str = '<img src="/image/'+which[i].img+'_1.png" class="CatImage" />';
			} else {
				class_str = 'class="menuheader expandable closeheader"';
				if (img_str)
					img_str = '<img src="/image/'+which[i].img+'_0.png" class="CatImage" />';
			}

			title_lang = get_words(which[i].title);
			if (i == 0) {
				title_lang += ' ' + changes_count;
				if (changes_count > 0) {
					if (img_str)
						title_str = '<span class="unsaved_blink">'+ title_lang +'</span></div>';
					else
						title_str = '<span class="unsaved_blink" style="font: bold 16px Arial;">'+ title_lang +'</span></div>';
				} else {
					if (img_str)
						title_str = '<span class="CatTitle">'+ title_lang +'</span></div>';
					else
						title_str = '<span class="CatTitle" style="font: bold 16px Arial;">'+ title_lang +'</span></div>';
				}
			} else {
				if (which[i].style)
					title_str = '<span class="CatTitle" style="' + which[i].style +'">'+ title_lang +'</span></div>';
				else
					title_str = '<span class="CatTitle">'+ title_lang +'</span></div>';
			}
			content_main += '<div><div ' + click_str + ' ' + class_str + '>' +
					img_str + title_str;
			content_main += this.build_sub_structure(category, i, sub_idx, (i == idx));
			content_main += '</div>';
		}
		content_main += '</div>';
		//$("#main_title").html(content_main);
		return content_main;
	};

	this.build_sub_structure = function(category, idx, sub_idx, expand)
	{
		var which = new Array();
		var content_sub='';

		which = advanced_L2[idx];
		if(expand)
			content_sub += '<ul class="categoryitems">';
		else
			content_sub += '<ul class="categoryitems" style="display:none;">';
		for(var j=0; j<which.length; j++)
		{
			if(j==sub_idx && expand)
				content_sub += '<li><a href="'+ which[j].page +'" style="color:#00aff0;">'+ (which[j].pretitle?which[j].pretitle:'') + get_words(which[j].title) +'</a></li>';
			else
				content_sub += '<li><a href="'+ which[j].page +'">' + (which[j].pretitle?which[j].pretitle:'') + get_words(which[j].title) +'</a></li>';
		}
		content_sub += '</ul>';
		return content_sub;
	};
	
	this.setSupportUSB = function(is){
		this.usb = is;
	};
}

menuObject.animoa = function(node, redirect){
//	console.log(redirect);
	var src = $('.menuheader.expandable.openheader').find('img').attr('src');
	if(src != undefined)
		$('.menuheader.expandable.openheader').find('img').attr('src', src.replace('_1.','_0.'));
	$('.menuheader.expandable.openheader').toggleClass('openheader').toggleClass('closeheader');
	$(node).toggleClass('closeheader').toggleClass('openheader');
	src = $(node).find('img').attr('src');
	if(src != undefined)
		$(node).find('img').attr('src', src.replace('_0.','_1.'));
	$('.categoryitems').slideUp();
	$(node).parent().children('ul').slideDown(400, function(){
		if(redirect!=undefined)
			location.assign(redirect);
	});
};
