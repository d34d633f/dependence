#!/bin/sh

PATH_TRANSLATED= PATH_INFO=/save_log_page.cgi REQUEST_METHOD=POST /www/cgi/ssi
