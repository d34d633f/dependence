<!--# exec cgi /bin/mjson sta_connection_status apclii0 -->
