#!/bin/sh

PATH_TRANSLATED= PATH_INFO=/save_configure.cgi REQUEST_METHOD=GET /www/cgi/ssi
