<!--# exec oneline_cgi autofw remote get_fw json_start -->
