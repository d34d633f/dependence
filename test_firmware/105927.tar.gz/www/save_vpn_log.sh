#!/bin/sh

PATH_TRANSLATED= PATH_INFO=/save_vpn_log.cgi REQUEST_METHOD=POST /www/cgi/ssi
