<!--# exec cgi autofw remote get_fw json_status -->
