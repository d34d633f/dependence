var g_strManufacturer=;
var g_strBoard=;
