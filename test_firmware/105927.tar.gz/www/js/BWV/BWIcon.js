/*
 * Copyright (c) 2014 Qualcomm Atheros, Inc.
 *
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary
 */
////////////////////////////////////////////////////////////////////////
/*
    Class: BWIcon
    Version:   1.0

    Bandwidth View Icon for the Dual graph node view and subview
*/
////////////////////////////////////////////////////////////////////////
