/*
 * Copyright (c) 2014 Qualcomm Atheros, Inc.
 *
 * All Rights Reserved.
 * Qualcomm Atheros Confidential and Proprietary
 */
////////////////////////////////////////////////////////////////////////
/*
    Class: BWLabel
    Version:   1.0

    Bandwidth View Label for items and sub items
*/
////////////////////////////////////////////////////////////////////////
