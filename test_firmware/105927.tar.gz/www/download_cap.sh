#!/bin/sh

PATH_TRANSLATED= PATH_INFO=/download_cap.cgi REQUEST_METHOD=GET /www/cgi/ssi
