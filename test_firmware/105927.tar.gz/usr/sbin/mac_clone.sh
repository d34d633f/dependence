#!/bin/sh

CHANGEMODE=`uci get gxbk.changemode.mode`

if [ x${CHANGEMODE} != x"Router" ]; then
	echo NOT Router mode
	echo 0 > /proc/sys/net/bridge/local_mac_enable
	return
fi

IPV6_BRIDGE_ENABLE=`uci get gxbk.ipv6_bridge.enabled`

if [ x"${IPV6_BRIDGE_ENABLE}" != x"1" ]; then
	echo NOT ipv6 bridge enable
	echo 0 > /proc/sys/net/bridge/local_mac_enable
	return
fi

wan_mac=`uci -q get network.wan.macaddr`

if [ "$wan_mac" == "" ]; then
echo NO WAN MAC Clone

echo 0 > /proc/sys/net/bridge/local_mac_enable

else
echo WAN MAC Clone $wan_mac

echo 1 > /proc/sys/net/bridge/local_mac_enable
echo -n $wan_mac > /proc/sys/net/bridge/local_mac_mac

fi



	
	
	
	
	
	
	
	

