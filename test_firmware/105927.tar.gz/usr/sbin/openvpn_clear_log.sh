#!/bin/sh

killall -SIGUSR2 openvpn


