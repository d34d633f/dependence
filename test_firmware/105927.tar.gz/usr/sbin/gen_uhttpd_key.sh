#!/bin/sh


mkdir -p /tmp/ukey
https_private=/tmp/ukey/private
https_public=/tmp/ukey/server
manufacturer=TRENDNET
https_ca=/tmp/ukey/ca

utmpkey=/tmp/ukey/uhttpd.key
utmpcrt=/tmp/ukey/uhttpd.crt

ukey=/etc/uhttpd.key
ucrt=/etc/uhttpd.crt

openssl genrsa 1024 > $https_private
openssl req -new -key $https_private -x509 -days 9999 -nodes -out $https_public -batch -subj "/O=$manufacturer" 
cat $https_private $https_public > $https_ca

openssl rsa -in $https_private -outform DER -out $utmpkey
openssl x509 -in $https_public -outform DER -out $utmpcrt

cp -f $utmpkey $ukey
cp -f $utmpcrt $ucrt
