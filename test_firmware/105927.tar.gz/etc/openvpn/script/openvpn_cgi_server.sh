#!/bin/sh

mkdir -p /etc/openvpn/keys
mkdir -p /etc/openvpn/lastclient

echo 0 > /tmp/gen_openkey

# gen ca
/etc/openvpn/script/openvpn_genca.sh

# copy dh1024
cp -f /etc/openvpn/defserverkey/dh1024.pem /etc/openvpn/keys

# gen server
/etc/openvpn/script/openvpn_genserver.sh

echo 1 > /tmp/gen_openkey

