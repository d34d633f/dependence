#!/bin/sh

clean-all

cp -f /etc/openvpn/keys/ca.crt /etc/easy-rsa/keys 
cp -f /etc/openvpn/keys/ca.key /etc/easy-rsa/keys


build-key-server --batch server

cp -f /etc/easy-rsa/keys/server.crt /etc/openvpn/keys
cp -f /etc/easy-rsa/keys/server.key /etc/openvpn/keys


