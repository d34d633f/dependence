#!/bin/sh


CONSOLE=/dev/console
echo CheckVPN user/pass [${username}] [${password}] > $CONSOLE



check_ok=0

a=0
a_max=15

while [ 1 ]
do 

#echo $a
#
#

name_str="vpnuser.@openvpn[$a].username"
pass_str="vpnuser.@openvpn[$a].password"


name=`uci get -q $name_str`
pass=`uci get -q $pass_str`


echo [$name] [$pass] >  $CONSOLE


if [ "$name" == "" ]; then
	break;
fi

if [ "$name" == "$username" ]  && [ "$pass" == "$password" ]; then
	check_ok=1
	break
fi

a=$((a+1))
if [ "$a" == "$a_max" ]; then
	break
fi



done


if [ "$check_ok" == "1" ]; then
	exit 0
fi

# exit 0 successful

exit 1


