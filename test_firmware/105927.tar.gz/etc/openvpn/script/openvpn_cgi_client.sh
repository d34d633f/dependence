#!/bin/sh

mkdir -p /etc/openvpn/keys
mkdir -p /etc/openvpn/lastclient

/etc/openvpn/script/openvpn_genclient.sh


