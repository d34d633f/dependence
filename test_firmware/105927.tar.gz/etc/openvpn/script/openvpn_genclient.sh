#!/bin/sh

clean-all

cp -f /etc/openvpn/keys/ca.crt /etc/easy-rsa/keys 
cp -f /etc/openvpn/keys/ca.key /etc/easy-rsa/keys


build-key --batch client

cp -f /etc/easy-rsa/keys/client.crt /etc/openvpn/lastclient
cp -f /etc/easy-rsa/keys/client.key /etc/openvpn/lastclient


