#!/bin/sh

clean-all
build-ca --batch

cp -f /etc/easy-rsa/keys/ca.crt /etc/openvpn/keys
cp -f /etc/easy-rsa/keys/ca.key /etc/openvpn/keys


