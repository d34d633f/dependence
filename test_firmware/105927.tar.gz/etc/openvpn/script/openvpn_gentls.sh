#!/bin/sh

openvpn --genkey --secret /etc/openvpn/keys/ta.key



