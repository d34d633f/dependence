#!/bin/sh

clean-all
build-dh

cp -f /etc/easy-rsa/keys/dh1024.pem /etc/openvpn/keys


