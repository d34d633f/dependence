#!/bin/sh

MODEL_NAME="TEW-827DRU"
echo_tlv()
{
    echo "[Type]$1[Length]${#2}[Value]$2"
}

dut_info()
{
    #echo_tlv_from_nvram "0x0001" "model_name"
    echo "[Type]0x0001[Length]${#MODEL_NAME}[Value]${MODEL_NAME}"
    
    #echo_tlv_from_nvram "0x0002" "hardware_version"
    hw_ver="$(uci get cameo.system.hw_version)"
    echo "[Type]0x0002[Length]${#hw_ver}[Value]${hw_ver}"
    
    #country=`nvram get wl_country_code`
    #countryid=`cat /etc/bulk/channeldomain.txt |grep $country|cut -d '	' -f 2`
    #echo "[Type]0x000C[Length]${#countryid}[Value]${countryid}"
    wifi_domain="$(uci get cameo.system.wlan0_domain)"
    echo "[Type]0x000C[Length]${#wifi_domain}[Value]${wifi_domain}"
    
    #Isdefault
    #echo_tlv "0x0004" "1"
    Isdefault="$(uci get cameo.cameo.setup_wizard_rt)"
    if [ "$Isdefault" = "1" ];then
    	echo_tlv "0x0004" "1"
    else
    	echo_tlv "0x0004" "0"	
    fi
    
    #echo_tlv_from_nvram "0x0005" "sys_trx_ver"
    fw_ver="$(uci -q get cameo.system.fw_version_build)"
    echo "[Type]0x0005[Length]${#fw_ver}[Value]${fw_ver}"
    
    #echo_tlv "0x0006" "0"
    
    #echo_tlv_from_nvram "0x0009" "et0macaddr"
    lan_mac="$(eth_mac r lan | tr [a-z] [A-Z])"
    echo "[Type]0x0009[Length]${#lan_mac}[Value]${lan_mac}"
    
    #echo_tlv_from_nvram "0x000A" "wl0_hwaddr"
    if [ $MODEL_NAME = "DWL-6610APB1" ];then
        echo_tlv_from_nvram "0x000B" "sb/1/macaddr"
        echo_tlv_from_nvram "0x000A" "0:macaddr"
        echo_tlv_from_nvram "0x0010" "wl2_ssid"
        echo_tlv_from_nvram "0x0011" "wl0_ssid"
    elif [ "$MODEL_NAME" = "TEW-827DRU" ];then
        wlan_mac_2g="$(uci -q get qcawifi.wlan0.macaddr | tr [a-z] [A-Z])"
        wlan_mac_5g="$(uci -q get qcawifi.wlan1.macaddr | tr [a-z] [A-Z])"
        wlan_ssid_2g="$(fw_getenv wlan0_ssid 2>/dev/null)"
        wlan_ssid_5g="$(fw_getenv wlan1_ssid 2>/dev/null)"
        wpakey_2g="$(fw_getenv wlan0_key 2>/dev/null)"
        wpakey_5g="$(fw_getenv wlan1_key 2>/dev/null)"
        wps_pin="$(/sbin/wlan_cmd wps 5G get_pincode)"
        admin_password="$(fw_getenv admin_password)"

    	echo "[Type]0x000A[Length]${#wlan_mac_2g}[Value]${wlan_mac_2g}"
    	echo "[Type]0x0010[Length]${#wlan_ssid_2g}[Value]${wlan_ssid_2g}"
    	echo "[Type]0x0012[Length]${#wpakey_2g}[Value]${wpakey_2g}"
    	echo "[Type]0x000B[Length]${#wlan_mac_5g}[Value]${wlan_mac_5g}"
    	echo "[Type]0x0011[Length]${#wlan_ssid_5g}[Value]${wlan_ssid_5g}"
    	echo "[Type]0x001C[Length]${#wpakey_5g}[Value]${wpakey_5g}"
	echo "[Type]0x0013[Length]${#admin_password}[Value]${admin_password}"
	echo "[Type]0x0015[Length]${#wps_pin}[Value]${wps_pin}"

    else
        echo_tlv_from_nvram "0x000A" "sb/1/macaddr"
        echo_tlv_from_nvram "0x0010" "wl0_ssid"
    fi
    
    #SN=`nvram_get uboot SN`
    #echo "[Type]0x0018[Length]${#SN}[Value]${SN}"
    
    #echo_tlv_from_nvram "0x001A" "mp_boardid"
    BoardID="$(fw_getenv board_id 2>/dev/null)"
    echo "[Type]0x001A[Length]${#BoardID}[Value]${BoardID}"

    # 3610/6610
    #echo_tlv_from_nvram "0x0014" "sys_cfe_crc32"
    #checksum=`uci get cameo.system.checksum`
    #echo "[Type]0x0014[Length]${#checksum}[Value]${checksum}"
    checksum="$(/bin/checksum)"
    echo "[Type]0x0014[Length]${#checksum}[Value]${checksum}"
    
    #echo_tlv_from_nvram "0x0017" "sys_trx_crc32"
    #echo_tlv_from_nvram "0x0018" "serial#"
}

dut_info > /var/tmp/DUTinfo_file

