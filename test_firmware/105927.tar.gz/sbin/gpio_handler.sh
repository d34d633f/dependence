#!/bin/sh

last_wan_reg=$(mii_mgr -g -p 4 -r 1 | sed 's/.*= //g')

while [ true ]; do

	# get wan cable status (value="796d" -> connected)
	wan_reg=$(mii_mgr -g -p 4 -r 1 | sed 's/.*= //g')
	if [ "$wan_reg" == "796d" ]; then
		wan_cable="connect"
	else
		wan_cable="disconnect"
	fi

	if [ "$wan_reg" != "$last_wan_reg" ]; then
		lan_proto=$(uci get network.lan.proto 2>/dev/null)
		wan_proto=$(uci get network.wan.proto 2>/dev/null)
		if [ "$wan_cable" = "connect" ]; then
			uci set cameo.wan.cable_connect=1
			if [ "$wan_proto" = "dhcp" -o "$lan_proto" = "dhcp" ]; then
				echo "gpio_handler: WAN cable reconnect -> send DHCP Discover" > /dev/console
				killall -SIGUSR1 udhcpc
			fi
		else
			uci set cameo.wan.cable_connect=0
			if [ "$wan_proto" = "dhcp" -o "$lan_proto" = "dhcp" ]; then
				killall -SIGUSR2 udhcpc
				echo "gpio_handler: WAN cable disconnect -> send DHCP Release" > /dev/console
			fi
		fi
	fi

	last_wan_reg=$wan_reg

	# read button status
	if [ "$(/sbin/gpio g 13 | sed 's/.*= //g')" = "0" ]; then

		reset_button_pushed="1"

		for default in $(seq 1 5)
		do
			if [ "$(/sbin/gpio g 13 | sed 's/.*= //g')" = "1" ]; then
				reset_button_pushed="0"
				break
			else
				echo "reset button pressed ($default/5)" > /dev/console
	                        sleep 1
			fi
		done

		if [ "$default" = "5" -a "$reset_button_pushed" = "1" ]; then
			firstboot
			echo "Restore default complete, device will reboot!!!" > /dev/console
			reboot
		fi
	fi

        sleep 1
done

