#!/bin/sh
wifi_mode=$(uci get gxbk.changemode.mode)
flag1=0
flag2=0
while [ 1 ]
do
        if [ "$wifi_mode" = "Router" ] || [ "$wifi_mode" = "AccessPoint" ]; then
                wifi_en=$(wlan_cmd clients ra0)
                wifi_2g_en=$(echo ${wifi_en} | awk '{print $1}' | awk -F ':' '{print $2}')
                wifi_5g_en=$(echo ${wifi_en} | awk '{print $2}' | awk -F ':' '{print $2}')

                if [ ${wifi_2g_en} -gt 0 ] && [ ${flag1} -eq 0 ]; then
                        mtk_led wifi 2g blink 2>&1 > /dev/null
                        flag1=1
                        sleep 1
                elif [ ${wifi_2g_en} -eq 0 ] && [ ${flag1} -eq 1 ]; then
                        mtk_led wifi 2g on 2>&1 > /dev/null
                        flag1=0
                fi
                if [ ${wifi_5g_en} -gt 0 ] && [ ${flag2} -eq 0 ]; then
                        sleep 1
                        mtk_led wifi 5g blink 2>&1 > /dev/null
                        flag2=1
                elif [ ${wifi_5g_en} -eq 0 ] && [ ${flag2} -eq 1 ]; then
                        mtk_led wifi 5g on 2>&1 > /dev/null
                        flag2=0
                fi
        else
                apcli0=$(iwconfig apcli0 | sed '2,3d' | awk '{print $4}' | sed 's/ESSID://g')
                apclix0=$(iwconfig apclix0 | sed '2,3d' | awk '{print $4}' | sed 's/ESSID://g')

                if [ ${apcli0} = "\"\"" ]; then
                        mtk_led wifi 5g off
                else
                        mtk_led wifi 5g on
                fi

                if [ ${apclix0} = "\"\"" ]; then
                        mtk_led wifi 2g off
                else
                        mtk_led wifi 2g on
                fi


        fi
        sleep 2
done
