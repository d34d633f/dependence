#!/bin/sh

if [ -z ${1} ] || [ -z ${2} ]; then
	echo "error argument"
	exit 0
fi

i=0
for ip in $(echo $1 | awk -F'.' '{print $1" "$2" "$3" "$4}')
do
	eval ip${i}=$ip
	i=$(($i+1))
done

i=0
for mask in $(echo $2 | awk -F'.' '{print $1" "$2" "$3" "$4}')
do
	eval mask${i}=$mask
	i=$(($i+1))
done

for i in $(echo $2 | awk -F'.' '{print $1" "$2" "$3" "$4}')
do
        j=7
        tag=1
        while [ $j -ge 0 ]
        do
          k=$((2**$j))          
          if [ $(( $i & $k )) -eq $k ]; then
                if [ $tag -eq 1 ]; then
                   n=$((n += 1))
                else
                   echo -e "\n$2 is a bad netamsk with holes\n"
                   exit
                fi
           else
                tag=0
           fi
           j=$((j -= 1))
          done
done

for i in 0 1 2 3
do
	cmd="echo \$ip${i}"
	ipp=`eval $cmd`
	cmd="echo \$mask${i}"
	mmask=`eval $cmd`
a=$a${a:+.}$((${ipp} & ${mmask}))
b=$b${b:+.}$((${ipp} | (${mmask} ^ 255)))
done

echo
echo Network number:$a
echo Broadcast address:$b
echo Netmask bits:$n
