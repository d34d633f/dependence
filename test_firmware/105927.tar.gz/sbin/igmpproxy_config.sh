#!/bin/sh

wan=eth3
lan=br-lan

opticalTVmode_start() {
	
	TVmode_2G=$(uci get ghbk.wifi0.opticalTVmode 2>/dev/null)
	TVmode_5G=$(uci get ghbk.wifi1.opticalTVmode 2>/dev/null)

	case $1 in
		"both")
			if [ "$TVmode_2G" = "1" ] && [ "$TVmode_5G" = "1" ]; then
				igmpproxy -w ra0 -w rai0
			elif [ "$TVmode_2G" = "1" ]; then
				igmpproxy -w ra0
			elif [ "$TVmode_5G" = "1" ]; then
				igmpproxy -w rai0
			fi
			;;
		"2.4G")
			if [ "$TVmode_2G" = "1" ]; then
				igmpproxy -w ra0
			fi
			;;
		"5G")
			if [ "$TVmode_5G" = "1" ]; then
				igmpproxy -w rai0
			fi
			;;
		*)
			echo "igmpproxy not run"
			;;
	esac

}

igmpproxy_start() {

	mode=$(uci get ghbk.changemode.mode 2>/dev/null)

	if [ "$mode" = "Router" ] || [ "$mode" = "AccessPoint" ]; then

		ra0_disabled=$(uci get wireless.main2_4.disabled 2>/dev/null)
		rai0_disabled=$(uci get wireless.main5.disabled 2>/dev/null)

		if [ "$ra0_disabled" = "0" ] && [ "$rai0_disabled" = "0" ]; then
			opticalTVmode_start both
		elif [ "$ra0_disabled" = "0" ]; then
			opticalTVmode_start 2.4G
		elif [ "$rai_disabled" = "0" ]; then
			opticalTVmode_start 5G
		fi
		
	fi
}

case $1 in
	"start")
		killall igmpproxy
		rm /etc/igmpproxy.conf
		igmpproxy.sh $wan $lan
		igmpproxy_start
		;;
	*)
		echo "igmpproxy start fail"
		;;
esac
