#!/bin/sh
max_blink=5

led_process()
{
	mtk_led mp on	

	mtk_led wifi 2.4G blink
	mtk_led wifi 5G blink
}

led_finish()
{
	mtk_led mp on

	mtk_led wifi 2.4G blink
	mtk_led wifi 5G blink
	mtk_led power blink
}

led_fail()
{
	mtk_led mp on	
	mtk_led power blink
}

led_notsupport()
{
	led_fail
}

led_success()
{
	echo "led_success not implement!!"
}

case $1 in
        "0")
                led_notsupport
                ;;
        "1")
                led_fail
                ;;
        "2")
                led_process
                ;;
        "3")
                led_success
                ;;
        "4")
                led_finish
                ;;
        *)
                echo "error argv!!"
                ;;
esac

