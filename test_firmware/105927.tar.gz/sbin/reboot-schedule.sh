#!/bin/sh

if [ -f /tmp/firmware_upgrading ]; then
	return
fi

now_day="$(date|cut -c -3)"
now_hour="$(date|cut -c 12-13)"
now_min="$(date|cut -c 15-16)"

for i in $(seq 0 9)
do
	uci_value="$(uci -q get cameo.reboot_schedule.rule0$i)"

	if [ "$uci_value" != "" ]; then
		day="$(echo $uci_value | cut -d '/' -f 1)"
		hour="$(echo $uci_value | cut -d '/' -f 2 | cut -d ':' -f 1)"
		min="$(echo $uci_value | cut -d '/' -f 2 | cut -d ':' -f 2)"

		if [ "$(echo $day | grep -c $now_day)" -gt 0 ]; then
			if [ "$now_hour" = "$hour" -a "$now_min" = "$min" ]; then
				echo "Device reboot by reboot-schedule.sh!!!" > /dev/console
				reboot
			fi
		fi
	fi
done

