#!/bin/ash

firstboot
sleep 10
reboot

