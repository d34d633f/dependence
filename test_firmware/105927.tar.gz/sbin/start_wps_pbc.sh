#!/bin/sh
#debug
#echo ">>>>>start_wps_pbc.sh"

#WPS status file
WPS_STATUS=/tmp/wps_status

#get config parameter WPS
WPS_PUSHBUTTON2_4=`uci get wireless.main2_4.wps_pushbutton`
WPS_PUSHBUTTON5=`uci get wireless.main5.wps_pushbutton`
SSID2_4=`uci get wireless.main2_4.ssid`
SSID5=`uci get wireless.main5.ssid`
DISABLED2_4=`uci get wireless.wifi0.disabled`
DISABLED5=`uci get wireless.wifi1.disabled`

#assign a 0:invalid if Entry not found
if [ ! $WPS_PUSHBUTTON2_4 ]; then
    WPS_PUSHBUTTON2_4=0
fi
if [ ! $WPS_PUSHBUTTON5 ]; then
    WPS_PUSHBUTTON5=0
fi
if [ ! $DISABLED2_4 ]; then
    DISABLED2_4=0
fi
if [ ! $DISABLED5 ]; then
    DISABLED5=0
fi

#debug confirm config parameter
<<comment
echo "WPS_PUSHBUTTON2_4:$WPS_PUSHBUTTON2_4"
echo "WPS_PUSHBUTTON5:$WPS_PUSHBUTTON5"
echo "SSID2_4:$SSID2_4"
echo "SSID5:$SSID5"
echo "SSID2_4(len):${#SSID2_4}"
echo "SSID5(len):${#SSID5}"
echo "DISABLED2_4:$DISABLED2_4"
echo "DISABLED5:$DISABLED5"
comment

#start hostapd
#if [ $WPS_PUSHBUTTON2_4 -eq 1 ]; then
if [ $WPS_PUSHBUTTON2_4 -eq 1 -a $DISABLED2_4 -eq 0 -a -n "$SSID2_4" ]; then
    echo "hostapd_cli -i ath0 -p /var/run/hostapd-wifi0 wps_pbc"
    hostapd_cli -i ath0 -p /var/run/hostapd-wifi0 wps_pbc
    #WPS status update
    if [ -e $WPS_STATUS ]; then
        echo START 1> $WPS_STATUS
        /usr/bin/wpsled.sh wps blink > /dev/null
    else
        touch $WPS_STATUS
        echo START 1> $WPS_STATUS
        /usr/bin/wpsled.sh wps blink > /dev/null
    fi
fi
#if [ $WPS_PUSHBUTTON5 -eq 1 ]; then
if [ $WPS_PUSHBUTTON5 -eq 1 -a $DISABLED5 -eq 0 -a -n "$SSID5" ]; then
    echo "hostapd_cli -i ath1 -p /var/run/hostapd-wifi1 wps_pbc"
    hostapd_cli -i ath1 -p /var/run/hostapd-wifi1 wps_pbc
    #WPS status update
    if [ -e $WPS_STATUS ]; then
        echo START 1> $WPS_STATUS
        /usr/bin/wpsled.sh wps blink > /dev/null
    else
        touch $WPS_STATUS
        echo START 1> $WPS_STATUS
        /usr/bin/wpsled.sh wps blink > /dev/null
    fi
fi

#debug
#echo "<<<<<start_wps_pbc.sh"
