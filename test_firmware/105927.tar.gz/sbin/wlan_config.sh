#!/bin/sh
VAP_COUNT=4
VAP_NUM=0
WDS_COUNT=4
WDS_NUM=0
WIFI_DEVICE=0
WIFI_NUM=0
GUEST_2=$(uci -q get qcawifi.wlan0.vap1_enable)
GUEST_5=$(uci -q get qcawifi.wlan1.vap1_enable)
GUEST_2_ADD_TO_GUEST_BR=$(uci -q get qcawifi.wlan0.vap1_gzone_enable)
GUEST_5_ADD_TO_GUEST_BR=$(uci -q get qcawifi.wlan1.vap1_gzone_enable)
GUEST_BRNAME="br-gzone"
mode=$(uci get qcawifi.wlan1.opmode)
sta_enable_wifi0=$(uci get qcawifi.wlan0.sta_enable 2>/dev/null)
sta_enable_wifi1=$(uci get qcawifi.wlan1.sta_enable 2>/dev/null)

reload_module() 
{
	rmmod /lib/modules/$(uname -r)/mt_wifi.ko
	sleep 1
	insmod /lib/modules/$(uname -r)/mt_wifi.ko
}

guest_zone_start() {
	[ "$GUEST_2" = "1" -a "$GUEST_2_ADD_TO_GUEST_BR" = "1" ] || [ "$GUEST_5" = "1" -a "$GUEST_5_ADD_TO_GUEST_BR" = "1" ] || return
	brctl addbr "$GUEST_BRNAME"
	ifconfig "$GUEST_BRNAME" up
	ifconfig "$GUEST_BRNAME" "$(uci get -q network.gzone.ipaddr)"
}

guest_zone_stop() {
	[ "$GUEST_2" = "1" -a "$GUEST_2_ADD_TO_GUEST_BR" = "1" ] || [ "$GUEST_5" = "1" -a "$GUEST_5_ADD_TO_GUEST_BR" = "1" ] || return
	ifconfig "$GUEST_BRNAME" down
	brctl delbr "$GUEST_BRNAME"
}

wlan_wds_stop() {
	#wds
	WIFI_DEVICE=0
	while [ "$WIFI_DEVICE" != "2" ]
	do
		str="uci get qcawifi.wlan"$WIFI_DEVICE".wds_enable"
		enable=$($str)
		WDS_NUM=0
		WDS_QCA_NUM=1
		while [ "$WDS_NUM" != "$WDS_COUNT" ]
		do
			if [ "$enable" == "1" ]; then
				str="uci get qcawifi.wlan"$WIFI_DEVICE".wds_mac_"$WDS_QCA_NUM""
				mac=$($str)
				if [ "$WIFI_DEVICE" = "0" ] && [ "$mac" != "" ]; then
					interface=wds$WDS_NUM
					ifconfig  $interface down
					brctl delif br-lan $interface
				elif [ "$WIFI_DEVICE" = "1" ] && [ "$mac" != "" ]; then
					interface=wdsi$WDS_NUM
					ifconfig $interface down
					brctl delif br-lan $interface
				fi
			fi
			WDS_NUM=$(($WDS_NUM+1))
			WDS_QCA_NUM=$(($WDS_QCA_NUM+1))
		done
		WIFI_DEVICE=$(($WIFI_DEVICE+1))
	done
}

wlan_stop() {
	WIFI_DEVICE=0

	#disable sta interface
	if [ "$sta_enable_wifi0" = "1" ] || [ "$sta_enable_wifi1" = "1" ]; then
		ifconfig apcli0 down
		ifconfig apclii0 down
		brctl delif br-lan apcli0 2>/dev/null
		brctl delif br-lan apclii0 2>/dev/null
	else
		echo "no enable sta mode"  > /dev/console
	fi

	while [ "$WIFI_DEVICE" != "2" ]
	do
		VAP_NUM=0
		WIFI_NUM=0
		while [ "$VAP_NUM" != "$VAP_COUNT" ]
		do
			enable="$(uci -q get qcawifi.wlan"$WIFI_DEVICE".vap"$VAP_NUM"_enable)"

			if [ "$enable" == "1" ]; then
				if [ "$WIFI_DEVICE" == "0" ]; then
					interface=ra$WIFI_NUM
				else
					interface=rai$WIFI_NUM
				fi

				ifconfig $interface down

				# renew uci state
				uci -P /var/state set qcawifi.wlan$((WIFI_DEVICE)).vap$((VAP_NUM))_up=0

				# Guest Zone and Multiple SSID
				if [ "$VAP_NUM" = "1" ]; then
					if [ "$WIFI_DEVICE" = "0" -a "$GUEST_2_ADD_TO_GUEST_BR" = "1" ]; then
						brctl delif "$GUEST_BRNAME" "$interface"
					elif [ "$WIFI_DEVICE" = "1" -a "$GUEST_5_ADD_TO_GUEST_BR" = "1" ]; then
						brctl delif "$GUEST_BRNAME" "$interface"
					else
						brctl delif br-lan "$interface"
					fi
				else
					brctl delif br-lan "$interface"
				fi
				WIFI_NUM=$(($WIFI_NUM+1))
			fi
			VAP_NUM=$(($VAP_NUM+1))
		done
		WIFI_DEVICE=$(($WIFI_DEVICE+1))
	done
	guest_zone_stop
	wlan_wds_stop
	killall rt2860apd
	killall rtinicapd
}

wlan_wds_start() {
	#wds
	WIFI_DEVICE=0
	while [ "$WIFI_DEVICE" != "2" ]
	do
		str="uci get qcawifi.wlan"$WIFI_DEVICE".wds_enable"
		enable=$($str)
		WDS_NUM=0
		WDS_QCA_NUM=1
		while [ "$WDS_NUM" != "$WDS_COUNT" ]
		do
			if [ "$enable" == "1" ]; then
				str="uci get qcawifi.wlan"$WIFI_DEVICE".wds_mac_"$WDS_QCA_NUM""
				mac=$($str)
				if [ "$WIFI_DEVICE" = "0" ] && [ "$mac" != "" ]; then
					interface=wds$WDS_NUM
					ifconfig  $interface up
					brctl addif br-lan $interface
				elif [ "$WIFI_DEVICE" = "1" ] && [ "$mac" != "" ]; then
					interface=wdsi$WDS_NUM
					ifconfig $interface up
					brctl addif br-lan $interface
				fi
			fi
			WDS_NUM=$(($WDS_NUM+1))
			WDS_QCA_NUM=$(($WDS_QCA_NUM+1))
		done
		WIFI_DEVICE=$(($WIFI_DEVICE+1))
	done
}

wlan_start() {
	#create .dat file
	ralink_init gen 2860;ralink_init gen rtdev

	#wait .dat file
	sleep 1
	guest_zone_start

	WLED_2G=0
	WLED_5G=0
	# for EAP
	EAP_2G=0
	EAP_5G=0
	#2.4G and 5G
	WIFI_DEVICE=0

	while [ "$WIFI_DEVICE" != "2" ]
	do
		VAP_NUM=0
		WIFI_NUM=0
		while [ "$VAP_NUM" != "$VAP_COUNT" ]
		do
			enable="$(uci -q get qcawifi.wlan"$WIFI_DEVICE".vap"$VAP_NUM"_enable)"
			security="$(uci -q get qcawifi.wlan"$WIFI_DEVICE".vap"$VAP_NUM"_security)"

			if [ "$enable" == "1" ]; then
				if [ "$WIFI_DEVICE" == "0" ]; then
					interface=ra$WIFI_NUM
					WLED_2G=1
					if [ "$security" == "wpa2auto_eap" ]; then
						EAP_2G=1
					fi
				else
					interface=rai$WIFI_NUM
					WLED_5G=1
					if [ "$security" == "wpa2auto_eap" ]; then
						EAP_5G=1
					fi
				fi

				ifconfig $interface up

				# uci state: ifup and ifname
				uci -P /var/state set qcawifi.wlan$((WIFI_DEVICE)).vap$((VAP_NUM))_up=1
				uci -P /var/state set qcawifi.wlan$((WIFI_DEVICE)).vap$((VAP_NUM))_if=$interface

				# Guest Zone and Multiple SSID
				if [ "$VAP_NUM" = "1" ]; then
					if [ "$WIFI_DEVICE" = "0" -a "$GUEST_2_ADD_TO_GUEST_BR" = "1" ]; then
						brctl addif "$GUEST_BRNAME" "$interface"
					elif [ "$WIFI_DEVICE" = "1" -a "$GUEST_5_ADD_TO_GUEST_BR" = "1" ]; then
						brctl addif "$GUEST_BRNAME" "$interface"
					else
						brctl addif br-lan "$interface"
					fi
				else
					brctl addif br-lan "$interface"
				fi
				WIFI_NUM=$(($WIFI_NUM+1))
			fi
			VAP_NUM=$(($VAP_NUM+1))
		done
		WIFI_DEVICE=$(($WIFI_DEVICE+1))
	done

	wlan_wds_start

	#add mac in config for mp
	uci set qcawifi.wlan0.macaddr=$(cat /sys/class/net/ra0/address)
	uci set qcawifi.wlan1.macaddr=$(cat /sys/class/net/rai0/address)
	uci set cameo.system.wan_mac=$(cat /sys/class/net/$(uci get -q network.wan.ifname)/address)
	uci set cameo.system.lan_mac=$(cat /sys/class/net/$(uci get -q network.lan.ifname)/address)
	uci commit cameo

	#add wds mac for webui
	uci set qcawifi.wlan0.wds_mac=$(cat /sys/class/net/ra0/address)
	uci set qcawifi.wlan1.wds_mac=$(cat /sys/class/net/rai0/address)
	uci commit qcawifi

	#sta mode
	if [ "$mode" = "sta" ]; then
		sta_ssid=""
		WLED_2G=0
		WLED_5G=0
		ifconfig apcli0 up;ifconfig apclii0 up
		if [ "$sta_enable_wifi0" = "1" ]; then
			ifconfig apcli0 up
			brctl addif br-lan apcli0
			iwpriv apcli0 set ApCliAutoConnect=1
			iwpriv apcli0 set ApCliEnable=1
			sta_ssid=$(uci -q get qcawifi.wlan0.sta_ssid)
			if [ "$sta_ssid" != "" ]; then
				WLED_2G=1
			fi
		elif [ "$sta_enable_wifi1" = "1" ]; then
			ifconfig apclii0 up
			brctl addif br-lan apclii0
			iwpriv apclii0 set ApCliAutoConnect=1
			iwpriv apclii0 set ApCliEnable=1
			sta_ssid=$(uci -q get qcawifi.wlan1.sta_ssid)
			if [ "$sta_ssid" != "" ]; then
				WLED_5G=1
			fi

		fi
		ifconfig ra0 down;ifconfig rai0 down
	fi

	#enable wifi led
	if [ "$WLED_2G" == "1" ]; then
		 mtk_led wifi 2.4G on
	else
		 mtk_led wifi 2.4G off
	fi

	if [ "$WLED_5G" == "1" ]; then
		 mtk_led wifi 5G on
	else
		 mtk_led wifi 5G off
	fi

	if [ "$EAP_2G" == "1" ]; then
		rt2860apd
	fi

	if [ "$EAP_5G" == "1" ]; then
		rtinicapd
	fi

	/sbin/gen_dut_info.sh
	touch /tmp/done
}

sync_nvram() {
	WiFi_Domain=$(fw_getenv wlan0_domain 2>/dev/null)
	uci set cameo.system.wlan0_domain "$WiFi_Domain"
	uci commit cameo

	load_uboot_env=$(uci get cameo.system.load_uboot_env 2>/dev/null)
	if [ "$load_uboot_env" == "1" ]; then
		def_ssid_2g="$(fw_getenv wlan0_ssid 2>/dev/null)"
		def_ssid_5g="$(fw_getenv wlan1_ssid 2>/dev/null)"
		def_key_2g="$(fw_getenv wlan0_key 2>/dev/null)"
		def_key_5g="$(fw_getenv wlan1_key 2>/dev/null)"
		wps_pin="$(fw_getenv wps_pin 2>/dev/null)"

		uci set cameo.system.load_uboot_env=0

		if [ "$def_ssid_2g" != "" ]; then
			uci set qcawifi.wlan0.vap0_ssid=$def_ssid_2g
		fi

		if [ "$def_ssid_5g" != "" ]; then
			uci set qcawifi.wlan1.vap0_ssid=$def_ssid_5g
		fi

		if [ "$def_key_2g" != "" ]; then
			uci set qcawifi.wlan0.vap0_psk_pass_phrase=$def_key_2g
		fi

		if [ "$def_key_5g" != "" ]; then
			uci set qcawifi.wlan1.vap0_psk_pass_phrase=$def_key_5g
		fi

		if [ "$wps_pin" != "" ]; then
			uci set qcawifi.wlan0.wps_pin=$wps_pin
			uci set qcawifi.wlan1.wps_pin=$wps_pin
		fi

		uci commit cameo
		uci commit qcawifi
	fi

	/sbin/wlan_cmd qcawifi
	/sbin/wlan_cmd wps 2_4G wps_disabled
	/sbin/wlan_cmd wps 5G wps_disabled
	/sbin/wlan_cmd wps 2_4G get_pincode
	/sbin/wlan_cmd wps 5G get_pincode

	# multicast to unicast
	/sbin/wlan_cmd advance 2_4G mcastenhance
	/sbin/wlan_cmd advance 5G mcastenhance

	nvram_set 2860 IEEE80211H 1
	nvram_set rtdev IEEE80211H 1
	
	if [ "$mode" = "sta" ]; then
		if [ "$sta_enable_wifi0" = "1" ]; then
			/sbin/wlan_cmd apclient converter 2_4G
		elif [ "$sta_enable_wifi1" = "1" ]; then
			/sbin/wlan_cmd apclient converter 5G
		fi
	else
		/sbin/wlan_cmd apclient wds 2_4G
		/sbin/wlan_cmd apclient wds 5G
		#Enabled dfs function
		nvram_set rtdev DfsEnable 1
	fi
	sleep 1
}

case $1 in
	"init")
		wlan_stop
		reload_module
		wlan_start
		;;
	"start")
		wlan_start
		;;
	"stop")
		wlan_stop
		;;
	"restart")
		wlan_stop
		wlan_start
		;;
	"boot")	
		reload_module
		sync_nvram
		wlan_start
		;;
	"sync_nvram")
		sync_nvram	
		;;
	*)
		echo "wlan init fail"
		;;
esac
