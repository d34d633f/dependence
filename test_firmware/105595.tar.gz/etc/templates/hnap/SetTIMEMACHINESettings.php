HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/inet.php";

$nodebase = "/runtime/hnap/SetTIMEMACHINESettings/";
$tm_path = get("", $nodebase."TIMEMACHINEPath");
$tm_vq = get("", $nodebase."TIMEMACHINEVQ");
$result = "OK";

if(get("", $nodebase."TIMEMACHINEEnable")=="Enable")
{	set("/timemachine/enable", 1);}
else if(get("", $nodebase."TIMEMACHINEEnable")=="Disable")
{	set("/timemachine/enable", 0);}
else
{	$result = "ERROR";}

/*if($tm_vq == "1" || $tm_vq == "0")
{
	set("/timemachine/volumequoto", $tm_vq);
}
else
{
	$result = "ERROR";
}*/
set("/timemachine/volumequoto", $tm_vq);
if($tm_path != "")
{
	if (substr($tm_path,0,1) == "/") //remove leading
	{
		$tm_path = substr($tm_path,1,strlen($tm_path) -1     );
	}
	set("/timemachine/path", $tm_path);
}

fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "echo \"[$0]-->TimeMachine Settings\" > /dev/console\n");

if($result=="OK")
{
	fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");
	fwrite("a",$ShellPath, "service TIMEMACHINE restart > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:xsd="http://www.w3.org/2001/XMLSchema"
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<SetTIMEMACHINESettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<SetTIMEMACHINESettingsResult><?=$result?></SetTIMEMACHINESettingsResult>
		</SetTIMEMACHINESettingsResponse>
	</soap:Body>
</soap:Envelope>
