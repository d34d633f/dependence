<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}

include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/trace.php"; 
include "/htdocs/phplib/encrypt.php";

$result = "OK";

function print_StorageUserInfo()
{
	echo "<UserInfoLists>";
	foreach("/users/entry")
	{
        $userenable = get("", "userenable");
        if($userenable != "true")
        {
            $userenable = "false";
        }
		$username = get("","username");
		$passwd = get("","passwd");

		$smbenable = get("","samba/enable");
		$smbpath = get("","samba/path");
    		if (substr($smbpath,0,1) != "/")
    		{
    			$smbpath = "/".$smbpath;
    		}
		$smbpermission = get("","samba/permission");

		$ftpenable = get("","ftp/enable");
		$ftppath = get("","ftp/path");
    		if (substr($ftppath,0,1) != "/")
    		{
    			$ftppath = "/".$ftppath;
    		}
		$ftppermission = get("","ftp/permission");

		$vpnenable = get("","vpn/enable");
		
		if($username != "Admin" && $username != "admin")
		{
			if($smbpermission == "rw") $smbpermission = "true";
			else $smbpermission = "false";
			if($ftppermission == "rw") $ftppermission = "true";
			else $ftppermission = "false";
			
			echo "<User>";
            echo "<UserEnable>".escape("x",$userenable)."</UserEnable>";
			echo "<UserName>".escape("x",$username)."</UserName>";
			echo "<Password>".AES_Encrypt128($passwd)."</Password>";
			echo "<SambaEnable>".escape("x",$smbenable)."</SambaEnable>";
			echo "<SambaAccessPath>".escape("x",$smbpath)."</SambaAccessPath>";
			echo "<SambaPromission>".escape("x",$smbpermission)."</SambaPromission>";
			echo "<FtpEnable>".escape("x",$ftpenable)."</FtpEnable>";
			echo "<FtpAccessPath>".escape("x",$ftppath)."</FtpAccessPath>";
			echo "<FtpPromission>".escape("x",$ftppermission)."</FtpPromission>";
			echo "<VpnEnable>".escape("x",$vpnenable)."</VpnEnable>";
			echo "</User>";
		}
	}
	echo "</UserInfoLists>";
}

?>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
<GetUSERSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
	<GetUSERSettingsResult><?=$result?></GetUSERSettingsResult>
	<?print_StorageUserInfo();?>
</GetUSERSettingsResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>
