<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)  {HTML_hnap_200_header();}
include "/htdocs/phplib/trace.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/encrypt.php";
$result = "OK";

?>
<? if($Remove_XML_Head_Tail != 1)   {HTML_hnap_xml_header();}?>
<GetTR069SettingsResponse xmlns="http://purenetworks.com/HNAP1/">
	<GetTR069SettingsResult><?=$result?></GetTR069SettingsResult>
	<?
		$tr069_path="/tr069/managementserver";
		$runtime_tr069_path="/runtime/tr069/managementserver";
		$url = query($tr069_path."/weburl");
		$username = query($tr069_path."/webusername");
		$password = query($tr069_path."/webpassword");
		
		if ($url == "")
			$url = query($tr069_path."/url");
		if ($url == "")
			$url = query($tr069_path."/defurl");
		if ($username == "")
			$username = query($tr069_path."/username");
		if ($password == "")
			$password = query($tr069_path."/password");
		
		$request_url = query($runtime_tr069_path."/connectionrequesturl");//use the runtime
		if($request_url == "")
			$request_url = query($tr069_path."/connectionrequesturl");//use the db
		
		$request_username = query($tr069_path."/connectionrequestusername");
		$request_password = query($tr069_path."/connectionrequestpassword");
		$login_password	= query("/device/account/entry/password_tr069");
		
		$tr069Enable			= query($tr069_path."/enablecwmp");
		$periodicinformenable	= query($tr069_path."/periodicinformenable");
		$periodicinforminterval	= query($tr069_path."/periodicinforminterval");
		$stunenable				= query($tr069_path."/stun/stunenable");
		$stunserveraddress		= query($tr069_path."/stun/stunserveraddress");
		$stunserverport			= query($tr069_path."/stun/stunserverport");
		$stunserverusername		= query($tr069_path."/stun/stunusername");
		$stunserverpassword		= query($tr069_path."/stun/stunpassword");
		$tr069vlanid			= query("/device/vlan/interid_pppoe");
		
		if(query("/tr069/external/pppoevlanid") == "" && 
		query("/tr069/external/enable_dualwan") == "")
			$tr069vlanid = 209;
	
		$password = AES_Encrypt128($password);
	
		echo "	<tr069Enable>".$tr069Enable."</tr069Enable>\n";
		echo "	<url>".$url."</url>\n";
		echo "	<username>".$username."</username>\n";
		echo "	<password>".$password."</password>\n";
		echo "	<requesturl>".$request_url."</requesturl>\n";
		echo "	<requestusername>".$request_username."</requestusername>\n";
		echo "	<requestpassword>".$request_password."</requestpassword>\n";
		echo "	<loginpassword>".$login_password."</loginpassword>\n";
		
		echo "	<periodicinformenable>".$periodicinformenable."</periodicinformenable>\n";
		echo "	<periodicinforminterval>".$periodicinforminterval."</periodicinforminterval>\n";

		echo "	<stunenable>".$stunenable."</stunenable>\n";
		echo "	<stunserveraddress>".$stunserveraddress."</stunserveraddress>\n";
		echo "	<stunserverport>".$stunserverport."</stunserverport>\n";
		echo "	<stunserverusername>".$stunserverusername."</stunserverusername>\n";
		echo "	<stunserverpassword>".$stunserverpassword."</stunserverpassword>\n";
		echo "	<tr069vlanid>".$tr069vlanid."</tr069vlanid>\n";
	?>
</GetTR069SettingsResponse>
<? if($Remove_XML_Head_Tail != 1)   {HTML_hnap_xml_tail();}?>
