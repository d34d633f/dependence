<? include "/htdocs/phplib/html.php";
include "/htdocs/phplib/trace.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}
/*
	Ref: spec. D-Link HNAP Extension - 20140701v1.20.pdf
	Discussion with D-Link Luke in 20140925
	DISCONNECTED : Cable is disconnected.
	LIMITED_CONNECTION : Cable is connected without WAN IP.
	CONNECTING : Cable is connected and try to get the WAN IP.
	CONNECTED : Cable is connected with WAN IP.
*/
include "/htdocs/phplib/inf.php";
include "/htdocs/phplib/phyinf.php";
include "/htdocs/webinc/config.php";

$layout = query("/device/layout");
$wirelessmode = query("/device/wirelessmode");

if($layout=="router")
{
	$INF = $WAN1;
}
else
{
	$INF = $BR1;
}

if($wirelessmode == "WirelessBridge" || $wirelessmode == "WirelessRepeaterExtender")
{
	$rp_phyinf_wlan1 = XNODE_getpathbytarget("runtime", "phyinf", "uid", $WLAN_APCLIENT, 0);
	$rp_phyinf_wlan2 = XNODE_getpathbytarget("runtime", "phyinf", "uid", $WLAN2_APCLIENT, 0);
	$rp_phyinf_wlan3 = XNODE_getpathbytarget("runtime", "phyinf", "uid", $WLAN3_APCLIENT, 0);

	if($rp_phyinf_wlan1!="") $rp_phyinf_wlan = $rp_phyinf_wlan1;
	else if($rp_phyinf_wlan2!="") $rp_phyinf_wlan = $rp_phyinf_wlan2;
	else if($rp_phyinf_wlan3!="") $rp_phyinf_wlan = $rp_phyinf_wlan3;

	$connstatus = query($rp_phyinf_wlan."/media/connstatus");

	if($connstatus == "CONNECTED")
	{
		$statusStr = "CONNECTED";
	}
	else
	{
		$statusStr = "DISCONNECTED";
	}
}
else
{
	$CableStatus = get("", PHYINF_getphypath($INF)."/linkstatus");
	if($CableStatus == "0" || $CableStatus == "")
	{	$statusStr = "DISCONNECTED";}
	else if(INF_getcfgipaddr($INF) != "" || INF_getcurripaddr($INF) != "")
	{ $statusStr = "CONNECTED"; }
	else
	{	$statusStr = "LIMITED_CONNECTION";}

	$path_run_inf_wan1 = XNODE_getpathbytarget("/runtime", "inf", "uid", $INF, 0);
	if(query($path_run_inf_wan1."/inet/ipv4/ipv4in6/mode") == "dslite" && $CableStatus != "")	// DS-Lite
	{
		$statusStr = "CONNECTED";
	}
}
TRACE_debug("  ++ statusStr = ".$statusStr);
?>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
<GetWanStatusResponse xmlns="http://purenetworks.com/HNAP1/">
<GetWanStatusResult>OK</GetWanStatusResult>
<Status><?=$statusStr ?></Status>
</GetWanStatusResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>
