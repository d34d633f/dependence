<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}

$result = "OK";
if(get("", "/timemachine/enable")=="1")
{	$TIMEMACHINEEnable = "Enable";}
else
{	$TIMEMACHINEEnable = "Disable";}

$TIMEMACHINEPath = get("", "/timemachine/path");

/*if(get("", "/timemachine/volumequoto") =="1")
{	$TIMEMACHINEVolumeQ = "Disable";}
else
{	$TIMEMACHINEVolumeQ = "Enable";}*/
$TIMEMACHINEVolumeQ = get("", "/timemachine/volumequoto");

?>

<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
		<GetTIMEMACHINESettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetTIMEMACHINESettingsResult><?=$result?></GetTIMEMACHINESettingsResult>
			<TIMEMACHINEEnable><?=$TIMEMACHINEEnable?></TIMEMACHINEEnable>
			<TIMEMACHINEPath><?=$TIMEMACHINEPath?></TIMEMACHINEPath>
			<TIMEMACHINEVolumeQ><?=$TIMEMACHINEVolumeQ?></TIMEMACHINEVolumeQ>
		</GetTIMEMACHINESettingsResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>
