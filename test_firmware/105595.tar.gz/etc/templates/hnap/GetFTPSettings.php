<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}

$result = "OK";
if(get("", "/ftpd/enable")=="1")
{	$FTPEnable = "Enable";}
else
{	$FTPEnable = "Disable";}

if(get("", "/ftpd/remotesharing")=="1")
{   $FTPRemoteSharing = "Enable";}
else
{   $FTPRemoteSharing = "Disable";}

if(get("", "/ftpd/port")=="")
{$FTPPort = "21";}
else
{$FTPPort = get("","/ftpd/port");}

$FTPIdelTime = get("","/ftpd/time");

if(get("", "/ftpd/transfermode")=="")
{$FTPTransferMode = "Passive mode";}
else
{$FTPTransferMode = get("","/ftpd/transfermode");}

if(get("", "/ftpd/encryption")=="")
{$FTPEncryption = "Explicit FTP over TLS";}
else
{$FTPEncryption = get("","/ftpd/encryption");}


?>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
		<GetFTPSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<GetFTPSettingsResult><?=$result?></GetFTPSettingsResult>
			<FTPEnable><?=$FTPEnable?></FTPEnable>
			<FTPPort><?=$FTPPort?></FTPPort>
            <FTPRemoteSharing><?=$FTPRemoteSharing?></FTPRemoteSharing>
            <FTPTransferMode><?=$FTPTransferMode?></FTPTransferMode>
            <FTPEncryption><?=$FTPEncryption?></FTPEncryption>
			<FTPIdelTime><?=$FTPIdelTime?></FTPIdelTime>
		</GetFTPSettingsResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>
