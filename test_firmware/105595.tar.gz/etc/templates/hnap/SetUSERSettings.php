HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/trace.php"; 
include "/htdocs/phplib/encrypt.php";

function XNODE_add_entry_for_WEBACCESS($base)
{
	$count = query($base."/count");
	if ($count == "")
		{$count = 0;}
	$count++;
	set($base."/count", $count);
	return $base."/entry:".$count;
}

$result = "OK";

/* start to set */
if($result == "OK")
{
	/* clean old entry */
	$i = 0;
	$old_count = get("", "/users/count");
	while($i < $old_count)
	{
		del("/users/entry");
		$i++;
	}
	set("/users/count",0);
	
	$old_cnt = get("", "/webaccess/account/count");
	$j = 0;
	while($j < $old_cnt)
	{
		del("/webaccess/account/entry");
		$j++;
	}
	set("/webaccess/account/count",0);
	
	/* add admin account */
	foreach("/device/account/entry")
	{
		$admin = get("","name");
		if( $admin == "Admin" || $admin == "admin") 
		{
			$admin_name = $admin;
			$admin_passwd = get("","password");
		}
	}
	if($admin_name == "")
	{
		TRACE_error("SetUsers is not OK: add admin account fail"); 
		$result = "ERROR";
	}
	else
	{
		/* account for samba, ftp */
		$newentry = XNODE_add_entry_for_WEBACCESS("/users");
		set($newentry."/username",$admin_name);
		set($newentry."/passwd",$admin_passwd);
		set($newentry."/samba/enable","true");
		set($newentry."/samba/path","");
		set($newentry."/samba/permission","rw");
		set($newentry."/ftp/enable","true");
		set($newentry."/ftp/path","");
		set($newentry."/ftp/permission","rw");
		set($newentry."/vpn/enable","true");
		
		/* account for web access */
		$newentry = XNODE_add_entry_for_WEBACCESS("/webaccess/account");
		set($newentry."/username",$admin_name);
		set($newentry."/passwd",$admin_passwd);
		set($newentry."/entry/path","root");
		set($newentry."/entry/permission","rw");
	}
	
	/* start to set users */
	foreach("/runtime/hnap/SetUSERSettings/UserInfoLists/User")
	{
        $req_UserEnable = get("", "UserEnable");
		$req_UserName = get("","UserName");
		$req_Password = get("","Password");
		$req_Password = AES_Decrypt128($req_Password);
		$req_SmbEnable = get("","SmbEnable");
		$req_SmbPath = get("","SmbPath");
		$req_SmbPromission = get("","SmbPermission");
		$req_FtpEnable = get("","FtpEnable");
		$req_FtpPath = get("","FtpPath");
		$req_FtpPromission = get("","FtpPermission");
		$req_VpnEnable = get("","VpnEnable");
		
		if($req_SmbPromission == "true")
			{$req_SmbPromission = "rw";}
		else
			{$req_SmbPromission = "ro";}
		
		if (substr($req_SmbPath,0,1) == "/") //remove leading
  		{
			$req_SmbPath = substr($req_SmbPath,1,strlen($req_SmbPath) -1 );
		}

		if($req_FtpPromission == "true")
			{$req_FtpPromission = "rw";}
		else
			{$req_FtpPromission = "ro";}
		
		if (substr($req_FtpPath,0,1) == "/") //remove leading
  		{
			$req_FtpPath = substr($req_FtpPath,1,strlen($req_FtpPath) -1 );
		}
		
		/* account for samba, ftp */
		$newentry = XNODE_add_entry_for_WEBACCESS("/users");
		set($newentry."/userenable",$req_UserEnable);
		set($newentry."/username",$req_UserName);
		set($newentry."/passwd",$req_Password);
		set($newentry."/samba/enable",$req_SmbEnable);
		set($newentry."/samba/path",$req_SmbPath);
		set($newentry."/samba/permission",$req_SmbPromission);
		set($newentry."/ftp/enable",$req_FtpEnable);
		set($newentry."/ftp/path",$req_FtpPath);
		set($newentry."/ftp/permission",$req_FtpPromission);
		set($newentry."/vpn/enable",$req_VpnEnable);
		
		/* account for web access */
		$newentry = XNODE_add_entry_for_WEBACCESS("/webaccess/account");
		set($newentry."/username",$req_UserName);
		set($newentry."/passwd",$req_Password);
		set($newentry."/entry/path","root");
		set($newentry."/entry/permission","rw");
	}
	
	fwrite("w",$ShellPath, "#!/bin/sh\n");
	fwrite("a",$ShellPath, "echo [$0] > /dev/console\n");
	fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");

	fwrite("a",$ShellPath, "service SAMBA restart > /dev/console\n");
	fwrite("a",$ShellPath, "service FTPD restart > /dev/console\n");
	fwrite("a",$ShellPath, "service IPSEC restart > /dev/console\n");
	
	fwrite("a",$ShellPath, "service WEBACCESS restart > /dev/console\n");
	$layout = query("/device/layout");
	if($layout == "bridge")
	{
		fwrite("a",$ShellPath, "xmldbc -t \"".scut($ShellPath, 0, "/var/run/").":3:service INET.BRIDGE-1 restart > /dev/console\"\n");
	}
	else
	{
		fwrite("a",$ShellPath, "xmldbc -t \"".scut($ShellPath, 0, "/var/run/").":3:service INET.LAN-1 restart > /dev/console\"\n");
	}
	fwrite("a",$ShellPath, "service UPNPC restart > /dev/console\n");
}
else
{
	fwrite("w",$ShellPath, "#!/bin/sh\n");
	fwrite("a",$ShellPath, "echo [$0] > /dev/console\n");
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" soap:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<soap:Body>
<SetUSERSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
	<SetUsersResult><?=$result?></SetUsersResult>
</SetUSERSettingsResponse>
</soap:Body>
</soap:Envelope>
