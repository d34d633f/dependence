<? include "/htdocs/phplib/html.php";
if($Remove_XML_Head_Tail != 1)	{HTML_hnap_200_header();}

$vlan_active = query("/device/vlan/active");
$service_provider =  query("/device/vlan/service_provider");
$manual_interid =  query("/device/vlan/manual_interid");
$manual_voipid	= query("/device/vlan/manual_voipid");
$manual_iptvid = query("/device/vlan/manual_iptvid");
$maxis_tm_interid = query("/device/vlan/maxis_tm_interid");
$maxis_tm_voipid = query("/device/vlan/maxis_tm_voipid");
$maxis_tm_iptvid = query("/device/vlan/maxis_tm_iptvid");
$maxis_maxis_interid = query("/device/vlan/maxis_maxis_interid");
$maxis_maxis_voipid = query("/device/vlan/maxis_maxis_voipid");
$maxis_maxis_iptvid = query("/device/vlan/maxis_maxis_iptvid");
$tm_unifi_interid =  query("/device/vlan/tm_unifi_interid");
$tm_unifi_voipid = query("/device/vlan/tm_unifi_voipid");
$tm_unifi_iptvid = query("/device/vlan/tm_unifi_iptvid");

$interid_pppoe = query("/device/vlan/interid_pppoe");
$voipid_pppoe = query("/device/vlan/voipid_pppoe");
$iptvid_pppoe = query("/device/vlan/iptvid_pppoe");
$interid_dhcp = query("/device/vlan/interid_dhcp");
$voipid_dhcp = query("/device/vlan/voipid_dhcp");
$iptvid_dhcp = query("/device/vlan/iptvid_dhcp");

$active_priority = query("/device/vlan/active_priority");
$inter_priority = query("/device/vlan/inter_priority");
$voip_priority = query("/device/vlan/voip_priority");
$iptv_priority = query("/device/vlan/iptv_priority");

$lan1_pppoe = query("/device/vlan/lanport/lan1_pppoe");
$lan2_pppoe = query("/device/vlan/lanport/lan2_pppoe");
$lan3_pppoe = query("/device/vlan/lanport/lan3_pppoe");
$lan4_pppoe = query("/device/vlan/lanport/lan4_pppoe");
$lan1_dhcp = query("/device/vlan/lanport/lan1_dhcp");
$lan2_dhcp = query("/device/vlan/lanport/lan2_dhcp");
$lan3_dhcp = query("/device/vlan/lanport/lan3_dhcp");
$lan4_dhcp = query("/device/vlan/lanport/lan4_dhcp");
$wlan01_pppoe = query("/device/vlan/wlanport/wlan01_pppoe");
$wlan02_pppoe = query("/device/vlan/wlanport/wlan02_pppoe");
$wlan01_dhcp = query("/device/vlan/wlanport/wlan01_dhcp");
$wlan02_dhcp = query("/device/vlan/wlanport/wlan02_dhcp");

?>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_header();}?>
	<GetVlanSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
		<GetVlanSettingsResult>OK</GetVlanSettingsResult>
		<active><?=$vlan_active?></active>
		<service_provider><?=$service_provider?></service_provider>
		<manual_interid><?=$manual_interid?></manual_interid>
		<manual_voipid><?=$manual_voipid?></manual_voipid>
		<manual_iptvid><?=$manual_iptvid?></manual_iptvid>
		<maxis_tm_interid><?=$maxis_tm_interid?></maxis_tm_interid>
		<maxis_tm_voipid><?=$maxis_tm_voipid?></maxis_tm_voipid>
		<maxis_tm_iptvid><?=$maxis_tm_iptvid?></maxis_tm_iptvid>
		<maxis_maxis_interid><?=$maxis_maxis_interid?></maxis_maxis_interid>
		<maxis_maxis_voipid><?=$maxis_maxis_voipid?></maxis_maxis_voipid>
		<maxis_maxis_iptvid><?=$maxis_maxis_iptvid?></maxis_maxis_iptvid>
		<tm_unifi_interid><?=$tm_unifi_interid?></tm_unifi_interid>
		<tm_unifi_voipid><?=$tm_unifi_voipid?></tm_unifi_voipid>
		<tm_unifi_iptvid><?=$tm_unifi_iptvid?></tm_unifi_iptvid>
		<active_priority><?=$active_priority?></active_priority>
		<inter_priority><?=$inter_priority?></inter_priority>
		<voip_priority><?=$voip_priority?></voip_priority>
		<iptv_priority><?=$iptv_priority?></iptv_priority>
		<interid_pppoe><?=$interid_pppoe?></interid_pppoe>
		<voipid_pppoe><?=$voipid_pppoe?></voipid_pppoe>
		<iptvid_pppoe><?=$iptvid_pppoe?></iptvid_pppoe>
		<interid_dhcp><?=$interid_dhcp?></interid_dhcp>
		<voipid_dhcp><?=$voipid_dhcp?></voipid_dhcp>
		<iptvid_dhcp><?=$iptvid_dhcp?></iptvid_dhcp>
		<lanport>
			<lan1_pppoe><?=$lan1_pppoe?></lan1_pppoe>
			<lan2_pppoe><?=$lan2_pppoe?></lan2_pppoe>
			<lan3_pppoe><?=$lan3_pppoe?></lan3_pppoe>
			<lan4_pppoe><?=$lan4_pppoe?></lan4_pppoe>
			<lan1_dhcp><?=$lan1_dhcp?></lan1_dhcp>
			<lan2_dhcp><?=$lan2_dhcp?></lan2_dhcp>
			<lan3_dhcp><?=$lan3_dhcp?></lan3_dhcp>
			<lan4_dhcp><?=$lan4_dhcp?></lan4_dhcp>
		</lanport>
		<wlanport>
			<wlan01_pppoe><?=$wlan01_pppoe?></wlan01_pppoe>
			<wlan02_pppoe><?=$wlan02_pppoe?></wlan02_pppoe>
			<wlan01_dhcp><?=$wlan01_dhcp?></wlan01_dhcp>
			<wlan02_dhcp><?=$wlan02_dhcp?></wlan02_dhcp>
		</wlanport>
	</GetVlanSettingsResponse>
<? if($Remove_XML_Head_Tail != 1)	{HTML_hnap_xml_tail();}?>

