HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/trace.php";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/encrypt.php";
$nodebase = "/runtime/hnap/SetTR069Settings";
$result = "OK";

$tr069Enable = get("",$nodebase."/tr069Enable");
$url = get("",$nodebase."/url");
$username = get("",$nodebase."/username");
$password = AES_Decrypt128(get("",$nodebase."/password"));
$request_url = get("",$nodebase."/requesturl");
$request_username = get("",$nodebase."/requestusername");
$request_password = get("",$nodebase."/requestpassword");

$connectionrequestport = get("",$nodebase."/connectionrequestport");
$connectionrequestpadding = get("",$nodebase."/connectionrequestpadding");
$connectionrequestport_old = query("/tr069/misc/connectionrequestport");


$tr069_login_password = get("",$nodebase."/loginpassword");
$tr069_login_password_ori = query("/device/account/entry/password_tr069");

$periodicinformenable = get("",$nodebase."/periodicinformenable");
$periodicinforminterval = get("",$nodebase."/periodicinforminterval");

$stunenable = get("",$nodebase."/stunenable");
$stunserveraddress = get("",$nodebase."/stunserveraddress");
$stunserverport = get("",$nodebase."/stunserverport");
$stunserverusername = get("",$nodebase."/stunserverusername");
$stunserverpassword = get("",$nodebase."/stunserverpassword");
$tr069vlanid = get("",$nodebase."/tr069vlanid");
$tr069vlan_oldid = get("","/device/vlan/interid_pppoe");

TRACE_error("TR069 SET password:[".$password."]\n");

set("/tr069/managementserver/enablecwmp",$tr069Enable);

set("/tr069/managementserver/weburl",$url);
set("/tr069/managementserver/webusername",$username);
set("/tr069/managementserver/webpassword",$password);

set("/device/vlan/interid_pppoe",$tr069vlanid);
set("/device/vlan/interid",$tr069vlanid);



if(strlen($request_url) > 7)
{
//	set("/tr069/managementserver/connectionrequesturl",$request_url);
//	set("/runtime/tr069/managementserver/connectionrequesturl",$request_url);
	set("/tr069/misc/connectionrequestport",$connectionrequestport);
	set("/tr069/misc/connectionrequestpadding",$connectionrequestpadding);
}


set("/tr069/managementserver/connectionrequestusername",$request_username);
set("/tr069/managementserver/connectionrequestpassword",$request_password);

set("/tr069/managementserver/periodicinformenable",$periodicinformenable);
set("/tr069/managementserver/periodicinforminterval",$periodicinforminterval);
set("/tr069/managementserver/stun/stunenable",$stunenable);
set("/tr069/managementserver/stun/stunserveraddress",$stunserveraddress);
set("/tr069/managementserver/stun/stunserverport",$stunserverport);
set("/tr069/managementserver/stun/stunserverusername",$stunserverusername);
set("/tr069/managementserver/stun/stunserverpassword",$stunserverpassword);
set("/tr069/external/enable_dualwan",1);

if($tr069_login_password_ori != $tr069_login_password)
	set("/device/account/entry/password_tr069",$tr069_login_password);

if($result == "OK")
{
	fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	fwrite("a",$ShellPath, "service TR069 restart > /dev/console\n");
	
	if($tr069_login_password_ori != $tr069_login_password)
	{
		fwrite("a",$ShellPath, "sh /var/servd/DEVICE.ACCOUNT_stop.sh\n");
		fwrite("a",$ShellPath, "xmldbc -P /etc/services/DEVICE.ACCOUNT.php -V START=/var/servd/DEVICE.ACCOUNT_start.sh -V STOP=/var/servd/DEVICE.ACCOUNT_stop.sh\n");
		fwrite("a",$ShellPath, "sh /var/servd/DEVICE.ACCOUNT_start.sh\n");
	}
	
	TRACE_error("connectionrequestport_old:[".$connectionrequestport_old."]\n");
	TRACE_error("connectionrequestport:[".$connectionrequestport."]\n");
	if($connectionrequestport_old != $connectionrequestport)
	{//if change port need to restart wan for firewall
		TRACE_error("connectionrequestport_old2:[".$connectionrequestport_old."]\n");
		TRACE_error("connectionrequestport2:[".$connectionrequestport."]\n");
		fwrite("a",$ShellPath, "service WAN restart > /dev/console\n");
	}
	
	set("/runtime/hnap/dev_status", "ERROR");

    if($tr069vlan_oldid != $tr069vlanid)
    {
        $result="REBOOT" ;
    }      


}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:xsd="http://www.w3.org/2001/XMLSchema"
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
	<SetTR069SettingsResponse xmlns="http://purenetworks.com/HNAP1/">
		<SetTR069SettingsResult><?=$result?></SetTR069SettingsResult>
	</SetTR069SettingsResponse>
	</soap:Body>
</soap:Envelope>
