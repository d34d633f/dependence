HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/webinc/config.php";
include "/htdocs/phplib/inet.php";

$nodebase = "/runtime/hnap/SetFTPSettings/";
$FtpEnable = get("", $nodebase."FTPEnable");
$FtpRemoteSharing = get("", $nodebase."FTPRemoteSharing");
$FtpPort = get("", $nodebase."FTPPort");
$FtpTime = get("", $nodebase."FTPIdleTime");
$FTPTransferMode = get("", $nodebase."FTPTransferMode");
$FTPEncryption = get("", $nodebase."FTPEncryption");
$result = "OK";

if($FtpRemoteSharing=="Enable")
{
    set("/ftpd/remotesharing", 1);
}else{
    set("/ftpd/remotesharing", 0);

}

if($FtpEnable=="Enable")
{
	set("/ftpd/enable", 1);
}
else if($FtpEnable=="Disable")
{
	set("/ftpd/enable", 0);
}
else
{
	$result = "ERROR";
}

if($FtpPort != "")
{ set("/ftpd/port", $FtpPort);}

if($FtpTime != "")
{ set("/ftpd/time", $FtpTime);}

fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "echo \"[$0]-->Ftpd Settings\" > /dev/console\n");

if($result=="OK")
{
	fwrite("a",$ShellPath, "event DBSAVE > /dev/console\n");
	fwrite("a",$ShellPath, "service FTPD restart > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:xsd="http://www.w3.org/2001/XMLSchema"
	xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
	<soap:Body>
		<SetFTPSettingsResponse xmlns="http://purenetworks.com/HNAP1/">
			<SetFTPSettingsResult><?=$result?></SetFTPSettingsResult>
		</SetFTPSettingsResponse>
	</soap:Body>
</soap:Envelope>
