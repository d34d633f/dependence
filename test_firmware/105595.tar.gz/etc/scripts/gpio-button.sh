#!/bin/sh
# gpio-button: Send usockc to gpio daemon(gpiod.c).

mfcmode=`devdata get -e mfcmode`

if [ "$mfcmode" = "1" ]; then

case "$1" in
wps)
	if [ "$2" == "pressed" ]; then
		echo 1 > /var/gpio_ctrl_result
	fi
	if [ "$2" == "released" ]; then
		echo 0 > /var/gpio_ctrl_result
	fi
	;;
reset)
	if [ "$2" == "pressed" ]; then
		echo 1 > /var/gpio_ctrl_result
	fi
	if [ "$2" == "released" ]; then
		echo 0 > /var/gpio_ctrl_result
	fi
	;;
esac
	
else

case "$1" in
wps)
	if [ "$2" == "pressed" ]; then
		usockc /var/gpio_ctrl BUTTON_WPS_PRESSED
	fi
	if [ "$2" == "released" ]; then
		usockc /var/gpio_ctrl BUTTON_WPS_RELEASED
	fi
	;;
reset)
	if [ "$2" == "pressed" ]; then
		usockc /var/gpio_ctrl BUTTON_RESET_PRESSED
	fi
	if [ "$2" == "released" ]; then
		usockc /var/gpio_ctrl BUTTON_RESET_RELEASED
	fi
	;;
esac

fi

exit 0
