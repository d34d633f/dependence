#!/bin/sh
NANE=`iwconfig ath1 | scut -p 802.11`
CHWIDTH=`iwpriv ath1 get_chwidth | scut -p :`
CHAN=`iwpriv ath1 get_deschan | scut -p :`
ENCRTYPE=`iwconfig ath1 | scut -p key:`

if [ $CHWIDTH -eq 2 ]; then
	if [ "$ENCRTYPE" != "off" ] && [ "$NAME" != "a" ]; then
		NANE="a"
	fi	
	if [ $CHAN -eq 36 ]; then
		echo "36&40&44&48 (11$NANE 5GHz)"
	elif [ $CHAN -eq 40 ]; then
		echo "40&36&44&48 (11$NANE 5GHz)"
	elif [ $CHAN -eq 44 ]; then
		echo "44&36&40&48 (11$NANE 5GHz)"
	elif [ $CHAN -eq 48 ]; then
		echo "48&36&40&44 (11$NANE 5GHz)"
	elif [ $CHAN -eq 52 ]; then
		echo "52&56&60&64 (11$NANE 5GHz)"
	elif [ $CHAN -eq 56 ]; then
		echo "56&52&60&64 (11$NANE 5GHz)"
	elif [ $CHAN -eq 60 ]; then
		echo "60&52&56&64 (11$NANE 5GHz)"
	elif [ $CHAN -eq 64 ]; then
		echo "64&52&56&60 (11$NANE 5GHz)"
	elif [ $CHAN -eq 100 ]; then
		echo "100&104&108&112 (11$NANE 5GHz)"
	elif [ $CHAN -eq 104 ]; then
		echo "104&100&108&112 (11$NANE 5GHz)"
	elif [ $CHAN -eq 108 ]; then
		echo "108&100&104&112 (11$NANE 5GHz)"
	elif  [ $CHAN -eq 112 ]; then
		echo "112&100&104&108 (11$NANE 5GHz)"
	elif  [ $CHAN -eq 116 ]; then
		echo "116&120&124&128 (11$NANE 5GHz)"
	elif [ $CHAN -eq 120 ]; then
		echo "120&116&124&128 (11$NANE 5GHz)"
	elif [ $CHAN -eq 124 ]; then
		echo "124&116&120&128 (11$NANE 5GHz)"
	elif [ $CHAN -eq 128 ]; then
		echo "128&116&120&124 (11$NANE 5GHz)"
	else
		echo "Unknow state"
	fi
else
	echo "Unknow state"
fi

