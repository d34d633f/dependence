#!/bin/sh
<?
include "/htdocs/phplib/xnode.php";

$wan_inf = XNODE_getpathbytarget("/runtime", "inf", "uid", "WAN-1", 0);
if($wan_inf == "")
	return 0;

$addrtype = get("x", $wan_inf."/inet/addrtype");
$ipaddr = "";

if($addrtype == "ppp4")
{
	$ipaddr = get("x", $wan_inf."/inet/ppp4/local");
}

if($addrtype == "ipv4")
{
	$ipaddr = get("x", $wan_inf."/inet/ipv4/ipaddr");
}

if($ipaddr == "")
{
	echo "xmldbc -s /runtime/wanstatus 0\n";
	return 0;
}
else
{
	echo "xmldbc -s /runtime/wanstatus 1\n";
	return 1;
}

?>
