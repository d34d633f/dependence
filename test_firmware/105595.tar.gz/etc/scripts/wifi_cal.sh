#!/bin/sh
echo [$0] $1 $2 ... > /dev/console

stop_5G()
{
	echo "5G stop"
	killall Qcmbr
	rmmod smart_antenna.ko
	rmmod ath_pktlog.ko
	rmmod qca_ol.ko
	rmmod qca_da.ko
	rmmod ath_dev.ko
	rmmod hst_tx99.ko
	rmmod ath_rate_atheros.ko
	rmmod ath_hal.ko
	rmmod umac.ko
	rmmod ath_spectral.ko
	rmmod ath_dfs.ko
	rmmod qdf.ko
	rmmod asf.ko
#	rmmod mem_manager.ko
	rm /dev/caldata
}

start_5G() 
{
	echo "5G start" > /dev/console
	ln -s /dev/mtdblock/6 /dev/caldata
#	insmod /lib/modules/mem_manager.ko
	insmod /lib/modules/asf.ko
	insmod /lib/modules/qdf.ko
	insmod /lib/modules/ath_dfs.ko
	insmod /lib/modules/ath_spectral.ko
	insmod /lib/modules/umac.ko ahbskip=1
	insmod /lib/modules/ath_hal.ko
	insmod /lib/modules/ath_rate_atheros.ko
	insmod /lib/modules/hst_tx99.ko
	insmod /lib/modules/ath_dev.ko
	insmod /lib/modules/qca_da.ko
	insmod /lib/modules/qca_ol.ko testmode=1
	insmod /lib/modules/ath_pktlog.ko
	insmod /lib/modules/smart_antenna.ko
# clicmd will call this script.After it start daemon ,telnet can not work with other input. 
#	/usr/sbin/Qcmbr -instance 1 -pcie 0 &
}

start_24G()
{
	mknod /dev/dk0 c 63 0
	mknod /dev/dk1 c 63 1
	ln -s /dev/mtdblock/6 /dev/caldata
#	insmod /lib/modules/mem_manager.ko
	insmod /lib/modules/asf.ko
	insmod /lib/modules/qdf.ko
	insmod /lib/modules/ath_dfs.ko
	insmod /lib/modules/ath_spectral.ko
	insmod /lib/modules/umac.ko ahbskip=1
	insmod /lib/modules/ath_hal.ko
	insmod /lib/modules/ath_rate_atheros.ko
	insmod /lib/modules/hst_tx99.ko
	insmod /lib/modules/ath_dev.ko
	insmod /lib/modules/qca_da.ko
	insmod /lib/modules/qca_ol.ko testmode=1
	insmod /lib/modules/ath_pktlog.ko
	insmod /lib/modules/smart_antenna.ko
	insmod /lib/modules/art.ko
# clicmd will call this script.After it start daemon ,telnet can not work with other input. 
#	/usr/sbin/nart.out -instance 0 &
}
stop_24G()
{
	killall -9 nart.out
	rmmod art.ko
	rmmod smart_antenna.ko
	rmmod ath_pktlog.ko
	rmmod qca_ol.ko
	rmmod qca_da.ko
	rmmod ath_dev.ko
	rmmod hst_tx99.ko
	rmmod ath_rate_atheros.ko
	rmmod ath_hal.ko
	rmmod umac.ko
	rmmod ath_spectral.ko
	rmmod ath_dfs.ko
	rmmod qdf.ko
	rmmod asf.ko
#	rmmod mem_manager.ko
	rm /dev/dk0
	rm /dev/dk1
	rm /dev/caldata
}

filecheck()
{
	checkfile=0
	[ -f /usr/sbin/nart.out ] && checkfile=$((checkfile*2 + 1)) || echo "nart.out transmit failure" 
	[ -f /usr/sbin/Qcmbr ] && checkfile=$((checkfile*2 + 1)) || echo "Qcmbr transmit failure" 
	[ -f /usr/lib/libanwi.so ] && checkfile=$((checkfile*2 + 1)) || echo "libanwi.so transmit failure"
	[ -f /usr/lib/libcal-2p.so ] && checkfile=$((checkfile*2 + 1)) || echo "libcal-2p.so transmit failure" 
	[ -f /usr/lib/libar9287.so ] && checkfile=$((checkfile*2 + 1)) || echo "libar9287.so transmit failure" 
	[ -f /usr/lib/libar9300.so ] && checkfile=$((checkfile*2 + 1)) || echo "libar9300.so transmit failure" 
	[ -f /usr/lib/libfield.so ] && checkfile=$((checkfile*2 + 1)) || echo "libfield.so transmit failure"
	[ -f /usr/lib/libqc98xx.so ] && checkfile=$((checkfile*2 + 1)) || echo "libqc98xx.so transmit failure"
	[ -f /usr/lib/libtlvtemplate.so ] && checkfile=$((checkfile*2 + 1)) || echo "libtlvtemplate.so transmit failure"
	[ -f /usr/lib/libpart.so ] && checkfile=$((checkfile*2 + 1)) || echo "libpart.so transmit failure"
	[ -f /usr/lib/libtlvutil.so ] && checkfile=$((checkfile*2 + 1)) || echo "libtlvutil.so transmit failure"
	[ -f /usr/lib/liblinkAr9k.so ] && checkfile=$((checkfile*2 + 1)) || echo "liblinkAr9k.so transmit failure"
	[ -f /usr/lib/libLinkQc9K.so ] && checkfile=$((checkfile*2 + 1)) || echo "libLinkQc9K.so transmit failure"
	[ -f /lib/modules/art.ko ] && checkfile=$((checkfile*2 + 1)) || echo "art.ko transmit failure" 
	[ -f /lib/firmware/QCA9888/hw.2/utf.bin ] && checkfile=$((checkfile*2 + 1)) || echo "utf.bin transmit failure" 
	[ -f /lib/firmware/QCA9888/hw.2/utf.codeswap.bin ] && checkfile=$((checkfile*2 + 1)) || echo "utf.codeswap.bin transmit failure" 


# echo "checkfile value is $checkfile"
 if [ $checkfile = 65535 ]; then
 	echo "Files transmit success"
 else 
 	echo "Files transmit failure"
 fi


}

clean_art_part()
{
	dd if=/dev/zero bs=1k count=64 | tr "\000" "\377" > /tmp/ff.bin
	dd if=/tmp/ff.bin  of=/dev/mtdblock/6 bs=64k
	sync
	rm /tmp/ff.bin
}



case "$1" in
5G)
	case "$2" in
		start)
			echo "calibration_5G_start" 
			start_5G
			;;
		stop)
			echo "calibration_5G_stop" 
			stop_5G
			;;
		restart)
			echo "calibration_5G_restart" 
			stop_5G
			start_5G
			;;
		*)
			echo "Usage $0 $1 [ start | stop | restart ]" 
			;;
	esac		
	;;
24G)
    case "$2" in
		start)
			echo "calibration_24G_start" 
			start_24G
			;;
		stop)
			echo "calibration_24G_stop" 
			stop_24G
			;;
		restart)
			stop_24G
			start_24G
			echo "calibration_24G_restart" 
			;;
		*)
		echo "Usage $0 $1 [ start | stop | restart ]" 
			;;
	esac
	;;

filecheck)
		filecheck
	;;
cleanart)
	clean_art_part
	;;

start_5G_daemon)
		/usr/sbin/Qcmbr -instance 1 -pcie 0 &
	;;
start_24G_daemon)
		/usr/sbin/nart.out -instance 0 &
	;;
*)
	echo "Usage $0 [ 5G | 24G | cleanart | start_5G_daemon | start_24G_daemom]" 
	 ;;
esac


exit 0

