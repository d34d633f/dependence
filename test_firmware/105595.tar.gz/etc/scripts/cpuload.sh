#!/bin/sh

CPULOADPRE="-1"
NETBUDGET="/proc/sys/net/core/netdev_budget"
NETMAXBACKLOG="/proc/sys/net/core/netdev_max_backlog"

QCAHNAT_POLL_TIME="/proc/qca_switch/nf_athrs17_hnat_poll_msec"
CONNTRACK_RELEASE_TIME="/proc/sys/net/ipv4/netfilter/ip_conntrack_tcp_timeout_established"
CONNTRACKPRE="-1"


echo 300 > $NETBUDGET
echo 1000 > $NETMAXBACKLOG

while :
do
  CPULOADNOW=`cat /proc/loadavg | cut -d '.' -f 1`
  CONNTRACKNOW=`cat /proc/sys/net/ipv4/netfilter/ip_conntrack_count`
#  echo "CPU loading : "$CPULOADNOW

  if [ "$CPULOADNOW" -ge "10" ] || [ "$CONNTRACKNOW" -ge "20000" ]; then
    CPULOADNOW=10
  elif [ "$CPULOADNOW" -ge "6" ] || [ "$CONNTRACKNOW" -ge "10000" ]; then
    CPULOADNOW=6
  else
    CPULOADNOW=0
  fi

  if [ $CPULOADNOW -ne $CPULOADPRE ]; then
    if [ $CPULOADNOW -eq 10 ]; then
      echo 8 > $NETBUDGET
      echo 100 > $NETMAXBACKLOG
    elif [ $CPULOADNOW -eq 6 ]; then
      echo 32 > $NETBUDGET
      echo 200 > $NETMAXBACKLOG
    else
      echo 300 > $NETBUDGET
      echo 1000 > $NETMAXBACKLOG
    fi
    CPULOADPRE=$CPULOADNOW
  fi

#here is for conntrack checking #
  if [ "$CONNTRACKNOW" -ge "20000" ]; then
    CONNTRACKNOW=20000
  elif [ "$CONNTRACKNOW" -ge "10000" ]; then
    CONNTRACKNOW=10000
  else
    CONNTRACKNOW=0
  fi

  if [ $CONNTRACKNOW -ne $CONNTRACKPRE ]; then
    if [ $CONNTRACKNOW -eq 20000 ]; then
	  echo 180 > $CONNTRACK_RELEASE_TIME
	  echo 20 > $QCAHNAT_POLL_TIME
	  #3*60
    elif [ $CONNTRACKNOW -eq 10000 ]; then
	  echo 86400 > $CONNTRACK_RELEASE_TIME
	  echo 10 > $QCAHNAT_POLL_TIME
	  #24*60*60
    else
	  echo 432000 > $CONNTRACK_RELEASE_TIME
	  echo 3 > $QCAHNAT_POLL_TIME
	  #5*24*60*60
    fi
    CONNTRACKPRE=$CONNTRACKNOW
  fi
  
  sleep 1
done
