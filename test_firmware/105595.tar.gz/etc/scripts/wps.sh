#!/bin/sh
ALLIF=`ifconfig | grep -i ath | cut -f1 -d' '`

if ["$ALLIF" = ""]; then
	echo "wireless is off, ignore wps" > /dev/console
else
	echo [$0] $1 $2 ... > /dev/console
	phpsh /etc/scripts/wps/wps.php PARAM1=$1 PARAM2=$2
fi
exit 0
