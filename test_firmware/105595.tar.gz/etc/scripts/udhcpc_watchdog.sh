#!/bin/sh

CONSOLEDEV="/dev/console"
SLEEPTIME=60
UDHCPC_RESTART=0

need_to_check () {
	mode=`xmldbc -w /device/layout`
	if [ "$mode" != "router" ]; then
		return 0
	fi

	addrtype=`xmldbc -w /inet/entry:3/addrtype`
	if [ "$addrtype" != "ipv4" ]; then
		return 0
	fi

	static=`xmldbc -w /inet/entry:3/ipv4/static`
	if [ "$static" != "0" ]; then
		return 0
	fi

	return 1
}

while :
do

	#echo "LOOP Monitor >>>>>" > $CONSOLEDEV
	#echo "SLEEPTIME="$SLEEPTIME > $CONSOLEDEV
	#echo "UDHCPC_RESTART="$UDHCPC_RESTART > $CONSOLEDEV
	#echo "#####" > $CONSOLEDEV
	#echo "" > $CONSOLEDEV

	need_to_check	
	if [ "$?" == "1" -a -f /var/run/WAN-1.UP ]; then
		UDHCPC=`ps | grep -v "grep" | grep -e "udhcpc -i eth0" -e "udhcpc -u -i eth0" |  scut -f 1` 
		#echo "UDHCPC_PID="$UDHCPC > $CONSOLEDEV
		if [ "$UDHCPC" == "" ]; then

			sleep 60

			need_to_check
			if [ "$?" == "1" -a -f /var/run/WAN-1.UP ]; then
				UDHCPC=`ps | grep -v "grep" | grep -e "udhcpc -i eth0" -e "udhcpc -u -i eth0" |  scut -f 1` 
				if [ "$UDHCPC" == "" ]; then
					#if [ $UDHCPC_RESTART -gt 2 ]; then
						#echo "UDHCPC_RESTART="$UDHCPC_RESTART > $CONSOLEDEV
						#sleep 5
						#/etc/scripts/push_msg.sh "dhcpc_die_more_than_2"
					#fi

					#echo "UDHCPC_RESTART="$UDHCPC_RESTART > $CONSOLEDEV
					#echo "Restart WAN service" > $CONSOLEDEV
					# we need to do restart twice, first restart has some bad status.
					# /var/run/WAN-1.UP won't show up, so we do restart again!
					#/etc/scripts/push_msg.sh "dhcpc_die"
					service WAN restart
					sleep 20
					service WAN restart
					sleep 100
                    UDHCPC_RESTART=`expr $UDHCPC_RESTART + 1`
                else 
					UDHCPC_RESTART=0
				fi
			fi
		else
			UDHCPC_RESTART=0
		fi
	fi

	need_to_check
	if [ "$?" == "1" -a -f /var/run/WAN-1.UP -a -f /tmp/udhcpc_lease ]; then
		UDHCP_LEASE=`cat /tmp/udhcpc_lease`
		if [ "$UDHCP_LEASE" == "1" ]; then
			#echo "UDHCP_LEASE="$UDHCP_LEASE > $CONSOLEDEV

			sleep 30
			
			need_to_check
			if [ "$?" == "1" -a -f /tmp/udhcpc_lease ]; then
				UDHCP_LEASE=`cat /tmp/udhcpc_lease`
				#echo "UDHCP_LEASE="$UDHCP_LEASE > $CONSOLEDEV

				if [ "$UDHCP_LEASE" == "1" ]; then
					#echo "UDHCP_LEASE still is 1, reboot" > $CONSOLEDEV
					sleep 10
					service WAN restart
					#/etc/scripts/push_msg.sh "dhcpc_lease_problem"
				fi

			fi
		fi
	fi

	sleep $SLEEPTIME
done
