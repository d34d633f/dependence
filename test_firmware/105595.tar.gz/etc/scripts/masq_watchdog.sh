#!/bin/sh

CONSOLEDEV="/dev/console"
SLEEPTIME=40
MASQCOUNT=0

LAYOUT=`xmldbc -w device/layout`
if [ "$LAYOUT" != "router" ]; then
return 0
fi

#wait for boot up.
sleep 80

while :
do
	phpsh /etc/scripts/get_wanstatus.php
	WANSTATUS=`xmldbc -g /runtime/wanstatus`
	#check wan get ip addr
	if [ "$WANSTATUS" == "1" ]; then
	
		MASQRUL=`iptables -t nat -nvL PST.MASQ.NAT-1 | grep MASQUERADE | scut -f 3`
		MASQRUL_NAT=`iptables -t nat -nvL POSTROUTING | grep PST.MASQ.NAT-1 | scut -f 3`
		if [ "$MASQRUL" == "" ] || [ "$MASQRUL_NAT" == "" ]; then
			MASQCOUNT=`expr $MASQCOUNT + 1`
			if [ "$MASQCOUNT" -ge "3" ]; then
				#iptables -t nat -A PST.MASQ.NAT-1 -j MASQUERADE
				service WAN restart
				MASQCOUNT=0
			fi
		else
			MASQCOUNT=0
		fi
	else
		MASQCOUNT=0
	fi
	sleep $SLEEPTIME;
done
