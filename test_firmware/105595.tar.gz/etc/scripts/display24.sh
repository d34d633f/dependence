#!/bin/sh
DATARATE=`iwconfig ath0 | scut -p Rate:`
NANE=`iwconfig ath0 | scut -p 802.11`
CHWIDTH=`iwpriv ath0 get_chwidth | scut -p :`
CHAN=`iwpriv ath0 get_deschan | scut -p :`
EXCHANPLUS=$(($CHAN+4))
EXCHANMINUS=$(($CHAN-4))
#ENCRTYPE=`xmldbc -g wifi/entry:1/encrtype`
ENCRTYPE=`iwconfig ath0 | scut -p key:`

#if [ $ENCRTYPE -eq "NONE" ]; then
if [ $CHWIDTH -eq 1 ] && [ "$DATARATE" == "300" ]; then
	if [ "$NANE" == "ng" ] && [ "$ENCRTYPE" != "off" ]; then
		NANE="n"
	fi	
	if [ $CHAN -lt 5 ]; then
		echo "$CHAN&$EXCHANPLUS (11$NANE 2.4GHz)"
	else
		echo "$CHAN&$EXCHANMINUS (11$NANE 2.4GHz)"
	fi
elif [ $CHWIDTH -eq 0 ] && [ "$DATARATE" == "144.4" ]; then
	if [ "$NANE" == "ng" ] && [ "$ENCRTYPE" != "off" ]; then
		NANE="n"
	fi
	echo "$CHAN (11$NANE 2.4GHz)"
else
	echo "$CHAN (11$NANE 2.4GHz)"
fi
#echo "1 (11n 2.4GHz)"
