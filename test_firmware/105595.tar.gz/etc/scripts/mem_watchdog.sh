#!/bin/sh

CONSOLEDEV="/dev/console"
SLEEPTIME=3

while :
do
	MEMFREE=`cat /proc/meminfo | grep MemFree | scut -f 2`
	
	if [ "$MEMFREE" -le "2000" ]; then
		echo "memory going to full. reboot." > $CONSOLEDEV
		echo 2 > /proc/qca_switch/nf_athrs17_hnat_need_clean
		echo 1 > /proc/qca_switch/nf_athrs17_hnat_need_clean
		echo 0 > /proc/qca_switch/nf_athrs17_hnat
		sleep 1
		echo b > /proc/sysrq-trigger
	fi

	sleep $SLEEPTIME;
done
