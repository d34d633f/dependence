<?
include "/etc/services/PHYINF/phywifi.php";
wificonfig("BAND24G-1.1");
?>
