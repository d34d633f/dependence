<?
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/phyinf.php";

function startcmd($cmd)	{fwrite(a,$_GLOBALS["START"], $cmd."\n");}
function stopcmd($cmd)	{fwrite(a,$_GLOBALS["STOP"], $cmd."\n");}
function error($errno)	{startcmd("exit ".$errno); stopcmd("exit ".$errno);}

fwrite("w",$START, "#!/bin/sh\n");
fwrite("w", $STOP, "#!/bin/sh\n");


$wlanmac = query("/runtime/devdata/wlanmac");
if ($wlanmac=="")   {$wlanmac="00:11:22:33:44:55";}
$wlanmac2 = query("/runtime/devdata/wlan5mac");
if ($wlan5mac=="")  {$wlanmac5="00:11:22:33:44:57";}

$country = query("/runtime/devdata/countrycode");
	if		($country == "AU")	{$countryID=36;  }
	else if	($country == "CA")	{$countryID=124;  }
	else if	($country == "CN")	{$countryID=156;  }
	else if	($country == "SG")	{$countryID=702;  }
	else if	($country == "IL")	{$countryID=376;  }
	else if	($country == "KR")	{$countryID=410;  }
	else if	($country == "JP")	{$countryID =4015; }
	else if	($country == "EG")	{$countryID=818;  }
	else if	($country == "BR")	{$countryID=76;  }
	else if ($country == "LA")  {$countryID=32;}
	else if	($country == "RU")	{$countryID=643;  }
	else if	($country == "US")	{$countryID=841;  }
	// NA == US 
	else if ($country == "NA") 	{$countryID=841;  }
	else if ($country == "EU") 	{$countryID=250;  }
	// EU == GB 
	else if ($country == "BG") 	{$countryID=100; }
	else if ($country == "TW") 	{$countryID=158; }
	else if ($country == "MY")  {$countryID=458; }
	else if ($country == "IN")  {$countryID=356; }
	else {$countryID =841;}
$mfcmode = query("/runtime/devdata/mfcmode");
fwrite("a",$START,"dd if=/dev/mtdblock/6 of=/tmp/wifi0.caldata bs=32 count=377 skip=128\n");
fwrite("a",$START,"dd if=/dev/mtdblock/6 of=/tmp/wifi1.caldata bs=32 count=377 skip=640\n");
if($mfcmode != 1)
{
	fwrite("a",$START,"insmod /lib/modules/mem_manager.ko\n");
	fwrite("a",$START,"insmod /lib/modules/asf.ko\n");
	fwrite("a",$START,"insmod /lib/modules/qdf.ko\n");
	fwrite("a",$START,"insmod /lib/modules/ath_dfs.ko\n");
	fwrite("a",$START,"insmod /lib/modules/ath_spectral.ko\n");
	fwrite("a",$START,"insmod /lib/modules/umac.ko CountryCode_2g=".$countryID."\n");
	fwrite("a",$START,"insmod /lib/modules/ath_hal.ko\n");
	fwrite("a",$START,"insmod /lib/modules/ath_rate_atheros.ko\n");
	fwrite("a",$START,"insmod /lib/modules/hst_tx99.ko\n");
	fwrite("a",$START,"insmod /lib/modules/ath_dev.ko\n");
	fwrite("a",$START,"insmod /lib/modules/qca_da.ko\n");
	fwrite("a",$START,"insmod /lib/modules/qca_ol.ko CountryCode_5g=".$countryID."\n");
	
	fwrite("a",$START,"insmod /lib/modules/ath_pktlog.ko\n");
	fwrite("a",$START,"insmod /lib/modules/smart_antenna.ko\n");

	fwrite("a",$START,"sleep 1\n");
	fwrite("a",$START,"iwpriv wifi0 setCountryID ".$countryID."\n");
	fwrite("a",$START,"iwpriv wifi1 setCountryID ".$countryID."\n");

	fwrite("a",$STOP,"rmmod smart_antenna.ko\n");
	fwrite("a",$STOP,"rmmod ath_pktlog.ko\n");
	fwrite("a",$STOP,"rmmod qca_ol.ko\n");
	fwrite("a",$STOP,"rmmod qca_da.ko\n");
	fwrite("a",$STOP,"rmmod ath_dev.ko\n");
	fwrite("a",$STOP,"rmmod hst_tx99.ko\n");
	fwrite("a",$STOP,"rmmod ath_rate_atheros.ko\n");
	fwrite("a",$STOP,"rmmod ath_hal.ko\n");
	fwrite("a",$STOP,"rmmod umac.ko\n");
	fwrite("a",$STOP,"rmmod ath_spectral.ko\n");
	fwrite("a",$STOP,"rmmod ath_dfs.ko\n");
	fwrite("a",$STOP,"rmmod qdf.ko\n");
	fwrite("a",$STOP,"rmmod asf.ko\n");
	fwrite("a",$STOP,"rmmod mem_manager.ko\n");
}

fwrite("a",$START,  "exit 0\n");
fwrite("a",$STOP,	"exit 0\n");
?>
