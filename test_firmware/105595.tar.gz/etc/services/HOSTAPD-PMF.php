<?
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/phyinf.php";
include "/htdocs/webinc/config.php";
include "/var/topology.conf";

function startcmd($cmd)	{fwrite(a,$_GLOBALS["START"], $cmd."\n");}
function stopcmd($cmd)	{fwrite(a,$_GLOBALS["STOP"], $cmd."\n");}
function schcmd($uid)
{
	/* Get schedule setting */
	$base = XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);
	$sch = query($base."/schedule");
	if ($sch=="")	{$cmd = "start";}
	else	{$cmd = XNODE_getschedule2013cmd($sch);}
	return $cmd;
}
function needsch($uid)
{
	/* Get schedule setting */
	$base = XNODE_getpathbytarget("", "phyinf", "uid", $uid, 0);
	$sch = query($base."/schedule");
	if ($sch=="")	{$needsch = "0";}
	else	{$needsch = "1";}
	if (query($base."/active")=="0") {$needsch = "0";}
	return $needsch;
}

/**************************************************************************************/
fwrite(w,$_GLOBALS["START"], "#!/bin/sh\n");
fwrite(w,$_GLOBALS["STOP"],  "#!/bin/sh\n");
startcmd("killall hostapd > /dev/null 2>&1");
stopcmd("killall hostapd > /dev/null 2>&1; sleep 1");

//cfg is in /var/topology.conf
startcmd("hostapd -B ".$cfg."-e /var/run/123 &");

$needsch_2g=needsch("BAND24G-1.1");
$needsch_5g=needsch("BAND5G-1.1");
fwrite("a",$START,"service PHYINF.BAND5G-1.1_ACTIVE start\n");
fwrite("a",$START,"service PHYINF.BAND24G-1.1_ACTIVE start\n");
if($needsch_2g=="1"){
	startcmd("sleep 2");
	fwrite("a",$START,"service PHYINF.BAND24G-1.1_ACTIVE ".schcmd("BAND24G-1.1")."\n");	
}
if($needsch_5g=="1"){
	startcmd("sleep 2");
	fwrite("a",$START,"service PHYINF.BAND5G-1.1_ACTIVE ".schcmd("BAND5G-1.1")."\n");
}
fwrite("a",$STOP,"service PHYINF.BAND24G-1.1_ACTIVE stop\n");	
fwrite("a",$STOP,"service PHYINF.BAND5G-1.1_ACTIVE stop\n");

?>
