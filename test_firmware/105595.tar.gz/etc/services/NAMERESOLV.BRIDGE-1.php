<? /* Maker :sam_pan Date: 2010/3/22 03:35 */

include "/etc/services/NAMERESOLV/nameresolv.php";
netbios_setup("BRIDGE-1");
?>
