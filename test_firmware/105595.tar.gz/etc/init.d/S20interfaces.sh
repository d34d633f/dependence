#!/bin/sh

insmod /lib/modules/shortcut-fe.ko
insmod /lib/modules/shortcut-fe-ipv6.ko
insmod /lib/modules/qca-ssdk.ko
insmod /lib/modules/fast-classifier.ko

#for QSDK HW NAT, it use acct to count
sysctl -w net.netfilter.nf_conntrack_acct=1

ssdk_sh nat global set enable disable 

#sysctl -w dev.nss.general.redirect=1
#sysctl -w dev.nss.general.rps=1 >/dev/null 2>/dev/null
