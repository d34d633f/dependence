#!/bin/sh

insmod ./lib/modules/gpio-button-hotplug.ko

wanidx=`xmldbc -g /device/router/wanindex`
if [ "$wanidx" != "" ]; then 
	gpiod -w $wanidx &
else
	gpiod &
fi

