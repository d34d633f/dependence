<?
$m_context_title = "IPv6 Settings";
$m_enable_ipv6  = "Enable IPv6";
$m_lan_type  = "Get IP From";
$m_static_ip = "Static";
$m_auto      = "Auto";

$m_ipaddr    = "IP Address";
$m_subnet    = "Prefix";
$m_dns   	 = "DNS";
$m_gateway   = "Default Gateway";

$a_invalid_ip= "Invalid IP address !";
$a_invalid_netmask= "Invalid Prefix !";
$a_invalid_dns= "Invalid DNS !";
$a_invalid_gateway= "Invalid gateway address !";
$a_connect_new_ip = "Please connect with new IP Address !";
$a_enable_ipv6 = "If enable ipv6, AP Client will set to Access Point.";
?>
