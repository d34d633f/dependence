<?
$m_context_title = "Configuration File Upload and Download";
$m_save_cfg = "Load Settings to Local Hard Drive";
$m_save = "Download";
$m_load_cfg = "Upload File";
$m_b_load = "Upload";
$m_upload_config_title = "Upload Configuration File";
$m_download_config_title = "Download Configuration File";
$m_upload_cwm_title = "Upload CWM File";

$a_empty_cfg_file_path	="Please select a saved configuration file to upload.";
$a_empty_cwm_file_path  ="Please select a saved CWM file to upload.";
$a_error_cfg_file_path	="File extension error! It must be \\\".dcf\\\" . Please try again!";
$a_error_cwm_file_path = "File extension error! It must be \\\".dat\\\" . Please try again!";
$a_sure_to_reload_cfg	="Load Settings From File ?";
?>
