<?
$m_context_title = "System Settings";
$m_reboot		=" Restart the Device";
$m_b_reboot		=" Restart";
$m_factory_reset	="Restore to Factory Default Settings";
$m_b_restore		="Restore";
$m_clear_lang_pack ="Clear Language Pack"; 
$m_clear ="Clear";
$a_sure_to_clear_lang ="Clear the language pack ?";
$a_sure_to_factory_reset="Restore to Factory Default Settings ?";
$a_sure_to_reboot	="Restart Access Point ?";

?>