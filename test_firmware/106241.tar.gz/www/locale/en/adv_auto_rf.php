<?
$m_context_title = "Auto-RF";
$m_enable_auto_rf = "Enable Auto-RF";
$m_disable = "Disable";
$m_enable = "Enable";
$m_init_auto_rf = "Initiate Auto-RF";
$m_optimize = "Auto-RF Optimize";
$m_init_auto = "Auto-Initiate";
$m_init_period = "Auto-Initiate Period";
$m_hour = "(hours)";
$m_miss = "Miss Threshold";
$m_rssi = "RSSI Threshold";
$m_10 = "10";
$m_20 = "20";
$m_30 = "30";
$m_40 = "40";
$m_50 = "50";
$m_60 = "60";
$m_70 = "70";
$m_80 = "80";
$m_90 = "90";
$m_100 = "100";
$m_freq = "RF Report Frequency";
$m_second = "(Seconds)";

$a_empty_period = "Please input a Period value.";
$a_invalid_period = "The Period value must be 1~24.";
$a_empty_miss = "Please input a Miss Threshold value.";
$a_invalid_miss = "The Miss Threshold value must be 0~20.";
$a_empty_freq = "Please input a Frequency value.";
$a_invalid_freq = "The Frequency value must be 5~300.";
?>
