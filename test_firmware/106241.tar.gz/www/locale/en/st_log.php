<?
$m_context_title	= "View Log";

$m_first_page	= "First Page";
$m_last_page	= "Last Page";
$m_previous	= "Previous";
$m_next		= "Next";
$m_clear	= "Clear";
$m_savelog	= "Save Log";

$m_time		= "Time";
$m_type		= "Priority";//"Type";
$m_message	= "Message";
$m_page		= "Page";
$m_of		= "of";
?>
