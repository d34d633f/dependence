﻿<?
$m_context_title = "ARP Spoofing Prevention Settings";
$m_arp_spoofing = "ARP Spoofing Prevention";
$m_disable = "Disable";
$m_enable = "Enable";
$m_add_title = "Add Gateway Address";
$m_gateway_ip = "Gateway IP Address";
$m_gateway_mac = "Gateway MAC Address";
$m_add = "Add";
$m_clear = "Clear";
$m_list_title ="Gateway Address List";
$m_total_entries = "Total Entries";
$m_del_all = "Delete All";
$m_edit = "Edit";
$m_delete = "Delete";

$a_rule_del_all_confirm = "Are you sure delete all the rules?";
$a_empty_ip_addr = "Please input IP address!";
$a_invalid_ip = "Invalid IP address!";
$a_can_not_same_ip = "The IP address has already been added in the list!";
$a_empty_mac_addr = "Please input MAC address!";
$a_invalid_mac = "Invalid MAC address!";
$a_can_not_same_mac = "The MAC address has already been added in the list!";
$a_confirm_delete = "Are you sure that you want to delete this rule?";
?> 
