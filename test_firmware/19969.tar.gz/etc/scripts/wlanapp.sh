#!/bin/sh

sysconf wlanapp $*

