#!/bin/sh
phpsh /etc/events/DHCPS4-STOP.php INF=$1
exit 0
