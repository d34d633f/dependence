#!/bin/sh
mknod /dev/gpio		c 77 0
