#!/bin/sh
[ "$1" != "" ] && sleep "$1"
reboot
