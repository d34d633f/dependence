#!/bin/sh
. /etc/config/defines
case "$1" in
start)
	echo "start LAN ..."		> /dev/console
	/etc/templates/lan.sh start	> /dev/console
	echo "start fresetd ..."	> /dev/console
	fresetd &
	echo "enable LAN ports ..."	> /dev/console
	/etc/scripts/enlan.sh		> /dev/console
	echo "start WLAN ..."		> /dev/console
	/etc/templates/wlan.sh start	> /dev/console
	echo "start RG ..."		> /dev/console
	/etc/templates/rg.sh start	> /dev/console
	echo "start DNRD ..."		> /dev/console
	/etc/templates/dnrd.sh start	> /dev/console
	echo "start runtime daemon ..."	> /dev/console
	/etc/templates/runtimed.sh &	> /dev/console
	# start telnet daemon
	/etc/scripts/misc/telnetd.sh	> /dev/console
	# Start the UPNP at the last.
	echo "start UPNPD ..."		> /dev/console
	/etc/templates/upnpd.sh start	> /dev/console
	echo "start WAN ..."		> /dev/console
	/etc/scripts/misc/setwantype.sh	> /dev/console
	/etc/templates/wan.sh start	> /dev/console
	;;
stop)
	echo "stop WAN ..."		> /dev/console
	/etc/templates/wan.sh stop	> /dev/console
	echo "stop UPNPD ..."		> /dev/console
	/etc/templates/upnpd.sh stop	> /dev/console
	echo "stop fresetd ..."		> /dev/console
	killall fresetd
	echo "stop runtime daemon ..."	> /dev/console
	/etc/templates/runtimed.sh stop	> /dev/console
	echo "stop DNRD ..."		> /dev/console
	/etc/templates/dnrd.sh stop	> /dev/console
	echo "stop RG ..."		> /dev/console
	/etc/templates/rg.sh stop	> /dev/console
	echo "stop WLAN ..."		> /dev/console
	/etc/templates/wlan.sh stop	> /dev/console
	echo "stop LAN ..."		> /dev/console
	/etc/templates/lan.sh stop	> /dev/console
	;;
restart)
	$0 stop
	$0 start
	;;
*)
	echo "Usage: system.sh {start|stop|restart}"
	;;
esac
exit 0
