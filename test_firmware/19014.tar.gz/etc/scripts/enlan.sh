#!/bin/sh
echo "WRITE 0 0 8000" > /proc/driver/ae531x
echo "WRITE 1 0 8000" > /proc/driver/ae531x
echo "WRITE 2 0 8000" > /proc/driver/ae531x
echo "WRITE 3 0 8000" > /proc/driver/ae531x
