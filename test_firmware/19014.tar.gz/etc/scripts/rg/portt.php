#!/bin/sh
# vi: set sw=4 ts=4:
[ -d /var/porttrigger ] || mkdir -p /var/porttrigger
rm -f /var/porttrigger/*
iptables -F FOR_PORTT
iptables -t nat -F PRE_PORTT
trigger -m flush
<?

$limit=" -m limit --limit 30/m --limit-burst 5";
$log  =" -j LOG --log-level info --log-prefix PTR:";

$count=0;
for (/nat/porttrigger/entry)
{
	$en=query(enable);
	if ($en == 1)
	{
		$count = $count + 1;
		$prot  = query(triggerprotocol);
		$begin = query(triggerportbegin);
		$end   = query(triggerportend);
		$port  = query(publicport);

		if ($begin == $end || $end == "") { $single=1; }
		else { $single=0; }

		if ($prot == 2 || $prot == 0)
		{
			if ($single == 1)	{ echo "iptables -A FOR_PORTT -p udp --dport ".$begin; }
			else				{ echo "iptables -A FOR_PORTT -p udp -m mport --ports ".$begin.":".$end; }
			echo $limit.$log.$@.":\n";
		}
		if ($prot == 1 || $prot == 0)
		{
			if ($single == 1)	{ echo "iptables -A FOR_PORTT -p tcp --dport ".$begin; }
			else				{ echo "iptables -A FOR_PORTT -p tcp -m mport --ports ".$begin.":".$end; }
			echo $limit.$log.$@.":\n";
		}
		if		($prot == 0)	{ echo "echo \"both,"; }
		else if ($prot == 1)	{ echo "echo \"tcp,"; }
		else if ($prot == 2)	{ echo "echo \"udp,"; }
		echo $port."\" > /var/porttrigger/".$@."\n";
	}
}

?>
rgdb -s /tmp/iptables/porttrigger <? if ($count==0) {echo "0";} else {echo "1";} ?>
