#!/bin/sh
. /etc/config/defines
echo [$0] ... > /dev/console
echo "Set fixed nodes .." > /dev/console
# Update mac address in env to bd. 
env_wan=`rgcfg getenv -n $nvram -e wanmac`
env_wlan=`rgcfg getenv -n $nvram -e wlanmac`
bd_enet=`bdtool get -d $nvram -e enet0Mac`
bd_wlan=`bdtool get -d $nvram -e wlan0Mac`
hw_rev=`rgcfg getenv -n $nvram -e hwrev`
[ "$env_wan" != "$bd_enet" ] && bdtool set -d $nvram -e enet0Mac=$env_wan
[ "$env_wlan" != "$bd_wlan" ] && bdtool set -d $nvram -e wlan0Mac=$env_wlan
[ "$hw_rev" = "" ] && hw_rev="E1"

# Set firmware version
version=`scut -p BUILD_VERSION= $layout_config`
build=`scut -p BUILD_NUMBER= $layout_config`
buildate=`scut -p BUILD_DATE= $layout_config -n 4`
rgdb -i -s "/runtime/sys/info/firmwareversion" "$version"
rgdb -i -s "/runtime/sys/info/firmwarebuildno" "$build"
rgdb -i -s "/runtime/sys/info/firmwarebuildate" "$buildate"
rgdb -i -s "/runtime/sys/info/hardwareversion" "rev E"

# Set regulatory domain.
ccode=`rgcfg getenv -n $nvram -e countrycode`
case "$ccode" in
840)
	regdomain=fcc;
	;;
392)
	regdomain=mkk;
	;;
*)	
	regdomain=fcc;
	;;
esac
rgdb -s /sys/regdomain			$regdomain
#
rgdb -s /sys/telnetd			true
rgdb -s /sys/sessiontimeout		600
rgdb -s /proc/web/sessionum		8
rgdb -s /proc/web/authnum		6
#rgdb -s /wireless/country		"$country"
rgdb -s /function/normal_g		1
rgdb -s /function/no_jumpstart		1


# set layout
rgdb -i -s /runtime/layout/image_sign	$image_sign
rgdb -i -s /runtime/layout/wanif	vlan2
rgdb -i -s /runtime/layout/lanif	br0
rgdb -i -s /runtime/layout/wlanif	ath0
rgdb -i -s /runtime/layout/wanmac	"$env_wan"
rgdb -i -s /runtime/layout/lanmac	"$env_wlan"
rgdb -i -s /runtime/layout/wlanmac	"$env_wlan"

fspeed=`rgcfg getenv -n $nvram -e flashspeed`
rgdb -A /etc/scripts/set_nodes.php -V "flashspeed=$fspeed"

# Upgrade Configuration
rgdb -A /etc/templates/upgrade_config.php > /var/run/upgrade_config.sh
sh /var/run/upgrade_config.sh > /dev/console
