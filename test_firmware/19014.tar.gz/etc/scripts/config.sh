#!/bin/sh
. /etc/config/defines
case "$1" in
start)
	echo "Mounting proc and var ..."
	mount -t proc none /proc
	mount -t ramfs ramfs /var
	mkdir -p /var/etc /var/log /var/run /var/state /var/tmp /var/etc/ppp /var/etc/config /var/dnrd /var/etc/iproute2
	echo -n > /var/etc/resolv.conf
	echo -n > /var/TZ

	echo "***************  |  SYS:001" > /var/log/messages

	echo "Inserting modules ..." > /dev/console
	insmod /lib/modules/sw_tcpip.o
	insmod /lib/modules/ifresetcnt.o
	# now NET80211 is buildin kernel
	insmod /lib/modules/ath_hal.o
	insmod /lib/modules/ath_rate_atheros.o
	# get the country code for madwifi, default is fcc.
	ccode=`rgcfg getenv -n $nvram -e countrycode`
	[ "$ccode" = "" ] && ccode="840"
	insmod /lib/modules/ath_ahb.o countrycode=$ccode

	wlanconfig ath0 create wlandev wifi0 wlanmode ap
	insmod /lib/modules/ar231x_gpio.o

	# prepare db...
	echo "Start xmldb ..." > /dev/console
	xmldb -n $image_sign -t > /dev/console &
	sleep 1
	/etc/scripts/misc/profile.sh get
	# set fix nodes
	[ -f /etc/scripts/set_nodes.sh ] && /etc/scripts/set_nodes.sh
	# set brand related node value
	[ -f /etc/scripts/brand.sh ] && /etc/scripts/brand.sh

	/etc/templates/timezone.sh set
	/etc/templates/logs.sh

	# bring up network devices
	env_wan=`rgcfg getenv -n $nvram -e wanmac`
	[ "$env_wan" = "" ] && env_wan="00:52:40:e1:00:01"
	ifconfig eth0 hw ether $env_wan up
	rgdb -i -s /runtime/wan/inf:1/mac "$env_wan"

	TIMEOUT=`rgdb -g /nat/general/tcpidletimeout`
	[ "$TIMEOUT" = "" ] && TIMEOUT=7200 && rgdb -s /nat/general/tcpidletimeout $TIMEOUT
	echo "$TIMEOUT" > /proc/sys/net/ipv4/netfilter/ip_conntrack_tcp_timeout_established

	rgdb -i -s /runtime/router/enable 1
	# VLAN & bridge setup
	mii_dev="/proc/driver/ae531x"
	
	echo "READ 5 0" > $mii_dev
	phyID=`cat $mii_dev`
	# echo $phyID > /dev/console
	if [ "$phyID" = "0x1022" ]; then
		echo Setting up ADM6996FC VLAN ... > /dev/console
		echo "WRITE 0 17 ff30" > $mii_dev
		echo "WRITE 1 16 09a7" > $mii_dev
		echo "WRITE 0 1  840f" > $mii_dev
		echo "WRITE 0 3  840f" > $mii_dev
		echo "WRITE 0 5  840f" > $mii_dev
		echo "WRITE 0 7  840f" > $mii_dev
		echo "WRITE 0 8  880f" > $mii_dev
		echo "WRITE 0 9  881f" > $mii_dev
		echo "WRITE 0 20 0155" > $mii_dev
		echo "WRITE 0 21 0180" > $mii_dev
	else
		echo Setting up ICPlus VLAN ... > /dev/console
		echo "WRITE 29 24 1"	> $mii_dev
		echo "WRITE 29 25 1"	> $mii_dev
		echo "WRITE 29 26 1"    > $mii_dev
		echo "WRITE 29 27 1"    > $mii_dev
		echo "WRITE 29 28 2"    > $mii_dev
		echo "WRITE 29 30 2"    > $mii_dev
		echo "WRITE 29 23 07c2" > $mii_dev
		echo "WRITE 30 1 2f00"  > $mii_dev
		echo "WRITE 30 2 0030"  > $mii_dev
		echo "WRITE 30 9 1089"  > $mii_dev
	fi

	vconfig set_name_type VLAN_PLUS_VID_NO_PAD
	vconfig add eth0 1
	vconfig add eth0 2
	ifconfig vlan1 up
	ifconfig vlan2 up
	brctl addbr br0 	> /dev/console
	brctl addif br0 ath0 	> /dev/console
	brctl addif br0 vlan1 	> /dev/console
	brctl setbwctrl br0 ath0 900 > /dev/console
	# Start up LAN interface & httpd
	ifconfig br0 up			> /dev/console
	/etc/templates/webs.sh start	> /dev/console
	;;
stop)
	umount /tmp
	umount /proc
	umount /var
	;;
esac
