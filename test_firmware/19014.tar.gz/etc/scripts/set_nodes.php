<?
/* flash programming speed */
if ($flashspeed == "")	{ $flashspeed=7200; }
if ($flashspeed < 1800)	{ $flashspeed=1800; }
$flashspeed = $flashspeed * 11 / 10;
set("/runtime/sys/info/fptime", $flashspeed);
set("/runtime/sys/info/bootuptime", 50);
?>
