#!/bin/sh
echo [$0] ... > /dev/console
<?
if (query("/sys/account/superusername") == "admin")
{
	/* user name list */
	set("/sys/user:1/name", "admin");
	set("/sys/user:1/group", "0");
	set("/sys/user:2/name", "user");
	set("/sys/user:2/group", "1");

	$password=query("/sys/account/superuserpassword");
	set("/sys/user:1/password", $password);
	$password=query("/sys/account/normaluserpassword");
	set("/sys/user:2/password", $password);
	del("/sys/account");

	/* upnp setting */
	$upnp=query("/upnp");
	if ($upnp == "") { $upnp="1"; }
	set("/upnp/enable", $upnp);
	set("/upnp", "");

	/* wireless setting */
	$atype=query("/wireless/authentication");
	if ($atype < 2)
	{
		$wepmode=query("/wireless/wepmode");
		if ($wepmode != "")
		{
			set("/wireless/wpa/wepmode", $wepmode);
			del("/wireless/wepmode");
		}
	}
	echo "echo \"Configuration upgrading ...\" > /dev/console\n";
	echo "/etc/scripts/misc/profile.sh put > /dev/console\n";
}
else
{
	echo "echo \"Configuration not changed !\" > /dev/console\n";
}
?>
