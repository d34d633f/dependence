#!/bin/sh
echo [$0] ... > /dev/console
<?
/* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");

$wlanif			= query("/runtime/layout/wlanif");
$lanif			= query("/runtime/layout/lanif");

$hostapd_pid	= "/var/run/hostapd.pid";
$hostapd_p1_conf= "/var/run/hostapd_p1.conf";
$hostapd_conf	= "/var/run/hostapd.conf";
$wlxmlpatch_pid	= "/var/run/wlxmlpatch.pid";
$wlan_light_path= "/var/run/gpio_wlan";
$signal_fresetd = "killall -SIGUSR1 fresetd\n";
$wlan_debug		= query("/runtime/wlan_debug");

if ($generate_start==1)
{
	echo "echo Start WLAN interface ".$wlanif." ... > /dev/console\n";

	if (query("/wireless/enable")!=1)
	{
		echo "echo Wireless is disabled ! > /dev/console\n";
		exit;
	}

	/* Get configuration */
	anchor("/wireless");
	$ssid			= query("ssid");
	$channel		= query("channel");
	$beaconinterval	= query("beaconinterval");
	$fraglength		= query("fraglength");
	$rtslength		= query("rtslength");
	$ssidhidden		= query("ssidhidden");
	$wlmode			= query("wlmode");
	$ctsmode		= query("ctsmode");				if($ctsmode=="")		{$ctsmode="2";}
	$w11gprotection	= query("w11gprotection");
	$preamble		= query("preamble");			if($preamble=="")		{$preamble="0";}
	$txrate			= query("txrate");
	$txpower		= query("txpower");
	$dtim			= query("dtim");
	$autochannel	= query("autochannel");
	$supermode		= query("supergmode");			if ($supermode=="2")		{$turbo="1"; $ar="0";}else{$turbo="0";}
	$xr				= query("xr");					if ($xr!="1"||$turbo=="1")	{$xr="0";}
	$wlan2wlan		= query("bridge/wlan2wlan");	if ($wlan2wlan!="0")		{$wlan2wlan="1";	}
	$wlan2lan		= query("bridge/wlan2lan");		if ($wlan2lan!="0")			{$wlan2lan="1";		}
	$wmm			= query("wmm/enable");			if ($wmm!="1")				{$wmm="0";			}	
	
	if($wmm=="1")
	{
		echo "iwpriv ".$wlanif." wmm 1\n";
		//require($template_root."/wmm.php");
	}
	else
	{
		echo "iwpriv ".$wlanif." wmm 0\n";
	}
	echo "iwpriv ".$wlanif." doth 0\n";
	
	if ($autochannel==1)		{ echo "iwconfig ".$wlanif." channel 0\n";							}
	else						{ echo "iwconfig ".$wlanif." channel "		.$channel."\n";			}
	if ($beaconinterval!="")	{ echo "iwpriv "  .$wlanif." bintval "		.$beaconinterval."\n";	}
	if ($rtslength!="")			{ echo "iwconfig ".$wlanif." rts "			.$rtslength."\n";		}
	if ($fraglength!="")		{ echo "iwconfig ".$wlanif." frag "			.$fraglength."\n";		}
	if ($dtim!="")				{ echo "iwpriv "  .$wlanif." dtim_period "	.$dtim."\n";			}
	if ($ssidhidden!="")		{ echo "iwpriv "  .$wlanif." hide_ssid "	.$ssidhidden."\n";		}

	if		($wlmode == 0)		{ echo "iwpriv ".$wlanif." mode 0\niwpriv ".$wlanif." pureg 0\n"; }
	else if	($wlmode == 1)		{ echo "iwpriv ".$wlanif." mode 3\niwpriv ".$wlanif." pureg 0\n"; }
	else if	($wlmode == 2)		{ echo "iwpriv ".$wlanif." mode 3\niwpriv ".$wlanif." pureg 1\n"; }
	else if	($wlmode == 3)		{ echo "iwpriv ".$wlanif." mode 2\niwpriv ".$wlanif." pureg 0\n"; }
	else if	($wlmode == 4)		{ echo "iwpriv ".$wlanif." mode 1\niwpriv ".$wlanif." pureg 0\n"; }

	echo "iwconfig ".$wlanif." rate auto\n";
	if ($txrate!="0" && $txrate!="")	{ echo "iwconfig ".$wlanif." rate ".$txrate."M\n"; }
	
	echo "iwpriv ".$wlanif." ff ".			$supermode."\n";
	echo "iwpriv ".$wlanif." burst ".		$supermode."\n";
	echo "iwpriv ".$wlanif." compression ".	$supermode."\n";
	echo "iwpriv ".$wlanif." turbo ".		$turbo."\n";
//	echo "iwpriv ".$wlanif." turbo 0\n";
	if($ar!="")	{echo "iwpriv ".$wlanif." ar ".$ar."\n";}
	echo "iwpriv ".$wlanif." protmode ".	$ctsmode."\n";

	echo "iwpriv ".$wlanif." xr ".			$xr."\n";
	
	echo "echo ".$wlan2lan." > /proc/net/br_forward_br0\n";
	echo "iwpriv ".$wlanif." ap_bridge ".$wlan2wlan."\n";
	
	/* aclmode 0:disable, 1:allow all of the list, 2:deny all of the list */
	echo "iwpriv ".$wlanif." maccmd 3\n";	// flush the ACL database.
	$aclmode=query("acl/mode");
	if		($aclmode == 1)		{ echo "iwpriv ".$wlanif." maccmd 1\n"; }
	else if	($aclmode == 2)		{ echo "iwpriv ".$wlanif." maccmd 2\n"; }
	else						{ echo "iwpriv ".$wlanif." maccmd 0\n"; }
	if ($aclmode == 1 || $aclmode == 2)
	{
		for("/wireless/acl/mac")
		{
			$mac=query("/wireless/acl/mac:".$@);
			echo "iwpriv ".$wlanif." addmac ".$mac."\n";
		}
	}
	
	anchor("/wireless");
	$authtype	= query("authentication");
	$psk		= query("wpa/wpapsk");
	$wpa_encrypt= query("wpa/wepmode");
	$js_enable	= query("jumpstart/enable");
	$js_phase	= query("jumpstart/phase");
	$ssid		= query("/wireless/ssid");
	$rekeyinterval	= query("wpa/grp_rekey_interval");

	if(fread($hostapd_pid)=="")
	{
//		require($template_root."/is_hostapd_changed.php");
//		$restart_hostapd=$is_hostapd_changed;
		$restart_hostapd=1;
	}

/*	if($wlan_debug=="1"){echo "echo Saving authentication type and info to rgdb ... > /dev/console\n";}
	$prefix				="/runtime/wireless/hostapd/";
	$ssid_path			="/runtime/wireless/ssid";
	$radius_ip_path		="/runtime/wireless/wpa/radiusServer";
	$radius_port_path	="/runtime/wireless/wpa/radiusPort";
	$radius_sec_path	="/runtime/wireless/wpa/radiusSecret";
	
	set($prefix."authtype",		$authtype);
	set($prefix."psk",			$psk);
	set($prefix."wpa_encrypt",	$wpa_encrypt);
	set($prefix."js_enable",	$js_enable);
	set($prefix."js_phase",		$js_phase);
	set($ssid_path, 			$ssid);
	set($prefix."grp_rekey_interval",$rekeyinterval);
	set($radius_ip_path,		$db_radius_ip);
	set($radius_port_path,		$db_radius_port);
	set($radius_sec_path,		$db_radius_sec);

	if($wlan_debug=="1")
	{
		anchor("/runtime/wireless/hostapd");
		echo "	echo after set rgdb .... > /dev/console\n";
		echo "	echo run_authtype=".query("authtype")." ... > /dev/console\n";
		echo "	echo run_psk=".query("psk")." ... > /dev/console\n";
		echo "	echo run_wpa_encrypt=".query("wpa_encrypt")." ... > /dev/console\n";
		echo "	echo run_js_enable=".query("js_enable")." ... > /dev/console\n";
		echo "	echo run_js_phase=".query("js_phase")." ... > /dev/console\n";
	}
*/
	/* Jump Start */
	if($js_enable=="1")
	{
		if($restart_hostapd=="1")
		{
			anchor("/wireless/jumpstart");
			$js_phase	= query("phase");

			if($js_phase=="1")
			{
				$hostapd_conf_path=$hostapd_p1_conf;
				$psk="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
			}
			else
			{
				$hostapd_conf_path=$hostapd_conf;
				$psk		= query("psk");
				$js_passhash= query("passhash");
				$js_salt	= query("salt");
			}

			fwrite($hostapd_conf_path,
					"interface=".$wlanif."\n"			."bridge=".$lanif."\n"
					."driver=madwifi\n"					."logger_syslog=0\n"
					."logger_syslog_level=0\n"			."logger_stdout=0\n"
					."logger_stdout_level=0\n"			."debug=0\n"
					."dump_file=/tmp/hostapd.dump\n"	."eapol_key_index_workaround=0\n"
					."wpa=3\n"							."wpa_psk=".$psk."\n"
					."wpa_key_mgmt=WPA-PSK\n"			."wpa_pairwise=CCMP TKIP\n");
					
			if($rekeyinterval!=""){fwrite2($hostapd_conf, "wpa_group_rekey=".$rekeyinterval."\n");}

			if($js_phase=="1")
			{
				fwrite2($hostapd_conf_path, "jumpstart_p1=1\n");
				echo "hostapd -S /etc/templates/hostapd_helper.sh ".$hostapd_conf_path." &\n";

				if($wlan_debug=="1"){echo "echo hostapd start to run... > /dev/console\n";}
			}
			else
			{
				$host_conf_path=$hostapd_conf;
				fwrite2($hostapd_conf_path, "jumpstart_p2=1\n"
						."jumpstart_passHash=".$js_passhash."\n"
						."jumpstart_salt=".$js_salt."\n");
				echo "hostapd -S /etc/templates/hostapd_helper.sh ".$hostapd_conf_path." &\n";
				if($wlan_debug=="1"){echo "echo hostapd start to run... > /dev/console\n";}
			}
			echo "echo $! > ".$hostapd_pid."\n";

			// in phase 1, it allows the station uses open with no wep to asscoicate.
			if($js_phase=="1")
			{
				echo "echo set authmode as open ... > /dev/console\n";
				echo "sleep 3\n";
				echo "iwpriv ".$wlanif." authmode 1\n";/* open-system */
			}
		}
		else
		{
			echo "ifconfig ".$wlanif." up\n";
		}
		if($js_phase=="1")	{	echo "echo 2 > ".$wlan_light_path."\n";		}
		else				{	echo "echo 3 > ".$wlan_light_path."\n";		}
		echo $signal_fresetd;
	}
	else
	{
		anchor("/wireless");
		$authentication	= query("authentication");
		$keylength		= query("keylength");
		$defkey			= query("defkey");
		$wepkey1		= queryjs("wepkey:1");
		$wepkey2		= queryjs("wepkey:2");
		$wepkey3		= queryjs("wepkey:3");
		$wepkey4		= queryjs("wepkey:4");
		$keyformat		= query("keyformat");
		$wpawepmode		= query("wpa/wepmode");
		$radiusport		= query("wpa/radiusport");
		$radiusserverip	= query("wpa/radiusserver");
		$radiussecret	= query("wpa/radiussecret");
		$wpapsk			= query("wpa/wpapsk");
		$rekeyinterval	= query("wpa/grp_rekey_interval");

		if		($authentication==0)	{ $use_hostapd=0; echo "iwpriv ".$wlanif." authmode 1\n"; }	/* open-system */
		/*else if	($authentication==1)	{ $use_hostapd=0; echo "iwpriv ".$wlanif." authmode 2\n"; }*/	/* shared-key */
		else if	($authentication==1)	{ $use_hostapd=0; echo "iwpriv ".$wlanif." authmode 1\n"; }	/* shared-key */
		else if	($authentication==2)	{ $use_hostapd=1; $hostapd_wpa=1; $hostapd_ieee8021x=1; } 	/* WPA */
		else if	($authentication==3)	{ $use_hostapd=1; $hostapd_wpa=1; $hostapd_ieee8021x=0; } 	/* WPA-PSK */
		else if	($authentication==4)	{ $use_hostapd=1; $hostapd_wpa=2; $hostapd_ieee8021x=1; } 	/* WPA2 */
		else if	($authentication==5)	{ $use_hostapd=1; $hostapd_wpa=2; $hostapd_ieee8021x=0; } 	/* WPA2-PSK */
		else if	($authentication==6)	{ $use_hostapd=1; $hostapd_wpa=3; $hostapd_ieee8021x=1; } 	/* WPA-AUTO */
		else if	($authentication==7)	{ $use_hostapd=1; $hostapd_wpa=3; $hostapd_ieee8021x=0; } 	/* WPA-AUTO-PSK */

		if ($use_hostapd != 1)
		{
			echo "echo Start WLAN interface ".$wlanif." ... > /dev/console\n";
			if ($wpawepmode == 1)
			{
				if		($defkey == 1)	{ $iw_keystring="\"".$wepkey1."\" [1]"; }
				else if	($defkey == 2)	{ $iw_keystring="\"".$wepkey2."\" [2]"; }
				else if	($defkey == 3)	{ $iw_keystring="\"".$wepkey3."\" [3]"; }
				else if	($defkey == 4)	{ $iw_keystring="\"".$wepkey4."\" [4]"; }
				if ($keyformat == 1)	{ $iw_keystring="s:".$iw_keystring; }
				echo "iwconfig ".$wlanif." key ".$iw_keystring."\n";
				if($authentication==1)
				{
					echo "iwpriv ".$wlanif." authmode 2\n";
					echo "iwconfig ".$wlanif." key ".$iw_keystring."\n";
				}
			}
			echo "iwconfig ".$wlanif." essid \"".queryjs("ssid")."\"\n";
			echo "ifconfig ".$wlanif." up\n";
			echo "sleep 1\n";
		}
		else if($restart_hostapd=="1")
		{
			fwrite($hostapd_conf,	 "interface=".$wlanif."\n"			."bridge=".$lanif."\n"
					."driver=madwifi\n"					."logger_syslog=0\n"
					."logger_syslog_level=0\n"			."logger_stdout=0\n"
					."logger_stdout_level=0\n"			."debug=0\n"
					."eapol_key_index_workaround=0\n"	."ssid=".$ssid."\n"
					."wpa=".$hostapd_wpa."\n");
					
			if($rekeyinterval!="")	{fwrite2($hostapd_conf, "wpa_group_rekey=".$rekeyinterval."\n");}

			if		($wpawepmode==2) { fwrite2($hostapd_conf, "wpa_pairwise=TKIP\n");		}
			else if	($wpawepmode==3) { fwrite2($hostapd_conf, "wpa_pairwise=CCMP\n");		}
			else if	($wpawepmode==4) { fwrite2($hostapd_conf, "wpa_pairwise=TKIP CCMP\n");	}

			if ($hostapd_ieee8021x == 1)
			{
				fwrite2($hostapd_conf,	 "ieee8021x=1\n"
						."wpa_key_mgmt=WPA-EAP\n"
						."auth_server_addr=".$radiusserverip."\n"
						."auth_server_port=".$radiusport."\n"
						."auth_server_shared_secret=".$radiussecret."\n");
			}
			else
			{
				if(query("wpa/PassPhraseFormat")=="1")
				{
					fwrite2($hostapd_conf,	"wpa_key_mgmt=WPA-PSK\n"	."wpa_passphrase=".$wpapsk."\n");
				}
				else
				{
					fwrite2($hostapd_conf,	"wpa_key_mgmt=WPA-PSK\n"	."wpa_psk=".$wpapsk."\n");
				}
			}
			echo "hostapd ".$hostapd_conf." &\n";	
			echo "echo $! > ".$hostapd_pid."\n";
			
			if($wlan_debug=="1"){echo "echo hostapd start to run... > /dev/console\n";}
		}
		echo "echo 5 > ".$wlan_light_path."\n";
		echo $signal_fresetd;
	}
	if($no_restart_wlxmlpatch!="1")
	{
		echo "wlxmlpatch & > /dev/console\n";
		echo "echo $! > ".$wlxmlpatch_pid."\n";
	}
	echo "ifconfig ".$wlanif." up\n";
}
else
{
	echo "echo Stop WLAN interface ".$wlanif." ... > /dev/console\n";

	$w_pid=fread($wlxmlpatch_pid);
	if($wlan_debug=="1"){echo "	echo wlxmlpatch pid=".$w_pid."> /dev/console\n";}
	if($w_pid!="")
	{
		if($no_restart_wlxmlpatch!="1")
		{
//			echo "kill -9 ".$w_pid." > /dev/null 2>&1\n";
			echo "kill ".$w_pid." > /dev/null 2>&1\n";
			echo "rm -f ".$wlxmlpatch_pid."\n";
		}
	}
	
	$h_pid=fread($hostapd_pid);
	if($h_pid!="")
	{
//		require($template_root."/is_hostapd_changed.php");
//		$need_rmmod=$is_hostapd_changed;
		$need_rmmod=1;

		if($need_rmmod=="1")
		{
//			echo "kill -9 ".$h_pid." > /dev/null 2>&1\n";
			echo "kill ".$h_pid." > /dev/null 2>&1\n";
			echo "rm -f ".$hostapd_pid."\n";

			if($wlan_debug=="1"){echo "	echo ifconfig down ... > /dev/console\n";}
			echo "ifconfig "		.$wlanif." down\n";
/*			
			if($wlan_debug=="1"){echo "	echo  wlanconfig ath0 destroy ... > /dev/console\n";}
			echo "wlanconfig "	.$wlanif." destroy\n";
			
			if($wlan_debug=="1"){echo "	echo  rmmod ath_ahb ... > /dev/console\n";}
			echo "rmmod ath_ahb\n";
			
			if($wlan_debug=="1"){echo "	echo  insmod ath_ahb.o ... > /dev/console\n";}
			echo "insmod /lib/modules/ath_ahb.o countrycode=840\n";
			
			if($wlan_debug=="1"){echo "	echo  wlanconfig ath0 create wlandev wifi0 wlanmode ap ... > /dev/console\n";}
			echo "wlanconfig "	.$wlanif." create wlandev wifi0 wlanmode ap\n";
			
			if($wlan_debug=="1"){echo "	echo brctl addif br0 ath0 ... > /dev/console\n";}
			echo "brctl addif "	.$lanif." ".$wlanif."\n";
*/
		}
	}

	echo "ifconfig ".$wlanif." down\n";
	echo "iwconfig ".$wlanif." key off\n";
	echo "echo 0 >".$wlan_light_path."\n";
	echo $signal_fresetd;
}
?>
