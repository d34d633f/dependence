<?
/* vi: set sw=4 ts=4: */
anchor("/runtime/wireless/hostapd");
$run_authtype	= query("authtype");
$run_psk		= query("psk");
$run_wpa_encrypt= query("wpa_encrypt");
$run_js_enable	= query("js_enable");
$run_js_phase	= query("js_phase");
$run_ssid		= query("/runtime/wireless/ssid");
$run_rekey      = query("grp_rekey_interval");

anchor("/wireless");
$authtype	= query("authentication");
$psk		= query("wpa/wpapsk");
$wpa_encrypt= query("wpa/wepmode");
$js_enable	= query("jumpstart/enable");
$js_phase	= query("jumpstart/phase");
$ssid		= query("/wireless/ssid");
$rekeyinterval  = query("wpa/grp_rekey_interval");
$db_radius_ip   = query("wpa/radiusServer");
$db_radius_port = query("wpa/radiusPort");
$db_radius_sec  = query("wpa/radiusSecret");

if(		$run_ssid	 	!= $ssid			|| $run_js_enable	!= $js_enable		|| $run_js_phase	!= $js_phase	
	||	$run_authtype	!= $authtype		|| $run_psk			!= $psk				|| $run_wpa_encrypt	!= $wpa_encrypt
	||	$run_rekey		!= $rekeyinterval	|| $run_radius_ip	!= $db_radius_ip	|| $run_radius_port	!= $db_radius_port
	||	$run_radius_sec	!= $db_radius_sec)
{$is_hostapd_changed="1";}

if($wlan_debug=="1")
{
	echo "	echo is_hostapd_changed="	.$is_hostapd_changed." > /dev/console\n";
	echo "	echo hostapd_pid="			.fread($hostapd_pid)." ... > /dev/console\n";
	echo "	echo run_authtype="			.$run_authtype		." ... > /dev/console\n";
	echo "	echo authtype="				.$authtype			." ...\n > /dev/console\n";
	echo "	echo run_psk="				.$run_psk			." ... > /dev/console\n";
	echo "	echo psk="					.$psk				." ...\n > /dev/console\n";
	echo "	echo run_wpa_encrypt="		.$run_wpa_encrypt	." ... > /dev/console\n";
	echo "	echo wpa_encrypt="			.$wpa_encrypt		." ...\n > /dev/console\n";
	echo "	echo run_js_enable="		.$run_js_enable		." ... > /dev/console\n";
	echo "	echo js_enable="			.$js_enable			." ...\n > /dev/console\n";
	echo "	echo js_phase="				.$js_phase			." ...\n > /dev/console\n";
}

?>
