#!/bin/sh
echo [$0] $1 ... > /dev/console
TROOT=`rgdb -i -g /runtime/template_root`
[ "$TROOT" = "" ] && TROOT="/etc/templates"
case "$1" in
start|restart)
	rgdb -A $TROOT/wlan_run.php -V generate_start=0 > /var/run/wlan_stop.sh
	sh /var/run/wlan_stop.sh > /dev/console
	sleep 1
	rgdb -A $TROOT/wlan_run.php -V generate_start=1 > /var/run/wlan_start.sh
	sleep 1
	sh /var/run/wlan_start.sh > /dev/console
	;;
stop)
	rgdb -A $TROOT/wlan_run.php -V generate_start=0 > /var/run/wlan_stop.sh
	sleep 1
	sh /var/run/wlan_stop.sh > /dev/console
	;;
*)
	echo "usage: $0 {start|stop|restart}"
	;;
esac
