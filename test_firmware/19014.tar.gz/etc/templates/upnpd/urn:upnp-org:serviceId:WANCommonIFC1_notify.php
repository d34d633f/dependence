<e:property><PhysicalLinkStatus><?map("/runtime/wan/inf:1/linkType","1","Up","*","Down");?></PhysicalLinkStatus></e:property>
