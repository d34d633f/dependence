<e:property><DefaultConnectionService><?=$udn?>:WANConnectionDevice:1,urn:upnp-org:serviceId:WANIPConn1</DefaultConnectionService></e:property>
