<?
require("/etc/templates/troot.php");
$WID = 1;
require($template_root."/upnpd/__wanipconn_action.php");
?>
