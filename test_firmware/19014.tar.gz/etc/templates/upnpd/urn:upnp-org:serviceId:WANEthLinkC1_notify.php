<e:property><EthernetLinkStatus>Up</EthernetLinkStatus></e:property>
