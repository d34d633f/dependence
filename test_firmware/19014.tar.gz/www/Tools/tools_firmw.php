<?
/* vi: set sw=4 ts=4: */

$file_name="tools_firmw.php";
$apply_name="tools_firmw.xgi?";
require("/www/comm/genTop.php");
$MSG_FILE="tools_firmw.php";
require("/www/comm/genTopScript.php");
?>
<script>
function doSubmit()
{
	var f=document.getElementById("tools_firmw_form");
	if(isBlank(f.firmware.value))
		alert("<?=$a_you_must_select_a_firmware_file?>");
	else
		document.forms[0].submit();
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<?require("/www/comm/middle.php");?>
<form name=tools_firmw_form id=tools_firmw_form method=POST action=upload_image._int enctype=multipart/form-data>
<table width="<?=$width_tb?>" border=0 cellpadding=0 height=217>
<tr><td height=30 colspan=2 class=title_tb><?=$m_title?></td></tr>
<tr>
	<td width=2%></td>
	<td height=15 class=l_tb>
	<?=$m_title_desc?>
	</td>
</tr>
<tr><td height=20 colspan=2 class=bc_tb><?=$m_current_firmware_version?> <?query("/runtime/sys/info/firmwareVersion");?></td></tr>
<tr><td height=54 colspan=2 align=center><input type=file name=firmware size=20></td></tr>
<tr>
	<td height=43 colspan=2 align=right>
	<script language="JavaScript">apply(""); cancel("document.forms[0].reset()");help("help_tools.php#13");</script>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
