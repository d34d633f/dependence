<?
/* vi: set sw=4 ts=4: */

$file_name="tools_misc.php";
$apply_name="tools_misc.xgi?";
require("/www/comm/genTop.php");
$MSG_FILE="tools_misc.php";
require("/www/comm/genTopScript.php");

$modelname=query("/sys/modelname");
$pingAllow=query("/security/firewall/pingAllow");
$upnp=query("/upnp/enable");
$pptp=query("/nat/passthrough/pptp");
$ipsec=query("/nat/passthrough/ipsec");
$dosMode=query("/security/dos/enable");
$etherLinkType=query("/wan/rg/inf:1/etherLinkType");
$pingResult=query("/runtime/diagnostic/pingResult");
set("/runtime/diagnostic/pingResult","");//to remove the last pint result.
?>
<script language="JavaScript">
function doCancel()
{
	document.forms[0].reset();
	document.getElementById("pingIP").value='';
}
function doPing()
{
<?
if($user=="admin" && query("/sys/user:1/password")==$passwd)
{
	echo " 	pingIp=document.getElementById(\"pingIP\");\n";
	echo "	if (pingIp.value == '')\n";
	echo "	{\n";
	echo "		alert(\"".$a_ip_addr_is_empty."\");\n";
	echo "		return;\n";
	echo "	}\n";
	echo "	else\n";
	echo "		location.href=\"tools_misc.xgi?set/runtime/diagnostic/pingIp=\"+pingIp.value;\n";
}
else
{
	echo "alert('".$a_only_admin_account_can_change_the_settings."');";
}
?>
}

function pingReturn()
{
	if ("<?=$pingResult?>" == "") { return; }
	else if ("<?=$pingResult?>" == "2")
	{
		document.write("<tr><td height=20 class=title_tb><font color=green><?=$m_ping_passed?></font></td>");
		document.write("<td height=20></td></tr>");
	}
	else
	{
		document.write("<tr><td height=20 class=title_tb><font color=red><?=$m_ping_failed?></font></td>");
		document.write("<td height=20></td></tr>");
	}
}

function doSubmit()
{
	var f=document.getElementById("tools_misc_form");
	var str=new String("<?=$apply_name?>");

	if (f.etherLinkType[0].checked)		etherLink = "2";
	else if (f.etherLinkType[1].checked)	etherLink = "4";
	else					etherLink = "0";
	str+="set/security/firewall/pingAllow="+(f.pingAllow[0].checked? "0":"1");
	str+="&set/upnp/enable="+(f.upnp[0].checked? "1":"0");
	str+="&set/security/dos/enable="+(f.spi[0].checked? "1":"0");
	str+="&set/nat/passthrough/pptp="+(f.pptp[0].checked? "1":"0");
	str+="&set/nat/passthrough/ipsec="+(f.ipsec[0].checked? "1":"0");
	str+="&set/wan/rg/inf:1/etherLinkType="+etherLink;
		
	str+=exeStr("submit COMMIT;submit RG_MISC");
	self.location.href=str;
}

</script>
<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<?require("/www/comm/middle.php");?>
<table width="<?=$width_tb?>" border=0 cellpadding=0 height=345>
<tr><td colspan=2 height=14 class=title_tb><?=$m_ping_test?></td></tr>
<tr valign="top">
	<td colspan=2 height=30 class=l_tb>
	<?=$m_ping_test_desc?>
	</td>
</tr>
<tr>
	<td width=40% height=20 class=br_tb><?=$m_host_name_or_ip_addr?></td>
	<td width=60% height=20>
	<input type=text name=pingIP id=pingIP size=30 maxlength=63>
	<input type=button value=<?=$m_ping?> onClick=doPing()>
	</td>
</tr>
<script language="Javascript">pingReturn()</script>

<form method=GET name=tools_misc_form id=tools_misc_form>
<tr><td height=20 colspan=2><br></td></tr>
<tr><td colspan=2 height=20 class=title_tb><?=$m_block_wan_ping?></td></tr>
<tr valign="top">
	<td colspan=2 height=70 class=l_tb>
	<?=$m_block_wan_ping_desc?>
	</td>
</tr>
<tr>
	<td height=20 class=br_tb><?=$m_discard_ping_from_wan_side?></td>
	<td class=l_tb>
	<input type=radio value=0 name=pingAllow <?if(query("/security/firewall/pingAllow")=="0"){echo "checked";}?>><?=$m_enabled?>
	<input type=radio value=1 name=pingAllow <?if(query("/security/firewall/pingAllow")!="0"){echo "checked";}?>><?=$m_disabled?></font></td>
</tr>
<tr><td height=20 colspan=2><br></td></tr>
<tr>
	<td colspan=2 height=20 class=title_tb><?=$m_spi_mode?></td>
</tr>
<tr valign="top">
	<td colspan=2 height=30 class=l_tb><?=$m_spi_mode_desc?></td>
</tr>
<tr>
	<td width=27% height=20 align=right></td>
	<td width=73% height=20 class=l_tb>
	<input type=radio name=spi value=1 <?if(query("/security/dos/enable")=="1"){echo "checked";}?>><?=$m_enabled?>
	<input type=radio name=spi value=0 <?if(query("/security/dos/enable")!="1"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>
<tr><td height=20 colspan=2><br></td></tr>
<tr><td colspan=2 height=20 class=title_tb><?=$m_upnp_settings?></td></tr>
<tr valign="top">
	<td colspan=2 height=30 class=l_tb><?=$m_upnp_settings_desc?></td>
</tr>
<tr>
	<td height=20></td>
	<td height=20 class=l_tb>
	<input type=radio name=upnp value=1 <?if(query("/upnp/enable")=="1"){echo "checked";}?>><?=$m_enabled?>
	<input type=radio name=upnp value=0 <?if(query("/upnp/enable")!="1"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>
<tr><td height=20 colspan=2><br></td></tr>
<tr><td colspan=2 height=9 class=title_tb><?=$m_vpn_pass_through?></td></tr>
<tr valign="top"><td colspan=2 height=30 class=l_tb><?=$m_vpn_pass_through_desc?> <?=$modelname?>.</td></tr>
<tr>
	<td height=20 class=br_tb><?=$m_pptp?></td>
	<td height=20 class=l_tb>
	<input type=radio name=pptp value=1 <?if($pptp=="1"){echo "checked";}?>><?=$m_enabled?>
	<input type=radio name=pptp value=0 <?if($pptp!="1"){echo "checked";}?>><?=$m_disabled?></td>
</tr>
<tr>
	<td height=20 class=br_tb><?=$m_ipsec?></td>
	<td height=20 class=l_tb>
	<input type=radio name=ipsec value=1 <?if($ipsec=="1"){echo "checked";}?>><?=$m_enabled?>
	<input type=radio name=ipsec value=0 <?if($ipsec!="1"){echo "checked";}?>><?=$m_disabled?></td>
</tr>
<tr><td height=20 colspan=2><br></td></tr>
<tr><td colspan="2" height=21 class=title_tb><?=$m_wan_type_setting?></td>
</tr>
<tr>
	<td height=20 colspan=2 class=c_tb>
	<input type=radio name=etherLinkType value=2 <?if($etherLinkType=="2"){echo "checked";}?>><?=$m_ltype_100Mbps?>
	<input type=radio name=etherLinkType value=4 <?if($etherLinkType=="4"){echo "checked";}?>><?=$m_ltype_10Mbps?>
	<input type=radio name=etherLinkType value=0 <?if($etherLinkType=="0"){echo "checked";}?>><?=$m_ltype_auto?>
	</td>
</tr>
<tr><td height=20 colspan=2><br></td></tr>
<tr><td colspan=2 align=right><script language="JavaScript">apply(""); cancel("doCancel()");help("help_tools.php#14");</script></td></tr>
</form>
</table>
<?require("/www/comm/bottom.php");?>
