<?
/* vi: set sw=4 ts=4: */
if($passwd_changed=="1") {unlink("/var/proc/web/session:".$sid."/user/ac_auth");}
$file_name="tools_admin.php";
$apply_name="tools_admin.xgi?";
require("/www/comm/genTop.php");
$MSG_FILE="tools_admin.php";
require("/www/comm/genTopScript.php");

$rmEnable=query("/security/firewall/httpAllow");
$rmIp=query("/security/firewall/httpRemoteIp");
$rmPort=query("/security/firewall/httpRemotePort");

$password_att="onkeyup=\"return limit_length(this);\" onFocus=\"this.select();\"";
?>
<script language="JavaScript">
function doSubmit()
{
	if (checkParameter()==false) return;
	var f=document.getElementById("admin_frm");
	var str=new String("<?=$apply_name?>");
	var passwd_changed=false;

	if (f.admPass1.value != "WDB8WvbXdHtZyM8")
	{
		passwd_changed=true;
		str+="SET/sys/user:1/password="+escape(f.admPass1.value);
	}
	if (f.userPass1.value != "WDB8WvbXdHtZyM8")
	{
		passwd_changed=true;
		str+="&SET/sys/user:2/password="+escape(f.userPass1.value);
	}
	str+="&SET/security/firewall/httpAllow="+(f.hEnable[0].checked? "1":"0");
	if (f.hip.value != "*")	str+="&SET/security/firewall/httpRemoteIp="+f.hip.value;
	else			str+="&SET/security/firewall/httpRemoteIp=";
	str+="&SET/security/firewall/httpRemotePort="+f.hport[f.hport.selectedIndex].value;

	str+=exeStr("submit COMMIT;submit RG_MISC;submit HTTPD_PASSWD");
	
	if(passwd_changed)	str+="&passwd_changed=1";
	
	self.location.href=str;
}

function checkParameter()
{
	var f=document.getElementById("admin_frm");
	if(CheckUCS2(f.admPass1.value))
	{
		alert("<?=$a_admin_password_only_allow_ascii_code?>");
		f.admPass1.value="";
		f.admPass1.focus();
		return false;
	}
	if(CheckUCS2(f.userPass1.value))
	{
		alert("<?=$a_user_password_only_allow_ascii_code?>");
		f.userPass1.value="";
		f.userPass1.focus();
		return false;
	}

	if (f.admPass1.value!=f.admPass2.value)
	{
		alert("<?=$a_admin_password_not_matched?>\n");
		f.admPass1.value="";
		f.admPass1.focus();
		return false;
	}
	if (f.userPass1.value!=f.userPass2.value)
	{
		alert("<?=$a_user_password_not_matched?>\n");
		f.userPass1.value="";
		f.userPass1.focus();
		return false;
	}
	if(f.hip.value=="")
	{
		alert("<?=$a_ip_addr_is_not_valid?>");
		f.hip.focus();
		return false;
	}
	if(f.hip.value!="*" && !checkIpAddr(f.hip, "<?=$a_err_ip_addr?>"))	return false;
}
function print_http(n)
{
	dList=["80","88","1080","8080"];
	str="<select name="+n+" size=1>";
	for(i=0;i<dList.length;i++)
	{
		str+="<option value="+dList[i];
		if(parseInt("<?=$rmPort?>", [10])==dList[i])str+=" selected";
		str+=">"+dList[i]+"</option>";
	}
	str+="</select>";
	document.write(str);
}
function limit_length(f)
{
	if(f.value.length > 15)
	{
		alert("<?=$a_more_than_max_length?>");
		return false;
	}
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<?require("/www/comm/middle.php");?>
<form method=POST id="admin_frm">
<table width="<?=$width_tb?>" border=0 cellpadding=0 height=383>
<tr>
	<td height=14 colspan=2 class=title_tb><?=$m_title?></td>
</tr>
<tr valign="top">
	<td height=30 colspan=2 class=l_tb><?=$m_title_desc?></td>
</tr>
<tr>
	<td height=20 bgcolor=#CCCCCC colspan=2 class=l_tb><?=$m_admin?></td>
</tr>
<tr>
	<td height=30 width=29% class=r_tb><?=$m_new_password?>&nbsp;</td>
	<td height=30 width=71%><input type=password name=admPass1 size=20 maxlength=16 value="WDB8WvbXdHtZyM8" <?=$password_att?>></td>
</tr>
<tr>
	<td height=30 width=29% class=r_tb><?=$m_confirm_password?>&nbsp;</td>
	<td height=30 width=71%><input type=password name=admPass2 size=20 maxlength=16 value="WDB8WvbXdHtZyM8" <?=$password_att?>></td>
</tr>
<tr>
	<td height=20 colspan=2 bgcolor=#CCCCCC class=l_tb><?=$m_user?></td>
</tr>
<tr>
	<td height=30 class=r_tb><?=$m_new_password?>&nbsp;</td>
	<td height=30><input type=password name=userPass1 size=20 maxlength=15 value="WDB8WvbXdHtZyM8" <?=$password_att?>></td>
</tr>
<tr>
	<td height=30 class=r_tb><?=$m_confirm_password?>&nbsp;</td>
	<td height=30><input type=password name=userPass2 size=20 maxlength=15 value="WDB8WvbXdHtZyM8" <?=$password_att?>></td>
</tr>
<tr>
	<td height=9 colspan=2><br></td>
</tr>
<tr>
	<td height=15 colspan=2 class=title_tb><?=$m_remote_management?></td>
</tr>
<tr>
	<td height=4></td>
	<td height=4 class=l_tb>
	<input type=radio value=1 name=hEnable <?if($rmEnable=="1"){echo "checked";}?>><?=$m_enabled?>
	<input type=radio value=0 name=hEnable <?if($rmEnable!="1"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>
<tr>
	<td height=14 class=r_tb><?=$m_ip_addr?>&nbsp;</td>
	<td height=14>
	<input type=text name=hip size=16 maxlength=15 value="<?if($rmIp==""){echo "*";}else{echo $rmIp;}?>">
	</td>
</tr>
<tr>
	<td height=2 class=r_tb><?=$m_port?>&nbsp;</td>
	<td height=2><script>print_http("hport");</script></td>
</tr>
<tr>
	<td height=45 colspan=2 align=right>
	<script language="JavaScript">apply(""); cancel("document.forms[0].reset();");help("help_tools.php#11");</script>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
