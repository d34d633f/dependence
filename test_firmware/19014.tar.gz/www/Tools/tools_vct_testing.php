<?
/* vi: set sw=4 ts=4: */
/*
$g_ww_cvt="../graphic/ww_vct.jpg";
*/
/*/ ---------------------message start--------------------
$m_cable_diagnosing="Cable Diagnosing ...";
// ---------------------message end---------------------- */

require("/www/comm/genTop.php");
$MSG_FILE="tools_vct_testing.php";
require("/www/comm/genTopScript.php");
?>
<script>
nLan=parseInt("<?=$port_id?>", [10]);
port_id=nLan+1;
port_link="<?query("/runtime/switch/port:".$port_id."/linkType");?>";

function doNext()
{
	self.location.href="tools_vct_info.xgi?set/runtime/switch/getlinktype=1&port_id="+port_id+"&nLan="+nLan+"&set/runtime/cabletest:"+port_id+"/testnow=ok";
}

</script>
</head>
<body bgcolor=#CCCCCC text=#000000 topmargin=0 leftmargin=0 onload="doNext()">
<form method=post id="vct_info">
<table border=0 cellspacing=0 cellpadding=0 width=400>
<tr>
	<td height=33 colspan=2><img src="<?=$g_ww_cvt?>" width=400 height=50></td>
</tr>
<tr><td height=60></td></tr>
<tr>
  <td><center><font class=wt><?=$m_cable_diagnosing?></font></center></td>
</tr>
</table>
</form>
</body>
</html>
