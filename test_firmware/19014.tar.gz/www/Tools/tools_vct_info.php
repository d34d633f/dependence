<?
/* vi: set sw=4 ts=4: */
/*
$g_ww_cvt="../graphic/ww_vct.jpg";
$g_link="../graphic/link.gif";
$g_nolink="../graphic/nolink.gif";
$g_exit_p="../graphic/exit_p.jpg";
*/
/*/ ----------------------message start------------------------
$m_disconnected="Disconnected";
$m_100full="100Full";
$m_100half="100Half";
$m_10full="10Full";
$m_10half="10Half";
$m_error="Error";
$m_normal_cable="Normal Cable";
$m_open_cable="Open Cable";
$m_short_cable="Short Cable";
$m_wan="WAN";
$m_lan="LAN";
$m_txpair_normal_cable="TxPair Normal cable!";
$m_rxpair_normal_cable="RxPair Normal cable!";
$m_txpair_status="TxPair \"+getStatString(txstatus)+\" at \"+txmeter+\" meters";
$m_rxpair_status="RxPair \"+getStatString(rxstatus)+\" at \"+txmeter+\" meters";
// ----------------------message end-------------------------- */

require("/www/comm/genTop.php");
$MSG_FILE="tools_vct_info.php";
require("/www/comm/genTopScript.php");
?>
<script>
port_id="<?=$port_id?>";
linkType=["<?=$m_disconnected?>","<?=$m_100full?>","<?=$m_100half?>","<?=$m_10full?>","<?=$m_10half?>"];
txrxstat=["<?=$m_error?>","<?=$m_normal_cable?>","<?=$m_open_cable?>","<?=$m_short_cable?>"];

function getInfo()
{
	switch(port_id)
	{
	case "1":
		cable_name="<?=$m_wan?>";
		linkStat="<?query("/runtime/wan/inf:1/linkType");?>";
		break;
	default:
		cable_name="<?=$m_lan?>"+eval(parseInt("<?=$port_id?>", [10])-1);
		linkStat="<?$lan_id=$port_id-1; query("/runtime/switch/port:".$lan_id."/linkType");?>";
		break;
	}
	txstatus="<?query("/runtime/cabletest:".$port_id."/txstatus");?>";
	rxstatus="<?query("/runtime/cabletest:".$port_id."/rxstatus");?>";
	txmeter="<?query("/runtime/cabletest:".$port_id."/txmeter");?>";
	rxmeter="<?query("/runtime/cabletest:".$port_id."/rxmeter");?>";
}

function getConnectString(s)
{
	return linkType[isNaN(parseInt(s, [10]))? 0: parseInt(s, [10])];
}

function getStatString(s)
{
	return txrxstat[isNaN(parseInt(s, [10]))? 0: parseInt(s, [10])];
}

function generateInfo()
{
	getInfo();
	var str=new String("");
	str+="<tr>";
	str+="<td width=11% height=31 align=left><b>"+cable_name+"</b></td>";
	if (linkStat != "0")
	{
		str+="<td width=37% height=20 align=left><img src=<?=$g_link?> width=223 height=35 border=0></td>";
		str+="<td width=35% height=20 align=center><font size=3 color=#0080FF><b>"+getConnectString(linkStat)+"</b></font></td>";
		str+="</tr>";
		str+="<tr><td height=15></td><td colspan=2><?=$m_txpair_normal_cable?><br>";
		str+="<?=$m_rxpair_normal_cable?></td></tr>";
		
	}
	else
	{
		str+="<td width=37% height=20 align=left><img src=<?=$g_nolink?> width=223 height=35 border=0></td>";
		str+="<td width=35% height=20 align=center><font size=3 color=#FF8080><b>"+getConnectString(linkStat)+"</b></font></td>";
	
		str+="</tr>";
		str+="<tr><td height=15></td><td colspan=2>";
		str+="<?=$m_txpair_status?>";
		str+="<br>";
		str+="<?=$m_rxpair_status?>";
		str+="</td></tr>";
	}
	document.write(str);
}

function ExitWindow()
{
        self.parent.close();
}

</script>
</head>
<body bgcolor=#CCCCCC text=#000000 topmargin=0 leftmargin=0>
<form method=post id="vct_info">
<table border=0 cellspacing=0 cellpadding=0 height=211 width=220>
<tr>
	<td height=33 colspan=2><img src="<?=$g_ww_cvt?>" width=400 height=50></td>
</tr>
<tr>
	<td height=10 bgcolor=#CCCCCC colspan=2>
	<table border=0 width=350 height=135 cellpadding=0 bgcolor=#CCCCCC>
		<script>generateInfo();</script>
	</table>
	</td>
</tr>
<tr bgcolor=#CCCCCC align=right>
	<td height=10 colspan=2>
	<a href="javascript:ExitWindow()"><img src="<?=$g_exit_p?>" width=36 height=52 border=0></a>
	</td>
</tr>
</table>
</form>
</body>
</html>
