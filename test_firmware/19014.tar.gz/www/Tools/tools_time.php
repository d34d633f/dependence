<?
$file_name="tools_time.php";
$apply_name="tools_time.xgi?";
require("/www/comm/genTop.php");
$MSG_FILE="tools_time.php";
require("/www/comm/genTopScript.php");

$start_year=2005;
$sync=query("/time/syncWith");
$timezone=query("/time/timeZone");
if($timezone==""){$timezone="22";}
$date=query("/runtime/time/date");
$time=query("/runtime/time/time");
$ntp=queryjs("/time/ntpserver/ip");
$daylightsaving=query("/time/daylightsaving");
$ntp_interval=query("/time/ntpServer/interval");
?>

<script language="JavaScript">
<?
require("/www/comm/select.js");
require("/www/comm/time.js");
?>
sData=["<?query("/time/syncWith");?>",		"<?query("/time/timeZone");?>",
	"<?query("/runtime/time/date");?>",	"<?query("/runtime/time/time");?>",
	"<?query("/time/ntpserver/ip");?>",	"<?query("/time/daylightsaving");?>"];
dsFlag=[''<?
for("/tmp/tz/zone")
{
	echo ",'";
	map("dst","","0",*,"1");
	echo "'";
}
?>];

function CheckDS(chkid)
{
	var f=document.getElementById("time_frm");
	var val=dsFlag[chkid];
	var dis=f.tzone.disabled;
	//Synchronize the modem's clock;
	if(val=="0")
	{
		f.daylight.checked=false;
		dis=true;
	}
	f.daylight.disabled=dis;
}

function CheckField(chkid)
{
	var f=document.getElementById("time_frm");
	var dis=true;
	var ntp_dis;
	//Synchronize the modem's clock;
	if(chkid=="2")	ntp_dis=false;
	else		ntp_dis=true;
	f.ntp.disabled=ntp_dis;
	f.interval.disabled=ntp_dis;

	if(chkid=="0")	dis=false;
	f.tzone.disabled=!dis;
	f.daylight.disabled=!dis;
	f.tYEAR.disabled=dis;
	f.tMON.disabled=dis;
	f.tDAY.disabled=dis;
	f.tHOUR.disabled=dis;
	f.tMIN.disabled=dis;
	f.tSEC.disabled=dis;
	CheckDS(f.tzone.value);
}

function initTime()
{
	var f=document.getElementById("time_frm");
	var tmp_date, tmp_time;
	var d=new Date();

	//Synchronize the modem's clock;
	switch ("<?=$sync?>")
	{
	case "0":	f.sync_with[2].checked=true;	break;
	case "2":	f.sync_with[0].checked=true;	break;
	default:	f.sync_with[1].checked=true;	break;
	}
	//daylight saving
	if (dsFlag[<?=$timezone?>]=="1" && <?=$daylightsaving?>==1)	f.daylight.checked=true;
	else	f.daylight.checked=false;

	//NTP
	f.ntp.value="<?=$ntp?>";
	//show localTime
	lt = document.getElementById("localTime");
	var str=new String("");
	tmp_date=("<?=$date?>").split("/");

	if (tmp_date.length ==3)	str+=month[tmp_date[0]-1]+" "+tmp_date[1]+", "+tmp_date[2]+" ";

	tmp_time=("<?=$time?>").split(":");
	if (tmp_time.length==3)		str+="<?=$time?>";

	lt.innerHTML=str;

	if(tmp_date[2]>=parseInt("<?=$start_year?>", [10]))
		f.tYEAR.selectedIndex=parseInt(tmp_date[2], [10])-parseInt("<?=$start_year?>", [10]);
	else
		f.tYEAR.selectedIndex=0;

	f.tMON.selectedIndex=parseInt(tmp_date[0], [10])-1;
	f.tDAY.selectedIndex=parseInt(tmp_date[1], [10])-1;
	f.tHOUR.selectedIndex=parseInt(tmp_time[0], [10]);
	f.tMIN.selectedIndex=parseInt(tmp_time[1], [10]);
	f.tSEC.selectedIndex=parseInt(tmp_time[2], [10]);
	CheckField("<?=$sync?>")
	CheckDS("<?=$timezone?>");
}
function doSubmit()
{
	var f=document.getElementById("time_frm");
	var str=new String("<?=$apply_name?>");
	var c=0; // 0: Manual, 1: PC clock, 2: NTP server
	if(f.ntp.value!="" && validateKey(f.ntp.value))
		if(!checkIpAddr(f.ntp, "<?=$a_err_ntp_server_ip_addr?>"))	return;

	if (f.sync_with[0].checked)
	{
		if(f.ntp.value=="")
		{
			alert("<?=$a_ntp_server_ip_addr_can_not_be_empty?>");
			return;
		}
		c=2;
	}
	if (f.sync_with[1].checked)	c=1;

	str+="setPath=/time/";
	str+="&syncWith="+c;
	str+="&timeZone="+f.tzone.value;
	str+="&daylightSaving="+(f.daylight.checked? "1":"0");
	str+="&endSetPath=1";
	str+="&set/time/ntpServer/ip="+reduceIP(f.ntp.value);
	str+="&set/time/ntpServer/interval="+(f.interval.value);
	switch (c)
	{
	// 0: Manual, 1: PC clock, 2: NTP server
	case 0:
		str+="&setPath=/runtime/time/";
		date1=f.tMON.value+"/"+f.tDAY.value+"/"+f.tYEAR.value;
		str+="&date="+date1;
		time1=f.tHOUR.value+":"+f.tMIN.value+":"+f.tSEC.value;
		str+="&time="+time1;
		str+="&endSetPath=1";
		break;
	case 1:
		var d=new Date();
		str+="&setPath=/runtime/time/";
		date1=(d.getMonth()+1)+"/"+d.getDate()+"/"+d.getFullYear();
		str+="&date="+date1;
		time1=d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
		str+="&time="+time1;
		str+="&endSetPath=1";
		break;
	}

	str+=exeStr("submit COMMIT;submit TIME");
	self.location.href=str;
}
function doReset()
{
	self.location.href="<?=$file_name?>";	
}
function chg_ntp_srv()
{
	var f=document.getElementById("time_frm");
	f.ntp.value=f.ntp_list.value;
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload="initTime()">
<?require("/www/comm/middle.php");?>
<form method=POST id="time_frm">
<table width="<?=$width_tb?>" border=0 cellpadding=0 cellspacing=2>
<tr><td colspan=2 height=20 class=title_tb><?=$m_title?></td></tr>
<tr valign="top"><td colspan=2 height=20 class=l_tb><?=$m_title_desc?></td></tr>
<tr>
	<td width=20% height=30 class=l_tb><?=$m_device_time?></td>
	<td width=80% height=30 class=bl_tb><font color=green><span id="localTime"></span></font></td>
</tr>
<TR><TD height=20 colSpan=2 class=l_tb><?=$m_sync_clock_with?></TD></TR>
<TR>
	<TD width="20%" colspan=2 class=l_tb>
	<INPUT TYPE=radio name=sync_with value=2 onclick="CheckField(this.value)">&nbsp;&nbsp;
	<?=$m_sync_by_auto?>
	</TD>
</TR>
<TR>
	<TD colspan=2 class=l_tb>
	<INPUT TYPE=radio name=sync_with value=1 onclick="CheckField(this.value)">&nbsp;&nbsp;
	<?=$m_sync_with_computer?>
	</TD>
</TR>
<TR>
	<TD colspan=2 class=l_tb>
	<INPUT TYPE=radio name=sync_with value=0 onclick="CheckField(this.value)">&nbsp;&nbsp;
	<?=$m_sync_by_manual?>
	</TD>
</TR>
<tr><td colspan="2" height=25><br></td></tr>
<tr>
	<td align=left class=l_tb><?=$m_time_zone?></td>
	<td><select size=1 name=tzone style="font-size:12" onchange="CheckDS(this.value)">
<?
$timezone=query("/time/timezone");
for("/tmp/tz/zone")
{
	echo "<option value=".$@;
	if($timezone==$@){echo " selected";}
	echo ">".query("name")."</option>\n";
}
?>
	</select></td>
</tr>
<tr>
	<td></td>
	<td class=l_tb><input type=checkbox name=daylight><?=$m_daylight_saving?></td>
</tr>
<tr><td colspan="2" height=25><br></td></tr>
<tr><td colspan="2" class=l_tb><?=$m_get_time_via_ntp?></td></tr>
<tr> 
	<td width=20% class=l_tb><?=$m_ntp_server?></td>
	<td class=l_tb>
		<input type=text name=ntp size=25 maxlength=30><?=$m_optional?>
		<input type=button id=sel_ntp_srv onclick="chg_ntp_srv()" value="<<">
		<select id=ntp_list>
			<option value="ntp1.dlink.com">ntp1.dlink.com</option>
			<option value="ntp.dlink.com.tw">ntp.dlink.com.tw</option>
		</select>
	</td>
</tr>
<tr>
	<td width=20% class=l_tb><?=$m_interval?></td>
	<td><select size=1 name=interval>
	<option value="3600" <?if($ntp_interval=="3600"){echo "selected";}?>>&nbsp;&nbsp;<?=$m_1hrs?></option>
	<option value="14400" <?if($ntp_interval=="14400"){echo "selected";}?>>&nbsp;&nbsp;<?=$m_4hrs?></option>
	<option value="28800" <?if($ntp_interval=="28800"){echo "selected";}?>>&nbsp;&nbsp;<?=$m_8hrs?></option>
	<option value="43200" <?if($ntp_interval=="43200"){echo "selected";}?>><?=$m_12hrs?></option>
	<option value="86400" <?if($ntp_interval=="86400"){echo "selected";}?>><?=$m_24hrs?></option>
	<option value="172800" <?if($ntp_interval=="172800"){echo "selected";}?>><?=$m_48hrs?></option>
	<option value="259200" <?if($ntp_interval=="259200"){echo "selected";}?>><?=$m_72hrs?></option>
	</select></td>
</tr>
										
<tr><td colspan="2" height=25><br></td></tr>
<tr>
	<td width=20% height=26 class=l_tb><?=$m_time?></td>
	<td height=25 class=l_tb><script>
	echo("<?=$m_year?>");	print_select("tYEAR",parseInt("<?=$start_year?>", [10]),2015,1);
	echo("<?=$m_month?>");	print_select("tMON",1,12,1);
	echo("<?=$m_day?>");	print_select("tDAY",1,31,1);
	</script></td>
</tr>
<tr> 
	<td width=20% height=26></td>
	<td height=25 class=l_tb><script>
	echo("<?=$m_hour?>");	print_select("tHOUR",0,23,1);
	echo("<?=$m_minute?>");	print_select("tMIN",0,59,1);
	echo("<?=$m_second?>");	print_select("tSEC",0,59,1);
	</script></td>
</tr>
<tr><td colspan="2" height=25><br></td></tr>
<tr><td colspan="2" align=right><script language="JavaScript">apply(""); cancel("");help("help_tools.php#10");</script></td></tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
