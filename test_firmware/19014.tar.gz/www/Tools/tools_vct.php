<?
/* vi: set sw=4 ts=4 */
require("/www/auth/only_allow_admin.php");

$reload=query("/tmp/reloadVct");
if($reload!="1")
{
	$NextUrl="tools_vct.xgi?set/runtime/switch/getlinktype=1";
	set("/tmp/reloadVct", "1");
	require("/www/sys/refresh.php");
	exit;
}
else
{
	del("/tmp/reloadVct");
}

$file_name="tools_vct.php";
$apply_name="tools_vct.xgi?";
require("/www/comm/genTop.php");
$MSG_FILE="tools_vct.php";
require("/www/comm/genTopScript.php");
?>

<script language="JavaScript">
<?require("/www/comm/genHTML.js");?>

cableTestLists=["","<?=$m_wan?>","<?=$m_lan?>1","<?=$m_lan?>2","<?=$m_lan?>3","<?=$m_lan?>4"];
linkType=["<?=$m_disconnected?>","<?=$m_100full?>","<?=$m_100half?>","<?=$m_10full?>","<?=$m_10half?>"];

sData=["","<?query("/runtime/wan/inf:1/linkType");?>",		"<?query("/runtime/switch/port:1/linkType");?>",
	"<?query("/runtime/switch/port:2/linkType");?>",	"<?query("/runtime/switch/port:3/linkType");?>",
	"<?query("/runtime/switch/port:4/linkType");?>"	];

function MoreInfo(name)
{
	window.open(name,"_blank","width=400,height=250");
}

function getConnectString(s)
{
	return linkType[isNaN(parseInt(s, [10]))? 0: parseInt(s, [10])];
}
function generateVS()
{
	var str=new String("");
	for (var i=1;i < 6;i++)
	{
		str+="<tr>";
		str+="<td width=11% height=31 align=left><b>"+cableTestLists[i]+"</b></td>";
		if (sData[i] != "0")
		{
			str+="<td width=37% height=31 align=left><img src=../graphic/link.gif width=223 height=35 border=0></td>";
			str+="<td width=35% height=31 class=cn_title_tb><font color=#0080FF>"+getConnectString(sData[i])+"</font></td>";
		}
		else
		{
			str+="<td width=37% height=31 align=left><img src=../graphic/nolink.gif width=223 height=35 border=0></td>";
			str+="<td width=35% height=31 class=cn_title_tb><font color=#0080FF>"+getConnectString(sData[i])+"</font></td>";
		}
		str+="<td width=35% height=31 class=cn_title_tb><input type=button name=vct_test value=\"<?=$m_more_info?>\" onClick=\"MoreInfo('tools_vct_testing.php?port_id="+(i-1)+"')\"></td>";
		str+="<td width=17% height=31 align=left></td>";
		str+="</tr>";
	}
	document.writeln(str);
}
function doSubmit()
{
	var str=new String("tools_vct.php");
	str+=exeStr("submit COMMIT");
	self.location.href=str;
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<?require("/www/comm/middle.php");?>

<table width="<?=$width_tb?>" border="0" cellspacing="0" cellpadding="0" height="90%">
<tr>
	<td colspan="4" class=title_tb><?=$m_title1?></td>
</tr>
<tr><td height=10></td></tr>
<tr>
	<td colspan="4" class=title_tb><?=$m_title2?></td>
</tr>
<tr><td height="31"></td></tr>
<tr>
	<td class=cn_title_tb><font color="#0080FF"><?=$m_ports?></font></td>
	<td class=cn_title_tb><font color="#0080FF"><?=$m_link_status?></font></td>
	<td class=cn_title_tb><font color="#0080FF"><?=$m_link_type?></font></td>
	<td></td>
</tr>

<script>generateVS();</script>

<tr>
	<td colspan="4" align=right>
	<form name=tF method=POST>
	<a href=tools_vct.php><img src=../graphic/refresh_p.jpg border=0></a>
	<script>help("help_tools.php#15");</script>
	</form>
	</td>
</tr>
</table>
<?require("/www/comm/bottom.php");?>
