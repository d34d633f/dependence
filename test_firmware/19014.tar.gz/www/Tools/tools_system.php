<?
/* vi: set sw=4 ts=4: */

$file_name="tools_system.php";
$apply_name="tools_system.xgi?";
require("/www/comm/genTop.php");
$MSG_FILE="tools_system.php";
require("/www/comm/genTopScript.php");
$no_jumpstart=query("/function/no_jumpstart");
?>

<script language="JavaScript">
<?
if($user=="admin" && query("/sys/user:1/password")==$passwd)
{
	echo "function configSave()\n";
	echo "{\n";
	echo "	self.location.href=\"../config.bin\";\n";
	echo "}\n";
	echo "function restoreConfirm(f)\n";
	echo "{\n";
	echo "	if(!confirm('".$a_restore_to_factory_default_setting."'))	return;\n";
	echo "	var str=\"\";\n";
	echo "	str = \"/sys/restart2.xgi?\"\n";
	echo "	str += exeStr(\"submit FRESET\");\n";
	echo "	self.location.href=str;\n";
	echo "}\n";
	echo "function loadConfirm(f)\n";
	echo "{\n";
	echo "	if(!confirm('".$a_load_settings_from_file."'))	return;\n";
	echo "	f.submit();\n";
	echo "}\n";
	echo "function rebootConfirm()\n";
	echo "{\n";
	echo "	if(!confirm('".$a_reboot_router."') )	return;\n";
	echo "	var str = \"\";\n";
	echo "	str = \"/sys/restart2.xgi?\";\n";
	echo "	str += exeStr(\"submit REBOOT\");\n";
	echo "	location.href=str;\n";
	echo "}\n";

	if($no_jumpstart!="1")
	{
		echo "function doJumpStart()\n";
		echo "{\n";
		echo "	var f=document.getElementById('js_form');";
		echo "	var enable=f.js_enable[0].checked?'1':'0';\n";
		echo "	if(enable!='".query("/wireless/jumpstart/enable")."')			set_js(enable);\n";
		echo "}\n";
		echo "function ResetJS(){if(confirm('".$a_reset_jumpstart."')==true)	set_js('1');}\n";
	}
}
else
{
	echo "function loginerr(){alert('".$a_only_admin_account_can_change_the_settings."');}";
	echo "function configSave(){loginerr();}\n";
	echo "function restoreConfirm(f){loginerr();}\n";
	echo "function loadConfirm(f){loginerr();}\n";
	echo "function rebootConfirm(){loginerr();}\n";
	echo "function doJumpStart(){loginerr();}\n";
	echo "function ResetJS(){loginerr();}\n";
}

?>
function set_js(enable)
{
	var f=document.getElementById('js_form');
	var str='tools_system.xgi?';
	str+= 'set/wireless/jumpstart/enable='+enable;
	str+='&set/wireless/jumpstart/phase=1';
	if(enable=="1")
	{
		str+="&set/wireless/authentication=6&/wireless/wpa/wepmode=4";
	}
	str+=exeStr('submit COMMIT; submit WLAN;');
	self.location.href=str;
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<?require("/www/comm/middle.php");?>
<table width="<?=$width_tb?>" border=0 cellpadding=0 height=313>
<tr><td height=30 width=57% class=title_tb><?=$m_title?></td></tr>

<form>
<tr><td height=10 class=l_tb><?=$m_save_settings_to_hdd?></td></tr>
<tr><td height=20><input type=button value="<?=$m_save?>" name=save onClick="configSave();"></td></tr>
</form>

<tr><td height=20></td></tr>

<form method=POST action=upload_config._int enctype=multipart/form-data>
<tr><td height=10 class=l_tb><?=$m_load_settings_from_hdd?></font></td></tr>
<tr><td height=20><font face="Arial, Helvetica, sans-serif"><input type=file name=configuration size=20></font></td></tr>
<tr><td height=20><input type="button" value="<?=$m_load?>" name=load onclick="loadConfirm(this.form)"></td></tr>
</form>
<tr><td height=20></td></tr>

<?if($no_jumpstart=="1"){echo "<!--";}?>
<form name=js_form id=js_form>
<tr>
	<td class=l_tb><?=$m_jumpstart_function?>
	<input type=radio name=js_enable value=1 <?if(query("/wireless/jumpstart/enable")=="1"){echo "checked";}?>><?=$m_enabled?>
	<input type=radio name=js_enable value=0 <?if(query("/wireless/jumpstart/enable")!="1"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>
<tr><td height=20><input type="button" value="<?=$m_apply?>" onclick="doJumpStart()"></td></tr>

<tr><td height=20></td></tr>

<tr><td class=l_tb><?=$m_reset_jumpstart?></td></tr>
<tr><td height=20><input type="button" value="<?=$m_restore?>" onclick="ResetJS()"></td></tr>
</form>
<tr><td height=20></td></tr>
<?if($no_jumpstart=="1"){echo "-->";}?>

<form>
<tr><td height=20 class=l_tb><?=$m_restore_to_factory_default_setting?></font></td></tr>
<tr><td height=20><input type="button" value="<?=$m_restore?>" name=restore onclick="restoreConfirm(this.form)"></td></tr>
</form>

<form>
<tr><td height=20></td></tr>
<tr valign="top"><td colspan=2 height=30 class=l_tb><?=$m_reboot_device?></td></tr>
<tr>
	<td height=20><input type="button" value="<?=$m_reboot?>" onclick="rebootConfirm()"></td>
	<td height=20></td>
</tr>
<tr><td colspan=2 class=r_tb><script>help("../Help/help_tools.php#12");</script></td></tr>
</form>

</table>
<?require("/www/comm/bottom.php");?>
