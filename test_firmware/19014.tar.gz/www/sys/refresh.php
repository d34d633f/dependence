<? /* vi: set sw=4 ts=4: */ 
$MSG_FILE="sys.php";
require("/www/comm/lang_msg.php");
?>

<HTML>
<HEAD>
<TITLE><?=$m_refresh_title?></TITLE>
<link rel="stylesheet" href="../comm/webCSS.css" type="text/css">
<META HTTP-EQUIV=Content-Type CONTENT="no-cache">
<META HTTP-EQUIV=Content-Type CONTENT="text/html; charset=iso-8859-1">
<META HTTP-EQUIV=Refresh CONTENT='0; url=<?=$NextUrl?>'>
</HEAD>
<body bgcolor=#FFFFFF text="#000000" topmargin=0>
<table background=../graphic/home_02.jpg border=0 cellspacing=0 cellpadding=0 align=center width=765>
	<tr><td><img src=../graphic/home_01.jpg width=765 height=95></td></tr>
	<tr><td background=../graphic/home_02.jpg>
		<table width=75% height=131 border=0 align=center cellpadding=0 cellspacing=0 >
		<tr><td class=c_tb>
		<font color='##FF0000'><b><?=$m_refreshing?></b></font>
		</td></tr>
		</table>
	</div></td></tr>
	<tr><td background=../graphic/home_03.jpg> <div align=right><img src=../graphic/down_44.gif width=25 height=27></div></td></tr>
</table>
</body></html>
