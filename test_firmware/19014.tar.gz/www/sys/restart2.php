<? /* vi: set sw=4 ts=4: */
$MSG_FILE="sys.php";
require("/www/comm/lang_msg.php");
?>
<HTML>
<HEAD>
<TITLE><?=$m_restart_title?></TITLE>
<link rel="stylesheet" href="/comm/webCSS.css" type="text/css">
<META HTTP-EQUIV=Content-Type CONTENT="no-cache">
<META HTTP-EQUIV=Content-Type CONTENT="text/html; charset=iso-8859-1">
</HEAD>
<?
require("/www/sys/burn_time.php");
?>
<SCRIPT language=javascript>
var countdown = get_burn_time(64);
function nev()
{
	countdown--;
	document.formWaitInfo.WaitInfo.value = countdown;
	if(countdown < 1 ) top.location.href='<?=$index_page?>';
	else setTimeout('nev()',1000);
}
</SCRIPT>

<body bgcolor=#FFFFFF text="#000000" topmargin=0 onload='nev()'>
<form method=post id=formWaitInfo name=formWaitInfo>
<table background=../graphic/home_02.jpg border=0 cellspacing=0 cellpadding=0 align=center width=765>
	<tr><td><img src=../graphic/home_01.jpg width=765 height=95></td></tr>
	<tr><td background=../graphic/home_02.jpg>
		<table width=75% height=131 border=0 align=center cellpadding=0 cellspacing=0 >
			<tr><td></td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td class=c_tb>
			<?require("/www/locale/".$__LANG."/restart_msg.php");?>
			</td></tr>
			<tr><td class=c_tb><a href=<?=$index_page?>><?=$g_continue?></a></td></tr>
		</table>
	</tr>
	<tr>
		<td background=../graphic/home_03.jpg> <div align=right><img src=../graphic/down_44.gif width=25 height=27></div></td>
	</tr>
</table>
</form>
</body></html>
