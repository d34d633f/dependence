<?

$MSG_FILE="adv_filters_ip.php";

$file_name="adv_filters_ip.php";
$apply_name="adv_filters_ip.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");

if($edit_id!="")
{
	$num=$edit_id;

	anchor("/security/di624/ipfilter/entry:".$edit_id);
	$enable=query("enable");
	$ip1=query("sourceipbegin");
	$ip2=query("sourceipend");
	$port1=query("destportbegin");
	$port2=query("destportend");
	$protocol=query("protocol");
	$schd=query("schedule/enable");
	$b_time=query("schedule/begintime");
	$e_time=query("schedule/endtime");
	$day1=query("schedule/beginday");
	$day2=query("schedule/endday");
}
?>

<script language="JavaScript">
<?require("/www/comm/select.js");?>
dataLists=[['index','enable','sip_b','sip_e','dport_b','dport_e','pro','schd','b_time','e_time','day_b','day_e']<?
$rule_num=0;
for("/security/di624/ipfilter/entry")
{
	$rule_num++;
	echo ",\n	['".$#."','".
	query("enable")."','".			query("sourceipbegin")."','".		query("sourceipend")."','".
	query("destportbegin")."','".		query("destportend")."','".		query("protocol")."','".
	query("schedule/enable")."','".		query("schedule/begintime")."','".	query("schedule/endtime")."','".
	query("schedule/beginday")."','".	query("schedule/endday").
	"']";
}
if($edit_id==""){$num=$rule_num+1;}
?>];
lanip="<?query("/lan/ethernet/ip");?>";
lanmask="<?query("/lan/ethernet/netmask");?>";

var	DstPortRangeType, SrcIpRangeType;
function setSchedule()
{
	var f=document.getElementById("frmIPF");

	beginTime=("<?=$b_time?>").split(":");
	f.hour1.selectedIndex = (parseInt(beginTime[0], [10]) >=12? parseInt(beginTime[0], [10])-12:parseInt(beginTime[0], [10]));
	f.min1.selectedIndex = (parseInt(beginTime[1], [10])/5);
	f.am1.selectedIndex = (parseInt(beginTime[0], [10]) >=12? 1:0);
	endTime=("<?=$e_time?>").split(":");
	f.hour2.selectedIndex = (parseInt(endTime[0], [10]) >=12? parseInt(endTime[0], [10])-12:parseInt(endTime[0], [10]));
	f.min2.selectedIndex = (parseInt(endTime[1], [10])/5);
	f.am2.selectedIndex = (parseInt(endTime[0], [10]) >=12? 1:0);
	f.day1.selectedIndex=parseInt("<?=$day1?>", [10]);
	f.day2.selectedIndex=parseInt("<?=$day2?>", [10]);
}

function CheckField(proto)
{
	var f=document.getElementById("frmIPF");
	var bPort=false;
	if(proto=="4" || proto=="1")
	{
		bPort=true;
		f.port1.value="";
		f.port2.value="";
	}
	f.port1.disabled=bPort;
	f.port2.disabled=bPort;
}

function EditRow(r)
{
	self.location.href="<?=$file_name?>?edit_id="+r;
}

function doReset()
{
	self.location.href="<?=$file_name?>";
}

// this function is used for sending data to server when user presses the "Apply" button.
function doSubmit()
{
	if (checkParameter()==false) return;
	var f = document.getElementById("frmIPF");
	var str=new String("<?=$apply_name?>");
	var num="<?=$num?>";

	str+="setPath=/security/di624/ipFilter/entry:"+num+"/";
	str+="&enable="+(f.enable[1].checked? "0":"1");
	str+="&action=2";
	str+="&sourceIPbegin="+reduceIP(f.ip1.value);
	str+="&sourceInf=1";
	str+="&sourceIPbegin="+(f.ip1.value==""? "":reduceIP(f.ip1.value));
	str+="&sourceIPend="+(f.ip2.value==""? "":reduceIP(f.ip2.value));
	str+="&sourceIpRangeType="+SrcIpRangeType;
	str+="&destIPbegin=0.0.0.0";
	str+="&destIPend=255.255.255.255";
	str+="&destinationInf=0";
	str+="&destIpRangeType=3";
	str+="&destPortBegin="+f.port1.value;
	str+="&destPortEnd="+f.port2.value;
	str+="&destPortRangeType="+DstPortRangeType;

	str+="&protocol="+f.protocol.value;
	str+="&/schedule/enable="+(f.schd[1].checked? "1":"0");

	if (f.schd[1].checked)
	{
		btime=(f.am1.selectedIndex==1? f.hour1.selectedIndex+12 : f.hour1.selectedIndex)+":"+f.min1[f.min1.selectedIndex].text;
		str+="&/schedule/beginTime="+btime;
		etime=(f.am2.selectedIndex==1? f.hour2.selectedIndex+12 : f.hour2.selectedIndex)+":"+f.min2[f.min2.selectedIndex].text;
		str+="&/schedule/endTime="+etime;
		str+="&/schedule/beginDay="+f.day1.selectedIndex;
		str+="&/schedule/endDay="+f.day2.selectedIndex;
	}

	str+="&endSetPath=1";
	str+=exeStr("submit COMMIT;submit RG_IP_FILTER");
	self.location.href=str;
}

// this function is used for sending data to server when user presses the "Delete" button.
function doDelete(num)
{
	if (confirm("Are you sure you want to delete this ?")==false) return;
	var f = document.getElementById("frmIPF");
	var str=new String("<?=$apply_name?>");

	str+="del/security/di624/ipfilter/entry:"+num+"=1";
	str+=exeStr("submit COMMIT;submit RG_FILTER");
	self.location.href=str;
}

function checkParameter()
{
	var f = document.getElementById("frmIPF");
	MaxRule=parseInt("<?=$max_rule?>", [10]);

	if (parseInt("<?=$num?>", [10]) > MaxRule)
	{
		alert(<?=$a_exced_max_entry?>);
		return false;
	}

	DstPortRangeType=3;
	SrcIpRangeType=3;
	// check if ip1 or ip2 are same with LAN IP address
	if (f.ip1.value==lanip)
	{
		alert(<?=$a_ip_cant_include_lanIP?>);
		f.ip1.focus();
		return false;
	}
	if (f.ip2.value==lanip)
	{
		alert(<?=$a_ip_cant_include_lanIP?>);
		f.ip2.focus();
		return false;
	}

	if(f.ip1.value!="*" && !checkSubnet(lanip, lanmask, f.ip1.value))
	{
		alert(<?=$a_should_be_in_same_subnet?>);
		f.ip1.focus();
		return false;
	}

	if(!isBlank(f.ip2.value) && !checkSubnet(lanip, lanmask, f.ip2.value))
	{
		alert(<?=$a_should_be_in_same_subnet?>);
		f.ip2.focus();
		return false;
	}

	
	// starting ip
	if(f.ip1.value==f.ip2.value)
		f.ip2.value="";

	// ending ip
	if (!isBlank(f.ip2.value))
	{
		if (!checkIpAddr(f.ip2, "<?=$a_error_endIP?>"))	return false;
	}
	else
		SrcIpRangeType=2;

	if(f.ip1.value=="*")
	{
		SrcIpRangeType=1;
		f.ip2.value="";
	}
	else if (!checkIpAddr(f.ip1, "<?=$a_error_startIP?>"))	return false;

	// if ending ip is bigger than starting ip ?
	if (f.ip2.value!="")
	{
		var ip1=(f.ip1.value).split(".");
		var ip2=(f.ip2.value).split(".");
		var tip1=0,tip2=0;
		var i=0;

		for (i=1; i<=4; i++)
		{
			tip1+=parseInt(ip1[i-1], [10])*(1<<((4-i)*8));
			tip2+=parseInt(ip2[i-1], [10])*(1<<((4-i)*8));
		}

		if (tip2 < tip1)
		{
			alert("<?=$a_endIP_should_be_greater_than_startIP?>");
			f.ip2.focus();
			return false;
		}
	}

	if(f.protocol.value!="4" && f.protocol.value!="1")
	{
		// starting port
		if(f.port1.value==f.port2.value)	f.port2.value="";
		if(f.port2.value=="")			DstPortRangeType=2;

		if(f.port1.value=="*")
		{
			DstPortRangeType=1;
			f.port2.value="";
		}
		else if (!isNumber(f.port1.value))
		{
			alert("<?=$a_start_port_should_be_number?>");
			f.port1.value="";
			f.port1.focus();
			return false;
		}
		else
		{
			if (!validPort(f.port1.value)) return false;
		}

		// ending port
		if (!isBlank(f.port2.value))
		{
			if (!isNumber(f.port2.value))
			{
				alert("<?=$a_end_port_should_be_number?>");
				f.port2.value();
				f.port2.focus();
				return false;
			}
			else
			{
				if (!validPort(f.port2.value)) return false;
			}
		}

		// if starting port is bigger than ending port ?
		if (f.port2.value!="")
		{
			if (parseInt(f.port1.value, [10]) > parseInt(f.port2.value, [10]))
			{
				alert("<?=$a_end_port_should_be_greater_than_start_port?>");
				f.port2.focus();
				return false;
			}
		}
	}

	if(f.enable[1].checked)
		return true;
	if(f.schd[1].checked)
	{
		btime=(f.am1.value*12+parseInt(f.hour1.value, [10]))*60+f.min1.value;
		etime=(f.am2.value*12+parseInt(f.hour2.value, [10]))*60+f.min2.value;
		if(parseInt(btime, [10])>=parseInt(etime, [10]))
		{
			alert("<?=$a_starttime_cant_big_then_end?>");
			f.hour1.focus();
			return false;
		}
	}

	btime=(f.am1.value==1? parseInt(f.hour1.value, [10])+12 : f.hour1.value)+":"+f.min1.value;
	etime=(f.am2.value==1? parseInt(f.hour2.value, [10])+12 : f.hour2.value)+":"+f.min2.value;
	for(i=0;i<dataLists.length;i++)
	{
		if(parseInt("<?=$edit_id?>", [10])==i)	continue;
		if(f.ip1.value==dataLists[i][2] && f.ip2.value==dataLists[i][3] && f.port1.value==dataLists[i][4] && 
			f.port2.value==dataLists[i][5] && f.protocol.value==parseInt(dataLists[i][6], [10]))
		{
			if((f.schd[1].checked && dataLists[i][7]=="1" && btime==dataLists[i][8] && 
				etime==dataLists[i][9] && f.day1.value==dataLists[i][10] && f.day2.value==dataLists[i][11])
				|| (f.schd[0].checked))
			{
				alert("<?=$a_same_entry_exist?>");
				return false;
			}
		}
	}

    return true;
}
function print_pro(n,v,s)
{
	proList=["","ALL","TCP","UDP","ICMP"];
	str="<select name="+n+" size=1";
	if(s!="")	str+=" onchange='"+s+"'";
	str+=">";
	for(i=1;i<proList.length;i++)
	{
		str+="<option value="+i;
		if(i==parseInt(v, [10])) str+=" selected";
		str+=">"+proList[i]+"</option>"
	}
	str+="</select>";
	document.write(str);
}
function init()
{
	var f = document.getElementById("frmIPF");
	<?if($edit_id==""){echo "	f.protocol.selectedIndex=1;\n";}?>
	CheckField('<?=$protocol?>');
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload="init()">
<?require("/www/comm/middle.php");?>
<form method=post action=ipf.cgi id=frmIPF>
<input type=hidden name=editRow value=-1>
<table width="<?=$width_tb?>" border=0 cellspacing=0 cellpadding=0>
<tr><td colspan=2><?$now_filter="ip";	require("/www/Advanced/adv_filters_comm.php");?></td></tr>
<tr>
	<td colspan=2 class=title_tb><?=$m_ip_filters?></td>
</tr>
<tr valign="top">
	<td colspan=2 height="30" class=l_tb><?=$m_ip_filters_description?><td>
</tr>
<tr>
	<td></td>
	<td height=35 class=l_tb>
	<input type=radio name=enable value=1 <?if($enable=="1"){echo "checked";}?>><?=$m_enabled?>
	<input type=radio name=enable value=0 <?if($enable=="0"){echo "checked";}?>><?=$m_disabled?>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type=reset value="<?=$m_clear?>" onClick="doReset()">
	</td>
</tr>
<tr>
	<td height=32 class=r_tb><?=$m_ip_addr?>&nbsp;</td>
	<td height=32 class=l_tb>
	<input type=text name=ip1 size=15 maxlength=15 value="<?=$ip1?>">-
	<input type=text name=ip2 size=15 maxlength=15 value="<?=$ip2?>">
	</td>
</tr>
<tr>
	<td height=23 class=r_tb><?=$m_protocol?>&nbsp;</td>
	<td height=23 class=l_tb><script>print_pro("protocol", "<?=$protocol?>","CheckField(this.value)");</script></td>
</tr>
<tr>
	<td height=35 class=r_tb><?=$m_port?>&nbsp;</td>
	<td height=35 class=l_tb>
	<input type=text name=port1 size=5 maxlength=5 value="<?=$port1?>">-
	<input type=text name=port2 size=5 maxlength=5 value="<?=$port2?>">
	</td>
</tr>
<?require("/www/locale/".$__LANG."/schedule.php");?>
<tr>
	<td height=10><br></td>
</tr>
<tr>
	<td colspan=2 align=right><script language="JavaScript">apply(""); cancel("");help("help_adv.php#07");</script></td>
</tr>
<tr>
	<td colspan=2><table width=100%><tr>
		<td width=50% class=title_tb><?=$m_ip_filter_list?></td>
		<td width=50% class=r_tb><script>print_rule_count("<?=$rule_num?>","<?=$max_rule?>");</script></td>
	</tr></table></td>
</tr>
<tr>
	<td colspan=2>
	<table width=100% border=0 id=tabIPF cellpadding=0 cellspacing=0>
	<tr bgcolor=#B7DCFB>
		<td width=5%></td>
		<td class=l_tb><?=$m_ip_range?></td><td class=l_tb><?=$m_pro?></td><td class=l_tb><?=$m_schedule?></td>
		<td></td>
	</tr>
<?
for("/security/di624/ipfilter/entry")
{
	$sip_e=query("sourceipend");
	$dst_e=query("destportend");
	if($edit_id==$#){echo "	<tr bgcolor=".$sel_color.">\n";}
	else		{echo "	<tr>\n";}
	if($index_en=="1"){echo "		<td class=r_tb nowrap>".$#.".<input type='checkbox' name='en' ";}
	else{echo "		<td class=r_tb nowrap><input type='checkbox' name='en' ";}
	if(query("enable")=="1"){echo "checked ";}
	echo "disabled></td>\n";
	echo "		<td class=l_tb>".query("sourceipbegin");
	if($sip_e!=""){echo "-".$sip_e;}
	echo "</td>\n";
	echo "		<td class=l_tb>";
	map("protocol","1","ALL","2","TCP","3","UDP","4","ICMP");
	echo ", ".query("destportbegin");
	if($dst_e!=""){echo "/".$dst_e;}
	echo "</td>\n";
	echo "		<td class=l_tb>\n";
	if(query("schedule/enable")!=1){echo $m_always;}
	else
	{
		echo query("schedule/begintime")."~".query("schedule/endtime").", ";
		map("schedule/beginday" ,"0","Sun", "1","Mon", "2","Tue", "3","Wed", "4","Thu", "5","Fri", "6","Sat");
		echo "~";
		map("schedule/endday" ,"0","Sun", "1","Mon", "2","Tue", "3","Wed", "4","Thu", "5","Fri", "6","Sat");
	}
	echo "</td>\n";
	echo "		<td class=r_tb width=40 nowarp>\n";
	echo "		<a href='javascript:EditRow(".$#.")'><img src='../graphic/edit.gif' width=15 height=17 border=0 alt=edit></a>\n";
	echo "		<a href='javascript:doDelete(".$#.")'><img src='../graphic/delet.gif' width=15 height=18 border=0 alt=delete></a>\n";
	echo "		</td>\n";
	echo "	</tr>\n";
}
?>
	</table>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
