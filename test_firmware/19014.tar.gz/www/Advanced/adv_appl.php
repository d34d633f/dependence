
<?
$MSG_FILE="adv_appl.php";

$file_name="adv_appl.php";
$apply_name="adv_appl.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");

if($edit_id!="")
{
	$num=$edit_id;

	anchor("/nat/porttrigger/entry:".$edit_id);
	$enable=query("enable");
	$name=queryjs("description");
	$triPort1=query("triggerportbegin");
	$triPort2=query("triggerportend");
	$triType=query("triggerProtocol");
	$pubPort=query("publicport");
	$pubType=query("publicProtocol");
}

?>

<script language="JavaScript">
dLists=[["","",""]<?
$rule_num=0;
for("/nat/porttrigger/entry")
{
	$rule_num++;
	echo ",\n	['".query("enable")."','".query("triggerProtocol")."','".query("triggerPortBegin")."','".query("triggerPortEnd")."']";
}
if($edit_id==""){$num=$rule_num+1;}
?>];

function EditRow(r)
{
	self.location.href="<?=$file_name?>?edit_id="+r;
}

function doReset()
{
	self.location.href="<?=$file_name?>";
}

function doSubmit()
{
	if (checkParameter()==false) return;
	var f = document.getElementById("frmSA");
	var str=new String("<?=$apply_name?>");
	var num;

	if(!chk_valid_char(f.name.value))
	{
		alert("<?=$a_invalid_domain?>");
		f.name.select();
		return;
	}
	num=parseInt("<?=$num?>", [10]);

	str+="setPath=/nat/porttrigger/entry:"+num+"/";
	str+="&enable="+(f.enable[0].checked? "1":"0");
	str+="&description="+escape(f.name.value);
	str+="&triggerProtocol="+f.triType.selectedIndex;
	str+="&triggerPortBegin="+f.triPort1.value;
	str+="&triggerPortEnd="+f.triPort2.value;
	str+="&publicPort="+f.pubPort.value;
	str+="&publicProtocol="+f.pubType.selectedIndex;
	str+="&endSetPath=1";
	str+=exeStr("submit COMMIT;submit RG_APP");
	self.location.href=str;
}

function doDelete(num)
{
	if (confirm(<?=$a_conf_delete?>)==false) return;
	var f = document.getElementById("frmSA");
	var str=new String("<?=$apply_name?>");

	str+="del/nat/portTrigger/entry:"+num+"=1";
	str+=exeStr("submit COMMIT;submit RG_APP");
	self.location.href=str;
}

function checkParameter()
{
	var f = document.getElementById("frmSA");
	var i=0;
	MaxRule=parseInt("<?=$max_rule?>", [10]);
	if (parseInt("<?=$num?>", [10]) > MaxRule)
	{
		alert(<?=$a_err_exceed?>);
		return false;
	}

	//name
	if (isBlank(f.name.value))
	{
		alert(<?=$a_err_name?>);
		return false;
	}

	// trigger port begin
	if (isNumber(f.triPort1.value))
	{
		if (!validPort(f.triPort1.value)) return false;
	}
	else
	{
		alert(<?=$a_err_trigger_port_begin?>);
		return false;
	}

	// trigger port end
	if (f.triPort2.value.length && isNumber(f.triPort2.value))
	{
		if (!validPort(f.triPort2.value)) return false;
	}
	else
	{
		if (f.triPort2.value.length)
		{
			alert(<?=$a_err_trigger_port_end?>);
			return false;
		}
	}

	// trigger port range
	if (parseInt(f.triPort2.value, [10]) < parseInt(f.triPort1.value, [10]))
	{
		alert(<?=$a_err_trigger_port_range?>);
		return false;
	}

	// public port
	var p=(f.pubPort.value).split(",");
	var flag=true;
	for (i=0; i < p.length; i++)
	{
		if ((p[i].indexOf("-"))!=-1)
		{
			var tmp_p=p[i].split("-");
			if (tmp_p.length==2)
			{
				for (var j=0; j < tmp_p.length; j++)
				{
					if (isNumber(tmp_p[j]))	{if (!validPort(tmp_p[j])) return false;}
					else			{flag=false;	break;}
				}
			}
			else	{flag=false;	break;}
		}
		else
		{
			if (isNumber(p[i]))	{if (!validPort(p[i])) return false;}
			else			{flag=false;	break;}
		}
	}
	if (!flag)
	{
		alert(<?=$a_err_public_port_format?>);
		return false;
	}

	if(f.enable[1].checked)
		return true;

	for(i=1; i<dLists.length; i++)
	{
		if(parseInt("<?=$edit_id?>", [10])==i)
			continue;
		if(f.triType.value==dLists[i][1] && f.triPort1.value==dLists[i][2])
		{
			alert(<?=$a_err_entry_exists?>);
			return false;
		}
	}

	return true;
}
function print_pro(n, value)
{
	proList=["<?=$m_both?>","<?=$m_tcp?>","<?=$m_udp?>"];
	str="";
	str+="<select name="+n+">";
	for(i=0;i<proList.length;i++)
	{
		str+="<option value="+i;
		if(i==parseInt(value, [10]))	str+=" selected ";
		str+=">"+proList[i]+"</option>";
	}
	str+="</select>";
	document.write(str);
}
function format_str_by_len(str,offset)
{
	if(offset=="") offset=5;
	var nstr=new String("");
	var i;
	for (i=0; i<str.length; i++) {
		nstr+=str.slice(i,i+1);
		if (!((i+1)%offset)) nstr+="<br>";
	}
	document.write(nstr);
}
function format_str_by_field(str,foffset)
{
	if(foffset=="") foffset=1;
	var nstr=new String("");
	var tmp=new String("");
	var i, j=0;
	for (i=0; i<str.length; i++) {
		tmp=str.slice(i,i+1);
		nstr+=tmp;
		if ((tmp==',')||(tmp=='-')) {
			if (!((++j)%foffset)) nstr+="<br>";
		}
	}
	document.write(nstr);
}
function init()
{
	var f = document.getElementById("frmSA");
<?
	if ($edit_id=="")
	{
		echo "	f.triType.selectedIndex=1;\n";
		echo "	f.pubType.selectedIndex=1;\n";
	}
	else
	{
		echo "	f.name.value=\"".$name."\";\n";
	}
?>
}
</script>
<BODY topmargin=0 leftmargin=0 BGCOLOR="#FFFFFF" onload=init()>
<?require("/www/comm/middle.php");?>
<form method=post id=frmSA>
<input type=hidden name=editRow value=-1>
<table width="<?=$width_tb?>" border=0 cellpadding=0 height=30>
<tr>
	<td colspan=2 height=14 class=title_tb><?=$m_appl_title?></td>
</tr>
<tr valign="top">
	<td colspan=2 height=30 class=l_tb><?=$m_appl_descript?></td>
</tr>
<tr>
	<td width=18%>&nbsp;</td>
	<td height=11 class=l_tb>
	<input type=radio name=enable value=1 checked><?=$m_enabled?>
	<input type=radio name=enable value=0 <?if($enable!="1"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>
<tr>
	<td class=l_tb><?=$m_name?>&nbsp;</td>
	<td height=12>
		<input type=text name=name size=30 maxlength=31>
		<input type="reset" value="Clear" onClick="doReset()" name="clear">
	</td>
</tr>
<tr>
	<td class=l_tb><?=$m_trigger_port?>&nbsp;</td>
	<td height=25>
		<input type=text name=triPort1 size=5 maxlength=5 value="<?=$triPort1?>">-
		<input type=text name=triPort2 size=5 maxlength=5 value="<?=$triPort2?>">
	</td>
</tr>
<tr>
	<td class=l_tb><?=$m_trigger_prot_type?>&nbsp;</td>
	<td height=25 class=l_tb><script>print_pro("triType","<?=$triType?>");</script></td>
</tr>
<tr>
	<td class=l_tb><?=$m_public_port?>&nbsp;</td>
	<td height=25><input type=text name=pubPort size=30 maxlength=60 value="<?=$pubPort?>"></td>
</tr>
<tr>
	<td class=l_tb><?=$m_public_prot_type?>&nbsp;</td>
	<td height=25 class=l_tb><script>print_pro("pubType","<?=$pubType?>");</script></td>
</tr>
<tr>
	<td colspan=2 valign=bottom align=right>
	<script language="JavaScript">apply(""); cancel("doReset()");help("help_adv.php#06");</script>
	</td>
</tr>
</table>
<table width="<?=$width_tb?>">
<tr><td valign=bottom class=title_tb><?=$m_appl_list?></td><td class=r_tb><script>print_rule_count("<?=$rule_num?>", "<?=$max_rule?>");</script></td></tr>
<tr>
	<td colspan=2>
	<table border=0 id=tabSA width=100% cellpadding=0 cellspacing=0>
	<tr bgcolor=#b7dcfb>
		<td width=3%>&nbsp;</td>
		<td class=l_tb width=30%><?=$m_name?></td>
		<td width=1%>&nbsp;</td>
		<td class=l_tb width=10%><?=$m_trigger?></td>
		<td width=1%>&nbsp;</td>
		<td class=l_tb width=45%><?=$m_public?></td>
		<td width=10%>&nbsp;</td>
	</tr>
<?
for("/nat/porttrigger/entry")
{
	$port_e=query("triggerportend");
	if($edit_id==$@){echo "	<tr bgcolor=".$sel_color.">\n";}
	else		{echo "	<tr>\n";}
	if($index_en=="1")	{echo "		<td class=r_tb nowrap>".$@.".<input type='checkbox' name='en' ";}
	else			{echo "		<td class=r_tb nowrap><input type='checkbox' name='en' ";}
	if(query("enable")=="1"){echo "checked ";}
	echo "disabled></td>\n";
	echo "		<td class=l_tb style='word-break:break-all'><script>format_str_by_len(\"".queryjs("description")."\",\"20\");</script></td>\n";
	echo "		<td>&nbsp;</td>\n";
	echo "		<td class=l_tb>".query("triggerportbegin");
	if($port_e!=""){echo "-<br>".$port_e;}
	echo "</td>\n"; 
	echo "		<td>&nbsp;</td>\n";
	echo "		<td class=l_tb style='word-break:break-all'><script>format_str_by_field(\"".query("publicport")."\",\"6\");</script></td>\n";
/*	echo "		<td class=l_tb style='word-break:break-all'><script>echosc(\"".queryjs("description")."\");</script></td>\n";
	echo "		<td>&nbsp;</td>\n";
	echo "		<td class=l_tb style='word-break:break-all'>".query("triggerportbegin");
	if($port_e!=""){echo "-".$port_e;}
	echo "</td>\n";
	echo "		<td>&nbsp;</td>\n";
	echo "		<td class=l_tb style='word-break:break-all'>".query("publicport")."</td>\n"; */
	echo "		<td class=r_tb>\n";
	echo "		<a href='javascript:EditRow(".$@.")'>".$g_edit."</a>\n";
	echo "		<a href='javascript:doDelete(".$@.")'>".$g_delete."</a>\n";
	echo "		</td>\n";
	echo "	</tr>\n";
}
?>
	</table>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
