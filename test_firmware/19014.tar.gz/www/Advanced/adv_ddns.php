<?
$MSG_FILE="adv_ddns.php";

$file_name="adv_ddns.php";
$apply_name="adv_ddns.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
anchor("/ddns");
$enable=query("enable");
$provider=query("provider");
$hostname=queryjs("hostname");
$user=queryjs("user");
$password=queryjs("password");
?>
<script language="JavaScript">
function doReset()
{
	self.location.href="<?=$file_name?>";
}

function doSubmit()
{
	if (checkParameter()==false) return;
	var f=document.getElementById("tools_ddns_form");
	var str=new String("<?=$apply_name?>");
	if(CheckUCS2(f.hostname.value))
	{
		alert(<?=$a_info_ASCII_host?>);
		f.hostname.focus();
		return;
	}
	if(CheckUCS2(f.user.value))
	{
		alert(<?=$a_info_ASCII_user?>);
		f.user.focus();
		return;
	}
	if(CheckUCS2(f.pass.value))
	{
		alert(<?=$a_info_ASCII_passwd?>);
		f.pass.focus();
		return;
	}
							
	str+="SET/ddns/enable="+(f.ddns[0].checked? "1":"0");
	str+="&SET/ddns/provider="+f.ddns_server[f.ddns_server.selectedIndex].value;
	str+="&SET/ddns/hostname="+escape(f.hostname.value);
	str+="&SET/ddns/user="+escape(f.user.value);
	str+="&SET/ddns/password="+escape(f.pass.value);
		
	str+=exeStr("submit COMMIT;submit DDNS");
	self.location.href=str;
}

function checkParameter()
{
	var f=document.getElementById("tools_ddns_form");

	//hostname
	if (isBlank(f.hostname.value))
	{
		alert(<?=$a_err_enpty_host?>);
		f.hostname.value="";
		f.hostname.focus();
		return false;
	}

	//Username
	if (isBlank(f.user.value))
	{
		alert(<?=$a_err_enpty_user?>);
		f.user.value="";
		f.user.focus();
		return false;
	}

	//Password
	if (isBlank(f.pass.value))
	{
		alert(<?=$a_err_enpty_passwd?>);
		f.pass.focus();
		return false;
	}
	return true;
}
function print_ddns_srv(n)
{
	dList=["","DynDns.org","No-IP.com","hn.org","zoneedit.com"];
	str="<select name="+n+" class=input1 tabindex=2 id="+n+">";
	for(i=1;i<dList.length;i++)
	{
		str+="<option value="+i;
		if(parseInt("<?=$provider?>", [10])==i)str+=" selected ";
		str+=">"+dList[i]+"</option>";
	}
	str+="</select>";
	document.write(str);
}

function initDDNS()
{
 f=document.getElementById("tools_ddns_form");
 f.hostname.value="<?=$hostname?>";
 f.user.value="<?=$user?>";
 f.pass.value="<?=$password?>";
}

</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload=initDDNS()>
<?require("/www/comm/middle.php");?>
<form method=POST name=tools_ddns_form id=tools_ddns_form>
<table width="<?=$width_tb?>" border=0 cellpadding=0>
<tr><td colspan=2 height=14 class=title_tb><?=$m_ddns_title?></td></tr>
<tr>
	<td width=27% height=20 class=l_tb><?=$m_ddns?></td>
	<td width=73% height=20 class=l_tb>
	<input type=radio name=ddns value=1 <?if($enable=="1"){echo "checked";}?>><?=$m_enabled?>
	<input type=radio name=ddns value=0 <?if($enable!="1"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>
<tr>
	<td height=20 class=l_tb><?=$m_ddns_server?></td>
	<td height=20><script>print_ddns_srv("ddns_server");</script></td>
</tr>
<tr>
	<td height=20 class=l_tb><?=$m_ddns_host_name?></td>
	<td height=20><input type="text" name="hostname" size="40" maxlength="60" value=""></td>
</tr>
<tr>
	<td height=20 class=l_tb><?=$m_user?></td>
	<td height=20><input type="text" name="user" size="40" maxlength="60" value=""></td>
</tr>
<tr>
	<td height=20 class=l_tb><?=$m_password?></td>
	<td height=20><input type="password" name="pass" size="40" maxlength="40" value=""></td>
</tr>
<tr>
	<td colspan=2 align=right><script language="JavaScript">apply(""); cancel("");help("help_adv.php#10");</script></td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
