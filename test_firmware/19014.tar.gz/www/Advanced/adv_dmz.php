<?
$MSG_FILE="adv_dmz.php";
$apply_name="adv_dmz.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");?>
<script language="JavaScript">
myAction=parseInt("<?query("/nat/dmzsrv/dmzaction");?>", [10]);
lanIP="<?query("/lan/ethernet/ip");?>";
dmzIP="<?query("/nat/dmzsrv/ipaddress");?>";

myLAN=getIP(lanIP);
myIP=getIP(dmzIP);

function EnableRow(f, e)
{
	switch (parseInt(e, [10]))
	{
	case 0:
		f.dmzEnable[1].checked = true;
		break;
	case 1:
		f.dmzEnable[0].checked = true;
		break;
	}
}
function checkParameter(f)
{
	var dIP4=f.dmzIP4.value;
	ip=myLAN[1]+"."+myLAN[2]+"."+myLAN[3]+"."+f.dmzIP4.value;
	if (isNumber(dIP4))
	{
		if (!check_ip_interval(dIP4))
		{
			alert(<?=$a_err_ip_ranger?>);
			return false;
		}
	}
	else
	{
		alert(<?=$a_err_ip_format?>);
		return false;
	}

	if(ip==lanIP)
	{
		alert(<?=$a_err_same_lanip?>);
		return false;
	}
}

// this function is used for sending data to server when user presses the "Apply" button.
function doSubmit()
{
	var f = document.getElementById("frmDMZ");
	var str=new String("<?=$apply_name?>");

	if(checkParameter(f)==false)	return;

	str+="SET/nat/dmzSrv/dmzAction="+(f.dmzEnable[0].checked? "1":"0");

	ip=myLAN[1]+"."+myLAN[2]+"."+myLAN[3]+"."+f.dmzIP4.value;
	str+="&SET/nat/dmzSrv/ipAddress="+reduceIP(ip);
	str+=exeStr("submit COMMIT;submit RG_DMZ");
	self.location.href=str;
}

function initDMZ()
{
	var f = document.getElementById("frmDMZ");
	EnableRow(f, myAction);
	f.dmzIP1.value=myLAN[1];
	f.dmzIP2.value=myLAN[2];
	f.dmzIP3.value=myLAN[3];
	if (myIP[4] != "")	f.dmzIP4.value=myIP[4];
	else			f.dmzIP4.value=0;
}
function print_ip(n)
{
	str="";
	for(var i=1;i<4;i++)
	{
		str+="<input type=text readonly name="+n+i+" size=3 maxlength=3 style='border:0;width=25px;text-align:center'>.";
	}
	document.write(str);
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload="initDMZ()">
<?require("/www/comm/middle.php");?>
<form method=POST action=dmz.cgi id=frmDMZ>
<table width="<?=$width_tb?>" border=0 cellspacing=2 cellpadding=0 height=30>
<tr><td colspan="2" class=title_tb><?=$m_dmz_title?></td></tr>
<tr valign="top"><td colspan="2" height="40" class=l_tb><?=$m_dmz_descript?></td></tr>
<tr>
	<td width=30%></td>
	<td height=11 class=l_tb><input type=radio name=dmzEnable value=1><?=$m_enabled?><input type=radio name=dmzEnable value=0 checked><?=$m_disabled?></td>
</tr>
<tr>
	<td class=r_tb><?=$m_ip_addr?> :&nbsp;</td>
	<td height=5 class=l_tb><script>print_ip("dmzIP");</script>
	<input type=text name=dmzIP4 size=3 maxlength=3 value="0">
	</td>
</tr>
<tr><td colspan=4><br></td></tr>
<tr>
	<td colspan=2 align=right>
	<script language="JavaScript">apply(""); cancel("initDMZ()");help("help_adv.php#09");</script>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
