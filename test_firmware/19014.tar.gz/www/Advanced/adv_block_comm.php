<? /* vi: set sw=4 ts=4: */
$MSG_FILE="adv_block_comm.php";
require("/www/comm/lang_msg.php");
?>
<table width=100% cellspacing=0 cellpadding=0>
<tr><td colspan=2 height=20 class=title_tb><?=$m_title_comm?></td></tr>
<tr valign="top">
	<td colspan=2 height=30 class=l_tb><?=$m_title_desc_comm?></td>
</tr>
<tr>
<?
if($now_block=="url")
{
	echo "	<td class=l_tb width=25% height=20><input type=radio name=filters checked>".$m_url_blocking."</td>\n";
	echo "	<td class=l_tb height=20><input type=radio name=filters onclick=\"self.location.href='adv_filters_domain.php'\">".$m_domain_blocking."</td>\n";
}
else if($now_block=="domain")
{
	echo "	<td class=l_tb width=25% height=20><input type=radio name=filters onclick=\"self.location.href='adv_filters_url.php'\">".$m_url_blocking."</td>\n";
	echo "	<td class=l_tb height=20><input type=radio name=filters checked>".$m_domain_blocking."</td>\n";
}
?>
</tr>
<tr><td height=10></td></tr>
</table>
