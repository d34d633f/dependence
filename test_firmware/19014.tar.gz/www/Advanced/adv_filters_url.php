<? /* vi: set sw=4 ts=4: */
$MSG_FILE="adv_filters_url.php";



$file_name="adv_filters_url.php";
$apply_name="adv_filters_url.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");

$enable=query("/security/urlblocking/enable");
if($edit_id!="")
{
	$keyword=queryjs("/security/urlblocking/string:".$edit_id);
	$num=$edit_id;
}
?>

<script language="JavaScript">
var enableZ=[<?query("/security/urlblocking/enable");?>];
var nameZ=[""<?
$rule_num=0;
for("/security/urlblocking/string")
{
	$rule_num++;
	echo ",'".queryjs("/security/urlblocking/string:".$@)."'";
}
if($edit_id==""){$num=$rule_num+1;}
?>];

function doReset()
{
	self.location.href="<?=$file_name?>";
}
function EditRow(index)
{
	self.location.href="<?=$file_name?>?edit_id="+index;
}
function doDelete(num)
{
	if (confirm("<?=$m_confirm_delete_message?>")==false) return;
	var f = document.getElementById("frmURL");
	var str=new String("<?=$apply_name?>");
	str+="DEL/SECURITY/URLBLOCKING/STRING:"+num+"=1";
	str+=exeStr("submit COMMIT;submit RG_BLOCKING");
	self.location.href=str;
}
function doSubmit()
{
	var f = document.getElementById("frmURL");
	var str=new String("<?=$apply_name?>");
	var num=parseInt("<?=$num?>", [10]);
	MaxPat=parseInt("<?=$max_pat?>", [10]);
	
	if (num > MaxPat && !isBlank(f.keyword.value))
	{
		alert(<?=$a_exceed_maximum_entry_number_x?>);
		return;
	}
	
	str+="SET/SECURITY/URLBLOCKING/ENABLE="+(f.enable[0].checked? "1":"0");
	
	if (!isBlank(f.keyword.value))
	{
		if(!chk_valid_char(f.keyword.value))
		{
			alert("<?=$a_invalid_url?>");
			f.keyword.select();
			return;
		}
																		
		for(i=0;i<nameZ.length;i++)
		{
			if(nameZ[i]==f.keyword.value && i!=parseInt("<?=$edit_id?>", [10]))
			{
				alert("<?=$a_same_url_entry_exists?>");
				return;
			}
		}
		str+="&SET/SECURITY/URLBLOCKING/STRING:"+num+"="+escape(f.keyword.value);
	}
	
	str+=exeStr("submit COMMIT;submit RG_BLOCKING");
	self.location.href=str;
}

function init()
{
	var f = document.getElementById("frmURL");
	f.keyword.value="<?=$keyword?>";
}

</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload="init()">
<?require("/www/comm/middle.php");?>

<form method=post id=frmURL>
<table width="<?=$width_tb?>" border=0 cellspacing=0 cellpadding=0>
<tr><td colspan=2><?$now_block="url"; require("/www/Advanced/adv_block_comm.php");?></td></tr>
<tr><td colspan=2 class=title_tb><?=$m_title?></td></tr>
<tr valign="top"><td colspan=2 height="30" class=l_tb><?=$m_title_desc?></td></tr>
<tr>
	<td colspan=2 class=l_tb>
	<input type=radio value=1 name=enable checked><?=$m_enabled?>
	<input type=radio value=0 name=enable <?if($enable!="1"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>
<tr><td colspan=2 height=10></td></tr>
<tr>
	<td class=l_tb width=20%><?=$m_url_keyword?></td>
	<td><input type=text name=keyword size=32 maxlength=33></td>
</tr>
<tr>
	<td colspan=5 align=right><script>apply("");cancel("");help("help_adv.php#7_1")</script></td>
</tr>
</table>
<table width="<?=$width_tb?>" border=0 cellspacing=0 cellpadding=0>
<tr>
	<td class=title_tb width=50%><?=$m_url_list?></td>
	<td class=r_tb width=50%>
	<script>print_rule_count("<?=$rule_num?>","<?=$max_pat?>");</script>
	</td>
</tr>
<tr>
	<td colspan=2>
	<table width=100% border=0 cellspacing=0 cellpadding=0 id=url_tb>
	<tr bgcolor=#b7dcfb><td width=3% class=r_tb></td><td width=2%></td><td colspan=2 class=l_tb><?=$m_url_keyword?></td></tr>
<?
for("/security/urlblocking/string")
{
	if($edit_id==$@){echo "<tr bgcolor=".$sel_color.">\n";}
	if($index_en=="1")	{echo "<td width=3% class=r_tb nowrap>".$@.".</td>";}
	else			{echo "<td width=3% class=r_tb nowrap> </td>";}
	echo "<td width=2%></td>";
	echo "<td width=80% class=l_tb><script>echosc(\"".queryjs("/security/urlblocking/string:".$@)."\");</script></td>\n";
	echo "<td width=10% class=r_tb>";
	echo "<a href='javascript:EditRow(".$@.")'><img src='../graphic/edit.gif' width=15 height=17 border=0 alt=edit></a>";
	echo "<a href='javascript:doDelete(".$@.")'><img src='../graphic/delet.gif' width=15 height=18 border=0 alt=delete></a>";
	echo "</td></tr>";
}
?>
	</table>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
