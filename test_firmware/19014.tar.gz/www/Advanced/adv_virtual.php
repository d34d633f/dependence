<?
$apply_name="adv_virtual.xgi?";
$file_name="adv_virtual.php";
$MSG_FILE="adv_virtual.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");

if($edit_id!="")
{
	$num=$edit_id;
	
	anchor("/nat/vrtsrv/entry:".$edit_id);
	$enable=query("enable");
	$name=queryjs("description");
	$ip=query("privateip");
	$protocol=query("protocol");
	$priPort=query("privateport");
	$pubPort=query("publicport");
	$schd=query("schedule/enable");
	$b_time=query("schedule/begintime");
	$e_time=query("schedule/endtime");
	$day1=query("schedule/beginday");
	$day2=query("schedule/endday");
}
?>

<script language="JavaScript">
<?require("/www/comm/select.js");?>
LanIP="<?query("/lan/ethernet/ip");?>";
NetMask="<?query("/lan/ethernet/netmask");?>";
dataLists=[<?
$rule_num=0;
for("/nat/vrtsrv/entry"){$rule_num++;}
for("/nat/vrtsrv/entry")
{
	echo "['".
	query("enable").		"','".queryjs("description").		"','".query("privateip")."','".
	query("protocol").		"','".query("privateport").		"','".query("publicport")."','".
	query("schedule/enable").	"','".query("schedule/begintime").	"','".query("schedule/endtime")."','".
	query("schedule/beginday").	"','".query("schedule/endday").
	"']";
	if($rule_num!=$@){echo ",";}
}
if($edit_id==""){$num=$rule_num+1;}
?>];

function rule_info(){document.write(<?=$rule_num?>+" / "+<?=$max_rule?>+" ( Number / Total )");}
function setSchedule()
{
	var f = document.getElementById("frmVS");
	beginTime=("<?=$b_time?>").split(":");
	f.hour1.selectedIndex = (parseInt(beginTime[0], [10]) >=12? parseInt(beginTime[0], [10])-12:parseInt(beginTime[0], [10]));
	f.min1.selectedIndex = (parseInt(beginTime[1], [10])/5);
	f.am1.selectedIndex = (parseInt(beginTime[0], [10]) >=12? 1:0);
	
	endTime=("<?=$e_time?>").split(":");
	f.hour2.selectedIndex = (parseInt(endTime[0], [10]) >=12? parseInt(endTime[0], [10])-12:parseInt(endTime[0], [10]));
	f.min2.selectedIndex = (parseInt(endTime[1], [10])/5);
	f.am2.selectedIndex = (parseInt(endTime[0], [10]) >=12? 1:0);
	f.day1.selectedIndex=parseInt("<?=$day1?>", [10]);
	f.day2.selectedIndex=parseInt("<?=$day2?>", [10]);
}

function EditRow(r)
{
	self.location.href="<?=$file_name?>?edit_id="+r;
}

function doDelete(num)
{
	if (confirm("<?=$a_sure_want_to_delete?>")==false) return;
	var f = document.getElementById("frmVS");
	var str=new String("<?=$apply_name?>");

	str+="del/nat/vrtsrv/entry:"+num+"=1";
	str+=exeStr("submit COMMIT;submit RG_VSVR");
	self.location.href=str;
}
function doReset()
{
	self.location.href="<?=$file_name?>";
}
function doSubmit()
{
	if (checkParameter()==false) return;
	var f = document.getElementById("frmVS");
	var str=new String("<?=$apply_name?>");
	var num;

	num="<?=$num?>";
	str+="setPath=/nat/vrtsrv/entry:"+num+"/";
	str+="&enable="+(f.enable[0].checked? "1":"0");
	str+="&description="+escape(f.name.value);
	str+="&privateip="+reduceIP(f.ip.value);
	str+="&protocol="+f.protocol.selectedIndex;
	str+="&privatePort="+f.priPort.value;
	str+="&publicPort="+f.pubPort.value;
	str+="&/schedule/enable="+(f.schd[0].checked? "0":"1");

	btime=(f.am1.value==1? parseInt(f.hour1.value, [10])+12 : f.hour1.value)+":"+f.min1.value;
	str+="&/schedule/beginTime="+btime;

	etime=(f.am2.value==1? parseInt(f.hour2.value, [10])+12 : f.hour2.value)+":"+f.min2.value;
	str+="&/schedule/endTime="+etime;

	str+="&/schedule/beginDay="+f.day1.value;
	str+="&/schedule/endDay="+f.day2.value;
	str+="&endSetPath=1";
	str+=exeStr("submit COMMIT;submit RG_VSVR");
	self.location.href=str;
}

function checkParameter()
{
	var f = document.getElementById("frmVS");
	var i=0;
	MaxRule=parseInt("<?=$max_rule?>", [10]);
	if (parseInt("<?=$num?>", [10]) > MaxRule)
	{
		alert("<?=$a_exceed_max_entry_num?> " + MaxRule + "!");
		return false;
	}

	//name
	if (isBlank(f.name.value))
	{
		alert("<?=$a_VS_name_cont_blank?>");
		f.name.focus();
		return false;
	}
	if (f.name.value.charAt(0)==" ")
	{
		alert("<?=$a_first_char_of_input_data_cant_blank?>");
		return false;
	}

	// private ip
	var ip=(f.ip.value).split(".");
	if (ip.length!=4)
	{
		alert("<?=$a_private_ip_you_input_in_a_wrong_ip_format?>");
		f.ip.value="";
		f.ip.focus();
		return false;
	}
	if (!checkIpAddr(f.ip, "<?=$a_invalid_ipaddr?>")) return false;

	if (f.ip.value==LanIP)
	{
		alert('<?=$a_invaild_virtual_server_addr?><?=$a_cant_be_same_with_current_ipaddr?>'+LanIP);
		f.ip.value ="";
		f.ip.focus();
		return false;
	}
	if ( !checkSubnet(f.ip.value, NetMask, LanIP))
	{
		alert('<?=$a_invaild_virtual_server_addr?><?=$a_should_be_located_same_subnet_of_current_ipaddr?>'+LanIP);
		f.ip.value ="";
		f.ip.focus();
		return false;
	}

	if(!checkMaskAddr(f.ip, NetMask, '<?=$a_invalid_ipaddr?>'))	return false;

	// private port
	if (!isNumber(f.priPort.value))
	{
		alert("<?=$a_private_port_should_be_num?> ");
		f.priPort.value="";
		f.priPort.focus();
		return false;
	}
	else
	{
		if (!validPort(f.priPort.value)) return false;
	}

	// public port
	if (!isNumber(f.pubPort.value))
	{
		alert("<?=$a_public_port_should_be_num?> ");
		f.pubPort.value="";
		f.pubPort.focus();
		return false;
	}
	else
	{
		if (!validPort(f.pubPort.value)) return false;
	}

	if(f.enable[1].checked)
		return true;
	if(f.schd[1].checked)
	{
		btime=(f.am1.value*12+parseInt(f.hour1.value, [10]))*60+f.min1.value;
		etime=(f.am2.value*12+parseInt(f.hour2.value, [10]))*60+f.min2.value;
		if(parseInt(btime, [10])>=parseInt(etime, [10]))
		{
			alert("<?=$a_starttime_cant_big_then_end?>");
			f.hour1.focus();
			return false;
		}
	}
	btime=(f.am1.value==1? f.hour1.value+12 : f.hour1.value)+":"+f.min1.value;
	etime=(f.am2.value==1? f.hour2.value+12 : f.hour2.value)+":"+f.min2.value;
	for(i=0;i<dataLists.length;i++)
	{
		if(parseInt("<?=$edit_id?>", [10])==(i+1))	continue;

		if(f.ip.value==dataLists[i][2] && f.protocol.selectedIndex==parseInt(dataLists[i][3], [10]) && f.priPort.value==dataLists[i][4] && f.pubPort.value==dataLists[i][5])
		{
			if((f.schd[1].checked && dataLists[i][6]=="1" && btime==dataLists[i][7] && etime==dataLists[i][8] && f.day1.selectedIndex==dataLists[i][9] && f.day2.selectedIndex==dataLists[i][10]) ||
				(f.schd[0].checked && dataLists[i][6]=="0"))
			{
				alert("<?=$a_entry_with_same_settings?>");
				f.ip.focus();
				return false;
			}
		}
	}

	for(i=0;i<dataLists.length;i++)
	{
		if(parseInt("<?=$edit_id?>", [10])==(i+1))	continue;
		if(dataLists[i][0]=="1" &&  f.protocol.selectedIndex==parseInt(dataLists[i][3], [10]) && f.pubPort.value==dataLists[i][5])
		{
			alert("<?=$a_entry_with_the_same_public_port?>");
			f.pubPort.focus();
			return false;
		}
	}

	return true;
}
function print_pro(n)
{
	selList=["Both","TCP","UDP"];
	str="";
	str+="<select name="+n+" size=1>";
	for(i=0;i<selList.length;i++)
	{
		str+="<option value="+i;
		if(i==parseInt("<?=$protocol?>", [10]))	str+=" selected";
		str+=">"+selList[i]+"</option>";
	}
	str+="</select>";
	document.write(str);
}
function init()
{
	var f = document.getElementById("frmVS");
<?
if ($edit_id=="")
{
	echo "	f.protocol.selectedIndex=1;\n";
}
else
{
	echo "	f.name.value=\"".$name."\";\n";
}
?>
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload=init()>
<?require("/www/comm/middle.php");?>
<form action=vs.cgi method=post id=frmVS>
<input type=hidden name=editRow value=-1>
<table width=<?=$width_tb?> border=0 cellspacing=2 cellpadding=0 height=30>
<tr>
	<td colspan=2 height="20" class=title_tb><?=$m_virtual_server?></td>
</tr>
<tr valign="top">
	<td colspan=2 height="30" class=l_tb><?=$m_virtual_server_allow_user_access_lan_service?></td>
</tr>
<tr>
	<td width=18%></td>
	<td width=82% height=11 class=l_tb>
		<input type=radio name=enable value=1 checked><?=$m_enabled?>
		<input type=radio name=enable value=0 <?if($enable!="1"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>
<tr>
	<td class=l_tb><?=$m_name?></td>
	<td height=12><input type=text name=name size=32 maxlength=31></td>
</tr>
<tr>
	<td class=l_tb><?=$m_private_ip?>&nbsp;</td>
	<td height=25><input type=text name=ip size=15 maxlength=15 value="<?=$ip?>"></td>
</tr>
<tr>
	<td class=l_tb><?=$m_protocol?>&nbsp;</td>
	<td height=25><script>print_pro("protocol");</script></td>
</tr>
<tr>
	<td height=2 class=l_tb><?=$m_priv_port?>&nbsp;</td>
	<td height=25><input type=text name=priPort size=5 maxlength=5 value="<?=$priPort?>"></td>
</tr>
<tr>
	<td height=28 align=left><?=$m_pub_port?>&nbsp;</td>
	<td height=25><input type=text name=pubPort size=5 maxlength=5 value="<?=$pubPort?>"></td>
</tr>
<?require("/www/locale/".$__LANG."/schedule.php");?>
<tr>
	<td height=10></td>
</tr>
<tr>
	<td colspan=2 align=right><script language="JavaScript">apply(""); cancel("");help("help_adv.php#05");</script></td>
</tr>
<tr>
	<td colspan=2><table width=100%><tr>
		<td width=50% class=title_tb><?=$m_virtual_server_list?></td>
		<td class=r_tb><script>print_rule_count("<?=$rule_num?>","<?=$max_rule?>");</script></td>
	</tr></table></td>
</tr>
<tr>
	<td colspan=2>
	<table width=100% border=0 id=tabVS cellpadding=0 cellspacing=0>
	<tr bgcolor=#B7DCFB>
		<td width=3%>&nbsp;</td>
		<td class=l_tb width=30%><?=$m_name?></td>	<td class=l_tb width=24%><?=$m_private_ip?></td>
		<td class=l_tb width=25%><?=$m_proto?></td>	<td class=l_tb width=8%><?=$m_schedule?></td>
		<td width=10%>&nbsp;</td>
	</tr>
<?
for("/nat/vrtsrv/entry")
{
	if($edit_id==$@){echo " <tr bgcolor=".$sel_color.">\n";}
        else		{echo " <tr>\n";}
	if($index_en=="1")	{echo "		<td class=r_tb nowrap>".$@.".<input type='checkbox' name='en' ";}
	else			{echo "		<td class=r_tb nowrap><input type='checkbox' name='en' ";}
	map("enable", "1","checked ", *,"");
	echo "disabled></td>\n";
	echo "		<td class=l_tb style='word-break:break-all'><script>echosc(\"".queryjs("description")."\");</script></td>\n";
	echo "		<td class=l_tb style='word-break:break-all'>".query("privateip")."</td>\n";
	echo "		<td class=l_tb style='word-break:break-all'>";
	map("protocol", "1","TCP ", "2","UDP ", *,"Both ");
	echo query("privateport")."/".query("publicport")."</td>";
	echo "		<td class=l_tb>";
	if(query("schedule/enable")!="1"){echo "Always";}
	else
	{
		echo query("schedule/begintime")."~".query("schedule/endtime").", ";
		map("schedule/beginday","0","Sun","1","Mon","2","Tue","3","Wed","4","Thu","5","Fri","6","Sat");
		echo "~";
		map("schedule/endday","0","Sun","1","Mon","2","Tue","3","Wed","4","Thu","5","Fri","6","Sat");
		echo "</td>\n";
	}
	echo "		<td class=r_tb>\n";
	echo "		<a href='javascript:EditRow(".$@.")'><img src='../graphic/edit.gif' width=15 height=17 border=0 alt=edit></a>";
	echo "		<a href='javascript:doDelete(".$@.")'><img src='../graphic/delet.gif' width=15 height=18 border=0 alt=delete></a>";
	echo "		</td>\n";
	echo "	</tr>\n";
}
?>
	</table>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
