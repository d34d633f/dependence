<?
$MSG_FILE="adv_perform_11g.php";
del("/tmp/wireless");
$file_name="adv_perform_11g.php";
$apply_name="adv_perform_11g.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
anchor("/wireless");
$tx_rate=query("txrate");
$power=query("txPower");
$wecaBI=query("beaconInterval");
$wecaRTS=query("rtsLength");
$wecaFrag=query("fragLength");
$wecaDtiminterval=query("dtim");
$wecaShortPreamble=query("preamble");
//$ssidHidden=query("ssidHidden");
//$x11gOnly=query("wlmode");
$cts=query("ctsmode");
//$super=query("supergmode");
$wmm=query("WMM/enable");
?>

<script language="JavaScript">
function doSubmit()
{
	if (checkParameter()==false) return;
	var f = document.getElementById("adv_perform_11g");
	var str=new String("<?=$apply_name?>");
	var c=0;
	var cts_mode=0;
	var i=0;

	str+="setPath=/WIRELESS/";
	str+="&txrate="+f.tx_rate.value;
	if(f.cts[0].checked)		cts_mode=0;
	else if(f.cts[1].checked)	cts_mode=1;
	else if(f.cts[2].checked)	cts_mode=2;
	str+="&ctsmode="+cts_mode;
//	str+="&supergmode="+parseInt(f.supergmode.selectedIndex, [10]);
	str+="&TXPOWER="+parseInt(f.power.selectedIndex+1, [10]);
	str+="&BEACONINTERVAL="+f.wecaBI.value;
	str+="&RTSLENGTH="+f.wecaRTS.value;
	str+="&FRAGLENGTH="+f.wecaFrag.value;
	str+="&DTIM="+f.wecaDtiminterval.value;
//	str+="&PREAMBLE="+(f.wecaShortPreamble[0].checked? "1":"2");
//	str+="&SSIDHIDDEN="+(f.ssidBroadcast[1].checked? "1":"0");
//	str+="&WLMODE="+(f.x11gOnly[0].checked? "2":"1"); 
	str+="&WMM/enable="+(f.wmm_enable[1].checked? "1":"0");
	str+="&endSetPath=1";
/*	str+="&setPath=/WIRELESS/WMM/AP/";
	for (i=0; i<4; i++) {
		str+="&entry:"+(i+1)+"/CWMin="+(f.wmmap_cwmin[i].value);
		str+="&entry:"+(i+1)+"/CWMax="+(f.wmmap_cwmax[i].value);
		str+="&entry:"+(i+1)+"/AIFS="+(f.wmmap_aifs[i].value);
		str+="&entry:"+(i+1)+"/TxopLimit="+(f.wmmap_txoplimit[i].value);
		str+="&entry:"+(i+1)+"/ACM="+(f.wmmap_acm[i].checked? "1":"0");
		str+="&entry:"+(i+1)+"/Ackpolicy="+(f.wmmap_ackpolicy[i].checked? "1":"0");
	}
	str+="&endSetPath=1";
	str+="&setPath=/WIRELESS/WMM/STA/";
	for (i=0; i<4; i++) {
		str+="&entry:"+(i+1)+"/CWMin="+(f.wmmsta_cwmin[i].value);
		str+="&entry:"+(i+1)+"/CWMax="+(f.wmmsta_cwmax[i].value);
		str+="&entry:"+(i+1)+"/AIFS="+(f.wmmsta_aifs[i].value);
		str+="&entry:"+(i+1)+"/TxopLimit="+(f.wmmsta_txoplimit[i].value);
		str+="&entry:"+(i+1)+"/ACM="+(f.wmmsta_acm[i].checked? "1":"0");
	}
*/
	str+="&endSetPath=1";
	str+=exeStr("submit COMMIT;submit WLAN");
//alert(str);
	self.location.href=str;
}

function doReset()
{
	self.location.href="<?=$file_name?>";
}

function checkParameter()
{
	var f = document.getElementById("adv_perform_11g");

	//beacon Interval
	var b=f.wecaBI.value;
	if (isNumber(b))
	{
		if (parseInt(b, [10]) < 20 || parseInt(b, [10]) > 1000)
		{
			alert("<?=$a_beacon_interval_between_20_1000?>\n");
			f.wecaBI.value="";
			f.wecaBI.focus();
			return false;
		}
	}
	else
	{
		alert("<?=$a_beacon_interval_input_not_number?>\n");
		f.wecaBI.value="";
		f.wecaBI.focus();
		return false;
	}

	//RTS Threshold
	var r=f.wecaRTS.value;
	if (isNumber(r))
	{
		if (parseInt(r, [10]) < 1 || parseInt(r, [10]) > 2346)
		{
			alert("<?=$a_rts_threshold_between_1_2346?>\n");
			f.wecaRTS.value="";
			f.wecaRTS.focus();
			return false;
		}
	}
	else
	{
		alert("<?=$a_rts_thresshold_input_not_number?>\n");
		f.wecaRTS.value="";
		f.wecaRTS.focus();
		return false;
	}

	//Fragmentation
	var fr=f.wecaFrag.value;
	if (isNumber(fr))
	{
		if (parseInt(fr, [10]) < 256 || parseInt(fr, [10]) > 2346 || (parseInt(fr, [10]) % 2)==1)
		{
			alert("<?=$a_fragmentation_between_256_number_only?>\n");
			f.wecaFrag.value="";
			f.wecaFrag.focus();
			return false;
		}
	}
	else
	{
		alert("<?=$a_fragmentation_input_not_number?>\n");
		f.wecaFrag.value="";
		f.wecaFrag.focus();
		return false;
	}

	//DTIM interval
	var d=f.wecaDtiminterval.value;
	if (isNumber(d))
	{
		if (parseInt(d, [10]) < 1 || parseInt(d, [10]) > 255)
		{
			alert("<?=$a_dtim_interval_between_1_255?>\n");
			f.wecaDtiminterval.value="";
			f.wecaDtiminterval.focus();
			return false;
		}
	}
	else
	{
		alert("<?=$a_dtim_interval_input_not_number?>\n");
		f.wecaDtiminterval.value="";
		f.wecaDtiminterval.focus();
		return false;
	}

/*	//WMM Parameters
	var i;
	for (i=0; i<4; i++) {
		if(f.wmmap_cwmin[i].value=="" || 
		   f.wmmap_cwmax[i].value=="" ||
		   f.wmmap_aifs[i].value=="" ||
		   f.wmmap_txoplimit[i].value=="" ||
		   f.wmmsta_cwmin[i].value=="" ||
		   f.wmmsta_cwmax[i].value=="" ||
		   f.wmmsta_aifs[i].value=="" ||
		   f.wmmsta_txoplimit[i].value=="") {
			alert("<?=$a_wmm_parameter_empty?>\n");
			return false;
		}
		if(!(isNumber(f.wmmap_cwmin[i].value) && 
		     isNumber(f.wmmap_cwmax[i].value) &&
		     isNumber(f.wmmap_aifs[i].value) && 
		     isNumber(f.wmmap_txoplimit[i].value) && 
		     isNumber(f.wmmsta_cwmin[i].value) && 
		     isNumber(f.wmmsta_cwmax[i].value) && 
		     isNumber(f.wmmsta_aifs[i].value) && 
		     isNumber(f.wmmsta_txoplimit[i].value))) {
			alert("<?=$a_wmm_parameter_should_number?>WMM parameters should be positive number!\n");
			return false;
		}
	}
*/
	return true;
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<?require("/www/comm/middle.php");?>
<form id="adv_perform_11g" method="post">
<table width="<?=$width_tb?>" border="0">
<tr>
	<td colspan=2 height="10" class=title_tb><?=$m_wireless_perdormance?></td>
</tr>
<tr valign="top">
	<td colspan="2" height="30" class=l_tb>
	<?=$m_wireless_performance_features?>
	</td>
</tr>
<tr>
	<td class=r_tb width=30%><?=$m_tx_rate?></td>
	<td class=l_tb width=70%>
	<select name="tx_rate">
		<option value="0" <?if($tx_rate=="0"){echo "selected";}?>><?=$m_auto?></option>
		<option value="1" <?if($tx_rate=="1"){echo "selected";}?>>1</option>
		<option value="2" <?if($tx_rate=="2"){echo "selected";}?>>2</option>
		<option value="5.5" <?if($tx_rate=="5.5"){echo "selected";}?>>5.5</option>
		<option value="6" <?if($tx_rate=="6"){echo "selected";}?>>6</option>
		<option value="9" <?if($tx_rate=="9"){echo "selected";}?>>9</option>
		<option value="11" <?if($tx_rate=="11"){echo "selected";}?>>11</option>
		<option value="12" <?if($tx_rate=="12"){echo "selected";}?>>12</option>
		<option value="18" <?if($tx_rate=="18"){echo "selected";}?>>18</option>
		<option value="24" <?if($tx_rate=="24"){echo "selected";}?>>24</option>
		<option value="36" <?if($tx_rate=="36"){echo "selected";}?>>36</option>
		<option value="48" <?if($tx_rate=="48"){echo "selected";}?>>48</option>
		<option value="54" <?if($tx_rate=="54"){echo "selected";}?>>54</option>
	</select>
	<?=$m_Mbps?>
	</td>
</tr>

<tr>
	<td class=r_tb><?=$m_transmit_power?></td>
	<td>
	<select name="power">
		<option value="1" <?if($power=="1"){echo "selected";}?>>100%</option>
		<option value="2" <?if($power=="2"){echo "selected";}?>>50%</option>
		<option value="3" <?if($power=="3"){echo "selected";}?>>25%</option>
		<option value="4" <?if($power=="4"){echo "selected";}?>>12.5%</option>
	</select>
	</td>
</tr>
<tr>
	<td class=r_tb><?=$m_beacon_interval?></td>
	<td class=l_tb><input maxlength=4 name=wecaBI size=4 value="<?=$wecaBI?>"><?=$m_msec_range_de100?></td>
</tr>
<tr>
	<td class=r_tb><?=$m_RTS_threshold?></td>
	<td class=l_tb><input maxlength=4 name=wecaRTS size=4 value="<?=$wecaRTS?>"><?=$?><?=$m_range_1_2346_de2346?></td>
</tr>
<tr>
	<td class=r_tb><?=$m_fragmentation?></td>
	<td class=l_tb><input maxlength=4 name=wecaFrag size=4 value="<?=$wecaFrag?>"><?=$m_range_256_2346_de2346?></td>
</tr>
<tr>
	<td class=r_tb><?=$m_dtim_interval?></td>
	<td class=l_tb><input maxlength=5 name=wecaDtiminterval size=4 value="<?=$wecaDtiminterval?>"><?=$m_range_1_255_de1?></td>
</tr>
<!--
<tr>
	<td class=r_tb><?=$m_preamble_type?></td>
	<td class=l_tb>
	<input name=wecaShortPreamble type=radio value=1 checked><?=$m_short_preamble?>
	<input name=wecaShortPreamble type=radio value=0 <?if($wecaShortPreamble!="1"){echo "checked";}?>><?=$m_long_preamble?>
	</td>
</tr>
<tr>
	<td class=r_tb>SSID Broadcast :</td>
	<td class=l_tb>
	<input name=ssidBroadcast type=radio value=1 checked>Enabled
	<input name=ssidBroadcast type=radio value=0 <?if($ssidHidden=="1"){echo "checked";}?>>Disabled
	</td>
</tr>
<tr>
	<td class=r_tb>802.11g Only Mode :</td>
	<td class=l_tb>
	<input name=x11gOnly type=radio value=1 checked>Enabled
	<input name=x11gOnly type=radio value=0 <?if($x11gOnly=="1"){echo "checked";}?>>Disabled
	</td>
</tr>
-->
<tr>
	<td class=r_tb><?=$m_cts_mode?></td>
	<td class=l_tb>
	<input name=cts type=radio value=0 <?if($cts=="0"){echo "checked";}?>><?=$m_none?>
	<input name=cts type=radio value=1 <?if($cts=="1"){echo "checked";}?>><?=$m_always?>
	<input name=cts type=radio value=2 <?if($cts=="2"){echo "checked";}?>><?=$m_auto?>
	</td>
</tr>
<!-- 
<tr>
	<td class=r_tb>Super G Mode :</td>
	<td>
	<select name="supergmode">
		<option value="0" <?if($super=="0"){echo "selected";}?>>Disabled</option>
		<option value="1" <?if($super=="1"){echo "selected";}?>>Super G without Turbo</option>
		<option value="2" <?if($super=="2"){echo "selected";}?>>Super G with Dynamic Turbo</option>
		<option value="3" <?if($super=="3"){echo "selected";}?>>Super G with Static Turbo</option>
	</select>
	</td>
</tr>
-->
<tr>
	<td class=r_tb><?=$m_WMM_function?></td>
	<td class=l_tb>
	<input name=wmm_enable type=radio value=0 <?if($wmm!="1"){echo "checked";}?>><?=$m_disabled?>
	<input name=wmm_enable type=radio value=1 <?if($wmm=="1"){echo "checked";}?>><?=$m_enabled?>
	</td>
</tr>
<tr><td>&nbsp;</td></tr>
<!--tr>
	<tr><td colspan=2><?=$m_wan_parameters_AP?></td></tr>
	<td colspan=2>
	<table><tr>
	<td width=14% class=c_tb><?=$m_access_type?></td>
	<td width=14% class=c_tb><?=$m_CWMin?></td>
	<td width=14% class=c_tb><?=$m_CWMax?></td>
	<td width=14% class=c_tb><?=$m_AIFS?></td>
	<td width=14% class=c_tb><?=$m_TxopLimit?></td>
	<td width=14% class=c_tb><?=$m_ACM?></td>
	<td width=14% class=c_tb><?=$m_Ack_policy?></td>
<?
for("/wireless/wmm/ap/entry") {
	echo "<tr>\n";
	echo "<td class=c_tb>".query("name")."</td>\n";
	echo "<td class=c_tb><input name=wmmap_cwmin size=6 value=".query("CWMin")."></td>\n";
	echo "<td class=c_tb><input name=wmmap_cwmax size=6 value=".query("CWMax")."></td>\n";
	echo "<td class=c_tb><input name=wmmap_aifs size=6 value=".query("AIFS")."></td>\n";
	echo "<td class=c_tb><input name=wmmap_txoplimit size=6 value=".query("TxopLimit")."></td>\n";
	echo "<td class=c_tb><input name=wmmap_acm type=checkbox";
	map("ACM","1"," checked","*","");
	echo "></td>\n";
	echo "<td class=c_tb><input name=wmmap_ackpolicy type=checkbox";
	map("ackpolicy","1"," checked","*","");
	echo "></td>\n";
	echo "</tr>\n";
}
?>	
	</tr>
	</table>
	</td>
</tr>
<tr>
	<tr><td colspan=2><?=$m_WMM_parameters_STA?></td></tr>
	<td colspan=2>
	<table><tr>
	<td width=14% class=c_tb><?=$m_access_type?></td>
	<td width=14% class=c_tb><?=$m_CWMin?></td>
	<td width=14% class=c_tb><?=$m_CWMax?></td>
	<td width=14% class=c_tb><?=$m_AIFS?></td>
	<td width=14% class=c_tb><?=$m_TxopLimit?></td>
	<td width=14% class=c_tb><?=$m_ACM?></td>
	<td width=14% class=c_tb>&nbsp;</td>
<?
for("/wireless/wmm/sta/entry") {
	echo "<tr>\n";
	echo "<td class=c_tb>".query("name")."</td>\n";
	echo "<td class=c_tb><input name=wmmsta_cwmin size=6 value=".query("CWMin")."></td>\n";
	echo "<td class=c_tb><input name=wmmsta_cwmax size=6 value=".query("CWMax")."></td>\n";
	echo "<td class=c_tb><input name=wmmsta_aifs size=6 value=".query("AIFS")."></td>\n";
	echo "<td class=c_tb><input name=wmmsta_txoplimit size=6 value=".query("TxopLimit")."></td>\n";
	echo "<td class=c_tb><input name=wmmsta_acm type=checkbox";
	map("ACM","1"," checked","*","");
	echo "></td>\n";
	echo "</tr>\n";
}
?>	
	</tr>
	</table>
	</td>
</tr-->
<tr>
	<td colspan=2 align=right>
	<script language="JavaScript">apply(""); cancel("");help("help_adv.php#11");</script>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
