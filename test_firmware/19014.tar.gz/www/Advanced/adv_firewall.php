<?
$file_name="adv_firewall.php";
$apply_name="adv_firewall.xgi?";

$MSG_FILE="adv_firewall.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");

$deny_msg="<font color=red>".$m_deny."</font>";
$allow_msg="<font color=blue>".$m_allow."</font>";
$schd=0;

if($edit_id!="")
{
	$num=$edit_id;

	anchor("/security/di624/firewall/entry:".$edit_id);
	$enable=query("enable");
	$name=queryjs("description");
	$action=query("action");
	$srcIface=query("sourceinf");
	$srcIP1=query("sourceipbegin");
	$srcIP2=query("sourceipend");
	$dstIface=query("destInf");
	$dstIP1=query("destipbegin");
	$dstIP2=query("destipend");
	$proto=query("protocol");
	$port1=query("destportbegin");
	$port2=query("destportend");
	$schd=query("schedule/enable");
	$b_time=query("schedule/begintime");
	$e_time=query("schedule/endtime");
	$day1=query("schedule/beginday");
	$day2=query("schedule/endday");
}
?>

<script language="JavaScript">
<?require("/www/comm/select.js");?>
dList=[['0','','','','','','','','','','','','','','','','','','','','']<?
$rule_num=0;
for("/security/di624/firewall/entry"){$rule_num++;}
for("/security/di624/firewall/entry")
{
	echo ",\n	['".$@."','".
	query("enable").		"','".queryjs("description").		"','".query("action")."','".
	query("sourceinf").		"','".query("sourceipbegin").		"','".query("sourceipend")."','".
	query("destInf").		"','".query("destipbegin").		"','".query("destipend")."','".
	query("protocol").		"','".query("destportbegin").		"','".query("destportend")."','".
	query("schedule/enable").	"','".query("schedule/begintime").	"','".query("schedule/endtime")."','".
	query("schedule/beginday").	"','".query("schedule/endday").		"','".query("sourceiprangetype")."','".
	query("destiprangetype").	"','".query("destportrangetype").
	"']";
}
if($edit_id==""){$num=$rule_num+1;}
?>];

var SrcIpRangeType, DstIpRangeType, DstPortRangeType;

function CheckField(proto)
{
	var f=document.getElementById("frmRule");
	var bPort=false;
	if(proto=="4" || proto=="1")
	{
		bPort=true;
		f.port1.value="";
		f.port2.value="";
	}
	f.port1.disabled=bPort;
	f.port2.disabled=bPort;
}

function CheckProtField()
{
	var f=document.getElementById("frmRule");
	var bPort=false;
	if(f.proto.value=="4" || f.proto.value=="1")
	{
		bPort=true;
		f.port1.value="";
		f.port2.value="";
	}
	f.port1.disabled=bPort;
	f.port2.disabled=bPort;
}

function editRow(r)
{
//	self.location.href="<?=$file_name?>?edit_id="+r;	
	self.location.href="<?=$apply_name?>edit_id="+r;	
}

function setSchedule()
{
	var f = document.getElementById("frmRule");
	beginTime=("<?=$b_time?>").split(":");
	f.hour1.selectedIndex = (parseInt(beginTime[0], [10]) >=12? parseInt(beginTime[0], [10])-12:parseInt(beginTime[0], [10]));
	f.min1.selectedIndex = (parseInt(beginTime[1], [10])/5);
	f.am1.selectedIndex = (parseInt(beginTime[0], [10]) >=12? 1:0);
	endTime=("<?=$e_time?>").split(":");
	f.hour2.selectedIndex = (parseInt(endTime[0], [10]) >=12? parseInt(endTime[0], [10])-12:parseInt(endTime[0], [10]));
	f.min2.selectedIndex = (parseInt(endTime[1], [10])/5);
	f.am2.selectedIndex = (parseInt(endTime[0], [10]) >=12? 1:0);
	f.day1.selectedIndex=parseInt("<?=$day1?>", [10]);
	f.day2.selectedIndex=parseInt("<?=$day2?>", [10]);
}
function cp(s,d,oder)
{
	if(oder==1)	str="";
	else		str="&";
	str+="setPath=/security/di624/firewall/entry:"+d+"/";
	str+="&enable="+dList[s][1];
	str+="&description="+dList[s][2];
	str+="&action="+dList[s][3];
	str+="&sourceInf="+dList[s][4];
	str+="&sourceIPbegin="+dList[s][5];
	str+="&sourceIPend="+dList[s][6];
	str+="&destInf="+dList[s][7];
	str+="&destIPbegin="+dList[s][8];
	str+="&destIPend="+dList[s][9];
	str+="&protocol="+dList[s][10];
	str+="&destPortbegin="+dList[s][11];
	str+="&destPortend="+dList[s][12];
	str+="&schedule/enable="+dList[s][13];
	str+="&schedule/beginTime="+dList[s][14];
	str+="&schedule/endTime="+dList[s][15];
	str+="&schedule/beginDay="+dList[s][16];
	str+="&schedule/endDay="+dList[s][17];
	str+="&sourceIpRangeType="+dList[s][18];
	str+="&destIpRangeType="+dList[s][19];
	str+="&destPortRangeType="+dList[s][20];
	str+="&endSetPath=1";
	return str;
}

function chgPri(s,d)
{
	var f = document.getElementById("frmRule");

	var str=new String("<?=$apply_name?>");
	
	str+=cp(s,d,1);
	str+=cp(d,s,0);
	
	str+=exeStr("submit COMMIT;submit RG_FIREWALL");
	self.location.href=str;
}

function doReset()
{
	self.location.href="<?=$file_name?>";
}

function doDelete(index)
{
	if (confirm("<?=$a_sure_to_delete_this?>")==false) return;
	var f = document.getElementById("frmRule");
	var str=new String("<?=$apply_name?>");

	str+="DEL/security/di624/firewall/entry:"+index+"=1";
	str+=exeStr("submit COMMIT;submit RG_FIREWALL");
	self.location.href=str;
}

function doSubmit()
{

	if (checkParameter()==false) return;
	var f = document.getElementById("frmRule");
	var str=new String("<?=$apply_name?>");
	var num,btime,etime;
	
	num="<?=$num?>";
	str+="setPath=/security/di624/firewall/entry:"+num+"/";
	str+="&enable="+(f.enable[1].checked? "0":"1");
	
	str+="&description="+escape(f.name.value);
	str+="&action="+(f.action[1].checked? "2":"1");
	str+="&sourceIPbegin="+(f.srcIP1.value==""? "":reduceIP(f.srcIP1.value));
	str+="&sourceIPend="+(f.srcIP2.value==""? "":reduceIP(f.srcIP2.value));
	str+="&sourceInf="+f.srcIface[f.srcIface.selectedIndex].value;
	str+="&sourceIpRangeType="+SrcIpRangeType;
	str+="&destIPbegin="+(f.dstIP1.value==""? "":reduceIP(f.dstIP1.value));
	str+="&destIPend="+(f.dstIP2.value==""? "":reduceIP(f.dstIP2.value));
	str+="&destInf="+f.dstIface[f.dstIface.selectedIndex].value;
	str+="&destIpRangeType="+DstIpRangeType;
	str+="&destPortbegin="+(f.port1.value==""? "":f.port1.value);
	str+="&destPortend="+(f.port2.value==""? "":f.port2.value);
	str+="&destPortRangeType="+DstPortRangeType;
	str+="&protocol="+f.proto[f.proto.selectedIndex].value;
	str+="&schedule/enable="+(f.schd[1].checked? "1":"0");

	if (f.schd[1].checked)
	{
		btime=(f.am1.value==1? parseInt(f.hour1.value, [10])+12 : f.hour1.value)+":"+f.min1.value;
		str+="&schedule/beginTime="+btime;
		etime=(f.am2.value==1? parseInt(f.hour2.value, [10])+12 : f.hour2.value)+":"+f.min2.value;
		str+="&schedule/endTime="+etime;
		str+="&schedule/beginDay="+f.day1.selectedIndex;
		str+="&schedule/endDay="+f.day2.selectedIndex;
	}

	str+="&endSetPath=1";
	
	str+=exeStr("submit COMMIT;submit RG_FIREWALL");
	self.location.href=str;
}

function checkParameter()
{
	var f = document.getElementById("frmRule");
	MaxRule=parseInt("<?=$max_rule?>", [10]);

	if (parseInt("<?=$num?>", [10]) > MaxRule)
	{
		alert(<?=$a_exceed_max_count?>);
		return false;
	}

	if(f.dstIface.value==f.srcIface.value && f.dstIface.value!=0)
	{
		alert('<?=$a_same_dir_not_support?>');
		return false;
	}

	//name
	if (isBlank(f.name.value))
	{
		alert("<?=$a_fw_name_cant_be_empty?>");
		f.name.focus();
		return false;
	}
	SrcIpRangeType=3;
	DstIpRangeType=3;
	DstPortRangeType=3;

	// source ip start
	if(f.srcIP1.value==f.srcIP2.value)
		f.srcIP2.value="";

	if(f.srcIP2.value=="")	SrcIpRangeType=2;

	if(f.srcIP1.value=="*")
	{
		SrcIpRangeType=1;
		f.srcIP2.value="";
	}
	else if(!checkIpAddr(f.srcIP1, "<?=$a_invalid_src_start_ip?>"))
		return false;

	// source ip end
	if(f.srcIP2.value!="" && !checkIpAddr(f.srcIP2, "<?=$a_invalid_src_end_ip?>"))
		return false;

	// destination start ip
	if(f.dstIP1.value==f.dstIP2.value) f.dstIP2.value="";
	if(f.dstIP2.value=="") DstIpRangeType=2;
	if(f.dstIP1.value=="*")
	{
		f.dstIP2.value="";
		DstIpRangeType=1;
	}
	else if(!checkIpAddr(f.dstIP1, "<?=$a_invalid_dest_start_ip?>"))
		return false;

	// destination end ip
	if (f.dstIP2.value!="" && !checkIpAddr(f.dstIP2, "<?=$a_invalid_dest_end_ip?>"))
		return false;
	// check if source start ip bigger than end ip.
	if(f.srcIP2.value!="")
	{
		for (var i=1;i<5;i++)
		{
			if (getDigit(f.srcIP2.value,i) < getDigit(f.srcIP1.value,i))
			{
				alert("<?=$a_src_start_gt_src_end?>");
				f.srcIP1.value="";
				f.srcIP1.focus();
				return false;
			}
			else if (getDigit(f.srcIP2.value,i) > getDigit(f.srcIP1.value, i))
			{
				i=5;
			}
		}
	}
	// check if destination start ip bigger than end ip.
	if(f.dstIP2.value!="")
	{
		for (var i=1;i<5;i++)
		{
			if (getDigit(f.dstIP2.value,i) < getDigit(f.dstIP1.value,i))
			{
				alert("<?=$a_dest_start_gt_dest_end?>");
				f.dstIP1.value="";
				f.dstIP1.focus();
				return false;
			}
			else if (getDigit(f.dstIP2.value,i) > getDigit(f.dstIP1.value, i))
			{
				i=5;
			}
		}
	}

	if(f.proto.value!="4" && f.proto.value!="1")
	{
		// starting port
		if(f.port1.value==f.port2.value) f.port2.value="";
		if(f.port2.value=="") DstPortRangeType=2;
		if(f.port1.value=="*")
		{
			DstPortRangeType=1;
			f.port2.value="";
		}
		else if (!isNumber(f.port1.value))
		{
			alert("<?=$a_port_start_should_be_num?>");
			f.port1.value="";
			f.port1.focus();
			return false;
		}
		else
		{
			if (!validPort(f.port1.value)) return false;
		}

		// ending port
		if (!isBlank(f.port2.value))
		{
			if (!isNumber(f.port2.value))
			{
				alert("<?=$a_port_end_should_be_num?>");
				f.port2.value="";
				f.port2.focus();
				return false;
			}
			else
			{
				if (!validPort(f.port2.value)) return false;
			}
		}

		// if starting port is bigger than ending port ?
		if (isNumber(f.port1.value) && isNumber(f.port2.value))
		{
			if (parseInt(f.port1.value, [10]) > parseInt(f.port2.value, [10]))
			{
				alert("<?=$a_start_port_gt_end_port?>");
				f.port1.focus();
				return false;
			}
		}
	}
	if(f.enable[1].checked)
		return true;

	if(f.schd[1].checked)
	{
		btime=(f.am1.value*12+parseInt(f.hour1.value, [10]))*60+f.min1.value;
		etime=(f.am2.value*12+parseInt(f.hour2.value, [10]))*60+f.min2.value;
		if(parseInt(btime, [10])>=parseInt(etime, [10]))
		{
			alert("<?=$a_starttime_cant_big_then_end?>");
			f.hour1.focus();
			return false;
		}
	}
	btime=(f.am1.value==1? f.hour1.value+12 : f.hour1.value)+":"+f.min1.value;
	etime=(f.am2.value==1? f.hour2.value+12 : f.hour2.value)+":"+f.min2.value;
	return true;
}
function print_inf(n,v)
{
	infList=["<?=$m_any?>","LAN","WAN"];
	str="<select name="+n+" size=1>";
	for(i=0;i<infList.length;i++)
	{
		str+="<option value="+i;
		if(i == parseInt(v, [10]))str+=" selected";
		str+=">"+infList[i]+"</option>";
	}
	str+="</select>";
	document.write(str);
}
function print_pro(n,v,s)
{
	proList=["","<?=$m_all?>","TCP","UDP","ICMP"];
	str="<select name="+n+" size=1";
	if(s!="")	str+=" onchange='"+s+"'";
	str+=">";
	for(i=1;i<proList.length;i++)
	{
		str+="<option value="+i;
		if(i==parseInt(v, [10])) str+=" selected";
		str+=">"+proList[i]+"</option>"
	}
	str+="</select>";
	document.write(str);
}
function format_str_by_field(str, llimit)
{
	if(llimit=="") llimit=1;
	var nstr=new String("");
	var tmp=new String("");
	var i, j=0, off=0;
	for (i=0; i<str.length; i++) {
		tmp=str.slice(i,i+1);
		if (tmp==' ') {
			nstr+=str.slice(j,i);	
			j=i;
		}
		if ((i-j) >= llimit) {
			nstr+=str.slice(j,i);
			nstr+="<br>";
			j=i;
		}
			
	}
	if (j!=i) {
		nstr+=str.slice(j, i);
	}

	document.write(nstr);
}
function init()
{
	var f = document.getElementById("frmRule");
<?
if($edit_id=="")
{
	// the default value of srcIface is "LAN"
	echo "	f.srcIface.selectedIndex=1;\n";
	// the default value of dstIface is "WAN"
	echo "	f.dstIface.selectedIndex=2;\n";
	// the default value of protocol is "TCP"
	echo "	f.proto.selectedIndex=1;\n";
	echo "	CheckField(\"".$proto."\");\n";
}
else
{
	echo "	f.name.value=\"".$name."\";\n";
}
?>	
}
</SCRIPT>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload="init()">
<?require("/www/comm/middle.php");?>
<form method="post" id="frmRule">
<table width="<?=$width_tb?>" border="0" cellpadding="0">
<tr>
	<td colspan="2" class=title_tb><?=$m_fw_title?></td>
</tr>
<tr valign="top">
	<td colspan="2" height="30" class=l_tb><?=$m_fw_description?></td>
</tr>
<tr>
	<td width="14%">&nbsp; </td>
	<td class=l_tb>
	<input type="radio" name="enable" value="1" checked><?=$m_enabled?>
	<input type="radio" name="enable" value="0" <?if($enable!="1"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>
<tr>
	<td class=l_tb><?=$m_name?>&nbsp;</td>
	<td>
	<input type="text" name="name" size="20" maxlength="31">
	<input type="reset" value="<?=$m_clear?>" onClick="doReset()" name="clear">
	</td>
</tr>
<tr>
	<td class=l_tb><?=$m_action?>&nbsp;</td>
	<td class=l_tb>
	<input type="radio" value="1" name="action" checked><?=$m_allow?>
	<input type="radio" name="action" value="2" <?if($action!="1"){echo "checked";}?>><?=$m_deny?>
	</td>
</tr>
<tr>
	<td colspan=2>
	<table width=100%>
	<tr>
		<td></td>
		<td class=l_tb><?=$m_interface?></td>
		<td class=l_tb><?=$m_ip_range_start?></td>
		<td class=l_tb><?=$m_ip_range_end?></td>
		<td class=l_tb><?=$m_protocol?></td>
		<td class=l_tb><?=$m_port_range?></td>
	</tr>
	</tr>
	<tr>
		<td class=l_tb><?=$m_source?>&nbsp;</td>
		<td class=l_tb><script>print_inf("srcIface","<?=$srcIface?>");</script></td>
		<td><input type="text" name="srcIP1" size="12" maxlength="15" value="<?=$srcIP1?>"></td>
		<td colspan=3><input type=text name=srcIP2 size=12 maxlength=15 value="<?=$srcIP2?>"></td>
	</tr>
	<tr>
		<td class=l_tb><?=$m_destination?>&nbsp;</td>
		<td><script>print_inf("dstIface","<?=$dstIface?>");</script></td>
		<td><input type="text" name="dstIP1" size="12" maxlength="15" value="<?=$dstIP1?>"></td>
		<td><input type=text name=dstIP2 size=12 maxlength=15 value="<?=$dstIP2?>"></td>
		<td><script>print_pro("proto", "<?=$proto?>","CheckField(this.value)");</script></td>
		<td class=l_tb>
		<input type="text" name="port1" size="2" maxlength="5" value="<?=$port1?>">-
		<input type="text" name="port2" size="2" maxlength="5" value="<?=$port2?>">
		</td>
	</tr>
	</table>
	</td>
</tr>
<script>CheckProtField();</script>
<? require("/www/locale/".$__LANG."/schedule.php"); ?>
<tr>
	<td colspan=2 align=right>
	<script language="JavaScript">apply(""); cancel("");help("help_adv.php#08");</script>
	</td>
</tr>
<tr>
	<td colspan=2><table width=100%><tr>
		<td width=50% valign="bottom" class=title_tb><?=$m_fw_list?></td>
		<td class=r_tb><script>print_rule_count("<?=$rule_num?>","<?=$max_rule?>");</script></td>
	</tr></table></td>
</tr>
<tr>
	<td colspan=2>
	<table border="0" width="100%" id="tabRule" cellpadding="0" cellspacing="0">
	<tr bgcolor="#B7DCFB">
		<td width="2%">&nbsp;</td>
		<td width="8%" class=c_tb><?=$m_action?></td>
		<td width="18%" class=c_tb><?=$m_name?></td>
		<td width="24%" class=c_tb><?=$m_source?></td>
		<td width="24%" class=c_tb><?=$m_destination?></td>
		<td width="15%" class=c_tb><?=$m_protocol?></td>
		<td width="14%">&nbsp;</td>
	</tr>
<?
$index=0;
for("/nat/vrtsrv/entry")
{
	if(query("enable")=="1")
	{
		$index++;
		echo "<tr>\n";
		if($index_en=="1"){echo "<td class=r_tb nowrap>".$index.".<input type='checkbox' name='vrtsrv' checked disabled></td>\n";}
		else{echo "<td class=r_tb nowrap><input type='checkbox' name='vrtsrv' checked disabled></td>\n";}
		echo "<td class=bl_tb>".$allow_msg."</td>\n";
		echo "<td class=l_tb><script>echosc(\"".queryjs("description")."\");</script></td>\n";
		echo "<td class=c_tb>WAN<br>*</td>\n";
		echo "<td class=c_tb>LAN<br>".query("privateip")."</td>\n";
		echo "<td class=c_tb>";
		map("protocol", "1","TCP", "2","UDP", *,"Both");
		echo "<br>".query("publicport")."</td>\n";
		echo "</tr>\n";
	}
}
	
for("/security/di624/firewall/entry")
{
	$index++;
	$sip_e=query("sourceipend");
	$dstip_e=query("destipend");
	$dstport_e=query("destportend");
	$protocol=query("protocol");

	$pre=$@-1;
	$next=$@+1;
	
	if($edit_id==$@){echo "<tr bgcolor=".$sel_color.">\n";}
	else		{echo "<tr>\n";}
	if($index_en=="1")	{echo "<td class=r_tb nowrap>".$index.".<input type=checkbox name=en ";}
	else			{echo "<td class=r_tb nowrap><input type=checkbox name=en ";}
	if(query("enable")=="1"){echo "checked ";}
	echo "disabled></td>\n";
	echo "<td class=bl_tb>";
	map("action" ,"1",$allow_msg,"2",$deny_msg,*,"");
	echo "</td>";
//	echo "<td class=l_tb><script>echosc(\"".queryjs("description")."\");</script></td>";
	echo "<td class=l_tb><script>format_str_by_field(\"".queryjs("description")."\",\"10\");</script></td>";
	echo "<td class=c_tb>";
	map("sourceinf","0",$m_any,"1","LAN","2","WAN");
	echo "<br>";
	map("sourceipbegin","","*");
	if($sip_e!=""){echo "<br>-<br>".$sip_e;}
	echo "</td>\n";
	echo "<td class=c_tb>";
	map("destinf","0",$m_any,"1","LAN","2","WAN");
	echo "<br>";
	map("destipbegin","","*");
	if($dstip_e!=""){echo "<br>-<br>".$dstip_e."</td>\n";}
	echo "<td class=c_tb>\n";
	map("protocol","1",$m_all,"2","TCP","3","UDP","4","ICMP");
	echo "<br>";
	if($protocol=="1"){echo " *";} 
	if($protocol=="2"||$protocol=="3"){
		echo "".query("destportbegin");
		if($dstport_e!=""){echo "<br>-<br>".$dstport_e;}
	}
	echo "</td>\n";
	echo "<td class=r_tb>\n";
	echo "<a href=\"javascript:editRow(".$@."); \">";
	echo "<IMG alt=edit border=0 height=17 src='../graphic/edit.gif' width=15></a>\n";
	echo "<a href='javascript:doDelete(".$@.");'>";
	echo "<IMG alt=delete border=0 height=18  src='../graphic/delet.gif' width=15></a><br>\n";
	if($@=="1"){echo "<img src='../graphic/up_g.gif'>";}
	else
	{
		echo "<a href='javascript:chgPri(".$@.",".$pre.");'>";
		echo "<img src='../graphic/up.gif' width=15 height=17 border=0 alt='priority up'></a>\n";
	}
	if($@==$rule_num){echo "<img src='../graphic/down_g.gif'>";}
	else
	{
		echo "<a href='javascript:chgPri(".$@.",".$next.");'>";
		echo "<img src='../graphic/down.gif' width=15 height=17 border=0 alt='priority down'></a>\n";
	}
	echo "</td>\n";
	echo "</tr>\n";
}

for("/security/di624/ipfilter/entry")
{
	if(query("enable")=="1")
	{
		$index++;
		$sip_e=query("sourceipend");
		$dstport_e=query("destportend");
		echo "<tr>\n";
		if($index_en=="1"){echo "<td class=r_tb nowrap>".$index.".<input type='checkbox' name='ipfilter' checked disabled></td>\n";}
		else{echo "<td class=r_tb nowrap><input type='checkbox' name='ipfilter' checked disabled></td>\n";}
		echo "<td class=bl_tb>".$deny_msg."</td>\n";
		echo "<td></td>\n";
		echo "<td class=c_tb>LAN<br>".query("sourceipbegin");
		if($sip_e!=""){echo "<br>-<br>".query("sourceipend");}
		echo "</td>\n";
		echo "<td class=c_tb>WAN<br>*</td>\n";
		echo "<td class=c_tb>";
		map("protocol", "1",$m_all,"2","TCP","3","UDP","4","ICMP");
		echo "<br>".query("destportbegin");
		if($dstport_e!=""){echo "<br>-<br>".query("destportend");}
		echo "</td>\n";
		echo "</tr>\n";
	}
}

if(query("/security/firewall/pingallow")=="1")
{
	$index++;
	echo "<tr>\n";
	if($index_en=="1"){echo "<td class=r_tb nowrap>".$index.".<input type='checkbox' name='pingallow' checked disabled></td>";}
	else{echo "<td class=r_tb nowrap><input type='checkbox' name='pingallow' checked disabled></td>";}
	echo "<td class=bl_tb>".$allow_msg."</td>";
	echo "<td class=l_tb>".$m_allow_ping."</td>";
	echo "<td class=c_tb>WAN<br>*</td>";
	echo "<td class=c_tb>LAN<br>".query("/lan/ethernet/ip")."</td>";
	echo "<td class=c_tb>ICMP</td>";
	echo "</tr>";
}
	
if(query("/security/firewall/httpallow")=="1")
{
	$index++;
	echo "<tr>";
	if($index_en=="1"){echo "<td class=r_tb nowrap>".$index.".<input type='checkbox' name='httpallow' checked disabled></td>";}
	else{echo "<td class=r_tb nowrap><input type='checkbox' name='httpallow' checked disabled></td>";}
	echo "<td class=bl_tb>".$allow_msg."</td>";
	echo "<td class=l_tb>".$m_remote_management."</td>";
	echo "<td class=c_tb>WAN<br>";
	if(query("/security/firewall/httpremoteip")==""){echo "*";}
	echo "</td>";
	echo "<td class=c_tb>LAN<br>".query("/lan/ethernet/ip")."</td>";
	echo "<td class=c_tb>TCP<br>".query("/security/firewall/httpremoteport")."</td>";
	echo "</tr>";
}
?>
	<tr>
		<td class=r_tb nowrap><?if($index_en=="1"){$index++; echo $index.".";}?><input type=checkbox name=en checked disabled></td>
		<td class=bl_tb><?=$deny_msg?></td>
		<td class=l_tb><?=$m_default?></td>
		<td class=c_tb>WAN<br>*</td>
		<td class=c_tb>LAN<br>*</td>
		<td class=c_tb><?=$m_all?><br>*</td>
		<td width=75>&nbsp;</td>
	</tr>
	<tr>
		<td class=r_tb nowrap><?if($index_en=="1"){$index++; echo $index.".";}?><input type=checkbox name=en checked disabled></td>
		<td class=bl_tb><?=$allow_msg?></td>
		<td class=l_tb><?=$m_default?></td>
		<td class=c_tb>LAN<br>*</td>
		<td class=c_tb><?=$m_any?><br>*</td>
		<td class=c_tb><?=$m_all?><br>*</td>
		<td width=75>&nbsp;</td>
	</tr>
	</table>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
