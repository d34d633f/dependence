<?
$MSG_FILE="adv_filters_comm.php";
require("/www/comm/lang_msg.php");
?>
<table width=100% cellspacing=0 cellpadding=0>
<tr><td colspan=3 height=20 class=title_tb><?=$m_filters?></tr>
<tr valign="top"><td colspan=3 height=30 class=l_tb><?=$m_filter_description?></td></tr>
<tr>
<?
if($now_filter=="ip")
{
	echo "	<td width=23% class=l_tb><input type=radio name=filters checked>".$m_ip_filters."</td>\n";
	echo "	<td class=l_tb><input type=radio name=filters onclick=\"self.location.href='adv_filters_mac.php'\">".$m_mac_filters."</td>\n";
}
else if($now_filter=="mac")
{
	echo "	<td width=23% class=l_tb><input type=radio name=filters onclick=\"self.location.href='adv_filters_ip.php'\">".$m_ip_filters."</td>\n";
	echo "	<td class=l_tb><input type=radio name=filters checked>".$m_mac_filters."</td>\n";
}
?>
</tr>
<tr><td height=10></td></tr>
</table>
