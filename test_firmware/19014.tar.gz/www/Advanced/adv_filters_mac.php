<?
$MSG_FILE="adv_filters_mac.php";
$file_name="adv_filters_mac.php";
$apply_name="adv_filters_mac.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");

anchor("/security/macfilter");
$enable=query("enable");
$action=query("action");

if($edit_id!="")
{
	$num=$edit_id;
	anchor("/security/macfilter/entry:".$edit_id);
	$name=queryjs("description");
	$mac=query("sourcemac");
}
?>

<script language="JavaScript">
macZ=[['index','description','sourcemac']<?
$rule_num=0;
for("/security/macfilter/entry"){$f_num++;}
for("/security/macfilter/entry")
{
	$rule_num++;
	echo ",\n	['".$#."','".queryjs("description")."','".query("sourcemac")."']";
}
if($edit_id==""){$num=$rule_num+1;}
?>];

dhcpList=[['index','hostname','macaddr']<?
//staticdhcp
$d_num=0;
for("/lan/dhcp/server/pool:1/staticdhcp/entry")
{
	$d_num++;
	echo ",\n	['".$d_num."','".queryjs("hostname")."','".query("mac")."']";
}
//dhcp
for("/runtime/dhcpserver/lease")
{
	$d_num++;
	echo ",\n";
	echo "/* dhcp */";
	echo "	['".$d_num."','".queryjs("hostname")."','".query("mac")."']";
}
?>];

function EditRow(r)
{
	self.location.href="<?=$file_name?>?edit_id="+r;
}

function doReset(f,tn)
{
	self.location.href="<?=$file_name?>";
}

// this function is used for sending data to server when user presses the "Apply" button.
function doSubmit()
{
	var f = document.getElementById("frmMAC");
	var str=new String("<?=$apply_name?>");
	var num,c=0;
	
	num=parseInt("<?=$num?>", [10]);

	if (f.macFilter[1].checked) c=1;
	if (f.macFilter[2].checked) c=0;

	if (f.macFilter[0].checked)
		str+="set/security/macfilter/enable=0";
	else
	{
		str+="set/security/macfilter/enable=1";
		str+="&set/security/macfilter/ACTION="+c;
	}

	if (!isBlank(f.name.value) ||
		!isBlank(f.mac1.value) || !isBlank(f.mac2.value) || !isBlank(f.mac3.value) || !isBlank(f.mac4.value) || !isBlank(f.mac5.value) || !isBlank(f.mac6.value))
	{
		if (checkParameter()==false) return;

		str+="&set/security/macfilter/ENTRY:"+num+"/DESCRIPTION="+escape(f.name.value);

		mac=f.mac1.value+":"+f.mac2.value+":"+f.mac3.value+":"+f.mac4.value+":"+f.mac5.value+":"+f.mac6.value;
		str+="&set/security/macfilter/ENTRY:"+num+"/SOURCEMAC="+mac;
	}
	else
	{
		if(f.macFilter[0].checked!=true && "<?=$rule_num?>"=="0")
		{
			alert("<?=$a_mac_filter_list_cant_be_empty?>");
			return ;
		}

	}
	str+=exeStr("submit COMMIT;submit RG_MAC_FILTER");
	if (confirm("<?=$a_confim_to_change_settings?>")==false) return;
	self.location.href=str;
}

// this function is used for sending data to server when user presses the "Delete" button.
function doDelete(num)
{
	var f = document.getElementById("frmMAC");
	if("<?=$enable?>"=="1" && "<?=$rule_num?>"=="1")
	{
		alert("<?=$a_mac_filter_list_cant_be_empty?>");
		return;
	}
	if (confirm("<?=$a_confim_to_delete?>")==false) return;
	var str=new String("<?=$apply_name?>");

	str+="del/security/macfilter/entry:"+num+"=1";
	str+=exeStr("submit COMMIT;submit RG_FILTER");
	self.location.href=str;
}

function cloneMAC(f,r)
{
	if(r == -1)	return;
	mac=getMAC(dhcpList[r][2]);
	f.name.value=dhcpList[r][1];
	for(i=1;i<7;i++)	eval("f.mac"+i+".value=mac["+i+"]");
}

function checkParameter()
{
	var f = document.getElementById("frmMAC");
	var i = 0, j = 0;
	
	MaxRule=parseInt("<?=$max_rule?>", [10]);

	if (parseInt("<?=$num?>", [10]) > MaxRule)
	{
		alert(<?=$a_exced_max_entry?>);
		return false;
	}
	//name
	var n=f.name.value;
	if (isBlank(n))
	{
		alert("<?=$a_mac_filter_name_cant_be_empty?>");
		f.name.focus();
		return false;
	}

	// dhcp client mac
	for (i=1; i < 7;i++)
	{
		var mac=eval("f.mac"+i);
		var strlen=2-mac.value.length;
		mac.value=mac.value.toUpperCase();
		for(j=0; j<strlen; j++)
			mac.value="0"+mac.value;

		if (!checkMAC(mac.value))
		{
			alert("<?=$a_wrong_format_mac_addr?>");
			eval("f.mac"+i+".focus();");
			return false;
		}
	}

	mac=f.mac1.value+":"+f.mac2.value+":"+f.mac3.value+":"+f.mac4.value+":"+f.mac5.value+":"+f.mac6.value;
	for(i=0; i<macZ.length; i++)
	{
		if(parseInt("<?=$edit_id?>", [10])==i)
			continue;
		if(mac.toUpperCase()==macZ[i][2].toUpperCase())
		{
			alert("<?=$a_same_entry_exist?>");
			return false;
		}
	}
	return true;
}
function print_mac(n)
{
	<?
	if($edit_id!=""){echo "	mac=getMAC('".$mac."');\n";}
	else		{echo "	mac=getMAC(':::::');\n";}
	?>
	str="";
	for(var i=1;i<7;i++)
	{
		str+="<input type=text name="+n+i+" size=2 maxlength=2 value='"+mac[i]+"'>";
		if(i!=6) str+=" : ";
	}
	document.write(str);
}

function print_dhcp(n)
{
	var f = document.getElementById("frmMAC");
	str="<select name="+n+" size=1>";
	str+="<option value=-1></option>";
	for (var i=1; i < dhcpList.length;i++)
	{
		str+="<option value='"+i+"'>"+dhcpList[i][1]+"("+dhcpList[i][2]+")</option>";
	}
	str+="</select>";
	document.write(str);
}
function init()
{
	var f = document.getElementById("frmMAC");
<?
	if ($edit_id!="")
	{
		echo "	f.name.value=\"".$name."\";\n";
	}
?>
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload=init()>
<?require("/www/comm/middle.php");?>
<form method=post action=mac.cgi id=frmMAC>
<input type=hidden name=editRow value=-1>
<table width="<?=$width_tb?>" border=0 cellspacing=0 cellpadding=0>
<tr><td colspan=2><?$now_filter="mac";	require("/www/Advanced/adv_filters_comm.php");?></td></tr>
<tr><td colspan=2 class=title_tb><?=$m_mac_filters?></td></tr>
<tr valign="top">
	<td colspan=2 class=l_tb><?=$m_mac_filters_description?><td>
</tr>
<tr>
	<td colspan=2>
	<table>
	<tr>
		<td height=20 class=l_tb><input type=radio value=0 name=macFilter <?if($enable=="0"){echo "checked";}?>></td>
		<td class=l_tb><?=$m_radio_disabled?></td>
	</tr>
	<tr>
		<td height=20 class=l_tb valign=top><input type=radio value=2 name=macFilter <?if($enable=="1" && $action=="1"){echo "checked";}?>></td>
		<td class=l_tb><?=$m_radio_allow_below_list?><td>
	</tr>
	<tr>
		<td height=20 class=l_tb valign=top><input type=radio value=1 name=macFilter <?if($enable=="1" && $action=="0"){echo "checked";}?>></td>
		<td class=l_tb><?=$m_radio_deny_below_list?><td>
	</tr>
	</table>
	</td>
</tr>
<tr>
	<td height=10></td>
</tr>
<tr>
	<td align=right width=20% class=l_tb><?=$m_name?>&nbsp;</td>
	<td ><input type=text name=name size=19 maxlength=19><input type="button" value="Clear" onClick="doReset()" name="clear"></td>
</tr>
<tr>
	<td class=r_tb><?=$m_mac_addr?>&nbsp;</td>
	<td class=l_tb><script>print_mac("mac");</script></td>
</tr>
<tr>
	<td class=r_tb><?=$m_dhcp_client?>&nbsp;</td>
	<td class=l_tb>
	<script>print_dhcp("dhcp");</script>
	<input type=button name=clone value=Clone onClick=cloneMAC(this.form,this.form.dhcp.value)>
	</td>
</tr>
<tr><td height=20></td></tr>
<tr>
	<td colspan=2 height=20 align=right>
	<script language="JavaScript">apply(""); cancel("");help("help_adv.php#07");</script>
	<td>
</tr>
<tr>
	<td height=20 class=title_tb><?=$m_mac_filter_list?></td>
	<td class=r_tb width=50%><script>print_rule_count("<?=$rule_num?>","<?=$max_rule?>");</script></td>
</tr>
<tr>
	<td colspan=2>
	<table width=100% border=0 id=tabMAC cellpadding=0 cellspacing=0>
	<tr bgcolor=#b7dcfb>
	<td width=5%></td><td width=2%></td>
	<td class=l_tb><?=$m_name?></td>
	<td class=l_tb><?=$m_mac_addr?></td>
	<td>&nbsp;</td>
	</tr>
<?
for("/security/macfilter/entry")
{
	if($edit_id==$#){echo "<tr bgcolor=".$sel_color.">\n";}
	else		{echo "	<tr>\n";}
	if($index_en=="1")	{echo "		<td class=r_tb nowrap>".$#.".</td><td></td>";}
	else			{echo "		<td class=r_tb nowrap></td><td></td>";}
	echo "		<td class=l_tb><script>echosc(\"".queryjs("description")."\");</script></td>\n";
	echo "		<td class=l_tb>".query("sourcemac")."</td>\n";
	echo "		<td class=r_tb>\n";
	echo "		<a href='javascript:EditRow(".$#.")'><img src='../graphic/edit.gif' width=15 height=17 border=0 alt=edit></a>\n";
	echo "		<a href='javascript:doDelete(".$#.")'><img src='../graphic/delet.gif' width=15 height=18 border=0 alt=delete></a>\n";
	echo "		</td>\n";
	echo "	</tr>\n";
}
?>
	</table>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
