<? /* vi: set sw=4 ts=4: */
$MSG_FILE="adv_filters_domain.php";

$file_name="adv_filters_domain.php";
$apply_name="adv_filters_domain.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");

$mode=query("/security/domainblocking/enable");
if($b_edit!="")
{
	$b_num=$b_edit;
	$block=queryjs("/security/domainblocking/deny:".$b_edit);
}
else if($p_edit!="")
{
	$p_num=$p_edit;
	$permit=queryjs("/security/domainblocking/allow:".$p_edit);
}
?>

<script language="JavaScript">

var allowZ=[''<?
$a_num=0;
for("/security/domainblocking/allow")
{
	$a_num++;
	echo ",'".queryjs("/security/domainblocking/allow:".$#)."'";
}
if($p_edit==""){$p_num=$a_num+1;}
?>];
var denyZ=[''<?
$d_num=0;
for("/security/domainblocking/deny")
{
	$d_num++;
	echo ",'".queryjs("/security/domainblocking/deny:".$#)."'";
}
if($b_edit==""){$b_num=$d_num+1;}
?>];

function init()
{
	var f = document.getElementById("frmDom");
<?
if($b_edit!="")
{
	echo "	f.block.value='".$block."';\n";
	echo "	f.permit.disabled=true;\n";
	
}
else if($p_edit!="")
{
	echo "	f.permit.value='".$permit."';\n";
	echo "	f.block.disabled=true;\n";
}
?>
}

function EditRow(index,k)
{
	if(k==0)	self.location.href="<?=$file_name?>?b_edit="+index;
	else if(k==1)	self.location.href="<?=$file_name?>?p_edit="+index;
}

function doSubmit()
{
	var f = document.getElementById("frmDom");
	var str=new String("<?=$apply_name?>");
	var num1,num2,c=0;
	num1="<?=$b_num?>";
	num2="<?=$p_num?>";
	MaxPat=parseInt("<?=$max_pat?>", [10]);
	if (f.mode[1].checked)
	{
		if (num1 > MaxPat && !isBlank(f.block.value))
		{
			alert("<?=$a_exceed_maximum_entry_number?>");
			return;
		}
		c=1;
	}
	if (f.mode[2].checked)
	{
		if (num2 > MaxPat && !isBlank(f.permit.value))
		{
			alert("<?=$a_exceed_maximum_entry_number?>");
			return;
		}
		c=2;
	}
	str+="SET/SECURITY/DOMAINBLOCKING/ENABLE="+c;

	// blocked strings
	if (!isBlank(f.block.value) && f.block.value.length)
	{		
		if(!chk_valid_char(f.block.value))
		{
			alert("<?=$a_invalid_domain?>");
			f.block.select();
			return;
		}
		for(i=1;i<denyZ.length;i++)
		{
			if(parseInt("<?=$b_edit?>", [10])==i) continue;
			if(denyZ[i]==f.block.value)
			{
				alert("<?=$a_same_domain_entry_exists?>");
				return;
			}
		}
		str+="&SET/SECURITY/DOMAINBLOCKING/DENY:"+num1+"="+f.block.value;
	}
	
	// permit strings
	if (!isBlank(f.permit.value) && f.permit.value.length)
	{
		if(!chk_valid_char(f.permit.value))
		{
			alert("<?=$a_invalid_domain?>");
			f.permit.select();
			return;
		}
		for(i=1;i<allowZ.length;i++)
		{
			if(parseInt("<?=$p_edit?>", [10])==i) continue;
			if(allowZ[i]==f.permit.value)
			{
				alert("<?=$a_same_domain_entry_exists?>");
				return;
			}

		}
		str+="&SET/SECURITY/DOMAINBLOCKING/ALLOW:"+num2+"="+f.permit.value;
	}
	str+=exeStr("submit COMMIT;submit RG_BLOCKING");
	self.location.href=str;
}

// this function is used for sending data to server when user presses the "Delete" button.
function doDelete(num,t)
{
	if (confirm("<?=$a_are_you_sure_to_delete_this?>")==false) return;
	var f = document.getElementById("frmDom");
	var str=new String("<?=$apply_name?>");
	if (t)	str+="DEL/SECURITY/DOMAINBLOCKING/ALLOW:"+num+"=1";
	else	str+="&DEL/SECURITY/DOMAINBLOCKING/DENY:"+num+"=1";
	str+=exeStr("submit COMMIT;submit RG_BLOCKING");
	self.location.href=str;
}
function doReset()
{
	self.location.href="<?=$file_name?>";
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 <?if($b_edit!="" || $p_edit!=""){echo "onload=init()";}?>>
<?require("/www/comm/middle.php");?>
<form method=post id=frmDom>

<table width="<?=$width_tb?>" border=0 cellspacing=0 cellpadding=0>
<tr><td colspan=2><?$now_block="domain"; require("/www/Advanced/adv_block_comm.php");?></td></tr>
<tr>
	<td colspan=2 height=20 class=title_tb><?=$m_title?></td>
</tr>
<tr>
	<td colspan=2 height=20 class=l_tb><input type=radio name=mode value=0 checked><?=$m_disabled?></td>
</tr>
<tr>
	<td colspan=2 height=20 class=l_tb><input type=radio name=mode value=1 <?if($mode=="1"){echo "checked";}?>><?=$m_allow_all_domains_except_blocked_ones?></td>
</tr>
<tr>
	<td colspan=2 height=20 class=l_tb><input type=radio name=mode value=2 <?if($mode=="2"){echo "checked";}?>><?=$m_deny_all_domains_except_permitted_ones?></td>
</tr>
</table>
<table width="<?=$width_tb?>" border=0 cellspacing=0 cellpadding=0>
<tr><td height=20></td></tr>
<tr>
	<td height=20 width=25% class=r_tb><?=$m_blocked_domains?>&nbsp;</td><td><input type=text name=block size=32 maxlength=39></td>
</tr>
<tr>
	<td height=20><br></td>
</tr>
<tr>
	<td height=20 class=r_tb><?=$m_permitted_domains?>&nbsp;</td><td><input type=text name=permit size=32 maxlength=39></td>
</tr>
<tr>
	<td height=20 align=right colspan=2><script>apply("");cancel("");help("help_adv.php#7_1");</script>
	</td>
</tr>
</table>
<table width="<?=$width_tb?>" border=0 cellspacing=0 cellpadding=0>
<tr>
	<td width=300 class=title_tb><?=$m_blocked_domains_list?></td>
	<td align=right><script>print_rule_count("<?=$d_num?>","<?=$max_pat?>");</script></td>
</tr>
<tr>
	<td colspan=2>
	<table width=100% border=0 id=block_tb cellpadding=0 cellspacing=0>
	<tr bgcolor=#b7dcfb><td width=3% class=r_tb></td><td width=2%></td><td colspan=2 class=l_tb><?=$m_blocked_domains?></td></tr>
<?
for("/security/domainblocking/deny")
{
	if($b_edit==$@)	{echo "<tr bgcolor=".$sel_color.">\n";}
	else		{echo "<tr>\n";}
	if($index_en=="1")	{echo "<td width=4% class=r_tb nowrap>".$@.".</td><td width=2%></td>";}
	else			{echo "<td width=4% class=r_tb nowrap></td><td width=2%></td>";}
	echo "<td><script>echosc(\"".queryjs("/security/domainblocking/deny:".$@)."\");</script></td>\n";
	echo "<td align=right>\n";
	echo "<a href='javascript:EditRow(".$@.",0)'><img src='../graphic/edit.gif' width=15 height=17 border=0 alt=edit></a>\n";
	echo "<a href='javascript:doDelete(".$@.",0)'><img src='../graphic/delet.gif' width=15 height=18 border=0 alt=delete></a>\n";
	echo "</td>\n";
	echo "</tr>\n";
}
?>
	</table>
	</td>
</tr>
</table>
<br>
<table width="<?=$width_tb?>" border=0 cellspacing=0 cellpadding=0>
<tr>
	<td width=300 class=title_tb><?=$m_permitted_domains_list?></td>
	<td align=right><script>print_rule_count("<?=$a_num?>","<?=$max_pat?>");</script></td>
</tr>
<tr>	
	<td colspan=2>
	<table width=100% border=0 id=per_tb cellpadding=0 cellspacing=0>
	<tr bgcolor=#b7dcfb><td width=3% class=r_tb></td><td width=2%></td><td colspan=2 class=l_tb><?=$m_permitted_domains?></td></tr>
<?
for("/security/domainblocking/allow")
{
	if($p_edit==$@)	{echo "<tr bgcolor=".$sel_color.">\n";}
	else		{echo "<tr>\n";}
	if($index_en=="1")	{echo "<td width=4% class=r_tb nowrap>".$@.".</td><td width=2%></td>";}
	else			{echo "<td width=4% class=r_tb nowrap></td><td width=2%></td>";}
	echo "	<td><script>echosc(\"".queryjs("/security/domainblocking/allow:".$@)."\");</script></td>";
	echo "	<td align=right>\n";
	echo "	<a href='javascript:EditRow(".$@.",1)'><img src='../graphic/edit.gif' width=15 height=17 border=0 alt=edit></a>\n";
	echo "	<a href='javascript:doDelete(".$@.",1)'><img src='../graphic/delet.gif' width=15 height=18 border=0 alt=delete></a>\n";
	echo "	</td>\n";
	echo "</tr>\n";
}							
?>
	</table>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
