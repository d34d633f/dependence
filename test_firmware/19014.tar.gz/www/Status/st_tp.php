<?
/* vi: set sw=4 ts=4: */
/*/ ----------------------message start---------------------------
$m_refresh="Refresh";
// ----------------------message end----------------------------- */

require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");?> 
<body leftmargin=0 topmargin=0>
<script>
phy_wan="<?query("/runtime/wan/inf:1/linkType");?>";
slan=["<?query("/runtime/switch/port:4/linkType");?>",
	"<?query("/runtime/switch/port:3/linkType");?>",
	"<?query("/runtime/switch/port:2/linkType");?>",
	"<?query("/runtime/switch/port:1/linkType");?>"
	];
<?$g_wlan=0; for("/runtime/stats/wireless/client"){$g_wlan++;}?>
//g_wlan = parseInt("<?query("/runtime/stats/wireless/client#");?>", [10]);
g_wlan = parseInt("<?=$g_wlan?>", [10]);
mode = <?query("/wan/rg/inf:1/mode");?>;
connectStatus = "<?query("/runtime/wan/inf:1/connectStatus");?>";
poe_status=["<?query("/runtime/wan/inf:1/connectStatus");?>","<?query("/runtime/wan/inf:2/connectStatus");?>"];

/*wan status*/
if((mode == 1 && phy_wan == 1) || connectStatus=="connected")/*static ip or connected*/
	g_wan=1;
else	g_wan=0;

/*lan status*/
g_lan=0;
for(i=0;i<slan.length;i++)
{
	if(slan[i]=="1")	g_lan++;
}

function writecount(id)
{
	str="";
	switch (id)
	{
	case 1:	break;
	case 2:
		if(g_lan!=0)		str="<font color=blue>"+g_lan+" x</font>";
		break;
	case 3:
		if(g_diskno!=0)		str="<font color=blue>x"+g_diskno+"</font>";
		break;
	case 4:
		if(g_pprinterCount!=0)	str="<font color=blue>x"+g_pprinterCount+"</font>";
		break;
	case 5:
		if(g_wlan!=0)		str="<font color=blue> x"+g_wlan+"</font>";
		else			str="<font color=blue>&nbsp;&nbsp;&nbsp;&nbsp;</font>"
		break;
	case 6:
		break;
	}
	document.writeln(str);
}
function getwanconfigpage()
{
	switch (mode)
	{
	case 2:	wanType="/Home/h_wan_dhcp.php";		break;
	case 3:	wanType="/Home/h_wan_poe.php";		break;
	case 4:	wanType="/Home/h_wan_pptp.php";		break;
	case 5:	wanType="/Home/h_wan_l2tp.php";		break;
	case 6:	wanType="/Home/h_wan_mpoe.php";		break;
	case 7:	wanType="/Home/h_wan_bigpond.php";	break;
	case 1:
	default:
		wanType="/Home/h_wan_fix.php";		break;
	}
	return wanType;
}
function linkto(id)
{
	str="";
	switch (id)
	{
	case 1:	str=getwanconfigpage();		break;
	case 2:	str="/Tools/tools_vct.php";	break;
	case 3:	str="/Status/st_devic.php";	break;
	case 4:	str="/Status/st_printer.php";	break;
	case 5:	str="/Status/st_wireless.php";	break;
	case 6:	break;
	}
	if(top.window.opener.closed)	return;
	top.opener.top.location.href=str;
	top.opener.focus();
}
function writephoto(id)
{
	str="";
	switch (id)
	{
	case 1:
		if(g_wan==0)
		str="<a href='javascript:linkto(1)'><img border='0' src='/graphic/xx.gif' width='60' height='60'></a>";
		else
		str="<a href='javascript:linkto(3)'><img border='0' src='/graphic/ss.gif' width='66' height='62'></a>";
		break;
	case 2:
		if(g_lan==0)
		str="<a href='javascript:linkto(2)'><img border='0' src='/graphic/xx.gif' width='60' height='60'></a>";
		else
		str="<a href='javascript:linkto(2)'><img border='0' src='/graphic/ss.gif' width='60' height='60'></a>";
		break;
	case 3:
		if(g_diskno==0)
		str="<a href='javascript:linkto(3)'><img border='0' src='/graphic/xx.gif' width='60' height='60'></a>";
		else
		str="<a href='javascript:linkto(3)'><img border='0' src='/graphic/ss.gif' width='60' height='60'></a>";
		break;
	case 4:
		if(g_pprinterCount==0)
		str="<a href='javascript:linkto(4)'><img border='0' src='/graphic/xx.gif' width='60' height='60'></a>";
		else
		str="<a href='javascript:linkto(4)'><img border='0' src='/graphic/ss.gif' width='60' height='60'></a>";
		break;
	case 5:
		if(g_wlan==0)
		str="<a href='javascript:linkto(5)'><img border='0' src='/graphic/xx.gif' width='60' height='60'></a>";
		else
		str="<a href='javascript:linkto(5)'><img border='0' src='/graphic/ss.gif' width='60' height='60'></a>";
		break;
	case 6:
		break;
	}
	document.writeln(str);
}
</SCRIPT>

<TABLE height=154 cellSpacing=0 cellPadding=0 width=471 align=center background=/graphic/bg_tp.jpg border=0>
<TR>
	<TD width=230 height=182></TD>
	<TD vAlign=bottom height=182 class=title_tb><SCRIPT>writephoto(1)</SCRIPT></TD>
	<TD height=182></TD>
	<TD height=182></TD>
</TR>
<TR>
	<TD vAlign=center height=113 class=title_tb>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<SCRIPT>writecount(2);</SCRIPT>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<SCRIPT>writephoto(2)</SCRIPT>
	</TD>
	<TD height=113></TD>
	<TD colSpan=2 height=113>&nbsp;
	</TD>
</TR>
<TR>
	<TD height=124></TD>
	<TD height=124></TD>
	<TD height=124></TD>
	<TD vAlign=top height=124>&nbsp;&nbsp;&nbsp;</TD>
</TR>
<TR>
	<TD vAlign=middle align=right height=110 class=title_tb>
	<SCRIPT>writephoto(5)</SCRIPT>&nbsp;&nbsp;
	<SCRIPT>writecount(5);</SCRIPT></TD>
</tr>
<tr>
	<TD colspan=4 class=cn_title_tb>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
	<INPUT onclick="window.location.href='st_tp.xgi?set/runtime/switch/getlinktype=1'" type=button value=<?=$m_refresh?>Refresh name=refresh><BR></TD>
</TR>
</TABLE>
</BODY>
</HTML>
