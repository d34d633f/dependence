<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="st_log_settings.php";
$file_name="st_log_settings.php";
$apply_name="st_log_settings.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");?>

<script>
sData=[<?
anchor("/sys/log"); 
echo "'".queryjs("mailServer")."','".queryjs("email")."'";
?>];
//system, debug, att, drop, notice
syslog=['',<?
anchor("/security/log");
echo 	"'".	query("systemInfo").		"','".query("debugInfo").	"','".query("attackInfo").
	"','".	query("dropPacketInfo").	"','".query("noticeInfo")."'";
?>];

function validateEmail(str)
{
	for(var i=0; i<str.length; i++)
	{
		if( (str.charAt(i) != '@') )	continue;
		else				return 1;
	}
	return 0;
}

function initLogSetting()
{
	f=document.getElementById("logSetting");

	f.smtp.value=sData[0];
	f.sendto.value=sData[1];

	for(i=1;i<6;i++)
	{
		if (syslog[i] == "1")	eval("f.type"+i+".checked=true");
	}
}

function doSubmit(bmail)
{
	var f=document.getElementById("logSetting");
	var str=new String("<?=$apply_name?>");
	
	if(!chk_valid_char(f.smtp.value))
	{
		alert("<?=$a_invalid_smtp?>");
		f.smtp.select();
		return;
	}
	if(!chk_valid_char(f.sendto.value))
	{
		alert("<?=$a_invalid_email_addr?>");
		f.sendto.select();
		return;
	}

	if(bmail=="1")
	{
		if(f.smtp.value == "")
		{
			alert("<?=$a_smtp_server_ip_addr_is_empty?>");
			f.smtp.focus();
			return;
		}
		else if(f.sendto.value == "")
		{
			alert("<?=$a_email_addr_is_empty?>");
			f.sendto.focus();
			return;
		}
		else
		{
			if(validateKey(f.smtp.value))
				if(!checkIpAddr(f.smtp, "<?=$a_err_smtp_server_ip_addr?>")) return false;
			if(!validateEmail(f.sendto.value))
			{
				alert("<?=$a_err_email_addr_format?>");
				return;
			}
		}
	}
	else
	{
		if(f.smtp.value == "" && f.sendto.value != "")
		{
			alert("<?=$a_smtp_server_ip_addr_is_empty?>");
			return;
		}
		else if(f.sendto.value == "" && f.smtp.value != "")
		{
			alert("<?=$a_email_addr_is_empty?>");
			return;
		}
		else
		{
			if(f.smtp.value != "" && f.sendto.value != "")
			{
				if(validateKey(f.smtp.value))
					if(!checkIpAddr(f.smtp, "<?=$a_err_smtp_server_ip_addr?>")) return;
				if(!validateEmail(f.sendto.value))
				{
					alert("<?=$a_err_email_addr_format?>");
					return;
				}
			}

		}
	}
	str+="setPath=/sys/log/";
	str+="&mailServer="+f.smtp.value;
	str+="&email="+f.sendto.value;
	str+="&endSetPath=1";
	str+="&setPath=/security/log/";
	str+="&systemInfo="+(f.type1.checked?1:0);
	str+="&debugInfo="+(f.type2.checked?1:0);
	str+="&attackInfo="+(f.type3.checked?1:0);
	str+="&dropPacketInfo="+(f.type4.checked?1:0);
	str+="&noticeInfo="+(f.type5.checked?1:0);
	str+="&endSetPath=1";
	str+=exeStr("submit COMMIT;submit SYSLOG;submit RG");
	if(bmail == "1")	str+="&set/runtime/syslog/sendmail=1";
	self.location.href=str;
}
function send_mail_now()
{
	<?
	if($user=="admin" && query("/sys/user:1/password")==$passwd)
	{
		echo "doSubmit(1);\n";
	}
	else
	{
		echo "self.location.href=\"/sys/relogin.php\";";
	}
	?>
}
</script>
<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload="initLogSetting()">
<?require("/www/comm/middle.php");?>
<form method=POST id="logSetting">
<table width="<?=$width_tb?>" border=0 cellspacing=2 cellpadding=0>
<tr><td colspan=2 height=22 class=title_tb><?=$m_title?></td></tr>
<tr valign="top"><td colspan="2" height=40 class=l_tb><?=$m_title_desc?></td></tr>
<tr>
	<td width=30% height=25 class=l_tb><?=$m_smtp_server_ip_addr?></td>
	<td width=70%><input type=text name=smtp size=30 maxlength=30></td>
</tr>
<tr>
	<td class=l_tb><?=$m_email_addr?></td>
	<td>
	<input type=text name=sendto size=30 maxlength=99>
	<input type=button value="<?=$m_send_mail_now?>" name=sendnow onclick="send_mail_now()">
	</td>
</tr>
<tr>
	<td colspan="2" height=25 class=l_tb><?=$m_save_log_to_hdd?>&nbsp;
	<input type="button" name="backup" value="<?=$m_save?>" onClick="window.location.href='/tsyslog.rg';">
	</td>
</tr>
<tr>
	<td height=25 class=l_tb><?=$m_log_type?></td>
	<td class=l_tb><input type=checkbox name=type1 value=1><?=$m_ltype_system_activity?></td></tr>
<tr><td></td><td height=25 class=l_tb><input type=checkbox name=type2 value=2><?=$m_ltype_debug_information?></td></tr>
<tr><td></td><td height=25 class=l_tb><input type=checkbox name=type3 value=4><?=$m_ltype_attacks?></td></tr>
<tr><td></td><td height=25 class=l_tb><input type=checkbox name=type4 value=8><?=$m_ltype_dropped_packets?></td></tr>
<tr><td></td><td height=25 class=l_tb><input type=checkbox name=type5 value=16><?=$m_ltype_notice?></td></tr>
<tr>
	<td colspan=2 align=right>
	<script language="JavaScript">apply("doSubmit(0)"); cancel("javascript:self.location='<?=$file_name?>'"); help("help_status.php#16");</script>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
