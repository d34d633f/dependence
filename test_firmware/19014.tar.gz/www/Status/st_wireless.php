<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="st_wireless.php";
$other_meta="<META HTTP-EQUIV=Refresh CONTENT='10;URL=st_wireless.php'>";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
?>

<script language="JavaScript">
<?require("/www/comm/time.js");?>
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<?require("/www/comm/middle.php");?>
<form>
<table width="<?=$width_tb?>" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="22" colspan=2 valign="top" class=title_tb><?=$m_connected_wlan_client_list?></td>
</tr>
<tr>
	<td></td>
	<td height="40" valign="bottom" class=l_tb>
	<?=$m_title_desc?>
	</td>
	<td class=r_tb><script>help("help_status.php#17_1");</script></td>
</tr>
</table>
<table width="<?=$width_tb?>" border=0 cellspacing=0 cellpadding=0>
<tr bgcolor="#b7dcfb">
	<td width=3%></td>
	<td width=2%></td>
	<td width="30%" class=l_tb><?=$m_connected_time?></td>
	<td width="25%" class=l_tb><?=$m_mac_addr?></td>
	<td width="20%" class=l_tb><?=$m_mode?></td>
</tr>
<?
for("/runtime/stats/wireless/client")
{
	if($index_en=="1")	{echo "<tr><td class=r_tb>".$@.".</td>\n";}
	else			{echo "<tr><td class=r_tb></td>\n";}
	echo "<td></td>\n";
	echo "<td class=l_tb><script>document.write(parseTime('".query("time")."'));</script></td>\n";
	echo "<td class=l_tb>".query("mac")."</td>\n";
	echo "<td class=l_tb>".query("mode")."</td></tr>\n";
}
?>
</table>
</form>
<?require("/www/comm/bottom.php");?>
