<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="st_naptinfo.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");?>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>

<?require("/www/comm/middle.php");?>
          
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="22" valign="top" width="53%" class=title_tb><?=$m_title?></td>
	<td height="22"></td>
	<td height="45" rowspan="2" width="8%" class=r_tb><script>help("help_status.php#66");</script></td>
</tr>
<tr> 
	<td height="40" valign="top" colspan="6" class=l_tb><?=$m_title_desc?></td>
</tr>
</table>

<table width=100% border=0 cellspacing=0 cellpadding=0>
<tr>
	<td colspan=6 class=title_tb><?=$m_napt_active_session_lists?></td>
</tr>
<tr bgcolor="#b7dcfb"> 
	<td width=15% class=l_tb><?=$m_protocol?></td>
	<td width=20% class=l_tb><?=$m_sip?></td>
	<td width=15% class=l_tb><?=$m_sport?></td>
	<td width=20% class=l_tb><?=$m_dip?></td>
	<td width=15% class=l_tb><?=$m_dport?></td>
<?
for("/runtime/stats/naptsession")
{
	$source_ip=query("srcip");
	if($source_ip==$srcip)
	{
		echo "<tr><td class=l_tb>";
		map(tcp,"1",TCP,*,UDP);
		echo "</td>";
		
		echo "<td class=l_tb>".$source_ip."</td>";
		echo "<td class=l_tb>".query("sport")."</td>";
		echo "<td class=l_tb>".query("dstip")."</td>";
		echo "<td class=l_tb>".query("dport")."</td></tr>";
	}
}
?>
</table> 
<?require("/www/comm/bottom.php");?>
