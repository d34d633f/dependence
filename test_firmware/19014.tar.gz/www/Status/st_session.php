<?
/* vi: set sw=4 ts=4: */
require("/www/auth/only_allow_admin.php");
$MSG_FILE="st_session.php";
$reload=query("/tmp/reloadSession");
if($reload!="1")
{
	$NextUrl="st_session.xgi?set/runtime/stats/naptsession=1";
	set("/tmp/reloadSession", "1");
	require("/www/sys/refresh.php");
	exit;
}
else
{
	del("/tmp/reloadSession");
}

$apply_name="st_session.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
?>

<script language="JavaScript">
var tcpcount="<?query("/runtime/stats/tcpsession");?>";
var udpcount="<?query("/runtime/stats/udpsession");?>";
// natp
// tcp, srcip, sport, dstip, dport, time
dataList=[<?
$tcp_session=0;
$udp_session=0;
$num=0;

for("/runtime/stats/naptsession"){$num++;}
for("/runtime/stats/naptsession")
{
	$tcp=query("tcp");
	if($tcp=="1")	{$tcp_session++;}
	else		{$udp_session++;}
	echo "['".$tcp."','".query("srcip")."','".query("sport")."','".
		query("dstip")."','".query("dport")."','".query("time")."']";
	if($#!=$num){echo ",\n";}
}
?>];

var TCPSession = "<?=$tcp_session?>";
var UDPSession = "<?=$udp_session?>";

function generateHTML()
{
	var str=new String("");
	//assign nx3 2D array.
	var list= new Array(<?=$num?>);
	for(i=0;i<parseInt("<?=$num?>", [10]);i++)	list[i]=new Array(3);
	
	var meet=false;
	var list_len=0;

	// find out all diffrent ip and list them into list[][];
	// list[j][0]: srcip,	list[j][1]: tcp num,	list[j][2]: udp num
	if(dataList.length!=0)
	{
		list[0][0]=dataList[0][1];	//source ip
		list[0][1]=0;			//init tcp sum
		list[0][2]=0;			//init udp sum
		list_len++;

		// find out all diffrent ip and list them into list[][];
		for(var i=1; i<parseInt("<?=$num?>", [10]);i++)
		{
			meet=false;
			for(j=0;j<list_len;j++)
			{
				if(dataList[i][1]!=list[j][0])	continue;
				else	{meet=true;	break;}
			}
			if(meet==false)
			{
				list[list_len][0]=dataList[i][1];	//source ip
				list[list_len][1]=0;			//init tcp sum
				list[list_len][2]=0;			//init udp sum
				list_len++;
			}
		}
		// count the tcp/udp number in the same source ip
		for(i=0; i<list_len;i++)
		{
			for(j=0;j<dataList.length;j++)
			{
				if(list[i][0]==dataList[j][1])
				{
					if(dataList[j][0]=="1")	list[i][1]++;	//tcp
					else			list[i][2]++;	//udp
				}
			}
		}
	}

	// napt session
	str+="<table width='<?=$width_tb?>' border=0 cellpadding=0 cellspacing=0>";
	str+="<tr><td colspan=3 bgcolor=#CCCCCC><?=$m_napt_session?></td></tr>";
	str+="<tr>";
	str+="	<td width=25% height=25 class=br_tb><?=$m_tcp_session?></td>";
	str+="	<td width=20></td>";
	str+="	<td height=25 class=l_tb>"+TCPSession+"</td>";
	str+="</tr>";
	str+="<tr>";
	str+="	<td height=25 class=br_tb><?=$m_udp_session?></td>";
	str+="	<td></td>";
	str+="	<td height=25 class=l_tb>"+UDPSession+"</td>";
	str+="</tr>";
	str+="<tr>";
	str+="	<td height=25 class=br_tb><?=$m_total?></td>";
	str+="	<td></td>";
	
	if(parseInt(TCPSession, [10]) || parseInt(UDPSession, [10]))
		str+="<td height=25 class=l_tb>"+(parseInt(TCPSession, [10])+parseInt(UDPSession, [10]))+"</td></tr>";
	else
		str+="<td height=25 class=l_tb>"+0+"</td></tr>";
	str+="</table>";
	
	// active session list
	str+="<table width='<?=$width_tb?>' border=0 cellpadding=0 cellspacing=0>";
	str+="<tr><td colspan=4 bgcolor=#CCCCCC class=l_tb><?=$m_active_session?></td></tr>";
	str+="<tr bgcolor=#b7dcfb>";
	str+="<td width=25% class=l_tb><?=$m_ip_addr?></td>";
	str+="<td width=25% class=l_tb><?=$m_tcp_session?></td>";
	str+="<td width=25% class=l_tb><?=$m_udp_session?></td>";
	str+="<td width=25%></td>";
	str+="</tr>";
	
	//for debug
	var debug=false;
	dbg="";
	
	for (var i=0; i<list_len; i++)
	{
		str+="<tr><td width=25% class=l_tb>"+list[i][0]+"</td>";
		str+="<td width=25% class=l_tb>"+list[i][1]+"</td>";
		str+="<td width=25% class=l_tb>"+list[i][2]+"</td>";
		
		str+="<td width=25% class=c_tb>";
		str+="<input type=button name=detail value=<?=$m_detail?> onClick=\"window.location.href='st_naptinfo.php?srcip="+list[i][0]+"'\">";
		str+="</td></tr>";
		if(debug)	dbg+="list["+i+"][srcip,tcpsum,udpsum]=["+list[i][0]+","+list[i][1]+","+list[i][2]+"]\n";
	}
	str+="</table>";
	
	if(debug)	alert(dbg);

	document.writeln(str);
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>

<?require("/www/comm/middle.php");?>
          
<form id=frmNatpInfo>
<table width=<?=$width_tb?> border=0 cellpadding=0 cellspacing=0>
<tr><td height=10 colspan=2 class=title_tb valign=top><?=$m_title?></td></tr>
<tr valign="top">
	<td height=30 colspan=2 class=l_tb>
	<?=$m_title_desc?>
	</td>
</tr>
<tr>
	<td height=35 valign=middle align=left> 
	<input type=button name=refresh value=<?=$m_refresh?> onClick="self.location.reload()">
	</td>
	<td class=r_tb><script>help("help_status.php#66");</script></td>
</tr>
</table>
<script language="JavaScript">generateHTML();</script>
</form>
<?require("/www/comm/bottom.php");?>
