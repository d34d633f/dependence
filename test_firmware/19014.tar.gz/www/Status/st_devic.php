<? /* vi: set sw=4 ts=4: */
$MSG_FILE="st_device.php";
anchor("/runtime/wan/inf:1");
if(query("connectstatus")!="connected")
{
	if($try_refresh=="")
	{
		$other_meta="<META HTTP-EQUIV=Refresh CONTENT=\"3;URL=st_devic.php?try_refresh=1\">";
	}
	else if($try_refresh<3)
	{
		$try_refresh++;
		$other_meta="<META HTTP-EQUIV=Refresh CONTENT=\"3;URL=st_devic.php?try_refresh=".$try_refresh."\">";
	}
}
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
$table_bg="#CCCCCC";

$m_null_ip="0.0.0.0";

anchor("/runtime/wan/inf:1");
if (query("connectstatus") == "connected")
{
	anchor("/runtime/wan/inf:1/");
	$wanstatus = $m_connected;
	$wanipaddr = query("ip");
	$wansubnet = query("netmask");
	$wangateway= query("gateway");
	$wandns = query("primarydns")."  ".query("secondarydns");
}
else
{
	$wanstatus = $m_disconnected;
	$wanipaddr = $m_null_ip;
	$wansubnet = $m_null_ip;
	$wangateway= $m_null_ip;
	$wandns = $m_null_ip;
}

if ($user == "admin" && $passwd == query("/sys/user:1/password"))
{ $ADMIN=1; } else { $ADMIN=0; }

$wanmode = query("/wan/rg/inf:1/mode");
if ($wanmode == 1)
{
	$modeStr = $m_static_ip;
	$statusStr = "";
	$doconnect = "";
	$dodisconnect = "";
}
else if ($wanmode == 2)
{
	$modeStr = $m_dhcp_client;
	$statusStr = $wanstatus;
	$doconnect = $m_dhcp_renew;
	$dodisconnect = $m_dhcp_release;
}
else if ($wanmode == 3)
{
	$modeStr = $m_pppoe;
	$statusStr = $wanstatus;
	$doconnect = $m_connect;
	$dodisconnect = $m_disconnect;
}
else if ($wanmode == 4)
{
	$modeStr = $m_pptp;
	$statusStr = $wanstatus;
	$doconnect = $m_connect;
	$dodisconnect = $m_disconnect;
}
else if ($wanmode == 5)
{
	$modeStr = $m_l2tp;
	$statusStr = $wanstatus;
	$doconnect = $m_connect;
	$dodisconnect = $m_disconnect;
}
if(query("/lan/dhcp/server/enable")==1)	{$dhcp_en=$m_enabled;}
else									{$dhcp_en=$m_disabled;}

/* wireless */
$no_jumpstart=query("/function/no_jumpstart");
anchor("/wireless");
$wlan_en	= query("enable");
$wep_len	= query("keylength");
$js_enable	= query("jumpstart/enable");
$js_phase	= query("jumpstart/phase");

if($js_enable==1 && $js_phase==1)	{$ssid=queryjs("/runtime/wireless/ssid"); }
else								{$ssid=queryjs("ssid");}
//if($wlan_en==0)						{$ssid=queryjs("ssid");}

if($js_enable == 1)	{	$jumpstart = $m_enabled;		$jsstatus = $m_protocol.$js_phase;}
else				{	$jumpstart = $m_disabled;	$jsstatus = $m_disabled;}

$str_sec = "";
//if ($wlan_en == 1)
//{
	$auth		= query("authentication");
	$sec		= query("wpa/wepmode");
//	$wlan_mode	= query("wlmode");

	if (query("autochannel")!=1 || $wlan_en==0) { $channel = query("channel"); }
	else { $channel = query("/runtime/stats/wireless/channel"); }
/*
	if ($auth==0)		{ $str_sec = "OPEN"; }
	else if ($auth==1)	{ $str_sec = "Shared Key"; }
	else if ($auth==4)	{ $str_sec = "WPA2-EAP"; }
	else if ($auth==5)	{ $str_sec = "WPA2-PSK"; }
	else if ($auth==6)	{ $str_sec = "WPA/WPA2-EAP"; }
	else if ($auth==7)	{ $str_sec = "WPA/WPA2-PSK"; }
	else if ($auth==8)	{ $str_sec = "802.1X"; }
*/
	if ($js_enable==1 && $js_phase==1)
	{
		$str_sec = $str_sec." ".$m_disabled;
	}
	else
	{
		if ($sec==1)		{ $str_sec = $str_sec." ".$wep_len." ".$m_bits; }
		else if ($sec==2)	{ $str_sec = $str_sec." ".$m_tkip; }
		else if ($sec==3)	{ $str_sec = $str_sec." ".$m_aes; }
		else if ($sec==4)	{ $str_sec = $str_sec." ".$m_cipher_auto; }
		else 				{ $str_sec = $str_sec." ".$m_disabled; }
	}
/*}
else
{
	$channel = "N/A (Wireless is off)";	
}
*/

?>

<script language="JavaScript">

function opentp()
{
	newwin=window.open("st_tp.xgi?set/runtime/switch/getlinktype=1","tp","scrollbars=yes,resizable=yes,width=490,height=590");
	newwin.moveTo(300,0);
	newwin.focus();
}
function shortTime()
{
	t="<?query("/runtime/sys/uptime");?>";

	var str=new String("");
	var tmp=parseInt(t, [10]);
	var sec=0,min=0,hr=0,day=0;
	sec=t % 60;  //sec
	min=parseInt(t/60, [10]) % 60; //min
	hr=parseInt(t/(60*60), [10]) % 24; //hr
	day=parseInt(t/(60*60*24), [10]); //day

	if(day>=0 || hr>=0 || min>=0 || sec >=0)
		str=(day >0? day+" <?=$m_days?>, ":"0 <?=$m_days?>, ")+(hr >0? hr+":":"00:")+(min >0? min+":":"00:")+(sec >0? sec :"00");
	else
		str="<?=$m_expired?>";
	return str;
}
function doConnect()
{
	self.location.href="st_devic.xgi?set/runtime/wan/inf:1/connect=1"
}

function doDisconnect()
{
	self.location.href="st_devic.xgi?set/runtime/wan/inf:1/disconnect=1"
}

</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<?require("/www/comm/middle.php");?>
<form method=GET>
<table width=100% border=0 cellspacing=2 cellpadding=0>
<tr>
	<td height=15 width=50% class=title_tb><?=$m_device_infor?>
<?
if($ADMIN=="1")
{
	echo "<br> (<a href=\"javascript:opentp();\"><font class=l_tb>".$m_view_network_topology."</font></a>)\n";
}
?>
	</td>
	<td width=50% class=br_tb valign=top>
		<font color=blue>
		<?=$m_system_uptime?><script>document.write(shortTime());</script>
		</font>
	</td>
</tr>
</table>
<table width="<?=$width_tb?>" border=0 cellspacing=2 cellpadding=0>
<!--  <script language="JavaScript">genHTML();</script> -->

<tr><td colspan=2 height=20 class=title_black><?=$m_firmware_version?><?query("/runtime/sys/info/firmwareversion");?></td></tr>

<tr bgcolor='<?=$table_bg?>'><td colspan=2 class=l_tb><?=$m_lan?></td></tr>
<tr>
	<td width=30% height=25 class=br_tb><?=$m_mac_addr?>&nbsp;</td>
	<td width=70% height=25 class=l_tb><?query("/runtime/sys/info/lanmac");?></td>
</tr>
<tr><td class=br_tb><?=$m_ip_addr?>&nbsp;</td>	<td class=l_tb><?query("/lan/ethernet/ip");?></td></tr>
<tr><td class=br_tb><?=$m_subnet_mask?>&nbsp;</td>	<td class=l_tb><?query("/lan/ethernet/netmask");?></td></tr>
<tr><td class=br_tb><?=$m_dhcp_server?>&nbsp;</td>	<td class=l_tb><?=$dhcp_en?></td></tr>

<tr><td colspan=2 bgcolor='<?=$table_bg?>' class=l_tb><?=$m_wan?></td></tr>
<tr><td class=br_tb><?=$m_mac_addr?>&nbsp;</td>	<td class=l_tb><?query("/runtime/wan/inf:1/mac");?></td></tr>
<tr>
	<td class=br_tb valign=top><?=$m_connection?>&nbsp;</td>
	<td class=l_tb><?
	echo $modeStr." ".$statusStr."<br>";
	if ($ADMIN==1 && $doconnect!="" && $dodisconnect!="")
	{
		echo "<input type=button onClick=doConnect(); value='".$doconnect."'>&nbsp;";
		echo "<input type=button onClick=doDisconnect(); value='".$dodisconnect."'>";
	}
	?></td>
</tr>

<tr><td class=br_tb><?=$m_ip_addr?>&nbsp;</td>		<td class=l_tb><?=$wanipaddr?></td></tr>
<tr><td class=br_tb><?=$m_subnet_mask?>&nbsp;</td>		<td class=l_tb><?=$wansubnet?></td></tr>
<tr><td class=br_tb><?=$m_def_gw?>&nbsp;</td>	<td class=l_tb><?=$wangateway?></td></tr>
<tr><td class=br_tb><?=$m_dns?>&nbsp;</td>				<td class=l_tb><?=$wandns?></td></tr>
<tr><td>&nbsp;</td></tr>

<?if($no_jumpstart=="1"){echo "<!--\n";}?>
<tr><td colspan=2 bgcolor='<?=$table_bg?>' class=l_tb><?=$m_wireless_jumpstart?></td></tr>
<tr><td class=br_tb><?=$m_jumpstart?>&nbsp;</td>		<td class=l_tb><?=$jumpstart?></td></tr>
<tr><td class=br_tb><?=$m_status?>&nbsp;</td>			<td class=l_tb><?=$jsstatus?></td></tr>
<tr><td>&nbsp;</td></tr>
<?if($no_jumpstart=="1"){echo "-->\n";}?>

<tr><td colspan=2 bgcolor='<?=$table_bg?>' class=l_tb><?=$m_wireless?></td></tr>
<tr><td class=br_tb><?=$m_ssid?>&nbsp;</td>				<td class=l_tb><script>echosc('<?=$ssid?>');</script></td></tr>
<tr><td class=br_tb><?=$m_channel?>&nbsp;</td>			<td class=l_tb><?=$channel?></td></tr>
<tr><td class=br_tb><?=$m_encryption?>&nbsp;</td>		<td class=l_tb><?=$str_sec?></td></tr>
<tr><td height=25>&nbsp;</td></tr>

<tr><td colspan=2 class=r_tb><script>help("help_status.php#15");</script></td></tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
