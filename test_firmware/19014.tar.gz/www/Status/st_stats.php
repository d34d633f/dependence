<? 
/* vi: set sw=4 ts=4: */
$MSG_FILE="st_stats.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");?>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<?require("/www/comm/middle.php");?>
<form>
<table width="<?=$width_tb?>" border=0 cellpadding=0 height=112 cellspacing=0>
<tr><td height=10 colspan=3 class=title_tb><?=$m_title?></td></tr>
<tr valign="top">
	<td height=30 colspan=3 class=l_tb><?=$m_title_desc?> 
	</td>
</tr>
<tr>
	<td colspan=2 height=35 valign=middle align=left>
	<input type=button name=refresh value=<?=$m_refresh?> onClick="window.location.href='st_stats.php'">
	<input type=button name=reset value=<?=$m_reset?> onClick="<?
	if($user=="admin" && query("/sys/user:1/password")==$passwd)
	{
		echo "window.location.href='st_stats.xgi?set/runtime/stats/resetCounter=1'";
	}
	else
	{
		echo "alert('".$a_only_admin_account_can_clear_the_statistics."');";
	}
	?>">
	</td>
	<td height=35 valign=top class=r_tb><script>help("help_status.php#17");</script></td>
</tr>
<tr bgcolor=#b7dcfb>
	<td width=30% height=2 class=c_tb><?=$m_interface?></td>
	<td width=35% height=2 class=l_tb><?=$m_receive?></td>
	<td width=35% height=2 class=l_tb><?=$m_transmit?></td>
</tr>
<tr><td width=111 height=20 class=bc_tb><?=$m_wan?></td>
<td height=20 class=l_tb><?map("/runtime/stats/wan/inf:1/rx/packets","",0);?> <?=$m_packets?></td>
<td height=20 class=l_tb><?map("/runtime/stats/wan/inf:1/tx/packets","",0);?> <?=$m_packets?></td></tr>

<tr><td width=111 height=20 class=bc_tb><b><?=$m_lan?></b></td>
<td height=20 class=l_tb><?map("/runtime/stats/lan/rx/packets","",0);?> <?=$m_packets?></td>
<td height=20 class=l_tb><?map("/runtime/stats/lan/tx/packets","",0);?> <?=$m_packets?></td></tr>

<tr><td width=111 height=20 class=bc_tb><b><?=$m_wireless?></b></td>
<td height=20 class=l_tb><?map("/runtime/stats/wireless/rx/packets","",0);?> <?=$m_packets?></td>
<td height=20 class=l_tb><?map("/runtime/stats/wireless/tx/packets","",0);?> <?=$m_packets?></td></tr>

</table>
</form>
<?require("/www/comm/bottom.php");?>
