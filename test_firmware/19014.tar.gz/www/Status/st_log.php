<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="st_log.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
$row_num="10";	//the row number per page
?>
<SCRIPT language=javascript>
//disable ConfigGetArray now
dataLists=[<?inclog("[\"%0\",\"%1\"],","/var/log/messages");?>["",""]];

var d_len=dataLists.length-1;
var row_num=parseInt("<?=$row_num?>", [10]);
var max=(d_len%row_num==0? d_len/row_num : parseInt(d_len/row_num, [10])+1);

function showSysLog()
{
	var str=new String("");
	var f=document.getElementById("frmLog");
	var p=parseInt(f.curpage.value, [10]);

	if (max==0 || max==1)
	{
		f.Pp1.disabled=true;
		f.Np1.disabled=true;
	}
	else
	{
		if (p==1)
		{
			f.Pp1.disabled=true;
			f.Np1.disabled=false;
		}
		if (p==max)
		{
			f.Pp1.disabled=false;
			f.Np1.disabled=true;
		}
		if (p > 1 && p < max)
		{
			f.Pp1.disabled=false;
			f.Np1.disabled=false;
		}
	}

	if (document.layers) return true;
	{
		str+="<table border=0 cellSpacing=0 cellPadding=0 width=100%>";
		str+="<tr><td colspan=2 class=l_tb><?=$m_page?> "+p+" <?=$m_of?> "+max+"</td></tr>";
		str+="<tr bgcolor=#B7DCFB>"
		str+="<td width=24% class=c_tb><?=$m_time?></td>";
		str+="<td width=76% class=c_tb><?=$m_message?></td>";
		str+="</tr>";
		
		for (var i=((p-1)*row_num);i < p*row_num;i++)
		{
			if (i>=dataLists.length) break;
			str+="<tr>";
			str+="<td width=24% class=l_tb>"+dataLists[i][0]+"</td>";
			str+="<td width=76% class=l_tb>"+dataLists[i][1]+"</td>";
			str+="</tr>";
		}
		str+="</table>";
	}

	if (document.all)			document.all("sLog").innerHTML=str;
	else if (document.getElementById)	document.getElementById("sLog").innerHTML=str;
}

function ToPage(p)
{
	if (document.layers)
	{
		alert("<?=$a_your_browser_is_not_support_this_function?><?=$a_upgrade_the_browser?>");
	}
	if (dataLists.length==0) return;
	var f=document.getElementById("frmLog");

	switch (p)
	{
	case "0":
		f.curpage.value=max;
		break;
	case "1":
		f.curpage.value=1;
		break;
	case "-1":
		f.curpage.value=(parseInt(f.curpage.value, [10])-1 <=0? 1:parseInt(f.curpage.value, [10])-1);
		break;
	case "+1":
		f.curpage.value=(parseInt(f.curpage.value, [10])+1 >=max? max:parseInt(f.curpage.value, [10])+1);
		break;
	}
	showSysLog();
}

function doClear()
{
<?
if($user=="admin" && query("/sys/user:1/password")==$passwd)
{
	echo "var str=new String(myFilename);";
	echo "str+=\"set/runtime/syslog/clear=1\";";
	echo "self.location.href=str;";
}
else
{
	echo "alert('".$a_only_admin_account_can_clear_logs."');";
}
?>
}

</SCRIPT>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload="showSysLog()">
<?require("/www/comm/middle.php");?>
<form method=POST id=frmLog>
<input type=hidden name=curpage value="1">
<table width="<?=$width_tb?>" border=0 cellspacing=0 cellpadding=0 height=42>
<tr>
	<td height=12 class=title_tb><?=$m_title?></td>
</tr>
<tr>
	<td height=40 valign="top" class=l_tb><?=$m_title_desc?>
	</td>
</tr>
<tr>
	<td><table width=100% cellspacing=2 cellpadding=2>
	<tr>
		<td height=10>
		<input type=button value="<?=$m_first_page?>" name=Fp1 onClick=ToPage("1")>
		<input type=button value="<?=$m_last_page?>" name=Lp1 onClick=ToPage("0")>
		<input type=button value="<?=$m_previous?>" name=Pp1 onClick=ToPage("-1")>
		<input type=button value="<?=$m_next?>" name=Np1 onClick=ToPage("+1")>
		<input type=button value="<?=$m_clean?>" name=clear onclick="doClear()">
		<input type=button value="<?=$m_log_settings?>" name=setting onClick="window.location.href='st_log_settings.php'">
		<input type=button value="<?=$m_refresh?>" onClick="javascript:self.location.href='st_log.php'">
		<td>
		<td class=r_tb><script>help("help_status.php#16");</script></td>
	</tr>
	</table>
	</td>
</tr>
<tr><td class=l_tb><div id=sLog></div></td></tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
