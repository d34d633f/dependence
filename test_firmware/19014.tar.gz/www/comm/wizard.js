<? /* vi: set sw=4 ts=4: */
$MSG_FILE="wizard.php";
require("/www/comm/lang_msg.php");
?>
function ExitWizard()
{
	if (confirm("<?=$a_exit_wizard?>")) self.parent.close();
}
