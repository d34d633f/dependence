<? /* vi: set sw=4 ts=4: */ 
$MSG_FILE="middle.php";
require("/www/comm/lang_msg.php");
?>
<!--*****************************************middle.php start*****************************************************-->
<table width=75% border=0 cellspacing=0 cellpadding=0 align=center>
<!-- Logo //-->
<tr>
	<td align=center><img src="<?=$g_home_01?>" width=765 height=95 usemap=#Map2 border=0></td>
</tr>
<!-- Logo //-->
<tr>
	<td>
	<table width=765 border=0 cellpadding=0 cellspacing=0 align=center>
	<!-- left menu lists //--><script>genTopMenu();</script><!-- left menu lists //-->
	<tr>
		<td width=20 background=../graphic/down_01.gif></td>
		<td width=133 height=42 bgcolor=#CCCCCC valign=top>
		<!-- left menu lists //--><script>genLeftMenu();</script><!-- left menu lists //-->
		</td>
		<td rowspan=2 width=25 background=../graphic/down_03.jpg></td>
		<td width=21 background=../graphic/down_14.gif></td>
		<td width=522 valign=top>
		<!-- main contents //-->
<!--*****************************************middle.php end*****************************************************-->
