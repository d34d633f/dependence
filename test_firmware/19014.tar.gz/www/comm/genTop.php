<?if($no_chk_auth_again!="1"){require("/www/auth/chk_auth.php");}?>
<HTML>
<HEAD>
<TITLE><?query("/sys/hostname");?></TITLE>
<link rel="stylesheet" href="../comm/webCSS.css" type="text/css">
<META HTTP-EQUIV=Content-Type CONTENT="no-cache">
<META HTTP-EQUIV=Content-Type CONTENT="text/html; charset=iso-8859-1">
<?=$other_meta?>
</HEAD>
<script>
function doLogout()
{
	<?
	if($FROM_WIZARD=="1")
	{
		echo "self.parent.close();";
	}
	else
	{
		echo "self.location.href=\"/auth/logout.php\";\n";
	}
	?>
}
setTimeout("doLogout()",<?map("/sys/sessiontimeout","","300");?>*1000);
</script>
