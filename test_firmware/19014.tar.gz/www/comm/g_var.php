<?
/* vi: set sw=4 ts=4: */
if ($global_variable_required != "true")
{
	$global_variable_required = "true";

	$__LANG		= "en";
	$max_rule	= 32;
	$max_pat	= 32;

	$index_page="/Status/st_devic.php";

	//require("/www/locale/".$__LANG."/g_var.php");

	// for default password
	$DEF_PASSWORD="WDB8WvbXdHtZyM8";

	//for table
	$width_tb	= "100%";
	$sel_color	= "#FFFF00";
	$list_color	= "#b7dcfb";

	//index of rules in Advanced tables.
	$index_en	= "0";

	/* Who is using this varaible, please come to me.  David. */
	//for apply message
	//$apply_msg	= $m_apply_successfully;
}
?>
