<? /* vi: set sw=4 ts=4: */ 
$MSG_FILE="htm.php";
require("/www/comm/lang_msg.php");
?>
/**************************************************** htm.php start **************************************************/
function apply(submit)
{
<?
$fmt="<img src=".$g_apply_p." width=51 height=52 border=0>";

if($user=="admin" && query("/sys/user:1/password")==$passwd)
{
	echo "	if (submit=='')\n";
	echo "		document.write('<a href=javascript:doSubmit()>".$fmt."</a>')\n";
	echo "	else\n";
	echo "		document.write('<a href=javascript:'+submit+'>".$fmt."</a>')\n";
}
else
{
	echo "	document.write('<a href=javascript:self.location.href=\"../sys/relogin.php\">".$fmt."</a>');\n";
}
?>
}

function cancel(init)
{
	if (init=="")
		document.write("<a href=javascript:doReset()><img src=<?=$g_cancel_p?> width=51 height=52 border=0></a>")
	else
		document.write("<a href=javascript:"+init+"><img src=<?=$g_cancel_p?> width=51 height=52 border=0></a>")
}

function help(link)
{
	document.write("<a href='/locale/<?=$__LANG?>/Help/"+link+"' target=_blank><img src=<?=$g_help_p?> width=36 height=52 border=0></a></a>")
}

// following function is for wizard page.
function wizardhead()
{
	document.write("<img src=<?=$g_ww?>>");
}

function next(link)
{
	if(link=="") 
		document.write("<a href=javascript:doNext()><img src=<?=$g_next_p?> width=36 height=52 border=0></a>&nbsp;")
	else
		document.write("<a href="+link+"><img src=<?=$g_next_p?> width=36 height=52 border=0></a>&nbsp;")
}

function back(link)
{
	document.write("<a href="+link+"><img src=<?=$g_back_p?> width=36 height=52 border=0></a>&nbsp;")
}

function exit()
{
	document.write("<a href=javascript:ExitWizard()><img src=<?=$g_exit_p?> width=36 height=52 border=0></a>&nbsp;")
}
function submit()
{
	document.write("<a href=javascript:doSubmit()><img src=<?=$g_exit_p?> width=36 height=52 border=0></a>&nbsp;")
}
function restart()
{
	document.write("<a href=javascript:doSubmit()><img src=<?=$g_restart_p?> width=51 height=52 border=0></a>&nbsp;")
}
/**************************************************** htm.php end **************************************************/
