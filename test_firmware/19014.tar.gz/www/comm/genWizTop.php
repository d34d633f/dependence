<? /* vi: set sw=4 ts=4: */
$FROM_WIZARD="1";
require("/www/auth/chk_auth.php");

//Link the message of h_wizxxxxxx.php first.
require("/www/comm/lang_msg.php");

//Link the message for this file.
$MSG_FILE="genWizTop.php";
require("/www/comm/lang_msg.php");
$no_chk_auth_again="1";
require("/www/comm/genTop.php");
$width_wiz=450;
$height_wiz=155;
$margin_wiz="topmargin=0 leftmargin=0";
$top_pic="<img src='".$g_ww."' width=".$width_wiz." height=34>";
$table="<table border=0 cellspacing=0 cellpadding=0 height=370 width=".$width_wiz.">";
?>
<script>
<?
require("/www/comm/htm.php");
require("/www/comm/wizard.js");
require("/www/comm/g_var.php");
require("/www/comm/comm.php");
?>
</script>
<body text=#000000 <?=$margin_wiz?> bgcolor=#cccccc background="../graphic/ww_bk.jpg" <?=$onload?>>
