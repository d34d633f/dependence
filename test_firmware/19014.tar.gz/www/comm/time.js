<? /* vi: set sw=4 ts=4: */
$MSG_FILE="time.php";
require("/www/comm/lang_msg.php");
?>
// common array
var week=[<?=$m_week_list?>];
var month=[<?=$m_month_list?>];

function parseTime(t)
{
	var str=new String("");
	var tmp=parseInt(t, [10]);
	var sec=0,min=0,hr=0,day=0;
	sec=t % 60;  //sec
	min=parseInt(t/60, [10]) % 60; //min
	hr=parseInt(t/(60*60), [10]) % 24; //hr
	day=parseInt(t/(60*60*24), [10]); //day

	if(t>0)
		str=(day >0? day+" <?=$m_days?> ":"")+(hr >0? hr+" <?=$m_hrs?> ":"")+(min >0? min+" <?=$m_mins?> ":"")+(sec >0? sec+" <?=$m_secs?> ":"");
	else
		str="<?=$m_expired?>";
	return str;
}
function day(start,end)
{
	document.write(week[start]+"~"+week[end]);
}
