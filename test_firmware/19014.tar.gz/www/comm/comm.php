<? /* vi: set sw=4 ts=4: */
$MSG_FILE="comm.php";
require("/www/comm/lang_msg.php");
?>
/**************************************** comm.php start **************************************************/
// this function is used to check if the inputted string is blank or not.
function isBlank(s)
{
	var i=0;
	for (i=0; i < s.length;i++)
	{
		if (s.charCodeAt(i)!=32) break;
	}
	if (i==s.length) return true;

	return false;
}

function getIP(ip)
{
	var myIP=new Array();

	if ( ip != "")
	{
		var tmp=ip.split(".");
		for (var i=1;i <= tmp.length;i++)
		{
			myIP[i]=tmp[i-1];
		}
		myIP[0]=ip;
	}
	else
	{
		for (var i=1;i <= 4;i++)
		{
			myIP[i]="";
		}
		myIP[0]="";
	}
	return myIP;
}

function check_ip_interval(separate_ip)
{
	var tmp_separate_ip=parseInt(separate_ip, [10]);
	if (separate_ip<255 && separate_ip>0) return true;
	return false;
}


function checkMask(str, num)
{
	d = getDigit(str,num);
	if (!( d==0 || d==128 || d==192 || d==224 || d==240 || d==248 || d==252 || d==254 || d==255 ))	return false;
	return true;
}

function checkSubnet(ip, mask, client)
{
	ip_d = getDigit(ip, 1);
	mask_d = getDigit(mask, 1);
	client_d = getDigit(client, 1);
	if ( (ip_d & mask_d) != (client_d & mask_d ) )	return false;

	ip_d = getDigit(ip, 2);
	mask_d = getDigit(mask, 2);
	client_d = getDigit(client, 2);
	if ( (ip_d & mask_d) != (client_d & mask_d ) )	return false;

	ip_d = getDigit(ip, 3);
	mask_d = getDigit(mask, 3);
	client_d = getDigit(client, 3);
	if ( (ip_d & mask_d) != (client_d & mask_d ) )	return false;

	ip_d = getDigit(ip, 4);
	mask_d = getDigit(mask, 4);
	client_d = getDigit(client, 4);
	if ( (ip_d & mask_d) != (client_d & mask_d ) )	return false;

	return true;
}

function changeAddress(bKeyCode, eventCode, KeyCode, field, fieldMask)
{
	if(bKeyCode=="1")
	{
		if(eventCode==KeyCode && field.value!="" && fieldMask.value=="")
		fieldMask.value=getNetMask(field.value);
	}
	else
	{
		if(field.value!="" && fieldMask.value=="")
		fieldMask.value=getNetMask(field.value);
	}
}

function getNetMask(IP)
{
	var IP1=getDigit(IP,1);
	if(IP1 < 128)					return "255.0.0.0";
	else if(IP1 > 127 && IP1 < 191)	return "255.255.0.0";
	else							return "255.255.255.0";
}

function getNetAddress(IP, Mask)
{
	var IP1=getDigit(IP,1);
	var IP2=getDigit(IP,2);
	var IP3=getDigit(IP,3);
	var IP4=getDigit(IP,4);
	var Mask1=getDigit(Mask,1);
	var Mask2=getDigit(Mask,2);
	var Mask3=getDigit(Mask,3);
	var Mask4=getDigit(Mask,4);
	var Oct1=IP1 &	Mask1;
	var Oct2=IP2 &	Mask2;
	var Oct3=IP3 &	Mask3;
	var Oct4=IP4 &	Mask4;
	return	Oct1+"."+Oct2+"."+Oct4+"."+Oct4;
}

function getBroadcast(IP, Mask)
{
	var IP1=getDigit(IP,1);
	var IP2=getDigit(IP,2);
	var IP3=getDigit(IP,3);
	var IP4=getDigit(IP,4);
	var Mask1=getDigit(Mask,1);
	var Mask2=getDigit(Mask,2);
	var Mask3=getDigit(Mask,3);
	var Mask4=getDigit(Mask,4);
	var Oct1=IP1 |	(Mask1 ^ 255);
	var Oct2=IP2 |	(Mask2 ^ 255);
	var Oct3=IP3 |	(Mask3 ^ 255);
	var Oct4=IP4 |	(Mask4 ^ 255);
	return	Oct1+"."+Oct2+"."+Oct4+"."+Oct4;
}

function validateKey(str)
{
	for (var i=0; i<str.length; i++)
	{
		if ( (str.charAt(i) >= '0' && str.charAt(i) <= '9') || (str.charAt(i) == '.' ) )	continue;
		return 0;
	}
	return 1;
}

function getDigit(str, num)
{
	i=1;
	if ( num != 1 )
	{
		while (i!=num && str.length!=0) 
		{
			if ( str.charAt(0) == '.' ) i++;
			str = str.substring(1);
		}
		if ( i!=num ) return -1;
	}
	for (i=0; i<str.length; i++) 
	{
		if ( str.charAt(i) == '.' )
		{
			str = str.substring(0, i);
			break;
		}
	}

	if ( str.length == 0) return -1;
	d = parseInt(str, [10]);
	return d;
}

function checkDigitRange(str, num, min, max)
{
	d = getDigit(str,num);
	if ( d > max || d < min ) return false;
	return true;
}

function validPort(port)
{
	var tmp_port=parseInt(port, [10]);
	if (tmp_port<=65535 && tmp_port >0) return true;

	alert("<?=$a_port_number_must_be_1_65535?>");

	return false;
}

function validMask(field, msg)
{
	if ( getDigit(field.value,5)>=0)
	{
		alert(msg+"<?=$a_value?>");
		field.focus();
		field.select();
		return false;
	}
	if ( !checkMask(field.value,1) || getDigit(field.value,1)=="0") 
	{
		alert(msg+"<?=$a_err_mask_in_1st_digit?>");
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	if ( !checkMask(field.value,2) )
	{
		alert(msg+"<?=$a_err_mask_in_2nd_digit?>");
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	if ( !checkMask(field.value,3) )
	{
		alert(msg+"<?=$a_err_mask_in_3rd_digit?>");
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	if ( !checkMask(field.value,4)  || getDigit(field.value,4)=="255")
	{
		alert(msg+"<?=$a_err_mask_in_4th_digit?>");
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	return true;
}

function checkIpAddr(field, msg)
{
	if ( validateKey(field.value) == 0)
	{
		alert(msg+"<?=$a_value_should_be_decimal_number?>");
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	if ( getDigit(field.value,5)>=0)
	{
		alert(msg+"<?=$a_value?>");
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	if ( !checkDigitRange(field.value,1,1,223) || getDigit(field.value,1)==127 )
	{
		alert(msg+"<?=$a_err_ip_range_in_1st_digit?>"); 
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	if ( !checkDigitRange(field.value,2,0,255) )
	{
		alert(msg+"<?=$a_err_ip_range_in_2nd_digit?>");
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	if ( !checkDigitRange(field.value,3,0,255) )
	{
		alert(msg+"<?=$a_err_ip_range_in_3rd_digit?>");
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	if ( !checkDigitRange(field.value,4,1,254) )
	{
		alert(msg+"<?=$a_err_ip_range_in_4th_digit?>");
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	return true;
}

function checkMaskAddr(field, Mask, msg)
{
	if ( getNetAddress(field.value, Mask)==field.value) {
		alert(msg+"<?=$a_value?> "+field.value+"<?=$a_is_reserved_for_network_host?>");
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	if ( getBroadcast(field.value, Mask)==field.value) {
		alert(msg+"<?=$a_value?> "+field.value+"<?=$a_is_reserved_for_broadcast?>");
		field.value = field.defaultValue;
		field.focus();
		return false;
	}
	return true;
}

// this function is used to check if the value "n" is a number or not.
function isNumber(n)
{
	if (n.length==0) return false;
	for (var i=0;i < n.length;i++)
	{
		if (n.charAt(i) < '0' || n.charAt(i) > '9') return false;
	}
	return true;
}

function checkMAC(m)
{
	if(m==":::::")	{ return false; }
	var allowChar="0123456789ABCEDF";

	m=m.toUpperCase();
	for (var i=0; i < m.length; i++)
	{
		if (allowChar.indexOf(m.charAt(i)) == -1) return false;
	}
	if (m.length==0) return false;
	return true;
}

function getMAC(m)
{
	var myMAC=new Array();
	if (m.search(":") != -1)	var tmp=m.split(":");
	else						var tmp=m.split("-");

	if ( m != "")
	{
		for (var i=1;i <= tmp.length;i++)
		{
			myMAC[i]=tmp[i-1];
		}
		myMAC[0]=m;
	}
	else
	{
		for (var i=0;i <= 6;i++)
		{
			myMAC[i]="";
		}
	}
	return myMAC;
}

function exeStr(shellPath)
{
	var str="";
	myShell = shellPath.split(";");
	for(i=0; i<myShell.length; i++)
	{
		str+="&"+"exeshell="+myShell[i];
	}
	return str;
}

function CheckUCS2(str)
{
	var strlen=str.length;
	if(strlen>0)
	{
		var c = '';
		for(var i=0;i<strlen;i++)
		{
			c = escape(str.charAt(i));
			if( c.charAt(0) == '%' && c.charAt(1)=='u')
				return true;
		}
	}
	return false;
}

function isIE()
{
	if (navigator.userAgent.indexOf("MSIE")>-1) return true;
	return false
}

function reduceIP(o_ip)
{
	if(o_ip=="") n_ip="";
//	else if (o_ip=="*") n_ip="";
	else
	{
		var n_ip="";
		var ip=getIP(o_ip);
		for(i=1;i<5;i++)
			ip[i]=parseInt(ip[i],[10]);
		n_ip=ip[1]+"."+ip[2]+"."+ip[3]+"."+ip[4];
		if(n_ip=="NaN.NaN.NaN.NaN") n_ip=o_ip;
	}
	return n_ip;
}

function echo(str){document.write(str);}

function echosc(str)
{
	str=str.replace(/</g,"&lt;");
	str=str.replace(/>/g,"&gt;");
	str=str.replace(/ /g,"&nbsp;");
	document.write(str);
}

function print_rule_count(count, max)
{
	document.write(count+" / "+max+" ( <?=$m_number?> / <?=$m_total?> )");
}

// return false if keyboard event is the character we want to filter.
function char_filter(evt)
{
	if (navigator.appName == 'Netscape')
	{
		if (evt.which == 0)  return true;							/* some control key. */
		if (evt.which == 8)  return true;							/* TAB */
		if (evt.which == 32) return true;							/* space */
		if (evt.which == 45) return true;							/* - */
		if (evt.which == 46) return true;							/* . */
		if (evt.which == 64) return true;							/* @ */
		if (evt.which == 95) return true;							/* _ */
		
		if (evt.which >= 48 && evt.which <= 57)  return true;		/* 0~9 */
		if (evt.which >= 65 && evt.which <= 90)  return true;		/* A~Z */
		if (evt.which >= 97 && evt.which <= 122) return true;		/* a~z */

		//if (evt.which < 33 || evt.which > 126) return false;
		return false;
	}
	else
	{
		if (evt.keyCode == 0)  return true;							/* some control key. */
		if (evt.keyCode == 8)  return true;							/* TAB */
		if (evt.keyCode == 32) return true;							/* space */
		if (evt.keyCode == 45) return true;							/* - */
		if (evt.keyCode == 46) return true;							/* . */
		if (evt.keyCode == 64) return true;							/* @ */
		if (evt.keyCode == 95) return true;							/* _ */
		
		if (evt.keyCode >= 48 && evt.keyCode <= 57)  return true;	/* 0~9 */
		if (evt.keyCode >= 65 && evt.keyCode <= 90)  return true;	/* A~Z */
		if (evt.keyCode >= 97 && evt.keyCode <= 122) return true;	/* a~z */
		
		//if (evt.keyCode < 33 || evt.keyCode > 126) return false;
		return false;
	}
	return true;
}
function chk_valid_char(str)
{
	var i;
	var character, char_ascii;

	for(i=0;i<str.length;i++)
	{
		character=str.charAt(i);
		char_ascii=str.charCodeAt(i);

		if(character ==' ') continue;
		if(character =='-') continue;
		if(character =='.') continue;
		if(character =='@') continue;
		if(character =='_') continue;
		if(character >='0' && character <= '9') continue;
		if(character >='a' && character <= 'z') continue;
		if(character >='A' && character <= 'Z') continue;

		return false;
	}
	return true;
}
function replace_html_sc(s)
{
	var s;
	s=s.replace(/&/g,"&amp;");
	s=s.replace(/</g,"&lt;");
	s=s.replace(/>/g,"&gt;");
	s=s.replace(/"/g,"&quot;");
	//s=s.replace(/'/g,"&apos;");
	s=s.replace(/'/g,"\\'");
	
	s=s.replace(/ /g,"&nbsp;");
	return s;
}
/**************************************** comm.php end **************************************************/
