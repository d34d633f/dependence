<?
require("/www/comm/g_var.php");
if($MSG_FILE!="")
{
	require("/www/locale/".$__LANG."/comm_msg.php");
	require("/www/locale/".$__LANG."/".$MSG_FILE);
}
?>
