<?
echo "<html><head>\n";
echo "<META HTTP-EQUIV=Content-Type CONTENT='no-cache'>\n";
echo "<META HTTP-EQUIV=Content-Type CONTENT='text/html; charset=iso-8859-1'>\n";
echo "<META HTTP-EQUIV=Refresh CONTENT='0; url=".$target_url."'>\n";
echo "</head></html>";
exit;
?>
