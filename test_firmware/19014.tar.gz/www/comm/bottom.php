<!-- ######################################################################################################### //-->
<!--**************************************bottom.php start*******************************************************-->
<!-- main contents //-->
		</td>
		<td width=19 background=../graphic/down_5F40.gif height=42></td>
		<td width=25 background="../graphic/down_11.gif"></td>
	</tr>
	<tr>
		<td colspan=7 align=left><img src=../graphic/2.jpg width=765 height=44></td>
	</tr>
	</table>
	</td>
</tr>
</table>
<!-- footer //-->
<map name=MapMap>
<area shape=rect coords=17,16,82,44 href="../Home/h_wizard.php" target=_self>
<area shape=rect coords=109,18,205,42 href="../Advanced/adv_virtual.php" target=_self>
<area shape=rect coords=232,19,289,46 href="../Tools/tools_admin.php" target=_self>
<area shape=rect coords=346,19,405,46 href="../Status/st_devic.php" target=_self>
<area shape=rect coords=455,18,501,47 href="../Help/help_men.php">
</map>
<map name=Map2>
<area shape=rect coords=13,11,153,62 href="<?query("/sys/url");?>" target=_blank>
</map>
<!-- footer //-->
</BODY>
</HTML>
<!--**************************************bottom.php end*******************************************************-->
