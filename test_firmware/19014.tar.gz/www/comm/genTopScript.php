<?
require("/www/comm/lang_msg.php");

echo "<script language=\"JavaScript\">\n";
require("/www/comm/comm.php");
require("/www/comm/genHTML.js");
require("/www/comm/htm.php");
echo "</script>\n";
?>
