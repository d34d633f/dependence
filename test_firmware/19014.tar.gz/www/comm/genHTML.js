<? /* vi: set sw=4 ts=4: */
$MSG_FILE="genHTML.php";
require("/www/comm/lang_msg.php");
?>
/****************************************** genHTML.js start *************************************************/
var filenameExp=/:\/\/\S*\/(\S*)\/(\S*).php\??/;
var result=document.location.href.match(filenameExp);
var myFilename=result[2]+".xgi?"; // we need the variable in all web pages;

// common array
var HomeList=[<?=$m_home_list?>];
var HomeUrl=["h_wizard.php","h_wireless_11g.php","h_wan.php","h_lan.php","h_dhcp.php"];
var AdvancedList=[<?=$m_advanced_list?>];
//var AdvancedUrl=["adv_virtual.php","adv_appl.php","adv_filters_ip.php","adv_filters_url.php","adv_firewall.php","adv_dmz.php","adv_ddns.php","adv_perform_11g.php"];
var AdvancedUrl=["adv_virtual.php","adv_appl.php","adv_filters_ip.php","adv_filters_url.php","adv_firewall.php","adv_dmz.php","adv_perform_11g.php"];
var ToolsList=[<?=$m_tools_list?>];
//var ToolsUrl=["tools_admin.php","tools_time.php","tools_system.php","tools_firmw.php","tools_misc.php","tools_vct.php"];
var ToolsUrl=["tools_admin.php","tools_time.php","tools_system.php","tools_firmw.php","adv_ddns.php","tools_misc.php","tools_vct.php"];
var StatusList=[<?=$m_status_list?>];
var StatusUrl=["st_devic.php","st_log.php","st_stats.php","st_wireless.php","st_session.php"];
var HelpList=[<?=$m_help_list?>];
var HelpUrl=["help_men.php"];

function genTopMenu()
{
	var str=new String("");
	var leftImage="up";
	var rightImage="up";
	if (result[1] == "<?=$m_home?>") leftImage="down";
	if (result[1] == "<?=$m_help?>") rightImage="down";


	str+="<tr>";
	str+="<td width=20 background=\"../graphic/down_01.gif\"></td>";
	str+="<td rowspan=2 width=133><img src=\"<?=$g_down_02?>\" width=133 height=75></td>";
	str+="<td width=25 background=\"../graphic/down_03.jpg\"></td>";
	str+="<td width=21><img src=\"../graphic/"+leftImage+"_04.jpg\" width=21 height=49></td>";
	str+="<td width=522><img src=\"../graphic/"+result[1]+"_05.jpg\" width=522 height=49 usemap=#MapMap border=0></td>";
	str+="<td width=19><img src=\"../graphic/"+rightImage+"_06.jpg\" width=19 height=49></td>";
	str+="<td width=25 background=\"../graphic/down_11.gif\"></td>";
	str+="</tr>";
	str+="<tr>";
	str+="<td width=20 background=\"../graphic/down_01.gif\"></td>";
	str+="<td width=25 background=\"../graphic/down_03.jpg\"></td>";
	str+="<td width=21 background=\"../graphic/down_14.gif\"></td>";
	str+="<td width=522 valign=top height=26></td>";
	str+="<td width=19><img src=\"../graphic/down_10.jpg\" width=19 height=26></td>";
	str+="<td width=25 background=\"../graphic/down_11.gif\"></td>";
	str+="</tr>";
	document.writeln(str);
}

function genLeftMenu()
{
	var str=new String("");
	str+="<table cellpadding=0 cellspacing=0 align=center>\n";

	if (result[2]=="adv_filters_domain") result[2]="adv_filters_url";
	if (result[2]=="adv_filters_mac") result[2]="adv_filters_ip";
	if (result[2]=="st_log_settings") result[2]="st_log";
	if (result[2]=="h_wan_fix") result[2]="h_wan";
	if (result[2]=="h_wan_dhcp") result[2]="h_wan";
	if (result[2]=="h_wan_pptp") result[2]="h_wan";
	if (result[2]=="h_wan_l2tp") result[2]="h_wan";
	if (result[2]=="h_wan_poe") result[2]="h_wan";
	if (result[2]=="h_wan_bigpond") result[2]="h_wan";
	if (result[2]=="st_naptinfo") result[2]="st_session";

	for (var i=0;i < eval(result[1]+"List").length;i++)
	{
		str+="<tr>\n";
		if (eval(result[1]+"Url[i]").search(result[2]) != -1)
		{
			str+="<td background=\"../graphic/title_over.gif\" width=133 height=57 align=center>\n";
			str+="<a style=\"text-decoration: none;\" href=\""+eval(result[1]+"Url[i]")+"\">";
			str+="<font style=\"text-decoration: none;color:#000000;font-family:Verdana, Arial, Helvetica, sans-serif;font-size:12px;font-weight:bold;\">";
			str+=eval(result[1]+"List[i]");
			str+="</font>";
		}
		else
		{
			str+="<td background=\"../graphic/title.gif\" width=133 height=57 align=center>\n";
			str+="<a style=\"text-decoration: none;\" href=\""+eval(result[1]+"Url[i]")+"\">";
			str+="<font style=\"text-decoration: none;color:#ffffff;font-family:Verdana, Arial, Helvetica, sans-serif;font-size:12px;font-weight:bold;\">";
			str+=eval(result[1]+"List[i]");
			str+="</font>";
			str+="</a>\n";
		}
		str+="</td>\n";
		str+="</tr>\n";
	}
	str+="</table>";
	document.writeln(str);
}

/****************************************** genHTML.js end *************************************************/
