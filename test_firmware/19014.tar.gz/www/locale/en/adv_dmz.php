<?
$m_dmz_title="DMZ";
$m_dmz_descript="DMZ (Demilitarized Zone) is used to allow a single computer on the LAN to be exposed to the Internet.";
$a_err_ip_ranger="\" The Value (DMZ IP Address) should be between 1 and 254!\"";
$a_err_ip_format="ip+\" is not a valid IP Address!\"";
$a_err_same_lanip="\" The DMZ IP Address can't be the same with the LAN IP Address(\"+lanIP+\")!\"";
?>
