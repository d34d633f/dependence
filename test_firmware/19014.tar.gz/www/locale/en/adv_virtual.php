<?
$a_sure_want_to_delete="Are you sure you want to delete this ?";
$a_exceed_max_entry_num="Exceed maximum entry number ";
$a_VS_name_cont_blank="The Virtual Server Name can not be blank!";
$a_first_char_of_input_data_cant_blank="The First Character of The Inputted Data can not be blank!";
$a_private_ip_you_input_in_a_wrong_ip_format="The Private IP that you input is in a wrong IP format!";
$a_invalid_ipaddr="Error IP address";
$a_invaild_virtual_server_addr="Invalid virtual server address!";
$a_cant_be_same_with_current_ipaddr="It can not be the same with current IP address:";
$a_should_be_located_same_subnet_of_current_ipaddr="It should be located in the same subnet of current IP address:";
$a_private_port_should_be_num=" The Value of The Private Port should be a number";
$a_public_port_should_be_num=" The Value of The Public Port should be a number";
$a_starttime_cant_big_then_end="Begin time can not equal or bigger than start time!";
$a_entry_with_same_settings=" A entry with the same setting exists!";
$a_entry_with_the_same_public_port=" An enabled entry with the same public port exists!";
$m_virtual_server="Virtual Server";
$m_virtual_server_allow_user_access_lan_service="Virtual Server is used to allow Internet users access to LAN services";
$m_private_ip="Private IP";
$m_form="From";
$m_time="time";
$m_day="day";
$m_virtual_server_list="Virtual Servers List";
$m_private_ip="Private IP";

?>

