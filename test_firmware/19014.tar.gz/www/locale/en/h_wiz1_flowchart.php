<?
/* vi: set sw=4 ts=4: */
$m_welcome_msg="Welcome to the ".query("/sys/modelname")." Setup Wizard. The Wizard will guide you through these five quick steps. Begin by clicking on <b>Next.</b>";
$m_step1="Step 1. Set your new password";
$m_step2="Step 2. Choose your time zone";
$m_step3="Step 3. Set Internet connection";
$m_step4="Step 4. Set wireless LAN connection";
$m_step5="Step 5. Restart";
?>
