<?
$m_title1="Fast Ethernet";
$m_title2="Virtual Cable Tester (VCT)";
$m_ports="Ports";
$m_link_status="Link Status";
$m_link_type="Link Type";
$m_wan="WAN";
$m_lan="LAN";
$m_disconnected="Disconnected";
$m_100full="100Full";
$m_100half="100Half";
$m_10full="10Full";
$m_10half="10Half";
$m_more_info="More Info";
?>

