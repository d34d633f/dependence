	The device is rebooting...<br>
	Please <font color=red>Don't Power Down.</font><br>
	And please wait for
	<input type='Text' readonly name='WaitInfo' value='150' size='2' style='border-width:0; background-color=#C7CBCE; color:#FF3030; text-align:center'>
	seconds...
                                