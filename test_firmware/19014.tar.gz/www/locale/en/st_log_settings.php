<?
// -------------------------message start---------------------------
$a_smtp_server_ip_addr_is_empty="The SMTP Server / IP Address can't be empty.";
$a_email_addr_is_empty="The Email Address can't be empty.";
$a_err_smtp_server_ip_addr="Error SMTP Server IP Address";
$a_err_email_addr_format="Error E-mail Address format.";
$a_invalid_smtp="Invalid SMTP Server / IP Address.";
$a_invalid_email_addr="Invalid Email Address.";

$m_title="Log settings";
$m_title_desc="Logs can be saved by sending it to an admin email address.";
$m_smtp_server_ip_addr="SMTP Server / IP Address";
$m_email_addr="Email Address";
$m_send_mail_now="Send Mail Now";
$m_save_log_to_hdd="Save Log File To Local Hard Drive";
$m_save="Save";
$m_log_type="Log Type";
$m_ltype_system_activity="System Activity";
$m_ltype_debug_information="Debug Information";
$m_ltype_attacks="Attacks";
$m_ltype_dropped_packets="Dropped Packets";
$m_ltype_notice="Notice";
// -------------------------message end----------------------------- */
?>
