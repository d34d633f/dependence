<?
/* vi: set sw=4 ts=4: */
/* ------------------------message start----------------------*/
$a_admin_password_only_allow_ascii_code="Administrator Password only allow ASCII code!";
$a_user_password_only_allow_ascii_code="User Password only allow ASCII code!";
$a_admin_password_not_matched="The Administrator New Password and Confirm Password do not match!";
$a_user_password_not_matched="The User New Password and Confirm Password do not match!";
$a_ip_addr_is_not_valid="The IP Address is an invalid address.";
$a_err_ip_addr="Error IP Address";
$a_more_than_max_length="More than maximum length!\\nThe maximum length is 15 characters.\\nPlease check the length of the password you want to input.";

$m_title="Administrator Settings";
$m_title_desc="Administrators can change their login password.";
$m_admin="Administrator (The Login name is admin)";
$m_new_password="New Password";
$m_confirm_password="Confirm Password";
$m_user="User (The Login name is user)";
$m_remote_management="Remote Management";
$m_enabled="Enabled";
$m_disabled="Disabled";
$m_ip_addr="IP Address";
$m_port="Port";
/* ------------------------message end------------------------ */
?>
