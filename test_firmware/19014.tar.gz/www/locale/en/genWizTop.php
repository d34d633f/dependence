<? /* vi: set sw=4 ts=4: */
$g_ww="../graphic/ww.jpg";
?>
