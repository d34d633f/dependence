<? /* vi: set sw=4 ts=4: */ 
$g_apply_p="../graphic/apply_p.jpg";
$g_cancel_p="../graphic/cancel_p.jpg";
$g_help_p="../graphic/help_p.jpg";
$g_ww="../graphic/ww.jpg";
$g_next_p="../graphic/next_p.jpg";
$g_back_p="../graphic/back_p.jpg";
$g_exit_p="../graphic/exit_p.jpg";
$g_restart_p="../graphic/restart_p.jpg";
?>
