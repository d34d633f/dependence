<?
/* vi: set sw=4 ts=4: */
$a_host_name_is_blank="The Host Name can not be blank.";
$a_mac_addr_is_invalid_formated="The MAC Address that you input is in a wrong format!";
$a_invalid_hostname="Invalid Host Name.\\n".$a_plz_use_valid_char;

$m_title="Set Dynamic IP Address";
$m_title_desc="If your ISP require you to enter a specific host name or specific MAC address, please enter it in. The <b>Clone MAC Address </b>button is used to copy the MAC address of your Ethernet adapter to the ".query("/sys/modelname").". Click <b>Next</b> to continue.";
$m_host_name="Host Name";
$m_mac="MAC";
$m_clone_mac_addr="Clone MAC Address";
?>
