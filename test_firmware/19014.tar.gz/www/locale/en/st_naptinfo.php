<?
// --------------------------message start---------------------------
$m_title="Napt Active Session";
$m_title_desc="Napt Active Session Detail Information.";
$m_napt_active_session_lists="Napt Active Session Lists";
$m_protocol="Protocol";
$m_sip="Source IP";
$m_sport="Source Port";
$m_dip="Dest IP";
$m_dport="Dest Port";
// --------------------------message end----------------------------- */
?>
