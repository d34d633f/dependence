<?
/* alert messages */
$a_invalid_ipaddr		= "The IP Address is invalid";
$a_invalid_netmask		= "The Subnet Mask is invalid";
$a_invalid_gwaddr		= "The Gateway Address is invalid";
$a_invalid_svraddr		= "The Server Address is invalid";
$a_invalid_dns			= "The DNS address is invalid";
$a_invalid_dns1			= "The primary DNS address is invalid";
$a_invalid_dns2			= "The secondary DNS address is invalid";
$a_invalid_mac			= "The MAC address is invalid";
$a_should_be_in_same_subnet	= "It should be in the same subnet of current IP address.";

$a_hostname_cant_be_empty	= "The Host Name can not be empty!";
$a_invalid_hostname		= "Invalid Host Name.\\n".$a_plz_use_valid_char;
$a_server_cant_be_empty		= "The Server IP can not be empty!";
$a_poe_uname_cant_be_empty	= "The PPPoE user name can not be empty!";
$a_pptpacc_cant_be_empty        = "The PPTP account can not be empty!";
$a_l2tpacc_cant_be_empty        = "The L2TP Account can not be empty!";
$a_bpacc_cant_be_empty		= "The BigPond User Name can not be empty!";

$a_poe_passwd_mismatch		= "The PPPoE Password and Retype Password do not match!";
$a_pptp_password_mismatch       = "The PPTP Password and Retype Passord do not match!";
$a_l2tp_password_mismatch       = "The L2TP Password and Retype Passord do not match!";
$a_bp_password_mismatch		= "The BigPond Password and Retype Passord do not match!";

$a_username_ascii_only          = "Only ASCII characters allowed for User Name!";
$a_passwd_ascii_only            = "Only ASCII characters allowed for Password!";
$a_hostname_ascii_only		= "Only ASCII characters allowed for Host Name!";
$a_poe_uname_ascii_only		= "Only ASCII characters allowed for PPPoE User Name!";
$a_poe_passwd_ascii_only	= "Only ASCII characters allowed for PPPoE Password!";
$a_poe_acname_ascii_only	= "Only ASCII characters allowed for PPPoE AC Name!";
$a_poe_svcname_ascii_only	= "Only ASCII characters allowed for PPPoE Service Name!";

$a_cant_get_client_mac		= "Can not get MAC Address from client!";
$a_mtu_not_number		= "The MTU that you input is not a number!";
$a_mtu_should_between_start_end	= "\"Invalid MTU size. It should be between \"+start+\" to \"+end+\".\"";
$a_max_idle_time_not_number	= "The Maximum Idle Time that you input is not a number!";


/* WAN setting title */
$m_wan_settings			= "WAN Settings";
$m_select_option_connect_ISP	= "Please select the appropriate option to connect to your ISP.";
$m_radio_dhcp			= "Dynamic IP Address";
$m_description_dhcp		= "Choose this option to obtain an IP address automatically from your ISP.".
				  "(For most Cable modem users)";
$m_radio_static_ip		= "Static IP Address";
$m_description_static_ip	= "Choose this option to set static IP information provided to you by your ISP.";
$m_radio_pppoe			= "PPPoE";
$m_description_pppoe		= "Choose this option if your ISP uses PPPoE. (For most DSL users)";
$m_radio_others			= "Others";
$m_description_others		= "PPTP, L2TP and BigPond Cable";
$m_radio_pptp			= "PPTP";
$m_description_pptp		= "(For Europe use only)";
$m_radio_l2tp			= "L2TP";
$m_description_l2tp		= "(For specific ISPs use only)";
$m_radio_bigpond		= "BigPond Cable";
$m_description_bigpond		= "(For Australia use only)";

/* Common message */
$m_clone_mac			= "Clone MAC Address";
$m_primary_dns			= "Primary DNS Address";
$m_secondary_dns		= "Secondary DNS Address";
$m_mtu				= "MTU";
$m_max_idle_time		= "Maximum Idle Time";
$m_minutes			= "Minutes";
$m_connection_mode		= "Connect mode select";
$m_always_on			= "Always on";
$m_manual			= "Manual";
$m_on_demand			= "Connect on demand";

/* DHCP message */
$m_dynamic_ip			= "Dynamic IP"
$m_host_name			= "Host Name";

/* Static IP message */
$m_static_ip			= "Static IP";
$m_isp_gateway			= "ISP Gateway Address";
$m_assigned_by_isp		= "(assigned by your ISP)";

/* PPPoE message */
$m_pppoe			= "PPPoE";
$m_dynamic_pppoe		= "Dynamic PPPoE";
$m_static_pppoe			= "Static PPPoE";
$m_ac_name			= "AC Name";
$m_service_name			= "Service Name";

/* PPTP/L2TP message */
$m_pptp_client			= "PPTP Client";
$m_l2tp_client			= "L2TP Client";
$m_gateway			= "Gateway";
$m_dns				= "DNS";
$m_server_ip			= "Server IP";
$m_pptp_account			= "PPTP Account";
$m_pptp_passwd			= "PPTP Password";
$m_pptp_retype_passwd		= "PPTP Retype Password";
$m_l2tp_account			= "L2TP Account";
$m_l2tp_passwd			= "L2TP Password";
$m_l2tp_retype_passwd		= "L2TP Retype Password";

/* Bigpond message */
$m_bigpond_cable		= "BigPond Cable";
$m_auth_server			= "Auth Server";
$m_login_server			= "Login Server IP/Name";
$m_bigpond			= "BigPond";
$m_auth_srv			= "Auth Server";
$m_login_server			= "Login Server IP/Name";
$m_auto_reconnect		= "Auto Reconnect";
?>
