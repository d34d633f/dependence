<? /* vi: set sw=4 ts=4: */ 
$g_home_01="../graphic/home_01.jpg";
?>
