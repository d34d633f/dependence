<? /* vi: set sw=4 ts=4: */
$g_down_02="../graphic/down_02.jpg";

$m_home_list="\"Wizard\",\"Wireless\",\"WAN\",\"LAN\",\"DHCP\"";
//$m_advanced_list="\"Virtual Server\",\"Applications\",\"Filters\",\"Parental Control\",\"Firewall\",\"DMZ\",\"DDNS\",\"Performance\"";
$m_advanced_list="\"Virtual Server\",\"Applications\",\"Filters\",\"Parental Control\",\"Firewall\",\"DMZ\",\"Performance\"";
//$m_tools_list="\"Admin\",\"Time\",\"System\",\"Firmware\",\"Misc.\",\"Cable Test\"";
$m_tools_list="\"Admin\",\"Time\",\"System\",\"Firmware\",\"DDNS\",\"Misc.\",\"Cable Test\"";
$m_status_list="\"Device Info\",\"Log\",\"Statistics\",\"Wireless Info\",\"Active Session\"";
$m_help_list="\"Menu\"";
$m_home="Home";
$m_advanced="Advanced";
$m_tools="Tools";
$m_status="Status";
$m_help="Help";
?>
