<?
// ----------------------------message start-------------------------
$a_your_browser_is_not_support_this_function="Your browser is not support this function.";
$a_upgrade_the_browser="Please upgrade your's browser to latest version!";
$a_only_admin_account_can_clear_logs="Only admin account can clear logs!";

$m_title="View Log";
$m_title_desc="View Log displays the activities occurring on the ".query("/sys/modelname").". Click on Log Settings for advance features.";
$m_first_page="First Page";
$m_last_page="Last Page";
$m_previous="Previous";
$m_next="Next";
$m_clean="Clear";
$m_log_settings="Log Settings";
$m_refresh="Refresh";
$m_time="Time";
$m_message="Message";
$m_page="page";
$m_of="of";
// ----------------------------message end--------------------------- */
?>
