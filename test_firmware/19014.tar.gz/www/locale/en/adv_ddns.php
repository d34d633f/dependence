<?
$m_ddns_title="Dynamic DNS";
$m_ddns="DDNS";
$m_ddns_server="Server Address";
$m_ddns_host_name="Host Name";
$a_info_ASCII_host="\"Host Name only allow ASCII code!\"";
$a_info_ASCII_user="\"User Name only allow ASCII code!\"";
$a_info_ASCII_passwd="\"Password only allow ASCII code!\"";
$a_err_enpty_host="\"The Dynamic DNS Host Name can not be blank!\"";
$a_err_enpty_user="\"The Dynamic DNS User Name can not be blank!\"";
$a_err_enpty_passwd="\"The Dynamic DNS Password can not be blank!\"";
?>
