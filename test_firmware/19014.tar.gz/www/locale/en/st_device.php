<?
// ---------------------------message start---------------------------
$m_device_infor="Device Information";
$m_view_network_topology="View network topology";
$m_system_uptime="System UpTime:";
$m_days="days";
$m_expired="Expired";
$m_firmware_version="Firmware Version:";
// --- LAN
$m_lan="LAN";
$m_mac_addr="MAC Address";
$m_ip_addr="IP Address";
$m_subnet_mask="Subnet Mask";
$m_dhcp_server="DHCP Server";
// --- WAN
$m_wan="WAN";
$m_connection="Connection";
$m_def_gw="Default Gateway";
$m_dns="DNS";
$m_static_ip="Static IP";
$m_dhcp_client="DHCP client";
$m_connected="Connected";
$m_disconnected="Disconnected";
$m_dhcp_renew="DHCP Renew";
$m_dhcp_release="DHCP Release";
$m_pppoe="PPPoE";
$m_pptp="PPTP";
$m_l2tp="L2TP";
$m_connect="Connect";
$m_disconnect="Disconnect";
$m_na="N/A";
$m_null_ip="0.0.0.0";
// --- Wireless
$m_wireless_jumpstart="Wireless JumpStart";
$m_jumpstart="JumpStart";
$m_enabled="Enabled";
$m_protocol="Protocol";
$m_disabled="Disabled";
$m_status="Status";
$m_wireless="Wireless 802.11g";
$m_ssid="SSID";
$m_channel="Channel";
$m_encryption="Encryption";
$m_bits="bits";
$m_tkip="TKIP";
$m_aes="AES";
$m_cipher_auto="CIPHER_AUTO";
// ---------------------------message end----------------------------- */
?>
