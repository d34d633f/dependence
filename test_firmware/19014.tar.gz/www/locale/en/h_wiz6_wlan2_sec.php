<?
/* vi: set sw=4 ts=4: */
// --------------------------message start------------------------
$a_invalid_key_length="\"The length of Key is too short. It should be \"+len+\" hex numbers.\"");
$a_invalid_key_value="Invalid key value. It should be in hex number (0-9 or a-f).";

$m_title="Set 802.11g Wireless LAN Connection";
$m_title_desc="If you wish to use encryption, enable it here and enter the encryption Key Values.Click <b>Next</b> to continue.";
$m_wep="WEP";
$m_enabled="Enabled";
$m_disabled="Disabled";
$m_wep_encryption="WEP Encryption";
$m_64bit="64 Bit";
$m_128bit="128 Bit";
$m_key="Key";
$m_input_hex_chars="Input the HEX characters (HEX is 0~9, A~F, or a~f)";
// --------------------------message end-------------------------- 
?>
