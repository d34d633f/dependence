<?
// -------------------------message start-------------------------
$m_title="Active Session";
$m_title_desc="Active Session display Source and Destination packets passing through the ".query("/sys/modelname").".";
$m_refresh="Refresh";
$m_napt_session="NAPT Session";
$m_tcp_session="TCP Session";
$m_udp_session="UDP Session";
$m_total="Total";
$m_active_session="Active Session";
$m_ip_addr="IP Address";
$m_detail="detail";
// -------------------------message end--------------------------- */
?>
