<? /* vi: set sw=4 ts=4: */
$m_sun="Sun";
$m_mon="Mon";
$m_tue="Tue";
$m_wed="Wed";
$m_thu="Thu";
$m_fri="Fri";
$m_sat="Sat";
$m_am="AM";
$m_pm="PM";
?>
