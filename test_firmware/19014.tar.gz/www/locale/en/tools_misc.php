<?
/* vi: set sw=4 ts=4: */
/* --------------------message start--------------------*/
$a_ip_addr_is_empty="The IP Address should not be empty";

$m_ping_test="Ping Test";
$m_ping_test_desc="Ping Test is used to send Ping packets to test if a computer is on the Internet.";
$m_host_name_or_ip_addr="Host Name or IP Address";
$m_ping="Ping";
$m_ping_passed="PASSED";
$m_ping_failed="FAILED";
$m_block_wan_ping="Block WAN Ping";
$m_block_wan_ping_desc="When you Block WAN Ping, you are causing the public WAN IP address on the ".query("/sys/modelname")." to not respond to ping commands. Pinging public WAN IP addresses is a common method used by hackers to test whether your WAN IP address is valid.";
$m_discard_ping_from_wan_side="Discard PING from WAN side";
$m_enabled="Enabled";
$m_disabled="Disabled";
$m_spi_mode="SPI mode";
$m_spi_mode_desc="You can setup this item if you want to enable SPI mode.";
$m_upnp_settings="UPNP Settings";
$m_upnp_settings_desc="You can setup this item if you want to enable UPnP.";
$m_vpn_pass_through="VPN Pass-Through";
$m_vpn_pass_through_desc="Allows VPN connections to work through the";
$m_pptp="PPTP";
$m_ipsec="IPSec";
$m_wan_type_setting="WAN select to 10/100 Mbps";
$m_ltype_100Mbps="100Mbps";
$m_ltype_10Mbps="10Mbps";
$m_ltype_auto="10/100Mbps Auto";
/* --------------------message end---------------------- */
?>

