<?
$a_exced_max_entry="\"Exceed maximum entry number \" + MaxRule + \"!\"";
$a_mac_filter_name_cant_be_empty="The MAC Filters Name can not be blank!";
$a_wrong_format_mac_addr=" The MAC Address that you input is in a wrong format!";
$a_same_entry_exist=" A entry with the same MAC Address exists!";
$a_mac_filter_list_cant_be_empty="The MAC Filter List can not be empty !";
$a_confim_to_change_settings="Are you sure you want to change the settings?";
$a_confim_to_delete="Are you sure you want to delete this ?";
$m_mac_filters_description="Use MAC address to allow or deny computers access to the network.";
$m_radio_disabled="Disabled MAC Filters";
$m_radio_allow_below_list="Only <b>allow</b> computers with MAC address listed below to access the network";
$m_radio_deny_below_list="Only <b>deny</b> computers with MAC address listed below to access the network";
$m_dhcp_client="DHCP Client";
$m_mac_filter_list="MAC Filter List";
?>



