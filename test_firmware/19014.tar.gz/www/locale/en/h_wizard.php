<?
/* vi: set sw=4 ts=4: */
$modelname=query("/sys/modelname");
$m_title="Setup Wizard";
$m_title_desc="The ".$modelname." is a Wireless Broadband Router ideal for home networking and small business networking. The Setup Wizard will guide you to configure the ".$modelname." to connect to your ISP (Internet Service Provider).  The ".$modelname."'s easy setup will allow you to have Internet access within minutes. Please follow the setup wizard step by step to configure the ".$modelname.".";
$m_run_wizard="Run Wizard";
?>
