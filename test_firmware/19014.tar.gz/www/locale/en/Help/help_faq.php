<?$modelname=query("/sys/modelname");?>
<HTML>
<HEAD>
<TITLE><?query("/sys/hostname");?></TITLE>
<META HTTP-EQUIV=Content-Type CONTENT="no-cache">
<META HTTP-EQUIV=Content-Type CONTENT="text/html; charset=iso-8859-1">
</HEAD>
<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<table border=0 cellspacing=0 cellpadding=0 width=750>
  <tr> 
    <td><b><font face=Arial size=5>FAQs<a name=001></a></font></b></td>
  </tr>
  <tr> 
    <td> 
      <ul>
        <li><font face=Arial><b><font color=#000000>Q1:</font></b> <a href=help_faq.php#01><font color=#000000>I 
          have problem connecting to the Web-management interface. </font></a></font></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td height=34> 
      <ul>
        <li><font face=Arial><b>Q2:</b> <a href=help_faq.php#02><font color=#000000>The 
          <?=$modelname?> has successfully connected to the ISP (from the connection status 
          shown in the Device Information screen) but I cannot surf the Internet.</font></a><br>
          </font></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td height=42> 
      <ul>
        <li><b><font face=Arial>Q3:</font></b><font face=Arial> <a href=help_faq.php#03><font color=#000000>The 
          <?=$modelname?> has problems getting IP settings from the ISP.</font></a><br>
          </font></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td height=35> 
      <ul>
        <li><font face=Arial><b>Q4:</b> <a href=help_faq.php#04><font color=#000000>If 
          all else fails ,what can I do?</font></a></font></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td height=43> 
      <ul>
        <li><font face=Arial><b>Q5:</b><a href=help_faq.php#05><font color=#000000> 
          Does the home internet gateway support PPP over Ethernet (PPPoE)</font></a></font></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td height=38> 
      <ul>
        <li><font face=Arial><b>Q6: </b><a href=help_faq.php#06><font color=#000000>How 
          will I be notified of new firmware upgrades?</font></a><br>
          </font></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td height=36> 
      <ul>
        <li><font face=Arial><b>Q7:</b> <a href=help_faq.php#07><font color=#000000>Does 
          it matter if I use a Dynamic IP address or Static IP address for my 
          computer?</font></a></font></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td height=12> 
      <ul>
        <li><b><font face=Arial>Q8:</font></b><font face=Arial color=#000000> 
          </font><font face=Arial><a href=help_faq.php#08><font color="#000000">Does 
          the <?=$modelname?> support VPN?</font></a></font></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td> 
      <ul>
        <li><font face=Arial><b>Q9:</b> <a href=help_faq.php#09><font color=#000000>Does 
          the <?=$modelname?> prevent hacker attacks?</font></a></font></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td> 
      <ul>
        <li><font face=Arial><b>Q10:</b> <a href=help_faq.php#10><font color=#000000>Why 
          can't I connect to the <?=$modelname?> wirelessly?</font></a></font></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td> 
      <ul>
        <li><font face=Arial><b>Q11:</b> <a href=help_faq.php#11><font color=#000000>Should 
          D-Link 802.11b wireless products communicate with the <?=$modelname?> out of 
          box?</font></a></font></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td height=23><font face=Arial><b>Q1: I have problem connecting to the web-management 
      interface.<a name=01></a></b></font></td>
  </tr>
  <tr> 
    <td> 
      <ol>
        <li><font face=Arial size=2>Check that the power LED in the front of the 
          <?=$modelname?> is ON.</font></li>
        <li><font face=Arial size=2>Check that the link light status of the Ethernet 
          port used by your computer is ON.</font></li>
        <li><font face="Arial" size="2">Check your computer's network settings 
          - verify that your TCP/IP settings are correct. In windows 95/98, you 
          can type <b>winipcfg</b> in the DOS prompt. In windows XP/NT/2000, you 
          can type <b>ipconfig</b> in the DOS prompt.</font></li>
        <li><font size="2" face="Arial">Check to see that your computer's IP address 
          is in the same network as the <?=$modelname?>. The computer's IP address should 
          be in the range from <?query("/sys/startip");?> to <?query("/sys/endip");?>.</font></li>
        <li><font face="Arial" size="2">Type http://<?query("/sys/ipaddr");?> in your browser's 
          URL interface.</font></li>
      </ol>
      <font face=Arial><a href=help_faq.php#001>TOP&gt;&gt;</a><br>
      <br>
      </font></td>
  </tr>
  <tr> 
    <td><font face=Arial><b><a name=02></a>Q2: The <?=$modelname?> has successfully connected 
      to the ISP (from the connection status shown in the Device Information screen) 
      but I cannot surf the Internet.</b></font></td>
  </tr>
  <tr> 
    <td> 
      <ol>
        <li><font face=Arial size=2>Check if your computer's IP settings are correct. 
          <br>
          a. Your computer's IP address should be in the range from <?query("/sys/startip");?> 
          to <?query("/sys/endip");?>. <br>
          b. Your computer's network mask should be <?query("/sys/netmask");?>. <br>
          c. Your computer's gateway should be <?query("/sys/ipaddr");?> (The IP address of 
          the <?=$modelname?>). <br>
          d. Your computer's DNS IP settings should be <?query("/sys/ipaddr");?> (The IP address 
          of the <?=$modelname?>). </font></li>
        <li><font face=Arial size=2>Try to ping an existing Internet IP, ex: yahoo.com.</font> 
        </li>
      </ol>
      <font face=Arial><a href=help_faq.php#001>TOP&gt;&gt;</a><br>
      <br>
      </font></td>
  </tr>
  <tr> 
    <td height=19><font face=Arial><b>Q3: The <?=$modelname?> has problems getting IP 
      settings from the ISP<a name=03></a></b></font></td>
  </tr>
  <tr> 
    <td> 
      <ol>
        <li><font face=Arial size=2>Make sure that your Cable or DSL modem is 
          connected properly.</font></li>
        <li><font face=Arial size=2>Try resetting your Cable or DSL modem by powering 
          the modem off and on.</font></li>
        <li> <font face="Arial" size="2">If you are using Dynamic IP addressing, 
          make sure that your Cable or DSL modem is DHCP capable.</font></li>
        <li><font face="Arial" size="2"> Some Internet Service Providers (ISP) 
          require a MAC address to be registered with them. In this case, make 
          sure you specify the correct WAN Ethernet MAC address required by the 
          ISP under &quot;Home&quot; &gt; &quot;WAN&quot; &gt; &quot;Dynamic IP 
          address&quot;. </font></li>
        <li><font size="2" face="Arial">If your connection is DSL and your ISP 
          requires you to input username and password, then your connection is 
          a PPPoE connection. To connect to the ISP's PPPoE server, you have to 
          input your PPPoE username/password from &quot;Home&quot; &gt; &quot;WAN&quot; 
          &gt; &quot;PPPoE&quot;.</font></li>
        <li><font face="Arial" size="2"> If your connection is Cable and your 
          ISP requires you to input a specific host computer name, you have to 
          input the host computer name from &quot;Home&quot; &gt; &quot;WAN&quot; 
          &gt; &quot;Dynamic IP address&quot;.</font></li>
      </ol>
      <font face=Arial><a href=help_faq.php#001>TOP&gt;&gt;</a><br>
      <br>
      </font></td>
  </tr>
  <tr> 
    <td height=26><font face=Arial><b>Q4: If all else fails ,what can I do?<a name=04></a></b></font></td>
  </tr>
  <tr> 
    <td> 
      <ol>
        <li><font face=Arial size=2>Reset your cable modem or DSL modem by powering 
          the unit off and on</font></li>
        <li><font face=Arial size=2>Reset the <?=$modelname?> back to factory default 
          settings in &quot;Tools&quot; -&gt; &quot;System Settings&quot;.</font></li>
        <li><font face=Arial size=2>Configure the device with the &quot;Setup 
          Wizard&quot;.</font></li>
      </ol>
      <font face=Arial><a href=help_faq.php#001>TOP&gt;&gt;</a><br>
      <br>
      </font></td>
  </tr>
  <tr> 
    <td> 
      <p><font face=Arial><a name=05></a><b>Q5: Does the home internet gateway 
        support PPP over Ethernet (PPPoE)</b> <br>
        <font size=2>Yes, the router does support PPPoE. To setup PPPoE support:</font></font></p>
      <ol>
        <li><font face=Arial size=2>Enter the web-based management utility by 
          typing &quot;http://<?query("/lan/ethernet/ip");?>&quot; in your web browser's address 
          line. Press <b>Enter </b></font></li>
        <li><font face=Arial size=2>After logging in, go to &quot;Home&quot; -&gt; 
          &quot;WAN&quot; -&gt; &quot;PPPoE&quot;</font></li>
        <li><font face=Arial size=2>Enter the username and password provided by 
          your ISP.</font></li>
        <li><font face=Arial size=2>Click <b>Apply</b> to save the settings.</font></li>
        <li><font face=Arial size=2>Go to &quot;Device Information&quot; to ensure 
          that PPPoE is enabled and that the status is connected.</font></li>
      </ol>
      <font face=Arial><a href=help_faq.php#001>TOP&gt;&gt;</a><br>
      <br>
      </font></td>
  </tr>
  <tr> 
    <td> 
      <p><font face=Arial><b>Q6: How will I be notified of new firmware upgrades?</b> <a name=06></a><br>
        <font size=2>All new firmware will be posted on D-Link support website at
        <A href="http://support.dlink.com/">http://support.dlink.com/</A>, where they can be downloaded
        for free.</font></font></p>
      <p><font face=Arial><br>
        <a href=help_faq.php#001>TOP&gt;&gt;</a><br>
        <br>
        </font></p>
    </td>
  </tr>
  <tr> 
    <td><font face=Arial><b>Q7: Does it matter if I use a Dynamic IP address or 
      Static IP address for my computer?</b> <a name=07></a><br>
      <font size=2>No, the <?=$modelname?> can be configured for either case. For Static 
      IP address, you have to make sure of the following:</font></font> 
      <ol>
        <li><font face=Arial size=2>The IP address is in the range from <?query("/sys/startip");?>
          to <?query("/sys/endip");?>.</font></li>
        <li><font face=Arial size=2>The network mask is <?query("/sys/netmask");?>.</font></li>
        <li><font face=Arial size=2>The gateway is <?query("/sys/ipaddr");?>.</font></li>
        <li> <font face="Arial" size="2">The DNS server IP address is correctly 
          setup. <br>
          For dynamic IP setting, you can check if your computer has successfully 
          acquired IP settings from the <?=$modelname?>. We strongly recommend that your 
          computer is setup to acquire IP settings from the <?=$modelname?> DHCP server. 
          </font> </li>
      </ol>
      <font face=Arial><a href=help_faq.php#001>TOP&gt;&gt;</a><br>
      <br>
      </font></td>
  </tr>
  <tr> 
  <tr> 
    <td> 
      <p><font face=Arial><b>Q8: Does the <?=$modelname?> support VPN?</b> <a name=08></a><br>
        <font size=2>Yes, the <?=$modelname?> supports VPN (PPTP pass-through and IPSec 
        pass-through). The <?=$modelname?> supports multiple concurrent VPN sessions.</font></font></p>
      <p><font face=Arial><br>
        <a href=help_faq.php#001>TOP&gt;&gt;</a><br>
        <br>
        </font></p>
    </td>
  </tr>
  <tr> 
    <td> 
      <p><font face=Arial><b>Q9: Does the <?=$modelname?> prevent hacker attacks?</b> 
        <a name=09></a><br>
        <font size=2>Yes, <?=$modelname?> supports hacker attack logging and will be able 
        to log most recent attacked hacker patterns. You can view the logs at 
        &quot;Status&quot; -&gt; &quot;Log&quot;.</font></font></p>
      <p><font face=Arial><br>
        <a href=help_faq.php#001>TOP&gt;&gt;</a><br>
        <br>
        </font></p>
    </td>
  </tr>
  <tr> 
    <td> 
      <p><font face=Arial><b>Q10: Why can't I connect to the <?=$modelname?> wirelessly?</b> 
        <a name=10></a><br>
        <font size=2>Make sure that you have the correct SSID set.  Also make sure that you are running on the same channel. Also, if you are using encryption make sure that you are on the same Key as the <?=$modelname?>.</font></font></p>
      <p><font face=Arial><br>
        <a href=help_faq.php#001>TOP&gt;&gt;</a><br>
        <br>
        </font></p>
    </td>
  </tr>
  <tr> 
    <td> 
      <p><font face=Arial><b>Q11: Should D-Link 802.11b wireless products communicate 
        with the <?=$modelname?> out of box?</b> <a name=11></a><br>
        <font size=2>Yes, all D-Link 802.11b have the same default settings. The 
        SSID is set to <b>default</b> and the channel is set to <b>6</b>.</font></font></p>
      <p><font face=Arial><br>
        <a href=help_faq.php#001>TOP&gt;&gt;</a><br>
        <br>
        </font></p>
    </td>
  </tr>
</table>
</BODY>
</HTML>
