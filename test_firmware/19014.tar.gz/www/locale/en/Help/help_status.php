<?$modelname=query("/sys/modelname");?>
<HTML>
<HEAD>
<TITLE><?query("/sys/hostname");?></TITLE>
<META HTTP-EQUIV=Content-Type CONTENT="no-cache">
<META HTTP-EQUIV=Content-Type CONTENT="text/html; charset=iso-8859-1">
</HEAD>
<body bgcolor=#FFFFFF text=#000000>
<table border=0 cellspacing=0 cellpadding=0 width=750 height=478>
  <tr> 
    <td height=2><font face=Arial size=4><b>Status</b></font></td>
  </tr>
  <tr> 
    <td height=39><font face=Arial><b>Device Information</b></font><font face=Arial size=4><b> 
      <a name=15></a></b></font><font face=Arial><br>
      <font size="2">This page displays the current information for the <?=$modelname?>. 
      The page will show the version of the firmware currently loaded in the device. 
      </font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=39><font face=Arial><b>LAN (Local Area Connection)</b></font><font face=Arial size=4><b> 
      </b></font><font face=Arial><br>
      <font size="2">The MAC Address of the Ethernet LAN connection, IP Address, 
      and Subnet Mask information will be shown, as well as the setting (Enabled/Disabled) 
      for the DHCP Server. </font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=39><font face=Arial><b>WAN (Wide Area Network)</b></font><font face=Arial size=4><b> 
      </b></font><font face=Arial><br>
      <font size="2">The MAC Address of the Ethernet WAN connection, IP Address, 
      Subnet Mask, Default Gateway, and DNS (Domain Name Server) information will 
      be displayed. The connection type: Dynamic, Static, and PPPoE will be displayed. 
      For Dynamic setting, there are buttons for releasing and renewing the IP 
      Address assigned by the ISP (Internet Service Provider) for the WAN Port. 
      For PPPoE setting, there are buttons for connecting and disconnecting the 
      DSL connection. </font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=39><a name=15_w></a><font face=Arial><b>Wireless</b></font><font face=Arial size=4><b> 
      </b></font><font face=Arial><br>
      <font size="2">The SSID, Channel, and Encryption (Enabled/Disabled) will be displayed. </font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=26><font face=Arial><b>Log</b> <a name=16></a><br>
      <font size="2">The log file keeps a running log of events and activities 
      occurring on the device. The log will display up to 200 recent logs. Newer 
      log activities will overwrite the older logs. You may want to save the log 
      files by clicking on <b>Log Setting</b>. When the device is rebooted, the 
      logs are automatically cleared. </font><br>
      <b><i><font size=2>First Page</font></i></b><font size=2> - The first page 
      of the log.<br>
      <b><i>Last Page</i></b> - The last page of the log.<br>
      <b><i>Previous</i></b> - Moves back one log page.<br>
      <b><i>Next</i></b> - Moves forward one log page.<br>
      <b><i>Clear</i></b> - Clears the logs completely.<br>
      <b><i>Log Settings</i> </b>- Brings up the page to configure the logs.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=92><font face=Arial><b>Log Settings</b><br>
      <font size="2">Not only does the device display the logs of activities and 
      events, it can be setup to send these logs to another location. The logs 
      can be sent via email to a specific email account.</font><br>
      <i><b><font size=2>SMTP Server</font></b></i><font size=2> - The address 
      of the SMTP (Simple Mail Transfer Protocol) server that will be used to 
      send the logs.<br>
      <i><b>Email Address</b></i> - The email address the logs will be sent to. 
      Click on Send Email Now to send the email.<br>
      <i><b>Log Type</b></i> - Select the type of activities that you want the 
      <?=$modelname?> to log.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=2><font face=Arial><b>Traffic Statistics</b> <a name=17></a><br>
      <font size="2">The device keeps statistic of the data traffic that it handles. 
      You are able to view the amount of Receive and Transmit packets that passes 
      through the device on both the WAN (Wide Area Network) port and the LAN 
      (Local Area Network) ports. Click the <b>Refresh</b> button to update the 
      counters and the <b>Reset</b> button to clear the counters. The traffic 
      counter will reset when the device is rebooted.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=2><font face=Arial><b>Connected Wireless Client List</b> <a name=17_1></a><br>
      <font size="2">The device keeps statistic of the data traffic that 
      it handles. You are able to view the amount of Receive and Transmit packets that 
      passes through the device on both the WAN (Wide Area Network) 
      port and the LAN (Local Area Network) ports.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=2><font face=Arial><b>Active Session</b><a name=66></a><br>
      <font size="2">Display Source and Destination packets passing through the <?=$modelname?>.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
</table>
</body>
</html>
