<?$modelname=query("/sys/modelname");?>
<HTML>
<HEAD>
<TITLE><?query("/sys/hostname");?></TITLE>
<META HTTP-EQUIV=Content-Type CONTENT="no-cache">
<META HTTP-EQUIV=Content-Type CONTENT="text/html; charset=iso-8859-1">
</HEAD>
<body bgcolor=#FFFFFF text=#000000>
<table border=0 cellspacing=0 cellpadding=0 width=750 height=710>
  <tr> 
    <td height=2><font face=Arial><b><font size=4>Tools</font></b></font></td>
  </tr>
  <tr> 
    <td height=16><font face=Arial><b>Administrator Settings</b> <a name=11></a><br>
      <font size="2"> There are two accounts that can access the management interface 
      through the web browser. The accounts are <b>admin</b> and <b>user</b>. 
      <b>Admin</b> has read/write access while <b>user</b> has read-only access. 
      <b>User</b> can only view the settings but cannot make any changes. Only 
      the <b>admin</b> account has the ability to change both <b>admin</b> and 
      <b>user</b> account passwords.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=97><font face=Arial><b>Remote Management</b><br>
      <font size="2">Remote Management allows the device to be configured through 
      the WAN (Wide Area Network) port from the Internet using a web browser. 
      A username and password is still required to access the browser-based management 
      interface.</font><br>
      <i><b><font size=2>IP Address</font></b></i><font size=2> - Internet IP 
      address of the computer that has access to the <?=$modelname?>. If the IP address 
      is set to *, this allows all Internet IP addresses to access the <?=$modelname?>.<br>
      <i><b>Port</b></i> - The port number used to access the <?=$modelname?>.<br>
      <b><i>Example:</i></b> <br>
      <a href="#">http://x.x.x.x:8080</a> whereas x.x.x.x is the WAN IP address 
      of the <?=$modelname?> and 8080 is the port used for the Web-Management interface.</font></font></td>
  </tr>
  <tr> 
    <td height=10>&nbsp;</td>
  </tr>
  <tr> 
    <td height=33><font face=Arial><b>System Time</b><b><font size=4> <a name=10></a></font></b><br>
      <font size=2>The &quot;system time&quot; setting is used by the unit for 
      synchronizing scheduling services and system logging activities. You will 
      need to set the time zone corresponding to your location. The time can be 
      set manually or the device can connect to a NTP (Network Time Protocol) 
      server to retrieve the time. You may also set Daylight Saving dates and 
      the system time will automatically adjust on those dates.</font></font></td>
  </tr>
  <tr> 
    <td height=2>&nbsp;</td>
  </tr>
  <tr> 
    <td height=40><font face=Arial><b>System Settings</b> <a name=12></a><br>
      <font size="2">The current system settings can be saved as a file onto the 
      local hard drive. The saved file or any other saved setting file created 
      by device can be uploaded into the unit. To reload a system settings file, 
      click on <b>Browse</b> to search the local hard drive for the file to be 
      used. The device can also be reset back to factory default settings by clicking 
      on <b>Restore</b>. Use the restore feature only if necessary. This will 
      erase previously save settings for the unit. Make sure to save your system 
      settings before doing a factory restore.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=51><font face=Arial><b>Firmware Upgrade</b> <a name=13></a><br>
      <font size=2>You can upgrade the firmware of the device using this tool. 
      Make sure that the firmware you want to use is saved on the local hard drive 
      of the computer. Click on <b>Browse</b> to search the local hard drive for 
      the firmware to be used for the update. Upgrading the firmware will not 
      change any of your system settings but it is recommended that you save your 
      system settings before doing a firmware upgrade.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=2><font face=Arial><b>Reboot Device</b><br>
      <font size="2">If for any reason the device is not responding correctly, 
      you may want to restart the unit by clicking on the <b>Reboot </b>button.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=2><font face=Arial><b>Miscellaneous Items</b> <a name=14></a><br>
      <font size="2">These are additional tools and features of the device.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=31><font face=Arial><b>Ping Test</b><br>
      <font size="2">This useful diagnostic utility can be used to check if a 
      computer is on the Internet. It sends ping packets and listens for replies 
      from the specific host. Enter in a host name or the IP address that you 
      want to ping (Packet Internet Groper) and click <b>Ping</b>.<br>
      <font color="#FF0000">Example:</font><br>
      yahoo.com or 216.115.108.245<br>
      </font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=16><font face=Arial><b>Block WAN Ping</b><br>
      <font size="2">When you &quot;Block WAN Ping&quot;, you are causing the 
      public WAN (Wide Area Network) IP address on the device not to respond to 
      ping commands sent by Internet users. Pinging public WAN IP addresses is 
      a common method used by hackers to test whether your WAN IP address is valid.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=69><font face=Arial><b>UPnP</b><br>
      <font size="2">UPnP is short for Universal Plug and Play which is a networking
      architecture that provides compatibility among networking equipment,
      software, and peripherals. The <?=$modelname?> is a UPnP enabled router and will
      only work with other UPnP devices/softwares. If you do not want to use the
      UPnP functionality, it can be disabled by selecting "Disabled".</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=69><font face=Arial><b>VPN Pass-Through</b><br>
      <font size="2">The device supports VPN (Virtual Private Network) pass-through 
      for both PPTP (Point-to-Point Tunneling Protocol) and IPSec (IP Security). 
      Once VPN pass-through is enabled, there is no need to open up virtual services. 
      Multiple VPN connections can be made through the device. This is useful 
      when you have many VPN clients on the local area network.</font></font></td>
  </tr>
  <td height=20>&nbsp;</td>
  <tr> 
    <td height=20><font face=Arial><b>WAN select to 10/100 Mbps</b><br>
     <font size="2">Which allow user to select their Mbps for device: 100Mbps, 10Mbps OR 10/100Mbps by automatically.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=69><font face=Arial><b>Cable Test</b><a name=15></a><br>
      <font size="2">Cable Test is an advanced feature that integrates a LAN cable tester
      on every Ethernet port of the <?=$modelname?>. Through the graphical user interface (GUI), 
      Cable Test can be used to remotely report whether each of the 5 Ethernet ports on 
      the <?=$modelname?> is connected or disconnected. This feature significantly reduces service
      calls and returns by allowing users to easily troubleshoot their cable connections.</font></font></td>
  </tr>
</table>
</body>
</html>
