<?$modelname=query("/sys/modelname");?>
<HTML>
<HEAD>
<TITLE><?query("/sys/hostname");?></TITLE>
<META HTTP-EQUIV=Content-Type CONTENT="no-cache">
<META HTTP-EQUIV=Content-Type CONTENT="text/html; charset=iso-8859-1">
</HEAD>
<body bgcolor=#FFFFFF text=#000000>
<table border=0 cellspacing=0 cellpadding=0 width=750>
  <tr> 
    <td height=40><font face=Arial size=4><b>Home<a name=001></a></b></font></td>
  </tr>
  <tr> 
    <td height=59><font face=Arial><b>Setup Wizard</b> <a name=01></a><br>
      <font size="2">The Setup Wizard is a useful and easy utility to help setup 
      the <?=$modelname?> to quickly connect to your ISP (Internet Service Provider) with 
      only a few steps required. It will guide you step by step to configure the 
      password, time, WAN, and Wireless settings of your <?=$modelname?>.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=59><font face=Arial><b>Wireless Settings</b><a name=02_1></a><br>
      <font size="2">Wireless Settings are settings for the (Access Point) Portion 
      of the Wireless Router. Allow you to change the wireless settings to fit 
      an existing wireless network or to customize your wireless network.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=59><font face=Arial><b>SSID</b><br>
      <font size="2">Service Set Identifier (SSID) is the name designated for 
      a specific wireless local area network (WLAN). The SSID's factory default 
      setting is "<?query("/sys/ssid");?>". The SSID can be easily changed to connect to an existing 
      wireless network or to establish a new wireless network.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=59><font face=Arial><b>Channel</b> <br>
      <font size="2">Indicates the channel setting for the <?=$modelname?>. By default 
      the channel is set to 6. The Channel can be changed to fit the channel setting 
      for an existing wireless network or to customize the wireless network.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=59><font face=Arial><b>Authentication</b><br>
      <font size="2">For added security on the wireless network, when enabling 
      Encryption, the Authentication type can also be selected. If Shared Key 
      is selected, the Access Point will not be seen on the wireless network except 
      to the wireless clients that share the same WEP key with MAC Addresses allowed 
      access as specified in Filter List. If Open System is chosen, only the wireless 
      clients with the same WEP key will be able to communicate on the wireless 
      network, but the Access Point will be visible to all devices on the network. 
      The default value for Authentication is set to "Open System".</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=59><font face=Arial><b>WEP</b> <br>
      <font size="2">Wired Equivalent Protocol (WEP) is a wireless security protocol 
      for Wireless Local Area Networks (WLAN). WEP provides security by encrypting 
      the data that is sent over the WLAN. The <?=$modelname?> supports 2 levels of WEP 
      Encryption: 64Bit encryption and 128Bit encryption. 
      WEP is disabled by default. The WEP setting can be changed to fit an existing 
      wireless network or to customize your wireless network.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=59><font face=Arial><b>Key Type</b> <br>
      <font size="2">The Key Types that are supported by the <?=$modelname?> are HEX (Hexadecimal) 
      and ASCII (American Standard Code for Information Interchange.) The Key 
      Type can be changed to fit an existing wireless network or to customize 
      your wireless network.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=59><font face=Arial><b>KEYS</b> <br>
      <font size="2">Keys 1-4 allow you to easily change wireless encryption settings to maintain a secure network.  Simply select the specific key to be used for encrypting wireless data on the network.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=59><font face=Arial><b>WPA</b> <br>
      <font size="2">Wi-Fi Protected Access authorizes and authenticates users onto 
	  the wireless network. WPA uses stronger security than WEP and is based on a key 
	  that changes automatically at a regular interval. This mode requires a RADIUS 
	  server in the network.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=59><font face=Arial><b>WPA-PSK</b> <br>
      <font size="2">Pre-Shared Key mode means that the wireless client and the router 
	  must have the same passphrase in order to establish the wireless connection. 
	  A RADIUS server is not required with PSK.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=46><font face=Arial><b>WAN Settings</b> <a name=02></a><br>
      <font size="2">WAN (wide area network) Settings are settings that are used to connect to your ISP (Internet Service Provider). The WAN settings are provided to you by your ISP and often times referred to as "public settings". Please select the appropriate option for your specific ISP.</font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=124> 
      <p><font face=Arial><b>WAN - Dynamic IP Address</b><br>
        <font size="2">Select this option if your ISP (Internet Service Provider) 
        provides you an IP address automatically. Cable modem providers typically 
        use dynamic assignment of IP Address.</font></font></p>
      <p><font face="Arial" size="2"><b><i>Host Name</i></b> - (optional) The 
        Host Name field is optional but may be required by some Internet Service 
        Providers. The default host name is the model number of the device.</font></p>
      <p><font face="Arial" size="2"><b><i>MAC Address</i></b> - (optional) The 
        MAC (Media Access Control) Address field is required by some Internet 
        Service Providers (ISP). The default MAC address is set to the MAC address 
        of the WAN interface in the device. You can use the "Clone MAC Address" 
        button to automatically copy the MAC address of the Ethernet Card installed 
        in the computer used to configure the device. It is only necessary to 
        fill the field if required by your ISP.</font><br>
      </p>
    </td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=142> 
      <p><font face=Arial><b>WAN - Static IP Address</b><br>
        <font size="2">If required by your ISP (Internet Service Provider) select this option to configure the device with the static IP Address information. Enter in the IP address, subnet mask, gateway address, and DNS (domain name server) address(es) provided to you by your ISP. Each IP address entered in the fields must be in the appropriate IP form, which are four IP octets separated by a dot (x.x.x.x). The Router will not accept the IP address if it is not in this format.</font></font></p>
      <p><font face=Arial color=#FF0000 size=2><i>Example:</i></font><font face=Arial> 
        <font size="2">192.168.100.100</font><br>
        </font></p>
    </td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=47> 
      <p><font face=Arial><b>WAN - PPPoE </b><br>
        <font size=2>Select this option if your ISP requires you to use a PPPoE (Point to Point Protocol over Ethernet) connection. DSL providers typically use this option. Select Dynamic PPPoE to obtain an IP address automatically for your PPPoE connection (used by majority of PPPoE connections). Select Static PPPoE to use a static IP address for your PPPoE connection. </font></font></p>
      <p><b><font face=Arial><i><font size=2>User Name</font></i></font></b><font face=Arial size=2> 
        - Enter your PPPoE username.<br>
        <b><i>Password</i></b> - Enter your PPPoE password.<br>
        <i><b>Service Name</b></i> - If your ISP uses a service name for the PPPoE 
        connection, enter the service name here. (optional)</font></p>
      <p><font face=Arial color=#FF0000 size=2><i>Example:</i></font><font face=Arial></font><font face=Arial size=2>@earthlink.net<br>
        <br>
        <i><b>IP Address</b></i> - This option is only available for Static PPPoE. 
        Enter in the static IP address for the PPPoE connection.</font><br>
        <font face=Arial size=2><i><b>Primary DNS Address</b></i> - Primary DNS 
        (Domain Name Server) IP provided by your ISP.<br>
        <i><b>Secondary DNS Address</b></i> - optional<br>
        <i><b>Maximum Idle time </b></i>- The amount of time of inactivity before the device will disconnect your PPPoE session. Enter a Maximum Idle Time (in minutes) to define a maximum period of time for which the Internet connection is maintained during inactivity. If the connection is inactive for longer than the defined Maximum Idle Time, then the connection will be dropped. Either set the value for idle time to zero or enable Auto-reconnect to disable this feature. <br>
        <b><i>Auto-reconnect</i></b> - If enabled, the device will automatically connect to your ISP after your unit is restarted or when the connection is dropped.</font></p>
   	<p><font face=Arial><b>WAN - Others </b><br>
	 <font size=2>PPTP, L2TP and BigPond Cable. </font></font></p>
        <p><font face="Arial" size="2"><b><i>PPTP</i></b> - For Europe use only.</font><br>
        <font face="Arial" size="2"><b><i>L2TP</i></b> - For specific ISPs use only.</font><br>
        <font face="Arial" size="2"><b><i>BigPond Cable</i></b> - For Australia use only.</font></p>
       </td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=71><font face=Arial><b>LAN Settings</b> <a name=03></a><br>
      <font size=2>These are the IP settings of the LAN (Local Area Network) interface for the device. These settings may be referred to as "private settings". You may change the LAN IP address if needed. The LAN IP address is private to your internal network and cannot be seen on the Internet. The default IP address is <?query("/sys/ipaddr");?> with a subnet mask of <?query("/sys/netmask");?>.<br>
      <i><b>IP Address:</b></i> IP address of the <?=$modelname?>, default is <?query("/sys/ipaddr");?>.<br>
      <i><b>Subnet Mask:</b></i> Subnet Mask of <?=$modelname?>, default is <?query("/sys/netmask");?>.<br>
      <i><b>Local Domain Name:</b></i> (optional) Enter in the local domain name 
      for the network.<br>
      </font></font></td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr> 
    <td height=211><font face=Arial><b>DHCP Server</b> <a name=04></a><br>
      <font size="2">DHCP stands for Dynamic Host Control Protocol. The DHCP server gives out IP addresses when a device is starting up and request an IP address to be logged on to the network. The device must be set as a DHCP client to "Obtain the IP address automatically". By default, the DHCP Server is enabled in the unit. The DHCP address pool contains the range of the IP address that will automatically be assigned to the clients on the network.</font><br>
      <b><i><font size=2>Starting IP address</font></i></b><font size=2> - The 
      starting IP address for the DHCP server's IP assignment. <br>
      <b><i>Ending IP address</i></b> - The ending IP address for the DHCP server's 
      IP assignment. <br>
      <b><i>Lease Time</i> </b>- The length of time for the IP lease.</font></font> 
      <p><font face=Arial size=2>DHCP client computers connected to the unit will have their information displayed in the DHCP Client Table. The table will show the Host Name, IP Address, MAC Address, and Lease Time of the DHCP lease for each client computer.</font></p>
    </td>
  </tr>
  <tr> 
    <td height=20>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <font face=Arial><b>Static DHCP</b><br>
	  <font size="2">Static DHCP allows the router to assign the same IP address
      information to a specific computer on the local network. The specified
      computer will get the same DHCP IP address information everytime it is
      turned on. No other computer on the local network will receive the
      specified static DHCP address except for the configured computer. Static
      DHCP is very helpful when used for server computers on the local network
      that are hosting applications such as Web and FTP.</font></font>
	</td>
  </tr>
</table>
</body>
</html>
