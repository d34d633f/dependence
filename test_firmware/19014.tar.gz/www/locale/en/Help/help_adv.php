<HTML>
<HEAD>
<TITLE><?query("/sys/hostname");?></TITLE>
<link rel="stylesheet" href="/www/comm/webCSS.css" type="text/css">
<META HTTP-EQUIV=Content-Type CONTENT="no-cache">
<META HTTP-EQUIV=Content-Type CONTENT="text/html; charset=iso-8859-1">
</HEAD>
<body bgcolor=#FFFFFF text=#000000>
<table border=0 cellspacing=0 cellpadding=0 width=750 height=799>
  <tr> 
    <td height=40 colspan="2"><font size=4><b>Advanced</b></font></td>
  </tr>
  <tr> 
    <td height=63 colspan="2"><b>Virtual Server</b><a name=05></a><br>
      The device can be configured as a virtual server so that remote 
      users accessing services such as Web or FTP services via the public (WAN) 
      IP address can be automatically redirected to local servers in the LAN network. 
      Depending on the requested service (TCP/UDP port number), the device redirects 
      the external service request to the appropriate server within the LAN network. 
      At the bottom of the screen, there are already defined well-known virtual 
      services. To use them, click on the edit icon. You will only need to input 
      the LAN IP address of the computer running the service and enable it.<br>
      <i><b>Name</b></i> - The name referencing the virtual service.<br>
      <i><b>Private IP</b></i> - The server computer 
      in the LAN network that will be providing the virtual services.<br>
      <i><b>Private Port</b></i> - The port number of the service used by the 
      Private IP computer.<br>
      <i><b>Protocol Type</b></i> - The protocol used for the virtual service.<br>
      <i><b>Public Port</b></i> - The port number on the WAN side that will be 
      used to access the virtual service.<br>
      <i><b>Schedule</b></i> - The schedule of time when the virtual service will 
      be enabled. 
      <p><font color=#FF0000>Example:</font><br>
        If you have a Web server that you wanted Internet users to access at all 
        times, you would need to enable it. Web (HTTP) server is on LAN computer 
        192.168.0.25. HTTP uses port 80, TCP.</p>
      <p>Name: Web Server<br>
        Private IP: 192.168.0.25<br>
        Protocol Type: TCP<br>
        Private Port: 80<br>
        Public Port: 80<br>
        Schedule: always<br>
      </p>
    </td>
  </tr>
  <tr> 
    <td colspan="2" height=100><img src="/graphic/help_adv_p1.jpg" width="523" height="71"></td>
  </tr>
  <tr> 
    <td width="48" height=55><img src="/graphic/edit.gif" width="48" height="54"><br>
    </td>
    <td width="702" height=55>Click on this icon to edit the virtual service.</td>
  </tr>
  <tr> 
    <td height=32 width="48"><img src="/graphic/delet.gif" width="45" height="54"></td>
    <td height=32 width="702"><font face="Geneva, Arial, Helvetica, san-serif">Click 
      on this icon to delete the virtual service.</font></td>
  </tr>
  <tr> 
    <td height=20 colspan="2"></td>
  </tr>
  <tr> 
    <td height=228 colspan="2"><b>Special Applications</b> <a name=06></a><br>
      Some applications require multiple connections, such as Internet 
      gaming, video conferencing, Internet telephony and others. These applications 
      have difficulties working through NAT (Network Address Translation). If 
      you need to run applications that require multiple connections, specify 
      the port normally associated with an application in the "Trigger Port" field, 
      select the protocol type as TCP (Transmission Control Protocol) or UDP (User 
      Datagram Protocol), then enter the public ports associated with the trigger 
      port to open them for inbound traffic. At the bottom of the screen, there 
      are already defined well-known special applications. To use them, click 
      on the edit icon and enable the service.<br>
      <i><b> Name</b></i> - This is the name 
      referencing the special application.<br>
      <i><b>Trigger Port </b></i>- This is the port used to trigger the application. 
      It can be either a single port or a range of ports.<br>
      <i><b>Trigger Type</b></i> - This is the protocol used to trigger the special 
      application.<br>
      <i><b>Public Port</b></i> - This is the port number on the WAN side that 
      will be used to access the application. You may define a single port or 
      a range of ports. You can use a comma to add multiple ports or port ranges.<br>
      <i><b>Public Type</b></i> - This is the protocol used for the special application.</td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=64 colspan="2"><b>Filters</b> <a name=07></a><br>
      Filters are used to deny or allow LAN computers from accessing 
      the Internet. Within the local area network, the unit can be setup to deny 
      Internet access to computers using the assigned IP or MAC addresses. The 
      unit can also block users from accessing restricted web sites.</td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=99 colspan="2"><b>Filter - IP Filters</b><br>
      Use IP Filters to deny particular LAN IP addresses from accessing 
      the Internet. You can deny specific port numbers or all ports for a specific 
      IP address. The screen will display well-known ports that are defined. To 
      use them, click on the edit icon. You will only need to input the LAN IP 
      address(es) of the computer(s) that will be denied Internet access.<br>
      <b><i>IP</i> </b>- The IP address of the 
      LAN computer that will be denied access to the Internet. You can also add 
      a range of IP addresses.<br>
      <b><i>Port</i></b> - The single port or port range that will be denied access 
      to the Internet.<br>
      <i><b>Protocol Type</b></i><i><b> </b></i>- 
       This is the protocol type that will be used 
      with the Port that will be blocked.<br>
      <i><b>Schedule </b></i>- This is the schedule of time when the IP Filter 
      will be enabled.</td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=44 colspan="2"><b>Filters - MAC Filters</b><br>
      Use MAC Filters to deny computers within the local area network 
      from accessing the Internet. You can either manually add a MAC address or 
      select the MAC address from the list of clients that are currently connected 
      to the unit.<br>
      Select &quot;Only <b>allow</b> computers with MAC address listed below to 
      access the network&quot; if you only want selected computers to have network 
      access and all other computers not to have network access. <br>
      Select &quot;Only <b>deny</b> computers with MAC address listed below to 
      access the network&quot; if you want all computers to have network access 
      except those computers in the list.<br>
      <i><b>Name:</b></i> The name referencing the MAC filter.<br>
      <i><b>MAC Address: </b></i>The MAC address of the computer in the LAN (Local 
      Area Network) to be used in the MAC filter table.<br>
      <i><b>DHCP Client:</b></i> DHCP clients will have their host name and MAC 
      address listed here. You can select the client computer you want to add 
      to the MAC filter and click <b>Clone</b>. This will automatically add that 
      computer's MAC address to the <b>MAC Address</b> section</td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=20 colspan="2"><b>Parental Control</b> <a name=7_1></a><br></td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=84 colspan="2"><b>URL Blocking</b><br>
      URL Blocking is used to deny computers within the LAN (Local 
      Area Network) from accessing specific web sites by its URL (Uniform Resource 
      Locator). A URL is a specially formatted text string that defines a location 
      on the Internet. If any part of the URL contains the blocked word, the site 
      will not be accessible and the web page will not be displayed.<i><font color="#FF0000"><br>
      Example:</font></i><br>
      If you wanted to block LAN users from any website containing a URL pertaining 
      to shopping, you would need to enter &quot;shopping&quot; into the URL Blocking 
      list. Sites like these will be denied access to LAN users because they contain 
      the keyword in the URL.<br>
      <a href="../www.yahoo.com/shopping/stores.html">http://www.yahoo.com/shopping/stores.html</a><br>
      <a href="../www.msn.com/search/shopping-spree.html">http://www.msn.com/search/shopping-spree.html</a></td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=248 colspan="2"> 
      <div align=left><b>Domain Blocking</b><br>
        Domain Blocking is used to deny or allow computers within 
        the LAN (Local Area Network) from accessing specific domains on the Internet. 
        Domain blocking will deny or allow all requests such as http and ftp to 
        a specific domain.<br>
        Select <b>Allow</b> users to access all domains except &quot;Blocked Domains&quot; 
        if you allow users to access all domains except the domains in the Blocked 
        Domains list.<br>
        Select <b>Deny</b> users to access all domains except &quot;Permitted 
        Domains&quot; if you only want users to access Permitted 
        Domains. 
        <p><i><font color="#FF0000">Example:</font></i> 
          If you want your children to only access particular sites, you would 
          then choose <b>Deny</b> users to access all domains except &quot;Permitted 
          Domains&quot;. Then enter in the domains you want your children to have 
          access to.</p>
      </div>
      <ul>
        <li> 
          <div align=left>Disney.com</div>
        </li>
        <li> 
          <div align=left>Cartoons.com</div>
        </li>
        <li> 
          <div align=left>DiscoveryChannel.com</div>
        </li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=20 colspan="2"><b>Firewall Rules</b> <a name=08></a><br>
      Firewall Rules is an advance feature used to deny or allow 
      traffic from passing through the device. It works in the same way as IP 
      Filters with additional settings. You can create more detailed rules for 
      the device. Please refer to the manual for more details and examples.</td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=20 colspan="2"><b>DMZ</b> <a name=09></a><br>
      If you have a computer that cannot run Internet applications 
      properly from behind the device, then you can allow the computer to have 
      unrestricted Internet access. Enter the IP address of that computer as a 
      DMZ (Demilitarized Zone) host with unrestricted Internet access. Adding 
      a client to the DMZ may expose that computer to a variety of security risks; 
      so only use this option as a last resort.</td>
  </tr>
  <tr> 
    <td height=20 colspan=2>&nbsp;</td>
  </tr>
  <tr> 
    <td height=69 colspan=2><font face=Arial><b>Dynamic DNS</b><a name=10></a><br>
      Dynamic DNS (Domain Name Service) is a method of keeping a domain name
      linked to a changing (dynamic) IP address. With most Cable and DSL
      connections, you are assigned a dynamic IP address and that address is used
      only for the duration of that specific connection. With the <?=$modelname?>, you can
      setup your DDNS service and the <?=$modelname?> will automatically update your DDNS
      server every time it receives a different IP address.</font></td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=20 colspan="2"><b>Wireless Performance</b> <a name=11></a><br>
      <br>
      <b>Beacon interval</b><br>
      Beacons are packets sent by an Access Point to synchronize 
      a wireless network. Specify a Beacon interval value between 20 and 1000. 
      The default value is set to 100 milliseconds.</td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=20 colspan="2"><b>RTS Threshold</b><br>
      This value should remain at its default setting of 2346. 
      If you encounter inconsistent data flow, only minor modifications to the 
      value range between 1 and 2346 are recommended. The default value for RTS 
      Threshold is set to 2346.</td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=20 colspan="2"><b>Fragmentation</b><br>
      This value should remain at its default setting of 2346. 
      If you experience a high packet error rate, you may slightly increase your 
      "Fragmentation" value within the value range of 256 to 2346. Setting the 
      Fragmentation value too low may result in poor performance.</td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=20 colspan="2"><b>DTIM interval (beacon rate)</b><br>
      Enter a value between 1 and 255 for the Delivery Traffic 
      Indication Message (DTIM). A DTIM is a countdown informing clients of the 
      next window for listening to broadcast and multicast messages. When the 
      Access Point has buffered broadcast or multicast messages for associated 
      clients, it sends the next DTIM with a DTIM Interval value. AP clients hear 
      the beacons and awaken to receive the broadcast and multicast messages. 
      The default value for DTIM interval is set to 1.</td>
  </tr>
  <!--tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=20 colspan="2"><b>Transmission (TX) Rates</b><br>
      Select the basic transfer rates based on the speed of wireless 
      adapters on the WLAN (wireless local area network).</td>
  </tr-->
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height=20 colspan="2"><b>Preamble Type</b><br>
      The Preamble Type defines the length of the CRC (Cyclic Redundancy 
      Check) block for communication between the Access Point and roaming wireless 
      adapters. Make sure to select the appropriate preamble type and click the 
      Apply button.<br>
      <font color="#FF0000"><b>Note:</b></font>High network traffic areas should 
      use the shorter preamble type. CRC is a common technique for detecting data 
      transmission errors.</td>
  </tr>
  <tr> 
    <td height=20 colspan="2">&nbsp;</td>
  </tr>
</table>
</body>
</html>
