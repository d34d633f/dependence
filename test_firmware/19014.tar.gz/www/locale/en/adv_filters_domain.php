<? /* vi: set sw=4 ts=4: */
$a_exceed_maximum_entry_number="Exceed maximum entry number \"+MaxPat+\"!";
$a_same_domain_entry_exists="A entry with the same domain exists!";
$a_are_you_sure_to_delete_this="Are you sure you want to delete this ?";
$a_invalid_domain= "Invalid Domain Name.\\n".$a_plz_use_valid_char;

$m_title="Domain Blocking";
$m_disabled="Disabled";
$m_allow_all_domains_except_blocked_ones="<b>Allow</b> users to access all domains except Blocked Domains";
$m_deny_all_domains_except_permitted_ones="<b>Deny</b> users to access all domains except Permitted Domains";
$m_blocked_domains="Blocked Domains";
$m_permitted_domains="Permitted Domains";
$m_blocked_domains_list="Blocked Domains List";
$m_permitted_domains_list="Permitted Domains List";
?>
