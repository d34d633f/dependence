<?require("/www/locale/".$__LANG."/sch_msg.php");?>
<tr>
	<td height=26 class=r_tb><?=$m_schedule?>&nbsp;</td>
	<td height=26 class=l_tb><input type=radio name=schd value=0 <?if($schd!="1"){echo "checked";}?>><?=$m_always?></td>
</tr>
<tr>
	<td></td>
	<td>
	<table cellspacing=2 cellpadding=0>
	<tr>
		<td width=12% height=25 class=l_tb>
		<input type=radio name=schd value=1 <?if($schd=="1"){echo "checked";}?>><?=$m_from?>
		</td>
		<td width=10% class=r_tb><?=$m_time?></td>
		<td class=l_tb><script>
		print_select("hour1",0,11,1);echo(" : ");print_select("min1",0,55,5);print_am("am1");echo("to ");
		print_select("hour2",0,11,1);echo(" : ");print_select("min2",0,55,5);print_am("am2");
		</script></td>
	</tr>
	<tr>
		<td height=25></td>
		<td height=25 class=r_tb><?=$m_day?></td>
		<td height=25 class=l_tb>
		<script>print_week("day1");echo("to");print_week("day2");setSchedule();</script>
		</td>
	</tr>
	</table>
	</td>
</tr>
