<?
/* vi: set sw=4 ts=4: */
$a_password_only_allow_ascii_code="Password only allow ASCII code!";
$a_password_not_match="The Password and Confirm Passord do not match!";

$m_title="Set Password";
$m_title_desc="You may change the <b>admin</b> account password by entering in a new password. Click <b>Next</b> to continue.";
$m_password="Password";
$m_confirm_password="Confirm Password";
?>
