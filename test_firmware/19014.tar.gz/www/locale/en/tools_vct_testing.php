<?
/* vi: set sw=4 ts=4: */
$g_ww_cvt="../graphic/ww_vct.jpg";
$m_cable_diagnosing="Cable Diagnosing ...";
?>

