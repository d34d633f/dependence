<?
$a_domin_only_ascii="Domain Name only allow ASCII code!";
$a_IP_cant_in_dhcp_range="The IP Address can't be in the DHCP range";

$m_lan_steeings="LAN Settings";
$m_lan_setting_description="The IP address of the ".query("/sys/modelname").".";
$m_local_domain_name="Local Domain Name";
$m_dns_relay="DNS Relay";
?>
