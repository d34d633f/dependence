<? /* vi: set sw=4 ts=4: */ 
/*$m_days="days";
$m_hrs="hrs";
$m_mins="mins";
$m_secs="secs";
$m_expired="Expired";
*/
$a_port_number_must_be_1_65535="Port number must be between 1 and 65535 !!!";
$a_value=" value.";
$a_err_mask_in_1st_digit=" in 1st digit.\\nIt should be the number of 128, 192, 224, 240, 248, 252 or 254";
$a_err_mask_in_2nd_digit=" in 2nd digit.\\nIt should be the number of 0, 128, 192, 224, 240, 248, 252 or 254";
$a_err_mask_in_3rd_digit=" in 3rd digit.\\nIt should be the number of 0, 128, 192, 224, 240, 248, 252 or 254";
$a_err_mask_in_4th_digit=" in 4th digit.\\nIt should be the number of 0, 128, 192, 224, 240, 248, 252 or 254";
$a_value_should_be_decimal_number=" value. It should be the decimal number (0-9).";
$a_err_ip_range_in_1st_digit=" range in 1st digit. It should be 1-223 and not be 127.";
$a_err_ip_range_in_2nd_digit=" range in 2nd digit. It should be 0-255.";
$a_err_ip_range_in_3rd_digit=" range in 3rd digit. It should be 0-255.";
$a_err_ip_range_in_4th_digit=" range in 4th digit. It should be 1-254.";
$a_is_reserved_for_network_host=" is reserved for network host.";
$a_is_reserved_for_broadcast=" is reserved for broadcast.";
?>
