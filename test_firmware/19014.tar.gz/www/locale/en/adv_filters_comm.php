<?
$m_filters="Filters";
$m_filter_description="Filters are used to allow or deny LAN users from accessing the Internet.";
$m_ip_filters="IP Filters";
$m_mac_filters="MAC Filters";
?>
