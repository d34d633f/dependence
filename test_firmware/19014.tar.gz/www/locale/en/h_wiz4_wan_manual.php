<?
/* vi: set sw=4 ts=4: */
$m_title="Select Internet Connection Type (WAN)";
$m_title_desc="Select the connection type to connect to your ISP. Click <b>Next</b> to continue.";
$m_dynamic_ip_addr="Dynamic IP Address";
$m_dynamic_ip_addr_desc="Choose this option to obtain an IP address automatically from your ISP.(For most Cable modem users)";
$m_static_ip_addr="Static IP Address";
$m_static_ip_addr_desc="Choose this option to set static IP information provided to you by your ISP.";
$m_pppoe="PPPoE";
$m_pppoe_desc="Choose this option if your ISP uses PPPoE.(For most DSL users)";
$m_pptp="PPTP";
$m_pptp_desc="PPTP Client";
$m_l2tp="L2TP";
$m_l2tp_desc="L2TP Client";
$m_bigpond="BigPond";
$m_bigpond_desc="BigPond Cable";
?>
