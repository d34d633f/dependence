<? /* vi: set sw=4 ts=4: */
$m_apply_successfully="Apply Successfully!";
?>
