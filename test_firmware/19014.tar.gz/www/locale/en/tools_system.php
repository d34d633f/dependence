<?
/* vi: set sw=4 ts=4: */
/* -------------------------message start----------------------*/
$a_restore_to_factory_default_setting="Restore To Factory Default Settings ?";
$a_load_settings_from_file="Load Settings From File ?";
$a_reboot_router="Reboot Router ?";
$a_reset_jumpstart="Reset JumpStart?";

$m_title="System Settings";
$m_save_settings_to_hdd="Save Settings To Local Hard Drive";
$m_save="Save";
$m_load_settings_from_hdd="Load Settings From Local Hard Drive";
$m_load="Load";
$m_jumpstart_function="JumpStart function:";
$m_enabled="Enabled";
$m_disabled="Disabled";
$m_apply="Apply";
$m_reset_jumpstart="Reset JumpStart";
$m_restore="Reset";
$m_restore_to_factory_default_setting="Restore To Factory Default Settings";
$m_reboot_device="Reboot the ".query("/sys/modelname").".";
$m_reboot="Reboot";
/* -------------------------message end------------------------ */
?>

