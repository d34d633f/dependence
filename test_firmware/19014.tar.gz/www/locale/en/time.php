<? /* vi: set sw=4 ts=4: */
$m_week_list="\"Sun\",\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\"";
$m_month_list="\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"May\",\"Jun\",\"Jul\",\"Aug\",\"Sep\",\"Oct\",\"Nov\",\"Dec\"";
$m_days="days";
$m_hrs="hrs";
$m_mins="mins";
$m_secs="secs";
$m_expired="Expired";
?>
