<?
// -----------------------message start----------------------------
$m_setup_completed="Setup Completed.";
$m_close="Close";
// -----------------------message end------------------------------ 
?>
