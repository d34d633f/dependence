<?
/* vi: set sw=4 ts=4: */
/* ------------------------message start------------------------*/
$a_you_must_select_a_firmware_file="You must select a firmware file.";

$m_title="Firmware Upgrade";
$m_title_desc="To upgrade the firmware, locate the upgrade file on the local hard drive with the Browse button. Once you have found the file to be used, click the Apply button below to start the firmware upgrade.";
$m_current_firmware_version="Current Firmware Version:";
/* ------------------------message end-------------------------- */
?>
