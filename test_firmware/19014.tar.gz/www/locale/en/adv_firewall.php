<?
$a_sure_to_delete_this		= "Are you sure you want to delete this ?";
$a_exceed_max_count		= "\"Exceed maximum entry number \" + MaxRule + \"!\"";
$a_same_dir_not_support		= "Allow/Deny traffic from \"WAN to WAN\" or \"LAN to LAN\" does not support!";
$a_fw_name_cant_be_empty	= "The Firewall Rules Name can not be empty!";
$a_invalid_src_start_ip		= "Invalid Source Start IP address";
$a_invalid_src_end_ip		= "Invalid Source End IP address";
$a_invalid_dest_start_ip	= "Invalid Destination Start IP address";
$a_invalid_dest_end_ip		= "Invalid Destination End IP address";
$a_src_start_gt_src_end		= "Invalid Source IP Range. The IP Range Start is greater than IP Range End.";
$a_dest_start_gt_dest_end	= "Invalid Destination IP Range. The IP Range Start is greater than IP Range End.";
$a_port_start_should_be_num	= "The Value of Starting Port should be a number.";
$a_port_end_should_be_num	= "The Value of Ending Port should be a number.";
$a_start_port_gt_end_port	= "The Starting Port is greater than The Ending Port!";
$a_starttime_cant_big_then_end  = "Begin time can not equal or bigger than start time!";

$m_fw_title		= "Firewall Rules";
$m_fw_description	= "Firewall Rules can be used to allow or deny traffic from passing through the ".
			  query("/sys/modelname").".";
$m_clear		= "Clear";
$m_all			= "ALL";
$m_any			= "ANY";
$m_default		= "Default";
$m_action		= "Action";
$m_allow		= "Allow";
$m_deny			= "Deny";
$m_interface		= "Interface";
$m_ip_range_start	= "IP Range Start";
$m_ip_range_end		= "IP Range End";
$m_protocol		= "Protocol";
$m_port_range		= "Port Range";
$m_source		= "Source";
$m_destination		= "Destination";
$m_schedule		= "Schedule";
$m_fw_list		= "Firewall Rules List";
$m_allow_ping		= "Allow to Ping WAN port";
$m_remote_management	= "Remote Management HTTP Server";
?>
