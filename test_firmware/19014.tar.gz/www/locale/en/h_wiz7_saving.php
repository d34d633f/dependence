<?
/* vi: set sw=4 ts=4: */
// ----------------------------message start---------------------
$m_setup_completed="Setup Completed";
$m_title_desc="The Setup Wizard has completed. Click on <b>Back</b> to modify changes or mistakes. Click on <b>Restart</b> to save the current settings and restart the ".query("/sys/modelname").".";
// ----------------------------message end----------------------- 
?>
