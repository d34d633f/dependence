<?
/* vi: set sw=4 ts=4: */
$g_ww_cvt="../graphic/ww_vct.jpg";
$g_link="../graphic/link.gif";
$g_nolink="../graphic/nolink.gif";
$g_exit_p="../graphic/exit_p.jpg";

$m_disconnected="Disconnected";
$m_100full="100Full";
$m_100half="100Half";
$m_10full="10Full";
$m_10half="10Half";
$m_error="Error";
$m_normal_cable="Normal Cable";
$m_open_cable="Open Cable";
$m_short_cable="Short Cable";
$m_wan="WAN";
$m_lan="LAN";
$m_txpair_normal_cable="TxPair Normal cable!";
$m_rxpair_normal_cable="RxPair Normal cable!";
$m_txpair_status="TxPair \"+getStatString(txstatus)+\" at \"+txmeter+\" meters";
$m_rxpair_status="RxPair \"+getStatString(rxstatus)+\" at \"+txmeter+\" meters";
?>

