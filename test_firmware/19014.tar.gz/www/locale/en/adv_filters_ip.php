<?
$a_exced_max_entry="\"Exceed maximum entry number \" + MaxRule + \"!\"";
$a_ip_cant_include_lanIP="\"IP Address can't include the LAN IP Address(\"+lanip+\").\"";
$a_should_be_in_same_subnet="\"Invalid IP address!\\nIt should be located in the same subnet of current LAN IP address(\"+lanip+\").\"";
$a_error_endIP="Error ending IP";
$a_error_startIP="Error start IP";
$a_endIP_should_be_greater_than_startIP="The end IP should be greater than the start IP!";
$a_start_port_should_be_number="The value of the start port should be a number";
$a_end_port_should_be_number=" The value of the end port should be a number";
$a_end_port_should_be_greater_than_start_port=" The end port should be greater than the start port!";
$a_starttime_cant_big_then_end= "Begin time can not equal or bigger than start time!";
$a_same_entry_exist="A entry with the same setting exists!";

$m_ip_filters_description="Use IP Filters to deny LAN IP addresses access to the Internet.";
$m_ip_filter_list="IP Filter List";
$m_ip_range="IP Range";
$m_pro="Protocol";
?>
