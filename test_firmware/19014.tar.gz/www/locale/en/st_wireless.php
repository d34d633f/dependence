<?
$m_connected_wlan_client_list="Connected  Wireless Client List";
$m_title_desc="The Wireless Client table below displays Wireless clients connected to the AP (Access Point).";
$m_connected_time="Connected Time";
$m_mac_addr="MAC Address";
$m_mode="Mode";
?>
