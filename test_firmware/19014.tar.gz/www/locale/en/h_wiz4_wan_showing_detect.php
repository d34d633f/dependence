<?
/* vi: set sw=4 ts=4: */
$m_title="Auto Detecting WAN";
$m_message="Please wait a moment ...";
?>
