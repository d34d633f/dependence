<?
$a_startIP_should_be_1_254="The Value (Starting IP Address) should be between 1 and 254!";
$a_startIP_wrong_format="The Starting IP Address that you input is in a wrong format!";
$a_endIP_should_be_1_254="The Value (Ending IP Address) should be between 1 and 254!";
$a_endIP_wrong_format="The Ending IP Address that you input is in a wrong format!";
$a_startIP_bigger_endIP="The Starting IP Address is bigger than The Ending IP Address!";
$a_dhcpIP_cant_include_lanIP="The DHCP IP Address range can't include the LAN IP Address";
$a_exceed_max_rule="Exceed maximum entry number";
$a_static_dhcp_name_cant_empty="The Name of Static DHCP can't be empty.";
$a_staticIP_should_be_1_254="The Value (Static DHCP Client IP Address) should be between 1 and 254!";
$a_staticIP_should_be_number="The Value (Static DHCP Client IP Address) should be a number!";
$a_staticIP_cant_same_lanIP="The Static DHCP IP can't be the same with the LAN IP Address";
$a_staticIP_wrong_format="The Static DHCP Client MAC Address that you input is in a wrong format!";
$a_staticIP_wrong_format="The Static DHCP Client MAC Address that you input is in a wrong format!";
$a_sameIP_exist="A entry with the same IP Address exists!";
$a_sameMAC_exist="A entry with the same MAC Address exists!";
$a_hostname_only_ascii="Host Name only allow ASCII code!";
$a_realy_del="Are you sure you want to delete this ?";

$m_DHCP_srv="DHCP Server";
$m_DHCP_explain="The ".query("/sys/modelname")." can be setup as a DHCP Server to distribute IP addresses to the LAN network.";
$m_startIP="Starting IP Address";
$m_endIP="Ending IP Address";
$m_lease_time="Lease Time";
$m_static_dhcp="Static DHCP";
$m_static_dhcp_explain="Static DHCP is used to allow DHCP server to assign same IP address to specific MAC address.";
$m_dhcp_client="DHCP Client";
$m_static_dhcp_clint_list="Static DHCP Client List";
$m_number="Number";
$m_total="Total";
$m_hostname="Host Name";
$m_dhcp_client_list="Dynamic DHCP Client List";
$m_hr="Hour";
$m_hrs="Hours";
$m_day="Day";
$m_days="Days";
$m_wk="Week";
?>
