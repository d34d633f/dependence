<? /* vi: set sw=4 ts=4: */
$m_title_comm="Parental Control";
$m_title_desc_comm="Parental Control filters are used to allow or deny LAN users from accessing the Internet.";
$m_url_blocking="URL Blocking";
$m_domain_blocking="Domain Blocking";
?>
