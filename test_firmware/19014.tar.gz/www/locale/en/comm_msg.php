<?
$a_plz_use_valid_char="Please use the characters: a~z, A~Z, 0~9, ' ', '-', '.', '@' or '_' .";
$a_only_admin_account_can_change_the_settings="Only admin account can configure the settings!";

$m_enabled	="Enabled";
$m_disabled	="Disabled";

$m_clear	="Clear";

$m_name		="Name";
$m_user		="User Name";
$m_password	="Password";
$m_retype_passwd="Retype Password";
$m_host_name	="Host Name";

$m_ip_addr	="IP Address";
$m_subnet	="Subnet Mask";
$m_def_gw	="Default Gateway";
$m_mac_addr	="MAC Address";

$m_port		="Port";
$m_protocol	="Protocol";
$m_protocol_type="Protocol Type";

$m_schedule	="Schedule";
$m_always	="Always";

$m_priv_port 	="Private Port";
$m_pub_port	="Public Port";

$m_optional	="optional";

$m_number	="Number";
$m_total	="Total";
?>
