<?
/* vi: set sw=4 ts=4: */
// ---------------------------message start---------------------
$a_ssid_can_not_be_blank="The SSID can not be blank!";
$a_ssid_only_allow_ascii_code="SSID only allow ASCII code!";

$m_title="Set 802.11g Wireless LAN Connection";
$m_title_desc="Enter the SSID name and Channel number to be used for the Wireless Access Point. Click <b>Next</b> to continue.";
$m_ssid="SSID";
$m_channel="Channel";
// ---------------------------message end----------------------- 
?>
