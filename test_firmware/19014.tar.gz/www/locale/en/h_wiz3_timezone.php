<?
/* vi: set sw=4 ts=4 */
$m_title="Choose Time Zone";
$m_title_desc="Select the appropriate time zone for your location and click <b>Next</b> to continue.";
?>
