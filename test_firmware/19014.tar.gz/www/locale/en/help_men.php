<?
$m_setup_wizard="Setup Wizard"; 
$m_wireless_settings="Wireless Settings";
$m_wan_settings="WAN Settings";
$m_lan_settings="LAN Settings";
$m_dhcp_server="DHCP Server"; 
$m_virtual_server="Virtual Server";
$m_special_applications="Special Applications";
$m_filters="Filters";
$m_paretal_control="Parental Control";
$m_firewall_rules="Firewall Rules";
$m_dmz="DMZ";
$m_ddns="DDNS";
$m_wireless_performance="Wireless Performance";
$m_admin_setings="Administrator Settings";
$m_sys_time="System Time";
$m_sys_settings="System Settings";
$m_firm_upgrade="Firmware Upgrade";
$m_misc_items="Miscellaneous Items";
$m_cable_test="Cable Test";
$m_device_info="Device Information";
$m_log="Log";
$m_traffic_statistics="Traffic Statistics";
$m_conn_wireless_client_list="Connected Wireless Client List";
$m_active_session="Active Session";
$m_faq="FAQs";
?>
