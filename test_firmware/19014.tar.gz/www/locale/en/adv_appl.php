<?
$m_appl_title="Special Application";
$m_appl_descript="Special Application is used to run applications that require multiple connections.";
$m_trigger_port="Trigger Port";
$m_trigger_prot_type="Trigger Type";
$m_public_port="Public Port";
$m_public_prot_type="Public Type";
$m_appl_list="Special Applications List";
$m_trigger="Trigger";
$m_public="Public";
$m_both="Both";
$m_tcp="TCP";
$m_udp="UDP";
$g_edit="<img src='../graphic/edit.gif' width=15 height=17 border=0 alt=edit>";
$g_delete="<img src='../graphic/delet.gif' width=15 height=18 border=0 alt=delete>";
$a_err_exceed="\"Exceed maximum entry number \" + MaxRule + \"!\"";
$a_err_name="\"The Special Application Name can not be blank!\"";
$a_err_trigger_port_begin="\" The Value of The First Trigger Port should be a number\"";
$a_err_trigger_port_end="\" The Value of The Last Trigger Port should be a number\"";
$a_err_trigger_port_range="\" The First Value of The Trigger Port should be less than The Last Value\"";
$a_err_public_port_format="\" The Legal Format of Public Port: \\n\\n1.single number,ex. 1024\\t\\n2.serial number,ex. 103,163,55,...\\n3.number range,ex. 103-157\\n4.mix,ex. 103,106-1333,154\"";
$a_err_entry_exists="\" A entry with the same Trigger Port exists!\"";
$a_conf_delete="\" Are you sure you want to delete this ?\"";
$a_invalid_domain= "Invalid Application Name.\\n".$a_plz_use_valid_char;
?>
