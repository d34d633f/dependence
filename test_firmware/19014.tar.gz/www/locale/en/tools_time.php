<?
/* vi: set sw=4 ts=4: */
$a_err_ntp_server_ip_addr="Error NTP Server IP Address";
$a_ntp_server_ip_addr_can_not_be_empty="NTP Server IP address can not be empty!";

$m_title="Time";
$m_title_desc="Set the ".query("/sys/modelname")." system time.";
$m_device_time="Device Time";
$m_sync_clock_with="Synchronize the device's clock with:";
$m_sync_by_auto="Automatic (Simple Network Time Protocol)";
$m_sync_with_computer="Your Computer's clock";
$m_sync_by_manual="Manual (Enter your own settings)";
$m_time_zone="Time Zone";
$m_daylight_saving="Daylight Saving";
$m_get_time_via_ntp="Get the Time Automatically via Network Time Protocol(NTP)";
$m_ntp_server="NTP Server";
$m_optional="(optional)";
$m_interval="Interval";
$m_1hrs="1 hrs";
$m_4hrs="4 hrs";
$m_8hrs="8 hrs";
$m_12hrs="12 hrs";
$m_24hrs="24 hrs";
$m_48hrs="48 hrs";
$m_72hrs="72 hrs";
$m_time="Time";
$m_year="Year";
$m_month="Month";
$m_day="Day";
$m_hour="Hour";
$m_minute="Minute";
$m_second="Second";
?>

