<? /* vi: set sw=4 ts=4: */
$a_exit_wizard="Quit Setup Wizard and discard settings ?";
?>
