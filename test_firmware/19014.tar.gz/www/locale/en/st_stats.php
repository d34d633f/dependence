<?
// --------------------------message start--------------------------
$a_only_admin_account_can_clear_the_statistics="Only admin account can clear the statistics!";
$m_title="Traffic Statistics";
$m_title_desc="Traffic Statistics display Receive and Transmit packets passing through the ".query("/sys/modelname").".";
$m_refresh="Refresh";
$m_reset="Reset";
$m_interface="Interface";
$m_receive="Receive";
$m_transmit="Transmit";
$m_wan="WAN";
$m_lan="LAN";
$m_wireless="WIRELESS";
$m_packets="Packets";
// --------------------------message end---------------------------- */
?>
