<?
$m_refresh_title="Refresh";
$m_db_no_change_title="No Changed.";
$m_restart_title="Restart";
$m_wrong_image_title="Error";

$m_refreshing="Refreshing...";
$m_no_change="No Changed.";
$m_only_allow_admin="Only <b>admin</b> account can read or change the settings.";
$m_restarting="The device is restarting...";
$m_setting_saving="Setting Saving ...";
$m_wrong_image="The chosen file is not an image file.";

// only for /www/auth/session_full.php
$m_session_full="Too many connection. Please try later.";
$m_logout_message="This session was timeout. Please close this browser and reopen to login again !";

$g_continue="<img src=../graphic/continue.gif width=70 border=0>";

?>
