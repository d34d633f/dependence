<? /* vi: set sw=4 ts=4: */
$a_exceed_maximum_entry_number_x	= "\"Exceed maximum entry number \"+MaxPat+\"!\"";
$a_same_url_entry_exists			= "A entry with the same URL is exists!";
$a_invalid_url						= "Invalid URL.\\n".$a_plz_use_valid_char;
$m_confirm_delete_message			= "Are you sure you want to delete this ?";

$m_title		= "URL Blocking";
$m_title_desc	= "Block those URLs which contain keywords listed below.";
$m_url_keyword	= "URL Keyword";
$m_url_list		= "URL List";
?>
