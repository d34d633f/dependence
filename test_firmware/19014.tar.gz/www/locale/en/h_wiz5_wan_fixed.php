<?
/* vi: set sw=4 ts=4: */
$a_err_wan_ip_addr="Error WAN IP Address";
$a_err_wan_subnet_mask="Error WAN Subnet Mask";
$a_err_wan_gw_addr="Error WAN Gateway Address";
$a_err_pri_dns_addr="Error Primary DNS Address";
$a_err_sec_dns_addr="Error Secondary DNS Address";

$m_title="Set Static IP Address";
$m_title_desc="Enter the static IP information provided to you by your ISP. Click <b>Next</b> to continue.";
$m_ip_addr="IP Address";
$m_subnet="Subnet Mask";
$m_isp_gw_addr="ISP Gateway Address";
$m_pri_dns_addr="Primary DNS Address";
$m_sec_dns_addr="Secondary DNS Address";
?>
