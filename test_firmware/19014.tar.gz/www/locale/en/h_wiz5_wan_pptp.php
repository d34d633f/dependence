<?
/* vi: set sw=4 ts=4: */
$a_err_ip_addr="Error IP Address";
$a_err_subnet_mask="Error Subnet Mask";
$a_subnet_mask_is_wrong_format="The Subnet Mask is in a wrong IP format!";
$a_err_server_ip_addr="Error Server IP Address";
$a_pptp_account_name_is_blank="The PPTP Account Name can not be blank!";
$a_password_not_matched="The Password and Retype Passord do not match!";
$a_pptp_account_only_allow_ascii_code="PPTP Account only allow ASCII code!";
$a_pptp_password_only_allow_ascii_code="PPTP Password only allow ASCII code!";
$a_should_be_in_same_subnet="It should be in the same subnet of current IP address.";

$m_title="Set PPTP Client";
$m_title_desc="Please set your PPTP Client data then press <b>Next</b> to continue.";
$m_my_ip="My IP";
$m_subnet="Subnet Mask";
$m_gateway="Gateway";
$m_dns="DNS";
$m_server_ip="Server IP";
$m_pptp_account="PPTP Account";
$m_pptp_password="PPTP Password";
$m_retype_password="Retype Password";
?>
