<?
/* vi: set sw=4 ts=4: */
$a_user_name_is_blank="The User Name can not be blank!";
$a_password_not_matched="The Password and Retype Passord do not match!";
$a_user_name_only_allow_ascii_code="User Name only allow ASCII code!";
$a_password_only_allow_ascii_code="Password only allow ASCII code!";
$a_service_name_only_allow_ascii_code="Service Name only allow ASCII code!";

$m_title="Set PPPoE";
$m_title_desc="The service name is optional but may be required by your ISP. Click <b>Next</b> to continue.";
$m_user_name="User Name";
$m_password="Password";
$m_retype_password="Retype Password";
$m_service_name_optional="Service Name (optional)";
?>
