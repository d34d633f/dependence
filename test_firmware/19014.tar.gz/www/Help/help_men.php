<?
$MSG_FILE="help_men.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
$help_page_path="/locale/".$__LANG."/Help/";
?>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<?require("/www/comm/middle.php");?>
<table width=75% border=0 cellspacing=0 cellpadding=0>
<tr>
<td height=25><font face=Arial size=4><b><?=$m_home?></b></font></td>
</tr>
<tr>
<td height=79>
<ul>
<li><a href="<?=$help_page_path?>help_home.php#001" target=_blank><font face=Arial color=#000000><?=$m_setup_wizard?>
</font></a></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_home.php#02_1" target=_blank><font color=#000000><?=$m_wireless_settings?>
</font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_home.php#02" target=_blank><font color=#000000><?=$m_wan_settings?>
</font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_home.php#03" target=_blank><font color=#000000><?=$m_lan_settings?>
</font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_home.php#04" target=_blank><font color=#000000><?=$m_dhcp_server?>
</font></a></font></li>
</ul>
</td>
</tr>
<tr>
<td><font face=Arial size=4><b><?=$m_advanced?></b></font></td>
</tr>
<tr>
<td>
<ul>
<li><font face=Arial><a href="<?=$help_page_path?>help_adv.php#05" target=_blank><font color=#000000><?=$m_virtual_server?>
</font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_adv.php#06" target=_blank><font color=#000000><?=$m_special_applications?>
</font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_adv.php#07" target=_blank><font color=#000000><?=$m_filters?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_adv.php#7_1" target=_blank><font color=#000000><?=$m_paretal_control?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_adv.php#08" target=_blank><font color=#000000><?=$m_firewall_rules?>
</font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_adv.php#09" target=_blank><font color="#000000"><?=$m_dmz?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_adv.php#10" target=_blank><font color="#000000"><?=$m_ddns?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_adv.php#11" target=_blank><font color="#000000"><?=$m_wireless_performance?></font></a></font></li>
</ul>
</td>
</tr>
<tr>
<td><font face=Arial size=4><b><?=$m_tools?></b></font></td>
</tr>
<tr>
<td>
<ul>
<li><font face=Arial><a href="<?=$help_page_path?>help_tools.php#11" target=_blank><font color=#000000><?=$m_admin_setings?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_tools.php#10" target=_blank><font color=#000000><?=$m_sys_time?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_tools.php#12" target=_blank><font color=#000000><?=$m_sys_settings?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_tools.php#13" target=_blank><font color=#000000><?=$m_firm_upgrade?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_tools.php#14" target=_blank><font color=#000000><?=$m_misc_items?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_tools.php#15" target=_blank><font color=#000000><?=$m_cable_test?></font></a></font></li>
</ul>
</td>
</tr>
<tr>
<td><font face=Arial size=4><b><?=$m_status?></b></font></td>
</tr>
<tr>
<td height=72>
<ul>
<li><font face=Arial><a href="<?=$help_page_path?>help_status.php#15" target=_blank><font color=#000000><?=$m_device_info?>
</font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_status.php#16" target=_blank><font color=#000000><?=$m_log?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_status.php#17" target=_blank><font color=#000000><?=$m_traffic_statistics?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_status.php#17_1" target=_blank><font color=#000000><?=$m_conn_wireless_client_list?></font></a></font></li>
<li><font face=Arial><a href="<?=$help_page_path?>help_status.php#66" target=_blank><font color=#000000><?=$m_active_session?></font></a></font></li>
</ul>
</td>
</tr>
<tr>
<td height=40 valign=top><b><font face=Arial size=4><a href="<?=$help_page_path?>help_faq.php" target=_blank><font color=#000000><?=$m_faq?></font></a></font></b></td>
</tr>
</table>
<?require("/www/comm/bottom.php");?>
</BODY>
</HTML>
