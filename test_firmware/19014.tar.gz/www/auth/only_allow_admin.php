<?
$prefix = "/var/proc/web/session:".$sid."/user";
$group = fread($prefix."/group");
if($group!="0")
{
	$target_url="/sys/relogin.php";
	require("/www/comm/header.php");
	exit;
}
?>
