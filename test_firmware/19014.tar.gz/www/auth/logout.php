<?
$MSG_FILE="sys.php";
require("/www/comm/lang_msg.php");

if ($sid > 0)
{
	fwrite("/var/proc/web/session_".$sid."_logout", "1");
}
?>
<HTML>
<HEAD>
<TITLE><?query("/sys/hostname");?></TITLE>
<link rel="stylesheet" href="/comm/webCSS.css" type="text/css">
<META HTTP-EQUIV=Content-Type CONTENT="no-cache">
<META HTTP-EQUIV=Content-Type CONTENT="text/html; charset=iso-8859-1">
</HEAD>

<body bgcolor=#FFFFFF text="#000000" topmargin=0>
<table border=0 cellspacing=0 cellpadding=0 align=center width=765>
<tr>
	<td><img src=../graphic/home_01.jpg width=765 height=95></td>
</tr>
<tr>
	<td background=../graphic/home_02.jpg>
	<div align=left><table width=75% border=0 cellspacing=0 cellpadding=0 align=center height=131>
	<tr><td><div align=center></div></td></tr>
	<tr><td>&nbsp;</td></tr>
	<tr><td class=c_tb><?=$m_logout_message?></td></tr>
	<tr><td>&nbsp;</td></tr>
	<tr><td><div align=center></div></td></tr>
	</table>
	</div>
	</td>
</tr>
<tr>
	<td background=../graphic/home_03.jpg><div align=right><img src=../graphic/down_44.gif width=25 height=27></div></td>
</tr>
</table>
</body>
</html>
