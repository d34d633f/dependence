<?
$debug="0";
if($debug=="1")
{
	echo "sid=".$sid."\n";
	echo "user=".$user."\n";
	echo "password".$passwd."\n";
	echo "authnum=".query("/proc/web/authnum")."\n";
	echo "sessionum=".query("/proc/web/sessionum")."\n";
}

$prefix		= "/var/proc/web/session:".$sid."/user";
$path_name	= $prefix."/name";
$path_password	= $prefix."/password";
$path_ac_auth	= $prefix."/ac_auth";
$path_group	= $prefix."/group";
$path_logout	= "/var/proc/web/session_".$sid."_logout";

// session id error
if($sid=="-1" || $sid=="" || $sid=="0")
{
	$target_url="/auth/session_full.php";
	require("/www/comm/header.php");
}
// no user name
if($user=="")
{
	echo "401;\n";
	fwrite($path_logout, "0");
	fwrite($path_ac_auth,"0");
	exit;
}
// session logout
$sess_logout = fread($path_logout);
if ($sess_logout==1)
{
	if($FROM_WIZARD=="1")
	{
		echo "<html><head><script>self.parent.close();</script></head><body></body></html>";
	}
	else
	{
		$target_url="/auth/logout.php";
		require("/www/comm/header.php");
	}
}
// user is "admin" or "user"
if($user=="admin")
{
	if($passwd==query("/sys/user:1/password"))	{$this_auth="1";}
	else						{$this_auth="0";}
}
else if($user=="user")
{
	if($passwd==query("/sys/user:2/password"))	{$this_auth="1";}
	else						{$this_auth="0";}
}
if($this_auth!="1")
{
	echo "401;\n";
	fwrite($path_ac_auth,"0");
	exit;
}
// if session full.
$ac_auth = fread($path_ac_auth);
if($this_auth=="1" && $ac_auth=="0")
{
	$authnum=0;
	$max_authnum=query("/proc/web/authnum");
	$max_session=query("/proc/web/sessionum");
	$index=1;
	while($index<=$max_session)
	{
		if(fread("/var/proc/web/session:".$index."/user/ac_auth")=="1"){$authnum++;}
		$index++;
	}
	//echo "authnum=".$authnum."\n";
	if($authnum>=$max_authnum)
	{
		$target_url="/auth/session_full.php";
		require("/www/comm/header.php");
	}
}
// update user info
if($user=="admin")	{$group="0";}
else			{$group="1";}
fwrite($path_name,	$user);
fwrite($path_group,	$group);
fwrite($path_ac_auth,	"1");
?>
