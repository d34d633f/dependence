<?
/* vi: set sw=4 ts=4: */

$onload="onload='checkWan()'";
require("/www/comm/genWizTop.php");
?>
<script>
wanStatus="<?query("/runtime/wan/inf:1/linkType");?>";
if (wanStatus=="") wanStatus=0;
discover="<?query("/runtime/wan/inf:1/discover");?>";
if (discover=="") discover=0;

function checkWan()
{
	if (parseInt(wanStatus), [10])	doNext(1);
	else				doNext(0);
}

function doNext(i)
{
	switch (i)
	{
	case 0:
		str="h_wiz4_wan_manual.php";
		break;
	case 1:
		switch (parseInt(discover, [10]))
		{
		case 0:
			str="h_wiz4_wan_manual.php";
			break;
		case 1:
			str="h_wiz5_wan_pppoe.php";
			break;
		case 2:
			str="h_wiz5_wan_dhcp.php";
			break;
		}
		break;
	}
	self.location.href=str;
}
</script>
</body>
</html>
