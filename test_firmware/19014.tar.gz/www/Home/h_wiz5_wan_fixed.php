<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz5_wan_fixed.php";
$onload="onload='setStatic()'";
require("/www/comm/genWizTop.php");
?>

<script>
ip="<?query("/tmp/wiz/wan/rg/inf:1/static/ip");?>";
if(ip=="")
{
	ip="<?query("/wan/rg/inf:1/static/ip");?>";
	mask="<?query("/wan/rg/inf:1/static/netmask");?>";
	gateway="<?query("/wan/rg/inf:1/static/gateway");?>";
	dns1="<?query("/dnsrelay/server/primarydns");?>";
	dns2="<?query("/dnsrelay/server/secondarydns");?>";
}
else
{
	mask="<?query("/tmp/wiz/wan/rg/inf:1/static/netmask");?>";
	gateway="<?query("/tmp/wiz/wan/rg/inf:1/static/gateway");?>";
	dns1="<?query("/tmp/wiz/dnsrelay/server/primarydns");?>";
	dns2="<?query("/tmp/wiz/dnsrelay/server/secondarydns");?>";
}
function setStatic()
{
	var f=document.getElementById("wiz1");
	f.ip.value=ip;
	f.mask.value=mask;
	f.gateway.value=gateway;
	f.dns1.value=dns1;
	f.dns2.value=dns2;
}

function doNext()
{
	var f=document.getElementById("wiz1");
	var str="h_wiz6_wlan1_cfg.xgi?";
	if (!checkIpAddr(f.ip, "<?=$a_err_wan_ip_addr?>Error WAN IP Address"))				return;
	if (!validMask(f.mask, "<?=$a_err_wan_subnet_mask?>Error WAN Subnet Mask"))			return;
	if (!checkIpAddr(f.gateway, "<?=$a_err_wan_gw_addr?>Error WAN Gateway Address"))	return;
	if (!checkIpAddr(f.dns1, "<?=$a_err_pri_dns_addr?>Error Primary DNS Address"))		return;
	if (f.dns2.value!="" && !checkIpAddr(f.dns2, "<?=$a_err_sec_dns_addr?>Error Secondary DNS Address"))	return;

	str+="&set/tmp/wiz/wan/rg/inf:1/mode=1";
	str+="&set/tmp/wiz/wan/rg/inf:1/static/IP="+reduceIP(f.ip.value);
	str+="&set/tmp/wiz/wan/rg/inf:1/static/NETMASK="+reduceIP(f.mask.value);
	str+="&set/tmp/wiz/wan/rg/inf:1/static/GATEWAY="+reduceIP(f.gateway.value);
	str+="&set/tmp/wiz/DnsRelay/server/PRIMARYDNS="+reduceIP(f.dns1.value);
	if(f.dns2.value!="")	str+="&"+"set/tmp/wiz/DnsRelay/server/SECONDARYDNS="+reduceIP(f.dns2.value);
	self.location.href=str;
}
</script>
<form method=post name=wiz1 id="wiz1">
<?=$table?>
<tr><td height=11><?=$top_pic?></td></tr>
<tr><td height=10 class=title_wiz><?=$m_title?></td></tr>
<tr>
	<td height=200>
	<table border=0 width=95% height=175>
	<tr valign=top>
		<td colspan=2 height=28>
		<table border=0 cellspacing=0 cellpadding=0 height=39 align=center>
		<tr><td class=l_wiz><?=$m_title_desc?></td></tr>
		</table>
		</td>
	</tr>
	<tr>
		<td width=45% height=9 class=r_wiz><?=$m_ip_addr?></td>
		<td width=55% height=9>
		<input type=text name=ip size=16 maxlength=15 onblur=changeAddress(0,0,event.keyCode,this,document.wiz1.mask) onkeydown=changeAddress(1,13,event.keyCode,this,document.wiz1.mask)>
		</td>
	</tr>
	<tr>
		<td height=9 class=r_wiz><div align=right><?=$m_subnet?></div></td>
		<td height=9><input type=text name=mask size=16 maxlength=15></td>
	</tr>
	<tr>
		<td height=9 class=r_wiz><?=$m_isp_gw_addr?></td>
		<td height=9><input type=text name=gateway size=16 maxlength=15></td>
	</tr>
	<tr>
		<td height=9 class=r_wiz><div align=right><?=$m_pri_dns_addr?></div></td>
		<td height=9><input type=text name=dns1 size=16 maxlength=15></td>
	</tr>
	<tr>
		<td height=9 class=r_wiz><div align=right><?=$m_sec_dns_addr?></div></td>
		<td height=9 class=l_wiz><input type=text name=dns2 size=16 maxlength=15>(<?=$m_optional?>)</td>
	</tr>
	</table>
	</td>
</tr>
<tr>
	<td align=right valign=bottom>
	<script language="JavaScript">back("h_wiz4_wan_manual.php");next("");exit();</script>
	</td>
</tr>
</table>
</form>
</body>
</html>
