<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz5_wan_l2tp.php";
$onload="onload='setL2TP()'";
require("/www/comm/genWizTop.php");
?>
<script>
var ip, mask, server, account,gw,dns;

ip="<?query("/tmp/wiz/wan/rg/inf:1/l2tp/ip");?>";
if(ip=="")
{
	<?anchor("/wan/rg/inf:1/l2tp/");?>
	ip="<?query("ip");?>";
	mask="<?query("netmask");?>";
	gw="<?query("gateway");?>";
	dns="<?query("dns");?>";
	server="<?query("serverip");?>";
	account="<?query("user");?>";
}
else
{
	<?anchor("/tmp/wiz/wan/rg/inf:1/l2tp/");?>
	mask="<?query("netmask");?>";
	gw="<?query("gateway");?>";
	dns="<?query("dns");?>";
	server="<?query("serverip");?>";
	account="<?query("user");?>";
}
function setL2TP()
{
	var f=document.getElementById("wiz1");
	f.ip.value=ip;
	f.mask.value=mask;
	f.gateway.value=gw;
	f.dns.value=dns;
	f.server_ip.value=server;
	f.l2tpuserid.value=account;
}

function doNext()
{
	var f=document.getElementById("wiz1");
	var str="h_wiz6_wlan1_cfg.xgi?";

	if (!checkIpAddr(f.ip, "<?=$a_err_ip_addr?>"))	return;
	if (!validMask(f.mask, "<?=$a_err_subnet_mask?>")) return;
	if (!checkMaskAddr(f.ip, f.mask.value, "<?=$a_err_ip_addr?>"))	return;
	if (f.gateway.value!="")
	{
		if (!checkIpAddr(f.gateway, "<?=$a_err_gw?>"))	return;
		if (!checkSubnet(f.gateway.value, f.mask.value, f.ip.value))
		{
			alert("<?=$a_err_gw?>");
			f.gateway.value="";
			f.gateway.focus();
			return;
		}
		if (f.dns.value!="")
		{
			if (!checkIpAddr(f.dns, "<?=$a_err_dns?>"))	return;
			if (f.server_ip.value=="")
			{
				alert("Server IP address can't be empty.");
				return;
			}
		}
		else
		{
			if (!checkIpAddr(f.server_ip, "<?=$a_err_server_ip_addr?>")) return;
			if (!checkSubnet(f.server_ip.value, f.mask.value, f.ip.value))
			{
				alert("<?=$a_err_server_ip_addr?>\n<?=$a_should_be_in_same_subnet?>");
				f.server_ip.value="";
				f.server_ip.focus();
				return;
			}
		}
	}
	else
	{
		if (!checkIpAddr(f.server_ip, "<?=$a_err_server_ip_addr?>")) return;
		if (!checkSubnet(f.server_ip.value, f.mask.value, f.ip.value))
		{
			alert("<?=$a_err_server_ip_addr?>\n<?=$a_should_be_in_same_subnet?>");
			f.server_ip.value="";
			f.server_ip.focus();
			return;
		}
	}

	if (isBlank(f.l2tpuserid.value))
	{
		alert( "<?=$a_l2tp_account_name_is_blank?>\n");
		return;
	}

	if (f.l2tppwd.value!=f.l2tppwd2.value)
	{
		alert( "<?=$a_password_not_matched?>\n");
		return;
	}
	if(CheckUCS2(f.l2tpuserid.value))
	{
		alert("<?=$a_l2tp_account_only_allow_ascii_code?>");
		f.l2tpuserid.focus();
		return;
	}
	if(CheckUCS2(f.l2tppwd.value))
	{
		alert("<?=$a_l2tp_password_only_allow_ascii_code?>");
		f.l2tppwd.focus();
		return;
	}		

	str+="set/tmp/wiz/wan/rg/inf:1/mode=5";
	str+="&setPath=/tmp/wiz/wan/rg/inf:1/l2tp/";
	str+="&mode=1";
	str+="&IP="+reduceIP(f.ip.value);
	str+="&NETMASK="+reduceIP(f.mask.value);
	str+="&gateway="+reduceIP(f.gateway.value);
	str+="&dns="+reduceIP(f.dns.value);
	str+="&SERVERIP="+reduceIP(f.server_ip.value);
	str+="&USER="+escape(f.l2tpuserid.value);
	str+="&PASSWORD="+escape(f.l2tppwd.value);
	str+="&endSetPath=1";
	self.location.href=str;
}

</script>
<form method=post name="wiz1" id="wiz1">
<?=$table?>
<tr><td height=11><?=$top_pic?></td></tr>
<tr><td height=10 class=title_wiz><?=$m_title?></td></tr>
<tr>
	<td height=200 valign=top>
	<table border=0 width=95% cellpadding=0>
	<tr><td height=20 colspan=2 class=l_wiz><?=$m_title_desc?></td></tr>
	<tr>
		<td width=30% height=20 class=r_wiz><?=$m_my_ip?></td>
		<td width=70% height=20>
		<input type=text name=ip size=16 maxlength=15 onblur=changeAddress(0,0,event.keyCode,this,document.wiz1.mask) onkeydown=changeAddress(1,13,event.keyCode,this,document.wiz1.mask)>
		</td>
	</tr>
	<tr>
		<td height=20 class=r_wiz><?=$m_subnet?></td>
		<td height=20><input type=text name=mask size=16 maxlength=15></td>
	</tr>
	<tr>
		<td height=20 class=r_wiz><?=$m_server_ip?></td>
		<td height=20><input type=text name=server_ip size=16 maxlength=15></td>
	</tr>
	<tr>
		<td height=20 class=r_wiz><?=$m_gateway?></td>
		<td height=20><input type=text name=gateway size=16 maxlength=15></td>
	</tr>
	<tr>
		<td height=20 class=r_wiz><?=$m_dns?></td>
		<td height=20><input type=text name=dns size=16 maxlength=15></td>
	</tr>
	<tr>
		<td height=20 class=r_wiz><?=$m_l2tp_account?></td>
		<td height=20><input type=text name=l2tpuserid size=32 maxlength=63></td>
	</tr>
	<tr>
	<tr>
		<td height=20 class=r_wiz><?=$m_l2tp_password?></td>
		<td height=20>
		<input type=password name=l2tppwd size=32 maxlength=31 value="<?=$DEF_PASSWORD?>"></td>
	</tr>
		<td height=20 class=r_wiz><?=$m_retype_password?></td>
		<td height=20>
		<input type=password name=l2tppwd2 size=32 maxlength=31 value="<?=$DEF_PASSWORD?>"></td>
	</tr>
	</table>
	</td>
</tr>
<tr>
	<td align=right valign=bottom>
	<script language="JavaScript">back("h_wiz4_wan_manual.php");next("");exit();</script>
	</td>
</tr>
</table>
</form>
</body>
</html>
