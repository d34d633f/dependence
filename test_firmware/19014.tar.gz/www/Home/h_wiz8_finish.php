<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz8_finish.php";
require("/www/comm/genWizTop.php");?>
<form>
<?=$table?>
<tr><td height=11><?=$top_pic?></td></tr>
<tr><td height=100% valign=middle class=c_wiz><?=$m_setup_completed?><td></tr>
<tr>
	<td height=160 align=right><div align=center><input type=button value="<?=$m_close?>" name=close onClick="self.parent.close()"></div></td>
</tr>
</table>
</form>
</body>
</html>
