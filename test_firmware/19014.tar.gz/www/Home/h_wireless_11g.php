<?
$MSG_FILE="h_wireless_11g.php";
//comm
$file_name="h_wireless_11g.php";
$apply_name="h_wireless_11g.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");

$country=query("/sys/regdomain");

$no_jumpstart	= query("/function/no_jumpstart");
if(query("/function/normal_g")=="1")
	{$with_xr_superg = "0";}
else	{$with_xr_superg = "1";}

anchor("/wireless");
$wradio=query("enable");

//JumpStart and phase 1
if(query("jumpstart/enable")=="1" && query("jumpstart/phase")=="1")// && $wradio=="1")
{$ssid=query("/runtime/wireless/ssid");	$wepMode="0";			$auth="0";			}
else
{$ssid=queryjs("ssid");			$wepMode=query("wpa/wepmode");	$auth=query("authentication");	}

$channel=query("channel");
$autoch=query("autochannel");

$ssidHidden=query("ssidHidden");
$x11gOnly=query("wlmode");
$super=query("superGMode");
$xr=query("XR");

//wep
$wepLen=query("keylength");
$wepFormat=query("keyformat");
$defkey=query("defkey");
$key1=queryjs("wepkey:1");
$key2=queryjs("wepkey:2");
$key3=queryjs("wepkey:3");
$key4=queryjs("wepkey:4");
//WPA
anchor("/wireless/wpa");
$wpaIp=query("radiusserver");
$wpaPort=query("radiusport");
$wpaSecret=queryjs("radiussecret");
//PSK
$psk_format=query("passphraseformat");
if($psk_format==""){$psk_format="1";}
if($psk_format=="1")//ASCII
{
	$passphrase=queryjs("wpapsk");
}
else	//HEX
{
	$psk=query("wpapsk");
}
?>
<script language="JavaScript">
var key1="<?=$key1?>";
var key2="<?=$key2?>";
var key3="<?=$key3?>";
var key4="<?=$key4?>";
function init()
{
	f=document.getElementById("theform");
	f.wirelessESSID.value="<?=$ssid?>";
	f.pass.value="<?=$wpaSecret?>";
	f.psk.value="<?=$psk?>";
	f.wpapsk1.value="<?=$passphrase?>";
	f.wpapsk2.value="<?=$passphrase?>";
<?
	if($with_xr_superg=="1"){echo "chg_supergmode();\n";}
?>
}
function f_focus(f)
{
	f.value="";
	f.focus();
}
function print_keys()
{
	var f=document.getElementById("theform");
	var k, s;
	echo("<table>");
	for(i=1;i<5;i++)
	{
		s=eval("key"+i);
		s=replace_html_sc(s);
		
		echo("<tr>");
		echo("<td class=r_tb width=36%>Key"+i+"</td>");
		echo("<td width=10 width=64%><input type='radio' name='defkey' value="+i+" "+(<?=$defkey?>==i ? " checked":"")+"></td>");
		echo("<td id='wep_key"+i+"'><input id='key"+i+"' type='text' name='key"+i+"' size=26 value='"+s+"'></td>");
		echo("</tr>");
	}
	echo("</table>");
}

function disable_channel()
{
	f=document.getElementById("theform");
	if(f.auto.checked)	f.channel.disabled=true;
	else			f.channel.disabled=false;
}
function SetChannel()
{
	cLists=["fcc","etsi","spain","france","mkk","israel"];
	cChannels=[
		["0","1","2","3","4","5","6","7","8","9","10","11"],
		["0","1","2","3","4","5","6","7","8","9","10","11","12","13"],
		["0","10","11"],
		["0","10","11","12","13"],
		["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14"],
		["0","3","4","5","6","7","8","9"]];

	f=document.getElementById("theform");
	var c=0,s=0;
	var ie;
	if (navigator.userAgent.indexOf("MSIE")>-1)	ie=true; 
	else						ie=false;
	for (var i=0;i < cLists.length;i++)
	{
		if ("<?=$country?>"==cLists[i])
		{
			c=i;
			break;
		}
	}

	for(i=1; i < cChannels[c].length; i++)
	{
		var opt = document.createElement("option");
		opt.text = cChannels[c][i];
		opt.value = cChannels[c][i];
		if (cChannels[c][i] =="<?=$channel?>") s=i-1;
		if (ie) f.channel.options.add(opt);
		else    f.channel.appendChild(opt);
	}
	f.channel.selectedIndex = s;
}
function chgSecuMode()
{
	var f=document.getElementById("theform");
	var s_wep=document.getElementById("setting_wep");
	var s_wpa=document.getElementById("setting_wpa");
	var s_wpaeap=document.getElementById("setting_wpa_eap");
	var s_wpapsk=document.getElementById("setting_wpa_psk");
	var s_pskeap=document.getElementById("psk_eap");

	switch(f.secumode.value)
	{
	case "0":	//open with no wep.
		s_wep.style.display = "none";
		s_wpa.style.display = "none";
		s_wpapsk.style.display = "none";
		s_wpaeap.style.display = "none";
		break;
	case "1":	//open wep or shared key
		s_wep.style.display = "";
		s_wpa.style.display = "none";
		s_wpapsk.style.display = "none";
		s_wpaeap.style.display = "none";
		break;
	case "2":	//WPA
	case "3":	//WPA2
	case "4":	//WPA2 auto
		s_wep.style.display = "none";
		s_wpa.style.display = "";
		if (f.psk_eap[1].checked){s_wpapsk.style.display="";	 s_wpaeap.style.display = "none";}
		else			 {s_wpapsk.style.display="none"; s_wpaeap.style.display = "";	}
		chgPskEap();
		break;
	default: 
		s_wep.style.display = "none";
		s_wpa.style.display = "none";
		s_wpapsk.style.display = "none";
		s_wpaeap.style.display = "none";
		alert("Unknown mode");
		break;
	}
/*	if(f.secumode.value=="3" || f.secumode.value=="4")
	{
		f.cipher_type[0].disabled=true;
		f.cipher_type[1].checked=true;
	}
	else if(f.secumode.value=="2")
		f.cipher_type[0].disabled=false;
*/
}
function chgPskEap()
{
	var s_wpaeap=document.getElementById("setting_wpa_eap");
	var s_wpapsk=document.getElementById("setting_wpa_psk");
	if(f.psk_eap[0].checked)
	{
		s_wpapsk.style.display = "";
		s_wpaeap.style.display = "none";
		chg_psk();
	}
	else
	{
		s_wpapsk.style.display = "none";
		s_wpaeap.style.display = "";
	}
}

function chgWepLen()
{
	f=document.getElementById("theform");
	var weplen;
	if(f.wep_Len.value=="64")
	{
		if(f.wepKeyType.value=="1")		weplen=5;	//ASCII
		else if(f.wepKeyType.value=="2")	weplen=10;	//HEX
	}
	else if(f.wep_Len.value=="128")
	{
		if(f.wepKeyType.value=="1")		weplen=13;	//ASCII
		else if(f.wepKeyType.value=="2")	weplen=26;	//HEX
	}
	var k1, k2, k3, k4;
	var k, s;
	for(i=1;i<5;i++)	eval("k"+i+"=document.getElementById('wep_key"+i+"');");
	if(weplen > 0)
	{
		//k1.innerHTML='<input id=key1 type=text name=key1 maxlength='+weplen+' size=48 value='+f.key1.value+'>';
		for(i=1;i<5;i++)
		{
			s=eval("key"+i);
			s=replace_html_sc(s);
			eval("k"+i+".innerHTML='<input id=key"+i+" type=text name=key"+i+" maxlength="+weplen+" size=26 value=\""+s+"\">'");
		}
	}
}

function validateWepKey(keyType, keyIndex, defkeyIndex, len)
{
	keyField=document.getElementById("key"+keyIndex);
	f=document.getElementById("theform");
	if((defkeyIndex==keyIndex) && (keyField.value==""))
	{
		alert("Key "+defkeyIndex+" can not be empty.");
		f_focus(keyField);
		return false;
	}
	if(keyField.value=="") return true;
	if (keyField.value.length != len)
	{
		if(keyType == "1")
			alert(<?=$a_too_short_key_i_in_characters?>);
		else
			alert(<?=$a_too_short_key_i_in_hex?>)
		f_focus(keyField);
		return false;
	}

	if(keyType == "1")      //ASC
	{
		if(CheckUCS2(keyField.value))
		{
			alert("<?=$a_only_allow_key_in_ascii?>");
			f_focus(keyField);
			return false;
		}
	}
	else    // Hex
	{
		for (var i=0; i<keyField.value.length; i++)
		{
			if ((keyField.value.charAt(i) >= '0' && keyField.value.charAt(i) <= '9') ||
				(keyField.value.charAt(i) >= 'a' && keyField.value.charAt(i) <= 'f') ||
				(keyField.value.charAt(i) >= 'A' && keyField.value.charAt(i) <= 'F'))
				continue;
			alert(<?=$a_invalid_hex_key_i?>);
			f_focus(keyField);
			return false;
		}
	}
	return true;
}
function check_wep(d)
{
	f=document.getElementById("theform");
	if (f.wep_Len.value == "64")
	{
		if (f.wepKeyType.value=="1")		keyLen=5;	// ASCI
		else if(f.wepKeyType.value=="2")	keyLen=10;	// HEX
	}
	else if (f.wep_Len.value=="128")
	{
		if (f.wepKeyType.value=="1")		keyLen=13;	// ASCII
		else if (f.wepKeyType.value=="2")	keyLen=26;	// HEX
	}
	for(i=1;i<5;i++)
	{
		if(!eval("validateWepKey(f.wepKeyType.value, "+i+", d, keyLen)")) return false;
	}
}
function check_wpa()
{
	f=document.getElementById("theform");
	if(!checkIpAddr(f.RADIUSIP, "Error RADIUS Server IP")) return false;
	if(!validPort(f.RADIUSPort.value))
	{
		f_focus(f.RADIUSPort);
		return false;
	}
	if(f.pass.value == "")
	{
		alert("<?=$a_secret_cant_be_empty?>");
		f_focus(f.pass);
		return false;
	}
	return true;
}
function check_psk()
{
	f=document.getElementById("theform");
	if(f.psk_format[0].checked)      //PSK
	{
		if(f.psk.value.length!=64)
		{
			alert("<?=$a_psk_must_be_64_hex?>");
			f_focus(f.psk);
			return false;
		}
		for (var i=0; i<f.psk.value.length; i++)
		{
			if ((f.psk.value.charAt(i) >= '0' && f.psk.value.charAt(i) <= '9') ||
				(f.psk.value.charAt(i) >= 'a' && f.psk.value.charAt(i) <= 'f') ||
				(f.psk.value.charAt(i) >= 'A' && f.psk.value.charAt(i) <= 'F'))
				continue;
			alert("<?=$a_invalid_psk?>");
			f_focus(f.psk);
			return false;
		}
	}
	else    // Passphrase
	{
		if (f.wpapsk1.value.length < 8)
		{
			alert("<?=$a_passphrase_at_least_8_char?>");
			f_focus(f.wpapsk1);
			return false;
		}
		else if(f.wpapsk1.value.length > 63)
		{
			alert("<?=$a_passphrase_at_most_63_char?>");
			f_focus(f.wpapsk1);
			return false;
		}
		if(CheckUCS2(f.wpapsk1.value))
		{
			alert("<?=$a_only_allow_passphrase_in_ascii?>");
			f_focus(f.wpapsk1);
			return false;
		}
		else if(f.wpapsk1.value != f.wpapsk2.value)
		{
			alert("<?=$a_passphrase_mismatch?>");
			f_focus(f.wpapsk1);
			return false;
		}
	}
	return true;
}
function doSubmit()
{
	f=document.getElementById("theform");

	if(isBlank(f.wirelessESSID.value))
	{
		alert("<?=$a_ssid_cant_empty?>");
		f_focus(f.wirelessESSID);
		return;
	}
	if(CheckUCS2(f.wirelessESSID.value))
	{
		alert("<?=$a_ssid_allow_ascii?>");
		f_focus(f.wirelessESSID);
		return;
	}
	for(i=0; i<f.wirelessESSID.value.length; i++)
	{
		if(f.wirelessESSID.value.charAt(i)=="`")
		{
			alert("<?=$a_invalid_ssid?>");
			f_focus(f.wirelessESSID);
			return;
		}
	}

	var str=new String("<?=$apply_name?>");
	var wpa_cipher;
	var need_radius=false;
	var need_psk=false;

	str+="setPath=/wireless/";
<?
	if($no_jumpstart!="1"){echo "str+=\"&jumpstart/enable=0\";\n";}
?>
	str+="&enable="+(f.wradio[0].checked? "1":"0");
	str+="&ssid="+escape(f.wirelessESSID.value);
	if(f.auto.checked)      str+="&autochannel=1";
	else
	{
		str+="&autochannel=0";
		str+="&channel="+f.channel.value;
	}
	
<?
	if($with_xr_superg=="1")
	{
		echo "str+=\"&superGMode=\"+f.supergmode.value;\n";
		echo "str+=\"&XR=\"+(f.xr[0].checked? \"1\":\"0\");\n";
	}
?>
	str+="&wlmode="+(f.x11gOnly[0].checked? "2":"1");
	str+="&ssidHidden="+(f.ssidBroadcast[1].checked? "1":"0");

	if(f.secumode.value >= 2 && f.secumode.value <= 4)
	{
		if(f.cipher_type[0].checked)		wpa_cipher=2;
		else if(f.cipher_type[1].checked)	wpa_cipher=3;
		else					wpa_cipher=4;
	}

	switch(f.secumode.value)
	{
	case "0":	// open without wep
		str+="&authentication=0&wpa/wepmode=0";
		str+="&endSetPath=1";
		break;
	case "1":	// open/shared key with wep
		var d=0;
		for(i=0;i<4;i++) if(eval("f.defkey["+i+"].checked")) d=i+1;

		if(check_wep(d)==false) return;
		str+="&authentication="+(f.wep_sk[1].checked? "1":"0");
		str+="&wpa/wepmode=1";
		str+="&keylength="+f.wep_Len.value;
		str+="&keyformat="+f.wepKeyType.value;
		str+="&defkey="+d;
		for(i=1;i<5;i++){str+="&wepkey:"+i+"="+escape(document.getElementById("key"+i).value);}
		str+="&endSetPath=1";
		break;
	case "2":	// wpa
		if (f.psk_eap[1].checked)	{str+="&authentication=2&endSetPath=1";	need_radius=true;	}
		else				{str+="&authentication=3&endSetPath=1";	need_psk=true;		}
		break;
	case "3":	// wpa2
		if (f.psk_eap[1].checked)	{str+="&authentication=4&endSetPath=1";	need_radius=true;	}
		else				{str+="&authentication=5&endSetPath=1";	need_psk=true;		}
		break;
	case "4":	// wpa/wpa2
		if (f.psk_eap[1].checked)	{str+="&authentication=6&endSetPath=1";	need_radius=true;	}
		else				{str+="&authentication=7&endSetPath=1";	need_psk=true;		}
		break;
	default:
		alert("Unknown mode\n");
		return;
	}
	if(need_radius)
	{
		if(check_wpa()==false) return;
		str+="&setPath=/wireless/wpa/";
		str+="&wepmode="+wpa_cipher;
		str+="&radiusserver="+f.RADIUSIP.value;
		str+="&radiusport="+f.RADIUSPort.value;
		str+="&radiussecret="+escape(f.pass.value);
		str+="&endSetPath=1";
	}
	if(need_psk)
	{
		if(check_psk()==false) return;
		str+="&setPath=/wireless/wpa/";
		str+="&wepmode="+wpa_cipher;
		if(f.psk_format[0].checked)
		{
			str+="&PassPhraseFormat=2";
			str+="&wpapsk="+escape(f.psk.value);
		}
		else
		{
			str+="&PassPhraseFormat=1";
			str+="&wpapsk="+escape(f.wpapsk1.value);
		}
		str+="&endSetPath=1";
	}
	str+=exeStr("submit COMMIT;submit WLAN");

	self.location.href=str;
}
function doReset()
{
	self.location.href="<?=$file_name?>";
}
function chg_supergmode()
{
	var f=document.getElementById("theform");
	var dis=false;
	if(f.supergmode.value=="2")
	{
		dis=true;
		f.channel.value=6;
		f.auto.checked=false;
		f.xr[1].checked=true;
	}
	if(f.auto.checked==false)	f.channel.disabled=dis;
	f.auto.disabled=dis;
	f.xr[0].disabled=dis;
	f.xr[1].disabled=dis;
}
function chg_psk()
{
	var f=document.getElementById("theform");
	document.getElementById("tr_psk").style.display="none";
	document.getElementById("tr_passphrase1").style.display="none";
	document.getElementById("tr_passphrase2").style.display="none";
	if(f.psk_format[0].checked)
	{
		document.getElementById("tr_psk").style.display="";
	}
	else
	{
		document.getElementById("tr_passphrase1").style.display="";
		document.getElementById("tr_passphrase2").style.display="";
	}
}
</script>
<body BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload=init()>
<?require("/www/comm/middle.php");?>
<table width="<?=$width_tb?>" cellpadding=0 cellspacing=0 border=0>
<form method="POST" id="theform" name="theform">
<tr><td height="10" class=title_tb><?=$m_wlan_setting?></td></tr>
<tr><td colspan=2 class=l_tb><?=$m_wlan_setting_for_ap?></td></tr><tr><td>&nbsp;</td></tr>
<tr>
	<td width=36% class=r_tb><?=$m_wlan_radio?> :&nbsp;</td>
	<td width=64% class=l_tb>
	<b><input name=wradio type=radio value=1 <?if($wradio=="1"){echo "checked";}?>><?=$m_on?>
	<input name=wradio type=radio value=0 <?if($wradio!="1"){echo "checked";}?>><?=$m_off?></b>
	</td>
</tr>
<tr>
	<td class=r_tb><?=$m_ssid?> :&nbsp;</td>
	<td class=l_tb><input type="text" name="wirelessESSID" maxlength="32"></td>
</tr>
<tr>
	<td class=r_tb><?=$m_channel?> :&nbsp;</td>
	<td class=l_tb>
	<select name="channel"></select>
	<input type="checkbox" id="auto" name="auto" <?if($autoch=="1"){echo "checked";}?> onclick="disable_channel()"><?=$m_auto_select?>
	</td>
	<script>SetChannel(); disable_channel();</script>
</tr>
<?if($with_xr_superg!="1"){echo "<!--";}?>
<tr>
        <td class=r_tb><?=$m_supergmode?> :&nbsp;</td>
        <td>
        <select name="supergmode" onchange="chg_supergmode()">
                <option value="0" <?if($super=="0"){echo "selected";}?>><?=$m_disabled?></option>
                <option value="1" <?if($super=="1"){echo "selected";}?>><?=$m_superg_without_turbo?></option>
                <option value="2" <?if($super=="2"){echo "selected";}?>><?=$m_superg_with_turbo?></option>
      	</select>
	</td>
</tr>
<tr>
        <td class=r_tb><?=$m_xr_mode?> :&nbsp;</td>
	<td class=l_tb>
	<input name=xr type=radio value=1 <?if($xr=="1"){echo "checked";}?>><?=$m_enabled?>
	<input name=xr type=radio value=0 <?if($xr=="0"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>
<?if($with_xr_superg!="1"){echo "-->";}?>
<tr>
        <td class=r_tb><?=$m_11g_only_mode?> :&nbsp;</td>
	<td class=l_tb>
	<input name=x11gOnly type=radio value=1 <?if($x11gOnly=="2"){echo "checked";}?>><?=$m_enabled?>
	<input name=x11gOnly type=radio value=0 <?if($x11gOnly=="1"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>					
<tr>
        <td class=r_tb><?=$m_ssid_broadcast?> :&nbsp;</td>
	<td class=l_tb>
	<input name=ssidBroadcast type=radio value=1 <?if($ssidHidden=="0"){echo "checked";}?>><?=$m_enabled?>
	<input name=ssidBroadcast type=radio value=0 <?if($ssidHidden=="1"){echo "checked";}?>><?=$m_disabled?>
	</td>
</tr>
<tr>
	<td class=r_tb><?=$m_security?> :&nbsp;</td>
	<td>
	<select name=secumode onChange="chgSecuMode(this.value)">
	<option value="0" <?if($wepMode=="0"){echo "selected";}?>><?=$m_disable?></option>
	<option value="1" <?if($wepMode=="1"){echo "selected";}?>><?=$m_wep?></option>
	<option value="2" <?if($auth=="2"||$auth=="3"){echo "selected";}?>><?=$m_wpa?></option>
	<option value="3" <?if($auth=="4"||$auth=="5"){echo "selected";}?>><?=$m_wpa2?></option>
	<option value="4" <?if($auth=="6"||$auth=="7"){echo "selected";}?>><?=$m_wpa2_auto?></option>
	</select></td>
</tr>

<tr id="setting_wep">
	<td colspan=2>
	<table width=<?=$width_tb?>>
	<tr>
		<td width=36% class=r_tb><?=$m_authentication?> :&nbsp;</td>
		<td width=64% class=l_tb>
		<input name=wep_sk type=radio value=0 <?if($auth!="1"){echo "checked";}?>><?=$m_open_system?>
		<input name=wep_sk type=radio value=1 <?if($auth=="1"){echo "checked";}?>><?=$m_shared_key?>
		</td>
	</tr>
	<tr>
		<td class=r_tb><?=$m_wep_encryption?> :&nbsp;</td>
		<td class=l_tb>
		<select name=wep_Len size=1 onChange="chgWepLen()">
		<option value="64" <?if($wepLen=="64"){echo "selected";}?>><?=$m_64bit?></option>
		<option value="128" <?if($wepLen=="128"){echo "selected";}?>><?=$m_128bit?></option></select>
		</td>
	</tr>
	<tr>
		<td class=r_tb><?=$m_key_type?> :&nbsp;</td>
		<td>
		<select name="wepKeyType" onChange="chgWepLen()">
		<option value="1" <?if($wepFormat=="1"){echo "selected";}?>><?=$m_ascii?></option>
		<option value="2" <?if($wepFormat=="2"){echo "selected";}?>><?=$m_hex?></option>
		</select>
		</td>
	</tr>
	<tr>
		<td colspan=2><script>print_keys(); chgWepLen();</script></td>
	</tr>
	</table>
	</td>
</tr>
<tr id="setting_wpa">	
	<td colspan=2>
	<table width="<?=$width_tb?>">
	<tr>
		<td width=36% class=r_tb><?=$m_cipher_type?> :&nbsp;</td>
		<td width=64% class=l_tb>
		<input name=cipher_type type=radio value=0 <?if($wepMode==2){echo "checked";}?>><?=$m_tkip?>
		<input name=cipher_type type=radio value=1 <?if($wepMode==3){echo "checked";}?>><?=$m_aes?>
		</td>
	</tr>
	<tr>	
		<td class=r_tb><?=$m_psk_eap?>:&nbsp;</td>
		<td class=l_tb>
		<input id=psk_eap name=psk_eap type=radio value=0 <?if($auth!=2&&$auth!=4&&$auth!=6){echo "checked";}?> onClick="chgPskEap()"><?=$m_psk?>
		<input name=psk_eap type=radio value=1 <?if($auth==2||$auth==4||$auth==6){echo "checked";}?> onClick="chgPskEap()"><?=$m_eap?>
		</td>
	</tr>
	</table></td>
</tr>
<tr id="setting_wpa_eap">
	<td colspan=2>
	<table width="<?=$width_tb?>">
	<tr><td height="6" class=title_tb><?=$m_1x?></td></tr>
	<tr>
		<td width=36% class=r_tb><?=$m_radius_ip?> :&nbsp;</td>
		<td width=64% class=l_tb><input maxlength=15 name=RADIUSIP size=15 value="<?=$wpaIp?>"></td>
	</tr>
	<tr>
		<td class=r_tb><?=$m_radius_port?> :&nbsp;</td>
		<td><input type="text" name="RADIUSPort" size="5" maxlength="5" value="<?=$wpaPort?>"></td>
	</tr>
	<tr>
		<td class=r_tb><?=$m_radius_secret?> :&nbsp;</td>
		<td><input type="password" name="pass" size="32" maxlength="31" value=""></td>
	</tr>
	</table>
	</td>
</tr>
<tr id="setting_wpa_psk">
	<td colspan=2>
	<table width="<?=$width_tb?>">
	<tr><td height="5"></td></tr>
	<tr>
		<td colspan=2 class=c_tb>
			<input type="radio" name=psk_format onchange="chg_psk()"<?if($psk_format=="2"){echo " checked";}?>><?=$m_psk_64_hex?>&nbsp;&nbsp;
			<input type="radio" name=psk_format onchange="chg_psk()"<?if($psk_format=="1"){echo " checked";}?>><?=$m_psk_8_63_ascii?>
		</td>
	</tr>
	<tr id="tr_psk">
		<td colspan=2 class=c_tb><?=$m_psk?> :&nbsp;<input type="text" name="psk" size=64 maxlength="64"></td>
	</tr>
	<tr id="tr_passphrase1">
		<td width=36% class=r_tb><?=$m_passphrase?> :&nbsp;</td>
		<td width=64% class=l_tb><input type="password" name="wpapsk1" size="30" maxlength="64"></td>
	</tr>
	<tr id="tr_passphrase2">
		<td class=r_tb><?=$m_confirm_passphrase?> :&nbsp;</td>
		<td class=l_tb><input type="password" name="wpapsk2" size="30" maxlength="64"></td>
	</tr>
	</table>
	</td>
</tr>
<tr><td>&nbsp;</td></tr>
<?if($with_xr_superg!="1"){echo "<!--";}?>
<tr><td colspan=2 class=l_tb><?=$m_warn_superg_with_turbo_only_work_in_ch6?><td></tr>
<?if($with_xr_superg!="1"){echo "-->";}?>
<tr><td>&nbsp;</td></tr>
<script language=JavaScript>chgSecuMode();</script>
<tr><td colspan=2 align=right><script language="JavaScript">apply(""); cancel("doReset()");help("help_home.php#02_1");</script></td></tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
