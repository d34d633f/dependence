<?
$MSG_FILE="h_dhcp.php";
$apply_name="h_dhcp.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");

$lan_ip=query("/lan/ethernet/ip");
anchor("/lan/dhcp/server/pool:1");
$dhcp_en=query("/lan/dhcp/server/enable");
$sip=query("startip");
$eip=query("endip");
$leasetime=query("leasetime");
$client_num=0;
?>

<script>
<? require("/www/comm/time.js"); ?>
var sip=getIP("<?=$sip?>");
var eip=getIP("<?=$eip?>");
var saveDHCPClient;
var SelRow=-1;
var SelRowBC;
// enable static dhcp client lists or not ?
sList=[['','','','','']<?
for("/lan/dhcp/server/pool:1/staticdhcp/entry")
{
	$client_num++;
	echo ",\n['','".query("enable")."','".queryjs("hostname")."','".query("ip")."','".query("mac")."']";
}
?>];
// dynamic dhcp client lists data
dList=[['index','hostname','ip','mac','expire']<?
$d_index=0;
for("/runtime/dhcpserver/lease")
{
	$d_index++;
	echo ",\n	";
	echo "['".$d_index."','".queryjs("hostname")."','".
	query("ip")."','".query("mac")."','".query("expire")."']";
}
?>];
var lanIP=getIP("<?=$lan_ip?>");

function dynamic_dhcp_list()
{
	var str=new String("");
	<?
	for("/runtime/dhcpserver/lease")
	{
		echo "str+='<tr><td class=l_tb>';\n";
		echo "	var h_name='".queryjs("hostname")."';\n";
		echo "	for(var i=0; i<h_name.length; i++)\n";
		echo "	{\n";
		echo "		if(h_name.charAt(i)=='<')	str+='&lt;';\n";
		echo "		else if(h_name.charAt(i)=='>')	str+='&gt';\n";
		echo "		else				str+=h_name.charAt(i);\n";
		echo "	}\n";
		echo "	str+='</td>';\n";
		echo "	str+='<td class=l_tb>&nbsp;".query("ip")."</td>';\n";
		echo "	str+='<td clqss=l_tb>&nbsp;".query("mac")."</td>';\n";
		echo "	str+='<td class=l_tb>&nbsp;'+parseTime(\"".query("expire")."\")+'</td>';\n";
		echo "	str+='</tr>'\n";
	}
	?>
	document.writeln(str);
}
function checkParameter1()
{
	var f = document.getElementById("frm_dhcps");
	var i = 0;

	// starting ip
	var sIP4=f.startIP4.value;
	if (isNumber(sIP4))
	{
		if (!check_ip_interval(sIP4))
		{
			alert("<?=$a_startIP_should_be_1_254?>\n");
			f.startIP4.focus();
			return false;
		}
	}
	else
	{
		alert("<?=$a_startIP_wrong_format?>\n");
		f.startIP4.focus();
		return false;
	}

	// ending ip
	var eIP4=f.endIP4.value;
	if (isNumber(eIP4))
	{	
		if (!check_ip_interval(eIP4))
		{
			alert("<?=$a_endIP_should_be_1_254?>\n");
			f.endIP4.focus();
			return false;
		}
	}
	else
	{
		alert("<?=$a_endIP_wrong_format?>\n");
		f.endIP4.focus();
		return false;
	}

	if (parseInt(sIP4, [10]) > parseInt(eIP4, [10]))
	{
		alert("<?=$a_startIP_bigger_endIP?>\n");
		f.endIP4.focus();
		return false;
	}

	// check if the LAN IP is in the DHCP range.
	if (parseInt(lanIP[4], [10]) >= parseInt(sIP4, [10]) && parseInt(lanIP[4], [10]) <= parseInt(eIP4, [10]))
	{
		var lan_IP=lanIP[1]+"."+lanIP[2]+"."+lanIP[3]+"."+lanIP[4];
		alert("<?=$a_dhcpIP_cant_include_lanIP?>("+lan_IP+")!\n");
		f.startIP4.focus();
		return false;
	}

	return true;
}

function checkParameter2()
{
	var f = document.getElementById("frm_dhcps");
	var i = 0;
	MaxRule=<?if($max_rule==""){echo "0";}else{echo $max_rule;}?>;

	if (f.editRow.value == -1 && parseInt('<?=$client_num?>', [10]) >= MaxRule)
	{
		alert("<?=$a_exceed_max_rule?>");
		return false;
	}

	var rIP4=f.revIP4.value;
	saveDHCPClient=false;

	if(isBlank(f.name.value))
	{
		alert("<?=$a_static_dhcp_name_cant_empty?>");
		f.name.focus();
		return false;
	}
	// dhcp client ip
	if (isNumber(rIP4))
	{
		if (!check_ip_interval(rIP4))
		{
			alert("<?=$a_staticIP_should_be_1_254?>");
			f.revIP4.focus();
			return false;
		}
	}
	else
	{
		alert("<?=$a_staticIP_should_be_number?>\n");
		f.revIP4.focus();
		return false;
	}
	// check if the ip address is the same with LAN ip address
	if (lanIP[4] == rIP4)
	{
		alert("<?=$a_staticIP_cant_same_lanIP?>(<?=$lan_ip?>)!");
		f.revIP4.focus();
		return false;
	}

	// dhcp client mac
	for (i=1; i < 7;i++)
	{
		var mac=eval("f.mac"+i);
		var strlen=2-mac.value.length;
		mac.value=mac.value.toUpperCase();
		for(j=0; j<strlen; j++)
			mac.value="0"+mac.value;

		if (!checkMAC(mac.value))
		{
			alert("<?=$a_staticIP_wrong_format?>\n");
			eval("f.mac"+i+".focus();");
			return false;
		}
	}

	ip=lanIP[1]+"."+lanIP[2]+"."+lanIP[3]+"."+parseInt(f.revIP4.value, [10]);
	mac=f.mac1.value+":"+f.mac2.value+":"+f.mac3.value+":"+f.mac4.value+":"+f.mac5.value+":"+f.mac6.value;
	for(i=0; i<sList.length; i++)
	{
		if(f.editRow.value==i)
			continue;
		if(ip==sList[i][3])
		{
			alert("<?=$a_sameIP_exist?>");
			f.revIP4.value=parseInt(f.revIP4.value, [10]);
			f.revIP4.focus();
			return false;
		}
		if(mac.toUpperCase()==sList[i][4].toUpperCase())
		{
			alert("<?=$a_sameMAC_exist?>");
			f.mac1.focus();
			return false;
		}
	}

	saveDHCPClient=true;
	return true;
}

// this function is used to send data to server when user presses the "Apply" button.
function doSubmit()
{
	if (checkParameter1()==false) return;
	var f = document.getElementById("frm_dhcps");
	var str=new String("<?=$apply_name?>");
	var num;

	num=parseInt(f.editRow.value, [10]);
	if (f.editRow.value == "-1") num=parseInt("<?=$client_num?>", [10])+1;

	str+="set/lan/dhcp/server/enable="+(f.dhcpsvr[0].checked? "1":"0");
	startip=lanIP[1]+"."+lanIP[2]+"."+lanIP[3]+"."+f.startIP4.value;
	str+="&set/lan/dhcp/server/pool:1/startIP="+reduceIP(startip);
	endip=lanIP[1]+"."+lanIP[2]+"."+lanIP[3]+"."+f.endIP4.value;
	str+="&set/lan/dhcp/server/pool:1/endIP="+reduceIP(endip);
	str+="&set/lan/dhcp/server/pool:1/leaseTime="+f.lease[f.lease.selectedIndex].value;

	//dhcp client name
	if(f.revdhcp[0].checked || !isBlank(f.revIP4.value) || !isBlank(f.mac1.value) || !isBlank(f.mac2.value) ||
		!isBlank(f.mac3.value) || !isBlank(f.mac4.value) || !isBlank(f.mac5.value) || !isBlank(f.mac6.value))
		if(checkParameter2()==false)	return;

	if (f.revdhcp[0].checked && checkParameter2()==false) return;
	if(CheckUCS2(f.name.value))
	{
		alert("<?=$a_hostname_only_ascii?>");
		return;
	}					
	if (saveDHCPClient)
	{
		str+="&set/lan/dhcp/server/pool:1/staticDhcp/entry:"+num+"/enable="+(f.revdhcp[0].checked? "1":"0");
		str+="&set/lan/dhcp/server/pool:1/staticDhcp/entry:"+num+"/hostname="+escape(f.name.value);
		ip=lanIP[1]+"."+lanIP[2]+"."+lanIP[3]+"."+f.revIP4.value;
		str+="&set/lan/dhcp/server/pool:1/staticDhcp/entry:"+num+"/IP="+reduceIP(ip);
		mac=f.mac1.value+":"+f.mac2.value+":"+f.mac3.value+":"+f.mac4.value+":"+f.mac5.value+":"+f.mac6.value;
		str+="&set/lan/dhcp/server/pool:1/staticDhcp/entry:"+num+"/MAC="+mac;
	}
	str+=exeStr("submit COMMIT;submit DHCPD");
	self.location.href=str;
}

function doDelete(num)
{
	if (confirm("<?=$a_realy_del?>")==false) return;
	var f = document.getElementById("frm_dhcps");
	var str=new String("<?=$apply_name?>");

	str+="&DEL/LAN/DHCP/SERVER/POOL:1/STATICDHCP/ENTRY:"+num+"=1";
	str+=exeStr("submit COMMIT;submit DHCPD");
	self.location.href=str;
}

function doReset()
{
	self.location.href="h_dhcp.php";
}

function SelectRow(tn,row)
{
	if (SelRow != row)
	{
		var bar = document.getElementById(tn);
		if (SelRow >= 0)	bar.rows[SelRow].style.backgroundColor = SelRowBC;
		if (row >= 0)
		{
			SelRowBC = bar.rows[row].style.backgroundColor;
			bar.rows[row].style.backgroundColor = "#FFFF00";
		}
		SelRow = row;
	}
}

function EditRow(r)
{
	var f = document.getElementById("frm_dhcps");
	var ip=getIP(sList[r][3]);
	var mac=getMAC(sList[r][4]);
	f.editRow.value=r;

	if(sList[r][1]==1)	f.revdhcp[0].checked=true;
	else			f.revdhcp[1].checked=true;
	f.name.value=sList[r][2];
	f.revIP4.value=ip[4];
	for(i=1;i<7;i++)	eval("f.mac"+i+".value=mac["+i+"];");
	SelectRow("static_dhcp",r);
}

function initDHCP()
{
	var f = document.getElementById("frm_dhcps");
	sip=getIP("<?=$sip?>");
	eip=getIP("<?=$eip?>");
	<?
	if($dhcp_en=="1")	{echo "f.dhcpsvr[0].checked=true";}
	else			{echo "f.dhcpsvr[1].checked=true";}
	?>
	for(i=1;i<4;i++)	eval("f.sIP"+i+".value=lanIP["+i+"];");
	for(i=1;i<4;i++)	eval("f.eIP"+i+".value=lanIP["+i+"];");
	for(i=1;i<4;i++)	eval("f.rIP"+i+".value=lanIP["+i+"];");
	
	f.startIP4.value=sip[4];
	f.endIP4.value=eip[4];
	//f.lease.selectedIndex=dServer.LTime[0];
}

function cloneMAC(f,r)
{
	if(r==-1) return;
	c_ip=getIP(dList[r][2]);
	c_mac=getMAC(dList[r][3]);
	
	f.name.value=dList[r][1];
	f.revIP4.value=c_ip[4];
	for(i=1;i<7;i++)	eval("f.mac"+i+".value=c_mac["+i+"];");
}

function print_pre_ip(n)
{
	str="";
	for(i=1;i<4;i++)
		str+="<input type=text readonly name="+n+i+" size=3 maxlength=3 style='border:0;width=25px;text-align:center'>.";
	document.write(str);
}
function print_mac(n)
{
	str="";
	for(i=1;i<7;i++)
	{
		str+="<input type=text name="+n+i+" size=1 maxlength=2 value=''>";
		if(i!=6)	str+=" : ";
	}
	document.write(str);
}
function print_lease_sel(n)
{
	lease_item=[	['3600','1 <?=$m_hr?>'],['7200','2 <?=$m_hrs?>'],['10800','3 <?=$m_hrs?>'],['86400','1 <?=$m_day?>'],
			['172800','2 <?=$m_days?>'],['259200','3 <?=$m_days?>'],['604800','1 <?=$m_wk?>']];

	str="<select name="+n+" size=1>";
	for(var i=0;i<lease_item.length;i++)
	{
		str+="<option value="+lease_item[i][0];
		if(lease_item[i][0]=="<?=$leasetime?>")	str+=" selected ";
		str+=">"+lease_item[i][1]+"</option>";
	}
	str+="</select>";
	document.write(str);
}
function print_dhcp_sel(n)
{
	str="<select name="+n+" size=1>";
	if(parseInt("<?=$d_index?>", [10])==0)	str+="<option value=-1></option>";
	for(i=1;i<=parseInt('<?=$d_index?>', [10]);i++)
	{
		str+="<option value="+i+">"+dList[i][1]+" ("+dList[i][3]+")</option>";
	}
	str+="</select>";
	document.write(str);
}

<?
$rule_num=0;
for("/lan/dhcp/server/pool:1/staticdhcp/entry") { $rule_num++; }
?>

</script>
<?$margin_tb=25;?>
<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0" onload=initDHCP()>
<?require("/www/comm/middle.php");?>
<form name=dhcps method=post id=frm_dhcps>
<input type=hidden name=editRow value="-1">
<input type="hidden" name="delrow" value="0">
<table width="<?=$width_tb?>" border=0 height=215 >
<tr>
	<td colspan=2 height=15 class=title_tb><?=$m_DHCP_srv?></td>
</tr>
<tr valign="top">
	<td colspan=2 height=40 class=l_tb><?=$m_DHCP_explain?></td>
</tr>
<tr>
	<td width="<?=$margin_tb?>"></td>
	<td>
	<table width=100%>
	<tr>
		<td width=30% class=l_tb><?=$m_DHCP_srv?></td>
		<td width=70% class=l_tb><input type=radio value=1 name=dhcpsvr><?=$m_enabled?><input type=radio name=dhcpsvr value=0><?=$m_disabled?></td>
	</tr>
	<tr>
		<td class=l_tb><?=$m_startIP?></td>
		<td class=l_tb><script>print_pre_ip("sIP");</script><input type=text name=startIP4 size=3 maxlength=3></td>
	</tr>
	<tr>
		<td class=l_tb><?=$m_endIP?></td>
		<td class=l_tb><script>print_pre_ip("eIP");</script><input type=text name=endIP4 size=3 maxlength=3></td>
	</tr>
	<tr>
		<td height=22 class=l_tb><?=$m_lease_time?></td>
		<td height=22 class=l_tb><script>print_lease_sel('lease');</script></td>
	</tr>
	<tr>
		<td colspan="2" height=22>&nbsp;</td>
	</tr>
	</table>
	</td>
</tr>
<tr>
	<td colspan=2 height=15 class=title_tb><?=$m_static_dhcp?></td>
</tr>
<tr valign="top">
	<td colspan=2 height=40 class=l_tb><?=$m_static_dhcp_explain?></td>
</tr>
<tr>
	<td width="<?=$margin_tb?>"></td>
	<td>
	<table width=100%>
	<tr>
		<td width=30%><?=$m_static_dhcp?></td>
		<td width=70% class=l_tb>
		<input type=radio value=1 name=revdhcp><?=$m_enabled?>&nbsp;
		<input type=radio name=revdhcp value=0 checked><?=$m_disabled?>
		</td>
	</tr>
	<tr>
		<td class=l_tb><?=$m_name?></td>
		<td><input type=text name=name size=19 maxlength=19></td>
	</tr>
	<tr>
		<td class=l_tb><?=$m_ip_addr?></td>
		<td class=l_tb><script>print_pre_ip("rIP");</script><input type=text name=revIP4 size=3 maxlength=3></td>
	</tr>
	<tr>
		<td class=l_tb><?=$m_mac_addr?></td>
		<td class=l_tb><script>print_mac("mac");</script></td>
	</tr>
	<tr>
		<td height=22 class=l_tb><?=$m_dhcp_client?></td>
		<td height=22 class=l_tb>
		<script>print_dhcp_sel("dhcp");</script>
		<input type=button name=clone value=Clone onClick=cloneMAC(this.form,this.form.dhcp.value)>
		</td>
	</tr>
	<tr><td colspan=2><br></td></tr>
	</table>
	</td>
</tr>
<tr>
	<td colspan=2 align=right>
	<script language="JavaScript">apply(""); cancel("");help("help_home.php#04");</script>
</tr>
</table>
<table width="<?=$width_tb?>" border=0 cellpadding=0 cellspacing=0 id=tabRev>
<tr>
	<td colspan=2><table width=100%><tr>
		<td width=50% class=title_tb><?=$m_static_dhcp_clint_list?></td>
		<td width=50% class=r_tb><script>print_rule_count("<?=$rule_num?>","<?=$max_rule?>");</script></td>
	</tr></table></td>
</tr>
<tr>
	<td>
	<table width=100% cellpadding=0 cellspacing=0 id=static_dhcp>
	<tr bgcolor=#B7DCFB>
		<td>&nbsp;</td>
		<td class=l_tb><?=$m_hostname?></td>
		<td class=l_tb><?=$m_ip_addr?></td>
		<td class=l_tb><?=$m_mac_addr?></td>
		<td>&nbsp;</td>
	</tr>
<?
for("/lan/dhcp/server/pool:1/staticdhcp/entry")
{
	echo "	<tr>\n";
	echo "		<td><input type='checkbox' name='en' ";
	if(query("enable")=="1"){echo "checked ";}
	echo "disabled></td>\n";
	echo "		<td class=l_tb><script>echosc(\"".queryjs("hostname")."\");</script></td>\n";
	echo "		<td class=l_tb>".query("ip")."</td>\n";
	echo "		<td class=l_tb>".query("mac")."</td>\n";
	echo "		<td>\n";
	echo "		<img src='../graphic/edit.gif' width=15 height=17 border=0 alt=edit onclick=EditRow(".$@.")>";
	echo "		<img src='../graphic/delet.gif' width=15 height=18 border=0 alt=delete onclick=doDelete(".$@.")>";
	echo "		</td>\n";
	echo "	</tr>\n";
}
?>
	</table>
	</td>
</tr>
</table>
<table width="<?=$width_tb?>" border=0 cellpadding=0 cellspacing=0>
<tr>
	<td colspan=3 height=30 class=title_tb><?=$m_dhcp_client_list?></td>
	<td colspan=2 class=r_tb align=right>
	<script>
		var to=dList.length-1;
		var mr=eip[4]-sip[4]+1;
		print_rule_count(to,mr);
	</script>
	&nbsp;</td>
</tr>
<tr bgcolor=#B7DCFB>
	<td class=c_tb><?=$m_hostname?></td>
	<td class=c_tb><?=$m_ip_addr?></td>
	<td class=c_tb><?=$m_mac_addr?></td>
	<td class=c_tb><?=$m_lease_time?></td>
	<td></td>
</tr>
<script>dynamic_dhcp_list();</script>
</table>
</form>
<?require("/www/comm/bottom.php");?>
