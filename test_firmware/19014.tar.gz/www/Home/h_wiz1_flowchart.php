<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz1_flowchart.php";
require("/www/comm/genWizTop.php");?>
<form>
<?=$table?>
<tr><td height=11><?=$top_pic?></td></tr>
<tr><td height=10></td></tr>
<tr><td>
	<table width=95% border=0 cellspacing=0 cellpadding=0 height=39 align=center>
	<tr><td class=c_wiz><?=$m_welcome_msg?>	</td></tr>
	</table>
</td></tr>
<tr><td height=180>
	<table width=100%>
	<tr>
		<td height=10 width=20%></td>
		<td>
		<table border=0 width=100% height="<?=$height_wiz?>" cellpadding=0>
		<tr><td class=l_wiz><?=$m_step1?></td></tr>
		<tr><td class=l_wiz><?=$m_step2?></td></tr>
		<tr><td class=l_wiz><?=$m_step3?></td></tr>
		<tr><td class=l_wiz><?=$m_step4?></td></tr>
		<tr><td class=l_wiz><?=$m_step5?></td></tr>
		</table>
		</td>
	</tr>
	</table>
</td></tr>
<tr><td height=10 align=right valign=bottom><script language="JavaScript">next("h_wiz2_password.php");exit();</script></td></tr>
</table>
</form>
</body>
</html>
