<?require("/www/comm/genTop.php");?>
<script language="JavaScript">
time="<?query("/time/syncWith");?>";
if(time=="1")
{
	var d=new Date();
	str="<?=$link?>.xgi?";
	str+="setPath=/runtime/time/";
	str+="&date="+"<?=$date?>";
	str+="&time="+"<?=$time?>";
	str+="&endSetPath=1";
	str+="&exeshell=submit TIME";
	self.location.href=str;
}
else
{
	self.location.href="<?=$link?>.php";
}
</script>
<body bgcolor="#FFFFFF" text="#000000">
</body>
</html>
