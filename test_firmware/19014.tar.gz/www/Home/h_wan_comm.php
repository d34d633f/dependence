<?/* vi: set sw=4 ts=4: */?>
<script>
function ChgPage(i)
{
	var p;
	switch(i)
	{
	case 0: p="h_wan_dhcp.php";		break;
	case 1: p="h_wan_fix.php";		break;
	case 2: p="h_wan_poe.php";		break;
	case 3: p="h_wan_pptp.php";		break;
	case 4: p="h_wan_l2tp.php";		break;
	case 5: p="h_wan_bigpond.php";	break;
	default:						break;
	}
	self.location.href=p;
}

function init()
{
	var f=document.getElementById("wan_form");
	var mac=new Array();
<?
	if($radio=="1")
	{
		anchor("/wan/rg/inf:1/static");
		echo "	f.ip.value='".queryjs("ip")."';\n";
		echo "	f.mask.value='".queryjs("netmask")."';";
		echo "	f.gateway.value='".queryjs("gateway")."';";
	}
	else if($radio=="2")
	{
		anchor("/wan/rg/inf:1/dhcp");
		echo "	f.host.value='".queryjs("/sys/hostname")."';\n";
	}
	else if($radio=="3")
	{
		anchor("/wan/rg/inf:1/pppoe");
		if (query("mode")=="1")	{echo "	f.fixIP[1].checked=true;";}
		else					{echo "	f.fixIP[0].checked=true;";}
		echo "	f.ip.value='".queryjs("staticip")."';\n";
		echo "	f.name.value='".queryjs("user")."';\n";
		echo "	f.ac_name.value='".queryjs("acName")."';\n";
		echo "	f.srv_name.value='".queryjs("acservice")."';\n";
		if (query("autoreconnect")!=1)
		{
			echo "	f.cod[1].checked=true;\n";
			echo "	on_change_connect_mode(1);\n";
		}
		else if (query("ondemand")==1)
		{
			echo "	f.cod[2].checked=true;\n";
			echo "	on_change_connect_mode(2);\n";
		}
		else
		{
			echo "	f.cod[0].checked=true;\n";
			echo "	on_change_connect_mode(0);\n";
		}
		echo "clickPOE();\n";
	}
	else if($radio=="4")
	{
		anchor("/wan/rg/inf:1/pptp");
		if (query("mode")=="1")	{ echo "	f.fixIP[1].checked=true\n"; }
		else					{ echo "	f.fixIP[0].checked=true\n"; }
		echo "	f.ip.value='".queryjs("ip")."';\n";
		echo "	f.mask.value='".queryjs("netmask")."';\n";
		echo "	f.gateway.value='".queryjs("gateway")."';\n";
		echo "	f.dns.value='".queryjs("dns")."';\n";
		echo "	f.server_ip.value='".queryjs("serverip")."';\n";
		echo "	f.pptpuserid.value='".queryjs("user")."';\n";
		echo "	f.pptppwd.value='WDB8WvbXdHtZyM8Ms2RENgHlacJghQy';\n";
		echo "	f.pptppwd2.value='WDB8WvbXdHtZyM8Ms2RENgHlacJghQy';\n";
		if (query("autoreconnect")!=1)
		{
			echo "	f.cod[1].checked=true;\n";
			echo "	on_change_connect_mode(1);\n";
		}
		else if (query("ondemand")==1)
		{
			echo "	f.cod[2].checked=true;\n";
			echo "	on_change_connect_mode(2);\n";
		}
		else
		{
			echo "	f.cod[0].checked=true;\n";
			echo "	on_change_connect_mode(0);\n";
		}
		echo "	clickPPTP();\n";
	}
	else if($radio=="5")
	{
		anchor("/wan/rg/inf:1/l2tp");
		if (query("mode")=="1")	{ echo "	f.fixIP[1].checked=true\n"; }
		else					{ echo "	f.fixIP[0].checked=true\n"; }
		echo "	f.ip.value='".queryjs("ip")."';\n";
		echo "	f.mask.value='".queryjs("netmask")."';\n";
		echo "	f.gateway.value='".queryjs("gateway")."';\n";
		echo "	f.dns.value='".queryjs("dns")."';\n";
		echo "	f.server_ip.value='".queryjs("serverip")."';\n";
		echo "	f.l2tpuserid.value='".queryjs("user")."';\n";
		echo "	f.l2tppwd.value='WDB8WvbXdHtZyM8Ms2RENgHlacJghQy';\n";
		echo "	f.l2tppwd2.value='WDB8WvbXdHtZyM8Ms2RENgHlacJghQy';\n";
		if (query("autoreconnect")!=1)
		{
			echo "	f.cod[1].checked=true;\n";
			echo "	on_change_connect_mode(1);\n";
		}
		else if (query("ondemand")==1)
		{
			echo "	f.cod[2].checked=true;\n";
			echo "	on_change_connect_mode(2);\n";
		}
		else
		{
			echo "	f.cod[0].checked=true;\n";
			echo "	on_change_connect_mode(0);\n";
		}
		echo "	clickL2TP();\n";
	}
	else if($radio=="7")
	{
		anchor("/wan/rg/inf:1/bigpond");
		echo "	f.bigusername.value='".queryjs("username")."';\n";
		echo "	f.bigpwd1.value='WDB8WvbXdHtZyM8Ms2RENgHlacJghQy';\n";
		echo "	f.bigpwd2.value='WDB8WvbXdHtZyM8Ms2RENgHlacJghQy';\n";
		//echo "	f.authserver.value='".queryjs("server")."';\n";
		//if(query("autoreconnect")=="1")	{echo "	f.autoreconnect[0].checked=true;\n";}
		//else				{echo " f.autoreconnect[1].checked=true;\n";}
		echo "	mac=getMAC('".queryjs("clonemac")."');\n";
		echo "	f.mac1.value=mac[1];\n";
		echo "	f.mac2.value=mac[2];\n";
		echo "	f.mac3.value=mac[3];\n";
		echo "	f.mac4.value=mac[4];\n";
		echo "	f.mac5.value=mac[5];\n";
		echo "	f.mac6.value=mac[6];\n";
	}
	if($radio<4)
	{
		echo "	f.dns1.value='".queryjs("/dnsrelay/server/primarydns")."';\n";
		echo "	f.dns2.value='".queryjs("/dnsrelay/server/secondarydns")."';\n";
		echo "	mac=getMAC('".queryjs("clonemac")."');\n";
		echo "	f.mac1.value=mac[1];\n";
		echo "	f.mac2.value=mac[2];\n";
		echo "	f.mac3.value=mac[3];\n";
		echo "	f.mac4.value=mac[4];\n";
		echo "	f.mac5.value=mac[5];\n";
		echo "	f.mac6.value=mac[6];\n";
	}
	if($radio>2 && $radio!="7")	{echo "  f.idle.value=parseInt('".queryjs("idletimeout")."', [10])/60;\n";}
	if($radio!="7")			{echo "	f.mtu.value='".queryjs("mtu")."';\n";}
?>
}
function doReset()
{
	init();
}
function setMac()
{
	var runtimeMAC='<?=$macaddr?>';
	if(runtimeMAC=="00:00:00:00:00:00" || runtimeMAC=="")
	{
		show_err("<?=$a_cant_get_client_mac?>");
		html_top.focus();
		return;
	}
	myMac = getMAC(runtimeMAC);

	var f=document.getElementById("wan_form");
	f.mac1.value=myMac[1];
	f.mac2.value=myMac[2];
	f.mac3.value=myMac[3];
	f.mac4.value=myMac[4];
	f.mac5.value=myMac[5];
	f.mac6.value=myMac[6];
}
function print_mac()
{
	str="";
	for(i=1; i<7; i++)
	{
		str+="<input type=text name=mac"+i+" size=2 maxlength=2>";
		if(i!=6)        str+=" - ";
		else            str+=" (<?=$m_optional?>)";
	}
	document.write(str);
}
function ck_dns2(f)
{
	if (!isBlank(f.dns2.value))
	{
		if (!checkIpAddr(f.dns2, "<?=$a_invalid_dns2?>"))
		{
			return false;
		}
	}
	return true;
}
function ck_mac(f)
{
	if (!isBlank(f.mac1.value)||!isBlank(f.mac2.value)||!isBlank(f.mac3.value)||
		!isBlank(f.mac4.value)||!isBlank(f.mac5.value)||!isBlank(f.mac6.value))
	{
		for (i=1; i < 7;i++)
		{
			var mac=eval("f.mac"+i);
			var strlen=2-mac.value.length;
			mac.value=mac.value.toUpperCase();
			for(j=0; j<strlen; j++)
				mac.value="0"+mac.value;

			if (!checkMAC(mac.value))
			{
				alert("<?=$a_invalid_mac?>\n");
				return false;
			}
		}
	}
	return true;
}
function ck_mtu(f,start,end)
{
	//MTU
	if (!isNumber(f.mtu.value))
	{
		alert("<?=$a_mtu_not_number?>\n");
		return false;
	}
	if (!checkDigitRange(f.mtu.value,1,start,end))
	{
		alert(<?=$a_mtu_should_between_start_end?>);
		return false;
	}
	return true;
}
function ck_idle(f)
{
	//Max idle time
	if (!isNumber(f.idle.value))
	{
		alert( "<?=$a_max_idle_time_not_number?>\n");
		return false;
	}
	return true;
}
function on_change_connect_mode(value)
{
	var f = document.getElementById("wan_form");
	if (value == 0 || value == 1)	{ f.idle.disabled = true; }
	else				{ f.idle.disabled = false; }
}
function ck_pptp_l2tp(ip, mask, gw, dns, server)
{

	if (!checkIpAddr(ip, "<?=$a_invalid_ipaddr?>")) return false;
	if (!validMask(mask, "<?=$a_invalid_netmask?>")) return false;
	if (!checkMaskAddr(ip, mask.value, "<?=$a_invalid_ipaddr?>")) return false;
	if (gw.value != "")
	{
		if (!checkIpAddr(gw, "<?=$a_invalid_gwaddr?>")) return false;
		if (!checkSubnet(gw.value, mask.value, ip.value))
		{
			alert("<?=$a_invalid_gwaddr?>\n<?=$a_should_be_in_same_subnet?>");
			gw.value = gw.defaultValue;
			gw.focus();
			return false;
		}
		if (dns.value != "")
		{
			if (!checkIpAddr(dns, "<?=$a_invalid_svraddr?>")) return false;
			if (server.value == "")
			{
				alert("<?=$a_server_cant_be_empty?>");
				return false;
			}
		}
		else
		{
			if (!checkIpAddr(server, "<?=$a_invalid_svraddr?>")) return false;
			if (!checkSubnet(server.value, mask.value, ip.value))
			{
				alert("<?=$a_invalid_svraddr?>\n<?=$a_should_be_in_same_subnet?>");
				f.server.value = f.server.defaultValue;
				f.server.focus();
				return false;
			}
		}
	}
	else
	{
		if (!checkIpAddr(server, "<?=$a_invalid_svraddr?>")) return false;
		if (!checkSubnet(server.value, mask.value, ip.value))
		{
			alert("<?=$a_invalid_svraddr?>\n<?=$a_should_be_in_same_subnet?>");
			server.value = f.server.defaultValue;
			server.focus();
			return false;
		}
	}
	return true;
}
</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload="init()">
<?require("/www/comm/middle.php");?>
<form method=POST name=wan_form id=wan_form action="<?=$WAN_ACTION?>">
<table width="<?=$width_tb?>">
<tr><td colspan=2 class=title_tb><?=$m_wan_settings?></td></tr>
<tr valign="top">
	<td colspan=2 height=30 class=l_tb><?=$m_select_option_connect_ISP?></td>
</tr>
<tr>
	<td width=34% height=38 valign=top class=l_tb>
		<input type=radio name=connType<?if($radio=="2"){echo " checked";}else{echo " onClick=ChgPage(0)";}?>><?=$m_radio_dhcp?>
	</td>
	<td width=66% height=38 valign=top class=l_tb><?=$m_description_dhcp?></td>
</tr>
<tr>
	<td valign=top class=l_tb>
		<input type=radio name=connType<?if($radio=="1"){echo " checked";}else{echo " onClick=ChgPage(1)";}?>><?=$m_radio_static_ip?>
	</td>
	<td valign=top class=l_tb><?=$m_description_static_ip?></td>
</tr>
<tr>
	<td valign=top class=l_tb>
		<input type=radio name=connType<?if($radio=="3"){echo " checked";}else{echo " onClick=ChgPage(2)";}?>><?=$m_radio_pppoe?>
	</td>
	<td valign=top class=l_tb><?=$m_description_pppoe?></td>
</tr>
<tr>
	<td valign=top class=l_tb>
		<input type=radio name=connType<?if($radio=="4"||$radio=="5"||$radio=="7"){echo " checked";}else{echo " onClick=ChgPage(3)";}?>><?=$m_radio_others?>
	</td>
	<td valign=top class=l_tb><?=$m_description_others?></td>
</tr>
<tr>
	<td>
	<table width=100%><?$width_others="20";?>
	<tr>
		<td width="<?=$width_others?>"></td>
		<td class=l_tb>
			<input type=radio name=other_conn<?if($radio=="4"){echo " checked";}else{echo " onClick=ChgPage(3)";}?>><?=$m_radio_pptp?>
		</td>
	</tr>
	</table>
	</td>
	<td valign=top class=l_tb><?=$m_description_pptp?></td>
</tr>
<tr>
	<td>
	<table width=100%>
	<tr>
		<td width="<?=$width_others?>" height="2"></td>
		<td height="2" class=l_tb>
			<input type=radio name=other_conn<?if($radio=="5"){echo " checked";}else{echo " onClick=ChgPage(4)";}?>><?=$m_radio_l2tp?>
		</td>
	</tr>
	</table>
	</td>
	<td valign=top class=l_tb><?=$m_description_l2tp?></td>
</tr>
<tr>
	<td>
	<table width=100%>
	<tr>
		<?$width_others="20";?>
		<td width="<?=$width_others?>"></td>
		<td class=l_tb>
			<input type=radio name=other_conn<?if($radio=="7"){echo " checked";}else{echo " onClick=ChgPage(5)";}?>><?=$m_radio_bigpond?></font>
		</td>
	</tr>
	</table>
	</td>
	<td valign=top class=l_tb><?=$m_description_bigpond?></td>
</tr>
</table>

