<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz4_wan_showing_detect.php";
$onload="onload='goNext()'";
require("/www/comm/genWizTop.php");
?>
<script>
function goNext()
{
	str="h_wiz4_wan_detect.xgi?set/runtime/wan/inf:1/discover=1";
	self.location.href=str;
}
</script>
<form name="" method=post action=wizard12.cgi>
<?=$table?>
<tr><td height=11><?=$top_pic?></td></tr>
<tr><td height=10 class=title_wiz><?=$m_title?></td></tr>
<tr>
	<td height=111 valign=top>
	<table border=0 width=100% cellpadding=0 height=135>
 	<tr>
		<td height=20 width=3>&nbsp;</td>
		<td height=20 colspan=2 class=c_wiz><?=$m_message?></td>
		<td height=20 width=1>&nbsp;</td>
	</tr>
	</table>
	</td>
</tr>
<tr>
	<td align=right>&nbsp;</td>
</tr>
</table>
</form>
</body>
</html>
