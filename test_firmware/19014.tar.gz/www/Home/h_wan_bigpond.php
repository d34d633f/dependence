<?
$file_name="h_wan_bigpond.php";
$apply_name="h_wan_bigpond.xgi?";
// radio mode: 1:static, 2:dhcp, 3:pppoe, 4:pptp, 5:l2tp 6: multi-pppoe 7: bigpond
$radio="7";

$MSG_FILE="h_wan.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
?>
<script language="JavaScript">
function doReset()
{
	self.location.href="<?=$file_name?>";
}
function check()
{
	var f = document.getElementById("wan_form");
	if (isBlank(f.bigusername.value))
	{
		alert("<?=$a_bpacc_cant_be_empty?>\n");
		f.bigusername.focus();
		return false;
	}
	if (f.bigpwd1.value!=f.bigpwd2.value)
	{
		alert("<?=$a_bp_password_mismatch?>\n");
		f.bigpwd1.value="";
		f.bigpwd1.focus();
		return false;
	}
	if (!ck_mac(f)) return false;
	return true;
}
function doSubmit()
{
	var f = document.getElementById("wan_form");
	if(check()==false)	return;
	var str=new String("");
	str+="h_wan_bigpond.xgi?";
	str+="set/wan/rg/inf:1/MODE=7";
	str+="&set/wan/rg/inf:1/bigpond/username="+escape(f.bigusername.value);
	if ( f.bigpwd1.value != "WDB8WvbXdHtZyM8Ms2RENgHlacJghQy")
	str+="&set/wan/rg/inf:1/bigpond/password="+f.bigpwd1.value;
	str+="&set/wan/rg/inf:1/bigpond/server="+f.authserver.value;
	//str+="&set/wan/rg/inf:1/bigpond/autoreconnect="+(f.autoreconnect[0].checked? "1":"0");
	mac=f.mac1.value+":"+f.mac2.value+":"+f.mac3.value+":"+f.mac4.value+":"+f.mac5.value+":"+f.mac6.value;
	str+="&set/wan/rg/inf:1/bigpond/CLONEMAC="+(mac==":::::"?"":mac);
			
	str+=exeStr("submit COMMIT;submit WAN");
	self.location.href=str;
}
</script>
<?require("/www/Home/h_wan_comm.php");?>
<table width="<?=$width_tb?>">
<tr><td colspan=2 height=30 class=title_tb><?=$m_bigpond?></tr>
<tr>
	<td width=34% valign=top class=l_tb><?=$m_user?></td>
	<td width=66% valign=top class=l_tb>
	<input type=text name=bigusername size=30 maxlength=63 value=""></td>
</tr>
<tr>
	<td width=34% class=l_tb><?=$m_password?></td>
	<td width=66% class=l_tb><input type=password name=bigpwd1 size=30 maxlength=63 value=""></td>
</tr>
<tr>
	<td width=34% height="25" class=l_tb><?=$m_retype_passwd?></td>
	<td width=66% height="25"><input type=password name=bigpwd2 size=30 maxlength=63 value=""></td>
</tr>
<tr>
	<td width=34% height="25" class=l_tb><?=$m_auth_srv?></td>
	<td width=66% height="25">
		<select name=authserver><? $bpserver=query("/wan/rg/inf:1/bigpond/server");?>
			<option value="sm-server"<?if($bpserver=="sm-server"){echo " selected";}?>>sm-server</option>
			<option value="dce-server"<?if($bpserver=="dce-server"){echo " selected";}?>>dce-server</option>
		</select>
	</td>
</tr>
<!--
<tr>
	<td width=34% height="25" class=l_tb><?=$m_login_server?></td>
	<td width=66% height="25" class=l_tb><input type=text name=loginserver size=30 maxlength=63 value="">(<?=$m_optional?>)</td>
</tr>
<tr>
	<td width=34% height="25" class=l_tb><?=$m_auto_reconnect?></td>
	<td width=66% height="25" class=l_tb>
	<input type=radio name=autoreconnect value=1><?=$m_enabled?>
	<input type=radio name=autoreconnect value=0><?=$m_disabled?>
	</td>
</tr>
-->
<tr>
	<td valign=top width=34% height="25" class=l_tb><?=$m_mac_addr?></td>
	<td class=l_tb>
	<script>print_mac();</script><br>
	<input type=button value="<?=$m_clone_mac?>" onClick=javascript:setMac()>
	</td>
</tr>
<tr>
	<td colspan=2 align=right>
	<script language="JavaScript">apply("doSubmit()"); cancel("doReset()");help("help_home.php#02");</script>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
