<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz4_wan_manual.php";
$onload="onload='setMode()'";
require("/www/comm/genWizTop.php");
?>
<script>
connMode="<?query("/tmp/wiz/wan/rg/inf:1/mode");?>";
if(connMode=="")
connMode="<?query("/wan/rg/inf:1/mode");?>";
if (connMode=="") connMode==1;

function setMode()
{
	var f=document.getElementById("mwiz");

	switch (parseInt(connMode, [10]))
	{
	case 1:
		f.ConnType[1].checked=true;
		break;
	case 2:
		f.ConnType[0].checked=true;
		break;
	case 3:
		f.ConnType[2].checked=true;
		break;
	case 4:
		f.ConnType[3].checked=true;
		break;
	case 5:
		f.ConnType[4].checked=true;
		break;
	case 7:
		f.ConnType[5].checked=true;
		break;
	}
}

function doNext()
{
	var str=new String("");
	var f=document.getElementById("mwiz");
	var k=0;
	for (var i=0;i < f.ConnType.length;i++)
	{
		if (eval("f.ConnType["+i+"].checked")) break;
	}

	switch (i)
	{
	case 0:
		str="h_wiz5_wan_dhcp.xgi";
		k=2;
		break;
	case 1:
		str="h_wiz5_wan_fixed.xgi";
		k=1;
		break;
	case 2:
		str="h_wiz5_wan_pppoe.xgi";
		k=3;
		break;
	case 3:
		str="h_wiz5_wan_pptp.xgi";
		k=4;
		break;
	case 4:
		str="h_wiz5_wan_l2tp.xgi";
		k=5;
		break;
	case 5:
		str="h_wiz5_wan_bigpond.xgi";
		k=7;
		break;
	}
	if (str.length==0) return;
	str+="?set/tmp/wiz/wan/rg/inf:1/mode="+k;
	self.location.href=str;
}
</script>

<form method=post id=mwiz name=mwiz>
<?=$table?>
<tr><td height=2 colspan=2><?=$top_pic?></td>
</tr>
<tr><td height=10 colspan=2 class=title_wiz><?=$m_title?></td></tr>
<tr valign=top>
	<td width=95% height=25 colspan=2 class=l_wiz><?=$m_title_desc?></td>
</tr>
<tr>
	<td height=170>
	<table>
	<tr>
		<td width=35% height=25 class=l_wiz><input type=radio name=ConnType value=0><?=$m_dynamic_ip_addr?></td>
		<td width=55%height=25 class=l_wiz><?=$m_dynamic_ip_addr_desc?></td>
	</tr>
	<tr>
		<td height=25  class=l_wiz><input type=radio name=ConnType value=1><?=$m_static_ip_addr?></td>
		<td height=25 class=l_wiz><?=$m_static_ip_addr_desc?></td>
	</tr>
	<tr>
		<td height=25 class=l_wiz><input type=radio name=ConnType value=2><?=$m_pppoe?></td>
		<td height=25 class=l_wiz><?=$m_pppoe_desc?></td>
	</tr>
	<tr>
		<td height=25 class=l_wiz><input type=radio name=ConnType value=3><?=$m_pptp?></td>
		<td height=25 class=l_wiz><?=$m_pptp_desc?></td>
	</tr>
	<tr>
		<td height=25 class=l_wiz><input type=radio name=ConnType value=3><?=$m_l2tp?></td>
		<td height=25 class=l_wiz><?=$m_l2tp_desc?></td>
	</tr>
	<tr>
		<td height=25 class=l_wiz><input type=radio name=ConnType value=3><?=$m_bigpond?></td>
		<td height=25 class=l_wiz><?=$m_bigpond_desc?></td>
	</tr>
	</table>
	</td>
</tr>
<tr>
	<td height=10 align=right colspan=2 valign=bottom>
	<script language="JavaScript">back("h_wiz3_timezone.php");next("");exit();</script>
	</td>
</tr>
</table>
</form>
</body>
</html>
