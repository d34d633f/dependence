<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz5_wan_dhcp.php";
$onload="onload='setDynamic()'";
require("/www/comm/genWizTop.php");
?>
<script>

host="<?queryjs("/tmp/wiz/sys/hostName");?>";
if (host=="")
{
	host="<?queryjs("/sys/hostName");?>";
	mac="<?query("/wan/rg/inf:1/dhcp/clonemac");?>";
}
else
	mac="<?query("/tmp/wiz/wan/rg/inf:1/dhcp/clonemac");?>";
var myMac=getMAC(mac);
browserMac="<?=$macaddr?>";
var myBrowserMac=getMAC(browserMac);

function setMac()
{
	var f=document.getElementById("wiz1");
	f.mac1.value=myBrowserMac[1];
	f.mac2.value=myBrowserMac[2];
	f.mac3.value=myBrowserMac[3];
	f.mac4.value=myBrowserMac[4];
	f.mac5.value=myBrowserMac[5];
	f.mac6.value=myBrowserMac[6];
}

function setDynamic()
{
	var f=document.getElementById("wiz1");
	f.host.value=host;
	f.mac1.value=myMac[1];
	f.mac2.value=myMac[2];
	f.mac3.value=myMac[3];
	f.mac4.value=myMac[4];
	f.mac5.value=myMac[5];
	f.mac6.value=myMac[6];
}

function doNext()
{
	var f=document.getElementById("wiz1");
	var str="h_wiz6_wlan1_cfg.xgi?";

	if (isBlank(f.host.value))
	{
		alert("<?=$a_host_name_is_blank?>");
		return;
	}
	// mac
	if (!isBlank(f.mac1.value))
	{
		for (i=1; i < 7;i++)
		{
			var mac=eval("f.mac"+i);
			var strlen=2-mac.value.length;
			mac.value=mac.value.toUpperCase();
			for(j=0; j<strlen; j++)
				mac.value="0"+mac.value;

			if (!checkMAC(mac.value))
			{
				alert("<?=$a_mac_addr_is_invalid_formated?>\n");
				return;
			}
		}
	}
	if(!chk_valid_char(f.host.value))
	{
		alert("<?=$a_invalid_hostname?>");
		f.host.select();
		return;
	}
	str+="&set/tmp/wiz/sys/hostname="+escape(f.host.value);
	str+="&set/tmp/wiz/wan/rg/inf:1/mode=2";
	if (!isBlank(f.mac1.value))
	{
		mac=f.mac1.value+":"+f.mac2.value+":"+f.mac3.value+":"+f.mac4.value+":"+f.mac5.value+":"+f.mac6.value;
		str+="&set/tmp/wiz/wan/rg/inf:1/dhcp/CLONEMAC="+(mac==":::::"?"":mac);
	}
	self.location.href=str;
}
function print_mac(n)
{
	str="";
	for(var i=1;i<7;i++)
	{
		str+="<input type=text name="+n+i+" size=1 maxlength=2>";
		if(i!=6) str+=":";
	}
	document.write(str);
}
</script>
<form method=post id="wiz1">
<?=$table?>
<tr><td height=11><?=$top_pic?></td></tr>
<tr>
	<td height=10 width=95% class=title_wiz><?=$m_title?></td>
</tr>
<tr>
	<td height=180 valign=top>
	<table border=0 width=100% height="<?=$height_wiz?>" cellpadding=0>
	<tr>
		<td colspan=2 align=center>
		<table width=91% border=0 cellspacing=0 cellpadding=0 height=39 align=center>
		<tr>
			<td class=l_wiz><?=$m_title_desc?></td>
		</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td width=20% class=r_wiz><?=$m_host_name?></td>
		<td width=80%><input type=text name=host size=40 maxlength=39></td>
	</tr>
	<tr>
		<td valign=middle class=r_wiz><?=$m_mac?></td>
		<td width=374><script>print_mac("mac");</script>(<?=$m_optional?>)</td>
	</tr>
	<tr>
		<td></td>
		<td><input type=button value="<?=$m_clone_mac_addr?>" name=clone onclick="setMac()"></td>
	</tr>
	</table>
	</td>
</tr>
<tr align=right valign=bottom>
	<td height=80>
	<script language="JavaScript">back("h_wiz4_wan_manual.xgi?/set/tmp/wiz/wan/rg/inf:1/mode=4");next("");exit();</script>
	</td>
</tr>
</table>
</form>
</body>
</html>
