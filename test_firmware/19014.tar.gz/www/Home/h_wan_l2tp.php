<?
/* vi: set sw=4 ts=4: */
$file_name="h_wan_l2tp.php";
$apply_name="h_wan_l2tp.xgi?";
// radio mode: 1:static, 2:dhcp, 3:pppoe, 4:pptp, 5:l2tp
$radio="5";

$MSG_FILE="h_wan.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
?>
<script language="JavaScript">

function check()
{
	var f=document.getElementById("wan_form");

	if(!checkIpAddr(f.server_ip, "<?=$a_invalid_svraddr?>"))	return false;

	if (f.fixIP[1].checked)
	{
		if (ck_pptp_l2tp(f.ip, f.mask, f.gateway, f.dns, f.server_ip)==false) return false;
	}
	else
	{
		if (f.server_ip.value == "")
		{
			alert("<?=$a_server_cant_be_empty?>");
			f.server_ip.focus();
			return false;
		}
	}

	// l2tp account
	if (isBlank(f.l2tpuserid.value))
	{
		alert( "<?=$a_l2tpacc_cant_be_empty?>");
		return false;
	}

	if (f.l2tppwd.value!=f.l2tppwd2.value)
	{
		alert( "<?=$a_l2tp_password_mismatch?>");
		return false;
	}

	if(CheckUCS2(f.l2tpuserid.value))
	{
		alert("<?=$a_username_ascii_only?>");
		f.l2tpuserid.focus();
		return false;
	}
	if(CheckUCS2(f.l2tppwd.value))
	{
		alert("<?=$a_passwd_ascii_only?>");
		f.l2tppwd.focus();
		return false;
	}

	//MTU
	if(!ck_mtu(f,200,1400))	return false;

	//Max idle time
	if(!ck_idle(f))	return false;

	return true;
}
function doSubmit()
{
	var f=document.getElementById("wan_form");
	var str=new String("<?=$apply_name?>");
	var l2tpmode, ondemand, auto;

	if(check()==false) return;

	if (f.fixIP[0].checked)	l2tpmode=2;
	else					l2tpmode=1;

	str+="set/wan/rg/inf:1/MODE=5";
	str+="&set/wan/rg/inf:1/l2tp/MODE="+l2tpmode;
	if (l2tpmode==1)
	{
		str+="&set/wan/rg/inf:1/l2tp/ip="+reduceIP(f.ip.value);
		str+="&set/wan/rg/inf:1/l2tp/netmask="+reduceIP(f.mask.value);
		str+="&set/wan/rg/inf:1/l2tp/gateway="+reduceIP(f.gateway.value);
		str+="&set/wan/rg/inf:1/l2tp/dns="+reduceIP(f.dns.value);
	}
	str+="&set/wan/rg/inf:1/l2tp/SERVERIP="+escape(f.server_ip.value);
	str+="&set/wan/rg/inf:1/l2tp/USER="+escape(f.l2tpuserid.value);
	if ( f.l2tppwd.value != "WDB8WvbXdHtZyM8Ms2RENgHlacJghQy")
		str+="&set/wan/rg/inf:1/l2tp/PASSWORD="+escape(f.l2tppwd.value);
	str+="&set/wan/rg/inf:1/l2tp/MTU="+f.mtu.value;
	str+="&set/wan/rg/inf:1/l2tp/IDLETIMEOUT="+parseInt(f.idle.value, [10])*60;

	if		(f.cod[0].checked)	{ ondemand=0; auto=1; }
	else if	(f.cod[1].checked)	{ ondemand=0; auto=0; }
	else						{ ondemand=1; auto=1; }
	str+="&set/wan/rg/inf:1/l2tp/ondemand="+ondemand;
	str+="&set/wan/rg/inf:1/l2tp/autoreconnect="+auto;

	str+=exeStr("submit COMMIT;submit WAN");
	self.location.href=str;
}
function clickL2TP()
{
	var f = document.getElementById("wan_form");
	var b;
	if (f.fixIP[0].checked)	b = true;
	else					b = false;
	f.ip.disabled = f.mask.disabled = f.gateway.disabled = f.dns.disabled = b;
}
</script>
<?require("/www/Home/h_wan_comm.php");?>
<table width="<?=$width_tb?>">
<tr>
	<td colspan=2 height=30 class=title_tb><?=$m_l2tp_client?></td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td class=l_tb>
	<input type=radio value=0 name=fixIP onClick=clickL2TP()><?=$m_dynamic_ip?>
	<input type=radio value=1 name=fixIP onClick=clickL2TP()><?=$m_static_ip?>
	</td>
</tr>
<tr>
	<td class=l_tb><?=$m_ip_addr?></td>
	<td>
		<input type=text name=ip size=16 maxlength=15
			onblur=changeAddress(0,0,event.keyCode,this,document.wan_form.mask)
			onkeydown=changeAddress(1,13,event.keyCode,this,document.wan_form.mask)>
	</td>
</tr>
<tr>
	<td class=l_tb><?=$m_subnet?></td>
	<td><input type=text name=mask size=16 maxlength=15></td>
</tr>
<tr>
	<td class=l_tb><?=$m_gateway?></td>
	<td><input type=text name=gateway size=16 maxlength=15></td>
</tr>
<tr>
	<td class=l_tb><?=$m_dns?></td>
	<td><input type=text name=dns size=16 maxlength=15></td>
</tr>
<tr>
	<td class=l_tb><?=$m_server_ip?></td>
	<td><input type=text name=server_ip size=16 maxlength=15></td>
</tr>
<tr>
	<td class=l_tb><?=$m_l2tp_account?></td>
	<td><input type=text name=l2tpuserid size=32 maxlength=63></td>
</tr>
<tr>
	<td class=l_tb><?=$m_l2tp_passwd?></td>
	<td><input type=password name=l2tppwd size=32 maxlength=31></td>
</tr>
<tr>
	<td class=l_tb><?=$m_l2tp_retype_passwd?></td>
	<td><input type=password name=l2tppwd2 size=32 maxlength=31></td>
</tr>
<tr>
	<td class=l_tb><?=$m_max_idle_time?></td>
	<td class=l_tb><input type=text name=idle size=4> <?=$m_minutes?></td>
</tr>
<tr>
	<td class=l_tb><?=$m_mtu?></td>
	<td><input type=text name=mtu maxlength=4 size=5></td>
</tr>
<tr>
	<td class=l_tb><?=$m_connection_mode?></td>
	<td class=l_tb>
	<input type=radio name=cod value=0 onclick=on_change_connect_mode(0)><?=$m_always_on?>
	<input type=radio name=cod value=1 onclick=on_change_connect_mode(1)><?=$m_manual?>
	<input type=radio name=cod value=2 onclick=on_change_connect_mode(2)><?=$m_on_demand?>
	</td>
</tr>
<tr>
	<td colspan=2 align=right>
	<script language="JavaScript">apply("doSubmit()"); cancel("doReset()");help("help_home.php#02");</script>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
