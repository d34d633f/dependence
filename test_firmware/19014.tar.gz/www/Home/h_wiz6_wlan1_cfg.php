<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz6_wlan1_cfg.php";

$onload="onload='SetChannel()'";
require("/www/comm/genWizTop.php");
?>
<script>
ssid="<?queryjs("/tmp/wiz/wireless/ssid");?>";
country=parseInt("<?query("/wireless/country");?>", [10]);
if(ssid=="")
{
	ssid="<?queryjs("/wireless/ssid");?>";
	channel=parseInt("<?query("/wireless/channel");?>", [10]);
}
else
{
	channel=parseInt("<?query("/tmp/wiz/wireless/channel");?>", [10]);
}
if (ssid=="") ssid="<?query("/sys/modelname");?>";
if (country=="") channel=0;
if (channel=="") channel=1;

cLists=["fcc","etsi","spain","france","mkk","israel"];
cChannels=[
	["0","1","2","3","4","5","6","7","8","9","10","11"],
	["0","1","2","3","4","5","6","7","8","9","10","11","12","13"],
	["0","10","11"],
	["0","10","11","12","13"],
	["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14"],
	["0","3","4","5","6","7","8","9"],
	];

function SetChannel()
{
	var f=document.getElementById("wiz1");
	var ie = isIE();
	var c=0,s=0;

	f.essid.value=ssid;

	for (var i=0;i < cLists.length;i++)
	{
		if (parseInt(country, [10])==cLists[i])
		{
			c=i;
			break;
		}
	}

	for(i=1; i < cChannels[c].length; i++)
	{
		var opt = document.createElement("option");
		opt.text = cChannels[c][i];
		opt.value = cChannels[c][i];
		if (cChannels[c][i] ==channel) s=i-1;
		if (ie)	f.channel.options.add(opt);
		else	f.channel.appendChild(opt);
	}
	f.channel.selectedIndex = s;
}
function doNext()
{
	var f=document.getElementById("wiz1");
	var str="h_wiz6_wlan2_sec.xgi?";

	// mac
	if (isBlank(f.essid.value))
	{
		alert("<?=$a_ssid_can_not_be_blank?>");
		return;
	}
	if(CheckUCS2(f.essid.value))
	{
		alert("<?=$a_ssid_only_allow_ascii_code?>");
		return;
	}
							

	str+="set/tmp/wiz/wireless/SSID="+escape(f.essid.value);
	str+="&set/tmp/wiz/wireless/CHANNEL="+parseInt(f.channel.selectedIndex+1, [10]);
	str+="&set/tmp/wiz/wireless/autoChannel=0";
	self.location.href=str;
}

</script>
<form method="post" id="wiz1">
<?=$table?>
<tr><td height="11"><?=$top_pic?></td></tr>
<tr><td height="10" class=title_wiz><?=$m_title?></td></tr>
<tr>
	<td height="200" valign=top>
	<table border="0" width=95%>
	<tr>
		<td height="50" colspan="2">
		<table width=100% border="0" cellspacing="0" cellpadding="0" align="center">
		<tr>
			<td class=l_wiz><?=$m_title_desc?></td>
		</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td width=35% height="10" class=r_wiz><?=$m_ssid?>&nbsp;</td>
		<td width=65% height="10"><input type="text" name="essid" size="20" maxlength="32"></td>
	</tr>
	<tr>
		<td height="10" class=r_wiz><?=$m_channel?>&nbsp;</td>
		<td height="10"><select name="channel"></select></td>
	</tr>
	</table>
	</td>
</tr>
<tr valign=bottom>
	<td align="right">
	<script language="JavaScript">back("h_wiz4_wan_manual.php");next("");exit();</script>
	</td>
</tr>
</table>
</form>
</body>
</html>
