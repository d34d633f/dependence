<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz6_wlan2_sec.php";
$onload="onload='setWEP()'";
require("/www/comm/genWizTop.php");
?>
<script>
encryption="<?query("/tmp/wiz/wireless/keyLength");?>";
if(encryption=="")
{
	wep="<?query("/wireless/wpa/wepMode");?>";
	encryption="<?query("/wireless/keyLength");?>";
	defkey="<?query("/wireless/defkey");?>";
	key1="<?queryjs("/wireless/wepKey:1");?>";
	key2="<?queryjs("/wireless/wepKey:2");?>";
	key3="<?queryjs("/wireless/wepKey:3");?>";
	key4="<?queryjs("/wireless/wepKey:4");?>";
}
else
{
	wep="<?query("/tmp/wiz/wireless/wpa/wepMode");?>";
	defkey="<?query("/tmp/wiz/wireless/defkey");?>";
	key1="<?queryjs("/tmp/wiz/wireless/wepKey:1");?>";
	key2="<?queryjs("/tmp/wiz/wireless/wepKey:2");?>";
	key3="<?queryjs("/tmp/wiz/wireless/wepKey:3");?>";
	key4="<?queryjs("/tmp/wiz/wireless/wepKey:4");?>";
}
var key_length;
if (wep!="0") wep="1";
if (encryption=="")		encryption=64;
if (encryption=="64")		key_length=10;
else				key_length=26;
if (defkey=="")			defkey=1;

function validateWepKey(keyField, len)
{
	if (keyField.value.length != len)
	{
		alert(<?=$a_invalid_key_length?>);
		keyField.value = "";
		keyField.focus();
		return 0;
	}
	for (var i=0; i<keyField.value.length; i++)
	{
		if ((keyField.value.charAt(i) >= '0' && keyField.value.charAt(i) <= '9') ||
		    (keyField.value.charAt(i) >= 'a' && keyField.value.charAt(i) <= 'f') ||
		    (keyField.value.charAt(i) >= 'A' && keyField.value.charAt(i) <= 'F'))
			continue;
		alert("<?=$a_invalid_key_value?>");
		keyField.value = "";
		keyField.focus();
		return 0;
	}
	return 1;
}

function setWEP()
{
	var f=document.getElementById("wiz1");

	f.wep[0].checked=(wep=="1");	// enabled
	f.wep[1].checked=(wep!="1");	// disabled

	f.keyLen.value=encryption;
	var key_value;

	switch (parseInt(defkey, [10]))
	{
	case 1:
		key_value=key1;
		break;
	case 2:
		key_value=key2;
		break;
	case 3:
		key_value=key3;
		break;
	case 4:
		key_value=key4;
		break;
	}
	if (encryption == "64")
	{
		if(key_value == "" || key_value.length != key_length)	f.key.value="0000000000";
		else	f.key.value=key_value;
	}
	else
	{
		if(key_value == "" || key_value.length != key_length)	f.key.value="00000000000000000000000000";
		else	f.key.value=key_value;
	}
	f.key.maxLength=key_length;
}

function sendData(v,s)
{
	var f=document.getElementById("wiz1");
	str=new String("h_wiz6_wlan2_sec.xgi?");
	str+="setPath=/tmp/wiz/wireless/";
	str+="&"+s+"="+v[v.selectedIndex].value;
	str+="&AUTHENTICATION=0";
	str+="&keyFormat=2";
	str+="&defkey="+defkey;
	str+="&wpa/WEPMODE="+(f.wep[0].checked? "1":"0");
	str+="&WEPKEY:"+defkey+"="+escape(f.key.value);
	str+="&keylength="+f.keyLen.value;
	self.location.href=str;
}

function doNext()
{
	var f=document.getElementById("wiz1");
	var str="h_wiz7_saving.xgi?";
	if(!validateWepKey(f.key, key_length))	return;
	str+="setPath=/tmp/wiz/wireless/";
	str+="&keyLength="+f.keyLen.value;
	str+="&authentication=0";
	str+="&keyFormat=2";
	str+="&defkey="+defkey;
	str+="&wpa/WEPMODE="+(f.wep[0].checked? "1":"0");
	str+="&WEPKEY:"+defkey+"="+escape(f.key.value);
	str+="&endSetPath=1";
	self.location.href=str;
}

</script>

<form method="post" id="wiz1">
<?=$table?>
<tr><td height="11"><?=$top_pic?></td></tr>
<tr><td height="10" class=title_wiz><?=$m_title?></td></tr>
<tr>
	<td height="200">
	<table border="0" width=95% height="175" cellpadding="0">
	<tr>
		<td height="49" colspan="2">
		<table width=100% border="0" cellspacing="0" cellpadding="0" height="39" align="center">
	        <tr><td>
		<?=$m_title_desc?></td></tr>
		</table>
		</td>
	</tr>
	<tr>
		<td width=30% height="10" class=r_wiz><?=$m_wep?>&nbsp;</td>
		<td width=70% height="10" class=l_wiz><b>
		<input type="radio" name="wep" value="1"><?=$m_enabled?>
		<input type="radio" name="wep" value="0"><?=$m_disabled?></b>
		</td>
	</tr>
	<tr>
		<td height="10" class=r_wiz><?=$m_wep_encryption?>&nbsp;</td>
		<td height="10"><b>
		<select name="keyLen" onChange="sendData(this,'KEYLENGTH')">
		<option value="64"><?=$m_64bit?></option>
		<option value="128"><?=$m_128bit?></option>
		</select>
		</b></td>
	</tr>
	<tr>
		<td height="10" class=r_wiz><?=$m_key?>&nbsp;</td>
		<td height="10"><input type="text" name="key" size="40"></td>
	</tr>
	<tr>
		<td height="10">&nbsp;</td>
		<td height="10" class=l_wiz><?=$m_input_hex_chars?></td>
	</tr>
	<tr>
		<td colspan="2" height="20">&nbsp;</td>
	</tr>
	</table>
 	</td>
</tr>
<tr>
	<td align=right valign=bottom>
	<script language="JavaScript">back("h_wiz6_wlan1_cfg.php");next("");exit();</script>
	</td>
</tr>
</table>
</form>
</body>
</html>
