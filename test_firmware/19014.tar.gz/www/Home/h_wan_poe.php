<?
/* vi: set sw=4 ts=4: */
$file_name="h_wan_poe.php";
$apply_name="h_wan_poe.xgi?";
// radio mode: 1:static, 2:dhcp, 3:pppoe, 4:pptp, 5:l2tp
$radio="3";
$MSG_FILE="h_wan.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
?>
<script language="JavaScript">
/*
runtimeMAC="<?=$macaddr?>";
*/
function doReset()
{
	self.location.href="<?=$file_name?>";
}
function clickPOE()
{
	var f = document.getElementById("wan_form");
	var b;
	if (f.fixIP[0].checked)	b = true;
	else			b = false;
	f.ip.disabled = b;
	f.dns1.disabled = b;
	f.dns2.disabled = b;
}
function check()
{
	var f=document.getElementById("wan_form");
	// pppoe user name
	if (isBlank(f.name.value))
	{
		alert( "<?=$a_poe_uname_cant_be_empty?>");
		return false;
	}
	
	if(CheckUCS2(f.name.value))
	{
		alert("<?=$a_poe_uname_ascii_only?>");
		f.name.focus();
		return false;
	}
	
	if (f.pass.value!=f.pass_v.value)
	{
		alert( "<?=$a_poe_passwd_mismatch?>");
		return false;
	}
	
	if(CheckUCS2(f.pass.value))
	{
		alert("<?=$a_poe_passwd_ascii_only?>");
		f.pass.focus();
		return false;
	}
	
	if(CheckUCS2(f.ac_name.value))
	{
		alert("<?=$a_poe_acname_ascii_only?>"); 
		f.ac_name.focus();
		return false;
	}
	if(CheckUCS2(f.srv_name.value))
	{
		alert("<?=$a_poe_svcname_ascii_only?>"); 
		f.srv_name.focus();
		return false;
	}
	
	if (f.fixIP[1].checked)
	{
		// static PPPOE ip
		if (!checkIpAddr(f.ip, "<?=$a_invalid_ipaddr?>"))
		return false;
		
		// static PPPOE dns1
		if (!isBlank(f.dns1.value))	
		{
			if (!checkIpAddr(f.dns1, "<?=$a_invalid_dns1?>"))
			return false;
		}
		
		// static PPPOE dns2
		if (!isBlank(f.dns2.value))
		{
			if (!checkIpAddr(f.dns2, "<?=$a_invalid_dns2?>"))
			return false;
		}
	}
	// mac
	if(!ck_mac(f))	return false;
	
	//MTU
	if(!ck_mtu(f,200,1492))	return false;

	//Max idle time
	if(!ck_idle(f))	return false;

	return true;

}

function doSubmit()
{
	var f=document.getElementById("wan_form");
	var ondemand, auto;

	if(check()==false)	return;
	var str=new String("<?=$apply_name?>");
	str+="set/wan/rg/inf:1/MODE=3";
	str+="&set/wan/rg/inf:1/pppoe/MODE="+(f.fixIP[0].checked? "2":"1");
	str+="&set/wan/rg/inf:1/pppoe/user="+escape(f.name.value);
	if ( f.pass.value != "WDB8WvbXdHtZyM8Ms2RENgHlacJghQy")
		str+="&set/wan/rg/inf:1/pppoe/password="+escape(f.pass.value);
	str+="&set/wan/rg/inf:1/pppoe/acService="+escape(f.srv_name.value);
	str+="&set/wan/rg/inf:1/pppoe/ACNAME="+escape(f.ac_name.value);
	if (f.mac1.value != "")
		mac=f.mac1.value+":"+f.mac2.value+":"+f.mac3.value+":"+f.mac4.value+":"+f.mac5.value+":"+f.mac6.value;
	else
		mac = "";
	
	str+="&set/wan/rg/inf:1/pppoe/CLONEMAC="+mac;
	if (f.fixIP[1].checked)
	{
		str+="&set/wan/rg/inf:1/pppoe/mode=1";
		str+="&set/wan/rg/inf:1/pppoe/STATICIP="+reduceIP(f.ip.value);
		str+="&set/DnsRelay/server/PRIMARYDNS="+reduceIP(f.dns1.value);
		str+="&set/DnsRelay/server/SECONDARYDNS="+reduceIP(f.dns2.value);
		str+="&set/wan/rg/inf:1/pppoe/autoDns=0";
	}
	else
	{
		str+="&set/wan/rg/inf:1/pppoe/mode=2"
		str+="&set/wan/rg/inf:1/pppoe/autoDns=1";
	}
	
	str+="&set/wan/rg/inf:1/pppoe/MTU="+f.mtu.value;
	if	(f.cod[0].checked)	{ ondemand=0; auto=1; }
	else if	(f.cod[1].checked)	{ ondemand=0; auto=0; }
	else				{ ondemand=1; auto=1; }

	str+="&set/wan/rg/inf:1/pppoe/idleTimeout="+parseInt(f.idle.value, [10])*60;
	str+="&set/wan/rg/inf:1/pppoe/autoReconnect="+auto;
	str+="&set/wan/rg/inf:1/pppoe/onDemand="+ondemand;

	str+=exeStr("submit COMMIT;submit WAN");
	self.location.href=str;
}


</script>
<?require("/www/Home/h_wan_comm.php");?>
<table width="<?=$width_tb?>">
<tr>
	<td colspan=2 height=30 class=title_tb><font color=#8bacb1><b><?=$m_pppoe?></b></font></td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td class=l_tb>
	<input type=radio value=0 name=fixIP onClick=clickPOE()><?=$m_dynamic_pppoe?>
	<input type=radio value=1 name=fixIP onClick=clickPOE()><?=$m_static_pppoe?>
	</td>
</tr>
<tr>
	<td valign=top class=l_tb><?=$m_user?></td>
	<td valign=top><input type=text name=name size=30 maxlength=63></td>
</tr>
<tr>
	<td class=l_tb><?=$m_password?></td>
	<td><input type=password name=pass size=30 maxlength=63 value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQy"></td>
</tr>
<tr>
	<td class=l_tb><?=$m_retype_passwd?> </td>
	<td><input type=password name=pass_v size=30 maxlength=63 value="WDB8WvbXdHtZyM8Ms2RENgHlacJghQy"></td>
</tr>
<tr>
	<td class=l_tb><?=$m_ac_name?></td>
	<td class=l_tb><input type=text name=ac_name size=30 maxlength=63>(<?=$m_optional?>)</td>
</tr>
<tr>
	<td class=l_tb><?=$m_service_name?></td>
	<td class=l_tb><input type=text name=srv_name size=30 maxlength=63>(<?=$m_optional?>)</td>
</tr>
<tr>
	<td class=l_tb><?=$m_ip_addr?></td>
	<td><input type=text name=ip size=16 maxlength=15></td>
</tr>
<tr>
	<td valign=top class=l_tb><?=$m_mac_addr?></td>
	<td class=l_tb><script>print_mac();</script><br>
	<input type=button value="Clone MAC Address" onClick=javascript:setMac()>
	</td>
</tr>
<tr>
	<td class=l_tb><?=$m_primary_dns?></td>
	<td><input type=text name=dns1 size=16 maxlength=15></td>
</tr>
<tr>
	<td class=l_tb><?=$m_secordary_dns?></td>
	<td class=l_tb><input type=text name=dns2 size=16 maxlength=15>(<?=$m_optional?>)</td>
</tr>
<tr>
	<td class=l_tb><?=$m_max_idle_time?></td>
	<td class=l_tb><input type=text name=idle size=4><?=$m_minutes?></td>
</tr>
<tr>
	<td class=l_tb><?=$m_mtu?></td>
	<td><input type=text name=mtu maxlength=4 size=5></td>
</tr>
<tr>
	<td class=l_tb><?=$m_connection_mode?></td>
	<td class=l_tb>
	<input type=radio name=cod value=0 onclick=on_change_connect_mode(0)><?=$m_always_on?>
	<input type=radio name=cod value=1 onclick=on_change_connect_mode(1)><?=$m_manual?>
	<input type=radio name=cod value=2 onclick=on_change_connect_mode(2)><?=$m_on_demand?>
	</td>
</tr>
<tr>
	<td colspan=2 align=right>
	<script language="JavaScript">apply("doSubmit()"); cancel("doReset()");help("help_home.php#02");</script>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
