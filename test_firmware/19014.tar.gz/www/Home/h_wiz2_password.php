<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz2_password.php";
require("/www/comm/genWizTop.php");?>
<script>
function check()
{
	var f=document.getElementById("wiz1");
	if(CheckUCS2(f.pwd1.value))
	{
		alert("<?=$a_password_only_allow_ascii_code?>\n");
		f.pw1.focus();
		return false;
	}
	if (f.pwd1.value!=f.pwd2.value)
	{
		alert("<?=$a_password_not_match?>\n");
		return false;
	}
	return true;
}
function doNext()
{
	var f=document.getElementById("wiz1");
	if(check()==false) return;

	str="h_wiz3_timezone.xgi?set/tmp/wiz/sys/user:1/password="+escape(f.pwd1.value);
	self.location.href=str;
}
</script>

<form method=post id="wiz1">
<?=$table?>
<tr><td height=33><?=$top_pic?></td></tr>
<tr>
	<td height=10 width=100% height=10 valign=bottom class=title_wiz><?=$m_title?></td>
</tr>
<tr>
	<td width=95% class=c_wiz><?=$m_title_desc?></td>
</tr>
<tr>
	<td height=165 valign=top>
	<table border=0 width=100% cellpadding=0>
	<tr><td height=20></td></tr>
	<tr>
		<td width=40% height=10 class=r_wiz><?=$m_password?>&nbsp;</td>
		<td width=60% height=10><input type=password name=pwd1 size=20 maxlength=15 value="<?=$DEF_PASSWORD?>"></td>
	</tr>
	<tr>
		<td height=10 class=r_wiz><?=$m_confirm_password?>&nbsp;</td>
		<td height=10><input type=password name=pwd2 size=20 maxlength=15 value="<?=$DEF_PASSWORD?>"></td>
	</tr>
	</table>
	</td>
</tr>
<tr align=right valign=bottom>
	<td height=10>
	<script language="JavaScript">back("h_wiz1_flowchart.php");next("");exit();</script>
	</td>
</tr>
</table>
</form>
</body>
</html>
