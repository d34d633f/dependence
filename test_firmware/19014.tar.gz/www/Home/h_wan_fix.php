<?
$file_name="h_wan_fix.php";
$apply_name="h_wan_fix.xgi?";
// radio mode: 1:static, 2:dhcp, 3:pppoe, 4:pptp, 5:l2tp
$radio="1";

$MSG_FILE="h_wan.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
?>

<script language="JavaScript">
/*
runtimeMAC="<?=$macaddr?>";
*/
function check()
{
	var f=document.getElementById("wan_form");
	// IP Address
	if (!checkIpAddr(f.ip, "<?=$a_invalid_ipaddr?>")) return false;

	// Subnet Mask
	if (!validMask(f.mask, "<?=$a_invalid_netmask?>")) return false;

	if(!checkMaskAddr(f.ip, f.mask.value, '<?=$a_invalid_ipaddr?>')) return false;

	// ISP Gateway Address
	if (!checkIpAddr(f.gateway, "<?=$a_invalid_gwaddr?>")) return false;

	if(!checkMaskAddr(f.gateway, f.mask.value, '<?=$a_invalid_gwaddr?>')) return false;

	if(!checkSubnet(f.ip.value, f.mask.value, f.gateway.value))
	{
		alert('<?=$invalid_gwaddr?>!\n<?=$a_should_be_in_same_subnet?>');
		f.gateway.value = f.gateway.defaultValue;
		f.gateway.focus();
		return false;
	}

	// static dns1
	if(isBlank(f.dns1.value)) { alert("<?=$a_invalid_dns1?>"); return false; }

	if (!checkIpAddr(f.dns1, "<?=$a_invalid_dns1?>")) return false;

	// static dns2
	if (!ck_dns2(f)) return false;

	// mac
	if (!ck_mac(f)) return false;

	//MTU
	if(!ck_mtu(f, 200,1500)) return false;

	return true;
}
function doSubmit()
{
	var f=document.getElementById("wan_form");
	if(check()==false) return;
	var str=new String("<?=$apply_name?>");
	str+="set/wan/rg/inf:1/MODE=1";
	str+="&set/wan/rg/inf:1/static/IP="+reduceIP(f.ip.value);
	str+="&set/wan/rg/inf:1/static/NETMASK="+reduceIP(f.mask.value);
	str+="&set/wan/rg/inf:1/static/GATEWAY="+reduceIP(f.gateway.value);
	if (f.mac1.value != "")
		mac=f.mac1.value+":"+f.mac2.value+":"+f.mac3.value+":"+f.mac4.value+":"+f.mac5.value+":"+f.mac6.value;
	else
		mac = "";
	str+="&set/wan/rg/inf:1/static/CLONEMAC="+mac;
	str+="&set/DnsRelay/server/PRIMARYDNS="+reduceIP(f.dns1.value);
	str+="&set/DnsRelay/server/SECONDARYDNS="+reduceIP(f.dns2.value);
	str+="&set/wan/rg/inf:1/static/MTU="+f.mtu.value;
	str+=exeStr("submit COMMIT;submit WAN");
	self.location.href=str;
}
</script>
<?require("/www/Home/h_wan_comm.php");?>
<table width="<?=$width_tb?>">
<tr>
	<td colspan=2 height=30 class=title_tb><?=$m_static_ip?></td>
</tr>
<tr>
	<td class=l_tb><?=$m_ip_addr?></td>
	<td class=l_tb><input type=text name=ip size=16 maxlength=15 onblur=changeAddress(0,0,event.keyCode,this,document.wan_form.mask) onkeydown=changeAddress(1,13,event.keyCode,this,document.wan_form.mask)><?=$m_assigned_by_isp?></td>
</tr>
<tr>
	<td valign=top class=l_tb><?=$m_subnet?></td>
	<td><input type=text name=mask size=16 maxlength=15></td>
</tr>
<tr>
	<td class=l_tb><?=$m_isp_gateway?></td>
	<td><input type=text name=gateway size=16 maxlength=15></td>
</tr>
<tr>
	<td valign=top class=l_tb><?=$m_mac_addr?></td>
	<td>
	<script>print_mac();</script><br>
	<input type=button value="<?=$m_clone_mac?>" onClick=javascript:setMac()>
	</td>
</tr>
<tr>
	<td class=l_tb><?=$m_primary_dns?></td>
	<td><input type=text name=dns1 size=16 maxlength=15></td>
</tr>
<tr>
	<td class=l_tb><?=$m_secondary_dns?></td>
	<td class=l_tb><input type=text name=dns2 size=16 maxlength=15>(<?=$m_optional?>)</td>
</tr>
<tr>
	<td class=l_tb><?=$m_mtu?></td>
	<td><input type=text name=mtu maxlength=4 size=5></td>
</tr>
<tr>
	<td colspan=2 align=right>
	<script language="JavaScript">apply("doSubmit()"); cancel("doReset()");help("help_home.php#02");</script>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
