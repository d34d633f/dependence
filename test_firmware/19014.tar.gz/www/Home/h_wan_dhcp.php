<?
$file_name="h_wan_dhcp.php";
$apply_name="h_wan_dhcp.xgi?";
// radio mode: 1:static, 2:dhcp, 3:pppoe, 4:pptp, 5:l2tp
$radio="2";

$MSG_FILE="h_wan.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
?>
<script>
/*runtimeMAC="<?=$macaddr?>";*/
function check()
{
	// hostname
	if (isBlank(f.host.value))
	{
		alert("<?=$a_hostname_cant_be_empty?>\n");
		return false;
	}
	if(!chk_valid_char(f.host.value))
	{
		alert("<?=$a_invalid_hostname?>");
		f.host.select();
		return false;
	}
	// dynamic dns1
	if (!isBlank(f.dns1.value))
		if (!checkIpAddr(f.dns1, "<?=$a_invalid_dns1?>")) return false;
	// dynamic dns2
	if (!ck_dns2(f)) return false;
	// mac
	if(!ck_mac(f)) return false;
	//MTU
	if(!ck_mtu(f,200,1500)) return false;
	return true;
}
function doSubmit()
{
	f=document.getElementById("wan_form");
	if(check()==false)	return;
	var str=new String("<?=$apply_name?>");
	str+="set/wan/rg/inf:1/MODE=2";
	str+="&set/sys/hostname="+escape(f.host.value);
	mac=f.mac1.value+":"+f.mac2.value+":"+f.mac3.value+":"+f.mac4.value+":"+f.mac5.value+":"+f.mac6.value;
	str+="&set/wan/rg/inf:1/dhcp/CLONEMAC="+(mac==":::::"?"":mac);
	str+="&set/DnsRelay/server/PRIMARYDNS="+reduceIP(f.dns1.value);
	str+="&set/DnsRelay/server/SECONDARYDNS="+reduceIP(f.dns2.value);
	str+="&set/wan/rg/inf:1/dhcp/MTU="+f.mtu.value;
	str+=exeStr("submit COMMIT;submit WAN;submit SYSLOG");
	self.location.href=str;
}
</script>
<?require("/www/Home/h_wan_comm.php");?>
<table width=<?=$width_tb?>>
<tr>
	<td colspan=2 height=30 class=title_tb><?=$m_dynamic_ip?></td>
</tr>
<tr>
	<td class=l_tb width=160><?=$m_host_name?></td>
	<td width=440>
	<!--input type=text name=host size=40 maxlength=39 onkeypress="return char_filter(event);" onFocus="this.select();"-->
	<input type=text name=host size=40 maxlength=39>
	</td>
</tr>
<tr>
	<td valign=top class=l_tb><?=$m_mac_addr?></td>
	<td class=l_tb>
	<script>print_mac();</script><br>
	<input type=button value="<?=$m_clone_mac?>" onClick=javascript:setMac()>
	</td>
</tr>
<tr>
	<td height="29" class=l_tb><?=$m_primary_dns?></td>
	<td height="29" class=l_tb><input type=text name=dns1 size=16 maxlength=15><?=$optional?></td>
</tr>
<tr>
	<td class=l_tb><?=$m_secondary_dns?></td>
	<td class=l_tb><input type=text name=dns2 size=16 maxlength=15>(<?=$m_optional?>)</td>
</tr>
<tr>
	<td class=l_tb><?=$m_mtu?></td>
	<td><input type=text name=mtu maxlength=4 size=5></td>
</tr>
<tr>
	<td colspan=2 align=right>
	<script language="JavaScript">apply("doSubmit()"); cancel("doReset()");help("help_home.php#02");</script>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
