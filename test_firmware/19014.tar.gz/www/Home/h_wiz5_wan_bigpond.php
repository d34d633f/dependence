<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz5_wan_bigpond.php";
$onload="onload='setBigpond()'";
require("/www/comm/genWizTop.php");
?>
<script>
userName="<?query("/tmp/wiz/wan/rg/inf:1/bigpond/username");?>";
if(userName=="")
{
	userName="<?query("/wan/rg/inf:1/bigpond/user");?>";
	userPassword="<?query("/wan/rg/inf:1/bigpond/password");?>";
	AuthServer="<?query("/wan/rg/inf:1/bigpond/server");?>";
	if(AuthServer=="") AuthServer="sm-server";
}
else
{
	userPassword="<?query("/tmp/wiz/wan/rg/inf:1/bigpond/password");?>";
	AuthServer="<?query("/tmp/wiz/wan/rg/inf:1/bigpond/server");?>";
}

function setBigpond()
{
	var f=document.getElementById("wiz1");
	f.name.value=userName;
//	f.pass1.value=userPassword;
//	f.pass2.value=userPassword;
	f.authserver.value=AuthServer;
}

function doNext()
{
	var f=document.getElementById("wiz1");
	var str="h_wiz6_wlan1_cfg.xgi?";

	if (isBlank(f.name.value))
	{
		alert( "<?=$a_user_name_is_blank?>\n");
		return;
	}

	if (f.pass1.value!=f.pass2.value)
	{
		alert( "<?=$a_password_not_matched?>\n");
		return;
	}
	if(CheckUCS2(f.name.value))
	{
		alert("<?=$a_user_name_only_allow_ascii_code?>");
		return;
	}
	if(CheckUCS2(f.pass1.value))
	{
		alert("<?=$a_password_only_allow_ascii_code?>");
		return;
	}

	str+="set/tmp/wiz/wan/rg/inf:1/mode=7";
	str+="&set/tmp/wiz/wan/rg/inf:1/bigpond/username="+f.name.value;
	str+="&set/tmp/wiz/wan/rg/inf:1/bigpond/password="+f.pass1.value;
	str+="&set/tmp/wiz/wan/rg/inf:1/bigpond/server="+f.authserver.value;
	self.location.href=str;
}
</script>
<form method=post id="wiz1">
<?=$table?>
<tr><td height=11><?=$top_pic?></td></tr>
<tr><td height=10 class=title_wiz><?=$m_title?></td></tr>
<tr>
	<td height=200 valign=top>
	<table border=0 width=95% cellpadding=0 height=135>
	<tr>
		<td height=20 colspan=2><?=$m_title_desc?></td>
	</tr>
	<tr>
		<td width=43% height=20 class=r_wiz><?=$m_user_name?></td>
		<td width=57% height=20><input type=text name=name size=30 maxlength=63 value=""></td>
	</tr>
	<tr>
		<td height=20 class=r_wiz><?=$m_password?></div></td>
		<td height=20><input type=password name=pass1 size=30 maxlength=63 value="<?=$DEF_PASSWORD?>"></td>
	</tr>
	<tr>
		<td height=20 class=r_wiz><?=$m_retype_password?></td>
		<td height=20><input type=password name=pass2 size=30 maxlength=63 value="<?=$DEF_PASSWORD?>"></td>
	</tr>
	<tr>
		<td height=20 class=r_wiz><?=$m_auth_server?></td>
		<td height=20 nowrap>
			<select name=authserver>
				<option value="sm-server">sm-server</option>
				<option value="dce-server">dce-server</option>
			</select>
		</td>
	</tr>
	</table>
	</td>
</tr>
<tr>
	<td align=right valign=bottom>
	<script language="JavaScript">back("h_wiz4_wan_manual.xgi?set/tmp/wiz/wan/rg/inf:1/mode=7");next("");exit();</script>
	</td>
</tr>
</table>
</form>
</body>
</html>
