<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wiz7_saving.php";
require("/www/comm/genWizTop.php");?>
<script>
function doSubmit()
{
	var str=new String("h_wiz8_finish.xgi?");
//	var str=new String("/Home/restart.xgi?Secs=120&");

	// admin password	(h_wiz2_password.php)
	admin_passwd="<?queryjs("/tmp/wiz/sys/user:1/password");?>";
	if(admin_passwd!="<?=$DEF_PASSWORD?>")
	{
		str+="set/sys/user:1/password="+escape(admin_passwd);
	}
	// timezone		(h_wiz3_timezone.php)
	str+="&set/time/timezone=<?query("/tmp/wiz/time/timezone");?>";
	// Wan ConnMode		(h_wiz4_wan_manual.php)
	connMode="<?query("/tmp/wiz/wan/rg/inf:1/mode");?>"
	str+="&set/wan/rg/inf:1/mode="+connMode;
	switch (connMode)
	{
	// Static		(h_wiz5_wan_fixed.php)
	case "1":
		str+="&setPath=/wan/rg/inf:1/static/";
		<?anchor("/tmp/wiz/wan/rg/inf:1/static");?>
		str+="&IP=<?query("ip");?>";
		str+="&NETMASK=<?query("netmask");?>";
		str+="&GATEWAY=<?query("gateway");?>";
		str+="&endSetPath=1";
		str+="&setPath=/DnsRelay/server/";
		str+="&PRIMARYDNS=<?queryjs("/tmp/wiz/dnsrelay/server/primarydns");?>";
		secDns="<?queryjs("/tmp/wiz/dnsrelay/server/secondarydns");?>";
		if (secDns!="")	str+="&SECONDARYDNS="+secDns;
		str+="&endSetPath=1";
		break;

   	// DHCP			(h_wiz5_wan_dhcp.php)
	case "2":
		str+="&set/sys/hostname="+escape("<?queryjs("/tmp/wiz/sys/hostName");?>");
		clonemac="<?query("/tmp/wiz/wan/rg/inf:1/dhcp/clonemac");?>";
		if(clonemac!="")	str+="&set/wan/rg/inf:1/dhcp/CLONEMAC="+clonemac;
		break;

	// PPPOE		(h_wiz5_wan_pppoe.php)
	case "3":
		<?anchor("/tmp/wiz/wan/rg/inf:1/pppoe");?>
		str+="&set/wan/rg/inf:1/pppoe/mode=2";
		str+="&set/wan/rg/inf:1/pppoe/user=<?queryjs("user");?>";
		passwd=escape("<?queryjs("password");?>");
		if(passwd!="<?=$DEF_PASSWORD?>")		str+="&set/wan/rg/inf:1/pppoe/password="+passwd;
/*		str+="&set/wan/rg/inf:1/pppoe/IDLETIMEOUT=0";
		str+="&set/wan/rg/inf:1/pppoe/onDemand=0";
*/		acName="<?queryjs("acService");?>";
		if(acName!="")	str+="&set/wan/rg/inf:1/pppoe/acService="+escape(acName);
		break;

	// pptp			(h_wiz5_wan_pptp.php)
	case "4":
		<?anchor("/tmp/wiz/wan/rg/inf:1/pptp");?>
		str+="&setPath=/wan/rg/inf:1/pptp/";
		str+="&mode=1";
		str+="&IP=<?query("ip");?>";
		str+="&NETMASK=<?query("netmask");?>";
		str+="&gateway=<?query("gateway");?>";
		str+="&dns=<?query("dns");?>";
		str+="&SERVERIP=<?query("serverip");?>";
		str+="&USER="+escape("<?queryjs("user");?>");
		passwd=escape("<?queryjs("password");?>");
		if(passwd!="<?=$DEF_PASSWORD?>")	str+="&PASSWORD="+passwd;
//		str+="&IDLETIMEOUT=0&onDemand=0";
		str+="&endSetPath=1";
		//alert(str);
		break;
	// l2tp			(h_wiz5_wan_l2tp.php)
	case "5":	
		<?anchor("/tmp/wiz/wan/rg/inf:1/l2tp");?>	
		str+="&setPath=/wan/rg/inf:1/l2tp/";
		str+="&mode=1";
		str+="&IP=<?query("ip");?>";
		str+="&NETMASK=<?query("netmask");?>";
		str+="&gateway=<?query("gateway");?>";
		str+="&dns=<?query("dns");?>";
		str+="&SERVERIP=<?query("serverip");?>";
		str+="&USER="+escape("<?queryjs("user");?>");
		passwd=escape("<?queryjs("password");?>");
		if(passwd!="<?=$DEF_PASSWORD?>")	str+="&PASSWORD="+passwd;
//		str+="&IDLETIMEOUT=0&onDemand=0";
		str+="&endSetPath=1";
		break;
	// bigpond		(h_wiz5_wan_bigpond.php)
	case "7":
		<?anchor("/tmp/wiz/wan/rg/inf:1/bigpond");?>
		str+="&set/wan/rg/inf:1/bigpond/username=<?queryjs("username");?>";
		passwd=escape("<?queryjs("password");?>");
		if(passwd!="<?=$DEF_PASSWORD?>")		str+="&set/wan/rg/inf:1/bigpond/password="+passwd;

		str+="&set/wan/rg/inf:1/bigpond/server=<?query("server");?>";
		break;
	}

	// wireless ssid channel	(h_wiz6_wlan1_cfg.php)
	<?anchor("/tmp/wiz/wireless");?>
	str+="&setPath=/wireless/";
	str+="&autoChannel=0&supergmode=0";
	str+="&SSID="+escape("<?queryjs("ssid");?>");
	str+="&CHANNEL=<?query("channel");?>";
	// wireless wep		(h_wiz6_wlan2_sec.php)
	wep="<?query("wpa/wepMode");?>";
	defkey="<?query("defkey");?>";
	key1="<?query("wepkey:1");?>";
	key2="<?query("wepkey:2");?>";
	key3="<?query("wepkey:3");?>";
	key4="<?query("wepkey:4");?>";

	str+="&jumpstart/enable=0";
	str+="&authentication=0";
	str+="&keyFormat=2";
	str+="&keyLength=<?query("keyLength");?>";
	str+="&wpa/WEPMODE="+wep;
//	str+="&WEPKEY:"+defkey+"="+eval("key"+defkey);
	str+="&WEPKEY:1="+eval("key"+defkey);
	str+="&WEPKEY:2="+eval("key"+defkey);
	str+="&WEPKEY:3="+eval("key"+defkey);
	str+="&WEPKEY:4="+eval("key"+defkey);
	str+="&endSetPath=1";
	str+="&del/tmp/wiz=1";


	switch(connMode) {
	case "2": /* DHCP */
		str+=exeStr("submit COMMIT;submit WAN;submit WLAN;submit TIME;submit HTTPD_PASSWD;submit SYSLOG");
		break;
		
	case "3": /* PPPoE */
		str+=exeStr("submit COMMIT;submit WAN;submit WLAN;submit HTTPD_PASSWD");
		break;
	default:
		str+=exeStr("submit COMMIT;submit WAN;submit WLAN;submit TIME;submit HTTPD_PASSWD");
		break;
	}
	self.location.href=str;

//	str+="&exeshell=submit COMMIT; submit REBOOT";
//	if(top.window.opener.closed)	return;
	
//	top.opener.top.location.href=str;
//	top.opener.focus();
//	window.close();
}
</script>
<form name="" method=post action=wizard8.cgi>
<?=$table?>
<tr><td height=11><?=$top_pic?></td></tr>
<tr><td height=20 class=title_wiz><?=$m_setup_completed?></td></tr>
<tr>
	<td height=200 valign=top>
	<table border=0 width=95% cellpadding=0 height="<?=$height_wiz?>">
	<tr valign=middle>
		<td colspan=2 height=100%>
		<table width=100% border=0 cellspacing=0 cellpadding=0 align=center>
		<tr><td class=c_wiz><?=$m_title_desc?></td></tr>
		</table>
		</td>
	</tr>
	</table>
	</td>
</tr>
<tr>
	<td height=10 align=right valign=bottom>
	<script language="JavaScript">back("h_wiz6_wlan2_sec.php");restart();exit();</script>
	</td>
</tr>
</table>
</form>
</body>
</html>
