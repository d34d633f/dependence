<?require("/www/comm/genTop.php");?>

<script language="JavaScript">
mode = "<?query("/wan/rg/inf:1/mode");?>";
switch (parseInt(mode, [10]))
{
case 2:
	filename="h_wan_dhcp.php";
	break;
case 3:
	filename="h_wan_poe.php";
	break;
case 4:
	filename="h_wan_pptp.php";
	break;
case 5:
	filename="h_wan_l2tp.php";
	break;
case 7:
	filename="h_wan_bigpond.php";
	break;
case 1:
default:
	filename="h_wan_fix.php";
	break;
}
document.write('<meta http-equiv="refresh" content="0; url='+filename+'">');
</script>
</html>
