<?
/* vi: set sw=4 ts=4: */
$MSG_FILE="h_wizard.php";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
?>
<script language="JavaScript">
//<?$modelname=query("/sys/modelname");?>

function ShowWizard(name)
{
<?
if($user!="admin"||query("/sys/user:1/password")!=$passwd)
{
	echo "	document.location='/sys/relogin.php';";
}
else
{
	echo "	window.open(name,'Wizard','width=450,height=380');";
}
?>
}

</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0>
<?require("/www/comm/middle.php");?>
<form>
<table width="<?=$width_tb?>">
<tr>
	<td class=title_tb><?=$m_title?></td>
</tr>
<tr>
	<td height=132>
	<table width=100%>
	<tr><td width=20></td><td class=l_tb>
		<p><?=$m_title_desc?></p>
	</td></tr>
	</table>
	</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
	<td height=34>
	<div align=center>
	<input type=button name=wizard value="<?=$m_run_wizard?>" onClick="ShowWizard('h_wiz1_flowchart.xgi?del/tmp/wiz=1')">
	</div>
	</td>
</tr>
<tr>
	<td height=34 class=r_tb><script>help("help_home.php#1");</script></td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
