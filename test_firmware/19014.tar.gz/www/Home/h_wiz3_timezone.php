<?
/* vi: set sw=4 ts=4 */
$MSG_FILE="h_wiz3_timezone.php";
require("/www/comm/genWizTop.php");
?>
<script>
<?
$tzone=query("/tmp/wiz/time/timeZone");
if($tzone=="")	{$tzone=query("/time/timeZone");}
if($tzone=="")  {$tzone=14;}
?>
tzone="<?=$tzone?>";

function doNext()
{
	var f=document.getElementById("wiz1");
	str="h_wiz4_wan_showing_detect.xgi?set/tmp/wiz/time/timezone="+f.tzone.value;
	self.location.href=str;
}
</script>
<form method=post id="wiz1" name=wiz1>
<?=$table?>
<tr><td height=11><?=$top_pic?></td></tr>
<tr><td height=20 class=title_wiz><?=$m_title?></td></tr>
<tr><td width=95% class=c_wiz><?=$m_title_desc?></td></tr>
<tr><td height=10></td></tr>
<tr>
	<td height="<?=$height_wiz?>" align=center valign=top>
	<select size=1 name=tzone>
	<?
	for("/tmp/tz/zone")
	{
		echo "<option value='".$@."'";
		if($tzone==$@){echo " selected ";}
		echo ">".query("name")."</option>\n";
	}
	?>
	</select>
	</td>
</tr>
<tr valign=bottom>
	<td height=10 align=right>
	<script language="JavaScript">back("h_wiz2_password.php");next("");exit();</script>
	</td>
</tr>
</table>
</form>
</body>
</html>
