<?
$MSG_FILE="h_lan.php";
$apply_name="h_lan.xgi?";
require("/www/comm/genTop.php");
require("/www/comm/genTopScript.php");
?>

<script>
ip="<?query("/lan/ethernet/ip");?>";
netmask="<?query("/lan/ethernet/netmask");?>";
domain="<?queryjs("/lan/dhcp/server/pool:1/domain");?>";
dnsRelay="<?query("/dnsrelay/mode");?>";
dServerEnable=parseInt("<?query("/lan/dhcp/server/enable");?>", [10]);
dServerSIP="<?query("/lan/dhcp/server/pool:1/startip");?>";
dServerEIP="<?query("/lan/dhcp/server/pool:1/endip");?>";

var lanIP=getIP(ip);
var sIP=getIP(dServerSIP);
var eIP=getIP(dServerEIP);
function initLAN()
{
	var f = document.getElementById("h_lan");
	f.ip.value=ip;
	f.mask.value=netmask;
	f.domain.value=domain;
	if (dnsRelay==1)	f.DNS_relay_enable[1].checked=true;
	else			f.DNS_relay_enable[0].checked=true;
}

function doSubmit()
{
	if (checkParameter()==false) return;

	var f = document.getElementById("h_lan");
	var str=new String("<?=$apply_name?>");

	// check if the new LAN IP is in the DHCP ranges.
	newlanIP = getIP(f.ip.value);
	if(dServerEnable) // if DHCP server is enable.
	{
		if(newlanIP[4] >= sIP[4] && newlanIP[4] <= eIP[4])
		{
			// change the DHCP range
			if (newlanIP[4] >= 100)
			{
				sIP[4] = 1;
				eIP[4] = 99;
			}
			else
			{
				sIP[4] = 100;
				eIP[4] = 199;
			}
		}
	}
	
	var newip=f.ip.value;
	str+="set/lan/ethernet/IP="+reduceIP(f.ip.value);
	str+="&set/lan/ethernet/NETMASK="+reduceIP(f.mask.value);
	str+="&SET/LAN/DHCP/SERVER/POOL:1/DOMAIN="+escape(f.domain.value);
	str+="&SET/DNSRELAY/MODE="+(f.DNS_relay_enable[0].checked? "2": "1");
	startip=getDigit(newip,1)+"."+getDigit(newip,2)+"."+getDigit(newip,3)+"."+sIP[4];
	str+="&set/lan/dhcp/server/pool:1/startIP="+reduceIP(startip);
	endip=getDigit(newip,1)+"."+getDigit(newip,2)+"."+getDigit(newip,3)+"."+eIP[4];
	str+="&set/lan/dhcp/server/pool:1/endIP="+reduceIP(endip);
	if(!checkSubnet(f.ip.value, f.mask.value, ip))
		str+=exeStr("submit LAN_CHANGE;submit COMMIT;submit LAN;submit DNSR;submit RG_VSVR;submit RG_DMZ;submit DHCPD");
	else
		str+=exeStr("submit COMMIT;submit LAN;submit DNSR");
	self.location.href=str;
}

function checkParameter()
{
	var f = document.getElementById("h_lan");
	if(CheckUCS2(f.domain.value))
	{
		alert("<?=$a_domin_only_ascii?>");
		return false;
	}
	if(!checkIpAddr(f.ip, "Error LAN IP Address"))	return false;
	if(!validMask(f.mask, "Error LAN Subnet Mask"))	return false;
	if(!checkMaskAddr(f.ip, f.mask.value, 'Invalid IP address'))	return false;
	
	//check if LAN IP is in the DHCP range.
	newlanIP = getIP(f.ip.value);
	if(dServerEnable) // if DHCP server is enable.
	{
		if((lanIP[1] == newlanIP[1]) && (lanIP[2] == newlanIP[2]) && (lanIP[3] == newlanIP[3]))	
		{
			if(parseInt(newlanIP[4], [10]) >= sIP[4] && parseInt(newlanIP[4], [10]) <= eIP[4])
			{
				alert("<?=$a_IP_cant_in_dhcp_range?>("+sIP[1]+"."+sIP[2]+"."+sIP[3]+"."+sIP[4]+"~"+eIP[1]+"."+eIP[2]+"."+eIP[3]+"."+eIP[4]+").");
				f.ip.focus();
				return false;
			}
		}
	}
}

</script>

<BODY BGCOLOR=#FFFFFF leftmargin=0 topmargin=0 onload="initLAN()">
<?require("/www/comm/middle.php");?>
<FORM name=h_lan method=get id=h_lan>
<table width="<?=$width_tb?>" border=0 height=152>
<tr>
	<td colspan=2 height=20 class=title_tb><font color=#8bacb1><b><?=$m_lan_steeings?></b></font></td>
</tr>
<tr valign="top">
	<td colspan=2 height=30 class=l_tb><?=$m_lan_setting_description?></td>
</tr>
<tr>
	<td width=30% class=l_tb><?=$m_ip_addr?></td>
	<td width=70%><input type=text name=ip size=16 maxlength=15 onblur=changeAddress(0,0,event.keyCode,this,document.h_lan.mask) onkeydown=changeAddress(1,13,event.keyCode,this,document.h_lan.mask)></td>
</tr>
<tr>
	<td class=l_tb><?=$m_subnet?></td>
	<td><input type=text name=mask size=16 maxlength=15 ></td>
</tr>
<tr>
	<td class=l_tb><?=$m_local_domain_name?></td>
	<td class=l_tb><input type=text name=domain size=40 maxlength=31 value="">(<?=$m_optional?>)</td>
</tr>
<tr>
	<td colspan=2 height=20>&nbsp;</td>
</tr>
<tr>
	<td colspan=2 height=20 class=title_tb><b><font color="#8bacb1"><?=$m_dns_relay?></font></b></td>
</tr>
<tr>
	<td width=27% height=20 align=right></td>
	<td width=73% height=20 class=l_tb><input type=radio name=DNS_relay_enable value=1><?=$m_enabled?><input type=radio name=DNS_relay_enable value=0><?=$m_disabled?></td>
</tr>
<tr>
	<td></td>
	<td>&nbsp;</td>
</tr>
<tr>
	<td colspan=2 align=right>
	<script language="JavaScript">apply(""); cancel("initLAN()");help("help_home.php#03");</script>
	</td>
</tr>
</table>
</form>
<?require("/www/comm/bottom.php");?>
