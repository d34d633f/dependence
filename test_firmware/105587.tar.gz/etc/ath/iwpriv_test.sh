#!/bin/sh
iwpriv wifi0 getHALparam
iwpriv wifi0 GetDMABcnRespT
iwpriv wifi0 GetSWBcnRespT
iwpriv wifi0 GetAddSWBAbo
iwpriv wifi0 Get5MBAck
iwpriv wifi0 GetCWMIgnExCCA
iwpriv wifi0 GetForceBias
iwpriv wifi0 GetForBiasAuto
iwpriv wifi0 GetPCIEPwrSvEn
iwpriv wifi0 GetPCIEL1SKPEn
iwpriv wifi0 GetPCIEClkReq    
iwpriv wifi0 GetPCIEWAEN      
iwpriv wifi0 GetPCIEPwRset    
iwpriv wifi0 GetPCIERestore   
iwpriv wifi0 GetHTEna         
iwpriv wifi0 GetDisTurboG     
iwpriv wifi0 GetOFDMTrgLow    
iwpriv wifi0 GetOFDMTrgHi     
iwpriv wifi0 GetCCKTrgHi      
iwpriv wifi0 GetCCKTrgLow     
iwpriv wifi0 GetANIEna        
iwpriv wifi0 GetNoiseImmLvl   
iwpriv wifi0 GetOFDMWeakDet   
iwpriv wifi0 GetCCKWeakThr    
iwpriv wifi0 GetSpurImmLvl    
iwpriv wifi0 GetFIRStepLvl    
iwpriv wifi0 GetRSSIThrHi     
iwpriv wifi0 GetRSSIThrLow    

iwpriv wifi0 GetDivtyCtl      

iwpriv wifi0 GetAntSwap       

iwpriv wifi0 GetHALDbg        

iwpriv wifi0 get_txchainmask  

iwpriv wifi0 get_rxchainmask  

iwpriv wifi0 get_chainmasksel 

iwpriv wifi0 getAMPDU         

iwpriv wifi0 getAMPDULim      

iwpriv wifi0 getAMPDUFrames   

iwpriv wifi0 getAggrProt      

iwpriv wifi0 getAggrProtDur   

iwpriv wifi0 getAddrProtMax   

iwpriv wifi0 getTxPowLim      

iwpriv wifi0 getTXPwrOvr      

iwpriv wifi0 getDisASPMWk     

iwpriv wifi0 getEnaASPM       

iwpriv wifi0 getBcnNoReset    

iwpriv wifi0 getCABlevel      

iwpriv wifi0 getATHDebug      

iwpriv wifi0 get_tpscale      

iwpriv wifi0 get_acktimeout   

iwpriv wifi0 getCountryID     

iwpriv wifi0 getCountry       





iwpriv ath0 getoptie         

iwpriv ath0 getchanlist      

iwpriv ath0 getchaninfo      

iwpriv ath0 get_mode         

iwpriv ath0 getwmmparams     

iwpriv ath0 get_cwmin        

iwpriv ath0 get_cwmax        

iwpriv ath0 get_aifs         

iwpriv ath0 get_txoplimit    

iwpriv ath0 get_acm          

iwpriv ath0 get_noackpolicy  

iwpriv ath0 getparam         

iwpriv ath0 get_authmode     

iwpriv ath0 get_protmode     

iwpriv ath0 get_mcastcipher  

iwpriv ath0 get_mcastkeylen  

iwpriv ath0 get_uciphers     

iwpriv ath0 get_ucastcipher  

iwpriv ath0 get_ucastkeylen  

iwpriv ath0 get_keymgtalgs   

iwpriv ath0 get_rsncaps      

iwpriv ath0 get_roaming      

iwpriv ath0 get_privacy      

iwpriv ath0 get_countermeas  

iwpriv ath0 get_dropunencry  

iwpriv ath0 get_wpa          

iwpriv ath0 get_driver_caps  

iwpriv ath0 get_wmm          

iwpriv ath0 get_hide_ssid    

iwpriv ath0 get_ap_bridge    

iwpriv ath0 get_inact        

iwpriv ath0 get_inact_auth   

iwpriv ath0 get_inact_init   

iwpriv ath0 get_abolt        

iwpriv ath0 get_dtim_period  

iwpriv ath0 get_bintval      

iwpriv ath0 get_doth         

iwpriv ath0 get_doth_pwrtgt  

iwpriv ath0 get_compression  

iwpriv ath0 get_ff           

iwpriv ath0 get_turbo        

iwpriv ath0 get_burst        

iwpriv ath0 get_pureg        

iwpriv ath0 get_ar           

iwpriv ath0 get_wds          

iwpriv ath0 get_bgscan       

iwpriv ath0 get_bgscanidle   

iwpriv ath0 get_bgscanintvl  

iwpriv ath0 get_mcast_rate   

iwpriv ath0 get_coveragecls  

iwpriv ath0 get_countryie    

iwpriv ath0 get_scanvalid    

iwpriv ath0 get_regclass     

iwpriv ath0 get_rssi11a      

iwpriv ath0 get_rssi11b      

iwpriv ath0 get_rssi11g      

iwpriv ath0 get_rate11a      

iwpriv ath0 get_rate11b 

iwpriv ath0 get_rate11g      

iwpriv ath0 get_uapsd        

iwpriv ath0 get_sleep        

iwpriv ath0 get_eospdrop     

iwpriv ath0 get_markdfs      

iwpriv ath0 get_chanbw       

iwpriv ath0 get_shpreamble   

iwpriv ath0 getiebuf         

iwpriv ath0 get_powersave    

iwpriv ath0 get_cwmmode      

iwpriv ath0 get_extoffset    

iwpriv ath0 get_extprotmode  

iwpriv ath0 get_extprotspac  

iwpriv ath0 get_cwmenable    

iwpriv ath0 get_extbusythres 

iwpriv ath0 get_chwidth      

iwpriv ath0 get_shortgi      

iwpriv ath0 get_fastcc       

iwpriv ath0 get_tx_chainmask 

iwpriv ath0 get_tx_cm_legacy 

iwpriv ath0 get_rx_chainmask 

iwpriv ath0 get_rtscts_rcode 

iwpriv ath0 get_ampdu        

iwpriv ath0 get_ampdulimit   

iwpriv ath0 get_ampdudensity 

iwpriv ath0 get_ampdusframes 

iwpriv ath0 get_amsdu        

iwpriv ath0 get_amsdulimit 

iwpriv ath0 get_htprot       

iwpriv ath0 get_countrycode  

iwpriv ath0 getaddbastatus   

iwpriv ath0 get11NRates      

iwpriv ath0 get11NRetries    

iwpriv ath0 getdbgLVL        

iwpriv ath0 get_wdsdetect    

iwpriv ath0 get_noedgech     

iwpriv ath0 get_htweptkip    

iwpriv ath0 getRadio         

iwpriv ath0 get_puren        

iwpriv ath0 get_ignore11d    

iwpriv ath0 get_stafwd       

iwpriv ath0 get_mcastenhance 

iwpriv ath0 get_medebug      

iwpriv ath0 get_me_length    

iwpriv ath0 get_metimer      

iwpriv ath0 get_metimeout    


