HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/trace.php"; 
include "/htdocs/webinc/config.php";

fwrite("w",$ShellPath, "#!/bin/sh\n");
$result="OK";
$radioID = get("","/runtime/hnap/SetMultipleSSID/RadioID");
$MSSIDIndex = get("","/runtime/hnap/SetMultipleSSID/MSSIDIndex");

$nodebase="/runtime/hnap/SetMultipleSSID/SetWLanRadioSettings/";
include "etc/templates/hnap/SetMultipleSSID_SetWLanRadioSettings.php";
if($result!="OK")
{
	//error need break;	
	TRACE_error("SetWLanRadioSettings is not OK ret=".$result); 
}

$nodebase="/runtime/hnap/SetMultipleSSID/SetWLanRadioSecuritys/";
include "etc/templates/hnap/SetMultipleSSID_SetWLanRadioSecuritys.php";
if($result!="OK")
{
	TRACE_error("SetWLanRadioSecuritys is not OK ret=".$result); 
}

fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "echo \"[$0]-->multiple setting\" > /dev/console\n");

if($result=="OK")
{
	fwrite("a",$ShellPath, "/etc/scripts/dbsave.sh > /dev/console\n");
	fwrite("a",$ShellPath, "service DEVICE.ACCOUNT restart > /dev/console\n");
	fwrite("a",$ShellPath, "service WAN restart > /dev/console\n");
	fwrite("a",$ShellPath, "service ".$SRVC_WLAN." restart > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
	//change to reboot ,we need restart much time
	$result="REBOOT";
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
<soap:Body>
<SetMultipleSSIDResponse xmlns="http://purenetworks.com/HNAP1/">
	<SetMultipleSSIDResult><?=$result?></SetMultipleSSIDResult>
</SetMultipleSSIDResponse>
</soap:Body>
</soap:Envelope>