/**
 * menuObject
 *  - 
 * author: Moa Chung
 * date:   2013-08-22
 * notice: 
 */

function cloneObject(obj) {
    if (obj === null || typeof obj !== 'object') {
        return obj;
    }
 
    var temp = obj.constructor(); // give temp the original obj's constructor
    for (var key in obj) {
        temp[key] = cloneObject(obj[key]);
    }
 
    return temp;
}

function clonearray(x) {
	var result = new Array(x.length);

	for (var i = 0; i < x.length; i++)
		result[i] = cloneObject(x[i]);

	return result;
}

// return: value of end position
function insert_menu_items(target, index, items)
{
	var i;

	for (i = 0; i < items.length; i++)
		target.splice(index+i, 0, items[i]);

	return index+i;
}

var w0_opmode = '<!--# echo qcawifi.wifi0.gOPmode -->';
var w1_opmode = '<!--# echo qcawifi.wifi1.gOPmode -->';
var changes_count = '<!--# uci_changes_count -->';

//main
var advanced_L1 =
	[
		{title:'_apply_discard',page:'adm_changes.asp'},
		{title:'_status',img:'but_network_status'},
		{title:'_system',img:'but_sys'},
		{title:'_wireless_2',img:'but_wireless_24'},
		{title:'_wireless_5',img:'but_wireless_5'},
		{title:'_management',img:'but_mgmt'}
	];
var advanced_L2 = [
	//save&reload(0)
	[],
	//status(1)
	[
		{title:'_main',page:'adm_status.asp'},
		{title:'_system_log',page:'adm_syslog.asp'},
		{title:'_ipv6_status',page:'adm_ipv6_status.asp'}
	],
	//system(2)
	[
		{title:'_wizard',page:'adm_wizard.asp'},
		{title:'_oper_mod',page:'adm_oper.asp'},
		{title:'_ip_set',page:'adm_ipset.asp'},
		{title:'_span_tree_set',page:'adm_spantree.asp'},
		{title:'_band_steer',page:'adm_bandsteer.asp'},
		{title:'_ip_set_v6',page:'adm_ipset_ipv6.asp'},
		{title:'_coovachilli',page:'adm_cp_index.asp'},
		{title:'_ATF',page:'adm_atf.asp'}
	],
	//wireless 2.4GHz(3)
	[
		{title:'_wds_set',page:'w0_wds.asp'},
		{title:'_wireless_network',page:'w0_network.asp'},
		{title:'_wifiser_mode22',page:'w0_filter.asp'},
		{title:'_wl_adv_set',page:'w0_adv.asp'},
		{title:'_WPS',page:'w0_wps.asp'}
	],
	//wireless 5GHz(4)
	[
		{title:'_wds_set',page:'w1_wds.asp'},
		{title:'_wireless_network',page:'w1_network.asp'},
		{title:'_wifiser_mode22',page:'w1_filter.asp'},
		{title:'_wl_adv_set',page:'w1_adv.asp'},
		{title:'_WPS',page:'w1_wps.asp'}
	],
	//Management(5)
	[
		{title:'_adminsttn',page:'adm_mgmt.asp'},
		{title:'_mgmt_vlan',page:'adm_vlan.asp'},
		{title:'_snmp_set',page:'adm_snmp.asp'},
		{title:'_br_set',page:'adm_settings.asp'},
		{title:'_upload_firm',page:'adm_upload_fw.asp'},
		{title:'_time_setting',page:'adm_time.asp'},
		{title:'_sched',page:'adm_schedule.asp'},
		{title:'_cli_set',page:'adm_cli.asp'},
		{title:'_log',page:'adm_log.asp'},
		{title:'_dgnst',page:'adm_dgnst.asp'},
		{title:'_led_ctrl',page:'adm_led.asp'}
	]
];

var stmnu_ap = [
		{title:'_wl_clnt_lst',page:'_stainfo.asp'}
	];

var stmnu_sta = [
		{title:'_conn_status',page:'_connstatus.asp'}
	];

var stmnu_wds_ap = [
		{title:'_wds_link_lst',page:'_wdslst.asp'},
		{title:'_wl_clnt_lst',page:'_stainfo.asp'}
	];

var stmnu_wds_br = [
		{title:'_wds_link_lst',page:'_wdslst.asp'}
	];

var stmnu_wds_sta = [
		{title:'_conn_status',page:'_connstatus.asp'}
	];

var stmnu_rpt = [
		{title:'_conn_status',page:'_connstatus.asp'},
		{title:'_wl_clnt_lst',page:'_stainfo.asp'}
	];

var menu_ap = [
		{title:'_wireless_network',page:'_network_ap.asp'},
		{title:'_wireless_bandwidth_control',page:'_bwc_ap.asp'},
		{title:'_wireless_rssi_scanner',page:'_check_rssi_ap.asp'},
		{title:'_wifiser_mode22',page:'_filter_ap.asp'},
		{title:'_wl_adv_set',page:'_adv_ap.asp'},
		{title:'_WPS',page:'_wps.asp'}
	];

var menu_sta = [
		{title:'_wireless_network',page:'_network_sta.asp'},
		{title:'_wl_adv_set',page:'_adv_sta.asp'}
	];

var menu_wds_ap = [
		{title:'_wds_set',page:'_wds.asp'},
		{title:'_wireless_network',page:'_network_ap.asp'},
		{title:'_wifiser_mode22',page:'_filter_ap.asp'},
		{title:'_wl_adv_set',page:'_adv_ap.asp'},
		{title:'_WPS',page:'_wps.asp'}
	];

var menu_wds_br = [
		{title:'_wds_set',page:'_wds.asp'},
		{title:'_wireless_network',page:'_network_br.asp'},
		{title:'_wl_adv_set',page:'_adv_sta.asp'}
	];

var menu_wds_sta = [
		{title:'_wireless_network',page:'_network_sta.asp'},
		{title:'_wl_adv_set',page:'_adv_sta.asp'}
	];

var menu_rpt = [
		{title:'_wireless_network',page:'_network_rpt.asp'},
		{title:'_wifiser_mode22',page:'_filter_rpt.asp'},
		{title:'_wl_adv_set',page:'_adv_rpt.asp'}
	];

// return: value of end position
function insert_wifi_menu_items(target, index, opmode, pretitle, prepage)
{
	var items, menu_ptr;

	switch (opmode) {
		case 'ap':
			menu_ptr = stmnu_ap; break;
		case 'sta':
			menu_ptr = stmnu_sta; break;
		case 'wds-ap':
			menu_ptr = stmnu_wds_ap; break;
		case 'wds-bridge':
			menu_ptr = stmnu_wds_br; break;
		case 'wds-sta':
			menu_ptr = stmnu_wds_sta; break;
		case 'repeater':
			menu_ptr = stmnu_rpt; break;
		default:
			menu_ptr = stmnu_ap;
	}

	// deep clone
	items = clonearray(menu_ptr);

	for (var i = 0; i < items.length; i++) {
		items[i].pretitle = pretitle;
		items[i].page = prepage + items[i].page;
	}

	return insert_menu_items(target, index, items);
}

function menuObject() {
	this.v4v6;
	this.usb;
	this.build_structure = function(category, idx, sub_idx, sub_title, sub_page)
	{
		var content_main="";
		var which;
		var total;
		which = advanced_L1;

		//total = (this.usb?which.length:--which.length);
		total = which.length;
		content_main += '<div class="arrowlistmenu">';
//		content_main += '<div class="homenav" style="margin-bottom:20px;"></div>';
//		content_main += '<div class="borderbottom"> </div>';

		for(var i=0; i<total; i++)
		{
			var img_str = '', class_str = '', click_str = '', title_str = '';
			var title_lang;

			if (which[i].img)
				img_str = which[i].img;

			if (which[i].page)
				click_str = 'onclick="menuObject.animoa(this,\''+ which[i].page +'\');"';
			else
				click_str = 'onclick="menuObject.animoa(this);"';

			if (i == idx) {
				class_str = 'class="menuheader expandable openheader"';
				if (img_str)
					img_str = '<img src="/image/'+which[i].img+'_1.png" class="CatImage" />';
			} else {
				class_str = 'class="menuheader expandable closeheader"';
				if (img_str)
					img_str = '<img src="/image/'+which[i].img+'_0.png" class="CatImage" />';
			}

			var get_language = "<!--# echo cameo.cameo.language -->"

			title_lang = get_words(which[i].title);
			if (i == 0) {
				title_lang += ' ' + changes_count;
				if (changes_count > 0) {
					if (img_str)
						title_str = '<span class="unsaved_blink">'+ title_lang +'</span></div>';
					/*
					else
						title_str = '<span class="unsaved_blink" style="font: bold 18px Arial;">'+ title_lang +'</span></div>';
					*/
					else if (get_language == "sp") {
						title_str = '<span class="unsaved_blink" style="font: bold 17px Arial; margin: 0 0 0 -6px;">'+ title_lang +'</span></div>';
					}
					else if (get_language == "ge") {
						title_str = '<span class="unsaved_blink" style="font: bold 15px Arial; margin: 0 0 0 -6px;">'+ title_lang +'</span></div>';
					}
					else {
						title_str = '<span class="unsaved_blink" style="font: bold 18px Arial;">'+ title_lang +'</span></div>';
					}
				} else {
					if (img_str)
						title_str = '<span class="CatTitle">'+ title_lang +'</span></div>';
					/*
					else
						title_str = '<span class="CatTitle" style="font: bold 18px Arial;">'+ title_lang +'</span></div>';
					*/
					else if (get_language == "en") {
						title_str = '<span class="CatTitle" style="font: bold 18px Arial; margin: 0 0 0 -10px;">'+ title_lang +'</span></div>';
					} 
					else if (get_language == "sp") {
						title_str = '<span class="CatTitle" style="font: bold 17px Arial; margin: 0 0 0 -15px;">'+ title_lang +'</span></div>';
					}
					else if (get_language == "ge") {
						title_str = '<span class="CatTitle" style="font: bold 15px Arial; margin: 0 0 0 -15px;">'+ title_lang +'</span></div>';
					}
					else if (get_language == "ru") {
						title_str = '<span class="CatTitle" style="font: bold 18px Arial; margin: -5px 0 0 0;">'+ title_lang +'</span></div>';
					}
					else if (get_language == "fr") {
						title_str = '<span class="CatTitle" style="font: bold 18px Arial; margin: -10px 0 0 -5px;">'+ title_lang +'</span></div>';
					}
					else {
						title_str = '<span class="CatTitle" style="font: bold 18px Arial;">'+ title_lang +'</span></div>';
					}
				}
			} else {
				if (img_str)
					title_str = '<span class="CatTitle">'+ title_lang +'</span></div>';
				else
					title_str = '<span class="CatTitle" style="font: bold 18px Arial;">'+ title_lang +'</span></div>';
			}
			content_main += '<div><div ' + click_str + ' ' + class_str + '>' +
					img_str + title_str +
					this.build_sub_structure(category, i, sub_idx, (i == idx), sub_title, sub_page);
			content_main += '</div>';
		}
		content_main += '</div>';
		//$("#main_title").html(content_main);
		return content_main;
	};

	this.build_sub_structure = function(category, idx, sub_idx, expand, sub_title, sub_page)
	{
		var which;
		var content_sub='';

		// 2.4G or 5G Wireless Section
		if (idx == 3 || idx == 4)
		{
			var menu_ptr;
			var opmode_ptr = (idx == 3 ? w0_opmode : w1_opmode);

			switch (opmode_ptr) {
			case 'ap':
				menu_ptr = menu_ap; break;
			case 'sta':
				menu_ptr = menu_sta; break;
			case 'wds-ap':
				menu_ptr = menu_wds_ap; break;
			case 'wds-bridge':
				menu_ptr = menu_wds_br; break;
			case 'wds-sta':
				menu_ptr = menu_wds_sta; break;
			case 'repeater':
				menu_ptr = menu_rpt; break;
			default:
				menu_ptr = menu_ap;
			}
			// deep clone
			which = clonearray(menu_ptr);

			for (var i=0; i<which.length; i++)
				if (idx == 3)
					which[i].page = "w0" + which[i].page;
				else
					which[i].page = "w1" + which[i].page;
		}
		// Status Section
		else if (idx == 1)
		{
			var pos;

			// deep clone
			which = clonearray(advanced_L2[idx]);

			pos = insert_wifi_menu_items(which, 1, w0_opmode, "2.4G ", "w0");

			pos = insert_wifi_menu_items(which, pos, w1_opmode, "5G ", "w1");
		}
		else {
			which = advanced_L2[idx];
		}

		if(expand)
			content_sub += '<ul class="categoryitems">';
		else
			content_sub += '<ul class="categoryitems" style="display:none;">';

		for(var j=0; j<which.length; j++)
		{
			if ( expand && (
			     (sub_page && sub_page==which[j].page) ||
			     (sub_title && sub_title==which[j].title) ||
			     (!sub_page && !sub_title && j==sub_idx)))
				content_sub += '<li><a href="'+ which[j].page +'" style="color:#00aff0;">'+ (which[j].pretitle?which[j].pretitle:'') + get_words(which[j].title) +'</a></li>';
			else
				content_sub += '<li><a href="'+ which[j].page +'">' + (which[j].pretitle?which[j].pretitle:'') + get_words(which[j].title) +'</a></li>';
		}
		content_sub += '</ul>';
		return content_sub;
	};

	this.setSupportUSB = function(is){
		this.usb = is;
	};
}

menuObject.animoa = function(node, redirect){
//	console.log(redirect);
	var src = $('.menuheader.expandable.openheader').find('img').attr('src');
	if(src != undefined)
		$('.menuheader.expandable.openheader').find('img').attr('src', src.replace('_1.','_0.'));
	$('.menuheader.expandable.openheader').toggleClass('openheader').toggleClass('closeheader');
	$(node).toggleClass('closeheader').toggleClass('openheader');
	src = $(node).find('img').attr('src');
	if(src != undefined)
		$(node).find('img').attr('src', src.replace('_0.','_1.'));
	$('.categoryitems').slideUp();
	$(node).parent().children('ul').slideDown(400, function(){
		if(redirect!=undefined)
			location.assign(redirect);
	});
};