#!/bin/sh

DEBUG=0

[ "$DEBUG" = "1" ] && echo -e "\$1=$1\t\$2=$2\t\$3=$3\t\$4=$4\t\$5=$5" > /dev/console

IFNAME=$1
CMD=$2
TMP_WPS_CONFIG="/tmp/wps_config_$IFNAME"
# VAPX="$(wifi_cmd findvap $IFNAME)"

[ "$DEBUG" = "1" ] && echo -e "IFNAME=$IFNAME\tCMD=$CMD\tTMP_WPS_CONFIG=$TMP_WPS_CONFIG\tVAPX=$VAPX" > /dev/console

case "$CMD" in
	WPS-NEW-AP-SETTINGS)
		hostapd_cli -i $IFNAME wps_get_config > $TMP_WPS_CONFIG
		local ssid=$(grep ^ssid= $TMP_WPS_CONFIG | cut -f2- -d =)
		local wpa=$(grep ^wpa= $TMP_WPS_CONFIG | cut -f2- -d =)
		local wpa_pairwise=$(grep ^wpa_pairwise= $TMP_WPS_CONFIG | cut -f2- -d =)
		local psk=$(grep ^wpa_psk= $TMP_WPS_CONFIG | cut -f2- -d =)
		local passphrase=$(grep ^wpa_passphrase= $TMP_WPS_CONFIG | cut -f2- -d =)
		local wps_state=$(grep ^wps_state= $TMP_WPS_CONFIG | cut -f2- -d =)
		local security cipher
		local VAPX="$(wifi_cmd findvap $IFNAME)"

		[ "$DEBUG" = "1" ] && echo -e "ssid=$ssid\twpa=$wpa\tpsk=$psk\tpassphrase=$passphrase\twps_state=$wps_state" > /dev/console

		[ -z "$psk" ] && psk=$passphrase

		case "$wpa" in
			1|3)
				security="psk-mixed"
				;;
			2)
				security="psk2"
				;;
			*)
				security="none"
				;;
		esac

		case "$wpa_pairwise" in
			*TKIP*)
				cipher="tkip+aes"
				;;
			*)
				cipher="aes"
				;;
		esac

		[ "$DEBUG" = "1" ] && echo -e "security=$security\tcipher=$cipher" > /dev/console

		# Update uci config
		case "$security" in
			none)
				uci set qcawifi.${VAPX}.encryption="none"
				;;
			*)
				uci set qcawifi.${VAPX}.encryption="$security+$cipher"
				uci set qcawifi.${VAPX}.key=$psk
				;;
		esac

		uci set qcawifi.${VAPX}.ssid="$ssid"
		uci set qcawifi.${VAPX}.wps_state=$wps_state
		uci commit qcawifi
		;;
	WPS-TIMEOUT)
		kill "$(cat /var/run/hostapd_cli_$IFNAME.pid)"
		env -i ACTION="wps-timeout" INTERFACE=$IFNAME /sbin/hotplug-call iface
		;;
	DISCONNECTED)
		kill "$(cat /var/run/hostapd_cli_$IFNAME.pid)"
		;;
esac

