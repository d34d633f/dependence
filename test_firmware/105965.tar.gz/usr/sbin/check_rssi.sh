tolerance_file="/tmp/rssi_tolerance"
tmp_file="/tmp/rssi_tmp_file"
tmp_file_tol="/tmp/rssi_tmp_file_tol"
tmp_file_tol2="/tmp/rssi_tmp_file_tol2"
if_list=

check_enabled()              
{
	for i in $(seq 0 23)
	do
		get_wifi_up=$(uci -p /var/state get qcawifi.@wifi-iface[${i}].up 2>&-)
		get_fn_disabled=$(uci get qcawifi.@wifi-iface[${i}].check_rssi_disabled 2>&-)
                if [ "$get_wifi_up" = "1" -a "$get_fn_disabled" = "0" ]; then
                        if_list=$if_list" "$i
                fi
	done
}

check_if()
{
	for i in $if_list
	do
		ath=$(uci -p /var/state get qcawifi.@wifi-iface[${i}].ifname 2>&-)
		sta_list=$(iwinfo ${ath} assoclist | grep dBm)
		if [ ! "$sta_list" = "" ]; then
			echo $sta_list > $tmp_file
			sed -i s/"ago "/\\n/g $tmp_file
			check_rssi $i $ath
		fi

		if [ -f $tmp_file ]; then
			rm $tmp_file
		fi
	done

	if [ ! -f $tmp_file_tol ]; then
		exit
	fi
}

check_rssi()
{
        while read line;
        do
		mac=$(echo ${line} | cut -d " " -f1)
		rssi=$(echo ${line} | cut -d " " -f2)
		low_rssi=$(uci get qcawifi.@wifi-iface[${1}].check_rssi_value 2>&-)
		tol_rssi=$(uci get qcawifi.@wifi-iface[${1}].check_rssi_tolerance 2>&-)
                if [ $rssi -lt $low_rssi ]; then
			if [ $tol_rssi -gt 0 ]; then
				echo $mac $1 >> $tmp_file_tol
			else
				if [ "$mac" == "00:00:00:00:00:00" ]; then
					echo "[check_rssi:] 00:00:00:00:00:00"				
				else
					iwpriv $2 kickmac $mac
					echo "[check_rssi:] kick $mac"
				fi
			fi
		fi
        done < $tmp_file

}

check_tolerance()
{
	if [ ! -f $tolerance_file ] ;then
		while read line;
		do
			mac=$(echo ${line} | cut -d " " -f1)
			if=$(echo ${line} | cut -d " " -f2)
			echo $mac $if 1 >> $tolerance_file
		done < $tmp_file_tol
	else
		while read line;
		do
			mac=$(echo ${line} | cut -d " " -f1)
			if=$(echo ${line} | cut -d " " -f2)
			tol_rssi=$(uci get qcawifi.@wifi-iface[${if}].check_rssi_tolerance 2>&-)
			match=$(grep ${mac} $tolerance_file | cut -d " " -f3 2>&-)
			if [ "$match" = "" ]; then
				echo $mac $if $(($match+1)) >> $tmp_file_tol2
			else
				if [ $match = $tol_rssi ]; then
					ath=$(uci -p /var/state get qcawifi.@wifi-iface[${if}].ifname 2>&-)
					iwpriv $ath kickmac $mac
					echo "[check_rssi:] kick $mac"
				elif [ $match -lt $tol_rssi ]; then
					echo $mac $if $(($match+1)) >> $tmp_file_tol2
				fi
			fi
		done < $tmp_file_tol

		if [ -f $tmp_file_tol2 ]; then
			mv $tmp_file_tol2 $tolerance_file
		else
			rm $tolerance_file
		fi
	fi

	rm $tmp_file_tol
}

check_enabled
check_if
check_tolerance
