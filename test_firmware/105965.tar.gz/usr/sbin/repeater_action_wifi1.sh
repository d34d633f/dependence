#!/bin/sh

echo "$1 - $2" > /dev/console

if [ "$2" = "CONNECTED" ]; then
	wifi_cmd syncch $1 wifi1_vap11
fi

