cp_disabled=$(uci get cameo.captive_portal.disabled 2>&-)
cp_redirect_disabled=$(uci get cameo.captive_portal.redirect_disabled 2>&-)
connect_list=$(uci get misc.captive_portal.connect_list 2>&-)
auth_timeout=$(uci get cameo.captive_portal.auth_timeout 2>&-)
auth_timeout_single_password=$(uci get cameo.captive_portal.auth_timeout_single_password 2>&-)
time_now=$(date +%s)

remove_allow_list()
{
	# $1=mac $2=iface $3=timeout #
	ebtables -t broute -D internal_captive_portal -i $2 -s $1 -j RETURN  # if, mac
	ebtables -t broute -D internal_captive_portal -d $1 -j RETURN # mac
	ebtables -D internal_captive_portal -i $2 -s $1 -j ACCEPT # if, mac
	uci del_list misc.captive_portal.connect_list=$1_$2_$3_$4
	# del account from logged in list by mac
	find_account_by_mac=$(uci get misc.captive_portal.logged_in_list | sed s'/ /\n/'g | grep $1)
	if [ ! "$find_account_by_mac" = "" ]; then
		uci del_list misc.captive_portal.logged_in_list=$find_account_by_mac
	fi
	uci commit misc
}

#main

#check function entable
if [ "$cp_disabled" = "1" -a "$cp_redirect_disabled" = "1" ]; then
	exit
fi

#check auth timeout
if [ ! "$auth_timeout" = "" -a ! "$auth_timeout" = "0" -a ! "$auth_timeout_single_password" = "" -a ! "$auth_timeout_single_password" = "0" ];then
	is_timeout_user_login=$(( $auth_timeout * 60))
	is_timeout_single_password=$(( $auth_timeout_single_password * 60))
	for data in $connect_list
	do
		get_mac=$(echo ${data} | cut -d '_' -f 1)
		get_if=$(echo ${data} | cut -d '_' -f 2)
		get_list_time=$(echo ${data} | cut -d '_' -f 3)
		login_method=$(echo ${data} | cut -d '_' -f 4)
		if [ "$login_method" = "0" ]; then
			time_cmp=$(( $get_list_time + $is_timeout_user_login ))
		else
			time_cmp=$(( $get_list_time + $is_timeout_single_password ))
		fi

		if [ $time_now -gt $time_cmp ]; then
			remove_allow_list $get_mac $get_if $get_list_time $login_method
		fi
	done
fi
