#!/bin/sh
WIFIX=$(uci -P /var/state/ show qcawifi | grep $1 | cut -d\. -f 2 | cut -d_ -f 1)
if [ "$WIFIX" != "" ]; then
	hwmode=$(uci get qcawifi.$WIFIX.hwmode)
	NRates=$(uci get qcawifi.$WIFIX.11NRates)
	nss=$(uci get qcawifi.$WIFIX.nss)
	vhtmcs=$(uci get qcawifi.$WIFIX.vhtmcs)
	if [ "$NRates" != "0" ]; then
		iwpriv $1 set11NRates $NRates
	elif [ $(echo $hwmode | grep ac) ]; then
		if [ "$nss" -gt "0" ]; then iwpriv $1 nss $nss; fi
		if [ $vhtmcs ]; then iwpriv $1 vhtmcs $vhtmcs; fi
	fi
fi
