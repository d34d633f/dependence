#!/bin/ash

flag=0

wlan0_enable=$(uci get qcawifi.wifi0_vap0.disabled)
wlan0_model=$(uci get qcawifi.wifi0.gOPmode)



if [ "${wlan0_enable}" == "1" ] || [ "${wlan0_model}" != "ap" ]; then
	return
fi


enable_gpio19_func()
{
        gpio_func4_value=$(devmem 0x1804003C)
        let "value=(gpio_func4_value & ~(0x000000ff << 24)) | (0x0000002F << 24)"
        devmem2 0x1804003C w ${value} 2>&-
        flag=0
}

disable_gpio19_func()
{
        gpio_func4_value=$(devmem 0x1804003C)
        let "value=gpio_func4_value & ~(0x000000ff << 24)"
        devmem2 0x1804003C w ${value} 2>&-

        gpio_output_value=$(devmem 0x18040008)
        let "value=gpio_output_value & ~(1 << 19)"
        devmem2 0x18040008 w ${value} 2>&-
        flag=1
}


while [ 1 ]
do
        i=0
        rm -rf /tmp/wifi_2.4G
        while [ ${i} -lt 8 ]
        do
                wifimode=$(iwconfig 2>&- | grep -A1 ath${i}  | sed '1d' | awk '{print$1}' | awk -F":" '{print $2}')
                if [ "${wifimode}" == "Master" ]; then
                        wlanconfig ath${i} list sta  > /tmp/wifi_2.4G
                fi
                let "i=i+1"
        done
        if [ -s /tmp/wifi_2.4G ]; then 
                #echo "$filename is NOT empty file."
                if [ ${flag} == 1 ];then
                        enable_gpio19_func
                fi

        else
                #echo "$filename is empty file."
                if [ ${flag} == 0 ];then
                        disable_gpio19_func
                fi

        fi

        sleep 2
done
