#!/bin/sh
#
# HTB stop script. Parameters:
#
# NONE
#

DEVICESFILE=/tmp/htb_devices.txt
CLASS=1

if [ -s $DEVICESFILE ]; then
    DEVICES=`cat $DEVICESFILE`
    echo "devices: $DEVICES"
else
    echo Error: $DEVICESFILE is empty or not existing
    exit 1
fi

# remove stale crap
for dev in $DEVICES; do
    tc qdisc del dev $dev root > /dev/null 2>&1
done    

# remove file
rm -f $DEVICESFILE
