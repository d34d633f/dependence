#!/bin/sh
#
# Initialization script.
# Required parameters:
#
# -l lan devices
# -w wan devices
# -i lan rate
# -o wan rate
#
# Optional parameters:
#
# -j lan burst
# -mj wan burst
# -x lan cburst
# -y wan cburst

DEVICESFILE=/tmp/htb_devices.txt
CLASS=10

usage=\
"
Usage: $0 -l <lan device list> -w <wan device list> -i <lan rate> -o <wan rate> -j <lan burst> -m <wan burst> -x <lan cburst> -y <wan cburst>\n\n
example: $0 -l 'eth3 ath0' -w 'eth1 eth2' -i 2000Kbit -o 1000Kbit -j 100Kb -m 100Kb -x 50Kb -y 50Kb
"

while getopts "l:w:i:o:j:m:x:y:r:d:" options; do
    case $options in
	l ) LANDEVICES=$OPTARG;;
	w ) WANDEVICES=$OPTARG;;
	i ) LANRATE=$OPTARG;;
	o ) WANRATE=$OPTARG;;
	j ) LANBURST=$OPTARG;;
	m ) WANBURST=$OPTARG;;
	x ) LANCBURST=$OPTARG;;
	y ) WANCBURST=$OPTARG;;
	r ) WANRATERatio=$OPTARG
		flag_wanRatio=1;
	;;
	d ) WANRATERatioRef=$OPTARG
	;;
	* ) 	echo -e $usage
		exit 1;;
    esac
done

if [ -z "$LANDEVICES" ] || [ -z "$LANRATE" ] || [ -z "$WANDEVICES" ] || [ -z "$WANRATE" ]
then
    echo -e $usage
    exit 1
fi      


LG="echo"
# remove stale crap
for dev in $LANDEVICES $WANDEVICES; do
    tc qdisc del dev $dev root > /dev/null 2>&1
done

# init root handles
for dev in $LANDEVICES; do
    TC="tc qdisc add dev $dev root handle $CLASS:0 htb"
    $TC || $LG "'${TC}' has failed."
    if [ -z $LANBURST ]; then
	TC="tc class add dev $dev parent $CLASS:0 classid $CLASS:0 htb rate $LANRATE"
    else
        if [ -z $LANCBURST ]; then
	    TC="tc class add dev $dev parent $CLASS:0 classid $CLASS:0 htb rate $LANRATE burst $LANBURST"
        else
	    TC="tc class add dev $dev parent $CLASS:0 classid $CLASS:0 htb rate $LANRATE burst $LANBURST cburst $LANCBURST"
        fi
    fi
    echo $TC
    $TC || $LG "'${TC}' has failed."
done

local WANRATETotal=${WANRATE%%[a-zA-Z]*}
local unit_str="bit"
if [ -n "$flag_wanRatio" ]; then
    unit=$(($WANRATETotal*10))
fi

##check is there exist NAWDS interface
if [ -f "${WANRATERatioRef}" ]; then
    local nawds_exist=$(grep -e "0$" ${WANRATERatioRef})
fi
if [ -n "$nawds_exist" ]; then
    TC="tc class add dev $dev parent $CLASS:0 classid $CLASS:0 htb rate $WANRATE ceil 600mbit" 
    echo $TC
    $TC || $LG "'${TC}' has failed."
fi

for dev in $WANDEVICES; do
    TC="tc qdisc add dev $dev root handle $CLASS:0 htb"
    echo $TC
    $TC || $LG "'${TC}' has failed."
    if [ -n "$flag_wanRatio" ]; then
    	# Need, exist athxxx will fail
    	check_dev=`iwconfig $dev`
	if [ "$check_dev" == "" ]; then
		echo $dev not exist
		continue;	
	fi      
    	#echo $check_dev
    
	#ssidno=$(grep -e "^$dev=" ${WANRATERatioRef}|cut -d '-' -f 2)
        ssidno=${dev:3:2}
        ssidno=$((ssidno+1))
        #ssidno=$((9))
        # wifi 1 issue
        if [  $ssidno -ge 9  ]; then
            ssidno=$((ssidno-8))
        fi
        
        #echo ${dev:3:2}
        #echo -e "^$dev=" ${WANRATERatioRef}
        
        #echo $ssidno
        ## let the ratio_index=$ssidno+1
        ratio=$(echo $WANRATERatio|cut -d ',' -f $(($ssidno+1)) )
        #echo $ratio
        #if [ $ssidno = "0" ];then
        #    wdsid=$(grep -e "^$dev=" ${WANRATERatioRef}|cut -d '-' -f 3)
        #    ratio=$(echo $ratio |cut -d '/' -f ${wdsid} )
        #fi
        if [ -z $ratio ]; then ratio=1; fi
        WANRATE=$(($ratio*$unit))$unit_str
        
        if [ "$WANRATE" == "0$unit_str" ]; then
        	WANRATE="8bit"
        fi
    fi

    if [ -z $WANBURST ]; then
	if [ $ssidno = "0" ];then
        TC="tc class add dev $dev parent $CLASS:0 classid $CLASS:0 htb rate $WANRATE ceil 600mbit" 
    else
        TC="tc class add dev $dev parent $CLASS:0 classid $CLASS:0 htb rate $WANRATE ceil 600mbit"
    fi
    else
    	if [ -z $WANCBURST ]; then
          TC="tc class add dev $dev parent $CLASS:0 classid $CLASS:1 htb rate $WANRATE burst $WANBURST"
	else
    	  TC="tc class add dev $dev parent $CLASS:0 classid $CLASS:1 htb rate $WANRATE burst $WANBURST cburst $WANCBURST"
        fi
    fi
    echo $TC
    $TC || $LG "'${TC}' has failed."
done

# save devices for other scripts
echo $LANDEVICES $WANDEVICES > $DEVICESFILE

