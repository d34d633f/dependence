<?
$m_user_name		="Benutzername";
$m_password		="Kennwort";
$m_continue		="Weiter";
$m_nochg_title		="Keine geänderten";
$m_nochg_dsc		="Einstellungen wurden nicht geändert.";
$m_saving_title		="Speichern";
$m_saving_dsc		="Die Einstellungen werden gespeichert und aktiviert.";
$m_saving_dsc_wait = "Bitte warten...";
$m_saving_dsc_change_ip = "Warten Sie bitte 10 Sekunden. Greifen Sie dann mit der neuen IP-Adresse auf das Gerät zu.";
$m_scan_title		="Scannen";
$m_detect_title	="Erkennen";
$m_scan_dsc		="Wird gescannt... <br><br> Bitte warten...";
$m_clear = "Entfernen";

$TITLE=query("/sys/hostname");
$first_frame = "home_sys";
$m_logo_title	=query("/sys/hostname");
?>
