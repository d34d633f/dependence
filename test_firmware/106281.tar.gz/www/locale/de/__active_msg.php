The device is active...<br><br>
Please <font color=red><b>DO NOT POWER OFF</b></font> the device.<br><br>
And please wait for
<input type='Text' readonly name='WaitInfo' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
seconds 
<? if($change_ip=="1") 
	{
		echo "<br><br>then access the device with new IP Address."; 	
	}?>...
