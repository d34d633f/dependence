<?
$m_context_title = "Systemeinstellungen";
$m_reboot		=" Führen Sie einen Neustart des Geräts durch";
$m_b_reboot		=" Neustart";
$m_factory_reset	="Auf Werkseinstellungen zurücksetzen";
$m_b_restore		="Wiederherstellen";
$m_clear_lang_pack ="Sprachpaket löschen"; 
$m_clear ="Entfernen";
$a_sure_to_clear_lang ="Sprachpaket löschen?";
$a_sure_to_factory_reset="Auf Werkseinstellungen zurücksetzen?";
$a_sure_to_reboot	="Access Point neu starten?";

?>
