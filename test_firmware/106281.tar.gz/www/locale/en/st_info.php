<?
$m_context_title = "Client Information";
$m_client_info = "Client Information";
$m_st_association  = "Station association";
$m_ssid = "SSID";
$m_ipaddr = "IP Address";
$m_mac = "MAC";
$m_band = "Band";
$m_auth = "Authentication";
$m_signal = "Signal";
$m_rssi = "RSSI";
$m_txpacket = "TX Packet";
$m_rxpacket = "RX Packet";
$m_power = "Power Saving Mode";
$m_multi_ssid = "MULTI-SSID ";
$m_primary_ssid = "Primary SSID";
$m_on = "On";
$m_off = "Off";
?>
