<?
$m_context_title = "Web Redirection";
$m_enable_url = "Web Redirection";
$m_url_addr = "Web Site";
$m_http = "http:\/\/";
$m_https = "https:\/\/";
$a_empty_url_addr = "Please input a web site.";
$a_invalid_url_addr = "Invalid Web Site.";
$a_invalid_http = "Web site can't start with 'http'.";
?>
