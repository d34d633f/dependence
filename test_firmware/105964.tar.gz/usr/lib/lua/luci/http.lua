local e=require"luci.ltn12"
local a=require"luci.http.protocol"
local o=require"luci.util"
local h=require"string"
local e=require"coroutine"
local r=require"table"
local t,i,t,t,s,n=
ipairs,pairs,next,type,tostring,error
module"luci.http"
context=o.threadlocal()
Request=o.class()
function Request.__init__(e,t,o,i)
e.input=o
e.error=i
e.filehandler=nil
e.message={
env=t,
headers={},
params=a.urldecode_params(t.QUERY_STRING or""),
}
e.parsed_input=false
end
function Request.formvalue(e,t,a)
if not a and not e.parsed_input then
e:_parse_input()
end
if t then
return e.message.params[t]
else
return e.message.params
end
end
function Request.formvaluetable(t,e)
local a={}
e=e and e.."."or"."
if not t.parsed_input then
t:_parse_input()
end
local o=t.message.params[nil]
for t,o in i(t.message.params)do
if t:find(e,1,true)==1 then
a[t:sub(#e+1)]=s(o)
end
end
return a
end
function Request.content(e)
if not e.parsed_input then
e:_parse_input()
end
return e.message.content,e.message.content_length
end
function Request.getcookie(t,e)
local t=h.gsub(";"..(t:getenv("HTTP_COOKIE")or"")..";","%s*;%s*",";")
local e=";"..e.."=(.-);"
local t,t,e=t:find(e)
return e and urldecode(e)
end
function Request.getenv(t,e)
if e then
return t.message.env[e]
else
return t.message.env
end
end
function Request.setfilehandler(e,t)
e.filehandler=t
end
function Request._parse_input(e)
a.parse_message_body(
e.input,
e.message,
e.filehandler
)
e.parsed_input=true
end
function close()
if not context.eoh then
context.eoh=true
e.yield(3)
end
if not context.closed then
context.closed=true
e.yield(5)
end
end
function content()
return context.request:content()
end
function formvalue(t,e)
return context.request:formvalue(t,e)
end
function formvaluetable(e)
return context.request:formvaluetable(e)
end
function getcookie(e)
return context.request:getcookie(e)
end
function getenv(e)
return context.request:getenv(e)
end
function setfilehandler(e)
return context.request:setfilehandler(e)
end
function header(a,t)
if not context.headers then
context.headers={}
end
context.headers[a:lower()]=t
e.yield(2,a,t)
end
function prepare_content(e)
if not context.headers or not context.headers["content-type"]then
if e=="application/xhtml+xml"then
if not getenv("HTTP_ACCEPT")or
not getenv("HTTP_ACCEPT"):find("application/xhtml+xml",nil,true)then
e="text/html; charset=UTF-8"
end
header("Vary","Accept")
end
header("Content-Type",e)
end
end
function source()
return context.request.input
end
function status(t,a)
t=t or 200
a=a or"OK"
context.status=t
e.yield(1,t,a)
end
function write(t,a)
if not t then
if a then
n(a)
else
close()
end
return true
elseif#t==0 then
return true
else
if not context.eoh then
if not context.status then
status()
end
if not context.headers or not context.headers["content-type"]then
header("Content-Type","text/html; charset=utf-8")
end
if not context.headers["cache-control"]then
header("Cache-Control","no-cache")
header("Expires","0")
end
context.eoh=true
e.yield(3)
end
e.yield(4,t)
return true
end
end
function splice(a,t)
e.yield(6,a,t)
end
function redirect(e)
status(302,"Found")
header("Location",e)
close()
end
function build_querystring(t)
local e={"?"}
for t,a in i(t)do
if#e>1 then e[#e+1]="&"end
e[#e+1]=urldecode(t)
e[#e+1]="="
e[#e+1]=urldecode(a)
end
return r.concat(e,"")
end
urldecode=a.urldecode
urlencode=a.urlencode
function write_json(e)
o.serialize_json(e,write)
end
