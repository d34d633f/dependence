module("luci.tools.status",package.seeall)
local a=require"luci.model.uci".cursor()
local function h(o)
local e={}
local i=require"nixio.fs"
local t="/var/dhcp.leases"
a:foreach("dhcp","dnsmasq",
function(e)
if e.leasefile and i.access(e.leasefile)then
t=e.leasefile
return false
end
end)
local s=io.open(t,"r")
if s then
while true do
local t=s:read("*l")
if not t then
break
else
local i,s,a,t,n=t:match("^(%d+) (%S+) (%S+) (%S+) (%S+)")
if i and s and a and t and n then
if o==4 and not a:match(":")then
e[#e+1]={
expires=os.difftime(tonumber(i)or 0,os.time()),
macaddr=s,
ipaddr=a,
hostname=(t~="*")and t
}
elseif o==6 and a:match(":")then
e[#e+1]={
expires=os.difftime(tonumber(i)or 0,os.time()),
ip6addr=a,
duid=(n~="*")and n,
hostname=(t~="*")and t
}
end
end
end
end
s:close()
end
local i=io.open("/tmp/hosts/odhcpd","r")
if i then
while true do
local t=i:read("*l")
if not t then
break
else
local h,s,i,t,n,h,h,a=t:match("^# (%S+) (%S+) (%S+) (%S+) (%d+) (%S+) (%S+) (.*)")
if a and i~="ipv4"and o==6 then
e[#e+1]={
expires=os.difftime(tonumber(n)or 0,os.time()),
duid=s,
ip6addr=a,
hostname=(t~="-")and t
}
elseif a and i=="ipv4"and o==4 then
e[#e+1]={
expires=os.difftime(tonumber(n)or 0,os.time()),
macaddr=s,
ipaddr=a,
hostname=(t~="-")and t
}
end
end
end
i:close()
end
return e
end
function dhcp_leases()
return h(4)
end
function dhcp6_leases()
return h(6)
end
function wifi_networks()
local t={}
local e=require"luci.model.network".init()
local a
for a,e in ipairs(e:get_wifidevs())do
local a={
up=e:is_up(),
device=e:name(),
name=e:get_i18n(),
networks={}
}
local o
for o,e in ipairs(e:get_wifinets())do
a.networks[#a.networks+1]={
name=e:shortname(),
link=e:adminlink(),
up=e:is_up(),
mode=e:active_mode(),
ssid=e:active_ssid(),
bssid=e:active_bssid(),
encryption=e:active_encryption(),
frequency=e:frequency(),
channel=e:channel(),
signal=e:signal(),
quality=e:signal_percent(),
noise=e:noise(),
bitrate=e:bitrate(),
ifname=e:ifname(),
assoclist=e:assoclist(),
country=e:country(),
txpower=e:txpower(),
txpoweroff=e:txpower_offset()
}
end
t[#t+1]=a
end
return t
end
function wifi_network(a)
local e=require"luci.model.network".init()
local e=e:get_wifinet(a)
if e then
local t=e:get_device()
if t then
return{
id=a,
name=e:shortname(),
link=e:adminlink(),
up=e:is_up(),
mode=e:active_mode(),
ssid=e:active_ssid(),
bssid=e:active_bssid(),
encryption=e:active_encryption(),
frequency=e:frequency(),
channel=e:channel(),
signal=e:signal(),
quality=e:signal_percent(),
noise=e:noise(),
bitrate=e:bitrate(),
ifname=e:ifname(),
assoclist=e:assoclist(),
country=e:country(),
txpower=e:txpower(),
txpoweroff=e:txpower_offset(),
disabled=(t:get("disabled")=="1"or
e:get("disabled")=="1"),
device={
up=t:is_up(),
device=t:name(),
name=t:get_i18n()
}
}
end
end
return{}
end
function switch_status(e)
local t
local o={}
for i in e:gmatch("[^%s,]+")do
local t={}
local a=io.popen("swconfig dev %q show"%i,"r")
if a then
local e
repeat
e=a:read("*l")
if e then
local a,i=e:match("port:(%d+) link:(%w+)")
if a then
local o=e:match(" speed:(%d+)")
local s=e:match(" (%w+)-duplex")
local n=e:match(" (txflow)")
local h=e:match(" (rxflow)")
local e=e:match(" (auto)")
t[#t+1]={
port=tonumber(a)or 0,
speed=tonumber(o)or 0,
link=(i=="up"),
duplex=(s=="full"),
rxflow=(not not h),
txflow=(not not n),
auto=(not not e)
}
end
end
until not e
a:close()
end
o[i]=t
end
return o
end
