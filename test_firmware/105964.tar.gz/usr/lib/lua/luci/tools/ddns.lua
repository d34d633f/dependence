module("luci.tools.ddns",package.seeall)
local n=require"nixio"
local t=require"nixio.fs"
local e=require"luci.model.ipkg"
local o=require"luci.model.uci"
local a=require"luci.sys"
local i=require"luci.util"
function calc_seconds(e,t)
if not tonumber(e)then
return nil
elseif t=="days"then
return(tonumber(e)*86400)
elseif t=="hours"then
return(tonumber(e)*3600)
elseif t=="minutes"then
return(tonumber(e)*60)
elseif t=="seconds"then
return tonumber(e)
else
return nil
end
end
function check_ipv6()
return t.access("/proc/net/ipv6_route")
and t.access("/usr/sbin/ip6tables")
end
function check_ssl()
if(a.call([[ grep -i "\+ssl" /usr/bin/wget >/dev/null 2>&1 ]])==0)then
return true
else
return t.access("/usr/bin/curl")
end
end
function check_proxy()
if(a.call([[ grep -i "\+ssl" /usr/bin/wget >/dev/null 2>&1 ]])==0)then
return true
elseif t.access("/usr/bin/curl")then
return(a.call([[ grep -i all_proxy /usr/lib/libcurl.so* >/dev/null 2>&1 ]])==0)
else
return t.access("/usr/bin/wget")
end
end
function check_bind_host()
return t.access("/usr/bin/host")
end
function epoch2date(a,e)
if not e or#e<2 then
local t=o.cursor()
e=t:get("ddns","global","date_format")or"%F %R"
t:unload("ddns")
end
e=e:gsub("%%n","<br />")
e=e:gsub("%%t","    ")
return os.date(e,a)
end
function get_lastupd(a)
local e=o.cursor()
local o=e:get("ddns","global","run_dir")or"/var/run/ddns"
local t=tonumber(t.readfile("%s/%s.update"%{o,a})or 0)
e:unload("ddns")
return t
end
function get_pid(i)
local a=o.cursor()
local e=a:get("ddns","global","run_dir")or"/var/run/ddns"
local e=tonumber(t.readfile("%s/%s.pid"%{e,i})or 0)
if e>0 and not n.kill(e,0)then
e=0
end
a:unload("ddns")
return e
end
function ipkg_ver_compare(t,e,o)
if not t or not o
or not e or not(#e>0)then return nil end
if e=="<>"or e=="><"or e=="!="or e=="~="then e="~="
elseif e=="<="or e=="<"or e=="=<"then e="<="
elseif e==">="or e==">"or e=="=>"then e=">="
elseif e=="="or e=="=="then e="=="
elseif e=="<<"then e="<"
elseif e==">>"then e=">"
else return nil end
local a=i.split(t,"[%.%-]",nil,true)
local o=i.split(o,"[%.%-]",nil,true)
for t=1,math.max(table.getn(a),table.getn(o)),1 do
local a=a[t]or""
local t=o[t]or""
if e=="~="and(a~=t)then return true end
if(e=="<"or e=="<=")and(a<t)then return true end
if(e==">"or e==">=")and(a>t)then return true end
if(a~=t)then return false end
end
return not(e=="<"or e==">")
end
function ipkg_ver_installed(e)
local a=nil
local t=io.open("/usr/lib/opkg/info/%s.control"%e,"r")
if t then
local e
repeat
e=t:read("*l")
if e and e:match("^Version: ")then
a=e:gsub("^Version: ","")
break
end
until not e
t:close()
end
return a
end
function read_value(t,a,o)
local e
if t.tag_error[a]then
e=t:formvalue(a)
else
e=t.map:get(a,o)
end
if not e then
return nil
elseif not t.cast or t.cast==type(e)then
return e
elseif t.cast=="string"then
if type(e)=="table"then
return e[1]
end
elseif t.cast=="table"then
return{e}
end
end
function flag_parse(e,t)
local a=e.map:formvalue(
luci.cbi.FEXIST_PREFIX..e.config.."."..t.."."..e.option)
if a then
local a=e:formvalue(t)and e.enabled or e.disabled
local o=e:cfgvalue(t)
if a~=e.default or(not e.optional and not e.rmempty)then
e:write(t,a)
else
e:remove(t)
end
if(a~=o)then e.section.changed=true end
else
e:remove(t)
e.section.changed=true
end
end
function parse_url(t)
local e={}
t=string.gsub(t,"#(.*)$",
function(t)
e.fragment=t
return""
end)
t=string.gsub(t,"^([%w][%w%+%-%.]*)%:",
function(t)
e.scheme=string.lower(t);
return""
end)
t=string.gsub(t,"^//([^/]*)",
function(t)
e.authority=t
return""
end)
t=string.gsub(t,"%?(.*)",
function(t)
e.query=t
return""
end)
t=string.gsub(t,"%;(.*)",
function(t)
e.params=t
return""
end)
e.path=t
local t=e.authority
if not t then
return e
end
t=string.gsub(t,"^([^@]*)@",
function(t)
e.userinfo=t;
return""
end)
t=string.gsub(t,":([0-9]*)$",
function(t)
if t~=""then
e.port=t
end;
return""
end)
if t~=""then
e.host=t
end
local t=e.userinfo
if not t then
return e
end
t=string.gsub(t,":([^:]*)$",
function(t)
e.password=t;
return""
end)
e.user=t
return e
end
