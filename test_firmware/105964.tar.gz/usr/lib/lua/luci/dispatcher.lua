local n=require"nixio.fs"
local h=require"luci.sys"
local a=require"luci.util"
local e=require"luci.http"
local c=require"nixio",require"nixio.util"
module("luci.dispatcher",package.seeall)
context=a.threadlocal()
uci=require"luci.model.uci"
i18n=require"luci.i18n"
_M.fs=n
authenticator={}
local r=nil
local t
function build_url(...)
local i={...}
local t={e.getenv("SCRIPT_NAME")or""}
local a,a
for a,o in pairs(context.urltoken)do
t[#t+1]="/;"
t[#t+1]=e.urlencode(a)
t[#t+1]="="
t[#t+1]=e.urlencode(o)
end
local e
for a,e in ipairs(i)do
if e:match("^[a-zA-Z0-9_%-%.%%/,;]+$")then
t[#t+1]="/"
t[#t+1]=e
end
end
return table.concat(t,"")
end
function node_visible(e)
if e then
return not(
(not e.title or#e.title==0)or
(not e.target or e.hidden==true)or
(type(e.target)=="table"and e.target.type=="firstchild"and
(type(e.nodes)~="table"or not next(e.nodes)))
)
end
return false
end
function node_childs(e)
local t={}
if e then
local o,o
for e,a in a.spairs(e.nodes,
function(t,a)
return(e.nodes[t].order or 100)
<(e.nodes[a].order or 100)
end)
do
if node_visible(a)then
t[#t+1]=e
end
end
end
return t
end
function error404(t)
e.status(404,"Not Found")
t=t or"Not Found"
require("luci.template")
if not a.copcall(luci.template.render,"error404")then
e.prepare_content("text/plain")
e.write(t)
end
return false
end
function error500(t)
a.perror(t)
if not context.template_header_sent then
e.status(500,"Internal Server Error")
e.prepare_content("text/plain")
e.write(t)
else
require("luci.template")
if not a.copcall(luci.template.render,"error500",{message=t})then
e.prepare_content("text/plain")
e.write(t)
end
end
return false
end
function authenticator.htmlauth(i,t,o)
local t=e.formvalue("luci_username")
local a=e.formvalue("luci_password")
if t and i(t,a)then
return t
end
if context.urltoken.stok then
context.urltoken.stok=nil
local t='sysauth=%s; expires=%s; path=%s/'%{
e.getcookie('sysauth')or'x',
'Thu, 01 Jan 1970 01:00:00 GMT',
build_url()
}
e.header("Set-Cookie",t)
e.redirect(build_url())
else
require("luci.i18n")
require("luci.template")
context.path={}
e.status(403,"Forbidden")
luci.template.render("sysauth",{duser=o,fuser=t})
end
return false
end
function httpdispatch(o,i)
e.context.request=o
local t={}
context.request=t
context.urltoken={}
local o=e.urldecode(o:getenv("PATH_INFO")or"",true)
if i then
for a,e in ipairs(i)do
t[#t+1]=e
end
end
local i=true
for o in o:gmatch("[^/]+")do
local e,a
if i then
e,a=o:match(";(%w+)=([a-fA-F0-9]*)")
end
if e then
context.urltoken[e]=a
else
i=false
t[#t+1]=o
end
end
local t,t=a.coxpcall(function()
dispatch(context.request)
end,error500)
e.close()
end
function dispatch(s)
local o=context
o.path=s
local t=require"luci.config"
assert(t.main,
"/etc/config/luci seems to be corrupt, unable to find section 'main'")
local i=t.main.lang or"auto"
if i=="auto"then
local e=e.getenv("HTTP_ACCEPT_LANGUAGE")or""
for e in e:gmatch("[%w-]+")do
e=e and e:gsub("-","_")
if t.languages[e]then
i=e
break
end
end
end
require"luci.i18n".setlanguage(i)
local t=o.tree
local i
if not t then
t=createtree()
end
local i={}
local r={}
o.args=r
o.requestargs=o.requestargs or r
local u
local d=o.urltoken
local l={}
local d={}
for o,e in ipairs(s)do
l[#l+1]=e
d[#d+1]=e
t=t.nodes[e]
u=o
if not t then
break
end
a.update(i,t)
if t.leaf then
break
end
end
if t and t.leaf then
for e=u+1,#s do
r[#r+1]=s[e]
d[#d+1]=s[e]
end
end
o.requestpath=o.requestpath or d
o.path=l
if i.i18n then
i18n.loadc(i.i18n)
end
if(t and t.index)or not i.notemplate then
local s=require("luci.template")
local t=i.mediaurlbase or luci.config.main.mediaurlbase
if not pcall(s.Template,"themes/%s/header"%n.basename(t))then
t=nil
for a,e in pairs(luci.config.themes)do
if a:sub(1,1)~="."and pcall(s.Template,
"themes/%s/header"%n.basename(e))then
t=e
end
end
assert(t,"No valid theme found")
end
local function i(t,e,i)
if t then
local t=getfenv(3)
local o=(type(t.self)=="table")and t.self
return string.format(
' %s="%s"',tostring(e),
a.pcdata(tostring(i
or(type(t[e])~="function"and t[e])
or(o and type(o[e])~="function"and o[e])
or""))
)
else
return''
end
end
s.context.viewns=setmetatable({
write=e.write;
include=function(e)s.Template(e):render(getfenv(2))end;
translate=i18n.translate;
translatef=i18n.translatef;
export=function(e,t)if s.context.viewns[e]==nil then s.context.viewns[e]=t end end;
striptags=a.striptags;
pcdata=a.pcdata;
media=t;
theme=n.basename(t);
resource=luci.config.main.resourcebase;
ifattr=function(...)return i(...)end;
attr=function(...)return i(true,...)end;
},{__index=function(t,e)
if e=="controller"then
return build_url()
elseif e=="REQUEST_URI"then
return build_url(unpack(o.requestpath))
else
return rawget(t,e)or _G[e]
end
end})
end
i.dependent=(i.dependent~=false)
assert(not i.dependent or not i.auto,
"Access Violation\nThe page at '"..table.concat(s,"/").."/' "..
"has no parent node so the access to this location has been denied.\n"..
"This is a software bug, please report this message at "..
"http://luci.subsignal.org/trac/newticket"
)
if i.sysauth then
local n=type(i.sysauth_authenticator)=="function"
and i.sysauth_authenticator
or authenticator[i.sysauth_authenticator]
local d=(type(i.sysauth)=="string")and i.sysauth
local r=d and{i.sysauth}or i.sysauth
local t=o.authsession
local l=false
if not t then
t=e.getcookie("sysauth")
t=t and t:match("^[a-f0-9]*$")
l=true
end
local i=(a.ubus("session","get",{ubus_rpc_session=t})or{}).values
local s
if i then
if not l or o.urltoken.stok==i.token then
s=i.user
end
else
local t=e.getenv("HTTP_AUTH_USER")
local e=e.getenv("HTTP_AUTH_PASS")
if t and e and h.user.checkpasswd(t,e)then
n=function()return t end
end
end
if not a.contains(r,s)then
if n then
local i,t=n(h.user.checkpasswd,r,d)
local n
if not i or not a.contains(r,i)then
return
else
if not t then
local e=a.ubus("session","create",{timeout=tonumber(luci.config.sauth.sessiontime)})
if e then
n=h.uniqueid(16)
a.ubus("session","set",{
ubus_rpc_session=e.ubus_rpc_session,
values={
user=i,
token=n,
section=h.uniqueid(16)
}
})
t=e.ubus_rpc_session
end
end
if t and n then
e.header("Set-Cookie",'sysauth=%s; path=%s/'%{
t,build_url()
})
o.urltoken.stok=n
o.authsession=t
o.authuser=i
e.redirect(build_url(unpack(o.requestpath)))
end
end
else
e.status(403,"Forbidden")
return
end
else
o.authsession=t
o.authuser=s
end
end
if i.setgroup then
h.process.setgroup(i.setgroup)
end
if i.setuser then
a.ubus()
h.process.setuser(i.setuser)
end
local e=nil
if t then
if type(t.target)=="function"then
e=t.target
elseif type(t.target)=="table"then
e=t.target.target
end
end
if t and(t.index or type(e)=="function")then
o.dispatched=t
o.requested=o.requested or o.dispatched
end
if t and t.index then
local e=require"luci.template"
if a.copcall(e.render,"indexer",{})then
return true
end
end
if type(e)=="function"then
a.copcall(function()
local a=getfenv(e)
local t=require(t.module)
local t=setmetatable({},{__index=
function(o,e)
return rawget(o,e)or t[e]or a[e]
end})
setfenv(e,t)
end)
local i,o
if type(t.target)=="table"then
i,o=a.copcall(e,t.target,unpack(r))
else
i,o=a.copcall(e,unpack(r))
end
assert(i,
"Failed to execute "..(type(t.target)=="function"and"function"or t.target.type or"unknown")..
" dispatcher target for entry '/"..table.concat(s,"/").."'.\n"..
"The called action terminated with an exception:\n"..tostring(o or"(unknown)"))
else
local e=node()
if not e or not e.target then
error404("No root node was registered, this usually happens if no module was installed.\n"..
"Install luci-mod-admin-full and retry. "..
"If the module is already installed, try removing the /tmp/luci-indexcache file.")
else
error404("No page is registered at '/"..table.concat(s,"/").."'.\n"..
"If this url belongs to an extension, make sure it is properly installed.\n"..
"If the extension was recently installed, try removing the /tmp/luci-indexcache file.")
end
end
end
function createindex()
local e={}
local o="%s/controller/"%a.libpath()
local t,t
for t in(n.glob("%s*.lua"%o)or function()end)do
e[#e+1]=t
end
for t in(n.glob("%s*/*.lua"%o)or function()end)do
e[#e+1]=t
end
if indexcache then
local a=n.stat(indexcache,"mtime")
if a then
local t=0
for a,e in ipairs(e)do
local e=n.stat(e,"mtime")
t=(e and e>t)and e or t
end
if a>t and h.process.info("uid")==0 then
assert(
h.process.info("uid")==n.stat(indexcache,"uid")
and n.stat(indexcache,"modestr")=="rw-------",
"Fatal: Indexcache is not sane!"
)
r=loadfile(indexcache)()
return r
end
end
end
r={}
for t,e in ipairs(e)do
local t="luci.controller."..e:sub(#o+1,#e-4):gsub("/",".")
local a=require(t)
assert(a~=true,
"Invalid controller file found\n"..
"The file '"..e.."' contains an invalid module line.\n"..
"Please verify whether the module name is set to '"..t..
"' - It must correspond to the file path!")
local a=a.index
assert(type(a)=="function",
"Invalid controller file found\n"..
"The file '"..e.."' contains no index() function.\n"..
"Please make sure that the controller contains a valid "..
"index function and verify the spelling!")
r[t]=a
end
if indexcache then
local e=c.open(indexcache,"w",600)
e:writeall(a.get_bytecode(r))
e:close()
end
end
function createtree()
if not r then
createindex()
end
local t=context
local o={nodes={},inreq=true}
local e={}
t.treecache=setmetatable({},{__mode="v"})
t.tree=o
t.modifiers=e
require"luci.i18n".loadc("base")
local t=setmetatable({},{__index=luci.dispatcher})
for a,e in pairs(r)do
t._NAME=a
setfenv(e,t)
e()
end
local function i(a,t)
return e[a].order<e[t].order
end
for a,e in a.spairs(e,i)do
t._NAME=e.module
setfenv(e.func,t)
e.func()
end
return o
end
function modifier(e,t)
context.modifiers[#context.modifiers+1]={
func=e,
order=t or 0,
module
=getfenv(2)._NAME
}
end
function assign(e,t,o,a)
local e=node(unpack(e))
e.nodes=nil
e.module=nil
e.title=o
e.order=a
setmetatable(e,{__index=_create_node(t)})
return e
end
function entry(e,o,t,a)
local e=node(unpack(e))
e.target=o
e.title=t
e.order=a
e.module=getfenv(2)._NAME
return e
end
function get(...)
return _create_node({...})
end
function node(...)
local e=_create_node({...})
e.module=getfenv(2)._NAME
e.auto=nil
return e
end
function _create_node(t)
if#t==0 then
return context.tree
end
local i=table.concat(t,".")
local e=context.treecache[i]
if not e then
local o=table.remove(t)
local a=_create_node(t)
e={nodes={},auto=true}
if a.inreq and context.path[#t+1]==o then
e.inreq=true
end
a.nodes[o]=e
context.treecache[i]=e
end
return e
end
function _firstchild()
local a={unpack(context.path)}
local e=table.concat(a,".")
local t=context.treecache[e]
local e
if t and t.nodes and next(t.nodes)then
local a,a
for a,o in pairs(t.nodes)do
if not e or
(o.order or 100)<(t.nodes[e].order or 100)
then
e=a
end
end
end
assert(e~=nil,
"The requested node contains no childs, unable to redispatch")
a[#a+1]=e
dispatch(a)
end
function firstchild()
return{type="firstchild",target=_firstchild}
end
function alias(...)
local e={...}
return function(...)
for a,t in ipairs({...})do
e[#e+1]=t
end
dispatch(e)
end
end
function rewrite(t,...)
local o={...}
return function(...)
local e=a.clone(context.dispatched)
for t=1,t do
table.remove(e,1)
end
for t,a in ipairs(o)do
table.insert(e,t,a)
end
for a,t in ipairs({...})do
e[#e+1]=t
end
dispatch(e)
end
end
local function a(e,...)
local t=getfenv()[e.name]
assert(t~=nil,
'Cannot resolve function "'..e.name..'". Is it misspelled or local?')
assert(type(t)=="function",
'The symbol "'..e.name..'" does not refer to a function but data '..
'of type "'..type(t)..'".')
if#e.argv>0 then
return t(unpack(e.argv),...)
else
return t(...)
end
end
function call(e,...)
return{type="call",argv={...},name=e,target=a}
end
local e=function(e,...)
require"luci.template".render(e.view)
end
function template(t)
return{type="template",view=t,target=e}
end
local function d(e,...)
local o=require"luci.cbi"
local h=require"luci.template"
local a=require"luci.http"
local t=e.config or{}
local o=o.load(e.model,...)
local e=nil
for o,a in ipairs(o)do
a.flow=t
local t=a:parse()
if t and(not e or t<e)then
e=t
end
end
local function i(e)
return type(e)=="table"and build_url(unpack(e))or e
end
if t.on_valid_to and e and e>0 and e<2 then
a.redirect(i(t.on_valid_to))
return
end
if t.on_changed_to and e and e>1 then
a.redirect(i(t.on_changed_to))
return
end
if t.on_success_to and e and e>0 then
a.redirect(i(t.on_success_to))
return
end
if t.state_handler then
if not t.state_handler(e,o)then
return
end
end
a.header("X-CBI-State",e or 0)
if not t.noheader then
h.render("cbi/header",{state=e})
end
local i
local a
local r=false
local n=true
local s={}
for t,e in ipairs(o)do
if e.apply_needed and e.parsechain then
local t
for t,e in ipairs(e.parsechain)do
s[#s+1]=e
end
r=true
end
if e.redirect then
i=i or e.redirect
end
if e.pageaction==false then
n=false
end
if e.message then
a=a or{}
a[#a+1]=e.message
end
end
for e,t in ipairs(o)do
t:render({
firstmap=(e==1),
applymap=r,
redirect=i,
messages=a,
pageaction=n,
parsechain=s
})
end
if not t.nofooter then
h.render("cbi/footer",{
flow=t,
pageaction=n,
redirect=i,
state=e,
autoapply=t.autoapply
})
end
end
function cbi(e,t)
return{type="cbi",config=t,model=e,target=d}
end
local function o(e,...)
local t={...}
local a=#t>0 and e.targets[2]or e.targets[1]
setfenv(a.target,e.env)
a:target(unpack(t))
end
function arcombine(t,e)
return{type="arcombine",env=getfenv(),target=o,targets={t,e}}
end
local function i(e,...)
local t=require"luci.cbi"
local o=require"luci.template"
local i=require"luci.http"
local a=luci.cbi.load(e.model,...)
local e=nil
for a,t in ipairs(a)do
local t=t:parse()
if t and(not e or t<e)then
e=t
end
end
i.header("X-CBI-State",e or 0)
o.render("header")
for t,e in ipairs(a)do
e:render()
end
o.render("footer")
end
function form(e)
return{type="cbi",model=e,target=i}
end
translate=i18n.translate
function _(e)
return e
end
