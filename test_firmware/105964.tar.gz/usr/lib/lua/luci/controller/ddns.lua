module("luci.controller.ddns",package.seeall)
local u=require"nixio"
local w=require"nixio.fs"
local o=require"luci.dispatcher"
local t=require"luci.http"
local f=require"luci.model.uci"
local c=require"luci.sys"
local a=require"luci.tools.ddns"
local e=require"luci.util"
DDNS_MIN="2.4.2-1"
function index()
local e=require"nixio.fs"
local t=require"luci.sys"
local t=require"luci.tools.ddns"
local a=t.ipkg_ver_installed("ddns-scripts")
local t=t.ipkg_ver_compare(a,">=","2.0.0-0")
if not t then
return
end
if not e.access("/etc/config/ddns")then
e.writefile("/etc/config/ddns","")
end
entry({"admin","services","ddns"},cbi("ddns/overview"),_("Dynamic DNS"),59)
entry({"admin","services","ddns","detail"},cbi("ddns/detail"),nil).leaf=true
entry({"admin","services","ddns","hints"},cbi("ddns/hints",
{hideapplybtn=true,hidesavebtn=true,hideresetbtn=true}),nil).leaf=true
entry({"admin","services","ddns","global"},cbi("ddns/global"),nil).leaf=true
entry({"admin","services","ddns","logview"},call("logread")).leaf=true
entry({"admin","services","ddns","startstop"},call("startstop")).leaf=true
entry({"admin","services","ddns","status"},call("status")).leaf=true
end
local function m()
local u=f.cursor()
local e=c.init.enabled("ddns")and 1 or 0
local t=o.build_url("admin","system","startup")
local i={}
i[#i+1]={
enabled=e,
url_up=t,
}
u:foreach("ddns","service",function(e)
local l=e[".name"]
local r=tonumber(e["enabled"])or 0
local d="_empty_"
local t="_empty_"
local o=a.calc_seconds(
tonumber(e["force_interval"])or 72,
e["force_unit"]or"hours")
local h=a.get_pid(l)
local s=c.uptime()
local n=a.get_lastupd(l)
if n>s then
n=0
end
if n==0 then
d="_never_"
else
local e=os.time()-s+n
d=a.epoch2date(e)
t=a.epoch2date(e+o)
end
o=(o>s)and s or o
if h>0 and(n+o-s)<=0 then
t="_verify_"
elseif o==0 then
t="_runonce_"
elseif h==0 and r==0 then
t="_disabled_"
elseif h==0 and r~=0 then
t="_stopped_"
end
local a=e["interface"]or"_nonet_"
local n=tonumber(e["use_ipv6"])or 0
if a~="_nonet_"then
local e=(n==1)and"IPv6"or"IPv4"
a=e.." / "..a
end
local o=e["domain"]or"_nodomain_"
local s=e["dns_server"]or""
local m=tonumber(e["force_ipversion"]or 0)
local u=tonumber(e["force_dnstcp"]or 0)
local e=[[/usr/lib/ddns/dynamic_dns_lucihelper.sh]]
e=e..[[ get_registered_ip ]]..o..[[ ]]..n..
[[ ]]..m..[[ ]]..u..[[ ]]..s
local e=c.exec(e)
if e==""then
e="_nodata_"
end
i[#i+1]={
section=l,
enabled=r,
iface=a,
domain=o,
reg_ip=e,
pid=h,
datelast=d,
datenext=t
}
end)
u:unload("ddns")
return i
end
function logread(e)
local a=f.cursor()
local o=a:get("ddns","global","log_dir")or"/var/log/ddns"
local e=o.."/"..e..".log"
local e=w.readfile(e)
if not e or#e==0 then
e="_nodata_"
end
a:unload("ddns")
t.write(e)
end
function startstop(o,s)
local e=f.cursor()
local i=a.get_pid(o)
local a={}
if i>0 then
local e=u.kill(i,15)
u.nanosleep(2)
a=m()
t.prepare_content("application/json")
t.write_json(a)
return
end
local i=true
local n=e:changes("ddns")
for e,t in pairs(n)do
if e~="ddns"then
i=false
break
end
for t,e in pairs(t)do
if t~=o then
i=false
break
end
for e,t in pairs(e)do
if e~="enabled"then
i=false
break
end
end
end
end
if not i then
t.write("_uncommitted_")
return
end
e:set("ddns",o,"enabled",((s=="true")and"1"or"0"))
e:save("ddns")
e:commit("ddns")
e:unload("ddns")
os.execute([[/usr/lib/ddns/dynamic_dns_updater.sh %s 0 > /dev/null 2>&1 &]]%o)
u.nanosleep(3)
a=m()
t.prepare_content("application/json")
t.write_json(a)
end
function status()
local e=m()
t.prepare_content("application/json")
t.write_json(e)
end
