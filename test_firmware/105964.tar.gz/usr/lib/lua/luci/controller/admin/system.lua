module("luci.controller.admin.system",package.seeall)
function index()
local e=require"nixio.fs"
entry({"admin","system"},alias("admin","system","system"),_("System"),30).index=true
entry({"admin","system","system"},cbi("admin_system/system"),_("System"),1)
entry({"admin","system","clock_status"},call("action_clock_status"))
entry({"admin","system","admin"},cbi("admin_system/admin"),_("Administration"),2)
if e.access("/bin/opkg")then
entry({"admin","system","packages"},call("action_packages"),_("Software"),10)
entry({"admin","system","packages","ipkg"},form("admin_system/ipkg"))
end
entry({"admin","system","startup"},form("admin_system/startup"),_("Startup"),45)
entry({"admin","system","crontab"},form("admin_system/crontab"),_("Scheduled Tasks"),46)
if e.access("/sbin/block")then
entry({"admin","system","fstab"},cbi("admin_system/fstab"),_("Mount Points"),50)
entry({"admin","system","fstab","mount"},cbi("admin_system/fstab/mount"),nil).leaf=true
entry({"admin","system","fstab","swap"},cbi("admin_system/fstab/swap"),nil).leaf=true
end
if e.access("/sys/class/leds")then
entry({"admin","system","leds"},cbi("admin_system/leds"),_("<abbr title=\"Light Emitting Diode\">LED</abbr> Configuration"),60)
end
entry({"admin","system","flashops"},call("action_flashops"),_("Backup / Flash Firmware"),70)
entry({"admin","system","flashops","backupfiles"},form("admin_system/backupfiles"))
entry({"admin","system","reboot"},call("action_reboot"),_("Reboot"),90)
end
function action_clock_status()
local e=tonumber(luci.http.formvalue("set"))
if e~=nil and e>0 then
local e=os.date("*t",e)
if e then
luci.sys.call("date -s '%04d-%02d-%02d %02d:%02d:%02d'"%{
e.year,e.month,e.day,e.hour,e.min,e.sec
})
end
end
luci.http.prepare_content("application/json")
luci.http.write_json({timestring=os.date("%c")})
end
function action_packages()
local r=require"nixio.fs"
local n=require"luci.model.ipkg"
local c=luci.http.formvalue("submit")
local h=false
local m={}
local f={}
local e={""}
local t={""}
local o,a
local w=luci.http.formvalue("display")or"installed"
local i=string.byte(luci.http.formvalue("letter")or"A",1)
i=(i==35 or(i>=65 and i<=90))and i or 65
local s=luci.http.formvalue("query")
s=(s~='')and s or nil
local l=c and luci.http.formvalue("install")
local d=nil
local u=luci.http.formvalue("url")
if u and u~=''and c then
d=u
end
if l then
m[l],o,a=n.install(l)
e[#e+1]=o
t[#t+1]=a
h=true
end
if d then
local i
for i in luci.util.imatch(d)do
m[d],o,a=n.install(i)
e[#e+1]=o
t[#t+1]=a
h=true
end
end
local d=c and luci.http.formvalue("remove")
if d then
f[d],o,a=n.remove(d)
e[#e+1]=o
t[#t+1]=a
h=true
end
local l=luci.http.formvalue("update")
if l then
l,o,a=n.update()
e[#e+1]=o
t[#t+1]=a
end
local d=luci.http.formvalue("upgrade")
if d then
d,o,a=n.upgrade()
e[#e+1]=o
t[#t+1]=a
end
local o=true
local a=false
if r.access("/var/opkg-lists/")then
local e
for e in r.dir("/var/opkg-lists/")do
o=false
if(r.stat("/var/opkg-lists/"..e,"mtime")or 0)<(os.time()-(24*60*60))then
a=true
break
end
end
end
luci.template.render("admin_system/packages",{
display=w,
letter=i,
query=s,
install=m,
remove=f,
update=l,
upgrade=d,
no_lists=o,
old_lists=a,
stdout=table.concat(e,""),
stderr=table.concat(t,"")
})
if h then
r.unlink("/tmp/luci-indexcache")
end
end
function action_flashops()
local e=require"luci.sys"
local t=require"nixio.fs"
local i=t.access("/lib/upgrade/platform.sh")
local o=os.execute([[grep '"rootfs_data"' /proc/mtd >/dev/null 2>&1]])==0
local s="tar -xzC/ >/dev/null 2>&1"
local r="sysupgrade --create-backup - 2>/dev/null"
local e="/tmp/firmware.img"
local function n()
return(os.execute("sysupgrade -T %q >/dev/null"%e)==0)
end
local function h()
return(luci.sys.exec("md5sum %q"%e):match("^([^%s]+)"))
end
local function d()
local e=0
if t.access("/proc/mtd")then
for t in io.lines("/proc/mtd")do
local o,a,o,t=t:match('^([^%s]+)%s+([^%s]+)%s+([^%s]+)%s+"([^%s]+)"')
if t=="linux"or t=="firmware"then
e=tonumber(a,16)
break
end
end
elseif t.access("/proc/partitions")then
for t in io.lines("/proc/partitions")do
local o,o,a,t=t:match('^%s*(%d+)%s+(%d+)%s+([^%s]+)%s+([^%s]+)')
if a and t and not t:match('[0-9]')then
e=tonumber(a)*1024
break
end
end
end
return e
end
local a
luci.http.setfilehandler(
function(o,t,i)
if not a then
if o and o.name=="image"then
a=io.open(e,"w")
else
a=io.popen(s,"w")
end
end
if t then
a:write(t)
end
if i then
a:close()
end
end
)
if luci.http.formvalue("backup")then
local e=ltn12_popen(r)
luci.http.header('Content-Disposition','attachment; filename="backup-%s-%s.tar.gz"'%{
luci.sys.hostname(),os.date("%Y-%m-%d")})
luci.http.prepare_content("application/x-targz")
luci.ltn12.pump.all(e,luci.http.write)
elseif luci.http.formvalue("restore")then
local e=luci.http.formvalue("archive")
if e and#e>0 then
luci.template.render("admin_system/applyreboot")
luci.sys.reboot()
end
elseif luci.http.formvalue("image")or luci.http.formvalue("step")then
local a=tonumber(luci.http.formvalue("step")or 1)
if a==1 then
if n()then
luci.template.render("admin_system/upgrade",{
checksum=h(),
storage=d(),
size=(t.stat(e,"size")or 0),
keep=(not not luci.http.formvalue("keep"))
})
else
t.unlink(e)
luci.template.render("admin_system/flashops",{
reset_avail=o,
upgrade_avail=i,
image_invalid=true
})
end
elseif a==2 then
local t=(luci.http.formvalue("keep")=="1")and""or"-n"
luci.template.render("admin_system/applyreboot",{
title=luci.i18n.translate("Flashing..."),
msg=luci.i18n.translate("The system is flashing now.<br /> DO NOT POWER OFF THE DEVICE!<br /> Wait a few minutes before you try to reconnect. It might be necessary to renew the address of your computer to reach the device again, depending on your settings."),
addr=(#t>0)and"192.168.1.1"or nil
})
fork_exec("killall dropbear uhttpd; sleep 1; /sbin/sysupgrade %s %q"%{t,e})
end
elseif o and luci.http.formvalue("reset")then
luci.template.render("admin_system/applyreboot",{
title=luci.i18n.translate("Erasing..."),
msg=luci.i18n.translate("The system is erasing the configuration partition now and will reboot itself when finished."),
addr="192.168.1.1"
})
fork_exec("killall dropbear uhttpd; sleep 1; mtd -r erase rootfs_data")
else
luci.template.render("admin_system/flashops",{
reset_avail=o,
upgrade_avail=i
})
end
end
function action_passwd()
local t=luci.http.formvalue("pwd1")
local a=luci.http.formvalue("pwd2")
local e=nil
if t or a then
if t==a then
e=luci.sys.user.setpasswd("root",t)
else
e=10
end
end
luci.template.render("admin_system/passwd",{stat=e})
end
function action_reboot()
local e=luci.http.formvalue("reboot")
luci.template.render("admin_system/reboot",{reboot=e})
if e then
luci.sys.reboot()
end
end
function fork_exec(t)
local e=nixio.fork()
if e>0 then
return
elseif e==0 then
nixio.chdir("/")
local e=nixio.open("/dev/null","w+")
if e then
nixio.dup(e,nixio.stderr)
nixio.dup(e,nixio.stdout)
nixio.dup(e,nixio.stdin)
if e:fileno()>2 then
e:close()
end
end
nixio.exec("/bin/sh","-c",t)
end
end
function ltn12_popen(i)
local e,t=nixio.pipe()
local o=nixio.fork()
if o>0 then
t:close()
local t
return function()
local a=e:read(2048)
local i,o=nixio.waitpid(o,"nohang")
if not t and i and o=="exited"then
t=true
end
if a and#a>0 then
return a
elseif t then
e:close()
return nil
end
end
elseif o==0 then
nixio.dup(t,nixio.stdout)
e:close()
t:close()
nixio.exec("/bin/sh","-c",i)
end
end
