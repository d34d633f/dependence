module("luci.controller.p910nd",package.seeall)
function index()
if not nixio.fs.access("/etc/config/p910nd")then
return
end
local e
e=entry({"admin","services","p910nd"},cbi("p910nd"),_("p910nd - Printer server"),60)
e.dependent=true
end
