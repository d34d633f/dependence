module("luci.controller.hd_idle",package.seeall)
function index()
if not nixio.fs.access("/etc/config/hd-idle")then
return
end
local e
e=entry({"admin","services","hd_idle"},cbi("hd_idle"),_("hd-idle"),60)
e.dependent=true
end
