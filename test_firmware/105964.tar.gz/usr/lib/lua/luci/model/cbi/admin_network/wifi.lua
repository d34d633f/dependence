local e=require"luci.tools.webadmin"
local h=require"luci.model.network"
local w=require"luci.util"
local u=require"luci.sys".net
local r=require"nixio.fs"
arg[1]=arg[1]or""
m=Map("wireless","",
translate("The <em>Device Configuration</em> section covers physical settings of the radio "..
"hardware such as channel, transmit power or antenna selection which are shared among all "..
"defined wireless networks (if the radio hardware is multi-SSID capable). Per network settings "..
"like encryption or operation mode are grouped in the <em>Interface Configuration</em>."))
m:chain("network")
m:chain("firewall")
m.redirect=luci.dispatcher.build_url("admin/network/wireless")
local l
function m.on_commit(e)
local e=h:get_wifinet(arg[1])
if l and e then
l.section=e.sid
m.title=luci.util.pcdata(e:get_i18n())
end
end
h.init(m.uci)
local i=h:get_wifinet(arg[1])
local a=i and i:get_device()
if not i or not a then
luci.http.redirect(luci.dispatcher.build_url("admin/network/wireless"))
return
end
function m.parse(e)
if m:formvalue("cbid.wireless.%s.__toggle"%a:name())then
if a:get("disabled")=="1"or i:get("disabled")=="1"then
i:set("disabled",nil)
else
i:set("disabled","1")
end
a:set("disabled",nil)
h:commit("wireless")
luci.sys.call("(env -i /bin/ubus call network reload) >/dev/null 2>/dev/null")
luci.http.redirect(luci.dispatcher.build_url("admin/network/wireless",arg[1]))
return
end
Map.parse(e)
end
m.title=luci.util.pcdata(i:get_i18n())
local function n(e)
local a=e.txpwrlist or{}
local e=tonumber(e.txpower_offset)or 0
local t={}
local i=-1
local o,o
for o,a in ipairs(a)do
local o=a.dbm+e
local e=math.floor(10^(o/10))
if e~=i then
i=e
t[#t+1]={
display_dbm=o,
display_mw=e,
driver_dbm=a.dbm,
driver_mw=a.mw
}
end
end
return t
end
local function d(t,e)
t=tonumber(t)
if t~=nil then
local a,a
for a,e in ipairs(e)do
if e.driver_dbm>=t then
return e.driver_dbm
end
end
end
return(e[#e]and e[#e].driver_dbm)or t or 0
end
local t=luci.sys.wifi.getiwinfo(arg[1])
local e=t.hwmodelist or{}
local o=n(t)
local c=d(a:get("txpower"),o)
s=m:section(NamedSection,a:name(),"wifi-device",translate("Device Configuration"))
s.addremove=false
s:tab("general",translate("General Setup"))
s:tab("macfilter",translate("MAC-Filter"))
s:tab("advanced",translate("Advanced Settings"))
st=s:taboption("general",DummyValue,"__status",translate("Status"))
st.template="admin_network/wifi_status"
st.ifname=arg[1]
en=s:taboption("general",Button,"__toggle")
if a:get("disabled")=="1"or i:get("disabled")=="1"then
en.title=translate("Wireless network is disabled")
en.inputtitle=translate("Enable")
en.inputstyle="apply"
else
en.title=translate("Wireless network is enabled")
en.inputtitle=translate("Disable")
en.inputstyle="reset"
end
local e=a:get("type")
local f=a:get("antenna")
local n=nil
local y,y
if i:mode()~="sta"then
for t,e in ipairs(a:get_wifinets())do
if e:mode()=="sta"then
if not n then
n={}
n.channel=e:channel()
n.names={}
end
n.names[#n.names+1]=e:shortname()
end
end
end
if n then
ch=s:taboption("general",DummyValue,"choice",translate("Channel"))
ch.value=translatef("Locked to channel %d used by: %s",
n.channel,table.concat(n.names,", "))
else
ch=s:taboption("general",Value,"_mode_freq",'<br />'..translate("Operating frequency"))
ch.hwmodes=t.hwmodelist
ch.freqlist=t.freqlist
ch.template="cbi/wireless_modefreq"
function ch.cfgvalue(t,e)
return{
m:get(e,"hwmode")or"",
m:get(e,"channel")or"auto",
m:get(e,"htmode")or""
}
end
function ch.formvalue(e,a)
return{
m:formvalue(e:cbid(a)..".band")or(t.hwmodelist.g and"11g"or"11a"),
m:formvalue(e:cbid(a)..".channel")or"auto",
m:formvalue(e:cbid(a)..".htmode")or""
}
end
function ch.write(a,t,e)
m:set(t,"hwmode",e[1])
m:set(t,"channel",e[2])
m:set(t,"htmode",e[3])
end
end
if e=="mac80211"then
if#o>1 then
tp=s:taboption("general",ListValue,
"txpower",translate("Transmit Power"),"dBm")
tp.rmempty=true
tp.default=c
function tp.cfgvalue(...)
return d(Value.cfgvalue(...),o)
end
for t,e in ipairs(o)do
tp:value(e.driver_dbm,"%i dBm (%i mW)"
%{e.display_dbm,e.display_mw})
end
end
local e=t and t.countrylist
if e and#e>0 then
cc=s:taboption("advanced",ListValue,"country",translate("Country Code"),translate("Use ISO/IEC 3166 alpha2 country codes."))
cc.default=tostring(t and t.country or"00")
for t,e in ipairs(e)do
cc:value(e.alpha2,"%s - %s"%{e.alpha2,e.name})
end
else
s:taboption("advanced",Value,"country",translate("Country Code"),translate("Use ISO/IEC 3166 alpha2 country codes."))
end
s:taboption("advanced",Value,"distance",translate("Distance Optimization"),
translate("Distance to farthest network member in meters."))
local e=t and t.extant
if e and#e>0 then
ea=s:taboption("advanced",ListValue,"extant",translate("Antenna Configuration"))
for t,e in ipairs(e)do
ea:value(e.id,"%s (%s)"%{e.name,e.description})
if e.selected then
ea.default=e.id
end
end
end
s:taboption("advanced",Value,"frag",translate("Fragmentation Threshold"))
s:taboption("advanced",Value,"rts",translate("RTS/CTS Threshold"))
end
if e=="atheros"then
tp=s:taboption("general",
(#o>0)and ListValue or Value,
"txpower",translate("Transmit Power"),"dBm")
tp.rmempty=true
tp.default=c
function tp.cfgvalue(...)
return d(Value.cfgvalue(...),o)
end
for t,e in ipairs(o)do
tp:value(e.driver_dbm,"%i dBm (%i mW)"
%{e.display_dbm,e.display_mw})
end
s:taboption("advanced",Flag,"diversity",translate("Diversity")).rmempty=false
if not f then
ant1=s:taboption("advanced",ListValue,"txantenna",translate("Transmitter Antenna"))
ant1.widget="radio"
ant1.orientation="horizontal"
ant1:depends("diversity","")
ant1:value("0",translate("auto"))
ant1:value("1",translate("Antenna 1"))
ant1:value("2",translate("Antenna 2"))
ant2=s:taboption("advanced",ListValue,"rxantenna",translate("Receiver Antenna"))
ant2.widget="radio"
ant2.orientation="horizontal"
ant2:depends("diversity","")
ant2:value("0",translate("auto"))
ant2:value("1",translate("Antenna 1"))
ant2:value("2",translate("Antenna 2"))
else
local e=s:taboption("advanced",ListValue,"antenna",translate("Transmitter Antenna"))
e:value("auto")
e:value("vertical")
e:value("horizontal")
e:value("external")
end
s:taboption("advanced",Value,"distance",translate("Distance Optimization"),
translate("Distance to farthest network member in meters."))
s:taboption("advanced",Value,"regdomain",translate("Regulatory Domain"))
s:taboption("advanced",Value,"country",translate("Country Code"))
s:taboption("advanced",Flag,"outdoor",translate("Outdoor Channels"))
end
if e=="broadcom"then
tp=s:taboption("general",
(#o>0)and ListValue or Value,
"txpower",translate("Transmit Power"),"dBm")
tp.rmempty=true
tp.default=c
function tp.cfgvalue(...)
return d(Value.cfgvalue(...),o)
end
for t,e in ipairs(o)do
tp:value(e.driver_dbm,"%i dBm (%i mW)"
%{e.display_dbm,e.display_mw})
end
ant1=s:taboption("advanced",ListValue,"txantenna",translate("Transmitter Antenna"))
ant1.widget="radio"
ant1:depends("diversity","")
ant1:value("3",translate("auto"))
ant1:value("0",translate("Antenna 1"))
ant1:value("1",translate("Antenna 2"))
ant2=s:taboption("advanced",ListValue,"rxantenna",translate("Receiver Antenna"))
ant2.widget="radio"
ant2:depends("diversity","")
ant2:value("3",translate("auto"))
ant2:value("0",translate("Antenna 1"))
ant2:value("1",translate("Antenna 2"))
s:taboption("advanced",Flag,"frameburst",translate("Frame Bursting"))
s:taboption("advanced",Value,"distance",translate("Distance Optimization"))
s:taboption("advanced",Value,"country",translate("Country Code"))
s:taboption("advanced",Value,"maxassoc",translate("Connection Limit"))
end
if e=="prism2"then
s:taboption("advanced",Value,"txpower",translate("Transmit Power"),"att units").rmempty=true
s:taboption("advanced",Flag,"diversity",translate("Diversity")).rmempty=false
s:taboption("advanced",Value,"txantenna",translate("Transmitter Antenna"))
s:taboption("advanced",Value,"rxantenna",translate("Receiver Antenna"))
end
s=m:section(NamedSection,i.sid,"wifi-iface",translate("Interface Configuration"))
l=s
s.addremove=false
s.anonymous=true
s.defaults.device=a:name()
s:tab("general",translate("General Setup"))
s:tab("encryption",translate("Wireless Security"))
s:tab("macfilter",translate("MAC-Filter"))
s:tab("advanced",translate("Advanced Settings"))
s:taboption("general",Value,"ssid",translate("<abbr title=\"Extended Service Set Identifier\">ESSID</abbr>"))
mode=s:taboption("general",ListValue,"mode",translate("Mode"))
mode.override_values=true
mode:value("ap",translate("Access Point"))
mode:value("sta",translate("Client"))
mode:value("adhoc",translate("Ad-Hoc"))
bssid=s:taboption("general",Value,"bssid",translate("<abbr title=\"Basic Service Set Identifier\">BSSID</abbr>"))
network=s:taboption("general",Value,"network",translate("Network"),
translate("Choose the network(s) you want to attach to this wireless interface or "..
"fill out the <em>create</em> field to define a new network."))
network.rmempty=true
network.template="cbi/network_netlist"
network.widget="checkbox"
network.novirtual=true
function network.write(o,a,t)
local e=h:get_interface(a)
if e then
if t=='-'then
t=m:formvalue(o:cbid(a)..".newnet")
if t and#t>0 then
local t=h:add_network(t,{proto="none"})
if t then t:add_interface(e)end
else
local t=e:get_network()
if t then t:del_interface(e)end
end
else
local a
for a,t in ipairs(e:get_networks())do
t:del_interface(e)
end
for t in w.imatch(t)do
local t=h:get_network(t)
if t then
if not t:is_empty()then
t:set("type","bridge")
end
t:add_interface(e)
end
end
end
end
end
if e=="mac80211"then
if r.access("/usr/sbin/iw")then
mode:value("mesh","802.11s")
end
mode:value("ahdemo",translate("Pseudo Ad-Hoc (ahdemo)"))
mode:value("monitor",translate("Monitor"))
bssid:depends({mode="adhoc"})
bssid:depends({mode="sta"})
bssid:depends({mode="sta-wds"})
mp=s:taboption("macfilter",ListValue,"macfilter",translate("MAC-Address Filter"))
mp:depends({mode="ap"})
mp:depends({mode="ap-wds"})
mp:value("",translate("disable"))
mp:value("allow",translate("Allow listed only"))
mp:value("deny",translate("Allow all except listed"))
ml=s:taboption("macfilter",DynamicList,"maclist",translate("MAC-List"))
ml.datatype="macaddr"
ml:depends({macfilter="allow"})
ml:depends({macfilter="deny"})
u.mac_hints(function(e,t)ml:value(e,"%s (%s)"%{e,t})end)
mode:value("ap-wds","%s (%s)"%{translate("Access Point"),translate("WDS")})
mode:value("sta-wds","%s (%s)"%{translate("Client"),translate("WDS")})
function mode.write(t,e,a)
if a=="ap-wds"then
ListValue.write(t,e,"ap")
m.uci:set("wireless",e,"wds",1)
elseif a=="sta-wds"then
ListValue.write(t,e,"sta")
m.uci:set("wireless",e,"wds",1)
else
ListValue.write(t,e,a)
m.uci:delete("wireless",e,"wds")
end
end
function mode.cfgvalue(e,t)
local e=ListValue.cfgvalue(e,t)
local t=m.uci:get("wireless",t,"wds")=="1"
if e=="ap"and t then
return"ap-wds"
elseif e=="sta"and t then
return"sta-wds"
else
return e
end
end
hidden=s:taboption("general",Flag,"hidden",translate("Hide <abbr title=\"Extended Service Set Identifier\">ESSID</abbr>"))
hidden:depends({mode="ap"})
hidden:depends({mode="ap-wds"})
wmm=s:taboption("general",Flag,"wmm",translate("WMM Mode"))
wmm:depends({mode="ap"})
wmm:depends({mode="ap-wds"})
wmm.default=wmm.enabled
end
if e=="atheros"then
mode:value("ahdemo",translate("Pseudo Ad-Hoc (ahdemo)"))
mode:value("monitor",translate("Monitor"))
mode:value("ap-wds","%s (%s)"%{translate("Access Point"),translate("WDS")})
mode:value("sta-wds","%s (%s)"%{translate("Client"),translate("WDS")})
mode:value("wds",translate("Static WDS"))
function mode.write(t,e,a)
if a=="ap-wds"then
ListValue.write(t,e,"ap")
m.uci:set("wireless",e,"wds",1)
elseif a=="sta-wds"then
ListValue.write(t,e,"sta")
m.uci:set("wireless",e,"wds",1)
else
ListValue.write(t,e,a)
m.uci:delete("wireless",e,"wds")
end
end
function mode.cfgvalue(e,t)
local e=ListValue.cfgvalue(e,t)
local t=m.uci:get("wireless",t,"wds")=="1"
if e=="ap"and t then
return"ap-wds"
elseif e=="sta"and t then
return"sta-wds"
else
return e
end
end
bssid:depends({mode="adhoc"})
bssid:depends({mode="ahdemo"})
bssid:depends({mode="wds"})
wdssep=s:taboption("advanced",Flag,"wdssep",translate("Separate WDS"))
wdssep:depends({mode="ap-wds"})
s:taboption("advanced",Flag,"doth","802.11h")
hidden=s:taboption("general",Flag,"hidden",translate("Hide <abbr title=\"Extended Service Set Identifier\">ESSID</abbr>"))
hidden:depends({mode="ap"})
hidden:depends({mode="adhoc"})
hidden:depends({mode="ap-wds"})
hidden:depends({mode="sta-wds"})
isolate=s:taboption("advanced",Flag,"isolate",translate("Separate Clients"),
translate("Prevents client-to-client communication"))
isolate:depends({mode="ap"})
s:taboption("advanced",Flag,"bgscan",translate("Background Scan"))
mp=s:taboption("macfilter",ListValue,"macpolicy",translate("MAC-Address Filter"))
mp:value("",translate("disable"))
mp:value("allow",translate("Allow listed only"))
mp:value("deny",translate("Allow all except listed"))
ml=s:taboption("macfilter",DynamicList,"maclist",translate("MAC-List"))
ml.datatype="macaddr"
ml:depends({macpolicy="allow"})
ml:depends({macpolicy="deny"})
u.mac_hints(function(e,t)ml:value(e,"%s (%s)"%{e,t})end)
s:taboption("advanced",Value,"rate",translate("Transmission Rate"))
s:taboption("advanced",Value,"mcast_rate",translate("Multicast Rate"))
s:taboption("advanced",Value,"frag",translate("Fragmentation Threshold"))
s:taboption("advanced",Value,"rts",translate("RTS/CTS Threshold"))
s:taboption("advanced",Value,"minrate",translate("Minimum Rate"))
s:taboption("advanced",Value,"maxrate",translate("Maximum Rate"))
s:taboption("advanced",Flag,"compression",translate("Compression"))
s:taboption("advanced",Flag,"bursting",translate("Frame Bursting"))
s:taboption("advanced",Flag,"turbo",translate("Turbo Mode"))
s:taboption("advanced",Flag,"ff",translate("Fast Frames"))
s:taboption("advanced",Flag,"wmm",translate("WMM Mode"))
s:taboption("advanced",Flag,"xr",translate("XR Support"))
s:taboption("advanced",Flag,"ar",translate("AR Support"))
local e=s:taboption("advanced",Flag,"sw_merge",translate("Disable HW-Beacon timer"))
e:depends({mode="adhoc"})
local e=s:taboption("advanced",Flag,"nosbeacon",translate("Disable HW-Beacon timer"))
e:depends({mode="sta"})
e:depends({mode="sta-wds"})
local e=s:taboption("advanced",Flag,"probereq",translate("Do not send probe responses"))
e.enabled="0"
e.disabled="1"
end
if e=="broadcom"then
mode:value("wds",translate("WDS"))
mode:value("monitor",translate("Monitor"))
hidden=s:taboption("general",Flag,"hidden",translate("Hide <abbr title=\"Extended Service Set Identifier\">ESSID</abbr>"))
hidden:depends({mode="ap"})
hidden:depends({mode="adhoc"})
hidden:depends({mode="wds"})
isolate=s:taboption("advanced",Flag,"isolate",translate("Separate Clients"),
translate("Prevents client-to-client communication"))
isolate:depends({mode="ap"})
s:taboption("advanced",Flag,"doth","802.11h")
s:taboption("advanced",Flag,"wmm",translate("WMM Mode"))
bssid:depends({mode="wds"})
bssid:depends({mode="adhoc"})
end
if e=="prism2"then
mode:value("wds",translate("WDS"))
mode:value("monitor",translate("Monitor"))
hidden=s:taboption("general",Flag,"hidden",translate("Hide <abbr title=\"Extended Service Set Identifier\">ESSID</abbr>"))
hidden:depends({mode="ap"})
hidden:depends({mode="adhoc"})
hidden:depends({mode="wds"})
bssid:depends({mode="sta"})
mp=s:taboption("macfilter",ListValue,"macpolicy",translate("MAC-Address Filter"))
mp:value("",translate("disable"))
mp:value("allow",translate("Allow listed only"))
mp:value("deny",translate("Allow all except listed"))
ml=s:taboption("macfilter",DynamicList,"maclist",translate("MAC-List"))
ml:depends({macpolicy="allow"})
ml:depends({macpolicy="deny"})
u.mac_hints(function(e,t)ml:value(e,"%s (%s)"%{e,t})end)
s:taboption("advanced",Value,"rate",translate("Transmission Rate"))
s:taboption("advanced",Value,"frag",translate("Fragmentation Threshold"))
s:taboption("advanced",Value,"rts",translate("RTS/CTS Threshold"))
end
encr=s:taboption("encryption",ListValue,"encryption",translate("Encryption"))
encr.override_values=true
encr.override_depends=true
encr:depends({mode="ap"})
encr:depends({mode="sta"})
encr:depends({mode="adhoc"})
encr:depends({mode="ahdemo"})
encr:depends({mode="ap-wds"})
encr:depends({mode="sta-wds"})
encr:depends({mode="mesh"})
cipher=s:taboption("encryption",ListValue,"cipher",translate("Cipher"))
cipher:depends({encryption="wpa"})
cipher:depends({encryption="wpa2"})
cipher:depends({encryption="psk"})
cipher:depends({encryption="psk2"})
cipher:depends({encryption="wpa-mixed"})
cipher:depends({encryption="psk-mixed"})
cipher:value("auto",translate("auto"))
cipher:value("ccmp",translate("Force CCMP (AES)"))
cipher:value("tkip",translate("Force TKIP"))
cipher:value("tkip+ccmp",translate("Force TKIP and CCMP (AES)"))
function encr.cfgvalue(e,t)
local e=tostring(ListValue.cfgvalue(e,t))
if e=="wep"then
return"wep-open"
elseif e and e:match("%+")then
return(e:gsub("%+.+$",""))
end
return e
end
function encr.write(o,a,i)
local t=tostring(encr:formvalue(a))
local e=tostring(cipher:formvalue(a))
if i=="wpa"or i=="wpa2"then
o.map.uci:delete("wireless",a,"key")
end
if t and(e=="tkip"or e=="ccmp"or e=="tkip+ccmp")then
t=t.."+"..e
end
o.map:set(a,"encryption",t)
end
function cipher.cfgvalue(t,e)
local e=tostring(ListValue.cfgvalue(encr,e))
if e and e:match("%+")then
e=e:gsub("^[^%+]+%+","")
if e=="aes"then e="ccmp"
elseif e=="tkip+aes"then e="tkip+ccmp"
elseif e=="aes+tkip"then e="tkip+ccmp"
elseif e=="ccmp+tkip"then e="tkip+ccmp"
end
end
return e
end
function cipher.write(t,e)
return encr:write(e)
end
encr:value("none","No Encryption")
encr:value("wep-open",translate("WEP Open System"),{mode="ap"},{mode="sta"},{mode="ap-wds"},{mode="sta-wds"},{mode="adhoc"},{mode="ahdemo"},{mode="wds"})
encr:value("wep-shared",translate("WEP Shared Key"),{mode="ap"},{mode="sta"},{mode="ap-wds"},{mode="sta-wds"},{mode="adhoc"},{mode="ahdemo"},{mode="wds"})
if e=="atheros"or e=="mac80211"or e=="prism2"then
local e=r.access("/usr/sbin/wpa_supplicant")
local t=r.access("/usr/sbin/hostapd")
local o=(os.execute("hostapd -veap >/dev/null 2>/dev/null")==0)
local a=(os.execute("wpa_supplicant -veap >/dev/null 2>/dev/null")==0)
if t and e then
encr:value("psk","WPA-PSK",{mode="ap"},{mode="sta"},{mode="ap-wds"},{mode="sta-wds"})
encr:value("psk2","WPA2-PSK",{mode="ap"},{mode="sta"},{mode="ap-wds"},{mode="sta-wds"})
encr:value("psk-mixed","WPA-PSK/WPA2-PSK Mixed Mode",{mode="ap"},{mode="sta"},{mode="ap-wds"},{mode="sta-wds"})
if o and a then
encr:value("wpa","WPA-EAP",{mode="ap"},{mode="sta"},{mode="ap-wds"},{mode="sta-wds"})
encr:value("wpa2","WPA2-EAP",{mode="ap"},{mode="sta"},{mode="ap-wds"},{mode="sta-wds"})
end
elseif t and not e then
encr:value("psk","WPA-PSK",{mode="ap"},{mode="ap-wds"})
encr:value("psk2","WPA2-PSK",{mode="ap"},{mode="ap-wds"})
encr:value("psk-mixed","WPA-PSK/WPA2-PSK Mixed Mode",{mode="ap"},{mode="ap-wds"})
if o then
encr:value("wpa","WPA-EAP",{mode="ap"},{mode="ap-wds"})
encr:value("wpa2","WPA2-EAP",{mode="ap"},{mode="ap-wds"})
end
encr.description=translate(
"WPA-Encryption requires wpa_supplicant (for client mode) or hostapd (for AP "..
"and ad-hoc mode) to be installed."
)
elseif not t and e then
encr:value("psk","WPA-PSK",{mode="sta"},{mode="sta-wds"})
encr:value("psk2","WPA2-PSK",{mode="sta"},{mode="sta-wds"})
encr:value("psk-mixed","WPA-PSK/WPA2-PSK Mixed Mode",{mode="sta"},{mode="sta-wds"})
if a then
encr:value("wpa","WPA-EAP",{mode="sta"},{mode="sta-wds"})
encr:value("wpa2","WPA2-EAP",{mode="sta"},{mode="sta-wds"})
end
encr.description=translate(
"WPA-Encryption requires wpa_supplicant (for client mode) or hostapd (for AP "..
"and ad-hoc mode) to be installed."
)
else
encr.description=translate(
"WPA-Encryption requires wpa_supplicant (for client mode) or hostapd (for AP "..
"and ad-hoc mode) to be installed."
)
end
elseif e=="broadcom"then
encr:value("psk","WPA-PSK")
encr:value("psk2","WPA2-PSK")
encr:value("psk+psk2","WPA-PSK/WPA2-PSK Mixed Mode")
end
auth_server=s:taboption("encryption",Value,"auth_server",translate("Radius-Authentication-Server"))
auth_server:depends({mode="ap",encryption="wpa"})
auth_server:depends({mode="ap",encryption="wpa2"})
auth_server:depends({mode="ap-wds",encryption="wpa"})
auth_server:depends({mode="ap-wds",encryption="wpa2"})
auth_server.rmempty=true
auth_server.datatype="host"
auth_port=s:taboption("encryption",Value,"auth_port",translate("Radius-Authentication-Port"),translatef("Default %d",1812))
auth_port:depends({mode="ap",encryption="wpa"})
auth_port:depends({mode="ap",encryption="wpa2"})
auth_port:depends({mode="ap-wds",encryption="wpa"})
auth_port:depends({mode="ap-wds",encryption="wpa2"})
auth_port.rmempty=true
auth_port.datatype="port"
auth_secret=s:taboption("encryption",Value,"auth_secret",translate("Radius-Authentication-Secret"))
auth_secret:depends({mode="ap",encryption="wpa"})
auth_secret:depends({mode="ap",encryption="wpa2"})
auth_secret:depends({mode="ap-wds",encryption="wpa"})
auth_secret:depends({mode="ap-wds",encryption="wpa2"})
auth_secret.rmempty=true
auth_secret.password=true
acct_server=s:taboption("encryption",Value,"acct_server",translate("Radius-Accounting-Server"))
acct_server:depends({mode="ap",encryption="wpa"})
acct_server:depends({mode="ap",encryption="wpa2"})
acct_server:depends({mode="ap-wds",encryption="wpa"})
acct_server:depends({mode="ap-wds",encryption="wpa2"})
acct_server.rmempty=true
acct_server.datatype="host"
acct_port=s:taboption("encryption",Value,"acct_port",translate("Radius-Accounting-Port"),translatef("Default %d",1813))
acct_port:depends({mode="ap",encryption="wpa"})
acct_port:depends({mode="ap",encryption="wpa2"})
acct_port:depends({mode="ap-wds",encryption="wpa"})
acct_port:depends({mode="ap-wds",encryption="wpa2"})
acct_port.rmempty=true
acct_port.datatype="port"
acct_secret=s:taboption("encryption",Value,"acct_secret",translate("Radius-Accounting-Secret"))
acct_secret:depends({mode="ap",encryption="wpa"})
acct_secret:depends({mode="ap",encryption="wpa2"})
acct_secret:depends({mode="ap-wds",encryption="wpa"})
acct_secret:depends({mode="ap-wds",encryption="wpa2"})
acct_secret.rmempty=true
acct_secret.password=true
wpakey=s:taboption("encryption",Value,"_wpa_key",translate("Key"))
wpakey:depends("encryption","psk")
wpakey:depends("encryption","psk2")
wpakey:depends("encryption","psk+psk2")
wpakey:depends("encryption","psk-mixed")
wpakey.datatype="wpakey"
wpakey.rmempty=true
wpakey.password=true
wpakey.cfgvalue=function(t,e,t)
local e=m.uci:get("wireless",e,"key")
if e=="1"or e=="2"or e=="3"or e=="4"then
return nil
end
return e
end
wpakey.write=function(e,t,a)
e.map.uci:set("wireless",t,"key",a)
e.map.uci:delete("wireless",t,"key1")
end
wepslot=s:taboption("encryption",ListValue,"_wep_key",translate("Used Key Slot"))
wepslot:depends("encryption","wep-open")
wepslot:depends("encryption","wep-shared")
wepslot:value("1",translatef("Key #%d",1))
wepslot:value("2",translatef("Key #%d",2))
wepslot:value("3",translatef("Key #%d",3))
wepslot:value("4",translatef("Key #%d",4))
wepslot.cfgvalue=function(t,e)
local e=tonumber(m.uci:get("wireless",e,"key"))
if not e or e<1 or e>4 then
return 1
end
return e
end
wepslot.write=function(a,t,e)
a.map.uci:set("wireless",t,"key",e)
end
local t
for e=1,4 do
wepkey=s:taboption("encryption",Value,"key"..e,translatef("Key #%d",e))
wepkey:depends("encryption","wep-open")
wepkey:depends("encryption","wep-shared")
wepkey.datatype="wepkey"
wepkey.rmempty=true
wepkey.password=true
function wepkey.write(a,t,e)
if e and(#e==5 or#e==13)then
e="s:"..e
end
return Value.write(a,t,e)
end
end
if e=="atheros"or e=="mac80211"or e=="prism2"then
nasid=s:taboption("encryption",Value,"nasid",translate("NAS ID"))
nasid:depends({mode="ap",encryption="wpa"})
nasid:depends({mode="ap",encryption="wpa2"})
nasid:depends({mode="ap-wds",encryption="wpa"})
nasid:depends({mode="ap-wds",encryption="wpa2"})
nasid.rmempty=true
eaptype=s:taboption("encryption",ListValue,"eap_type",translate("EAP-Method"))
eaptype:value("tls","TLS")
eaptype:value("ttls","TTLS")
eaptype:value("peap","PEAP")
eaptype:depends({mode="sta",encryption="wpa"})
eaptype:depends({mode="sta",encryption="wpa2"})
eaptype:depends({mode="sta-wds",encryption="wpa"})
eaptype:depends({mode="sta-wds",encryption="wpa2"})
cacert=s:taboption("encryption",FileUpload,"ca_cert",translate("Path to CA-Certificate"))
cacert:depends({mode="sta",encryption="wpa"})
cacert:depends({mode="sta",encryption="wpa2"})
cacert:depends({mode="sta-wds",encryption="wpa"})
cacert:depends({mode="sta-wds",encryption="wpa2"})
clientcert=s:taboption("encryption",FileUpload,"client_cert",translate("Path to Client-Certificate"))
clientcert:depends({mode="sta",encryption="wpa"})
clientcert:depends({mode="sta",encryption="wpa2"})
clientcert:depends({mode="sta-wds",encryption="wpa"})
clientcert:depends({mode="sta-wds",encryption="wpa2"})
privkey=s:taboption("encryption",FileUpload,"priv_key",translate("Path to Private Key"))
privkey:depends({mode="sta",eap_type="tls",encryption="wpa2"})
privkey:depends({mode="sta",eap_type="tls",encryption="wpa"})
privkey:depends({mode="sta-wds",eap_type="tls",encryption="wpa2"})
privkey:depends({mode="sta-wds",eap_type="tls",encryption="wpa"})
privkeypwd=s:taboption("encryption",Value,"priv_key_pwd",translate("Password of Private Key"))
privkeypwd:depends({mode="sta",eap_type="tls",encryption="wpa2"})
privkeypwd:depends({mode="sta",eap_type="tls",encryption="wpa"})
privkeypwd:depends({mode="sta-wds",eap_type="tls",encryption="wpa2"})
privkeypwd:depends({mode="sta-wds",eap_type="tls",encryption="wpa"})
auth=s:taboption("encryption",Value,"auth",translate("Authentication"))
auth:value("PAP")
auth:value("CHAP")
auth:value("MSCHAP")
auth:value("MSCHAPV2")
auth:depends({mode="sta",eap_type="peap",encryption="wpa2"})
auth:depends({mode="sta",eap_type="peap",encryption="wpa"})
auth:depends({mode="sta",eap_type="ttls",encryption="wpa2"})
auth:depends({mode="sta",eap_type="ttls",encryption="wpa"})
auth:depends({mode="sta-wds",eap_type="peap",encryption="wpa2"})
auth:depends({mode="sta-wds",eap_type="peap",encryption="wpa"})
auth:depends({mode="sta-wds",eap_type="ttls",encryption="wpa2"})
auth:depends({mode="sta-wds",eap_type="ttls",encryption="wpa"})
identity=s:taboption("encryption",Value,"identity",translate("Identity"))
identity:depends({mode="sta",eap_type="peap",encryption="wpa2"})
identity:depends({mode="sta",eap_type="peap",encryption="wpa"})
identity:depends({mode="sta",eap_type="ttls",encryption="wpa2"})
identity:depends({mode="sta",eap_type="ttls",encryption="wpa"})
identity:depends({mode="sta-wds",eap_type="peap",encryption="wpa2"})
identity:depends({mode="sta-wds",eap_type="peap",encryption="wpa"})
identity:depends({mode="sta-wds",eap_type="ttls",encryption="wpa2"})
identity:depends({mode="sta-wds",eap_type="ttls",encryption="wpa"})
password=s:taboption("encryption",Value,"password",translate("Password"))
password:depends({mode="sta",eap_type="peap",encryption="wpa2"})
password:depends({mode="sta",eap_type="peap",encryption="wpa"})
password:depends({mode="sta",eap_type="ttls",encryption="wpa2"})
password:depends({mode="sta",eap_type="ttls",encryption="wpa"})
password:depends({mode="sta-wds",eap_type="peap",encryption="wpa2"})
password:depends({mode="sta-wds",eap_type="peap",encryption="wpa"})
password:depends({mode="sta-wds",eap_type="ttls",encryption="wpa2"})
password:depends({mode="sta-wds",eap_type="ttls",encryption="wpa"})
end
if e=="atheros"or e=="mac80211"or e=="prism2"then
local t=r.access("/usr/sbin/wpa_supplicant")
local e=r.access("/usr/sbin/hostapd_cli")
if e and t then
wps=s:taboption("encryption",Flag,"wps_pushbutton",translate("Enable WPS pushbutton, requires WPA(2)-PSK"))
wps.enabled="1"
wps.disabled="0"
wps.rmempty=false
wps:depends("encryption","psk")
wps:depends("encryption","psk2")
wps:depends("encryption","psk-mixed")
end
end
return m
