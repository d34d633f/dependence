require("luci.tools.webadmin")
local n=require"nixio.fs"
local t=require"nixio.util"
local o=require"luci.template.parser"
local s=io.popen("block info","r")
local t,a,i=nil,nil,{}
repeat
t=s:read("*l")
a=t and t:match("^/dev/(.-):")
if a then
local e,o,s,s={}
for a,t in t:gmatch([[(%w+)="(.-)"]])do
e[a:lower()]=t
i[t]=e
end
o=tonumber((n.readfile("/sys/class/block/%s/size"%a)))
e.dev="/dev/%s"%a
e.size=o and math.floor(o/2048)
i[e.dev]=e
end
until not t
s:close()
m=Map("fstab",translate("Mount Points"))
local t=luci.sys.mounts()
v=m:section(Table,t,translate("Mounted file systems"))
n=v:option(DummyValue,"fs",translate("Filesystem"))
mp=v:option(DummyValue,"mountpoint",translate("Mount Point"))
avail=v:option(DummyValue,"avail",translate("Available"))
function avail.cfgvalue(a,e)
return luci.tools.webadmin.byte_format(
(tonumber(t[e].available)or 0)*1024
).." / "..luci.tools.webadmin.byte_format(
(tonumber(t[e].blocks)or 0)*1024
)
end
used=v:option(DummyValue,"used",translate("Used"))
function used.cfgvalue(a,e)
return(t[e].percent or"0%").." ("..
luci.tools.webadmin.byte_format(
(tonumber(t[e].used)or 0)*1024
)..")"
end
mount=m:section(TypedSection,"mount",translate("Mount Points"),translate("Mount Points define at which point a memory device will be attached to the filesystem"))
mount.anonymous=true
mount.addremove=true
mount.template="cbi/tblsection"
mount.extedit=luci.dispatcher.build_url("admin/system/fstab/mount/%s")
mount.create=function(...)
local e=TypedSection.create(...)
if e then
luci.http.redirect(mount.extedit%e)
return
end
end
mount:option(Flag,"enabled",translate("Enabled")).rmempty=false
a=mount:option(DummyValue,"device",translate("Device"))
a.rawhtml=true
a.cfgvalue=function(n,a)
local e,t
e=m.uci:get("fstab",a,"uuid")
t=e and i[e:lower()]
if e and t and t.size then
return"UUID: %s (%s, %d MB)"%{o.pcdata(e),t.dev,t.size}
elseif e and t then
return"UUID: %s (%s)"%{o.pcdata(e),t.dev}
elseif e then
return"UUID: %s (<em>%s</em>)"%{o.pcdata(e),translate("not present")}
end
e=m.uci:get("fstab",a,"label")
t=e and i[e]
if e and t and t.size then
return"Label: %s (%s, %d MB)"%{o.pcdata(e),t.dev,t.size}
elseif e and t then
return"Label: %s (%s)"%{o.pcdata(e),t.dev}
elseif e then
return"Label: %s (<em>%s</em>)"%{o.pcdata(e),translate("not present")}
end
e=Value.cfgvalue(n,a)or"?"
t=e and i[e]
if e and t and t.size then
return"%s (%d MB)"%{o.pcdata(e),t.size}
elseif e and t then
return o.pcdata(e)
elseif e then
return"%s (<em>%s</em>)"%{o.pcdata(e),translate("not present")}
end
end
mp=mount:option(DummyValue,"target",translate("Mount Point"))
mp.cfgvalue=function(t,e)
if m.uci:get("fstab",e,"is_rootfs")=="1"then
return"/overlay"
else
return Value.cfgvalue(t,e)or"?"
end
end
n=mount:option(DummyValue,"fstype",translate("Filesystem"))
n.cfgvalue=function(e,t)
local e,a
e=m.uci:get("fstab",t,"uuid")
e=e and e:lower()or m.uci:get("fstab",t,"label")
e=e or m.uci:get("fstab",t,"device")
a=e and i[e]
return a and a.type or m.uci:get("fstab",t,"fstype")or"?"
end
op=mount:option(DummyValue,"options",translate("Options"))
op.cfgvalue=function(t,e)
return Value.cfgvalue(t,e)or"defaults"
end
rf=mount:option(DummyValue,"is_rootfs",translate("Root"))
rf.cfgvalue=function(t,e)
local e=m.uci:get("fstab",e,"target")
if e=="/"then
return translate("yes")
elseif e=="/overlay"then
return translate("overlay")
else
return translate("no")
end
end
ck=mount:option(DummyValue,"enabled_fsck",translate("Check"))
ck.cfgvalue=function(e,t)
return Value.cfgvalue(e,t)=="1"
and translate("yes")or translate("no")
end
swap=m:section(TypedSection,"swap","SWAP",translate("If your physical memory is insufficient unused data can be temporarily swapped to a swap-device resulting in a higher amount of usable <abbr title=\"Random Access Memory\">RAM</abbr>. Be aware that swapping data is a very slow process as the swap-device cannot be accessed with the high datarates of the <abbr title=\"Random Access Memory\">RAM</abbr>."))
swap.anonymous=true
swap.addremove=true
swap.template="cbi/tblsection"
swap.extedit=luci.dispatcher.build_url("admin/system/fstab/swap/%s")
swap.create=function(...)
local e=TypedSection.create(...)
if e then
luci.http.redirect(swap.extedit%e)
return
end
end
swap:option(Flag,"enabled",translate("Enabled")).rmempty=false
a=swap:option(DummyValue,"device",translate("Device"))
a.cfgvalue=function(o,a)
local t
t=m.uci:get("fstab",a,"uuid")
if t then return"UUID: %s"%t end
t=m.uci:get("fstab",a,"label")
if t then return"Label: %s"%t end
t=Value.cfgvalue(o,a)or"?"
e=t and i[t]
if t and e and e.size then
return"%s (%s MB)"%{t,e.size}
else
return t
end
end
return m
