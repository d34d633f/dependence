m=Map("network",translate("Switch"),translate("The network ports on this device can be combined to several <abbr title=\"Virtual Local Area Network\">VLAN</abbr>s in which computers can communicate directly with each other. <abbr title=\"Virtual Local Area Network\">VLAN</abbr>s are often used to separate different network segments. Often there is by default one Uplink port for a connection to the next greater network like the internet and other ports for a local network."))
local e=require"nixio.fs"
local u={}
m.uci:foreach("network","switch",
function(o)
local v=o['.name']
local a=o.name or v
local f=nil
local w=nil
local t=nil
local l=nil
local p=nil
local d=0
local i=16
local r=16
local i=tonumber(e.readfile("/proc/switch/eth0/cpuport")or 5)
local h=i+1
local n
local y=false
local c=io.popen("swconfig dev %q help 2>/dev/null"%a)
if c then
local o=false
local a=false
while true do
local e=c:read("*l")
if not e then break end
if e:match("^%s+%-%-vlan")then
a=true
elseif e:match("^%s+%-%-port")then
a=false
o=true
elseif e:match("cpu @")then
n=e:match("^switch%d: %w+%((.-)%)")
h,i,r=
e:match("ports: (%d+) %(cpu @ (%d+)%), vlans: (%d+)")
h=tonumber(h)or 6
r=tonumber(r)or 16
i=tonumber(i)or 5
d=1
elseif e:match(": pvid")or e:match(": tag")or e:match(": vid")then
if a then t=e:match(": (%w+)")end
elseif e:match(": enable_vlan4k")then
y=true
elseif e:match(": enable_vlan")then
f="enable_vlan"
elseif e:match(": enable_learning")then
w="enable_learning"
elseif e:match(": enable_mirror_rx")then
p="enable_mirror_rx"
elseif e:match(": max_length")then
l="max_length"
end
end
c:close()
end
s=m:section(NamedSection,o['.name'],"switch",
n and translatef("Switch %q (%s)",a,n)
or translatef("Switch %q",a))
s.addremove=false
if f then
s:option(Flag,f,translate("Enable VLAN functionality"))
end
if w then
o=s:option(Flag,w,translate("Enable learning and aging"))
o.default=o.enabled
end
if l then
o=s:option(Flag,l,translate("Enable Jumbo Frame passthrough"))
o.enabled="3"
o.rmempty=true
end
if p then
s:option(Flag,"enable_mirror_rx",translate("Enable mirroring of incoming packets"))
s:option(Flag,"enable_mirror_tx",translate("Enable mirroring of outgoing packets"))
local o=s:option(ListValue,"mirror_source_port",translate("Mirror source port"))
local a=s:option(ListValue,"mirror_monitor_port",translate("Mirror monitor port"))
local e
for e=0,h-1 do
local t
t=(e==i)and translate("CPU")or translatef("Port %d",e)
o:value(e,t)
a:value(e,t)
end
end
s=m:section(TypedSection,"switch_vlan",
n and translatef("VLANs on %q (%s)",a,n)
or translatef("VLANs on %q",a))
s.template="cbi/tblsection"
s.addremove=true
s.anonymous=true
s.filter=function(t,e)
local e=m:get(e,"device")
return(e and e==a)
end
s.cfgsections=function(e)
local e=TypedSection.cfgsections(e)
local a={}
local o
for t,e in luci.util.spairs(
e,
function(a,o)
return(tonumber(m:get(e[a],t or"vlan"))or 9999)
<(tonumber(m:get(e[o],t or"vlan"))or 9999)
end
)do
a[#a+1]=e
end
return a
end
s.create=function(o,i,e)
if m:get(e,"device")~=a then
return
end
local e=TypedSection.create(o,i)
local o=0
local i=0
m.uci:foreach("network","switch_vlan",
function(e)
if e.device==a then
local a=tonumber(e.vlan)
local e=t and tonumber(e[t])
if a~=nil and a>o then o=a end
if e~=nil and e>i then i=e end
end
end)
m:set(e,"device",a)
m:set(e,"vlan",o+1)
if t then
m:set(e,t,i+1)
end
return e
end
local o={}
local n={}
local c=function(a,e)
local t
for e in(m:get(e,"ports")or""):gmatch("%w+")do
local t,e=e:match("^(%d+)([tu]*)")
if t==a.option then return(#e>0)and e or"u"end
end
return""
end
local n=function(e,t,a)
if t=="u"then
if not n[e.option]then
n[e.option]=true
elseif d>0 or tonumber(e.option)~=i then
return nil,
translatef("Port %d is untagged in multiple VLANs!",tonumber(e.option)+1)
end
end
return t
end
local e=s:option(Value,t or"vlan","VLAN ID","<div id='portstatus-%s'></div>"%a)
local l=t and 4094 or(r-1)
e.rmempty=false
e.forcewrite=true
e.vlan_used={}
e.datatype="and(uinteger,range("..d..","..l.."))"
e.validate=function(i,o,a)
local a=tonumber(o)
local t=t and 4094 or(r-1)
if a~=nil and a>=d and a<=t then
if not i.vlan_used[a]then
i.vlan_used[a]=true
return o
else
return nil,
translatef("Invalid VLAN ID given! Only unique IDs are allowed")
end
else
return nil,
translatef("Invalid VLAN ID given! Only IDs between %d and %d are allowed.",d,t)
end
end
e.write=function(n,a,i)
local t
local t={}
for e,o in ipairs(o)do
local e=o:formvalue(a)
if e=="t"then
t[#t+1]=o.option..e
elseif e=="u"then
t[#t+1]=o.option
end
end
if y then
m:set(v,"enable_vlan4k","1")
end
m:set(a,"ports",table.concat(t," "))
return Value.write(n,a,i)
end
e.cfgvalue=function(a,e)
return m:get(e,t or"vlan")
or m:get(e,"vlan")
end
local e
for e=0,h-1 do
local t
if e==i then
t=translate("CPU")
else
t=translatef("Port %d",e)
end
local e=s:option(ListValue,tostring(e),t)
e:value("",translate("off"))
e:value("u",translate("untagged"))
e:value("t",translate("tagged"))
e.cfgvalue=c
e.validate=n
e.write=function()end
o[#o+1]=e
end
u[#u+1]=a
end
)
s=m:section(SimpleSection)
s.template="admin_network/switch_status"
s.switches=u
return m
