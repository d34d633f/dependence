local e=require"nixio.fs"
m=Map("network",translate("Interfaces"))
m.pageaction=false
m:section(SimpleSection).template="admin_network/iface_overview"
if e.access("/usr/sbin/br2684ctl")then
atm=m:section(TypedSection,"atm-bridge",translate("ATM Bridges"),
translate("ATM bridges expose encapsulated ethernet in AAL5 "..
"connections as virtual Linux network interfaces which can "..
"be used in conjunction with DHCP or PPP to dial into the "..
"provider network."))
atm.addremove=true
atm.anonymous=true
atm.create=function(t,e)
local e=TypedSection.create(t,e)
local t=-1
m.uci:foreach("network","atm-bridge",
function(e)
local e=tonumber(e.unit)
if e~=nil and e>t then
t=e
end
end)
m.uci:set("network",e,"unit",t+1)
m.uci:set("network",e,"atmdev",0)
m.uci:set("network",e,"encaps","llc")
m.uci:set("network",e,"payload","bridged")
m.uci:set("network",e,"vci",35)
m.uci:set("network",e,"vpi",8)
return e
end
atm:tab("general",translate("General Setup"))
atm:tab("advanced",translate("Advanced Settings"))
vci=atm:taboption("general",Value,"vci",translate("ATM Virtual Channel Identifier (VCI)"))
vpi=atm:taboption("general",Value,"vpi",translate("ATM Virtual Path Identifier (VPI)"))
encaps=atm:taboption("general",ListValue,"encaps",translate("Encapsulation mode"))
encaps:value("llc",translate("LLC"))
encaps:value("vc",translate("VC-Mux"))
atmdev=atm:taboption("advanced",Value,"atmdev",translate("ATM device number"))
unit=atm:taboption("advanced",Value,"unit",translate("Bridge unit number"))
payload=atm:taboption("advanced",ListValue,"payload",translate("Forwarding mode"))
payload:value("bridged",translate("bridged"))
payload:value("routed",translate("routed"))
m.pageaction=true
end
local e=require"luci.model.network"
if e:has_ipv6()then
local e=m:section(NamedSection,"globals","globals",translate("Global network options"))
local e=e:option(Value,"ula_prefix",translate("IPv6 ULA-Prefix"))
e.datatype="ip6addr"
e.rmempty=true
m.pageaction=true
end
return m
