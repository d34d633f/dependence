local t=require"nixio.fs"
local a=SimpleForm("firewall",
translate("Firewall - Custom Rules"),
translate("Custom rules allow you to execute arbritary iptables commands \
		which are not otherwise covered by the firewall framework. \
		The commands are executed after each firewall restart, right after \
		the default ruleset has been loaded."))
local e=a:field(Value,"_custom")
e.template="cbi/tvalue"
e.rows=20
function e.cfgvalue(e,e)
return t.readfile("/etc/firewall.user")
end
function e.write(a,a,e)
e=e:gsub("\r\n?","\n")
t.writefile("/etc/firewall.user",e)
end
return a
