local e="/etc/opkg.conf"
f=SimpleForm("ipkgconf",translate("OPKG-Configuration"))
f:append(Template("admin_system/ipkg"))
t=f:field(TextValue,"lines")
t.rows=10
function t.cfgvalue()
return nixio.fs.readfile(e)or""
end
function t.write(a,a,t)
return nixio.fs.writefile(e,t:gsub("\r\n","\n"))
end
function f.handle(e,e,e)
return true
end
return f
