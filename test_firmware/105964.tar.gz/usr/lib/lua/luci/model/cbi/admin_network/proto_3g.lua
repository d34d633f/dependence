local t,e,t=...
local l,y,o,p,v,f,c
local d,u,n,s,r,i,
t,a,h
l=e:taboption("general",Value,"device",translate("Modem device"))
l.rmempty=false
local w=nixio.fs.glob("/dev/tty[A-Z]*")
or nixio.fs.glob("/dev/tts/*")
if w then
local e
for e in w do
l:value(e)
end
end
o=e:taboption("general",Value,"service",translate("Service Type"))
o:value("",translate("-- Please choose --"))
o:value("umts","UMTS/GPRS")
o:value("umts_only",translate("UMTS only"))
o:value("gprs_only",translate("GPRS only"))
o:value("evdo","CDMA/EV-DO")
y=e:taboption("general",Value,"apn",translate("APN"))
p=e:taboption("general",Value,"pincode",translate("PIN"))
v=e:taboption("general",Value,"username",translate("PAP/CHAP username"))
f=e:taboption("general",Value,"password",translate("PAP/CHAP password"))
f.password=true
c=e:taboption("general",Value,"dialnumber",translate("Dial number"))
c.placeholder="*99***1#"
if luci.model.network:has_ipv6()then
d=e:taboption("advanced",Flag,"ipv6",
translate("Enable IPv6 negotiation on the PPP link"))
d.default=d.disabled
end
u=e:taboption("advanced",Value,"maxwait",
translate("Modem init timeout"),
translate("Maximum amount of seconds to wait for the modem to become ready"))
u.placeholder="20"
u.datatype="min(1)"
n=e:taboption("advanced",Flag,"defaultroute",
translate("Use default gateway"),
translate("If unchecked, no default route is configured"))
n.default=n.enabled
s=e:taboption("advanced",Value,"metric",
translate("Use gateway metric"))
s.placeholder="0"
s.datatype="uinteger"
s:depends("defaultroute",n.enabled)
r=e:taboption("advanced",Flag,"peerdns",
translate("Use DNS servers advertised by peer"),
translate("If unchecked, the advertised DNS server addresses are ignored"))
r.default=r.enabled
i=e:taboption("advanced",DynamicList,"dns",
translate("Use custom DNS servers"))
i:depends("peerdns","")
i.datatype="ipaddr"
i.cast="string"
t=e:taboption("advanced",Value,"_keepalive_failure",
translate("LCP echo failure threshold"),
translate("Presume peer to be dead after given amount of LCP echo failures, use 0 to ignore failures"))
function t.cfgvalue(t,e)
local e=m:get(e,"keepalive")
if e and#e>0 then
return tonumber(e:match("^(%d+)[ ,]+%d+")or e)
end
end
function t.write()end
function t.remove()end
t.placeholder="0"
t.datatype="uinteger"
a=e:taboption("advanced",Value,"_keepalive_interval",
translate("LCP echo interval"),
translate("Send LCP echo requests at the given interval in seconds, only effective in conjunction with failure threshold"))
function a.cfgvalue(t,e)
local e=m:get(e,"keepalive")
if e and#e>0 then
return tonumber(e:match("^%d+[ ,]+(%d+)"))
end
end
function a.write(o,e,i)
local o=tonumber(t:formvalue(e))or 0
local t=tonumber(i)or 5
if t<1 then t=1 end
if o>0 then
m:set(e,"keepalive","%d %d"%{o,t})
else
m:del(e,"keepalive")
end
end
a.remove=a.write
a.placeholder="5"
a.datatype="min(1)"
h=e:taboption("advanced",Value,"demand",
translate("Inactivity timeout"),
translate("Close inactive connection after the given amount of seconds, use 0 to persist connection"))
h.placeholder="0"
h.datatype="uinteger"
