local f=require"nixio"
local y=require"nixio.fs"
local l=require"luci.sys"
local v=require"luci.util"
local c=require"luci.dispatcher"
local h=require"luci.tools.webadmin"
local n=require"luci.cbi.datatypes"
local t=require"luci.tools.ddns"
local e=arg[1]
local a=t.check_ipv6()
local s=t.check_ssl()
local w=t.check_proxy()
local u=t.check_bind_host()
local p=s and u
local r="<font color='red'>"
local d="</font>"
local i="<strong>"
local o="</strong>"
err_ipv6_plain=translate("IPv6 not supported").." - "..
translate("please select 'IPv4' address version")
err_ipv6_basic=i..
r..
translate("IPv6 not supported")..
d..
"<br />"..translate("please select 'IPv4' address version")..
o
err_ipv6_other=i..
r..
translate("IPv6 not supported")..
d..
"<br />"..translate("please select 'IPv4' address version in").." "..
[[<a href="]]..
c.build_url("admin","services","ddns","detail",e)..
"?tab.dns."..e.."=basic"..
[[">]]..
translate("Basic Settings")..
[[</a>]]..
o
function err_tab_basic(e)
return translate("Basic Settings").." - "..e.title..": "
end
function err_tab_adv(e)
return translate("Advanced Settings").." - "..e.title..": "
end
function err_tab_timer(e)
return translate("Timer Settings").." - "..e.title..": "
end
local function b()
local h="-"
local s="-"
local n="-"
local i="-"
local o=""
local a=usev6:formvalue(e)
local t=(a=="1")
and src6:formvalue(e)
or src4:formvalue(e)
if t=="network"then
h=(a=="1")
and ipn6:formvalue(e)
or ipn4:formvalue(e)
elseif t=="web"then
s=(a=="1")
and iurl6:formvalue(e)
or iurl4:formvalue(e)
o=(pxy)and pxy:formvalue(e)or""
elseif t=="interface"then
n=ipi:formvalue(e)
elseif t=="script"then
i=ips:formvalue(e)
end
local e=[[/usr/lib/ddns/dynamic_dns_lucihelper.sh get_local_ip ]]..
a..[[ ]]..t..[[ ]]..h..[[ ]]..
s..[[ ]]..n..[[ ']]..i..[[' ]]..o
local e=l.call(e)
if e==0 then
return true
else
return nil
end
end
m=Map("ddns")
m.title=[[</a><a href="]]..c.build_url("admin","services","ddns")..[[">]]..
translate("Dynamic DNS")
m.description=translate("Dynamic DNS allows that your router can be reached with "..
"a fixed hostname while having a dynamically changing "..
"IP address.")
m.redirect=c.build_url("admin","services","ddns")
m.on_after_commit=function(a)
if a.changed then
local e=t.get_pid(e)
if e>0 then
local e=f.kill(e,1)
end
end
end
date_format=m.uci:get(m.config,"global","date_format")or"%F %R"
log_dir=m.uci:get(m.config,"global","log_dir")or"/var/log/ddns"
ns=m:section(NamedSection,e,"service",
translate("Details for")..([[: <strong>%s</strong>]]%e),
translate("Configure here the details for selected Dynamic DNS service.")
..[[<br /><a href="http://wiki.openwrt.org/doc/uci/ddns#version_1x" target="_blank">]]
..translate("For detailed information about parameter settings look here.")
..[[</a>]])
ns.instance=e
ns:tab("basic",translate("Basic Settings"),nil)
ns:tab("advanced",translate("Advanced Settings"),nil)
ns:tab("timer",translate("Timer Settings"),nil)
ns:tab("logview",translate("Log File Viewer"),nil)
en=ns:taboption("basic",Flag,"enabled",
translate("Enabled"),
translate("If this service section is disabled it could not be started.".."<br />"..
"Neither from LuCI interface nor from console"))
en.orientation="horizontal"
function en.parse(e,a)
t.flag_parse(e,a)
end
usev6=ns:taboption("basic",ListValue,"use_ipv6",
translate("IP address version"),
translate("Defines which IP address 'IPv4/IPv6' is send to the DDNS provider"))
usev6.widget="radio"
usev6.default="0"
usev6:value("0",translate("IPv4-Address"))
function usev6.cfgvalue(t,e)
local e=AbstractValue.cfgvalue(t,e)
if a or(e=="1"and not a)then
t:value("1",translate("IPv6-Address"))
end
if e=="1"and not a then
t.description=err_ipv6_basic
end
return e
end
function usev6.validate(t,e)
if(e=="1"and a)or e=="0"then
return e
end
return nil,err_tab_basic(t)..err_ipv6_plain
end
function usev6.write(e,a,t)
if t=="0"then
return e.map:del(a,e.option)
else
return e.map:set(a,e.option,t)
end
end
svc4=ns:taboption("basic",ListValue,"ipv4_service_name",
translate("DDNS Service provider").." [IPv4]")
svc4.default="-"
svc4:depends("use_ipv6","0")
local f={}
local c=io.open("/usr/lib/ddns/services","r")
if c then
local e
repeat
e=c:read("*l")
local t=e and e:match('^%s*"([^"]+)"')
if t then f[#f+1]=t end
until not e
c:close()
end
for t,e in v.vspairs(f)do svc4:value(e)end
svc4:value("-",translate("-- custom --"))
function svc4.cfgvalue(e,a)
local e=t.read_value(e,a,"service_name")
if not e or#e==0 then
return"-"
else
return e
end
end
function svc4.validate(a,t)
if usev6:formvalue(e)=="0"then
return t
else
return""
end
end
function svc4.write(e,t,a)
if usev6:formvalue(t)=="0"then
e.map:del(t,e.option)
if a~="-"then
e.map:del(t,"update_url")
return e.map:set(t,"service_name",a)
else
return e.map:del(t,"service_name")
end
end
end
svc6=ns:taboption("basic",ListValue,"ipv6_service_name",
translate("DDNS Service provider").." [IPv6]")
svc6.default="-"
svc6:depends("use_ipv6","1")
if not a then
svc6.description=err_ipv6_basic
end
local c={}
local f=io.open("/usr/lib/ddns/services_ipv6","r")
if f then
local e
repeat
e=f:read("*l")
local t=e and e:match('^%s*"([^"]+)"')
if t then c[#c+1]=t end
until not e
f:close()
end
for t,e in v.vspairs(c)do svc6:value(e)end
svc6:value("-",translate("-- custom --"))
function svc6.cfgvalue(e,a)
local e=t.read_value(e,a,"service_name")
if not e or#e==0 then
return"-"
else
return e
end
end
function svc6.validate(t,o)
if usev6:formvalue(e)=="1"then
if a then return o end
return nil,err_tab_basic(t)..err_ipv6_plain
else
return""
end
end
function svc6.write(e,t,a)
if usev6:formvalue(t)=="1"then
e.map:del(t,e.option)
if a~="-"then
e.map:del(t,"update_url")
return e.map:set(t,"service_name",a)
else
return e.map:del(t,"service_name")
end
end
end
uurl=ns:taboption("basic",Value,"update_url",
translate("Custom update-URL"),
translate("Update URL to be used for updating your DDNS Provider.".."<br />"..
"Follow instructions you will find on their WEB page."))
uurl:depends("ipv4_service_name","-")
uurl:depends("ipv6_service_name","-")
function uurl.validate(a,i)
local o=ush:formvalue(e)
if(usev6:formvalue(e)=="0"and svc4:formvalue(e)~="-")or
(usev6:formvalue(e)=="1"and svc6:formvalue(e)~="-")then
return""
elseif not i then
if not o or not(#o>0)then
return nil,err_tab_basic(a)..translate("missing / required")
else
return""
end
elseif(#o>0)then
return nil,err_tab_basic(a)..translate("either url or script could be set")
end
local e=t.parse_url(i)
if not e.scheme=="http"then
return nil,err_tab_basic(a)..translate("must start with 'http://'")
elseif not e.query then
return nil,err_tab_basic(a).."<QUERY> "..translate("missing / required")
elseif not e.host then
return nil,err_tab_basic(a).."<HOST> "..translate("missing / required")
elseif l.call([[nslookup ]]..e.host..[[ >/dev/null 2>&1]])~=0 then
return nil,err_tab_basic(a)..translate("can not resolve host: ")..e.host
end
return i
end
ush=ns:taboption("basic",Value,"update_script",
translate("Custom update-script"),
translate("Custom update script to be used for updating your DDNS Provider."))
ush:depends("ipv4_service_name","-")
ush:depends("ipv6_service_name","-")
function ush.validate(o,a)
local t=uurl:formvalue(e)
if(usev6:formvalue(e)=="0"and svc4:formvalue(e)~="-")or
(usev6:formvalue(e)=="1"and svc6:formvalue(e)~="-")then
return""
elseif not a then
if not t or not(#t>0)then
return nil,err_tab_basic(o)..translate("missing / required")
else
return""
end
elseif(#t>0)then
return nil,err_tab_basic(o)..translate("either url or script could be set")
elseif not y.access(a)then
return nil,err_tab_basic(o)..translate("File not found")
end
return a
end
dom=ns:taboption("basic",Value,"domain",
translate("Hostname/Domain"),
translate("Replaces [DOMAIN] in Update-URL"))
dom.rmempty=false
dom.placeholder="mypersonaldomain.dyndns.org"
function dom.validate(t,e)
if not e
or not(#e>0)
or not n.hostname(e)then
return nil,err_tab_basic(t)..translate("invalid - Sample")..": 'mypersonaldomain.dyndns.org'"
else
return e
end
end
user=ns:taboption("basic",Value,"username",
translate("Username"),
translate("Replaces [USERNAME] in Update-URL"))
user.rmempty=false
function user.validate(t,e)
if not e then
return nil,err_tab_basic(t)..translate("missing / required")
end
return e
end
pw=ns:taboption("basic",Value,"password",
translate("Password"),
translate("Replaces [PASSWORD] in Update-URL"))
pw.rmempty=false
pw.password=true
function pw.validate(t,e)
if not e then
return nil,err_tab_basic(t)..translate("missing / required")
end
return e
end
if s or((m:get(e,"use_https")or"0")=="1")then
https=ns:taboption("basic",Flag,"use_https",
translate("Use HTTP Secure"))
https.orientation="horizontal"
https.rmempty=false
function https.cfgvalue(e,t)
local t=AbstractValue.cfgvalue(e,t)
if not s and t=="1"then
e.description=i..r..
translate("HTTPS not supported")..d.."<br />"..
translate("please disable").." !"..o
else
e.description=translate("Enable secure communication with DDNS provider")
end
return t
end
function https.parse(a,e)
t.flag_parse(a,e)
end
function https.validate(t,e)
if(e=="1"and s)or e=="0"then return e end
return nil,err_tab_basic(t)..translate("HTTPS not supported").." !"
end
function https.write(e,t,a)
if a=="1"then
return e.map:set(t,e.option,a)
else
e.map:del(t,"cacert")
return e.map:del(t,e.option)
end
end
end
if s then
cert=ns:taboption("basic",Value,"cacert",
translate("Path to CA-Certificate"),
translate("directory or path/file").."<br />"..
translate("or")..i.." IGNORE "..o..
translate("to run HTTPS without verification of server certificates (insecure)"))
cert:depends("use_https","1")
cert.rmempty=false
cert.default="/etc/ssl/certs"
function cert.validate(a,t)
if https:formvalue(e)=="0"then
return""
end
if t then
if n.directory(t)
or n.file(t)
or t=="IGNORE"then
return t
end
end
return nil,err_tab_basic(a)..
translate("file or directory not found or not 'IGNORE'").." !"
end
end
src4=ns:taboption("advanced",ListValue,"ipv4_source",
translate("IP address source").." [IPv4]",
translate("Defines the source to read systems IPv4-Address from, that will be send to the DDNS provider"))
src4:depends("use_ipv6","0")
src4.default="network"
src4:value("network",translate("Network"))
src4:value("web",translate("URL"))
src4:value("interface",translate("Interface"))
src4:value("script",translate("Script"))
function src4.cfgvalue(e,a)
return t.read_value(e,a,"ip_source")
end
function src4.validate(a,t)
if usev6:formvalue(e)=="1"then
return""
elseif not b()then
return nil,err_tab_adv(a)..
translate("can not detect local IP. Please select a different Source combination")
else
return t
end
end
function src4.write(e,t,a)
if usev6:formvalue(t)=="1"then
return true
elseif a=="network"then
e.map:del(t,"ip_url")
e.map:del(t,"ip_interface")
e.map:del(t,"ip_script")
elseif a=="web"then
e.map:del(t,"ip_network")
e.map:del(t,"ip_interface")
e.map:del(t,"ip_script")
elseif a=="interface"then
e.map:del(t,"ip_network")
e.map:del(t,"ip_url")
e.map:del(t,"ip_script")
elseif a=="script"then
e.map:del(t,"ip_network")
e.map:del(t,"ip_url")
e.map:del(t,"ip_interface")
end
e.map:del(t,e.option)
return e.map:set(t,"ip_source",a)
end
src6=ns:taboption("advanced",ListValue,"ipv6_source",
translate("IP address source").." [IPv6]",
translate("Defines the source to read systems IPv6-Address from, that will be send to the DDNS provider"))
src6:depends("use_ipv6",1)
src6.default="network"
src6:value("network",translate("Network"))
src6:value("web",translate("URL"))
src6:value("interface",translate("Interface"))
src6:value("script",translate("Script"))
if not a then
src6.description=err_ipv6_other
end
function src6.cfgvalue(a,e)
return t.read_value(a,e,"ip_source")
end
function src6.validate(t,o)
if usev6:formvalue(e)=="0"then
return""
elseif not a then
return nil,err_tab_adv(t)..err_ipv6_plain
elseif not b()then
return nil,err_tab_adv(t)..
translate("can not detect local IP. Please select a different Source combination")
else
return o
end
end
function src6.write(t,e,a)
if usev6:formvalue(e)=="0"then
return true
elseif a=="network"then
t.map:del(e,"ip_url")
t.map:del(e,"ip_interface")
t.map:del(e,"ip_script")
elseif a=="web"then
t.map:del(e,"ip_network")
t.map:del(e,"ip_interface")
t.map:del(e,"ip_script")
elseif a=="interface"then
t.map:del(e,"ip_network")
t.map:del(e,"ip_url")
t.map:del(e,"ip_script")
elseif a=="script"then
t.map:del(e,"ip_network")
t.map:del(e,"ip_url")
t.map:del(e,"ip_interface")
end
t.map:del(e,t.option)
return t.map:set(e,"ip_source",a)
end
ipn4=ns:taboption("advanced",ListValue,"ipv4_network",
translate("Network").." [IPv4]",
translate("Defines the network to read systems IPv4-Address from"))
ipn4:depends("ipv4_source","network")
ipn4.default="wan"
h.cbi_add_networks(ipn4)
function ipn4.cfgvalue(e,a)
return t.read_value(e,a,"ip_network")
end
function ipn4.validate(a,t)
if usev6:formvalue(e)=="1"
or src4:formvalue(e)~="network"then
return""
else
return t
end
end
function ipn4.write(t,e,a)
if usev6:formvalue(e)=="1"
or src4:formvalue(e)~="network"then
return true
else
t.map:set(e,"interface",a)
t.map:del(e,t.option)
return t.map:set(e,"ip_network",a)
end
end
ipn6=ns:taboption("advanced",ListValue,"ipv6_network",
translate("Network").." [IPv6]")
ipn6:depends("ipv6_source","network")
ipn6.default="wan6"
h.cbi_add_networks(ipn6)
if a then
ipn6.description=translate("Defines the network to read systems IPv6-Address from")
else
ipn6.description=err_ipv6_other
end
function ipn6.cfgvalue(a,e)
return t.read_value(a,e,"ip_network")
end
function ipn6.validate(o,t)
if usev6:formvalue(e)=="0"
or src6:formvalue(e)~="network"then
return""
elseif a then
return t
else
return nil,err_tab_adv(o)..err_ipv6_plain
end
end
function ipn6.write(t,e,a)
if usev6:formvalue(e)=="0"
or src6:formvalue(e)~="network"then
return true
else
t.map:set(e,"interface",a)
t.map:del(e,t.option)
return t.map:set(e,"ip_network",a)
end
end
iurl4=ns:taboption("advanced",Value,"ipv4_url",
translate("URL to detect").." [IPv4]",
translate("Defines the Web page to read systems IPv4-Address from"))
iurl4:depends("ipv4_source","web")
iurl4.default="http://checkip.dyndns.com"
function iurl4.cfgvalue(a,e)
return t.read_value(a,e,"ip_url")
end
function iurl4.validate(a,o)
if usev6:formvalue(e)=="1"
or src4:formvalue(e)~="web"then
return""
elseif not o or#o==0 then
return nil,err_tab_adv(a)..translate("missing / required")
end
local e=t.parse_url(o)
if not(e.scheme=="http"or e.scheme=="https")then
return nil,err_tab_adv(a)..translate("must start with 'http://'")
elseif not e.host then
return nil,err_tab_adv(a).."<HOST> "..translate("missing / required")
elseif l.call([[nslookup ]]..e.host..[[>/dev/null 2>&1]])~=0 then
return nil,err_tab_adv(a)..translate("can not resolve host: ")..e.host
else
return o
end
end
function iurl4.write(t,e,a)
if usev6:formvalue(e)=="1"
or src4:formvalue(e)~="web"then
return true
else
t.map:del(e,t.option)
return t.map:set(e,"ip_url",a)
end
end
iurl6=ns:taboption("advanced",Value,"ipv6_url",
translate("URL to detect").." [IPv6]")
iurl6:depends("ipv6_source","web")
iurl6.default="http://checkipv6.dyndns.com"
if a then
iurl6.description=translate("Defines the Web page to read systems IPv6-Address from")
else
iurl6.description=err_ipv6_other
end
function iurl6.cfgvalue(a,e)
return t.read_value(a,e,"ip_url")
end
function iurl6.validate(o,i)
if usev6:formvalue(e)=="0"
or src6:formvalue(e)~="web"then
return""
elseif not a then
return nil,err_tab_adv(o)..err_ipv6_plain
elseif not i or#i==0 then
return nil,err_tab_adv(o)..translate("missing / required")
end
local e=t.parse_url(i)
if not(e.scheme=="http"or e.scheme=="https")then
return nil,err_tab_adv(o)..translate("must start with 'http://'")
elseif not e.host then
return nil,err_tab_adv(o).."<HOST> "..translate("missing / required")
elseif l.call([[nslookup ]]..e.host..[[>/dev/null 2>&1]])~=0 then
return nil,err_tab_adv(o)..translate("can not resolve host: ")..e.host
else
return i
end
end
function iurl6.write(t,e,a)
if usev6:formvalue(e)=="0"
or src6:formvalue(e)~="web"then
return true
else
t.map:del(e,t.option)
return t.map:set(e,"ip_url",a)
end
end
ipi=ns:taboption("advanced",ListValue,"ip_interface",
translate("Interface"),
translate("Defines the interface to read systems IP-Address from"))
ipi:depends("ipv4_source","interface")
ipi:depends("ipv6_source","interface")
for t,e in pairs(l.net.devices())do
net=h.iface_get_network(e)
if net and net~="loopback"then
ipi:value(e)
end
end
function ipi.validate(a,t)
if(usev6:formvalue(e)=="0"and src4:formvalue(e)~="interface")
or(usev6:formvalue(e)=="1"and src6:formvalue(e)~="interface")then
return""
else
return t
end
end
function ipi.write(t,e,a)
if(usev6:formvalue(e)=="0"and src4:formvalue(e)~="interface")
or(usev6:formvalue(e)=="1"and src6:formvalue(e)~="interface")then
return true
else
local o=h.iface_get_network(a)
t.map:set(e,"interface",o)
return t.map:set(e,t.option,a)
end
end
ips=ns:taboption("advanced",Value,"ip_script",
translate("Script"),
translate("User defined script to read systems IP-Address"))
ips:depends("ipv4_source","script")
ips:depends("ipv6_source","script")
ips.rmempty=false
ips.placeholder="/path/to/script.sh"
function ips.validate(o,t)
local a
if t then a=v.split(t," ")end
if(usev6:formvalue(e)=="0"and src4:formvalue(e)~="script")
or(usev6:formvalue(e)=="1"and src6:formvalue(e)~="script")then
return""
elseif not t or not(#t>0)or not y.access(a[1],"x")then
return nil,err_tab_adv(o)..
translate("not found or not executable - Sample: '/path/to/script.sh'")
else
return t
end
end
function ips.write(t,e,a)
if(usev6:formvalue(e)=="0"and src4:formvalue(e)~="script")
or(usev6:formvalue(e)=="1"and src6:formvalue(e)~="script")then
return true
else
return t.map:set(e,t.option,a)
end
end
eif4=ns:taboption("advanced",ListValue,"ipv4_interface",
translate("Event Network").." [IPv4]",
translate("Network on which the ddns-updater scripts will be started"))
eif4:depends("ipv4_source","web")
eif4:depends("ipv4_source","script")
eif4.default="wan"
h.cbi_add_networks(eif4)
function eif4.cfgvalue(e,a)
return t.read_value(e,a,"interface")
end
function eif4.validate(a,t)
if usev6:formvalue(e)=="1"
or src4:formvalue(e)=="network"
or src4:formvalue(e)=="interface"then
return""
else
return t
end
end
function eif4.write(t,e,a)
if usev6:formvalue(e)=="1"
or src4:formvalue(e)=="network"
or src4:formvalue(e)=="interface"then
return true
else
t.map:del(e,t.option)
return t.map:set(e,"interface",a)
end
end
eif6=ns:taboption("advanced",ListValue,"ipv6_interface",
translate("Event Network").." [IPv6]")
eif6:depends("ipv6_source","web")
eif6:depends("ipv6_source","script")
eif6.default="wan6"
h.cbi_add_networks(eif6)
if not a then
eif6.description=err_ipv6_other
else
eif6.description=translate("Network on which the ddns-updater scripts will be started")
end
function eif6.cfgvalue(e,a)
return t.read_value(e,a,"interface")
end
function eif6.validate(t,o)
if usev6:formvalue(e)=="0"
or src4:formvalue(e)=="network"
or src4:formvalue(e)=="interface"then
return""
elseif not a then
return nil,err_tab_adv(t)..err_ipv6_plain
else
return o
end
end
function eif6.write(t,e,a)
if usev6:formvalue(e)=="0"
or src4:formvalue(e)=="network"
or src4:formvalue(e)=="interface"then
return true
else
t.map:del(e,t.option)
return t.map:set(e,"interface",a)
end
end
if s or((m:get(e,"bind_network")or"")~="")then
bnet=ns:taboption("advanced",ListValue,"bind_network",
translate("Bind Network"))
bnet:depends("ipv4_source","web")
bnet:depends("ipv6_source","web")
bnet.rmempty=true
bnet.default=""
bnet:value("",translate("-- default --"))
h.cbi_add_networks(bnet)
function bnet.cfgvalue(e,t)
local t=AbstractValue.cfgvalue(e,t)
if not s and t~=""then
e.description=i..r..
translate("Binding to a specific network not supported")..d.."<br />"..
translate("please set to 'default'").." !"..o
else
e.description=translate("OPTIONAL: Network to use for communication")..
"<br />"..translate("Casual users should not change this setting")
end
return t
end
function bnet.validate(t,e)
if(e~=""and s)or e==""then return e end
return nil,err_tab_adv(t)..translate("Binding to a specific network not supported").." !"
end
end
if p or((m:get(e,"force_ipversion")or"0")~="0")then
fipv=ns:taboption("advanced",Flag,"force_ipversion",
translate("Force IP Version"))
fipv.orientation="horizontal"
function fipv.cfgvalue(e,t)
local t=AbstractValue.cfgvalue(e,t)
if not p and t~="0"then
e.description=i..r..
translate("Force IP Version not supported")..d.."<br />"..
translate("please disable").." !"..o
else
e.description=translate("OPTIONAL: Force the usage of pure IPv4/IPv6 only communication.")
end
return t
end
function fipv.validate(t,e)
if(e=="1"and p)or e=="0"then return e end
return nil,err_tab_adv(t)..translate("Force IP Version not supported")
end
function fipv.parse(e,a)
t.flag_parse(e,a)
end
function fipv.write(e,t,a)
if a=="1"then
return e.map:set(t,e.option,a)
else
return e.map:del(t,e.option)
end
end
end
dns=ns:taboption("advanced",Value,"dns_server",
translate("DNS-Server"),
translate("OPTIONAL: Use non-default DNS-Server to detect 'Registered IP'.").."<br />"..
translate("Format: IP or FQDN"))
dns.placeholder="mydns.lan"
function dns.validate(t,a)
if not a then
return""
elseif not n.host(a)then
return nil,err_tab_adv(t)..translate("use hostname, FQDN, IPv4- or IPv6-Address")
else
local o=usev6:formvalue(e)
local e=(fipv)and fipv:formvalue(e)or"0"
local e=[[/usr/lib/ddns/dynamic_dns_lucihelper.sh verify_dns ]]..
a..[[ ]]..o..[[ ]]..e
local e=l.call(e)
if e==0 then return a
elseif e==2 then return nil,err_tab_adv(t)..translate("nslookup can not resolve host")
elseif e==3 then return nil,err_tab_adv(t)..translate("nc (netcat) can not connect")
elseif e==4 then return nil,err_tab_adv(t)..translate("Forced IP Version don't matched")
else return nil,err_tab_adv(t)..translate("unspecific error")
end
end
end
if u or((m:get(e,"force_dnstcp")or"0")~="0")then
tcp=ns:taboption("advanced",Flag,"force_dnstcp",
translate("Force TCP on DNS"))
tcp.orientation="horizontal"
function tcp.cfgvalue(e,t)
local t=AbstractValue.cfgvalue(e,t)
if not u and t~="0"then
e.description=i..r..
translate("DNS requests via TCP not supported")..d.."<br />"..
translate("please disable").." !"..o
else
e.description=translate("OPTIONAL: Force the use of TCP instead of default UDP on DNS requests.")
end
return t
end
function tcp.validate(t,e)
if(e=="1"and u)or e=="0"then
return e
end
return nil,err_tab_adv(t)..translate("DNS requests via TCP not supported")
end
function tcp.parse(e,a)
t.flag_parse(e,a)
end
end
if w or((m:get(e,"proxy")or"")~="")then
pxy=ns:taboption("advanced",Value,"proxy",
translate("PROXY-Server"))
pxy.placeholder="user:password@myproxy.lan:8080"
function pxy.cfgvalue(e,t)
local t=AbstractValue.cfgvalue(e,t)
if not w and t~=""then
e.description=i..r..
translate("PROXY-Server not supported")..d.."<br />"..
translate("please remove entry").."!"..o
else
e.description=translate("OPTIONAL: Proxy-Server for detection and updates.").."<br />"..
translate("Format")..": "..i.."[user:password@]proxyhost:port"..o.."<br />"..
translate("IPv6 address must be given in square brackets")..": "..
i.." [2001:db8::1]:8080"..o
end
return t
end
function pxy.validate(t,a)
if not a then
return""
elseif w then
local o=usev6:formvalue(e)or"0"
local e=(fipv)and fipv:formvalue(e)or"0"
local e=[[/usr/lib/ddns/dynamic_dns_lucihelper.sh verify_proxy ]]..
a..[[ ]]..o..[[ ]]..e
local e=l.call(e)
if e==0 then return a
elseif e==2 then return nil,err_tab_adv(t)..translate("nslookup can not resolve host")
elseif e==3 then return nil,err_tab_adv(t)..translate("nc (netcat) can not connect")
elseif e==4 then return nil,err_tab_adv(t)..translate("Forced IP Version don't matched")
elseif e==5 then return nil,err_tab_adv(t)..translate("proxy port missing")
else return nil,err_tab_adv(t)..translate("unspecific error")
end
else
return nil,err_tab_adv(t)..translate("PROXY-Server not supported")
end
end
end
slog=ns:taboption("advanced",ListValue,"use_syslog",
translate("Log to syslog"),
translate("Writes log messages to syslog. Critical Errors will always be written to syslog."))
slog.default="2"
slog:value("0",translate("No logging"))
slog:value("1",translate("Info"))
slog:value("2",translate("Notice"))
slog:value("3",translate("Warning"))
slog:value("4",translate("Error"))
logf=ns:taboption("advanced",Flag,"use_logfile",
translate("Log to file"),
translate("Writes detailed messages to log file. File will be truncated automatically.").."<br />"..
translate("File")..[[: "]]..log_dir..[[/]]..e..[[.log"]])
logf.orientation="horizontal"
logf.rmempty=false
logf.default="1"
function logf.parse(e,a)
t.flag_parse(e,a)
end
ci=ns:taboption("timer",Value,"check_interval",
translate("Check Interval"))
ci.template="ddns/detail_value"
ci.default=10
ci.rmempty=false
function ci.validate(o,a)
if not n.uinteger(a)
or tonumber(a)<1 then
return nil,err_tab_timer(o)..translate("minimum value 5 minutes == 300 seconds")
end
local e=t.calc_seconds(a,cu:formvalue(e))
if e>=300 then
return a
else
return nil,err_tab_timer(o)..translate("minimum value 5 minutes == 300 seconds")
end
end
function ci.write(e,a,o)
local t=t.calc_seconds(o,cu:formvalue(a))
if t~=600 then
return e.map:set(a,e.option,o)
else
e.map:del(a,"check_unit")
return e.map:del(a,e.option)
end
end
cu=ns:taboption("timer",ListValue,"check_unit","not displayed, but needed otherwise error",
translate("Interval to check for changed IP".."<br />"..
"Values below 5 minutes == 300 seconds are not supported"))
cu.template="ddns/detail_lvalue"
cu.default="minutes"
cu.rmempty=false
cu:value("seconds",translate("seconds"))
cu:value("minutes",translate("minutes"))
cu:value("hours",translate("hours"))
function cu.write(a,o,e)
local t=t.calc_seconds(ci:formvalue(o),e)
if t~=600 then
return a.map:set(o,a.option,e)
else
return true
end
end
fi=ns:taboption("timer",Value,"force_interval",
translate("Force Interval"))
fi.template="ddns/detail_value"
fi.default=72
fi.rmempty=false
function fi.validate(o,a)
if not n.uinteger(a)
or tonumber(a)<0 then
return nil,err_tab_timer(o)..translate("minimum value '0'")
end
local s=t.calc_seconds(a,fu:formvalue(e))
if s==0 then
return a
end
local i=ci:formvalue(e)
if not n.uinteger(i)then
return""
end
local e=t.calc_seconds(i,cu:formvalue(e))
if s>=e then
return a
end
return nil,err_tab_timer(o)..translate("must be greater or equal 'Check Interval'")
end
function fi.write(e,a,o)
local t=t.calc_seconds(o,fu:formvalue(a))
if t~=259200 then
return e.map:set(a,e.option,o)
else
e.map:del(a,"force_unit")
return e.map:del(a,e.option)
end
end
fu=ns:taboption("timer",ListValue,"force_unit","not displayed, but needed otherwise error",
translate("Interval to force updates send to DDNS Provider".."<br />"..
"Setting this parameter to 0 will force the script to only run once".."<br />"..
"Values lower 'Check Interval' except '0' are not supported"))
fu.template="ddns/detail_lvalue"
fu.default="hours"
fu.rmempty=false
fu:value("minutes",translate("minutes"))
fu:value("hours",translate("hours"))
fu:value("days",translate("days"))
function fu.write(i,o,a)
local e=t.calc_seconds(fi:formvalue(o),a)
if e~=259200 and e~=0 then
return i.map:set(o,i.option,a)
else
return true
end
end
rc=ns:taboption("timer",Value,"retry_count")
rc.title=translate("Error Retry Counter")
rc.description=translate("On Error the script will stop execution after given number of retrys")
.."<br />"
..translate("The default setting of '0' will retry infinite.")
rc.default=0
rc.rmempty=false
function rc.validate(t,e)
if not n.uinteger(e)then
return nil,err_tab_timer(t)..translate("minimum value '0'")
else
return e
end
end
function rc.write(e,a,t)
if tonumber(t)~=e.default then
return e.map:set(a,e.option,t)
else
return e.map:del(a,e.option)
end
end
ri=ns:taboption("timer",Value,"retry_interval",
translate("Error Retry Interval"))
ri.template="ddns/detail_value"
ri.default=60
ri.rmempty=false
function ri.validate(t,e)
if not n.uinteger(e)
or tonumber(e)<1 then
return nil,err_tab_timer(t)..translate("minimum value '1'")
else
return e
end
end
function ri.write(e,a,o)
local t=t.calc_seconds(o,ru:formvalue(a))
if t~=60 then
return e.map:set(a,e.option,o)
else
e.map:del(a,"retry_unit")
return e.map:del(a,e.option)
end
end
ru=ns:taboption("timer",ListValue,"retry_unit","not displayed, but needed otherwise error",
translate("On Error the script will retry the failed action after given time"))
ru.template="ddns/detail_lvalue"
ru.default="seconds"
ru.rmempty=false
ru:value("seconds",translate("seconds"))
ru:value("minutes",translate("minutes"))
function ru.write(e,o,a)
local t=t.calc_seconds(ri:formvalue(o),a)
if t~=60 then
return e.map:set(o,e.option,a)
else
return true
end
end
lv=ns:taboption("logview",DummyValue,"_logview")
lv.template="ddns/detail_logview"
lv.inputtitle=translate("Read / Reread log file")
lv.rows=50
function lv.cfgvalue(t,e)
local e=log_dir.."/"..e..".log"
if y.access(e)then
return e.."\n"..translate("Please press [Read] button")
end
return e.."\n"..translate("File not found or empty")
end
return m
