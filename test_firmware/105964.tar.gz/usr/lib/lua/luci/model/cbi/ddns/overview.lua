local i=require"nixio.fs"
local n=require"luci.controller.ddns"
local o=require"luci.dispatcher"
local h=require"luci.http"
local t=require"luci.sys"
local e=require"luci.tools.ddns"
show_hints=not(e.check_ipv6()
and e.check_ssl()
and e.check_proxy()
and e.check_bind_host()
)
need_update=e.ipkg_ver_compare(e.ipkg_ver_installed("ddns-scripts"),"<<",n.DDNS_MIN)
font_red=[[<font color="red">]]
font_off=[[</font>]]
bold_on=[[<strong>]]
bold_off=[[</strong>]]
m=Map("ddns")
m.title=[[</a><a href="javascript:alert(']]
..translate("Version Information")
..[[\n\nluci-app-ddns]]
..[[\n\t]]..translate("Version")..[[:\t]]..e.ipkg_ver_installed("luci-app-ddns")
..[[\n\nddns-scripts ]]..translate("required")..[[:]]
..[[\n\t]]..translate("Version")..[[:\t]]..n.DDNS_MIN..[[ ]]..translate("or higher")
..[[\n\nddns-scripts ]]..translate("installed")..[[:]]
..[[\n\t]]..translate("Version")..[[:\t]]..e.ipkg_ver_installed("ddns-scripts")
..[[\n\n]]
..[[')">]]
..translate("Dynamic DNS")
m.description=translate("Dynamic DNS allows that your router can be reached with "..
"a fixed hostname while having a dynamically changing "..
"IP address.")
m.on_after_commit=function(e)
if e.changed then
if t.init.enabled("ddns")then
os.execute("/etc/init.d/ddns restart")
else
os.execute("killall -1 dynamic_dns_updater.sh")
end
end
end
a=m:section(SimpleSection)
a.template="ddns/overview_status"
if show_hints or need_update or not t.init.enabled("ddns")then
s=m:section(SimpleSection,translate("Hints"))
if need_update then
local e=s:option(DummyValue,"_update_needed")
e.titleref=o.build_url("admin","system","packages")
e.rawhtml=true
e.title=font_red..bold_on..
translate("Software update required")..bold_off..font_off
e.value=translate("The currently installed 'ddns-scripts' package did not support all available settings.")..
"<br />"..
translate("Please update to the current version!")
end
if not t.init.enabled("ddns")then
local e=s:option(DummyValue,"_not_enabled")
e.titleref=o.build_url("admin","system","startup")
e.rawhtml=true
e.title=bold_on..
translate("DDNS Autostart disabled")..bold_off
e.value=translate("Currently DDNS updates are not started at boot or on interface events.".."<br />"..
"You can start/stop each configuration here. It will run until next reboot.")
end
if show_hints then
local e=s:option(DummyValue,"_separate")
e.titleref=o.build_url("admin","services","ddns","hints")
e.rawhtml=true
e.title=bold_on..
translate("Show more")..bold_off
e.value=translate("Follow this link".."<br />"..
"You will find more hints to optimize your system to run DDNS scripts with all options")
end
end
ts=m:section(TypedSection,"service",
translate("Overview"),
translate("Below is a list of configured DDNS configurations and their current state.")
.."<br />"
..translate("If you want to send updates for IPv4 and IPv6 you need to define two separate Configurations "
.."i.e. 'myddns_ipv4' and 'myddns_ipv6'")
.."<br />"
..[[<a href="]]..o.build_url("admin","services","ddns","global")..[[">]]
..translate("To change global settings click here")..[[</a>]])
ts.sectionhead=translate("Configuration")
ts.template="cbi/tblsection"
ts.addremove=true
ts.extedit=o.build_url("admin","services","ddns","detail","%s")
function ts.create(e,t)
AbstractSection.create(e,t)
h.redirect(e.extedit:format(t))
end
dom=ts:option(DummyValue,"_domainIP",
translate("Hostname/Domain").."<br />"..translate("Registered IP"))
dom.template="ddns/overview_doubleline"
function dom.set_one(e,t)
local e=e.map:get(t,"domain")or""
if e~=""then
return e
else
return[[<em>]]..translate("config error")..[[</em>]]
end
end
function dom.set_two(e,a)
local o=e.map:get(a,"domain")or""
if o==""then return""end
local h=e.map:get(a,"dnsserver")or""
local n=tonumber(e.map:get(a,"use_ipv6")or 0)
local s=tonumber(e.map:get(a,"force_ipversion")or 0)
local a=tonumber(e.map:get(a,"force_dnstcp")or 0)
local e=[[/usr/lib/ddns/dynamic_dns_lucihelper.sh]]
if not i.access(e,"rwx","rx","rx")then
i.chmod(e,755)
end
e=e..[[ get_registered_ip ]]..o..[[ ]]..n..
[[ ]]..s..[[ ]]..a..[[ ]]..h
local e=t.exec(e)
if e==""then e=translate("no data")end
return e
end
ena=ts:option(Flag,"enabled",
translate("Enabled"))
ena.template="ddns/overview_enabled"
ena.rmempty=false
function ena.parse(a,t)
e.flag_parse(a,t)
end
upd=ts:option(DummyValue,"_update",
translate("Last Update").."<br />"..translate("Next Update"))
upd.template="ddns/overview_doubleline"
function upd.set_one(a,o)
local a=t.uptime()
local t=e.get_lastupd(o)
if t>a then
t=0
end
if t==0 then
return translate("never")
else
local t=os.time()-a+t
return e.epoch2date(t)
end
end
function upd.set_two(i,o)
local s=tonumber(i.map:get(o,"enabled")or 0)
local a=translate("unknown error")
local n=tonumber(i.map:get(o,"force_interval")or 72)
local i=i.map:get(o,"force_unit")or"hours"
local i=e.calc_seconds(n,i)
local n=t.uptime()
local t=e.get_lastupd(o)
if t>n then
t=0
end
local o=e.get_pid(o)
if t>0 then
local t=os.time()-n+t+i
datelast=e.epoch2date(t)
end
if o>0 and(t+i-n)<0 then
a=translate("Verify")
elseif i==0 then
a=translate("Run once")
elseif o==0 and s==0 then
a=translate("Disabled")
elseif o==0 and s~=0 then
a=translate("Stopped")
end
return a
end
btn=ts:option(Button,"_startstop",
translate("Process ID").."<br />"..translate("Start / Stop"))
btn.template="ddns/overview_startstop"
function btn.cfgvalue(a,t)
local e=e.get_pid(t)
if e>0 then
btn.inputtitle="PID: "..e
btn.inputstyle="reset"
btn.disabled=false
elseif(a.map:get(t,"enabled")or"0")~="0"then
btn.inputtitle=translate("Start")
btn.inputstyle="apply"
btn.disabled=false
else
btn.inputtitle="----------"
btn.inputstyle="button"
btn.disabled=true
end
return true
end
return m
