local t,e,t=...
local r,d,h
local s,t,a,n,o,i
r=e:taboption("general",Value,"server",translate("L2TP Server"))
r.datatype="host"
d=e:taboption("general",Value,"username",translate("PAP/CHAP username"))
h=e:taboption("general",Value,"password",translate("PAP/CHAP password"))
h.password=true
if luci.model.network:has_ipv6()then
s=e:taboption("advanced",Flag,"ipv6",
translate("Enable IPv6 negotiation on the PPP link"))
s.default=s.disabled
end
t=e:taboption("advanced",Flag,"defaultroute",
translate("Use default gateway"),
translate("If unchecked, no default route is configured"))
t.default=t.enabled
a=e:taboption("advanced",Value,"metric",
translate("Use gateway metric"))
a.placeholder="0"
a.datatype="uinteger"
a:depends("defaultroute",t.enabled)
n=e:taboption("advanced",Flag,"peerdns",
translate("Use DNS servers advertised by peer"),
translate("If unchecked, the advertised DNS server addresses are ignored"))
n.default=n.enabled
o=e:taboption("advanced",DynamicList,"dns",
translate("Use custom DNS servers"))
o:depends("peerdns","")
o.datatype="ipaddr"
o.cast="string"
i=e:taboption("advanced",Value,"mtu",translate("Override MTU"))
i.placeholder="1500"
i.datatype="max(9200)"
