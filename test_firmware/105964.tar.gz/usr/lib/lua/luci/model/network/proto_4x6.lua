local a=luci.model.network
local e,e
for e,t in ipairs({"dslite"})do
local e=a:register_protocol(t)
function e.get_i18n(e)
if t=="dslite"then
return luci.i18n.translate("Dual-Stack Lite (RFC6333)")
end
end
function e.ifname(e)
return t.."-"..e.sid
end
function e.opkg_package(e)
if t=="dslite"then
return"ds-lite"
end
end
function e.is_installed(e)
return nixio.fs.access("/lib/netifd/proto/"..t..".sh")
end
function e.is_floating(e)
return true
end
function e.is_virtual(e)
return true
end
function e.get_interfaces(e)
return nil
end
function e.contains_interface(e,t)
return(a:ifnameof(ifc)==e:ifname())
end
a:register_pattern_virtual("^%s-%%w"%t)
end
