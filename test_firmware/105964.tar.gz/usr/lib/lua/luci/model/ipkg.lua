local n=require"os"
local h=require"io"
local o=require"nixio.fs"
local e=require"luci.util"
local d=type
local t=pairs
local a=error
local e=table
local s="opkg --force-removal-of-dependent-packages --force-overwrite --nocase"
local r="/etc/opkg.conf"
module"luci.model.ipkg"
local function i(a,...)
local e=""
for a,t in t({...})do
e=e.." '"..t:gsub("'","").."'"
end
local e="%s %s %s >/tmp/opkg.stdout 2>/tmp/opkg.stderr"%{s,a,e}
local a=n.execute(e)
local t=o.readfile("/tmp/opkg.stderr")
local e=o.readfile("/tmp/opkg.stdout")
o.unlink("/tmp/opkg.stderr")
o.unlink("/tmp/opkg.stdout")
return a,e or"",t or""
end
local function l(t)
if d(t)~="function"then
a("OPKG: Invalid rawdata given")
end
local n={}
local e={}
local o=nil
for i in t do
if i:sub(1,1)~=" "then
local t,a=i:match("(.-): ?(.*)%s*")
if t and a then
if t=="Package"then
e={Package=a}
n[a]=e
elseif t=="Status"then
e.Status={}
for t in a:gmatch("([^ ]+)")do
e.Status[t]=true
end
else
e[t]=a
end
o=t
end
else
e[o]=e[o].."\n"..i
end
end
return n
end
local function a(t,e)
local t=s.." "..t
if e then
t=t.." '"..e:gsub("'","").."'"
end
local e=n.tmpname()
n.execute(t..(" >%s 2>/dev/null"%e))
local t=l(h.lines(e))
n.remove(e)
return t
end
function info(e)
return a("info",e)
end
function status(e)
return a("status",e)
end
function install(...)
return i("install",...)
end
function installed(e)
local e=status(e)[e]
return(e and e.Status and e.Status.installed)
end
function remove(...)
return i("remove",...)
end
function update()
return i("update")
end
function upgrade()
return i("upgrade")
end
function _list(t,e,n)
local i=h.popen(s.." "..t..
(e and(" '%s'"%e:gsub("'",""))or""))
if i then
local e,t,a
while true do
local o=i:read("*l")
if not o then break end
e,t,a=o:match("^(.-) %- (.-) %- (.+)")
if not e then
e,t=o:match("^(.-) %- (.+)")
a=""
end
n(e,t,a)
e=nil
t=nil
a=nil
end
i:close()
end
end
function list_all(e,t)
_list("list",e,t)
end
function list_installed(t,e)
_list("list_installed",t,e)
end
function find(t,e)
_list("find",t,e)
end
function overlay_root()
local t="/"
local a=h.open(r,"r")
if a then
local e
repeat
e=a:read("*l")
if e and e:match("^%s*option%s+overlay_root%s+")then
t=e:match("^%s*option%s+overlay_root%s+(%S+)")
local e=o.stat(t)
if not e or e.type~="dir"then
t="/"
end
break
end
until not e
a:close()
end
return t
end
