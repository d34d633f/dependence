local d=require"os"
local e=require"uci"
local r=require"luci.util"
local s=require"table"
local t,t,t=setmetatable,rawget,rawset
local t,i=require,getmetatable
local a,n,t=error,pairs,ipairs
local a,l,h,o=type,tostring,tonumber,unpack
module"luci.model.uci"
cursor=e.cursor
APIVERSION=e.APIVERSION
function cursor_state()
return cursor(nil,"/var/state")
end
inst=cursor()
inst_state=cursor_state()
local e=i(inst)
function e.apply(a,e,t)
e=a:_affected(e)
if t then
return{"/sbin/luci-reload",o(e)}
else
return d.execute("/sbin/luci-reload %s >/dev/null 2>&1"
%s.concat(e," "))
end
end
function e.delete_all(s,i,h,e)
local o={}
if a(e)=="table"then
local t=e
e=function(a)
for t,e in n(t)do
if a[t]~=e then
return false
end
end
return true
end
end
local function a(t)
if not e or e(t)then
o[#o+1]=t[".name"]
end
end
s:foreach(i,h,a)
for t,e in t(o)do
s:delete(i,e)
end
end
function e.section(o,a,i,e,n)
local t=true
if e then
t=o:set(a,e,i)
else
e=o:add(a,i)
t=e and true
end
if t and n then
t=o:tset(a,e,n)
end
return t and e
end
function e.tset(a,o,s,t)
local e=true
for t,i in n(t)do
if t:sub(1,1)~="."then
e=e and a:set(o,s,t,i)
end
end
return e
end
function e.get_bool(e,...)
local e=e:get(...)
return(e=="1"or e=="true"or e=="yes"or e=="on")
end
function e.get_list(i,e,t,o)
if e and t and o then
local e=i:get(e,t,o)
return(a(e)=="table"and e or{e})
end
return nil
end
function e.get_first(n,s,o,e,t)
local i=t
n:foreach(s,o,
function(o)
local e=not e and o['.name']or o[e]
if a(t)=="number"then
e=h(e)
elseif a(t)=="boolean"then
e=(e=="1"or e=="true"or
e=="yes"or e=="on")
end
if e~=nil then
i=e
return false
end
end)
return i
end
function e.set_list(n,t,i,o,e)
if t and i and o then
return n:set(
t,i,o,
(a(e)=="table"and e or{e})
)
end
return false
end
function e._affected(o,e)
e=a(e)=="table"and e or{e}
local o=cursor()
o:load("ucitrack")
local a={}
local function i(n)
local a={n}
local e={}
o:foreach("ucitrack",n,
function(a)
if a.affects then
for a,t in t(a.affects)do
e[#e+1]=t
end
end
end)
for o,e in t(e)do
for t,e in t(i(e))do
a[#a+1]=e
end
end
return a
end
for o,e in t(e)do
for t,e in t(i(e))do
if not r.contains(a,e)then
a[#a+1]=e
end
end
end
return a
end
function e.substate(t)
e._substates=e._substates or{}
e._substates[t]=e._substates[t]or cursor_state()
return e._substates[t]
end
local a=e.load
function e.load(t,...)
if e._substates and e._substates[t]then
a(e._substates[t],...)
end
return a(t,...)
end
local a=e.unload
function e.unload(t,...)
if e._substates and e._substates[t]then
a(e._substates[t],...)
end
return a(t,...)
end
