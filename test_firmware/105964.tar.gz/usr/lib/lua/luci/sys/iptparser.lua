local i={}
i.util=require"luci.util"
i.sys=require"luci.sys"
i.ip=require"luci.ip"
local n,s,r=tonumber,ipairs,table
module("luci.sys.iptparser")
IptParser=i.util.class()
function IptParser.__init__(e,t)
e._family=(n(t)==6)and 6 or 4
e._rules={}
e._chains={}
if e._family==4 then
e._nulladdr="0.0.0.0/0"
e._tables={"filter","nat","mangle","raw"}
e._command="iptables -t %s --line-numbers -nxvL"
else
e._nulladdr="::/0"
e._tables={"filter","mangle","raw"}
e._command="ip6tables -t %s --line-numbers -nxvL"
end
e:_parse_rules()
end
function IptParser.find(o,e)
local e=e or{}
local i={}
e.source=e.source and o:_parse_addr(e.source)
e.destination=e.destination and o:_parse_addr(e.destination)
for t,a in s(o._rules)do
local t=true
if not(not e.table or e.table:lower()==a.table)then
t=false
end
if not(t==true and(
not e.chain or e.chain==a.chain
))then
t=false
end
if not(t==true and(
not e.target or e.target==a.target
))then
t=false
end
if not(t==true and(
not e.protocol or a.protocol=="all"or
e.protocol:lower()==a.protocol
))then
t=false
end
if not(t==true and(
not e.source or a.source==o._nulladdr or
o:_parse_addr(a.source):contains(e.source)
))then
t=false
end
if not(t==true and(
not e.destination or a.destination==o._nulladdr or
o:_parse_addr(a.destination):contains(e.destination)
))then
t=false
end
if not(t==true and(
not e.inputif or a.inputif=="*"or
e.inputif==a.inputif
))then
t=false
end
if not(t==true and(
not e.outputif or a.outputif=="*"or
e.outputif==a.outputif
))then
t=false
end
if not(t==true and(
not e.flags or a.flags==e.flags
))then
t=false
end
if not(t==true and(
not e.options or
o:_match_options(a.options,e.options)
))then
t=false
end
if t==true then
i[#i+1]=a
end
end
return i
end
function IptParser.resync(e)
e._rules={}
e._chain=nil
e:_parse_rules()
end
function IptParser.tables(e)
return e._tables
end
function IptParser.chains(e,o)
local a={}
local t={}
for o,e in s(e:find({table=o}))do
if not a[e.chain]then
a[e.chain]=true
t[#t+1]=e.chain
end
end
return t
end
function IptParser.chain(t,e,a)
return t._chains[e:lower()]and t._chains[e:lower()][a]
end
function IptParser.is_custom_target(t,e)
for a,t in s(t._rules)do
if t.chain==e then
return true
end
end
return false
end
function IptParser._parse_addr(t,e)
if t._family==4 then
return i.ip.IPv4(e)
else
return i.ip.IPv6(e)
end
end
function IptParser._parse_rules(a)
for e,h in s(a._tables)do
a._chains[h]={}
for e,o in s(i.util.execl(a._command%h))do
if o:find("^Chain ")==1 then
local t
local e,s,r,i=o:match(
"^Chain ([^%s]*) %(policy (%w+) "..
"(%d+) packets, (%d+) bytes%)"
)
if not e then
e,t=o:match(
"^Chain ([^%s]*) %((%d+) references%)"
)
end
a._chain=e
a._chains[h][e]={
policy=s,
packets=n(r or 0),
bytes=n(i or 0),
references=n(t or 0),
rules={}
}
else
if o:find("%d")==1 then
local t=i.util.split(o,"%s+",nil,true)
local e={}
if o:match("^%d+%s+%d+%s+%d+%s%s")then
r.insert(t,4,nil)
end
if a._family==6 then
r.insert(t,6,"--")
end
e["table"]=h
e["chain"]=a._chain
e["index"]=n(t[1])
e["packets"]=n(t[2])
e["bytes"]=n(t[3])
e["target"]=t[4]
e["protocol"]=t[5]
e["flags"]=t[6]
e["inputif"]=t[7]
e["outputif"]=t[8]
e["source"]=t[9]
e["destination"]=t[10]
e["options"]={}
for o=11,#t do
if#t[o]>0 then
e["options"][o-10]=t[o]
end
end
a._rules[#a._rules+1]=e
a._chains[h][a._chain].rules[
#a._chains[h][a._chain].rules+1
]=e
end
end
end
end
a._chain=nil
end
function IptParser._match_options(e,t,a)
local e={}
for a,t in s(t)do e[t]=true end
for a,t in s(a)do
if not e[t]then
return false
end
end
return true
end
