#!/bin/sh

if ! grep -q "stat.sh" /etc/crontabs/root; then
	M=$(tr -cd 0-9 </dev/urandom | head -c 3 | awk '{print $1 % 60}')
	H=$(tr -cd 0-9 </dev/urandom | head -c 3 | awk '{print $1 % 24}')
	echo "# $M $H * * * /sbin/stat.sh" >> /etc/crontabs/root
fi

exit 0
