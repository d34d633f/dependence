#!/bin/sh
echo [$0] $1 ... > /dev/console
TROOT=`rgdb -i -g /runtime/template_root`
[ "$TROOT" = "" ] && TROOT="/etc/templates"
case "$1" in
start|restart)
if [ "`rgdb -i -g /runtime/wireless/setting/status`" = "0" ]; then
        rgdb -i -s /runtime/wireless/setting/status 1
	sh /etc/templates/autorekey.sh start &> /dev/console # yuda add autorekey
	sleep 1

	[ -f /var/run/multi_ssid_stop.sh ] && sh /var/run/multi_ssid_stop.sh > /dev/console
	[ -f /var/run/wlan_stop.sh ] && sh /var/run/wlan_stop.sh > /dev/console

	echo "start WLAN ....."     > /dev/console
	rgdb -A $TROOT/wlan_run.php -V generate_start=1 > /var/run/wlan_start.sh
	rgdb -A $TROOT/wlan_run.php -V generate_start=0 > /var/run/wlan_stop.sh
#	rgdb -A $TROOT/multi_ssid_run.php -V generate_start=1 > /var/run/multi_ssid_start.sh  # jack add multi_ssid 09/03/07
        rgdb -A $TROOT/multi_ssid_run.php -V generate_start=0 > /var/run/multi_ssid_stop.sh   # jack add multi_ssid 09/03/07
        rgdb -A $TROOT/__vlan.php -V generate_start=1 > /var/run/vlan_start.sh  # jack add multi_ssid 09/03/07
        rgdb -A $TROOT/__vlan.php -V generate_start=0 > /var/run/vlan_stop.sh   # jack add multi_ssid 09/03/07
        rgdb -A $TROOT/wlan_insmod.php > /var/run/wlan_insmod.sh        # leave insert module alone        
	rgdb -A $TROOT/__wlan_device_up.php -V generate_start=1 > /var/run/wlan_device_up.sh  # jack add multi_ssid 09/03/07
	rgdb -A $TROOT/__wlan_daemon_up.php -V generate_start=1 > /var/run/wlan_daemon_up.sh  # jack add multi_ssid 09/03/07

	sh /var/run/wlan_insmod.sh > /dev/console #  leave insert module alone
       	# check wifi0 PHY before wlan start
        if [ "`ifconfig wifi0 | grep wifi0 | cut -b 0-5`" = "wifi0" ]; then
		sh /var/run/wlan_start.sh > /dev/console
		sh /var/run/wlan_daemon_up.sh > /dev/console
#	        sh /var/run/wlan_device_up.sh > /dev/console      
		rgdb -A $TROOT/__auth_topology.php -V generate_start=1 > /var/run/auth_topology_start.sh # log_luo add for new hostapd and wpa_supplicant
		rgdb -A $TROOT/__auth_topology.php -V generate_start=0 > /var/run/auth_topology_stop.sh # log_luo add for new hostapd and wpa_supplicant
		sh  /var/run/auth_topology_start.sh &> /dev/console
                echo "sleep 5....."     > /dev/console
                sleep 5
                sh /var/run/wlan_device_up.sh > /dev/console 
		sh /var/run/wlan_servd_start.sh > /dev/console
	        sh /var/run/vlan_start.sh > /dev/console
	fi
	rgdb -i -s /rumtime/wlan/inf:1/autorekey/first 0
	rgdb -i -s /runtime/wireless/setting/status 0
	if [ "`rgdb -i -g /wlan/inf:1/ap_mode`" = "0" ]; then
                sh /etc/templates/lld2d.sh restart > /dev/console
        else
                sh /etc/templates/lld2d.sh stop  > /dev/console
        fi

	submit QOS_TC_TM;  # restart qos and traffic manager module;
	submit NETFILTER;  #CONFIG_NETFILTER_FOR_THROUGHPUT
	
	submit ARP_SPOOFING > /dev/null	 # eric fu , arp spoofing disable in apc mode.
	CheckFreeMEM & > /dev/console
	sleep 30;
#	sh /etc/templates/txpower.sh > /dev/console
fi		
	;;
stop)
if [ "`rgdb -i -g /runtime/wireless/setting/status`" = "0" ]; then
	rgdb -i -s /runtime/wireless/setting/status 1
	
	#STOP QOS
	submit QOS_TC_TM_STOP;

	if [ -f /var/run/autorekey_stop.sh ]; then  # yuda add autorekey
		sh /var/run/autorekey_stop.sh > /dev/console  # yuda add autorekey
		rm -f /var/run/autorekey_stop.sh  # yuda add autorekey
		rm -f /var/run/autorekey_start.sh  # yuda add autorekey
	fi
	if [ -f /var/run/auth_topology_stop.sh ]; then
		sh /var/run/auth_topology_stop.sh > /dev/console
		rm -f var/run/auth_topology_stop.sh
	fi
	if [ -f /var/run/vlan_stop.sh ]; then             # jack add multi_ssid 29/03/07 
		sh /var/run/vlan_stop.sh > /dev/console
		rm -f /var/run/vlan_stop.sh
	fi
	if [ -f /var/run/multi_ssid_stop.sh ]; then             # jack add multi_ssid 29/03/07 
	        sh /var/run/multi_ssid_stop.sh > /dev/console
		rm -f /var/run/multi_ssid_stop.sh
	fi
	if [ -f /var/run/wlan_stop.sh ]; then
		sh /var/run/wlan_stop.sh > /dev/console
		rm -f /var/run/wlan_stop.sh
	fi
	rgdb -i -s /runtime/wireless/setting/status 0
fi	
	;;
*)
	echo "usage: wlan.sh {start|stop|restart}" > /dev/console
#	echo "       if option "a" or "g" are not give," > /dev/console
#	echo "       both wlan would be start|stop|restart." > /dev/console
	;;
esac
