#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");
$WLAN = "/wlan/inf:1";  // b, g, n band
$multi_ssid_path = $WLAN."/multi";
$sys = "/sys";
$eth = "/lan/ethernet";
$wlan_enable = query("/wlan/inf:1/enable");

$multi_total_state = query($multi_ssid_path."/state");  
$ap_mode	= query($WLAN."/ap_mode");  // "1" #1--->a   0---> b,g,n
$wlanif = query("/runtime/layout/wlanif");
$wlanmac= query("/runtime/layout/wlanmac");
$wlan_ap_operate_mode = query($WLAN."/ap_mode");
if ($ap_mode == 4)  // WDS without AP // WDSwithoutAP_bug_0321
{    $withoutap = 1; }
else  // ($WLAN == 3)  WDS with AP
{    $withoutap = 0; }


if (query($WLAN."/enable")!=1)
{
    	echo "echo WLAN is disabled ! > /dev/console\n";
	exit;
}
if ($wlan_ap_operate_mode==1)
{
 	echo "echo APC MODE  > /dev/console\n";	
	exit;
}
anchor($WLAN);
/* common cmd */
$IWCONF="iwconfig ".$wlanif;
require("/etc/templates/troot.php");
$auth_mode = query($WLAN."/authentication");
$ap_igmp_pid = "/var/run/ap_igmp.pid";
// $wlan_ap_operate_mode = query($WLAN."/ap_mode");
$W_PATH=$WLAN."/";

//****************************Device UP*********************************************

//~~~~~~~~~~APMDOE: ath0 up~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	
if($wlan_enable == 1)
{
echo "ifconfig ".$wlanif." up\n";
if (query("/wlan/inf:1/autochannel")==1) {echo $IWCONF." freq 0\n";}	//erial_acs_201009
//~~~~~~~~~~APMDOE: ath0 add to br~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
echo "brctl addif br0 ".$wlanif."\n";

if ($wlan_ap_operate_mode==2)
{
	echo "sleep 3\n";
 	echo "ifconfig ath1 up\n";
	echo "ifconfig br0 hw ether `ifconfig ath1 | grep ath1 | scut -f5`\n";	
	echo "sh ".$template_root."/apr_loop.sh &\n";	
} else{ 
	echo "ifconfig br0 hw ether ".$wlanmac." \n";   //switch apr to apc/wds will cause ping fail,william_201207.
}

$auth_mode = query("/wlan/inf:1/authentication");

//~~~~~~~~~MSSID : ath1-8 up~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if ($multi_total_state == 1)
{
	$index=0; 
       	//$index1=0;
       	for ($multi_ssid_path."/index")
    	{      
        	$index++;     
        	/*add schedule for multi-ssid by yuda start*/
        	$schedule_enable=query("/schedule/enable");
        	if ($schedule_enable==1)
        	{
        		if(query($multi_ssid_path."/index:".$index."/schedule_rule_state")==1)
        		{
				$multi_ind_schedule_state = query($multi_ssid_path."/index:".$index."/schedule_state"); 
			}
	        	else
	        	{
	        		$multi_ind_schedule_state = 1;
	        	}     	
	        }
	        else
	        {
	        	$multi_ind_schedule_state = 1;
	        }
	      	/*add schedule for multi-ssid by yuda end*/	    
	        
	       	$multi_ind_state = query($multi_ssid_path."/index:".$index."/state");  
	       	if ($multi_ind_state==1)  //add $multi_ind_schedule_state for schedule for multi-ssid by yuda  
	       	{ 	            
                	echo "ifconfig ath".$index." up\n";
			if (query("/wlan/inf:1/autochannel")==1) {echo "iwconfig ath".$index." freq 0\n";}//erial_acs_201009
	                echo "brctl addif br0 ath".$index."\n";	
	        }  // end of if ($multi_ind_state==1)  
	}  // end of for ($multi_ssid_path."/index")
} // end of ($multi_total_state == 1)

        	
//~~~~~~~~WDS: ath9-15 up~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
{
		
	$index=7;
       	$index_mac=0;
       	$up_ath_cnt=0;	
	
	for ($WLAN."/wds/list/index")
       	{   
      		$index++;     
               	$index_mac++;   
               	$wds_mac = query($WLAN."/wds/list/index:".$index_mac."/mac");  
               	if ($wds_mac!="")  
               	{   
               		$up_ath_cnt++;    
            		echo "\necho UP WDS ath".$index."... > /dev/console\n";
      	 		echo "ifconfig ath".$index." up\n";
			echo "brctl addif br0 ath".$index."\n";
           	}//if ($wds_mac!="")  
	
	 }//  for ($WLAN."/wds/list/index")
	
	
}   //($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
}
        
?>
