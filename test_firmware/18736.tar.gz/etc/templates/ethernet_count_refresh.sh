#!/bin/sh
echo [$0] ... > /dev/console                                   

LAN_RX_BYTES=`rgdb -i -g /runtime/stats/ethernet/rx/bytes_c`
LAN_RX_BYTES_REDUCE=`rgdb -i -g /runtime/stats/ethernet/rx/bytes_reduce`
LAN_RX_BYTES_SHOW=`rgdb -i -g /runtime/stats/ethernet/rx/bytes`

LAN_RX_PACKETS=`rgdb -i -g /runtime/stats/ethernet/rx/packets_c`
LAN_RX_PACKETS_REDUCE=`rgdb -i -g /runtime/stats/ethernet/rx/packets_reduce`
LAN_RX_PACKETS_SHOW=`rgdb -i -g /runtime/stats/ethernet/rx/packets`

LAN_RX_DROP=`rgdb -i -g /runtime/stats/ethernet/rx/drop_c`
LAN_RX_DROP_REDUCE=`rgdb -i -g /runtime/stats/ethernet/rx/drop_reduce`
LAN_RX_DROP_SHOW=`rgdb -i -g /runtime/stats/ethernet/rx/drop`

LAN_TX_BYTES=`rgdb -i -g /runtime/stats/ethernet/tx/bytes_c`
LAN_TX_BYTES_REDUCE=`rgdb -i -g /runtime/stats/ethernet/tx/bytes_reduce`
LAN_TX_BYTES_SHOW=`rgdb -i -g /runtime/stats/ethernet/tx/bytes`

LAN_TX_PACKETS=`rgdb -i -g /runtime/stats/ethernet/tx/packets_c`
LAN_TX_PACKETS_REDUCE=`rgdb -i -g /runtime/stats/ethernet/tx/packets_reduce`
LAN_TX_PACKETS_SHOW=`rgdb -i -g /runtime/stats/ethernet/tx/packets`

LAN_TX_DROP=`rgdb -i -g /runtime/stats/ethernet/tx/drop_c`
LAN_TX_DROP_REDUCE=`rgdb -i -g /runtime/stats/ethernet/tx/drop_reduce`
LAN_TX_DROP_SHOW=`rgdb -i -g /runtime/stats/ethernet/tx/drop`



LAN_RX_BYTES_SHOW=`expr $LAN_RX_BYTES - $LAN_RX_BYTES_REDUCE`
rgdb -i -s "/runtime/stats/ethernet/rx/bytes" "$LAN_RX_BYTES_SHOW"

LAN_RX_PACKETS_SHOW=`expr $LAN_RX_PACKETS - $LAN_RX_PACKETS_REDUCE`
rgdb -i -s "/runtime/stats/ethernet/rx/packets" "$LAN_RX_PACKETS_SHOW"

LAN_RX_DROP_SHOW=`expr $LAN_RX_DROP - $LAN_RX_DROP_REDUCE`
rgdb -i -s "/runtime/stats/ethernet/rx/drop" "$LAN_RX_DROP_SHOW"

LAN_TX_BYTES_SHOW=`expr $LAN_TX_BYTES - $LAN_TX_BYTES_REDUCE`
rgdb -i -s "/runtime/stats/ethernet/tx/bytes" "$LAN_TX_BYTES_SHOW"

LAN_TX_PACKETS_SHOW=`expr $LAN_TX_PACKETS - $LAN_TX_PACKETS_REDUCE`
rgdb -i -s "/runtime/stats/ethernet/tx/packets" "$LAN_TX_PACKETS_SHOW"

LAN_TX_DROP_SHOW=`expr $LAN_TX_DROP - $LAN_TX_DROP_REDUCE`
rgdb -i -s "/runtime/stats/ethernet/tx/drop" "$LAN_TX_DROP_SHOW"



xmldbc -t "traffic:300:sh /etc/templates/ethernet_count_refresh.sh"