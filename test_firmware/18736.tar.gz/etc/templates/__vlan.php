#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */

$WLAN_g = "/wlan/inf:1";  // b, g, n band
$WLAN_a = $WLAN_g;  // a, g band use the same config.
$band	= query($WLAN_g."/ch_mode");  // "1" #1--->a   0---> b,g,n
$A_BAND = 1;  // 1--->a   
$G_BAND = 0;  // 0---> b,g,n
$WLAN = $WLAN_g; 

if ($band == $A_BAND)	// 11A band
{ 	    
	$WLAN = $WLAN_a;
}
else            // 11b,g,n band
{ 
	$WLAN = $WLAN_g;      
}
$multi_ssid_path = $WLAN."/multi";
$wds_path = $WLAN."/wds";
$sys = "/sys";
$eth = "/lan/ethernet";

if ($generate_start==1)
{    
	    // MULTI_VLAN +++
	    $vlan_state = query($sys."/vlan_state"); 
	    $vlan_mode = query($sys."/vlan_mode"); 
	    $auth_mode = query($WLAN."/authentication");	
	    
	    // check vlan status
	    if ($vlan_state == 1 && $vlan_mode==1)  // dynamic vlan mode
	    {    
	        if ($auth_mode==1 || // shared key 
                $auth_mode==0 || // open
                $auth_mode==3 || //wpa-psk 
                $auth_mode==5 || //wpa2-psk  
                $auth_mode==7    //wpa-auto-psk     
                )
            {   // if not wpa-eap -> disable vlan.
                //echo "\necho set($sys./vlan_state, 0  ...\n > /dev/console\n";  
                set($sys."/vlan_state", 0);  // 
                set($sys."/vlan_mode", 0);  // 
            } 
        } 
	    $vlan_state = query($sys."/vlan_state"); 
	    // end of // check vlan status
	    
	    $vlan_id_sys = query($sys."/vlan_id"); 
	    $vlan_id_eth = query($eth."/vlan_id"); 
	    $vlan_id = query($WLAN."/vlan_id"); 
	    if($vlan_state == 1)
	    { 
            echo "\necho MTU=1504 setting...\n > /dev/console\n"; 
	        echo "ifconfig wifi0 mtu 1504\n";  //printf("[test]  \n"); // jack test
	        echo "ifconfig ath0  mtu 1504\n";
	        echo "ifconfig ath1  mtu 1504\n";
	        echo "ifconfig ath2  mtu 1504\n";
	        echo "ifconfig ath3  mtu 1504\n";
	        echo "ifconfig ath4  mtu 1504\n";
	        echo "ifconfig ath5  mtu 1504\n";
	        echo "ifconfig ath6  mtu 1504\n";
	        echo "ifconfig ath7  mtu 1504\n";
	        echo "ifconfig ath8  mtu 1504\n";
	        echo "ifconfig ath9  mtu 1504\n";
	        echo "ifconfig ath10 mtu 1504\n";
	        echo "ifconfig ath11 mtu 1504\n";
	        echo "ifconfig ath12 mtu 1504\n";
	        echo "ifconfig ath13 mtu 1504\n";
	        echo "ifconfig ath14 mtu 1504\n";
	        echo "ifconfig ath15 mtu 1504\n";	        
	        echo "ifconfig eth0  mtu 1504\n";  //printf("[test]  \n"); // jack test
	    }                      
	    if($vlan_state == 1 && $vlan_mode==0) // static vlan mode
	    {	        
            echo "\necho start vlan setting...\n > /dev/console\n"; 
            
	        echo "brctl setvlanstate br0 1\n";
	        $group_vid_path = "/sys/group_vlan";
	        //   set vlan mode
	        if ($vlan_mode==0)
	            {echo "brctl setvlanmode br0 0\n";}
	        else
	            {echo "brctl setvlanmode br0 1\n";}	            
	            
            //	 set pvid
	        if ($vlan_id!="")			
	        { 
	            echo "brctl setpvidif br0 ath0 ".$vlan_id."\n";
	        } 	    
	        if ($vlan_id_eth!="")			
	        { 
	            echo "brctl setpvidif br0 eth0 ".$vlan_id_eth."\n";
	        } 
	        if ($vlan_id_sys!="")			
	        { 
	            echo "brctl setsysvid br0 ".$vlan_id_sys."\n";
	        }      
	        // set multi-ssid pvid
	        $index=0;
	        for ($multi_ssid_path."/index")
	        {      
	            $index++;	            
	            $multi_ind_state = query($multi_ssid_path."/index:".$index."/state");  
	            if ($multi_ind_state==1)
	            { 
	                
	                $ath_pvid = query($multi_ssid_path."/index:".$index."/vlan_id");  
	                if ($ath_pvid!="")
	                    {
				echo "brctl setpvidif br0 ath".$index." ".$ath_pvid."\n";
	                    }
	            }
	        }
	        // jack, check papa, sandy, to not delete WDS's mac rgdb entry.......
	        // set WDS pvid
	        $index=0;
	        for ($wds_path."/index")
	        {      
	            $index++;	            
	            $wds_mac = query($wds_path."/list/index:".$index."/mac");  
	            if ($wds_mac!="")  
	            { 
	                $ath_pvid = query($wds_path."/index:".$index."/vlan_id");
	                $wds_index = $index + 7;  
	                if ($ath_pvid!="")
	                    {echo "brctl setpvidif br0 ath".$wds_index." ".$ath_pvid."\n";
	                    
	                    }
	            }
	        }
               
		    $ind=0;
	        for ($group_vid_path."/index") 
            {
    	        $ind++;
    	        echo "echo ind: ".$ind."  \n"; 
    	        $group_vid = query($group_vid_path."/index:".$ind."/group_vid");
    	        if ($group_vid!="")
    	        {
    	            //$egress = query($group_vid_path."/index:".$ind."/egress");    	        
    	            //$tag = query($group_vid_path."/index:".$ind."/tag");
    	            // 0: none, 1: tag port, 2: un-tag port
    	            $ath0_egress= query($group_vid_path."/index:".$ind."/ath:1/egress"); 
    	            $ath1_egress= query($group_vid_path."/index:".$ind."/ath:2/egress"); 
                    $ath2_egress= query($group_vid_path."/index:".$ind."/ath:3/egress"); 
                    $ath3_egress= query($group_vid_path."/index:".$ind."/ath:4/egress"); 
                    $ath4_egress= query($group_vid_path."/index:".$ind."/ath:5/egress"); 
                    $ath5_egress= query($group_vid_path."/index:".$ind."/ath:6/egress"); 
                    $ath6_egress= query($group_vid_path."/index:".$ind."/ath:7/egress"); 
                    $ath7_egress= query($group_vid_path."/index:".$ind."/ath:8/egress"); 
                    $ath8_egress= query($group_vid_path."/index:".$ind."/ath:9/egress"); 
                    $ath9_egress= query($group_vid_path."/index:".$ind."/ath:10/egress"); 
                    $ath10_egress=query($group_vid_path."/index:".$ind."/ath:11/egress"); 
                    $ath11_egress=query($group_vid_path."/index:".$ind."/ath:12/egress"); 
                    $ath12_egress=query($group_vid_path."/index:".$ind."/ath:13/egress"); 
                    $ath13_egress=query($group_vid_path."/index:".$ind."/ath:14/egress"); 
                    $ath14_egress=query($group_vid_path."/index:".$ind."/ath:15/egress"); 
                    $ath15_egress=query($group_vid_path."/index:".$ind."/ath:16/egress"); 
                    $eth0_egress= query($group_vid_path."/index:".$ind."/eth:1/egress"); 
                    $sys_egress=  query($group_vid_path."/index:".$ind."/sys:1/egress"); 
    	            //  jack test debug +++
    	            /*
    	            echo "echo ath0_egress: ".$ath0_egress." \n";
    	            echo "echo ath1_egress: ".$ath1_egress." \n";
    	            echo "echo ath2_egress: ".$ath2_egress." \n";
    	            echo "echo ath3_egress: ".$ath3_egress." \n";
    	            echo "echo ath4_egress: ".$ath4_egress." \n";
    	            echo "echo ath5_egress: ".$ath5_egress." \n";
    	            echo "echo ath6_egress: ".$ath6_egress." \n";
    	            echo "echo ath7_egress: ".$ath7_egress." \n";
    	            echo "echo ath8_egress: ".$ath8_egress." \n";
    	            echo "echo ath9_egress: ".$ath9_egress." \n";
    	            echo "echo ath10_egress: ".$ath10_egress." \n";
    	            echo "echo ath11_egress: ".$ath11_egress." \n";
    	            echo "echo ath12_egress: ".$ath12_egress." \n";
    	            echo "echo ath13_egress: ".$ath13_egress." \n";
    	            echo "echo ath14_egress: ".$ath14_egress." \n";
    	            echo "echo ath15_egress: ".$ath15_egress." \n";
    	            echo "echo eth0_egress: ".$eth0_egress." \n";
    	            echo "echo sys_egress: ".$sys_egress." \n";*/
    	            //  jack test debug ---            
		            if ($ath0_egress==1)  {echo "brctl setgroupvidif br0 ath0 ".$group_vid." 1\n"; }    else if ($ath0_egress==2)  {echo "brctl setgroupvidif br0 ath0 ".$group_vid." 0\n"; }        
                    if ($ath1_egress==1)  {echo "brctl setgroupvidif br0 ath1 ".$group_vid." 1\n"; }    else if ($ath1_egress==2)  {echo "brctl setgroupvidif br0 ath1 ".$group_vid." 0\n"; }        
                    if ($ath2_egress==1)  {echo "brctl setgroupvidif br0 ath2 ".$group_vid." 1\n"; }    else if ($ath2_egress==2)  {echo "brctl setgroupvidif br0 ath2 ".$group_vid." 0\n"; }        
                    if ($ath3_egress==1)  {echo "brctl setgroupvidif br0 ath3 ".$group_vid." 1\n"; }    else if ($ath3_egress==2)  {echo "brctl setgroupvidif br0 ath3 ".$group_vid." 0\n"; }        
                    if ($ath4_egress==1)  {echo "brctl setgroupvidif br0 ath4 ".$group_vid." 1\n"; }    else if ($ath4_egress==2)  {echo "brctl setgroupvidif br0 ath4 ".$group_vid." 0\n"; }        
                    if ($ath5_egress==1)  {echo "brctl setgroupvidif br0 ath5 ".$group_vid." 1\n"; }    else if ($ath5_egress==2)  {echo "brctl setgroupvidif br0 ath5 ".$group_vid." 0\n"; }        
                    if ($ath6_egress==1)  {echo "brctl setgroupvidif br0 ath6 ".$group_vid." 1\n"; }    else if ($ath6_egress==2)  {echo "brctl setgroupvidif br0 ath6 ".$group_vid." 0\n"; }        
                    if ($ath7_egress==1)  {echo "brctl setgroupvidif br0 ath7 ".$group_vid." 1\n"; }    else if ($ath7_egress==2)  {echo "brctl setgroupvidif br0 ath7 ".$group_vid." 0\n"; }        
                    if ($ath8_egress==1)  {echo "brctl setgroupvidif br0 ath8 ".$group_vid." 1\n"; }    else if ($ath8_egress==2)  {echo "brctl setgroupvidif br0 ath8 ".$group_vid." 0\n"; }        
                    if ($ath9_egress==1)  {echo "brctl setgroupvidif br0 ath9 ".$group_vid." 1\n"; }    else if ($ath9_egress==2)  {echo "brctl setgroupvidif br0 ath9 ".$group_vid." 0\n"; }                         
		            if ($ath10_egress==1) {echo "brctl setgroupvidif br0 ath10 ".$group_vid." 1\n"; }   else if ($ath10_egress==2) {echo "brctl setgroupvidif br0 ath10 ".$group_vid." 0\n"; }       
                    if ($ath11_egress==1) {echo "brctl setgroupvidif br0 ath11 ".$group_vid." 1\n"; }   else if ($ath11_egress==2) {echo "brctl setgroupvidif br0 ath11 ".$group_vid." 0\n"; }       
                    if ($ath12_egress==1) {echo "brctl setgroupvidif br0 ath12 ".$group_vid." 1\n"; }   else if ($ath12_egress==2) {echo "brctl setgroupvidif br0 ath12 ".$group_vid." 0\n"; }       
                    if ($ath13_egress==1) {echo "brctl setgroupvidif br0 ath13 ".$group_vid." 1\n"; }   else if ($ath13_egress==2) {echo "brctl setgroupvidif br0 ath13 ".$group_vid." 0\n"; }       
                    if ($ath14_egress==1) {echo "brctl setgroupvidif br0 ath14 ".$group_vid." 1\n"; }   else if ($ath14_egress==2) {echo "brctl setgroupvidif br0 ath14 ".$group_vid." 0\n"; }       
                    if ($ath15_egress==1) {echo "brctl setgroupvidif br0 ath15 ".$group_vid." 1\n"; }   else if ($ath15_egress==2) {echo "brctl setgroupvidif br0 ath15 ".$group_vid." 0\n"; }                         
                    if ($eth0_egress==1)  {echo "brctl setgroupvidif br0 eth0 ".$group_vid." 1\n"; }    else if ($eth0_egress==2)  {echo "brctl setgroupvidif br0 eth0 ".$group_vid." 0\n"; }       
                    if ($sys_egress==1)   {echo "brctl setgroupvidif br0 sys ".$group_vid." 1\n"; }     else if ($sys_egress==2)   {echo "brctl setgroupvidif br0 sys ".$group_vid." 0\n"; }     
    	        }   // end of if ($group_vid!="")
    	    } // end of for loop
	    }  // end of if($vlan_state == 1)
	    else if($vlan_state == 1 && $vlan_mode==1) // NAP vlan mode
	    {	        
	        echo "brctl setvlanstate br0 1\n";
	            echo "brctl setvlanmode br0 1\n";	  
	        echo "iwpriv ath0 napstate 1\n";		              
	    }
	    else  // if($vlan_state != 1) 
	        { 
	        echo "brctl setvlanstate br0 0 \n";  
	        }   
	    // MULTI_VLAN ---         

} // end of ($generate_start==1)
else
{
	    // MULTI_VLAN +++
	    $vlan_state = query($sys."/vlan_state");  
	    $vlan_mode = query($sys."/vlan_mode");   
	    $auth_mode = query($WLAN."/authentication");	
	    	    
	    // check vlan status
	    if ($vlan_state == 1 && $vlan_mode==1)  // dynamic vlan mode
	    {    
	        if ($auth_mode==1 || // shared key 
                $auth_mode==0 || // open
                $auth_mode==3 || //wpa-psk 
                $auth_mode==5 || //wpa2-psk  
                $auth_mode==7    //wpa-auto-psk     
                )
            {   // if not wpa-eap -> disable vlan.
                //echo "\necho set($sys./vlan_state, 0  ...\n > /dev/console\n";  
                set($sys."/vlan_state", 0);  // 
                set($sys."/vlan_mode", 0);  // 
            } 
        } 
	    $vlan_state = query($sys."/vlan_state"); 
	    // end of // check vlan status	    
	     
	    if($vlan_state == 1 && $vlan_mode==0)  	// static vlan mode                                            
	    {	        
            echo "\necho kill vlan  ...\n > /dev/console\n"; 
            // disable 
            echo "brctl setvlanstate br0 0 \n";  
              
            // set default value
	        echo "brctl setpvidif br0 ath0   1 \n";
	        echo "brctl setpvidif br0 ath1   1 \n";
	        echo "brctl setpvidif br0 ath2   1 \n";
	        echo "brctl setpvidif br0 ath3   1 \n";
	        echo "brctl setpvidif br0 ath4   1 \n";
	        echo "brctl setpvidif br0 ath5   1 \n";
	        echo "brctl setpvidif br0 ath6   1 \n";
	        echo "brctl setpvidif br0 ath7   1 \n";
	        echo "brctl setpvidif br0 ath8   1 \n";
	        echo "brctl setpvidif br0 ath9   1 \n";
	        echo "brctl setpvidif br0 ath10  1 \n";
	        echo "brctl setpvidif br0 ath11  1 \n";
	        echo "brctl setpvidif br0 ath12  1 \n";
	        echo "brctl setpvidif br0 ath13  1 \n";
	        echo "brctl setpvidif br0 ath14  1 \n";
	        echo "brctl setpvidif br0 ath15  1 \n";
	        echo "brctl setpvidif br0 eth0   1 \n";
	        echo "brctl setsysvid br0 1\n";
            
            //    del all group vid
            echo "brctl delallgroupvidif br0 ath0  \n";  
            echo "brctl delallgroupvidif br0 ath1  \n";  
            echo "brctl delallgroupvidif br0 ath2  \n";  
            echo "brctl delallgroupvidif br0 ath3  \n";  
            echo "brctl delallgroupvidif br0 ath4  \n";  
            echo "brctl delallgroupvidif br0 ath5  \n";  
            echo "brctl delallgroupvidif br0 ath6  \n";  
            echo "brctl delallgroupvidif br0 ath7  \n";  
            echo "brctl delallgroupvidif br0 ath8  \n";  
            echo "brctl delallgroupvidif br0 ath9  \n";  
            echo "brctl delallgroupvidif br0 ath10 \n";  
            echo "brctl delallgroupvidif br0 ath11 \n";  
            echo "brctl delallgroupvidif br0 ath12 \n";  
            echo "brctl delallgroupvidif br0 ath13 \n";  
            echo "brctl delallgroupvidif br0 ath14 \n";  
            echo "brctl delallgroupvidif br0 ath15 \n";  
            echo "brctl delallgroupvidif br0 eth0  \n";  
            echo "brctl delallgroupvidif br0 sys   \n";     
            
	        echo "sleep 3\n";
	    }  // end of if($vlan_state == 1)
	    else if($vlan_state == 1 && $vlan_mode==1) // NAP vlan mode
	    {	        
	        echo "brctl setvlanstate br0 0\n";	  
	        echo "iwpriv ath0 napstate 0\n";	  
	    } 
	    
}  // end of else ($generate_start!=1)
?>
