#!/bin/sh
echo [$0] ... > /dev/console
<?
if ($generate_start==1)
{
$ap_array_scan_list_path =  "/runtime/wlan/inf:1/scan_table";
$system_time = "/runtime/sys/uptime";

     for ("/runtime/wlan/inf:1/scan_table/index")
    {          
         $ap_array_scan_timer = query($ap_array_scan_list_path."/index:".$@."/timer");
       //  echo "ap_array_scan_timer ".$ap_array_scan_timer."... > /dev/console\n";
         $system_time = query("/runtime/sys/uptime"); 
       //   echo "system_time ".$system_time."... > /dev/console\n";
         $diff_timer = $system_time - $ap_array_scan_timer;
       //   echo "diff_timer ".$diff_timer."... > /dev/console\n";
         if($diff_timer > 100)
    	   {
    	       del("/runtime/wlan/inf:1/scan_table/index:".$@);
    	       echo "scan table clear... > /dev/console\n";
    	   }
    }         
}

?>