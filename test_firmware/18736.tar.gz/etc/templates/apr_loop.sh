#!/bin/sh
#echo [$0] ... > /dev/console
TROOT=`rgdb -i -g /runtime/template_root`
[ "$TROOT" = "" ] && TROOT="/etc/templates"

#APMODE=`rgdb -g /wlan/inf:1/ap_mode`
#if [ "$APMODE" != "2" ]; then
#exit;
#fi

xmldbc -k rootap_check
#xmldbc -d /runtime/wireless/rootap_status

RESULT=`iwconfig ath1|scut -p Point:`
#2 minutes
TIMEOUT=30
if [ "$RESULT" = "Not-Associated" -o "$RESULT" = "" ]; then
        echo "root AP is not connected."
#        xmldbc -i -s  /runtime/wireless/rootap_status 0
#        /etc/templates/wlan.sh restart    > /dev/console
else
#       xmldbc -i -s  /runtime/wireless/rootap_status 1
#       TIMEOUT=86400
	LAST_CHAN=`rgdb -i -g /runtime/stats/wlan/inf:1/last_ch`
	CUR_CHAN=`rgdb -i -g /runtime/stats/wlan/inf:1/channel`

	if [ "$CUR_CHAN" != "$LAST_CHAN" ]; then
        	xmldbc -i -s  /runtime/stats/wlan/inf:1/last_ch $CUR_CHAN
		iwconfig ath0 channel $CUR_CHAN
#        	echo "root AP is working on, different channel..."
#	else
#      		echo "root AP is working on, same channel..."
	fi
fi

xmldbc -t "rootap_check:$TIMEOUT:sh $TROOT/apr_loop.sh"
