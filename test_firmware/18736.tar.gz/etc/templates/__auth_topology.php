#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */

$WLAN = "/wlan/inf:1";  // b, g, n band
$multi_ssid_path = $WLAN."/multi";
require("/etc/templates/troot.php");
$multi_total_state = query($multi_ssid_path."/state");  
$ap_mode	= query($WLAN."/ap_mode");  // "1" #1--->a   0---> b,g,n
$wlan_ap_operate_mode = query($WLAN."/ap_mode");
$wlanif = query("/runtime/layout/wlanif");

if ($generate_start==1)
{

$ip_mode = query("/wan/rg/inf:1/mode"); /* 1:static, 2:dynamic */
$own_dynamic_ip_addr    = query("/runtime/wan/inf:1/ip");
$own_dynamic_ip_netmask    = query("/runtime/wan/inf:1/netmask");
$own_static_ip_addr     = query("/wan/rg/inf:1/static/ip");
$own_static_ip_netmask     = query("/wan/rg/inf:1/static/netmask");
if($ip_mode==2 && $own_dynamic_ip_addr!="")
{
        $own_ip_addr    = $own_dynamic_ip_addr;
        $own_ip_netmask    = $own_dynamic_ip_netmask;
} else {
        $own_ip_addr    = $own_static_ip_addr;
        $own_ip_netmask    = $own_static_ip_netmask;
}

$asu_ip = query("/sys/wapi/ext_cert/asu_ip");
$asu_port = query("/sys/wapi/ext_cert/asu_port");
$cert_name = query("/sys/wapi/certname");
$asu_cert_name = query("/sys/wapi/asucertname");
$as_cert_name = query("/sys/wapi/ascertname");
$cert_index = query("/sys/wapi/cert_index");
$cert_status = query("/sys/wapi/cert_status");
$cert_mode = query("/sys/wapi/cert_mode");

$WAPI_CONF = "/var/run/wapi.conf";
$WAPI_pid = "/var/run/wapid.pid";
$wapi_run = 0;

fwrite($WAPI_CONF, "debug=0\n");
fwrite2($WAPI_CONF, "CERT_NAME=/var/etc/wapi/".$cert_name."\n");
fwrite2($WAPI_CONF, "ASU_CERT_NAME=/var/etc/wapi/".$asu_cert_name."\n");
fwrite2($WAPI_CONF, "CA_CERT_NAME=/var/etc/wapi/".$as_cert_name."\n");
fwrite2($WAPI_CONF, "CERT_INDEX=".$cert_index."\n");
fwrite2($WAPI_CONF, "CERT_MODE=".$cert_mode."\n");
fwrite2($WAPI_CONF, "CERT_STATUS=".$cert_status."\n");
fwrite2($WAPI_CONF, "ASU_IP=".$asu_ip."\n");
fwrite2($WAPI_CONF, "ASU_PORT=".$asu_port."\n");
fwrite2($WAPI_CONF, "[WLAN_BEGIN]\n");

$TOPOLOGY_CONF	= "/var/run/topology.conf";
$RADIO_CONF	= "/var/run/radio.conf";
$wpa2_run = 0;
$wpa2_apc_run = 0;

fwrite($TOPOLOGY_CONF, "bridge br0\n{\n");
fwrite2($TOPOLOGY_CONF, "ipaddress ".$own_ip_addr."\n");
fwrite2($TOPOLOGY_CONF, "netmask ".$own_ip_netmask."\n");

fwrite2($RADIO_CONF, "radio wifi0\n{\n");

if (query($WLAN."/enable")==1)
{
$auth_mode = query("/wlan/inf:1/authentication");

$wapi_psk_type  = query($WLAN."/wapi/psk_type");
$wapi_password  = query($WLAN."/wapi/password");
$usk_rekey_period       = query($WLAN."/wapi/usk_rekey_period");
$msk_rekey_period       = query($WLAN."/wapi/msk_rekey_period");

if ($wlan_ap_operate_mode != 1)
{		
	if ($auth_mode==3 || /*wpa-psk*/
    		$auth_mode==5 || /*wpa2-psk*/
    		$auth_mode==7 || /*wpa-auto-psk*/
    		$auth_mode==2 || /*wpa-eap*/
    		$auth_mode==4 || /*wpa2-eap*/
    		$auth_mode==6 || /*wpa-auto-eap*/
    		$auth_mode==9) /*802.1x*/
	{
		$HAPD_conf	= "/var/run/hostapd.".$wlanif.".ap_bss";	
		fwrite2($TOPOLOGY_CONF, "interface ".$wlanif."\n");
		
		fwrite2($RADIO_CONF, "ap\n{\n");
		fwrite2($RADIO_CONF, "bss ".$wlanif."\n{\n");
		fwrite2($RADIO_CONF, "config ".$HAPD_conf."\n}\n}\n");
		$wpa2_run = 1;
	}
	else if ($auth_mode==10 || $auth_mode==11)
	{
		if ($wapi_password == "")
		{
			$wapi_password = "00000000";
		}
		if ($auth_mode==10)
	{
		fwrite2($WAPI_CONF, $wlanif." 7 ".$wapi_psk_type." ".$wapi_password." ".$usk_rekey_period." ".$msk_rekey_period."\n");
		$wapi_run = 1;
	}
	else if ($auth_mode==11)
	{
		fwrite2($WAPI_CONF, $wlanif." 11 ".$wapi_psk_type." ".$wapi_password." ".$usk_rekey_period." ".$msk_rekey_period."\n");
		$wapi_run = 1;
	}
	}
/**----------------------Multi start add by log_luo----------------------*/	
	if ($multi_total_state == 1)
	{
		$index=0; 
       		//$index1=0;
       		for ($multi_ssid_path."/index")
    		{      
        		$index++; 
        		$schedule_enable=query("/schedule/enable");
                	if ($schedule_enable==1)
                	{
                        	if(query($multi_ssid_path."/index:".$index."/schedule_rule_state")==1)
                        	{
                                	$multi_ind_schedule_state = query($multi_ssid_path."/index:".$index."/schedule_state");
                        	}
                        	else
                        	{
                                	$multi_ind_schedule_state = 1;
                        	}
                	}
                	else
                	{
                        	$multi_ind_schedule_state = 1;
                	}

			$multi_ind_state = query($multi_ssid_path."/index:".$index."/state");  
			if ($multi_ind_state==1 && $multi_ind_schedule_state == 1)  
			{ 
        		$multi_auth = query($multi_ssid_path."/index:".$index."/auth");
			if ($multi_auth==3 || /*wpa-psk*/
                                $multi_auth==5 || /*wpa2-psk*/
                                $multi_auth==7 || /*wpa-auto-psk*/
                                $multi_auth==2 || /*wpa-eap*/
                                $multi_auth==4 || /*wpa2-eap*/
                                $multi_auth==6 || /*wpa-auto-eap*/
                                $multi_auth==9) /*802.1x*/
			{
				$hostapd_conf	= "/var/run/hostapd0".$index.".ap_bss";
				fwrite2($TOPOLOGY_CONF, "interface ath".$index."\n");
				
				fwrite2($RADIO_CONF, "ap\n{\n");
				fwrite2($RADIO_CONF, "bss ath".$index."\n{\n");
				fwrite2($RADIO_CONF, "config ".$hostapd_conf."\n}\n}\n");
				$wpa2_run = 1;
			}
			else if ($multi_auth==10 || $multi_auth==11)
			{
			$wapi_psk_type  = query($multi_ssid_path."/index:".$index."/wapi/psk_type");
                        $wapi_password  = query($multi_ssid_path."/index:".$index."/wapi/password");
                        $usk_rekey_period       = query($multi_ssid_path."/index:".$index."/wapi/usk_rekey_period");
                        $msk_rekey_period       = query($multi_ssid_path."/index:".$index."/wapi/msk_rekey_period");
			if ($wapi_password == "")
			{
				$wapi_password = "00000000";
			}

                        /*security +++*/
                        if($multi_auth==10)
                        {
                                fwrite2($WAPI_CONF, "ath".$index." 7 ".$wapi_psk_type." ".$wapi_password." ".$usk_rekey_period." ".$msk_rekey_period."\n");
                                $wapi_run = 1;
                        }
                        else if($multi_auth==11)
                        {
                                fwrite2($WAPI_CONF, "ath".$index." 11 ".$wapi_psk_type." ".$wapi_password." ".$usk_rekey_period." ".$msk_rekey_period."\n");
                                $wapi_run = 1;
                        }
		}
	}
}
}
/**----------------------Multi end add by log_luo----------------------*/
}
else
{
	if ($auth_mode==3 || /*wpa-psk*/
    		$auth_mode==5 || /*wpa2-psk*/
    		$auth_mode==7 || /*wpa-auto-psk*/
    		$auth_mode==2 || /*wpa-eap*/
    		$auth_mode==4 || /*wpa2-eap*/
    		$auth_mode==6 || /*wpa-auto-eap*/
    		$auth_mode==9) /*802.1x*/
	{
		$wpa_supplicant_conf 	= "/var/run/wpa_supplicant.".$wlanif.".sta";
		fwrite2($TOPOLOGY_CONF, "interface ".$wlanif."\n");
		
		fwrite2($RADIO_CONF, "sta ".$wlanif."\n{\n");
		fwrite2($RADIO_CONF, "bridge br0\n");
		fwrite2($RADIO_CONF, "driver atheros\n");
		fwrite2($RADIO_CONF, "config ".$wpa_supplicant_conf."\n}\n");
		$wpa2_apc_run = 1;
	}
}

if($wlan_ap_operate_mode == 2)
{
	if ($auth_mode==3 || /*wpa-psk*/
    		$auth_mode==5 || /*wpa2-psk*/
    		$auth_mode==7 || /*wpa-auto-psk*/
    		$auth_mode==2 || /*wpa-eap*/
    		$auth_mode==4 || /*wpa2-eap*/
    		$auth_mode==6 || /*wpa-auto-eap*/
    		$auth_mode==9) /*802.1x*/
	{
		$wpa_supplicant_conf 	= "/var/run/wpa_supplicant.ath1.sta";
		fwrite2($TOPOLOGY_CONF, "interface ath1\n");
		
		fwrite2($RADIO_CONF, "sta ath1\n{\n");
		fwrite2($RADIO_CONF, "bridge br0\n");
		fwrite2($RADIO_CONF, "driver atheros\n");
		fwrite2($RADIO_CONF, "config ".$wpa_supplicant_conf."\n}\n");
		$wpa2_apc_run = 1;
	}
}

if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
{		
	$index=7;
       	$index_mac=0;	
	for ($WLAN."/wds/list/index")
       	{   
      		$index++;     
               	$index_mac++;   
               	$wds_mac = query($WLAN."/wds/list/index:".$index_mac."/mac");  
               	if ($wds_mac!="")  
               	{   
			if ($auth_mode==3 || /*wpa-psk*/
                            $auth_mode==5 || /*wpa2-psk*/
                            $auth_mode==7 || /*wpa-auto-psk*/
                            $auth_mode==2 || /*wpa-eap*/
                            $auth_mode==4 || /*wpa2-eap*/
                            $auth_mode==6) /*wpa-auto-eap*/
			{
				$wpa_supplicant_conf = "/var/run/wpa_supplicant".$index.".conf_wds";
                        	$hostapd_conf	= "/var/run/hostapd".$index.".conf_wds";
				fwrite2($TOPOLOGY_CONF, "interface ath".$index."\n");
				
				if (query($WLAN."/wds/list/index:".$index_mac."/cmp")==1)
				{
					fwrite2($RADIO_CONF, "ap\n{\n");
					fwrite2($RADIO_CONF, "bss ath".$index."\n{\n");
					fwrite2($RADIO_CONF, "config ".$hostapd_conf."\n}\n}\n");
					$wpa2_run = 1;
				}else
				{
					fwrite2($RADIO_CONF, "sta ath".$index."\n{\n");
					fwrite2($RADIO_CONF, "bridge br0\n");
					fwrite2($RADIO_CONF, "driver atheros\n");
					fwrite2($RADIO_CONF, "config ".$wpa_supplicant_conf."\n}\n");
					$wpa2_apc_run = 1;
				}
			}
			
           	}//if ($wds_mac!="")  	
	 }//  for ($WLAN."/wds/list/index")		
}   //($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
}
fwrite2($TOPOLOGY_CONF, "}\n\n");
fwrite2($RADIO_CONF, "}\n\n");
echo "cat ".$RADIO_CONF." >> ".$TOPOLOGY_CONF."\n";
echo "rm ".$RADIO_CONF."\n";

fwrite2($WAPI_CONF, "[WLAN_END]\n");
if ($wapi_run==1)
{
        echo "echo Start wapid ... > /dev/console\n";
        echo "wapid -c ".$WAPI_CONF." &\n";
        echo "echo $! > ".$WAPI_pid."\n";
        echo "sleep 1\n";
//      echo "sh /etc/templates/wapi.sh start > /dev/console &\n";
}
if ($wpa2_run==1)
{
	echo "echo Start hostapd ... > /dev/console\n";
	echo "hostapd ".$TOPOLOGY_CONF." -B\n";
        echo "sleep 2\n";
}
if ($wpa2_apc_run==1)
{
        echo "echo Start wpa_supplicant ... > /dev/console\n";
        echo "wpa_supplicant ".$TOPOLOGY_CONF." -B\n";
        echo "sleep 1\n";
}

}
else // end generate_start==1
{
	echo "kill -9 `ps | grep hostapd | grep -v grep|cut -b 1-5` > /dev/null 2>&1\n";
	echo "kill -9 `ps | grep wpa_supplicant | grep -v grep | cut -b 1-5` > /dev/null 2>&1\n";
	echo "rm /var/run/topology.conf\n";
	echo "kill `ps | grep wapid | grep -v grep|cut -b 1-5` > /dev/null 2>&1\n";
	echo "rm /var/run/wapi.conf";
}

?>	
