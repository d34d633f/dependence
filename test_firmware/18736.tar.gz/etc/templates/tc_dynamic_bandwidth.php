#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");

$loopFile="\"/etc/templates/tc_dynamic.sh start\"";
$needloop=0;
if ($generate_start==1)
{
$needupdate=0;
$Mssid=1;
$tcallenable=query("/trafficctrl/wtp/trafficmgr/enable");

if($tcallenable != "1")
{
  exit;
}
$tcenable=query("/trafficctrl/trafficrule:1/enable");
$dynamicenable=query("/trafficctrl/trafficrule:1/dynamicwidth");
$debugruntime=query("/trafficctrl/wtp/trafficmgr/debugruntime");
 $FlowType= query("/trafficctrl/trafficrule:1/flowcontroltype");
 $isrunning=query("/runtime/stats/wtp/trafficctrl/refreshstat");
 if($isrunning == "" )
 {
   $isrunning=0;
 }
  if($debugruntime=="1")
         {
 echo "echo tc dymanic bandwidth refresh...\n";
 }
  if($debugruntime=="1")
  {
   echo "echo rule ".$tcenable." flowtype:".$FlowType."dynamicwidth:".$dynamicenable."...\n";
  }

if($tcenable=="1" && $FlowType=="0" && $dynamicenable=="1")
{
$assonum=0;
$needloop=1;
$actassonum=query("/runtime/stats/wtp/trafficctrl/trafficrule:1/assonum");

for("/runtime/stats/wlan/inf:1/client") //primary
{ 
        $mac="";
	 $mac=query("mac");
 	  if($debugruntime=="1")
	  {
	  echo "echo dbg[mac]:".$mac."...\n";
	 }
	 if($mac!="")
	 {
		$assonum++;

	 }
}

 if($actassonum=="" )
 {
   $actassonum=0;
 }
   if($debugruntime=="1")
         {
  echo "echo dbg assonum".$assonum."  old ".$actassonum.".\n";
  }
if( $assonum!=$actassonum)
{     
        if($assonum>0)
        {
        
	
       $UPLINK = query("/trafficctrl/trafficrule:1/maxwidthup");
       $DOWNLINK= query("/trafficctrl/trafficrule:1/maxwidthdown");
          if($debugruntime=="1")
         {
	 echo "echo dbg UPLINK".$UPLINK."--".$DOWNLINK."...\n";
         }
	if($UPLINK!="")
	{
	   $tmpclientwidthup=$UPLINK/$assonum;
	  if($debugruntime=="1")
         {
	    echo "echo dbg tmpclientwidthup".$tmpclientwidthup."...\n";
	    }
        }else
        {
           $tmpclientwidthup=0;
        }

        if($DOWNLINK!="")
	{
	   $tmpclientwidthdown=$DOWNLINK/$assonum;
	  if($debugruntime=="1")
         {
	    echo "echo dbg tmpclientwidthdown".$tmpclientwidthdown."...\n";
	    }
        }else
        {
           $tmpclientwidthdown=0;
        }
     
       if($assonum>$actassonum )	         
	 {
	   $temnum=$assonum-$actassonum;      
           $temnum1=$temnum*5;   
           if ($temnum1 > $assonum &&  $isrunning !="1" ){
            if($debugruntime=="1")
            {
	             echo "echo dbg assonum333333333".$assonum."  old ".$actassonum.".\n";
	   }
	            $needupdate=1;
	      }
	   }

	    if($assonum<$actassonum )
	    {	      
	    $temnum=$actassonum-$assonum;      
           $temnum1=$temnum*5;   
           if ($temnum1 > $actassonum &&  $isrunning !="1" ){
            if($debugruntime=="1")
         {
	             echo "echo dbg 2222222".$assonum."  old ".$actassonum.".\n";
	             }
	            $needupdate=1;
	            }

	         }
         
        if($needupdate==1)
        {
        set("/runtime/stats/wtp/trafficctrl/trafficrule:1/assonum",$assonum);
        }
	set("/runtime/stats/wtp/trafficctrl/trafficrule:1/tmpclientwidthup",$tmpclientwidthup);
   	set("/runtime/stats/wtp/trafficctrl/trafficrule:1/tmpclientwidthdown",$tmpclientwidthdown);
   	 }else
   	 {
   	    set("/runtime/stats/wtp/trafficctrl/trafficrule:1/assonum",0);
   	     set("/runtime/stats/wtp/trafficctrl/trafficrule:1/tmpclientwidthup","0");
   	     set("/runtime/stats/wtp/trafficctrl/trafficrule:1/tmpclientwidthdown","0");
   	 }
	  
}

}

$mssid_index = "";



for("/wlan/inf:1/multi/index")
{
      
         $state=query("state");
         $mssid_index = $@;
         $Mssid=$mssid_index+1;
       
         if(query("state") !="0")
         {
        
          $tcenable=query("/trafficctrl/trafficrule:".$Mssid."/enable");
          $dynamicenable=query("/trafficctrl/trafficrule:".$Mssid."/dynamicwidth");
	  $FlowType= query("/trafficctrl/trafficrule:".$Mssid."/flowcontroltype");

         if($tcenable=="1" && $FlowType==0 && $dynamicenable=="1")
         {
          $assonum=0;
          $needloop=1;
          $actassonum=query("/runtime/stats/wtp/trafficctrl/trafficrule:".$Mssid."/assonum");

         for("/runtime/stats/wlan/inf:1/mssid:".$mssid_index."/client")
          {
          $mac="";
          $mac=query("mac");
          if($mac!="")
	 {
	   $assonum++;
	  }
          }

          if($actassonum=="" || $assonum!=$actassonum)
		{
		 if( && $assonum>0)
		 {
		
		 $UPLINK = query("/trafficctrl/trafficrule:".$Mssid."/maxwidthup");
      		  $DOWNLINK= query("/trafficctrl/trafficrule:".$Mssid."/maxwidthdown");
		
		if($UPLINK!="")
		{
		   $tmpclientwidthup=$UPLINK/$assonum;
	        }else
	        {
	           $tmpclientwidthup=0;
	        }

	        if($DOWNLINK!="")
		{
		   $tmpclientwidthdown=$DOWNLINK/$assonum;
	        }else
	        {
	           $tmpclientwidthdown=0;
	        }

		      
	       if($assonum>$actassonum )	         
		 {
		   $temnum=$assonum-$actassonum;      
	           $temnum1=$temnum*5;   
	           if ($temnum1 > $assonum &&  $isrunning !="1" ){
	            if($debugruntime=="1")
	            {
		             echo "echo dbg Massonum333333333".$assonum."  old ".$actassonum.".\n";
		   }
		            $needupdate=1;
		      }
		   }

		    if($assonum<$actassonum )
		    {	      
		    $temnum=$actassonum-$assonum;      
	           $temnum1=$temnum*5;   
	           if ($temnum1 > $actassonum &&  $isrunning !="1" ){
	            if($debugruntime=="1")
	           {
		             echo "echo dbg M2222222".$assonum."  old ".$actassonum.".\n";
		             }
		            $needupdate=1;
		            }

		 }
         
         
	        if($needupdate==1)
	        {
	        set("/runtime/stats/wtp/trafficctrl/trafficrule:".$Mssid."/assonum",$assonum);
	        }
		set("/runtime/stats/wtp/trafficctrl/trafficrule:".$Mssid."/tmpclientwidthup",$tmpclientwidthup);
	   	set("/runtime/stats/wtp/trafficctrl/trafficrule:".$Mssid."/tmpclientwidthdown",$tmpclientwidthdown);
		}else
	   	 {
	   	     set("/runtime/stats/wtp/trafficctrl/trafficrule:".$Mssid."/assonum",0);
	   	     set("/runtime/stats/wtp/trafficctrl/trafficrule:".$Mssid."/tmpclientwidthup","0");
	   	     set("/runtime/stats/wtp/trafficctrl/trafficrule:".$Mssid."/tmpclientwidthdown","0");
	   	 }
            
          }
          
         }

     }
}
 if($needupdate==1)
     {
     echo "sleep 1\n";
     echo "bandwidthset refresh\n";
      if($needloop==1)
    {
	echo "xmldbc -t  dynamicbandwidthtag:18:".$loopFile."\n";
    }
     }else
     {
    if($needloop==1)
    {
	echo "xmldbc -t  dynamicbandwidthtag:18:".$loopFile."\n";
    }
    }
}else
{
  echo "xmldbc -k dynamicbandwidthtag\n";
}
?>


