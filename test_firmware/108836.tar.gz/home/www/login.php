<?php
  
    function checkSessionLink()
	{
		if(file_exists('/tmp/sessionid')) {
			return true;
		}
		else {
			return false;
		}
	}

	function checkSessionExpired()
	{
		if (checkSessionLink()) {
			if ((time()-@filemtime('/tmp/sessionid'))>300) 
				return true;
			else 
				return false;
		}
		else
			return true;
	}
	
	$passStr = conf_get("system:basicSettings:adminPasswd");
    	$str = explode(' ',$passStr);
	$str[1] = str_replace('\:',':',$str[1]);
	//$str[1] = str_replace('\\ ',' ',$str[1]);
	//$str[1] = str_replace('\\\\','\\',$str[1]);
        //$str[1] = 'password';
	//system("/usr/local/bin/passwd_check \"".$_REQUEST['username']."\" \"".$_REQUEST['password']."\" >> /dev/null", $authCheck);
    if ($_REQUEST['username'] == 'admin' && htmlentities($_REQUEST['password']) == htmlentities(conf_decrypt($str[1]))) {
    //if($authCheck=='0'){
                                     
        if (checkSessionExpired()===false) {
    		echo 'sessionexists';
        }
		else {
			session_start();
            $_SESSION['username']=$_REQUEST['username'];
			$fp = fopen('/tmp/sessionid', 'w');
			//fwrite($fp, session_id().','.$_SERVER['REMOTE_ADDR']);
			fwrite($fp, session_id().','.$_SERVER['REMOTE_ADDR'].','.$_SESSION['username']);
			fclose($fp);
			echo 'loginok';
		}
	}
	else {
		header('location:index.php');
	}
?>
