#!/bin/sh
#Game=("xboxlive" "worldofwarcraft" "teamfortress2" "subspace" "runesofmagic" "quake1" "quake-halflife" "mohaa" "liveforspeed" "halflife2-deathmatch" "guildwars" "doom3" "armagetron" "battlefield1942" "battlefield2" "battlefield2142" "counterstrike-source")
Game1="xboxlive"
Game2="worldofwarcraft"
Game3="teamfortress2"
Game4="subspace"
Game5="runesofmagic"
Game6="quake1"
Game7="quake-halflife"
Game8="mohaa"
Game9="liveforspeed"
Game10="halflife2-deathmatch"
Game11="guildwars"
Game12="doom3"
Game13="armagetron"
Game14="battlefield1942"
Game15="battlefield2"
Game16="battlefield2142"
Game17="counterstrike-source"
Game=17

Web1="http-rtsp"
Web2="http"
Web=2
#Web=("http-rtsp" "http")
Chat1="yahoo"
Chat2="qq"
Chat3="aim"
Chat4="irc"
Chat5="jabber"
Chat6="msn-filetransfer"
Chat7="msnmessenger"
Chat=7
#Chat=("yahoo" "qq" "aim" "irc" "jabber" "msn-filetransfer" "manmessenger")
Video1="rtp"
Video2="rtsp"
Video3="pplive"
Video4="replaytv-ivs"
Video5="shoutcast"
Video6="httpvideo"
Video=6
#Video=("rtp" "rtsp" "pplive" "replaytv-ivs" "shoutcast")
P2P1="xunlei"
P2P2="soulseek"
P2P3="soribada"
P2P4="poco"
P2P5="openft"
P2P6="napster"
P2P7="mute"
P2P8="kugoo"
P2P9="imesh"
P2P10="hotline"
P2P11="goboogy"
P2P12="gnutella"
P2P13="gnucleuslan"
P2P14="fasttrack"
P2P15="edonkey"
P2P16="100bao"
P2P17="applejuice"
P2P18="ares"
P2P19="bittorrent"
P2P20="directconnect"
P2P=20

#P2P=("xunlei" "soulseek" "soribada" "poco" "openft" "napster" "mute" "kugoo" "imesh" "hotline" "goboogy" "gnutella" "gnucleuslan" "fasttrack" "edonkey" "100bao" "applejuice" "ares" "bittorrent" "directconnect")
VoIP1="ventrilo"
VoIP2="teamspeak" 
VoIP3="h323"
VoIP4="rtp"
VoIP5="rtsp"
VoIP6="sip"
VoIP7="skypeout"
VoIP8="skypetoskype"
VoIP=8
#VoIP=("ventrilo" "teamspeak" "h323" "rtp" "rtsp" "sip" "skyoeout" "skypetoskype")

#function command(){
#eval number=\$$1
#echo "$number\n"
#		for ((i=1;i<=$number;i++))
#			do
#				eval /sbin/QosCoordinator -c L7 \$$1$i -f $2 $3 -dir 2
#				eval echo "/sbin/QosCoordinator -c L7 \$$1$i -f $2 $3 -dir 2"
#			done


#}

upload() {
    echo "upload setting:"
	tc class add dev $UP_IF parent 10: classid 10:200 htb rate $UP_BASE ceil $UP_BASE quantum 2000

	i=0	
	k=42
	while [ $k -le "47" ]
	do
		if [ $priority1 == "1" -a $k == "42" ] || [ $priority2 == "1" -a $k == "43" ] || [ $priority3 == "1" -a $k == "44" ] || [ $priority4 == "1" -a $k == "45" ] || [ $priority5 == "1" -a $k == "46" ] || [ $priority6 == "1" -a $k == "47" ]; then
			if [ $LoadBW == "1" ]; then
				tc class add dev $UP_IF parent 10:200 classid 10:$k htb rate $UP_BW ceil $UP_BW quantum 2000
				tc qdisc add dev $UP_IF parent 10:$k handle $k: pfifo limit 30
				tc filter add dev $UP_IF parent 10: protocol all prio 100  handle $k fw classid 10:$k
			fi
		fi

			if [ $LoadBW == "0" ]; then
				if [ $i == "0" -a $LAZY_FBMPER0 != "0" ]; then
				tc class add dev $UP_IF parent 10:200 classid 10:47 htb rate $FBMPER0 ceil $FBMPER0 quantum 2000
            	tc qdisc add dev $UP_IF parent 10:47 handle 47: pfifo limit 30
            	tc filter add dev $UP_IF parent 10: protocol all prio 100  handle 47 fw classid 10:47	
				fi

				if [ $i == "1" -a $LAZY_FBMPER1 != "0" ]; then
				tc class add dev $UP_IF parent 10:200 classid 10:46 htb rate $FBMPER1 ceil $FBMPER1 quantum 2000
            	tc qdisc add dev $UP_IF parent 10:46 handle 46: pfifo limit 30
            	tc filter add dev $UP_IF parent 10: protocol all prio 100  handle 46 fw classid 10:46	
				fi

				if [ $i == "2" -a $LAZY_FBMPER2 != "0" ]; then
				tc class add dev $UP_IF parent 10:200 classid 10:42 htb rate $FBMPER2 ceil $FBMPER2 quantum 2000
            	tc qdisc add dev $UP_IF parent 10:42 handle 42: pfifo limit 30
            	tc filter add dev $UP_IF parent 10: protocol all prio 100  handle 42 fw classid 10:42	
				fi

				if [ $i == "3" -a $LAZY_FBMPER3 != "0" ]; then
				tc class add dev $UP_IF parent 10:200 classid 10:44 htb rate $FBMPER3 ceil $FBMPER3 quantum 2000
            	tc qdisc add dev $UP_IF parent 10:44 handle 44: pfifo limit 30
            	tc filter add dev $UP_IF parent 10: protocol all prio 100  handle 44 fw classid 10:44	
				fi

				if [ $i == "4" -a $LAZY_FBMPER4 != "0" ]; then
				tc class add dev $UP_IF parent 10:200 classid 10:43 htb rate $FBMPER4 ceil $FBMPER4 quantum 2000
            	tc qdisc add dev $UP_IF parent 10:43 handle 43: pfifo limit 30
            	tc filter add dev $UP_IF parent 10: protocol all prio 100  handle 43 fw classid 10:43	
				fi

				if [ $i == "5" -a $LAZY_FBMPER5 != "0" ]; then
				tc class add dev $UP_IF parent 10:200 classid 10:45 htb rate $FBMPER5 ceil $FBMPER5 quantum 2000
            	tc qdisc add dev $UP_IF parent 10:45 handle 45: pfifo limit 30
            	tc filter add dev $UP_IF parent 10: protocol all prio 100  handle 45 fw classid 10:45	
				fi
			fi

		k=$(($k+1))
		i=$(($i+1))
	done
}

download() {
    echo "download setting:"
	tc class add dev $DOWN_IF parent 10: classid 10:200 htb rate $DOWN_BASE ceil $DOWN_BASE quantum 2000

	i=0	
	k=42
	while [ $k -le "47" ]
	do
		if [ $priority1 == "1" -a $k == "42" ] || [ $priority2 == "1" -a $k == "43" ] || [ $priority3 == "1" -a $k == "44" ] || [ $priority4 == "1" -a $k == "45" ] || [ $priority5 == "1" -a $k == "46" ] || [ $priority6 == "1" -a $k == "47" ]; then
			if [ $LoadBW == "1" ]; then
				tc class add dev $DOWN_IF parent 10:200 classid 10:$k htb rate $DOWN_BW ceil $DOWN_BW quantum 2000
				tc qdisc add dev $DOWN_IF parent 10:$k handle $k: pfifo limit 30
				tc filter add dev $DOWN_IF parent 10: protocol all prio 100  handle $k fw classid 10:$k
			fi
		fi

			if [ $LoadBW == "0" ]; then
				if [ $i == "0" -a $LAZY_FBMPER0 != "0" ]; then
				tc class add dev $DOWN_IF parent 10:200 classid 10:47 htb rate $FBMPER0_DOWN ceil $FBMPER0_DOWN quantum 2000
            	tc qdisc add dev $DOWN_IF parent 10:47 handle 47: pfifo limit 30
            	tc filter add dev $DOWN_IF parent 10: protocol all prio 100  handle 47 fw classid 10:47	
				fi

				if [ $i == "1" -a $LAZY_FBMPER1 != "0" ]; then
				tc class add dev $DOWN_IF parent 10:200 classid 10:46 htb rate $FBMPER1_DOWN ceil $FBMPER1_DOWN quantum 2000
            	tc qdisc add dev $DOWN_IF parent 10:46 handle 46: pfifo limit 30
            	tc filter add dev $DOWN_IF parent 10: protocol all prio 100  handle 46 fw classid 10:46	
				fi

				if [ $i == "2" -a $LAZY_FBMPER2 != "0" ]; then
				tc class add dev $DOWN_IF parent 10:200 classid 10:42 htb rate $FBMPER2_DOWN ceil $FBMPER2_DOWN quantum 2000
            	tc qdisc add dev $DOWN_IF parent 10:42 handle 42: pfifo limit 30
            	tc filter add dev $DOWN_IF parent 10: protocol all prio 100  handle 42 fw classid 10:42	
				fi

				if [ $i == "3" -a $LAZY_FBMPER3 != "0" ]; then
				tc class add dev $DOWN_IF parent 10:200 classid 10:44 htb rate $FBMPER3_DOWN ceil $FBMPER3_DOWN quantum 2000
            	tc qdisc add dev $DOWN_IF parent 10:44 handle 44: pfifo limit 30
            	tc filter add dev $DOWN_IF parent 10: protocol all prio 100  handle 44 fw classid 10:44	
				fi

				if [ $i == "4" -a $LAZY_FBMPER4 != "0" ]; then
				tc class add dev $DOWN_IF parent 10:200 classid 10:43 htb rate $FBMPER4_DOWN ceil $FBMPER4_DOWN quantum 2000
            	tc qdisc add dev $DOWN_IF parent 10:43 handle 43: pfifo limit 30
            	tc filter add dev $DOWN_IF parent 10: protocol all prio 100  handle 43 fw classid 10:43	
				fi

				if [ $i == "5" -a $LAZY_FBMPER5 != "0" ]; then
				tc class add dev $DOWN_IF parent 10:200 classid 10:45 htb rate $FBMPER5_DOWN ceil $FBMPER5_DOWN quantum 2000
            	tc qdisc add dev $DOWN_IF parent 10:45 handle 45: pfifo limit 30
            	tc filter add dev $DOWN_IF parent 10: protocol all prio 100  handle 45 fw classid 10:45	
				fi
			fi

		k=$(($k+1))
		i=$(($i+1))
	done
}

UNIT="kbps"
sum=0
k=0
UP_IF=`rdcsman 0x8001000b str`
QOS_INTERFACE=`rdcsman 0x00121300 u16`
MUTI_ENABLE=`rdcsman 0x00010100 u16`
if [ $QOS_INTERFACE == "99" ] || [ $QOS_INTERFACE == "0" -a $MUTI_ENABLE == "0" ]; then
	UP_IF=`rdcsman 0x8001000b str`
else
	UP_IF=`rdcsman 0x80010190 str`
fi
DOWN_IF=`rdcsman 0x8000F201 str`
UP_MAX_BW=`rdcsman 0x00120020 u32`
DOWN_MAX_BW=`rdcsman 0x00120030 u32`
LAZY_FBMPER0=`rdcsman 0x0012d000 u16`
LAZY_FBMPER1=`rdcsman 0x0012d001 u16`
LAZY_FBMPER2=`rdcsman 0x0012d002 u16`
LAZY_FBMPER3=`rdcsman 0x0012d003 u16`
LAZY_FBMPER4=`rdcsman 0x0012d004 u16`
LAZY_FBMPER5=`rdcsman 0x0012d005 u16`
QOS_MODE=`rdcsman 0x00120010 u8`
LoadBW=`rdcsman 0x00120015 u8`
LAZY_SETTING=`rdcsman 0x00120017 str`
priority1=0
priority2=0
priority3=0
priority4=0
priority5=0
priority6=0
ROMID=`rdcsman 0x80004210 str`
i=1
#for (( i=0; i<6; i++ ))
while [ $i -le "6" ]
do
	SET=`expr $LAZY_SETTING % 10`
	if [ "$SET" == "1" ] && [ "$i" == "1" ]; then 
		sum=$(($sum+1))
		priority1="1"
	elif [ "$SET" == "1" ] && [ "$i" == "2" ]; then
		sum=$(($sum+1))
        priority2="1"
	elif [ "$SET" == "1" ] && [ "$i" == "3" ]; then
		sum=$(($sum+1))
        priority3="1"
	elif [ "$SET" == "1" ] && [ "$i" == "4" ]; then
		sum=$(($sum+1))
        priority4="1"
	elif [ "$SET" == "1" ] && [ "$i" == "5" ]; then
		sum=$(($sum+1))
        priority5="1"
	elif [ "$SET" == "1" ] && [ "$i" == "6" ]; then
		sum=$(($sum+1))
        priority6="1"
	else
		echo ""
	fi
	LAZY_SETTING=`expr $LAZY_SETTING / 10`
	echo "LAZY_SETTING=$LAZY_SETTING"
	i=$(($i+1))
done 

UP_MAX_BW=`expr $UP_MAX_BW / 8`
	echo "UP_MAX_BW=$UP_MAX_BW"
UP_BASE_MAX=`expr $UP_MAX_BW \* 9`
	echo "UP_BASE_MAX=$UP_BASE_MAX"
UP_BASE=`expr $UP_BASE_MAX / 10`
	echo "UP_BASE=$UP_BASE"
if [ $sum != "0" ]; then
	UP_BW=`expr $UP_BASE / $sum`$UNIT
else
	UP_BW=$UP_BASE$UNIT
fi	
	echo "UP_BW=$UP_BW"
#FBM_BASE=`expr $UP_BASE / 100`
FBMPER0=`expr $UP_MAX_BW \* $LAZY_FBMPER0`
FBMPER0=`expr $FBMPER0 / 100`$UNIT

FBMPER1=`expr $UP_MAX_BW \* $LAZY_FBMPER1`
FBMPER1=`expr $FBMPER1 / 100`$UNIT

FBMPER2=`expr $UP_MAX_BW \* $LAZY_FBMPER2`
FBMPER2=`expr $FBMPER2 / 100`$UNIT

FBMPER3=`expr $UP_MAX_BW \* $LAZY_FBMPER3`
FBMPER3=`expr $FBMPER3 / 100`$UNIT

FBMPER4=`expr $UP_MAX_BW \* $LAZY_FBMPER4`
FBMPER4=`expr $FBMPER4 / 100`$UNIT

FBMPER5=`expr $UP_MAX_BW \* $LAZY_FBMPER5`
FBMPER5=`expr $FBMPER5 / 100`$UNIT
	echo "FBMPER5=$FBMPER5"
UP_MAX_BW=$UP_MAX_BW$UNIT
UP_BASE=$UP_BASE$UNIT

DOWN_MAX_BW=`expr $DOWN_MAX_BW / 8`
DOWN_BASE_MAX=`expr $DOWN_MAX_BW \* 9`
DOWN_BASE=`expr $DOWN_BASE_MAX / 10`
if [ $sum != "0" ]; then
    DOWN_BW=`expr $DOWN_BASE / $sum`$UNIT
else
    DOWN_BW=$DOWN_BASE$UNIT
fi
#FBM_BASE=`expr $UP_BASE / 100`
FBMPER0_DOWN=`expr $DOWN_MAX_BW \* $LAZY_FBMPER0`
FBMPER0_DOWN=`expr $FBMPER0_DOWN / 100`$UNIT

FBMPER1_DOWN=`expr $DOWN_MAX_BW \* $LAZY_FBMPER1`
FBMPER1_DOWN=`expr $FBMPER1_DOWN / 100`$UNIT

FBMPER2_DOWN=`expr $DOWN_MAX_BW \* $LAZY_FBMPER2`
FBMPER2_DOWN=`expr $FBMPER2_DOWN / 100`$UNIT

FBMPER3_DOWN=`expr $DOWN_MAX_BW \* $LAZY_FBMPER3`
FBMPER3_DOWN=`expr $FBMPER3_DOWN / 100`$UNIT

FBMPER4_DOWN=`expr $DOWN_MAX_BW \* $LAZY_FBMPER4`
FBMPER4_DOWN=`expr $FBMPER4_DOWN / 100`$UNIT

FBMPER5_DOWN=`expr $DOWN_MAX_BW \* $LAZY_FBMPER5`
FBMPER5_DOWN=`expr $FBMPER5_DOWN / 100`$UNIT
DOWN_MAX_BW=$DOWN_MAX_BW$UNIT
DOWN_BASE=$DOWN_BASE$UNIT

v=$#
case $1 in
"forbidden")
	#for((j=1;j<$v;j++))
	j=1
	while [ $j -le $v ]
	do
	eval number=\$$2
		echo "$number\n"
		i=1
	#	for ((i=1;i<=$number;i++))
		while [ $i -le $number ]
		do
				#eval /sbin/QoSCoordinator -c L7 \$$2$i -f DROP -dir 2
				#eval echo "/sbin/QosCoordinator -c L7 \$$2$i -f DROP -dir 2"
			eval iptables -t mangle -I qos_post -m layer7 --l7proto \$$2$i -j  DROP
			i=$(($i+1))
			done
	#command $2 DROP
	echo  "command $2 DROP"
	shift
	echo "$2"
			j=$(($j+1))
	done

	;;
"important")
	#for((j=1;j<$v;j++))	
	j=1
	while [ $j -le $v ]
	do
		if [ $2 == "Game" ]; then
			k=47
		elif [ $2 == "Chat" ]; then
			k=46
		elif [ $2 == "Web" ]; then
			k=45
		elif [ $2 == "P2P" ]; then
			k=44
		elif [ $2 == "Video" ]; then
			k=43
		else 
			k=42
		fi

		eval number=\$$2
		echo "$number\n"
		i=1
		#for ((i=1;i<=$number;i++))
		while [ $i -le $number ]
			do
				#eval /sbin/QoSCoordinator -c L7 \$$2$i -f PRI 1 -dir 2
				#eval echo "/sbin/QosCoordinator -c L7 \$$2$i -f PRI 1 -dir 2"
			eval iptables -t mangle -I qos_post -m layer7 --l7proto \$$2$i  -j  RETURN
			eval iptables -t mangle -I qos_post -m layer7 --l7proto \$$2$i  -j  MARK --set-mark $k
			i=$(($i+1))
			done

	#command $2 PRI 1
	echo  "command $2 PRI 1"
	shift
	echo "$2"
			j=$(($j+1))
	done
	upload
	download
	;;
"Dimportant")
	#for((j=1;j<$v;j++))	
	j=1
	while [ $j -le $v ]
	do
		if [ $2 == "Game" ]; then
			k=47
		elif [ $2 == "Chat" ]; then
			k=46
		elif [ $2 == "Web" ]; then
			k=45
		elif [ $2 == "P2P" ]; then
			k=44
		elif [ $2 == "Video" ]; then
			k=43
		else 
			k=42
		fi

		eval number=\$$2
		echo "$number\n"
		i=1
		#for ((i=1;i<=$number;i++))
		while [ $i -le $number ]
			do
				#eval /sbin/QoSCoordinator -c L7 \$$2$i -f PRI 1 -dir 2
				#eval echo "/sbin/QosCoordinator -c L7 \$$2$i -f PRI 1 -dir 2"
			eval iptables -t mangle -D qos_post -m layer7 --l7proto \$$2$i  -j  RETURN
			eval iptables -t mangle -D qos_post -m layer7 --l7proto \$$2$i  -j  MARK --set-mark $k
			i=$(($i+1))
			done

	#command $2 PRI 1
	echo  "command $2 PRI 1"
	shift
	echo "$2"
			j=$(($j+1))
	done
##	Dupload
	;;
"Dforbidden")
	#for((j=1;j<$v;j++))
	j=1
	while [ $j -le $v ]
	do
	eval number=\$$2
		echo "$number\n"
		i=1
	#	for ((i=1;i<=$number;i++))
		while [ $i -le $number ]
		do
				#eval /sbin/QoSCoordinator -c L7 \$$2$i -f DROP -dir 2
				#eval echo "/sbin/QosCoordinator -c L7 \$$2$i -f DROP -dir 2"
			eval iptables -t mangle -D qos_post -m layer7 --l7proto \$$2$i -j  DROP
			i=$(($i+1))
			done
	#command $2 DROP
	echo  "command $2 DROP"
	shift
	echo "$2"
			j=$(($j+1))
	done

	;;

	
	*)
	echo "wrong argument $1 $2 $3"
	exit 1
	;;
esac

	
