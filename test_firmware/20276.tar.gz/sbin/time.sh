#!/bin/sh

echo "`take_time c $1 $2 $3`" > /etc/qos_time_tule


