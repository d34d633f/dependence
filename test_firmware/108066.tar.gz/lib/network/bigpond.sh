print_bpa_options(){
	cat <<EOF
username $1
password $2
authserver $3
idletime $4
maxheartbeatinterval 900
devname $5
linkmode $6
EOF
}

setup_interface_bigpond() {
	local domain mode dod idle="0"

	dod="$($CONFIG get wan_endis_dod)"

	if [ "$dod" = "1" ]; then
		idle="$($CONFIG get wan_bpa_idle_time)"
		mode="demand"
	elif [ "$dod" = "2" ]; then
		[ "x$1" != "xmanually" ] && exit 0
		mode="runone"
	else
		mode="persist"
	fi

	print_bpa_options "$($CONFIG get wan_bpa_username)" "$($CONFIG get wan_bpa_password)" "$($CONFIG get wan_bpa_servicename)" "$idle" "$WAN_IF" "$mode" > /tmp/bpalogin.conf

	udhcpc -b -i $WAN_IF -h $($CONFIG get wan_hostname) -r $($CONFIG get wan_dhcp_ipaddr)
	sleep 1
	ifconfig $WAN_IF mtu $($CONFIG get wan_dhcp_mtu)

	# Started it by udhcpc-script which will add 'dhcp-learned-domain-suffix' into '/tmp/bpalogin.conf'
	echo "Start BPA-Login by DHCP module"
	#bpalogin -c /tmp/bpalogin.conf
}

