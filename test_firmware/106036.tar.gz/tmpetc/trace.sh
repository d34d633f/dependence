#!/bin/sh
/usr/bin/traceroute -n -m $1 $2 > /tmp/traceroute.$3 2>&1
echo "==END==" >> /tmp/traceroute.$3
