#!/bin/sh
phpsh /etc/events/UPDATELEASES.php INF=$1 FILE=$2
exit 0
