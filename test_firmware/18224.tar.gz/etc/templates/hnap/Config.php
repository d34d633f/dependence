<?	
	$WAN1  = "WAN-1";
	$WAN2  = "WAN-2";
	$WLAN1 = "BAND24G-1.1";
	$WLAN2 = "BAND5G-1.1";
	$LAN1  = "LAN-1";
	$LAN2  = "LAN-2";
	
	$SRVC_WLAN = "PHYINF.WIFI";
?>

