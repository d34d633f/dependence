HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
/*$nodebase="/runtime/hnap//SetWLanRadioSecurity/";

if( query($nodebase."RadioID") == "2.4GHZ" || query($nodebase."RadioID") == "RADIO_24GHz")
{	$path_phyinf_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN1, 0);	}
if( query($nodebase."RadioID") == "5GHZ" || query($nodebase."RadioID") == "RADIO_5GHz")
{	$path_phyinf_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN2, 0);	}
$path_wlan_wifi = XNODE_getpathbytarget("/wifi", "entry", "uid", query($path_phyinf_wlan."/wifi"), 0);

anchor($path_wlan_wifi);
$result = "REBOOT";
if( query($nodebase."RadioID") != "2.4GHZ" &&
	query($nodebase."RadioID") != "5GHZ" &&
	query($nodebase."RadioID") != "RADIO_24GHz" &&
	query($nodebase."RadioID") != "RADIO_5GHz" )
{
	
	$result = "ERROR_BAD_RADIOID";
}
else
*/

$nodebase="/runtime/hnap/SetWLanRadioSecurity/";
$RadioID = query($nodebase."RadioID");

if( $RadioID == "2.4GHZ" || $RadioID == "RADIO_24GHz" || $RadioID == "RADIO_2.4GHz"){
    $path_phyinf_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN1, 0);
    $result = "REBOOT";
}
else if( $RadioID == "5GHZ" || $RadioID == "RADIO_5GHz"){
    $path_phyinf_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN2, 0);
    $result = "REBOOT";
}
else if( $RadioID == "RADIO_2.4G_Guest"){	
	$path_phyinf_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN1_GZ, 0);
	$result = "REBOOT";
} 
else if( $RadioID == "RADIO_5G_Guest"){	
	$path_phyinf_wlan = XNODE_getpathbytarget("", "phyinf", "uid", $WLAN2_GZ, 0);
	$result = "REBOOT";
}
else {$result = "ERROR_BAD_RADIOID";}

$path_wlan_wifi = XNODE_getpathbytarget("/wifi", "entry", "uid", query($path_phyinf_wlan."/wifi"), 0);
anchor($path_wlan_wifi);

if( $result == "REBOOT" ||  $result == "OK")
{
	if(query($nodebase."Enabled") == "false" )
	{
		set("encrtype","NONE");
		set("authtype","OPEN");
	}
	else
	{
		$type = query($nodebase."Type");
		$encrypt = query($nodebase."Encryption");
		$key = query($nodebase."Key");
		$keyRenewal = query($nodebase."KeyRenewal");
		$radiusIP1 = query($nodebase."RadiusIP1");
		$radiusPort1 = query($nodebase."RadiusPort1");
		$radiusSecret1 = query($nodebase."RadiusSecret1");
		$radiusIP2 = query($nodebase."RadiusIP2");
		$radiusPort2 = query($nodebase."RadiusPort2");
		$radiusSecret2 = query($nodebase."RadiusSecret2");
		if( $type == "WEP-OPEN" || $type == "WEP-SHARED" || $type == "WEP-AUTO")
		{
			if( $encrypt == "WEP-64" )
			{
				$wepLen = 64;
			}
			else if( $encrypt == "WEP-128" )
			{
				$wepLen = 128;
			}
			else
			{
				$result = "ERROR_ENCRYPTION_NOT_SUPPORTED";
			}
			if( $type == "WEP-OPEN" )
			{
				$auth = "OPEN";
			}
			if( $type == "WEP-AUTO" )
			{
				$auth = "WEPAUTO";
			}			
			else
			{
				$auth = "SHARED";
			}
			//The WEP key should be 5 ASCII or 13 hex digits for 64 bit or 10 ASCII or 26 hex digits for 128 bit.
			if( $key == "" )
			{ $result = "ERROR_ILLEGAL_KEY_VALUE"; }
			else
			{
				$keyLen = strlen($key);
				if(isprint($key)==1 && $keyLen==5 && $wepLen==64) { $ascii = "1";}
				else if(isprint($key)==1 && $keyLen==10 && $wepLen==128) { $ascii = "1";}
				else if(isxdigit($key)==1 && $keyLen==13 && $wepLen==64) { $ascii = "0";}
				else if(isxdigit($key)==1 && $keyLen==26 && $wepLen==128) { $ascii = "0";}
				else {$result = "ERROR_ILLEGAL_KEY_VALUE";}
			}
			if( $result == "REBOOT" ||  $result == "OK" )
			{
				set("wps/configured", "1");
				set("authtype", $auth);
				set("encrtype","WEP");
				set("nwkey/wep/size", $wepLen);
				set("nwkey/wep/ascii", $ascii);
				set("nwkey/wep/defkey", "1"); 
				$defKey = query("nwkey/wep/defkey");
				set("nwkey/wep/key:".$defKey, $key);
			}
		}
		else if( $type == "WPA-PSK" || $type == "WPA2-PSK" || $type == "WPAORWPA2-PSK" )
		{
			if( $keyRenewal == "" )
			{
				$result = "ERROR_KEY_RENEWAL_BAD_VALUE";
			}
			//more strict
			if( $keyRenewal < 60 || $keyRenewal > 7200 )
			{
				$result = "ERROR_KEY_RENEWAL_BAD_VALUE";
			}
			if( $key == "" )
			{
				$result = "ERROR_ILLEGAL_KEY_VALUE";
			}
			if( $encrypt != "TKIP" && $encrypt != "AES" && $encrypt != "TKIPORAES" )
			{
				$result = "ERROR_ENCRYPTION_NOT_SUPPORTED";
			}
			if( $type == "WPA-PSK" )
			{ $auth = "WPAPSK"; }
			else if( $type == "WPA2-PSK" )
			{ $auth = "WPA2PSK"; }
			else
			{ $auth = "WPA+2PSK"; }
			if( $encrypt == "TKIP" )
			{ $encrypttype = "TKIP"; }
			else if( $encrypt == "AES" )
			{ $encrypttype = "AES"; }
			else
			{ $encrypttype = "TKIP+AES"; }
			if( $result == "REBOOT" ||  $result == "OK" )
			{
				set("wps/configured", "1");
				set("authtype",$auth);
				set("encrtype",$encrypttype);
				set("nwkey/wep/ascii","1");
				set("nwkey/psk/key",$key);
				set("nwkey/psk/passphrase", "1");
				set("nwkey/rekey/gtk",$keyRenewal);
			}
		}
		else if( $type == "WPA-RADIUS" || $type == "WPA2-RADIUS" || $type == "WPAORWPA2-RADIUS" )
		{
			if( $keyRenewal == "" )
			{
				$result = "ERROR_KEY_RENEWAL_BAD_VALUE";
			}
			//more strict
			if( $keyRenewal < 60 || $keyRenewal > 7200 )
			{
				$result = "ERROR_KEY_RENEWAL_BAD_VALUE";
			}
			if( $encrypt != "TKIP" && $encrypt != "AES" && $encrypt != "TKIPORAES" )
			{
				$result = "ERROR_ENCRYPTION_NOT_SUPPORTED";
			}
			if( $radiusIP1 == "" || $radiusPort1 == "" || $radiusSecret1 == "" )
			{
				$result = "ERROR_BAD_RADIUS_VALUES";
			}
			if( $type == "WPA-RADIUS" )
			{ $auth = "WPA"; }
			else if( $type == "WPA2-RADIUS" )
			{ $auth = "WPA2"; }
			else
			{ $auth = "WPA+2"; }
			if( $encrypt == "TKIP" )
			{ $encrypttype = "TKIP"; }
			else if( $encrypt == "AES" )
			{ $encrypttype = "AES"; }
			else
			{ $encrypttype = "TKIP+AES"; }
			if( $result == "REBOOT" ||  $result == "OK" )
			{
				set("wps/configured", "1");
				set("authtype",$auth);
				set("encrtype",$encrypttype);
				set("nwkey/wep/ascii","1");
				set("nwkey/eap/radius",$radiusIP1);
				set("nwkey/eap/port",$radiusPort1);
				set("nwkey/eap/secret",$radiusSecret1);
				set("nwkey/eap/radius2",$radiusIP2);
				set("nwkey/eap/port2",$radiusPort2);
				set("nwkey/eap/secret2",$radiusSecret2);
				set("nwkey/rekey/gtk",$keyRenewal);
			}
		}
		else
		{
			$result = "ERROR_TYPE_NOT_SUPPORT";
		}
	}
}

fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "echo \"[$0]-->WLan Change\" > /dev/console\n");
if($result == "REBOOT" ||  $result == "OK")
{
	fwrite("a",$ShellPath, "/etc/scripts/dbsave.sh > /dev/console\n");
	fwrite("a",$ShellPath, "service ".$SRVC_WLAN." restart > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <SetWLanRadioSecurityResponse xmlns="http://purenetworks.com/HNAP1/">
      <SetWLanRadioSecurityResult><?=$result?></SetWLanRadioSecurityResult>
    </SetWLanRadioSecurityResponse>
  </soap:Body>
</soap:Envelope>
