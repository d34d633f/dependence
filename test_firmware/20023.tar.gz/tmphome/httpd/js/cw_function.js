/* 
	Enabled_Load Function
	Control a<--checkbox, radio
	Disabled b<--any element
	Enabled c
	
	Visabled_Load(":input[name=BBB][value=on]", "#startip, #endip", null);
	Visabled_Load(":input[name=BBB][value=off]", null , "#status, #startip, #endip");
	
*/


function Visabled_Load(a,b,c){
	
	if($(a).prop("type")=="select-one"){
		Visabled_Func($(a)[0].selectedIndex ==0, b ,c);		
		$(a).bind("change", {Object: a, Show: b, Hide: c}, Visabled_Event);
	}
	else{
		Visabled_Func($(a).prop("checked"), b ,c);
		$(a).bind("click", {Object: a, Show: b, Hide: c}, Visabled_Event);
		$(a).bind("change", {Object: a, Show: b, Hide: c}, Visabled_Event);
	}	
	
};


function Visabled_Event(event){
	if($(event.data.Object).prop("type")=="select-one")
		Visabled_Func($(event.data.Object)[0].selectedIndex==0, event.data.Show, event.data.Hide);	
	else
		Visabled_Func($(event.data.Object).prop("checked"), event.data.Show, event.data.Hide);
	
};

function Visabled_Func(a, b, c){

	if(a==true){
		if (b!=null) $(b).show();
		if (c!=null) $(c).hide();
	}
	else
	{
		if (b!=null)$(b).hide();
		if (c!=null)$(c).show();
	}	
}
//=======================================================================================================
function Enabled_Load(a,b,c){
	if($(a).prop("type")=="select-one"){
		Enabled_Func($(a)[0].selectedIndex ==0, b ,c);		
		$(a).bind("change", {Object: a, Show: b, Hide: c}, Enabled_Event);
	}
	else{
		Enabled_Func($(a).prop("checked") , b ,c);
		$(a).bind("click", {Object: a, Show: b, Hide: c}, Enabled_Event);
		$(a).bind("change", {Object: a, Show: b, Hide: c}, Enabled_Event);
	}	
	
};


function Enabled_Event(event){
	if($(event.data.Object).prop("type")=="select-one")
		Enabled_Func($(event.data.Object)[0].selectedIndex==0, event.data.Show, event.data.Hide);	
	else
		Enabled_Func($(event.data.Object).prop("checked"), event.data.Show, event.data.Hide);
	
};

function Enabled_Func(a, b, c){
	if(a==true){
		if (b!=null) $(b).attr("disabled",false);
		if (c!=null) $(c).attr("disabled",true);
	}
	else
	{
		if (b!=null) $(b).attr("disabled",true);
		if (c!=null) $(c).attr("disabled",false);
	}	
}


//=======================================================================================================
function Mix_Load(a, b1, b2, c1, c2){
	if($(a).prop("type")=="select-one"){
		Mix_Func($(a)[0].selectedIndex ==0, b1 , b2, c1, c2);		
		$(a).bind("change", {Object: a, Show: b1, Enabled: b2, Hide: c1, Disabled: c2 }, Mix_Event);
	}
	else{
		Mix_Func($(a).prop("checked") ,b1 ,b2 ,c1 ,c2);
		$(a).bind("click", {Object: a, Show: b1, Enabled: b2, Hide: c1, Disabled: c2 }, Mix_Event);		
		$(a).bind("change", {Object: a, Show: b1, Enabled: b2, Hide: c1, Disabled: c2 }, Mix_Event);		
	}	

}

function Mix_Event(event){
	if($(event.data.Object).prop("type")=="select-one")
		Mix_Func($(event.data.Object)[0].selectedIndex==0, event.data.Show, event.data.Enabled, event.data.Hide, event.data.Disabled);	
	else
		Mix_Func($(event.data.Object).prop("checked"), event.data.Show, event.data.Enabled, event.data.Hide, event.data.Disabled);
	
};

function Mix_Func(a, b1, b2, c1, c2){
	if(a==true){
		if (b1!=null) $(b1).show();
		if (c1!=null) $(c1).hide();
		if (b2!=null) $(b2).attr("disabled",false);
		if (c2!=null) $(c2).attr("disabled",true);
	}
	else
	{
		if (b1!=null) $(b1).hide();
		if (c1!=null) $(c1).show();
		if (b2!=null) $(b2).attr("disabled",true);
		if (c2!=null) $(c2).attr("disabled",false);
	}	
}

function clear_function(){
	this.form.reset();
	location.reload();
}

function default_value(name, value, select_check_name)
{
	if($(name).prop("type") == "text") {
		if($(name).val() == "")
			$(name).val(value);
	}
	else if($(name).prop("type") == "radio") {
		if($(name+"[checked]").val() == undefined)
			$(name+"[value="+value+"]").attr("checked", "checked");
	}
	else if($(name).prop("type") == "select-one") {
		if($(select_check_name).val() == "") {
			$(name).attr("value", value);
		}
	}
}

function checkMac(str) {
	var len = str.length;
	if(len != 17 && len != 12)
		return false;
	
	for (i=0; i<len; i++) {
		if(len == 17 && (i%3) == 2){
			if(str.charAt(i) == ':')
				continue;
		}else{
			if (    (str.charAt(i) >= '0' && str.charAt(i) <= '9') ||
					(str.charAt(i) >= 'a' && str.charAt(i) <= 'f') ||
					(str.charAt(i) >= 'A' && str.charAt(i) <= 'F') )
				continue;
		}
		return false;
	}
	return true;
}

function checkURL(str) {
	var len = str.length;
	if(len == 0)
		return false;
	
	for (i=0; i<len; i++) {
		if(str.charAt(i) == ' ' || str.charAt(i) == ';' ||
			str.charAt(i) == '"')
			return false;
	}
	return true;
}

function Check_IP(value)
{
	var regexIP = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
	return (!value.match(regexIP));
}

function Check_URL(value)
{
	var regexURL = /^([\w]+)(\.[\w]+){1,5}$/;
	return (!value.match(regexURL));
}

function Check_Domain(value)
{
	var regexDM = /^(\w{2,}\.)+[a-zA-Z]{2,}$/;
	return (!value.match(regexDM));
}

function Check_Mail(value)
{
	var regexMail = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
	return (!value.match(regexMail));
}

function roundNumber(num, dec) {
	var result = Math.round(num*Math.pow(10,dec))/Math.pow(10,dec);
	return result;
}

var ESSID_Change_event=function($input){
	var valid_word_len=function(event){
		var val=$(this).val();
		var text=encodeURIComponent(val);
		var len=text.replace(/%[A-F\d]{2}/g, 'U').length;
		while(len>32){
			val=val.substring(0, val.length-1);
			text=encodeURIComponent(val);
			len=text.replace(/%[A-F\d]{2}/g, 'U').length;
			$(this).val(val);
		}
		if((val.search('"')!=-1) || (val.search("'")!=-1)){
			while(((val.search('"')!=-1) || (val.search("'")!=-1)))
				val=val.replace('"', "").replace("'", "");
			$(this).val(val);
		}


	};
	$input.change(valid_word_len).keyup(valid_word_len);
	$input.keydown(function(event){
		if(event.which==222)
			event.preventDefault();
	});
};

