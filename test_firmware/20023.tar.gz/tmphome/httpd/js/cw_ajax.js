	var options = { dataType: 'json', beforeSubmit: beforefunc, success: proccessJson};
	var hotzone_options = { dataType: 'json', beforeSubmit: beforefunc, success: proccessJson2};
	var urls="/cgi-bin/index.cgi?cgi=MODE";
	var mode, user;
	var ints=0;
	var cgi="MODE";
	var page="";
	var auto_refresh_id=0;
	var d= new Date();
	var NOBJ= new Object();
	var dev_options={
		series: {
			lines: {show: true}, 
			points: {show: true, radius: 2}
		},
		xaxis: {
			tickSize:10,
			tickFormatter: function(val, axis){return ""}
		},
		yaxis: {
			min: 0,
			ticks: 5,
			labelWidth: 50,
			tickDecimals: 1,
			tickFormatter: function (val, axis)
			{
				if(axis.max > 1048576)
				{
					if(val==0)
						return ("MBps 0")
					else 
						return (val / 1000000).toFixed(axis.tickDecimals);
				}
				else if((axis.max < 1048576 & axis.max > 1024))
				{
					if(val==0)	
						return ("KBps 0");
					else
						return (val / 1000).toFixed(axis.tickDecimals);
				}
				else
				{
					if(val==0)
						return ("Bps 0");
					else
						return (val).toFixed(axis.tickDecimals);
				}
			}
		}
	};
	$(function(){
		$("body").hide();
		$('#dialog').dialog({
			autoOpen: false,
			bgiframe: true,
			modal: true,
			draggable: false,
			resizable: false,
			width: 360,
			open: function(event, ui){
				$("a.ui-dialog-titlebar-close").hide();
			},
			close: function(event, ui){
				$("a.ui-dialog-titlebar-close").show();
			}
		});

		$("#tab_menu").load("/cgi-bin/index.cgi?cgi=MENU #main_menu",
			function(){
				$("#tab_menu a.link").click(
					function()
					{
						cgi = $(this).attr("cgi");
						page = $(this).attr("page");
						urls = "/cgi-bin/index.cgi?cgi="+cgi+"&page="+page;
						loadpage();
					}
				);
				/*
				$("#COUNTRY").load("/cgi-bin/index.cgi?cgi=COUNTRY_CODE",
					function(){
					$(":input[name=Country_code]").change(function(){
						$.post("/cgi-bin/Save.cgi?cgi=COUNTRY_CODE", {"Country_code": $(this).val()},
							function(data){
								if(data.status=="success")
									location.href="/index.html";
								else
									alertinfo('Error Message', data.msg);
						},"json");
					});
				});
				*/
				$("#navbar").load("/cgi-bin/index.cgi?cgi=MENU #sub_menu",
					function(){
						$("#navbar #menu").treeview({collapsed: false});
						$("#navbar a.link").click(
							function()
							{
								cgi = $(this).attr("cgi");
								page = $(this).attr("page");
								urls = "/cgi-bin/index.cgi?cgi="+cgi+"&page="+page;
								loadpage();
						});
				});
				$.cookie("LASTACCESS", ((new Date()).getTime()).toString());
				loadpage();	
				$("body").show();
			});
	});
function proccessJson(data) {
	if(data.status=="error")
		alertinfo('Error Message', data.msg);
	else
		loadpage();
}
function proccessJson2(data) {
	if(data.status=="error")
			alertinfo('Error Message', data.msg);
	else
	{
		$("#alert-info").show();
		$("#WEBPAGE").dialog("close");
		load_zone();
	}
}
function proccessJson3(data) {
	if(data.status=="error")
	{
		alertinfo('Error Message', data.msg);
	}
	else
	{
		$("#dialog").dialog('close');
		loadpage();
	}
}
function beforefunc()
{
	$("#alert-info").hide();
}
function DialogClose()
{
	$("#dialog").dialog('close');
}
function loadpage()
{
	var now = (new Date()).getTime();
	var ACCESSTIME=(now-($.cookie("LASTACCESS")?eval($.cookie("LASTACCESS")):now))/1000;
	if(ACCESSTIME>600){
		$.cookie("LASTACCESS", null);
		$("#content").load("/cgi-bin/index.cgi?cgi=LOGOUT", Auto_Refresh);
	}
	else{
		$.cookie("LASTACCESS", now.toString());
		$("#content").load(urls, Auto_Refresh);
	}
}
function Auto_Refresh(){
		var do_refresh=0;
		var Refresh_List=new Array("STATUS", "AP_CLIENT", "LAN_STATUS", "WLAN_STATUS","WDS_CLIENT", "WDS_AP_CLIENT", "WDS_STAUTS", "STA_STATUS", "STA_AP_STATUS", "WAN_STATUS", "DHCP_STATUS");

		for(i in Refresh_List)
		{
			if(Refresh_List[i]==cgi)
			{
				do_refresh=1;
				break;
			}
		}
		auto_refresh_id=self.clearInterval(auto_refresh_id);
		if(do_refresh==1)
			auto_refresh_id=self.setInterval("loadpage()", 10000);
}

function load_lang()
{
	$("label, legend, h1, h2, h3, a, th, td, .lang, option").each(function(){
		if(lang[$(this).html()]!=undefined)
			$(this).html(lang[$(this).html()]);
	});
	$(":input[type=button],:input[type=submit]").each(function(){
		if(lang[$(this).attr("value")]!=undefined)
			$(this).attr("value", lang[$(this).attr("value")]);
	});
}

function closeinfo2(file, data)
{
	if(data.status=='success'){
		//$("#dialog").dialog('close');
		$("#dialog").dialog('option', 'title', 'Message');
		$("#dialog p").html("Success");
		$("#dialog").dialog('option', 'buttons', { Close: DialogClose});
		$("#dialog").dialog('option', 'closeOnEscape', true);
		$("#dialog").dialog('open');
		loadpage();
	}
	else
	{
		$("#dialog").dialog('option', 'title', 'Error Message');
		$("#dialog p").html(data.msg);
		$("#dialog").dialog('option', 'buttons', { Close: DialogClose});
		$("#dialog").dialog('option', 'closeOnEscape', true);
		$("#dialog").dialog('open');
	}
}

function closeinfo(data)
{
	if(data.status=='success'){
		//$("#dialog").dialog('close');
		$("#dialog").dialog('option', 'title', 'Message');
		$("#dialog p").html("Success");
		$("#dialog").dialog('option', 'buttons', { Close: DialogClose});
		$("#dialog").dialog('option', 'closeOnEscape', true);
		$("#dialog").dialog('open');
		loadpage();
	}
	else
	{
		$("#dialog").dialog('option', 'title', 'Error Message');
		$("#dialog p").html(data.msg);
		$("#dialog").dialog('option', 'buttons', { Close: DialogClose});
		$("#dialog").dialog('option', 'closeOnEscape', true);
		$("#dialog").dialog('open');
	}
}
function showinfo(title, msg)
{
	$("#dialog p").html(msg);
	$("#dialog").dialog('option', 'title', title);
	$("#dialog").dialog('option', 'buttons', {});
	$("#dialog").dialog('option', 'closeOnEscape', false);
	$("#dialog").dialog('open');
}

function alertinfo(title, msg)
{
	$("#dialog p").html(msg);
	$("#dialog").dialog('option', 'title', title);
	$("#dialog").dialog('option', 'buttons', { Close: DialogClose});
	$("#dialog").dialog('option', 'closeOnEscape', true);
	$("#dialog").dialog('open');
}
function AuthUser_func(mode, user, cgi){
	//load_lang();
}
