#!/bin/sh
<? /* vi: set sw=4 ts=4: */
if ($SERVDSTART=="1")
{
	echo "ifconfig ath0 up\n";
	echo "ifconfig ath1 up\n";
	echo "ifconfig ath2 up\n";
	echo "ifconfig ath3 up\n";
}
else
{
	echo "ifconfig ath0 down\n";
	echo "ifconfig ath1 down\n";
	echo "ifconfig ath2 down\n";
	echo "ifconfig ath3 down\n";
}
?>
