<?
	$wlanmac    = query("/runtime/macclone/addr");
    $wlmode     = query("/wlan/ch_mode");

    if ($wlmode==1) //a mode
    {
	    require("/etc/templates/__wlan_apcmode_a.php");
        exit;
    }
    else if ($wlmode==0) //g mode
    {
        require("/etc/templates/__wlan_apcmode_g.php");
        exit;
    }
?>
