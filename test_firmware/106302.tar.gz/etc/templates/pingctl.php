#!/bin/sh
<? /* vi: set sw=4 ts=4: */

$pingctl = "/var/run/__pingctl.sh";
$pingctlstatus = query("/sys/pingctl");

fwrite($pingctl, "echo pingctl.sh...\n");
	
if ($pingctlstatus==1)
{
    fwrite2($pingctl, "echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_all\n");

    /*fwrite2($pingctl, "brctl pingctl br0 enable\n");*/
}else{
    fwrite2($pingctl, "echo 0 > /proc/sys/net/ipv4/icmp_echo_ignore_all\n");
    /*fwrite2($pingctl, "brctl pingctl br0 disable\n");*/
}
?>
