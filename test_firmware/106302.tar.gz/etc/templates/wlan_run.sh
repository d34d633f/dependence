#!/bin/sh
echo [$0] $1 $2 ... > /dev/console
TROOT=`rgdb -i -g /runtime/template_root`

clonetype=`rgdb -g /wlan/inf:1/macclone/type`
[ "$TROOT" = "" ] && TROOT="/etc/templates"
case "$1" in
start|restart)
if [ "`rgdb -i -g /runtime/wireless/setting/status`" = "0" ]; then
     rgdb -i -s /runtime/wireless/setting/status 1
	sh /etc/templates/autorekey.sh start &> /dev/console # yuda add autorekey
	sleep 1
	if [ -n "$2" ]; then
		if [ "$2" = "a" ]; then
			echo "start WLAN (5G)...."     > /dev/console
		else
			echo "start WLAN (2.4G)...."     > /dev/console
		fi
		[ -f /var/run/multi_ssid_stop.sh ] && sh /var/run/multi_ssid_stop.sh > /dev/console  # jack add  multi_ssid 09/03/07 
		[ -f /var/run/wlan_$2_stop.sh ] && sh /var/run/wlan_$2_stop.sh > /dev/console
		rgdb -A $TROOT/wlan_run.php -V generate_start=0 -V band_type=$2 > /var/run/wlan_$2_stop.sh
		rgdb -A $TROOT/wlan_run.php -V generate_start=1 -V band_type=$2 > /var/run/wlan_$2_start.sh
	    rgdb -A $TROOT/multi_ssid_run.php -V generate_start=1 > /var/run/multi_ssid_start.sh  # jack add multi_ssid 09/03/07
	    rgdb -A $TROOT/multi_ssid_run.php -V generate_start=0 > /var/run/multi_ssid_stop.sh   # jack add multi_ssid 09/03/07
	    rgdb -A $TROOT/__vlan.php -V generate_start=1 > /var/run/vlan_start.sh  # jack add multi_ssid 09/03/07
	    rgdb -A $TROOT/__vlan.php -V generate_start=0 > /var/run/vlan_stop.sh   # jack add multi_ssid 09/03/07
	    rgdb -A $TROOT/__wlan_device_up.php -V generate_start=1  > /var/run/wlan_device_up.sh  # jack add multi_ssid 09/03/07
		sh /var/run/wlan_$2_start.sh > /dev/console
	    #sh /var/run/multi_ssid_start.sh > /dev/console                                        /* Jack add 13/11/08 init_MSSID_before_WDS multi-ssid should be init before WDS_VAP */
               sh /var/run/wlan_device_up.sh > /dev/console    	                                               
sh /var/run/vlan_start.sh > /dev/console    
	else
		if [ "`rgdb -g /wlan/ch_mode`" = "1" ]; then
		    [ -f /var/run/multi_ssid_stop.sh ] && sh /var/run/multi_ssid_stop.sh > /dev/console  # jack add  multi_ssid 09/03/07 
			[ -f /var/run/wlan_a_stop.sh ] && sh /var/run/wlan_a_stop.sh > /dev/console
			[ -f /var/run/wlan_g_stop.sh ] && sh /var/run/wlan_g_stop.sh > /dev/console
			echo "start WLAN (5G)....."     > /dev/console
			rgdb -A $TROOT/wlan_run.php -V generate_start=0 -V band_type=a > /var/run/wlan_a_stop.sh
			rgdb -A $TROOT/wlan_run.php -V generate_start=1 -V band_type=a > /var/run/wlan_a_start.sh
	        rgdb -A $TROOT/multi_ssid_run.php -V generate_start=1 > /var/run/multi_ssid_start.sh  # jack add multi_ssid 09/03/07
	        rgdb -A $TROOT/multi_ssid_run.php -V generate_start=0 > /var/run/multi_ssid_stop.sh   # jack add multi_ssid 09/03/07
	        rgdb -A $TROOT/__vlan.php -V generate_start=1 > /var/run/vlan_start.sh  # jack add multi_ssid 09/03/07
	        rgdb -A $TROOT/__vlan.php -V generate_start=0 > /var/run/vlan_stop.sh   # jack add multi_ssid 09/03/07
                rgdb -A $TROOT/__wlan_device_up.php -V generate_start=1 > /var/run/wlan_device_up.sh  # jack add multi_ssid 09/03/07
			sh /var/run/wlan_a_start.sh > /dev/console
	        #sh /var/run/multi_ssid_start.sh > /dev/console   /* Jack add 13/11/08 init_MSSID_before_WDS multi-ssid should be init before WDS_VAP */
	        sh /var/run/wlan_device_up.sh > /dev/console  
	        sh /var/run/vlan_start.sh > /dev/console                                               # jack add multi_ssid 09/03/07
		
		else
	        if [ -f /var/run/multi_ssid_stop.sh ]; then             # jack add multi_ssid 29/03/07 
	            sh /var/run/multi_ssid_stop.sh > /dev/console
	        fi
			[ -f /var/run/wlan_g_stop.sh ] && sh /var/run/wlan_g_stop.sh > /dev/console
			[ -f /var/run/wlan_a_stop.sh ] && sh /var/run/wlan_a_stop.sh > /dev/console
			echo "start WLAN (2.4G)....."     > /dev/console
			rgdb -A $TROOT/wlan_run.php -V generate_start=0 -V band_type=g > /var/run/wlan_g_stop.sh
			rgdb -A $TROOT/wlan_run.php -V generate_start=1 -V band_type=g > /var/run/wlan_g_start.sh
	        rgdb -A $TROOT/multi_ssid_run.php -V generate_start=1 > /var/run/multi_ssid_start.sh  # jack add multi_ssid 09/03/07
	        rgdb -A $TROOT/multi_ssid_run.php -V generate_start=0 > /var/run/multi_ssid_stop.sh   # jack add multi_ssid 09/03/07
	        rgdb -A $TROOT/__vlan.php -V generate_start=1 > /var/run/vlan_start.sh  # jack add multi_ssid 09/03/07
	        rgdb -A $TROOT/__vlan.php -V generate_start=0 > /var/run/vlan_stop.sh   # jack add multi_ssid 09/03/07
                rgdb -A $TROOT/__wlan_device_up.php -V generate_start=1 > /var/run/wlan_device_up.sh  # jack add multi_ssid 09/03/07
			sh /var/run/wlan_g_start.sh > /dev/console
	        #sh /var/run/multi_ssid_start.sh > /dev/console    /* Jack add 13/11/08 init_MSSID_before_WDS multi-ssid should be init before WDS_VAP */
	        sh /var/run/wlan_device_up.sh > /dev/console      
	        sh /var/run/vlan_start.sh > /dev/console 
		fi 	
	fi
	rgdb -i -s /rumtime/wlan/inf:1/autorekey/first 0
	rgdb -i -s /runtime/wireless/setting/status 0
	if [ "`rgdb -i -g /wlan/inf:1/ap_mode`" = "0" ]; then
                sh /etc/templates/lld2d.sh restart > /dev/console
        else
                sh /etc/templates/lld2d.sh stop  > /dev/console
        fi
	[ -f /var/run/qos_stop.sh ] && sh /var/run/qos_stop.sh > /dev/console
	xmldbc -A $TROOT/qos_run.php -V generate_start=1 > /var/run/qos_start.sh
	xmldbc -A $TROOT/qos_run.php -V generate_start=0 > /var/run/qos_stop.sh
	sh /var/run/qos_start.sh > /dev/console
	submit ARP_SPOOFING > /dev/null	 # eric fu , arp spoofing disable in apc mode.
	CheckFreeMEM & > /dev/console
	
        echo "sleep 30..."     > /dev/console
        sleep 30
        sh /var/run/wlan_servd_start.sh

fi		
	;;
stop)
if [ "`rgdb -i -g /runtime/wireless/setting/status`" = "0" ]; then
    rgdb -i -s /runtime/wireless/setting/status 1
	if [ -f /var/run/qos_stop.sh ]; then
		sh /var/run/qos_stop.sh > /dev/console
		rm -f /var/run/qos_stop.sh
	fi
	if [ -f /var/run/autorekey_stop.sh ]; then  # yuda add autorekey
		sh /var/run/autorekey_stop.sh > /dev/console  # yuda add autorekey
		rm -f /var/run/autorekey_stop.sh  # yuda add autorekey
		rm -f /var/run/autorekey_start.sh  # yuda add autorekey
	fi
	if [ -n "$2" ]; then
	    if [ -f /var/run/vlan_stop.sh ]; then             # jack add multi_ssid 29/03/07 
	        sh /var/run/vlan_stop.sh > /dev/console
	    fi
	    if [ -f /var/run/multi_ssid_stop.sh ]; then             # jack add multi_ssid 29/03/07 
	        sh /var/run/multi_ssid_stop.sh > /dev/console
		rm -f /var/run/multi_ssid_stop.sh
	    fi
		if [ -f /var/run/wlan_$2_stop.sh ]; then
		sh /var/run/wlan_$2_stop.sh > /dev/console
		rm -f /var/run/wlan_$2_stop.sh
		fi
	else
		if [ -f /var/run/vlan_stop.sh ]; then             # jack add multi_ssid 29/03/07 
	        sh /var/run/vlan_stop.sh > /dev/console
	    fi
	    if [ -f /var/run/multi_ssid_stop.sh ]; then             # jack add multi_ssid 29/03/07 
	        sh /var/run/multi_ssid_stop.sh > /dev/console
		rm -f /var/run/multi_ssid_stop.sh
	    fi
		if [ -f /var/run/wlan_a_stop.sh ]; then
			sh /var/run/wlan_a_stop.sh > /dev/console
			rm -f /var/run/wlan_a_stop.sh
		fi
		if [ -f /var/run/wlan_g_stop.sh ]; then
			sh /var/run/wlan_g_stop.sh > /dev/console
			rm -f /var/run/wlan_g_stop.sh
		fi
	fi
	rgdb -i -s /runtime/wireless/setting/status 0
fi	
	;;
*)
	echo "usage: wlan.sh {start|stop|restart}" > /dev/console
	echo "       if option "a" or "g" are not give," > /dev/console
	echo "       both wlan would be start|stop|restart." > /dev/console
	;;
esac
