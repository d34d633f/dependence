<?
/* vi: set sw=4 ts=4: */
//only focus on WPA-SPK mode
//none WDS none MULTI-SSID
//only ath0
fwrite("/dev/console", "Hello from hostapd.conf\n");
$HAPD_interface	= "ath0";
$HAPD_bridge	= "br0";
$HAPD_conf	= "/var/run/hostapd.".$HAPD_interface.".conf";
$HAPD_pid  = "/var/run/hostapd.".$HAPD_interface.".pid";
$authtype	= query("/wlan/inf:1/authentication");
$encrtype	= query("/wlan/inf:1/wpa/wepmode");
$Rport		= query("/wlan/inf:1/wpa/radiusport");
$Rhost		= query("/wlan/inf:1/wpa/radiusserver");
$Rsecret	= query("/wlan/inf:1/wpa/radiussecret");
$BackupRport	= query("/wlan/inf:1/wpa/b_radiusport");
$BackupRhost	= query("/wlan/inf:1/wpa/b_radiusserver");
$BackupRsecret	= query("/wlan/inf:1/wpa/b_radiussecret");
$ip_mode = query("/wan/rg/inf:1/mode");	/* 1:static, 2:dynamic */
$own_dynamic_ip_addr	= query("/runtime/wan/inf:1/ip");
$own_static_ip_addr	= query("/wan/rg/inf:1/static/ip");
if($ip_mode==2 && $own_dynamic_ip_addr!="") 
{
	$own_ip_addr	= $own_dynamic_ip_addr;
} else {
	$own_ip_addr	= $own_static_ip_addr;
}
$nas_identifier	= query("/runtime/layout/lanmac");
$VLAN_state = query("/sys/vlan_state");
$NAP_enable	= query("/sys/vlan_mode");
$Aenable	= query("/wlan/inf:1/wpa/acctstate");
$Aport		= query("/wlan/inf:1/wpa/acctport");
$Ahost		= query("/wlan/inf:1/wpa/acctserver");
$Asecret	= query("/wlan/inf:1/wpa/acctsecret");
$BackupAport	= query("/wlan/inf:1/wpa/b_acctport");
$BackupAhost	= query("/wlan/inf:1/wpa/b_acctserver");
$BackupAsecret	= query("/wlan/inf:1/wpa/b_acctsecret");

if(query("/wlan/inf:1/autorekey/ssid/enable")==1 && query("/runtime/wlan/inf:1/wpa/wpapsk")!="")//add for autoredey by yuda
{
	$wpapsk     = query("/runtime/wlan/inf:1/wpa/wpapsk");

}
else if(query("/wlan/inf:1/wpa/wpapsk")!="")
{
$wpapsk		= query("/wlan/inf:1/wpa/wpapsk");
}
else
{
	$wpapsk = 00000000;
}

$wpapskformat	= query("/wlan/inf:1/wpa/passphraseformat");
$rkeyint	= query("/wlan/inf:1/wpa/grp_rekey_interval");
$ssid		= query("/wlan/inf:1/ssid");
$DyWepKeyLen	= query("/wlan/inf:1/d_wepkeylen");
$DyWepRKeyInt	= query("/wlan/inf:1/d_wep_rekey_interval");

if	($authtype==0) { $HAPD_wpa=0; $HAPD_ieee8021x=0; }	/* Open					*/
else if	($authtype==1) { $HAPD_wpa=0; $HAPD_ieee8021x=0; }	/* Shared-Key			*/
else if	($authtype==2) { $HAPD_wpa=1; $HAPD_ieee8021x=1; }	/* WPA					*/
else if	($authtype==3) { $HAPD_wpa=1; $HAPD_ieee8021x=0; }	/* WPA-PSK				*/
else if	($authtype==4) { $HAPD_wpa=2; $HAPD_ieee8021x=1; }	/* WPA2					*/
else if	($authtype==5) { $HAPD_wpa=2; $HAPD_ieee8021x=0; }	/* WPA2-PSK				*/
else if	($authtype==6) { $HAPD_wpa=3; $HAPD_ieee8021x=1; }	/* WPA+WPA2				*/
else if	($authtype==7) { $HAPD_wpa=3; $HAPD_ieee8021x=0; }	/* WPA-PSK + WPA2-PSK	*/
else if ($authtype==9) { $HAPD_wpa=0; $HAPD_ieee8021x=1; }	/* 802.1x Only          */
// start config
// apr mode. ath0 is AP mode.
// this file is only used by apr.
/* Create config file for hostapd */
fwrite($HAPD_conf,  "driver=madwifi\n");
fwrite2($HAPD_conf, "eapol_key_index_workaround=0\n");
fwrite2($HAPD_conf, "logger_syslog=0\nlogger_syslog_level=0\nlogger_stdout=0\nlogger_stdout_level=0\ndebug=0\n");

fwrite2($HAPD_conf, "interface=ath0\n");
fwrite2($HAPD_conf, "bridge="	.$HAPD_bridge	."\n");
fwrite2($HAPD_conf, "ssid="	.$ssid		."\n");
fwrite2($HAPD_conf, "wpa="	.$HAPD_wpa	."\n");
fwrite2($HAPD_conf, "ieee8021x=0\n");

if ($HAPD_wpa > 0 && $HAPD_ieee8021x!=1)
{
	if ($rkeyint!="")	{ fwrite2($HAPD_conf, "wpa_group_rekey=".$rkeyint."\n");}
	if	($encrtype==2)	{ fwrite2($HAPD_conf, "wpa_pairwise=TKIP\n");		}
	else if	($encrtype==3)	{ fwrite2($HAPD_conf, "wpa_pairwise=CCMP\n");		}
	else if	($encrtype==4)	{ fwrite2($HAPD_conf, "wpa_pairwise=TKIP CCMP\n");	}

	fwrite2($HAPD_conf, "wpa_key_mgmt=WPA-PSK\n");
	if ($wpapskformat == 1)	{fwrite2($HAPD_conf, "wpa_passphrase=".$wpapsk."\n");}
	else			{fwrite2($HAPD_conf, "wpa_psk=".$wpapsk."\n");}
	echo "hostapd -B ".$HAPD_conf." &\n";
	echo "sleep 5\n";
}

?>
