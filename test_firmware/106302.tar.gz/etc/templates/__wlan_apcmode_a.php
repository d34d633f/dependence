<?
        $INSMOD = "insmod /lib/modules/";
        $wlanif = query("/runtime/layout/wlanif");
        $IWCONF="iwconfig ".$wlanif;

	      echo "rgdb -i -s /runtime/stats/wireless/led11a 0\n";
	      echo "rgdb -i -s /runtime/stats/wireless/led11g 0\n";

        $countrycode= query("/runtime/nvram/countrycode");
        $wepmode        = query("/wlan/inf:1/wpa/wepmode");
        $a_mode         = query("/wlan/inf:1/wlmode");
        $cwmmode        = query("/wlan/inf:1/cwmmode");
        $wmmenable      = query("/wlan/inf:1/wmm/enable");
        $auth_mode      = query("/wlan/inf:1/authentication");
        $acktimeout_a   = query("/wlan/inf:1/acktimeout_a");
        $router_enable = query("/runtime/router/enable");
        $wlxmlpatch_pid = "/var/run/wlxmlpatch.pid";
        $ethlink        = query("/wlan/inf:1/ethlink");
        $clonetype      = query("/wlan/inf:1/macclone/type");
	$txpower	= query("/wlan/inf:1/txpower");

        echo $INSMOD."ath_hal.ko\n";
        echo $INSMOD."wlan.ko\n";
        echo $INSMOD."ath_rate_atheros.ko\n";
        echo $INSMOD."ath_dfs.ko\n";
	echo $INSMOD."ath_dev.ko\n";
        echo $INSMOD."ath_ahb.ko\n";
        echo $INSMOD."wlan_xauth.ko\n";
        echo $INSMOD."wlan_ccmp.ko\n";
        echo $INSMOD."wlan_tkip.ko\n";
        echo $INSMOD."wlan_wep.ko\n";
        echo $INSMOD."wlan_acl.ko\n";
        echo $INSMOD."ath_pktlog.ko\n";

        if ($countrycode!=""){
            echo "iwpriv wifi0 setCountryID ".$countrycode."\n";
        }else{
            echo "iwpriv wifi0 setCountryID 840\n";
        }
        
        if ($clonetype==0){//clone disabled
        	if($router_enable !=1)//papa add 2009/02/11
        	{
            	$wlanmac= query("/runtime/layout/wlanmac");
            }
            else
            {
            	$wlanmac= query("/runtime/layout/wanmac");
            }        	
            echo "brctl clonetype br0 0\n";
        }else if ($clonetype==1){//auto clone
            $wlanmac= query("/runtime/macclone/addr");
            echo "rgdb -i -s /runtime/layout/wanmac ".$wlanmac."\n";
            echo "brctl setcloneaddr br0 ".$wlanmac."\n";
            echo "brctl clonetype br0 1\n";
        }else if ($clonetype==2){//manual clone
            $wlanmac= query("/wlan/inf:1/macclone/addr");
            echo "rgdb -i -s /runtime/layout/wanmac ".$wlanmac."\n";
            echo "brctl setcloneaddr br0 ".$wlanmac."\n";
            echo "brctl clonetype br0 2\n";
        }
        
        echo "ifconfig wifi0 hw ether ".$wlanmac."\n";
        echo "wlanconfig ath create wlandev wifi0 wlanmode sta nosbeacon\n";
        echo "ifconfig ".$wlanif." hw ether ".$wlanmac."\n";
        echo "iwpriv wifi0 acktimeout ".$acktimeout_a."\n";
        echo "iwpriv ath0 bgscan 0\n";
        echo "iwpriv wifi0 HALDbg 0\n";
        echo "iwpriv ath0 dbgLVL 0x100\n";
        echo "ifconfig ath0 txqueuelen 1000\n";
	echo "ifconfig ath0 allmulti\n";
        echo "ifconfig wifi0 txqueuelen 1000\n";
        if ($cwmmode==1){
        	echo "iwpriv ath0 cwmmode 1\n";
        	echo "iwpriv ath0 mode 11NAHT40\n";
        }else{
        	echo "iwpriv ath0 cwmmode 0\n";               
                echo "iwpriv ath0 mode 11NAHT20\n";
       }    

        echo "iwpriv wifi0 AMPDU 1\n";
        echo "iwpriv wifi0 AMPDUFrames 32\n";
        echo "iwpriv wifi0 AMPDULim 50000\n";
        echo "iwpriv wifi0 ANIEna 0\n";

        if ($wmmenable>0)       { echo "iwpriv ath0 wmm 1\n"; }
        else                    { echo "iwpriv ath0 wmm 0\n"; }
        echo "echo 1 > /proc/sys/dev/ath/htdupieenable\n";
        echo "iwconfig ".$wlanif." essid \"".get("s","/wlan/inf:1/ssid")."\" mode managed freq 36\n";
        echo "iwpriv wifi0 txchainmask 7\n";
        echo "iwpriv wifi0 rxchainmask 7\n";   
        if ($auth_mode>1){          
                require("/etc/templates/__auth_supplicant.php");
                echo $INSMOD."wlan_scan_sta.ko\n";
                echo "iwpriv ".$wlanif." apband 1\n"; //show ap band in wireless driver
                echo "wlxmlpatch -L ".$wlanif." /runtime/stats/wlan/inf:1 RADIO_SSID1_ON RADIO_SSID1_BLINK MADWIFI > /dev/console &\n";
                echo "echo $! > ".$wlxmlpatch_pid."\n";
                echo "ifconfig ath0 up\n";
                echo "brctl apmode br0 1\n";
                echo "brctl addif br0 ath0\n";
            } else { 
                echo $INSMOD."wlan_scan_sta.ko\n";
                echo "ifconfig ath0 up\n";
                echo "brctl addif br0 ath0\n";
                 require("/etc/templates/__auth_openshared_a.php");
                echo "iwpriv ".$wlanif." apband 1\n"; //show ap band in wireless driver
                echo "wlxmlpatch -L ".$wlanif." /runtime/stats/wlan/inf:1 RADIO_SSID1_ON RADIO_SSID1_BLINK MADWIFI > /dev/console &\n";
                echo "echo $! > ".$wlxmlpatch_pid."\n";
                echo "brctl apmode br0 1\n";
 
        }
        if($txpower == 2){
                echo "iwpriv wifi0 tpscale 1\n";
        }
        else if($txpower == 3){
                echo "iwpriv wifi0 tpscale 2\n";
        }
        else if($txpower == 4){
                echo "iwpriv wifi0 tpscale 3\n";
        }
        else {
                echo "iwpriv wifi0 tpscale 0\n";
        }
        /* ethernet integration dennis2008-02-05 start */
        if ($ethlink==1){
            echo "brctl ethlink br0 ".$ethlink."\n";
        }else{
            echo "brctl ethlink br0 0\n";
        }
        /* ethernet integration dennis2008-02-05 end */
        echo "gpioc -o 19 \n";
        echo "gpioc -w 19 \n";
        echo "gpioc -e 19 \n";
       	echo "rgdb -i -s /runtime/stats/wireless/led11a 1\n";
        if ($clonetype != 0){
            	echo "ifconfig eth0 down\n";
	        echo "brctl delif br0 eth0\n";
	        echo "brctl addif br0 eth0\n";
	        echo "ifconfig eth0 up\n";
		$wlanmac = query("/runtime/layout/wlanmac");
		echo "ifconfig br0 hw ether ".$wlanmac."\n";
        }

  	
        exit;
?>
