#!/bin/sh
echo [$0] ... > /dev/console
<?
$WLAN_g="/wlan/inf:1";  // b, g, n band
$WLAN_a=$WLAN_g;  // a band
$band	= query($WLAN_g."/ch_mode");  // "1" #1--->a   0---> b,g,n
$countrycode= query("/runtime/nvram/countrycode");

require("/etc/templates/troot.php");
if ( $band_type == "a" ) //a mode
{
        if ($countrycode==376){
                 //disable 5g band for IL
                echo "echo IL do not support 5G outdoor channels, force to 2.4G band! > /dev/console\n";
    		require($template_root."/wlan_run_g.php");
        }
	else{
		require($template_root."/wlan_run_a.php");
	}
    exit;
}
else  //g mode
{
    require($template_root."/wlan_run_g.php");
    exit;
}
?>
