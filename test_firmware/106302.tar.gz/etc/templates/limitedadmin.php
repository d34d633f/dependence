#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */
$WLAN_g="/wlan/inf:1";
$WLAN = $WLAN_g;
$wlan_ap_operate_mode = query($WLAN."/ap_mode");

$limitedadmin = "/var/run/__limitedadmin.sh";
$limitedadmintype = query("/sys/adminlimit/status");
$limitedadminvid  = query("/sys/adminlimit/vlanid");
$sys = "/sys";          // jack add, vlan_admin_conflict +++
$vlan_state = query($sys."/vlan_state"); 
fwrite($limitedadmin, "echo limitedadmin.sh...\n");
	
if ($limitedadmintype>=0 && $limitedadmintype<=3) //yuda modify 2->3, and 3 is both VID and IP address
{

    fwrite2($limitedadmin, "brctl ladtype br0 ".$limitedadmintype." > /dev/console\n");
	//echo "brctl ladtype br0 ".$limitedadmintype." > /dev/console\n";
}

if ($limitedadminvid>=0 && $limitedadminvid<4096)
{
	fwrite2($limitedadmin, "brctl ladvid br0 ".$limitedadminvid." > /dev/console\n");
	//echo "brctl ladvid br0 ".$limitedadminvid." > /dev/console\n";
}

for("/sys/adminlimit/ipentry/index")
{
	$ippoolstart = query("/sys/adminlimit/ipentry/index:".$@."/ippoolstart".);
	$ippoolend   = query("/sys/adminlimit/ipentry/index:".$@."/ippoolend".);
	if($ippoolstart!="" && $ippoolend!="")
	{
	    fwrite2($limitedadmin, "brctl ladippool br0 ".$@." ".$ippoolstart." ".$ippoolend." > /dev/console\n");
	}else{
	    fwrite2($limitedadmin, "brctl ladippool br0 ".$@." 0.0.0.0 0.0.0.0"." > /dev/console\n");
	}
}
/*if limited vid enabled, must change eth0's mtu to 1504.
because eth0 will receive packets with vlan id.(1500+4)*/
if ($limitedadmintype==1 || $limitedadmintype==3)
{
        fwrite2($limitedadmin, "echo set eth0\\'s MTU to 1504... > /dev/console\n");
        fwrite2($limitedadmin, "ifconfig eth0 mtu 1504 > /dev/console\n");
}
else
{
        if ($vlan_state==0)
        {
		if ($wlan_ap_operate_mode==3 || $wlan_ap_operate_mode==4)
                {
                /*if vlan is disabled and limited vlan is disabled set MTU to 1500*/
                fwrite2($limitedadmin, "echo set eth0\\'s MTU to 1504... > /dev/console\n");
                fwrite2($limitedadmin, "ifconfig eth0 mtu 1504 > /dev/console\n");
                }
                else
                {
                /*if vlan is disabled and limited vlan is disabled set MTU to 1500*/
                fwrite2($limitedadmin, "echo set eth0\\'s MTU to 1500... > /dev/console\n");
                fwrite2($limitedadmin, "ifconfig eth0 mtu 1500 > /dev/console\n");
                }
        }
}
?>
# limitedadmin.php <<<

