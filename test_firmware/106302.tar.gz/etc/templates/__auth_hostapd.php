<?
/* vi: set sw=4 ts=4: */
fwrite("/dev/console", "Hello from hostapd.conf\n");
$HAPD_interface	= $wlanif;
$HAPD_bridge	= "br0";
$HAPD_conf	= "/var/run/hostapd.".$HAPD_interface.".conf";
$HAPD_pid  = "/var/run/hostapd.".$HAPD_interface.".pid";
$authtype	= query("/wlan/inf:1/authentication");
$encrtype	= query("/wlan/inf:1/wpa/wepmode");
$Rport		= query("/wlan/inf:1/wpa/radiusport");
$Rhost		= query("/wlan/inf:1/wpa/radiusserver");
$Rsecret	= query("/wlan/inf:1/wpa/radiussecret");
$BackupRport	= query("/wlan/inf:1/wpa/b_radiusport");
$BackupRhost	= query("/wlan/inf:1/wpa/b_radiusserver");
$BackupRsecret	= query("/wlan/inf:1/wpa/b_radiussecret");
$ip_mode = query("/wan/rg/inf:1/mode");	/* 1:static, 2:dynamic */
$own_dynamic_ip_addr	= query("/runtime/wan/inf:1/ip");
$own_static_ip_addr	= query("/wan/rg/inf:1/static/ip");
if($ip_mode==2 && $own_dynamic_ip_addr!="") 
{
	$own_ip_addr	= $own_dynamic_ip_addr;
} else {
	$own_ip_addr	= $own_static_ip_addr;
}
$nas_identifier	= query("/runtime/layout/lanmac");
$VLAN_state = query("/sys/vlan_state");
$NAP_enable	= query("/sys/vlan_mode");
$Aenable	= query("/wlan/inf:1/wpa/acctstate");
$Aport		= query("/wlan/inf:1/wpa/acctport");
$Ahost		= query("/wlan/inf:1/wpa/acctserver");
$Asecret	= query("/wlan/inf:1/wpa/acctsecret");
$BackupAport	= query("/wlan/inf:1/wpa/b_acctport");
$BackupAhost	= query("/wlan/inf:1/wpa/b_acctserver");
$BackupAsecret	= query("/wlan/inf:1/wpa/b_acctsecret");

if(query("/wlan/inf:1/autorekey/ssid/enable")==1 && query("/runtime/wlan/inf:1/wpa/wpapsk")!="")//add for autoredey by yuda
{
	$wpapsk     = query("/runtime/wlan/inf:1/wpa/wpapsk");

}
else if(query("/wlan/inf:1/wpa/wpapsk")!="")
{
$wpapsk		= query("/wlan/inf:1/wpa/wpapsk");
}
else
{
	$wpapsk = 00000000;
}

$wpapskformat	= query("/wlan/inf:1/wpa/passphraseformat");
$rkeyint	= query("/wlan/inf:1/wpa/grp_rekey_interval");
$ssid		= query("/wlan/inf:1/ssid");
$DyWepKeyLen	= query("/wlan/inf:1/d_wepkeylen");
$DyWepRKeyInt	= query("/wlan/inf:1/d_wep_rekey_interval");

if	($authtype==0) { $HAPD_wpa=0; $HAPD_ieee8021x=0; }	/* Open					*/
else if	($authtype==1) { $HAPD_wpa=0; $HAPD_ieee8021x=0; }	/* Shared-Key			*/
else if	($authtype==2) { $HAPD_wpa=1; $HAPD_ieee8021x=1; }	/* WPA					*/
else if	($authtype==3) { $HAPD_wpa=1; $HAPD_ieee8021x=0; }	/* WPA-PSK				*/
else if	($authtype==4) { $HAPD_wpa=2; $HAPD_ieee8021x=1; }	/* WPA2					*/
else if	($authtype==5) { $HAPD_wpa=2; $HAPD_ieee8021x=0; }	/* WPA2-PSK				*/
else if	($authtype==6) { $HAPD_wpa=3; $HAPD_ieee8021x=1; }	/* WPA+WPA2				*/
else if	($authtype==7) { $HAPD_wpa=3; $HAPD_ieee8021x=0; }	/* WPA-PSK + WPA2-PSK	*/
else if ($authtype==9) { $HAPD_wpa=0; $HAPD_ieee8021x=1; }	/* 802.1x Only          */

/* Create config file for hostapd */
fwrite($HAPD_conf,  "driver=madwifi\n");
fwrite2($HAPD_conf, "eapol_key_index_workaround=0\n");
fwrite2($HAPD_conf, "logger_syslog=0\nlogger_syslog_level=0\nlogger_stdout=0\nlogger_stdout_level=0\ndebug=0\n");

fwrite2($HAPD_conf, "interface=".$HAPD_interface."\n");
fwrite2($HAPD_conf, "bridge="	.$HAPD_bridge	."\n");
fwrite2($HAPD_conf, "ssid="	.$ssid		."\n");
fwrite2($HAPD_conf, "wpa="	.$HAPD_wpa	."\n");
fwrite2($HAPD_conf, "ieee8021x=".$HAPD_ieee8021x."\n");

if ($HAPD_wpa > 0)
{
	if ($rkeyint!="")	{ fwrite2($HAPD_conf, "wpa_group_rekey=".$rkeyint."\n");}
	if	($encrtype==2)	{ fwrite2($HAPD_conf, "wpa_pairwise=TKIP\n");		}
	else if	($encrtype==3)	{ fwrite2($HAPD_conf, "wpa_pairwise=CCMP\n");		}
	else if	($encrtype==4)	{ fwrite2($HAPD_conf, "wpa_pairwise=TKIP CCMP\n");	}

	if ($HAPD_ieee8021x == 1)
	{
		fwrite2($HAPD_conf, "wpa_key_mgmt=WPA-EAP\n");
	}
	else
	{
		fwrite2($HAPD_conf, "wpa_key_mgmt=WPA-PSK\n");
		if ($wpapskformat == 1)	{fwrite2($HAPD_conf, "wpa_passphrase=".$wpapsk."\n");}
		else			{fwrite2($HAPD_conf, "wpa_psk=".$wpapsk."\n");}
	}
}

if ($HAPD_ieee8021x == 1)
{

		/* Radius Server Seetings */
		fwrite2($HAPD_conf, "auth_server_addr=".$Rhost."\n");
		fwrite2($HAPD_conf, "auth_server_port=".$Rport."\n");
		fwrite2($HAPD_conf, "auth_server_shared_secret=".$Rsecret."\n");
		
		if($BackupRhost != "" && $BackupRport != "" && $BackupRsecret != "")
		{
			fwrite2($HAPD_conf, "auth_server_addr=".$BackupRhost."\n");
			fwrite2($HAPD_conf, "auth_server_port=".$BackupRport."\n");
			fwrite2($HAPD_conf, "auth_server_shared_secret=".$BackupRsecret."\n");
		}
		fwrite2($HAPD_conf, "own_ip_addr=".$own_ip_addr."\n");
		fwrite2($HAPD_conf, "nas_identifier=".$nas_identifier."\n");

		/* Disable EAP reauthentication */
		/*fwrite2($HAPD_conf, "eap_reauth_period=0\n");*/

		/* Radius Retry Primary Interval */
		fwrite2($HAPD_conf, "radius_retry_primary_interval=600\n");

	/* Accounting Server Settings */
	if ($Aenable == 1)
	{
		fwrite2($HAPD_conf, "acct_server_addr=".$Ahost."\n");
		fwrite2($HAPD_conf, "acct_server_port=".$Aport."\n");
		fwrite2($HAPD_conf, "acct_server_shared_secret=".$Asecret."\n");
		if($BackupAhost != "" && $BackupAport != "" && $BackupAsecret != "")
		{
			fwrite2($HAPD_conf, "acct_server_addr=".$BackupAhost."\n");
			fwrite2($HAPD_conf, "acct_server_port=".$BackupAport."\n");
			fwrite2($HAPD_conf, "acct_server_shared_secret=".$BackupAsecret."\n");
		}
	}

	/* 802.1x support for dynamic WEP keying */
	if ($HAPD_wpa == 0)
	{
		/* Key lengths , 5 = 64-bit , 13 = 128-bit (default: 128-bit) */
		if ($DyWepKeyLen == 64)
		{
			fwrite2($HAPD_conf, "wep_key_len_unicast=5\n");
			fwrite2($HAPD_conf, "wep_key_len_broadcast=5\n");
		}
		else/* DyWepKeyLen == 128 */
		{
			fwrite2($HAPD_conf, "wep_key_len_unicast=13\n");
			fwrite2($HAPD_conf, "wep_key_len_broadcast=13\n");
		}

		/* Rekeying period in seconds (default:300 secs) */
		if ($DyWepRKeyInt != "")	{	fwrite2($HAPD_conf, "wep_rekey_period=".$DyWepRKeyInt."\n");	}
	}

	/* Disable EAP reauthentication */
	fwrite2($HAPD_conf, "eap_reauth_period=0\n");

	/* NAP Support */
	if ($VLAN_state == 1 && $NAP_enable!="")	{ fwrite2($HAPD_conf, "nap_enable=".$NAP_enable."\n");}	

	/* Enable PreAuthentication */
	fwrite2($HAPD_conf, "rsn_preauth=0\n");
	fwrite2($HAPD_conf, "rsn_preauth_interfaces=br0\n");

}

echo "hostapd -B ".$HAPD_conf." &\n";
/*echo "echo $! > ".$HAPD_pid."\n";*/

?>
