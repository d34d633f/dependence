<?
$m_html_title="WRONG FIRMWARE IMAGE";
$m_context_title="Wrong Firmware Image";
$m_context="The chosen file is not an image file.";
$m_button_dsc=$m_continue;
?>
