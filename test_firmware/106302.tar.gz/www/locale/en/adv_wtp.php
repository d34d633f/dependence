<?
$m_context_title = "WLAN Switch Settings";
$m_wtp_title = "Wireless Termination Point Settings";
$m_connect_title = "Connecting Info";
$m_wtp_enable = "WTP Enable";
$m_wtp_name = "WTP Name";
$m_wtp_location = "WTP Location Data";
$m_ac_ip = "WLAN Switch IP";
$m_ac_name = "WLAN Switch Name";
$m_ac_ipaddr = "WLAN Switch IP Address";
$m_ac_ip_list_title = "WLAN Switch Address List";
$m_id = "ID";
$m_ip = "IP Address";
$m_del = "Delete";

$a_wtp_del_confirm		= "Are you sure that you want to delete this IP Address?";
$a_same_wtp_ip	= "There is an existent entry with the same IP Address.\\n Please change the IP Address.";
$a_invalid_ip		= "Invalid IP Address !";
$a_max_ip_table		= "Maximum number of WLAN Switch Address List is 8!";
?>