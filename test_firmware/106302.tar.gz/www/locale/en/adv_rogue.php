<?
$m_context_title = "Wireless Intrusion Protection";
$m_b_detect = "Detect";
$m_ap_list_title = "AP List";
$m_type = "Type";
$m_band = "Band";
$m_channel = "CH";
$m_ssid = "SSID";
$m_mac = "BSSID";
$m_last_seem = "Last Seen";
$m_status = "Status";
$m_b_valid = "Set as Valid";
$m_b_neighborhood = "Set as Neighborhood";
$m_b_rogue = "Set as Rogue";
$m_b_new = "Set as New";
$m_all_valid = "Mark All New Access Points as Valid Access Points";
$m_all_rogue = "Mark All New Access Points as Rogue Access Points";
$m_valid = "Valid";
$m_neighborhood = "Neighbor";
$m_rogue = "Rogue";
$m_new = "New";
$m_a = "A";
$m_b = "B";
$m_g = "G";
$m_n = "N";
$m_days = "Days";
$m_all = "All";
$m_up = "Up";
$m_down = "Down";
$m_wireless_band = "Wireless Band";
$m_band_2_4G = "2.4GHz";
$m_band_5G = "5GHz";

$a_max_list = "Maximum number of this type list is 64! \\n";
$a_can_add_num = "You can add ";
$a_entry = " entry";
$a_no_click = "No entry click!";
?>