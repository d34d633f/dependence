<?
$m_context_title = "Administration Settings";
$m_limit_title = "Limit Administrator";
$m_sysname_title= "System Name Settings";
$m_login_title = "Login Settings";
$m_console_title = "Console Settings";
$m_snmp_title = "SNMP Settings";
$m_ping_title = "Ping Control Setting";
$m_login_name		="Login Name";
$m_old_password		="Old Password";
$m_new_password		="New Password";
$m_confirm_password	="Confirm Password";
$m_status = "Status";
$m_enable = "Enable";
$m_console_protocol = "Console Protocol";
$m_telnet = "Telnet";
$m_ssh = "SSH";
$m_timeout = "Timeout";
$m_1min = "1 Min";
$m_3mins = "3 Mins";
$m_5mins = "5 Mins";
$m_10mins = "10 Mins";
$m_15mins = "15 Mins";
$m_never = "Never";
$m_snmp_public	="Public Community String";
$m_snmp_private	="Private Community String";
$m_trap = "Trap";
$m_trap_server_ip	="Trap Server IP";
$m_trap_type = "Trap Type";
$m_admin_ap_with_lan = "Administrate AP with WLAN ";
$m_limit_admin_vid = "Limit Administrator VLAN ID";
$m_limit_admin_ip = "Limit Administrator IP";
$m_ip_range = "IP Range";
$m_b_add = "Add";
$m_id = "Item";
$m_from = "From";
$m_to = "To";
$m_del = "Delete";
$m_sysname="System Name";
$m_location="Location";

$url_redir=query("/runtime/web/display/url_redir");
if($url_redir==1)
{
$a_enable_limit_admin_status="If Limit Administrator Status enable , VLAN Status, Web redirection and Network Access Protection Status will be disable !";
}
else
{
	$a_enable_limit_admin_status="If Limit Administrator Status enable , VLAN Status and Network Access Protection Status will be disable !";	
}
$a_empty_ip_list = "Please add Limit Admin IP Range!";
$a_disable_limit_ip = "Limit Admin IP will be disabled if the Limit Admin IP rule list is null!";
$a_empty_login_name	="Please input the Login Name.";
$a_invalid_login_name	="The Login Name is with invalid character. Please check it.";
$a_invalid_password = "The Password is not match! \\nPlease Enter Again.";
$a_invalid_new_password	="The New Password is with invalid character. Please check it.";
$a_password_not_matched	="The New Password and Confirm Password are not matched.";
$a_empty_snmp_public ="Please input public Community string.";
$a_empty_snmp_private="Please input private Community string.";
$a_invalid_trap_server_ip ="Invalid IP Address!";
$a_invalid_ip ="Invalid IP Address!";
$a_invalid_admin_vid		="The Limit Administrator VID value range is 1 ~ 4094.";
$a_invalid_ip_range = "The IP range is not right! \\n Please check.";
$a_max_ip_table		= "Maximum number of IP Range List is 4!";
$a_empty_sysname	= "The System Name field can not be blank.";
$a_invalid_sysname	= "There are some invalid characters in the System Name field. Please check it.";
$a_first_blank_sysname	= "The first character of System Name can't be blank.";
$a_empty_location	= "The Location field can not be blank.";
$a_invalid_location	= "There are some invalid characters in the Location field. Please check it.";
$a_first_blank_location	= "The first character of Location can't be blank.";
$a_invalid_user_name	= "There are some invalid characters in the user name field. Please check it.";
$a_first_blank_user_name	= "The first character of Login Name can't be blank.";
$a_first_blank_public	= "The first character of Public Community String can't be blank.";
$a_first_blank_private	= "The first character of Private Community String can't be blank.";
?>
