<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME      = "adv_perf";
$MY_MSG_FILE  = $MY_NAME.".php";
$MY_ACTION    = $MY_NAME;
$NEXT_PAGE    = "adv_perf";
set("/runtime/web/help_page",$MY_NAME);
/* --------------------------------------------------------------------------- */
if($ACTION_POST != "")
{
	require("/www/model/__admin_check.php");
	require("/www/__action_adv.php");
	$ACTION_POST = "";
	exit;
}

/* --------------------------------------------------------------------------- */
require("/www/model/__html_head.php");
set("/runtime/web/next_page",$first_frame);
/* --------------------------------------------------------------------------- */
// get the variable value from rgdb.
echo "<!--debug\n";
$cfg_band = query("/wlan/ch_mode");
if($cfg_band == 0) // 11g
{
	echo "anchor 11g";
	anchor("/wlan/inf:1");
	$cfg_ack_time=query("acktimeout_g");
}
else
{
	echo "anchor 11a";
	//anchor("/wlan/inf:2");
	anchor("/wlan/inf:1");
	$cfg_ack_time=query("acktimeout_a");
}

$cfg_wl_enable = query("enable");
$cfg_wlmode = query("wlmode");
$cfg_rate = query("fixedrate");
$cfg_beacon = query("beaconinterval");
$cfg_dtim = query("dtim");
$cfg_frag = query("fraglength");
$cfg_rts = query("rtslength");
$cfg_power = query("txpower");
$cfg_wmm = query("wmm/enable");
$cfg_shortgi = query("shortgi");
$cfg_limit_state = query("assoc_limit/enable");
$cfg_limit_num = query("assoc_limit/number");
$cfg_utilization = query("wlan_bytes_lim");
$cfg_igmp = query("igmpsnoop");
$cfg_link_integrality =query("ethlink");
$cfg_ap_mode	=query("ap_mode");
$display_ack_time=query("/runtime/web/display/ack_timeout_range");
$cfg_mode = query("ap_mode");
$cfg_channel = query("channel");
if($cfg_channel == 12 || $cfg_channel == 13 || $cfg_channel == 165)
{
	$special_channel = 1;
}
$cfg_channel_width = query("cwmmode");
$cfg_display_mcast = query("/runtime/web/display/mcast");
$cfg_display_igmp = query("/runtime/web/display/igmp");
$cfg_mcast_a = query("mcastrate_a");
$cfg_ht2040=query("coexistence/enable");
$cfg_mcast_g = query("mcastrate_g");
$cfg_auth=query("authentication");
$cfg_cipher=query("wpa/wepmode");
$flag_mcast_max="";
$cfg_wep = "";


if($cfg_cipher==1 || $cfg_cipher==2 || $cfg_auth==9)
{
	$flag_mcast_max="54";
	$cfg_wep = 1;
}
else
{
	$flag_mcast_max="130";
}


echo "-->";
/* --------------------------------------------------------------------------- */
?>

<?
echo $G_TAG_SCRIPT_START."\n";
require("/www/model/__wlan.php");
?>
var w_wlmode = "";
var w_rate = "";
var g_mrate;
var a_mrate;

function on_change_wl_enable(s)
{
	//alert(s.value);
}

function on_change_wlmode(s)
{
	//alert(s.value);
	var f = get_obj("frm");
	if("<?=$cfg_display_mcast?>" == "1")
	{
		get_obj("mcast_a").style.display = "none";
		get_obj("mcast_g").style.display = "none";	
		get_obj("mcast_a_n").style.display = "none";
		get_obj("mcast_g_n").style.display = "none";	
		get_obj("mcast_n_fora").style.display = "none";
		get_obj("mcast_n_forg").style.display = "none";
	}
	w_rate.disabled = false;

	if(s.value != 2 && s.value != 7) // NOT Mixed g_b, a only
	{
		f.shortgi.disabled=false;
		if("<?=$cfg_wep?>" == "1")
		{
			f.shortgi.disabled=true;
		}
		select_index(w_rate, "31");
		w_rate.options[0].text = "<?=$m_best?>";
		w_rate.disabled = true;
		if("<?=$cfg_display_mcast?>" == "1")
		{
			if(s.value == 4 ||s.value == 9)
			{
				a_mrate=get_obj("mcast_n_fora");
				get_obj("mcast_n_fora").style.display = "";
				g_mrate=get_obj("mcast_n_forg");
				get_obj("mcast_n_forg").style.display = "";
			}
			else
			{
				if("<?=$flag_mcast_max?>"==54)
				{
					a_mrate=get_obj("mcast_a");
					get_obj("mcast_a").style.display = "";
					g_mrate=get_obj("mcast_g");
					get_obj("mcast_g").style.display = "";			
				}
				else
				{
					a_mrate=get_obj("mcast_a_n");
					get_obj("mcast_a_n").style.display = "";
					g_mrate=get_obj("mcast_g_n");
					get_obj("mcast_g_n").style.display = "";		
				}
			}
		}
	}
	else
	{
		f.shortgi.disabled=true;
		select_index(f.shortgi, "0");
		w_rate.options[0].text = "<?=$m_best_54?>";
		if("<?=$cfg_display_mcast?>" == "1")
		{
			a_mrate=get_obj("mcast_a");
			get_obj("mcast_a").style.display = "";
			g_mrate=get_obj("mcast_g");
			get_obj("mcast_g").style.display = "";	
		}
	}
}

function on_change_power(s)
{
	//alert(s.value);
}

function on_change_wmm(s)
{
	//alert(s.value);
}

function on_change_shortgi(s)
{
	//alert(s.value);
}

function on_change_user_limit(s)
{
	//alert(s.value);
	var f = get_obj("frm");
	f.limit_num.disabled = false;
	if(f.utilization != null)
	{
		f.utilization.disabled =false;
	}
	if(s.value == 0)
	{
		f.limit_num.disabled = true;
		if(f.utilization != null)
		{
			f.utilization.disabled =true;
		}
	}
}

function on_change_utilization(s)
{
	//alert(s.value);
}

function on_change_mcast()
{
	var f = get_obj("frm");
	if(a_mrate.value !=0 && "<?=$cfg_band?>"!=0 && "<?=$cfg_display_igmp?>" == "1")
	{
		f.igmp.value=0;
	}
	if(g_mrate.value !=0 && "<?=$cfg_band?>"==0 && "<?=$cfg_display_igmp?>" == "1")
	{
		f.igmp.value=0;
	}
	//alert(s.value);
}
function on_change_igmp(s)
{
	var f = get_obj("frm");
	if(f.igmp.value==1 && "<?=$cfg_display_mcast?>" == "1")
	{
		a_mrate.value=0;
		g_mrate.value=0;
	}
	//alert(s.value);
}
/* page init functoin */
function init()
{
	var f = get_obj("frm");
	get_obj("wlmode_a").style.display = "none";
	get_obj("wlmode_g").style.display = "none";
	get_obj("rate_a").style.display = "none";
	get_obj("rate_g").style.display = "none";
	if("<?=$cfg_display_mcast?>" == "1")
	{
		get_obj("mcast_a_setting").style.display = "none";
		get_obj("mcast_g_setting").style.display = "none";
	}

	select_index(f.wl_enable, "<?=$cfg_wl_enable?>");
	
	if("<?=$cfg_band?>" == 0) // 11g
	{
		get_obj("wlmode_g").style.display = "";
		get_obj("rate_g").style.display = "";
		if("<?=$cfg_display_mcast?>" == "1")
		{
			get_obj("mcast_g_setting").style.display = "";
		}
		w_wlmode = get_obj("wlmode_g");
		w_rate = get_obj("rate_g");
		get_obj("ack_timeout_msg").innerHTML = "<?=$m_ack_timeout_g_msg?>";
	}	
	else
	{
		get_obj("wlmode_a").style.display = "";
		get_obj("rate_a").style.display = "";
		if("<?=$cfg_display_mcast?>" == "1")
		{
			get_obj("mcast_a_setting").style.display = "";
		}
		w_wlmode = get_obj("wlmode_a");
		w_rate = get_obj("rate_a");
		get_obj("ack_timeout_msg").innerHTML = "<?=$m_ack_timeout_a_msg?>";
	}	
	 if("<?=$cfg_channel_width?>"==0 || "<?=$cfg_ap_mode?>"==4 || "<?=$cfg_ap_mode?>"==1 || "<?=$cfg_band?>"==1)
        {
                f.ht_status.disabled=true;
        }
        else
        {
                f.ht_status.disabled=false;
        }
	select_index(w_wlmode, "<?=$cfg_wlmode?>");
	select_index(w_rate, "<?=$cfg_rate?>");

if("<?=$cfg_ap_mode?>" =="1") //apc
        w_wlmode.disabled = true;

    on_change_wlmode(w_wlmode);
	if("<?=$cfg_display_mcast?>" == "1")
	{
		if(("<?=$cfg_wlmode?>" == 2 || "<?=$cfg_wlmode?>" == 4) && "<?=$cfg_mcast_g?>">12)
		{
			g_mrate.value = 0;
		}
		else
		{
			g_mrate.value = "<?=$cfg_mcast_g?>";
		}
		if(("<?=$cfg_wlmode?>" == 7 && "<?=$cfg_mcast_a?>">8) || ("<?=$cfg_wlmode?>" == 9 && "<?=$cfg_mcast_a?>">12))
		{
			a_mrate.value = 0;
		}
		else
		{
			a_mrate.value = "<?=$cfg_mcast_a?>";
		}
	}

	if(f.frag != null)
	{
		f.frag.value = "<?=$cfg_frag?>";	
	}
	if(f.rts != null)
	{
		f.rts.value = "<?=$cfg_rts?>";	
	}	

	select_index(f.power, "<?=$cfg_power?>");
	select_index(f.wmm, "<?=$cfg_wmm?>");
	f.ack_timeout.value = "<?=$cfg_ack_time?>";
	if("<?=$cfg_mode?>"==1)
	{	
		if("<?=$cfg_channel_width?>"==0)
		{
			select_index(f.shortgi, "0");
			f.shortgi.disabled=true;
		}
		else
		{
			select_index(f.shortgi, "1");
			f.shortgi.disabled=true;
		}
	}
	else
	{
	select_index(f.shortgi, "<?=$cfg_shortgi?>");
	}
	select_index(f.limit_state, "<?=$cfg_limit_state?>");
	if(f.utilization != null)
	{
		select_index(f.utilization, "<?=$cfg_utilization?>");
	}
	//select_index(f.link_integrality, "<?=$cfg_link_integrality?>");
	
	if("<?=$cfg_ap_mode?>" !="0") //not access point
	{
		select_index(f.limit_state, "0");
		f.limit_state.disabled = true;		
	}
	
	f.limit_num.value = "<?=$cfg_limit_num?>";
	on_change_user_limit(f.limit_state);
	if("<?=$cfg_display_igmp?>" == "1")
	{
		select_index(f.igmp, "<?=$cfg_igmp?>");		
	}
		
	if("<?=$cfg_ap_mode?>" =="1") //apc
	{
		f.dtim.disabled = true;
		f.dtim.value="";
		f.bi.disabled = true;
		f.bi.value="";
		if("<?=$cfg_display_igmp?>" == "1")
		{
			f.igmp.disabled = true;
		}
	}
	else if("<?=$cfg_ap_mode?>" =="3" || "<?=$cfg_ap_mode?>" =="4")//WDS
	{
		f.bi.value = "<?=$cfg_beacon?>";
		f.dtim.value = "<?=$cfg_dtim?>";
		if("<?=$cfg_ap_mode?>" =="4" && "<?=$cfg_display_igmp?>" == "1")
		{		
			f.igmp.disabled = true;		
		}	
	}	
	else
	{
		f.bi.value = "<?=$cfg_beacon?>";
		f.dtim.value = "<?=$cfg_dtim?>";				
	}
	
	if(f.utilization)
		f.utilization.value = "<?=$cfg_utilization?>";
	if("<?=$cfg_display_mcast?>" == "1")
	{
		if("<?=$cfg_mode?>"==1 || "<?=$cfg_mode?>"==4)
    	{
    		f.mcast_a.disabled=true;
	    	f.mcast_g.disabled=true;
    		f.mcast_a_n.disabled=true;
    		f.mcast_g_n.disabled=true;
			f.mcast_n_fora.disabled=true;
			f.mcast_n_forg.disabled=true;
	    }
	}
		select_index(f.ht_status, "<?=$cfg_ht2040?>")
}

function on_change_ht_status()
{
	var f=get_obj("frm");
	f.f_coexistence.value = f.ht_status.value;
}

/* parameter checking */
function check()
{
	var f=get_obj("frm");
	
	if(f.wl_enable.value != "0")
	{
		if("<?=$cfg_ap_mode?>" !="1") //apc
		{
			if(!is_in_range(f.bi.value,25,500))
			{
				alert("<?=$a_invalid_bi?>");
				if(f.bi.value=="") f.bi.value=100;
				field_select(f.bi);
				return false;
			}	
			if(!is_in_range(f.dtim.value,1,15))
			{
				alert("<?=$a_invalid_dtim?>");
				if(f.dtim.value=="") f.dtim.value=1;
				field_select(f.dtim);
				return false;
			}						
		}
		if(f.frag != null)
		{
			if(!is_in_range(f.frag.value,256,2346))
			{
				alert("<?=$a_invalid_frag?>");
				if(f.frag.value=="") f.frag.value=2346;
				field_select(f.frag);
				return false;
			}		
		}
		if(f.rts != null)
		{
			if(!is_in_range(f.rts.value,256,2346))
			{
				alert("<?=$a_invalid_rts?>");
				if(f.rts.value=="") f.rts.value=2346;
				field_select(f.rts);
				return false;
			}		
		}
		if ("<?=$cfg_band?>"==1)
		{
			if("<?=$display_ack_time?>"!="1")
			{
				if(!is_in_range(f.ack_timeout.value,25,200))
				{
					alert("<?=$a_invalid_ack_timeouta?>");
					if(f.ack_timeout.value=="") f.ack_timeout.value=25;
					field_select(f.ack_timeout);
					return false;
				}		
			}
			else
			{
				if(!is_in_range(f.ack_timeout.value,50,200))
				{
					alert("<?=$a_invalid_ack_timeouta?>");
					if(f.ack_timeout.value=="") f.ack_timeout.value=50;
					field_select(f.ack_timeout);
					return false;
				}
			}
		}
		else
		{
			if("<?=$display_ack_time?>"!="1")
			{
				if(!is_in_range(f.ack_timeout.value,48,200))
				{
					alert("<?=$a_invalid_ack_timeoutg?>");
					if(f.ack_timeout.value=="") f.ack_timeout.value=48;
					field_select(f.ack_timeout);
					return false;
				}		
			}
			else
			{
				if(!is_in_range(f.ack_timeout.value,64,200))
				{
					alert("<?=$a_invalid_ack_timeoutg?>");
					if(f.ack_timeout.value=="") f.ack_timeout.value=64;
					field_select(f.ack_timeout);
					return false;
				}	
			}
		}
	
		if("<?=$cfg_ap_mode?>" =="0") //access point
		{		
			if(f.limit_state.value == 1)
			{		
				if(!is_in_range(f.limit_num.value,0,64))
				{
					alert("<?=$a_invalid_limit_num?>");
					if(f.limit_num.value=="") f.limit_num.value=64;
					field_select(f.limit_num);
					return false;
				}	
			}
		}
	}
	
	f.f_wlmode.value = w_wlmode.value;
	f.f_rate.value = w_rate.value;
	if("<?=$cfg_display_mcast?>" == "1")
	{
		f.f_mrate_a.value=a_mrate.value;
		f.f_mrate_g.value=g_mrate.value;
	}
	f.f_coexistence.value = f.ht_status.value;
	fields_disabled(f, false);
	return true;
}

function submit()
{
	if(check()) get_obj("frm").submit();
}

</script>

<body <?=$G_BODY_ATTR?> onload="init();">

<form name="frm" id="frm" method="post" action="<?=$MY_NAME?>.php" onsubmit="return false;">

<input type="hidden" name="ACTION_POST" value="<?=$MY_ACTION?>">
<input type="hidden" name="f_wlmode"		value="">
<input type="hidden" name="f_rate"		value="">
<input type="hidden" name="f_mrate_a"		value="">
<input type="hidden" name="f_mrate_g"		value="">
<input type="hidden" name="f_coexistence" value="">
<table id="table_frame" border="0"<?=$G_TABLE_ATTR_CELL_ZERO?>>
	<tr>
		<td valign="top">
			<table id="table_header" <?=$G_TABLE_ATTR_CELL_ZERO?>>
			<tr>
				<td id="td_header" valign="middle"><?=$m_context_title?></td>
			</tr>
			</table>
<!-- ________________________________ Main Content Start ______________________________ -->
			<table id="table_set_main"  border="0" <?=$G_TABLE_ATTR_CELL_ZERO?>>
				<tr>
					<td width="35%" id="td_left">
						<?=$m_wl_enable?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("wl_enable", [0,1], ["<?=$m_off?>","<?=$m_on?>"], "on_change_wl_enable(this)");<?=$G_TAG_SCRIPT_END?>
					</td>
				</tr>
				<tr>
					<td id="td_left">
						<?=$m_wlmode?>
					</td>
<? if($cfg_wep == 1)	{echo "<!--";} ?>						
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("wlmode_g", [5,2,4], ["<?=$m_wlmode_n_g_b?>","<?=$m_wlmode_g_b?>","<?=$m_wlmode_n?>"], "on_change_wlmode(this)");<?=$G_TAG_SCRIPT_END?>
						<?=$G_TAG_SCRIPT_START?>genSelect("wlmode_a", [8,7,9], ["<?=$m_wlmode_n_a?>","<?=$m_wlmode_a?>","<?=$m_wlmode_n?>"], "on_change_wlmode(this)");<?=$G_TAG_SCRIPT_END?>
					</td>
<? if($cfg_wep == 1) {echo "-->";} ?>
<? if($cfg_wep != 1)	{echo "<!--";} ?>						
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("wlmode_g", [5,2], ["<?=$m_wlmode_n_g_b?>","<?=$m_wlmode_g_b?>"], "on_change_wlmode(this)");<?=$G_TAG_SCRIPT_END?>
						<?=$G_TAG_SCRIPT_START?>genSelect("wlmode_a", [8,7], ["<?=$m_wlmode_n_a?>","<?=$m_wlmode_a?>"], "on_change_wlmode(this)");<?=$G_TAG_SCRIPT_END?>
					</td>
<? if($cfg_wep != 1) {echo "-->";} ?>						
				</tr>				
				<tr>
					<td id="td_left">
						<?=$m_rate?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("rate_g", [31,11,10,9,8,7,6,5,4,3,2,1,0], ["<?=$m_best?>","<?=$m_54?>","<?=$m_48?>","<?=$m_36?>","<?=$m_24?>","<?=$m_18?>","<?=$m_12?>","<?=$m_9?>","<?=$m_6?>","<?=$m_11?>","<?=$m_5.5?>","<?=$m_2?>","<?=$m_1?>"], "");<?=$G_TAG_SCRIPT_END?>
						<?=$G_TAG_SCRIPT_START?>genSelect("rate_a", [31,7,6,5,4,3,2,1,0], ["<?=$m_best?>","<?=$m_54?>","<?=$m_48?>","<?=$m_36?>","<?=$m_24?>","<?=$m_18?>","<?=$m_12?>","<?=$m_9?>","<?=$m_6?>"], "");<?=$G_TAG_SCRIPT_END?>
						&nbsp;<?=$m_mbps?>
					</td>
				</tr>	
				<tr>
					<td id="td_left">
						<?=$m_beacon_interval?>
					</td>
					<td id="td_right">
						<input name="bi" id="bi" class="text" type="text" size="10" maxlength="3" value="">
					</td>
				</tr>	
				<tr>
					<td id="td_left">
						<?=$m_dtim?>
					</td>
					<td id="td_right">
						<input name="dtim" id="dtim" class="text" type="text" size="10" maxlength="2" value="">
					</td>
				</tr>
<? if(query("/runtime/web/display/frag") !="1")	{echo "<!--";} ?>									
				<tr>
					<td id="td_left">
						<?=$m_frag?>
					</td>
					<td id="td_right">
						<input name="frag" id="frag" class="text" type="text" size="10" maxlength="4" value="">
					</td>
				</tr>
<? if(query("/runtime/web/display/frag") !="1") {echo "-->";} ?>
<? if(query("/runtime/web/display/rts") !="1")	{echo "<!--";} ?>	
								<tr>
					<td id="td_left">
						<?=$m_rts?>
					</td>
					<td id="td_right">
						<input name="rts" id="rts" class="text" type="text" size="10" maxlength="4" value="">
					</td>
				</tr>	
<? if(query("/runtime/web/display/rts") !="1") {echo "-->";} ?>
<? if(query("/runtime/web/display/txpower_have_75") =="1") {echo "<!--";} ?>
				<tr>
					<td id="td_left">
						<?=$m_power?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("power", [1,2,3,4], ["<?=$m_100?>%","<?=$m_50?>%","<?=$m_25?>%","<?=$m_12.5?>%"], "on_change_power(this)");<?=$G_TAG_SCRIPT_END?>
					</td>
				</tr>	
<? if(query("/runtime/web/display/txpower_have_75") =="1") {echo "-->";} ?>
<? if(query("/runtime/web/display/txpower_have_75") !="1") {echo "<!--";} ?>				
				<tr>
					<td id="td_left">
						<?=$m_power?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("power", [1,5,2,3,4], ["<?=$m_100?>%","<?=$m_75?>%","<?=$m_50?>%","<?=$m_25?>%","<?=$m_12.5?>%"], "on_change_power(this)");<?=$G_TAG_SCRIPT_END?>
					</td>
				</tr>	
<? if(query("/runtime/web/display/txpower_have_75") !="1") {echo "-->";} ?>				
				<tr>
					<td id="td_left">
						<?=$m_wmm?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("wmm", [0,1], ["<?=$m_disable?>","<?=$m_enable?>"], "on_change_wmm(this)");<?=$G_TAG_SCRIPT_END?>
					</td>
				</tr>	
				<tr>
					<td id="td_left">
						<?=$m_ack_timeout?>&nbsp;<span id="ack_timeout_msg"><?=$m_ack_timeout_g_msg?><span>
					</td>
					<td id="td_right">
						<input name="ack_timeout" id="ack_timeout" class="text" type="text" size="10" maxlength="3" value="">&nbsp;<?=$m_ms?>
					</td>
				</tr>	
				<tr>
					<td id="td_left">
						<?=$m_shortgi?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("shortgi", [0,1], ["<?=$m_disable?>","<?=$m_enable?>"], "on_change_shortgi(this)");<?=$G_TAG_SCRIPT_END?>
					</td>
				</tr>		
<? if(query("/runtime/web/display/igmp") !="1") {echo "<!--";} ?>
				<tr>
					<td id="td_left">
						<?=$m_igmp?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("igmp", [0,1], ["<?=$m_disable?>","<?=$m_enable?>"], "on_change_igmp(this)");<?=$G_TAG_SCRIPT_END?>
					</td>
				</tr>			
<? if(query("/runtime/web/display/igmp") !="1") {echo "-->";} ?>
<!--				<tr>
					<td id="td_left">
						<?=$m_link_integrality?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("link_integrality", [0,1], ["<?=$m_disable?>","<?=$m_enable?>"], "");<?=$G_TAG_SCRIPT_END?>
					</td>
				</tr>-->			
				<tr>
					<td id="td_left">
						<?=$m_limit_state?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("limit_state", [0,1], ["<?=$m_disable?>","<?=$m_enable?>"], "on_change_user_limit(this)");<?=$G_TAG_SCRIPT_END?>
					</td>
				</tr>	
				<tr>
					<td id="td_left">
						&nbsp;&nbsp;&nbsp;&nbsp;
						<?=$m_limit_num?>
					</td>
					<td id="td_right">
						<input name="limit_num" id="limit_num" class="text" type="text" size="10" maxlength="2" value="">
					</td>
				</tr>	
<? if(query("/runtime/web/display/utilization") !="1")	{echo "<!--";} ?>																		
				<tr>
					<td id="td_left">
						&nbsp;&nbsp;&nbsp;&nbsp;
						<?=$m_utilization?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>genSelect("utilization", [1,2,3,4,5,6], ["<?=$m_100?>%","<?=$m_80?>%","<?=$m_60?>%","<?=$m_40?>%","<?=$m_20?>%","<?=$m_0?>%"], "on_change_utilization(this)");<?=$G_TAG_SCRIPT_END?>
					</td>
				</tr>					
<? if(query("/runtime/web/display/utilization") !="1") {echo "-->";} ?>				
<? if(query("/runtime/web/display/mcast") !="1") {echo "<!--";} ?>
				<tbody id="mcast_a_setting" style="display:none;">		
				<tr>
					<td id="td_left">
						<?=$m_mcast_a?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>
							genSelect("mcast_a_n", [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20], ["<?=$m_disable?>","6","9","12","18","24","36","48","54","6.5","13","19.5","26","39","52","58.5","65","78","104","117","130"], "on_change_mcast();");
							genSelect("mcast_a", [0,1,2,3,4,5,6,7,8], ["<?=$m_disable?>","6","9","12","18","24","36","48","54"], "on_change_mcast();");
							genSelect("mcast_n_fora", [0,1,2,3,4,5,6,7,8,9,10,11,12], ["<?=$m_disable?>","6.5","13","19.5","26","39","52","58.5","65","78","104","117","130"], "on_change_mcast();");
						<?=$G_TAG_SCRIPT_END?>
						<?=$m_mbps?>
					</td>
				</tr>
				</tbody>
				<tbody id="mcast_g_setting" style="display:none;">		
				<tr>
					<td width="35%" id="td_left">
						<?=$m_mcast_g?>
					</td>
					<td id="td_right">
						<?=$G_TAG_SCRIPT_START?>
							genSelect("mcast_g_n", [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24], ["<?=$m_disable?>","1","2","5.5","11","6","9","12","18","24","36","48","54","6.5","13","19.5","26","39","52","58.5","65","78","104","117","130"], "on_change_mcast();");
							genSelect("mcast_g", [0,1,2,3,4,5,6,7,8,9,10,11,12], ["<?=$m_disable?>","1","2","5.5","11","6","9","12","18","24","36","48","54"], "on_change_mcast();");
							genSelect("mcast_n_forg", [0,1,2,3,4,5,6,7,8,9,10,11,12], ["<?=$m_disable?>","6.5","13","19.5","26","39","52","58.5","65","78","104","117","130"], "on_change_mcast();");
						<?=$G_TAG_SCRIPT_END?><?=$m_mbps?>
					</td>
				</tr>		
				</tbody>
<? if(query("/runtime/web/display/mcast") !="1") {echo "-->";} ?>
<tr>
					<td><?=$m_ht2040?></td>
					<td>
						<?=$G_TAG_SCRIPT_START?>genSelect("ht_status", [0,1], ["<?=$m_disable?>","<?=$m_enable?>"], "on_change_ht_status()");<?=$G_TAG_SCRIPT_END?>
					</td>
		</tr>
				<tr>
					<td colspan="2">
<?=$G_APPLY_BUTTON?>
					</td>
				</tr>
			</table>
<!-- ________________________________  Main Content End _______________________________ -->
		</td>
	</tr>
</table>
</form>
</body>
</html>
				
