<html>
<head>
<title></title>
</head>
<?
$cfg_lan_type = query("/wan/rg/inf:1/mode");
if($cfg_lan_type == 1)
{
	anchor("/wan/rg/inf:1/static");
}
else
{
	anchor("/runtime/wan/inf:1");
}
$cfg_ipaddr = query("ip");
?>
<script>
function init()
{
	//alert("You are the first time to connect outside URL, \n and therefore need to transfer to web redirect authentication page.");
	setTimeout("wr()",1000);
}
function wr()
{
	parent.location.href = "//<?=$cfg_ipaddr?>/wr_login.php";
}
	
</script>
<body onload="init();">
	
</body>
</html>
