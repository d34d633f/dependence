<html><head>
<META HTTP-EQUIV=Refresh CONTENT='0; url=<?=$HEADER_URL?>'>
</head></html>
<? exit;?>
