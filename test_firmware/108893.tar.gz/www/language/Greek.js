//BRS_01_checkNet.html
bh_internet_checking="Γίνεται έλεγχος της σύνδεσης Διαδικτύου, περιμένετε..."


//BRS_02_genieHelp.html
bh_config_net_connection="Ρυθμίζονται οι παράμετροι της σύνδεσης Διαδικτύου"

bh_connection_further_action="Δεν έχετε συνδεθεί ακόμα στο Διαδίκτυο."

bh_want_genie_help="Θέλετε τη βοήθεια του NETGEAR genie?"

bh_yes_mark="Ναι"

bh_no_genie_help="Όχι, θέλω να ρυθμίσω ο ίδιος τις παραμέτρους της σύνδεσης Διαδικτύου."

bh_no_genie_help_confirm="Η ρύθμιση παραμέτρων της σύνδεσης Διαδικτύου απαιτεί εμπειρία στα δίκτυα. Είστε βέβαιοι?"

bh_have_saved_copy="<b>Αποθηκευμένες ρυθμίσεις δρομολογητή.</b> Θέλω να φορτώσω αποθηκευμένες ρυθμίσεις διαμόρφωσης του δρομολογητή."

bh_next_mark="Επόμενο"

bh_need_genie_help="<b>Ναι.</b> Θέλω το NETGEAR genie να καθορίσει τις κατάλληλες ρυθμίσεις για το περιβάλλον μου και να διαμορφώσει αυτόματα το δρομολογητή μου."

bh_no_need_genie_help="<b>Όχι.</b> Θέλω να καταχωρίσω με μη αυτόματο τρόπο τις ρυθμίσεις διαμόρφωσης χρησιμοποιώντας τον οδηγό του NETGEAR genie."


//BRS_03A_detcInetType.html
bh_detecting_connection="Γίνεται εντοπισμός της σύνδεσης Διαδικτύου"

bh_plz_wait_process="Η διαδικασία ενδέχεται να διαρκέσει ένα ή δύο λεπτά. Περιμένετε."


//BRS_03A_A_noWan.html
bh_no_cable="Δεν έχει συνδεθεί καλώδιο Ethernet στη θύρα Διαδικτύου του δρομολογητή"

bh_wizard_setup_nowan_check="Βεβαιωθείτε ότι το καλώδιο είναι σωστά συνδεδεμένο στη θύρα ευρυζωνικής σύνδεσης του μόντεμ και στη θύρα Διαδικτύου του δρομολογητή."

bh_click_try_again="Αφού ελέγξετε το καλώδιο Ethernet, πατήστε <b>Δοκιμάστε ξανά</b>."

bh_try_again="Δοκιμάστε ξανά"


//BRS_03A_B_pppoe.html
bh_pppoe_connection="Εντοπίστηκε σύνδεση Διαδικτύου DSL PPPoE"

bh_enter_info_below="Εισαγάγετε παρακάτω τις απαιτούμενες πληροφορίες."

bh_pppoe_login_name="Όνομα χρήστη"
bh_ddns_passwd="Κωδικός πρόσβασης"


//BRS_03A_B_pppoe_reenter.html
bh_ISP_namePasswd_error="Λανθασμένο όνομα χρήστη ή κωδικός πρόσβασης παρόχου"

bh_enter_info_again="Εισαγάγετε ξανά τις απαιτούμενες πληροφορίες."


//BRS_03A_C_pptp.html
bh_pptp_login_name="Σύνδεση"

bh_pptp_connection="Εντοπίστηκε σύνδεση Διαδικτύου PPTP"

bh_basic_pptp_servip="Διεύθυνση διακομιστή"

bh_sta_routes_gtwip="Διεύθυνση IP πύλης"

bh_basic_pptp_connection_id="Αναγνωριστικό σύνδεσης/Όνομα"

//BRS_03A_F_l2tp.html
bh_l2tp_connection="Εντοπίστηκε σύνδεση Διαδικτύου L2TP"

//BRS_03A_D_bigpond.html
bh_bpa_connection="Εντοπίστηκε σύνδεση Διαδικτύου BigPond"

bh_basic_bpa_auth_serv="Διακομιστής ελέγχου ταυτοτήτων"

bh_basic_pppoe_idle="Λήξη χρονικού ορίου αδράνειας (σε λεπτά)"


//BRS_03A_E_IP_problem_staticIP.html
bh_no_internet_ip="Πρόβλημα κατά τον εντοπισμό της σύνδεσης Διαδικτύου"

bh_no_internet_ip2="Πρόβλημα κατά τον εντοπισμό της σύνδεσης Διαδικτύου - διεύθυνση IP"

bh_no_internet_ip3="Πρόβλημα κατά τον εντοπισμό της σύνδεσης Διαδικτύου - διεύθυνση MAC"

bh_if_have_static_ip="Η υπηρεσία παροχής Διαδικτύου (ISP) σάς έχει εκχωρήσει καθορισμένη (στατική) διεύθυνση IP; Πρόκειται για μια <b>πολύ σπάνια</b> ειδική ανάπτυξη. "

bh_yes_correct="Ναι. Η υπηρεσία παροχής Διαδικτύου (ISP) μού έχει εκχωρήσει καθορισμένη (στατική) διεύθυνση IP."

bh_not_have_static_ip="Όχι, δεν έλαβα καθορισμένη (στατική) διεύθυνση ΙΡ από την υπηρεσία παροχής Διαδικτύου."

bh_do_not_know="Δεν γνωρίζω. "

bh_select_option="Ενεργοποιήστε μια επιλογή και πατήστε <b>Επόμενο</b> για να συνεχίσετε."

bh_select_an_option="Πρώτα ενεργοποιήστε μια επιλογή."


//BRS_03A_E_IP_problem_staticIP_A_inputIP.html
bh_fix_ip_setting="Ρυθμίσεις καθορισμένης ΙΡ Διαδικτύου"

bh_enter_ip_setting="Εισαγάγετε τις ρυθμίσεις της καθορισμένης διεύθυνσης ΙΡ που σας εκχωρήθηκε από την υπηρεσία παροχής Διαδικτύου και πατήστε <b>Επόμενο</b> για να συνεχίσετε."

bh_info_mark_ip="Διεύθυνση IP"
//var bh_info_mark_ip="Η διεύθυνση IP μου"
bh_info_mark_mask="Μάσκα υποδικτύου"

bh_constatus_defgtw="Προεπιλεγμένη πύλη"

bh_preferred_dns="Προτιμώμενος διακομιστής DNS"

bh_alternate_dns="Εναλλακτικός διακομιστής DNS"

bh_basic_int_third_dns="Τρίτο DNS"

//BRS_03A_E_IP_problem.html
bh_genie_cannot_find_ip="Αυτό πιθανότατα οφείλεται σε έναν από τους παρακάτω λόγους:"
bh_genie_cannot_find_ip_reason1="1.  Δεν απενεργοποιήσατε και ενεργοποιήσατε ξανά το μόντεμ όταν σας ζητήθηκε κατά τη διαδικασία της καλωδίωσης."
bh_genie_cannot_find_ip_reason1_desc="Για να επιλύσετε το πρόβλημα, απενεργοποιήστε το μόντεμ και ενεργοποιήστε το ξανά. Για να απενεργοποιήσετε και να ενεργοποιήσετε ένα μόντεμ με εφεδρεία μπαταρίας, ενδέχεται να πρέπει να αφαιρέσετε την μπαταρία και να την τοποθετήσετε ξανά. Στη συνέχεια, περιμένετε 2 λεπτά μέχρι το μόντεμ να τεθεί κανονικά σε λειτουργία."
bh_genie_cannot_find_ip_reason2="2.  Το κίτρινο καλώδιο Ethernet δεν έχει τοποθετηθεί πλήρως ή έχει τοποθετηθεί σε λάθος σημείο."
bh_genie_cannot_find_ip_reason2_desc="Για να επιλύσετε το πρόβλημα, βεβαιωθείτε ότι το κίτρινο καλώδιο Ethernet έχει ασφαλίσει στην ευρυζωνική θύρα μόντεμ και στη θύρα Διαδικτύου του δρομολογητή."

bh_select_no_IP_option="Ενεργοποιήστε μία από τις παρακάτω επιλογές και πατήστε <b>Επόμενο</b> για να συνεχίσετε:"
bh_select_no_IP_option1="Απενεργοποίησα και ενεργοποίησα ξανά το μόντεμ και περίμενα για 2 λεπτά."
bh_select_no_IP_option2="Διόρθωσα το πρόβλημα με το καλώδιο Ethernet."
bh_select_no_IP_option3="Κανένα από τα παραπάνω."


//BRS_03A_E_IP_problem_staticIP_B_macClone.html
bh_use_pc_mac="Αν παλαιότερα συνδεόσασταν στην υπηρεσία Διαδικτύου μέσω υπολογιστή ή μέσω άλλου δρομολογητή, το NETGEAR genie μπορεί να χρησιμοποιήσει την ίδια διεύθυνση MAC που χρησιμοποιούσατε τότε."

bh_mac_in_product_label="Η διεύθυνση MAC είναι ένας ξεχωριστός αριθμός.  Μπορείτε να βρείτε τη διεύθυνση MAC του υπολογιστή ή του δρομολογητή στην ετικέτα προϊόντος."

bh_enter_mac="Εισαγάγετε τη διεύθυνση MAC εδώ."

bh_mac_format="(μορφή AABBCCDDEEFF)"


//BRS_03B_haveBackupFile.html
bh_settings_restoration="Επαναφορά ρυθμίσεων δρομολογητή"

bh_browser_file="Περιηγηθείτε στο αντίγραφο ασφαλείας των ρυθμίσεων δρομολογητή που έχετε αποθηκεύσει και πατήστε <b>Επόμενο</b> για να συνεχίσετε."

bh_back_mark="Πίσω"

bh_browse_mark="Αναζήτηση"

//BRS_03B_haveBackupFile_fileRestore.html
bh_settings_restoring="Γίνεται επαναφορά των ρυθμίσεων δρομολογητή"

bh_plz_waite_restore="Η διαδικασία ενδέχεται να διαρκέσει μερικά λεπτά, περιμένετε..."


//BRS_04_applySettings.html
bh_apply_connection="Εφαρμόζονται οι ρυθμίσεις σύνδεσης Διαδικτύου"

bh_plz_waite_apply_connection="Η διαδικασία ενδέχεται να διαρκέσει ένα ή δύο λεπτά. Περιμένετε."


//BRS_05_networkIssue.html
bh_netword_issue="Πρόβλημα σύνδεσης δικτύου"

bh_cannot_connect_internet="Ο δρομολογητής δεν μπορεί να συνδεθεί στο Διαδίκτυο με τις τρέχουσες ρυθμίσεις."

bh_plz_reveiw_items="Ελέγξτε τα παρακάτω στοιχεία:"

bh_cable_connection="- Ελέγξτε αν τα καλώδια έχουν συνδεθεί σωστά. Για οδηγίες, ανατρέξτε στον Οδηγό εγκατάστασης του δρομολογητή."

bh_modem_power_properly="- Ελέγξτε αν το ευρυζωνικό μόντεμ απενεργοποιήθηκε και ενεργοποιήθηκε ξανά σωστά. Αν το μόντεμ λειτουργεί με εφεδρεία μπαταρίας, αφαιρέστε την μπαταρία και τοποθετήστε την ξανά για να απενεργοποιηθεί και να ενεργοποιηθεί ξανά η συσκευή."

bh_try_again_or_manual_config="Θέλετε να δοκιμάσει ξανά το NETGEAR genie;"

bh_I_want_manual_config="Όχι. Θέλω να ρυθμίσω ο ίδιος τις παραμέτρους της σύνδεσης Διαδικτύου."

bh_manual_config_connection="Θέλω να ρυθμίσω ο ίδιος τις παραμέτρους της σύνδεσης Διαδικτύου."


//BRS_success.html
bh_congratulations="Συγχαρητήρια!"

bh_connect_success_1="Συνδεθήκατε στο Διαδίκτυο με επιτυχία."

bh_connect_success_2="Αυτός ο δρομολογητής είναι προρρυθμισμένος με το παρακάτω ξεχωριστό όνομα ασύρματου δικτύου (SSID) και "

bh_network_key="το κλειδί δικτύου (κωδικός πρόσβασης)"

bh_rollover_help_text="Ο δρομολογητής σας είναι προρυθμισμένος με ασφάλεια ασύρματου δικτύου WPA2-PSK, για την προστασία του δικτύου σας από ανεπιθύμητη πρόσβαση. Για να συνδεθείτε στο ασύρματο δίκτυο, πρέπει να εισαγάγετε το κλειδί δικτύου (κωδικός πρόσβασης). Αυτές οι προκαθορισμένες ρυθμίσεις είναι μοναδικές και ισχύουν μόνο για αυτήν τη συσκευή, σαν σειριακός αριθμός.  Αν θελήσετε να τις αλλάξετε, μπορείτε να μεταβείτε στην οθόνη Ρυθμίσεις ασύρμ. δικτύου στη διαδικτυακή GUI του δρομολογητή."

bh_success_no_wireless_security_1 ="Η ασύρματη ασφάλεια δεν είναι ενεργοποιημένη σε αυτό το δρομολογητή. Η NETGEAR συνιστά να "
bh_success_no_wireless_security_2 ="κάντε κλικ εδώ"
bh_success_no_wireless_security_3 =" για να ενεργοποιήσετε την ασύρματη ασφάλεια και να προστατεύσετε το δίκτυό σας."

bh_wirless_name="Όνομα ασύρματου δικτύου (SSID)"

bh_wireless="Ασύρματο"

bh_wpa_wpa2_passpharse="Κλειδί δικτύου (κωδικός πρόσβασης)"

bh_save_settings="Save router settings"

bh_print_this="Εκτύπωση"


bh_take_to_internet="Σύνδεση στο Διαδίκτυο"

bh_plz_wait_moment="Περιμένετε λίγο..."

//the string for not_support_print is temporary.
bh_not_support_print="Ο υπολογιστής δεν υποστηρίζει εκτυπωτή."
//already exist
bh_login_name_null="Το όνομα χρήστη δεν μπορεί να είναι κενό."
bh_password_error="Μη έγκυρος κωδικός πρόσβασης."
bh_idle_time_null="Πληκτρολογήστε χρον διάστ αδράνειας.\n"
bh_invalid_idle_time="Μη έγκυρο χρονικό διάστημα αδράνειας. Πληκτρολογήστε έναν σωστό αριθμό.\n"
bh_invalid_myip="Μη έγκυρη διεύθυνση IP. Πληκτρολογήστε τη διεύθυνση ξανά ή αφήστε την κενή."
bh_invalid_gateway="Μη έγκυρη διεύθυνσης IP πύλης. Πληκτρολογήστε ξανά."
bh_bpa_invalid_serv_name="Μη έγκυρη διεύθυνση IP διακομιστή ελέγχου ταυτοτήτων."
bh_invalid_servip_length="Οι ετικέτες πρέπει να έχουν μήκος έως 63 χαρακτήρες.\n"
bh_invalid_ip="Μη έγκυρη διεύθυνση IP. Πληκτρολογήστε ξανά."
bh_invalid_mask="Μη έγκυρη μάσκα υποδικτύου. Πληκτρολογήστε ξανά.\n"
bh_same_subnet_ip_gtw="Η διεύθυνση IP και η διεύθυνση IP πύλης πρέπει να βρίσκεται στο ίδιο υποδίκτυο.\n"
bh_same_lan_wan_subnet="Η διεύθυνση IP LAN και η διεύθυνση IP WAN δεν επιτρέπεται να βρίσκονται στο ίδιο υποδίκτυο.\n"
bh_filename_null="Το όνομα αρχείου δεν μπορεί να είναι κενό."
bh_not_correct_file="Αντιστοιχίστε το σωστό αρχείο. Η μορφή αρχείου είναι *."
bh_ask_for_restore="Προειδοποίηση! \nΗ επαναφορά ρυθμίσεων από ένα αρχείο ρύθμισης παραμέτρων θα διαγράψει όλες τις τρέχουσες ρυθμίσεις. \nΕίστε βέβαιοι ότι θέλετε να γίνει αυτό;"
bh_invalid_primary_dns="Μη έγκυρη κύρια διεύθυνση DNS. Πληκτρολογήστε ξανά.\n"
bh_invalid_second_dns="Μη έγκυρη δευτερεύουσα διεύθυνση DNS. Πληκτρολογήστε ξανά.\n"
hb_invalid_third_dns="Μη έγκυρη διεύθυνση τρίτου DNS. Πληκτρολογήστε ξανά."
bh_dns_must_specified="Πρέπει να καθορίζεται διεύθυνση DNS."
bh_invalid_mac="Μη έγκυρη διεύθυνση MAC."
bh_failure_head="Αποτυχία"
bh_few_second="Αυτή η οθόνη θα επιστρέψει αυτόματα στην προηγούμενη οθόνη σε λίγα δευτερόλεπτα..."

bh_important="Σημαντική ενημέρωση"
bh_wanlan_conflict_info="Για να αποφύγετε διένεξη με την υπηρεσία παροχής Internet, έχει γίνει ενημέρωση της διεύθυνσης IP του δρομολογητή σας σε "
bh_continue_mark="Συνέχεια"
bh_same_server_wan_ip="Η διεύθυνση IP δεν πρέπει να είναι ίδια με τη διεύθυνση διακομιστή!"

//readySHARE remote strings
remote_share_head="ReadySHARE Cloud"

ready_share_info1="Η λειτουργία ReadySHARE Cloud σάς παρέχει απομακρυσμένη πρόσβαση στο Διαδίκτυο μέσω μιας συσκευής αποθήκευσης USB που είναι συνδεδεμένη στη θύρα USB του δρομολογητή."
how_setup_ready_share="Τρόπος ρύθμισης λειτουργίας ReadySHARE Cloud"
ready_share_step1="Βήμα 1: Πρέπει να έχετε λογαριασμό ReadySHARE Cloud. Αν δεν έχετε λογαριασμό,<a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>κάντε κλικ εδώ</a> για να αποκτήσετε."
ready_share_step2="Βήμα 2: Σε αυτήν τη σελίδα, πληκτρολογήστε το όνομα χρήστη και τον κωδικό πρόσβασης του λογαριασμού ReadySHARE Cloud, προκειμένου να εγγράψετε το δρομολογητή σας και τη συσκευή USB που είναι συνδεδεμένη σε αυτόν με το λογαριασμό σας."
ready_share_step3="Βήμα 3: Συνδεθείτε πάλι στο <a class='linktype' target='_blank' href='http://readyshare.netgear.com/'>http://readyshare.netgear.com/</a> με το λογαριασμό σας. Θα πρέπει να βλέπετε τη συσκευή USB που είναι συνδεδεμένη στο δρομολογητή σας."
ready_share_step4="Βήμα 4: Την πρώτη φορά, θα σας ζητηθεί να κάνετε λήψη ενός πελάτη Windows που χρησιμοποιείται για τη δημιουργία μιας ασφαλούς σύνδεσης από τον υπολογιστή σας προς τη συσκευή USB του δρομολογητή. Συνδεθείτε σε αυτόν τον πελάτη. Θα μπορείτε να προσπελάσετε τη συσκευή USB όπου κι αν βρίσκεστε."
ready_share_set_note="<b>Σημείωση:</b> Χωρίς αυτόν τον πελάτη, μπορείτε να πραγματοποιήσετε αναζήτηση στα περιεχόμενα της συσκευής USB, αλλά δεν μπορείτε να ανοίξετε αρχεία ή να πραγματοποιήσετε αλλαγές σε αυτά."
ready_share_start="Ξεκινήστε τώρα για να ενεργοποιήσετε το ReadySHARE Cloud"
ready_share_get_account="Αν δεν έχετε λογαριασμό ReadySHARE Cloud, <a class='linktype' target='_blank' href='https://readyshare.netgear.com/site/index.jsp?pid=4&src=device'>κάντε κλικ εδώ</a> για να αποκτήσετε"
username="Όνομα χρήστη"
key_passphrase="Κωδικός πρόσβασης"
register="Εγγραφή"
register_note="<b>Σημείωση:</b> Η σύνδεση στο Διαδίκτυο θα διατηρηθεί ενεργή μέχρι την κατάργηση της εγγραφής."
help_center="Κέντρο βοήθειας"
help_show_hide="Εμφάνιση/Απόκρυψη κέντρου βοήθειας"

resister_user="Το ReadySHARE Cloud είναι εγγεγραμμένο με το χρήστη"
access_storage_method="Μπορείτε να ακολουθήσετε τα βήματα 2~4 για να προσπελάσετε τη συσκευή αποθήκευσης όπου κι αν βρίσκεστε."
unregister_info="Πατήστε <B>Κατάργηση εγγραφής</B> για να εγγράψετε το ReadySHARE Cloud με διαφορετικό χρήστη."
unregister="Κατάργηση εγγραφής"

result_register_ok="Η εγγραφή ολοκληρώθηκε με επιτυχία"
result_register_fail="Η εγγραφή απέτυχε"
result_unreg_ok="Η κατάργηση της εγγραφής ολοκληρώθηκε με επιτυχία"
result_unreg_fail="Η κατάργηση εγγραφής απέτυχε"

//WIZ_sel_3g_adsl.htm
bh_connection_mode="Choosing Connection Mode"

bh_ethernet_connection="Always use Ethernet connection"

bh_mobile_broadband_connection="Να χρησιμοποιείται πάντα σύνδεση Mobile Broadband"

bh_multi_wan_connection="Failover Mode"

//config_3g_wait_page.htm
bh_umts_3g_mode="Detecting Mobile Broadband USB Modem"

//detect_succ_hsdpa.htm
bh_detect_hsdpa_msg="Please Enter Service Provider Information"
bh_detect_hsdpa_msg1="Επιλέξτε την <strong>Υπηρεσία παροχής Internet</strong> και μετά κάντε κλικ στο κουμπί <strong>Επόμενο</strong>."
bh_detect_hsdpa_msg2="Εάν η υπηρεσία παροχής Mobile Broadband που χρησιμοποιείτε δεν υπάρχει στην πτυσσόμενη λίστα, επιλέξτε άλλο"
bh_country_3g="Χώρα"
bh_basic_intserv_provider="Υπηρεσία παροχής Internet"
bh_access_number_3g="Αριθμός πρόσβασης"
//country list
bh_coun_austrilia="Αυστραλία"
bh_coun_austria="Αυστρία"
bh_coun_belgium="Βέλγιο"
bh_coun_brazil="Βραζιλία"
bh_coun_chile="Χιλή"
bh_coun_china="China"
bh_coun_finland="Φινλανδία"
bh_coun_germany="Γερμανία"
bh_coun_hk="Χoνγκ Κονγκ"
bh_coun_italy="Ιταλία"
bh_coun_netherlands="Ολλανδία"
bh_coun_newzealand="Νέα Ζηλανδία"
bh_coun_norway="Νορβηγία"
bh_coun_peru="Περού"
bh_coun_russia="Ρωσία"
bh_coun_singapore="Σιγκαπούρη"
bh_coun_south_africa="South Africa"
bh_coun_sweden="Σουηδία"
bh_coun_tw="Ταϊβάν"
bh_coun_uk="UK"
bh_coun_usa="ΗΠΑ"

//detect_not.htm
bh_unable_detect_msg="Δεν είναι δυνατός ο εντοπισμός μόντεμ"
bh_unable_detect_msg1="Δεν εντοπίστηκε προσαρμογέας Mobile Broadband USB Modem."
bh_want_try_again="Do you want to try again?"

//detect_no_sim.htm
bh_detect_not_simcard="Δεν εντοπίστηκε κάρτα SIM"
bh_detect_not_simcard_msg1="The problem could be one of the following:"
bh_detect_not_simcard_msg2="SIM card not detected."
bh_detect_not_simcard_msg3="Ελέγξτε αν είναι τοποθετημένη η κάρτα SIM και αν εφάπτεται σωστά."
bh_detect_not_simcard_msg4="Η κάρτα SIM απορρίφθηκε."
bh_detect_not_simcard_msg5="Ελέγξτε αν είναι έγκυρη η κάρτα SIM."
bh_quit_mark="Έξοδος"


//BRS_00_01_check_ap.html
bh_check_ap="Πραγματοποιείται έλεγχος της ρύθμισης δικτύου, περιμένετε…"
//BRS_00_02_ap_select.html
bh_ap_select_title="Εντοπίστηκε δρομολογητής ή πύλη στο δίκτυό σας"
bh_ap_select_doc="Ο δρομολογητής NETGEAR είναι συνδεδεμένος σε δίκτυο που διαθέτει ήδη δρομολογητή. Αν δεν θέλετε να αποσυνδέσετε τον πρώτο δρομολογητή, το genie συνιστά τη λειτουργία σημείου πρόσβασης για χρήση με το δρομολογητή NETGEAR. Όταν η λειτουργία σημείου πρόσβασης είναι ενεργοποιημένη στο δρομολογητή NETGEAR, μπορείτε να τον χρησιμοποιήσετε για να συνδεθείτε στο δίκτυο. Ο άλλος δρομολογητής συνεχίζει να εκτελεί τις ίδιες εργασίες δικτύου που εκτελούσε και προηγουμένως."
bh_ap_select_question="Θέλετε να ρυθμίσετε αυτήν τη συσκευή σε λειτουργία ασύρματου σημείου;"
bh_ap_select_item_1="Ναι (συνιστάται)"
bh_ap_select_item_2="Όχι, θέλω να εκτελείται σε προεπιλεγμένη λειτουργία δρομολογητή"
//BRS_00_03_ap_setup.html
bh_ap_setup_title="Για να προσθέσετε αυτόν το δρομολογητή στο δίκτυό σας σε λειτουργία σημείου πρόσβασης"
bh_ap_setup_type_select="Διεύθυνση IP νέας συσκευής"
bh_ap_setup_type_item1="Δυναμική λήψη διεύθυνσης IP από υπάρχοντα δρομολογητή"
bh_ap_setup_type_item2="Χρήση σταθερής διεύθυνσης IP (δεν συνιστάται)"
bh_ap_setup_note="Σημείωση: Αφού πατήσετε Επόμενο, ο συγκεκριμένος δρομολογητής θα εκχωρηθεί σε νέα διεύθυνση IP. Σε αυτήν την περίπτωση, το πρόγραμμα περιήγησης ενδέχεται να αποσυνδεθεί από το δίκτυο. Για επανασύνδεση με το δρομολογητή, κλείστε το παράθυρο και εκκινήστε ξανά το πρόγραμμα περιήγησης."
bh_ip_subnet_mask="ΙΡ Μάσκα υποδικτύου"
bh_primary_dns="Κύριος DNS"
bh_secondary_dns="secondary DNS"
//warning
bh_wps_in_progress="Η διαδικασία WPS βρίσκεται σε εξέλιξη. Εφαρμόστε τις αλλαγές αργότερα."

//BRS_00_04_ap_wait.html
bh_ap_wait_title="Εφαρμόζονται οι ρυθμίσεις σύνδεσης Διαδικτύου"
bh_ap_wait_note="Η διαδικασία ενδέχεται να διαρκέσει ένα ή δύο λεπτά. Περιμένετε."

//BRS_no_simcard.html
bh_no_simcard="Δεν εντοπίστηκε έγκυρη κάρτα SIM"
bh_not_simcard_msg1="Ελέγξτε αν είναι έγκυρη η κάρτα SIM."
bh_not_device_msg1="Please check that the device is valid."
//BRS_enter_pin.html
bh_enter_pincode="Please enter PIN code for SIM Card"
bh_enter_pin_msg="Please contact your Service Provider if you do not know your PIN Code"
//BRS_enter_puk.html
bh_enter_pukcode="Please enter PUK code for SIM Card"
bh_enter_puk_msg="Please contact your Service Provider if you do not know your PUK Code"

//BRS_no_coverage.html
bh_no_coverage="Δεν υπάρχει κάλυψη δικτύου"
bh_no_coverage_msg1="Mobile signal not detected."
bh_no_coverage_msg2="Please check that the antennas are securely connected to the router."

//isp list
bh_coun1_isp_type18="Άλλο"
bh_coun8_isp_type6="Κυριακή"
bh_coun20_isp_type1="China Mobile"
bh_coun20_isp_type2="China Unicom"
bh_coun20_isp_type3="China Telecom"

//download
bh_download_apps="Downloading the following router apps:"
bh_genie_app="<b>genie app.</b> A personal dashboard that lets you monitor, control, and repaire your home network."
bh_rs_vault_app="<b>ReadySHARE Vault app(Only for Windows computers).</b> Enable automatic continuous backup of a Windows computer to a USB drive that's connected to your router."
bh_exit_mark="Έξοδος"
bh_previous="Προηγούμενο"
bh_processing="Processing your request..."
bh_downloading="Downloading..."
bh_dl_all1="Install the genie app and ReadySHARE Vault app after the download completes."
bh_dl_all2="Click the <b>Next</b> button after you install the genie app and ReadySHARE Vault app to finish configuring the router."
bh_dl_genie1="Εγκατάσταση της εφαρμογής genie μετά την ολοκλήρωση της λήψης."
bh_dl_genie2="Click the <b>Next</b> button after you install the genie app to finish configuring the router."
bh_dl_vault1="Εγκατάσταση της εφαρμογής ReadySHARE Vault μετά την ολοκλήρωση της λήψης."
bh_dl_vault2="Click the <b>Next</b> button after you install the ReadySHARE Vault app to finish configuring the router."

//firmware checking and update
bh_wait_upg_head="Βοηθός αναβάθμισης υλικολογισμικού"
bh_cancel_mark="Άκυρο"
bh_wait_new_version="Βρέθηκε νέα έκδοση υλικολογισμικού. Επιθυμείτε αναβάθμιση στη νέα έκδοση τώρα;"
bh_current_firmware="Τρέχουσα έκδοση"
bh_new_firmware="New Version"
bh_current_language="Τρέχουσα έκδοση γλώσσας GUI"
bh_new_language="Νέα έκδοση γλώσσας GUI"
bh_greendl_upgrade_version_cur="Τρέχουσα έκδοση NETGEAR Downloader"
bh_greendl_upgrade_version_new="Νέα έκδοση NETGEAR Downloader"
bh_no_mark="Όχι"
bh_downloading_ver="Ο δρομολογητής εκτελεί λήψη της νέας έκδοσης τώρα. Περιμένετε..."
bh_download_confile_fail="Δεν ήταν δυνατή η λήψη του υλικολογισμικού από το διακομιστή NETGEAR. Ελέγξτε τη σύνδεσή σας στο Internet."
bh_upg_md5_check_error="Σφάλμα επαλήθευσης MD5."
bh_firmware_check="Έλεγχος έκδοσης υλικολογισμικού "
bh_no_new_version="Δεν υπάρχει διαθέσιμη νέα έκδοση υλικολογισμικού."
bh_wait_cancel="Η αναβ του υλ/κού ακυρώθηκε!"
bh_auto_fail_no_internet="Επικοινωνήστε με τη θύρα Internet και προσπαθήστε ξανά"
bh_greendl_upgrade_version_waiting="Ο δρομολογητής πραγματοποιεί αναβάθμιση στη νεότερη έκδοση της NETGEAR Downloader. Περιμένετε…"
bh_greendl_upgrade_name="NETGEAR Downloader Update"
bh_wait_update_lang="Περιμένετε μέχρι να ολοκληρωθεί η ενημέρωση της γλώσσας του περιβάλλοντος χρήσης"
bh_auto_upg_nowan_head="Δεν υπάρχει σύνδεση στο Internet"
bh_ml_failDownload="Ο δρομολογητής απέτυχε να εκτελέσει λήψη του πίνακα γλωσσών που ζητήσατε. Δοκιμάστε ξανά αργότερα."
bh_ml_noInternet="Ο δρομολογητής δεν είναι συνδεδεμένος στο Internet, δεν μπορεί να πραγματοποιήσει λήψη του καθορισμένου αρχείου γλώσσας από τον ιστότοπο της NETGEAR. Εάν δεν έχετε ρυθμίσει τη θύρα Internet του δρομολογητή, εκτελέστε το CD εγκατάστασης, διαφορετικά, πραγματοποιήστε μη αυτόματη σύνδεση του δρομολογητή στο Internet και δοκιμάστε αυτή τη λειτουργία ξανά."
bh_ok_mark="OK"
