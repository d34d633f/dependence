<?
$m_html_title="登出";
$m_context_title="登出";
$m_context="您已成功登出。";
$m_button_dsc="回返至登入頁";
?>
