<?
$m_context_title = "無線區域網路交換設定";
$m_wtp_title = "無線端點設定";
$m_connect_title = "連接資訊";
$m_wtp_enable = "WTP啟動";
$m_wtp_name = "WTP名稱";
$m_wtp_location = "WTP位置資料";
$m_ac_ip = "無線區域網路交換IP";
$m_ac_name = "無線區域網路交換名稱";
$m_ac_ipaddr = "無線區域網路交換IP位址";
$m_ac_ip_list_title = "無線區域網路交換位址清單";
$m_id = "識別碼";
$m_ip = "IP位址";
$m_del = "刪除";

$a_wtp_del_confirm		= "確定刪除這個IP位址？";
$a_same_wtp_ip	= "已有相同的IP位址存在。\\n 請更換IP位址。";
$a_invalid_ip		= "IP位址無效！";
$a_max_ip_table		= "無線區域網路交換位址清單的數目上限為8！";
?>
