<?
$m_context_title = "系統設定";
$m_reboot		=" 設備重新開機";
$m_b_reboot		=" 重新開機";
$m_factory_reset	="恢復原廠預設值";
$m_b_restore		="恢復";
$m_clear_lang_pack ="清除語言套件"; 
$m_clear ="清除";
$a_sure_to_clear_lang ="確認要清除語言套件 ?";
$a_sure_to_factory_reset="是否恢復原廠預設值?";
$a_sure_to_reboot	="重新開啟無線基地台 ?";

?>
