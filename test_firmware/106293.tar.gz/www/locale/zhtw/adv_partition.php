<?
$m_context_title = "無線分割";
$m_isc = "內部站台連接";
$m_guest = "訪客模式";
$m_ewa = "乙太網路對無線區域網路的連線";
$m_enable = "啟動";
$m_disable = "取消";
$m_band = "無線頻帶";
$m_band_5G = "5GHz";
$m_band_2.4G = "2.4GHz";
$m_link_integrality="Link Integrity";
$m_pri_ssid = "主要服務設定識別碼";
$m_ms_ssid1 = "多重服務設定識別碼 1";
$m_ms_ssid2 = "多重服務設定識別碼 2";
$m_ms_ssid3 = "多重服務設定識別碼 3";
$m_ms_ssid4 = "多重服務設定識別碼 4";
$m_ms_ssid5 = "多重服務設定識別碼 5";
$m_ms_ssid6 = "多重服務設定識別碼 6";
$m_ms_ssid7 = "多重服務設定識別碼 7";

$a_will_block_packets = "AP will block all multicast/broadcast packets from Ethernet to Wireless, except DHCP's.";
?>
