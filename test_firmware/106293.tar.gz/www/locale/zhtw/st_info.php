<?
$m_context_title = "用戶端訊息";
$m_client_info = "用戶端訊息";
$m_st_association  = "基地台關係";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "Band";
$m_auth = "認證";
$m_signal = "訊號";
$m_power = "省電模式";
$m_multi_ssid = "MULTI-SSID ";
$m_primary_ssid = "Primary SSID";
$m_on = "開啟";
$m_off = "關閉";
?>
