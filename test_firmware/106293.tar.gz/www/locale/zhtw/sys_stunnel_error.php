<?
$m_html_title="上傳";
$m_context_title="上傳";
$m_context="系統錯誤!!!<br>請重試一次。";
$m_button_dsc="返回";
?>
