<?
$m_context_title = "Client-Informationen";
$m_client_info = "Client-Informationen";
$m_st_association  = "Stationszuweisung";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "Band";
$m_auth = "Authentifizierung";
$m_signal = "Signal";
$m_power = "Stromsparmodus";
$m_multi_ssid = "MULTI-SSID ";
$m_primary_ssid = "Primäre SSID";
$m_on = "Ein";
$m_off = "Aus";
?>
