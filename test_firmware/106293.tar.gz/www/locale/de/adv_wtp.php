<?
$m_context_title = "WLAN-Switch-Einstellungen";
$m_wtp_title = "Einstellungen für drahtlosen Endpunkt";
$m_connect_title = "Verbindungsinformationen";
$m_wtp_enable = "WTP aktivieren";
$m_wtp_name = "WTP-Name";
$m_wtp_location = "WTP-Standortdaten";
$m_ac_ip = "WLAN-Switch-IP";
$m_ac_name = "WLAN-Switch-Name";
$m_ac_ipaddr = "WLAN-Switch-IP-Adresse";
$m_ac_ip_list_title = "WLAN-Switch-Adressliste";
$m_id = "Kennung";
$m_ip = "IP-Adresse";
$m_del = "Löschen";

$a_wtp_del_confirm		= "Möchten Sie diese IP-Adresse wirklich löschen?";
$a_same_wtp_ip	= "Ein Eintrag mit derselben IP-Adresse existiert bereits.\\n Ändern Sie bitte die IP-Adresse.";
$a_invalid_ip		= "Ungültige IP-Adresse!";
$a_max_ip_table		= "Die maximale Anzahl von WLAN-Switch-Adresslisten ist 8!";
?>
