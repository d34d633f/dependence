Das Gerät wird neu gestartet...<br><br>
<font color=red><b>Schalten Sie das Gerät BITTE NICHT AUS.</b></font><br><br>
Warten Sie bitte 
<input type='Text' readonly name='WaitInfo' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
 Sekunden lang...
