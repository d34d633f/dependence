<?
$m_html_title="Falsches Firmware-Bild";
$m_context_title="Falsches Firmware-Bild";
$m_context="Die ausgewählte Datei ist keine Bilddatei.";
$m_button_dsc=$m_continue;
?>
