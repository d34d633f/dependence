<?
$tool_admin = "Administrationseinstellungen";
$tool_fw = "Firmware- und SSL-Zertifizierung hochladen";
$tool_config = "Konfigurationsdatei";
$tool_sntp = "Uhrzeit und Datum";
$logout_msg = "&nbsp;&nbsp;Die aktuelle Browser-Verbindung wird getrennt,<br>&nbsp;&nbsp;<b>wenn Sie hier klicken.</b>.";
?>
