<?
$m_context_title = "Internal RADIUS Server";
$m_account_title = "Add RADIUS Account";
$m_name = "User Name";
$m_password = "Password";
$m_list_title = "RADIUS Account list";
$m_edit = "(Edit)";
$m_delete = "Delete";
$m_enable = "Enable";
$m_disable = "Disable";
$m_status = "Status";
$a_can_not_same_name = "Can't use the same name !";
$a_max_account_number = "Maximum number of user account is 256!";
$a_empty_user_name ="Please input a user name.";
$a_first_end_blank  = "The first character and last character can't be blank.";
$a_invalid_password_len	= "The length of password should be 8~64.";
$a_invalid_password	= "The password should be ASCII characters.";
?>
