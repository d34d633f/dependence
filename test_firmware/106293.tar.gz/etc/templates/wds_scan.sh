#!/bin/sh
echo [$0] ... > /dev/console
#rgdb -i -d /runtime/wireless/wdslistinfo
if [ $1 = "g" ]; then
iwpriv ath0 wdssite 1
iwlist ath0 scanning wds_scan
#iwpriv ath8 reset 1
else
APMODE=`rgdb -g /wlan/inf:2/ap_mode`
APCHANNEL=`rgdb -ig /runtime/stats/wlan/inf:2/channeltable/channel:1/channel`
	if [ "$APMODE" = "0" ]; then
		iwconfig ath16 freq $APCHANNEL 
		iwpriv ath16 wdssite 1
		iwlist ath16 scanning wds_scan
APCHANNEL=`rgdb -g /wlan/inf:2/channel`
		iwconfig ath16 freq $APCHANNEL
	else
		iwpriv ath16 wdssite 1
		iwlist ath16 scanning wds_scan
	fi
fi

