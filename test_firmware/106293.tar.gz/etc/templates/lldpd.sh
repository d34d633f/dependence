if [ `ifconfig eth1 | scut -p BROADCAST`  = "RUNNING" ];then 
	lldpd -I eth1 -C eth1 
	sleep 1 
	lldpcli configure ports eth1 dot3 power pd supported  enable powerpairs signal class class-4 type 2 source pse priority low requested 25500 allocated 25500
	lldpcli update 
fi 
