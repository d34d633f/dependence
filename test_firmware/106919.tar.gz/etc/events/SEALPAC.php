<?
include "/htdocs/phplib/slp.php";
$langcode = sealpac($FILE);
SLP_setlangcode($langcode);
echo $langcode;
?>
