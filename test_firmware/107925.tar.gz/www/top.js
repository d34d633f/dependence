function languageShowlist()
{
	document.write('<option value=Auto>$auto_mark</option>');
	if (language_oriArray != "")
	{
		for (j=0; j<language_oriArray.length; j++)
		{
			document.write('<option value='+language_oriArray[j]+'>'+language_showArray[j]+'</option>');
		}
	}
	else
		document.write('<option value=English>'+language_oriArray[0]+'</option>');
}

function doDisable()
{
	form=document.forms[0];
	if( form.lang_avi.value == lang_select && !(lang_select == "Auto" && browser_lang != gui_region))
		location.reload();
	else
	{
		form.lang_avi.disabled=true;
        form.hidden_lang_avi.value=form.lang_avi.value;
		form.target="formframe";
        form.submit();
	}
}

function firmwareUpgrade()
{
	goto_formframe('ver_lang_firm.htm');
}

function do_search()
{
	var key = document.forms[0].search.value.replace(/ /g,"%20");
	var winoptions = "width=960,height=800,menubar=yes,scrollbars=yes,toolbar=yes,status=yes,location=yes,resizable=yes";
	var url="http://kb.netgear.com/app/answers/list/kw/"+key;

	window.open(url,null,winoptions);
}

function load_top_value()
{
        form=document.forms[0];

        var sUserAgent = navigator.userAgent;

	if(document.compatMode == "BackCompat")
		var width = top.document.body.clientWidth;
	else
	        var width = top.document.documentElement.clientWidth;
        var upgrade_div = document.getElementById("update_info");
        if(upgrade_div != null)
        {
                if(wan_status==1 && config_status==9999 && updateFirmware==1)
                        upgrade_div.style.display = "inline";
                else
                        upgrade_div.style.display = "none";
        }

	/* to fix bug 25107 */
        if( upgrade_div.style.display != "none")
        {
                var upgrade_mess = upgrade_div.getElementsByTagName("i")[0];
                var left = 60 + 20;
                var free_width = width - left - 181;
                var info_width = document.getElementById("update_info_middle").clientWidth + 34;

                if( free_width > info_width )
                {
                        var upgrade_left = (free_width - info_width)/2 > 15 ? 15 : (free_width - info_width)/2;
                        upgrade_div.className = "update_info_down";
                        upgrade_div.style.left = (left + upgrade_left) + "px";
                }
                else
                {
                        upgrade_div.className="update_info_up";
                        upgrade_div.style.left="270px";
                }
        }
}
