<?
$m_context_title	= "Protokoll anzeigen";

$m_first_page	= "Erste Seite";
$m_last_page	= "Letzte Seite";
$m_previous	= "Zurück";
$m_next		= "Weiter";
$m_clear	= "Entfernen";

$m_time		= "Zeit";
$m_type		= "Priorität ";//"Type";
$m_message	= "Nachricht";
$m_page		= "Seite";
$m_of		= "von";
?>
