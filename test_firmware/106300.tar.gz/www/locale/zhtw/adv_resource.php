<?
$m_context_title = "無線資源控制";
$m_band = "無線頻帶";
$m_band_2.4G = "2.4GHz";
$m_band_5G = "5GHz";
$m_disable = "禁用";
$m_enable  = "啟用";
$m_5g_preferred="頻段轉換";
$m_5g_preferred_age="频段轉換壽命";
$m_5g_preferred_diff="频段轉換差";
$m_5g_preferred_refuse="频段轉換拒絕數量";
$m_5g_preferred_rssi="频段转换RSSI";
$m_limit_state = "連接上限";
$m_limit_num = "使用者上限 (0 - 64)";
$m_11n_preferred="11n優先";
$m_utilization = "網路應用";
$m_aging = "老化";
$m_rssi ="RSSI";
$m_date_rate="資料速率";
$m_mcs = "MCS";
$m_agingout_time = "老化時間";
$m_aging_date_rate="資料速率閾值";
$m_aging_rssi="RSSI閾值";
$m_auto = "自動";
$m_acl_rssi="ACL RSSI";
$m_acl_rssi_thre="ACL RSSI閾值";
$m_54   = "54";
$m_48   = "48";
$m_36   = "36";
$m_24   = "24";
$m_18   = "18";
$m_12   = "12";
$m_9    = "9";
$m_6    = "6";
$m_0 = "0";
$m_10 = "10";
$m_20 = "20";
$m_30 = "30";
$m_40 = "40";
$m_50 = "50";
$m_60 = "60";
$m_70 = "70";
$m_80 = "80";
$m_90 = "90";
$m_100 = "100";
$m_180 = "180";
$m_75 = "75";
$m_25 = "25";
$i=0;
while($i<16)
{
	$mcs_index = "mcs_".$i;
	$$mcs_index = "MCS ".$i;
	$i++;
}
$j=0;
while($j<10)
{
	$mcs_index2 = "mcs_".$j."_nss1";
	$$mcs_index2 = "MCS ".$j."-nss1";
	$mcs_index3 = "mcs_".$j."_nss2";
	$$mcs_index3 = "MCS ".$j."-nss2";
	$j++;
}
$m_nac_enable = "802.11n/ac優先";
$m_nac_time = "延遲時間";
$m_nac_timeout = "超時時間";

$a_invalid_preferred_5g_rssi = "頻段轉換RSSI' 的範圍為從-100到0。";
$a_preferred_5g_rssi_range = "頻段轉換RSSI值為0~100之間。";
$a_invalid_preferred_5g_age = "頻段轉換壽命值為數位。";
$a_preferred_5g_age_range = "頻段轉換壽命值為0~600之間。";
$a_invalid_preferred_5g_diff = "頻段轉換差值為數位。";
$a_preferred_5g_diff_range = "頻段轉換差值為0~32之間。";
$a_invalid_preferred_5g_refuse = "頻段轉換拒絕數值為數位。";
$a_preferred_5g_refuse_range = "頻段轉換拒絕數值為0~10之間。";
$a_invalid_limit_num    ="'用戶限制'的範圍為從0至64。";
$a_invalid_nac_time = "802.11n/ac延遲時間為數位。";
$a_invalid_nac_timeout = "802.11n/ac超時間為數位。";
$a_invalid_rssi_threshod = "RSSI閾值為 -95 到 -53之間。";
$a_invalid_nac_timeout_range = "802.11n/ac超時值必須大於10。";
?>
