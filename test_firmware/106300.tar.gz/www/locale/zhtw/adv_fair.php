<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIRELESS";
/* ---------------------------------------------------------------------- */
$m_context_title		="頻寬控制";
$m_enable_fair		="啟用頻寬控制";
$m_Trafficmanage_type		="Traffic Control Type";

$m_disable    = "禁用";
$m_enable    = "啟用";

$m_context_band_title = "按頻段控制頻寬";
$m_context_ssid_title = "按SSID控制頻寬";
$m_perband = "啟用按頻段設置頻寬";
$m_average="規則類型       ";
$m_averagetype_s="為每個網站平均分配頻寬";
$m_averagetype_fssid="為SSID分配指定頻寬";
if(query("/wlan/inf:2/ap_mode") != "")
{
	$m_averagetype_fw="為11a/b/g/n網站分配不同的頻寬";
}
else
{
	$m_averagetype_fw="為11b/g/n網站分配不同的頻寬";
}
$m_averagetype_fstation="為每個網站分配最大頻寬";
$m_pri_ssid = "主SSID";
$m_ms_ssid1 = "SSID 1";
$m_ms_ssid2 = "SSID 2";
$m_ms_ssid3 = "SSID 3";
$m_ms_ssid4 = "SSID 4";
$m_ms_ssid5 = "SSID 5";
$m_ms_ssid6 = "SSID 6";
$m_ms_ssid7 = "SSID 7";
$m_ms_ssid8 = "SSID 8";
$m_ms_ssid9 = "SSID 9";
$m_ms_ssid10 = "SSID 10";
$m_ms_ssid11 = "SSID 11";
$m_ms_ssid12 = "SSID 12";
$m_ms_ssid13 = "SSID 13";
$m_ms_ssid14 = "SSID 14";
$m_ms_ssid15 = "SSID 15";
$m_ssid = "SSID";
$m_ssidindex = "SSID索引";
$m_band = "頻段";
$m_band_2_4G = "2.4 GHz";
$m_band_5G = "5 GHz";
$m_n="80211n";
$m_b="80211b";
$m_g="80211g";
$m_a="80211a";
$m_100="100%";
$m_50="50%";
$m_30="30%";
$m_10="10%";
$m_0="0%";

$m_speed_m="Mbits/sec";
$m_speed_k="Kbits/sec";
$m_Comment ="Comment";

$m_context_add_title		="添加頻寬優先規則";
$m_context_qos_title		="按SSID控制頻寬列表";
$m_type ="類型"; 
$m_b_add		="新增";
$m_b_cancel		="清除";
$a_disable_trafficctrl = "如果啟用頻寬控制，流量管理和QoS將被禁用。";
$a_empty_value_for_bandwidth = "請輸入下行頻寬和上行頻寬！";
$a_empty_value_for_two_speed = "請輸入下行速率和上行速率。";
$a_rule_del_confirm	="您確認想要刪除此條規則？";
$a_invalid_value_for_bandwidth  ="頻寬為無效值！";
$a_invalid_range_for_bandwidth_st = "頻寬範圍0~";
$a_invalid_range_for_bandwidth_end = " Mbits/sec.";
$a_primaryless_value_for_bandwidth ="頻寬不可以小於頻寬控制規則中最大速率。";
$a_GreaterThanPrimary_value_for_speed ="頻寬控制規則的頻寬速率不可小於1Kbits/秒，或大於頻寬。";
$a_invalid_value_for_speed  ="速率為無效值！";
$a_Rule_maxnum = "您所添加的規則數量不能多於64條！";
$a_Dynamic_flow_max ="動態流量為最大總流量！";
$a_invalid_value_for_bandwidth_perband  ="頻寬為無效值!";
$a_GreaterThanPrimary_value_for_speed_perband ="按頻段設置的頻寬值必須大於1 Kbits/秒，且小於總頻寬值!";
$m_DownlinkInterface = "下行頻寬";
$m_UplinkInterface = "上行頻寬";
$m_edit = "編輯";
$m_del = "刪除";
$m_Downlink_Speed		="下行速率";
$m_Uplink_Speed		="上行速率";
?>
