<?
$m_context_title = "動態集區設定";
$m_srv_enable = "功能啟動/取消";
$m_disable = "取消";
$m_enable = "啟動";
$m_dhcp_srv = "動態主機設定通訊協定伺服器控制";
$m_dhcp_pool = "動態集區設定";
$m_ipaddr = "IP分配來自";
$m_iprange ="集區的範圍（1-254）";
$m_ipmask = "子網路遮罩";
$m_gateway = "閘道器";
$m_wins = "微軟視窗網際絡路名稱服務";
$m_dns = "網域名稱系統";
$m_m_domain_name = "網域名稱";
$m_m_lease_time = "租用時間(60-31536000秒)";
$m_on = "開";
$m_off = "關";
$m_status_enable = "狀態";
$m_index = "索引";
$m_pri_ssid = "主要服務設定識別碼";
$m_ms_ssid1 = "服務設定識別碼 1";
$m_ms_ssid2 = "服務設定識別碼 2";
$m_ms_ssid3 = "服務設定識別碼 3";
$m_ms_ssid4 = "服務設定識別碼 4";
$m_ms_ssid5 = "服務設定識別碼 5";
$m_ms_ssid6 = "服務設定識別碼 6";
$m_ms_ssid7 = "服務設定識別碼 7";
$m_ssid = "服務設定識別碼";
$m_multi_dhcp = "多重動態主機設定通訊協定控制";
$m_multi_dhcp_enable ="多重動態主機設定通訊協定啟動/取消";
$m_multi_srv_enable ="多重動態主機設定通訊協定伺服器啟動/取消";
$m_multi_dhcp_srv = "多重動態主機設定通訊協定伺服器控制";
$m_index="索引";


$a_invalid_ip		= "IP位址無效 !";
$a_invalid_ip_range	= "IP範圍無效 !";
$a_invalid_netmask	= "子網路遮罩無效 !";
$a_invalid_gateway	="閘道器無效 !";
$a_invalid_wins	= "微軟視窗網際絡路名稱服務無效 !";
$a_invalid_dns	="網域名稱系統無效 !";
$a_invalid_domain_name	= "網域名稱無效 !";
$a_invalid_lease_time	= "動態主機設定通訊協定租用時間無效 !";

?>
