<?
$m_context_title = "Login Page Upload";
$m_upload_style_titles = "Upload Login Style From Local Hard Drive";
$m_upload_style_file = "Upload Login Style from file";
$m_upload = "Upload";
$m_left = "The Left space";
$m_byte = " Byte(s)";
$m_style_list = "Login Page Style List";
$m_id = "ID";
$m_name = "Style Name";
$m_download = "Download";
$m_del = "Del";
$m_per_ssid_title = "Select Style for each SSID Index";
$m_band = "Wireless Band";
$m_2_4g = " 2.4GHz";
$m_5g = " 5GHz";
$m_pri = "Pri";
$m_s1 = "S-1";
$m_s2 = "S-2";
$m_s3 = "S-3";
$m_s4 = "S-4";
$m_s5 = "S-5";
$m_s6 = "S-6";
$m_s7 = "S-7";
$m_select_style = "Select Login Style";
$m_pages_default = "pages_default.tar";
$m_pages_headerpic = "pages_headerpic.tar";
$m_pages_license = "pages_license.tar";
$m_pages_default_st = "pages_default";
$m_pages_headerpic_st = "pages_headerpic";
$m_pages_license_st = "pages_license";

$a_del_confirm      = "Are you sure that you want to delete this style?";
$a_invalid_style = "File extension error! It must be \\\".tar\\\" . Please try again!";
$a_same_rule = "This rule name has already exist in list!";
?>
