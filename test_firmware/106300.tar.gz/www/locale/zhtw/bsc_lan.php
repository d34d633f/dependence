<?
$m_context_title = "區域網路設定";

$m_lan_type  = "設定IP位址";
$m_static_ip = "手動設定IP位址";
$m_dhcp      = "自動取的IP位址";

$m_ipaddr    = "IP位址";
$m_subnet    = "子網路遮罩";
$m_gateway   = "預設閘道";
$m_dns		 = "DNS";
$m_backup_ip = "備用IP位址";

$a_invalid_ip= "不合法的IP位址!";
$a_invalid_netmask= "不合法的子網路遮罩!";
$a_invalid_gateway= "不合法的閘道位址!";
$a_invalid_dns= "Invalid DNS !";
$a_connect_new_ip = "請用新的IP位址建立連線!";
$a_ip_mask_not_match = "IP地址和Mask地址不匹配!";
$a_ip_gateway = "閘道地址不能和IP地址相同。";
$a_ip_dns = "DNS地址不能和IP地址相同。";
?>
