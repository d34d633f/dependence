<?
$m_lan1 = "LAN1";
$m_lan2 = "LAN2";
$msg_title="乙太網路流量狀態";
$msg_t_title="傳送計數";
$msg_r_title="接收計數";
$msg_T_Packet="傳送封包計數";
$msg_T_Bytes="傳送位元組計數";
$msg_T_Dropped_Packet="丟棄封包計數";
$msg_R_Packet="接收封包計數";
$msg_R_Bytes="接收位元組計數";
$msg_R_Dropped_Packet="丟棄封包計數";
$msg_R_Multicast_Packet="接收多重封包計數";
$msg_R_Broadcast_Packet="接收廣播封包計數";
$msg_Len_64="長度64封包計數";
$msg_Len_65_127="長度65~127封包計數";
$msg_Len_128_255="長度128~255封包計數";
$msg_Len_256_511="長度256~511封包計數";
$msg_Len_512_1023="長度512~1023封包計數";
$msg_Len_1024_1518="長度1024~1518封包計數";
$msg_Len_1519_MAX="長度1519~MAX封包計數";
$msg_clear="清除";
$msg_refresh="更新";
?>
