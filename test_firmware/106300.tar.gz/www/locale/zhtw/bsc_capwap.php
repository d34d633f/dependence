<?
$m_context_title = "CAPWAP Settings";

$m_enable_capwap = "Enable CAPWAP";
$m_stp = "STP";
$m_disable = "Disable";
$m_enable = "Enable";
$m_hw_version = "Hardware Version";
$m_company = "Company";
$m_sys_model = "System Model";
$m_prefix = "Domain Prefix";
$m_discover_mode = "Discover Mode";
$m_auto = "Auto";
$m_dhcp_60 = "DHCP Option 60";
$m_dhcp_43 = "DHCP Option 43";
$m_broadcast = "Broadcast";
$m_dns = "DNS";
$m_static = "Static";
$m_refresh = "Refresh";

$m_dns_setting = "DNS Setting";
$m_domain_name = "Domain Name";
$m_ipv4 = "IPv4";
$m_ipv6 = "IPv6";
$m_dns_addr = "DNS Server";
$m_static_setting = "Staitc Setting";
$m_ip_addr = "IP Address";

$a_blank_name = "The name can't be blank!";
$a_first_blank_name = "The first character can't be blank.";
$a_invalid_name = "There are some invalid characters in the Name field. Please check it.";
$a_invalid_ip = "Invalid IP Address!";
$a_invalid_hw_ver = "Invalid hardware version!";
$a_invalid_company = "Invalid company name!";
$a_invalid_prefix = "Invalid domain prefix!";
$a_invalid_sys_model = "Invalid system model!";
?>
