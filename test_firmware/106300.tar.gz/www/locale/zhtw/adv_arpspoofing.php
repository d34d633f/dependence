﻿<?
$m_context_title = "ARP欺騙預防設置";
$m_arp_spoofing = "ARP欺騙預防";
$m_disable = "關閉";
$m_enable = "啟用";
$m_add_title = "加入閘道位址";
$m_gateway_ip = "閘道IP地址";
$m_gateway_mac = "閘道MAC地址";
$m_add = "新增";
$m_clear = "清除";
$m_list_title ="閘道位址清單";
$m_total_entries = "總數";
$m_del_all = "刪除所有";
$m_edit = "編輯";
$m_delete = "刪除";

$a_rule_del_all_confirm = "確定刪除所有記錄？";
$a_empty_ip_addr = "請輸入IP位址!";
$a_invalid_ip = "無效IP地址!";
$a_can_not_same_ip = "IP位址已被添加入清單!";
$a_empty_mac_addr = "請輸入MAC位址!";
$a_invalid_mac = "無效MAC地址!";
$a_can_not_same_mac = "MAC位址已被添加入清單!";
$a_confirm_delete = "您確認要刪除此規則？";
?> 