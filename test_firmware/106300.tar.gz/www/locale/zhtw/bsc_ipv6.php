<?
$m_context_title = "IPv6設置";
$m_enable_ipv6  = "開啟IPv6";
$m_lan_type  = "獲得IP途徑";
$m_static_ip = "靜態";
$m_auto      = "自動";

$m_ipaddr    = "IP地址";
$m_subnet    = "首碼";
$m_dns   	 = "DNS";
$m_gateway   = "預設閘道器";

$a_invalid_ip= "無效的IP地址!";
$a_invalid_netmask= "無效首碼!";
$a_invalid_dns= "無效的DNS!";
$a_invalid_gateway= "無效的閘道！";
$a_connect_new_ip = "請用新IP位址連接!";
$a_enable_ipv6 = "如果啟用IPv6，AP用戶端將被設置到接入點。";
?>
