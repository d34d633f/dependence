<?
/* ---------------------------------------------------------------------- */
//$TITLE=$m_pre_title."WIRELESS";
/* ---------------------------------------------------------------------- */
$m_context_title		="流量管理";
$m_Trafficmanage		="流量管理";
$m_Trafficmanage_type		="Traffic Manager Type";

$m_TrafficmanageDisa    = "關閉";
$m_TrafficmanageEnable    = "開啟";
$m_UnlistedClientsTraffic = "表格外的使用者";
$m_Trafficmanage_type_s = "Specify Station";
$m_Trafficmanage_type_a = "Station Average";

$m_deny = "拒絕";
$m_forward = "同意";

$m_average="Average Type       ";
$m_averagetype_s="Static";
$m_averagetype_d="Dynamic";
$m_pri_ssid = "Primary SSID";
$m_ms_ssid1 = "SSID 1";
$m_ms_ssid2 = "SSID 2";
$m_ms_ssid3 = "SSID 3";
$m_ms_ssid4 = "SSID 4";
$m_ms_ssid5 = "SSID 5";
$m_ms_ssid6 = "SSID 6";
$m_ms_ssid7 = "SSID 7";
$m_ssid = "SSID";
$m_band = "Band";
$m_band_2_4G = "2.4 GHz";
$m_band_5G = "5 GHz";

$m_DownlinkInterface = "有線到無線";
$m_DownlinkInterface1 ="Wlan0";
$m_UplinkInterface = "無線到有線";
$m_UplinkInterface1 ="Eth0";

//$m_ClientIP ="Client IP";

//$m_ClientMac ="Client MAC";
$m_speed_m="Mbits/sec";
$m_speed_k="Kbits/sec";
$m_Downlink  = "Ethernet to Wireless";
$m_Uplink ="Wireless to Ethernet";
$m_Comment ="Comment";

$m_context_add_title		="加入流量管理資料";
$m_context_qos_title		="流量管理資料";
$m_enable		="開啟流量管理";
$a_invalid_mac		="無效MAC地址!";
$m_auto		="自動";
$m_auto_msg	="(如果沒有其它相匹配則顯示預設) ";
$m_name		="名字";
$m_type ="Type"; 
$m_SourceAddressIp	="用戶IP";
$m_SourceAddressMac	="用戶MAC";
//$m_Downlink_Speed		="Ethernet to Wireless Speed";
//$m_Uplink_Speed		="Wireless to Ethernet Speed";
$m_b_add		="新增";
$m_b_cancel		="清除";
$a_rule_del_confirm	="確定刪除";
$a_rule_state_confirm ="您確認要啟用/禁用";
$a_invalid_name		= "名稱中有無效字元。請檢查";
$a_first_blank_name		= "第一個字元不能為空。";
$a_invalid_ip		= "無效IP地址!";
$a_invalid_ip_range		= "無效IP地址範圍!";
$Reason_trfficmgr_cnt_enable = "流量管理不能被啟用，由於QoS被啟用且根據LAN埠優先！";
$a_empty_value_for_speed	="請輸入速率值！";
$a_invalid_value_for_speed	="無效速率值!";
$a_invalid_range_for_speed  ="流量管理頻寬範圍必須1~120百萬bits/秒。";
$a_primaryless_value_for_speed ="流量管理頻寬必須大於流量管理清單中的最大頻寬!";
$a_GreaterThanPrimary_value_for_speed ="流量管理清單中頻寬必須大於1 Mbits/秒,也必須小於流量管理頻寬!";
$a_Rule_maxnum = "清單數最大值為64!";
$a_same_tmrule_ip = "IP位址已被加入清單!";
$a_same_tmrule_mac = "MAC位址已被加入清單!";
$a_Dynamic_flow_max ="動態流量為最大總流量！";

$m_can_not_enable = "當上行下行設定中上行和下行值為空時不能啟用流量管理!";
$a_disable_fair = "啟用流量管理時必須禁用頻寬優化!";
$m_DownlinkInterface = "下行頻寬";
$m_UplinkInterface = "上行頻寬";
$m_edit = "編輯";
$m_del = "刪除";
$m_ClientIP ="用戶IP(可選))";
$m_ClientMac ="用戶MAC(可選)";
$m_Downlink_Speed		="下行速率";
$m_Uplink_Speed		="上行速率";
$a_empty_ip_or_mac_address = "請輸入IP位址或者MAC位址!";
$a_empty_value_for_two_speed = "請輸入有線到無線速率或者無線到有線速率!";
$a_empty_dn_or_up = "請輸入下行速率或上行速率!";
$a_blank_name = "名稱不能為空!";
$a_can_not_same_name = "不能使用同一個名稱!";
/*$		="";*/
?>
