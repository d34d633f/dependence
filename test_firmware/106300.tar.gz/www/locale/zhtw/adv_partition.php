<?
$m_context_title = "無線分割";
$m_isc = "內部站台連接";
$m_guest = "訪客模式";
$m_ewa = "乙太網路對無線區域網路的連線";
$m_enable = "啟動";
$m_disable = "取消";
$m_band = "無線頻帶";
$m_band_5G = "5GHz";
$m_band_2.4G = "2.4GHz";
$m_link_integrality="連結整體度";
$m_pri_ssid = "SSID";
$m_ms_ssid1 = "SSID 1";
$m_ms_ssid2 = "SSID 2";
$m_ms_ssid3 = "SSID 3";
$m_ms_ssid4 = "SSID 4";
$m_ms_ssid5 = "SSID 5";
$m_ms_ssid6 = "SSID 6";
$m_ms_ssid7 = "SSID 7";
$m_ms_ssid8 = "SSID 8";
$m_ms_ssid9 = "SSID 9";
$m_ms_ssid10 = "SSID 10";
$m_ms_ssid11 = "SSID 11";
$m_ms_ssid12 = "SSID 12";
$m_ms_ssid13 = "SSID 13";
$m_ms_ssid14 = "SSID 14";
$m_ms_ssid15 = "SSID 15";


$a_will_block_packets = "AP會過濾掉除DHCP意外的所有從有線到無線的多播/廣播包。";
?>
