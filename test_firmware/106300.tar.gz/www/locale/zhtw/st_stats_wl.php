<?
$m_band_2.4G = "2.4GHz";
$m_band_5G = "5GHz";

$msg_title="無線網路流量狀態";
$msg_t_title="傳送計數";
$msg_t_msg1="傳送封包計數";
$msg_t_msg2="傳送位元組計數";
$msg_t_msg3="丟棄封包計數";
$msg_t_msg4="重新接收計數";
$msg_r_title="接收計數";
$msg_r_msg1="接收封包計數";
$msg_r_msg2="接收位元組計數";
$msg_r_msg3="丟棄封包計數";
$msg_r_msg4="接收CRC計數";
$msg_r_msg5="接收解密錯誤計數";
$msg_r_msg6="接收MIC錯誤計數";
$msg_r_msg7="接收PHY錯誤計數";
$msg_clear="清除";
$msg_refresh="更新";

$msg_mssid_title = "每个SSID流量狀態";
$m_pri = "主SSID";
$m_m1 = "SSID 1";
$m_m2 = "SSID 2";
$m_m3 = "SSID 3";
$m_m4 = "SSID 4";
$m_m5 = "SSID 5";
$m_m6 = "SSID 6";
$m_m7 = "SSID 7";
$m_m8 = "SSID 8";
$m_m9 = "SSID 9";
$m_m10 = "SSID 10";
$m_m11 = "SSID 11";
$m_m12 = "SSID 12";
$m_m13 = "SSID 13";
$m_m14 = "SSID 14";
$m_m15 = "SSID 15";


?>
