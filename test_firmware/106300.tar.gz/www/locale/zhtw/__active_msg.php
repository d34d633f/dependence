作業正在處理中...<br><br>
<font color=red><b>勿關閉</b></font>裝置電源.<br><br>
請靜待
<input type='Text' readonly name='WaitInfo' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
秒 
<? if($change_ip=="1") 
	{
		echo "<br><br>then access the device with new IP Address."; 	
	}?>...
