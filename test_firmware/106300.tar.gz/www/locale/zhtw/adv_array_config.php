<?
$m_context_title= "AP Array Configuration";
$m_enable_config = "Enable AP Array Configuration";
$m_disable = "Disable";
$m_enable = "Enable";
$m_clear_all = "Clear all";

$m_wireless_basic_setting = "Wireless Basic Settings";
$m_mode = "Mode";
$m_captival_profile ="Captive Profile";
$m_wl_enable = "Wireless";
$m_wlmode = "Wireless Mode";
$m_network_name = "Network Name (SSID)";
$m_ssid_visibility = "SSID Visibility";
$m_operating_frequency = "Operating Frequency";
$m_auto_chann = "Auto Channel Selection";
$m_channel = "Channel";
$m_channel_width = "Channel Width";
$m_security = "Security";
$m_band = "Band";

$m_wireless_adv_setting = "Wireless Advanced Settings";
$m_wireless_mode = "Wireless Mode";
$m_data_rate = "Data Rate";
$m_captival_portal = "Captive Portal";
$m_arp_spoofing = "ARP Spoofing Prevention";
$m_fair_air_time = "Bandwidth Optimization";
$m_updown_link = "Uplink/Downlink Settings";
$m_beacon_interval = "Beacon Interval";
$m_dtim = "DTIM Interval";
$m_transmit_power = "Transmit Power";
$m_wmm_wifi = "WMM (Wi-Fi Multimedia)";
$m_ack_timeout = "Ack Time Out";
$m_short_gi = "Short GI"; 
$m_igmp = "IGMP Snooping";
$m_link_integrity = "Link Integrity";
$m_conn_limit = "Connection Limit";
$m_acl = "Wireless ACL";

$m_mssid_vlan = "Multiple SSID & VLAN";
$m_ssid = "SSID";
$m_ssid_visibility = "SSID Visibility";
$m_security = "Security";
$m_wmm = "WMM"; 
$m_vlan = "VLAN";

$m_adv_func = "Advanced Functions";
$m_schedule_settings = "Schedule Settings";
$m_qos_setting = "QoS Settings";
$m_dhcp_svr_setting = "DHCP server Settings";
$m_arrayauth = "AP Array Authentication";
$m_autorf = "Auto RF";
$m_loadbalance = "Load Balance";
$m_log_setting = "Log Settings";
$m_time_date = "Time and Date Settings";

$m_admin_setting = "Administration Settings";
$m_limit_admin = "Limit Administrator";
$m_sys_name_setting = "System Name Settings";
$m_login_setting = "Login Settings";
$m_console_setting = "Console Settings";
$m_snmp_setting = "SNMP Settings";
$m_ping_control_setting = "Ping Control Setting"; 
?>
