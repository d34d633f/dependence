<?
$m_context_title = "內部RADIUS伺服器";
$m_radius_state = "加入RADIUS條目";
$m_account_title = "加入RADIUS條目";
$m_name = "用戶名";
$m_password = "金鑰";
$m_list_title = "RADIUS條目清單";
$m_add = "新增";
$m_edit = "(編輯)";
$m_delete = "刪除";
$m_enable = "啟用";
$m_disable = "關閉";
$m_status = "狀態";
$a_can_not_same_name = "不能使用同樣的名稱!";
$a_max_account_number = "條目最多為256條!";
$a_empty_user_name ="請輸入用戶名。";
$a_invalid_name     = "在名稱欄位中有無效字元。請檢查。";
$a_first_end_blank  = "第一個和最後一個字元不能為空。";
$a_invalid_password_len	= "金鑰的長度應為8~64。";
$a_invalid_password	= "金鑰應為ASCII碼。";
$a_confirm_delete = "您確認想要刪除此條規則？";
?>
