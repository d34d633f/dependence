<?
$m_context_title = "頻譜分析";
$m_band = "頻率";
$m_wireless_band = "無線頻率";
$m_band_2_4G = "2.4GHz";
$m_band_5G = "5GHz";
$m_detect = "檢測";
$m_cochannel = "同頻干擾AP資訊";
$m_adjchannel = "鄰頻干擾AP資訊";
$m_wlandev = "WLAN設備干擾";
$m_nonwlandev = "非WLAN設備干擾";
$m_index = "編號";
$m_rssi = "RSSI";
$m_channel = "頻道";
$m_mac = "MAC位址";
$m_ssid = "SSID";
$m_noise = "干擾強度";
$m_time = "時間";
?>
