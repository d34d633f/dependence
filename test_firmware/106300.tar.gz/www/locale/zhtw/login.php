<?
$a_invalid_user_name	="請輸入使用者名稱。";

$m_html_title		="登入";
$m_context_title	="登入";
$m_login_router		="登入至路由器:";
$m_login_ap		="登入至無線基地台:";
$m_log_in		=" 登入 ";
?>
