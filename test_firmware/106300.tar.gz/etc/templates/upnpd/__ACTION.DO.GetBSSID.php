<NewBSSID><?
	query("/runtime/wan/inf:1/mac");
?></NewBSSID>