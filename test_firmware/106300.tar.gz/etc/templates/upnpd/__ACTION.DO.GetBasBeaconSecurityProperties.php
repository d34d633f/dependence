<NewBasicEncryptionModes>None</NewBasicEncryptionModes>
<NewBasicAuthenticationMode>None</NewBasicAuthenticationMode>