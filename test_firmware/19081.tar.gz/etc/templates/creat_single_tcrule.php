#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");

$create_downlink = "/var/run/create_downlink";
$create_uplink = "/var/run/create_uplink";
$tm_downlink = "/var/run/tm_downlink";
$tm_uplink = "/var/run/tm_uplink";
$TC="tc";
$K=kbit;
$markid= query("/runtime/stats/trafficctrl/curmarkid");	

$debugTc= query("/runtime/stats/trafficctrl/debugTc");	

if($debugTc!="")
{
  $TC=$debugTc;
}
if($markid !="")
{
$temmarkid=$markid+11;   /*from 11 to 26*/
$classid="1:".$temmarkid;
$downclassid="2:".$temmarkid;
$index = 0;
$all_uplink = 0;
$all_downlink = 0;
$MssidIdx=1;

$UPLINK_INF = "veth2";
$DOWNLINK_INF = "veth3";

$posoffset=query("/runtime/stats/wtp/trafficctrl/trafficrule:".$markid."/posoffset");
$usingoffset=0;
if($posoffset=="") {$posoffset=0;
}else
{
$usingoffset=1;
}
$mac3=3+$posoffset;
$mac4=4+$posoffset;
$mac5=5+$posoffset;
$mac6=6+$posoffset;
$mac7=7+$posoffset;
$mac8=8+$posoffset;
$mac9=9+$posoffset;
$mac10=10+$posoffset;
$mac11=11+$posoffset;
$mac12=12+$posoffset;
$mac13=13+$posoffset;
$mac14=14+$posoffset;

$trafficmgr_run = query("/runtime/stats/trafficctrl/trafficmgr_run");
$ruleenable=query("/trafficctrl/trafficrule:".$MssidIdx."/enable");
  
if($trafficmgr_run == 1){
   if($ruleenable ==1)
   {
	/* ip filter option */


	/* create DOWNLINK queues and filters, line num is the filter priority */


	echo "echo while read prio limit ip mac >> ".$create_downlink." \n";
	echo "echo do >> ".$create_downlink." \n";
	echo "echo { >> ".$create_downlink." \n";

	echo "echo \"	\"".$TC." class add dev ".$DOWNLINK_INF." parent ".$downclassid." classid 2:".$temmarkid."'\"$prio\"' htb prio 8 rate '\"$limit\"'".$K." ceil '\"$limit\"'".$K." burst 20k cburst 20k >> ".$create_downlink." \n";
	echo "echo \"	\"opt_src_ip='\"\"' >> ".$create_downlink." \n";
	echo "echo \"	\"opt_dst_ip='\"\"' >> ".$create_downlink." \n";
	echo "echo \"	\"opt_src_mac='\"\"' >> ".$create_downlink." \n";
	echo "echo \"	\"opt_dst_mac='\"\"' >> ".$create_downlink." \n";
	echo "echo \"	\"opt_src_mac1='\"\"' >> ".$create_downlink." \n";
	echo "echo \"	\"opt_dst_mac2='\"\"' >> ".$create_downlink." \n";

	/* ip filter option */
      /*
	echo "echo \"	\"if [ '\"$ip\"' != \\\"0.0.0.0\\\" ] >> ".$create_uplink." \n";
	echo "echo \"	\"then >> ".$create_uplink." \n";
	
	echo "echo \"		\"opt_src_ip='\"match ip src $ip/1\"' >> ".$create_downlink." \n";
	echo "echo \"		\"opt_dst_ip='\"match ip dst $ip/1\"' >> ".$create_downlink." \n";
		
	echo "echo \"	\"fi >> ".$create_downlink." \n";
       */
	/* mac filter option */
	
	echo "echo \"	\"if [ '\"$mac\"' != \\\"00:00:00:00:00:00\\\" ] >> ".$create_downlink." \n";
	echo "echo \"	\"then >> ".$create_downlink." \n";
	echo "echo \"		\"tfmgr_mac='\"$mac\"' >> ".$create_downlink." \n";
	echo "echo \"		\"tfmgr_mac1='`echo $tfmgr_mac | cut -c1-2`'  >> ".$create_downlink." \n";
	echo "echo \"		\"tfmgr_mac2='`echo $tfmgr_mac | cut -c4-5`'  >> ".$create_downlink." \n";
	echo "echo \"		\"tfmgr_mac3='`echo $tfmgr_mac | cut -c7-8`'  >> ".$create_downlink." \n";
	echo "echo \"		\"tfmgr_mac4='`echo $tfmgr_mac | cut -c10-11`'  >> ".$create_downlink." \n";
	echo "echo \"		\"tfmgr_mac5='`echo $tfmgr_mac | cut -c13-14`'  >> ".$create_downlink." \n";
	echo "echo \"		\"tfmgr_mac6='`echo $tfmgr_mac | cut -c16-17`'  >> ".$create_downlink." \n";	
	echo "echo \"		\"opt_dst_mac='`echo match u8 0x$tfmgr_mac1 0xFF at -14 match u8 0x$tfmgr_mac2 0xFF at -13 match u8 0x$tfmgr_mac3 0xFF at -12 match u8 0x$tfmgr_mac4 0xFF at -11 match u8 0x$tfmgr_mac5 0xFF at -10 match u8 0x$tfmgr_mac6 0xFF at -9`' >> ".$create_downlink." \n";
	echo "echo \"		\"opt_src_mac='`echo match u8 0x$tfmgr_mac1 0xFF at -8 match u8 0x$tfmgr_mac2 0xFF at -7 match u8 0x$tfmgr_mac3 0xFF at -6 match u8 0x$tfmgr_mac4 0xFF at -5 match u8 0x$tfmgr_mac5 0xFF at -4 match u8 0x$tfmgr_mac6 0xFF at -3`' >> ".$create_downlink." \n";

	echo "echo \"		\"opt_dst_mac1='`echo match u8 0x$tfmgr_mac1 0xFF at -".$mac14." match u8 0x$tfmgr_mac2 0xFF at -".$mac13." match u8 0x$tfmgr_mac3 0xFF at -".$mac12." match u8 0x$tfmgr_mac4 0xFF at -".$mac11." match u8 0x$tfmgr_mac5 0xFF at -".$mac10." match u8 0x$tfmgr_mac6 0xFF at -".$mac9."`' >> ".$create_downlink." \n";
	echo "echo \"		\"opt_src_mac1='`echo match u8 0x$tfmgr_mac1 0xFF at -".$mac8." match u8 0x$tfmgr_mac2 0xFF at -".$mac7." match u8 0x$tfmgr_mac3 0xFF at -".$mac6." match u8 0x$tfmgr_mac4 0xFF at -".$mac5." match u8 0x$tfmgr_mac5 0xFF at -".$mac4." match u8 0x$tfmgr_mac6 0xFF at -".$mac3."`' >> ".$create_downlink." \n";
	echo "echo \"	\"fi >> ".$create_downlink." \n";
	
	/* add filter */
	
	echo "echo \"	\"".$TC." filter add dev ".$DOWNLINK_INF." protocol all parent ".$downclassid." prio '$prio' u32 '$opt_src_ip' '$opt_src_mac' flowid ".$downclassid."'$prio' >> ".$create_downlink." \n";
	echo "echo \"	\"".$TC." filter add dev ".$DOWNLINK_INF." protocol all parent ".$downclassid." prio '$prio' u32 '$opt_dst_ip' '$opt_dst_mac' flowid ".$downclassid."'$prio' >> ".$create_downlink." \n";

 	if($ruleenable ==1)
 	  {
 	  	/* add filter for tunel*/
	/*
	echo "echo \"	\"".$TC." filter add dev ".$UPLINK_INF." protocol all parent ".$downclassid." prio '$prio' u32 '$opt_src_ip' '$opt_src_mac1' flowid 1:".$temmarkid."'$prio' >> ".$create_downlink." \n";
	echo "echo \"	\"".$TC." filter add dev ".$UPLINK_INF." protocol all parent ".$downclassid." prio '$prio' u32 '$opt_dst_ip' '$opt_dst_mac1' flowid 1:".$temmarkid."'$prio' >> ".$create_downlink." \n";
       */
  	 }
	echo "echo } >> ".$create_downlink." \n";
	echo "echo done >> ".$create_downlink." \n";	
	echo "sh ".$create_downlink." < ".$tm_downlink." \n";

	
	/* create UPLINK queues and filters, line num is the filter priority */
	

	echo "echo while read prio limit ip mac >> ".$create_uplink." \n";
	echo "echo do >> ".$create_uplink." \n";
	echo "echo { >> ".$create_uplink." \n";
      
	echo "echo \"	\"".$TC." class add dev ".$UPLINK_INF." parent ".$classid." classid 1:".$temmarkid."'\"$prio\"' htb prio 8 rate '\"$limit\"'".$K." ceil '\"$limit\"'".$K." burst 20k cburst 20k >> ".$create_uplink." \n";
	echo "echo \"	\"opt_src_ip='\"\"' >> ".$create_uplink." \n";
	echo "echo \"	\"opt_dst_ip='\"\"' >> ".$create_uplink." \n";
	echo "echo \"	\"opt_src_mac='\"\"' >> ".$create_uplink." \n";
	echo "echo \"	\"opt_dst_mac='\"\"' >> ".$create_uplink." \n";
	echo "echo \"	\"opt_src_mac1='\"\"' >> ".$create_uplink." \n";
	echo "echo \"	\"opt_dst_mac2='\"\"' >> ".$create_uplink." \n";

	/* ip filter option */
	/*
	echo "echo \"	\"if [ '\"$ip\"' != \\\"0.0.0.0\\\" ] >> ".$create_uplink." \n";
	echo "echo \"	\"then >> ".$create_uplink." \n";
	echo "echo \"		\"opt_src_ip='\"match ip src $ip/1\"' >> ".$create_uplink." \n";
	echo "echo \"		\"opt_dst_ip='\"match ip dst $ip/1\"' >> ".$create_uplink." \n";
	echo "echo \"	\"fi >> ".$create_uplink." \n";
	*/
	/* mac filter option */
	echo "echo \"	\"if [ '\"$mac\"' != \\\"00:00:00:00:00:00\\\" ] >> ".$create_uplink." \n";
	echo "echo \"	\"then >> ".$create_uplink." \n";
	echo "echo \"		\"tfmgr_mac='\"$mac\"' >> ".$create_uplink." \n";
	echo "echo \"		\"tfmgr_mac1='`echo $tfmgr_mac | cut -c1-2`'  >> ".$create_uplink." \n";
	echo "echo \"		\"tfmgr_mac2='`echo $tfmgr_mac | cut -c4-5`'  >> ".$create_uplink." \n";
	echo "echo \"		\"tfmgr_mac3='`echo $tfmgr_mac | cut -c7-8`'  >> ".$create_uplink." \n";
	echo "echo \"		\"tfmgr_mac4='`echo $tfmgr_mac | cut -c10-11`'  >> ".$create_uplink." \n";
	echo "echo \"		\"tfmgr_mac5='`echo $tfmgr_mac | cut -c13-14`'  >> ".$create_uplink." \n";
	echo "echo \"		\"tfmgr_mac6='`echo $tfmgr_mac | cut -c16-17`'  >> ".$create_uplink." \n";	
	echo "echo \"		\"opt_dst_mac='`echo match u8 0x$tfmgr_mac1 0xFF at -14 match u8 0x$tfmgr_mac2 0xFF at -13 match u8 0x$tfmgr_mac3 0xFF at -12 match u8 0x$tfmgr_mac4 0xFF at -11 match u8 0x$tfmgr_mac5 0xFF at -10 match u8 0x$tfmgr_mac6 0xFF at -9`' >> ".$create_uplink." \n";
	echo "echo \"		\"opt_src_mac='`echo match u8 0x$tfmgr_mac1 0xFF at -8 match u8 0x$tfmgr_mac2 0xFF at -7 match u8 0x$tfmgr_mac3 0xFF at -6 match u8 0x$tfmgr_mac4 0xFF at -5 match u8 0x$tfmgr_mac5 0xFF at -4 match u8 0x$tfmgr_mac6 0xFF at -3`' >> ".$create_uplink." \n";

	echo "echo \"		\"opt_dst_mac1='`echo match u8 0x$tfmgr_mac1 0xFF at -".$mac14." match u8 0x$tfmgr_mac2 0xFF at -".$mac13." match u8 0x$tfmgr_mac3 0xFF at -".$mac12." match u8 0x$tfmgr_mac4 0xFF at -".$mac11." match u8 0x$tfmgr_mac5 0xFF at -".$mac10." match u8 0x$tfmgr_mac6 0xFF at -".$mac9."`' >> ".$create_uplink." \n";
	echo "echo \"		\"opt_src_mac1='`echo match u8 0x$tfmgr_mac1 0xFF at -".$mac8." match u8 0x$tfmgr_mac2 0xFF at -".$mac7." match u8 0x$tfmgr_mac3 0xFF at -".$mac6." match u8 0x$tfmgr_mac4 0xFF at -".$mac5." match u8 0x$tfmgr_mac5 0xFF at -".$mac4." match u8 0x$tfmgr_mac6 0xFF at -".$mac3."`' >> ".$create_uplink." \n";
	echo "echo \"	\"fi >> ".$create_uplink." \n";
	/* add filter */
	echo "echo \"	\"".$TC." filter add dev ".$UPLINK_INF." protocol all parent ".$classid." prio '$prio' u32 '$opt_src_ip' '$opt_src_mac' flowid 1:".$temmarkid."'$prio' >> ".$create_uplink." \n";
	echo "echo \"	\"".$TC." filter add dev ".$UPLINK_INF." protocol all parent ".$classid." prio '$prio' u32 '$opt_dst_ip' '$opt_dst_mac' flowid 1:".$temmarkid."'$prio' >> ".$create_uplink." \n";

 	if($ruleenable ==1)
 	  {
 	  	/* add filter for tunel*/
	/*
	echo "echo \"	\"".$TC." filter add dev ".$UPLINK_INF." protocol all parent ".$classid." prio '$prio' u32 '$opt_src_ip' '$opt_src_mac1' flowid 1:".$temmarkid."'$prio' >> ".$create_uplink." \n";
	echo "echo \"	\"".$TC." filter add dev ".$UPLINK_INF." protocol all parent ".$classid." prio '$prio' u32 '$opt_dst_ip' '$opt_dst_mac1' flowid 1:".$temmarkid."'$prio' >> ".$create_uplink." \n";
       */
  	 }
	
	echo "echo } >> ".$create_uplink." \n";
	echo "echo done >> ".$create_uplink." \n";	
	echo "sh ".$create_uplink." < ".$tm_uplink." \n";
	
	/*--- the default queue ---*/
	$default_index = 500;
	if($all_uplink >= $UPLINK){
		$default_uplink = 1;
	}
	else{
		$default_uplink = $UPLINK - $all_uplink;
	}


	/*
	echo $TC." class add dev ".$UPLINK_INF." parent ".$classid." classid 1:".$temmarkid.$default_index." htb prio 8 rate ".$default_uplink.$K." ceil 1".$K." burst 20k cburst 20k  \n";
	*/
       /*filter to default queue*/
      	/*
        echo $TC." filter add dev ".$UPLINK_INF." parent ".$classid."  protocol all prio 999 handle ".$temmarkid." fw flowid 1:".$temmarkid.$default_index." \n";
        */
     }else
     {
         echo "echo traffic manager is not enable for this Mssid. \n";
		exit;
     }
	
	}
       else{
       echo "echo traffic manager is not running. \n";
		exit;
	}
}
?>
