<? /* vi: set sw=4 ts=4: */

$g_mode = query($WLAN."/wlmode");    

if ($wlan_ap_operate_mode == 4)  // WDS without AP // WDSwithoutAP_bug_0321
{    $withoutap = 1; }
else  // ($WLAN == 3)  WDS with AP
{    $withoutap = 0; }


if ($generate_start==1)
{    
	echo "echo Start WLAN interface ".$wlanif." ... > /dev/console\n";
	
	// Disable IPv6 on wireless interface
	echo "echo \"1\" > /proc/sys/net/ipv6/conf/wifi0/disable_ipv6;\n";

	if (query("/wlan/inf:1/enable")!=1)
	{
		echo "echo WLAN is disabled ! > /dev/console\n";
		exit;
	}
	/* common cmd */
	$IWPRIV="iwpriv ".$wlanif;
	$IWCONF="iwconfig ".$wlanif;
	
	anchor("/wlan/inf:1");
	$channel = query("channel");         if (query("autochannel")==1) { $channel=0; }
	$bintval = query("beaconinterval");
	$cwmmode = query("cwmmode");
	$shortgi = query("shortgi");
	$g_mode = query("wlmode");
	$ssid = query("ssid");
	$ssidhidden = query("ssidhidden");
	$dtim       = query("dtim");
	$wmmenable  = query("wmm/enable");
	$perssidassoclimit  = query("/wlan/userlimit/perssid");
        if ( $perssidassoclimit == 1 )
        {
                $assoclimitenable   = query($WLAN."/userlimit:0/enable");
                $assoclimitnumber   = query($WLAN."/userlimit:0/number");
        }
        else
        {
        $assoclimitenable   = query("assoc_limit/enable");
        $assoclimitnumber   = query("assoc_limit/number");
        }
	$igmpsnoop = query("igmpsnoop");
	$wpartition = query("w_partition");
	$epartition = query("e_partition");
	$ethlink = query("ethlink");
	$fixedrate  = query("fixedrate");
	$mcastrate_a  = query("/wlan/inf:1/mcastrate_a");/*add for mcast rate by yuda*/
	$mcastrate_g  = query("/wlan/inf:1/mcastrate_g");/*add for mcast rate by yuda*/
	$autochannel = query("autochannel");
	$ampdu		= query("ampdu");
	$ampduframe	= query("ampdusframes");
	$ampdulimit	= query("ampdulimit");
	$ampdmin	= query("ampdmin");		
	$aniena		= query("aniena");
	$acktimeout = query("acktimeout_g");
	$txpower    = query("txpower");
	$multi_pri_state = query("multi/pri_by_ssid");
	$wds_pri_bit = query("pri_bit");
	$wepmode = query("/wlan/inf:1/wpa/wepmode");
	$zonedefence = query("zonedefence");
	$mcastrate  = query("mcastrate_g");/*add for mcast rate by yuda*/
	$coexistence=query("coexistence/enable");


	//Create the instance	
	echo "ifconfig wifi0 hw ether ".$wlanmac."\n";
	echo "wlanconfig ".$wlanif." create wlandev wifi0 wlanmode ap\n";
	//echo "ifconfig ".$wlanif." hw ether ".$wlanmac."\n";
	
	// Disable IPv6 on wireless interface
	echo "echo \"1\" > /proc/sys/net/ipv6/conf/".$wlanif."/disable_ipv6;\n";

	//Disable Background Scan
	//echo $IWPRIV." bgscan 0\n";
	//set debug mode output
	echo "iwpriv wifi0 HALDbg 0x0\n";
	echo "iwpriv wifi0 ATHDebug 0x0\n";
	echo $IWPRIV." dbgLVL 0x100\n";
	//common RF setting start
	echo "ifconfig ".$wlanif." txqueuelen 1000\n";
	echo "ifconfig wifi0 txqueuelen 1000\n";
	echo $IWPRIV." shortgi ".$shortgi." \n";
	echo "iwpriv wifi0 burst 1\n";
        echo "iwpriv wifi0 noisespuropt 1\n";

	if($autochannel==0)
	{
		if($channel>14)
		{
			$channel=6;
		}
	}

        //(20) 1:11g only, 2.b/g mode 3:11b only, 4:only n  5:b/g/n mix, 6:g/n mix
	if ($cwmmode == 0)
	{
        	if($g_mode == 5)	{echo $IWPRIV." mode 11NGHT20\n";}
            	else if($g_mode == 6) 	{echo $IWPRIV." mode 11NGHT20\n";}
            	else if($g_mode == 4)	{echo $IWPRIV." mode 11NGHT20\n";}
            	else if($g_mode == 2)	{echo $IWPRIV." mode 11G\n";}
            	else if($g_mode == 1) 	{echo $IWPRIV." mode 11G\n";}
            	else if($g_mode == 3) 	{echo $IWPRIV." mode 11B\n";}
            	else			{echo $IWPRIV." mode 11NGHT20\n";}
        }
        //5--->11bgn 6-->11gn 4--->only n	
        else//cwmmode=1 HT20/40 mode
	{
        	if($autochannel==1)	{echo $IWPRIV." mode 11NGHT40\n";}//autochannel enable
            	else//autochannel disable
		{ 
                	if($channel<5)	{echo $IWPRIV." mode 11NGHT40PLUS\n";}//channel 1~4
                	else if($channel<=11){echo $IWPRIV." mode 11NGHT40MINUS\n";}//channel 5~11
			else		{echo $IWPRIV." mode 11NGHT20\n";}//channel 12,13 for JP
            	}
        }
	//if in one of the 11NG bands that require ANI processing
	if($g_mode > 3)		{echo "iwpriv wifi0 ForBiasAuto 1\n";}
    	//Set Aggregation State
	if ($ampdu!="")		{echo "iwpriv wifi0 AMPDU ".$ampdu."\n";}
	else			{echo "iwpriv wifi0 AMPDU 1 \n";}
	//set number of sub-frames in an ampdu
	if ($ampduframe!="")	{echo "iwpriv wifi0 AMPDUFrames ".$ampduframe."\n";}	
	else			{echo "iwpriv wifi0 AMPDUFrames 32 \n";}
	//set ampdu limit
	if ($ampdulimit!="")	{echo "iwpriv wifi0 AMPDULim ".$ampdulimit."\n";}
	else			{echo "iwpriv wifi0 AMPDULim 50000 \n";}
	/*	
	if ($ampdumin!="")    {echo $IWPRIV." ampdumin ".$ampdumin."\n";    }
	else {echo $IWPRIV." ampdumin 32768 \n";}*/
	//1:11g only, 2.b/g mode 3:11b only, 4:only n  5:b/g/n mix, 6:g/n mix
	if($g_mode == 1)
	{
		echo "iwpriv ath0 puren 0\n";
		echo "iwpriv ath0 pureg 1\n";
	}
	else if($g_mode == 2)
	{
		echo "iwpriv ath0 puren 0\n";
		echo "iwpriv ath0 pureg 0\n";
	}		
	else if($g_mode == 4){
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 1\n";
		}
	else if($g_mode == 5)
	{
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 0\n";
	}
	else if($g_mode == 6)
	{
		echo "iwpriv ath0 pureg 1\n";
		echo "iwpriv ath0 puren 0\n";
	} 
	else
	{
		echo "iwpriv ath0 pureg 0\n";
		echo "iwpriv ath0 puren 0\n";
	}
	if($coexistence==1)	{echo $IWPRIV." disablecoext 0\n";}
	else			{echo $IWPRIV." disablecoext 1\n";}
	// set SSID and frequency
	echo $IWCONF." essid \"".get("s","/wlan/inf:1/ssid")."\" freq ".$channel."\n"; 

	echo $IWCONF." mode master \n";
	echo "iwpriv wifi0 noisespuropt 1\n";
	//Set the chain masks
	echo "iwpriv wifi0 txchainmask 3\n";//2T
	echo "iwpriv wifi0 rxchainmask 3\n";//2R
	// common RF setting end

	if ($ssidhidden!="")		{echo $IWPRIV." hide_ssid ".$ssidhidden."\n";}
	if ($dtim!="")			{echo $IWPRIV." dtim_period ".$dtim."\n";}
	if ($wmmenable>0)		{echo $IWPRIV." wmm 1\n";}
	else		        	{echo $IWPRIV." wmm 0\n";}
	if($assoclimitenable==1)	{echo $IWPRIV." assocenable 1\n";}
	else				{echo $IWPRIV." assocenable 0\n";}
	if($assoclimitnumber!="")	{echo $IWPRIV." assocnumber ".$assoclimitnumber."\n";}
	if ($epartition!="")		{echo "brctl e_partition br0 ".$epartition."\n";}
	else  				{echo "brctl e_partition br0 0\n"; }
	if ($wpartition==2)  /* guest mode*/
	{ 
	    	echo $IWPRIV." w_partition 1 \n"; 
        	echo "brctl w_partition br0 ".$wlanif." 1 \n";
	}
	else if ($wpartition==1)
	{ 
	    	echo $IWPRIV." w_partition 1 \n";
	    	echo "brctl w_partition br0 ".$wlanif." 0 \n";
	}
	else            
	{ 
	    	echo $IWPRIV." w_partition 0\n";
	    	echo "brctl w_partition br0 ".$wlanif." 0 \n";
	}
	//echo $IWPRIV." cwmmode ".$cwmmode."\n";
//	if ($aniena!="")	{echo "iwpriv wifi0 ANIEna ".$aniena."\n"; }
//	else 			{echo "iwpriv wifi0 ANIEna 0 \n";}
	echo "iwpriv wifi0 ANIEna 1 \n";

	echo $IWPRIV." doth 0\n";//no dfs for 2.4G
	/*erial mark
	echo "iwpriv ath0 staextoffset 0\n";*/
	echo $IWPRIV." countryie 1\n";	

	//echo "echo 1 > /proc/sys/dev/ath/htdupieenable\n";
	/*erial mark	
	echo "echo 2 > /proc/sys/dev/ath/hal/forceBias\n";*/
	if($bintval!="")	{echo $IWPRIV." bintval ".$bintval."\n";}
	else			{echo $IWPRIV." bintval 100\n";	}	
//2009_07_02 sandy++++	
	if($g_mode == 5 || $g_mode == 4)
	{
		  $fixedrate = 31;
		  set($WLAN."/fixedrate", $fixedrate);
	}
//2009_07_02 sandy----	
	/*0==1M;1==2M;2==5.5M;3==11M;4==6M;5==9M;6==12M;7==18M;8==24M;9==36M;10==48M;11==54M*/ 
	if  ($fixedrate<0)           {echo "iwpriv wifi0 fixedrate 0\n";}
	else if  ($fixedrate<12)     {echo "iwpriv wifi0 fixedrate ".$fixedrate."\n";}
	else                         {echo "iwpriv wifi0 fixedrate 31\n";}
	echo "iwpriv wifi0 acktimeout ".$acktimeout."\n";
	echo "brctl apc br0 0"."\n";
	echo $IWPRIV." apband 0\n"; //show ap band in wireless driver
	echo "sleep 1\n";
	require($template_root."/__wlan_acl.php");
        if ($multi_pri_state == 1) 
	{ 
        	echo $IWPRIV." pristate 1\n";
        	echo $IWPRIV." pribit ".$pri_bit."\n"; 
        }		
	echo $IWPRIV." wds 1\n";
	echo $IWPRIV." wdsalpha 1\n";
	echo $IWPRIV." wdsprobereq 0\n";
	if($withoutap == 1 ) { echo $IWPRIV." wdswithoutap 1\n"; }
	else	{ echo $IWPRIV." wdswithoutap 0\n"; }
	
/*add for mcast rate by yuda start*/
	if($mcastrate!=0){
    	if($mcastrate==1){
    		echo $IWPRIV." mcast_rate 1000\n";
    	}
    	else if($mcastrate==2){
    		echo $IWPRIV." mcast_rate 2000\n";
    	}
    	else if($mcastrate==3){
    		echo $IWPRIV." mcast_rate 5500\n";
    	}
    	else if($mcastrate==4){
    		echo $IWPRIV." mcast_rate 11000\n";
    	}
    	else if($mcastrate==5){
    		echo $IWPRIV." mcast_rate 6000\n";
    	}
    	else if($mcastrate==6){
    		echo $IWPRIV." mcast_rate 9000\n";
    	}
    	else if($mcastrate==7){
    		echo $IWPRIV." mcast_rate 12000\n";
    	}
    	else if($mcastrate==8){
    		echo $IWPRIV." mcast_rate 18000\n";
    	}
    	else if($mcastrate==9){
    		echo $IWPRIV." mcast_rate 24000\n";
    	}
    	else if($mcastrate==10){
    		echo $IWPRIV." mcast_rate 36000\n";
    	}
    	else if($mcastrate==11){
    		echo $IWPRIV." mcast_rate 48000\n";
    	}
    	else if($mcastrate==12){
    		echo $IWPRIV." mcast_rate 54000\n";
    	}
    	else if($mcastrate==13){
    		echo $IWPRIV." mcast_rate 6500\n";
    	}
    	else if($mcastrate==14){
    		echo $IWPRIV." mcast_rate 13000\n";
    	}
    	else if($mcastrate==15){
    		echo $IWPRIV." mcast_rate 19500\n";
    	}
    	else if($mcastrate==16){
    		echo $IWPRIV." mcast_rate 26000\n";
    	}
    	else if($mcastrate==17){
    		echo $IWPRIV." mcast_rate 39000\n";
    	}
    	else if($mcastrate==18){
    		echo $IWPRIV." mcast_rate 52000\n";
    	}
    	else if($mcastrate==19){
    		echo $IWPRIV." mcast_rate 58500\n";
    	}
    	else if($mcastrate==20){
    		echo $IWPRIV." mcast_rate 65000\n";
    	}
    	else if($mcastrate==21){
    		echo $IWPRIV." mcast_rate 78000\n";
    	}
    	else if($mcastrate==22){
    		echo $IWPRIV." mcast_rate 104000\n";
    	}
    	else if($mcastrate==23){
    		echo $IWPRIV." mcast_rate 117000\n";
    	}
    	else if($mcastrate==24){
    		echo $IWPRIV." mcast_rate 130000\n";
    	}
     	else {
    		echo $IWPRIV." mcast_rate 11000\n";
    	}   	
    	}        
    	/*add for mcast rate by yuda end*/
         $auth_mode = query($WLAN."/authentication");
	if ($auth_mode>1){  
		/*remove device up */
	}
	else {
	    require($template_root."/__auth_openshared.php"); 	
	}
    	if ($zonedefence==1){
		echo $IWPRIV." zonedefence 1\n";
		require($template_root."/zonedefence.php");
	}    
	else{
		echo $IWPRIV." zonedefence 0\n";
	}
    	require($template_root."/multi_ssid_run.php");  /* Jack add 13/11/08 init_MSSID_before_WDS multi-ssid should be init before WDS_VAP */
	
	$lan_mac = query("/runtime/layout/lanmac");
        anchor($WLAN);
        $auth_mode	= query("authentication");
        $keylength	= query("keylength");
        $defkey	= query("defkey");
      if($defkey==1){
           $keyformat  = query("wepkey:1/keyformat");
	   }
	  else if($defkey==2){
	        $keyformat  = query("wepkey:2/keyformat");
	   }
	 else if($defkey==3){
	        $keyformat  = query("wepkey:3/keyformat");
	   }
	 else if($defkey==4){
	        $keyformat  = query("wepkey:4/keyformat");
	  }
	 else{
	        $keyformat  = query("wepkey:1/keyformat");
	  }
        $wepmode	= query("wpa/wepmode");
        $index=7;
        $index_mac=0;
        $up_ath_cnt=0;
        $W_PATH=$WLAN."/";
	$ssid = query($WLAN."/ssid");
	$wpapsk = query($WLAN."/wpa/wpapsk");
        for ($WLAN."/wds/list/index")
        {      
            $index++;     
            $index_mac++;   
            $path="/wirelss/";
            $wds_mac = query($WLAN."/wds/list/index:".$index_mac."/mac");  
            if ($wds_mac!="")  
            {                  	
		   $up_ath_cnt++;
		    echo "\necho Add WDS ath".$index."... > /dev/console\n";
                    echo "wlanconfig ath".$index." create wlandev wifi0 wlanmode ap\n";
                    //echo "iwpriv ath".$index." bgscan 0\n";
		    echo "iwpriv ath".$index." dbgLVL 0x100\n";
                    /*iwconfig*/
                    echo "ifconfig ath".$index." txqueuelen 1000\n";
                    echo "ifconfig ath".$index." mtu 1504\n"; // for vlan over wds pass through                
                                    
                    if ($shortgi!="")    
                    {echo "iwpriv ath".$index." shortgi ".$shortgi."\n";	}
                    
                    echo "iwpriv ath".$index." wds 1\n";
                    echo "iwpriv ath".$index." wdsprobereq 1"."\n";
	            echo "iwpriv ath".$index." wdsalpha 1"."\n";
	            echo "iwpriv ath".$index." wdsaddmac ".$wds_mac."\n";
	            if($withoutap == 1 ) { echo "iwpriv ath".$index." wdswithoutap 1"."\n";}
	            else                 { echo "iwpriv ath".$index." wdswithoutap 0"."\n"; }	
                    if ($multi_pri_state == 1) { echo "iwpriv ath".$index." pribit ".$wds_pri_bit."\n";}                 
                    /*iwpriv*/
	        //(20) 1:11g only, 2.b/g mode 3:11b only, 4:only n  5:b/g/n mix, 6:g/n mix
		if ($cwmmode == 0)
		{
        		if($g_mode == 5)	{echo  "iwpriv ath".$index." mode 11NGHT20\n";}
            		else if($g_mode == 6) 	{echo  "iwpriv ath".$index." mode 11NGHT20\n";}
            		else if($g_mode == 4)	{echo  "iwpriv ath".$index." mode 11NGHT20\n";}
            		else if($g_mode == 2)	{echo  "iwpriv ath".$index." mode 11G\n";}
            		else if($g_mode == 1) 	{echo  "iwpriv ath".$index." mode 11G\n";}
            		else if($g_mode == 3) 	{echo  "iwpriv ath".$index." mode 11B\n";}
            		else			{echo  "iwpriv ath".$index." mode 11NGHT20\n";}
       	 	}
        	//5--->11bgn 6-->11gn 4--->only n	
        	else//cwmmode=1 HT20/40 mode
		{
        		if($autochannel==1)	{echo  "iwpriv ath".$index." mode 11NGHT40\n";}//autochannel enable
            		else//autochannel disable
			{ 
                		if($channel<5)	{echo  "iwpriv ath".$index." mode 11NGHT40PLUS\n";}//channel 1~4
                		else if($channel<=11){echo  "iwpriv ath".$index." mode 11NGHT40MINUS\n";}//channel 5~11
				else		{echo  "iwpriv ath".$index." mode 11NGHT20\n";}//channel 12,13 for JP
            		}
        	}
    		echo "iwconfig ath".$index." essid \"".get("s",$W_PATH."ssid")."\" mode master \n";
    		echo "iwconfig ath".$index." freq ".$channel."\n";
		//1:11g only, 2.b/g mode 3:11b only, 4:only n  5:b/g/n mix, 6:g/n mix
		if($g_mode == 1)
		{
			echo "iwpriv ath".$index." puren 0\n";
			echo "iwpriv ath".$index." pureg 1\n";
		}
		else if($g_mode == 2)
		{
			echo "iwpriv ath".$index." puren 0\n";
			echo "iwpriv ath".$index." pureg 0\n";
		}		
		else if($g_mode == 4){
			echo "iwpriv ath".$index." pureg 0\n";
			echo "iwpriv ath".$index." puren 1\n";
			}
		else if($g_mode == 5)
		{
			echo "iwpriv ath".$index." pureg 0\n";
			echo "iwpriv ath".$index." puren 0\n";
		}
		else if($g_mode == 6)
		{
			echo "iwpriv ath".$index." pureg 1\n";
			echo "iwpriv ath".$index." puren 0\n";
		} 
		else
		{
			echo "iwpriv ath".$index." pureg 0\n";
			echo "iwpriv ath".$index." puren 0\n";
		}
                echo "iwpriv ath".$index." doth 0\n"; 
                echo "iwpriv ath".$index." extprotspac 0\n";
     
               //if ($cwmmode!="")    {echo "iwpriv ath".$index." cwmmode ".$cwmmode."\n";}
	         
	            if ($dtim!="")          {echo "iwpriv ath".$index." dtim_period ".$dtim."\n"; }   // for each VAP. (WDS - ath0) jack.
	            /* w_partition 2008-03-22 end */            
	            if ($wmmenable>0)       { echo "iwpriv ath".$index." wmm 1"."\n"; }
	            else                    { echo "iwpriv ath".$index." wmm 0\n"; }
    
                    if ($auth_mode==1 || $auth_mode==0 )  /*shared key or open*/  
                    {                    
                        echo "iwpriv ath".$index." authmode 1\n";
    	                if ($wepmode==1)
    	                {            
                               /*
    	 		    *	For ASCII string:
    	                    *		iwconfig ath0 key s:"ascii" [1]
    	                    *	For Hex string:
    	                    *		iwconfig ath0 key "1234567890" [1]
    	                    */
    	                    echo "iwpriv ath".$index." ampdu 0\n";
    	                    if ($keyformat==1)	{ $iw_keystring="s:\"".get("s",$W_PATH."wepkey:".$defkey)."\" [".$defkey."]";}
    	                    else				{ $iw_keystring="\"".query($W_PATH."wepkey:".$defkey)."\" [".$defkey."]"; }
    	                    echo "iwconfig ath".$index." key ".$iw_keystring."\n";
    	                    if ($auth_mode==1)	{ echo "iwpriv ath".$index." authmode 2; "."iwconfig ath".$index." key ".$iw_keystring."\n"; }
    		        	}

                    }else if ($auth_mode==3 || /*wpa-psk*/ 
                              $auth_mode==5 || /*wpa2-psk*/  
                              $auth_mode==7 || /*wpa-auto-psk*/     
                              $auth_mode==2 || /*wpa-eap*/ 
                              $auth_mode==4 || /*wpa2-eap*/  
                              $auth_mode==6) /*wpa-auto-eap*/           
                    {            	
			$hostapd_conf	= "/var/run/hostapd".$index.".conf_wds";
//			$hostapd_pid	= "/var/run/hostapd".$index.".pid_wds";
			fwrite($hostapd_conf,
				"ignore_file_errors=1\n".
				"logger_syslog=0\n".
				"logger_syslog_level=0\n".
				"logger_stdout=0\n".
				"logger_stdout_level=0\n".
				"debug=0\n".
				"eapol_key_index_workaround=0\n".
				"dtim_period=2\n".
				"max_num_sta=255\n".
				"macaddr_acl=0\n".
				"auth_algs=1\n".
				"ignore_broadcast_ssid=0\n".
				"wme_enabled=0\n".
				"ssid=".$ssid."\n".
				"wpa=2\n".
				"wds_enable=1\n".
				"wds_mac=".$wds_mac."\n".
				"wpa_group_rekey=0\n".
				"wpa_key_mgmt=WPA-PSK\n".
				"wpa_passphrase=".$wpapsk."\n".
				"wpa_pairwise=CCMP\n");
				
			$wpa_supplicant_conf = "/var/run/wpa_supplicant".$index.".conf_wds";
//			$wpa_supplicant_pid = "/var/run/wpa_supplicant".$index.".pid_wds";
			fwrite($wpa_supplicant_conf,
				"ap_scan=2\n".
				"wds_enable=1\n".
				"wds_mac=".$wds_mac."\n".
				"network={\n".
				"ssid=\"".$ssid."\"\n".
				"scan_ssid=1\n".
				"key_mgmt=WPA-PSK\n".
				"psk=\"".$wpapsk."\"\n".
				"proto=WPA2\n".
				"pairwise=CCMP\ngroup=CCMP\n".
				"}\n");
               	    } // end of wpa-psk and eap           
		// Disable IPv6 on wireless interface
		echo "echo \"1\" > /proc/sys/net/ipv6/conf/ath".$index."/disable_ipv6;\n"; 
             }     // end of if ($wds_mac!="") 
        }// end of for

        echo "ifconfig eth0 mtu 1504\n"; // for vlan over wds pass through                
        if($up_ath_cnt > 0)
        {
            //echo "brctl stp br0 1 \n";    
        }
        //INCLUDE_WDSMODE_INFO_start
        if($index_mac !=0)
        {
            set("/runtime".$WLAN."/wds/devicenum", $index_mac);
            set("/runtime".$WLAN."/wds/wdsinfostatus", 1);  
        } 

} // end of ($generate_start==1)
else
{    
	$igmpsnoop = query("/wlan/inf:1/igmpsnoop");
        $limitedadmintype = query("/sys/adminlimit/status");
        echo "echo Stop WLAN WDS interface ".$wlanif." ... > /dev/console\n";

        if($limitedadmintype!=1 && $limitedadmintype!=3)
        {
            echo "ifconfig eth0 mtu 1500\n";
        }
	
	$index=7; 
	$index_mac=0;	
	echo "brctl stp br0 0 \n";

	for ($WLAN."/wds/list/index")
	{      
        	$index++; 
        	$index_mac++;
        	$wds_mac = query($WLAN."/wds/list/index:".$index_mac."/mac");  
        	if ($wds_mac!="")  
        	{    
	            echo "\necho kill WDS ath".$index."... > /dev/console\n"; 
	            
	            /* Stop wlxmlpatch_pid */	            
                	$index_tmp = $index-7;
			$wlxmlpatch_wds_pid = "/var/run/wlxmlpatch".$index_tmp.".pid_wds";
                	echo "if [ -f ".$wlxmlpatch_wds_pid." ]; then\n";
                	echo "kill \`cat ".$wlxmlpatch_wds_pid."\` > /dev/null 2>&1\n";
                	echo "rm -f ".$wlxmlpatch_wds_pid."\n";
                	echo "fi\n\n";
        	   /* IGMP Snooping dennis 2008-01-29 start */
			if($withoutap == 0 ){//wds with ap mode
				if($igmpsnoop == 1 ){
				echo "echo disable > /proc/net/br_igmp_ap_br0\n";
				echo "brctl igmp_snooping br0 0\n";
				echo "echo unsetwl ath".$index." > /proc/net/br_igmp_ap_br0\n";
			   }
			}
			   /* IGMP Snooping dennis 2008-01-29 end */
	        	echo "ifconfig ath".$index." down"."\n";  
		        //echo "sleep 2\n";  
		    	/* destroy and remove wireless */
		    	echo "brctl delif br0 ath".$index."\n";
		      /*  echo "iwpriv ath".$index." wdsalpha 0"."\n";*/

				/* Stop hostapd */
	          	$hostapd_conf	= "/var/run/hostapd".$index.".conf_wds";
			echo "rm -f ".$hostapd_conf."\n";
	
	        	/* Stop wpa_supplicant */
	          	$wpa_supplicant_conf = "/var/run/wpa_supplicant".$index.".conf_wds";
			echo "rm -f ".$wpa_supplicant_conf."\n";

				/* IGMP Snooping dennis 2008-01-29 start */
			if($withoutap == 0 ){//wds with ap mode
				if($igmpsnoop == 1 ){
					echo "if [ -f /var/run/ap_igmp_".$index.".pid ]; then\n";
					echo "kill \`cat /var/run/ap_igmp_".$index.".pid\` > /dev/null 2>&1\n";
					echo "rm -f /var/run/ap_igmp_".$index.".pid\n";
					echo "fi\n\n";
				}
			}

		    	echo "iwconfig ath".$index." key off"."\n"; // must add key off
		        //echo "sleep 1\n";  
		    	//echo "wlanconfig ath".$index." destroy"."\n";  
	    	}  // end of ($wds_mac!="")
	}  // end of for

        /* Stop wlxmlpatch_primary_pid */
        echo "if [ -f ".$wlxmlpatch_pid." ]; then\n";
        echo "kill \`cat ".$wlxmlpatch_pid."\` > /dev/null 2>&1\n";
        echo "rm -f ".$wlxmlpatch_pid."\n";
        echo "fi\n\n";

        set("/runtime".$WLAN."/wds/wdsinfostatus", 0); //INCLUDE_WDSMODE_INFO


	if (query("/wlan/inf:1/enable")!=1)
	{
		echo "echo WLAN is disabled ! > /dev/console\n";
		exit;
	}
	
	// jack, \\1.54.45.230\project\andy\2590-4448\boards\wapnd02\apps\wireless\__wlan_wdsmode.php  
	// jack, modify sh, then load r004, and then r005 by WEB, than test , crash or not.......
	echo "brctl e_partition br0 0\n";
	/* IGMP Snooping dennis 2008-01-29 start */
	if ($igmpsnoop == 1){
	if($withoutap == 0 ){//wds with ap mode
	echo "echo disable > /proc/net/br_igmp_ap_br0\n";
	echo "echo unsetwl ath0 > /proc/net/br_igmp_ap_br0\n";
	echo "brctl igmp_snooping br0 0\n";
	}
	}
	/* IGMP Snooping dennis 2008-01-29 end */
	echo "brctl apc br0 0"."\n";

	echo "ifconfig ".$wlanif." down\n";
//	echo "sleep 2\n";
	echo "brctl delif br0 ".$wlanif."\n";
	echo "sleep 1\n";
	/* Stop hostapd */
	$HAPD_conf	= "/var/run/hostapd.".$wlanif.".conf";
	echo "rm -f ".$HAPD_conf."\n";
	//echo "kill -9 `ps | grep ".$HAPD_conf." | grep -v grep | cut -b 1-5`\n";
	/*$HAPD_pid  = "/var/run/hostapd.".$wlanif.".pid";
	echo "if [ -f ".$HAPD_pid." ]; then\n";
	echo "kill -9 \`cat ".$HAPD_pid."\` > /dev/null 2>&1\n";
	echo "rm -f ".$HAPD_pid."\n";
	echo "rm -f ".$HAPD_conf."\n";
	echo "fi\n\n";*/
	 /* IGMP Snooping dennis 2008-01-29 start */
	 if($withoutap == 0 ){//wds with ap mode
	 echo "if [ -f ".$ap_igmp_pid." ]; then\n";
	 echo "kill \`cat ".$ap_igmp_pid."\` > /dev/null 2>&1\n";
	 echo "rm -f ".$ap_igmp_pid."\n";
	 echo "fi\n\n";
	 }
	/* IGMP Snooping dennis 2008-01-29 end */
	echo "iwconfig ".$wlanif." key off\n";
	echo "sleep 3\n";
	echo "VAPLIST=`iwconfig | grep ath | cut -b 1-5`\n";
	echo "for i in $VAPLIST\n";
	echo "do\n";
	echo "echo killing $i\n";
	echo "wlanconfig $i destroy\n";
	echo "done\n";
	//echo "wlanconfig ".$wlanif." destroy\n";
	echo "sleep 3\n";
	echo "rmmod ath_pktlog\n";
	echo "sleep 2\n";
	echo "rmmod umac\n";
	echo "sleep 2\n";
	echo "rmmod ath_dev\n";
	echo "rmmod ath_rate_atheros\n";
	echo "rmmod ath_hal\n";
	echo "rmmod asf\n";
	echo "rmmod adf\n";
	
}  // end of else ($generate_start!=1)

?>
