#!/bin/sh
echo [$0] ... > /dev/console 
	echo Start art module ... > /dev/console

	echo Stop normal wireless ... > /dev/console
	[ -f /etc/templates/wlan.sh ] && sh /etc/templates/wlan.sh stop
	sleep 8	#wait for removing ath_pci module
	echo insmode  art module ... > /dev/console
	mknod /dev/dk0 c 63 0
	mknod /dev/caldata b 31 6

	insmod /lib/modules/art.ko
	/usr/sbin/mdk_client.out &


