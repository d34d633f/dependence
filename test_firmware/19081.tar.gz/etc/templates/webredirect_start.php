#!/bin/sh
echo [$0] ... > /dev/console
<?
/* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");
$generate_start=1;
$webredirect_mode = 0;
$webredirect_mode = query("/wlan/inf:1/webredirect/enable");
$wan_lan_sta_ip=query("/runtime/webredirect/wan_lan_sta_ip");



if($webredirect_mode==1) 
{	
	echo "webredirect &> /dev/console\n";
	echo "echo $! > /var/run/webredirect.pid\n";
		
	echo "brctl webredirect br0 1 \n";
	echo "brctl setapip br0 ".$wan_lan_sta_ip."\n";
	
}
else
{
	echo "brctl webredirect br0 0 \n";
}

?>
