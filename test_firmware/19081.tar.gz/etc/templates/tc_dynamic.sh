#!/bin/sh
TROOT=`rgdb -i -g /runtime/template_root`
[ "$TROOT" = "" ] && TROOT="/etc/templates"
case "$1" in
start)
	rgdb -A $TROOT/tc_dynamic_bandwidth.php -V generate_start=1 > /var/run/tc_dynamic_bandwidth.sh
	sh /var/run/tc_dynamic_bandwidth.sh start> /dev/console
	;;
stop)
	rgdb -A $TROOT/tc_dynamic_bandwidth.php -V generate_start=0 > /var/run/tc_dynamic_bandwidth.sh
	if [ -f /var/run/tc_dynamic_bandwidth.sh ]; then
		sh /var/run/tc_dynamic_bandwidth.sh stop > /dev/console
		rm -f /var/run/tc_dynamic_bandwidth.sh
	fi
	;;
restart)
	rgdb -A $TROOT/tc_dynamic_bandwidth.php -V generate_start=1 > /var/run/tc_dynamic_bandwidth.sh
	sh /var/run/tc_dynamic_bandwidth.sh stop> /dev/console
	sh /var/run/tc_dynamic_bandwidth.sh start> /dev/console
	;;

*)
	echo "usage: tc_dynamic.sh {start|stop|restart}"
	;;
esac