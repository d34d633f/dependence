#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */
/* Jack add for stop/start multi_ssid 09/03/07 */

$WLAN = "/wlan/inf:1";  // b, g, n band
$igmpsnoop = query($WLAN."/igmpsnoop");
$multi_ssid_path = $WLAN."/multi";
$multi_total_state = query($multi_ssid_path."/state");  
$coexistence = query("coexistence/enable");
if ($generate_start==1)
{
	if ($multi_total_state == 1)
	{
	    	//$multicast_limit = query($WLAN."/multicast_bwctrl");/* dennis 2006-06-25 multicast bwctrl */
		$multi_pri_state = query($multi_ssid_path."/pri_by_ssid");

	    	$multi_ssid_amount=0;    /* Jack add 17/04/07 MULTI_SSID_CLIENT_INFO */
	    
	    	$index=0; 
/* dennis 2006-06-25 multicast bwctrl start 
    $index1=0;
    $ssid_counter=1; //1-->ath0
    for ($multi_ssid_path."/index")
    {
    	$index1++;
    	$multi_ind_state1 = query($multi_ssid_path."/index:".$index1."/state");
	    //add schedule for multi-ssid by yuda start
	    $schedule_enable=query("/schedule/enable");
	    if ($schedule_enable==1)
	    {
	    	if(query($multi_ssid_path."/index:".$index."/schedule_rule_state")==1)
	    	{
	    		$multi_ind_schedule_state = query($multi_ssid_path."/index:".$index."/schedule_state");
	    	}
	    	else
	    	{
	    		$multi_ind_schedule_state = 1;
	    	}
	    }
	    else
	    {
	    	$multi_ind_schedule_state = 1;
	    }
	    //add schedule for multi-ssid by yuda end	      

    	if ($multi_ind_state1==1) 
    	{
    		$ssid_counter++;
    	}
    }
    
    $denominator = $multicast_limit/$ssid_counter;
      dennis 2006-06-25 multicast bwctrl end */      
		for ($multi_ssid_path."/index")
		{      
	    		$index++;     
	    		$IWPRIV="iwpriv ath".$index;
	    		$multi_ind_state = query($multi_ssid_path."/index:".$index."/state");  
	    		/*add schedule for multi-ssid by yuda start*/
	    		$schedule_enable=query("/schedule/enable");
	    		if ($schedule_enable==1)
	    		{
	    			if(query($multi_ssid_path."/index:".$index."/schedule_rule_state")==1)
	    			{
	    				$multi_ind_schedule_state = query($multi_ssid_path."/index:".$index."/schedule_state");
	    			}
	    			else
	    			{
	    				$multi_ind_schedule_state = 1;
	    			}
	    		}
	    		else
	    		{
	    			$multi_ind_schedule_state = 1;
	    		}
	    		/*add schedule for multi-ssid by yuda end*/	      
	        	set("/runtime".$WLAN."/multi_ssid/index:".$index."/state", 0);  /* Jack add 17/04/07 MULTI_SSID_CLIENT_INFO */
	    		if ($multi_ind_state==1)  //add $multi_ind_schedule_state for schedule for multi-ssid by yuda 
	    		{ 
		   // if($iapp_state == 1){ /* Added by Enos , IAPP_20070620 */
	           //$iapp_interface = $iapp_interface." ath".$index;
	        //}        
	        		$multi_ssid = query($multi_ssid_path."/index:".$index."/ssid");//query($multi_ssid_path."/index:".$index."/ssid");
	        		$multi_ssid_hidden = query($multi_ssid_path."/index:".$index."/ssid_hidden");
	        		$multi_wmm = query($multi_ssid_path."/index:".$index."/wmm/enable");  
	            		$multi_wpartition = query($multi_ssid_path."/index:".$index."/w_partition");
	            
				$mcastrate_g  = query("/wlan/inf:1/mcastrate_g");/*add for mcast rate by yuda*/
				//$multi_cipher = query($multi_ssid_path."/index:".$index."/cipher");	
				$multi_pri_bit = query($multi_ssid_path."/index:".$index."/pri_bit");
	        		echo "\necho Add multi-ssid ath".$index."... > /dev/console\n";
	        		echo "wlanconfig ath".$index." create wlandev wifi0 wlanmode ap\n";

				// Disable IPv6 on wireless interface
				echo "echo \"1\" > /proc/sys/net/ipv6/conf/ath".$index."/disable_ipv6;\n";

				//echo $IWPRIV." bgscan 0\n";	/*not_yet*/
				echo "ifconfig ath".$index." txqueuelen 1000\n";	        

				if($autochannel==0)
			        {
                			if($channel>14)
                			{
                        			$channel=6;
               				}
        			}

	        	
	             /* erial mark start
    		    if($multi_cipher==1||$multi_cipher==2){
         			if($g_mode == 2) {echo $IWPRIV." mode 11G\n";}
        			else if($g_mode == 1) {echo $IWPRIV." mode 11G\n";}
        			else if($g_mode == 3) {echo $IWPRIV." mode 11B\n";}
        			else{
					 	if($cwmmode == 0){
						echo $IWPRIV." mode 11NGHT20\n";
						echo $IWPRIV." htweptkip 0\n";	
						}	
						else{//cwmmode==1
							if($autochannel==1){
								echo $IWPRIV." mode 11NGHT40\n";
								echo $IWPRIV." htweptkip 0\n";
							}
							else{
								if($channel<5){
									echo $IWPRIV." mode 11NGHT40PLUS\n";
									echo $IWPRIV." htweptkip 0\n";
								}
								else{
									echo $IWPRIV." mode 11NGHT40MINUS\n";		
									echo $IWPRIV." htweptkip 0\n";
								}
							}
						}		
					}
    	        }else{ erial mark end */	
				//(20) 1:11g only, 2.b/g mode 3:11b only, 4:only n  5:b/g/n mix, 6:g/n mix
	
	            		if ($cwmmode == 0)
	            		{
	            			if($g_mode == 5) {echo $IWPRIV." mode 11NGHT20\n";}
	            			else if($g_mode == 6) {echo $IWPRIV." mode 11NGHT20\n";}
	            			else if($g_mode == 4) {echo $IWPRIV." mode 11NGHT20\n";}
	            			else if($g_mode == 2) {echo $IWPRIV." mode 11G\n";}
	            			else if($g_mode == 1) {echo $IWPRIV." mode 11G\n";}
	            			else if($g_mode == 3) {echo $IWPRIV." mode 11B\n";}
	            			else {echo $IWPRIV." mode 11NGHT20\n";}
	            		}
	                	//5--->11bgn 6-->11gn 4--->only n	
	                	else//cwmmode=1 HT20/40 mode
        			{
                			if($autochannel==1)     {echo $IWPRIV." mode 11NGHT40\n";}//autochannel enable
                			else//autochannel disable
                			{
                        			if($channel<5)  {echo $IWPRIV." mode 11NGHT40PLUS\n";}//channel 1~4
                        			else if($channel<=11){echo $IWPRIV." mode 11NGHT40MINUS\n";}//channel 5~11
                        			else            {echo $IWPRIV." mode 11NGHT20\n";}//channel 12,13 for JP
                			}
        			}
 
	            		if($g_mode == 1){
	            			echo $IWPRIV." puren 0\n";
	            			echo $IWPRIV." pureg 1\n";
	            		}
	            		else if($g_mode == 2){
	            			echo $IWPRIV." puren 0\n";
	            			echo $IWPRIV." pureg 0\n";
	            		}		
	            		else if($g_mode == 4){
	            			echo $IWPRIV." pureg 0\n";
	            			echo $IWPRIV." puren 1\n";
	            		}
	            		else if($g_mode == 5){
	            			echo $IWPRIV." pureg 0\n";
	            			echo $IWPRIV." puren 0\n";
	            		}
	            		else if($g_mode == 6){
	            			echo $IWPRIV." pureg 1\n";
	            			echo $IWPRIV." puren 0\n";
	            		}
	            		else{
	            			echo $IWPRIV." pureg 0\n";
	            			echo $IWPRIV." puren 0\n";
	            		}

				if($coexistence==1)	{echo $IWPRIV." disablecoext 0\n";}
				else			{echo $IWPRIV." disablecoext 1\n";}
				//erial_acs_201009
                               // echo "iwconfig ath".$index." essid \"".get("s",$multi_ssid_path."/index:".$index."/ssid")."\" freq ".$channel."\n";
			        if($channel == 0) {echo "iwconfig ath".$index." essid \"".get("s",$multi_ssid_path."/index:".$index."/ssid")."\" \n";}
        			else {echo "iwconfig ath".$index." essid \"".get("s",$multi_ssid_path."/index:".$index."/ssid")."\" freq ".$channel."\n";}

                                echo "iwconfig ath".$index." mode master\n";
				echo "iwpriv wifi0 noisespuropt 1\n";
 
	        		if ($multi_ssid_hidden!="")    { echo $IWPRIV." hide_ssid ".$multi_ssid_hidden."\n"; }
	        		if ($dtim!="")          { echo $IWPRIV." dtim_period ".$dtim."\n"; }
	               		if ($multi_wmm!="")       { echo $IWPRIV." wmm ".$multi_wmm."\n"; }
	        		else                    { echo $IWPRIV." wmm 0\n"; }
	        
	        		/* w_partition 2008-03-22 start */
	                	/* Jack add 11/11/08 +++ */  
	                	if ($multi_wpartition==2)   /* guest mode,  */
	                	{
	                    		echo $IWPRIV." w_partition 1 \n";	                    
					echo "brctl w_partition br0 ath".$index."  1 \n";  
	                	}   // for Mssid1, WDS-ath0 jack.
	                	else if ($multi_wpartition==1) 
	                	{
	                		echo $IWPRIV." w_partition 1 \n";             
                        		echo "brctl w_partition br0 ath".$index." 0 \n";   	  	
	                	}  
	                	else                    
	                	{
	                    		echo $IWPRIV." w_partition 0\n";                   
                        		echo "brctl w_partition br0 ath".$index." 0 \n";    
	                	}
	        
	               	 	/* Jack add 11/11/08 --- */  
	                        /* w_partition 2008-03-22 end */   
	        
	       	     		echo $IWPRIV." apband 0\n"; //show ap band in wireless driver
	        
	        		echo $IWPRIV." countryie 1\n";
	        		echo $IWPRIV." bintval ".$bintval."\n";   // Atheros suggest 400 is a better value for MSSID. jack test
				/*add for mcast rate by yuda start*/
    				if($mcastrate_g!=0){
    					if($mcastrate_g==1){
    						echo $IWPRIV." mcast_rate 1000\n";
    					}
    					else if($mcastrate_g==2){
    						echo $IWPRIV." mcast_rate 2000\n";
    					}
    					else if($mcastrate_g==3){
    						echo $IWPRIV." mcast_rate 5500\n";
    					}
    					else if($mcastrate_g==4){
    						echo $IWPRIV." mcast_rate 11000\n";
    					}
    					else if($mcastrate_g==5){
    						echo $IWPRIV." mcast_rate 6000\n";
    					}
    					else if($mcastrate_g==6){
    						echo $IWPRIV." mcast_rate 9000\n";
    					}
    					else if($mcastrate_g==7){
    						echo $IWPRIV." mcast_rate 12000\n";
    					}
    					else if($mcastrate_g==8){
    						echo $IWPRIV." mcast_rate 18000\n";
    					}
    					else if($mcastrate_g==9){
    						echo $IWPRIV." mcast_rate 24000\n";
    					}
    					else if($mcastrate_g==10){
    						echo $IWPRIV." mcast_rate 36000\n";
    					}
    					else if($mcastrate_g==11){
    						echo $IWPRIV." mcast_rate 48000\n";
    					}
    					else if($mcastrate_g==12){
    						echo $IWPRIV." mcast_rate 54000\n";
    					}
    					else if($mcastrate_g==13){
    						echo $IWPRIV." mcast_rate 6500\n";
    					}
    					else if($mcastrate_g==14){
		    				echo $IWPRIV." mcast_rate 13000\n";
		    			}
		    			else if($mcastrate_g==15){
		    				echo $IWPRIV." mcast_rate 19500\n";
    					}
    					else if($mcastrate_g==16){
    						echo $IWPRIV." mcast_rate 26000\n";
    					}
    					else if($mcastrate_g==17){
    						echo $IWPRIV." mcast_rate 39000\n";
    					}
    					else if($mcastrate_g==18){
    						echo $IWPRIV." mcast_rate 52000\n";
    					}
    					else if($mcastrate_g==19){
    						echo $IWPRIV." mcast_rate 58500\n";
    					}
    					else if($mcastrate_g==20){
    						echo $IWPRIV." mcast_rate 65000\n";
    					}
    					else if($mcastrate_g==21){
    						echo $IWPRIV." mcast_rate 78000\n";
    					}
    					else if($mcastrate_g==22){
    						echo $IWPRIV." mcast_rate 104000\n";
    					}
    					else if($mcastrate_g==23){
    						echo $IWPRIV." mcast_rate 117000\n";
    					}
    					else if($mcastrate_g==24){
    						echo $IWPRIV." mcast_rate 130000\n";
    					}
     					else {
    						echo $IWPRIV." mcast_rate 11000\n";
    					}   	   
    				}     
				/*add for mcast rate by yuda end*/

	        		/* aclmode 0:disable, 1:allow all of the list, 2:deny all of the list */
	        		echo $IWPRIV." maccmd 3\n";   // flush the ACL database.
	        		$aclmode=query($WLAN."/acl/mode");
		    		//echo "echo aclmode:  ".$aclmode."  ... > /dev/console\n";
	        		if      ($aclmode == 1)     { echo $IWPRIV." maccmd 1\n"; }
	        		else if ($aclmode == 2)     { echo $IWPRIV." maccmd 2\n"; }
	        		else                        { echo $IWPRIV." maccmd 0\n"; }
	        		if ($aclmode == 1 || $aclmode == 2)
	        		{
	           			for($WLAN."/acl/mac")
	           			{
	            				$mac=query($WLAN."/acl/mac:".$@);
	             				echo $IWPRIV." addmac ".$mac."\n";//wtpmacenable 2007-09-13 dennis
	           			}
	        		}
	                	/* Jack add 20/04/07 MULTI_SSID_FILTER --- */

             	    //echo "brctl setbwctrl br0 ath".$index." ".$denominator."\n";// dennis 2006-06-25 multicast bwctrl
	                	$multi_ssid_amount++;  /* Jack add 17/04/07 MULTI_SSID_CLIENT_INFO */
	    	        	set("/runtime".$WLAN."/multi_ssid/index:".$index."/state", 1);  /* Jack add 17/04/07 MULTI_SSID_CLIENT_INFO */
	         		/*2008_07_14_allen,multi-ssid priority*/
                 		if ($multi_pri_state == 1) 
				{
					echo $IWPRIV." pristate 1\n";
					echo $IWPRIV." pribit ".$multi_pri_bit."\n";
		 		}
				else 
				{ 
					echo $IWPRIV." pristate 0\n"; 
				}
				
				$perssidassoclimit  = query("/wlan/userlimit/perssid");
				if ( $perssidassoclimit == 1 )
				{
					$assoclimitenable   = query($WLAN."/userlimit:0/enable");
					$assoclimitnumber   = query($WLAN."/userlimit:".$index."/number");
					if($assoclimitenable==1)        {echo $IWPRIV." assocenable 1\n";}
					else                            {echo $IWPRIV." assocenable 0\n";}
					if($assoclimitnumber!="")       {echo $IWPRIV." assocnumber ".$assoclimitnumber."\n";}
				}
	         	}     // end of ($multi_ind_state==1) 
	    	}// end of for
   		//echo "brctl setbwctrl br0 ath0 ".$denominator."\n"; // dennis 2006-06-25 multicast bwctrl
	        /* Jack add 17/04/07 MULTI_SSID_CLIENT_INFO +++ */
	        if($multi_ssid_amount !=0)
	        {
	    	    set("/runtime".$WLAN."/multi_ssid/multi_ssid_infostatus", 1);  
	    	    set("/runtime".$WLAN."/multi_ssid/devicenum", $multi_ssid_amount);  
	        } 
	        
	} // end of ($multi_total_state == 1)
	/*if($iapp_state == 1){
		echo "iappd -f br0".$iapp_interface." &\n"; // added by Enos , IAPP_20070620 
	}*/
} // end of ($generate_start==1)
else
{
	/*
	if($iapp_state == 1){
		echo "killall iappd\n"; // added by Enos , IAPP_20070620 
	}*/
	if (query($WLAN."/enable")!=1)
        {
                echo "echo WLAN is disabled ! > /dev/console\n";
                exit;
        }

	if ($multi_total_state == 1)
	{       
	    $index=0; 
	    for ($WLAN."/multi/index")
	    {      
	    	$index++;     
	        /*add schedule for multi-ssid by yuda start*/
	        $schedule_enable=query("/schedule/enable");
	        if ($schedule_enable==1)
	        {
	        	if(query($multi_ssid_path."/index:".$index."/schedule_rule_state")==1)
	        	{
	        		$multi_ind_schedule_state = query($multi_ssid_path."/index:".$index."/schedule_state");
	        	}
	        	else
	        	{
	        		$multi_ind_schedule_state = 1;
	        	}     	
	        }
	        else
	        {
	        	$multi_ind_schedule_state = 1;
	        }
	        
	        /*add schedule for multi-ssid by yuda end*/	    
	        $multi_ind_state = query($multi_ssid_path."/index:".$index."/state");  
	        if ($multi_ind_state==1)  
	        {          
	        	echo "\necho kill multi-ssid ath".$index."... > /dev/console\n";       
	            	$hostapd_conf = "/var/run/hostapd0".$index.".conf";
		        echo "rm -f ".$hostapd_conf."\n"; 
	            /* Stop wlxmlpatch_pid */	            
/* Jack add 13/02/08 +++ wlxmlpatch_v2*/
		        $wlxmlpatch_pid	= "/var/run/wlxmlpatch".$index.".pid_mssid";
                	echo "if [ -f ".$wlxmlpatch_pid." ]; then\n";
                	echo "kill \`cat ".$wlxmlpatch_pid."\` > /dev/null 2>&1\n";
                	echo "rm -f ".$wlxmlpatch_pid."\n";
                	echo "fi\n\n";
/* Jack add 13/02/08 --- wlxmlpatch_v2*/
			if ($igmpsnoop == 1){
				echo "echo disable > /proc/net/br_igmp_ap_br0\n";
				echo "brctl igmp_snooping br0 0\n";
				echo "echo unsetwl ath".$index." > /proc/net/br_igmp_ap_br0\n";
				echo "if [ -f /var/run/ap_igmp_".$index.".pid ]; then\n";
				echo "kill \`cat /var/run/ap_igmp_".$index.".pid\` > /dev/null 2>&1\n";
				echo "rm -f /var/run/ap_igmp_".$index.".pid\n";
				echo "fi\n\n";
			}

		        echo "brctl delif br0 ath".$index."\n";  
		        echo "ifconfig ath".$index." down"."\n";  
		        echo "iwconfig ath".$index." key off"."\n"; 
		       // echo "wlanconfig ath".$index." destroy"."\n";  
		    }  // end of ($multi_ind_state==1)
		}  // end of for
	} // end of ($multi_total_state == 1)
}  // end of else ($generate_start!=1)
?>
