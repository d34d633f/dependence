#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");



       echo "rgdb -s /trafficctrl/wtp/trafficmgr/enable 1\n";
       
/*	echo "rgdb -s /trafficctrl/updownlinkset/bandwidth/uplink 150\n";

	echo "rgdb -s /trafficctrl/updownlinkset/bandwidth/downlink 150\n";
*/
	echo "rgdb -s /trafficctrl/count 8 \n";

	
/*	 echo "rgdb -s /trafficctrl/trafficmgr/enable 1 \n";
	 */
       echo "rgdb -s /trafficctrl/trafficrule:1/id 0 \n";
       echo "rgdb -s /trafficctrl/trafficrule:1/enable 1 \n";

	echo "rgdb -s /trafficctrl/trafficrule:1/maxwidth 102400 \n";
	echo "rgdb -s /trafficctrl/trafficrule:1/clientmaxwidth 2048\n";
	echo "rgdb -s /trafficctrl/trafficrule:1/flowcontroltype 0\n";	
	
	
       echo "rgdb -s /trafficctrl/trafficrule:1/name ath0 \n";
       echo "rgdb -s /trafficctrl/trafficrule:1/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:1/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:1/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:1/dstnode/node:1/name ath0\n";


	echo "rgdb -s /trafficctrl/trafficrule:2/id 1 \n";
	echo "rgdb -s /trafficctrl/trafficrule:2/enable 0 \n";
	
	echo "rgdb -s /trafficctrl/trafficrule:2/maxwidth 2072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:2/clientmaxwidth 200\n";
	echo "rgdb -s /trafficctrl/trafficrule:2/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:2/name ath1 \n";
       echo "rgdb -s /trafficctrl/trafficrule:2/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:2/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:2/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:2/dstnode/node:1/name ath1\n";


       echo "rgdb -s /trafficctrl/trafficrule:3/id 2 \n";
       echo "rgdb -s /trafficctrl/trafficrule:3/enable 0 \n";
	
	echo "rgdb -s /trafficctrl/trafficrule:3/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:3/clientmaxwidth 300\n";
	
	echo "rgdb -s /trafficctrl/trafficrule:3/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:3/name ath2 \n";
       echo "rgdb -s /trafficctrl/trafficrule:3/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:3/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:3/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:3/dstnode/node:1/name ath2\n";


       echo "rgdb -s /trafficctrl/trafficrule:4/id 1 \n";
       echo "rgdb -s /trafficctrl/trafficrule:4/enable 0 \n";
	
	echo "rgdb -s /trafficctrl/trafficrule:4/maxwidth 4072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:4/clientmaxwidth 400\n";
	echo "rgdb -s /trafficctrl/trafficrule:4/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:4/name ath3 \n";
       echo "rgdb -s /trafficctrl/trafficrule:4/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:4/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:4/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:4/dstnode/node:1/name ath3\n";


       echo "rgdb -s /trafficctrl/trafficrule:5/id 1 \n";
       echo "rgdb -s /trafficctrl/trafficrule:5/enable 0 \n";
	
	echo "rgdb -s /trafficctrl/trafficrule:5/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:5/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:5/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:5/name ath4 \n";
       echo "rgdb -s /trafficctrl/trafficrule:5/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:5/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:5/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:5/dstnode/node:1/name ath4\n";

       echo "rgdb -s /trafficctrl/trafficrule:6/id 6 \n";
       echo "rgdb -s /trafficctrl/trafficrule:6/enable 0 \n";

	
	echo "rgdb -s /trafficctrl/trafficrule:6/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:6/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:6/flowcontroltype 0\n";	

	echo "rgdb -s /trafficctrl/trafficrule:6/name ath5 \n";
       echo "rgdb -s /trafficctrl/trafficrule:6/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:6/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:6/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:6/dstnode/node:1/name ath5\n";

       echo "rgdb -s /trafficctrl/trafficrule:7/id 7 \n";
       echo "rgdb -s /trafficctrl/trafficrule:7/enable 0 \n";

	
	echo "rgdb -s /trafficctrl/trafficrule:7/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:7/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:7/flowcontroltype 0\n";	

	
	echo "rgdb -s /trafficctrl/trafficrule:7/name ath6 \n";
       echo "rgdb -s /trafficctrl/trafficrule:7/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:7/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:7/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:7/dstnode/node:1/name ath6\n";

       echo "rgdb -s /trafficctrl/trafficrule:8/id 8 \n";
       echo "rgdb -s /trafficctrl/trafficrule:8/enable 0 \n";

	
	echo "rgdb -s /trafficctrl/trafficrule:8/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:8/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:8/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:8/name ath7 \n";
       echo "rgdb -s /trafficctrl/trafficrule:8/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:8/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:8/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:8/dstnode/node:1/name ath7\n";

         echo "rgdb -s /trafficctrl/trafficrule:9/id 9 \n";
       echo "rgdb -s /trafficctrl/trafficrule:9/enable 0 \n";

	
	echo "rgdb -s /trafficctrl/trafficrule:9/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:9/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:9/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:9/name ath16 \n";
       echo "rgdb -s /trafficctrl/trafficrule:9/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:9/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:9/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:9/dstnode/node:1/name ath16\n";
       
        echo "rgdb -s /trafficctrl/trafficrule:10/id 10 \n";
       echo "rgdb -s /trafficctrl/trafficrule:10/enable 0 \n";

	
	echo "rgdb -s /trafficctrl/trafficrule:10/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:10/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:10/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:10/name ath17 \n";
       echo "rgdb -s /trafficctrl/trafficrule:10/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:10/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:10/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:10/dstnode/node:1/name ath17\n";

  	echo "rgdb -s /trafficctrl/trafficrule:11/id 11 \n";
       echo "rgdb -s /trafficctrl/trafficrule:11/enable 0 \n";

	
	echo "rgdb -s /trafficctrl/trafficrule:11/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:11/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:11/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:11/name ath18 \n";
       echo "rgdb -s /trafficctrl/trafficrule:11/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:11/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:11/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:11/dstnode/node:1/name ath18\n";

         echo "rgdb -s /trafficctrl/trafficrule:12/id 12 \n";
       echo "rgdb -s /trafficctrl/trafficrule:12/enable 0 \n";

	
	echo "rgdb -s /trafficctrl/trafficrule:12/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:12/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:12/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:12/name ath19 \n";
       echo "rgdb -s /trafficctrl/trafficrule:12/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:12/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:12/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:12/dstnode/node:1/name ath19\n";


         echo "rgdb -s /trafficctrl/trafficrule:13/id 13 \n";
       echo "rgdb -s /trafficctrl/trafficrule:13/enable 0 \n";

	
	echo "rgdb -s /trafficctrl/trafficrule:13/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:13/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:13/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:13/name ath20 \n";
       echo "rgdb -s /trafficctrl/trafficrule:13/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:13/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:13/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:13/dstnode/node:1/name ath20\n";
       
         echo "rgdb -s /trafficctrl/trafficrule:14/id 14 \n";
       echo "rgdb -s /trafficctrl/trafficrule:14/enable 0 \n";

	
	echo "rgdb -s /trafficctrl/trafficrule:14/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:14/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:14/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:14/name ath21 \n";
       echo "rgdb -s /trafficctrl/trafficrule:14/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:14/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:14/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:14/dstnode/node:1/name ath21\n";

         echo "rgdb -s /trafficctrl/trafficrule:15/id 15 \n";
       echo "rgdb -s /trafficctrl/trafficrule:15/enable 0 \n";

	
	echo "rgdb -s /trafficctrl/trafficrule:15/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:15/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:15/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:15/name ath22 \n";
       echo "rgdb -s /trafficctrl/trafficrule:15/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:15/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:15/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:15/dstnode/node:1/name ath22\n";

         echo "rgdb -s /trafficctrl/trafficrule:16/id 16 \n";
       echo "rgdb -s /trafficctrl/trafficrule:16/enable 0 \n";

	
	echo "rgdb -s /trafficctrl/trafficrule:16/maxwidth 3072 \n";
	echo "rgdb -s /trafficctrl/trafficrule:16/clientmaxwidth 1024\n";
	echo "rgdb -s /trafficctrl/trafficrule:16/flowcontroltype 0\n";	
	
	echo "rgdb -s /trafficctrl/trafficrule:16/name ath23 \n";
       echo "rgdb -s /trafficctrl/trafficrule:16/srcnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:16/srcnode/node:1/name eth0\n";
       echo "rgdb -s /trafficctrl/trafficrule:16/dstnode/count 1\n";
       echo "rgdb -s /trafficctrl/trafficrule:16/dstnode/node:1/name ath23\n";
       
       exit;
?>

