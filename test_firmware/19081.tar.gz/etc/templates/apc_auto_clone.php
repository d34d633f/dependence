<?
	$wlanmac    = query("/runtime/macclone/addr");

        require("/etc/templates/__wlan_apcmode.php");
        exit;
?>
