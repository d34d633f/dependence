#!/bin/sh
echo [$0] ... > /dev/console
static_dhcp &>/dev/console
