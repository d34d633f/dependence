#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */
require("/etc/templates/troot.php");

 echo "echo tc rule refresh...\n";

$offset=0;
$tunnelmode=query("/runtime/ac/wlan/inf:1/link/wlanID:1/tunnelMode");
$Mssid=1;
$tcenable=query("/trafficctrl/trafficrule:1/enable");
if($tcenable=="1")
{
for("/runtime/stats/wlan/inf:1/client") //primary
{ 
        $mac="";
	 $mac=query("mac");
 	

	 if($mac!="")
	 {

	 if($tunnelmode=="1") {$offset=48;}
	 echo "rgdb -is /runtime/stats/wtp/trafficctrl/trafficrule:1/client:".$@."/mac ".$mac." \n";
	// set("/runtime/stats/wtp/trafficctrl/trafficrule:1/client:".$@."/mac ",$mac); 
	 echo "bandwidthset add mac 1 ".$mac." ".$offset."\n";

	 }
}


}
$mssid_index = "";



for("/wlan/inf:1/multi/index")
{
      
         $state=query("state");
         $mssid_index = $@;
         $Mssid=$mssid_index+1;
         $tunnelmode=0;
         if(query("state") !="0")
         {
         $tunnelmode=query("/runtime/ac/wlan/inf:1/link/wlanID:".$Mssid."/tunnelMode");
          if($tunnelmode=="1")	  {$offset=48;}
          $tcenable=query("/trafficctrl/trafficrule:".$Mssid."/enable");
         if($tcenable=="1")
         {
         $association_num=0;
         for("/runtime/stats/wlan/inf:1/mssid:".$mssid_index."/client")
          {
          $mac="";
          $mac=query("mac");
          if($mac!="")
	 {
	  if($tunnelmode=="1")	  {$offset=48;}
	  echo "rgdb -is /runtime/stats/wtp/trafficctrl/trafficrule:".$Mssid."/client:".$@."/mac ".$mac."\n";

	  echo "bandwidthset add mac ".$Mssid." ".$mac." ".$offset."\n";
	  }
          }
          }
          
         }

 }
?>

