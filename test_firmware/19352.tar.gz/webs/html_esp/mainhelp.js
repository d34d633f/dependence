﻿if (HelpItem=='firmware'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Esta página muestra la versión del firmware de su dispositivo e información que será útil para los técnicos de D-Link si usted les solicita asistencia técnica. Esta información es solo como referencia, puesto que a menudo no es necesario cargar nuevo firmware en su router.<br><br>' +
                                        '<a href="helpmaintenance.html#Firmware">Más…</a>';

} else if (HelpItem=='system'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Esta página le permite guardar la configuración de su router en un archivo de su ordenador como media de precaución en caso de que tenga que restablecer los parámetros por defecto en el router. Así podrá restaurar los parámetros del router desde un archivo de configuración guardado previamente.  También hay una función que le permite restaurar los parámetros por defecto en el router. Al restablecer los parámetros por defecto en el router, borrará la configuración actual.<br><br>' +
                                        '<a href="helpmaintenance.html#System">Más…</a>';

} else if (HelpItem=='diag'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Esta página muestra el resultado del autodiagnóstico del router y los resultados de los tests de conexión. El estado de la conectividad a internet solo mostrará SUPERA si ha configurado correctamente la conexión a internet y su router está en ese momento en línea.<br><br>' +
                                        '<a href="helpmaintenance.html#Diag">Más…</a>';

} else if (HelpItem=='acadmin'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Está página le permite modificar la contraseña de su router, necesaria para acceder a esta interfaz de gestión web. Por motivos de seguridad, es recomendable que cambie la contraseña de su dispositivo de la que figura por defecto. Asegúrese de que elige una contraseña que puede recordar o anotar y conservar en un lugar seguro para tenerla a mano cuando la necesite. Si olvida la contraseña de su dispositivo, la única solución es restablecer los parámetros por defecto en el router, pero perderá todos los parámetros que haya configurado en el dispositivo.<br><br>' +
                                        '<a href="helpmaintenance.html#Password">Más…</a>';

} else if (HelpItem=='acip'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'You can restrict users who can access the local management using IP address.<br><br>' +
                                        '<a href="helpmaintenance.html#Access">More...</a>';

} else if (HelpItem=='syslog'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Esta página le permite habilitar, configurar y ver el registro del sistema del router. El registro del sistema genera una relación con la actividad del router. En función de la cantidad de detalles que usted incluya en el registro, el router solo podrá conservar un número limitado de entradas de registro, dadas las limitaciones de memoria del dispositivo. Si dispone de un servidor SYSLOG externo, puede elegir configurar un registro externo y, de este modo, todas las entradas de registro se enviarán a su servidor remoto.<br><br>' +
                                        'También puede configurar el router para que envíe por correo electrónico el registro del sistema a un dirección de correo electrónico específica, pero necesitará que su ISP le proporcione la información del servidor de correo electrónico.<br><br>' +
                                        '<a href="helpmaintenance.html#SystemLog">Más…</a>';
} else if (HelpItem=='captcha'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Esta página le permite activar o desactivar la característica de CAPTCHA en su registro en la página. Si desea mejorar la seguridad de su router, que debería permitir a la función. Otherwisze puede desactivar si no puede autenticar recongnize la imagen.<br><br>';
}
