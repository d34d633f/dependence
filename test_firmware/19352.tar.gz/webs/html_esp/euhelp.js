if (HelpItem=='euwan'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br>' +
                                        'Se les recomienda a los usuarios sin experiencia que ejecuten el asistente de configuración. Haga clic en el botón del asistente de configuración para que le guíe a través de los pasos del proceso de configuración de su conexión ADSL.<br><br>' +
                                        'Marque la casilla Configuración manual si usted es un usuario avanzado y tiene a mano los parámetros de su proveedor de servicios internet (ISP).<br><br>' +
                                        'Cuando introduzca su nombre de usuario y su contraseña tenga en cuenta que se distinguen las mayúsculas de las minúsculas. La mayoría de los problemas con la conexión suelen deberse a combinaciones incorrectas del nombre de usuario y la contraseña.<br><br> '+
                                        '<a href="helpbasic.html#Internet">Más...</a>';
}else if (HelpItem=='euwireless'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br>' +
                                        'El primer paso para dar seguridad a su red inalámbrica es cambiar su nombre de red inalámbrica (SSID). Cámbielo por un nombre que le resulte familiar, pero que no contenga información personal.<BR><BR> ' +
                                        'Habilite al escaneo automático del canal para que, de este modo, el router pueda seleccionar el mejor canal posible en el que opere su red inalámbrica.<BR><BR> ' + 
										'Elegir ocultar la red inalámbrica también permite darle seguridad a la red, puesto que los clientes inalámbricos no verán su red en la lista de redes cuando busquen redes disponibles. Para conectar sus dispositivos inalámbricos al router, ha de introducir manualmente el nombre de red inalámbrica  (SSID) en cada dispositivo. (Tome nota de su SSID y téngalo a mano.)<BR><BR>' + 
                                        'Si ha habilitado la seguridad inalámbrica, asegúrese de que toma nota de su clave de encriptación. Tendrá que introducirla, junto con el SSID, en cada uno de los dispositivos inalámbricos que quiera conectar a su red.<br><br>' + 
										'<a href="helpbasic.html#Wireless">Más…</a>';
}else if (HelpItem=='eulan'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br>' +
                                        'Si ya dispone de un servidor DHCP en su red o usa direcciones IP estáticas en todos los dispositivos de su red, haga clic en Habilitar servidor DHCP para deshabilitar está característica.<BR><BR> ' + 
										'Si en su red hay dispositivos que siempre han de tener direcciones IP fijas, añada una reserva  DHCP para cada uno de ellos.<br><br>' + 
										'<a href="helpbasic.html#Local">Más…</a>';
}else if (HelpItem=='eublock'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br>' +
                                        'Para habilitar rápidamente el acceso a internet dentro de los periodos de tiempo restringidos por las restricciones horarias de acceso a internet, marque las casillas que figuran bajo Permitir y haga clic en Guardar parámetros. Recuerde que para iniciar de nuevo las restricciones horarias, debe volver a marcar las casillas de Denegar.<br><BR> ' + 
										'<a href="helpbasic.html#Parental">Más…</a>';

}else if (HelpItem=='eudatetime'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br>' +
                                        'Asegúrese de que la fecha y la hora son las correctas; así podrá configurar con precisión las restricciones horarios en el apartado Control parental.<br><br>' +
                                        'Habilite el horario de verano para garantizar que el router mantiene la hora correcta a lo largo de todo el año.<BR><BR> '+
                                        '<a href="helpbasic.html#Time">Más…</a>';
}else if (HelpItem=='euadvwlan'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br>' +
                                        'Por defecto no es necesario cambiar estas opciones para que el router opere en modo inalámbrico. La opción Potencia de transmisión es la potencia de la señal de radio. Debe disminuir la potencia si añade una antena de alta ganancia, puesto que se excederían los limites de funcionamiento.<br><br>' +

                                        '<a href="helpadvanced.html#WirelessAdv">Más...</a>';
}else if (HelpItem=='euadvlan'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br>' +
                                        'La mayoría del software audiovisual popular usa UPnP. Permite detectar su dispositivo en la red. Si cree que UPnP puede comprometer la seguridad, puede deshabilitarlo aquí. Para que el router no respondan a las solicitudes de internet maliciosas, debería estar habilitado el Bloqueo de ICMP Ping. Multicast streams se usan en funciones de red avanzadas, como IPTV, y los distribuye su ISP.<BR><BR> '+
                                        '<a href="helpadvanced.html#LANAdv">Más...</a>';

}else if (HelpItem=='eufwdmz'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br>' +
                                        'Habilite la opción DMZ solo como el último recurso. Si está teniendo problemas al utilizar una aplicación desde un ordenador que está detrás del router. Está fuera de la protección del firewall. Dirección IP introducida. Mientras por defecto tiene todas las solicitudes de puertos dirigidas hacia él. Solo debería usarse como una herramienta para solucionar problemas. Durante breves periodos de tiempo.<BR><BR>' +
                                        '<a href="helpadvanced.html#Firewall">Más...</a>';

}else if (HelpItem=='euwizintro'){
 document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' +
 						  'This wizard will guide you through a step-by-step process to configure your new D-Link router and connect to the Internet.<p>' +
 						  'There are three steps to configure your router.<p>' + 
			 'Step 1, in order to protect your security, Change your <%ejGetOther(ProdInfo,ModemVer)%> router password,<p>' + 
 						  'Step 2, Select Internet connection type, input the information provided by ISP. <p>' + 
 						  'Step 3, you must restart your router.<p>' +
 						  '<a href="helpbasic.html#Internet">More...</a>';

 						  
}else if (HelpItem=='euwizpass'){
 document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' +
 						  'The default password is "admin", in orde to secure your network , please modify the password.<p>' +
 						  '<strong>note:</strong>  Confirm Password must be same as "New Password".<p>' + 
 						  'Of course, you can click  "skip" to ignore the step.<p>' + 
 						  '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizisp'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						  'Please select your Country and ISP, the PVC information will display Automatically. <p>Of course, you can modify the information if you can not find the country and ISP in the list below, you can select the "Others", then input the "VPI" and "VCI", select the  right Connection Type."<p>' +
						  '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizpppuser'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Please input  "username" and "password" provided by your ISP, and confirm the password is correct.<p>' + 
						   'If you can not go on next step, maybe the username or password is false, you should contact your ISP  right now.<P>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizsum'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Now, the setup will be finished. If you ensure the setting information correctly, you can click "Restart" make the setup effect, and the router will reboot.<p>' + 
						   'Of course, you can Click "Back" to review or modify settings.<p>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizprtcl'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Select the appropriate Internet connection type based on the information as provided by your ISP.<p>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizppp'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						  'Please enter the information exactly as shown taking note of upper and lower cases provided by your ISP. <p>' +
						  'The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>'+
						  '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizdyn'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Please enter the appropriate information below as provided by your ISP. The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>' + 
						 'Maybe, you have to input your PC  MAC address  if ISP requires , and you can click the button to copy it.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='euwizstatic'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Please enter the appropriate information below as provided by your ISP.The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>' + 
						 'You should input correct Ip address, SubnetMask, DefaultGateway and DNS information. By the way, if you select to keep defaultGateway and DNS information blank,  they should been gotten automatically.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';

}else if (HelpItem=='euwizreboot'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'The wizard page allows you to reboot your router, as well as restore it from  what you have changed. You can also backup your settings at a point when you have completed all your changes.<p>' + 
						 'If you ever need to automatically reconfigure your router,you can then use the saved file to restore to your favoured settings automatically.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='portmapping'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Port Mapping supports multiple ports to PVC and bridging groups. Each group will perform as an independent network. To support this feature, you must create mapping groups with appropriate LAN and WAN interfaces using the Add button.<p>' + 
						 'The Remove button will remove the grouping and add the ungrouped interfaces to the Default group. Only the default group has IP interface.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='routing'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'The Routing page allows you to set default gateway or Automatic Assigned Default Gateway. <p>' + 
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='wlschedule'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Calendario le permite crear la programación de la aplicación de normas para su Wireless (activar / desactivar).<p>' + 
						 '<a href="helpbasic.html#Internet">More...</a>';


}





