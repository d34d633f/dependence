if (HelpItem=='deviceinfo'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Esta página muestra un resumen del estado de su router, incluida la versión del software del dispositivo, así como un resumen de la configuración a internet, incluidos el estado Ethernet y el estado inalámbrico.<br><br>' +
                                        '<a href="helpstatus.html#DeviceInfo">Más...</a>';

} else if (HelpItem=='connectclients'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Exhibe la lista de los clientes conectados actualmente con esta rebajadora, separada en listados sin hilos de los clientes y de los clientes del LAN. Los clientes sin hilos enumeran demostraciones usted todo el PC/clients sin hilos conectado actualmente. Los clientes del LAN enumeran demostraciones usted todas las direcciones dinámicamente asignadas activas del IP de DHCP incluyendo la radio y PC/clients conectado Ethernet.<br><br>' +
                                        '<a href="helpstatus.html#WirelessClients">Más...</a>';

} else if (HelpItem=='dhcpclient'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'This is a list of all LAN clients thatare currently connected to your wireless router.<br><br>' +
                                        '<a href="helpmenu.html">Más...</a>';
} else if (HelpItem=='log'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Check the log frequently to detect unauthorized network usage.<br><br>' +
                                        '<a href="helpstatus.html#Logs">Más...</a>';

} else if (HelpItem=='statistics'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'Muestra la lista de clientes que están conectados en ese momento al router, diferenciando los clientes inalámbricos y los clientes LAN.La lista de clientes inalámbricos recoge todos los PC o clientes inalámbricos conectados actualmente. La lista de clientes LAN muestra todas las direcciones IP asignadas automáticamente por DHCP y activas, incluidos los PC o clientes Ethernet e inalámbricos conectados.' +
                                        '<a href="helpstatus.html#Statistics">Más...</a>';

}else if (HelpItem=='ber'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
                                        'La prueba de la tarifa de error de pedacito del ADSL (AZUFAIFA) determina la calidad de la conexión del ADSL. ' +
                                        'de la prueba es hecha transfiriendo las células ociosas que contienen un patrón sabido y que comparan los datos recibidos con este patrón sabido para comprobar para saber si hay cualquier error.<br><br>' +
                                        '<a href="helpstatus.html#BER">Más...</a>';
}
else if (HelpItem=='routingtable'){
  document.getElementById('helpLabel').innerHTML = '<b>Consejos útiles...</b> <br><br> ' +
  													'La encaminamiento Info demuestra a tabla de encaminamiento estática cuál incluye la destinación, el subnet mask y gatway..<br><br>'+
                                        '<a href="helpstatus.html#RoutingInfo">Más...</a>';
}