if (HelpItem=='euwan'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br>' +
                                        "Agli utenti che utilizzano per la prima volta il prodotto si consiglia l'utilizzo del programma Setup Wizard.  Cliccando sul pulsante Setup Wizard, l'utente viene guidato passo passo nell'esecuzione della procedura di impostazione della connessione ADLS.<br><br>" +
                                        "Gli utenti esperti che dispongono delle impostazioni fornite dal proprio Internet Service Provider (ISP) possono selezionare l'opzione Configurazione manuale.<br><br>" +
                                        "Durante l'inserimento di nome utente e password è necessario distinguere tra caratteri minuscoli e maiuscoli.  La maggior parte dei problemi di connessione sono dovuti a un'errata combinazione di nome utente e password.<br><br> "+
                                        '<a href="helpbasic.html#Internet">Ulteriori informazioni...</a>';
}else if (HelpItem=='euwireless'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br>' +
                                        'La prima operazione richiesta per rendere più sicura la rete wireless consiste nel modificare il nome della rete SSID (Wireless Network Name).  Utilizzare un nome familiare che non contenga informazioni personali.<BR><BR> ' +
                                        'Abilitare la funzione Scansione automatica del canale in modo che il router possa selezionare il canale migliore per un funzionamento ottimale della rete wireless.<BR><BR> ' + 
										"Nascondendo la rete wireless si incrementa ulteriormente il livello di sicurezza. In questo modo, quando un client wireless esegue la scansione, la rete non viene visualizzata nell'elenco delle reti disponibili.  Per instaurare una connessione wireless al router è necessario inserire manualmente il nome di rete wireless (SSID) per ciascun dispositivo.  (Prendere nota e tenere a portata di mano il valore del parametro SSID).<BR><BR>" + 
                                        'Se la sicurezza wireless è stata abilitata, prendere nota della chiave di cifratura.  La chiave di cifratura e il nome della rete SSID devono essere specificati per ogni dispositivo wireless da connettere alla rete.<br><br>' + 
										'<a href="helpbasic.html#Wireless">Ulteriori informazioni...</a>';
}else if (HelpItem=='eulan'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br>' +
                                        "Se la rete dispone già di un server DHCP o se si utilizzano indirizzi IP statici per tutti i dispositivi connessi, deselezionare l'opzione Server DHCP per disabilitare la funzionalità.<BR><BR> " + 
										'Se la rete utilizza dispositivi che devono avere un indirizzo IP fisso, aggiungere una prenotazione DHCP per ciascuno di essi.<br><br>' + 
										'<a href="helpbasic.html#Local">Ulteriori informazioni...</a>';
}else if (HelpItem=='eublock'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br>' +
                                        "Per abilitare l'accesso a Internet anche nelle fasce orarie non consentite dalla funzione Limitazione tempo di accesso, selezionare la casella Abilita e cliccare su Salva impostazioni. Per ripristinare le limitazioni definite dalla funzione Limitazione tempo di accesso, selezionare la casella disabilita.<br><BR> " + 
										'<a href="helpbasic.html#Parental">Ulteriori informazioni...</a>';

}else if (HelpItem=='eudatetime'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br>' +
                                        "Una corretta impostazione della data e dell'ora permette di configurare con precisione il parametro Limitazione tempo di accesso della sezione Controllo parentale.<br><br>" +
                                        "L'abilitazione della configurazione automatica dell'ora legale assicura la correttezza della data e dell'ora utilizzate dal router nel corso dell'anno.<BR><BR> "+
                                        '<a href="helpbasic.html#Time">Ulteriori informazioni...</a>';
}else if (HelpItem=='euadvwlan'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br>' +
                                        'Per queste opzioni non è necessario modificare le impostazioni di default al fine di consentire un corretto funzionamento del router in modalità wireless. L\'opzione Potenza di trasmissione corrisponde alla potenza del segnale radio. Se si aggiunge una nuova antenna ad alto rendimento è necessario ridurre la potenza per non superare i limiti operativi.<br><br>' +
                                        '<a href="helpadvanced.html#WirelessAdv">Ulteriori informazioni...</a>';
}else if (HelpItem=='euadvlan'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br>' +
                                        'UPnP è utilizzato per molti software audio e video diffusi sul mercato. Consente l\'individuazione automatica del dispositivo sulla rete. Se si ritiene che l\'utilizzo della funzione UPnP possa provocare problemi di sicurezza, è possibile disabilitarla. La funzione Bloccaggio ICMP Ping può essere abilitata in modo che il router non risponda a richieste potenzialmente pericolose provenienti da Internet. I Multicast stream sono utilizzati da funzioni di rete avanzate come IPTV e sono distribuiti dall\'ISP<BR><BR> '+
                                        '<a href="helpadvanced.html#LANAdv">Ulteriori informazioni...</a>';

}else if (HelpItem=='eufwdmz'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br>' +
                                        'Abilitare l\'opzione DMZ solo in caso di reale necessità. Se si presentano problemi durante l\'esecuzione di un\'applicazione su un computer mascherato dal router. Poichè viene posizionata al di fuori della protezione del firewall. Indirizzo IP inserito. Mentre per default tutte le richieste delle porte vengono a esso inoltrate. Dovrebbe essere utilizzato esclusivamente come strumento di risoluzione degli errori. Per brevi intervalli di tempo.<BR><BR>' +
					/*					'Non-UDP/TCP/ICMP LAN Sessions is normally enabled. It facilitates single VPN connections to a remote host.<br><br>'+*/
                                        '<a href="helpadvanced.html#Firewall">Ulteriori informazioni...</a>';

}else if (HelpItem=='euwizintro'){
 document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' +
 						  'This wizard will guide you through a step-by-step process to configure your new D-Link router and connect to the Internet.<p>' +
 						  'There are three steps to configure your router.<p>' + 
			 'Step 1, in order to protect your security, Change your <%ejGetOther(ProdInfo,ModemVer)%> router password,<p>' + 
 						  'Step 2, Select Internet connection type, input the information provided by ISP. <p>' + 
 						  'Step 3, you must restart your router.<p>' +
 						  '<a href="helpbasic.html#Internet">More...</a>';

 						  
}else if (HelpItem=='euwizpass'){
 document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' +
 						  'The default password is "admin", in orde to secure your network , please modify the password.<p>' +
 						  '<strong>note:</strong>  Confirm Password must be same as "New Password".<p>' + 
 						  'Of course, you can click  "skip" to ignore the step.<p>' + 
 						  '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizisp'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						  'Please select your Country and ISP, the PVC information will display Automatically. <p>Of course, you can modify the information if you can not find the country and ISP in the list below, you can select the "Others", then input the "VPI" and "VCI", select the  right Connection Type."<p>' +
						  '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizpppuser'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Please input  "username" and "password" provided by your ISP, and confirm the password is correct.<p>' + 
						   'If you can not go on next step, maybe the username or password is false, you should contact your ISP  right now.<P>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizsum'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Now, the setup will be finished. If you ensure the setting information correctly, you can click "Restart" make the setup effect, and the router will reboot.<p>' + 
						   'Of course, you can Click "Back" to review or modify settings.<p>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizprtcl'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Select the appropriate Internet connection type based on the information as provided by your ISP.<p>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizppp'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						  'Please enter the information exactly as shown taking note of upper and lower cases provided by your ISP. <p>' +
						  'The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>'+
						  '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizdyn'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Please enter the appropriate information below as provided by your ISP. The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>' + 
						 'Maybe, you have to input your PC  MAC address  if ISP requires , and you can click the button to copy it.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='euwizstatic'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Please enter the appropriate information below as provided by your ISP.The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>' + 
						 'You should input correct Ip address, SubnetMask, DefaultGateway and DNS information. By the way, if you select to keep defaultGateway and DNS information blank,  they should been gotten automatically.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';

}else if (HelpItem=='euwizreboot'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'The wizard page allows you to reboot your router, as well as restore it from  what you have changed. You can also backup your settings at a point when you have completed all your changes.<p>' + 
						 'If you ever need to automatically reconfigure your router,you can then use the saved file to restore to your favoured settings automatically.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='portmapping'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Port Mapping supports multiple ports to PVC and bridging groups. Each group will perform as an independent network. To support this feature, you must create mapping groups with appropriate LAN and WAN interfaces using the Add button.<p>' + 
						 'The Remove button will remove the grouping and add the ungrouped interfaces to the Default group. Only the default group has IP interface.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='routing'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'The Routing page allows you to set default gateway or Automatic Assigned Default Gateway. <p>' + 
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='wlschedule'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Agenda ti permette di creare regole di programmazione che devono essere applicati per il wireless (attivare / disattivare).<p>' + 
						 '<a href="helpbasic.html#Internet">More...</a>';


}





