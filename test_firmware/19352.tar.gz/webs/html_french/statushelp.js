﻿if (HelpItem=='deviceinfo'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        "Cette page affiche un aperçu de l'état de votre routeur, notamment la version du logiciel du périphérique et un résumé de votre configuration Internet et de l'état des connexions sans fil et Ethernet.<br><br>" +
                                        '<a href="helpstatus.html#DeviceInfo">En savoir plus...</a>';

} else if (HelpItem=='connectclients'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Montre la liste de clients actuellement reliés à ce couteau, séparé les listes sans fil dans clients et de clients de LAN. Les clients sans fil énumèrent des expositions vous tout le PC/clients sans fil actuellement relié. Les clients de LAN énumèrent des expositions vous toutes les adresses dynamiquement assignées actives d\'IP de DHCP comprenant la radio et le PC/clients relié par Ethernet.<br><br>' +
                                        '<a href="helpstatus.html#WirelessClients">En savoir plus...</a>';

} else if (HelpItem=='dhcpclient'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Affiche la liste des clients actuellement connectés à ce routeur, classés en clients sans fil et clients LAN. La liste des clients sans fil affiche tous les PC/clients sans fil actuellement connectés. La liste des clients LAN affiche toutes les adresses DHCP attribuées de manière dynamique, y compris les PC/clients sans fil et Ethernet connectés.<br><br>' +
                                        '<a href="helpmenu.html">En savoir plus...</a>';
} else if (HelpItem=='log'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Check the log frequently to detect unauthorized network usage.<br><br>' +
                                        '<a href="helpstatus.html#Logs">En savoir plus...</a>';

} else if (HelpItem=='statistics'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        "Cette page affiche les statistiques du réseau et du transfert de données de votre routeur utilisées par les techniciens de D-Link pour déterminer si votre routeur fonctionne correctement. Les informations fournies sont à but informatif et n'affectent pas le fonctionnement de votre routeur." +
                                        '<a href="helpstatus.html#Statistics">En savoir plus...</a>';

}else if (HelpItem=='ber'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'TLe test ADSL Bit Error Rate (BER) détermine la qualité de la connexion ADSL. Le test est effectué en transférant des cellules cachées contenant un modèle connu et en le comparant avec celui des cellules reçues en retour, pour vérifier si il y a des erreurs.<br><br>' +
                                        '<a href="helpstatus.html#BER">En savoir plus...</a>';
}
else if (HelpItem=='routingtable'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
  													'L\'information de cheminement montre à la table de cheminement statique ce qui incluent la destination, le subnet mask et gatway.y.<br><br>'+
                                        '<a href="helpstatus.html#RoutingInfo">En savoir plus...</a>';
}