#!/bin/sh
xmldbc -t "UDEVSTART:5:udevstart"
#udevstart

