#!/bin/sh
mkdir -p /var/tmp/storage
/etc/scripts/usbmount_helper.sh
