#!/bin/sh

# bouble - 20101209 - enable switch port base qos
# Enable QoS and use WFQ by default
# rtlioc qos_init 0	<< --- ..WFQ
# rtlioc qos_init 1	<< --- ..SPQ
service MACCTRL restart
