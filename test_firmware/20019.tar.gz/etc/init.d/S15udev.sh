#!/bin/sh
udevd --daemon
udevstart
