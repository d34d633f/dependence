<?
set("/device/session/timeout", "180");
?>
