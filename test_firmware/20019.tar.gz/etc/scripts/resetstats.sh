#!/bin/sh
echo 0 > /proc/wlan0/stats

