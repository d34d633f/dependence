#!/bin/sh
echo [$0]: $1 ... > /dev/console
if [ "$1" = "start" ]; then
event DISKUP add "/etc/events/disk.sh"
event DISKDOWN add "/etc/events/disk.sh"
fi
