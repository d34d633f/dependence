<?
include "/htdocs/phplib/xnode.php";
$FILE= "/var/maclistfile";

fwrite("w",$START, "#!/bin/sh\n");
fwrite("w",$STOP,  "#!/bin/sh\n");
fwrite("w",$FILE,  "");
$cmd = "rtlioc macfilter reset\n";
fwrite("a",$STOP, $cmd);			
fwrite("a",$START, $cmd);

foreach("/acl/macctrl/entry")
{
	$uid = query("uid");
	$enable = query("enable");
	$mac = query("mac");
	if($enable == 1) fwrite("a",$FILE, $mac."\n");		
}

$policy = query("/acl/macctrl/policy");
if($policy == "ACCEPT")
{																
	$cmd = "rtlioc macfilter drop ".$FILE."\n";
	fwrite("a",$START, $cmd);						
	
	$cpumac = query("/runtime/devdata/lanmac");
	$cmd = "rtlioc cpumac ".$cpumac."\n";
	fwrite("a",$START, $cmd);
}
else if($policy == "DROP")
{		
	$cmd = "rtlioc macfilter allow ".$FILE."\n";
	fwrite("a",$START, $cmd);						
	
	$cpumac = query("/runtime/devdata/lanmac");
	$cmd = "rtlioc cpumac ".$cpumac."\n";
	fwrite("a",$START, $cmd);
}

?>
