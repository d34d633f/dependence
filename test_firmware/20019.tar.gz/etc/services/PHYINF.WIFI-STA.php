<?
include "/etc/services/PHYINF/phywifi.php";
wificonfig("WIFI-STA");
?>
