<?
include "/htdocs/phplib/trace.php";
include "/htdocs/phplib/phyinf.php";
include "/etc/services/TRAFFICCTRL/lib_common.php";

function trafficctrl_setup($name)
{
    startcmd("echo ".$name." Start Qos and Traffic Control system ...\n");

    $infp = XNODE_getpathbytarget("", "inf", "uid", $name, 0);
    if ($infp=="")
	{
		SHELL_info($_GLOBALS["START"], "trafficctrl_setup: (".$name.") no interface.");
		SHELL_info($_GLOBALS["STOP"],  "trafficctrl_setup: (".$name.") no interface.");
		error("9");
		return;
	}
	
	/* Is this interface active ? */
	$active	= query($infp."/active");
	$trafficctrls	= query($infp."/trafficctrl");
	if ($active!="1" || $trafficctrls == "")
	{
		SHELL_info($_GLOBALS["START"], "trafficctrl_setup: (".$name.") not active.");
		SHELL_info($_GLOBALS["STOP"],  "trafficctrl_setup: (".$name.") not active.");
		error("8");
		return;
	}
	
	/* Get the profile */
	$trafficctrlp = XNODE_getpathbytarget("/trafficctrl", "entry", "uid", $trafficctrls, 0);
	if ($trafficctrlp=="")
	{
		SHELL_info($_GLOBALS["START"], "trafficctrl_setup: (".$name.") no profile.");
		SHELL_info($_GLOBALS["STOP"],  "trafficctrl_setup: (".$name.") no profile.");
		error("9");
		return;
	}
	
	start_setup($trafficctrlp);
	stop_setup($trafficctrlp);
}
?>