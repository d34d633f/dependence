<?/*  J.Su create for PLC HNAP   *
   *  Get PLC Firmware version   *
   */
?>
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8
<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

/*fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "plc_util -i br0 -I -v > /dev/console\n");*/
/*$Status = query("/runtime/plcnode/hnap/getdeviceinfo");
if($Status =="OK")
$Result = $Status ;
else
$Result = "ERROR";*/

$FWVer=query("/runtime/plcnode/deviceinfo/fwversion");
if($FWVer != "")
$Result = "OK" ;
else
$Result = "ERROR";

?>
<soap:Envelope  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetPLCFirmwareVersionResponse xmlns="http://purenetworks.com/HNAP1/">
      <GetPLCFirmwareVersionResult><?=$Result?></GetPLCFirmwareVersionResult>
      <FirmwareVersion><?=$FWVer?></FirmwareVersion>
    </GetPLCFirmwareVersionResponse>
  </soap:Body>
</soap:Envelope>