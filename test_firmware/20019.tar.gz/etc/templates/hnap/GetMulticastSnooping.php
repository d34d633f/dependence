HTTP/1.1 200 OK 
Content-Type: text/xml; charset=utf-8 
Content-Length: <Number of Bytes/Octets in the Body> 
<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";

if( query("/device/multicast/igmpsnooping") == "1" )
{ 
	$enable = "true"; 
}
else
{ 
	$enable = "false"; 
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
<soap:Body> 
<GetMulticastSnoopingResponse xmlns="http://purenetworks.com/HNAP1/"> 
<GetMulticastSnoopingResult>OK</GetMulticastSnoopingResult> 
<Enabled><?=$enable?></ Enabled> 
</GetMulticastSnoopingResponse> 
</soap:Body> 
</soap:Envelope>
