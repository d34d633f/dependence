<?/*  J.Su create for PLC HNAP    
   *  Get PLC Info:                                
   *  Interface,  Enable/Disable       
   *  Mode,       AV/AV+/AV500      
   *  CCoMode,    Auto/Force          
   *  Security,   Public/Private           
   *  MAC     ,   Mac Address             
   *  MaxBitRate, 0~500                    
   *  MemberNum,  0~64                   
   *   
   *  -plcd will execute "plc_util -i br0 -I" to get the 
   *    device and member info  
   */
?>
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
/*fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "plc_util -i br0 -I > /dev/console\n");*/
?>


<?
include "/htdocs/phplib/xnode.php"; 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

/*$Status = query("/runtime/plcnode/hnap/getdeviceinfo");
if($Status =="OK")
$Result = $Status ;
else
$Result = "ERROR";*/

$error_cnt=0;

$PlcInterface = query("/runtime/plcnode/deviceinfo/interface");
if($PlcInterface != "Enable" && $PlcInterface != "Disable" )
{$error_cnt++;}

$PlcMode      = query("/runtime/plcnode/deviceinfo/avmode");
if($PlcMode != "AV" && $PlcMode != "AV+" && $PlcMode != "AV500")
{$error_cnt++;}

$CCoMode      = query("/runtime/plcnode/deviceinfo/cco");
if($CCoMode != "Auto" && $CCoMode != "Force")
{$error_cnt++;}
    
$SecurityMode = query("/runtime/plcnode/deviceinfo/security");
if($SecurityMode != "Public" && $SecurityMode != "Private")
{$error_cnt++;}

$MacAddress   = query("/runtime/plcnode/deviceinfo/mac");
if($MacAddress == "")
{$error_cnt++;}

$MaxRate      = query("/runtime/plcnode/deviceinfo/maxrate");
if($MaxRate < 0 || $MaxRate >500)
{$error_cnt++;}

$MemberNum    = query("/runtime/plcnode/deviceinfo/membernum");
if($MemberNum =="")
$MemberNum = 0;

if($MemberNum < 0 || $MemberNum >64)
{$error_cnt++;}

/*$Result = query("/runtime/plcnode/hanp/getdeviceinfo");
if($Result == "" || error_cnt >0)
$Result = "ERROR";*/

if(error_cnt >0)
$Result = "ERROR";
else
$Result = "OK";

?>
<soap:Envelope  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetPLCInfoResponse xmlns="http://purenetworks.com/HNAP1/">
      <GetPLCInfoResult><?=$Result?></GetPLCInfoResult>
      <PLCInterface><?=$PlcInterface?></PLCInterface>
      <PLCMode><?=$PlcMode?></PLCMode>
      <CCoMode><?=$CCoMode?></CCoMode>
      <SecurityMode><?=$SecurityMode?></SecurityMode>
      <PLCMACAddress><?=$MacAddress?></PLCMACAddress>
      <MaxBitRate><?=$MaxRate?></MaxBitRate>
      <PLCMemberNumber><?=$MemberNum?></PLCMemberNumber>
    </GetPLCInfoResponse>
  </soap:Body>
</soap:Envelope>