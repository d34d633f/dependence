HTTP/1.1 200 OK 
Content-Type: text/xml; charset=utf-8 
Content-Length: <Number of Bytes/Octets in the Body> 
<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
$nodebase="/runtime/hnap/SetMulticastSnooping/";
$enable = query($nodebase."Enabled");
$result = "OK";

if( $enable == "true")
{ 
	set("/device/multicast/igmpsnooping", "1");
}
else if( $enable == "false")
{ 
	set("/device/multicast/igmpsnooping", "0");
}
else
{
	$result = "ERROR";
}

fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "echo \"[$0]-->SetMulticastSnooping Change\" > /dev/console\n");
if($result=="OK")
{
	fwrite("a",$ShellPath, "/etc/scripts/dbsave.sh > /dev/console\n");
	fwrite("a",$ShellPath, "service MULTICAST restart > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' > /dev/console\n");
	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error in setting, so we do nothing...\" > /dev/console");
}

?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> 
<soap:Body> 
<SetMulticastSnoopingResponse xmlns="http://purenetworks.com/HNAP1/"> 
<SetMulticastSnoopingResult><?=$result?></SetMulticastSnoopingResult> 
</SetMulicastSnoopingResponse> 
</soap:Body> 
</soap:Envelope>
