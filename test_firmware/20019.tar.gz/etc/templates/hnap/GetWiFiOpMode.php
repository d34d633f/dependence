HTTP/1.1 200 OK 
Content-Type: text/xml; charset=utf-8 
 
<? 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/webinc/config.php";
$path_phyinf_wds = XNODE_getpathbytarget("", "phyinf", "uid", $WDS-1, 0);
$path_wlan_wifi = XNODE_getpathbytarget("/wifi", "entry", "uid", query($path_phyinf_wlan."/wifi"), 0);
$opmode	= get("x",$path_wlan_wifi."/opmode");
if (query("/device/layout")=="router") 
{
	if (query($path_phyinf_wds."/active")=="1")
	{
		$wifiopmode = "WDS";
	}
	else if ($opmode=="AP")
	{
		$wifiopmode = "AP"; 
	}
	else
	{
		$wifiopmode = "AP";
	}
} 
else if (query("/device/layout")=="bridge")
{
	if ($opmode=="AP")
	{
		$wifiopmode = "AP";
	}
	else if ($opmode=="REPEAT")
	{
			$wifiopmode = "Repeater";
	}
	else
	{
		$wifiopmode = "AP Client";
	}
}
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body> 
	<GetWiFiOpModeResponse xmlns="http://purenetworks.com/HNAP1/"> 
	<GetWiFiOpModeResult>OK</GetWiFiOpModeResult> 
	<WiFiOpMode><?=$wifiopmode?></WiFiOpMode> 
	</GetWiFiOpModeResponse> 
  </soap:Body> 
</soap:Envelope>

