<?/*  J.Su create for PLC HNAP    *
   *      -Get all PLC member info in the same network
   *      -plcd will execute "plc_util -i br0 -I" to get the 
   *        device and member info   
   */
?>
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
include "/htdocs/phplib/xnode.php";
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

/*fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "plc_util -i br0 -I > /dev/console\n");*/

$Status = query("/runtime/plcnode/hnap/getdeviceinfo");
if($Status == "ERROR" || $Status == "")
$Result = "ERROR" ;
else
$Result = "OK";

?>
<soap:Envelope  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetPLCMemberINfoResponse xmlns="http://purenetworks.com/HNAP1/">
      <GetPLCMemberInfoResult><?=$Result?></GetPLCMemberInfoResult>
      <PLCMemberInfo>  
          <?
            foreach("/runtime/plcnode/deviceList/entry")
            {
                echo "<MemberName>".query("name")."</MemberName>\n";
                echo "          <MemberMac>".query("mac")."</MemberMac>\n";
                echo "          <MemberPLCMode>".query("avmode")."</MemberPLCMode>\n";
                echo "          <MemberTxPHYRate>".query("linkrate")."</MemberTxPHYRate>\n";
                echo "          <MemberRxPHYRate>".query("rxrate")."</MemberRxPHYRate>\n";
                echo "          <MemberAvgSNR>".scut(query("snr"),0,"V")."</MemberAvgSNR>\n";
                echo "          <MemberAvgAttenuation>".scut(query("atn"),0,"V")."</MemberAvgAttenuation>\n";
            }
          ?>
      </PLCMemberInfo>   
    </GetPLCMemberINfoResponse>
  </soap:Body>
</soap:Envelope>