<?/*  J.Su create for PLC HNAP              
   *                                        
   *  string SetPLCInterface
   *         (in string PLCInterface)      
   *  
   *  PLCInterface: Enable/Disable          
   *                                        
   */
?>
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
$nodebase="/runtime/hnap/SetPLCInterface/";
$dev_intf = query($nodebase."PLCInterface");
$Result = "REBOOT";

fwrite("w",$ShellPath, "#!/bin/sh\n");
if($dev_intf != "Enable" && $dev_intf == "Disable" )
{ $Result = "ERROR"; }
else
{ fwrite("a",$ShellPath, "plc_util -i br0 -s INTF*".$dev_intf." > /dev/console\n"); }

//$Result = query("/runtime/plcnode/hanp/setdeviceinfo");
?>


<soap:Envelope  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <SetPLCInterfaceResponse xmlns="http://purenetworks.com/HNAP1/">
      <SetPLCInterfaceResult><?=$Result?></SetPLCInterfaceResult>
    </SetPLCInterfaceResponse>
  </soap:Body>
</soap:Envelope>