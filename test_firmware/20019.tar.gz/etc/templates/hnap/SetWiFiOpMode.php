HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/trace.php"; 
include "/htdocs/webinc/config.php";  
$path_phyinf_wds = XNODE_getpathbytarget("", "phyinf", "uid", $WDS-1, 0);
$path_wlan_wifi = XNODE_getpathbytarget("/wifi", "entry", "uid", query($path_phyinf_wlan."/wifi"), 0);
$nodebase="/runtime/hnap/SetWiFiOpMode/";
$WiFiOpMode = query($nodebase."WiFiOpMode");
if ($WiFiOpMode == "AP") 
{
	set($path_wlan_wifi."/opmode","AP");
	$result = "REBOOT";
} 
else if ($WiFiOpMode == "AP Client")
{
	set($path_wlan_wifi."/opmode","STA");
	$result = "REBOOT";
} 
else if ($WiFiOpMode == "WDS")
{
	set("/device/layout","router");
	set($path_wlan_wifi."/opmode","AP");
	set($path_phyinf_wds."/active","1");
	$result = "REBOOT";
}
else if ($WiFiOpMode == "Repeater")
{
	set("/device/layout","bridge");
	set($path_wlan_wifi."/opmode","REPEAT");
	$result = "REBOOT";
}
else
{
	$result = "ERROR_BAD_WiFiOpMode";
}

fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "echo [$0] > /dev/console\n");
if( $result == "REBOOT" )
{
	
       fwrite("a",$ShellPath, "service DEVICE.LAYOUT stop > /dev/console \n");
       fwrite("a",$ShellPath, "service DEVICE.HOSTNAME stop > /dev/console\n");
	fwrite("a",$ShellPath, "/etc/scripts/dbsave.sh > /dev/console\n");
	fwrite("a",$ShellPath, "service WIFI.WLAN-1 restart > /dev/console\n");
	fwrite("a",$ShellPath, "xmldbc -s /runtime/hnap/dev_status '' \n");
	set("/runtime/hnap/dev_status", "ERROR");
}
else
{
	fwrite("a",$ShellPath, "echo \"We got a error, so we do nothing...\"> /dev/console ");
}
?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
	<SetWiFiOpModeResponse xmlns="http://purenetworks.com/HNAP1/"> 
	<SetWiFiOpModeResult><?=$result?></SetWiFiOpModeResult> 
	</SetWiFiOpModeResponse > 
  </soap:Body>
</soap:Envelope>

