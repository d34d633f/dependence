<?/*  J.Su create for PLC HNAP              
   *                                        
   *  string SetCCoMode
   *         (in string CCoMode)      
   *  
   *  CCoMode: Auto/Force          
   *                                        
   */
?>
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
$nodebase="/runtime/hnap/SetCCoMode/";
$CCoMode = query($nodebase."CCoMode");
$Result = "REBOOT";

fwrite("w",$ShellPath, "#!/bin/sh\n");
if($CCoMode == "Auto")
{ fwrite("a",$ShellPath, "plc_util -i br0 -s CCO*Auto > /dev/console\n");
}
else if($CCoMode == "Force")
{ fwrite("a",$ShellPath, "plc_util -i br0 -s CCO*Force > /dev/console\n");
}
else
{ $Result = "ERROR"; }


//$Result = query("/runtime/plcnode/hanp/setdeviceinfo");

?>


<soap:Envelope  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <SetCCoModeResponse xmlns="http://purenetworks.com/HNAP1/">
      <SetCCoModeResult><?=$Result?></SetCCoModeResult>
    </SetCCoModeResponse>
  </soap:Body>
</soap:Envelope>