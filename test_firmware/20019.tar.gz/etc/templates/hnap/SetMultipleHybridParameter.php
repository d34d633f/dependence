<?/*  J.Su create for Hybrid HNAP   
 *    Use this method to set multiple
 *    hybrid parameters
 */
   
?>
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
include "/htdocs/phplib/xnode.php"; 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
$nodebase="/runtime/hnap/SetMultipleHybridOpParameter/";

$Result = "OK";
/*MaxUtilization PLC*/
$MaxUti_PLC = query($nodebase."MaxUtilization_PLC");
if($MaxUti_PLC < 0 || $MaxUti_PLC > 100 || $MaxUti_PLC =="")
$Result = "ERROR_BAD_HybridOpMode";

/*UtilizationChange PLC*/
$UtiChange_PLC = query($nodebase."UtilizationChange_PLC");
if($UtiChange_PLC < 0 || $UtiChange_PLC > 100 || $UtiChange_PLC =="")
$Result = "ERROR_BAD_HybridOpMode";

/*LinkCapacityChange PLC*/
$LinkChange_PLC = query($nodebase."LinkCapacityChange_PLC");
if($LinkChange_PLC < 0 || $LinkChange_PLC > 500 || $LinkChange_PLC =="")
$Result = "ERROR_BAD_HybridOpMode";




/*MaxUtilization WiFi*/
$MaxUti_WiFi = query($nodebase."MaxUtilization_WiFi");
if($MaxUti_WiFi < 0 || $MaxUti_WiFi > 100 || $MaxUti_WiFi =="")
$Result = "ERROR_BAD_HybridOpMode";

/*UtilizationChange WiFi*/
$UtiChange_WiFi = query($nodebase."UtilizationChange_WiFi");
if($UtiChange_PLC < 0 || $UtiChange_PLC > 100 || $UtiChange_PLC =="")
$Result = "ERROR_BAD_HybridOpMode";

/*LinkCapacityChange WiFi*/
$LinkChange_WiFi = query($nodebase."LinkCapacityChange_WiFi");
if($LinkChange_WiFi < 0 || $LinkChange_WiFi > 300 || $LinkChange_WiFi =="")
$Result = "ERROR_BAD_HybridOpMode";

/*Set MultipleHybridParameter*/

/*Set MultipleHybridParameter*/
?>
<soap:Envelope  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <SetMultipleHybridParameterResponse xmlns="http://purenetworks.com/HNAP1/">
      <SetMultipleHybridParameterResult><?=$Result?></SetMultipleHybridParameterResult>
    </SetMultipleHybridParameterResponse>
  </soap:Body>
</soap:Envelope>