<?/*  J.Su create for Hybrid HNAP   
 *    Use this method to set device hybrid
 *    operational mode 
 */
   
?>
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
include "/htdocs/phplib/xnode.php"; 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
$nodebase="/runtime/hnap/SetHybridOpMode/";
$OpMode = query($nodebase."HybridOpMode");

if($OpMode =="HR" || $OpMode =="HC" || $OpMode =="HRE")
$Result = "OK";
else
$Result = "ERROR_BAD_HybridOpMode";

/*Set HybridOpMode*/

/*Set HybridOpMode*/
?>
<soap:Envelope  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <SetHybridOpModeResponse xmlns="http://purenetworks.com/HNAP1/">
      <SetHybridOpModeResult><?=$Result?></SetHybridOpModeResult>
    </SetHybridOpModeResponse>
  </soap:Body>
</soap:Envelope>