<?/*  J.Su create for Hybrid HNAP   
 *    Use this method to get multiple hybrid
 *    parameters 
 */
   
?>
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
include "/htdocs/phplib/xnode.php"; 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

$Result = "OK";
/*MaxUtilization PLC*/
$MaxUti_PLC = query("/device/hybrid/plc/maxuti");
if($MaxUti_PLC =="")
$MaxUti_PLC = 0;

if($MaxUti_PLC < 0 || $MaxUti_PLC > 100)
$Result = "ERROR";

/*UtilizationChange PLC*/
$UtiChange_PLC = query("/device/hybrid/plc/utichange");
if($UtiChange_PLC =="")
$UtiChange_PLC = 0;

if($UtiChange_PLC < 0 || $UtiChange_PLC > 100)
$Result = "ERROR";

/*LinkCapacityChange PLC*/
$LinkChange_PLC = query("/device/hybrid/plc/linkchange");
if($LinkChange_PLC =="")
$LinkChange_PLC = 0;

if($LinkChange_PLC < 0 || $LinkChange_PLC > 500)
$Result = "ERROR";

/*MaxUtilization WiFi*/
$MaxUti_WiFi = query("/device/hybrid/wifi/maxuti");
if($MaxUti_WiFi =="")
$MaxUti_WiFi = 0;
if($MaxUti_WiFi < 0 || $MaxUti_WiFi > 100)
$Result = "ERROR";

/*UtilizationChange WiFi*/
$UtiChange_WiFi = query("/device/hybrid/wifi/utichange");
if($UtiChange_WiFi =="")
$UtiChange_WiFi = 0;

if($UtiChange_WiFi < 0 || $UtiChange_WiFi > 100)
$Result = "ERROR";

/*LinkCapacityChange WiFi*/
$LinkChange_WiFi = query("/device/hybrid/wifi/linkchange");
if($LinkChange_WiFi =="")
$LinkChange_WiFi = 0;

if($LinkChange_WiFi < 0 || $LinkChange_WiFi > 300)
$Result = "ERROR";

?>
<soap:Envelope  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetMultipleHybridParameterResponse xmlns="http://purenetworks.com/HNAP1/">
      <GetMultipleHybridParameterResult><?=$Result?></GetMultipleHybridParameterResult>
      <MaxUtilization_PLC><?=$MaxUti_PLC?></MaxUtilization_PLC>
      <UtilizationChange_PLC><?=$UtiChange_PLC?></UtilizationChange_PLC>
      <LinkCapacityChange_PLC><?=$LinkChange_PLC?></LinkCapacityChange_PLC>
      <MaxUtilization_WiFi><?=$MaxUti_WiFi?></MaxUtilization_WiFi>
      <UtilizationChange_WiFi><?=$UtiChange_WiFi?></UtilizationChange_WiFi>
      <LinkCapacityChange_WiFi><?=$LinkChange_WiFi?></LinkCapacityChange_WiFi>
    </GetMultipleHybridParameterResponse>
  </soap:Body>
</soap:Envelope>