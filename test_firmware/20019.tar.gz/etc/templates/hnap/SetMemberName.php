<?/*  J.Su create for PLC HNAP              
   *                                        
   *  string SetMemberName
   *         (in string MemberName
   *          in string MemberMAC)
   *                                        
   */
?>
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";
$nodebase="/runtime/hnap/SetMemberName/";
$name = query($nodebase."MemberName");
$mac  = query($nodebase."MemberMAC");
$Result = "OK";

fwrite("w",$ShellPath, "#!/bin/sh\n");
fwrite("a",$ShellPath, "plc_util -i br0 -s DEVNAME*".$name."*".$mac." > /dev/console\n");

/*$Result = query("/runtime/plcnode/hanp/setdeviceinfo");
if($Result == "")
$Result = "Error";*/
?>


<soap:Envelope  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <SetMemberNameResponse xmlns="http://purenetworks.com/HNAP1/">
      <SetMemberNameResult><?=$Result?></SetMemberNameResult>
    </SetMemberNameResponse>
  </soap:Body>
</soap:Envelope>