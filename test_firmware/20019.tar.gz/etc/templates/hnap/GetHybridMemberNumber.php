<?/*  J.Su create for Hybrid HNAP   
 *    Use this method to get associated device
 *    number via hybrid 
 */
   
?>
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?
include "/htdocs/phplib/xnode.php"; 
echo "\<\?xml version='1.0' encoding='utf-8'\?\>";

$Result = "OK";
/*MaxUtilization PLC*/
$MemberNum = query("/runtime/hybrid/membernum");
if($MemberNum =="")
$MemberNum = 0;

if($MemberNum < 0 || $MemberNum > 64)
$Result = "ERROR";

?>
<soap:Envelope  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetHybridMemberNumberResponse xmlns="http://purenetworks.com/HNAP1/">
      <GetHybridMemberNumberResult><?=$Result?></GetHybridMemberNumberResult>
      <HybridMemberNumber><?=$MemberNum?></HybridMemberNumber>
    </GetHybridMemberNumberResponse>
  </soap:Body>
</soap:Envelope>