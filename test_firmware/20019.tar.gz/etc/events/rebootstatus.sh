xmldbc -s /runtime/reboot/status "1"
