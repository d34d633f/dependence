<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Once your AP or wireless client is configured the way you want it, you can save these settings to a configuration file that can later be loaded in the event that the access point's default settings are restored. To do this, click the <strong>Save</strong> button next to where it says Save Settings to Local Hard Drive.");
?></p>
