<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("If you already have a DHCP server on your network or are using static IP addresses on all the devices on your network, uncheck Enable DHCP Server to disable this feature.");
?></p>
