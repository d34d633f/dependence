<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Schedules are used with a number of other features to define when those features are in effect.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n('Give each schedule a name that is meaningful to you. For example, a schedule for Monday through Friday from 3:00pm to 9:00pm, might be called "After School".');
?></p>
