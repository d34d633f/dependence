<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo I18N("h","After adding new media content to the router, click the Enable or Disable button and then save settings.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo '<a href="/spt_setup.php#MediaServer">'.I18N("h","More...").'</a>';
?></p>
