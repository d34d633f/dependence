<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("<strong>Firmware Update</strong> are released periodically to improve the functionality of your AP or wireless client and also to add features. If you run into a problem with a specific feature of the access point, check our support site by clicking on the <strong>Check Now</strong> and see if an updated version of firmware is available for your access point.");
?></p>

