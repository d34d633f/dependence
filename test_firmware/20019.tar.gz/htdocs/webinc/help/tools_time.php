<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Either enter the time manually by clicking the <strong>Copy Your Computers Time Settings</strong> button, or use the <strong>Automatic Time Configuration</strong> option to have your AP or wireless client synchronize with a time server on the Internet.");
?></p>
