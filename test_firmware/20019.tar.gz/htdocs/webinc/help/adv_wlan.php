<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("It is recommended that you leave these parameters with their default values. Adjusting them could limit the performance of your wireless network.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Use <strong>802.11n</strong> only for countries where it is required.");
?></p>
<!--
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Enabling <strong>WMM</strong> can help control latency and jitter when transmitting multimedia content over a wireless connection.");
?></p>
-->
