<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Enable this option if you want to allow QOS to prioritize wireless traffic.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("There are two options for QOS Type selected,such as priority by Lan port and by protocol,which ensure the right priorities available for your special applications.");
?></p>
