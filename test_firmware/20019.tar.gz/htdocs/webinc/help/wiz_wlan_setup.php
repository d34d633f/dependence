<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<!--
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Wi-Fi Protected Setup provides a more intuitive way of setting up wireless security between the router and the wireless client. Make sure the wireless card supports this feature or uses a certified Windows Vista driver in order to take advantage of this feature.");
?></p>
-->
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("If you are new to networking and have never configured an access point before, click on Launch Wireless Setup Wizard and the access point will guide you through a few simple steps to get your network up and running.");
?></p>
