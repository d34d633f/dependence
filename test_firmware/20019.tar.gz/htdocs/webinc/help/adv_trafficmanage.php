<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Enable this option if you want to allow TRAFFIC MANAGER to control wireless traffic speed.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("For most applications, the traffic manager ensure the right traffic speed and specific traffic manager rules are not required.");
?></p>
