<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("User Limit can set a limit upon the number of wireless clinet. Using user limit, you can prevent scenarios where the DAP-1650 in your network shows performance degradation because it is handing heavy wireless traffic.");
?></p>
