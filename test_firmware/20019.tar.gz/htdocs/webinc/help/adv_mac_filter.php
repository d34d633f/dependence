<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Create a list of MAC addresses and choose whether to allow or deny them access to your network.");
?></p>

