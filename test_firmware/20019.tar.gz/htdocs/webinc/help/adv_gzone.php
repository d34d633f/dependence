<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Use this section to configure the guest zone settings of your access point. The guest zone provides a separate network zone for guest to access Internet.");
?></p>
