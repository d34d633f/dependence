<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo I18N("h","The Storage page contains information about the USB storage drivers or SD cards currently plugged into the device.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo '<a href="/spt_setup.php#Storage">'.I18N("h","More...").'</a>';
?></p>
