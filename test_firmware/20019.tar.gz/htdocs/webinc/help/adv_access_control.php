<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Create a list of MAC addresses and choose whether to allow or deny them access to your network.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Computers that have connected to AP through wireless will be in the Wireless Clinet List. Select a device from the drop down menu and click the arrow to add that device's MAC to the list.");
?></p>
