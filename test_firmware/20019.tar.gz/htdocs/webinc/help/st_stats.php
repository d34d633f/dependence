<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("This is a summary displaying the number of packets that have passed between the Wireless and the LAN since the AP or wireless client was last initialized.");
?></p>
