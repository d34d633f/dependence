<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("If you already have a wireless network setup with Wi-Fi Protected Setup, click on <strong>Add Wireless Device with WPS</strong> to add new device to your wireless network.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("If you are new to wireless networking and have never configured a wireless router before, click on <strong>Wireless Connection Setup Wizard</strong> and the router will guide you through a few simple steps to get your wireless network up and running.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("If you consider yourself an advanced user and have configured a wireless router before, click<strong> Manual Wireless Connection Setup</strong> to input all the settings manually.");
?></p>
