<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<!--<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("For added security, it is recommended that you disable the <strong>WAN Ping Respond</strong> option. Ping is often used by malicious Internet users to locate active networks or PCs.");
?></p> -->
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("It is recommended that you leave these options at their default values. Adjusting them could negatively impact the performance of your wireless network. The options on this page should be changed by advanced users or if you are instructed to by one of our support personnel, as they can negatively affect the performance of your Access Point if configured improperly.");
?></p>
