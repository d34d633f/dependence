<module>
	<service><?=$GETCFG_SVC?></service>
		<device>
			<qos_prio>
				<?echo dump(3, "/device/qos_prio");?>
			</qos_prio>
		</device>
</module>
