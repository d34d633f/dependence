<module>
	<FATLADY>ignore</FATLADY>
	<SETCFG>ignore</SETCFG>
	<service>SAMBA</service>
</module>
