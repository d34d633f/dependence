<module>
	<service>PHYINF.WIFI</service>
	<FATLADY>ignore</FATLADY>
	<SETCFG>ignore</SETCFG>
</module>
