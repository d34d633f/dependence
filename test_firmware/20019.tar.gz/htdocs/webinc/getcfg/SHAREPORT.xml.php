<module>
	<service>SHAREPORT</service>
	<FATLADY>ignore</FATLADY>
	<SETCFG>ignore</SETCFG>
</module>
