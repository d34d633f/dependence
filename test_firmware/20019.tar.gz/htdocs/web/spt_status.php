HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "spt_status";
$TEMP_MYGROUP   = "help";
$TEMP_STYLE		= "help";
include "/htdocs/webinc/templates.php";
?>
