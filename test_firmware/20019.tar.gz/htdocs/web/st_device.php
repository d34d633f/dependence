HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "st_device";
$TEMP_MYGROUP   = "status";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
