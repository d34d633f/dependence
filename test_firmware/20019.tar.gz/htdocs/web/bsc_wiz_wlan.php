<?
include "/htdocs/web/wiz_wlan_setup.php";
?>
