<?
include "/htdocs/web/bsc_wlan.php";
?>
