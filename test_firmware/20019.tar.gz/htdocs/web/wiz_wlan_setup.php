HTTP/1.1 200 OK

<?
$TEMP_MYNAME	= "wiz_wlan_setup";
$TEMP_MYGROUP	= "basic";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
