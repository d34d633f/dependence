HTTP/1.1 200 OK

<?
/* The variables are used in js and body both, so define them here. */
include "/htdocs/phplib/xnode.php"; 
$path_wifi_wifi1 = XNODE_getpathbytarget("wifi", "entry", "uid", "WIFI-1.1", 0);
$MAC_FILTER_MAX_COUNT = query("/acl/max");
if ($MAC_FILTER_MAX_COUNT == "") $MAC_FILTER_MAX_COUNT = 25;

/* necessary and basic definition */
$TEMP_MYNAME    = "adv_access_control";
$TEMP_MYGROUP   = "advanced";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
