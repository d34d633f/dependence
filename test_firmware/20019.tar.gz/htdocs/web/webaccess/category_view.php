﻿HTTP/1.1 200 OK

<html>
<head>
<title>SharePort Web Access</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Cache-Control" content="no-cache"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="Tue, 01 Jan 1980 1:00:00 GMT"/>
<link href="webfile_css/layout.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="webfile_js/webfile.js"></script>
<script language="JavaScript" src="js/object.js"></script>
<script language="JavaScript" src="js/xml.js"></script>
<script language="JavaScript" src="js/public.js"></script>
<script type="text/javascript">
load_lang_obj();
</script>	
</head>
	<body onload="MM_preloadImages('webfile_images/btn_home_.png')">
	<center>
	<div id="wrapper">
		<div id="header">
			<div align="right">
				<table width="100%" border="0" cellspacing="0">
					<tr>		    
						<th width="224" rowspan="2" scope="row"><img src="webfile_images/index_01.png"width="220" height="55" /></th>
						<th width="715" height="30" scope="row"><a href="folder_view.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image6','','webfile_images/btn_menu_.png'/*tpa=/webaccess/webfile_images/btn_menu_.png*/,1)"><img src="webfile_images/btn_menu_.png" name="Image6" width="25" height="25" border="0" align="right" id="Image6" /></a></th>
						<th width="15" scope="row"></th>
					</tr>
					<tr>
						<th scope="row"></th>
						<th scope="row"></th>
					</tr>
				</table>					
			</div>
			</div>
				<div id="button_list">
					<table width="960" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_3">
						<tr>
							<td width="968" colspan="2" align="left" valign="top">
							<table width="960" border="0" cellpadding="0" cellspacing="0">
							<tr onMouseUp="location.href='music.php'">
							<td height="25" style="cursor: default" onMouseOver="this.style.background='#efefef'" onMouseOut="this.style.background=''">
							<table width="960" border="0" align="left" cellpadding="0" cellspacing="0">
							<tr>
							<td width="56" height="91" class="tdbg"><img src="webfile_images/icon_music.png" alt="" width="56" height="56" border="0"></td>
							<td width="868" class="text_1"><? echo I18N("h", "Music");?></td>
							<td width="36" class="tdbg"><img src="webfile_images/).png" alt="" width="15" height="15"></td>
							</tr>
							</table>
							</td>
						</tr>
											</table>
											<table width="960" border="0" cellpadding="0" cellspacing="0">
												<tr onMouseUp="location.href='photo.php'">
													<td height="25" style="cursor: default" onMouseOver="this.style.background='#efefef'" onMouseOut="this.style.background=''">
														<table width="960" border="0" align="left" cellpadding="0" cellspacing="0">
															<tr>
																<td width="56" class="tdbg"><img src="webfile_images/icon_photos.png" alt="" width="56" height="56" border="0"></td>
													<td width="868" height="91" class="text_1"><? echo I18N("h", "Photo");?></td>
																<td width="36" class="tdbg"><img src="webfile_images/).png" alt="" width="15" height="15"></td>
															</tr>
														</table>
													</td>
												</tr>
											</table>   
											<table width="960" border="0" cellpadding="0" cellspacing="0">
												<tr onMouseUp="location.href='movie.php'">
													<td height="25" style="cursor: default" onMouseOver="this.style.background='#efefef'" onMouseOut="this.style.background=''">
														<table width="960" border="0" align="left" cellpadding="0" cellspacing="0">
															<tr>
																<td width="56" class="tdbg"><img src="webfile_images/icon_movies.png" alt="" width="56" height="56" border="0"></td>
													<td width="868" height="56" class="text_1"><? echo I18N("h", "Movie");?></td>
																<td width="36" class="tdbg"><img src="webfile_images/).png" alt="" width="15" height="15"></td>
															</tr>
														</table>					 
													</td>
												</tr>
											</table>											
											<table width="960" border="0" cellpadding="0" cellspacing="0">
												<tr onMouseUp="location.href='doc.php'">
													<td height="25" style="cursor: default" onMouseOver="this.style.background='#efefef'" onMouseOut="this.style.background=''">
														<table width="960" border="0" align="left" cellpadding="0" cellspacing="0">
															<tr>
																<td width="56" class="tdbg"><img src="webfile_images/icon_files.png" alt="" width="56" height="56" border="0"></td>
													<td width="868" height="91" class="text_1"><? echo I18N("h", "Document");?></td>
																<td width="36" class="tdbg"><img src="webfile_images/).png" alt="" width="15" height="15"></td>
															</tr>
														</table>
													</td>
												</tr>
											</table>											
										</td>
									</tr>
								</table>
				<div id="footer"><img src="webfile_images/dlink.png" width="77" height="22" /></div>
			</div>
		</div>
	</center>
	</body>
</html>