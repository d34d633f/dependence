<?
/* vi: set sw=4 ts=4: */
$MY_NAME="index";
$MSG_FILE="";
$TITLE=query("/sys/web/sysname");
$NO_SESSION_TIMEOUT=1;
$NOT_FRAME =1;


/* ------------------------------ */
//AP_display
if($TITLE == "DAP-2553")
{
//	require("/www/dap2553_display.php");
	require("/www/dap2553_webdisplay.php");
}
else if($TITLE == "DAP-2590")
{
	require("/www/dap2590_webdisplay.php");
}
else if($TITLE == "DAP-2690")
{
	require("/www/dap2690_webdisplay.php");
}
else if($TITLE == "DAP-1353")
{
	require("/www/dap1353b_webdisplay.php");
}
else if($TITLE == "DAP-3690")
{
    require("/www/dap3690_webdisplay.php");
}
else if($TITLE == "DAP-2360")
{
	require("/www/dap2360_webdisplay.php");
}
/* ------------------------------ */
$group=fread("/var/proc/web/session:".$sid."/user/group");

if ($group==0 && query("/time/syncwith")==1)
{
	$NEXT_LINK=$G_HOME_PAGE;
	require("/www/comm/__msync.php");
}
else
{
	require("/www/main.php");
}
?>

