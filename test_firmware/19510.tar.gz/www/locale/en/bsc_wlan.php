<?
$m_context_title = "Wireless Settings";
$m_band = "Wireless Band";
$m_band_5G = "5GHz";
$m_band_2.4G = "2.4GHz";
$m_application           = "Application";
$m_indoor           = "Concurrent 11a/n on W52/W53/W56 for indoor";
$m_outdoor          = "Concurrent 11a/n on W56 for outdoor";
$m_in_out_door      = "Concurrent 11b/g/n on 2.4GHz for indoor/outdoor";
$m_mode           = "Mode";
$m_ap_access      = "Access Point";
$m_ap_repeater    = "AP Repeater";
$m_ap_client      = "Wireless Client";
$m_ap_wds         = "WDS";
$m_ap_wds_with_ap = "WDS with AP";

$m_ap_hidden = "SSID Visibility";
$m_disable = "Disable";
$m_enable  = "Enable";
$m_auto_ch_scan = "Auto Channel Selection";
$m_channel = "Channel";
$m_channel_width ="Channel Width";
$m_cw_20	= "20 MHz";
$m_cw_auto	= "Auto 20/40 MHz";

$m_authentication = "Authentication";
$m_auth_open      = "Open System";
$m_auth_shared    = "Shared Key";
$m_auth_both      = "Open System/Shared Key";
$m_auth_wpaper    = "WPA-Personal";
$m_auth_wpaent    = "WPA-Enterprise";
$m_auth_1x    = "802.1X";
$m_wapi_cert	= "WAPI-Cert";
$m_wapi_psk		= "WAPI-Psk";

$m_key_field_title = "Key Settings";
$m_encryption = "Encryption";
$m_key_type = "Key Type";
$m_ascii = "ASCII";
$m_hex = "HEX";
$m_key_size   = "Key Size";
$m_key_64bit  = "64 Bits";
$m_key_128bit = "128 Bits";
$m_key_152bit = "152 Bits";
$m_default_key = "Key Index(1~4)";
$m_key = "Network Key";
$m_key1 = "1";
$m_key2 = "2";
$m_key3 = "3";
$m_key4 = "4";
$m_confirm_key = "Confirm Key";

$m_passphrase_field_title = "PassPhrase Settings";
$m_cipher = "Cipher Type";
$m_cipher_auto = "Auto";
$m_cipher_aes = "AES";
$m_cipher_tkip = "TKIP";
$m_wpa_mode = "WPA Mode";
$m_wpa_mode_auto = "AUTO (WPA or WPA2)";
$m_wpa_mode_wpa2 = "WPA2 Only";
$m_wpa_mode_wpa  = "WPA Only";
$m_gkui = "Group Key Update Interval";
$m_sec  = " (Seconds)";
$m_passphrase  = "PassPhrase";
$m_confirm_passphrase = "Confirm PassPhrase";

$m_eap_field_title = "EAP Settings";
$m_eap_method = "EAP Method";
$m_peap = "PEAP";
$m_ttls = "TTLS";
$m_mschav2 = "MSCHAPv2";
$m_pap = "PAP";
$m_chap = "CHAP";
$m_inner_auth = "Inner Authentication";
$m_username = "Username";
$m_password = "Password";

$m_radius_field_title = "RADIUS Server Settings";
$m_primary_radius_title = "Primary RADIUS Server Setting";
$m_secondary_radius_title = "Backup RADIUS Server Setting (Optional)";
$m_primary_accounting_title = "Primary Accounting Server Setting";
$m_secondary_accounting_title = "Backup Accounting Server Setting (Optional)";
$m_nap_title = "Network Access Protection";
$m_nap ="Network Access Protection";
$m_radius_server = "RADIUS Server";
$m_radius_port = "RADIUS Port";
$m_radius_secret = "RADIUS Secret";
$m_accounting_mode = "Accounting Mode";
$m_accounting_server = "Accounting Server";
$m_accounting_port = "Accounting Port";
$m_accounting_secret = "Accounting Secret";

$m_radius_server_mode = "RADIUS Server Mode";
$m_kui = "Key Update Interval";
$m_external = "External";
$m_internal = "Internal";

$m_ssid = "Network Name (SSID)";
$m_auto_chennel = "Auto Channel Scan";

$m_wds_mac_title = "WDS";
$m_wds_ap_mac_title = "WDS with AP";
$m_remote_ap_mac = "Remote AP MAC Address";
$m_site_survey_title = "Site Survey";
$m_b_scan = "Scan";
$m_scan_type = "Type";
$m_scan_ch = "CH";
$m_scan_signal = "Signal";
$m_scan_mac = "BSSID";
$m_scan_sec = "Security";
$m_scan_ssid = "SSID";

$m_manual="Manual";
$m_periodrical_key_change="Periodical Key Change";
$m_time="Time Interval";
$m_hour="(1~168)hour(s)";
$m_activated_from = "Activated From";
$m_shour = "Hour";
$m_smin = "minute";
$m_sun = "Sun";
$m_mon = "Mon";
$m_tue = "Tue";
$m_wed = "Wed";
$m_thu = "Thu";
$m_fri = "Fri";
$m_sat = "Sat";

$m_as_ip = "AS IP Address";
$m_as_port = "Port";
$m_ukui = "Unicat Key Update Interval";
$a_enable_nap ="If Network Access Protection enable , Limit Administrator Status will be disable !";
$a_check_mail_for_rekey = "Please check the Log or E-mail for the new security key.";
$a_invalid_time_range	= "Invalid Time Interval range !";
if(query("/runtime/web/display/sys/hostname") == "DAP-1353")
{
	$a_invalid_mssid_status =   "Multi- SSID will be disabled when ".query("/sys/hostname")." is configured in 'WDS', 'Wireless Client' or 'AP Repeater'.";
}
else
{
	$a_invalid_mssid_status	=	"Multi- SSID will be disabled when ".query("/sys/hostname")." is configured in 'WDS' or 'Wireless Client'.";
}
$a_empty_ssid	= "The SSID field can not be blank.";
$a_invalid_ssid	= "There are some invalid characters in the SSID field. Please check it.";
$a_first_blank_ssid	= "The first character can't be blank.";
$a_empty_username	= "The username field can not be blank.";
$a_invalid_username	= "There are some invalid characters in the username field. Please check it.";
$a_first_blank_username	= "The first character can't be blank.";
$a_invalid_pass_len	= "The length of password should be 8~63.";
$a_invalid_pass	= "The password should be ASCII characters.";
$a_blank_wds_mac	=	"Please input MAC Address.";
$a_invalid_wds_mac = "Invalid MAC Address. \\nFormat xx:xx:xx:xx:xx:xx(x:0-9;A-f).";
$a_same_wds_mac	= "There is an existent entry with the same MAC Address.\\n Please change the MAC Address.";
$a_empty_key = "The Key cannot be blank.";
$a_first_end_blank  = "The first character and last character can't be blank.";
$a_valid_hex_char	= "The legal characters are 0~9, A~F or a~f.";
$a_valid_asc_char	= "The legal characters are ASCII.";
$a_invalid_len_hex_64 ="The length of Key must be 10 hexadecimal number.";
$a_invalid_len_hex_128 ="The length of Key must be 26 hexadecimal number.";
$a_invalid_len_asc_64 ="The length of Key must be 5 ASCII number.";
$a_invalid_len_asc_128 ="The length of Key must be 13 ASCII number.";
$a_invalid_psk_len	= "The length of Passphrase should be 8~63.";
$a_invalid_eap_pass_len  = "The length of password should be 8~64.";
$a_invalid_psk	= "The Passphrase should be ASCII characters.";
$a_invalid_key_interval	= "The range of Group Key Update Interval is 300 to 9999999.";
$a_invalid_1x_key_interval	= "The range of 802.1x Key Update Interval is 300 to 9999999.";
$a_invalid_radius_srv	= "The IP Address of RADIUS Server is invalid.";
$a_invalid_radius_port	= "The Port of RADIUS Server is invalid.";
$a_empty_radius_sec	= "The Shared Secret of RADIUS Server can not be empty.";
$a_invalid_radius_sec	= "The Shared Secret of RADIUS Server should be ASCII characters.";
$a_invalid_acc_srv	= "The IP Address of Accounting Server is invalid.";
$a_invalid_acc_port	= "The Port of Accounting Server is invalid.";
$a_empty_acc_sec	= "The Shared Secret of Accounting Server can not be empty.";
$a_invalid_acc_sec	= "The Shared Secret of Accounting Server should be ASCII characters.";
$a_unknown_auth = "Unknown Authentication Type.";
$a_key_not_matched	="The Network Key and Confirm Key are not matched.";
$a_passphrase_not_matched	="The PassPhrase and Confirm PassPhrase are not matched.";
$a_invalid_vlan_status	=	"VLAN will be disabled when Authentication is not configured in 'WPA-Enterprise'.";
$a_key_index_matched_mssid_index = "Key value is used by SSID! \\n To change Key value affects other SSID settings.";
$a_otherband_to_apmode = "Can't set this mode to APC if the other mode is WDS, WDS with AP or APC.";
$a_disable_ap_array = "If mode is WDS, WDS with AP or APC, AP Array will be disabled.";
$a_disable_url = "If mode is WDS or APC, Web Redirection will be disabled.";
$a_disable_vlan = "If mode is APC, VLAN will be disabled.";
$a_two_band_same_time = "Two bands will share the same time range of Periodical Key Change.";
$a_invalid_password_len = "The length of password should be 8~64.";
$a_two_band_share_the_same_nap = "NAP of the other band will enable/disable like this band.";
$a_invalid_secret_len = "The length of password should be 1~64.";

$a_empty_as_ip = "Please input IP Address!";
$a_invalid_as_ip = "The IP Address is invalid!";
$a_empty_as_port = "Please input a port!";
$a_invalid_as_port = "The Port is invalid!";
$a_invalid_usk_key_interval = "The range of Unicate Key Update Interval is 300 to 9999999.";
$m_clone_mac = "Wireless MAC Clone";
$m_mac_source = "MAC Source";
$m_auto = "Auto";
$m_manual = "Manual";
$m_scan = "Scan";
$m_mac_addr = "MAC Address";
$a_invalid_mac = "Invalid MAC address !";
$a_invalid_secret_len = "The length of password should be 1~64.";
?>
