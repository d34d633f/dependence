<?
$m_html_title	= "LOGIN FAIL";
$m_context_title= "Login fail";
if($timeout!=1)
{
	$m_context	= "User Name or Password is incorrect.";
}
else
{
	$m_context	= "Reply from Radiusclient Timeout";
}
$m_button_dsc	= "Login Again";
?>
