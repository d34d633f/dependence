<?
$msg_title="Ethernet Traffic Statistics";
$msg_t_title="Transmitted Count";
$msg_r_title="Received Count";
$msg_T_Packet="Transmitted Packet Count";
$msg_T_Bytes=" Transmitted Bytes Count";
$msg_T_Dropped_Packet="Dropped Packet Count";
$msg_R_Packet="Received Packet Count";
$msg_R_Bytes="Received Bytes Count";
$msg_R_Dropped_Packet="Dropped Packet Count";
$msg_R_Multicast_Packet="Received Multicast Packet Count";
$msg_R_Broadcast_Packet="Received Broadcast Packet Count";
$msg_Len_64="Length 64 Packet Count";
$msg_Len_65_127="Length 65~127 Packet Count";
$msg_Len_128_255="Length 128~255 Packet Count";
$msg_Len_256_511="Length 256~511 Packet Count";
$msg_Len_512_1023="Length 512~1023 Packet Count";
$msg_Len_1024_1518="Length 1024~1518 Packet Count";
$msg_Len_1519_MAX="Length 1519~MAX Packet Count";
$msg_clear="Clear";
$msg_refresh="Refresh";
?>