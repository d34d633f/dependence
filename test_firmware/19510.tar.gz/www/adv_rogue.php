<?
/* vi: set sw=4 ts=4: ---------------------------------------------------------*/
$MY_NAME      = "adv_rogue";
$MY_MSG_FILE  = $MY_NAME.".php";
$MY_ACTION    = $MY_NAME;
$NEXT_PAGE    = "adv_rogue";
set("/runtime/web/help_page",$MY_NAME);
/* --------------------------------------------------------------------------- */
if($ACTION_POST != "")
{
	require("/www/model/__admin_check.php");
	require("/www/__action_adv.php");
	$ACTION_POST = "";
	exit;
}

/* --------------------------------------------------------------------------- */
echo "<!DOCTYPE html PUBLIC \"-\/\/W3C\/\/DTD XHTML 1.0 Strict\/\/EN\" \"http:\/\/www.w3.org\/TR\/xhtml1\/DTD\/xhtml1-strict.dtd\">";
require("/www/model/__html_head.php");
require("/www/comm/__js_ip.php");
set("/runtime/web/next_page",$first_frame);
/* --------------------------------------------------------------------------- */
// get the variable value from rgdb.
$tmp_valid = 0;
$tmp_neighborhood = 0;
$tmp_rogue = 0;
for("/wlan/inf:1/rogue_ap/client")
{
	if(query("type")== 1)
	{
		$tmp_valid ++;
	}
	else if(query("type")== 2)
	{
		$tmp_neighborhood ++;
	}
	else if(query("type")== 3)
	{
		$tmp_rogue ++;
	}

}

if($type_reload != 1 && $type_reload != 2 && $type_reload != 3 && $type_reload != 0)
{
	$type_reload = 5;
}
/* --------------------------------------------------------------------------- */
?>


<?
echo $G_TAG_SCRIPT_START."\n";
require("/www/model/__wlan.php");
?>
function on_change_scan_table_height()
{
	var x = get_obj("scan_tab").offsetHeight;
	
	if(get_obj("adjust_td") != null)
	{
		if(x <= 120)
		{
			get_obj("adjust_td").width="10%";
			if(is_IE())
			{
				get_obj("scan_tab").width="100%";
			}
		}
		else
		{
			get_obj("adjust_td").width="7%";
			if(is_IE())
			{
				get_obj("scan_tab").width="97%";
			}
		}
	}
}	

function on_change_rogue_ap_type(s)
{
	var f = get_obj("frm");
	self.location.href = "adv_rogue.php?type_reload=" + s.value;
}

function shortTime(t,t_str)
{
	var str=new String("");
	var t=parseInt(t, [10]);
	var sec=0,min=0,hr=0,day=0;

	if(t > 1199116800)
	{
		str=t_str;
	}
	else
	{
		sec=t % 60;  //sec
		min=parseInt(t/60, [10]) % 60; //min
		hr=parseInt(t/(60*60), [10]) % 24; //hr
		day=parseInt(t/(60*60*24), [10]); //day
	
		if(day>=0 || hr>=0 || min>=0 || sec >=0)
			str=(day >0? day+" <?=$m_days?>, ":"0 <?=$m_days?>, ")+(hr >0? hr+":":"00:")+(min >0? min+":":"00:")+(sec >0? sec :"00");
	}	
	document.write(str);
}
/* page init functoin */
function init()
{
	var f = get_obj("frm");

	f.rogue_type.value = "<?=$type_reload?>";
	
	f.set_new[0].disabled = false;
	f.set_new[1].disabled = false;	
		
	
	if(f.rogue_type.value == 1 || f.rogue_type.value == 2 || f.rogue_type.value == 3)
	{
		f.set_new[0].disabled = true;
		f.set_new[1].disabled = true;	
	}

	f.set_new[0].checked = true;

	on_change_scan_table_height();
	AdjustHeight();

}

/* parameter checking */
function check()
{
	var f=get_obj("frm");

	if(f.set_new[0].checked)
	{
		f.f_type.value = 1;
	}
	else
	{
		f.f_type.value = 3;
	}

	if(check_db_number(f.f_type.value) != false)
		f.submit();
	return true;
}

function submit()
{
	if(check()) get_obj("frm").submit();
}

function do_detect()
{
	var f	=get_obj("frm");
	f.f_detect.value = "1";
	var str = "";
	for(var x in f)
	{
		str += x + " : " + " --- ";
	}
	//alert(str);
	f.submit();
}

function do_change_type(type)
{
	var f	=get_obj("frm");
	f.f_type.value = type;

	if(check_db_number(f.f_type.value) != false)
		f.submit();
}

</script>

<body <?=$G_BODY_ATTR?> onload="init();">

<form name="frm" id="frm" method="post" action="<?=$MY_NAME?>.php" onsubmit="return check();">

<input type="hidden" name="ACTION_POST" value="<?=$MY_ACTION?>">
<input type="hidden" name="f_detect"		value="">
<input type="hidden" name="f_type"		value="">
<input type="hidden" name="f_new_to_valid"		value="">
<input type="hidden" name="f_new_to_rogue"		value="">

<table id="table_frame" border="0"<?=$G_TABLE_ATTR_CELL_ZERO?>>
	<tr>
		<td valign="top">
			<table id="table_header" <?=$G_TABLE_ATTR_CELL_ZERO?>>
			<tr>
				<td id="td_header" valign="middle"><?=$m_context_title?></td>
			</tr>
			</table>
<!-- ________________________________ Main Content Start ______________________________ -->
			<table id="table_set_main"  border="0"<?=$G_TABLE_ATTR_CELL_ZERO?>>
				<tr>
					<td colspan="2">
						<input type="button" value="&nbsp;&nbsp;<?=$m_b_detect?>&nbsp;&nbsp;" name="detect" onclick="do_detect()">
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<fieldset id="ap_list_fieldset" style="">
							<legend><?=$m_ap_list_title?></legend>
							<table  width="100%" border="0" align="center" <?=$G_TABLE_ATTR_CELL_ZERO?>>
								<tr>
									<td height="25">
										<?=$G_TAG_SCRIPT_START?>genSelect("rogue_type", [5,1,2,3,0], ["<?=$m_all?>","<?=$m_valid?>","<?=$m_neighborhood?>","<?=$m_rogue?>","<?=$m_new?>"], "on_change_rogue_ap_type(this)");<?=$G_TAG_SCRIPT_END?>
									</td>
								</tr>
								<tr>
									<td>
										<table width="100%" border="0" align="center" <?=$G_TABLE_ATTR_CELL_ZERO?>>
										<tr class="list_head" align="center">
											<td width="5%">
												<?=$G_TAG_SCRIPT_START?>genCheckBox("all_click", "on_click_all(this)");<?=$G_TAG_SCRIPT_END?>
											</td>
											<td width="10%">
												<?=$m_type?>
											</td>
											<td width="10%">
												<?=$m_band?>
											</td>
											<td width="5%">
												<?=$m_channel?>
											</td>
											<td width="20%">
												<?=$m_ssid?>
											</td>
											<td width="20%">
												<?=$m_mac?>
											</td>
											<td width="20%">
												<?=$m_last_seem?>
											</td>
											<td width="10%">
												<?=$m_status?>
											</td>
											<td>
												&nbsp;
											</td>												
										</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td>
										<div class="div_tab">
										<table id="scan_tab" border="0"  width="100%" <?=$G_TABLE_ATTR_CELL_ZERO?>>
<?
$tmp = "";
$client_num = 0;
for("/runtime/wlan/inf:1/rogue_ap/client")
{
	set("/runtime/wlan/inf:1/rogue_ap/client:".$@."/index",  0);
	
	$type_match = 0;

	if(query("type")== 1)
	{
		$type = $m_valid;
	}
	else if(query("type")== 2)
	{
		$type = $m_neighborhood;
	}
	else if(query("type")== 3)
	{
		$type = $m_rogue;
	}
	else
	{
		$type = $m_new;
	}

	if(query("band")== 1)
	{
		$band = $m_g;
	}
	else if(query("band")== 2)
	{
		$band = $m_n;
	}
	else if(query("band")== 3)
	{
		$band = $m_a;
	}
	else
	{
		$band = $m_b;
	}

	if($type_reload == query("type"))
	{
		$type_match = 1;
	}

	if(query("status")== 1)
	{
		$status = $m_up;
	}
	else
	{
		$status = $m_down;
	}

echo "<input type=\"hidden\" id=\"h_type".$@."\" name=\"h_type".$@."\" value=\"".query("type")."\">\n";

	if($type_reload == 5 || $type_match == 1)
	{
		if($tmp != 1)
		{
			echo "<tr align=\"center\" style=\"background:#CCCCCC;\">\n";
			$tmp = 1;
		}
		else
		{
			echo "<tr align=\"center\" style=\"background:#B3B3B3;\">\n";
			$tmp = 0;
		}
		echo "<td width=\"5%\">".$G_TAG_SCRIPT_START."genCheckBox(\"client_idx".$@."\", \"\")".$G_TAG_SCRIPT_END."</td>\n";
		echo "<td width=\"10%\" style=\"font-size: 11px;\">".$type."</td>\n";
		echo "<td width=\"10%\" style=\"font-size: 11px;\">".$band."</td>\n";
		echo "<td width=\"5%\" style=\"font-size: 11px;\">".query("channel")."</td>\n";
		echo "<td width=\"20%\" style=\"font-size: 11px;\">".$G_TAG_SCRIPT_START."genTableSSID(\"".get("j","ssid")."\",0);".$G_TAG_SCRIPT_END."</td>\n";
		echo "<td width=\"20%\" style=\"font-size: 11px;\">".query("mac")."</td>\n";
		echo "<td width=\"20%\" style=\"font-size: 11px;\">".$G_TAG_SCRIPT_START."shortTime(\"".query("time")."\",\"".query("time_str")."\");".$G_TAG_SCRIPT_END."</td>\n";
		echo "<td id=\"adjust_td\" style=\"font-size: 11px;\">".$status."</td>\n";
		echo "</tr>\n";
	}
	$client_num ++;
}

?>

										</table>
										</div>
									</td>
								</tr>
							</table>
						</fieldset>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="button" value="&nbsp;<?=$m_b_valid?>&nbsp;" name="valid" onclick="do_change_type('1')">
						<input type="button" value="&nbsp;<?=$m_b_neighborhood?>&nbsp;" name="neighborhood" onclick="do_change_type('2')">
						<input type="button" value="&nbsp;<?=$m_b_rogue?>&nbsp;" name="rogue" onclick="do_change_type('3')">
						<input type="button" value="&nbsp;<?=$m_b_new?>&nbsp;" name="new" onclick="do_change_type('0')">
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="radio" id="set_new" name="set_new" value="0" onClick="on_check_set_new()">
						<?=$m_all_valid?>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="radio" id="set_new" name="set_new" value="1" onClick="on_check_set_new()">
						<?=$m_all_rogue?>
					</td>
				</tr>
				<tr>
					<td colspan="2">
<?=$G_APPLY_BUTTON?>
					</td>
				</tr>
			</table>
<!-- ________________________________  Main Content End _______________________________ -->
		</td>
	</tr>
</table>
</form>
</body>
<?=$G_TAG_SCRIPT_START?>
function on_click_all(s)
{
	if(s.checked)
	{
		for(var i=1; i<="<?=$client_num?>" ; i++)
		{
			if(get_obj("client_idx"+i) != null)
			{
				get_obj("client_idx"+i).checked = true;
			}
		}
	}
	else
	{
		for(var i=1; i<="<?=$client_num?>" ; i++)
		{
			if(get_obj("client_idx"+i) != null)
			{
				get_obj("client_idx"+i).checked = false;
			}
		}
	}
}

function check_db_number(type_num)
{
	var how_many_click = 0;
	var can_add_num = 0 , want_to_add_num = 0;

	for(var i=1; i<="<?=$client_num?>"; i++)
	{
		if(get_obj("client_idx"+i) != null)
		{
			if(get_obj("client_idx"+i).checked)
				how_many_click ++;
		}
	}
	if(how_many_click < 1)
	{
		alert("<?=$a_no_click?>");
		return false;
	}

	if(type_num == 1)
	{
		can_add_num = 64 - parseInt("<?=$tmp_valid?>",[10]);
		want_to_add_num = parseInt("<?=$tmp_valid?>",[10])+parseInt(how_many_click);
	}
	else if(type_num == 2)
	{
		can_add_num = 64 - parseInt("<?=$tmp_neighborhood?>",[10]);
		want_to_add_num = parseInt("<?=$tmp_neighborhood?>",[10])+parseInt(how_many_click);
	}
	else if(type_num == 3)
	{
		can_add_num = 64 - parseInt("<?=$tmp_rogue?>",[10]);
		want_to_add_num = parseInt("<?=$tmp_rogue?>",[10])+parseInt(how_many_click);
	}

	if(want_to_add_num > 64 )
	{
		alert("<?=$a_max_list?><?=$a_can_add_num?>"+can_add_num+"<?=$a_entry?>");
		return false
	}
	return true;
}

function on_check_set_new()
{
	var f = get_obj("frm");

	for(var i=1; i<="<?=$client_num?>" ; i++)
	{
		if(get_obj("h_type"+i).value == 0)
		{
			get_obj("client_idx"+i).checked = true;
		}
	}
}
<?=$G_TAG_SCRIPT_END?>
</html>

