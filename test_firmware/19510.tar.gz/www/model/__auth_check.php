<?
/* vi: set sw=4 ts=4: */
$wr_sta_mac = query("/runtime/webredirect/client_mac");
$wr_da_ip = query("/runtime/webredirect/daddr_ip_flag");
$wr_enable = query("/wlan/inf:1/webredirect/enable");
//echo "echo ".$wr_sta_mac." -- ".$wr_da_ip." --  ".$wr_enable."... > /dev/console\n";
if($wr_sta_mac == "")
{
	$wr_sta_mac = 1;	
}
if ($NO_NEED_AUTH!="1")
{
	/* for POP up login. */
//	require("/www/auth/__authenticate_p.php");
//	if ($AUTH_RESULT=="401")	{exit;}

	/* for WEB based login  */
	require("/www/auth/__authenticate_s.php");
	
	if($wr_enable == 1 && $wr_sta_mac!=1 && $wr_da_ip != 0)
	{
		require("/www/session_wr_login.php"); 
		exit;
	}
	else
	{
	if($AUTH_RESULT=="401")		{require("/www/session_login.php"); exit;}
	if($AUTH_RESULT=="full")	{require("/www/session_full.php"); exit;}
	if($AUTH_RESULT=="timeout")	{require("/www/session_timeout.php"); exit;}
	}
	$AUTH_GROUP=fread("/var/proc/web/session:".$sid."/user/group");
}
require("/www/model/__lang_msg.php");
?>
