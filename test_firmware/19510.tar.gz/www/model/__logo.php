<table width="775" height="56" border="0"  cellspacing="0" cellpadding="0" background="/pic/banner.jpg">
<tr>
	<td align="left">
   		<img src="/pic/dlink.jpg">
   	</td>
	<td align="right" valign="middle">
   		<font style="color:white; font:12pt Arial;"><b><?=$m_logo_title?>&nbsp;&nbsp;&nbsp;</b></font>
   	</td>
</tr>
</table>