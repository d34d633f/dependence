<html>
<head>
<title></title>
</head>
<?
$wr_sta_mac = query("/runtime/webredirect/client_mac");
$wr_da_ip = query("/runtime/webredirect/daddr_ip_flag");
?>
<script>
function init()
{
	var wr_reload = "<?=$reload?>";
	if(wr_reload == "")
	{
		setTimeout("reload_page()",1000);
	}
	else
	{
		login();
	}
}
function reload_page()
{
	self.location.href="session_login.php?reload=1";
}

function login()
{
	var wr_sta_mac = "<?=$wr_sta_mac?>";
	var wr_da_ip = "<?=$wr_da_ip?>";	
	if(wr_sta_mac !=1 && wr_da_ip != 0)
	{
		parent.location.href="web_redirect.php";
	}
	else
	{
		parent.location.href="login.php";
	}
}
</script>
<body onload="init();">
	
</body>
</html>
