#!/bin/sh
case "$1" in
start)
	echo "start Layout ..."	> /dev/console
	/etc/scripts/layout.sh start	> /dev/console
	echo "start LAN ..."		> /dev/console
	/etc/templates/lan.sh start	> /dev/console
	echo "start web server ..."                 
	/etc/templates/webs.sh start    > /dev/console
	sh /etc/templates/limitedadmin.sh	>	/dev/console
	mkdir /var/servd	>	/dev/console
	servd&	>	/dev/console
	echo "start fresetd ..."	> /dev/console
	fresetd &
	echo "enable LAN ports ..."	> /dev/console
	/etc/scripts/enlan.sh		> /dev/console
	echo " Generate channel table according to the country code..."	> /dev/console
	genchanneltable		> /dev/console
	echo " Generate VLAN table according to the port..."	> /dev/console
	genVLANTableByPort	> /dev/console
	echo "start WAN ..."		> /dev/console
	/etc/scripts/misc/setwantype.sh	> /dev/console
	/etc/templates/wan.sh start	> /dev/console
	echo "start WLAN ..."     > /dev/console
	/etc/templates/wlan.sh start    > /dev/console
	echo "start stunnel ..."
	/etc/templates/stunnel.sh start > /dev/console
	echo "start telnet daemon ..." > /dev/console
	/etc/scripts/misc/telnetd.sh	> /dev/console
	echo "start SSHD daemon ..." > /dev/console
	/etc/templates/sshd.sh start	> /dev/console
	echo "start DHCP server"    > /dev/console
	/etc/templates/dhcpd.sh		> /dev/console
 echo "start SNMP ..."		> /dev/console
 /etc/templates/snmp.sh start   	> /dev/console
 echo "start NEAP ..."     > /dev/console
 /etc/templates/neaps.sh start    > /dev/console
 echo "start NEAPC ..."     > /dev/console
 /etc/templates/neapc.sh start    > /dev/console
 echo "start Microsoft LLDP ..."     > /dev/console
 /etc/templates/lld2d.sh start    > /dev/console
echo "start Ethlink ..."     > /dev/console
ethlink &> /dev/console
 echo "cp art script..."     > /dev/console
 cp /etc/templates/art_start.sh /var/run/  > /dev/console
 cp /etc/templates/art_stop.sh /var/run/    > /dev/console
 /etc/templates/arpspoofing.sh start   	> /dev/console
	;;
stop)
 echo "stop SNMP ..."         	> /dev/console
 /etc/templates/snmp.sh stop    	> /dev/console
 echo "stop NEAP ..."          > /dev/console
 /etc/templates/neaps.sh stop     > /dev/console
 echo "stop NEAPC ..."          > /dev/console
 /etc/templates/neapc.sh stop     > /dev/console
 echo "stop LLDP ..."          > /dev/console
 /etc/templates/lld2d.sh stop     > /dev/console
 /etc/templates/arpspoofing.sh stop    	> /dev/console
	echo "stop WAN ..."		> /dev/console
	/etc/templates/wan.sh stop	> /dev/console
	echo "stop fresetd ..."	> /dev/console
	killall fresetd
	echo "stop WLAN ..."		> /dev/console
	/etc/templates/wlan.sh stop	> /dev/console
	echo "stop LAN ..."		> /dev/console
	/etc/templates/lan.sh stop	> /dev/console
	echo "reset layout ..."	> /dev/console
	/etc/scripts/layout.sh	stop	> /dev/console
	;;
restart)
	sleep 3
	$0 stop
	$0 start
	;;
*)
	echo "Usage: system.sh {start|stop|restart}"
	;;
esac
exit 0
