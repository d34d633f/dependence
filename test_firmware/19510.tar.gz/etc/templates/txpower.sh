#!/bin/sh
echo [$0] ... > /dev/console
TXPOWER_NODE=`rgdb -g /wlan/inf:1/txpower`
TXPOWER_RUNTIME=`rgdb -i -g /runtime/stats/wlan/inf:1/txpower`
txpower=`rgdb -g /wlan/inf:1/txpower`
WLAN_ENABLE=`rgdb -g /wlan/inf:1/enable`
apmode=`rgdb -g /wlan/inf:1/ap_mode`
if [ "$WLAN_ENABLE" = "1" ]; then
	if [ "$txpower" != "1" ]; then
		ifconfig ath0 down
		brctl delif br0 ath0
		if [ "$apmode" = "2" ]; then
			ifconfig ath1 down
			brctl delif br0 ath1
		fi
		d=`expr $TXPOWER_RUNTIME \* "2"`
			if [ "$TXPOWER_NODE" = "2" ]; then
				if [ "$TXPOWER_RUNTIME" -gt "3" ]; then
					a=`expr \( $TXPOWER_RUNTIME - "3" \)`
					a1=`expr $a \* "2"`
					iwpriv wifi0 TXPwrOvr $a1
				else
					iwpriv wifi0 TXPwrOvr 2
				fi
			elif [ "$TXPOWER_NODE" = "3" ]; then
				if [ "$TXPOWER_RUNTIME" -gt "6" ]; then
					b=`expr \( $TXPOWER_RUNTIME - "6" \)`
					b1=`expr $b \* "2"`
					iwpriv wifi0 TXPwrOvr $b1
				else
					iwpriv wifi0 TXPwrOvr 2
				fi
			elif [ "$TXPOWER_NODE" = "4" ]; then
				if [ "$TXPOWER_RUNTIME" -gt "9" ]; then
					c=`expr \( $TXPOWER_RUNTIME - "9" \)`
					c1=`expr $c \* "2"`
					iwpriv wifi0 TXPwrOvr $c1
				else
					iwpriv wifi0 TXPwrOvr 2
				fi
			else
				iwpriv wifi0 TXPwrOvr $d
			fi
		ifconfig ath0 up
		brctl addif br0 ath0
		if [ "$apmode" = "2" ]; then
			ifconfig ath1 up
			brctl addif br0 ath1
		fi
	fi
fi
