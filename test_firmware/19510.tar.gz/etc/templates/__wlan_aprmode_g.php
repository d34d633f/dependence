<?
        $INSMOD = "insmod /lib/modules/2.6.15/net/";
		$wlanif = "ath1";//query("/runtime/layout/wlanif");
        $IWCONF="iwconfig ".$wlanif;

	      echo "rgdb -i -s /runtime/stats/wireless/led11a 0\n";
	      echo "rgdb -i -s /runtime/stats/wireless/led11g 0\n";
        
        $countrycode    = query("/runtime/nvram/countrycode");
        $wepmode        = query("/wlan/inf:1/wpa/wepmode");
        $g_mode         = query("/wlan/inf:1/wlmode");
        $cwmmode        = query("/wlan/inf:1/cwmmode");
        $wmmenable      = query("/wlan/inf:1/wmm/enable");
        $auth_mode      = query("/wlan/inf:1/authentication");
        $acktimeout_g   = query("/wlan/inf:1/acktimeout_g");
        $router_enable = query("/runtime/router/enable");
        $wlxmlpatch_pid = "/var/run/wlxmlpatch.pid";
        $ethlink        = query("/wlan/inf:1/ethlink");
        $clonetype      = query("/wlan/inf:1/macclone/type");
	$wlanmac= query("/runtime/layout/wlanmac");

        echo $INSMOD."ath_hal.ko\n";
        echo $INSMOD."wlan.ko\n";
        echo $INSMOD."ath_rate_atheros.ko\n";
        echo $INSMOD."ath_dfs.ko\n";
		if ($countrycode!=""){
			echo $INSMOD."ath_dev.ko countrycode=".$countrycode."\n";
		}else{
			echo $INSMOD."ath_dev.ko countrycode=840\n";
		}	
        echo $INSMOD."ath_ahb.ko\n";
        echo $INSMOD."wlan_xauth.ko\n";
        echo $INSMOD."wlan_ccmp.ko\n";
        echo $INSMOD."wlan_tkip.ko\n";
        echo $INSMOD."wlan_wep.ko\n";
        echo $INSMOD."wlan_acl.ko\n";
        echo $INSMOD."ath_pktlog.ko\n";

        if ($countrycode!=""){
            echo "iwpriv wifi0 setCountryID ".$countrycode."\n";
        }else{
            echo "iwpriv wifi0 setCountryID 840\n";
        }
        echo "brctl clonetype br0 0\n";
       /* 
        if ($clonetype==0){//clone disabled
        	if($router_enable !=1)//papa add 2009/02/11
        	{
            	$wlanmac= query("/runtime/layout/wlanmac");
            }
            else
            {
            	$wlanmac= query("/runtime/layout/wanmac");
            }
            echo "brctl clonetype br0 0\n";
        }else if ($clonetype==1){//auto clone
            $wlanmac= query("/runtime/macclone/addr");
            echo "rgdb -i -s /runtime/layout/wanmac ".$wlanmac."\n";
            echo "brctl setcloneaddr br0 ".$wlanmac."\n";
            echo "brctl clonetype br0 1\n";
        }else if ($clonetype==2){//manual clone
            $wlanmac= query("/wlan/inf:1/macclone/addr");
            echo "rgdb -i -s /runtime/layout/wanmac ".$wlanmac."\n";
            echo "brctl setcloneaddr br0 ".$wlanmac."\n";
            echo "brctl clonetype br0 2\n";
        }
        */
        echo "ifconfig wifi0 hw ether ".$wlanmac."\n";
		echo "wlanconfig ath0 create wlandev wifi0 wlanmode ap\n";
        echo "wlanconfig ath1 create wlandev wifi0 wlanmode sta nosbeacon 2>&1 > /dev/console\n";
		echo "iwpriv ath0 dbgLVL 0x100\n";
		echo "iwpriv ath0 countryie 1\n";
		echo "iwconfig ath0 channel 2\n";
		echo "iwpriv ath0 authmode 1\n";
		//
		echo "iwpriv ath0 bgscan 0\n";
		echo "ifconfig ath0 txqueuelen 1000\n";
		echo "iwpriv ath0 shortgi 1\n";
	    if ($cwmmode==1){
        	echo "iwpriv ath0 cwmmode 1\n";
        	echo "iwpriv ath1 cwmmode 1\n";
			echo "iwpriv ath0 mode 11NGHT40\n";
			echo "iwpriv ath1 mode 11NGHT40\n";
        }
        else{
            echo "iwpriv ath0 cwmmode 0\n";
            echo "iwpriv ath1 cwmmode 0\n";
            echo "iwpriv ath0 mode 11NGHT20\n";
            echo "iwpriv ath1 mode 11NGHT20\n";
        }
		//
		echo "ifconfig ath0 up\n";
		echo "iwconfig ath0 essid \"".get("s","/wlan/inf:1/ssid")."\" mode managed freq 6\n";
		echo "brctl addif br0 ath0\n";
		echo "sleep 5\n";
		echo "brctl ethlink br0 0\n";
		echo "wlxmlpatch -L ath0 /runtime/stats/wlan/inf:1 RADIO_SSID1_ON RADIO_SSID1_BLINK MADWIFI > /dev/console &\n";
		echo "rgdb -i -s /runtime/stats/wireless/led11g 1\n";
        echo "ifconfig ath0 hw ether ".$wlanmac."\n";
        echo "iwpriv wifi0 acktimeout ".$acktimeout_g."\n";
        echo "iwpriv ath1 bgscan 0\n";
        echo "iwpriv wifi0 HALDbg 0\n";
        echo "iwpriv ath1 dbgLVL 0x100\n";
        echo "ifconfig ath1 txqueuelen 1000\n";
		echo "ifconfig ath1 allmulti\n";
        echo "ifconfig wifi0 txqueuelen 1000\n";
        echo "iwpriv wifi0 AMPDU 1\n";
        echo "iwpriv wifi0 AMPDUFrames 32\n";
        echo "iwpriv wifi0 AMPDULim 50000\n";
        echo "iwpriv ath1 ampdumin 32768\n";
        echo "iwpriv wifi0 ANIEna 0\n";

        if ($wmmenable>0)      
	    { 
		echo "iwpriv ath1 wmm 1\n";
		echo "iwpriv ath0 wmm 1\n";
	    }
        else
            { 
		echo "iwpriv ath1 wmm 0\n"; 
		echo "iwpriv ath0 wmm 0\n";
	    }
	echo "iwconfig ath1 essid \"".get("s","/wlan/inf:1/ssid")."\"\n";
        echo "echo 1 > /proc/sys/dev/ath/htdupieenable\n";
        echo "echo 2 > /proc/sys/dev/ath/hal/forceBias\n";
        echo "iwpriv wifi0 txchainmask 7\n";
        echo "iwpriv wifi0 rxchainmask 7\n";
       if ($auth_mode>1){      
              echo $INSMOD."wlan_scan_sta.ko\n";
			  echo "sleep 10\n";
              require("/etc/templates/__auth_supplicant.php");
              echo "iwpriv ".$wlanif." apband 0\n"; //show ap band in wireless driver
              echo "wlxmlpatch -L ath1 /runtime/stats/wlan/inf:1/rootap RADIO_SSID1_ON RADIO_SSID1_BLINK MADWIFI > /dev/console &\n";
              echo "echo $! > ".$wlxmlpatch_pid."\n";
              echo "ifconfig ath1 up\n";
              echo "brctl apmode br0 2\n";
              echo "brctl addif br0 ath1\n";
// for ath0
			  echo "echo hostapd start > /dev/console\n";
              require("/etc/templates/__auth_hostapd_apr.php");
			  echo "echo hostapd done > /dev/console\n";
			  echo "ifconfig ath0 mode master\n";
            } else { 
                echo $INSMOD."wlan_scan_sta.ko\n";
                echo "ifconfig ath1 up\n";
		echo "brctl addif br0 ath1\n";
                require("/etc/templates/__auth_openshared_g.php"); 
        		$IWCONF="iwconfig ath0";
                require("/etc/templates/__auth_openshared_g.php"); 
                echo "iwpriv ".$wlanif." apband 0\n"; //show ap band in wireless driver
                echo "wlxmlpatch -L ath1 /runtime/stats/wlan/inf:1/rootap RADIO_SSID1_ON RADIO_SSID1_BLINK MADWIFI > /dev/console &\n";
                echo "echo $! > ".$wlxmlpatch_pid."\n";
                echo "brctl apmode br0 2\n";               
        }
       if($txpower>1){
            echo "iwlist ath1 txpower\n";
        }

      /* ethernet integration dennis2008-02-05 start */
        if ($ethlink==1){
            echo "brctl ethlink br0 ".$ethlink."\n";
        }else{
            echo "brctl ethlink br0 0\n";
        }
        /* ethernet integration dennis2008-02-05 end */
        echo "gpioc -o 20 \n";
        echo "gpioc -w 20 \n";
        echo "gpioc -e 20 \n";	
      	echo "rgdb -i -s /runtime/stats/wireless/led11g 1\n";
//	echo "ifconfig br0 hw ether ".$wlanmac."\n";
/*  if ($clonetype != 0){
            	echo "ifconfig eth0 down\n";
	            echo "brctl delif br0 eth0\n";
	            echo "brctl addif br0 eth0\n";
	            echo "ifconfig eth0 up\n";
        }
*/
        exit;
?>
