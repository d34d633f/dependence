<?php /* Smarty version 2.6.18, 
         compiled from ProductRegistration.tpl */ ?>
	<tr>
		<td>
			<table class="tableStyle">
			<tr>
					<td width="100%" colspan="2" align="center">
						<div align="center" style="margin:auto;">
							<table id="errorMessageBlock" align="center" style="margin: 4px auto 10px auto; <?php if ($flag != true) echo 'display: none;' ?>">
								<tr>
									<td style="padding: 5px; vertical-align: top;"><img src="images/alert.gif" style="border: 0px; padding: 0px; margin: 0px;"></td>
									<td style="padding: 5px 5px 5px 0px; vertical-align: middle;"><b id="br_head" style="color: #CC0000;"><?php if ($flag == true) echo ($msg=='')?"Invalid Data!":$msg; ?></b></td>
								</tr>
							</table>
						</div>
					</td>
				</tr>
				<tr>
					<td colspan="3">
						<table class='tableStyle'>
						<tr>
							<td colspan="3"><script>tbhdr('Registration','ProductRegistration')</script></td>
						</tr>
						</table>
					</td>
				</tr>
				<tr >
					<td class="subSectionBodyDot">&nbsp;&nbsp;&nbsp;</td>
					<td  class = "helppageattributes" style='padding:10px'>
					<div id='Registration_popup' style='display:none'>
					<p style='font-size:12px;line-height: 1.6em;'>We are delighted to have you as a customer.<br>Registration confirms your email alerts will work,<br> lowers technical support resolution time and ensures your<br>shipping address accuracy. We'd also like to incorporate<br>your feedback into future product development.</p>
					<br>
					<p style='font-size:12px;line-height: 1.6em;'>NETGEAR will never sell or rent your email address and <br>you may opt out of communications at any time.</p>
					</div>
					<?php 
					if(@fsockopen("www.netgear.com",80)) 
						{
					?>
					<script type='text/javascript'>
						new Ajax.Request('/productregistration/Prod_Reg_SerialCheck.php',
						  {
						  method:'get',
						  parameters: { id: Math.floor(Math.random()*10005) },    
						  onSuccess: function(RegisterStat){
						  var response = RegisterStat.responseText;
						  if(response=='notregistered')
								{
								  document.getElementById('Registration_popup').style.display='block';						  
									var buttons = new buttonObject();
									buttons.getStaticButtons(['register']);
									top.action.$('register').style.display = 'block';
								}
								else if(response=='registered')
								{
									document.getElementById('Registration_popup').style.display='block';
									document.getElementById('Registration_popup').innerHTML="<p style='font-size:12px;'>The product has been registered, no further action required.</p>";
								}							

							}
						});
					</script>
					<?php
						} 
					else
					{
					?>
					<script type='text/javascript'>
					$('br_head').innerHTML = "Error: Registration server is not accessible;<br>please check your internet connectivity or try at a later time";
					$('errorMessageBlock').show();
					</script>
					<?php
					}
					?>
					</td>
					<td class="subSectionBodyDotRight">&nbsp;&nbsp;&nbsp;</td>
				</tr>
					<td class="subSectionBodyDot" >&nbsp;</td>
					<td >
					</td>
					<td class="subSectionBodyDotRight">&nbsp;</td>
				<tr>
					<td colspan="3" class="subSectionBottom">&nbsp;</td>
				</tr>
			</table>
		</td>
	</tr>
