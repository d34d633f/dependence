#!/bin/sh


SLEEP_TIME=10

# first time to sleep
sleep $SLEEP_TIME

OUTDEV=/dev/console

while [ 1 ]
do
#echo check http >> $OUTDEV

	wizard=`uci -q get cameo.cameo.setup_wizard_rt`
	if [ "$wizard" != "1" ]; then
		echo not need monitor http >> $OUTDEV
		break		
	fi

	http=`ps | grep uhttp | grep -v grep`
	if [ "$http" == "" ]; then
		echo http disappear >> $OUTDEV
		/etc/init.d/uhttpd restart	
	fi


	sleep $SLEEP_TIME

done
