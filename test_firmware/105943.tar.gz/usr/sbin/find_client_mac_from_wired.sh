# /bin/sh
# ralph@cameo 2016/11/28

icp_disabled=$(uci get cameo.captive_portal.disabled)
redirect_url_disabled=$(uci get cameo.captive_portal.redirect_disabled)

if [ "$icp_disabled" = "1" -a "$redirect_url_disabled" = "1" ]; then
	exit
fi

arp_list=$(cat /proc/net/arp | sed '1d'| awk '{print $4}' | tr A-Z a-z)

uci delete misc.captive_portal.client_from_arp

#get all client from wired and wireless
for mac in $arp_list
do
	if [ ! "$mac" = "" -a ! "$mac" = "00:00:00:00:00:00" ]; then
		uci add_list misc.captive_portal.client_from_arp="$mac"
	fi
done

#remve sta mac in arp table list from wireless
for i in $(seq 0 23)
do
	ath=$(uci -p /var/state get qcawifi.@wifi-iface[${i}].ifname 2>&-)
	if [ ! "$ath" = "" ];then
		sta_list=$(iwinfo ${ath} assoclist | grep dBm | tr A-Z a-z)
		#delete mac in arp which is connect from wireless
		for mac in $sta_list
		do
			if [ ! "$mac" = "" -a ! "$mac" = "00:00:00:00:00:00" ]; then
				uci del_list misc.captive_portal.client_from_arp="$mac"
			fi
		done
	fi

done

#del
#old_mac_list=$(uci get misc.captive_portal.client_from_wired)
#for mac in $old_mac_list
#do
#	mac_exist=$(uci get misc.captive_portal.client_from_arp | grep "$mac" 2>&-)
	
#	#is not exist
#	if [ "$mac_exist" = "" ]; then
#		ebtables -t broute -D internal_captive_portal -s $mac -p IPv4 --ip-proto tcp --ip-dport 80:443 -j mark --set-mark 99990 --mark-target ACCEPT
#		uci del_list misc.captive_portal.client_from_wired="$mac"
#	fi
#done

#add
new_mac_list=$(uci get misc.captive_portal.client_from_arp)
for mac in $new_mac_list
do
	mac_exist=$(uci get misc.captive_portal.client_from_wired | grep "$mac" 2>&-)

	#is exist
	if [ "$mac_exist" = "" ]; then
		ebtables -t broute -I internal_captive_portal -s $mac -p IPv4 --ip-proto tcp --ip-dport 80:443 -j mark --set-mark 99990 --mark-target ACCEPT
		uci add_list misc.captive_portal.client_from_wired="$mac"
	fi
done

uci commit misc
