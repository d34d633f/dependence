#!/bin/sh

PATH_TRANSLATED= PATH_INFO=/techsupport_dl.cgi REQUEST_METHOD=GET /www/cgi/ssi
