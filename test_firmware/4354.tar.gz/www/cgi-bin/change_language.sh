PRE_LANGUAGE_TABLE=/tmp/pre_language_table
IMPORT_LANGUAGE_TABLE=/tmp/language_table.tar.gz
config_change()
{
	#$nvram set Enable_GUIStringTable=$1
	echo "$1" > /tmp/b
	$nvram set GUI_Region=$1
	$nvram set run_refresh="yes"
}
language_table_upgrade()
{
	local offset=0
        [ "$1" != "" ] && offset=$1
        dd if=$PRE_LANGUAGE_TABLE of=$IMPORT_LANGUAGE_TABLE bs=1 skip=$offset
	/bin/rm -rf $PRE_LANGUAGE_TABLE
	/sbin/language_table save
	/sbin/language_table reload
	sleep 1
}


