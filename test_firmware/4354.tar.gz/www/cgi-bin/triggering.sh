config_triggering_add()
{
	add_num=$(ls /tmp/configs | grep triggering | grep -v ^size | wc -l)
	add_num=$(($add_num+1))
	$nvram set triggering$add_num="$1 $2 $3 $4 $5 $6 $7 $8 0"
	$nvram set port_forward_trigger="1"
}

config_triggering_editnum()
{
	$nvram set porttrigger_editnum=$1
}

config_triggering_edit()
{
	edit_num=$($nvram get porttrigger_editnum)
	$nvram set triggering$edit_num="$1 $2 $3 $4 $5 $6 $7 $8 $9"
	$nvram set port_forward_trigger="1"
}

config_triggering_del()
{
	rm -f /tmp/configs/triggering$1
	$nvram show | grep triggering | grep -v ^size | sort -n > /tmp/aa
	cat /tmp/aa | /bin/grep 'triggering[0-9]=' > /tmp/cc
	cat /tmp/aa | /bin/grep 'triggering[0-9][0-9]=' >> /tmp/cc
	mv /tmp/cc /tmp/aa
	$nvram set port_forward_trigger="1"
	line=`grep "triggering" -c /tmp/aa`
	num=1
	while (test $num -le $line)
	do
		name=`sed ''"$num"'p' -n /tmp/aa | sed 's/triggering.*=//'`
		triggering_name=triggering$num
		$nvram set $triggering_name="$name"
		num=$(($num+1))
	done
	if [ $1 != $num ];then
		rm -f /tmp/configs/triggering$num
	fi
	rm -f /tmp/aa
}

config_triggering_apply()
{
	$nvram set disable_port_trigger=$1
	$nvram set porttrigger_timeout=$2
	total_num=$(ls /tmp/configs | grep triggering | grep -v ^size | wc -l)
	if [ $total_num != 0 ];then
		if [ $total_num = 1 ];then
			new_name=`cat /tmp/configs/triggering1 | sed "s/.$/$3/"`
			$nvram set triggering1="$new_name"
		else
			num=1	
			new_enable_list=$3
			line=`grep "triggering" -c /tmp/aa`
			while (test $num -le $total_num)
			do
				new_enable=$(echo "$new_enable_list" | sed 's/,.*//')
				triggering_name=triggering$num
				new_name=`cat /tmp/configs/$triggering_name | sed "s/.$/$new_enable/"`
				$nvram set $triggering_name="$new_name"
				new_enable_list=$(echo "$new_enable_list" | sed 's/.,//') 
				num=$(($num+1))
			done
		fi
	fi
}
