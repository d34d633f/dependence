config_rip() 
{
    $nvram set rip_version=$1
    $nvram set rip_direction=$2
}
