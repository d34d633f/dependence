config_pppoe()
{
	$nvram set wan_proto="pppoe"
	$nvram set internet_type="0"
	$nvram set internet_ppp_type="0"
	$nvram set wan_pppoe_username=$1
	$nvram set wan_pppoe_passwd=$2
	$nvram set wan_pppoe_service=$3
	$nvram set wan_pppoe_idletime=$(($4*60))
	$nvram set wan_pppoe_wan_assign=$5
	$nvram set wan_pppoe_ip=$6
	$nvram set wan_pppoe_dns_assign=$7
	if [ $7 -eq 1 ];then
		$nvram set wan_ether_dns1=$8
		$nvram set wan_ether_dns2=$9	
	fi	
	$nvram set static_conflict=${10}	
	$nvram set change_wan_type=${11}
	$nvram set run_test="${12}"
	$nvram set wan_pppoe_demand="${13}"
	if [ "${13}" = "1" ];then
		$nvram set wan_endis_dod=1
	elif [ "${13}" = "2" ];then
		$nvram set wan_endis_dod=2
	else
		$nvram set wan_endis_dod=0
	fi
}
