config_ntp()
{
	$nvram set endis_ntp=$1
	$nvram set ntpserver_select=$2
	$nvram set ntpserver1=$3
	$nvram set ntpserver2=$4
	$nvram set ntpadjust=$5
	$nvram set time_zone=$2
	$nvram set ntp_hidden_select=$6
}
