<?php
	ob_start();
	if(isset($_GET['username'])==false){
         header('location:../index.php');
         exit();
     }     
	else
	{
		$passStr = conf_get("system:basicSettings:adminPasswd");
	    $str = explode(' ',$passStr);
			//user1
		$user1 		= 	conf_get("system:userSettings:user1");
		$user1		=	explode(' ',$user1);
		$user1pwd 	= 	conf_get("system:userSettings:user1pword");
		$user1pwd	=	explode(' ',$user1pwd);
		$user1status= 	conf_get("system:userSettings:user1status");
		$user1status=	explode(' ',$user1status);
		
		//user2
		$user2 		= 	conf_get("system:userSettings:user2");
		$user2		=	explode(' ',$user2);
		$user2pwd 	=	conf_get("system:userSettings:user2pword");
		$user2pwd	=	explode(' ',$user2pwd);
		$user2status= 	conf_get("system:userSettings:user2status");
		$user2status=	explode(' ',$user2status);	
		
		//user3
		$user3 		= 	conf_get("system:userSettings:user3");
		$user3		=	explode(' ',$user3);
		$user3pwd 	= 	conf_get("system:userSettings:user3pword");
		$user3pwd	=	explode(' ',$user3pwd);
		$user3status= 	conf_get("system:userSettings:user3status");		
		$user3status=	explode(' ',$user3status);	
	
		//user4
		$user4 		= 	conf_get("system:userSettings:user4");
		$user4		=	explode(' ',$user4);
		$user4pwd 	=	conf_get("system:userSettings:user4pword");
		$user4pwd	=	explode(' ',$user4pwd);
		$user4status= 	conf_get("system:userSettings:user4status");		
		$user4status=	explode(' ',$user4status);	
		
		//system("/usr/local/bin/passwd_check \"".$_REQUEST['username']."\" \"".$_REQUEST['password']."\" >> /dev/null", $authCheck);
		$userpword = $_REQUEST['password'];
		
        if(($_GET['username']=='admin' && htmlentities($_REQUEST['password']) == htmlentities(conf_decrypt($str[1]))) || ($_REQUEST['username']== $user1[1] && $_REQUEST['password'] == conf_decrypt($user1pwd[1])) || ($_REQUEST['username']== $user2[1] && $_REQUEST['password'] == conf_decrypt($user2pwd[1])) || ($_REQUEST['username']== $user3[1] && $_REQUEST['password'] == conf_decrypt($user3pwd[1])) || ($_REQUEST['username']== $user4[1] && $_REQUEST['password'] == conf_decrypt($user4pwd[1]))){
	function getLoginUser()
	{
		$file = '/tmp/sessionid';
		if (!file_exists($file)) return '';
		$fp = fopen($file, "rb");
		if (!$fp) return '';
		$str = file_get_contents($file);
		fclose($fp);
		$strArr = explode(",",$str);
		return $strArr[2].",".$strArr[3].",".$strArr[4];
	}

	session_start();
	$loggeduser=getLoginUser();
	@unlink('/tmp/sessionid');
	session_destroy();
	
	session_start();
	$currentuser=explode(",",$loggeduser);
	$_SESSION['username']   = $currentuser[0];
	$_SESSION['previlige']   = $currentuser[1];
	$_SESSION['user_logged']   = $currentuser[2];
	$fp = fopen('/tmp/sessionid', 'w');
	fwrite($fp, session_id().','.$_SERVER['REMOTE_ADDR'].','.$_SESSION['username'].','.$_SESSION['previlige'].','.$_SESSION['user_logged']);
	fclose($fp);
	echo 'recreateok';
	}
     else {
         header('location:../index.php');
         exit();
     }
}
	ob_end_flush();
?>
