			var wizpage = 0;
			var which_second = 119;

			function show_setupwiz(){
				uLightBoxT.init({
			        override:true,
			        background: 'black',
			        centerOnResize: false,
			        fade: true
			    });

			    uLightBoxT.alert({
			    width: "614px",
			    title: '',
			    opened: function(){
			           $('<span />').html('<div class=\"wizard_banner\"\><table id=\"wizard_head\" class=\"wizard_head\"></table></div><div id=\"wizard_page\" class=\"wizard_img\"></div><div id=\"wizard_msg\" style=\"width: 100%; height: 159px;\">').appendTo('#lbContentT');
			           $('<span />').html('<div id=\"wizard_bottom\" style=\"text-align:left\"></div>').appendTo('#lbContentT');
			       	}
			   	});

			   	$("#uLightBoxT").attr("class", "wizardBox-top wizardBox-bottom");			   	
				$("#uLightBoxT").height(422);
				
			   	$("#lbHeader").attr("class", "wizradius-head");	
				$("#lbHeader").height(20);
				$('#lbHeader').css('filter', 'alpha(opacity=0)');

			   	$("#lbFooterT").attr("class", "wizradius-bottom");
			   	$("#lbFooterT").height(20);	
				$('#lbFooterT').css('filter', 'alpha(opacity=0)');

				$("#lbHeader").append('<img src=\"image/bg_top.png\" style=\"position:absolute; left: -20px;\">');
			   	$('#wizard_head').html('<tr><td id=\"wizard_title\" class=\"wizard_title\"></td><td id=\"wizard_close\" class=\"wizard_close\" onclick=\"close_setupwiz();\" valign=\"top\"><img src=\"image/closeWizard.gif\"></td></tr>');			   		   	
			   	$('#wizard_title').html(_wizard_conn);	
				
				var wizard_img = '<table id=\"wizard_img\" width=\"100%\" height=\"73\" cellspacing=\"0\">';
					wizard_img+= '<tr height="64px">';
					wizard_img+= '<td width=\"5%\"></td>';
					wizard_img+= '<td width=\"145\"><img src=\"image/Uplink.gif\" ></td>';
					wizard_img+= '<td width=\"27\"><img id=\"img_uplnk_right\" src=\"\"></td>'; //span
					wizard_img+= '<td width=\"80\" align=\"right\"><img id=\"img_dut_left\" src=\"\"></td>'; //span
					wizard_img+= '<td width=\"50\"><img src=\"image/DAP1520.png\" ></td>'; 
					wizard_img+= '<td width=\"80\" align=\"left\"><img id=\"img_dut_right\" src=\"\"></td>'; //span
					wizard_img+= '<td width=\"27\"><img id=\"img_client_left\" src=\"\"></td>'; //span
					wizard_img+= '<td align=\"left\"><img src=\"image/wifiCients.gif\" ></td>'; 
					wizard_img+= '<td width=\"5%\"></td>';
					wizard_img+= '</tr>';
					wizard_img+= '</table>';
					wizard_img+= '<table style=\"padding-bottom: 18px;\">';
					wizard_img+= '<td style=\"padding-left: 90px;\">'+ _up_router +'</td>';
					wizard_img+= '<td style=\"padding-left: 86px;\">DAP-1320</td>';
					wizard_img+= '<td style=\"padding-left: 85px;\">'+ _wifi_client +'</td>';
					wizard_img+= '</tr>';	
					wizard_img+= '</table>';				
				$('#wizard_page').html(wizard_img);

				var table1 = '<table id=\"wizard_page_1\" class=\"wizard_tables\">';
					table1+= '<tr><td>'+ _wizard_intro +'</td></tr>';
					table1+= '</table>';				

				var table2 = '<table id=\"wizard_page_2\" class=\"wizard_tables\">';
					table2+= '<tr valign=\"baseline\"><td><div id=\"conn_method_0\" class=\"cus_radio_on\" onClick=\"change_radio(\'conn_method\',0)\" style=\"top:10px\"></div><input type=\"radio\" name=\"conn_method\" value=\"0\" checked=\"true\" style=\"display:none\"></td><td> -- '+wps_KR51+'</td></tr>';
					table2+= '<tr><td><div id=\"conn_method_1\" class=\"cus_radio_off\" onClick=\"change_radio(\'conn_method\',1)\"></div><input type=\"radio\" name=\"conn_method\" value=\"1\" style=\"display:none\"></td><td> -- '+wps_KR51_1+'</td></tr>';
					table2+= '</table>';

				var table3 = '<table id=\"wizard_page_3\" class=\"wizard_tables\">';  //wps count --
					table3+= '<tr><td id=\"wps_msg\">'+ _wps_notice+' <font color="red"><span id=\"show_pbc_second\">120</span></font> '+ _seconds +'...</td></tr>';
					table3+= '<tr><td><div id=\"aniloader\"><span id=\"ani_test\"></span></div></td></tr>';
					table3+= '<tr><td><div id=\"aniloader_title\">'+_scanning+'...</div></td></tr>';
					table3+= '</table>';	
				
				var table4 = '<table id=\"wizard_page_4\" class=\"wizard_tables\">';  //wps fail
					table4+= '<tr><td>'+ _wps_notice_5 +'</td></tr>';
					table4+= '<tr><td style=\"text-align:center; height:90px;\" ><img src=\"image/warning.gif\"></td></tr>';
					table4+= '</table>';				

				var table5 = '<table id=\"wizard_page_5\" class=\"wizard_tables_5\" >'; //site survey
					table5+= '<tr><td>';
					table5+= '<div id=\"survey_result_list_container\" class=\"wizard_site_survey_table\"><span id=\"wizard_survey_result_list\"></span></div>';
					table5+= '</td></tr>';
					table5+= '</table>';

				var table6 = '<table id=\"wizard_page_6\" class=\"wizard_tables\" >'; 
					table6+= '<tr id=\"wizard_page_6_1\"><td colspan=\"2\">'+ _wifi_conn_1 +'</td></tr>';
					table6+= '<tr id=\"wizard_page_6_2\">' ;
					table6+= '<td id=\"wizard_page_6_2_1\">'+ wwz_wwl_wnp + ': </td><td><input id=\"uplink_password\" type=\"text\" class=\"styled-text\"></br></td></tr>';
					table6+= '<tr><td></td><td><span id=\"wizard_page_6_pass_msg\">'+ _8_and_63 +'</span></td></tr>';
					table6+= '</table>';

				var table7 = '<table id=\"wizard_page_7\" class=\"wizard_tables\">';
					table7+= '<tr><td>'+_setup_extend_network_name+'</td></tr>';
					table7+= '<tr><td><input type=\"text\" id=\"extend_ssid\" name=\"extend_ssid\" class=\"styled-text\" style=\"width:190px;\" value=\"\">&nbsp;'+_up_to_32+'</td></tr>';		
					table7+= '<tr><td>'+_setup_extend_network_password+'</td></tr>';		
					table7+= '<tr><td><input type=\"text\" id=\"extend_pwd\" name=\"extend_pwd\" class=\"styled-text\" maxlength=\"63\" style=\"width:190px;\" value=\"\">&nbsp;'+_8_and_63+'</td></tr>';
					table7+= '<tr id=\"table7_msg2\" ><td >'+_ext_wifi_network_name+'&nbsp;(SSID) : <span id=\"wiz_uplink_ssid_page7\"></span></td></tr>';
					table7+= '<tr><td><input type=\"checkbox\" id=\"en_extend\" name=\"en_extend\">'+_setup_extend_network_same_ssid+'</td></tr>';
					table7+= '</table>';

				var table8 = '<table id=\"wizard_page_8\" class=\"wizard_tables\">';					
					table8+= '<tr><td colspan=\"2\">'+_wps_notice_3+'</td></tr>';			
					table8+= '<tr><td class=\"wizard_complete\" style=\"width:42%;white-space:nowrap\">'+_wifi_network_name+	  ':</td><td  style=\"color:#4598AA;\" id=\"wiz_uplink_ssid\"></td></tr>';		
					table8+= '<tr><td class=\"wizard_complete\" style=\"width:42%;white-space:nowrap\">'+wwz_wwl_wnp+			  ':</td><td  style=\"color:#4598AA;word-break:break-all;\" id=\"wiz_uplink_pwd\"></td></tr>';					
					table8+= '<tr><td class=\"wizard_complete\" style=\"width:42%;white-space:nowrap\">'+_ext_wifi_network_name+ ':</td><td style=\"color:#4598AA;\" id=\"wiz_extend_ssid\"></td></tr>';							
					table8+= '<tr><td class=\"wizard_complete\" style=\"width:42%;white-space:nowrap\">'+_ext_wireless+' '+_password+':</td><td style=\"color:#4598AA;word-break:break-all;\" id=\"wiz_extend_pwd\"></td></tr>';									
					table8+= '</table>';

				var table_tobal = table1 + table2 + table3 + table4 + table5 + table6 + table7 + table8;
				$('#wizard_msg').html(table_tobal);
							

				$('#wizard_page_2 img').click(function(){
					if($(this).attr('src') == 'image/select.gif') {
						$('#wizard_page_2 img').each(function(){
							$(this).attr('src', 'image/select.gif');
							$(this).prev().attr('checked', 'false');
						});

						$(this).attr('src', 'image/select_.gif');
						$(this).prev().attr('checked', 'true');
					}
				});

				en_extend_check();
				var wiz_btm_tmp="<table id=\"wiz_bottom\" class=\"wizbottom-style\"><tr>";
				wiz_btm_tmp += "<td><div id=\"lang_text\">"+_Language+":</div></td><td><div id=\"custom_lang_select\" class=\"dropdown\" style=\"z-index:9999\">";
				wiz_btm_tmp += "<p>"+ _lang_english +"</p>";
				wiz_btm_tmp += "<ul>";
				wiz_btm_tmp += "<li><a rel=\"0\">"+_lang_english+"</a></li>";
				wiz_btm_tmp += "</ul></div></td>";
				wiz_btm_tmp += "<td id=\"wizbtn_back\" class=\"wizbutton-style\" onclick=\"minus_page()\"></td>";
				wiz_btm_tmp += "<td id=\"wizbtn_next\" class=\"wizbutton-style\" onclick=\"check_wizard_page()\"></td>";
				wiz_btm_tmp += "</tr></table>";


				get_by_id("wizard_bottom").innerHTML=wiz_btm_tmp;
				$(function(){
					custom_select("custom_lang_select", _lang_english, "lang_select","NULL");
				});

				$('<img src=\"image/bg_bottom.png\" style=\"position:absolute; left: -20px;\">').appendTo("#lbFooterT");

				
				wizpage = 1;	
				wlan1_ssid = "";
				
				
				//$('#extend_ssid').attr('value',get_by_id("wlan0_ssid").value); 
				$('#extend_ssid').attr('value',ssid_decode("wlan0_ssid")); 
				$('#extend_pwd').attr('value',get_by_id("wlan0_psk_pass_phrase").value);  
	
			   	wizard_page(0);
			}
			function close_setupwiz(){	
				if (setup_wizard_ap == "1"){
					if(confirm(_wizquit)){
						send_submit("form2");
						wizpage = 1;
						uLightBoxT.clear();
					}
				}else{
					wizpage = 1;
					uLightBoxT.clear();
				}
			}
			
			function check_wizard_page(){
				switch(wizpage){
					case 1:
					case 2:
						wizard_page(1);
						break;		
					case 5:
						if (get_radio_value("conn_method") != "0"){ // site survey 
							if (wizard_copy_site_info() == false){
								return ;
							}
						}
						break;
					case 6:
						if(security_mode==2){
							if (check_psk_wizard("uplink_password") == false){
								return false;
							}else{
								wizard_page(1);
								return true;
							}	
						}else if(security_mode==1){
							if(check_set_wep(get_by_id("uplink_password").value)==false){
								return false;
							}else{
								wizard_page(1);
								return true;
							}
						}else{
							wizard_page(1);
							return true;
						}
						break;
					case 7:
						if (page7_check_wireless() == false){
							return ;
						}	
						break;
					case 8:
						wizard_complete();
						break;
					default:
						break;
				}		
			}
			
			function minus_page(){
				switch(wizpage){
					case 1:
						break;
					case 7:
						if (get_radio_value("conn_method") == "0"){ // WPS
							wizard_page(-5);
						}else{
							if (security_mode == 0){
								wizard_page(-2);
							}else{
								wizard_page(-1);
							}
						}
						break;
					case 5:
						wizard_page(-3);
						break;
					default:
						wizard_page(-1);
						break;
				}
			}
			
			function show_picture(page){
				switch(wizpage){
					case 1:
						$('#img_uplnk_right').attr('src', '/image/wireless.gif');
						$('#img_dut_left').attr('src', '/image/wireless_180.gif');
						$('#img_dut_right').attr('src', '/image/wireless.gif');
						$('#img_client_left').attr('src', '/image/wireless_180.gif');
						break;
					case 2:	
					case 3:
					case 4:
					case 5:
					case 6:
						$('#img_uplnk_right').attr('src', '/image/wireless_.gif');
						$('#img_dut_left').attr('src', '/image/wireless_180_.gif');
						$('#img_dut_right').attr('src', '/image/wireless.gif');
						$('#img_client_left').attr('src', '/image/wireless_180.gif');
						break;
					case 7:
						$('#img_uplnk_right').attr('src', '/image/wireless.gif');
						$('#img_dut_left').attr('src', '/image/wireless_180.gif');
						$('#img_dut_right').attr('src', '/image/wireless_.gif');
						$('#img_client_left').attr('src', '/image/wireless_180_.gif');
						break;
					case 8:
						$('#img_uplnk_right').attr('src', '/image/wireless_.gif');
						$('#img_dut_left').attr('src', '/image/wireless_180_.gif');
						$('#img_dut_right').attr('src', '/image/wireless_.gif');
						$('#img_client_left').attr('src', '/image/wireless_180_.gif');
						break;
					default:
						$('#img_uplnk_right').attr('src', '/image/wireless.gif');
						$('#img_dut_left').attr('src', '/image/wireless_180.gif');
						$('#img_dut_right').attr('src', '/image/wireless.gif');
						$('#img_client_left').attr('src', '/image/wireless_180.gif');
						break;
				}
			}
			
			function wizard_page(index){
				//if(mode_flag==0){
					wizpage += index;
				//}else{
					//wizpage = index;
				//}
				$('#wizard_msg table').hide();
	   			$("#uLightBoxT").css('top', '25%');
				$("#lbContentT").css({'height':'381px', 'padding':'0px 34px'});
				$("#uLightBoxT").height(422);
				$("#wizard_msg").height(159);
				show_picture(wizpage);
							
				switch(wizpage){
					case 1:
						$('#wizard_title').html(_wizard_conn);
						
						if (setup_wizard_ap == "1"){
							$('#lang_text').show();
							$("#custom_lang_select").css("display", "");
						}
						else{
							$('#lang_text').hide();
							$("#custom_lang_select").css("display", "none");
						}
						
						$('#wizard_page_1').show();

						$('#wizbtn_back').css('background', 'url(/image/btn2.jpg)');
						//$('#wizbtn_back').attr('onclick','').unbind('click');							
						$('#wizbtn_back').html(_back);
						$('#wizbtn_next').html(TEXT074);	
						break;
					case 2:
						$('#wizard_title').html(_wizard_method);
						$('#wizard_page_2').show();
						$('#lang_text').hide();
						$("#custom_lang_select").css("display", "none");

						$('#wizbtn_back').css('background', 'url(/image/save_btn3.png)');
						//$('#wizbtn_back').attr('onclick','minus_page()');		
						break;
					case 3:																	
						$('#wizard_page_3').show();
						//$('#wizard_page_3').css({'width':'84%', 'padding-left':'10%'});		
						//$('#wiz_bottom').hide();			
						$('#wiz_bottom td').hide();		
						
						if (get_radio_value("conn_method") == "0"){ // WPS
							$('#wizard_title').html(_wps_vpb);
							$('#aniloader_title').hide();
							start_whp_wps_pbc();
						}else{
							$('#wizard_title').html(_select_wifi);
							$('#wps_msg').hide();
							
							wizard_survey_get_file();
						}
						creat_ani_loader('ani_test');
						
						break;
					case 4:
						//which_second = 119;
						$('#wizard_page_4').show();
						//$('#wizard_page_4').css({'width':'84%', 'padding-left':'10%'});	
						
						$('#wiz_bottom td').show();
						$('#lang_text').hide();
						$("#custom_lang_select").css("display", "none");
						$('#wizbtn_next').hide();
						$('#wizbtn_back').show();											
						$('#wizbtn_back').html(TEXT073);
						break;
					case 5:
						$('#wizard_title').html(_select_wifi);
						$('#wizard_page_5').show();
						$("#uLightBoxT").height(578);
			   			$("#lbContentT").css({'height':'538px'});			   			
			   			$("#uLightBoxT").css('top', '10%');	
						$("#wizard_msg").height(316);
														
						$('#wiz_bottom td').show();	
						$('#lang_text').hide();
						$("#custom_lang_select").css("display", "none");
						$('#wizbtn_next').html(_select);
						break;

					case 6:
						$('#wizard_title').html(_enter_passwd);
						$('#wizard_page_6').show();
						$('#wizard_page_6_2').css({'height':'70px'});	
						$('#wizard_page_6_2_1').css({'width':'22%'});	
						
						$('#wiz_bottom td').show();	
						$('#lang_text').hide();
						$("#custom_lang_select").css("display", "none");
						$('#wizbtn_back').html(_back);
						$('#wizbtn_next').html(TEXT074);								
						break;

					case 7:
						$('#wizard_title').html(_setup_extend_setting);					
						$('#wizard_page_7').show();
						//$('#wizard_page_7').css({'width':'80%','padding-left':'7%', 'padding-top':'10px'});	

						$('#en_extend').click(function(){
							en_extend_check();
						});
						
						$('#wiz_bottom td').show();
						$('#lang_text').hide();	
						$("#custom_lang_select").css("display", "none");

						$('#wizbtn_back').html(_back);		
						$('#wizbtn_next').html(TEXT074);	
						break;

					case 8:						
						$('#wiz_uplink_ssid').html(replace_special_char(wlan1_ssid));
						
						if (set_by_wps == "0"){
							if(wlan1_security != "disable"){
								$('#wiz_uplink_pwd').html(get_by_id("uplink_password").value); //page 6 password
								wlan1_psk_pass_phrase = $('#wiz_uplink_pwd').html();
							}else
								$('#wiz_uplink_pwd').html("");
						}else{
							if(wlan1_security != "disable"){
								$('#wiz_uplink_pwd').html(wlan1_psk_pass_phrase); //page 3 wps password
							}else
								$('#wiz_uplink_pwd').html("");
						}
							
						if($('#en_extend').attr('checked')){
							$('#wiz_extend_ssid').html($('#wiz_uplink_ssid').html());
							$('#wiz_extend_pwd').html($('#wiz_uplink_pwd').html());
						} else {
							$('#wiz_extend_ssid').html(get_by_id("extend_ssid").value);
							$('#wiz_extend_pwd').html(get_by_id("extend_pwd").value);							
						}
						var length_ul_ssid=get_by_id("wiz_uplink_ssid").innerHTML.length;
						var length_ul_pwd=get_by_id("wiz_uplink_pwd").innerHTML.length;
						var length_ext_ssid=get_by_id("wiz_extend_ssid").innerHTML.length;
						var length_ext_pwd=get_by_id("wiz_extend_pwd").innerHTML.length;
						var add_length=0;
						add_length=Math.ceil(length_ul_ssid/20)+Math.ceil(length_ul_pwd/20)+Math.ceil(length_ext_ssid/20)+Math.ceil(length_ext_pwd/20)-4;
						if(length_ul_ssid==0){
							add_length+=1;
						}
						if(length_ul_pwd==0){
							add_length+=1;
						}
						if(length_ext_ssid==0){
							add_length+=1;
						}
						if(length_ext_pwd==0){
							add_length+=1;
						}
						//$('#wiz_uplink_ssid').html()
						//console.log($('#wiz_uplink_ssid').val());
						var new_height_uLightBoxT=25*add_length+422;
						var new_height_lbContentT=25*add_length+381;
						new_height_lbContentT+='px';
						var new_height_wizard_msg=25*add_length+159;
						var new_top_uLightBoxT=25-(3*add_length);
						new_top_uLightBoxT+='%';
								
						$("#uLightBoxT").height(new_height_uLightBoxT);
			   			$("#lbContentT").css({'height':new_height_lbContentT});			   			
						$("#wizard_msg").height(new_height_wizard_msg);

			   			$("#uLightBoxT").css('top', new_top_uLightBoxT);	
						$('#wizard_title').html(_complete);					
						$('#wizard_page_8').show();
						//$('#wizard_page_8').css({'width':'85%','padding-left':'7%', 'padding-top':'10px'});

						$('#wizbtn_next').html(_save);						
						//$('#wizbtn_next').attr('onclick','wizard_complete()');		
						break;
				}
			}
			
			function page7_check_wireless(){
				if($('#en_extend').attr('checked')){
					wizard_page(1);
				}else{
					var	extend_ssid	= get_by_id("extend_ssid").value;
					
					if(extend_ssid.length < 1) {
						alert(_badssid);
						return false;
					}	
					
					if(check_ssid(extend_ssid)){
						return false;
					}
					
					if (check_psk_wizard("extend_pwd") == false){
						return false;
					}else{
						wizard_page(1);
						return true;
					}	
				}
				return true;				
			}
			
			function check_psk_wizard(password_id) {
				var psk_value = get_by_id(password_id).value;
				
				if(psk_value.length==0){
					var _key_blank_r=_key_blank.replace(/%s/gi, _password_s);
					alert(_key_blank_r);
					return false;
				}
				if(psk_value.length<8){
					alert(YM116);
					return false;
				}
				
				//wizard_page(1);
				//return true;
			}
			
			function en_extend_check(){
				if($('#en_extend').attr('checked')){
					$('#wizard_page_7 tr').hide();
					$('#wizard_page_7 tr:last').show();
					$('#table7_msg2').show();					
				} else {
					$('#wizard_page_7 tr').show();
					$('#table7_msg2').hide();	
				}
			}
						
			function wizard_complete(){
				get_by_id("wlan1_ssid").value=wlan1_ssid;
				
				if($('#en_extend').attr('checked')){
					get_by_id("wlan_repeater_mode").value="0";
					if(get_by_id("wlan_repeater_mode").value!="<!--# echo wlan_repeater_mode -->"){
						non_forward_flag=1;
					}
					
					if(wlan1_security!="disable"){
						var wlan1_security_type=wlan1_security.split("_");
						if(wlan1_security_type[0]=="wep") {
							get_by_id("wlan1_security").value=wlan1_security;
						}else {
							get_by_id("wlan1_11n_protection").value="auto";
							get_by_id("wlan1_security").value="wpa2auto_psk";
							get_by_id("wlan1_psk_cipher_type").value="both";
							get_by_id("wlan1_psk_pass_phrase").value = wlan1_psk_pass_phrase;
						}
					}else{
						get_by_id("wlan1_security").value="disable";
					}
					
				}else{
					
					get_by_id("wlan_repeater_mode").value="1";
					if(get_by_id("wlan_repeater_mode").value!="<!--# echo wlan_repeater_mode -->"){
						non_forward_flag=1;
					}
					if(wlan1_security!="disable"){
						
						var wlan1_security_type=wlan1_security.split("_");
						if(wlan1_security_type[0]=="wep") {
						}else {
							get_by_id("wlan1_11n_protection").value="auto";
							get_by_id("wlan1_security").value="wpa2auto_psk";
							get_by_id("wlan1_psk_cipher_type").value="both";
							get_by_id("wlan1_psk_pass_phrase").value = wlan1_psk_pass_phrase;
						}
					}else{
						get_by_id("wlan1_security").value="disable";
					}
					
					//wlan0 always wpa2 and both
					get_by_id("wlan0_11n_protection").value="auto";
					get_by_id("wlan0_security").value="wpa2auto_psk";
					if(get_by_id("wlan0_security").value!="<!--# echo wlan0_security -->"){
						non_forward_flag=1;
					}
					get_by_id("wlan0_psk_cipher_type").value="both";
					get_by_id("wlan0_psk_pass_phrase").value = get_by_id("extend_pwd").value
					if(get_by_id("wlan0_psk_pass_phrase").value!="<!--# echo wlan0_psk_pass_phrase -->"){
						non_forward_flag=1;
					}
					get_by_id("wlan0_ssid").value = get_by_id("extend_ssid").value;
					if(get_by_id("wlan0_ssid").value!="<!--# echo wlan0_ssid -->"){
						non_forward_flag=1;
					}
				}
				if(non_forward_flag==1){
					get_by_id("form1_change_forward").value="false";
				}
				var save_link="http://";
				save_link+=get_by_id("ap_device_name").value;
				create_favorite_link(save_link);	
				send_submit("form1");			
			}
			
////////wps wlan1 
			var check_id, count_id;
			
			function start_whp_wps_pbc(){
				wan_connection_type("wps_cli.htm");
				start_whp_wps_pbc_result();
			}
			
			var wan_connection_type = function(conn_type) {
				var wan_con = new createRequest();
				if(wan_con){
					var url = "";
					var temp_cURL = document.URL.split("/");
					for (var i = 0; i < temp_cURL.length-1; i++) {
						if ( i == 1) continue;
						if ( i == 0)
							url += temp_cURL[i] + "//";
						else
							url += temp_cURL[i] + "/";
					}
					url += conn_type;
					wan_con.open("GET", url, true);
					wan_con.send(null);
					//cnt = 2;
				}
			};
						
			function start_whp_wps_pbc_result(){
					which_second = 119;
					//disable_all_btn(false);
					get_by_id("show_pbc_second").innerHTML = which_second;
					//show_wizard_section(3);
					check_id = setInterval('get_wps_status()', 3000); // every 1 seconds to check the wps connect status	
					count_id = setInterval('check_time_down()', 1000);
			}
			
			function get_wps_status(){
				xmlhttp_wps_sta=new createRequest();
				if(xmlhttp_wps_sta){
					var url="";
					var temp_cURL=document.URL.split("/");
					
					for(var i=0; i<temp_cURL.length-1; i++){
						if(i==1){
							continue;
						}else if(i==0){
							url+=temp_cURL[i]+"//";
						}else{
							url+=temp_cURL[i]+"/";
						}
					}
					
					url+="wps_status.xml";
					xmlhttp_wps_sta.onreadystatechange=wps_xmldoc;
					xmlhttp_wps_sta.open("GET", url, true);
					xmlhttp_wps_sta.send(null);
				}
			}
			
			function check_time_down(){
				if (which_second == 0){
					clear_interval();
					wizard_page(1);	//go to wps fail UI,page 4 
					//show_wizard_section(6);	// show wizard section 6, WPS fail message
				}else{
					get_by_id("show_pbc_second").innerHTML = which_second--;
				}
			}
			
			function wps_xmldoc(){
				var wps_status;
				if(xmlhttp_wps_sta.readyState==4 && xmlhttp_wps_sta.status==200){
					try{
						wps_status=xmlhttp_wps_sta.responseXML.getElementsByTagName("wps_status")[0].firstChild.nodeValue;
						if(wps_status==1){
							clear_interval();	
							get_wps_info();							
							wizard_page(4); //page 7, wps success
							//show_wizard_section(4); // wps success
						}
					}catch(e){
						//do nothing
					}
				}
			}
			
			function get_wps_info(){
				get_uplink_info();	
			}
			
			function get_uplink_info(){
				xmlhttp_wps_result=new createRequest();
				if(xmlhttp_wps_result){
					var url="";
					var temp_cURL=document.URL.split("/");
					
					for(var i=0; i<temp_cURL.length-1; i++){
						if(i==1){
							continue;
						}else if(i==0){
							url+=temp_cURL[i]+"//";
						}else{
							url+=temp_cURL[i]+"/";
						}
					}
					
					url+="uplink_info.xml";
					xmlhttp_wps_result.onreadystatechange=uplinkinfo;
					xmlhttp_wps_result.open("GET", url, true);
					xmlhttp_wps_result.send(null);
				}
			}
					
			function uplinkinfo(){
				
				if(xmlhttp_wps_result.readyState==4 && xmlhttp_wps_result.status==200){
					try{
						wlan1_ssid=xmlhttp_wps_result.responseXML.getElementsByTagName("wlan1_ssid")[0].firstChild.nodeValue;
						var tmp_ssid=wlan1_ssid;
						wlan1_ssid=tmp_ssid;
						final_ssid=tmp_ssid;
						get_by_id("wiz_uplink_ssid_page7").innerHTML = replace_special_char(final_ssid);
						//get_by_id("wiz_uplink_ssid_page7").innerHTML = final_ssid;
						
						wlan1_psk_pass_phrase=xmlhttp_wps_result.responseXML.getElementsByTagName("wlan1_psk_pass_phrase")[0].firstChild.nodeValue;
						wlan1_security=xmlhttp_wps_result.responseXML.getElementsByTagName("wlan1_security")[0].firstChild.nodeValue;
						wlan1_psk_cipher_type=xmlhttp_wps_result.responseXML.getElementsByTagName("wlan1_psk_cipher_type")[0].firstChild.nodeValue;
						wlan1_wps_enable=xmlhttp_wps_result.responseXML.getElementsByTagName("wlan1_wps_enable")[0].firstChild.nodeValue;
						wlan1_wep_display=xmlhttp_wps_result.responseXML.getElementsByTagName("wlan1_wep_display")[0].firstChild.nodeValue;
						wlan1_wep64_key=xmlhttp_wps_result.responseXML.getElementsByTagName("wlan1_wep64_key")[0].firstChild.nodeValue;
						wlan1_wep128_key=xmlhttp_wps_result.responseXML.getElementsByTagName("wlan1_wep128_key")[0].firstChild.nodeValue;
						set_uplink_info();
						set_by_wps="1";
						//show_wizard_section(14);
					}catch(e){
						//do nothing
					}
				}
			}
			
			function set_uplink_info(){
				if(wlan1_security!="disable"){
					var wlan1_security_type=wlan1_security.split("_");
					if(wlan1_security[0]=="wep") {
					}else {
						get_by_id("wlan1_11n_protection").value="auto";
						get_by_id("wlan1_psk_cipher_type").value="both";
						get_by_id("wlan1_psk_pass_phrase").value=wlan1_psk_pass_phrase;
					}
					//get_by_id("uplink_summary_key").style.display = "";
				}else{
					//get_by_id("uplink_summary_key").style.display = "none";
				}
			}
			
			function clear_interval(){
				clearInterval(check_id);
				clearInterval(count_id);
			}
////wps wlan1 end
			function wizard_survey_get_file() {
				//alert("survey_get_file");
				xmlhttp_survey = new createRequest();
				//bar_id = setInterval('change_bar()', 1000);
				
				if(xmlhttp_survey){
					var url = "";
					var temp_cURL = document.URL.split("/");
					for (var i = 0; i < temp_cURL.length-1; i++) {
						if (i == 1) continue;
						if ( i == 0)
							url += temp_cURL[i] + "//";
						else
							url += temp_cURL[i] + "/";
					}
					url += "wds_scan.xml";
					xmlhttp_survey.onreadystatechange = wizard_site_survey_xmldoc; 
					xmlhttp_survey.open("GET", url, true); 
					xmlhttp_survey.send(null);
					//get_by_id("prev_btn7").disabled=true;
				}	
			}
			
			function wizard_site_survey_xmldoc(){
				if(xmlhttp_survey.readyState==4 && xmlhttp_survey.status==200){	
					//console.log("site_survey_xmldoc_done");
					try{
						site_list = set_mutil_data(xmlhttp_survey.responseXML.getElementsByTagName("wireless_network")[0]);
						sort_by_signal();
						discard_duplicate();
						wizard_show_site_survey();						
						wizard_page(2);
						//site_survey_flag=1;
						//uLightBoxT.clear();
						//showList("survey_result");
					}catch(e){
						//do nothing
						//console.log("wizard_site_survey_xmldoc_fail");
					}
				}
			}
			
			function wizard_show_site_survey(){
				//var scan_table = get_by_id("scan_table");
				var index = 0;
				var res_tmp="";
				last_select = -1;
				
				for (var i = 0; i < site_list.length; i++){
					var obj = site_list[i];
					var tmp_quality=0;
					
					if (obj.get("ssid") == ""){
						continue;
					}else{						
						index++;
					}
					res_tmp += "<div id=\"wiz_res_"+i+"\" onclick=\"select_site('"+i+"','wiz_res_"+i+"','"+get_security_str(obj.get("security"))+"')\" class=\"wizard_site_result\" style=\"cursor:pointer\">" + replace_special_char(process_survey_ssid(obj.get("ssid"),20));

					if(get_security_str(obj.get("security"))=="NONE"){
						res_tmp += "<div class=\"wizard_site_result_security\" style=\"display:none\"></div>";
					}else{
						res_tmp += "<div class=\"wizard_site_result_security\"><img src=\"image/security.png\" width=\"11\" height=\"20\"></div>";
					}
					tmp_quality=convert_percent(obj.get("quality"));
					if(tmp_quality<34){
						res_tmp += "<div class=\"wizard_site_result_quality_low\"></div>";
					}else if(tmp_quality>66){
						res_tmp += "<div class=\"wizard_site_result_quality_high\"></div>";
					}else{
						res_tmp += "<div class=\"wizard_site_result_quality_mid\"></div>";
					}
					res_tmp += "</div>";
				}

				get_by_id("wizard_survey_result_list").innerHTML=res_tmp;
			}			
			
			function wizard_copy_site_info(){
				var security;
				var obj;
				
				if (last_select != -1){
					obj = site_list[last_select];					
					}
				
				if (obj){
					wlan1_ssid = obj.get("ssid");
					get_by_id("wiz_uplink_ssid_page7").innerHTML = replace_special_char(wlan1_ssid);
					
					channel = obj.get("channel");
					security = (obj.get("security")).split(",");
					if (security[0].indexOf("NONE") > -1){
						security_mode = 0;
						wlan1_security="disable";
					}else if ((security[0].indexOf("WEP") > -1)){
						security_mode = 1;
						wlan1_security="wep";
					}else{
						wlan1_security="wpa2auto_psk";
						if(security[0].indexOf("WPA2") > -1){
							if(security[1]){
								//WPA,WPA2 mix
								wpa_mode = 3;
							}else{
								//WPA2 only
								wpa_mode = 2;
							}
						}else{
							//WPA only
							wpa_mode = 1;
						}
						if(security[0].indexOf("CCMP") > -1){
							if(security[0].indexOf("TKIP") > -1){
								//cipher type = both
								cipher_type = 0;
							}else{
								//cipher type = AES only
								cipher_type = 2;
							}
							
						}else{
							//TKIP
							cipher_type = 1;
						}
						security_mode = 2;
					}
					
					if (security_mode == 0){
						wizard_page(2);
					}else{
						wizard_page(1);
						if(wlan1_security=="wep"){
							$('#wizard_page_6_pass_msg').html(_5_or_13);
							$("#uplink_password").attr('maxlength','26');
						}else{
							$('#wizard_page_6_pass_msg').html(_8_and_63);
							$("#uplink_password").attr('maxlength','63');
						}
					}
					
					return true;
				}else{
					alert(_select_a_site);
					return false;
				}
			}