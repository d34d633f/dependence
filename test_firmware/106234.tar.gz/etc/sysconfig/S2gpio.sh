#!/bin/sh

STATUS_RED_LED=9
STATUS_GREEN_LED=40
PUSH_BUTTON=1

gpio_led_init() {
	
	for i in $STATUS_RED_LED $STATUS_GREEN_LED ;do
		gpio_ctrl d $i out
		
		#init gpio value.
		if [ $i = $STATUS_RED_LED ] ; then
			gpio_ctrl c $i on
		else
			gpio_ctrl c $i off
		fi
	done
}

gpio_on()
{
	gpio_ctrl c $1 on
}

gpio_off()
{
	gpio_ctrl c $1 off
}

case $1 in
on)
	gpio_on $2
	;;
off)
	gpio_off $2
	;;
start)
	gpio_led_init
	gpio_ctrl d $PUSH_BUTTON in
	gpio_ctrl m $PUSH_BUTTON on
	gpio_ctrl i on
	;;
*)
	echo "$0 [start] to initial gpio driver at booting"
	echo "$0 [on|off <num>] to control gpio"
	;;
esac
