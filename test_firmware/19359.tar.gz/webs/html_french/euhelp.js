if (HelpItem=='euwan'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br>' +
                                        "Lors de votre première utilisation, nous vous recommandons d'utiliser l'Assistant de configuration. Cliquez sur le bouton Assistant de configuration pour être guidé étape par étape dans le processus de configuration de votre connexion ADSL.<br><br>" +
                                        "Cochez la case Configuration manuelle si vous êtes un utilisateur plus avancé et si vous disposez des paramètres de votre fournisseur d'accès Internet (FAI).<br><br>" +
                                        "Faites attention lors de la saisie de votre nom d’utilisateur et de votre mot de passe. Ils sont sensibles à la casse. La plupart des problèmes de connexion sont causés par une mauvaise saisie du nom d’utilisateur ou du mot de passe. <br><br> "+
                                        '<a href="helpbasic.html#Internet">En savoir plus...</a>';
}else if (HelpItem=='euwireless'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br>' +
                                        'Pour sécuriser votre réseau sans fil (SSID), la première étape consiste à en modifier le nom. Remplacez-le par un nom familier ne contenant aucune information personnelle.<BR><BR> ' +
                                        'Activez le Balayage automatique des canaux afin que le routeur sélectionne le meilleur canal possible pour le réseau sans fil.<BR><BR> ' + 
										"Vous pouvez également décider de masquer votre réseau sans fil afin de sécuriser votre réseau sans fil. Dans ce cas, votre réseau ne s'affichera pas sur les clients sans fil lorsqu'ils rechercheront les réseaux disponibles. Pour connecter vos périphériques sans fil au routeur, vous devrez saisir manuellement le nom du réseau sans fil (SSID) pour chaque périphérique.  (Notez votre SSID et le garder à portée de main).<BR><BR>" +
                                        "Si vous avez activé la sécurité sans fil, assurez-vous d'avoir bien pris note de votre clé de chiffrement. Vous devrez saisir cette clé ainsi que le SSID pour tous les appareils sans fil que vous connecterez à votre réseau.<br><br>" +
										'<a href="helpbasic.html#Wireless">En savoir plus...</a>';
}else if (HelpItem=='eulan'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br>' +
                                        'Si votre réseau comporte déjà un serveur DHCP ou si vous utilisez des adresses IP statiques sur tous les périphériques du réseau, décochez la case Activer le serveur DHCP pour désactiver cette option.<BR><BR> ' + 
										'Si votre réseau comporte des périphériques dont l’adresse IP doit être fixe, ajoutez une réservation DHCP à chacun de ces appareils.<br><br>' + 
										'<a href="helpbasic.html#Local">En savoir plus...</a>';
}else if (HelpItem=='eublock'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces... </b> <br><br>' +
                                        "Vous pouvez facilement autoriser l'accès à Internet pendant les heures où il est bloqué par les Restrictions d'heures d'accès Internet ; cochez pour cela les cases sous Autoriser puis cliquez sur Enregistrer les paramètres. N'oubliez pas de recocher les cases Refuser pour réactiver les Restrictions d'heures.<br><BR> " + 
										'<a href="helpbasic.html#Parental">En savoir plus...</a>';

}else if (HelpItem=='eudatetime'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br>' +
                                        "Après avoir bien réglé l'heure et la date, vous pourrez définir les Restrictions d'heures avec précision dans la section Contrôle parental.<br><br>" +
                                        "Activez l'heure d'été pour garantir que votre routeur soit à l'heure juste toute l'année.<BR><BR> "+
                                        '<a href="helpbasic.html#Time">En savoir plus...</a>';
}else if (HelpItem=='euadvwlan'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br>' +
                                        'Il n\'est pas nécessaire de modifier ces options par défaut pour faire fonctionner le routeur sans fil. Pour cette option, le gain à l\'émission est la puissance du signal radio. Vous devrez diminuer la puissance si vous ajouter une nouvelle antenne à gain élevé, car elle dépassera les limites de fonctionnement.<br><br>' +
                                        '<a href="helpadvanced.html#WirelessAdv">En savoir plus...</a>';
}else if (HelpItem=='euadvlan'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br>' +
                                        'UPnP est utilisé pour de nombreux logiciels audiovisuels courants. Il permet de reconnaître automatiquement vos périphériques sur le réseau. Si vous pensez que UPnP met en danger votre sécurité, vous avez la possibilité de le désactiver ici. L\'option Bloquer les pings IMCP devrait être activée, afin que le routeur ne réponde pas aux requêtes Internet mal intentionnées. Les flux de multidiffusion sont utilisés par les fonctions réseau avancées comme IPTV distribués par votre FAI.<BR><BR> '+
                                        '<a href="helpadvanced.html#LANAdv">En savoir plus...</a>';

}else if (HelpItem=='eufwdmz'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br>' +
                                        'N\'activez l’option DMZ qu’en dernier recours. Si vous rencontrez des problèmes avec une application sur un ordinateur couvert par le routeur. Lorsque vous l\'avez placé hors de la protection du firewall. L\'adresse IP saisie. Par défaut, toutes les requêtes de port y sont transmises. Cette option ne devrait être utilisée que comme un outil de dépannage. Pour de courtes périodes.<BR><BR>' +
                                        '<a href="helpadvanced.html#Firewall">En savoir plus...</a>';

}else if (HelpItem=='euwizintro'){
 document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' +
 						  'This wizard will guide you through a step-by-step process to configure your new D-Link router and connect to the Internet.<p>' +
 						  'There are three steps to configure your router.<p>' + 
			 'Step 1, in order to protect your security, Change your <%ejGetOther(ProdInfo,ModemVer)%> router password,<p>' + 
 						  'Step 2, Select Internet connection type, input the information provided by ISP. <p>' + 
 						  'Step 3, you must restart your router.<p>' +
 						  '<a href="helpbasic.html#Internet">More...</a>';

 						  
}else if (HelpItem=='euwizpass'){
 document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' +
 						  'The default password is "admin", in orde to secure your network , please modify the password.<p>' +
 						  '<strong>note:</strong>  Confirm Password must be same as "New Password".<p>' + 
 						  'Of course, you can click  "skip" to ignore the step.<p>' + 
 						  '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizisp'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						  'Please select your Country and ISP, the PVC information will display Automatically. <p>Of course, you can modify the information if you can not find the country and ISP in the list below, you can select the "Others", then input the "VPI" and "VCI", select the  right Connection Type."<p>' +
						  '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizpppuser'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Please input  "username" and "password" provided by your ISP, and confirm the password is correct.<p>' + 
						   'If you can not go on next step, maybe the username or password is false, you should contact your ISP  right now.<P>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizsum'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Now, the setup will be finished. If you ensure the setting information correctly, you can click "Restart" make the setup effect, and the router will reboot.<p>' + 
						   'Of course, you can Click "Back" to review or modify settings.<p>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizprtcl'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Select the appropriate Internet connection type based on the information as provided by your ISP.<p>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizppp'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						  'Please enter the information exactly as shown taking note of upper and lower cases provided by your ISP. <p>' +
						  'The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>'+
						  '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizdyn'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Please enter the appropriate information below as provided by your ISP. The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>' + 
						 'Maybe, you have to input your PC  MAC address  if ISP requires , and you can click the button to copy it.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='euwizstatic'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Please enter the appropriate information below as provided by your ISP.The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>' + 
						 'You should input correct Ip address, SubnetMask, DefaultGateway and DNS information. By the way, if you select to keep defaultGateway and DNS information blank,  they should been gotten automatically.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';

}else if (HelpItem=='euwizreboot'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'The wizard page allows you to reboot your router, as well as restore it from  what you have changed. You can also backup your settings at a point when you have completed all your changes.<p>' + 
						 'If you ever need to automatically reconfigure your router,you can then use the saved file to restore to your favoured settings automatically.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='portmapping'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Port Mapping supports multiple ports to PVC and bridging groups. Each group will perform as an independent network. To support this feature, you must create mapping groups with appropriate LAN and WAN interfaces using the Add button.<p>' + 
						 'The Remove button will remove the grouping and add the ungrouped interfaces to the Default group. Only the default group has IP interface.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='routing'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'The Routing page allows you to set default gateway or Automatic Assigned Default Gateway. <p>' + 
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='wlschedule'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Calendrier vous permet de créer des règles de programmation à appliquer pour votre sans-fil (activer / désactiver).<p>' + 
						 '<a href="helpbasic.html#Internet">More...</a>';


}






