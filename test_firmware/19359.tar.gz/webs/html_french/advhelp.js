if (HelpItem=='webfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Create a list of websites that you would like the devices on ' +
                                        'your network to be allowed or denied access to.<br><br>' +
                                        '<a href="helpadvanced.html#Filter">En savoir pluse...</a>';
} else if (HelpItem=='ddns'){
  document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br> ' +
                                        'DDNS - This stands for Dynamic DNS.<br> ' +
                                        'By creating a static hostname, users will be able to point to this in order to access ' +
                                        'a dynamic IP address from anywhere in the world.<br><br>' +
                                        '<a href="helpadvanced.html#DDNS">En savoir pluse...</a>';
}else if (HelpItem=='acservice'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Par défaut, la gestion à distance devrait être désactivée. Toutefois, si vous souhaitez vous connecter et gérer votre routeur à partir d\'un autre périphérique Internet, vous pouvez ordonner au routeur d\'accepter de telles commandes à partir du port Internet. Cette option peut être utile si votre administrateur réseau n\'est pas présent ou si le support technique demande cet accès.<br><br>' +
                                        '<a href="helpadvanced.html#RM">En savoir pluse...</a>';

} else if (HelpItem=='wirelessadv'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'By default these options need not be changed for this router to operate with Wireless.For the option Transmit Power is the radio signal strength. You will need to decrease the power if you add an new high gain antenna, as this will exceed operating limits.<br><br>' +
                                        '<a href="helpadvanced.html#WirelessAdv">En savoir pluse...</a>';
} else if (HelpItem=='portforwarding'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Le menu déroulant Nom de l\'application contient une liste d\'applications prédéfinies. Vous pouvez également définir simplement une nouvelle règle.<br><br>' +
                                        '<a href="helpadvanced.html#PortForwarding">En savoir plus...</a>';
} else if (HelpItem=='porttriggering'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Utilisez cette fonction si vous essayez d\'exécuter l\'une des applications réseau mentionnées et si elle ne communique pas comme prévu.<br><br>' +
                                        'Le menu déroulant Nom de l\'application contient une liste d\'applications prédéfinies. Même si votre application figure dans cette liste, vous pouvez définir une nouvelle règle.<br><br>' +
                                        '<a href="helpadvanced.html#ApplicationRules">En savoir plus...</a>';
} else if (HelpItem=='dmz'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Enable the DMZ option only as a last resort. If you are having trouble ' +
                                        'using an application from a computer behind the router, first try opening ' +
                                        'ports associated with the application in the <b>Port Forwarding</b> section.<br><br>' +
                                        '<a href="helpadvanced.html#DMZ">En savoir pluse...</a>';
} else if (HelpItem=='infilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Donnez à chaque règle un nom parlant pour vous.<br><br>' +
                                        'Chaque règle peut autoriser l\'accès à partir du WAN.<br><br>' +
                                        'Les adresses IP source sont des adresses côté WAN et les adresses IP de destination sont des adresses côté LAN.<br><br>' +
                                        'Cliquer sur le bouton ajouter/Appliquer pour stocker une règle prête dans la liste des règles.<br><br>' +
                                        'Cochez la case Supprimer dans la liste des règles puis cliquez sur le bouton Supprimer pour supprimer définitivement une règle.<br><br>'+
                                        '<a href="helpadvanced.html#Inbound">En savoir plus...</a>';
} else if (HelpItem=='outfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Donnez à chaque règle un nom parlant pour vous.<br><br>' +
                                        'Chaque règle peut refuser le trafic sortant du LAN.<br><br>' +
                                        'Les adresses IP source sont des adresses côté LAN et les adresses IP de destination sont des adresses côté WAN.<br><br>' +
                                        'Cliquer sur le bouton ajouter/Appliquer pour stocker une règle prête dans la liste des règles.<br><br>' +
                                        'Cochez la case Supprimer dans la liste des règles puis cliquez sur le bouton Supprimer pour supprimer définitivement une règle.<br><br>'+
                                        '<a href="helpadvanced.html#Outbound">En savoir plus...</a>';
} else if (HelpItem=='macfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Create a list of MAC addresses that you would either like to allow or deny access to your ' +
                                        'network depending on the current <b>Global Policy</b>.<br><br>' +
                                        '<a href="helpadvanced.html#Filter">En savoir pluse...</a>';

} else if (HelpItem=='wlmacfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
													'Créer une liste d’adresses MAC pour autoriser ou refuser les utilisateurs d’accéder au routeur. ' + 
													'Cliquer sur Supprimer l’élément sélectionné si vous voulez enlever une adresse MAC de la liste.<br><br>' +
													'<a href="helpadvanced.html#WirelessFilter">Plus d’informations …</a>';
                     //                   'Create a list of MAC addresses that you would either like to allow or deny users access to '+
                     //                   'the wireless router. Click on Remove if you want to take out a MAC address from the MAC filter list.<br><br>' +
                     //                   '<a href="helpadvanced.html#WirelessAdv">More...</a>';

} else if (HelpItem=='wlbridge'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Selecting Acess Point enables access point functionality. Wireless bridge functionality ' +
                                        'will still be available and wireless stations will be able to associate to the AP.<br><br> ' +
                                        'Select Disabled in Bridge Restrict which disables wireless bridge restriction. <br><br>' +
                                        'Any wireless bridge will be granted access. Selecting Enabled or Enabled(Scan) enables ' +
                                        'wireless bridge restriction. Only those bridges selected in Remote Bridges will be granted access.<br><br>' +
                                        '<a href="helpadvanced.html#WirelessAdv">En savoir pluse...</a>';

} else if (HelpItem=='wlanQos'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Vous pouvez donner à des applications multimédia  une priorité et une qualité de service plus élevée sur le réseau sans fil. Ainsi les applications telles les vidéos seront de meilleure qualité. <br><br>' +
                                        '<a href="helpadvanced.html#QoS">En savoir pluse...</a>';

} else if (HelpItem=='lanQos'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Vous pouvez donner à des applications multimédia  une priorité et une qualité de service plus élevée sur le réseau Lan. Ainsi les applications telles les vidéos seront de meilleure qualité.<br><br>' +
                                        '<a href="helpadvanced.html#QoS">En savoir pluse...</a>';

}  else if (HelpItem=='tod'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Give each rule a name that is meaningful to you. For example, a schedule for Monday ' +
                                        'through Friday from 3:00pm to 9:00pm, might be called "After School" and enter the MAC address ' +
                                        'that you want to blocking.<br><br>' +
                                        '<a href="helpadvanced.html#Parental">En savoir pluse...</a>';

} else if (HelpItem=='dns'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Si la case « Activer l\'attribution automatique des DNS » est cochée, ce routeur acceptera la première attribution de DNS de l\'un des protocoles de connexion Interne. Des PVC ont été configurés par PPPoA, PPPoE ou MER/DHCP lors de l\'établissement de la connexion. Si cette case n\'est pas cochée, saisissez manuellement les adresses IP des serveurs DNS primaire et secondaire. N\'effectuez cette opération que si vous rencontrez des problèmes avec vos serveurs DNS.<br><br>' +
                                        '<a href="helpadvanced.html#DNS">En savoir plus...</a>';

} else if (HelpItem=='portmap'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'To use this feature, mapping groups should be created. <br>' +
                                        'If you need to remove an entry, then click on the Remove button.<br><br>' +
                                        '<a href="helpadvanced.html#Network">En savoir pluse...</a>';

} else if (HelpItem=='qosadd'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
       ' La QdS ou Qualité de service permet à votre routeur de hiérarchiser le flux des paquets de données dans votre routeur et sur votre réseau. Cette fonction est essentielle pour les programmes sensibles au temps de transmission, comme la voix sur IP, pour éviter les interruptions d\'appel. Il est possible de mettre en attente de grands volumes de données non critiques pour ne pas affecter ces programmes sensibles au temps de transmission. D-Link a défini certaines règles fréquemment utilisées pour la QdS. VoIP et H.323. sont souvent utilisés pour la téléphonie sur Internet.<br><br>'                    
									  +  '<a href="helpadvanced.html#QoS">En savoir plus...</a>';

} else if (HelpItem=='adslsetting'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Ne modifiez pas ces paramètres sauf instruction directe de votre FAI. Par défaut, le routeur D-Link déterminera votre meilleure connexion. Vous n\'avez pas besoin de modifier ces paramètres, sauf instructions du support technique de D-Link.<br><br>' +
                                        '<a href="helpadvanced.html#ADSLAdv">En savoir plus...</a>';

} else if (HelpItem=='snmp'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Fournit des moyens de surveiller le statut et l\'exécution aussi bien que des paramètres de configuration d\'ensemble.<br><br>' +
                                        '<a href="helpadvanced.html#SNMP">En savoir pluse...</a>';

} else if (HelpItem=='certificate'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'A local certificate identifies your router over the network.  To apply for a certificate, ' +
                                        'click on <b><font color="rgb(108,169,213)">Create Certificate Request</font></b> and if you have an existing certificate, click on ' +
                                        '<b><font color="rgb(108,169,213)">Import Certificate</font></b> to retrieve it.<br><br> ' +
                                        'Trusted certificate authority (CA) allows you to verify the certificates of your peers.<br><br>' +
                                        '<a href="helpadvanced.html#Network">En savoir pluse...</a>';

} else if (HelpItem=='staticroute'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Vous pouvez choisir quel passage à employer, byinterface ou en indiquant un passage.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">En savoir pluse...</a>';

} else if (HelpItem=='dfltgateway'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        '<b>NOTE</b>: If changing the AutomaticAssigned Default Gateway from unselected to selected, ' +
                                        'You must reboot the router to get the automatic assigned default gateway.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">En savoir pluse...</a>';

} else if (HelpItem=='dos'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'If "Enable Attack Prevent" checkbox isselected, the router will detect some attacks. ' +
                        'When the router detects attack, it will drop the packets and log them in the "System log".<br><br>' +
                                'If "Prevent IP Spoofing" checkbox is selected,the route will drop the packets from WAN interface ' +
                        'with private source ip address. The private ip addressranges are as: 10.0.0.0/8, 172.16.0.0/12, ' +
                        'and 192.168.0.0/16.<br><br>' +
                                        '<a href="helpadvanced.html#Firewall">En savoir pluse...</a>';

} else if (HelpItem=='tr069'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Provides a means to monitor status andperformance as well as set configuration parameters ' +
                                        'from WAN side.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">En savoir pluse...</a>';

} else if (HelpItem=='rip'){
  document.getElementById('helpLabel').innerHTML = '<b>Astuces...</b> <br><br> ' +
                                        'Enabling RIP provides a protocol that determines the best path to a target by estimating ' +
                                        'the distance in number of hops or intermediate routers.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">En savoir pluse...</a>';

}

