﻿if (HelpItem=='webfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Create a list of websites that you would like the devices on ' +
                                        'your network to be allowed or denied access to.<br><br>' +
                                        '<a href="helpadvanced.html#Filter">Weitere Informationen...</a>';
} else if (HelpItem=='ddns'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'DDNS - This stands for Dynamic DNS.<br> ' +
                                        'By creating a static hostname, users will be able to point to this in order to access ' +
                                        'a dynamic IP address from anywhere in the world.<br><br>' +
                                        '<a href="helpadvanced.html#DDNS">Weitere Informationen...</a>';
}else if (HelpItem=='acservice'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Standardmäßig sollte die Remoteverwaltung deaktiviert sein. Wenn Sie sich jedoch bei dem Router von einem anderen Internetgerät aus anmelden und den Router von diesem Gerät aus verwalten möchten, können Sie den Router so einstellen, dass er diese Befehle vom Internet-Port akzeptiert. Diese Option ist nützlich, wenn Ihr Netzwerkadministrator nicht vor Ort sein kann oder der Technische Kundendienst einen solchen Zugriff anfordert.<br><br>' +
                                        '<a href="helpadvanced.html#RM">Weitere Informationen...</a>';

} else if (HelpItem=='wirelessadv'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'By default these options need not be changed for this router to operate with Wireless.For the option Transmit Power is the radio signal strength. You will need to decrease the power if you add an new high gain antenna, as this will exceed operating limits.<br><br>' +
                                        '<a href="helpadvanced.html#WirelessAdv">Weitere Informationen...</a>';
} else if (HelpItem=='portforwarding'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Sie können Multimediaanwendungen eine höhere Priorität bei der Übertragung im drahtlosen Netzwerk zuweisen, dies führt zu einer höheren Stabilität und Qualität der Multimediaanwendung.<br><br>' +
                                        '<a href="helpadvanced.html#PortForwarding">Weitere Informationen...</a>';
} else if (HelpItem=='porttriggering'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Verwenden Sie diese Funktion, wenn Sie eine der aufgelisteten Netzwerkanwendungen ausführen möchten, diese aber nicht wie erwartet kommuniziert.<br><br>' +
                                        'Im Dropdown-Menü "Application Name" (Anwendungsname) können Sie aus einer Liste vordefinierter Anwendungen wählen. Wenn Ihre Anwendung nicht aufgelistet ist, können Sie eine neue Regel definieren.<br><br>' +
                                        '<a href="helpadvanced.html#ApplicationRules">Weitere Informationen...</a>';
} else if (HelpItem=='dmz'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Enable the DMZ option only as a last resort. If you are having trouble ' +
                                        'using an application from a computer behind the router, first try opening ' +
                                        'ports associated with the application in the <b>Port Forwarding</b> section.<br><br>' +
                                        '<a href="helpadvanced.html#DMZ">Weitere Informationen...</a>';
} else if (HelpItem=='infilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Geben Sie jeder Regel einen aussagekräftigen Namen.<br><br>' +
                                        'Mit jeder Regel können Sie den Zugriff aus dem WAN erlauben.<br><br>' +
                                        'Die Quell-IP-Adressen sind Adressen auf der WAN-Seite, während die Ziel-IP-Adressen LAN-seitige Adressen darstellen.<br><br>' +
                                        'Um eine fertige Regel in der Liste für Regeln zu speichern, klicken Sie auf "Hinzufügen".<br><br>' +
                                        'Wenn Sie eine Regel dauerhaft löschen möchten, aktivieren Sie in der Liste für Regeln das Kontrollkästchen "Entfernen", und klicken Sie anschließend auf "Entfernen".<br><br>'+
                                        '<a href="helpadvanced.html#Inbound">Weitere Informationen...</a>';
} else if (HelpItem=='outfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Geben Sie jeder Regel einen aussagekräftigen Namen.<br><br>' +
                                        'Jede Regel kann den vom LAN ausgehenden Datenverkehr blockieren.<br><br>' +
                                        'Die Quell-IP-Adressen sind Adressen auf der LAN-Seite, während die Ziel-IP-Adressen WAN-seitige Adressen darstellen.<br><br>' +
                                        'Um eine fertige Regel in der Liste für Regeln zu speichern, klicken Sie auf "Hinzufügen".<br><br>' +
                                        'Wenn Sie eine Regel dauerhaft löschen möchten, aktivieren Sie in der Liste für Regeln das Kontrollkästchen "Entfernen", und klicken Sie anschließend auf "Entfernen".<br><br>'+
                                        '<a href="helpadvanced.html#Outbound">Weitere Informationen...</a>';
} else if (HelpItem=='macfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Create a list of MAC addresses that you would either like to allow or deny access to your ' +
                                        'network depending on the current <b>Global Policy</b>.<br><br>' +
                                        '<a href="helpadvanced.html#Filter">Weitere Informationen...</a>';

} else if (HelpItem=='wlmacfilter'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
													'Erstellen Sie eine Liste von MAC Adressen, denen Sie entweder Zugang zu Ihrem WLAN Router ' + 
													'gewähren oder untersagen möchten. Klicken Sie auf „Entfernen“ wenn Sie eine MAC Adresse von ' + 
													'der Filter Liste entfernen möchten.<br><br>' +
                                        //'Create a list of MAC addresses that you would either like to allow or deny users access to '+
                                        //'the wireless router. Click on Remove if you want to take out a MAC address from the MAC filter list.<br><br>' +
                                        '<a href="helpadvanced.html#WirelessFilter">More...</a>';

} else if (HelpItem=='wlbridge'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Selecting Acess Point enables access point functionality. Wireless bridge functionality ' +
                                        'will still be available and wireless stations will be able to associate to the AP.<br><br> ' +
                                        'Select Disabled in Bridge Restrict which disables wireless bridge restriction. <br><br>' +
                                        'Any wireless bridge will be granted access. Selecting Enabled or Enabled(Scan) enables ' +
                                        'wireless bridge restriction. Only those bridges selected in Remote Bridges will be granted access.<br><br>' +
                                        '<a href="helpadvanced.html#WirelessAdv">Weitere Informationen...</a>';

} else if (HelpItem=='wlanQos'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Sie können Multimediaanwendungen eine höhere Priorität bei der Übertragung im drahtlosen Netzwerk zuweisen, dies führt zu einer höheren Stabilität und Qualität der Multimediaanwendung. <br><br>' +
                                      
                                        '<a href="helpadvanced.html#QoS">Weitere Informationen...</a>';

} else if (HelpItem=='lanQos'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Sie können Multimediaanwendungen eine höhere Priorität bei der Übertragung im kabelgebundenen Netzwerk zuweisen, dies führt zu einer höheren Stabilität und Qualität der Multimediaanwendung. <br><br>' +

                                        '<a href="helpadvanced.html#QoS">Weitere Informationen...</a>';

}  else if (HelpItem=='tod'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Give each rule a name that is meaningful to you. For example, a schedule for Monday ' +
                                        'through Friday from 3:00pm to 9:00pm, might be called "After School" and enter the MAC address ' +
                                        'that you want to blocking.<br><br>' +
                                        '<a href="helpadvanced.html#Parental">Weitere Informationen...</a>';

} else if (HelpItem=='dns'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Wenn das Kontrollkästchen DNS-Server-Adresse automatisch beziehen aktiviert ist, akzeptiert der Router den DNS-Server, den er von einem der Internetverbindungsprotokolle zuerst zugewiesen erhalten hat. Ist das Kontrollkästchen nicht aktiviert, geben Sie die IP-Adressen . Geben Sie diese NUR DANN manuell ein, wenn Probleme mit Ihren DNS-Servern auftreten.<br><br>' +							
                                    /*    'DDNS stands for Dynamic DNS. ' +
                                        'By creating a static hostname, users will be able to point to this in order to access ' +
                                        'a dynamic IP address from anywhere in the world.<br><br>' +*/
                                        '<a href="helpadvanced.html#DNS">Weitere Informationen...</a>';

} else if (HelpItem=='portmap'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'To use this feature, mapping groups should be created. <br>' +
                                        'If you need to remove an entry, then click on the Remove button.<br><br>' +
                                        '<a href="helpadvanced.html#Network">Weitere Informationen...</a>';

} else if (HelpItem=='qosadd'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
       ' Mit QoS bzw. Quality of Service kann Ihr Router den Fluss der Datenpakete in Ihrem Netzwerk priorisieren. Dies ist besonders wichtig bei Anwendungen wie VoIP, bei welchen die Latenzzeit eine große Rolle spielt, da ansonsten möglicherweise ein Anruf verloren geht. Große Mengen nichtkritischer Daten können so klassifiziert werden, dass sie die zeitempfindlichen Echtzeitprogramme nicht stören. D-Link hat bereits einige oft verwendete Regeln für QoS eingerichtet. So wird für Internet-Telefonie oft VoIP und H.323 verwendet. <br><br>'                    
									  +  '<a href="helpadvanced.html#QoS">Weitere Informationen...</a>';

} else if (HelpItem=='adslsetting'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Ändern Sie diese Einstellungen nur, wenn Ihr Internetdienstanbieter Sie dazu auffordert. Standardmäßig erkennt der D-Link-Router die beste Verbindung. Sie müssen keine Einstellungen verändern, es sei denn, der Technische Kundendienst fordert Sie dazu auf.<br><br>' +
                                        '<a href="helpadvanced.html#ADSLAdv">Weitere Informationen...</a>';

} else if (HelpItem=='snmp'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Das Simple Network Management Protocol (SNMP) ermöglicht es den Status und Statistiken über das Netzwerk mittels einer SNMP-Client-Anwendung zu überwachen..<br><br>' +
                                        '<a href="helpadvanced.html#SNMP">Weitere Informationen...</a>';

} else if (HelpItem=='certificate'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'A local certificate identifies your router over the network.  To apply for a certificate, ' +
                                        'click on <b><font color="rgb(108,169,213)">Create Certificate Request</font></b> and if you have an existing certificate, click on ' +
                                        '<b><font color="rgb(108,169,213)">Import Certificate</font></b> to retrieve it.<br><br> ' +
                                        'Trusted certificate authority (CA) allows you to verify the certificates of your peers.<br><br>' +
                                        '<a href="helpadvanced.html#Network">Weitere Informationen...</a>';

} else if (HelpItem=='staticroute'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Mit diesen Optionen wird die Konfiguration des Routing Information Protocol (RIP) vorgenommen. Um RIP für dieses Gerät zu aktivieren, wählen Sie die Option “aktivieren“ aus.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">Weitere Informationen...</a>';

} else if (HelpItem=='dfltgateway'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        '<b>NOTE</b>: If changing the AutomaticAssigned Default Gateway from unselected to selected, ' +
                                        'You must reboot the router to get the automatic assigned default gateway.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">Weitere Informationen...</a>';

} else if (HelpItem=='dos'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'If "Enable Attack Prevent" checkbox isselected, the router will detect some attacks. ' +
                        'When the router detects attack, it will drop the packets and log them in the "System log".<br><br>' +
                                'If "Prevent IP Spoofing" checkbox is selected,the route will drop the packets from WAN interface ' +
                        'with private source ip address. The private ip addressranges are as: 10.0.0.0/8, 172.16.0.0/12, ' +
                        'and 192.168.0.0/16.<br><br>' +
                                        '<a href="helpadvanced.html#Firewall">Weitere Informationen...</a>';

} else if (HelpItem=='tr069'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Provides a means to monitor status and performance as well as set configuration parameters ' +
                                        'from WAN side.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">Weitere Informationen...</a>';

} else if (HelpItem=='rip'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br> ' +
                                        'Enabling RIP provides a protocol that determines the best path to a target by estimating ' +
                                        'the distance in number of hops or intermediate routers.<br><br>' +
                                        '<a href="helpadvanced.html#Routing">Weitere Informationen...</a>';

}

