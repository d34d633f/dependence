﻿if (HelpItem=='euwan'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br>' +
                                        'Erstbenutzern wird empfohlen, den Setup-Assistenten zu verwenden.  Klicken Sie auf die Schaltfläche "Setup-Assistent". Sie werden dann Schritt für Schritt durch die Einrichtungsprozedur für Ihre ADSL-Verbindung geführt.<br><br>' +
                                        'Wenn Sie ein erfahrener Anwender sind und Ihnen die Einstellungen Ihres Internetdienstanbieters vorliegen, aktivieren Sie das Kontrollkästchen "Manuelles Einrichten".<br><br>' +
                                        'Achten Sie bei der Eingabe von Benutzernamen und Kennwort auf die Groß- und Kleinschreibung.  Die meisten Probleme beim Verbindungsaufbau sind auf eine falsche Eingabe von Benutzernamen oder Kennwort zurückzuführen.<br><br> '+
                                        '<a href="helpbasic.html#Internet">Weitere Informationen...</a>';
}else if (HelpItem=='euwireless'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br>' +
                                        'Der erste Schritt zur Sicherung Ihres drahtlosen Netzwerks besteht darin, den Namen Ihres drahtlosen Netzwerks (SSID) zu ändern.  Wählen Sie einen geläufigen Namen, der keine persönlichen Informationen enthält.<BR><BR> ' +
                                        'Aktivieren Sie "Auto Channel Scan" (Automatische Kanalerkennung), damit der Router den bestmöglichen Kanal für das drahtlose Netzwerk auswählt.<BR><BR> ' + 
										'Die Sicherheit des drahtlosen Netzwerks kann noch erhöht werden, indem Sie das drahtlose Netzwerk verbergen. Dies bewirkt, dass Ihr drahtloses Netzwerk nicht in der Netzwerkliste angezeigt wird, wenn Clients nach verfügbaren Netzwerken scannen.  Um die drahtlosen Geräte mit Ihrem Router zu verbinden, müssen Sie den Namen des Netzwerks (SSID) für jedes Gerät manuell eingeben.  (Schreiben Sie sich die SSID Ihres Netzwerks auf, und halten Sie diese griffbereit.<BR><BR>' + 
                                        'Wenn Sie WLAN-Sicherheit aktiviert haben, sollten Sie sich auch den Verschlüsselungsschlüssel notieren.  Sie müssen diesen Schlüssel und den Namen Ihres Netzwerks bei jedem drahtlosen Gerät eingeben, das Sie mit dem Netzwerk verbinden möchten.<br><br>' + 
										'<a href="helpbasic.html#Wireless">Weitere Informationen...</a>';
}else if (HelpItem=='eulan'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise... </b> <br><br>' +
                                        'Wenn sich in Ihrem Netzwerk bereits ein DHCP-Server befindet oder Sie für alle Geräte im Netzwerk statische IP-Adressen verwenden, deaktivieren Sie das Kontrollkästchen für die Option "DHCP-Server aktivieren".<BR><BR> ' + 
										'Wenn sich in Ihrem Netzwerk Geräte befinden, die eine feste IP-Adresse benötigen, fügen Sie für jedes dieser Geräte eine DHCP-Reservierung hinzu.<br><br>' + 
										'<a href="helpbasic.html#Local">Weitere Informationen...</a>';
}else if (HelpItem=='eublock'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise... </b> <br><br>' +
                                        'Sie können auch während der Zeiten, in denen eigentlich eine Zugriffsbeschränkung für das Internet besteht leicht auf das Internet zugreifen, indem Sie im Bereich "Zeitbeschränkungen für den Internetzugriff" die Kontrollkästchen unter "Erlauben" aktivieren und auf "Einstellungen speichern" klicken. Achten Sie darauf, die Kontrollkästchen "Block" wieder zu aktivieren, um die Zeitbeschränkungen wieder zu starten.<br><BR> ' + 
										'<a href="helpbasic.html#Parental">Weitere Informationen...</a>';

}else if (HelpItem=='eudatetime'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise... </b> <br><br>' +
                                        'Wenn Sie hier die genaue Uhrzeit und das genaue Datum eingeben, können Sie die Zeitbeschränkungen im Abschnitt "Kindersicherung" exakt festlegen.<br><br>' +
                                        '<a href="helpbasic.html#Time">Weitere Informationen...</a>';
}else if (HelpItem=='euadvwlan'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br>' +
                                        'Standardmäßig müssen diese Optionen für den Funkbetrieb des Routers nicht geändert werden.  Bei der Option "Übertragungsleistung" handelt es sich um die Stärke des Funksignals.  Sie müssen diese Leistung reduzieren, wenn Sie eine neue Hochleistungsantenne einbauen, da sonst die Kapazitätsgrenzen überschritten werden.<br><br>' +

                                        '<a href="helpadvanced.html#WirelessAdv">Mehr...</a>';
}else if (HelpItem=='euadvlan'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br>' +
                                        'UPnP wird von vielen gängigen audiovisuellen Programmen verwendet. Es ermöglicht die automatische Erkennung Ihres Geräts im Netzwerk. Wenn Sie der Meinung sind, dass UPnP ein Sicherheitsrisiko darstellt, können Sie diese Option hier deaktivieren. Aktivieren Sie "Block ICMP Ping" (ICMP-Ping sperren), um zu verhindern, dass der Router auf bösartige Anfragen aus dem Internet antwortet. Multicast-Datenströme werden von modernen Netzwerkfunktionen wie IPTV verwendet und von Ihrem Internetdienstanbieter verwendet. <BR><BR> '+
                                        '<a href="helpadvanced.html#LANAdv">Weitere Informationen</a>';

}else if (HelpItem=='eufwdmz'){
  document.getElementById('helpLabel').innerHTML = '<b>Nützliche Hinweise...</b> <br><br>' +
                                        'Aktivieren Sie die Option "DMZ" nur als letzten Ausweg. Wenn Sie Probleme haben, eine Anwendung auf einem Computer auszuführen, der sich hinter dem Router befindet. Die eingegebene IP-Adresse befindet sich dann außerhalb des Schutzes der Firewall, während standardmäßig alle Portanfragen an sie weitergeleitet werden. Sie sollten diese Option nur zur Fehlerbehebung und nur für kurze Zeit verwenden.<BR><BR>' +
									/*	'Normalerweise ist für LAN-Sitzungen die Option "Non-UDP/TCP/ICMP" aktiviert. Dadurch sind einzelne VPN-Verbindungen zu einem Remote-Host möglich.<br><br>'+*/
                                        '<a href="helpadvanced.html#Firewall">Weitere Informationen...</a>';

}else if (HelpItem=='euwizintro'){
 document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' +
 						  'This wizard will guide you through a step-by-step process to configure your new D-Link router and connect to the Internet.<p>' +
 						  'There are three steps to configure your router.<p>' + 
			 'Step 1, in order to protect your security, Change your <%ejGetOther(ProdInfo,ModemVer)%> router password,<p>' + 
 						  'Step 2, Select Internet connection type, input the information provided by ISP. <p>' + 
 						  'Step 3, you must restart your router.<p>' +
 						  '<a href="helpbasic.html#Internet">More...</a>';

 						  
}else if (HelpItem=='euwizpass'){
 document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' +
 						  'The default password is "admin", in orde to secure your network , please modify the password.<p>' +
 						  '<strong>note:</strong>  Confirm Password must be same as "New Password".<p>' + 
 						  'Of course, you can click  "skip" to ignore the step.<p>' + 
 						  '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizisp'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						  'Please select your Country and ISP, the PVC information will display Automatically. <p>Of course, you can modify the information if you can not find the country and ISP in the list below, you can select the "Others", then input the "VPI" and "VCI", select the  right Connection Type."<p>' +
						  '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizpppuser'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Please input  "username" and "password" provided by your ISP, and confirm the password is correct.<p>' + 
						   'If you can not go on next step, maybe the username or password is false, you should contact your ISP  right now.<P>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizsum'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Now, the setup will be finished. If you ensure the setting information correctly, you can click "Restart" make the setup effect, and the router will reboot.<p>' + 
						   'Of course, you can Click "Back" to review or modify settings.<p>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 


}else if (HelpItem=='euwizprtcl'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						   'Select the appropriate Internet connection type based on the information as provided by your ISP.<p>'+
						   '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizppp'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						  'Please enter the information exactly as shown taking note of upper and lower cases provided by your ISP. <p>' +
						  'The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>'+
						  '<a href="helpbasic.html#Internet">More...</a>'; 



}else if (HelpItem=='euwizdyn'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Please enter the appropriate information below as provided by your ISP. The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>' + 
						 'Maybe, you have to input your PC  MAC address  if ISP requires , and you can click the button to copy it.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='euwizstatic'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Please enter the appropriate information below as provided by your ISP.The Auto PVC Scan feature will not work in all cases so please enter the VPI/VCI numbers if provided by the ISP.<p>' + 
						 'You should input correct Ip address, SubnetMask, DefaultGateway and DNS information. By the way, if you select to keep defaultGateway and DNS information blank,  they should been gotten automatically.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';

}else if (HelpItem=='euwizreboot'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'The wizard page allows you to reboot your router, as well as restore it from  what you have changed. You can also backup your settings at a point when you have completed all your changes.<p>' + 
						 'If you ever need to automatically reconfigure your router,you can then use the saved file to restore to your favoured settings automatically.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='portmapping'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Port Mapping supports multiple ports to PVC and bridging groups. Each group will perform as an independent network. To support this feature, you must create mapping groups with appropriate LAN and WAN interfaces using the Add button.<p>' + 
						 'The Remove button will remove the grouping and add the ungrouped interfaces to the Default group. Only the default group has IP interface.<p>'+
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='routing'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'The Routing page allows you to set default gateway or Automatic Assigned Default Gateway. <p>' + 
						 '<a href="helpbasic.html#Internet">More...</a>';


}else if (HelpItem=='wlschedule'){
document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br>' + 
						 'Schedule ermöglicht Ihnen das Erstellen Planung Vorschriften, die für Ihre Wireless (aktivieren / deaktivieren).<p>' + 
						 '<a href="helpbasic.html#Internet">More...</a>';


}




