var CountryList=new Array();
var ISPList=new Array();

var ispPrtcl;
var ispEncap;
var ispVPI;
var ispVCI;
var ispMTU;

var PPPoEPPPoA=new Array();
var Dynamic=new Array();
var Static=new Array();

//modify the define of contrylist & ISPlist, by Jack 2008.4.24
var cn = 0;
var num = 0;
//Belgium
CountryList[cn]=new Citem(cn,"Belgique", 3);
ISPList[num++ ]=new ISPitem(cn, "Belgacom/Skynet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Scarlet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Versatel/Tele2", "PPPoA", "VC Mux", 8, 35, 0);
cn++;

//Bosnia
CountryList[cn]=new Citem(cn,"La Bosnie et la Herzégovine", 2);
ISPList[num++ ]=new ISPitem(cn,"BiHNet", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "HT", "PPPoE", "LLC", 8, 35, 1492);
cn++;

//Bulgaria
CountryList[cn]=new Citem(cn,"Bulgarien", 1);
ISPList[num++]=new ISPitem(cn, "BTC", "PPPoE", "LLC", 0, 35, 0);
cn++;

//Croatia
CountryList[cn]=new Citem(cn,"Croatie", 4);
ISPList[num++ ]=new ISPitem(cn, "H Telecom", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "Iskon", "PPPoE", "LLC", 0, 33, 1492);
ISPList[num++ ]=new ISPitem(cn, "Optima Telekom", "PPPoE", "LLC", 0, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "T-Com", "PPPoE", "LLC", 0, 33, 1492);
cn++;

//Czech Republic
CountryList[cn]=new Citem(cn,"République Tchèque", 4)
ISPList[num++ ]=new ISPitem(cn, "GTS Novera", "PPPoE", "LLC", 8, 48, 0);
ISPList[num++ ]=new ISPitem(cn, "Radiokomunikace", "PPPoE", "LLC", 8, 48, 0);
ISPList[num++ ]=new ISPitem(cn, "Telefonica O2", "PPPoE", "LLC", 8, 48, 0);
ISPList[num++ ]=new ISPitem(cn, "Volny", "PPPoE", "LLC", 8, 48, 0);
cn++;

//Denmark
CountryList[cn]=new Citem(cn,"Danemark", 1);
ISPList[num++ ]=new ISPitem(cn, "TDC", "PPPoE", "LLC", 0, 35, 0);
cn++;

//Finland
CountryList[cn]=new Citem(cn,"Finlande", 4);
ISPList[num++ ]=new ISPitem(cn, "DNA/Finnet", "Dynamic IP", "LLC", 0, 100, 0);
ISPList[num++ ]=new ISPitem(cn, "Elisa", "Dynamic IP", "LLC", 0, 100, 0);
ISPList[num++ ]=new ISPitem(cn, "Saunalahti", "Dynamic IP", "LLC", 0, 100, 0);
ISPList[num++ ]=new ISPitem(cn, "Sonera", "Dynamic IP", "LLC", 0, 33, 0);
cn++;

//France
CountryList[cn]=new Citem(cn,"France", 13);
ISPList[num++ ]=new ISPitem(cn, "Alice", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "AOL", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Bouygues Telecom", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Club Internet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Darty", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Easynet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Free", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Free (Degroupe)", "Static IP", "VC Mux", 8, 36, 0);
ISPList[num++ ]=new ISPitem(cn, "Neuf Cegetel", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Nordnet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Orange (Wanadoo)", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "SFR", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Tele2", "PPPoE", "LLC", 8, 35, 0);
cn++;

//Germany
CountryList[cn]=new Citem(cn,"Allemagne", 15);
ISPList[num++ ]=new ISPitem(cn, "1und1", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++ ]=new ISPitem(cn, "Alice", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++ ]=new ISPitem(cn, "AOL Germany", "PPPoE", "LLC", 1, 32, 1400);
ISPList[num++ ]=new ISPitem(cn, "Arcor", "PPPoE", "LLC", 1, 32, 1488);
ISPList[num++ ]=new ISPitem(cn, "Congster", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++ ]=new ISPitem(cn, "Freenet", "PPPoE", "LLC", 1, 32, 1454);
ISPList[num++ ]=new ISPitem(cn, "GMX", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++ ]=new ISPitem(cn, "Hansenet", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++ ]=new ISPitem(cn, "HeLi NET", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++ ]=new ISPitem(cn, "Kamp-DSL", "PPPoE", "LLC", 1, 32, 1460);
ISPList[num++ ]=new ISPitem(cn, "M-Net", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++ ]=new ISPitem(cn, "Netcologne", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++ ]=new ISPitem(cn, "T-Online", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++ ]=new ISPitem(cn, "Tiscali", "PPPoE", "LLC", 1, 32, 1492);
ISPList[num++ ]=new ISPitem(cn, "Versatel", "PPPoE", "LLC", 1, 32, 1492);
cn++;

//Greece
CountryList[cn]=new Citem(cn,"Grecia", 8);
ISPList[num++ ]=new ISPitem(cn, "Altec", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Forthnet", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Hellas On Line", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "NetOne", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "On Telecoms", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Otenet	", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Tellas", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Vivodi", "PPPoE", "LLC", 8, 35, 0);
cn++;

//Hungary
CountryList[cn]=new Citem(cn,"Hongrie", 2);
ISPList[num++ ]=new ISPitem(cn, "Matav", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "Invitel", "PPPoE", "LLC", 8, 35, 0);
cn++


//Ireland
CountryList[cn]=new Citem(cn,"Irlande", 4);
ISPList[num++ ]=new ISPitem(cn, "Eircom", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Esat", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "NTL", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "TalkTalk", "PPPoE", "LLC", 8, 35, 1492);
cn++;

//Italy
CountryList[cn]=new Citem(cn,"Italia", 12);
ISPList[num++ ]=new ISPitem(cn, "Aruba", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "BT Albacom", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Cheapnet", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Eutelia", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "INFOSTRADA", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Kataweb", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "McLink", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Tele 2", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Telecom Italia (PPPoE)", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Telecom Italia (PPPoA)", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Tiscali", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Vira", "PPPoA", "VC Mux", 8, 35, 0);
cn++;

//Lichtenstein
CountryList[cn]=new Citem(cn,"Lichtenstein", 1);
ISPList[num++ ]=new ISPitem(cn, "Telecom FL", "PPPoE", "LLC", 8, 35, 0);
cn++;

//FYROM
CountryList[cn]=new Citem(cn,"Ex Repubblica iugoslava di Macedonia", 1);
ISPList[num++ ]=new ISPitem(cn, "Maktel", "PPPoE", "LLC", 1, 32, 0);
cn++;

//Montenegro
CountryList[cn]=new Citem(cn,"Montenegro", 1);
ISPList[num++ ]=new ISPitem(cn, "T-Com", "PPPoE", "LLC", 0, 33, 1492);
cn++;

//Netherlands
CountryList[cn]=new Citem(cn,"Pays-Bas", 5);
ISPList[num++ ]=new ISPitem(cn, "BBned", "PPPoA", "VC Mux", 0, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "KPN", "PPPoA", "VC Mux", 8, 48, 0);
ISPList[num++ ]=new ISPitem(cn, "Tele2", "Dynamic IP", "LLC", 0, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Tiscali NL", "PPPoA", "VC Mux", 8, 48, 0);
ISPList[num++ ]=new ISPitem(cn, "Versatel", "PPPoA", "VC Mux", 0, 32, 0);
cn++;

//Norway
CountryList[cn]=new Citem(cn,"Norway", 2);
ISPList[num++ ]=new ISPitem(cn, "Nexgentel", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "Telenor", "PPPoE", "LLC", 8, 35, 0);
cn++;

//Poland
CountryList[cn]=new Citem(cn,"Pologne", 5);
ISPList[num++ ]=new ISPitem(cn, "Dialog", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "Dialog (TPSA)", "PPPoA", "VC Mux", 0, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Netia", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Netia (TPSA)", "PPPoA", "VC Mux", 0, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "TPSA", "PPPoA", "VC Mux", 0, 35, 0);
cn++;

//Portugal
CountryList[cn]=new Citem(cn,"Portugal", 3);
ISPList[num++ ]=new ISPitem(cn, "Clix", "PPPoE", "LLC", 0, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "PT", "PPPoE", "LLC", 0, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Zon", "PPPoE", "LLC", 0, 35, 0);
cn++;

//Romania
CountryList[cn]=new Citem(cn,"Roumanie", 1);
ISPList[num++ ]=new ISPitem(cn, "Romtelecom", "PPPoE", "LLC", 0, 35, 0);
cn++;


//Serbia
CountryList[cn]=new Citem(cn,"La Serbia", 7);cn++;
ISPList[num++ ]=new ISPitem(cn, "BeotelNET", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "DrenikNet", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "EUNet", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "Neobee Net", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "PTT Net", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "SezamPro", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "VeratNet", "PPPoE", "LLC", 8, 35, 1492);


//Slovak Republic
CountryList[cn]=new Citem(cn,"République slovaque", 4);
ISPList[num++ ]=new ISPitem(cn, "GTS Nextra", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "Slovanet", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "SWAN", "PPPoE", "LLC", 1, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "T-COM", "PPPoE", "LLC", 1, 32, 0);
cn++;

//Slovenia
CountryList[cn]=new Citem(cn,"La Slovénie", 1);
ISPList[num++ ]=new ISPitem(cn, "Siol/Telekom", "PPPoE", "LLC", 1, 32, 1480);
cn++;

//Spain
CountryList[cn]=new Citem(cn,"Espagne", 10);
ISPList[num++ ]=new ISPitem(cn, "Auna", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Jazztel", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Orange", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Telefonica(IP Dinamica)", "PPPoE", "LLC", 8, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "Telefonica(IP Estatica)", "Static IP", "LLC", 8, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "Wanadoo", "PPPoA", "VC Mux", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Ya.com(PPPoA)", "PPPoA", "VC Mux", 8, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "Ya.com(PPPoE)", "PPPoE", "LLC", 8, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "Ya.com(IP Dinamica)", "Dynamic IP", "LLC", 8, 32, 0);
ISPList[num++ ]=new ISPitem(cn, "Ya.com(IP Estatica)", "Static IP", "LLC", 8, 32, 0);
cn++;



//Sweden
CountryList[cn]=new Citem(cn,"Suède", 7); 
ISPList[num++ ]=new ISPitem(cn, "Bredbandsbolaget(PPPoE)", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Bredbandsbolaget(Static IP)", "Static IP", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Glocalnet(PPPoE)", "PPPoE", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Glocalnet(Static IP)", "Static IP", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Telia", "Dynamic IP", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Tele2(Dynamic IP)", "Dynamic IP", "LLC", 8, 35, 0);
ISPList[num++ ]=new ISPitem(cn, "Tele2(PPPoE)", "PPPoE", "LLC", 8, 35, 0);
cn++;

//Switzerland
CountryList[cn]=new Citem(cn,"Suisse", 6); 
ISPList[num++ ]=new ISPitem(cn, "Bluewin", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "Econophone", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "Green", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "Sunrise", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "Tele2", "PPPoE", "LLC", 8, 35, 1492);
ISPList[num++ ]=new ISPitem(cn, "VTX", "PPPoE", "LLC", 8, 35, 1492);
cn++;

//United Kingdom
CountryList[cn]=new Citem(cn,"Royaume-Uni", 30);
ISPList[num++ ]=new ISPitem(cn, "AOL", "PPPoA", "VC Mux", 0, 38, 1400);
ISPList[num++ ]=new ISPitem(cn, "BT", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++ ]=new ISPitem(cn, "Bulldog", "PPPoA", "VC Mux", 0, 38, 1458);
ISPList[num++ ]=new ISPitem(cn, "Demon Internet", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++ ]=new ISPitem(cn, "Easynet", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++ ]=new ISPitem(cn, "Eclipse", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Entanet", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Freedom 2 surf", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Griffin", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Madasfish", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Namesco", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Netservices", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Nildram", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++ ]=new ISPitem(cn, "O2", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "One.Tel", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++ ]=new ISPitem(cn, "Orange", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "PlusNet", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Pipex", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++ ]=new ISPitem(cn, "Sky Broadband", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "T-Mobile", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "TalkTalk", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Tesco.Net", "PPPoA", "VC Mux", 0, 38, 1432);
ISPList[num++ ]=new ISPitem(cn, "Tiscali", "PPPoA", "VC Mux", 0, 38, 0);
ISPList[num++ ]=new ISPitem(cn, "Toucan", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Twang", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "UK Online", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Virgin", "PPPoA", "VC Mux", 0, 38, 1492);
ISPList[num++ ]=new ISPitem(cn, "Virgin.Net", "PPPoA", "VC Mux", 0, 38, 1432);
ISPList[num++ ]=new ISPitem(cn, "Wanadoo", "PPPoA", "VC Mux", 0, 38, 1458);
ISPList[num++ ]=new ISPitem(cn, "Zen Internet", "PPPoA", "VC Mux", 0, 38, 0);
cn++;



//function Citem(scountry, iispcount)
function Citem(index,scountry, iispcount)  //modify by jack 2008.4.24
{
	this.index = index; // add by jack 2008.4.24
	this.scountry=scountry;
    this.iispcount=iispcount;
}


//function ISPitem(scountry,sname,sprtcl,sencap,ivpi, ivci, imtu)
function ISPitem(index,sname,sprtcl,sencap,ivpi, ivci, imtu)  //modify by jack 2008.4.24
{
    //this.scountry=scountry;
    this.index=index; 	//modify by jack 2008.4.24
    this.sname=sname;
    this.sprtcl=sprtcl;
    this.sencap=sencap;
    this.ivpi=ivpi;
    this.ivci=ivci;
    this.imtu=imtu;
}

function changeISP(cb1, cb2){

var value = cb1[cb1.selectedIndex].value;
	
	cb2.options.length=0;

	cb2.options[0]=new Option("(Cliccare per selezionare)", "-1");

	if ((value == -1)||(value == -2)){
		cb2.options[1]=new Option("Autres", "-2");
		if ((value == -2))
			cb2.selectedIndex = cb2.length - 1;

		return;
	}

	var count =0;

	for (i=0; i < ISPList.length; i++){
		//if (CountryList[cb1[cb1.selectedIndex].value].scountry == ISPList[i].scountry){
		if (CountryList[cb1[cb1.selectedIndex].value].index == ISPList[i].index){   //use an index to  judge,by jack
			cb2.options[count+1]=new Option(ISPList[i].sname, i);
			count++;
		}

		if (count == CountryList[cb1[cb1.selectedIndex].value].iispcount){
			break;
		}
	}

	cb2.options[count + 1]=new Option("Autres", "-2");
	
}

function createCountry(cb){
	
	cb.options.length=0;

	cb.options[0]=new Option("(Cliccare per selezionare)", "-1");

	var count =0;

	for (i=0; i < CountryList.length; i++){
		cb.options[i+1]=new Option(CountryList[i].scountry, i);
		count++;
	}

	cb.options[count + 1]=new Option("Autres", "-2");
	
}

function getISPDetails(cb){

var value = cb[cb.selectedIndex].value;

	if ((value == -1)||(value == -2)){
		ispPrtcl = "";
		ispEncap = "";
		ispVPI = 0;
		ispVCI = 35;
		ispMTU = 0;
		return;
	}

	ispPrtcl = ISPList[cb[cb.selectedIndex].value].sprtcl;
	ispEncap = ISPList[cb[cb.selectedIndex].value].sencap;
	ispVPI = ISPList[cb[cb.selectedIndex].value].ivpi;
	ispVCI = ISPList[cb[cb.selectedIndex].value].ivci;
	ispMTU = ISPList[cb[cb.selectedIndex].value].imtu;
	
}

function setContype(cb){
	
	cb.options.length = 0;

	cb.options[0] = new Option("(Cliccare per selezionare)", "-1");
	cb.selectedIndex = 0;

	if (ispPrtcl == "PPPoA"){
		cb.options[1] = new Option("VC-Mux", "PPPoAVCMux");
		cb.options[2] = new Option("LLC", "PPPoALLC");
		if (ispEncap == "LLC")
			cb.selectedIndex = 2;
		else if (ispEncap == "VC Mux")
			cb.selectedIndex = 1;
	} else if (ispPrtcl == "PPPoE"){
		cb.options[1] = new Option("VC-Mux", "PPPoEVCMux");
		cb.options[2] = new Option("LLC", "PPPoELLC");
		if (ispEncap == "LLC")
			cb.selectedIndex = 2;
		else if (ispEncap == "VC Mux")
			cb.selectedIndex = 1;
	} else if (ispPrtcl == "Dynamic IP"){
		cb.options[1] = new Option("LLC", "DynLLC");
		cb.options[2] = new Option("VC-Mux", "DynVCMux");
		if (ispEncap == "LLC")
			cb.selectedIndex = 1;
		else if (ispEncap == "VC Mux")
			cb.selectedIndex = 2;
	} else if (ispPrtcl == "Static IP"){
		cb.options[1] = new Option("LLC", "MerLLC");
		cb.options[2] = new Option("VC-Mux", "MerVCMux");
//		cb.options[2] = new Option("1483 Routed IP LLC", "IPoALLC");
//		cb.options[3] = new Option("1483 Routed IP VC-Mux", "IPoAVCMux");
		if (ispEncap == "LLC")
			cb.selectedIndex = 1;
		else if (ispEncap == "VC Mux")
			cb.selectedIndex = 2;
	} else if (ispPrtcl == "Bridge"){
		cb.options[1] = new Option("LLC", "MerLLC");
		cb.options[2] = new Option("VC-Mux", "MerVCMux");
		if (ispEncap == "LLC")
			cb.selectedIndex = 1;
		else if (ispEncap == "VC Mux")
			cb.selectedIndex = 2;
	}
}


