﻿if (HelpItem=='deviceinfo'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        "Questa pagina mostra una panoramica sullo stato del router, includendo la versione del software, il riepilogo dei parametri di configurazione Internet e lo stato delle connessioni wireless ed Ethernet.<br><br>" +
                                        '<a href="helpstatus.html#DeviceInfo">Ulteriori informazioni...</a>';

} else if (HelpItem=='connectclients'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        'Visualizza la lista dei clienti attualmente collegati a questo router, separato nei clienti e nelle esposizioni senza fili la lista dei clienti attualmente collegati a questo router, separato negli elenchi senza fili dei clienti di lan e dei clienti. I clienti senza fili elencano le esposizioni voi tutto il PC/clients senza fili attualmente collegato. I clienti di lan elencano le esposizioni voi tutti gli indirizzi dinamicamente assegnati attivi del IP di DHCP compreso la radio e PC/clients collegato Ethernet.<br><br>' +
                                        '<a href="helpstatus.html#WirelessClients">Ulteriori informazioni...</a>';

} else if (HelpItem=='dhcpclient'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        "Visualizza l'elenco dei client attualmente connessi al router, suddivisi in client wireless e client di LAN.  L'elenco dei client wireless contiene tutti i client/PC attualmente connessi al router in modalità wireless.  L'elenco dei client di LAN visualizza tutti gli indirizzi IP assegnati dinamicamente dal server DHCP, includendo tutti i client/PC attualmente connessi al router in modalità wireless ed Ethernet.<br><br>" +
                                        '<a href="helpmenu.html">Ulteriori informazioni...</a>';
} else if (HelpItem=='log'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        'Check the log frequently to detect unauthorized network usage.<br><br>' +
                                        '<a href="helpstatus.html#Logs">Ulteriori informazioni...</a>';

} else if (HelpItem=='statistics'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        "Questa pagina contiene statistiche sulla rete e sulla trasmissione dei dati. Queste informazioni possono risultare utili ai tecnici D-Link in caso di un malfunzionamento del router.  Queste informazioni servono generalmente solo a titolo di conoscenza e non influenzano le funzionalità del router.<br><br>" +
                                        '<a href="helpstatus.html#Statistics">Ulteriori informazioni...</a>';

}else if (HelpItem=='ber'){
  document.getElementById('helpLabel').innerHTML = '<b>Consigli utili...</b> <br><br> ' +
                                        'Il test ADSL BER (Bit Rate Error) determina la qualità della connessione ADSL. Il test si basa sul trasferimento di celle inattive, contenenti modelli conosciuti che vengono confrontati con i dati ricevuti al fine di individuare eventuali errori.' +
                                        '<a href="helpstatus.html#BER">Ulteriori informazioni...</a>';
}
else if (HelpItem=='routingtable'){
  document.getElementById('helpLabel').innerHTML = '<b>Helpful Hints...</b> <br><br> ' +
  													'Il percorso Info mostra alla tabella di percorso statica quale includono la destinazione, il subnet mask e gatway.<br><br>'+
                                        '<a href="helpstatus.html#RoutingInfo">More...</a>';
}