#!/bin/sh
buildver=`cat /etc/config/buildver`
buildno=`cat /etc/config/buildno`
echo "v$buildver build $buildno"
