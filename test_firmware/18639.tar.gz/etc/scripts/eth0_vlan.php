#!/bin/sh
echo [$0] ... > /dev/console
<? /* vi: set sw=4 ts=4: */

$WLAN_g = "/wlan/inf:1";  // b, g, n band
$WLAN_a = "/wlan/inf:2";  // a, n band 

$multi_ssid_path_g = $WLAN_g."/multi";
$multi_ssid_path_a = $WLAN_a."/multi";
$wds_path_g = $WLAN_g."/wds";
$wds_path_a = $WLAN_a."/wds";

$sys = "/sys";
$eth = "/lan/ethernet";

$multi_total_state_g = query($multi_ssid_path_g."/state");
$multi_total_state_a = query($multi_ssid_path_a."/state");
$ap_operate_mode_g = query($WLAN_g."/ap_mode");
$ap_operate_mode_a = query($WLAN_a."/ap_mode");

if ($generate_start==1)
{    
	// for dual band AP, only when both multi-ssid enable, VLAN can be activated, Joe, 2009-06-03
	// if ($multi_total_state_g == 1 && $multi_total_state_a == 1)

	// for dual band AP, if either one band(2.4G/5G) set as APC, disable VLAN, Joe, 2009-10-13
	if ($ap_operate_mode_g != 1 && $ap_operate_mode_a != 1)
	{       	    
	    // MULTI_VLAN +++
	    $vlan_state = query($sys."/vlan_state"); 
	    $vlan_mode = query($sys."/vlan_mode"); 
	    $auth_mode_g = query($WLAN_g."/authentication");	
	    $auth_mode_a = query($WLAN_a."/authentication");	
	    
	    // check vlan status
	    if ($vlan_state == 1 && $vlan_mode==1)  // dynamic vlan mode
	    {    
	        if ($auth_mode_g==1 || // shared key 
				$auth_mode_a==1 ||
                $auth_mode_g==0 || // open
                $auth_mode_a==0 || // open
                $auth_mode_g==3 || //wpa-psk 
                $auth_mode_a==3 || //wpa-psk 
                $auth_mode_g==5 || //wpa2-psk  
                $auth_mode_a==5 || //wpa2-psk  
                $auth_mode_g==7 || //wpa-auto-psk     
                $auth_mode_a==7 || //wpa-auto-psk     
                $auth_mode_g==9 || //802.1x
                $auth_mode_a==9    //802.1x
                )
            {   // if not wpa-eap -> disable vlan.
                //echo "\necho set($sys./vlan_state, 0  ...\n > /dev/console\n";  
                set($sys."/vlan_state", 0);  // 
                set($sys."/vlan_mode", 0);  // 
            } 
        } 
	    $vlan_state = query($sys."/vlan_state"); 
	    // end of // check vlan status
	    
	    $vlan_id_sys = query($sys."/vlan_id"); 
	    $vlan_id_eth = query($eth."/vlan_id"); 
	    $vlan_id_g = query($WLAN_g."/vlan_id"); 	    
	    $vlan_id_a = query($WLAN_a."/vlan_id"); 	    
	    if($vlan_state == 1)
	    { 
            echo "\necho MTU=1504 setting...\n > /dev/console\n"; 
	        echo "ifconfig eth0  mtu 1504\n";
	    }                      
	    if($vlan_state == 1 && $vlan_mode==0) // static vlan mode
	    {	        
            echo "\necho start vlan setting...\n > /dev/console\n"; 
            
	        echo "brctl setvlanstate br0 1\n";
	        $group_vid_path = "/sys/group_vlan";
	        //   set vlan mode
	        if ($vlan_mode==0)
	            {echo "brctl setvlanmode br0 0\n";}
	        else
	            {echo "brctl setvlanmode br0 1\n";}	            
	            
            //	 set pvid
	        if ($vlan_id_eth!="")			
	        { 
	            echo "brctl setpvidif br0 eth0 ".$vlan_id_eth."\n";
	        } 
	        if ($vlan_id_sys!="")			
	        { 
	            echo "brctl setsysvid br0 ".$vlan_id_sys."\n";
	        }      
               
		$ind=0;
	        for ($group_vid_path."/index") 
            {
    	        $ind++;
    	        echo "echo ind: ".$ind."  \n"; 
    	        $group_vid = query($group_vid_path."/index:".$ind."/group_vid");
    	        if ($group_vid!="")
    	        {
                    $eth0_egress= query($group_vid_path."/index:".$ind."/eth:1/egress"); 
                    $sys_egress=  query($group_vid_path."/index:".$ind."/sys:1/egress"); 
    	            //  jack test debug +++
    	            /*
    	            echo "echo ath0_egress: ".$ath0_egress." \n";
    	            echo "echo ath1_egress: ".$ath1_egress." \n";
    	            echo "echo ath2_egress: ".$ath2_egress." \n";
    	            echo "echo ath3_egress: ".$ath3_egress." \n";
    	            echo "echo ath4_egress: ".$ath4_egress." \n";
    	            echo "echo ath5_egress: ".$ath5_egress." \n";
    	            echo "echo ath6_egress: ".$ath6_egress." \n";
    	            echo "echo ath7_egress: ".$ath7_egress." \n";
    	            echo "echo ath8_egress: ".$ath8_egress." \n";
    	            echo "echo ath9_egress: ".$ath9_egress." \n";
    	            echo "echo ath10_egress: ".$ath10_egress." \n";
    	            echo "echo ath11_egress: ".$ath11_egress." \n";
    	            echo "echo ath12_egress: ".$ath12_egress." \n";
    	            echo "echo ath13_egress: ".$ath13_egress." \n";
    	            echo "echo ath14_egress: ".$ath14_egress." \n";
    	            echo "echo ath15_egress: ".$ath15_egress." \n";
    	            echo "echo eth0_egress: ".$eth0_egress." \n";
    	            echo "echo sys_egress: ".$sys_egress." \n";*/
    	            //  jack test debug ---            
                    if ($eth0_egress==1)  {echo "brctl setgroupvidif br0 eth0 ".$group_vid." 1\n"; }    else if ($eth0_egress==2)  {echo "brctl setgroupvidif br0 eth0 ".$group_vid." 0\n"; }       
                    if ($sys_egress==1)   {echo "brctl setgroupvidif br0 sys ".$group_vid." 1\n"; }     else if ($sys_egress==2)   {echo "brctl setgroupvidif br0 sys ".$group_vid." 0\n"; }     
    	        }   // end of if ($group_vid!="")
    	    } // end of for loop
	    }  // end of if($vlan_state == 1)
	    else if($vlan_state == 1 && $vlan_mode==1) // NAP vlan mode
	    {	        
	        echo "brctl setvlanstate br0 1\n";
	        echo "brctl setvlanmode br0 1\n";	  
	        echo "iwpriv ath0 napstate 1\n";		              
	        echo "iwpriv ath16 napstate 1\n";		              
	    }
	    else  // if($vlan_state != 1) 
	    { 
	        echo "brctl setvlanstate br0 0 \n";  
	    }   
	    // MULTI_VLAN ---         
	} // end of ($ap_operate_mode_g != 1 && $ap_operate_mode_a != 1)

} // end of ($generate_start==1)
else
{
    
	//if ($multi_total_state_g == 1 && $multi_total_state_a == 1)
	if ($ap_operate_mode_g != 1 && $ap_operate_mode_a != 1)
	{       
	    // MULTI_VLAN +++
	    $vlan_state = query($sys."/vlan_state");  
	    $vlan_mode = query($sys."/vlan_mode");   
	    $auth_mode_g = query($WLAN_g."/authentication");	
	    $auth_mode_a = query($WLAN_a."/authentication");	
	    	    
	    // check vlan status
	    if ($vlan_state == 1 && $vlan_mode==1)  // dynamic vlan mode
	    {    
	        if ($auth_mode_g==1 || // shared key 
				$auth_mode_a==1 ||
                $auth_mode_g==0 || // open
				$auth_mode_a==0 ||
                $auth_mode_g==3 || //wpa-psk 
                $auth_mode_a==3 || //wpa-psk 
                $auth_mode_g==5 || //wpa2-psk  
                $auth_mode_a==5 || //wpa2-psk  
                $auth_mode_g==7 || //wpa-auto-psk     
                $auth_mode_a==7 || //wpa-auto-psk
				$auth_mode_g==9 || //802.1x
				$auth_mode_a==9
                )
            {   // if not wpa-eap -> disable vlan.
                //echo "\necho set($sys./vlan_state, 0  ...\n > /dev/console\n";  
                set($sys."/vlan_state", 0);  // 
                set($sys."/vlan_mode", 0);  // 
            } 
        } 
	    $vlan_state = query($sys."/vlan_state"); 
	    // end of // check vlan status	    
	     
	    if($vlan_state == 1 && $vlan_mode==0)  	// static vlan mode                                            
	    {	        
            echo "\necho kill vlan  ...\n > /dev/console\n"; 
            // disable 
            echo "brctl setvlanstate br0 0 \n";  
              
            // set default value
	        echo "brctl setpvidif br0 eth0   1 \n";
	        echo "brctl setsysvid br0 1\n";
            
            //    del all group vid
            echo "brctl delallgroupvidif br0 eth0  \n";  
            echo "brctl delallgroupvidif br0 sys   \n";     
            
	        echo "sleep 3\n";
	    }  // end of if($vlan_state == 1)
	    else if($vlan_state == 1 && $vlan_mode==1) // NAP vlan mode
	    {	        
	        echo "brctl setvlanstate br0 0\n";	  
	    } 
	    
	}  // end of if ($ap_operate_mode_g != 1 && $ $ap_operate_mode_a != 1)
	
}  // end of else ($generate_start!=1)
?>
