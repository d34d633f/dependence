<?
$wlanif_a = query("/runtime/layout/wlanif_a");//ath16
$IWPRIV="iwpriv ".$wlanif_a;
$WLAN = "/wlan/inf:2/";
$countrycode= query("/runtime/nvram/countrycode");
if ($generate_start==1)
{
	if ($wlan_ap_operate_mode_a!=0)  /*close aparray if APC&WDS&WDS+AP mode*/
	{
		echo "echo not pure AP mode or WDS/AP, so disable AP ARRAY ... > /dev/console\n";
	  	echo "rgdb -s /wlan/inf:1/aparray_enable 0  \n";	  	 
		echo "killall neapc> /dev/console\n";  		
		echo "rgdb -i -d /runtime/wlan/inf:1/ap_array_members/list \n";
		echo "rgdb -i -d /runtime/wlan/inf:1/slaver_record \n";
		echo "rgdb -i -d /runtime/wlan/inf:1/arrayslaver/list \n";
		echo "rgdb -i -d /runtime/wlan/inf:1/arraymaster/list \n";
		echo "rgdb -i -d /runtime/wlan/inf:1/scan_table \n";
	}  
	/*for JP //OUTDOOR_APPS_JP +++ */
	$is_outdoor = query("/wlan/application");
	if ($wlan_ap_operate_mode_a==3 || $wlan_ap_operate_mode_a==4) // WDS or WDS+AP mode
	{
		if ($countrycode==392 && $is_outdoor==1 )
		{
			set($WLAN."/ap_mode", 0);
			echo "echo Because japan outdoor has no WDS DFS channel, so WDS change to Pure AP mode! > /dev/console\n";
			$wlan_ap_operate_mode_a = query($WLAN."/ap_mode");
		}
	}		
		//echo "echo wlan_ap_operate_mode is ".$wlan_ap_operate_mode." ... > /dev/console\n";
	/*for JP //OUTDOOR_APPS_JP --- */
	if ($wlan_ap_operate_mode_a==1)
	{
                $clonetype = query("/wlan/inf:1/macclone/type");
                if ($clonetype==1){/*auto*/
                        echo "brctl setcloneaddr br0 00:00:00:00:00:00\n";
                        echo "brctl clonetype br0 1\n";
                        echo "brctl apc_a br0 1"."\n";
                        echo "cloned\n";
                }else{/*Disable and Manual*/
		require($template_root."/__wlan_apcmode_a.php");
		//	exit;
		}
	}
	else if ($wlan_ap_operate_mode_a==3 || $wlan_ap_operate_mode_a==4)
	{
		require($template_root."/__wlan_wdsmode_a.php");
	//	exit;
	}
	else{
	/* common cmd */
//	$IWPRIV="iwpriv ".$wlanif_a;
	$EmRadiusState  =   query("/wlan/inf:2/wpa/embradius/state");
	$MultiEmRadiusState_index1  =   query("/wlan/inf:2/multi/index:1/embradius_state");
	$MultiEmRadiusState_index2  =   query("/wlan/inf:2/multi/index:2/embradius_state");
	$MultiEmRadiusState_index3  =   query("/wlan/inf:2/multi/index:3/embradius_state");
	$MultiEmRadiusState_index4  =   query("/wlan/inf:2/multi/index:4/embradius_state");
	$MultiEmRadiusState_index5  =   query("/wlan/inf:2/multi/index:5/embradius_state");
	$MultiEmRadiusState_index6  =   query("/wlan/inf:2/multi/index:6/embradius_state");
	$MultiEmRadiusState_index7  =   query("/wlan/inf:2/multi/index:7/embradius_state");

	$EmRadiusCertState  =   query("/wlan/inf:2/wpa/embradius/certstate");
	$EmRadiusEAPUser_conf   =   "/var/hostapd_a.eap_user";
	$EmRadiusDefaultCA  = "/etc/templates/certs/cacert.pem";
	$EmRadiusDefaultCAKey   =   "/etc/templates/certs/cakey.key";
	$EmRadiusDefaultCAPass  =   "DEFAULT";
	//Internal Radius EAP user, the same for 2.4G and 5G
	$EmRadiusEapUser    =   "/wlan/inf:1/wpa/embradius/eap_user/index";
	$EmRadiusE_SrvCert  =   "/var/etc/certs/hostapd/eca_srvcert.pem";
	$EmRadiusE_SrvKey   =   "/var/etc/certs/hostapd/eca_srvkey.key";
	$EmRadiusE_Srv_KeyPass  =   query("/wlan/inf:2/wpa/embradius/eca_keypasswd");
	// Disable IPv6 on wireless interface
	echo "echo \"1\" > /proc/sys/net/ipv6/conf/wifi1/disable_ipv6;\n";

	anchor("/wlan/inf:2");
	$channel = query("channel");         if (query("autochannel")==1) { $channel=0; }
	$bintval = query("beaconinterval");
	$cwmmode = query("cwmmode");
	$shortgi = query("shortgi");
	$a_mode = query("wlmode");
	$ssidhidden = query("ssidhidden");
	$dtim       = query("dtim");
	$aniena		= query("aniena");
	$wmmenable  = query("wmm/enable");
	$ampdu = query("ampdu");
	$ampdulimit = query("ampdulimit");
	$ampduframes = query("ampduframes");
	$autochannel = query("autochannel");
	$epartition = query("e_partition");
	$assoclimitenable   = query("assoc_limit/enable");
	$assoclimitnumber   = query("assoc_limit/number");
	$wpartition = query("w_partition");
	$acktimeout = query("acktimeout_a");
	$fixedrate  = query("fixedrate");
	$mcastrate  = query("mcastrate");/*add for mcast rate by yuda*/
	$wlan_utilization  = query("wlan_bytes_lim");
	$wlan_time = query("wlan_bytes_time");
	$ratectl = query("ratectl");
	$manrate = query("manrate");
	$manretries = query("manretries");
	$uapsd = query("uapsd");
	$multi_pri_state = query("multi/pri_by_ssid");
	$pri_bit = query("pri_bit");
	$zonedefence = query("zonedefence");
	$coexistence = query("coexistence/enable");
	$INACT 	= query("inact");
	echo "ifconfig wifi1 hw ether ".$wlanmac_a."\n";//joe
	echo "wlanconfig ".$wlanif_a." create wlandev wifi1 wlanmode ap\n";//joe
	echo "echo Start WLAN interface ".$wlanif_a." ... > /dev/console\n";
//	echo "ifconfig ".$wlanif_a." hw ether ".$wlanmac_a."\n";//the address get by 'ifconfig' and 'iwconfig' should keep the same

	// Disable IPv6 on wireless interface
	echo "echo \"1\" > /proc/sys/net/ipv6/conf/".$wlanif_a."/disable_ipv6;\n";
	

	echo "iwpriv wifi1 HALDbg 0x0\n";
	echo $IWPRIV." dbgLVL 0x100\n";
	echo "iwpriv wifi1 ATHDebug 0x0\n";
	
	// common RF settings start
	echo "ifconfig ".$wlanif_a." txqueuelen 1000\n";
	echo "ifconfig wifi1 txqueuelen 1000\n";
	
	if($EmRadiusState == 1||$MultiEmRadiusState_index1==1||$MultiEmRadiusState_index2==1||
	$MultiEmRadiusState_index3==1||$MultiEmRadiusState_index4==1||$MultiEmRadiusState_index5==1||
	$MultiEmRadiusState_index6==1||$MultiEmRadiusState_index7==1)
	{
		fwrite($EmRadiusEAPUser_conf, "# Phase 1 users\n");
		fwrite2($EmRadiusEAPUser_conf, "*\tPEAP,TTLS\n");
		fwrite2($EmRadiusEAPUser_conf, "# Phase 2 (tunnelled within EAP-PEAP/EAP-TTLS) users\n");
		for($EmRadiusEapUser)
		{
			$EmRadiusEapUserName = query($EmRadiusEapUser.":".$@."/name");
			$EmRadiusEapUserEnable = query($EmRadiusEapUser.":".$@."/enable");
        		if($EmRadiusEapUserName != "" && $EmRadiusEapUserEnable == 1)
			{
				$EmRadiusEapUserPasswd = query($EmRadiusEapUser.":".$@."/passwd");
				fwrite2($EmRadiusEAPUser_conf, "\"".$EmRadiusEapUserName."\"\tMSCHAPV2\t\"".$EmRadiusEapUserPasswd."\"\t[2]\n");
			}
		}

	}
	//if($rxmit_first != "")	{ echo "iwpriv wifi1 rxmit_first ".$rxmit_first."\n"; }
	//if($rxmit_last != "")	{ echo "iwpriv wifi1 rxmit_last ".$rxmit_last."\n"; }
	//if($txmit_first != "")	{ echo "iwpriv wifi1 txmit_first ".$txmit_first."\n"; }
	//if($txmit_last != "")	{ echo "iwpriv wifi1 txmit_last ".$txmit_last."\n"; }
	
	if($autochannel==0){
		if($channel<36){
			$channel=36;
		}
	}

//	echo $IWPRIV." chextoffset 1\n";// default to no extension channel present
//	echo $IWPRIV." chwidth 1\n";// default to 20MHz channel width

	// 1:na, 2:a, 3:n
	//$wepmode = query("/wlan/inf:2/wpa/wepmode");
	//if($wepmode==1 || $wepmode==2){//1:WEP, 2:TKIP
	//	echo $IWPRIV." mode 11A\n";
	//}else{
		//(20) 1-->NA mix 3--> only n  2--> only a
		if ($cwmmode == 0){
			if($a_mode == 1) {echo $IWPRIV." mode 11NAHT20\n";}
			else if($a_mode == 3) {echo $IWPRIV." mode 11NAHT20\n";}
			else if($a_mode == 2) {echo $IWPRIV." mode 11A\n";}
			else {echo $IWPRIV." mode 11NAHT20\n";}
		}
		//1-->NA mix 3--> only n	
		else{//cwmmode=1 HT20/40 mode
			if($autochannel==1){//autochannel enable
				echo $IWPRIV." mode 11NAHT40\n";
//				echo $IWPRIV." chextoffset 0\n";// use ic->extoffset to decide extension channel
//				echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
			}
			else{ //autochannel disable
				if($channel==36||$channel==44||$channel==52||$channel==60||$channel==100||$channel==108||$channel==116||$channel==124||$channel==132||$channel==149||$channel==157){
					echo $IWPRIV." mode 11NAHT40PLUS\n";				
//					echo $IWPRIV." chextoffset 2\n";// override with extension channel above control channel	
//					echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
				}
				else if($channel==40||$channel==48||$channel==56||$channel==64||$channel==104||$channel==112||$channel==120||$channel==128||$channel==136||$channel==153||$channel==161){
					echo $IWPRIV." mode 11NAHT40MINUS\n";				
//					echo $IWPRIV." chextoffset 3\n";// override with extension channel above control channel	
//					echo $IWPRIV." chwidth 2\n";// override with 40MHz channel width
				}
				else{
					echo $IWPRIV." mode 11NAHT20\n";
				}
			}
		}
	//}

//	if ($aniena!="")    {echo "iwpriv wifi1 ANIEna ".$aniena."\n";  }
//	else {echo " iwpriv wifi1 ANIEna 0 \n";}
	echo "iwpriv wifi1 ANIEna 1 \n";

	echo "iwpriv wifi1 burst 1\n"; // for intel6300 downlink/bidi throughput issue
	//1--->NA mix 3--> only n
	if($a_mode == 1){
		echo $IWPRIV." pureg 0\n";
		echo $IWPRIV." puren 0\n";
	}
	else if($a_mode == 3){
		echo $IWPRIV." puren 1\n";
	}		
	else{
		echo $IWPRIV." pureg 0\n";
		echo $IWPRIV." puren 0\n";
	}
	if($ampdu!="") {echo "iwpriv wifi1 AMPDU ".$ampdu."\n";}
	else {echo "iwpriv wifi1 AMPDU 1 \n";}	
	if($ampduframes!="") {echo "iwpriv wifi1 AMPDUFrames ".$ampduframes."\n";}
	else {echo "iwpriv wifi1 AMPDUFrames 32 \n";}
	if($ampdulimit!="")	{echo "iwpriv wifi1 AMPDULim ".$ampdulimit."\n";}
	else {echo "iwpriv wifi1 AMPDULim 50000 \n";}

//	echo "iwconfig ".$wlanif_a." essid \"".get("s","/wlan/inf:2/ssid")."\" mode master freq ".$channel."\n";//joe
//	echo "iwconfig ".$wlanif_a." essid \"".get("s","/wlan/inf:2/ssid")."\" freq ".$channel."\n";

        // erial add for driver 9.0, temp solution for auto channel scan.       erial_acs_2010
	if($channel == 0) 
	{
		echo "iwconfig ".$wlanif_a." essid \"".get("s","/wlan/inf:2/ssid")."\" \n";
		echo $IWPRIV." acs 1\n";
	}
	else {echo "iwconfig ".$wlanif_a." essid \"".get("s","/wlan/inf:2/ssid")."\" freq ".$channel."\n";}
	echo "iwconfig ".$wlanif_a." mode master\n";

	// if rate control is not auto, set the manual settings
	if($ratectl>1)
	{
		echo $IWPRIV." set11NRates ".$manrate."\n";// seems default 0x8c8c8c8c will cause can not ping through, joe
		echo $IWPRIV." set11NRetries ".$manretries."\n";
	}
	echo "iwpriv wifi1 txchainmask 3\n";//joe,2T
	echo "iwpriv wifi1 rxchainmask 3\n";//joe,2R
	
	echo "iwpriv wifi1 noisespuropt 1\n";

	// common RF settings end
	
	if ($ssidhidden!="")    { echo $IWPRIV." hide_ssid ".$ssidhidden."\n"; }
	//if ($uapsd!="")	{ echo $IWPRIV." uapsd ".$uapsd."\n"; }	/*not_yet*/

	if ($dtim!="")          { echo $IWPRIV." dtim_period ".$dtim."\n"; }
	
	/* e_partition 2008-02-1 start */
	if ($epartition!="")  { echo "brctl e_partition_a br0 ".$epartition."\n";}
	else            { echo "brctl e_partition_a br0 0\n"; }
	/* e_partition 2008-02-1 end */
	/* w_partition 2008-03-22 start */
	if ($wpartition==2)  /* guest mode*/
        {
            echo $IWPRIV." ap_bridge 0 \n";
        echo "brctl w_partition br0 ".$wlanif_a." 1 \n";
        }
        else if ($wpartition==1)
        {
            echo $IWPRIV." ap_bridge 0 \n";
            echo "brctl w_partition br0 ".$wlanif_a." 0\n";
        }
        else
        {
            echo $IWPRIV." ap_bridge 1\n";
            echo "brctl w_partition br0 ".$wlanif_a." 0\n";
        }
	/* w_partition 2008-03-22 end */
	
//	echo "brctl apc_a br0 0"."\n";
	if ($wmmenable>0)       { echo $IWPRIV." wmm 1\n"; }
	else                    { echo $IWPRIV." wmm 0\n"; }

	if($fixedrate<0)	{echo "iwpriv wifi1 fixedrate 0\n";}
	else if($fixedrate<12)	{echo "iwpriv wifi1 fixedrate ".$fixedrate."\n";}
	else	{echo "iwpriv wifi1 fixedrate 31\n";}
	
	if($acktimeout != "")	{ echo "iwpriv wifi1 acktimeout ".$acktimeout."\n"; }//default to 25
	else { echo "iwpriv wifi1 acktimeout 25\n"; }

	require($template_root."/__wlan_acl_a.php");

	if($multi_pri_state==1)	
	{ 
		echo  $IWPRIV." pristate 1\n";
		echo  $IWPRIV." pribit ".$pri_bit."\n";
	}
	else	{echo  $IWPRIV." pristate 0\n";}


        /*add for mcast rate by yuda start */
        if($mcastrate!=0){
    	if($mcastrate==1){
    		echo $IWPRIV." mcast_rate 6000\n";
    	}
    	else if($mcastrate==2){
    		echo $IWPRIV." mcast_rate 9000\n";
    	}
    	else if($mcastrate==3){
    		echo $IWPRIV." mcast_rate 12000\n";
    	}
    	else if($mcastrate==4){
    		echo $IWPRIV." mcast_rate 18000\n";
    	}
    	else if($mcastrate==5){
    		echo $IWPRIV." mcast_rate 24000\n";
    	}
    	else if($mcastrate==6){
    		echo $IWPRIV." mcast_rate 36000\n";
    	}
    	else if($mcastrate==7){
    		echo $IWPRIV." mcast_rate 48000\n";
    	}
    	else if($mcastrate==8){
    		echo $IWPRIV." mcast_rate 54000\n";
    	}
    	else if($mcastrate==9){
    		echo $IWPRIV." mcast_rate 6500\n";
    	}
    	else if($mcastrate==10){
    		echo $IWPRIV." mcast_rate 13000\n";
    	}
    	else if($mcastrate==11){
    		echo $IWPRIV." mcast_rate 19500\n";
    	}
    	else if($mcastrate==12){
    		echo $IWPRIV." mcast_rate 26000\n";
    	}
    	else if($mcastrate==13){
    		echo $IWPRIV." mcast_rate 39000\n";
    	}
    	else if($mcastrate==14){
    		echo $IWPRIV." mcast_rate 52000\n";
    	}
    	else if($mcastrate==15){
    		echo $IWPRIV." mcast_rate 58500\n";
    	}
    	else if($mcastrate==16){
    		echo $IWPRIV." mcast_rate 65000\n";
    	}
    	else if($mcastrate==17){
    		echo $IWPRIV." mcast_rate 78000\n";
    	}
    	else if($mcastrate==18){
    		echo $IWPRIV." mcast_rate 104000\n";
    	}
    	else if($mcastrate==19){
    		echo $IWPRIV." mcast_rate 117000\n";
    	}
    	else if($mcastrate==20){
    		echo $IWPRIV." mcast_rate 130000\n";
    	}
    	else {
    		echo $IWPRIV." mcast_rate 6000\n";
    	}        
    	}
    	/*add for mcast rate by yuda end */

	/*Please put the settings which will affect all VAPs here, and no need to do it in multi-ssid, vice versa*/
	/*Common setting for all VAPs of ATH DEV start*/
	/* erial move to __wlan_device_a_up.php, for dual band ap scan.
	echo $IWPRIV." apband 1\n"; //show ap band in wireless driver*/
	if($shortgi != "")	{ echo $IWPRIV." shortgi ".$shortgi."\n"; }
        //echo $IWPRIV." staextoffset 0\n";

	if ($cwmmode == 1){
		if($autochannel==0){
			if($channel==36||$channel==44||$channel==52||$channel==60||$channel==100||$channel==108||$channel==116||$channel==124||$channel==132||$channel==149||$channel==157){
				//echo $IWPRIV." extoffset 1\n";	not_yet
			}
			else if($channel==40||$channel==48||$channel==56||$channel==64||$channel==104||$channel==112||$channel==120||$channel==128||$channel==136||$channel==153||$channel==161){
				//echo $IWPRIV." extoffset -1\n";	not_yet
			}
			else if($channel==140||$channel==165){ // channel 140, 165 does not support 40MHz channel width
				$cwmmode = 0;
				set("/wlan/inf:2/cwmmode",$cwmmode);
			}
		}
	}
	if($assoclimitenable == 1){
	if($a_mode == 1 || $a_mode == 3){
        	if($cwmmode==0){//default 60M*60s
         		if($wlan_utilization==1)    {echo "iwpriv ".$wlanif_a." wlan_utiliz 0\n";}
			else if ($wlan_utilization==2) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 377487360\n";}
			else if ($wlan_utilization==3) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 283115520\n";}
			else if ($wlan_utilization==4) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 188743680\n";}
			else if ($wlan_utilization==5) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 94371840\n";}
         		else if ($wlan_utilization==6) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 0\n";}
        		else  {echo "iwpriv ".$wlanif_a." wlan_utiliz 0\n";}
        	}
		else{//cwmmode=1 //default 90M*60s
        		if($wlan_utilization==1)    {echo "iwpriv ".$wlanif_a." wlan_utiliz 0\n";}
			else if ($wlan_utilization==2) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 566231040\n";}
			else if ($wlan_utilization==3) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 424673280\n";}
			else if ($wlan_utilization==4) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 283115520\n";}
			else if ($wlan_utilization==5) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 141557760\n";}
        		else if ($wlan_utilization==6) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 0\n";}
         		else  {echo "iwpriv ".$wlanif_a." wlan_utiliz 0\n";}
        	}
        }
        else{   // a mode only in HT20 mode default 20M*60s
		if($wlan_utilization==1)    {echo "iwpriv ".$wlanif_a." wlan_utiliz 0\n";}
		else if ($wlan_utilization==2) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 125829120\n";}
		else if ($wlan_utilization==3) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 94371840\n";}
		else if ($wlan_utilization==4) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 62914560\n";}
		else if ($wlan_utilization==5) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 31457280\n";}
		else if ($wlan_utilization==6) {echo "iwpriv ".$wlanif_a." wlan_utiliz 1; iwpriv ".$wlanif_a." bytes_time 60; iwpriv ".$wlanif_a." bytes_limit 0\n";}
		else  {echo "iwpriv ".$wlanif_a." wlan_utiliz 0\n";}
	}
	}
	else {echo "iwpriv ".$wlanif_a." wlan_utiliz 0\n";}
	//echo $IWPRIV." cwmmode ".$cwmmode."\n"; 	not_yet
	//echo $IWPRIV." countryie 1\n"; // enable country IE in beacon and probe response	not_yet
	echo $IWPRIV." doth 1\n";// dfs for 5G
	echo $IWPRIV." extprotspac 0\n";

	$preferred5g = query("/sys/wlan/preferred5g");  
        if($preferred5g == 1) { echo $IWPRIV." preferred5g 1\n"; }
        else { echo $IWPRIV." preferred5g 0\n"; }

	if($bintval!="") {echo $IWPRIV." bintval ".$bintval."\n";}
	else {echo $IWPRIV." bintval 100\n"; }

	if($assoclimitenable == 1)	{echo $IWPRIV." assocenable 1\n";}
	else {echo $IWPRIV." assocenable 0\n";}
	if($assoclimitnumber != "") {echo $IWPRIV." assocnumber ".$assoclimitnumber."\n";}

	if ($zonedefence==1)
	{
                echo $IWPRIV." zonedefence 1\n";
                require($template_root."/zonedefence_a.php");
  }
  else
  {
                echo $IWPRIV." zonedefence 0\n";
  }
  if($coexistence == 1)
	{
			echo $IWPRIV." disablecoext 0\n";
	}
	else
	{
			echo $IWPRIV." disablecoext 1\n";
	}
	echo $IWPRIV." inact_auth ".$INACT."\n";
	/*Common setting for all VAPs of ATH DEV end*/

	$auth_mode = query("/wlan/inf:2/authentication");
	if ($auth_mode>1){  
	}
	else { 
		require($template_root."/__auth_openshared_a.php");
	}

	require($template_root."/multi_ssid_run_a.php");

	}
}//if end
else
{
	$wlanif_a = query("/runtime/layout/wlanif_a");
	$igmpsnoop = query("/wlan/inf:2/igmpsnoop");
	$multi_total_state = query($WLAN_a."/multi/state");
	if ($multi_total_state == 1)
	{
		if ($wlan_ap_operate_mode_a==1 || $wlan_ap_operate_mode_a==2 || $wlan_ap_operate_mode_a==4) /*    WDS_OVER_MULTI_SSID_080422 */
		{   // 1:apc, 2:apr, 4:WDS without AP 
			echo "echo multi-ssid must be normal AP mode! > /dev/console\n";
			set($WLAN_a."/ap_mode", 0);
		}
	}
	if ($wlan_ap_operate_mode_a==3 || $wlan_ap_operate_mode_a==4)
	{
		require($template_root."/__wlan_wdsmode_a.php");
	//	exit;
	}
	else{
	if (query("/wlan/inf:2/enable")!=1)
	{
		echo "echo WLAN is disabled ! > /dev/console\n";
		exit;
	}

	echo "brctl e_partition_a br0 0\n";

	$wlxmlpatch_a_pid = "/var/run/wlxmlpatch_a.pid";
	echo "if [ -f ".$wlxmlpatch_a_pid." ]; then\n";
	echo "kill \`cat ".$wlxmlpatch_a_pid."\` > /dev/null 2>&1\n";
	echo "rm -f ".$wlxmlpatch_a_pid."\n";
	echo "fi\n\n";
	 	
	/* IGMP Snooping dennis 2008-01-29 start */
	if ($igmpsnoop == 1){
		$ap_igmp_pid = "/var/run/ap_igmp_a.pid";
		echo "echo disable > /proc/net/br_igmp_ap_br0\n";
		echo "echo unsetwl ".$wlanif_a." > /proc/net/br_igmp_ap_br0\n";//joe
		echo "brctl igmp_snooping br0 0\n";
		echo "if [ -f ".$ap_igmp_pid." ]; then\n";
		echo "kill \`cat ".$ap_igmp_pid."\` > /dev/null 2>&1\n";
		echo "rm -f ".$ap_igmp_pid."\n";
		echo "fi\n\n";
	}
	/* IGMP Snooping dennis 2008-01-29 end */

	echo "ifconfig ".$wlanif_a." down"."\n";//joe
	echo "sleep 2\n";
	echo "brctl delif br0 ".$wlanif_a."\n";//joe
 
	echo "sleep 1\n";
	echo "brctl apc_a br0 0"."\n";
	echo "iwconfig ".$wlanif_a." key off\n";
	//echo "wlanconfig ".$wlanif_a." destroy\n";	move to wlan_run, destroy vap at last 
	}
}
?>
