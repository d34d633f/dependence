<?
$tool_admin = "Administration Settings";
$tool_fw = "Firmware and SSL Certification Upload";
$tool_config = "Configuration File";
$tool_sntp = "Time and Date";
$logout_msg = "&nbsp;&nbsp;The current browser connection will<br>&nbsp;&nbsp;be disconnected if you click <b>here</b>.";
?>