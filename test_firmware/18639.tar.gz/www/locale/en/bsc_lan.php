<?
$m_context_title = "LAN Settings";

$m_lan_type  = "Get IP From";
$m_static_ip = "Static IP (Manual)";
$m_dhcp      = "Dynamic IP (DHCP)";

$m_ipaddr    = "IP Address";
$m_subnet    = "Subnet Mask";
$m_gateway   = "Default Gateway";
$m_dns		 = "DNS";

$a_invalid_ip= "Invalid IP address !";
$a_invalid_netmask= "Invalid subnet mask !";
$a_invalid_gateway= "Invalid gateway address !";
$a_invalid_dns= "Invalid DNS !";
$a_connect_new_ip = "Please connect with new IP Address !";
$a_ip_mask_not_match = "The IP address and Mask address are not match!";
?>
