<?
$m_context_title = "目前IP清單";
$m_host_name = "主機名稱";
$m_mac = "配聯網路實際位址";
$m_ip = "被分配的IP位址";
$m_time = "租用時間";
$m_dynamic_pools = "目前的動態主機設定通訊協定動態集區";
$m_static_pools = "目前的動態主機設定通訊協定靜態集區";
$m_days			="天/星期";
$m_hrs			="小時";
$m_mins			="分鐘";
$m_secs			="秒";
$m_timeout		="TimeOut";
?>
