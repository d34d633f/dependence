作業正在處理中...<br><br>
請<font color=red><b>勿關閉</b></font>裝置電源.<br><br>
請靜待
<input type='text' readonly name='WaitInfo' value='150' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
秒...
