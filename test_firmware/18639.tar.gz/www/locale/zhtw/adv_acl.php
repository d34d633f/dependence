<?
$m_context_title = "無線網路實際位址存取控制列表設定";
$m_acl_type = "存取控管清單";
$m_disable = "取消";
$m_accept = "接受";
$m_reject = "拒絕";
$m_wmac = "網路實際位址";
$m_id = "識別碼";
$m_del = "刪除";
$m_wband = "無線頻帶";
$m_band_5G = "5GHz";
$m_band_2.4G = "2.4GHz";
$m_ssid = "服務設定識別碼";
$m_mac = "網路實際位址";
$m_band = "頻帶";
$m_auth = "認證";
$m_signal = "信號";
$m_power = "省電模式";
$m_multi_ssid = "多重服務設定識別碼";
$m_select_ssid = "Select SSID";
$m_primary_ssid = "主要服務設定識別碼";
$m_ms_ssid1 = "SSID 1";
$m_ms_ssid2 = "SSID 2";
$m_ms_ssid3 = "SSID 3";
$m_ms_ssid4 = "SSID 4";
$m_ms_ssid5 = "SSID 5";
$m_ms_ssid6 = "SSID 6";
$m_ms_ssid7 = "SSID 7";
$m_clirnt_info = "目前的客戶機資訊";
$m_b_add = " 新增 ";

$a_acl_del_confirm		= "確定刪除這個網路實際位址？";
$a_same_acl_mac	= "已有相同的網路實際位址存在。\\n 請更換網路實際位址。";
$a_invalid_mac		= "網路實際位址無效！";
$a_max_acl_mac		= "存取控管清單的數目上限為256！";
$a_max_acl_mac_ipv6      = "Maximum number of Access Control List is 64!";
$a_zone_defence_disable = "Zone defence would be disable.";
$m_upload_acl_titles = "Upload ACL File";
$m_upload_acl_file = "Upload File";
$m_acl_upload = "Upload";
$a_format_error_file ="File extension error! It must be \\\".acl\\\" . Please try again!";
$a_blank_acl_file = "Empty file is not accepted!";
$m_download_acl_title = "Download ACL File";
$m_save_acl = "Load ACL File to Local Hard Driver";
$m_save = "Download";

?>
