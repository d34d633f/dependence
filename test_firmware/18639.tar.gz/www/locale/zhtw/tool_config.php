<?
$m_context_title = "設定組態檔案上傳與下載";
$m_save_cfg = "下載設定至局端的硬碟";
$m_save = "下載";
$m_load_cfg = "上傳檔案";
$m_b_load = "上傳檔案";
$m_upload_config_title = "上傳設定組態檔案";
$m_download_config_title = "下載設定組態檔案";

$a_empty_cfg_file_path	="請選擇您所要上傳的儲存設定組態檔案。";
$a_error_cfg_file_path	="檔案格式錯誤! 請再試一次!";
$a_sure_to_reload_cfg	="確認從檔案下載設定?";
?>
