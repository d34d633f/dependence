<?
$m_html_title="SESSION額滿";
$m_context_title="Session額滿";
$m_context="登入的Session已滿。請稍後登入";
$m_button_dsc="重新登入";
?>
