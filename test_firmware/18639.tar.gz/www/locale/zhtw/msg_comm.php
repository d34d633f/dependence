<?
$m_user_name		="使用者名稱";
$m_password		="密碼";
$m_continue		="繼續";
$m_nochg_title		="沒有改變";
$m_nochg_dsc		="設定並沒有改變。";
$m_saving_title		="儲存";
$m_saving_dsc		="設定正在進行儲存並且需要花費一點時間。";
$m_saving_dsc_wait = "請稍後...";
$m_saving_dsc_change_ip = "請等待10秒鐘並且重新使用新的IP位址登入設備。";
$m_scan_title		="掃描";
$m_detect_title	="偵測";
$m_scan_dsc		="掃描中... <br><br> 請稍後....";
$m_clear = "清除";

$TITLE=query("/sys/hostname");
$first_frame = "home_sys";
$m_logo_title	=query("/sys/hostname");
?>
