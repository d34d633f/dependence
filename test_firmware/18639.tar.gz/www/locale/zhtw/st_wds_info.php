<?
$m_context_title = "無線橋接訊息";
$m_client_info = "無線橋接訊息";
$m_st_association  = "基地台運作於11";
$m_ssid = "SSID";
$m_mac = "MAC";
$m_band = "Band";
$m_auth = "認證";
$m_signal = "訊號";
$m_power = "省電模式";
$m_wpa		= "WPA-";
$m_wpa2		= "WPA2-";
$m_wpa_auto		= "WPA2-Auto-";
$m_eap		= "Enterprise";
$m_psk		= "Personal";
$m_open		="Open System";
$m_shared	="Shared Key";
$m_disabled		="停用";
$m_channel = "頻道";
$m_name = "名稱";
$m_status = "狀態";
$wds = "W";
$m_on = "開啟";
$m_off = "關閉";
$m_none = "None";
?>
