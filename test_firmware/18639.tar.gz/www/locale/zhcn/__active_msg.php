设备正在运行...<br><br>
请<font color=red><b>不要关闭</b></font>设备.<br><br>
请等待
<input type='Text' readonly name='WaitInfo' size='3' style='border-width:0; background-color=#DFDFDF; color:#FF3030; text-align:center'>
秒钟后
<? if($change_ip=="1") 
	{
		echo "<br><br>用新IP地址登录。"; 	
	}?>...
