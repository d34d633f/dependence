<?
$m_html_title="Abmelden";
$m_context_title="Abmelden";
$m_context="Sie sind nun abgemeldet.";
$m_button_dsc="Zurück zur Anmeldeseite";
?>
