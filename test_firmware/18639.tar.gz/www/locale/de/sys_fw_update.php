<?
$m_menu_upgrade_fw = "<font face=\"Arial\" color=\"red\" size=2>".
					 "<b>Do Not Power Down </b></font>".
					 "<font face=\"Arial\" size=2>Gerät nicht während dieses Prozesses abschalten.".
					 " Das könnte sonst Ihren ".query("/sys/hostname").
					 " (Wenn Ihr Browser Sie nicht automatisch auf die Webseite zurü".
					 "ckführt, klicken Sie auf die Aktualisierungsschaltfläche.)</font>";
					 
$m_upload_fw = "Firmware wird hochgeladen...";
$m_verify_fw = "Firmware wird verifiziert...";
$m_upgrad_device = "Upgrade des Gerätes wird durchgeführt...";
$m_reboot_device = "Gerät wird neu gestartet...";

$a_upgrade_fw_fail_msg = "Firmware-Upgrade ist fehlgeschlagen. Laden Sie die Firmware erneut und versuchen Sie es noch einmal.";

?>
