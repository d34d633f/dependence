<?
$msg_title="Ethernet-Datenverkehrstatistik";
$msg_t_title="Gesendet";
$msg_r_title="Empfangen";
$msg_T_Packet="Gesendete Pakete";
$msg_T_Bytes="Gesendete Bytes";
$msg_T_Dropped_Packet="Verlorene Pakete";
$msg_R_Packet="Empfangene Pakete";
$msg_R_Bytes="Empfangene Bytes";
$msg_R_Dropped_Packet="Verlorene Pakete";
$msg_R_Multicast_Packet="Empfangene Multicast-Pakete";
$msg_R_Broadcast_Packet="Empfangene Broadcast-Pakete";
$msg_Len_64="Länge 64 Paketanzahl";
$msg_Len_65_127="Länge 65~127 Paketanzahl";
$msg_Len_128_255="Länge 128~255 Paketanzahl";
$msg_Len_256_511="Länge 256~511 Paketanzahl";
$msg_Len_512_1023="Länge 512~1023 Paketanzahl";
$msg_Len_1024_1518="Länge 1024~1518 Paketanzahl";
$msg_Len_1519_MAX="Länge 1519~MAX Paketanzahl";
$msg_clear="Entfernen";
$msg_refresh="Aktualisieren";
?>
