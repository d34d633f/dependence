var subnet_mask_value = new Array(0, 128, 192, 224, 240, 248, 252, 254, 255);
var key_num_array = new Array("64", "128");
var name_word = new Array('#', '*', '/', ',', ';', '"', "'");
var name_word_psk = new Array('/', ',', ';', '"', "'", ' ');
var encoding_char = new Array('$', '&', '+', ',', '/', ':', ';', '=', '?', '@', ' ', '"', '<', '>', '#', '%', '{', '}', '|', '\\', '^', '~', '[', ']', '`');
var time_out_counter = 200;
var time_out_id;

/* ----- langusge for trendnet ----- */
var lang_obj;

function load_lang_obj(){
	var which_lang = "<% getIndex("multiLang");%>";
	lang_obj = new Lang_Obj(which_lang);
}

function get_default_lang(which_id){	
	var this_lang = load_xml("/xml/lang_en.xml");
	
	return get_node_value(this_lang, which_id);
}

function Lang_Obj(which_lang){
	this.my_lang = load_xml("/xml/lang_" + which_lang + ".xml");			
}

Lang_Obj.prototype = {

get_word:function(which_id){
	var which_word = get_node_value(this.my_lang, which_id);
	if (which_word == ""){
		which_word = get_default_lang(which_id);
	}
	
	return which_word;
},

write:function(which_id){
	var which_word = this.get_word(which_id);

	for (var i = 1; i < this.write.arguments.length; i++){
		which_word = which_word.replace("%s", arguments[i]);
	}
	
	if ( which_word == "") // if get no which_id, print which_id by default.
	{
		with(document){				
			write(which_id);
		}	
	}
	
	with(document){				
			write(which_word);
	}	
},	

display:function(which_id){
	var which_word = this.get_word(which_id);
	
	for (var i = 1; i < this.display.arguments.length; i++){
		which_word = which_word.replace("%s", arguments[i]);
	}
	
	return which_word;
}
}

//need new object first...
load_lang_obj();

/* ----- langusge for trendnet ----- */

//in /public.js
//var subnet_mask_msg = new Array(lang_obj.display("msg_109"),
//						           lang_obj.display("msg_114"),
//						           lang_obj.display("msg_115"),
//							    	   lang_obj.display("msg_116"),
//							    	   lang_obj.display("msg_117"),
//							    	   lang_obj.display("msg_118"),
//							    	   lang_obj.display("msg_130"),
//							    	   lang_obj.display("msg_131"),
//							    	   lang_obj.display("msg_132"),
//							    	   lang_obj.display("msg_133")
//						          );
						          
var subnet_mask_msg = new Array(lang_obj.display("msg_129"),
					           lang_obj.display("msg_109"),
					           lang_obj.display("msg_110") + " " + lang_obj.display("msg_114"),
					           lang_obj.display("msg_111") + " " + lang_obj.display("msg_114"),
					           lang_obj.display("msg_112") + " " + lang_obj.display("msg_114"),
					           lang_obj.display("msg_113") + " " + lang_obj.display("msg_114"),
					           lang_obj.display("msg_115"),
					           lang_obj.display("msg_116"),
					           lang_obj.display("msg_117"),
					           lang_obj.display("msg_118")
					          );

var gateway_msg = new Array(lang_obj.display("msg_134"),
										lang_obj.display("msg_135"),
										lang_obj.display("msg_136"),
										lang_obj.display("msg_137"),
										lang_obj.display("msg_138"),
										lang_obj.display("msg_139"),
										lang_obj.display("msg_140"),
										lang_obj.display("msg_141"),
										lang_obj.display("msg_142"),
										lang_obj.display("msg_143"),
										lang_obj.display("msg_144")
						       );

var server_msg = new Array(lang_obj.display("msg_145"),
										lang_obj.display("msg_146"),
										lang_obj.display("msg_147"),
										lang_obj.display("msg_148"),
										lang_obj.display("msg_149"),
										lang_obj.display("msg_150"),
										lang_obj.display("msg_151"),
										lang_obj.display("msg_152"),
										lang_obj.display("msg_153"),
										lang_obj.display("msg_154"),
										lang_obj.display("msg_155")
						       );

var ip_addr_msg = new Array(lang_obj.display("msg_123"),
						       lang_obj.display("msg_124"),
						       lang_obj.display("msg_110"),
						       lang_obj.display("msg_111"),
						       lang_obj.display("msg_112"),
						       lang_obj.display("msg_113"),
						       lang_obj.display("msg_125"),
						       lang_obj.display("msg_126"),
						       lang_obj.display("msg_127"),
						       lang_obj.display("msg_128"),
						       lang_obj.display("msg_129")
						      );

var subnet_mask = new Array(0, 128, 192, 224, 240, 248, 252, 254, 255);
var INVALID_IP = 0;
var ZERO_IP = 1;
var FIRST_IP_ERROR = 2;
var SECOND_IP_ERROR = 3;
var THIRD_IP_ERROR = 4;
var FOURTH_IP_ERROR = 5;
var FIRST_RANGE_ERROR = 6;
var SECOND_RANGE_ERROR = 7;
var THIRD_RANGE_ERROR = 8;
var FOURTH_RANGE_ERROR = 9;
var FOURTH_RANGE_ERROR1 = 10;
var RADIUS_SERVER_PORT_ERROR = 11;
var RADIUS_SERVER_SECRET_ERROR = 12;

var days = new Array(	lang_obj.display("sun"), lang_obj.display("mon"), lang_obj.display("tue"), lang_obj.display("wed"), lang_obj.display("thu"), lang_obj.display("fri"), lang_obj.display("sat") );				     						          						      
var days_in_month = ['31', '28', '31', '30', '31', '30', '31', '31', '30', '31', '30', '31'];

var help_left = {
  "main" : {
  	item : {
	    0 : "device",
	    1 : "network",
	    2 : "password",
	    3 : "time",
	    4 : "ipv6"
	  },
	  item_str : {
	    0 : lang_obj.display('opmode'),
	    1 : lang_obj.display('network_setting'),
	    2 : lang_obj.display('device_information'),
	    3 : lang_obj.display('time_settings'),
	    4 : lang_obj.display('ipv6')
	  },
	  link_str : {
	    0 : "main_help.htm#mode",
	    1 : "main_help.htm#network",
	    2 : "main_help.htm#password",
	    3 : "main_help.htm#time",
	    4 : "main_help.htm#ipv6"
	  },
	  len : 5,
	  word : lang_obj.display('main'),
	  image : "images/but_setup_0.png"
  },
  "wireless" : {
  	item : {
	    0 : "wireless basic",
	    1 : "Advanced",
	    2 : "WPS"
	  },
	  item_str : {
	    0 : lang_obj.display('basic'),
	    1 : lang_obj.display('advanced'),
	    2 : lang_obj.display('wifi_wps')
	  },
	  link_str : {
	    0 : "wireless_help.htm#basic",
	    1 : "wireless_help.htm#advanced",
	    2 : "wireless_help.htm#wps"
	  },
	  len : 3,
	  word : lang_obj.display('wireless'),
	  image : "images/but_wireless_0.png"
  },
  "admin" : {
  	item : {
	    0 : "firmware",
	    1 : "settings",
	    2 : "ping",
	    3 : "schedule",
	    4 : "email",
	    5 : "syslog"
	  },
	  item_str : {
	    0 : lang_obj.display('upload_firmware'),
	    1 : lang_obj.display("settings_management"),
	    2 : lang_obj.display('ping_test'),
	    3 : lang_obj.display('schedule'),
	    4 : lang_obj.display('email_settings'),
	    5 : lang_obj.display('syslog')
	  },
	  link_str : {
	    0 : "tools_help.htm#firmware",
	    1 : "tools_help.htm#settings",
	    2 : "tools_help.htm#ping",
	    3 : "tools_help.htm#schedules",
	    4 : "tools_help.htm#email",
	    5 : "tools_help.htm#syslog"
	  },
	  len : 6,
	  word : lang_obj.display('tools'),
	  image : "images/but_administrator_0.png"
  },
  "access" : {
  	item : {
	    0 : "mac_filter",
	    1 : "multi_ssid",
	    2 : "user limit"
	  },
	  item_str : {
	    0 : lang_obj.display('mac_filters'),
	    1 : lang_obj.display('multi_ssid'),
	    2 : lang_obj.display('user_limit')
	  },
	  link_str : {
	    0 : "acc_help.htm#mac_filter",
	    1 : "acc_help.htm#mbssid",
	    2 : "acc_help.htm#user_limit"
	  },
	  len : 3,
	  word : lang_obj.display('access'),
	  image : "images/but_firewall_0.png"
  },
  "status" : {
  	item : {
	    0 : "device info",
	    1 : "logs",
	    2 : "statistics",
	    3 : "wireless client",
	    4 : "sta_ipv6"
	  },
	  item_str : {
	    0 : lang_obj.display('device_info'),
	    1 : lang_obj.display('logs'),
	    2 : lang_obj.display('statistics'),
	    3 : lang_obj.display('wireless_client'),
	    4 : lang_obj.display('ipv6')
	  },
	  link_str : {
	    0 : "sta_help.htm#device",
	    1 : "sta_help.htm#log",
	    2 : "sta_help.htm#statistics",
	    3 : "sta_help.htm#wireless",
	    4 : "sta_help.htm#ipv6"
	  },
	  len : 5,
	  word : lang_obj.display('status'),
	  image : "images/but_network_map_0.png"
  },
  "help" : {
  	item : {
	    0 : "help"
	  },
	  item_str : {
	    0 : lang_obj.display('help_menu')
	  },
	  link_str : {
	    0 : "#help"
	  },
	  len : 1,
	  word : lang_obj.display('help'),
	  image : "images/but_guest_network_0.png"
  }
}

var cli_left = {
  "main" : {
  	item : {
	    0 : "wizard",
	    1 : "network",
	    2 : "password",
	    3 : "time"
	  },
	  item_str : {
	    0 : lang_obj.display('wizard'),
	    1 : lang_obj.display('network_setting'),
	    2 : lang_obj.display('device_information'),
	    3 : lang_obj.display('time_settings')
	  },
	  link_str : {
	    0 : "wizard_password.htm",
	    1 : "main_network.htm",
	    2 : "main_password.htm",
	    3 : "main_time.htm"
	  },
	  len : 4,
	  word : lang_obj.display('main'),
	  image : "images/but_setup_0.png"
  },
  "wireless" : {
  	item : {
	    0 : "wireless basic"
	  },
	  item_str : {
	    0 : lang_obj.display('site_survey')
	  },
	  link_str : {
	    0 : 'wireless_client_scan.htm?<% getInfo("modelName"); %>'
	  },
	  len : 1,
	  word : lang_obj.display('wireless'),
	  image : "images/but_wireless_0.png"
  },
  "admin" : {
  	item : {
	    0 : "firmware",
	    1 : "settings",
	    2 : "ping",
	    3 : "email",
	    4 : "syslog",
	    5 : "login"
	  },
	  item_str : {
	    0 : lang_obj.display('upload_firmware'),
	    1 : lang_obj.display("settings_management"),
	    2 : lang_obj.display('ping_test'),
	    3 : lang_obj.display('email_settings'),
	    4 : lang_obj.display('syslog'),
	    5 : lang_obj.display('logout')
	  },
	  link_str : {
	    0 : "firmware.htm",
	    1 : "admin_settings.htm",
	    2 : "admin_ping.htm",
	    3 : "tools_email.htm",
	    4 : "tools_syslog.htm",
	    5 : "home.htm"
	  },
	  len : 6,
	  word : lang_obj.display('tools'),
	  image : "images/but_administrator_0.png"
  },
  "status" : {
  	item : {
	    0 : "device info",
	    1 : "logs",
	    2 : "statistics",
	    3 : "link status"
	  },
	  item_str : {
	    0 : lang_obj.display('device_info'),
	    1 : lang_obj.display('logs'),
	    2 : lang_obj.display('statistics'),
	    3 : lang_obj.display('link_status')
	  },
	  link_str : {
	    0 : "sta_device_info.htm",
	    1 : "sta_logs.htm",
	    2 : "sta_statistics.htm",
	    3 : "sta_wireless_client.htm"
	  },
	  len : 4,
	  word : lang_obj.display('status'),
	  image : "images/but_network_map_0.png"
  },
  "help" : {
  	item : {
	    0 : "help"
	  },
	  item_str : {
	    0 : lang_obj.display('help_menu')
	  },
	  link_str : {
	    0 : "help.htm"
	  },
	  len : 1,
	  word : lang_obj.display('help'),
	  image : "images/but_guest_network_0.png"
  }
}

var rpt_left = {
  "main" : {
  	item : {
	    0 : "wizard",
	    1 : "network",
	    2 : "password",
	    3 : "time"
	  },
	  item_str : {
	    0 : lang_obj.display('wizard'),
	    1 : lang_obj.display('network_setting'),
	    2 : lang_obj.display('device_information'),
	    3 : lang_obj.display('time_settings')
	  },
	  link_str : {
	    0 : "wizard_password.htm",
	    1 : "main_network.htm",
	    2 : "main_password.htm",
	    3 : "main_time.htm"
	  },
	  len : 4,
	  word : lang_obj.display('main'),
	  image : "images/but_setup_0.png"
  },
  "wireless" : {
  	item : {
	    0 : "wireless basic"
	  },
	  item_str : {
	    0 : lang_obj.display('site_survey')
	  },
	  link_str : {
	    0 : 'wireless_rpt_scan.htm?<% getInfo("modelName"); %>'
	  },
	  len : 1,
	  word : lang_obj.display('wireless'),
	  image : "images/but_wireless_0.png"
  },
  "admin" : {
  	item : {
	    0 : "firmware",
	    1 : "settings",
	    2 : "ping",
	    3 : "email",
	    4 : "syslog",
	    5 : "led",
	    6 : "login"
	  },
	  item_str : {
	    0 : lang_obj.display('upload_firmware'),
	    1 : lang_obj.display("settings_management"),
	    2 : lang_obj.display('ping_test'),
	    3 : lang_obj.display('email_settings'),
	    4 : lang_obj.display('syslog'),
	    5 : lang_obj.display('led_control'),
	    6 : lang_obj.display('logout')
	  },
	  link_str : {
	    0 : "firmware.htm",
	    1 : "admin_settings.htm",
	    2 : "admin_ping.htm",
	    3 : "tools_email.htm",
	    4 : "tools_syslog.htm",
	    5 : "tools_led.htm",
	    6 : "home.htm"
	  },
	  len : 7,
	  word : lang_obj.display('tools'),
	  image : "images/but_administrator_0.png"
  },
  "status" : {
  	item : {
	    0 : "device info",
	    1 : "logs",
	    2 : "statistics",
	    3 : "wireless client"
	  },
	  item_str : {
	    0 : lang_obj.display('device_info'),
	    1 : lang_obj.display('logs'),
	    2 : lang_obj.display('statistics'),
	    3 : lang_obj.display('wireless_client')
	  },
	  link_str : {
	    0 : "sta_device_info.htm",
	    1 : "sta_logs.htm",
	    2 : "sta_statistics.htm",
	    3 : "sta_wireless_client.htm"
	  },
	  len : 4,
	  word : lang_obj.display('status'),
	  image : "images/but_network_map_0.png"
  },
  "help" : {
  	item : {
	    0 : "help"
	  },
	  item_str : {
	    0 : lang_obj.display('help_menu')
	  },
	  link_str : {
	    0 : "help.htm"
	  },
	  len : 1,
	  word : lang_obj.display('help'),
	  image : "images/but_guest_network_0.png"
  }
}

var wds_left = {
  "wireless" : {
  	item : {
	    0 : "wireless basic",
	    1 : "Advanced"
	  },
	  item_str : {
	    0 : lang_obj.display('basic'),
	    1 : lang_obj.display('advanced')
	  },
	  link_str : {
	    0 : "wireless_basic.htm",
	    1 : "wireless_advanced.htm"
	  },
	  len : 2,
	  word : lang_obj.display('wireless'),
	  image : "images/but_wireless_0.png"
  },
  "admin" : {
  	item : {
	    0 : "firmware",
	    1 : "settings",
	    2 : "ping",
	    3 : "schedule",
	    4 : "email",
	    5 : "syslog",
	    6 : "login"
	  },
	  item_str : {
	    0 : lang_obj.display('upload_firmware'),
	    1 : lang_obj.display("settings_management"),
	    2 : lang_obj.display('ping_test'),
	    3 : lang_obj.display('schedule'),
	    4 : lang_obj.display('email_settings'),
	    5 : lang_obj.display('syslog'),
	    6 : lang_obj.display('logout')
	  },
	  link_str : {
	    0 : "firmware.htm",
	    1 : "admin_settings.htm",
	    2 : "admin_ping.htm",
	    3 : "admin_schedules.htm",
	    4 : "tools_email.htm",
	    5 : "tools_syslog.htm",
	    6 : "home.htm"
	  },
	  len : 7,
	  word : lang_obj.display('tools'),
	  image : "images/but_administrator_0.png"
  },
  "main" : {
  	item : {
	    0 : "wizard",
	    1 : "network",
	    3 : "password",
	    4 : "time"
	  },
	  item_str : {
	    0 : lang_obj.display('wizard'),
		1 : lang_obj.display('network_setting'),
	    2 : lang_obj.display('device_information'),
	    3 : lang_obj.display('time_settings')
	  },
	  link_str : {
	    0 : "wizard_password.htm",
	    1 : "main_network.htm",
	    2 : "main_password.htm",
	    3 : "main_time.htm"
	  },
	  len : 4,
	  word : lang_obj.display('main'),
	  image : "images/but_setup_0.png"
  },
  "status" : {
  	item : {
	    0 : "device info",
	    1 : "logs",
	    2 : "statistics",
	    3 : "wireless client",
	    4 : "sta_ipv6"
	  },
	  item_str : {
	    0 : lang_obj.display('device_info'),
	    1 : lang_obj.display('logs'),
	    2 : lang_obj.display('statistics'),
	    3 : lang_obj.display('wireless_client'),
	    4 : lang_obj.display('ipv6')
	  },
	  link_str : {
	    0 : "sta_device_info.htm",
	    1 : "sta_logs.htm",
	    2 : "sta_statistics.htm",
	    3 : "sta_wireless_client.htm",
	    4 : "sta_ipv6.htm"
	  },
	  len : 5,
	  word : lang_obj.display('status'),
	  image : "images/but_network_map_0.png"
  },
  "help" : {
  	item : {
	    0 : "help"
	  },
	  item_str : {
	    0 : lang_obj.display('help_menu')
	  },
	  link_str : {
	    0 : "help.htm"
	  },
	  len : 1,
	  word : lang_obj.display('help'),
	  image : "images/but_guest_network_0.png"
  }
}

var ap_left = {
  "main" : {
  	item : {
	    0 : "wizard",
	    1 : "network",
	    2 : "password",
	    3 : "time",
	    4 : "ipv6"
	  },
	  item_str : {
	    0 : lang_obj.display('wizard'),
	    1 : lang_obj.display('network_setting'),
	    2 : lang_obj.display('device_information'),
	    3 : lang_obj.display('time_settings'),
	    4 : lang_obj.display('ipv6')
	  },
	  link_str : {
	    0 : "wizard_password.htm",
	    1 : "main_network.htm",
	    2 : "main_password.htm",
	    3 : "main_time.htm",
	    4 : "main_ipv6.htm"
	  },
	  len : 5,
	  word : lang_obj.display('main'),
	  image : "images/but_setup_0.png"
  },
  "wireless" : {
  	item : {
	    0 : "wireless basic",
	    1 : "Advanced",
	    2 : "WPS"
	  },
	  item_str : {
	    0 : lang_obj.display('basic'),
	    1 : lang_obj.display('advanced'),
	    2 : lang_obj.display('wifi_wps')
	  },
	  link_str : {
	    0 : "wireless_basic.htm",
	    1 : "wireless_advanced.htm",
	    2 : "wireless_wps.htm"
	  },
	  len : 3,
	  word : lang_obj.display('wireless'),
	  image : "images/but_wireless_0.png"
  },
  "admin" : {
  	item : {
	    0 : "firmware",
	    1 : "settings",
	    2 : "ping",
	    3 : "schedule",
	    4 : "email",
	    5 : "syslog",
	    6 : "led",
	    7 : "login"
	  },
	  item_str : {
	    0 : lang_obj.display('upload_firmware'),
	    1 : lang_obj.display("settings_management"),
	    2 : lang_obj.display('ping_test'),
	    3 : lang_obj.display('schedule'),
	    4 : lang_obj.display('email_settings'),
	    5 : lang_obj.display('syslog'),
	    6 : lang_obj.display('led_control'),
	    7 : lang_obj.display('logout')
	  },
	  link_str : {
	    0 : "firmware.htm",
	    1 : "admin_settings.htm",
	    2 : "admin_ping.htm",
	    3 : "admin_schedules.htm",
	    4 : "tools_email.htm",
	    5 : "tools_syslog.htm",
	    6 : "tools_led.htm",
	    7 : "home.htm"
	  },
	  len : 8,
	  word : lang_obj.display('tools'),
	  image : "images/but_administrator_0.png"
  },
  "access" : {
  	item : {
	    0 : "mac_filter",
	    1 : "multi_ssid",
	    2 : "user limit"
	  },
	  item_str : {
	    0 : lang_obj.display('mac_filters'),
	    1 : lang_obj.display('multi_ssid'),
	    2 : lang_obj.display('user_limit')
	  },
	  link_str : {
	    0 : "acc_macfilter.htm",
	    1 : "acc_mbssid.htm",
	    2 : "user_limit.htm"
	  },
	  len : 3,
	  word : lang_obj.display('access'),
	  image : "images/but_firewall_0.png"
  },
  "status" : {
  	item : {
	    0 : "device info",
	    1 : "logs",
	    2 : "statistics",
	    3 : "wireless client",
	    4 : "sta_ipv6"
	  },
	  item_str : {
	    0 : lang_obj.display('device_info'),
	    1 : lang_obj.display('logs'),
	    2 : lang_obj.display('statistics'),
	    3 : lang_obj.display('wireless_client'),
	    4 : lang_obj.display('ipv6')
	  },
	  link_str : {
	    0 : "sta_device_info.htm",
	    1 : "sta_logs.htm",
	    2 : "sta_statistics.htm",
	    3 : "sta_wireless_client.htm",
	    4 : "sta_ipv6.htm"
	  },
	  len : 5,
	  word : lang_obj.display('status'),
	  image : "images/but_network_map_0.png"
  },
  "help" : {
  	item : {
	    0 : "help"
	  },
	  item_str : {
	    0 : lang_obj.display('help_menu')
	  },
	  link_str : {
	    0 : "help.htm"
	  },
	  len : 1,
	  word : lang_obj.display('help'),
	  image : "images/but_guest_network_0.png"
  }
}

function get_left( idx , left_val ){
  var left_idx; // client, wds, repeater:2  ap:0
  
  if( idx == 0){
    left_idx = "main";
  }else if( idx == 1){
    left_idx = "wireless";
  }else if( idx == 2){
    left_idx = "status";
  }else if( idx == 3 ){
    if( left_val == 2 ){ // client, wds, repeater
      left_idx = "admin";
    }else{
      left_idx = "access";
  	}
  }else if( idx == 4){
		left_idx = "admin";
  }else{
    left_idx = "main";
  }
    
  return left_idx;

}

function show_left( mode_val, sel_item ){
	var ul_head    = "<ul class=\"categoryitems\">";
	var ul_tail    = "</ul>";
	var li_head    = "<li>";
	var li_tail    = "</li>";
	var select_str = "class=\"selected0\"" ;
	var link_htm = 'wireless_setting.htm';
	var link_str =  lang_obj.display('wifi_setting');
	var htm_str = new Array();
	//select_str = "";
	htm_str[0] = "<a  onclick=\"location.href ='" + link_htm + "'\"" + select_str + ">" + link_str + "</a>";
	
	//alert(ap_left["wireless"].item[0]);
	//alert(ap_left["wireless"].link_str[0]);
	//alert(ap_left["wireless"].len);
	
	var mode_left_val = "<% getIndex("wlanMode"); %>";
	var mode_left = ap_left;
	var num_item = 4;
	var isrpt = get_repeater_mode();
	var left_order = 0;
	/*
	left_order
	0: ap
	2: client, wds, repeater
	*/
	
	//alert(mode_val); 
	//alert(mode_left_val);
	//alert(<% getIndex("get_repeaterEnabled"); %>);
	
	if(mode_val == "help"){
		mode_left = help_left;
		num_item = 5;
	}else{ //web page always setting "ap"
		if( mode_left_val == "0"){
			if(isrpt > 0){
				//AP_repeater
				mode_left = rpt_left;
				num_item = 4;
				left_order = 2;
			}else{
				//AP
				mode_left = ap_left;
				num_item = 5;	
			}
		}else if( mode_left_val == "1"){
			mode_left = cli_left;
			num_item = 4;
			left_order = 2;
		}else if ( mode_left_val == "2"){
			mode_left = wds_left;
			num_item = 4;
			left_order = 2;
		}else{
			mode_left = ap_left;
			num_item = 5;
		}
	}
	
	for(var j = 0; j < num_item; j++){ // num_item of left items
		left_idx = get_left(j, left_order);
		
		document.write("<div class=\"menuheader expandable\" ><span class=\"CatTitle\">" + mode_left[ left_idx ].word + "</span></div>"); //joe remove image
		document.write( ul_head );
		
		for(var i = 0; i < mode_left[ left_idx ].len; i++){
			if( sel_item == mode_left[ left_idx ].item[i] ){
				//alert("mode_left[ left_idx ].item[i] = " + mode_left[ left_idx ].item[i]);
				select_str = "class=\"selected0\"" ;
			}else{
				select_str = "";
			}
			
			htm_str[i] = "<a  onclick=\"location.href ='" + mode_left[ left_idx ].link_str[i] + "'\"" + select_str + ">" + mode_left[ left_idx ].item_str[i] + "</a>";
			document.write( li_head + htm_str[i] + li_tail);
		}
		
		document.write( ul_tail );
	}
}

function set_texpanded(texpanded){

ddaccordion.init({ //top level headers initialization
	headerclass: "expandable", //Shared CSS class name of headers group that are expandable
	contentclass: "categoryitems", //Shared CSS class name of contents group
	revealtype: "click", //Reveal content when user clicks or onmouseover the header? Valid value: "click", "clickgo", or "mouseover"
	mouseoverdelay: 500, //if revealtype="mouseover", set delay in milliseconds before header expands onMouseover
	collapseprev: true, //Collapse previous content (so only one open at any time)? true/false 
	defaultexpanded: [texpanded], //index of content(s) open by default [index1, index2, etc]. [] denotes no content
	onemustopen: false, //Specify whether at least one header should be open always (so never all headers closed)
	animatedefault: false, //Should contents open by default be animated into view?
	persiststate: false, //persist state of opened contents within browser session?
	toggleclass: ["", "openheader"], //Two CSS classes to be applied to the header when it's collapsed and expanded, respectively ["class1", "class2"]
	togglehtml: ["src", "", ""], //Additional HTML added to the header when it's collapsed and expanded, respectively  ["position", "html1", "html2"] (see docs)
	animatespeed: 250, //speed of animation: integer in milliseconds (ie: 200), or keywords "fast", "normal", or "slow"
	oninit:function(headers, expandedindices){ //custom code to run when headers have initalized
		//do nothing
		//jQuery('.categoryitems').hide();
	},
	onopenclose:function(header, index, state, isuseractivated){ //custom code to run whenever a header is opened or closed
		$(".selected0").addClass('selected');
	}
})

$(document).ready(function () {
	$('.arrowlistmenu ul li a').click(function () {
		$('.arrowlistmenu ul li a').removeClass('selected');
		$(this).addClass('selected');
	});
});
}

function time_out(){
	time_out_counter=time_out_counter-1;
	if(time_out_counter<0){
		window.location.href="/home.htm";
	}
	time_out_id = setTimeout("time_out()",1000);
}

function show_help_page(name){
	window.open(name,'Help','scrollbars=yes, resizable=yes, width=1000, height=500, ');
}

function addr_obj(addr, e_msg, allow_zero, is_network){
	this.addr = addr;
	this.e_msg = e_msg;
	this.allow_zero = allow_zero;		
	this.is_network = is_network;
}

function check_current_range(order, my_obj, checking_ip, mask){
	var which_ip = (my_obj.addr[order]).split(" ");
	var start, end;

	if (isNaN(which_ip) || which_ip == "" || which_ip.length > 1 || (which_ip[0].length > 1 && which_ip[0].substring(0,1) == "0")){	// if the address is invalid
		alert(my_obj.e_msg[2 + order]);
		return false;
	}

	if (order == 0){				// the checking range of 1st address
		start = 1;	
	}else{
		start = 0;				
	}

	if (mask[order] != 255){				
		if (parseInt(checking_ip[order]) >= 0 && parseInt(checking_ip[order]) <= 255){	
			end = (~mask[order]+256);				
			start = mask[order] & checking_ip[order];	
			end += start;

			if (end > 255){
				end = 255;
			}
		}else{
			end = 255;
		}
	}else{
		end = 255;
	}

	if (order == 3){
		if ((mask[0] == 255) && (mask[1] == 255) && (mask[2] == 255)){
			start += 1;
			end -= 1;
		}else{		
			if (((mask[0] | (~my_obj.addr[0]+256)) == 255) && ((mask[1] | (~my_obj.addr[1]+256)) == 255) && ((mask[2] | (~my_obj.addr[2]+256)) == 255)){
				start += 1;
			}

			if (((mask[0] | my_obj.addr[0]) == 255) && ((mask[1] | my_obj.addr[1]) == 255) && ((mask[2] | my_obj.addr[2]) == 255)){			
				end -= 1;
			}	
		}	
	}

	if (parseInt(which_ip) < start || parseInt(which_ip) > end){			
		alert(my_obj.e_msg[6 + order] + " " + start + " ~ " + end + ".");		
		return false;
	}

	return true;
}

function MM_preloadImages() { //v3.0
	var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
	var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
	if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function check_address(my_obj, mask_obj, ip_obj){
	var count_zero = 0;
	var count_bcast = 0;	
	var ip = my_obj.addr;
	var mask;

	if (my_obj.addr.length == 4){
		// check the ip is not multicast IP (127.x.x.x && 224.x.x.x ~ 239.x.x.x)
		if((my_obj.addr[0] == "127") || ((my_obj.addr[0] >= 224) && (my_obj.addr[0] <= 239))){
			alert(TEXT030); //MULTICASE_IP_ERROR
			return false;
		}
		// check the ip is "0.0.0.0" or not
		for(var i = 0; i < ip.length; i++){
			if (ip[i] == "0"){
				count_zero++;			
			}
		}

		if (!my_obj.allow_zero && count_zero == 4){	// if the ip is not allowed to be 0.0.0.0
			alert(MSG046);			// but we check the ip is 0.0.0.0
			return false;
		}else if (count_zero != 4){		// when IP is not 0.0.0.0, checking range. Otherwise no need to check		
			count_zero = 0;

			if (check_address.arguments.length >= 2 && mask_obj != null){
				mask = mask_obj.addr;
			}else{
				mask = new Array(255,255,255,0);
			}

			for(var i = 0; i < ip.length; i++){

				if (check_address.arguments.length == 3 && ip_obj != null){
					if (!check_current_range(i, my_obj, ip_obj.addr, mask)){
						return false;
					}
				}else{					
					if (!check_ip_range(i, my_obj, mask)){
						return false;
					}
				}
			}		

			for (var i = 0; i < 4; i++){	// check the IP address is a network address or a broadcast address																							
				if (((~mask[i] + 256) & ip[i]) == 0){	// (~mask[i] + 256) = reverse mask[i]
					count_zero++;						
				}

				if ((mask[i] | ip[i]) == 255){
					count_bcast++;
				}
			}

			if ((count_zero == 4 && !my_obj.is_network) || (count_bcast == 4)){
				alert(ipaddr_msg0);			
				return false;
			}													
		}
	}else{	// if the length of ip is not correct, show invalid ip msg
		alert(ipaddr_msg0);
		return false;
	}

	return true;
}

function check_port(port){
	var temp_port = port.split(" ");

	if (isNaN(port) || port == "" || temp_port.length > 1 
			|| (parseInt(port) < 1 || parseInt(port) > 65535)){
		return false;
	}
	return true;
}

function check_radius(radius){
	if (!check_address(radius.ip)){
		return false;
	}else if (!check_port(radius.port)){
		alert(MSG008);
		return false;
	}else if (radius.secret == ""){
		alert(MSG009);
		return false;               
	}

	return true;
}

function check_multi_port(remote_port, obj_port){
	//multi-port: 25,80,110,443,50000-65535
	var port_info = obj_port + ",";
	var port = port_info.split(",");

	for(var i = 0; i < port.length; i++){
		var port_range = port[i].split("-");
		if(port_range.length > 1){
			if(parseInt(port_range[0]) <= parseInt(remote_port) && parseInt(port_range[1]) >= parseInt(remote_port)){
				return false;
			}
		}else{
			if(port[i] == remote_port){
				return false;
			}
		}
	}
	return true;
}

function send_submit(which_form){
	get_by_id(which_form).submit();
}

function set_selectIndex(which_value, obj){
	for (var pp=0; pp<obj.options.length; pp++){
		if (which_value == obj.options[pp].value){
			obj.selectedIndex = pp;
			break;
		}
	}
}

function set_checked(which_value, obj){
	if(obj.length > 1){
		obj[0].checked = true;
		for(var pp=0;pp<obj.length;pp++){
			if(obj[pp].value == which_value){
				obj[pp].checked = true;
			}
		}
	}else{
		obj.checked = false;
		if(obj.value == which_value){
			obj.checked = true;
		}
	}
}

function set_mac(mac){
	var temp_mac = mac.split(":");
	for (var i = 0; i < 6; i++){
		var obj = get_by_id("mac" + (i+1));
		obj.value = temp_mac[i];
	}
}

function show_words(word){
	with(document){
		return write(word);
	}
}

function check_ascii_key_fun(data){	

	if (!(data >= 'A' && data <= 'Z') && !(data >= '0' && data <= '9') && !(data >= 'a' && data <= 'z')){	
		return false;
	}	
	return true;
}

function hex_to_a(inValue){
	outValue = "";
	var k = '';
	for (i = 0; i < inValue.length; i++) {
		l = i % 2;
		if (l == 0)
			k += "%";
		k += inValue.substr(i, 1);
	}
	outValue = unescape(k);
	return outValue;
}

function addstr(input_msg){
	var last_msg = "";
	var str_location;
	var temp_str_1 = "";
	var temp_str_2 = "";
	var str_num = 0;
	temp_str_1 = addstr.arguments[0];
	while(1)
	{
		str_location = temp_str_1.indexOf("%s");
		if(str_location >= 0)
		{
			str_num++;
			temp_str_2 = temp_str_1.substring(0,str_location);
			last_msg += temp_str_2 + addstr.arguments[str_num];
			temp_str_1 = temp_str_1.substring(str_location+2,temp_str_1.length);
			continue;
		}
		if(str_location < 0)
		{
			last_msg += temp_str_1;
			break;
		}
	}
	return last_msg;
}

function ip_num(IP_array){
	var total1 = 0;
	if(IP_array.length > 1){
		total1 += parseInt(IP_array[3],10);
		total1 += parseInt(IP_array[2],10)*256;
		total1 += parseInt(IP_array[1],10)*256*256;
		total1 += parseInt(IP_array[0],10)*256*256*256;
	}
	return total1;
}

/*
 * is_form_modified
 *	Check if a form's current values differ from saved values in custom attribute.
 *	Function skips elements with attribute: 'modified'= 'ignore'. 
 */
function is_form_modified(form_id){
	var df = document.forms[form_id];
	if (!df) {
		return false;
	}
	if (df.getAttribute('modified') == "true") {
		return true;
	}
	if (df.getAttribute('saved') != "true") {
		return false;
	}
	for (var i = 0, k = df.elements.length; i < k; i++) {
		var obj = df.elements[i];
		if (obj.getAttribute('modified') == 'ignore') {
			continue;
		}
		var name = obj.tagName.toLowerCase();
		if (name == 'input') {
			var type = obj.type.toLowerCase();
			if (((type == 'text') || (type == 'textarea') || (type == 'password') || (type == 'hidden')) &&
					!are_values_equal(obj.getAttribute('default'), obj.value)) {
				return true;
			} else if (((type == 'checkbox') || (type == 'radio')) && !are_values_equal(obj.getAttribute('default'), obj.checked)) {
				return true;
			}
		} else if (name == 'select') {
			var opt = obj.options;
			for (var j = 0; j < opt.length; j++) {
				if (!are_values_equal(opt[j].getAttribute('default'), opt[j].selected)) {
					return true;
				}
			}
		}
	}
	return false;
}

/*
 * set_form_default_values
 *	Save a form's current values to a custom attribute.
 */
function set_form_default_values(form_id){
	var df = document.forms[form_id];
	if (!df) {
		return;
	}
	for (var i = 0, k = df.elements.length; i < k; i++) {
		var obj = df.elements[i];
		if (obj.getAttribute('modified') == 'ignore') {
			continue;
		}
		var name = obj.tagName.toLowerCase();
		if (name == 'input') {
			var type = obj.type.toLowerCase();
			if ((type == 'text') || (type == 'textarea') || (type == 'password') || (type == 'hidden')) {
				obj.setAttribute('default', obj.value);
				/* Workaround for FF error when calling focus() from an input text element. */
				if (type == 'text') {
					obj.setAttribute('autocomplete', 'off');
				}
			} else if ((type == 'checkbox') || (type == 'radio')) {
				obj.setAttribute('default', obj.checked);
			}
		} else if (name == 'select') {
			var opt = obj.options;
			for (var j = 0; j < opt.length; j++) {
				opt[j].setAttribute('default', opt[j].selected);
			}
		}
	}
	df.setAttribute('saved', "true");
}

/*
 * are_values_equal()
 *	Compare values of types boolean, string and number. The types may be different.
 *	Returns true if values are equal.
 */
function are_values_equal(val1, val2){
	/* Make sure we can handle these values. */
	switch (typeof(val1)) {
	case 'boolean':
	case 'string':
	case 'number':
		break;
	default:
		// alert("are_values_equal does not handle the type '" + typeof(val1) + "' of val1 '" + val1 + "'.");
		return false;
	}

	switch (typeof(val2)) {
	case 'boolean':
		switch (typeof(val1)) {
		case 'boolean':
			return (val1 == val2);
		case 'string':
			if (val2) {
				return (val1 == "1" || val1.toLowerCase() == "true" || val1.toLowerCase() == "on");
			} else {
				return (val1 == "0" || val1.toLowerCase() == "false" || val1.toLowerCase() == "off");
			}
			break;
		case 'number':
			return (val1 == val2 * 1);
		}
		break;
	case 'string':
		switch (typeof(val1)) {
		case 'boolean':
			if (val1) {
				return (val2 == "1" || val2.toLowerCase() == "true" || val2.toLowerCase() == "on");
			} else {
				return (val2 == "0" || val2.toLowerCase() == "false" || val2.toLowerCase() == "off");
			}
			break;
		case 'string':
			if (val2 == "1" || val2.toLowerCase() == "true" || val2.toLowerCase() == "on") {
				return (val1 == "1" || val1.toLowerCase() == "true" || val1.toLowerCase() == "on");
			}
			if (val2 == "0" || val2.toLowerCase() == "false" || val2.toLowerCase() == "off") {
				return (val1 == "0" || val1.toLowerCase() == "false" || val1.toLowerCase() == "off");
			}
			return (val2 == val1);
		case 'number':
			if (val2 == "1" || val2.toLowerCase() == "true" || val2.toLowerCase() == "on") {
				return (val1 == 1);
			}
			if (val2 == "0" || val2.toLowerCase() == "false" || val2.toLowerCase() == "off") {
				return (val1 === 0);
			}
			return (val2 == val1 + "");
		}
		break;
	case 'number':
		switch (typeof(val1)) {
		case 'boolean':
			return (val1 * 1 == val2);
		case 'string':
			if (val1 == "1" || val1.toLowerCase() == "true" || val1.toLowerCase() == "on") {
				return (val2 == 1);
			}
			if (val1 == "0" || val1.toLowerCase() == "false" || val1.toLowerCase() == "off") {
				return (val2 === 0);
			}
			return (val1 == val2 + "");
		case 'number':
			return (val2 == val1);
		}
		break;
	default:
		return false;
	}
	return false;
}

/*
 * reset_form()
 *	Reset a form with previously saved default values.
 *	Function skips elements with attribute: 'modified'= 'ignore'. 
 */
function reset_form(form_id)
{
	var df = document.forms[form_id];
	if (!df) {
		return;
	}
	if (df.getAttribute('saved') != "true") {
		return;
	}

	for (var i = 0, k = df.elements.length; i < k; i++) {
		var obj = df.elements[i];
		if (obj.getAttribute('modified') == 'ignore') {
			continue;
		}
		var name = obj.tagName.toLowerCase();
		var value;
		if (name == 'input') {
			var type = obj.type.toLowerCase();
			if ((type == 'text') || (type == 'textarea') || (type == 'password') || (type == 'hidden')) {
				obj.value = obj.getAttribute('default');
			} else if ((type == 'checkbox') || (type == 'radio')) {
				value = obj.getAttribute('default');
				switch (typeof(value)) {
				case 'boolean':
					obj.checked = value;
					break;
				case 'string':
					if (value == "1" || value.toLowerCase() == "true" || value.toLowerCase() == "on") {
						obj.checked = true;
					}
					if (value == "0" || value.toLowerCase() == "false" || value.toLowerCase() == "off") {
						obj.checked = false;
					}
					break;
				}
			}
		} else if (name == 'select') {
			var opt = obj.options;
			for (var j = 0; j < opt.length; j++) {
				value = obj[j].getAttribute('default');
				switch (typeof(value)) {
				case 'boolean':
					obj[j].selected = value;
					break;
				case 'string':
					if (value == "1" || value.toLowerCase() == "true" || value.toLowerCase() == "on") {
						obj[j].selected = true;
					}
					if (value == "0" || value.toLowerCase() == "false" || value.toLowerCase() == "off") {
						obj[j].selected = false;
					}
					break;
				}
			}
		}
	}
}

/*
 * trim_string
 *	Remove leading and trailing blank spaces from a string.
 */
function trim_string(str){
	var trim = str + "";
	trim = trim.replace(/^\s*/, "");
	return trim.replace(/\s*$/, "");
}

/*
 * is_mac_valid()
 *	Check if a MAC address is in a valid form.
 *	Allow 00:00:00:00:00:00 and FF:FF:FF:FF:FF:FF if optional argument is_full_range is true.
 */
function is_mac_valid(mac, is_full_range){
	var macstr = mac + "";
	var got = macstr.match(/^[0-9a-fA-F]{2}[:-]?[0-9a-fA-F]{2}[:-]?[0-9a-fA-F]{2}[:-]?[0-9a-fA-F]{2}[:-]?[0-9a-fA-F]{2}[:-]?[0-9a-fA-F]{2}$/);
	if (!got) {
		return false;
	}
	macstr = macstr.replace (/[:-]/g, '');
	if (!is_full_range && (macstr.match(/^0{12}$/) || macstr.match(/^[fF]{12}$/))) {
		return false;
	}

	return true;
}

/*
 * is_ascii()
 *      Returns true if value is made of printable ASCII characters (or blank).
 */
function is_ascii(value){
	value += "";
	return value.match(/^[\x20-\x7E]*$/) ? true : false;
}

/*
 * is_number()
 *	Returns true if a value represents a number, else return false.
 */
function is_number(value){
	value += "";
	return value.match(/^-?\d*\.?\d+$/) ? true : false;
}

/*
 * is_ipv4_valid
 *	Check is an IP address dotted string is valid.
 */
function is_ipv4_valid(ipaddr){
	var ip = ipv4_to_bytearray(ipaddr);
	if (ip === 0) {
		return false;
	}
	return true;
}

/*
 * ipv4_to_bytearray
 *	Convert an IPv4 address dotted string to a byte array
 */
function ipv4_to_bytearray(ipaddr){
	var ip = ipaddr + "";
	var got = ip.match (/^\s*(\d{1,3})\s*[.]\s*(\d{1,3})\s*[.]\s*(\d{1,3})\s*[.]\s*(\d{1,3})\s*$/);
	if (!got) {
		return 0;
	}
	var a = [];
	var q = 0;
	for (var i = 1; i <= 4; i++) {
		q = parseInt(got[i],10);
		if (q < 0 || q > 255) {
			return 0;
		}
		a[i-1] = q;
	}
	return a;
} 

function transValue(data){
	var value =0;
	data = data.toUpperCase();

	if(data == "0")
		value =0;
	else if(data =="1")
		value = 1;
	else if(data =="2")
		value = 2;
	else if(data =="3")
		value = 3;
	else if(data =="4")
		value = 4;	
	else if(data =="5")
		value = 5;
	else if(data =="6")
		value = 6;
	else if(data =="7")
		value = 7;
	else if(data =="8")
		value = 8;
	else if(data =="9")
		value = 9;
	else if(data =="A")
		value = 10;
	else if(data =="B")
		value = 11;
	else if(data =="C")
		value = 12;
	else if(data =="D")
		value = 13;
	else if(data =="E")
		value = 14;
	else if(data =="F")
		value = 15;				
	else
		value = 0;
	return value ;				
}

function compare_suffix(start_suffix,end_suffix){
	var start_suffix_length = start_suffix.length;
	var end_suffix_length = end_suffix.length;

	var start_suffix_value =0;
	var end_suffix_value=0;

	//calculate the start_suffix
	if(start_suffix_length == 1){
		start_suffix_value = transValue(start_suffix.charAt(0)) * 1;
	}else if(start_suffix_length == 2){
		start_suffix_value = transValue(start_suffix.charAt(0)) * 16;
		start_suffix_value += transValue(start_suffix.charAt(1)) * 1;
	}else if(start_suffix_length == 3){
		start_suffix_value = transValue(start_suffix.charAt(0)) * 256;
		start_suffix_value += transValue(start_suffix.charAt(1)) * 16;
		start_suffix_value += transValue(start_suffix.charAt(2)) * 1;
	}else if(start_suffix_length == 4){
		start_suffix_value = transValue(start_suffix.charAt(0)) * 4096;
		start_suffix_value += transValue(start_suffix.charAt(1)) * 256;
		start_suffix_value += transValue(start_suffix.charAt(2)) * 16;
		start_suffix_value += transValue(start_suffix.charAt(3)) * 1;
	}

	//calculate the end_suffix
	if(end_suffix_length == 1){
		end_suffix_value = transValue(end_suffix.charAt(0)) * 1;
	}else if(end_suffix_length == 2){
		end_suffix_value = transValue(end_suffix.charAt(0)) * 16;
		end_suffix_value += transValue(end_suffix.charAt(1)) * 1;
	}else if(end_suffix_length == 3){
		end_suffix_value = transValue(end_suffix.charAt(0)) * 256;
		end_suffix_value += transValue(end_suffix.charAt(1)) * 16;
		end_suffix_value += transValue(end_suffix.charAt(2)) * 1;
	}else if(end_suffix_length == 4){
		end_suffix_value = transValue(end_suffix.charAt(0)) * 4096;
		end_suffix_value += transValue(end_suffix.charAt(1)) * 256;
		end_suffix_value += transValue(end_suffix.charAt(2)) * 16;
		end_suffix_value += transValue(end_suffix.charAt(3)) * 1;
	}

	if(start_suffix_value >= end_suffix_value){
		alert(compare_suffix_error);
		return false;	
	}
	return true;
}

function base64Encode(str) {
	var c, d, e, end = 0;
	var u, v, w, x;
	var ptr = -1;
	var input = str.split("");
	var output = "";
	while(end == 0) {
		c = (typeof input[++ptr] != "undefined") ? input[ptr].charCodeAt(0) :
			((end = 1) ? 0 : 0);
		d = (typeof input[++ptr] != "undefined") ? input[ptr].charCodeAt(0) :
			((end += 1) ? 0 : 0);
		e = (typeof input[++ptr] != "undefined") ? input[ptr].charCodeAt(0) :
			((end += 1) ? 0 : 0);
		u = enc64List[c >> 2];
		v = enc64List[(0x00000003 & c) << 4 | d >> 4];
		w = enc64List[(0x0000000F & d) << 2 | e >> 6];
		x = enc64List[e & 0x0000003F];

		// handle padding to even out unevenly divisible string lengths
		if (end >= 1) {x = "=";}
		if (end == 2) {w = "=";}

		if (end < 3) {output += u + v + w + x;}
	}
	// format for 76-character line lengths per RFC
	var formattedOutput = "";
	var lineLength = 76;
	while (output.length > lineLength) {
		formattedOutput += output.substring(0, lineLength) + "\n";
		output = output.substring(lineLength);
	}
	formattedOutput += output;
	return formattedOutput;
}

var enc64List, dec64List;
function initBase64() {
	enc64List = new Array();
	dec64List = new Array();
	var i;
	for (i = 0; i < 26; i++) {
		enc64List[enc64List.length] = String.fromCharCode(65 + i);
	}
	for (i = 0; i < 26; i++) {
		enc64List[enc64List.length] = String.fromCharCode(97 + i);
	}
	for (i = 0; i < 10; i++) {
		enc64List[enc64List.length] = String.fromCharCode(48 + i);
	}
	enc64List[enc64List.length] = "+";
	enc64List[enc64List.length] = "/";
	for (i = 0; i < 128; i++) {
		dec64List[dec64List.length] = -1;
	}
	for (i = 0; i < 64; i++) {
		dec64List[enc64List[i].charCodeAt(0)] = i;
	}
}

//Self-initialize the global variables
initBase64();

function replaceAll(src, src_rep, new_str){
	var index = 0;
	while(src.indexOf(src_rep, index) != -1) {
		src = src.replace(src_rep, new_str);
		index = src.indexOf(src_rep, index);
	}
	return src
}

/* end : fromat.js */

/* start : md5.js */
/* 
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message 
 * Digest Algorithm, as defined in RFC 1321. 
 * Copyright (C) Paul Johnston 1999 - 2000. 
 * Updated by Greg Holt 2000 - 2001. * See http://pajhome.org.uk/site/legal.html for details. 
 */ 
/* 
 * Convert a 32-bit number to a hex string with ls-byte first 
 */ 
var hex_chr = "0123456789abcdef"; 
function rhex(num) { 
	var str = ""; 
	for(var j = 0; j <= 3; j++) 
		str += hex_chr.charAt((num >> (j * 8 + 4)) & 0x0F) + hex_chr.charAt((num >> (j * 8)) & 0x0F); 
	return str; 
} 
/* 
 * Convert a string to a sequence of 16-word blocks, stored as an array. 
 * Append padding bits and the length, as described in the MD5 standard. 
 */ 
function str2blks_MD5(str){ 
	var nblk = ((str.length + 8) >> 6) + 1; 
	var blks = new Array(nblk * 16); 
	for(var i = 0; i < nblk * 16; i++) blks[i] = 0; 
	for(var i = 0; i < str.length; i++) 
		blks[i >> 2] |= str.charCodeAt(i) << ((i % 4) * 8); 
	blks[i >> 2] |= 0x80 << ((i % 4) * 8); 
	blks[nblk * 16 - 2] = str.length * 8; 
	return blks; 
} 
/* 
 * Add integers, wrapping at 2^32. This uses 16-bit operations internally 
 * to work around bugs in some JS interpreters. 
 */ 
function safe_add(x, y){ 
	var lsw = (x & 0xFFFF) + (y & 0xFFFF); 
	var msw = (x >> 16) + (y >> 16) + (lsw >> 16); 
	return (msw << 16) | (lsw & 0xFFFF); 
} 
/* 
 * Bitwise rotate a 32-bit number to the left 
 */ 
function rol(num, cnt){ 
	return (num << cnt) | (num >>> (32 - cnt)); 
} 
/* 
 * These functions implement the basic operation for each round of the 
 * algorithm. 
 */ 
function cmn(q, a, b, x, s, t){ 
	return safe_add(rol(safe_add(safe_add(a, q), safe_add(x, t)), s), b); 
} 

function ff(a, b, c, d, x, s, t){ 
	return cmn((b & c) | ((~b) & d), a, b, x, s, t); 
} 

function gg(a, b, c, d, x, s, t) { 
	return cmn((b & d) | (c & (~d)), a, b, x, s, t); 
} 

function hh(a, b, c, d, x, s, t) { 
	return cmn(b ^ c ^ d, a, b, x, s, t); 
} 

function ii(a, b, c, d, x, s, t) { 
	return cmn(c ^ (b | (~d)), a, b, x, s, t); 
} 
/* 
 * Take a string and return the hex representation of its MD5. 
 */ 
function calcMD5(str) { 
	var x = str2blks_MD5(str); 
	var a = 1732584193; 
	var b = -271733879; 
	var c = -1732584194; 
	var d = 271733878; 
	for(i = 0; i < x.length; i += 16) 
	{ 
		var olda = a; 
		var oldb = b; 
		var oldc = c; 
		var oldd = d; 
		a = ff(a, b, c, d, x[i+ 0], 7 , -680876936); 
		d = ff(d, a, b, c, x[i+ 1], 12, -389564586); 
		c = ff(c, d, a, b, x[i+ 2], 17, 606105819); 
		b = ff(b, c, d, a, x[i+ 3], 22, -1044525330); 
		a = ff(a, b, c, d, x[i+ 4], 7 , -176418897); 
		d = ff(d, a, b, c, x[i+ 5], 12, 1200080426); 
		c = ff(c, d, a, b, x[i+ 6], 17, -1473231341); 
		b = ff(b, c, d, a, x[i+ 7], 22, -45705983); 
		a = ff(a, b, c, d, x[i+ 8], 7 , 1770035416); 
		d = ff(d, a, b, c, x[i+ 9], 12, -1958414417); 
		c = ff(c, d, a, b, x[i+10], 17, -42063); 
		b = ff(b, c, d, a, x[i+11], 22, -1990404162); 
		a = ff(a, b, c, d, x[i+12], 7 , 1804603682); 
		d = ff(d, a, b, c, x[i+13], 12, -40341101); 
		c = ff(c, d, a, b, x[i+14], 17, -1502002290); 
		b = ff(b, c, d, a, x[i+15], 22, 1236535329); 
		a = gg(a, b, c, d, x[i+ 1], 5 , -165796510); 
		d = gg(d, a, b, c, x[i+ 6], 9 , -1069501632); 
		c = gg(c, d, a, b, x[i+11], 14, 643717713); 
		b = gg(b, c, d, a, x[i+ 0], 20, -373897302); 
		a = gg(a, b, c, d, x[i+ 5], 5 , -701558691); 
		d = gg(d, a, b, c, x[i+10], 9 , 38016083); 
		c = gg(c, d, a, b, x[i+15], 14, -660478335); 
		b = gg(b, c, d, a, x[i+ 4], 20, -405537848); 
		a = gg(a, b, c, d, x[i+ 9], 5 , 568446438); 
		d = gg(d, a, b, c, x[i+14], 9 , -1019803690); 
		c = gg(c, d, a, b, x[i+ 3], 14, -187363961); 
		b = gg(b, c, d, a, x[i+ 8], 20, 1163531501); 
		a = gg(a, b, c, d, x[i+13], 5 , -1444681467); 
		d = gg(d, a, b, c, x[i+ 2], 9 , -51403784); 
		c = gg(c, d, a, b, x[i+ 7], 14, 1735328473); 
		b = gg(b, c, d, a, x[i+12], 20, -1926607734); 
		a = hh(a, b, c, d, x[i+ 5], 4 , -378558); 
		d = hh(d, a, b, c, x[i+ 8], 11, -2022574463); 
		c = hh(c, d, a, b, x[i+11], 16, 1839030562); 
		b = hh(b, c, d, a, x[i+14], 23, -35309556); 
		a = hh(a, b, c, d, x[i+ 1], 4 , -1530992060); 
		d = hh(d, a, b, c, x[i+ 4], 11, 1272893353); 
		c = hh(c, d, a, b, x[i+ 7], 16, -155497632); 
		b = hh(b, c, d, a, x[i+10], 23, -1094730640); 
		a = hh(a, b, c, d, x[i+13], 4 , 681279174); 
		d = hh(d, a, b, c, x[i+ 0], 11, -358537222); 
		c = hh(c, d, a, b, x[i+ 3], 16, -722521979); 
		b = hh(b, c, d, a, x[i+ 6], 23, 76029189); 
		a = hh(a, b, c, d, x[i+ 9], 4 , -640364487); 
		d = hh(d, a, b, c, x[i+12], 11, -421815835); 
		c = hh(c, d, a, b, x[i+15], 16, 530742520); 
		b = hh(b, c, d, a, x[i+ 2], 23, -995338651); 
		a = ii(a, b, c, d, x[i+ 0], 6 , -198630844); 
		d = ii(d, a, b, c, x[i+ 7], 10, 1126891415); 
		c = ii(c, d, a, b, x[i+14], 15, -1416354905); 
		b = ii(b, c, d, a, x[i+ 5], 21, -57434055); 
		a = ii(a, b, c, d, x[i+12], 6 , 1700485571); 
		d = ii(d, a, b, c, x[i+ 3], 10, -1894986606); 
		c = ii(c, d, a, b, x[i+10], 15, -1051523); 
		b = ii(b, c, d, a, x[i+ 1], 21, -2054922799); 
		a = ii(a, b, c, d, x[i+ 8], 6 , 1873313359); 
		d = ii(d, a, b, c, x[i+15], 10, -30611744); 
		c = ii(c, d, a, b, x[i+ 6], 15, -1560198380); 
		b = ii(b, c, d, a, x[i+13], 21, 1309151649); 
		a = ii(a, b, c, d, x[i+ 4], 6 , -145523070); 
		d = ii(d, a, b, c, x[i+11], 10, -1120210379); 
		c = ii(c, d, a, b, x[i+ 2], 15, 718787259); 
		b = ii(b, c, d, a, x[i+ 9], 21, -343485551); 
		a = safe_add(a, olda); 
		b = safe_add(b, oldb); 
		c = safe_add(c, oldc); 
		d = safe_add(d, oldd); 
	} 
	return rhex(a) + rhex(b) + rhex(c) + rhex(d); 
}

/* end : md5.js */

/* WPS 2.0 Spec */
/* 
 * Verify Key exists or not
 */

function isExist_var(obj){
	return ((get_by_id(obj) != null ) ? true : false); 
}

function getVal(obj){
	/* maybe need to justify obj type */
	return get_by_id(obj).value;
}

function wps_behavior(security, cipher, broadcast){

	if (broadcast) {
		get_by_id("wps_enable").value = 0;
		return true;
	}
	
	if (security.match(/wep/g)) {
		get_by_id("wps_enable").value = 0;
		return true;
	}

	if (security.match(/_psk/g) && cipher == "tkip") {
		get_by_id("wps_enable").value = 0;
		return true;
	}

	if (security.match(/_eap/g)) {			//WPA-Enterprise
		get_by_id("wps_enable").value = 0;
		return true;
	}

	return false;
}

function getNames(obj){
	var gnames = get_by_name(obj);
	if (gnames[0].checked == true && gnames[1].checked == false) {
		return false;
	} else {
		return true;
	}
}

function WPS(){
	var wlan0_en = isExist_var("wlan0_enable") ? getVal("wlan0_enable") : "-1";
	var wlan1_en = isExist_var("wlan1_enable") ? getVal("wlan1_enable") : "-1";

	var wlan0_sec = isExist_var("wlan0_security") ? getVal("wlan0_security") : "-1";
	var wlan1_sec = isExist_var("wlan1_security") ? getVal("wlan1_security") : "-1";

	var wlan0_cipher =  isExist_var("wlan0_psk_cipher_type") ? getVal("wlan0_psk_cipher_type") : "-1";
	var wlan1_cipher =  isExist_var("wlan1_psk_cipher_type") ? getVal("wlan1_psk_cipher_type") : "-1";

	if (wlan0_en == "1")
		wps_behavior(wlan0_sec, wlan0_cipher, getNames("wlan0_ssid_broadcast"));
	else if(wlan0_en == "0") 
		get_by_id("wps_enable").value = 0;

	if (wlan1_en == "1")
		wps_behavior(wlan1_sec, wlan1_cipher, getNames("wlan1_ssid_broadcast"));
	else if(wlan1_en == "0") 
		get_by_id("wps_enable").value = 0;
}       

function show_wordsEX(str1, str2, flag) {	
    flag ? show_words(str2) : show_words(str1);
}

// TEW-732 
// Objs class
function HASH_TABLE(){
   this.hash_table = new Array();
}

HASH_TABLE.prototype = {
	clear: function(){
	    this.hash_table = new Array();
	},

	get: function(key){
	    return this.hash_table[key];
	},

	put: function(key, value){
	    if (key == null || value == null) {
	        throw "NullPointerException {" + key + "},{" + value + "}";
	    }else{
	        this.hash_table[key] = value;
	    }
	},

	size: function(){
	    var size = 0;

	    for (var i in this.hash_table){
	        if (this.hash_table[i] != null){
	            size++;
	        }
	    }

	   return size;
	},

	isEmpty: function(){
	   return (parseInt(this.size()) == 0) ? true : false;
	}
}

function Dict(obj){
	this.dict = obj;
}

Dict.prototype = {
	get: function(key){
		return this.dict[key];
	}
}

function Addr_Obj(field_name, addr, is_network){
	this.field_name = field_name;	
	this.addr = addr;	
	this.is_network = is_network;
}

function Variable(field_name, var_value, min, max, is_even){
	this.field_name = field_name;
	this.var_value = var_value;
	this.min = min;
	this.max = max;
	this.is_even = is_even;
}

function RADIUS_SERVER(ip_field, port_field, secret_field, addr, port, shared_secret){
	this.ip_field = ip_field;
	this.port_field = port_field;
	this.secret_field = secret_field;
	this.addr = addr;	
	this.port = port;
	this.shared_secret = shared_secret;
}

// public functions
function get_by_id(id){
	with(document){
		return getElementById(id);
	}
}

function get_by_name(name){
	with(document){
		return getElementsByName(name);
	}
}

function get_xml_node(which_doc, which_id){
	return which_doc.getElementsByTagName(which_id)[0];
}

function get_node_value(which_doc, which_id){		
	var node = get_xml_node(which_doc, which_id);
	var node_value = "";
	
	if (node != null){
		if (node.nodeType != 3){	// NS6/Mozilla will treat space as an element, so we need to ingore it
			if (node.childNodes.length > 0){
				node_value = node.childNodes[0].nodeValue;	
			}
		}
	}
	
	return node_value;
}

function xmlhttp_getxml(which_one){
	var xml_request=new XMLHttpRequest();
	
	if (xml_request!=null){  
  		xml_request.open("GET",which_one,false);
  		xml_request.send(null);
	} else {
  		alert("Your browser does not support XMLHTTP.11");
  		return false;
	}
	return(xml_request);
}

function load_xml(which_one){
	var my_doc;
	
	if (window.ActiveXObject){	// code for IE
		my_doc = new ActiveXObject("Microsoft.XMLDOM");
		my_doc.async = false;
		my_doc.load(which_one);
	} else if (document.implementation && document.implementation.createDocument && document.implementation.createDocument.load){	// code for Mozilla, Firefox, Opera, etc.
		my_doc = document.implementation.createDocument("","",null);
		my_doc.async = false;
		my_doc.load(which_one);
	} else if(window.XMLHttpRequest){	//code for Apple Safari, Google Chrome, etc.
		my_doc=xmlhttp_getxml(which_one).responseXML;
	} else {
		alert('Your browser cannot handle this script');
	}
	
	return my_doc;
}

function key_handler(e){
	var which_key;

	if (document.all) {
		which_key = window.event.keyCode;
	} else {
		which_key = e.which;
	}

	if (which_key == 13){
		return; // do nothing
	}
}

function return_to_login(){
	location.href = 'home.htm';
}

function check_user_info(redirect_page){
	var which_page;

	if (redirect_page != null){		
		location.href = redirect_page;
		return 0;
	}

	return 1;
}

function timeup_to_login(){
	setTimeout('return_to_login()', 180000);
}

function check_wps_pin(pin){
	var sum = 0;
	var result = false;

	sum += 3 * (parseInt(pin / 10000000) % 10);
	sum += 1 * (parseInt(pin / 1000000) % 10);
	sum += 3 * (parseInt(pin / 100000) % 10);
	sum += 1 * (parseInt(pin / 10000) % 10);
	sum += 3 * (parseInt(pin / 1000) % 10);
	sum += 1 * (parseInt(pin / 100) % 10);
	sum += 3 * (parseInt(pin / 10) % 10);
	sum += 1 * (parseInt(pin / 1) % 10);

	if ((sum % 10) == 0){	// 0 : valid , others : invalid
		result = true;
	}

	return result;
}

function get_index_str(index){
    var str = "";

    switch(index){
        case 0:
            str = "1st";
            break;
        case 1:
            str = "2nd";
            break;
        case 2:
            str = "3rd";
            break;
        case 3:
            str = "4th";
            break;
    }

    return str;
}

function get_digit_number(num){
	if (num <= 9){
		return "0" + num;
	}

	return num;
}

function get_month(index){
	var str;
	var month = new Array(MON001, MON002, MON003, MON004, MON005, MON006, MON007, MON008, MON009, MON010, MON011, MON012);
	str = month[index];

	return str;
}

function replace_msg(msg){

	for (var i = 1; i < arguments.length; i++){
		msg = msg.replace("%s", arguments[i]);
	}

	return msg;
}

function check_integer(which_int, min, max){
	var temp_int = which_int.split(" ");

	if (temp_int.length > 1){
		return false;
	}

	if (isNaN(which_int) || which_int == ""){	// if it is not an integer
		return false;
	}

	if (which_int.charAt(0) == "0" && which_int.length > 1){	// when the value start with 0
		return false;
	}

	if (arguments.length == 3){
		if (parseInt(which_int) < min || parseInt(which_int) > max){	// if it is not in the range
			return false;
		}
	}

	return true;
}

function check_ip_range(order, my_obj, mask, checking_ip, is_broadcast){
	var which_ip = my_obj.addr[order];
	var temp_ip;
	var temp_msg;
	var start = 0;
	var end = 255;

	if(is_broadcast != "BROADCAST_IP_IGNORE"){
	if (order == 0){				// the checking range of 1st address
		start = 1;
	}

	if (mask[order] != 255){
		if (arguments.length == 4 && checking_ip != null){
			temp_ip = checking_ip[order];
		}else{
			temp_ip = which_ip;
		}

		if (parseInt(temp_ip) >= 0 && parseInt(temp_ip) <= 255){
			end = (~mask[order]+256);
			start = mask[order] & temp_ip;
			end += start;

			if (end > 255){
				end = 255;
			}
		}
	}

	if (order == 3){
		/* if the 1st, 2nd, 3rd ip address are the network address */
		if (((mask[0] | (~my_obj.addr[0]+256)) == 255) && ((mask[1] | (~my_obj.addr[1]+256)) == 255) && ((mask[2] | (~my_obj.addr[2]+256)) == 255)){
			if (!my_obj.is_network){	// if the address does not support to be the network address
				start += 1;
			}
		}

		/* if the 1st, 2nd, 3rd ip address are the broadcast address, the end range must be minus 1 */
		if (((mask[0] | my_obj.addr[0]) == 255) && ((mask[1] | my_obj.addr[1]) == 255) && ((mask[2] | my_obj.addr[2]) == 255)){
			end -= 1;
		}

		if (end == 0){	// when the 4th oct of subnet mask is 254, the end value will be zero
			end = 1;
		}
	}

	if (parseInt(which_ip) < start || parseInt(which_ip) > end){
		if (start != end){
			warning_msg(PMSG01,  get_index_str(order), my_obj.field_name, start, end);
		}else{
			temp_msg = replace_msg(PMSG02,  get_index_str(order), my_obj.field_name) + " " + start;
			alert(temp_msg);
		}
		return false;
	}
	}

	return true;
}

function check_IP(ip_address, msg_title){
	var ip_split;
	var re=/^(\d{1,3}\.){3}\d{1,3}$/gi;
	var chkflag=true;
	var ErrMsg=lang_obj.display("the") + " " + msg_title + " " + lang_obj.display("msg_124") + "!"
	if(ip_address.search(re)==-1){
		chkflag=false;
	}else{
		ip_split=ip_address.split(".");
		for(i=0;i<4;i++){
			if(ip_split[i]>255){
				chkflag=false;
				break;
			}
			if(i==3 && ip_split[i]>=255){
				chkflag=false;
				break;
			}
		}
	}
	if(!chkflag)
	alert(ErrMsg);
	return chkflag;
} 

function check_address(my_obj, mask_obj, ip_obj, is_broadcast){
	var ip = my_obj.addr;
	var count_bcast = 0;
	var mask;

	if (ip.length == 4){
		if (ip[0] == "0" && ip[1] == "0" && ip[2] == "0" && ip[3] == "0"){	// when ip is 0.0.0.0
			warning_msg(PMSG03, my_obj.field_name);
			return false;
		}else if ((parseInt(ip[0]) == 127) || (parseInt(ip[0]) >= 224 && parseInt(ip[0]) <= 239)){
			warning_msg(PMSG04, my_obj.field_name);
			return false;
		}else{		// when IP is not 0.0.0.0, checking range. Otherwise no need to check

			if (arguments.length > 1 && mask_obj != null){
				mask = mask_obj.addr;
			}else{
				mask = new Array(255,255,255,0);
			}

			for(var i = 0; i < ip.length; i++){
				if (!check_integer(ip[i])){
					warning_msg(PMSG05, get_index_str(i), my_obj.field_name);
					return false;
				}

				if (arguments.length == 3 && ip_obj != null){
					if (!check_ip_range(i, my_obj, mask, ip_obj.addr)){
						return false;
					}
				}else{
					if (!check_ip_range(i, my_obj, mask, null, is_broadcast)){
						return false;
					}
				}
			}
			for (var i = 0; i < 4; i++){	// check the IP address is a broadcast address or not

				if ((mask[i] | ip[i]) == 255){
					count_bcast++;
				}
			}

			/* broadcast check */
			if (count_bcast == 4){
				if(is_broadcast != "BROADCAST_IP_IGNORE"){
					warning_msg(PMSG06, my_obj.field_name);
					return false;
				}
			}

		}
	}else{	// if the length of ip is not correct, show invalid ip msg

		if (ip.length == 1 && ip[0] == ""){
			warning_msg(PMSG03, my_obj.field_name);
		}else{
			warning_msg(PMSG06, my_obj.field_name);
		}

		return false;
	}

	return true;
}

function check_routing_address(my_obj, mask_obj){
	var count_zero = 0;
	var ip = my_obj.addr;
	var mask;
	var allow_cast = false;

	if (ip.length == 4){
		// check the ip is not multicast IP (127.x.x.x && 224.x.x.x ~ 239.x.x.x)
		if (ip[0] == "0" && ip[1] == "0" && ip[2] == "0" && ip[3] == "0"){	// when ip is 0.0.0.0
			warning_msg(PMSG03, my_obj.field_name);
			return false;

		}else if ((parseInt(ip[0]) == 127) || (parseInt(ip[0]) >= 224 && parseInt(ip[0]) <= 239)){
			warning_msg(PMSG04, my_obj.field_name);
			return false;

		}else{		// when IP is not 0.0.0.0, checking range. Otherwise no need to check
				mask = mask_obj.addr;
				for(var i = 0; i < mask.length; i++){
					if (mask[i] != "255"){
						if (ip[i] != (mask[i] & ip[i])){
							warning_msg(PMSG05, get_index_str(i), my_obj.field_name);
							return false;
						}
					}
				}

				for(var i = 0; i < ip.length; i++){
					if (!check_integer(ip[i])){
						warning_msg(PMSG05, get_index_str(i), my_obj.field_name);
						return false;
					}

					if (!check_ip_range(i, my_obj, mask)){
						return false;
					}
				}
		}
	}else{	// if the length of ip is not correct, show invalid ip msg
		if (ip.length == 1 && ip[0] == ""){
			warning_msg(PMSG03, my_obj.field_name);
		}else{
			warning_msg(PMSG06, my_obj.field_name);
		}

		return false;
	}

	return true;
}

function check_routing_mask(my_mask){
	var temp_mask = my_mask.addr;

	if (temp_mask.length == 4){
		if (temp_mask[0] == "0" && temp_mask[1] == "0" && temp_mask[2] == "0" && temp_mask[3] == "0"){	// when ip is 0.0.0.0
			warning_msg(PMSG03, my_mask.field_name);
			return false;
		}

		for (var i = 0; i < temp_mask.length; i++){
			var mask;
			var range_msg;
			var in_range = false;
			var j = 0;

			if (!check_integer(temp_mask[i])){	// check the input value is integer and in well format
				warning_msg(PMSG05, get_index_str(i), my_mask.field_name);
				return false;
			}

			mask = parseInt(temp_mask[i]);
			if (i == 0){	// when it's 1st address
				j = 1;		// the 1st address can't be 0
			}

			for (; j < subnet_mask_value.length; j++){
				if (mask == subnet_mask_value[j]){
					in_range = true;
					break;
				}else{
					in_range = false;
				}
			}

			if (!in_range){
				range_msg = replace_msg(PMSG02, get_index_str(i), my_mask.field_name);

				for (var k = 0; k < subnet_mask_value.length; k++){
					if (i == 0 && k == 0){	// the 1st address cannot include 0
						continue;
					}

					range_msg += " " + subnet_mask_value[k];

					if (k < subnet_mask_value.length - 1){
						range_msg += ",";
					}
				}

				alert(range_msg);
				return false;
			}

			if ((i != 0) && (mask != 0)){ // when not the 1st range and the value is not 0
				if (parseInt(temp_mask[i-1]) != 255){  // check the previous value is 255 or not
					warning_msg(PMSG05, get_index_str(i), my_mask.field_name);
					return false;
				}
			}
		}
	}else{

		if (temp_mask.length == 1 && temp_mask[0] == ""){
			warning_msg(PMSG03, my_mask.field_name);
		}else{
			warning_msg(PMSG06, my_mask.field_name);
		}

		return false;
	}

	return true;
}

function check_subnet_mask(my_mask){
	var temp_mask = my_mask.addr;

	if (temp_mask.length == 4){
		if (temp_mask[0] == "0" && temp_mask[1] == "0" && temp_mask[2] == "0" && temp_mask[3] == "0"){	// when ip is 0.0.0.0
			warning_msg(PMSG03, my_mask.field_name);
			return false;
		}

		for (var i = 0; i < temp_mask.length; i++){
			var mask;
			var range_msg;
			var in_range = false;
			var j = 0;

			if (!check_integer(temp_mask[i])){	// check the input value is integer and in well format
				warning_msg(PMSG05, get_index_str(i), my_mask.field_name);
				return false;
			}

			mask = parseInt(temp_mask[i]);
			if (i == 0){	// when it's 1st address
				j = 1;		// the 1st address can't be 0
			}

			for (; j < subnet_mask_value.length; j++){
				if (mask == subnet_mask_value[j]){
					in_range = true;
					break;
				}else{
					in_range = false;
				}
			}

			if (i == 3 && parseInt(mask) == 255){	// when the last mask address is 255
				in_range = false;
			}

			if (!in_range){
				range_msg = replace_msg(PMSG02, get_index_str(i), my_mask.field_name);

				for (var k = 0; k < subnet_mask_value.length; k++){
					if (i == 0 && k == 0){	// the 1st address cannot include 0
						continue;
					}

					range_msg += " " + subnet_mask_value[k];

					if (k < subnet_mask_value.length - 1){
						if (i == 3 && k == subnet_mask_value.length - 2){ // the 4th address cannot include 255
							break;
						}
						range_msg += ",";
					}
				}

				alert(range_msg);
				return false;
			}

			if ((i != 0) && (mask != 0)){ // when not the 1st range and the value is not 0
				if (parseInt(temp_mask[i-1]) != 255){  // check the previous value is 255 or not
					warning_msg(PMSG05, get_index_str(i), my_mask.field_name);
					return false;
				}
			}
		}
	}else{

		if (temp_mask.length == 1 && temp_mask[0] == ""){
			warning_msg(PMSG03, my_mask.field_name);
		}else{
			warning_msg(PMSG06, my_mask.field_name);
		}

		return false;
	}

	return true;
}

function check_same_subnet(ip, mask, gateway){
	var temp_ip = ip.addr;
	var temp_mask = mask.addr;
	var temp_gateway = gateway.addr;

	for (var i = 0; i < temp_ip.length - 1; i++){
		if ((temp_ip[i] & temp_mask[i]) != (temp_gateway[i] & temp_mask[i])){
			return false;		// when not in the same subnet mask, return false
		}
	}

	return true;
}

function check_radius_server(radius, which_id){
	var addr_obj = new Addr_Obj(radius.ip_field, (radius.addr).split("."), false);
	var port_obj = new Variable(radius.port_field, radius.port, 1, 65534, false);

	if (!check_address(addr_obj)){
		return false;
	}

	if (!check_varible(port_obj)){
   	return false;
 	}

 	if (radius.shared_secret == ""){
 		warning_msg(PMSG07, radius.secret_field);
   	return false;
	}

	return true;
}

function check_multi_ports(which_error, which_ports){
	var port_array = which_ports.split(",");

	for (var i = 0; i < port_array.length; i++){
		var temp_ports = port_array[i].split("-");

		if (temp_ports.length > 2){
			warning_msg(PMSG08, port_array[i]);
			return false;
		}else if (temp_ports.length == 2){
			if (temp_ports[0] == "" || temp_ports[1] == ""){
				warning_msg(PMSG08, port_array[i]);
				return false;
			}
		}

		for (var j = 0; j < temp_ports.length; j++){
			var temp_varible = new Variable(which_error, temp_ports[j], 1, 65535, false);

			if (!check_varible(temp_varible)){
				return false;
			}
		}

		if (temp_ports.length == 2){
			if (parseInt(temp_ports[0]) >= parseInt(temp_ports[1])){
				warning_msg(PMSG09, port_array[i]);
				return false;
			}
		}
	}

	return true;
}

function check_multi_port_conflict(incoming_port, checking_port){
	var incoming_array = incoming_port.split(",");
	var checking_array = checking_port.split(",");

	for (var i = 0; i < incoming_array.length; i++){
		var temp_port = incoming_array[i].split("-");
		var start_port = 0;
		var end_port = 0;

		start_port = parseInt(temp_port[0]);

		for (var j = 0; j < checking_array.length; j++){
			var temp_checking_port = checking_array[j].split("-")
			var start_checking_port = parseInt(temp_checking_port[0]);
			var end_checking_port = 0;

			if (temp_checking_port.length == 2){	// if the checking port is in range
				end_checking_port = parseInt(temp_checking_port[1]);
			}

			if (temp_port.length == 1){	// when the incoming port only has one port value
				if (temp_checking_port.length == 1){	// when the checking port only has one port value
					if (start_port == start_checking_port){
						return true;
					}
				}else if (temp_checking_port.length == 2){ // when the checking port is in range, check the incoming port is in the range of the checking port or not
					if (start_checking_port <= start_port && end_checking_port >= start_port){
						return true;
					}
				}
			}else if (temp_port.length == 2){	// when the incoming port is in range
				end_port = parseInt(temp_port[1]);

				if (start_port <= start_checking_port && end_port >= start_checking_port){
					return true;
				}

				if (checking_array.length == 2){
					if (start_port <= end_checking_port && end_port >= end_checking_port){
						return true;
					}

					if (start_checking_port <= start_port && end_checking_port >= start_port){
						return true;
					}
				}
			}
		}
	}
	return false;
}

function check_conflict_virtual_server(server_list, checking_protocol, checking_port){

	for (var i = 0; i < server_list.length; i++){
		var obj = server_list[i];
		var protocol = obj.get("protocol");

		if (obj.get("server_enable") == "0"){
			continue;
		}

		if ((protocol == checking_protocol) || (protocol == "Both") || (checking_protocol == "Any")){

			if (check_multi_port_conflict(obj.get("public_port"), checking_port)){
				return false;
			}
		}
	}

	return true;
}

function check_conflict_application(application_list, checking_protocol, checking_port){

	for (var i = 0; i < application_list.length; i++){
		var obj = application_list[i];
		var firewall_protocol = obj.get("firewall_protocol");

		if (obj.get("rule_enable") == "0"){
			continue;
		}

		if ((firewall_protocol == checking_protocol) || (firewall_protocol == "ALL") || (checking_protocol == "Both")){

			if (check_multi_port_conflict(checking_port, obj.get("firewall_port"))){
				return false;
			}
		}
	}

	return true;
}

function check_conflict_remote_management(remote_management, checking_port){

	if (remote_management.get("remote_enable") == "1"){
		if (check_multi_port_conflict(remote_management.get("remote_port"), checking_port)){
			return false;
		}
	}

	return true;
}

function check_varible(obj){
	var temp_obj = (obj.var_value).split(" ");

	if (obj.var_value == ""){
		warning_msg(PMSG07, obj.field_name);
		return false;
	}else if ((temp_obj.length > 1) || (isNaN(obj.var_value)) || ((obj.var_value).indexOf(".") != -1)){
		warning_msg(PMSG10, obj.field_name);
		return false;
	}else if (parseInt(obj.var_value,10) < obj.min || parseInt(obj.var_value,10) > obj.max){
		warning_msg(PMSG11, obj.field_name, obj.min, obj.max);
		return false;
	}else if (obj.is_even && (parseInt(obj.var_value,10) % 2 != 0)){
		warning_msg(PMSG12, obj.field_name);
		return false;
	}

	return true;
}

function check_hex(data){
	data = data.toUpperCase();

	for (var i = 0; i < data.length; i++){
		var temp_char = data.charAt(i);

		if (!(temp_char >= 'A' && temp_char <= 'F') && !(temp_char >= '0' && temp_char <= '9')){
			return false;
		}
	}

	return true;
}

function check_ascii(data){

	for (var i = 0; i < data.length; i++){
		var temp_char = data.charCodeAt(i);

		if (temp_char < 32 || temp_char > 126){	// if the character is less than a space(0x20) or greater than ~(0x7F)
			return false;
		}
	}

	return true;
}

function check_space(data){
	var count = 0;
	var result = false;

	for (var i = 0; i < data.length; i++){
		var temp_char = data.charCodeAt(i);

		if (temp_char == 32){	// if the character is a space
			count++;
		}
	}

	if (count == data.length){	// when the checking data is all space
		result = true;
	}

	return result;
}

function hex_to_int(hex){
	var dec = 0;
	var result = 0;

	hex = hex.toUpperCase();
	dec = hex.charCodeAt(0);

	if ((dec >= 48) && (dec <= 57)){
		result = dec - 48;
	}else if ((dec >= 65) && (dec <= 70)){
		result = dec - 55;
	}

	return result;
}

function check_multicase_mac(mac, splinter){
	var temp_mac = mac.split(splinter);
	var nibble = hex_to_int((temp_mac[0]).charAt(1));	// get the last 4 bits of first byte
	var result = false;

	if ((nibble % 2) != 0){	// if the last bit of first byte is 1, it means this mac adddress is multicast
		result = true;
	}

	return result;
}

function check_mac(mac, splinter){
    var temp_mac = mac.split(splinter);
    var error = 0;

	if (temp_mac.length == 6){
		for (var i = 0; i < 6; i++){
	   		var temp_str = temp_mac[i];

			if (temp_str == "" || temp_str.length != 2){
	      		error = 1;	//return 1 means mac format error, it will show different message in GUI. ONLY for DHP-W306AV!
	      	}else{
	      		if (!check_hex(temp_str)){
	         		error = 2;
	       		}
	    	}

	    	if (error != 0){
	      		break;
	   		}
		}
	}else{
		error = 1;	//return 1 means mac format error, it will show different message in GUI. ONLY for DHP-W306AV!
	}

   return error;
}

function check_host_name(host_name, which_name){
	var count_numeric = 0;

	host_name = host_name.toUpperCase();	// chagne to uppercase for checking easier

	for (var i = 0; i < host_name.length; i++){
		var temp_char = host_name.charCodeAt(i);

		if (temp_char >= 48 && temp_char <= 57){	// if the char is between 0 ~ 9
			if (i == 0){	// if the first char is a number
				warning_msg(PMSG13, which_name);
				return false;
			}else{
				count_numeric++;
				continue;
			}
		}

		if (temp_char == 32 || temp_char == 45 || temp_char == 46){
			if (i == 0){	// if the first char is space(0x20), or hyphen(0x2D), or dot(0x2E)
				warning_msg(PMSG14, which_name);
				return false;
			}else if (i == host_name.length - 1){
				warning_msg(PMSG15, which_name);
				return false;
			}else if (temp_char == 46){	// if the current character is dot
				if (host_name.charAt(i+1) == "."){	// check the next character is a dot or not
					warning_msg(PMSG16, which_name);
					return false;
				}
			}
		}

		// if the char is not between "A" ~ "Z" or space(0x20) or hyphen(0x2D) or dot(0x2E)
		if ((temp_char < 65 && temp_char != 32 && temp_char != 45 && temp_char != 46) || (temp_char > 90)){
			warning_msg(PMSG17, which_name);
			return false;
		}
	}

	if (count_numeric == host_name.length){	// if the host name is all numeric, it's invalid
		warning_msg(PMSG18, which_name);
		return false;
	}

	return true;
}

function check_ip_order(start_ip, end_ip){
	var temp_start_ip = start_ip.addr;
	var temp_end_ip = end_ip.addr;

	for (var i = 0; i < temp_start_ip.length; i++){
		if (parseInt(temp_start_ip[i]) > parseInt(temp_end_ip[i])){
			return false;
		}
	}

	return true;
}

function is_ipv4_valid(ipaddr){
	var ip = ipv4_to_bytearray(ipaddr);
	if (ip == 0) {
		return false;
	}
	return true;
}

function ipv4_to_bytearray(ipaddr){
	var ip = ipaddr + "";
	var got = ip.match (/^\s*(\d{1,3})\s*[.]\s*(\d{1,3})\s*[.]\s*(\d{1,3})\s*[.]\s*(\d{1,3})\s*$/);
	if (!got) {
		return 0;
	}
	var a = [];
	var q = 0;
	for (var i = 1; i <= 4; i++) {
		q = parseInt(got[i],10);
		if (q < 0 || q > 255) {
			return 0;
		}
		a[i-1] = q;
	}
	return a;
}

function check_email(which_error, email_addr){

	if (!check_ascii(email_addr)){
		return;
	}

	if (email_addr == ""){
		warning_msg(PMSG07, which_error);
		return false;
	}

	//check email used by Regular Expressions 2010/12/10 Pin
	if (email_addr.search(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/) == -1){
		warning_msg(PMSG06, which_error);
		return false;
	}

	//Only check email format have included "@" & "." or not, and "@" can be the first word & "." can be the last word.

	/* with (email_addr){
		var apos=value.indexOf("@")
		var dotpos=value.lastIndexOf(".")
		if (apos < 1 || dotpos-apos < 2){
			msg_obj.warning_msg("PMSG06", which_error);
			return false
		}
	} */
	return true;
}

function set_mac_addr(mac, splinter){
	var temp_mac = mac.split(splinter);

	if (temp_mac.length == 6){
		for (var i = 1; i < 7; i++){
			get_by_id("mac" + i).value = temp_mac[i-1];
		}
	}
}

function copy_element_values(from, to){
	var from_obj;
	var to_obj

	from_obj = document.getElementById(from);
	to_obj = document.getElementById(to);

	if (from_obj){
		if (from_obj.tagName == "INPUT"){
			if (from_obj.type == "checkbox"){	// when input field is checkbox
				to_obj.checked = from_obj.checked;
				to_obj.defaultChecked = from_obj.defaultChecked;
			}else if (from_obj.type == "text" || from_obj.type == "password" || from_obj.type == "hidden"){	// when input field is text or password or textarea
				to_obj.value = from_obj.value;
				to_obj.defaultValue = from_obj.defaultValue;
			}else if (from_obj.type == "radio"){	// when input field is radio, for IE only
				from_obj = document.getElementsByName(from);
				to_obj = document.getElementsByName(to);

				for (var j = 0; j < from_obj.length; j++){
					to_obj[j].checked = from_obj[j].checked;
					to_obj[j].defaultChecked = from_obj[j].defaultChecked;
				}
			}
		}else if (from_obj.tagName == "SELECT"){
			to_obj.selectedIndex = from_obj.selectedIndex;

			for (var j = 0; j < from_obj.length; j++){
				to_obj.options[j].defaultSelected = from_obj.options[j].defaultSelected;
			}
		}else if (from_obj.tagName == "TEXTAREA"){
			to_obj.value = from_obj.value;
			to_obj.defaultValue = from_obj.defaultValue;
		}
	}else {	// when the input field is radio, for firefox
		from_obj = document.getElementsByName(from);
		to_obj = document.getElementsByName(to);

		for (var j = 0; j < from_obj.length; j++){
			to_obj[j].checked = from_obj[j].checked;
			to_obj[j].defaultChecked = from_obj[j].defaultChecked;
		}
	}
}

function get_checkbox_value(which_box){
	var obj = get_by_id(which_box);
	var which_value;

	if (obj.checked){
		which_value = obj.value;
	}else{
		if (obj.value == "1"){	// when the checkbox doesn't be checked, return the opposite value
			which_value = "0";
		}else if (obj.value == "0"){
			which_value = "1";
		}
	}

	return which_value;
}

function get_radio_value(which_radio){
    var obj = get_by_name(which_radio);

    for (var i = 0; i < obj.length; i++){
        if (obj[i].checked){
            return obj[i].value;
        }
    }

    return "";
}

function set_radio(which_radio, which_value, set_default){
	var obj = get_by_name(which_radio);

	if (set_default){	// clear the previous default checked
		for (var i = 0; i < obj.length; i++){
			obj[i].defaultChecked = false;
		}
	}

	for (var i = 0; i < obj.length; i++){
		if (obj[i].value == which_value){
			obj[i].checked = true;

			if (set_default){
				obj[i].defaultChecked = true;
			}
			break;
		}
	}
}

function set_selection(which_combo, which_value, set_default){
	var obj = get_by_id(which_combo);

	if (set_default){	// clear the previous default selected
		for (var i = 0; i < obj.options.length; i++){
			obj.options[i].defaultSelected = false;
		}
	}

	for (var i = 0; i < obj.options.length; i++){
		if (obj.options[i].value == which_value){
			obj.options[i].selected = true;
			if (set_default){
				obj.options[i].defaultSelected = true;
			}
			break;
		}
	}
}

function set_text(which_text, which_value, set_default){
	var obj = get_by_id(which_text);

	if(obj == null){
		return;
	}
	obj.value = which_value;

	if (set_default){
		obj.defaultValue = which_value;
	}
}

function disable_static_address(which_one){
	var conn_type = get_by_name(which_one + "_conn_type");

	get_by_id(which_one + "_ip_addr").disabled = conn_type[0].checked;
	get_by_id(which_one + "_subnet_mask").disabled = conn_type[0].checked;
	get_by_id(which_one + "_gateway").disabled = conn_type[0].checked;

	if(which_one != "static"){
		get_by_id("primary_dns").disabled = conn_type[0].checked;
	}
}

function disable_idle_time_out(which_one){
	var conn_mode = get_by_name(which_one + "_conn_mode");

	get_by_id(which_one + "_max_idle_time").disabled = !conn_mode[2].checked;
}

function disable_all_btn(is_disable){
	var input_objs = document.getElementsByTagName("input");

	if (input_objs != null){
		for (var i = 0; i < input_objs.length; i++){
			if (input_objs[i].type == "button" || input_objs[i].type == "submit"){
				input_objs[i].disabled = is_disable;
			}
		}
	}
}

function disable_all_items(is_disable){
	var input_objs = document.getElementsByTagName("input");
	var select_objs = document.getElementsByTagName("select");

	if (input_objs != null){
		for (var i = 0; i < input_objs.length; i++){
			input_objs[i].disabled = is_disable;
		}
	}

	if (select_objs != null){
		for (var i = 0; i < select_objs.length; i++){
			select_objs[i].disabled = is_disable;
		}
	}
}

function ascii_to_hex(ascii){
	var hex = "";

	for (var i = 0; i < ascii.length; i++){
		var dec = ascii.charCodeAt(i);
		var str = "";

		str = parseInt(dec / 16, 10);

		if (str > 9){
			str = String.fromCharCode(str + 55);
		}

		if ((dec % 16) > 9){
			str += String.fromCharCode((dec % 16) + 55);
		}else{
			str += (dec % 16) + "";
		}

		hex += str;
	}

	return hex;
}

function hex_to_ascii(hex){
	var ascii = "";

	for (var i = 0; i < hex.length; i += 2){
		var temp_hex = "0x" + hex.substring(i, i+2);
		ascii += String.fromCharCode(temp_hex);
	}

	return ascii;
}

function remove_array(which_array, index){
	var result = new Array();
	var count = 0;
	
	for (var i = 0; i < which_array.length; i++){
		if (i == index){	// when we find the obj we want to remove in which_array
			continue;		// don't copy to the result array
		}
		
		result[count++] = which_array[i];	// copy the obj to the result array
	}
	
	return result;
}

function change_color(table_name, row){
	var obj = get_by_id(table_name);
	
	for (var i = 1; i < obj.rows.length; i++){
		if (row == i){
			obj.rows[i].style.backgroundColor = "#FFFF00";
		}else{
			obj.rows[i].style.backgroundColor = "#DFDFDF";
		}
	}       
}

function change_wan_htm(index){
    var redirect_htm;

    switch(parseInt(index)){
        case 0:
            redirect_htm = "wan_dhcp.htm";
            break;
        case 1:
            redirect_htm = "wan_dhcp.htm";
            break;
        case 2:
            redirect_htm = "wan_poe.htm";
            break;
        case 3:
            redirect_htm = "wan_pptp.htm";
            break;
        case 4:
            redirect_htm = "wan_l2tp.htm";
            break;
    }

    location.href = redirect_htm;
}

function check_user_level(which_level){
	if (which_level == "user"){	// if the level is the user level

		is_submit = true;		// prevent users click the apply button
		disable_all_items(true);

		if (get_by_id("user_only")){
			get_by_id("user_only").style.display = "";
		}
	}
}

function check_is_same(database_obj, array_obj){
	var result = false;

	if (database_obj.length != array_obj.length){
		result = true;
	}else{
		for (var i = 0; i<database_obj.length; i++){
			if (database_obj[i].get("reserved_enable") == array_obj[i].get("reserved_enable")
			&& database_obj[i].get("reserved_name") == array_obj[i].get("reserved_name")
			&& database_obj[i].get("reserved_ip") == array_obj[i].get("reserved_ip")
			&& database_obj[i].get("reserved_mac") == array_obj[i].get("reserved_mac")){

				result = false;
			}else
				result = true;

			if (result){
				break;
			}
		}
	}
	return result;
}

function check_modified_settings(){
	var is_modified = false;
	var input_element;
	var select_element;

	input_element = document.getElementsByTagName("INPUT");

	for (var i = 0; i < input_element.length; i++){
		var obj = input_element[i];

		if (obj.type == "checkbox"){	// when input field is checkbox
			if (obj.checked != obj.defaultChecked){
				is_modified = true;
			}
		}else if (obj.type == "text" || obj.type == "password" || obj.type == "hidden"){	// when input field is text or password
			if (obj.value != obj.defaultValue){
				is_modified = true;
			}
		}else if (obj.type == "radio"){	// when input field is radio, for IE only
			var radio_obj = document.getElementsByName(obj.name);

			for (var j = 0; j < radio_obj.length; j++){
				if (radio_obj[j].checked != radio_obj[j].defaultChecked){
					is_modified = true;
					break;
				}
			}
		}

		if (is_modified){
			break;
		}
	}

	if (!is_modified){
		select_element = document.getElementsByTagName("SELECT");
		for (var i = 0; i < select_element.length; i++){
			var obj = select_element[i];

			for (var j = 0; j < obj.options.length; j++){
				var opt = obj.options[j];

				if (opt.defaultSelected){	// if this option is selected by default, check the current index is equal to this option
					if (j != obj.selectedIndex){	// if not, then this selection has been modified
						is_modified = true;
						break;
					}
				}

				if (is_modified){
					break;
				}
			}

			if (is_modified){
				break;
			}
		}
		if (!is_modified){
			if (arguments.length == 2){
				is_modified = check_is_same (arguments[0], arguments[1]);
			}
		}
	}
	return is_modified;
}

function check_is_changed(){
	var result = false;

	if (arguments.length == 2){
		result = check_modified_settings(arguments[0], arguments[1]);

	}else{
		result = check_modified_settings();
	}

	if (!result){
		return confirm(MSG43);
	}

	return result;
}

function check_change_text(which_text){
	var is_modified = false;
	var obj = get_by_id(which_text);

	if (obj.value != obj.defaultValue){
		is_modified = true;
	}

	return is_modified;
}

function check_change_selection(which_select){
	var is_modified = false;
	var obj = get_by_id(which_select);

	for (var i = 0; i < obj.options.length; i++){
		var opt = obj.options[i];

		if (opt.defaultSelected){	// if this option is selected by default, check the current index is equal to this option
			if (i != obj.selectedIndex){	// if not, then this selection has been modified
				is_modified = true;
				break;
			}
		}

		if (is_modified){
			break;
		}
	}

	return is_modified;
}

function check_change_radio(which_radio){
	var is_modified = false;
	var radio_obj = get_by_name(which_radio);
						
	for (var i = 0; i < radio_obj.length; i++){				
		if (radio_obj[i].checked != radio_obj[i].defaultChecked){
			is_modified = true;
			break;
		}
	}
	
	return is_modified;
}

function check_resip_order(reserved_ip,start_ip, end_ip){
	var temp_start_ip = start_ip.addr;
	var temp_end_ip = end_ip.addr;
	var temp_res_ip = reserved_ip.addr;
	var total1 = ip_num(temp_start_ip);
	var total2 = ip_num(temp_end_ip);
    var total3 = ip_num(temp_res_ip);

   if(total1 <= total3 && total3 <= total2){
        return false;
	}

	return true;
}

function ip_num(IP_array){
	var total1 = 0;

	if(IP_array.length > 1){
   		total1 += parseInt(IP_array[3],10);
	    total1 += parseInt(IP_array[2],10)*256;
	    total1 += parseInt(IP_array[1],10)*256*256;
	    total1 += parseInt(IP_array[0],10)*256*256*256;
	}

	return total1;
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function show_wizard(){
	window.open('wizard.htm','Wizard','width=530,height=450');
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

// Other functions
function warning_msg(which_str){
	var which_msg = which_str

	for (var i = 1; i < this.warning_msg.arguments.length; i++){
		which_msg = which_msg.replace("%s", arguments[i]);
	}
	alert(which_msg)
}

var key1_len_error = new Array("The length of Key1 must be 5 characters.",
							   "The length of Key1 must be 13 characters.",
							   "The length of Key1 must be 10 characters.",
							   "The length of Key1 must be 26 characters."
							   );
							   
var key2_len_error = new Array("The length of Key2 must be 5 characters.",
							   "The length of Key2 must be 13 characters.",
							   "The length of Key2 must be 10 characters.",
							   "The length of Key2 must be 26 characters."
							   );	
							   
var key3_len_error = new Array("The length of Key3 must be 5 characters.",
							   "The length of Key3 must be 13 characters.",
							   "The length of Key3 must be 10 characters.",
							   "The length of Key3 must be 26 characters."
							   );
							   
var key4_len_error = new Array("The length of Key4 must be 5 characters.",
							   "The length of Key4 must be 13 characters.",
							   "The length of Key4 must be 10 characters.",
							   "The length of Key4 must be 26 characters."
							   );
	
var illegal_key_error = new Array("Key1 is wrong, the legal characters are 0~9, A~F, or a~f.",
								  "Key2 is wrong, the legal characters are 0~9, A~F, or a~f.",
								  "Key3 is wrong, the legal characters are 0~9, A~F, or a~f.",
								  "Key4 is wrong, the legal characters are 0~9, A~F, or a~f."								 
								  );	
	
	
function get_key_len_msg(which_key){
	switch(which_key){
    	case 1 :
    		return key1_len_error;    		
    	case 2 :
    		return key2_len_error;    		
    	case 3 :
    		return key3_len_error;    		
    	case 4 :
    		return key4_len_error;    
	}
}
	
function get_length(){
    var wep_key_len = get_by_id("wep_key_len");
    var wep_key_type = get_by_id("wlan0_wep_display");       
	var length = parseInt(wep_key_len.value);
		
	if (wep_key_type.value == "hex"){
	    length *= 2;
	}
	return length;
}

function check_wep_key(){            	                        	
	var length = get_length();	
	var wep_def_key = get_by_name("wlan0_wep_default_key");
	var key_length = get_by_id("wep_key_len").selectedIndex;
	var wep_key_type = get_by_id("wlan0_wep_display").value;
	var key_len_msg;
	
	for (var i = 1; i < 5; i++){					
	    var key = get_by_id("key" + i +"_"+ key_num_array[key_length] +"_"+ wep_key_type).value;

	    if (wep_def_key[i-1].checked){
	        if (key == ''){
	            alert(msg[MSG10]);
		        return false;
	        }
	    }
	    
	    key_len_msg = get_key_len_msg(i);
	    	    
        if (key != ''){
            if (key.length < length){
                alert(show_key_len_error(key_len_msg, length));
                return false;
            }else{
            	if (wep_key_type == "hex"){	// check the key is hex or not
	            	for (var j = 0; j < key.length; j++){
	            		if (!check_hex(key.substring(j, j+1))){
	            			alert(illegal_key_error[i-1]);
	            			return false;
	            		}
	            	}
	            }
            }
        }           	  
	}                	                	
	
	return true;
}

function logout_UI(){
	$.get("logout.htm", function(){location.href = 'home.htm';});
}

function check_wpa_psk(){
	var pre_shared_key = get_by_id("pre_shared_key").value;

    if (pre_shared_key.length < 8){
    	warning_msg(MSG12);
    	return false;
    }else if (pre_shared_key.length > 63){	// check it's hex or not
		if (!check_hex(pre_shared_key)){
			warning_msg(MSG13);
			return false;
		}
    }
	return true;
}

function ssid_decode(key)
{
	var ssid = get_by_id(key).value;
	var ssid_tmp = "";
	for (var i = 0; i < ssid.length; i++) {
		if (encodeURI(ssid.charAt(i)) === "%C2%A0") {
			ssid_tmp += decodeURI("%20");
		} else {
			ssid_tmp += ssid.charAt(i);
		}
	}
	return ssid_tmp;
}

function ssid_decode2(key)
{
	var ssid = key;
	var ssid_tmp = "";
	for (var i = 0; i < ssid.length; i++) {
		if (encodeURI(ssid.charAt(i)) === "%C2%A0") {
			ssid_tmp += decodeURI("%20");
		} else {
			ssid_tmp += ssid.charAt(i);
		}
	}
	return ssid_tmp;
}

function check_DeviceName(tmp_hostName)
{
	var i;
	var error =false;
	var tmp_count=0;

	if (tmp_hostName.length <= 63){
		var tmp_stringlength = tmp_hostName.length - 1
		for(i = 0; i<tmp_hostName.length; i++) {
			var c = tmp_hostName.substring(i,i+1);
			if (("0" <= c && c <= "9")){
				tmp_count=tmp_count+1;
			}
			if((("0" <= c && c <= "9") || ("a" <= c && c <= "z") ||
					("A" <= c && c <= "Z") || (i!=0 && c=="-") &&
					(i!=tmp_stringlength && c=="-")) && 
					(tmp_count != tmp_hostName.length)) {
				continue;
			} else {
				alert(GW_LAN_DEVICE_NAME_INVALID);
				error= true;
				return error;
			}
		}
	} else {
		alert(GW_LAN_DEVICE_NAME_INVALID);
		error= true;
		return error;
	}
	return error;
}

function replace_special_char(src_str){
	var dest_src = "";
	
	for (var i = 0; i < src_str.length; i++){
		var ch = src_str.charAt(i);
		
		if (ch == '>'){
			dest_src += "&gt;";
		}else if (ch == '<'){
			dest_src += "&lt;";
		}else if (ch == ' '){
			dest_src += "&nbsp;";
		}else if (ch == '&'){
			dest_src += "&amp;";
		}else{
			dest_src += ch;
		}
	}
	
	return dest_src;
}

if( (location.pathname != "/home.htm") && (location.pathname != "/") )
{
	if(location.pathname.match("wizard_") != "wizard_")//Ed add for wizard will not time out
  	time_out(); // joe add for logout timeout
}

function disable_right_btn(){
	return false;
}

document.oncontextmenu = disable_right_btn;// disable the mouse's right button    
document.onkeypress = key_handler;

function wizard_do_cencel(){

	var is_def =  "<% getInfo("defaultVal"); %>";
	var redirect_url=document.getElementsByName("submit-url");
	
	if( is_def == "1" ){
		redirect_url[0].value="/login.htm";
	}else{
		redirect_url[0].value="/sta_device_info.htm";
	}  
	document.wizard_form.action="/boafrm/formWizardCancel";
	document.wizard_form.submit();
}

function AddBookmark(){
	// split according to ":"
	var mac_addr =  "<% getInfo("hwaddr"); %>".split(":");
	var deviec_name =  "<% getInfo("hostName"); %>";
	var http_web = "http://";		
	var web_url = http_web.concat(deviec_name, mac_addr[4], mac_addr[5]);
	var web_title= "TRENDnet AP Web Management";
	var isIE11 = !!navigator.userAgent.match(/Trident.*rv[ :]*11\./);
	isIE = navigator.userAgent.search("MSIE") > -1;
	isFirefox = navigator.userAgent.search("Firefox") > -1; 
	
	//if(isIE || isFirefox){
	if(isIE || isIE11){
		var addfavor = confirm(lang_obj.display('msg_007'));
		if (addfavor == true)	
		{
			if(isIE11)
				window.external.AddFavorite(web_url, web_title);	
			if(window.sidebar){//FireFox
				//FireFox not support bookmark
				//window.sidebar.addPanel(web_title, web_url,""); 
			}else if(window.external){  // IE
				window.external.AddFavorite(web_url, web_title);	
			}
		}
	}	

	if(submit_check == 0){
    submit_check = 1;
    javascript:document.forms[0].submit();
  }
  else if(submit_check == 1){
    return 0;  
  }
}

function validateNum(str)
{
  for (var i=0; i<str.length; i++) {
   	if ( !(str.charAt(i) >='0' && str.charAt(i) <= '9')) {
		alert(lang_obj.display("msg_107"));
		return false;
  	}
  }
  return true;
}

function check_mask(my_mask){
	var temp_mask = my_mask.addr;

	if (temp_mask.length == 4){
		for (var i = 0; i < temp_mask.length; i++){
			var which_ip = temp_mask[i].split(" ");
			var mask = parseInt(temp_mask[i]);
			var in_range = false;
			var j = 0;

			if (isNaN(which_ip) || which_ip == "" || which_ip.length > 1 || (which_ip[0].length > 1 && which_ip[0].substring(0,1) == "0")){
				alert(my_mask.e_msg[FIRST_IP_ERROR + i]);
				return false;
			}

			if (i == 0){
				j = 1;
			}

			for (; j < subnet_mask.length; j++){
				if (mask == subnet_mask[j]){
					in_range = true;
					break;
				}else{
					in_range = false;
				}
			}

			if (!in_range){
				alert(my_mask.e_msg[FIRST_RANGE_ERROR + i]);
				return false;
			}

			if (i != 0 && mask != 0){
				if (parseInt(temp_mask[i-1]) != 255){
					alert(my_mask.e_msg[INVALID_IP]);
					return false;
				}
			}

			if (i == 3 && parseInt(mask) >= 255){
				alert(my_mask.e_msg[FOURTH_RANGE_ERROR]);
				return false;
			}
		}
	}else{
		alert(my_mask.e_msg[INVALID_IP]);
		return false;
	}

	return true;
}

// substr_count
function substr_count (haystack, needle, offset, length)
{
    var pos = 0, cnt = 0;

    haystack += '';
    needle += '';
    if (isNaN(offset)) {offset = 0;}
    if (isNaN(length)) {length = 0;}
    offset--;

    while ((offset = haystack.indexOf(needle, offset+1)) != -1){
        if (length > 0 && (offset+needle.length) > length){
            return false;
        } else{
            cnt++;
        }
    }

    return cnt;
}

// test_ipv4
// Test for a valid dotted IPv4 address

function test_ipv4(ip)
{
   var match = ip.match(/(([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|255[0-5])\.){3}([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])/);
   return match != null;
}

// test_ipv6
// Test if the input is a valid ipv6 address.
function test_ipv6(ip)
{
  if(ip == "")
    return false;

  var items = ip.split(":");
  // ipv6 has 8 section separate by ":"
  if (items.length > 8) 
    return false;
    
  // Test for empty address
  if (ip.length<3)
		return ip == "::";

  // Check if part is in IPv4 format
  if (ip.indexOf('.')>0)
  {
        lastcolon = ip.lastIndexOf(':');

        if (!(lastcolon && test_ipv4(ip.substr(lastcolon + 1))))
            return false;
        // replace IPv4 part with dummy
        ip = ip.substr(0, lastcolon) + ':0:0';
  } 

  // Check uncompressed
  if (ip.indexOf('::')<0)
  {
    var match = ip.match(/^(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}$/i);
    return match != null;
  }

  // Check colon-count for compressed format
  if (substr_count(ip, ':'))
  {
    var match = ip.match(/^(?::|(?:[a-f0-9]{1,4}:)+):(?:(?:[a-f0-9]{1,4}:)*[a-f0-9]{1,4})?$/i);
    return match != null;
  } 

  // Not a valid IPv6 address
  return false;
}

//check domain name Add by Pan 20101004
function checkDomain(nname)
{
var mai = nname;
var val = true;

var dot = mai.lastIndexOf(".");
var dname = mai.substring(0,dot);
var ext = mai.substring(dot,mai.length);
	
if(dot>2 && dot<57)
{
	for(var j=0; j<dname.length; j++)
	{
	  var dh = dname.charAt(j);
	  var hh = dh.charCodeAt(0);
	  if((hh > 47 && hh<59) || (hh > 64 && hh<91) || (hh > 96 && hh<123) || hh==45 || hh==46)
	  {
		 if((j==0 || j==dname.length-1) && hh == 45)	
	  	 {
	 	  	 alert(lang_obj.display("msg_122"));
		      return false;
	 	 }
	  }
	  else	{
	  	 alert(lang_obj.display("msg_121"));
		 return false;
	  }
	}
}
else
{
 alert(lang_obj.display("msg_120"));
 return false;
}	

return true;
}

function get_text( cells )
{
  if ( cells.textContent != undefined )
  { return cells.textContent; }
  else
  { return cells.innerText; }
}

function encode_base64(psstr) {
   		return encode(psstr,psstr.length); 
}

function encode (psstrs, iLen) {
	 var map1="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
   var oDataLen = (iLen*4+2)/3;
   var oLen = ((iLen+2)/3)*4;
   var out='';
   var ip = 0;
   var op = 0;
   while (ip < iLen) {
      var xx = psstrs.charCodeAt(ip++);
      var yy = ip < iLen ? psstrs.charCodeAt(ip++) : 0;
      var zz = ip < iLen ? psstrs.charCodeAt(ip++) : 0;
      var aa = xx >>> 2;
      var bb = ((xx &   3) << 4) | (yy >>> 4);
      var cc = ((yy & 0xf) << 2) | (zz >>> 6);
      var dd = zz & 0x3F;
      out += map1.charAt(aa);
      op++;
      out += map1.charAt(bb);
      op++;
      out += op < oDataLen ? map1.charAt(cc) : '='; 
      op++;
      out += op < oDataLen ? map1.charAt(dd) : '='; 
      op++; 
   }
   return out; 
}

function check_vaild_url_address(urlAddr){
	var expression = /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
	var regex = new RegExp(expression);
	
	if (urlAddr.match(regex))
		return 1;
	else 
		return 0;
}

function get_repeater_mode(){
	var rpt_mode_enable = 0;
	
	var set_wlanidx_2g = "<% getIndex("set_wlanindex","1"); %>";
  if(parseInt(<% getIndex("repeaterEnabled"); %>)){
		rpt_mode_enable += 1;
	}
  var set_wlanidx_5g = "<% getIndex("set_wlanindex","0"); %>";
  if(parseInt(<% getIndex("repeaterEnabled"); %>)){
		rpt_mode_enable += 1;
	}
	
	return rpt_mode_enable;
}

function ntohdw(v)
{
	var tmp_v = v.split(".");
	var result_v = 0;
	
	for(var i = 0; i < 4; i++){
		result_v += tmp_v[i]*Math.pow(256, 3-i);
	}

	return result_v;
}

function check_client_range(start, end, ip, mask)
{
	var ip_t = ntohdw(ip);
	var mask_t = ntohdw(mask);
	var end_t = ntohdw(end);
	var start_t = ntohdw(start);
	var diff = end_t - start_t;
		
	if (diff <= 0 || diff > 256*3 || (ip_t&mask_t) != (start_t&mask_t) || (ip_t&mask_t) != (end_t&mask_t) ) {
		return false;
	}
	if((ip_t>=start_t)&&(ip_t<=end_t)) {
		return false;
	}
	
	return true;
}

function check_pwd_length(pwd)
{
	var length_min = 8;
	var length_max = 16;
	
	if(pwd.length < length_min || pwd.length > length_max)
		return false;
	
	return true;
}