	rgdb -A /etc/templates/dhcp_mc2uc.php
	sh /var/run/__dhcp_mc2uc.sh

