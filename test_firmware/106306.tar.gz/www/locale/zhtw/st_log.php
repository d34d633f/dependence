<?
$m_context_title	= "檢視Log";

$m_first_page	= "第一頁";
$m_last_page	= "最後一頁";
$m_previous	= "上一頁";
$m_next		= "下一頁";
$m_clear	= "清除";

$m_time		= "時間";
$m_type		= "優先順序";//"Type";
$m_message	= "訊息";
$m_page		= "頁";
$m_of		= "关于";
?>
