<?
$m_menu_upgrade_fw = "<font face=\"Arial\" size=2>在這個過程中".
 					 "請</font><font face=\"Arial\" color=\"red\" size=2><b>不要將您的設備".
					 "關機</b></font><font face=\"Arial\" size=2>。可能會造成".
					 .query("/sys/hostname").
					 "實體設備的損壞。 (假如您的網頁瀏覽器並沒有自動更新網頁,請點選更新的按鍵。)</font>";
					 
$m_upload_fw = "上傳韌體中...";
$m_verify_fw = "核對韌體中...";
$m_upgrad_device = "升級韌體中...";
$m_reboot_device = "設備重新開機中...";

$a_upgrade_fw_fail_msg = "韌體更新失敗,請重新載入韌體再試一次。";

?>
