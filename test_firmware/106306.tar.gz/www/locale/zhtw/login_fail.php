<?
$m_html_title	= "登入失敗";
$m_context_title= "登入失敗";
if($timeout!=1)
{
	$m_context	= "使用者名稱與密碼錯誤。";
}
else
{
$m_context	= "Reply from Radiusclient Timeout.";
}
$m_button_dsc	= "請再登入一次";
?>
