<?
$m_context_title = "無線入侵防護";
$m_b_detect = "偵測";
$m_ap_list_title = "AP清單";
$m_type = "型態";
$m_band = "頻帶";
$m_channel = "CH";
$m_ssid = "服務設定識別碼";
$m_mac = "基礎服務設定識別碼";
$m_last_seem = "最後一次見到";
$m_status = "狀態";
$m_b_valid = "設定為有效";
$m_b_neighborhood = "設定為鄰域";
$m_b_rogue = "設定為破壞者";
$m_b_new = "設定為New";
$m_all_valid = "將所有新的存取點標示成有效存取點";
$m_all_rogue = "將所有新的存取點標示成破壞存取點";
$m_valid = "有效";
$m_neighborhood = "鄰域";
$m_rogue = "破壞者";
$m_new = "新";
$m_a = "A";
$m_b = "B";
$m_g = "G";
$m_n = "N";
$m_days = "天";
$m_all = "全部";
$m_up = "上";
$m_down = "下";
$m_wireless_band = "Wireless Band";
$m_band_2_4G = "2.4GHz";
$m_band_5G = "5GHz";

$a_max_list = "這類清單的數目上限為64!\\n";
$a_can_add_num = "您可以加入";
$a_entry = "輸入";
$a_no_click = "沒有輸入被選取！";
?>
