<?
$tool_admin = "行政設定";
$tool_fw = "韌體與SSL認證上傳";
$tool_config = "組態檔案";
$tool_sntp = "時間與日期";
$logout_msg = "&nbsp;&nbsp;按<b>這裡</b>之後，目前的瀏覽軟體連線將中斷。<br>&nbsp;&nbsp;";
?>
