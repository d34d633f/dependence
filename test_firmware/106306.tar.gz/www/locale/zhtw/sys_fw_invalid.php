<?
$m_html_title="錯誤韌體Image";
$m_context_title="錯誤韌體Image";
$m_context="選擇的檔案不是image檔案。";
$m_button_dsc=$m_continue;
?>
