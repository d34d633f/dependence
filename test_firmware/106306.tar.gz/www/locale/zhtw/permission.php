<?
$m_context_title	="&nbsp";
$m_context		="僅有<strong>管理權限</strong>的帳號才可以更改設定。";
$m_button_dsc		=$m_continue;
?>
