var in_ipaddr='Incorrect IP Address';
var in_subnet='Incorrect IP Subnet Mask';
var in_gateway='Incorrect Default Gateway';
var in_ip255='LAN static IP settings are invalid. You cannot use 0.0.0.0 or 255.255.255.255.';
var in_ip127='LAN static IP settings are invalid. You cannot use 127.0.0.1.';
var in_ip123='The IP Address does not have a valid format.\n Please use the following format: 123.123.123.123';
var in_ip254='The latest number of IP Address can only consist out of numbers in the range 1-254';
var in_ipdots='The IP Address can only consist out of numbers in the range 0-255 (separated by dots)';
var in_sub123='The Network Mask does not have a valid format. Please use the following format: 123.123.123.123';
var in_sub255='The Network Mask can only consist out of numbers in the range 0-255 (separated by dots)';
var in_subleft='The netmask must represent a contiguous number of bits with the leftmost bit 1\n';
var in_sub123='The Default Gateway does not have a valid format. Please use the following format: 123.123.123.123';
var in_gate255='The Default gateway settings are invalid. You cannot use 0.0.0.0 or 255.255.255.255.';
var in_gatedots='The Default Gateway can only consist out of numbers in the range 0-255 (separated by dots)';
var in_gatecon='LAN gateway is not configured correctly.';
same_subnet_ip_gtw="IP Address and Gateway IP Address must be in the same subnet!\n";
changelanip="Do you want to change your IP to "
changelanip_auto="Do you want to change your IP address to Dynamically ? if it is not found, default value is changed to be 192.168.1.250 !"
changelanip_renew="\nYou should release and renew PC's IP address after click  \"Apply\""
invalid_gateway="Invalid Gateway IP Address, please enter again!\n";
invalid_primary_dns="Invalid Primary DNS Address, please enter again!\n";
invalid_second_dns="Invalid Secondary DNS Address, please enter again!\n";
same_lan_wan_subnet="LAN IP Address and WAN IP Address must not be in the same subnet!\n";
same_lan_wan_ip="WAN IP Address should not be the same with LAN IP Address!\n";

invalid_ip="Invalid IP Address, please enter again!\n";
invalid_mask="Invalid Subnet Mask, please enter again!\n";

var coun_select='WARNING: Selecting the incorrect region may result in a violation of applicable law. Do you agree to act in accordance with these settings?';
var wpa_phrase='The PSK Passphrase can only be fit the value between 8~63 characters. Over these range (8~63) is against the WiFi WPA rule .';
var gene_phrase="You should input 1 to 32 ASCII characters to generate 4 keys."
ssid_null="SSID can't be blank!";
ssid_not_allowed=" is not allowed to be a ssid!"
establish_connection="To re-establish the connection, please click the Connect button."
//change password
newpas_null="New Passwords can't be blank!";
oldpas_notmatch="The current password is incorrect!";
newpas_notmatch="New Passwords do not match!";
oldnewpas_same="New Passwords is the same as the current password!";
//qos
var select_serv_edit="Please select a service to edit. ";
var no_serv_edit="There is no service to edit. ";
var select_serv_del="Please select a service to delete. ";
var no_serv_del="There is no service to delete. ";
var select_reservip_edit="Please select an address reservation item to edit. ";
var no_reservip_edit="There is no address reservation item to edit. ";
var select_reservip_del="Please select an address reservation item to delete. ";
var no_reservip_del="There is no address reservation item to delete. ";
var device_name_null="Device name can not be NULL!"
var device_name_error="Invalid Device Name!"
qos_policy_name_null="The name of QoS Policy can not be blank!"
qos_mac_apply="Please select a MAC in MAC Device List!"
qos_policy_name_dup="Duplicate policy name!"
qos_port_used="The port is used already!"
qos_ether_port_dup="Duplicate Ethernet LAN Port!"
invalid_port="Invalid Starting/Ending Port vlaue.";
invalid_port_used="The specified port(s) are being used by other configurations. Please check your configurations of Remote Management, Port Forwarding, Port Triggering, UPnP Port Mapping table, RIP, and Internet connection type."
invalid_start_port="Invalid Starting Port value";
invalid_end_port="Invalid Ending Port value"
end_port_greater="Ending Port value should be greater or equal to Starting Port value.";
mac_dup="Duplicate MAC Address!"
device_name_dup="Duplicate Device Name!"
var invalid_mac='Invalid MAC Address!';
var enter_full_mac='Please enter a full MAC Address.';
var allowed128='Maximum Access Control Entries allowed 128';
var blocked128='Maximum Access Control Entries blocked 128';
var duplicate_allowed_mac='Duplicate Mac Address! This Mac Address has existed on allow list';
var duplicate_blocked_mac='Duplicate Mac Address! This Mac Address has existed on block list.';

var in_passwd3='Incorrect password.\n\nPassword must consist of at least 3 characters';
var in_passwd16='Incorrect password.\n\nPassword must consist of at most 16 characters';
var in_passwdmatch='Incorrect password.\n\nPasswords do not match.'

var in_upgrade='The filename is NULL.Locate and select the update file from your hard disk,plsase!';


var wds_reboot_wpapsk='This will reboot the AP and enable WPA-PSK over WDS!';
var wds_reboot_wpa2psk='This will reboot the AP and enable WPA2-PSK over WDS!';
var wds_reboot_wpapsk2='This will reboot the AP and enable WPA-PSK/WPA2-PSK over WDS!';
var in_ip_first='LAN static IP settings are invalid. The first number of IP Address can not be 0, 255 or 127.';

var duplicate_multi_mac='Duplicate Mac Address! This Mac Address has existed on list';

//email
error_email_addr="Error: Invalid E-Mail address!"
choose_time_daily="Please choose time period when you set daily schedule"
choose_am_pm_daily="Please choose [a.m.] or [p.m.] when you set daily schedule"
choose_a_day="Please choose a day when you set weekly schedule"
choose_time_weekly="Please choose time period when you set weekly schedule"
choose_am_pm_weekly="Please choose [a.m.] or [p.m.] when you set weekly schedule"
//wds
invalid_mac_basic_station="Invalid Base Station MAC Address!"
mac_basic_station_null="Please input Base Station MAC Address!"
invalid_mac1="Invalid Repeater MAC Address 1"
invalid_mac2="Invalid Repeater MAC Address 2"
invalid_mac3="Invalid Repeater MAC Address 3"
invalid_mac4="Invalid Repeater MAC Address 4"
all_mac_null="Please input Repeater MAC Address!"
invalid_server_used="You can not edit this Address Reservation. It has been used by others!";
invalid_wds_ip="To operate as a Repeater, please setup a new IP address of this device first, then you can configure this device via this new IP address x.x.x.x in the future."

//backup setting
filename_null="Filename can not be blank!"
not_cfg="Please assign correct file. (File format is \"*.cfg\")"
invalid_filename="Invalid file name!"
ask_for_restore="Warning!\nRestoring settings from a config file will erase all of the current settings.\nAre you sure you want to do this?"

//wait for download
wait_upg_head="Firmware Update Assistant"
wait_serv="Firmware Updating, Download Control File ..."
wait_serv1="Attempting to connect to 1st Netgear Server.  Please Wait..."
wait_serv2="Attempting to connect to 2nd Netgear Server.  Please Wait..."
wait_serv3="Attempting to connect to 3rd Netgear Server.  Please Wait..."
wait_cancel="Firmware Updateis Canceled. "
download_confile_fail="Unable to download firmware from Netgear server. Please check your internet connection."
wait_return="This page will automatically return to the previous page in a few seconds..."
wait_new_version="A New Firmware Version is Found. Do You Want to Update to the New Version Now?"
no_new_version="No New Firmware Version Available"
wait_download="The Router is Downloading the New Version Now. Please Wait..."
upg_wanlink_error="WAN link is not up. Please check your Internet port connection. "
upg_download_error="Unable to download firmware from Netgear server. Please check your internet connection."
upg_upload_error="Fail to Upload Image."
upg_control_error="Error in Auto Update Control File, Contact Netgear !"
wait_string="<tr><td>Please wait a moment...</td></tr>"
line_string="<tr><td colspan=2><img src=/liteblue.gif width=100% height=12></td></tr>"
failure_head="Failure"
old_ver="Current Version"
new_ver="New Version"
download_image="The Extender is Downloading the New Version Now. Please Wait..."
download_image_fail="Fail to Upload Image."

//wlan_acl
device_name_dup="Duplicate Device Name!"
mac_dup="Duplicate MAC Address!"
acl_length_64="Max number of rules reached"

//upgrade
not_img="Please assign the correct file. (The file format is \"*.img\")"
error_module="Error update file module name! (Module name is \"WPN824EXT\") "
error_firm_ver="Error firmware version!"
upgrade_1="Warning! You are trying to download a non NA (world wide) firmware which is different from the NA firmware you had. Do you still want to continue?"
upgrade_2="Warning! You are trying to download a GR firmware with German language which is different from the NA firmware with English you had. Do you still want to continue?"
upgrade_3="Warning! You are trying to download a JP firmware with Japanese language which is different from the NA firmware with English you had. Do you still want to continue?"
error_firm_reg="Error firmware region!"
upgrade_4="Warning! You are trying to download a GR firmware with German language which is different from the world wide firmware with English you had. Do you still want to continue?"
upgrade_5="Warning! You are trying to download a JP firmware with Japanese language which is different from the world wide firmware with English you had. Do you still want to continue?"
upgrade_6="Warning! You are trying to download a NA firmware which is different from the non NA (world wide) firmware you had. Do you still want to continue?"
//upgrade_7="Warning! You are trying to download a world wide firmware with English GUI! After installing this Firmware the Router GUI will be in English! Do you still want to continue?"
upgrade_7="Warning! You are trying to download a non FR (world wide) firmware which is different from the FR firmware you had. Do you still want to continue?"
upgrade_8="Warning! You are trying to download a GR firmware with German language which is different from the FR firmware with France language you had. Do you still want to continue?"
upgrade_9="Warning! You are trying to download a NA firmware with English GUI which is different from the FR firmware with France language you had. Do you still want to continue?"
upgrade_10="Warning! You are trying to download a world wide firmware with English GUI! After installing this Firmware the Router GUI will be in English! Do you still want to continue?"
upgrade_11="Warning! You are trying to download a NA firmware with English GUI which is different from the GR firmware with German language you had.\nPlease note that the usage of this Firmware may cause technical limitation like e.g. a reduction of available Wireless-Channel!\n Do you still want to continue?"
upgrade_12="Warning! You are trying to download a JP firmware with Japanese language which is different from the GR firmware with German language you had.\n Please note that the usage of this Firmware may cause technical limitation like e.g. a reduction of available Wireless-Channel!\n Do you still want to continue?"
upgrade_13="Warning! You are trying to download a FR firmware with France language which is different from the NA firmware with English you had. Do you still want to continue?";
upgrade_14="Warning! You are trying to download a FR firmware with France language which is different from the world wide firmware with English you had. Do you still want to continue?";
oldver1="Warning!You are trying to download a firmware with version V"
oldver2=" is older than the firmware with V"
oldver3= " you had. Do you still want to continue?"
upgrade_turnoff_auto="The firmware update can contain valuable enhancements.\nAre you sure you want to turn off automatic checking?\nAfter you turn it off, you can re-enable it through the Wireless Extender Update page.";

//wds
rts_null="RTS Threshold value is NULL."
fragmentation_null="Fragmentation Length value is NULL."
rts_range="RTS Threshold value is out of range [1 - 2347]."
fragmentation_range="Fragmentation Length value is out of range [256 - 2346]."
wds_not_wpa="The wireless security options \"WPA-PSK[TKIP]\",\"WPA2-PSK[AES]\" and \"WPA-PSK[TKIP]+WPA-PSK[AES]\" are not available if you enable Wireless Repeating Function.\nPlease change your security option before you enable Wireless Repeating Function. "
wds_auto_channel="Wireless repeating function cannot be used with Auto channel.\nPlease change your channel settings before you enable Wireless Repeating Function. "


//welcome_alert
passphrase_short8="Insufficient passphrase length, should be minimum of 8 characters long."
passphrase_long63="Passphrase is too long, the maximum length should be 63 characters."
//welcome
welcome_setup="Would you like help setting up your wireless network?"
welcome_setup_yes="Yes, guide me through the options. "
welcome_setup_no="No, I am an advanced user. Take me to the browser interface to perform manual configuration. The default username is admin and the default password is password.";
ca_05_SSID_h="Assign a name to your wireless network."
ca_05_SSID_p="The name that you assign to your wireless network is also called an SSID. This name uniquely identifies your network and when you connect additional devices to your network, you will need to enter your SSID.  <strong>Note:</strong> Your SSID is case sensitive. "
ca_05_SSID_name="Name for your wireless network (SSID):"
ca_06_wanwirelessSecurity_h1="Do you want to add security to your wireless network?"
ca_06_wanwirelessSecurity_p="Adding security to your wireless network can protect against unauthorized access to your wireless network.  "
ca_06_wanwirelessSecurity_yes="Yes, guide me through the settings. "
ca_06_wanwirelessSecurity_no="No, I will set this up later. "
ca_07_SecurityOptions_h1="What kind of wireless security do you want to use? "
ca_07_SecurityOptions_p="Adding security to your wireless network can protect against unauthorized access to your wireless network.   "
ca_07_SecurityButton="<strong>Note:</strong>  For a list of wireless security supported by your adapter, refer to your adapter documentation."
ca_08_WPA_PassPhrase_h1_WPA1WPA2="Create a passphrase for WPA-PSK(TKIP) + WPA2-PSK(AES) wireless security"
ca_08_WPA_PassPhrase_h1_psk="Create a passphrase for WPA-PSK wireless security"
ca_08_h1_aes="Create a passphrase for WPA2-PSK(AES) wireless security"
ca_10_maxkey="Maximum Key length is "
ca_10_char=" characters."
ca_13_Change_h1="The Wireless Extender's Administration Screens"
ca_13_Change_p="This wireless extender includes a security feature that restricts access to the wireless extender's administration screens. Your wireless extender was manufactured with a default login and password: "
loginname_not_allowed="Invalid login name!"
password_not_allowed="Invalid password"
servname_not_allowed="Invalid service name"
acname_not_allowed="Invalid account name"
doname_not_allowed="Invalid domain name"
//wep
wep_generate="You must generate the key!"
wep_128="The 128bit selection only allows 26 hexadecimals value!"
wep_64="The 64bit selection only allows 10 hexadecimals value!"
wep_null="WEP passphrase can't be blank"

pool_null="The Pool Interval can not be null."
rang_pool="The valid rang of \"Pool Inteval\" is between 5 and 86400 seconds. "

function isIE()
{
    var browser = new Object();
    browser.version = parseInt(navigator.appVersion);
    browser.isNs = false;
    browser.isIe = false;
    if(navigator.appName.indexOf("Netscape") != -1)
        browser.isNs = true;
    else if(navigator.appName.indexOf("Microsoft") != -1)
        browser.isIe = true;

    if(browser.isNs)
        return false;
    else if (browser.isIe)
        return true;
}
function loadhelp(fname,anchname)
{
        if ((loadhelp.arguments.length == 1 ) || (anchname == "" ))
                top.helpframe.location.href="/h"+fname+".html";
        else
                top.helpframe.location.href="/h"+fname+".html#" + anchname;
   	return;
}
function load_default(step)
{
    if (parent.frames['IA_menu']){
        for(var i=1;i<=5;i++){
            eval("parent.IA_menu.IA_menu_"+i).className ="left_nav_headers";
        }
        eval("parent.frames[\'IA_menu\'].IA_menu_"+step).className ="left_nav_headers_current_state";
    }
}
function isValidHex(each_char)
{
    var macVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9","A", "B", "C", "D", "E", "F", "a", "b", "c", "d", "e", "f");
        var len = macVals.length;
        var i = 0;
        var ret = false;
        for ( i = 0; i < len; i++ )
        if ( each_char == macVals[i] ) break;
        if ( i < len )
                ret = true;
                return ret;
}
function isValidChar_space(each_char)
{
    if( each_char < 32 || each_char > 127)
        return false;
}
function isValidChar(each_char)
{
    if( each_char < 33 || each_char > 126)
        return false;
}
function goTestApply()
{
    var winoptions = "width=640,height=480,menubar=yes,toolbar=yes,status=yes,location=yes,resizable=yes";
    if( run_test == "test")
        window.open('testpage.html',null,winoptions);
}
function getkeya(e)
{
var keycode;
  if (window.event) 
  {
    keycode = window.event.keyCode;
    if (((keycode>47) && (keycode<58))||(keycode==8)||((keycode>64) && (keycode<71))||((keycode>96) && (keycode<103))) { return true; }
    else return false;
  }
  else if (e) 
  {
    keycode = e.which;
    if (((keycode>47) && (keycode<58))||(keycode==8)||(keycode==0)||((keycode>64) && (keycode<71))||((keycode>96) && (keycode<103))) { return true; }
    else return false;
  }
  else 
  {
    return true;
  }
}
function isValidMac(digit)
{
        var macVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9","A", "B", "C", "D", "E", "F", "a", "b", "c", "d", "e", "f",":");
        var len = macVals.length;
        var i = 0;
        var ret = false;
        for ( i = 0; i < len; i++ )
        if ( digit == macVals[i] ) break;
        if ( i < len )
                ret = true;
                return ret;
}
function change_sec_to_time(uptime)
{
        var sec=uptime;
        var sec=parseInt(sec);
        var hour_sec=sec%3600;
        if(hour_sec!=sec)
                new_hour=(sec-hour_sec)/3600;
        else
                new_hour=0;
        var min_sec=hour_sec%60;
        if(min_sec!=hour_sec)
                new_min=(hour_sec-min_sec)/60;
        else
                new_min=0;
        var new_sec=min_sec;
        new_hour=new_hour.toString();
        new_min=new_min.toString();
        new_sec=new_sec.toString();
        if(new_hour.length==1)
                new_hour='0'+new_hour;
        if(new_min.length==1)
                new_min='0'+new_min;
        if(new_sec.length==1)
                new_sec='0'+new_sec;
        var new_time=new_hour+':'+new_min+':'+new_sec;
        return new_time;
}

function getkey(type, e)
{
        var keycode;
        if (window.event) keycode = window.event.keyCode;
        else if (e) keycode = e.which;
        else return true;

        if(type == "apname")
        {
                if ((keycode==34) ||(keycode==39)||(keycode==92)) { return false; }
                else return true;
        }
        else if(type == "ipaddr")
        {
                if (((keycode>47) && (keycode<58))||(keycode==8)||(keycode==0)||(keycode==46)) { return true; }
                else return false;
        }
        else if(type == "ssid")
        {
                if (keycode==32) return false;
                else return true;
        }
        else if(type == "wep")
        {
                if (((keycode>47) && (keycode<58))||((keycode>64) && (keycode<71))||((keycode>96) && (keycode<103))||(keycode == 8)||(keycode == 0))
                        return true;
                else return false;
        }
        else if(type == "num")
        {
                if      (((keycode>47) && (keycode<58)) || (keycode==8)||(keycode==0))
                        return true;
                else return false;
        }
        else if(type == "hostname")
        {
                if (((keycode>47) && (keycode<58))||(keycode==45)||((keycode>64) && (keycode<91))||((keycode>96) && (keycode<123)) || (keycode==8)||(keycode==0)) { return true; }
                else return false;
        }
        else if(type == "ddns_hostname")
        {
                if (((keycode>47) && (keycode<58))||(keycode==45)||(keycode==46)||((keycode>64) && (keycode<91))||((keycode>96) && (keycode<123)) || (keycode==8)||(keycode==0)) { return true; }
                else return false;
        }
        else if(type == "mac")
        {
                if (((keycode>47) && (keycode<58))||((keycode>64) && (keycode<71))||((keycode>96) && (keycode<103))||(keycode == 8)||(keycode == 0) || (keycode == 58))
                        return true;
                else return false;
        }
        else
                return false;
}



function changesectype(fname)
{
	var html_href;
	if(fname.options[0].selected == true) html_href = "security_off.html";
	else if(fname.options[1].selected == true) html_href = "wep.html";
	else if(fname.options[2].selected == true) html_href = "wpa_psk.html";
	else if(fname.options[3].selected == true) html_href = "wpa2_psk.html";
	else if(fname.options[4].selected == true) html_href = "wpas_psk.html";
	else if(fname.options[5].selected == true) html_href = "wpa.html";
	else if(fname.options[6].selected == true) html_href = "wpa2.html";
	else if(fname.options[7].selected == true) html_href = "8021x.html";
	location.href = html_href;
}
function changekeylen(form)
{
    if(form.sec_keylen.options[0].selected == true)
    {
        form.wepkey1.size=form.wepkey2.size=form.wepkey3.size=form.wepkey4.size=12;
        if (form.wepkey1.value.length>10)
            form.wepkey1.value = form.wepkey1.value.substring(0,10);
        if (form.wepkey2.value.length>10)
            form.wepkey2.value = form.wepkey2.value.substring(0,10);
        if (form.wepkey3.value.length>10)
            form.wepkey3.value = form.wepkey3.value.substring(0,10);
        if (form.wepkey4.value.length>10)
            form.wepkey4.value = form.wepkey4.value.substring(0,10);
    }
    else
    {
        form.wepkey1.size=form.wepkey2.size=form.wepkey3.size=form.wepkey4.size=28;
        if (form.wepkey1.value.length>26)
            form.wepkey1.value = form.wepkey1.value.substring(0,26);
        if (form.wepkey2.value.length>26)
            form.wepkey2.value = form.wepkey2.value.substring(0,10);
        if (form.wepkey3.value.length>26)
            form.wepkey3.value = form.wepkey3.value.substring(0,10);
        if (form.wepkey4.value.length>26)
            form.wepkey4.value = form.wepkey4.value.substring(0,10);
    }
    form.generate_flag.value=0;
}
function setDisabled(OnOffFlag,formFields)
{
    for (var i = 1; i < setDisabled.arguments.length; i++)
        setDisabled.arguments[i].disabled = OnOffFlag;
}

function maccheck(mac_addr)
{
	mac_array=mac_addr.split(':');
	var mac11 = mac_array[0];
    	mac11 = mac11.substr(1,1);
	if((mac11=="1")||(mac11=="3")||(mac11=="5")||(mac11=="7")||(mac11=="9")||(mac11=="b")||(mac11=="d")||(mac11=="f")||(mac11=="B")||(mac11=="D")||(mac11=="F"))
    	{
		if(mac11=="1" &&   mac_array[0] == "11")
		{}
		else
		{
			alert(invalid_mac);
        		return false;
		}
    	}
	if(mac_array.length!=6)
	{
		alert(invalid_mac);
                return false;
	}
    	if(( mac_array[0]=="")||( mac_array[1]=="")||( mac_array[2]=="")||( mac_array[3]=="")||( mac_array[4]=="")||( mac_array[5]==""))
	{
		alert(enter_full_mac);
		return false;
	}
    if((( mac_array[0]=="00")&&( mac_array[1]=="00")&&
        ( mac_array[2]=="00")&&( mac_array[3]=="00")&&
        ( mac_array[4]=="00")&&( mac_array[5]=="00"))||
       (( mac_array[0]=="ff")&&( mac_array[1]=="ff")&&
        ( mac_array[2]=="ff")&&( mac_array[3]=="ff")&&
        ( mac_array[4]=="ff")&&( mac_array[5]=="ff"))||
       (( mac_array[0]=="FF")&&( mac_array[1]=="FF")&&
        ( mac_array[2]=="FF")&&( mac_array[3]=="FF")&&
        ( mac_array[4]=="FF")&&( mac_array[5]=="FF")))
	{
		alert(invalid_mac);
		return false;
	}
	if(( mac_array[0].length!=2)||( mac_array[1].length!=2)||
	   ( mac_array[2].length!=2)||( mac_array[3].length!=2)||
           ( mac_array[4].length!=2)||( mac_array[5].length!=2))
	{
		alert(invalid_mac);
		return false;
	}
	
	for(i=0;i<mac_addr.length;i++)
         {
                if(isValidMac(mac_addr.charAt(i))==false)
                {
                        alert(invalid_mac);
                        return false;
                }
        }
	return true;
}
function maccheck_wds(mac_addr)
{
    if(mac_addr=="")
        return 2;
    var mac_array=mac_addr.split(':');
    var mac11 = mac_array[0];
        mac11 = mac11.substr(1,1);
    if((mac11=="1")||(mac11=="3")||(mac11=="5")||(mac11=="7")||
       (mac11=="9")||(mac11=="b")||(mac11=="d")||(mac11=="f")||
       (mac11=="B")||(mac11=="D")||(mac11=="F"))
    {
        if( mac11 == "1" && mac_array[0]=="11")
        {}
        else
                return 1;
    }
    if(mac_addr.length!=17 && mac_addr.length!=0)
            return 1;
    if((mac_array[0]=="")||(mac_array[1]=="")||(mac_array[2]=="")||(mac_array[3]=="")|| (mac_array[4]=="")||(mac_array[5]==""))
    {
        if((mac_array[0]=="")&&(mac_array[1]=="")&&(mac_array[2]=="")&&(mac_array[3]=="")&& (mac_array[4]=="")&&(mac_array[5]==""))
                return 2;
        else
            return 1;
    }
    if(((mac_array[0]=="00")&&(mac_array[1]=="00")&&
        (mac_array[2]=="00")&&(mac_array[3]=="00")&&
        (mac_array[4]=="00")&&(mac_array[5]=="00"))||
       ((mac_array[0]=="ff")&&(mac_array[1]=="ff")&&
        (mac_array[2]=="ff")&&(mac_array[3]=="ff")&&
        (mac_array[4]=="ff")&&(mac_array[5]=="ff"))||
       ((mac_array[0]=="FF")&&(mac_array[1]=="FF")&&
        (mac_array[2]=="FF")&&(mac_array[3]=="FF")&&
        (mac_array[4]=="FF")&&(mac_array[5]=="FF")))
                return 1;
        if((mac_array[0].length!=2)||(mac_array[1].length!=2)||
           (mac_array[2].length!=2)||(mac_array[3].length!=2)||
       (mac_array[4].length!=2)||(mac_array[5].length!=2))
                return 1;
    for(i=0;i<mac_addr.length;i++)
                if(isValidMac(mac_addr.charAt(i))==false)
                        return 1;

        return 0;
}	   
function printableKeyFilter() 
{
	if (event.keyCode < 32 || event.keyCode > 126)
    		event.returnValue = false;
}

function checkpsk(form)
{
    var len = form.sec_wpaphrase.value.length;
    if(len < 8 || len > 63){
        alert(wpa_phrase);
        return false;
    }
    for(i=0;i<form.sec_wpaphrase.value.length;i++)
         {
                if(isValidChar_space(form.sec_wpaphrase.value.charCodeAt(i))==false)
                {
                        alert(wpa_phrase);
                        return false;
                }
        }
    form.sec_wpaphrase_len.value=len;
    return true;
}

function clickApply(fname, form)
{
	var canapply = false;
	switch(fname)
	{
		case "lan":
			canapply = checklan(form);
			break;
		case "secoff":
		case "wds_ap":
		case "secwpa":
			canapply = true;
			break;
		case "secwep":
			canapply = checkwep(form);
			break;
		case "wlan":
			canapply = check_wlan(form);
			break;
		case "acl":
			canapply = changebtnmode(form);
			form.submit_flag.value="acl";
			break;
		case "secwpapsk":
			canapply = checkpsk(form);
			break;
		case "passwd":
			canapply = checkpasswd(form); 
			break;
		case "upgrade":
			canapply = clickUpgrade(form);
			break;
		case "fdefault":
			canapply = clickFdefault(form);
			break;
		case "ureboot":
			canapply = clickReboot(form);
			break;
		case "wlan_adv":
			canapply = checkadv(form);
			break;
		case "wds_ptp":
			canapply = checkptp(form);
			break;
		case "wds_repeater":
			canapply = checkrepeater(form);
			break;
		case "wds_sta":
			canapply = checksta(form);
			break;		
		case "wds_multi":
			canapply = change_multi_btnmode(form);
			break;
		default:
			break;
	}
	
	if(canapply == true)
		form.submit();
}


/////////////////////////////////////generate wep key by md5////////////////////////////////////////////////////
function HexToAscii(F,I,S,D) {
        var temp1="";

        S = S.toUpperCase();

    var optionindex=F.sec_keylen.selectedIndex;

    if( F.sec_keylen.options[optionindex].value=="13" )
    {
        wordCount = 26;
    }
    else {
        wordCount = 10;
    }

        //if(F.keyno_11g[I].checked)
        if(1)
        {
                if( (S.length!=wordCount) )
                {
                        if(F.wepkeyno[I].checked)
                        {
                                var s="Hex type key length must be ";
                                alert(s + wordCount);
                        }
                        D.value="";
                        S="";
                        return S;
                }
                for(i=0;i<wordCount;i+=2)
                {
                        var c=S.charCodeAt(i);
                        var d=S.charCodeAt(i+1);

                        if( (c>=48)&&(c<=57) )
                                c=c-48;
                        else if( (c>=65)&&(c<=70) )
                                c=c-55;
                        else
                        {
                                var s="Over Hex range (0~F)";
                                alert(s);
                                return S;
                        }

                        if( (d>=48)&&(d<=57) )
                                d=d-48;
                        else if( (d>=65)&&(d<=70) )
                                d=d-55;
                        else
                        {
                                var s="Over Hex range (0~F)";
                                alert(s);
                                return S;
                        }
                        var value=c*16+d;

                        if( ((value>=0)&&(value<32)) || ((value>128)&&(value<=255)) )
                        {
                                temp1+=String.fromCharCode(92);
                                temp1+=S.substring(i,i+2);

                        }
                        else
                        {
                                if(value==92)
                                {
                                        temp1+=String.fromCharCode(value);
                                        temp1+=String.fromCharCode(value);
                                }
                                else
                                        temp1+=String.fromCharCode(value);
                        }
                }
                D.value=temp1;
        }
        return S;
}

function PassPhrase40(F)
{
        var seed = 0;
        var pseed = new Array(0, 0, 0, 0);
        var pkey = new Array(4);
        var asciiObj = new Array(4);
        Length = F.weppassphrase.value.length;

        if(Length != 0) {
                for (i=0; i<Length; i++ ) {
                        pseed[i%4] ^= F.weppassphrase.value.charCodeAt(i);
                }
                seed = pseed[0];
                seed += pseed[1] << 8;
                seed += pseed[2] << 16;
                seed += pseed[3] << 24;
        }

        F.wepkey1.value = F.wepkey2.value = "";
        F.wepkey3.value = F.wepkey4.value = "";

        // init key array
        pkey[0] = F.wepkey1;
        pkey[1] = F.wepkey2;
        pkey[2] = F.wepkey3;
        pkey[3] = F.wepkey4;

        for(j=0; j<4; j++) {
                for (i=0; i<5 ;i++ )  {
                        seed = (214013 * seed) & 0xffffffff;

                        if(seed & 0x80000000) {
                                seed = (seed & 0x7fffffff) + 0x80000000 + 0x269ec3;
                        }
                        else {
                                seed = (seed & 0x7fffffff) + 0x269ec3;
                        }
                        temp = ((seed >> 16) & 0xff);
                        if(temp < 0x10) {
                                pkey[j].value += "0" + temp.toString(16).toUpperCase();
                        }
                        else {
                                pkey[j].value += temp.toString(16).toUpperCase();
                        }
                }
        }

        asciiObj[0] = "";
        asciiObj[1] = "";
        asciiObj[2] = "";
        asciiObj[3] = "";

        for(k=0; k<4; k++) {
                HexToAscii(F, k, pkey[k].value, asciiObj[k]);
        }

        wepkey1 = pkey[0].value;
        wepkey2 = pkey[1].value;
        wepkey3 = pkey[2].value;
        wepkey4 = pkey[3].value;
}

/*
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Copyright (C) Paul Johnston 1999 - 2000.
 * Updated by Greg Holt 2000 - 2001.
 * See http://pajhome.org.uk/site/legal.html for details.
 */

/*
 * Convert a 32-bit number to a hex string with ls-byte first
 */
var hex_chr = "0123456789abcdef";
function rhex(num)
{
  str = "";
  for(j = 0; j <= 3; j++)
    str += hex_chr.charAt((num >> (j * 8 + 4)) & 0x0F) +
           hex_chr.charAt((num >> (j * 8)) & 0x0F);
  return str;
}

/*
 * Convert a string to a sequence of 16-word blocks, stored as an array.
 * Append padding bits and the length, as described in the MD5 standard.
 */
function str2blks_MD5(str)
{
  nblk = ((str.length + 8) >> 6) + 1;
  blks = new Array(nblk * 16);
  for(i = 0; i < nblk * 16; i++) blks[i] = 0;
  for(i = 0; i < str.length; i++)
    blks[i >> 2] |= str.charCodeAt(i) << ((i % 4) * 8);
  blks[i >> 2] |= 0x80 << ((i % 4) * 8);
  blks[nblk * 16 - 2] = str.length * 8;
  return blks;
}

/*
 * Add integers, wrapping at 2^32. This uses 16-bit operations internally 
 * to work around bugs in some JS interpreters.
 */
function add(x, y)
{
  var lsw = (x & 0xFFFF) + (y & 0xFFFF);
  var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return (msw << 16) | (lsw & 0xFFFF);
}

/*
 * Bitwise rotate a 32-bit number to the left
 */
function rol(num, cnt)
{
  return (num << cnt) | (num >>> (32 - cnt));
}

/*
 * These functions implement the basic operation for each round of the
 * algorithm.
 */
function cmn(q, a, b, x, s, t)
{
  return add(rol(add(add(a, q), add(x, t)), s), b);
}
function ff(a, b, c, d, x, s, t)
{
  return cmn((b & c) | ((~b) & d), a, b, x, s, t);
}
function gg(a, b, c, d, x, s, t)
{
  return cmn((b & d) | (c & (~d)), a, b, x, s, t);
}
function hh(a, b, c, d, x, s, t)
{
  return cmn(b ^ c ^ d, a, b, x, s, t);
}
function ii(a, b, c, d, x, s, t)
{
  return cmn(c ^ (b | (~d)), a, b, x, s, t);
}

/*
 * Take a string and return the hex representation of its MD5.
 */
function calcMD5(str)
{
  x = str2blks_MD5(str);
  a =  1732584193;
  b = -271733879;
  c = -1732584194;
  d =  271733878;

  for(i = 0; i < x.length; i += 16)
  {
    olda = a;
    oldb = b;
    oldc = c;
    oldd = d;

    a = ff(a, b, c, d, x[i+ 0], 7 , -680876936);
    d = ff(d, a, b, c, x[i+ 1], 12, -389564586);
    c = ff(c, d, a, b, x[i+ 2], 17,  606105819);
    b = ff(b, c, d, a, x[i+ 3], 22, -1044525330);
    a = ff(a, b, c, d, x[i+ 4], 7 , -176418897);
    d = ff(d, a, b, c, x[i+ 5], 12,  1200080426);
    c = ff(c, d, a, b, x[i+ 6], 17, -1473231341);
    b = ff(b, c, d, a, x[i+ 7], 22, -45705983);
    a = ff(a, b, c, d, x[i+ 8], 7 ,  1770035416);
    d = ff(d, a, b, c, x[i+ 9], 12, -1958414417);
    c = ff(c, d, a, b, x[i+10], 17, -42063);
    b = ff(b, c, d, a, x[i+11], 22, -1990404162);
    a = ff(a, b, c, d, x[i+12], 7 ,  1804603682);
    d = ff(d, a, b, c, x[i+13], 12, -40341101);
    c = ff(c, d, a, b, x[i+14], 17, -1502002290);
    b = ff(b, c, d, a, x[i+15], 22,  1236535329);    

    a = gg(a, b, c, d, x[i+ 1], 5 , -165796510);
    d = gg(d, a, b, c, x[i+ 6], 9 , -1069501632);
    c = gg(c, d, a, b, x[i+11], 14,  643717713);
    b = gg(b, c, d, a, x[i+ 0], 20, -373897302);
    a = gg(a, b, c, d, x[i+ 5], 5 , -701558691);
    d = gg(d, a, b, c, x[i+10], 9 ,  38016083);
    c = gg(c, d, a, b, x[i+15], 14, -660478335);
    b = gg(b, c, d, a, x[i+ 4], 20, -405537848);
    a = gg(a, b, c, d, x[i+ 9], 5 ,  568446438);
    d = gg(d, a, b, c, x[i+14], 9 , -1019803690);
    c = gg(c, d, a, b, x[i+ 3], 14, -187363961);
    b = gg(b, c, d, a, x[i+ 8], 20,  1163531501);
    a = gg(a, b, c, d, x[i+13], 5 , -1444681467);
    d = gg(d, a, b, c, x[i+ 2], 9 , -51403784);
    c = gg(c, d, a, b, x[i+ 7], 14,  1735328473);
    b = gg(b, c, d, a, x[i+12], 20, -1926607734);
    
    a = hh(a, b, c, d, x[i+ 5], 4 , -378558);
    d = hh(d, a, b, c, x[i+ 8], 11, -2022574463);
    c = hh(c, d, a, b, x[i+11], 16,  1839030562);
    b = hh(b, c, d, a, x[i+14], 23, -35309556);
    a = hh(a, b, c, d, x[i+ 1], 4 , -1530992060);
    d = hh(d, a, b, c, x[i+ 4], 11,  1272893353);
    c = hh(c, d, a, b, x[i+ 7], 16, -155497632);
    b = hh(b, c, d, a, x[i+10], 23, -1094730640);
    a = hh(a, b, c, d, x[i+13], 4 ,  681279174);
    d = hh(d, a, b, c, x[i+ 0], 11, -358537222);
    c = hh(c, d, a, b, x[i+ 3], 16, -722521979);
    b = hh(b, c, d, a, x[i+ 6], 23,  76029189);
    a = hh(a, b, c, d, x[i+ 9], 4 , -640364487);
    d = hh(d, a, b, c, x[i+12], 11, -421815835);
    c = hh(c, d, a, b, x[i+15], 16,  530742520);
    b = hh(b, c, d, a, x[i+ 2], 23, -995338651);

    a = ii(a, b, c, d, x[i+ 0], 6 , -198630844);
    d = ii(d, a, b, c, x[i+ 7], 10,  1126891415);
    c = ii(c, d, a, b, x[i+14], 15, -1416354905);
    b = ii(b, c, d, a, x[i+ 5], 21, -57434055);
    a = ii(a, b, c, d, x[i+12], 6 ,  1700485571);
    d = ii(d, a, b, c, x[i+ 3], 10, -1894986606);
    c = ii(c, d, a, b, x[i+10], 15, -1051523);
    b = ii(b, c, d, a, x[i+ 1], 21, -2054922799);
    a = ii(a, b, c, d, x[i+ 8], 6 ,  1873313359);
    d = ii(d, a, b, c, x[i+15], 10, -30611744);
    c = ii(c, d, a, b, x[i+ 6], 15, -1560198380);
    b = ii(b, c, d, a, x[i+13], 21,  1309151649);
    a = ii(a, b, c, d, x[i+ 4], 6 , -145523070);
    d = ii(d, a, b, c, x[i+11], 10, -1120210379);
    c = ii(c, d, a, b, x[i+ 2], 15,  718787259);
    b = ii(b, c, d, a, x[i+ 9], 21, -343485551);

    a = add(a, olda);
    b = add(b, oldb);
    c = add(c, oldc);
    d = add(d, oldd);
  }
  return rhex(a) + rhex(b) + rhex(c) + rhex(d);
}
 



function PassPhrase104(F) 
{

        var     pseed2 = "";
        Length2 = F.weppassphrase.value.length;

        for(p=0; p<64; p++) {
                tempCount = p % Length2;
                pseed2 += F.weppassphrase.value.substring(tempCount, tempCount+1);
        }
        md5Str = calcMD5(pseed2);

        F.wepkey1.value = md5Str.substring(0, 26).toUpperCase();
        F.wepkey2.value = md5Str.substring(0, 26).toUpperCase();
        F.wepkey3.value = md5Str.substring(0, 26).toUpperCase();
        F.wepkey4.value = md5Str.substring(0, 26).toUpperCase();
}

function clickgenerate(form)
{
    if(form.weppassphrase.value.length == 0 )
    {
        alert(gene_phrase)
                return false;
    }
    for(i=0;i<form.weppassphrase.value.length;i++)
         {
                if(isValidChar_space(form.weppassphrase.value.charCodeAt(i))==false)
                {
                        alert(gene_phrase);
                        return false;
                }
        }
    if(form.sec_keylen.options[0].selected == true)
        PassPhrase40(form);
    else
        PassPhrase104(form);
    form.generate_flag.value=1;
}

function checkwep(form)
{
    form.wep_press_flag.value=0;
    var wepkey1=form.wepkey1.value;
    var wepkey2=form.wepkey2.value;
    var wepkey3=form.wepkey3.value;
    var wepkey4=form.wepkey4.value;
    if(form.sec_keylen.value==13)
    {
        if( form.wepkeyno[0].checked == true )
        {
            if(form.wepkey1.value.length!=26)
            {
                alert(wep_128);
                return false;
            }
        }
        else if( form.wepkey1.value.length!=0 && form.wepkey1.value.length!=26)
        {
            alert(wep_128);
            return false;
        }
        if(form.wepkey1.value.length!=0)
            for(i=0;i<wepkey1.length;i++)
            {
                if(isValidHex(wepkey1.charAt(i))==false)
                {
                    alert(wep_128);
                    return false;
                }
            }

        if( form.wepkeyno[1].checked == true )
        {
            if(form.wepkey2.value.length!=26)
            {
                alert(wep_128);
                return false;
            }
        }
        else if( form.wepkey2.value.length!=0 && form.wepkey2.value.length!=26)
        {
            alert(wep_128);
            return false;
        }
        if(form.wepkey2.value.length!=0)
            for(i=0;i<wepkey2.length;i++)
            {
                if(isValidHex(wepkey2.charAt(i))==false)
                {
                    alert(wep_128);
                    return false;
                }
            }
        if( form.wepkeyno[2].checked == true)
        {
            if(form.wepkey3.value.length!=26)
            {
                alert(wep_128);
                return false;
            }
        }
        else if( form.wepkey3.value.length!=0 && form.wepkey3.value.length!=26)
        {
            alert(wep_128);
            return false;
        }
        if(form.wepkey3.value.length!=0)
            for(i=0;i<wepkey3.length;i++)
            {
                if(isValidHex(wepkey3.charAt(i))==false)
                {
                    alert(wep_128);
                    return false;
                }
            }
        if( form.wepkeyno[3].checked == true)
        {
            if(form.wepkey4.value.length!=26)
            {
                alert(wep_128);
                return false;
            }
        }
        else if( form.wepkey4.value.length!=0 && form.wepkey4.value.length!=26)
        {
            alert(wep_128);
            return false;
        }
        if(form.wepkey4.value.length!=0)
            for(i=0;i<wepkey4.length;i++)
            {
                if(isValidHex(wepkey4.charAt(i))==false)
                {
                    alert(wep_128);
                    return false;
                }
            }
    }
    if(form.sec_keylen.value==5)
    {
        if( form.wepkeyno[0].checked == true)
        {
            if(form.wepkey1.value.length!=10)
            {
                alert(wep_64);
                return false;
            }
        }
        else if( form.wepkey1.value.length!=0 && form.wepkey1.value.length!=10)
        {
            alert(wep_64);
            return false;
        }
        if(form.wepkey1.value.length!=0)
            for(i=0;i<wepkey1.length;i++)
            {
                if(isValidHex(wepkey1.charAt(i))==false)
                {
                    alert(wep_64);
                    return false;
                }
            }
        if( form.wepkeyno[1].checked == true)
        {
            if(form.wepkey2.value.length!=10)
            {
                alert(wep_64);
                return false;
            }
        }
        else if( form.wepkey2.value.length!=0 && form.wepkey2.value.length!=10)
        {
            alert(wep_64);
            return false;
        }
        if(form.wepkey2.value.length!=0)
            for(i=0;i<wepkey2.length;i++)
            {
                if(isValidHex(wepkey2.charAt(i))==false)
                {
                    alert(wep_64);
                    return false;
                }
            }
        if( form.wepkeyno[2].checked == true)
        {
            if(form.wepkey3.value.length!=10)
            {
                alert(wep_64);
                return false;
            }
        }
        else if( form.wepkey3.value.length!=0 && form.wepkey3.value.length!=10)
        {
            alert(wep_64);
            return false;
        }
        if(form.wepkey3.value.length!=0)
            for(i=0;i<wepkey3.length;i++)
            {
                if(isValidHex(wepkey3.charAt(i))==false)
                {
                    alert(wep_64);
                    return false;
                }
            }
        if( form.wepkeyno[3].checked == true)
        {
            if(form.wepkey4.value.length!=10)
            {
                alert(wep_64);
                return false;
            }
        }
        else if( form.wepkey4.value.length!=0 && form.wepkey4.value.length!=10)
        {
            alert(wep_64);
            return false;
        }
        if(form.wepkey4.value.length!=0)
            for(i=0;i<wepkey4.length;i++)
            {
                if(isValidHex(wepkey4.charAt(i))==false)
                {
                    alert(wep_64);
                    return false;
                }
            }
    }

    return true;
}		
function isValidHex(each_char)
{
    var macVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9","A", "B", "C", "D", "E", "F", "a", "b", "c", "d", "e", "f");
        var len = macVals.length;
        var i = 0;
        var ret = false;
        for ( i = 0; i < len; i++ )
        if ( each_char == macVals[i] ) break;
        if ( i < len )
                ret = true;
                return ret;
}			

function checkipaddr(ipaddr)
{
	var form = document.forms[0];
	var ipArray = ipaddr.split(".");
	var ipstr = ipArray[0]+ipArray[1]+ipArray[2]+ipArray[3];
	var i = 0;

	if((ipArray[0]=="")||(ipArray[0]<0)||(ipArray[0]>255)||(ipArray[1]=="")||(ipArray[1]<0)||(ipArray[1]>255)
 	||(ipArray[2]=="")||(ipArray[2]<0)||(ipArray[2]>255)||(ipArray[3]=="")||(ipArray[3]<0)||(ipArray[3]>255))
	{
		return false;
	}
	for(i=0;i<ipstr.length;i++)
      	{
        	if((ipstr.charAt(i)!='0')&&(ipstr.charAt(i)!='1')&&(ipstr.charAt(i)!='2')
         	&&(ipstr.charAt(i)!='3')&&(ipstr.charAt(i)!='4')&&(ipstr.charAt(i)!='5')
         	&&(ipstr.charAt(i)!='6')&&(ipstr.charAt(i)!='7')&&(ipstr.charAt(i)!='8')
         	&&(ipstr.charAt(i)!='9'))
         	{
            		return false;
         	}
      	}
	if( ipArray[0] > 223)
		return false;
	if (ipaddr == "0.0.0.0" || ipaddr == "255.255.255.255")
	{
        	return false;
	}
	if (ipaddr == "127.0.0.1")
        {
        	return false;
      	}
	if (!ipArray || ipArray.length != 4)
      	{
           	return false;
	}
	else
	{
		for (i = 0; i < 4; i++)
        	{
          		thisSegment = ipArray[i];
          		if (thisSegment != "")
          		{
             			if(i==3){
                			if (!((ipArray[3] > 0) && (ipArray[3] < 255)))
                			{
                  				return false;
                			}	
				}
		             	else if (!(thisSegment >=0 && thisSegment <= 255))
             			{
                			return false;
             			}
          		} 
			else
          		{
            			return false;
          		}
        	}

	}
	return true;
}

function checksubnet(subnet)
{
        var subnetArray = subnet.split(".");
        var subnetstr = subnetArray[0]+subnetArray[1]+subnetArray[2]+subnetArray[3];
        var i = 0;
        var maskTest = 0;
        var validValue = true;

        if((subnetArray[0]=="")||(subnetArray[0]<0)||(subnetArray[0]>255)||(subnetArray[1]=="")||(subnetArray[1]<0)||(subnetArray[1]>255)
        ||(subnetArray[2]=="")||(subnetArray[2]<0)||(subnetArray[2]>255)||(subnetArray[3]=="")||(subnetArray[3]<0)||(subnetArray[3]>255))
        {
                return false;
        }
        for(i=0;i<subnetstr.length;i++)
        {
                if((subnetstr.charAt(i)!='0')&&(subnetstr.charAt(i)!='1')&&(subnetstr.charAt(i)!='2')
                &&(subnetstr.charAt(i)!='3')&&(subnetstr.charAt(i)!='4')&&(subnetstr.charAt(i)!='5')
                &&(subnetstr.charAt(i)!='6')&&(subnetstr.charAt(i)!='7')&&(subnetstr.charAt(i)!='8')
                &&(subnetstr.charAt(i)!='9'))
                {
                        return false;
                }
        }
	if (!subnetArray || subnetArray.length != 4)
        {
                return false;
        }
	else
        {
                for (i = 0; i < 4; i++) {
                        thisSegment = subnetArray[i];
                        if (thisSegment != "") {
                                if (!(thisSegment >=0 && thisSegment <= 255)) { //check if number?
                             
                                        return false;
                                }
                        } else {
                                return false;
                        }
		}
        }
        if( subnetArray[0] < 255 ) 
	{
                if( (subnetArray[1] > 0) || (subnetArray[2] > 0) || (subnetArray[3] > 0))
                        validValue = false;
                else
                        maskTest = subnetArray[0];
        } 
	else 
	{
                if( subnetArray[1] < 255 ) 
		{
                        if( (subnetArray[2] > 0) || (subnetArray[3] > 0))
                                validValue = false;
                        else
                                maskTest = subnetArray[1];
                } 
		else
		{
                        if( subnetArray[2] < 255 ) 
			{
                                if( (subnetArray[3] > 0) )
                                        validValue = false;
                                else
                                        maskTest = subnetArray[2];
                        } 
			else
                                maskTest = subnetArray[3];
                }
        }
        if( validValue ) {
                switch( maskTest ) {
                case "0":
                case "128":
                case "192":
                case "224":
                case "240":
                case "248":
                case "252":
                case "254":
                case "255":
                        break;
                default:
                        validValue = false;
                }
                if( subnetstr == "0.0.0.0" )
                        validValue = false;
        }
        else
                validValue = false;


        return validValue;
}

function checkgateway(gateway)
{
	var form = document.forms[0];
	var dgArray = gateway.split(".");
        var dgstr = dgArray[0]+dgArray[1]+dgArray[2]+dgArray[3];
	var i = 0;	

	if((dgArray[0]=="")||(dgArray[0]<0)||(dgArray[0]>255)||(dgArray[1]=="")||(dgArray[1]<0)||(dgArray[1]>255)
 	||(dgArray[2]=="")||(dgArray[2]<0)||(dgArray[2]>255)||(dgArray[3]=="")||(dgArray[3]<0)||(dgArray[3]>255))
	{
		return false;
	}	
	for(i=0;i<dgstr.length;i++)
      	{
        	if((dgstr.charAt(i)!='0')&&(dgstr.charAt(i)!='1')&&(dgstr.charAt(i)!='2')
         	&&(dgstr.charAt(i)!='3')&&(dgstr.charAt(i)!='4')&&(dgstr.charAt(i)!='5')
         	&&(dgstr.charAt(i)!='6')&&(dgstr.charAt(i)!='7')&&(dgstr.charAt(i)!='8')
         	&&(dgstr.charAt(i)!='9'))
         	{
            		return false;
         	}
      	}
	if( dgArray[0] > 223)
                return false;
        if (gateway == "0.0.0.0" || gateway == "255.255.255.255")
        {
                return false;
        }
        if (gateway == "127.0.0.1")
        {
                return false;
        }
	if (!dgArray || dgArray.length != 4)
        {
                return false;
        }
        else
        {
                for (i = 0; i < 4; i++) {
                        thisSegment = dgArray[i];
                        if (thisSegment != "") {
                                if (!(thisSegment >=0 && thisSegment <= 255)) { //check if number?
                            
                                        return false;
                                }
                        } else {
                                return false;
                        }
		}
        }
	return true;
}		
function isSameIp(ipstr1,ipstr2)
{
        var count = 0;
        var ip1_array=ipstr1.split('.');
        var ip2_array=ipstr2.split('.');
        for(i = 0;i<4;i++)
        {
                num1 = parseInt(ip1_array[i]);
                num2 = parseInt(ip2_array[i]);
                if( num1 == num2)
                        count++;
        }
        if( count == 4)
                return true;
        else
                return false;
}

function isSameSubNet(lan1Ip, lan1Mask, lan2Ip, lan2Mask)
{       
        var count = 0;
		var count_error_end = 0;
		var count_error_start = 0;
        lan1a = lan1Ip.split('.');
        lan1m = lan1Mask.split('.');
        lan2a = lan2Ip.split('.');
        lan2m = lan2Mask.split('.');
        
        for (i = 0; i < 4; i++)
        {       
                l1a_n = parseInt(lan1a[i]);
                l1m_n = parseInt(lan1m[i]);
                l2a_n = parseInt(lan2a[i]);
                l2m_n = parseInt(lan2m[i]);
                if ((l1a_n & l1m_n) == (l2a_n & l2m_n))
                        count++;
				lan_error_start=(l1a_n & l1m_n);
				var l2a_n_two=0;
				var l2m_n_two=0;
				
				
				var rev = ~l2m_n;
				rev=rev+256;
               
				
				lan_error_end=(rev|l2a_n);
				if (lan_error_end==l2a_n)
				    count_error_end++;
				if (lan_error_start==l2a_n)
				    count_error_start++;
				if (count_error_end == 4)
				   return false;
				if (count_error_start == 4)
				   return false;
	            
        }
        if (count == 4)
               return true;
	    
		
        else
               return false;
}


