
function dhcponoff(onoff, form)
{
	if(onoff == 0)
		form.lan_ipaddr.disabled = form.lan_subnet.disabled = form.lan_gateway.disabled = false;
	else
		form.lan_ipaddr.disabled = form.lan_subnet.disabled = form.lan_gateway.disabled = true; 
}

function checklan(form)
{
	if(form.lan_dhcpmode[0].checked == true)
	{
		var askstr=changelanip+" dhcp ?";
                if(!confirm(askstr))
                        return false;
                alert(changelanip_renew);
		return true;
	}
	if(checkipaddr(form) == true && checksubnet(form) == true && checkgateway(form) == true)
	{}
	else
		return false;
	if(form.lan_gateway.value!="" && form.lan_gateway.value!="0.0.0.0")
	{
		if(isSameSubNet(form.lan_ipaddr.value,form.lan_subnet.value,form.lan_gateway.value,form.lan_subnet.value)==false)
		{
			alert(same_subnet_ip_gtw);
			return false;
		}
	}
	if(isSameIp(form.lan_ipaddr.value,old_lan_ip)==false)
	{
		var askstr=changelanip+form.lan_ipaddr.value+" ?";
                if(!confirm(askstr))
                        return false;
                alert(changelanip_renew);
		form.changeip_flag.value=1;
		form.action="/cgi-bin/setobject.cgi?/cgi-bin/welcomeok.html"
		return true;		
	}
	else
		return true;
}
