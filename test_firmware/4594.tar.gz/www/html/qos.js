function check_qos()
{
	var cf=document.forms[0];
	if(cf.enable_wmm.checked == true)
		cf.qos_endis_wmm.value=1;
	else
		cf.qos_endis_wmm.value=0;
		
	if(cf.turn_qos_on.checked == true)
		cf.qos_endis_on.value=1;
	else
		cf.qos_endis_on.value=0;
	cf.submit_flag.value="apply_qos";
	cf.submit();
}

function change_priority()
{
	var cf=document.forms[0];
	if( cf.priority_category.selectedIndex == 0)
		location.href="qos_adva_add.html";
	else if( cf.priority_category.selectedIndex == 1)
		location.href="qos_ether_add.html";
	else if( cf.priority_category.selectedIndex == 2)
		location.href="qos_mac_add.html";
}

function change_serv_adva()
{
	var cf=document.forms[0];
	
		cf.qos_policy_name.value='';
		cf.priority.selectedIndex=0;
		real_app_port.innerHTML=str_div;
	
	/*else
	{
		real_app_port.innerHTML='';
		var i=cf.application.selectedIndex;
		cf.qos_policy_name.value=serv_array[i][3];
		cf.priority.selectedIndex=serv_array[i][4];
	}*/
}

function change_serv_online()
{
	var cf=document.forms[0];
	if (cf.application.selectedIndex == 10)
	{
		cf.qos_policy_name.value='';
		cf.priority.selectedIndex=0;
		real_app_port.innerHTML=str_div;
	}
	else
	{
		real_app_port.innerHTML='';
		var i=cf.application.selectedIndex;
		if(serv_array[i][3]=="Counter-Strike")
			cf.qos_policy_name.value="Counter Strike";
		else if(serv_array[i][3]=="Age-of-Empires")
			cf.qos_policy_name.value="Age of Empires";
		else if(serv_array[i][3]=="Diablo-II")
			cf.qos_policy_name.value="Diablo II";
		else if(serv_array[i][3]=="Half-Life")
			cf.qos_policy_name.value="Half Life";
		else if(serv_array[i][3]=="Quake-2")
			cf.qos_policy_name.value="Quake 2";
		else if(serv_array[i][3]=="Quake-3")
			cf.qos_policy_name.value="Quake 3";
		else if(serv_array[i][3]=="Unreal-Tourment")
			cf.qos_policy_name.value="Unreal Tourment";	
		else if(serv_array[i][3]=="Return-to-Castle-Wolfenstein")
			cf.qos_policy_name.value="Return to Castle Wolfenstein";		
		else
			cf.qos_policy_name.value=serv_array[i][3];
		cf.hidden_qos_policy_name.value=serv_array[i][3];
		cf.priority.selectedIndex=serv_array[i][4];
	}
}

function change_name_online(name)
{
		if(name=="Counter-Strike")
			new_name="Counter Strike";
		else if(name=="Age-of-Empires")
			new_name="Age of Empires";
		else if(name=="Diablo-II")
			new_name="Diablo II";
		else if(name=="Half-Life")
			new_name="Half Life";
		else if(name=="Quake-2")
			new_name="Quake 2";
		else if(name=="Quake-3")
			new_name="Quake 3";
		else if(name=="Unreal-Tourment")
			new_name="Unreal Tourment";	
		else if(name=="Return-to-Castle-Wolfenstein")
			new_name="Return to Castle Wolfenstein";		
		else if(name=="LAN_Port_1")
			new_name="LAN Port 1";
		else if(name=="LAN_Port_2")
			new_name="LAN Port 2";
		else if(name=="LAN_Port_3")
			new_name="LAN Port 3";
		else if(name=="LAN_Port_4")
			new_name="LAN Port 4";	
        else if(name.indexOf("LAN_Port_")>-1)
            {
			new_name=name.replace(/\_/g," ");
			}			
		else
			new_name=name;
		return new_name;
}

function change_serv_ether()
{
	var cf=document.forms[0];
	if(cf.qos_policy_name.value=="LAN Port 1" ||cf.qos_policy_name.value=="LAN Port 2"||cf.qos_policy_name.value=="LAN Port 3" || cf.qos_policy_name.value=="LAN Port 4" || cf.qos_policy_name.value=="")
	{
		cf.qos_policy_name.value="LAN Port "+cf.application.options[cf.application.selectedIndex].value;
		cf.hidden_qos_policy_name.value="LAN_Port_"+cf.application.options[cf.application.selectedIndex].value;
	}
		
}

function qosmac_data_select(num)
{
	var cf=document.forms[0];
	var str = eval ( 'qosmac_Array' + num );
	var each_info=str.split(' ');
	cf.qos_device_name.value=each_info[2];
	if(each_info[0]!='----')
		cf.qos_policy_name.value=each_info[0];
	else
		cf.qos_policy_name.value='';
	var edit_mac=each_info[3];
	var mac_array=edit_mac.split(':');
	cf.mac_addr1.value=mac_array[0];
	cf.mac_addr2.value=mac_array[1];
	cf.mac_addr3.value=mac_array[2];
	cf.mac_addr4.value=mac_array[3];
	cf.mac_addr5.value=mac_array[4];
	cf.mac_addr6.value=mac_array[5];
	cf.priority.value=each_info[1];
	cf.select_editnum_mac.value=num;
	var new_num=0;
	for(i=1;i<=qos_array_num;i++)
	{
		var str = eval ( 'qosArray' + i );
		var each_qoslist_info=str.split(' ');
		if( each_qoslist_info[0] == each_info[0])
			new_num=i;
	}
	cf.select_qoslist_num.value=new_num;
}

function check_qoslist_editnum(cf)
{
	if( qos_array_num == 0 )
	{
		alert(no_serv_edit);
		return false;
	}
	var count_select=0;
	var select_num;
	if( qos_array_num == 1)
	{
		if(cf.select_qos.checked == true)
		{
			count_select++;
			select_num=1;
		}
	}
	else for(i=0;i<qos_array_num;i++)
		if(cf.select_qos[i].checked == true)
		{
			count_select++;
			select_num=i+1;
		}
	if(count_select==0)
	{
		alert(select_serv_edit);
		return false;
	}
	else
	{
		cf.select_edit.value=select_num;
		cf.submit_flag.value="qos_editnum";
		var edit_str=eval('qosArray' + select_num);
		var edit_each_info=edit_str.split(' ');
		if(edit_each_info[1]=='0')
			cf.action="/cgi-bin/setobject.cgi?/cgi-bin/qos_adva_edit.html";
		//else if(edit_each_info[1]=='1')
			//cf.action="/cgi-bin/setobject.cgi?/cgi-bin/qos_online_edit.html";
		else if(edit_each_info[1]=='1')
			cf.action="/cgi-bin/setobject.cgi?/cgi-bin/qos_ether_edit.html";	
		else if(edit_each_info[1]=='2')
			cf.action="/cgi-bin/setobject.cgi?/cgi-bin/qos_mac_edit.html";	
		cf.submit();
	}
}

function check_qos_port(cf)
{
	if(cf.portstart.value==""||cf.portend.value=="")
	{
		alert(invalid_port);
		return false;
	}
	txt=cf.portstart.value;
	for(i=0;i<txt.length;i++)
	{
		c=txt.charAt(i);
		if("0123456789".indexOf(c,0)<0)
		{
			alert(invalid_start_port);
			return false;
		}
	}
	txt=cf.portend.value;
	for(i=0;i<txt.length;i++)
	{
		c=txt.charAt(i);
		if("0123456789".indexOf(c,0)<0)
		{
			alert(invalid_end_port);
			return false;
		}
	}
	if(parseInt(cf.portstart.value)<1||parseInt(cf.portstart.value)>65535)
	{
		alert(invalid_start_port);
		return false;
	}
	if(parseInt(cf.portend.value)<1||parseInt(cf.portend.value)>65535)
	{
		alert(invalid_end_port);
		return false;
	}
	if(parseInt(cf.portend.value)<parseInt(cf.portstart.value))
	{
		alert(end_port_greater);
		return false;
	}
	return true;
}
function check_qos_adva(cf,flag)
{
	if(cf.qos_policy_name.value == "")
	{
		alert(qos_policy_name_null);
		return false;
	}
    var input_start_port="0";
    var input_end_port="0";
    
	
		input_start_port=cf.portstart.value;
		input_end_port=cf.portend.value;
	

	for(i=1;i<=qos_array_num;i++)
	{
		var str = eval ( 'qosArray' + i );
		var each_info=str.split(' ');
        startport=each_info[5];
        endport=each_info[6];
		
		if(flag == 'edit')
		{
			if( cf.qos_policy_name.value == each_info[0] && select_editnum!=i )
			{
				alert(qos_policy_name_dup);
				return false;
			}
			if ((parseInt(cf.portstart.value) == parseInt(each_info[5]))&&(parseInt(cf.portend.value) == parseInt(each_info[6]))&&((cf.port_type.value ==each_info[4])||(each_info[4]=="TCP/UDP"))&& select_editnum!=i)
			{       
					alert(qos_port_used);
					return false;
			}
			if((parseInt(cf.portstart.value)<parseInt(each_info[5]))&&(parseInt(cf.portend.value)>parseInt(each_info[6]))&&((cf.port_type.value ==each_info[4])||(each_info[4]=="TCP/UDP"))&& select_editnum!=i)
			{      
			        alert(qos_port_used);
					return false;
			}
			if((parseInt(cf.portstart.value)>=parseInt(each_info[5]))&&(parseInt(cf.portstart.value)<=parseInt(each_info[6]))&&((cf.port_type.value ==each_info[4])||(each_info[4]=="TCP/UDP"))&& select_editnum!=i)
			{      
			        alert(qos_port_used);
					return false;
			}		
            if((parseInt(cf.portend.value)>=parseInt(each_info[5]))&&(parseInt(cf.portend.value)<=parseInt(each_info[6]))&&((cf.port_type.value ==each_info[4])||(each_info[4]=="TCP/UDP"))&& select_editnum!=i)		
            {      
			        alert(qos_port_used);
					return false;
			}
            else if((!(parseInt(endport)<parseInt(input_start_port)||parseInt(input_end_port)<parseInt(startport))) && select_editnum!=i && endport != "----" && startport != "----" && each_info[2]=="Add" )
            {
                alert(qos_port_used);
                return false;
            }

		}
		else
		{
			if( cf.qos_policy_name.value == each_info[0])
			{
				alert(qos_policy_name_dup);
				return false;
			}
			if ((parseInt(cf.portstart.value) == parseInt(each_info[5]))&&(parseInt(cf.portend.value) == parseInt(each_info[6]))&&((cf.port_type.value ==each_info[4])||(each_info[4]=="TCP/UDP")))
			{       
					alert(qos_port_used);
					return false;
			}
			if((parseInt(cf.portstart.value)<parseInt(each_info[5]))&&(parseInt(cf.portend.value)>parseInt(each_info[6]))&&((cf.port_type.value ==each_info[4])||(each_info[4]=="TCP/UDP")))
			{      
			        alert(qos_port_used);
					return false;
			}
			if((parseInt(cf.portstart.value)>=parseInt(each_info[5]))&&(parseInt(cf.portstart.value)<=parseInt(each_info[6]))&&((cf.port_type.value ==each_info[4])||(each_info[4]=="TCP/UDP")))
			{      
			        alert(qos_port_used);
					return false;
			}
			if((parseInt(cf.portend.value)>=parseInt(each_info[5]))&&(parseInt(cf.portend.value)<=parseInt(each_info[6]))&&((cf.port_type.value ==each_info[4])||(each_info[4]=="TCP/UDP")))
			{      
			        alert(qos_port_used);
					return false;
			}
            else if(!(parseInt(endport)<parseInt(input_start_port)||parseInt(input_end_port)<parseInt(startport)) && endport != "----" && startport != "----" && each_info[2]=="Add")
            {
                alert(qos_port_used);
                return false;
            }
		}
	}

	
		if (check_qos_port(cf)==false)
			return false;
	
//add new info	
	
		cf.hidden_port_type.value=cf.port_type.options[cf.port_type.selectedIndex].value;
		cf.hidden_portstart.value=cf.portstart.value
		cf.hidden_portend.value=cf.portend.value;
	
	/*else
	{
		var i=cf.application.selectedIndex;
		cf.hidden_port_type.value=serv_array[i][0];
		cf.hidden_portstart.value=serv_array[i][1];
		cf.hidden_portend.value=serv_array[i][2];
	}*/
	
	cf.submit();
}

function check_qos_online(cf,flag)
{
	if(cf.qos_policy_name.value=='')
	{
		alert(qos_policy_name_null);
		return false;
	}
    var input_start_port="0";
    var input_end_port="0";
    if(cf.application.selectedIndex==10)
    {
        var input_start_port=cf.portstart.value;
        var input_end_port=cf.portend.value;
    }
	for(i=1;i<=qos_array_num;i++)
	{
		var str = eval ( 'qosArray' + i );
		var each_info=str.split(' ');
        startport=each_info[5];
        endport=each_info[6];
    	if(flag == 'edit')
		{
			if( cf.qos_policy_name.value == change_name_online(each_info[0]) && select_editnum!=i )
			{
				alert(qos_policy_name_dup);
				return false;
			}
            else if((!(parseInt(endport)<parseInt(input_start_port)||parseInt(input_end_port)<parseInt(startport))) && select_editnum!=i && endport != "----" && startport != "----" && each_info[2]=="Add")
            {
                alert(qos_port_used);
                return false;
            }

		}
		else
		{
			if( cf.qos_policy_name.value == change_name_online(each_info[0]))
			{
				alert(qos_policy_name_dup);
				return false;
			}
            else if(!(parseInt(endport)<parseInt(input_start_port)||parseInt(input_end_port)<parseInt(startport)) && endport != "----" && startport != "----" && each_info[2]=="Add")
            {
                alert(qos_port_used);
                return false;
            }

		}
	}
	if (cf.application.selectedIndex == 10)
	{
		if (check_qos_port(cf)==false)
			return false;
	}
//add new info	
	if (cf.application.selectedIndex == 10)
	{
		cf.hidden_port_type.value=cf.port_type.options[cf.port_type.selectedIndex].value;
		cf.hidden_portstart.value=cf.portstart.value
		cf.hidden_portend.value=cf.portend.value;
	}
	else
	{
		var i=cf.application.selectedIndex;
		cf.hidden_port_type.value=serv_array[i][0];
		cf.hidden_portstart.value=serv_array[i][1];
		cf.hidden_portend.value=serv_array[i][2];
	}
    var str_game=cf.qos_policy_name.value;
    var str_new="";
    for(var j=0;j<=str_game.length;j++)
    {
        if(str_game.substr(j,1)==' ')
            str_new+='-';
        else
            str_new+=str_game.substr(j,1);
    }
    cf.hidden_qos_policy_name.value=str_new;

	cf.submit();
}

function check_qos_ether(cf,flag)
{	
	if(cf.qos_policy_name.value == "" )
	{
		cf.qos_policy_name.value="LAN Port "+cf.application.options[cf.application.selectedIndex].value;
		cf.hidden_qos_policy_name.value="LAN_Port_"+cf.application.options[cf.application.selectedIndex].value;
	}
	else
	{
		cf.hidden_qos_policy_name.value=change_name_online(cf.qos_policy_name.value);
		cf.hidden_qos_policy_name.value=cf.hidden_qos_policy_name.value.replace(/ /g,'_')
	}
	for(i=1;i<=qos_array_num;i++)
	{
		var str = eval ( 'qosArray' + i );
		var each_info=str.split(' ');
		if(flag == 'edit')
		{
			if( cf.qos_policy_name.value == change_name_online(each_info[0]) && select_editnum!=i )
			{
				alert(qos_policy_name_dup);
				return false;
			}
			/*if(cf.application.options[cf.application.selectedIndex].value==each_info[2] && select_editnum!=i )
			{
				alert(qos_ether_port_dup);
				return false;
			}
			*/
		}
		else
		{
			if( cf.qos_policy_name.value == change_name_online(each_info[0]))
			{
				alert(qos_policy_name_dup);
				return false;
			}
				if(cf.application.options[cf.application.selectedIndex].value==each_info[2] )
			{
				alert(qos_ether_port_dup);
				return false;
			}
		}
	}
	//alert(cf.hidden_qos_policy_name.value);
	cf.submit();
}

function valid_add_qosmac(cf,flag)
{ 
	if (qosmac_array_num ==0 && flag == 'edit')
	{
		alert(no_serv_edit);
		return false;
	}
	else if( cf.select_editnum_mac.value == '' && flag == 'edit')
	{
		alert(select_serv_edit);
		return false;
	}
	if(cf.qos_device_name.value=='')
	{
		alert(device_name_null);
		return false;
	}
	cf.the_mac.value = cf.mac_addr1.value+':'+cf.mac_addr2.value+':'+cf.mac_addr3.value+':'+
					  cf.mac_addr4.value+':'+cf.mac_addr5.value+':'+cf.mac_addr6.value;

	if(maccheck(cf.the_mac.value) == false)
			return false;

	for(i=1;i<=qosmac_array_num;i++)
	{   
		var str = eval ( 'qosmac_Array' + i );
		var each_info=str.split(' ');
		if(flag == 'edit')
		{   
			if( cf.qos_device_name.value == each_info[2] && cf.select_editnum_mac.value!=i )
			{
				alert(device_name_dup);
				return false;
			}
			if( cf.qos_policy_name.value == each_info[0] && cf.select_editnum_mac.value!=i)
			{
				alert(qos_policy_name_dup);
				return false;
			}
			if( cf.the_mac.value == each_info[3]  && cf.select_editnum_mac.value!=i)
			{
				alert(mac_dup);
				return false;
			}
		}
		else
		{   if( qos_array_num > 0)
            {
                for(j=1;j<=qos_array_num;j++)
	            {
	                var str_list= eval ( 'qosArray' +j);
	                var list_info= str_list.split(' ');
                    
					if( cf.qos_device_name.value == each_info[2]||cf.qos_device_name.value == list_info[7])
					{
						alert(device_name_dup);
						return false;
					}
					if( cf.qos_policy_name.value == each_info[0]||cf.qos_policy_name.value == list_info[0])
					{
						alert(qos_policy_name_dup);
						return false;
					}
					if( cf.the_mac.value == each_info[3]||cf.the_mac.value == list_info[8])
					{
						alert(mac_dup);
						return false;
					}
				}
			}
		}
	}	
	var def_name=cf.the_mac.value.substring(12,14)+cf.the_mac.value.substring(15,17);
	if(cf.qos_policy_name.value=='')
		cf.qos_policy_name.value='Pri_MAC_'+def_name;
	if (flag == 'add')
		cf.submit_flag.value="qos_addmac";
	else
		cf.submit_flag.value="qos_editmac";
		cf.action="/cgi-bin/setobject.cgi?/cgi-bin/qos_mac_add.html";
	cf.submit();
}

function valid_delete_qosmac(cf)
{
	if (qosmac_array_num ==0)
	{
		alert(no_serv_del);
		return false;
	}
	else if( cf.select_editnum_mac.value == '')
	{
		alert(select_serv_del);
		return false;
	}
	else
	{
		cf.submit_flag.value="qos_delmac";
		cf.action="/cgi-bin/setobject.cgi?/cgi-bin/qos_mac_add.html";
		cf.submit();
	}
}

function check_qos_mac(cf,flag)
{
	var cf=document.forms[0];	
	if( cf.select_editnum_mac.value == '')
	{
		alert(qos_mac_apply);
		return false;
	}	
	
	if(cf.qos_device_name.value=='')
	{
		alert(device_name_null);
		return false;
	}
	cf.the_mac.value = cf.mac_addr1.value+':'+cf.mac_addr2.value+':'+cf.mac_addr3.value+':'+
					  cf.mac_addr4.value+':'+cf.mac_addr5.value+':'+cf.mac_addr6.value;

	if(maccheck(cf.the_mac.value) == false)
			return false;
	var def_name=cf.the_mac.value.substring(12,13)+cf.the_mac.value.substring(15,16);
	if(cf.qos_policy_name.value=='')
		cf.qos_policy_name.value= 'Pri_MAC_'+def_name;

		
	
	if(flag == 'add')
	{
		
		if( qos_array_num > 0)
        {
            for(j=1;j<=qos_array_num;j++)
	        {
	            var str_list= eval ( 'qosArray' +j);
	            var list_info= str_list.split(' ');
	        

				if(cf.qos_device_name.value  == list_info[7]  && cf.select_editnum_mac.value!=j)
				{
					alert(device_name_dup);
					return false;
				}
				if(cf.qos_policy_name.value  == list_info[0]  && cf.select_editnum_mac.value!=j)
				{
					alert(qos_policy_name_dup);
					return false;
				}
				if(cf.the_mac.value  == list_info[8]  && cf.select_editnum_mac.value!=j)
				{
					alert(mac_dup);
					return false;
				}
		    }
		}	
	}
	else
	{
		if( qos_array_num > 0)
        {
            for(j=1;j<=qos_array_num;j++)
	        {
	            var str_list= eval ( 'qosArray' +j);
	            var list_info= str_list.split(' ');
	        

				if(cf.qos_device_name.value  == list_info[7]  && select_editnum!=j)
				{
					alert(device_name_dup);
					return false;
				}
				if(cf.qos_policy_name.value  == list_info[0]  && select_editnum!=j)
				{
					alert(qos_policy_name_dup);
					return false;
				}
				if(cf.the_mac.value  == list_info[8]  && select_editnum!=j)
				{
					alert(mac_dup);
					return false;
				}
		    }
		}	
	}
	if(flag == 'add')
		cf.submit_flag.value="add_qos_mac";
	else
		cf.submit_flag.value="edit_qos_mac";
	cf.action="/cgi-bin/setobject.cgi?/cgi-bin/qos.html";
	cf.submit();
}

function check_qoslist_delnum(cf)
{
	if( qos_array_num == 0 )
	{
		alert(no_serv_del);
		return false;
	}
	var count_select=0;
	var select_num;
	if( qos_array_num == 1)
	{
		if(cf.select_qos.checked == true)
		{
			count_select++;
			select_num=1;
		}
	}
	else for(i=0;i<qos_array_num;i++)
		if(cf.select_qos[i].checked == true)
		{
			count_select++;
			select_num=i+1;
		}
	if(count_select==0)
	{
		alert(select_serv_del);
		return false;
	}
	else
	{
		cf.select_del.value=select_num;
		cf.submit_flag.value="qos_del";
		cf.action="/cgi-bin/setobject.cgi?/cgi-bin/qos.html";	
		cf.submit();
	}
}

function check_qos_apply(cf)
{
	if(cf.enable_wmm.checked == true)
		cf.qos_endis_wmm.value=1;
	else
		cf.qos_endis_wmm.value=0;
		
	if(cf.turn_qos_on.checked == true)
		cf.qos_endis_on.value=1;
	else
		cf.qos_endis_on.value=0;
	cf.submit_flag.value="apply_qos";
	cf.action="/cgi-bin/setobject.cgi?/cgi-bin/qos.html";
	cf.submit();
}
