function clickFdefault(form)
{
	if(form.factory_default[0].checked)
	{
		if(confirm("This will reboot the AP and restore the settings to factory default."))
		{
			top.contents.location.href="menu.html";
			return true;
		}
	}
	else
	{
		alert("Please select 'yes' and then press [ Apply ] to reset AP into factory default settings.");
		return false;
	}
}