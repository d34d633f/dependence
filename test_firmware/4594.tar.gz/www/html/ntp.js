function check_ntp(cf)
{
		cfindex=cf.ntp_server.options[cf.ntp_server.selectedIndex].value;
	if( cfindex == "GMT+1" || cfindex == "GMT+2" || cfindex == "GMT+3" )
	{
		cf.ntpserver1.value="time-h.netgear.com";
		cf.ntpserver2.value="time-a.netgear.com";
	}
	else if( cfindex == "GMT+4" || cfindex == "GMT+5" || cfindex == "GMT+6" )
	{
		cf.ntpserver1.value="time-a.netgear.com";
		cf.ntpserver2.value="time-b.netgear.com";
	}
	else if( cfindex == "GMT+7" || cfindex == "GMT+8" || cfindex == "GMT+9" )
	{
		cf.ntpserver1.value="time-b.netgear.com";
		cf.ntpserver2.value="time-c.netgear.com";
	}
	else if( cfindex == "GMT+10" || cfindex == "GMT+11" || cfindex == "GMT+12" )
	{
		cf.ntpserver1.value="time-c.netgear.com";
		cf.ntpserver2.value="time-d.netgear.com";
	}
	else if( cfindex == "GMT-9" || cfindex == "GMT-10" || cfindex == "GMT-11" || cfindex=="GMT-12" )
	{
		cf.ntpserver1.value="time-d.netgear.com";
		cf.ntpserver2.value="time-e.netgear.com";
	}
	else if( cfindex == "GMT-6" || cfindex == "GMT-7" || cfindex == "GMT-8" )
	{
		cf.ntpserver1.value="time-e.netgear.com";
		cf.ntpserver2.value="time-f.netgear.com";
	}
	else if( cfindex == "GMT-3" || cfindex == "GMT-4" || cfindex == "GMT-5" )
	{
		cf.ntpserver1.value="time-f.netgear.com";
		cf.ntpserver2.value="time-g.netgear.com";	
	}
	else if( cfindex == "GMT-0" || cfindex == "GMT-1" || cfindex == "GMT-2" )
	{
		cf.ntpserver1.value="time-g.netgear.com";
		cf.ntpserver2.value="time-h.netgear.com";	
	}
	if(cf.adjust.checked == true)
	{
		cf.ntpadjust.value=1;
		cf.hidden_ntpserver.value=cf.ntp_server.value+"GMT";
	}
	else
	{
		cf.ntpadjust.value=0;
		cf.hidden_ntpserver.value=cf.ntp_server.value;
	}
	if(cf.enable_ntp.checked == true)
		cf.endis_ntp.value=1;
	else
		cf.endis_ntp.value=0;
	cf.hidden_select.value=cf.ntp_server.selectedIndex;
	return true;
}
