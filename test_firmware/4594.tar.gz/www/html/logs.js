function check_logs_clear(form)
{
	form.submit_flag.value="logs_clear";
	return true;
}

function check_logs_send(form)
{
	form.submit_flag.value="logs_send";
        return true;
}
