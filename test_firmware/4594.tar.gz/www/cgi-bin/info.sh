show_channel() #$1 for info_get_channel, $2 for gmode
{
        if [ "$1" = 0 ];then
               tmp_channel=$(iwlist ath0 channel | grep "Frequency" | awk '/Channel/{print $5}' | awk -F"\)" '{print $1}')
               if [ "x$tmp_channel" != "x" ];then
                       echo -n "auto($tmp_channel)"
               else
                       echo -n "--"
               fi
        else
               echo -n "$1"
        fi
}

show_region() #$1: country number
{
    case "$1" in
        0)
            echo -n $coun_af
            ;;
        1)
            echo -n $coun_as
            ;;
        2)
            echo -n $coun_au
            ;;
        3)
            echo -n $coun_ca
            ;;
        4)
            echo -n $coun_eu
            ;;
        5)
            echo -n $coun_fr
            ;;
        6)
            echo -n $coun_is
            ;;
        7)
            echo -n $coun_mx
            ;;
        8)
            echo -n $coun_sa
            ;;
        9)
            echo -n $coun_sa
            ;;
        10)
            echo -n $coun_us
            ;;
        *)
            echo -n $coun_no
            ;;
    esac
}

show_enc()
{
    case "$1" in
        2)
            echo -n $r_wep
            ;;
        3)
            echo -n $r_wpa
            ;;
        4)
            echo -n $r_wpa2
            ;;
        5)
            echo -n $r_wpas
            ;;
        *)
            echo -n $r_off
            ;;
    esac
}
show_wlap()
{
   case "$1" in
	0)
	    echo -n $r_off
	    ;;	
	1)
 	    echo -n $r_on
	    ;;
   esac
}
show_wlmode()
{
    case "$1" in
	1)
	    echo -n $wlan_mark_bo
	    ;;
	2)
	    echo -n $wlan_mark_go
	    ;;
	3)
	    echo -n $wlan_mark_gb
	    ;;
	4)
	    echo -n $wlan_mark_turbog
	    ;;
    esac	
}
show_brcname()
{
   case "$1" in
        0)
            echo -n $r_off
            ;;
        1)
            echo -n $r_on
            ;;
   esac
}
show_acl()
{
    if [ "$1" = "1" ]; then
        echo -n $r_allow
    elif [ "$1" = "2" ]; then
        echo -n $r_block
    else
        echo -n $r_disable
    fi
}

config_show_statistic()
{
	$nvram set timereset="$1"
}
