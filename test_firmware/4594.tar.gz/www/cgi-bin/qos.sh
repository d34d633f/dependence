config_qos_list_add ()
{
	add_num=$($nvram show | grep qos_list | grep -v ^size | wc -l)
	add_num=$(($add_num+1))
	$nvram set qos_list$add_num="$1 $2 $3 $4 $5 $6 $7 $8 $9"
}

config_qos_editnum()
{
	$nvram set qoslist_editnum=$1
}

config_qos_list_edit()
{
	edit_num=$($nvram get qoslist_editnum)
	$nvram set qos_list$edit_num="$1 $2 $3 $4 $5 $6 $7 $8 $9"
}

config_qos_list_del()
{
	#rm -f /tmp/configs/qos_list$1
	$nvram unset qos_list$1
	$nvram show | grep qos_list | grep -v ^size > /tmp/aa
	cat /tmp/aa | /bin/grep 'qos_list[0-9]=' > /tmp/cc
	cat /tmp/aa | /bin/grep 'qos_list[0-9][0-9]=' >> /tmp/cc
	mv /tmp/cc /tmp/aa

	line=`grep "qos_list" -c /tmp/aa`
	num=1
	while (test ${num} -le ${line})
	do
		name=`sed ''"${num}"'p' -n /tmp/aa | sed 's/qos_list.*=//'`
		qos_list_name=qos_list${num}
		$nvram set $qos_list_name="${name}"
		num=$(($num+1))
	done
	if [ $1 != ${num} ];then
		#rm -f /tmp/configs/qos_list${num}
		$nvram unset qos_list${num}
	fi
	rm -f /tmp/aa
}

config_qosmac_add ()
{
	add_num=$($nvram show | grep qos_mac_list | grep -v ^size | wc -l)
	add_num=$(($add_num+1))
	$nvram set qos_mac_list$add_num="$1 $2 $3 $4"
	$nvram set qos_mac_count=$(($add_num+1))
}

config_qosmac_edit ()
{
	edit_num="$5"
	$nvram set qos_mac_list$edit_num="$1 $2 $3 $4"
}

config_qos_list_edit_mac ()
{
	edit_num="${10}"
	$nvram set qos_list$edit_num="$1 $2 $3 $4 $5 $6 $7 $8 $9"
}
config_qosmac_del ()
{
	#rm -f /tmp/configs/qos_mac_list$1
	$nvram unset qos_mac_list$1
	$nvram show | grep qos_mac_list | grep -v ^size > /tmp/bb
	cat /tmp/bb | /bin/grep 'qos_mac_list[0-9]=' > /tmp/cc
	cat /tmp/bb | /bin/grep 'qos_mac_list[0-9][0-9]=' >> /tmp/cc
	mv /tmp/cc /tmp/bb

	line=`grep "qos_mac_list" -c /tmp/bb`
	num=1
	while (test $num -le $line)
	do
		name=`sed ''"$num"'p' -n /tmp/bb | sed 's/qos_mac_list.*=//'`
		qos_mac_list_name=qos_mac_list$num
		$nvram set $qos_mac_list_name="$name"
		num=$(($num+1))
	done
	if [ $1 != $num ];then
		rm -f /tmp/configs/qos_mac_list$num
		$nvram unset qos_mac_list$num
	fi
	rm -f /tmp/bb
}

config_apply_qos ()
{
	$nvram set qos_endis_wmm="$1" 
	$nvram set qos_endis_on="$2"
}
