config_acl() 
{
    $nvram set wl_access_ctrl_on=$1
	if [ "$1" = "1" ];then
		$nvram set apply_allow_maclist=$($nvram get add_allowlist)	
	elif [ "$1" = "2" ];then
		$nvram set apply_block_maclist=$($nvram get add_blocklist)	
	fi
	$nvram set acl_btn_mode=$2
}
