config_addmac()
{
    $nvram set hidden_acl_mode=$1
    $nvram set add_allowlist=$2
    $nvram set add_blocklist=$3
	$nvram set acl_btn_mode=$4
}

