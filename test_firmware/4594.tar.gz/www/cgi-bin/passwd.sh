config_currect_passwd() 
{
	$nvram set http_passwd=$1
	$nvram set router_passwd_length=$2
	$nvram set http_passwd_ok=0
}

config_error_passwd() 
{
	$nvram set http_passwd_ok=1
}