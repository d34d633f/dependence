config_ether()
{
	if [ $1 -eq 1 ]; then
		$nvram set lan_dhcp=0
		$nvram set lan_ipaddr=$2
		$nvram set lan_netmask=$3
		$nvram set lan_gateway=$4
	else
		$nvram set lan_dhcp=1
	fi
	$nvram set lan_ether_dns_assign=$5
	$nvram set lan_ether_dns1=$6
	$nvram set lan_ether_dns2=$7	
	$nvram set run_test="$8"
	#$nvram set port_speed=$9
}
active_lan()
{
    dhcp_enable=$($nvram get lan_dhcp)
    if [ "$dhcp_enable" = "0" ]; then
        killall udhcpc
        /sbin/ifconfig br0 "$($nvram get lan_ipaddr)" netmask "$($nvram get lan_netmask)"
    else
        killall udhcpc
        /sbin/ifconfig br0 0.0.0.0
        /sbin/udhcpc -i br0 &
    fi
}

