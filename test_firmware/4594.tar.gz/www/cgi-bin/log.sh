# prepare log
getlogs ()
{
	LOG_FILE=/var/log/messages

	if [ -s $LOG_FILE ]; then
		sed -n '1! G;$p;h' $LOG_FILE | sed -n '1,256 p' | sed '/CLEARCLEARCLEAR/,$d'
	else
		echo "The system doesn't have any logs yet"
	fi
}

logs_send ()
{
	email_get_addr=$($nvram get email_addr)
	email_get_smtp=$($nvram get email_smtp)
	email_get_username=$($nvram get email_username)
	email_get_password=$($nvram get email_password)
	email_get_from_assign=$($nvram get email_from_assign)
	email_get_this_addr=$($nvram get email_this_addr)
	email_subject="NETGEAR WPN824V3 Log"

	logger -- "[email sent to: $ADDRESS]"
	# send email script -f sender
	if [ "$email_get_from_assign" -eq 0 ]; then
		getlogs | /usr/sbin/smtpclient -s "$email_subject" -S $email_get_smtp \
				-f $email_get_addr -U $email_get_username \
				-P $email_get_password $email_get_addr > /dev/null 2> /tmp/sendemail_log_tmp
	else
		getlogs | /usr/sbin/smtpclient -s "$email_subject" -S $email_get_smtp \
				-f $email_get_this_addr -U $email_get_username \
				-P $email_get_password $email_get_addr > /dev/null 2> /tmp/sendemail_log_tmp
	fi
	stat=$?

	if [ "$stat" -ne 0 ]; then
		logger -- "[email failed] $(cat /tmp/sendemail_log_tmp)"
#	else
#		logger -- "CLEARCLEARCLEAR"
	fi
}
