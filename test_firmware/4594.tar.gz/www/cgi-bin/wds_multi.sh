config_wdsmulti() 
{
    $nvram set wds_mode=$1
	$nvram set wds_btn_mode=$2
	$nvram set wds_apply_maclist=$($nvram get wds_add_maclist)
    $nvram set wds_apply_ssidlist=$($nvram get wds_add_ssidlist)
	$nvram set wds_apply_chanlist=$($nvram get wds_add_chanlist)
	$nvram set wds_apply_signallist=$($nvram get wds_add_signallist)
	$nvram set wl_usermode="mtp"
}
