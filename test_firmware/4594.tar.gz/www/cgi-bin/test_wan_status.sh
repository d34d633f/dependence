#!/bin/sh
# test if route has valid Internet connection

SUCC_FILE=/tmp/determine_wan_success
FAIL_FILE=/tmp/determine_wan_fail

nvram=/usr/sbin/nvram
#wan_status="down"
#port_status=$(cat /tmp/port_status)
#info_get_wanproto=$($nvram get lan_dhcp)

#if [ "$info_get_wanproto" = "1" ]; then
#	vlan02_value=`ifconfig | grep ^vlan0002`
#	if [ "x$vlan02_value" != "x" ]; then
#		[ "$port_status" = "1" ] && wan_status="up"
#	fi
#elif [ "$info_get_wanproto" = "0" ]; then
#	vlan02_value=`ifconfig | grep ^vlan0002`
#	if [ "x$vlan02_value" != "x" ]; then
#		wan_status="up"
#	fi
#fi

if [ -f $SUCC_FILE ];then
	rm -f $SUCC_FILE
fi
if [ -f $FAIL_FILE ];then
	rm -f $FAIL_FILE
fi

ping -c 2 www.netgear.com > /tmp/netgear_ping
ping_num=`cat /tmp/netgear_ping | grep "received" | awk '{ print $4 }'`
rm /tmp/netgear_ping

if [ "x$ping_num" = "x" ];then
    ping_num="unreceived"
fi

if [ "$ping_num" = "unreceived" ]; then
	touch $FAIL_FILE
else
	touch $SUCC_FILE
fi

#sleep 12
#rm -f $SUCC_FILE
#rm -f $FAIL_FILE
