#the following line combines the last line to prevent this file been sourced twice
if [ "x$webupgrade_sh" = "x" ]; then webupgrade_sh="sourced"

INFO_HEAD=/tmp/image_info_head 
HEAD_SIZE=128
#KERNEL_SIZE=524288

NETGEAR_SITE_1="ftp://router-fw1.ftp.netgear.com"
NETGEAR_SITE_2=`echo $NETGEAR_SITE_1 |sed 's/1\./2./'`
NETGEAR_SITE_3=`echo $NETGEAR_SITE_1 |sed 's/1\./3./'`

CTL_FILE="WPN824EXT.LatestVersion"
CTL_FILE_FULLNAME="/files/firmware/WPN824EXT/$CTL_FILE"
CTL_FILE_CLN="/tmp/$CTL_FILE.cln"

IMPORT_FILE_NAME=/tmp/netgear-wpn824ext-image
IMAGE_FILE=$IMPORT_FILE_NAME
IMAGE_INFO_FILE="/tmp/image.info"
IMAGE_CRC_FILE="/tmp/image.crc"
IMAGE_INFO_FILE_SIZE=$APPENDED_INFO_SIZE
IMAGE_CRC_FILE_SIZE=$APPENDED_CRC_SIZE

WEBUPGRADE_CANCEL_TOUCH="/tmp/webupgrade-cancel.touch"

WEBUPGRADE_STAGE_1="download_control_file"
WEBUPGRADE_STAGE_2="download_image_file"
WEBUPGRADE_STAGE_3="imginstall"

WEBUPGRADE_STATUS_FILE="/tmp/webupgrade_status"
TMP_FIRMWARE_VER=/tmp/tmp_firmware_version

STATUS_INITIALIZING=0001
STATUS_0_PERCENT=1000
STATUS_5_PERCENT=1005
STATUS_25_PERCENT=1025
STATUS_33_PERCENT=1033
STATUS_50_PERCENT=1050
STATUS_66_PERCENT=1066
STATUS_75_PERCENT=1075
STATUS_100_PERCENT=1100

STATUS_FINISH=9999
STATUS_REBOOT=9999

STATUS_WAN_LINK_ERROR=10006
STATUS_DOWNLOAD_ERROR=10000
STATUS_UPLOAD_ERROR=10001
STATUS_CONTROL_FILE_ERROR=10002
STATUS_NO_NEWER_VER_ERROR=10003
STATUS_CHKSUM_ERROR=10004
STATUS_CHKINFO_ERROR=10005
STATUS_ERASE_KERNEL_ERROR=10010
STATUS_ERASE_JFFS2_ERROR=10011
STATUS_WRITE_KERNEL_ERROR=10012
STATUS_WRITE_JFFS2_ERROR=10013
STATUS_DOWNLOAD_CANCEL=20000

write_webupgrade_status() # $1: stage, $2: status_number
{
#	oc lockfile -1 $WEBUPGRADE_STATUS_LOCK_FILE
	echo "$1:$2" > $WEBUPGRADE_STATUS_FILE
#	oc rm -f $WEBUPGRADE_STATUS_LOCK_FILE
}

write_webupgrade_status_of_download_control_file() # $1: status_number
{
	write_webupgrade_status "$WEBUPGRADE_STAGE_1" "$1"
}

write_webupgrade_status_of_download_image_file() # $1: status_number
{
	write_webupgrade_status "$WEBUPGRADE_STAGE_2" "$1"
}

write_webupgrade_status_of_imginstall() # $1: status_number
{
	write_webupgrade_status "$WEBUPGRADE_STAGE_3" "$1"
}

get_webupgrade_status()
{
#	oc lockfile -1 $WEBUPGRADE_STATUS_LOCK_FILE
	echo "`awk -F: '{print $1, $2}' $WEBUPGRADE_STATUS_FILE`"
#	oc rm -f $WEBUPGRADE_STATUS_LOCK_FILE
}

get_webupgrade_status_in_stage() # $1: this_stage , #2: next_stage
{
	local this_stage=$1
	local next_stage=$2
	local webupgrade_stage webupgrade_status r_status

	set -- `get_webupgrade_status`
	webupgrade_stage=$1
	webupgrade_status=$2

	if [ "$webupgrade_stage" = "$this_stage" ] ; then
		r_status=$webupgrade_status
	elif [ "$webupgrade_stage" = "$next_stage" ] ; then
		r_status=$STATUS_FINISH
	else
		r_status=$STATUS_INITIALIZING
	fi

	echo "$r_status" 
}

get_webupgrade_status_in_download_control_file()
{
	echo "`get_webupgrade_status_in_stage $WEBUPGRADE_STAGE_1 $WEBUPGRADE_STAGE_2`"
}

get_webupgrade_status_in_download_image_file()
{
	echo "`get_webupgrade_status_in_stage $WEBUPGRADE_STAGE_2 $WEBUPGRADE_STAGE_3`"
}

get_webupgrade_status_in_imginstall()
{
	echo "`get_webupgrade_status_in_stage $WEBUPGRADE_STAGE_3 never_match`"
}

prepare_for_upgrade ()
{
	oc rm -f "/tmp/$CTL_FILE" "$CTL_FILE_CLN" 
	oc rm -f "$IMAGE_FILE" "$IMAGE_INFO_FILE" "$IMAGE_CRC_FILE"
	oc rm -f "$IMPORT_FILE_NAME"
	oc rm -f "$WEBUPGRADE_CANCEL_TOUCH" "$WEBUPGRADE_STATUS_FILE"
}

giveup_webupgrade_in_stage() # $1: stage, $2: status_number
{
	write_webupgrade_status "$1" "$2"
	oc sleep 5

	oc rm -f "$IMAGE_FILE"
	oc rm -f "$IMPORT_FILE_NAME"
	exit 0
}

giveup_webupgrade_in_download_control_file() # $1 : status_number
{
	giveup_webupgrade_in_stage "$WEBUPGRADE_STAGE_1" "$1"
}

giveup_webupgrade_in_download_image_file() # $1 : status_number
{
	giveup_webupgrade_in_stage "$WEBUPGRADE_STAGE_2" "$1"
}

giveup_webupgrade_in_imginstall() # $1 : status_number
{
	giveup_webupgrade_in_stage "$WEBUPGRADE_STAGE_3" "$1"
}

check_webupgrade_cancelled_in_stage() # $1: stage
{
	if [ -f $WEBUPGRADE_CANCEL_TOUCH ]; then
		oc echo -e "\nWebupgrade_cancelled in $1 !!"
		giveup_webupgrade_in_stage "$1" "$STATUS_DOWNLOAD_CANCEL"
	fi
}

check_webupgrade_cancelled_in_download_control_file() # $# = 0
{
	check_webupgrade_cancelled_in_stage "$WEBUPGRADE_STAGE_1"
}

check_webupgrade_cancelled_in_download_image_file() # $# = 0
{
	check_webupgrade_cancelled_in_stage "$WEBUPGRADE_STAGE_2"
}

prepare_ctl_file_cln() # $1: CTL_FILE, $2: CTL_FILE_CLN
{
	# delete null lines & comment lines & remove 'CR'
	grep -v -e '^[[:space:]]*$' "$1" | grep -v -e '^#' | sed 's/\(^[[:print:]]*\)\(.*\)/\1/' > "$2"
}

get_ctl_file_parameters() # $1: CTL_FILE_CLN
# output global variables : 
#		g_image_file_fullname,		eg: /files/firmware/wgt634u-1.4.0.5.img
#		g_image_server,				eg: router-fw1.ftp.netgear.com
#		g_image_file_size			eg: 4000000
#		g_image_file_name,			eg: wgt634u-1.4.0.5.img
#		g_image_ver_new,			eg: 1.4.0.5
#		g_image_ver_old,			eg: 1.3.0.0
#
{
		
	local device=$( echo $(cat /module_name))
	[ $(cat /firmware_region) = "FR" ] && device=$( echo $(cat /module_name)_FR)
	local line_number=`awk "/\\[$device\\]/ {print NR}" $1`
	local nr_1 nr_2 nr_3

	if [ $line_number ]; then
		nr_1=$(( $line_number + 1 ))
		nr_2=$(( $line_number + 2 ))
		nr_3=$(( $line_number + 3 ))
		g_image_file_fullname=`awk 'NR == '$nr_1' {print $1}' $1`
		g_image_server=`awk 'NR == '$nr_2' {print $1}' $1`
		g_image_file_size=`awk 'NR == '$nr_3' {print $1}' $1`
		g_image_file_name=${g_image_file_fullname##/*/}
		g_image_ver_new=`echo $g_image_file_name | sed "s/.*-//; s/.img//; s/[a-z.A-Z]*$//"`
		echo $g_image_ver_new > $TMP_FIRMWARE_VER
		g_image_ver_new=`echo $g_image_ver_new | sed "s/_/./; s/V//"`
		g_image_ver_old=`cat /firmware_version | sed 's/_/./; s/V//; s/RC.*//'`
		#g_image_ver_old="1.0.1.1.0.7"
		return 0
	else
		return 1
	fi
}

is_newer()  # $1,$2 is x.x.x.x, if $1 >= $2 return 0 else return 1
{
	local n1 o1

	n1=`echo $1 |awk '-F.' '{print $1}'`
	o1=`echo $2 |awk '-F.' '{print $1}'`
	if [ $n1 -gt $o1 ] ; then
		return 0
	elif [ $n1 -lt $o1 ] ; then
		return 1
	fi
	
	n1=`echo $1 |awk '-F.' '{print $2}'`
	o1=`echo $2 |awk '-F.' '{print $2}'`
	if [ $n1 -gt $o1 ] ; then
		return 0
	elif [ $n1 -lt $o1 ] ; then
		return 1
	fi
	
	n1=`echo $1 |awk '-F.' '{print $3}'`
	o1=`echo $2 |awk '-F.' '{print $3}'`
	if [ $n1 -gt $o1 ] ; then
		return 0
	elif [ $n1 -lt $o1 ] ; then
		return 1
	fi
	
	n1=`echo $1 |awk '-F.' '{print $4}'`
	o1=`echo $2 |awk '-F.' '{print $4}'`
	if [ $n1 -gt $o1 ] ; then
		return 0
	elif [ $n1 -lt $o1 ] ; then
		return 1
	fi

	n1=`echo $1 |awk '-F.' '{print $5}'`
	o1=`echo $2 |awk '-F.' '{print $5}'`
	if [ $n1 -gt $o1 ] ; then
		return 0
	elif [ $n1 -lt $o1 ] ; then
		return 1
	fi

	n1=`echo $1 |awk '-F.' '{print $6}'`
	o1=`echo $2 |awk '-F.' '{print $6}'`
	if [ $n1 -gt $o1 ] ; then
		return 0
	elif [ $n1 -lt $o1 ] ; then
		return 1
	fi

	return 1
}

write_mtd_upgrade_status () # write write mtd status
{
	write_webupgrade_status_of_imginstall 1002
	sleep 10
	write_webupgrade_status_of_imginstall 1010
	sleep 10
	write_webupgrade_status_of_imginstall 1020
	sleep 10
	write_webupgrade_status_of_imginstall 1030
	sleep 10
	write_webupgrade_status_of_imginstall 1040
	sleep 10
	write_webupgrade_status_of_imginstall 1050
	sleep 10
	write_webupgrade_status_of_imginstall 1060
	sleep 10
	write_webupgrade_status_of_imginstall 1070
	sleep 5
	write_webupgrade_status_of_imginstall 1080
	sleep 5
	write_webupgrade_status_of_imginstall 1090
}

chop_and_check_image_chksum() # $1: IMAGE_FILE
{
	oc /bin/imgchop "$1" "$1" "$IMAGE_CRC_FILE" "$IMAGE_CRC_FILE_SIZE"
	oc echo "$IMAGE_CRC_FILE : " ; oc cat "$IMAGE_CRC_FILE"
	check_chksum "$1" "$IMAGE_CRC_FILE"
}

extract_and_check_image_info() # $1: IMAGE_FILE
{
	/bin/imgextract "$1" "$IMAGE_INFO_SKIP_BYTES" "$IMAGE_INFO_FILE_SIZE" > "$IMAGE_INFO_FILE"
	oc echo "$IMAGE_INFO_FILE : " ; oc cat "$IMAGE_INFO_FILE"
	check_image_info_file "$IMAGE_INFO_FILE"
}

imginstall() # $1: useless head's offset
{
	local offset=0
	[ "$1" != "" ] && offset=$1
	local total_offset=$(($offset+$HEAD_SIZE))
	
	write_webupgrade_status_of_imginstall $STATUS_INITIALIZING

	dd if=$IMPORT_FILE_NAME of=$INFO_HEAD bs=1 count=128 skip=$offset

	# test head info: module_name
	module_name=$(cat /module_name)
	new_name=$(sed -n '1{p; q}' $INFO_HEAD | sed 's/.*://')
	if [ "$module_name" != "$new_name" ]; then
		oc echo "$IMPORT_FILE_NAME info_check fail !"
		rm -f $INFO_HEAD
		giveup_webupgrade_in_imginstall $STATUS_CHKINFO_ERROR
	fi

	#fw_version=$(cat /firmware_version)
	#fw_region=$(cat /firmware_region)

	# test checksum
	CHECKSUM=$(/sbin/mychecksum -o $offset -i $IMPORT_FILE_NAME | sed 's/,.*$//')
	if [ "$CHECKSUM" != "checksum = 0x00" ]; then
		oc echo "$IMPORT_FILE_NAME crc_check fail !"
		rm -f $INFO_HEAD
		giveup_webupgrade_in_imginstall $STATUS_CHKSUM_ERROR
	else
		oc echo "$IMPORT_FILE_NAME crc_check ok ..."
	fi

	write_mtd_upgrade_status &

	oc echo "begin to write kernel and rootfs, offset: $total_offset"
	oc kill -27 1
	mtd -o $total_offset upgrade $IMPORT_FILE_NAME /dev/mtd/3
	oc kill -24 1

	write_webupgrade_status_of_imginstall $STATUS_REBOOT
	sleep 8
}

imginstall_hide() # $1: useless head's offset
{
    local offset=0
    [ "$1" != "" ] && offset=$1
    local total_offset=$(($offset+$HEAD_SIZE))

    write_webupgrade_status_of_imginstall $STATUS_INITIALIZING

    dd if=$IMPORT_FILE_NAME of=$INFO_HEAD bs=1 count=128 skip=$offset

    # test head info: module_name

    #fw_version=$(cat /firmware_version)
    #fw_region=$(cat /firmware_region)

    # test checksum

    write_mtd_upgrade_status &

    oc echo "begin to write kernel and rootfs, offset: $total_offset"
    oc kill -27 1
    mtd -o $total_offset upgrade $IMPORT_FILE_NAME /dev/mtd/3
    oc kill -24 1

    write_webupgrade_status_of_imginstall $STATUS_REBOOT
    sleep 8
}

fi #-------------------- this must be the last line -----------------------------
