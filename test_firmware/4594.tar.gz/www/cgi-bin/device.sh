#!/bin/sh
. /www/cgi-bin/functions.sh

run_device()
{
    lan_get_ip=$($nvram get lan_ipaddr)
	lan_get_netmask=$($nvram get lan_netmask)
	nbtscan ${lan_get_ip}/${lan_get_netmask}
}	
