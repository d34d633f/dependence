config_welcome()
{
	$nvram set internet_type="$1"
	$nvram set wl_ssid="$3"
	$nvram set wl_channel="$4"
	$nvram set wl_sectype="$5"
	$nvram set wl_wpa1_psk="$6"
	$nvram set wl_wpa2_psk="$7"
	$nvram set wl_wpas_psk="$8"
	$nvram set wl_sec_wpaphrase_len="${9}"
	$nvram set wl_key1="${10}"
	$nvram set wl_key="1"
	$nvram set key_length="${11}"
	$nvram set dns_hijack="${12}"
	$nvram set blank_status="0"
	$nvram set endis_wl_radio=1
	#$nvram set after_welcome="1"
}
config_welcome_tmp()
{
	$nvram set internet_type="$1"
	$nvram set wl_ssid="$3"
	$nvram set wl_channel="$4"
	$nvram set wl_sectype="$5"
	$nvram set wl_wpa1_psk="$6"
	$nvram set wl_wpa2_psk="$7"
	$nvram set wl_wpas_psk="$8"
	$nvram set wl_sec_wpaphrase_len="${9}"
	$nvram set wl_key1="${10}"
	$nvram set wl_key="1"
	$nvram set key_length="${11}"
}
config_welcome_adva_nohijack()
{
	$nvram set dns_hijack=0
	$nvram set endis_wl_radio=1
	#$nvram set after_welcome="1"
}
