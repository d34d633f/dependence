#!/bin/sh
#########################
# 1) insert module
# 2) up interface
# 3) set vlan
# 4) set lan / wan mac
# 5) set bridge
# 6) set up lan ip
#########################
echo "begin $0"

fun_nvram_get(){
	if [ "$1" != "" ]; then
		ret=`nvram get $1`
	fi
	echo "$ret"
}


get_lan_mac(){
	mac_lan=`artblock_cmd get lan_mac`
	if [ "$mac_lan" = "" ]; then
		mac_lan=`nvram get lan_mac`
		if [ "$mac_lan" = "" ]; then
			mac_lan="00:03:7f:EE:EE:EE"
		fi
	else
		nvram set lan_mac=$mac_lan
	fi
	echo "$mac_lan"
}

get_wan_mac(){
        mac_wan=$(fun_nvram_get "wan_mac")
        if [ "$mac_wan" = "" ]; then
                mac_wan=`artblock_cmd get wan_mac`
                if [ "$mac_wan" = "" ]; then
			mac_wan="00:03:7f:EE:EE:EF"
                else
                        nvram set wan_mac=$mac_wan
                fi
        fi
        echo "$mac_wan"
}

hnat_enable=`nvram get hnat_enable`
[ -z "$hnat_enable" ] && hnat_enable="1"

lan_mac=$(get_lan_mac)
[ -z "$lan_mac" ] && lan_mac="00:03:7F:EE:EE:EE"

wan_mac=$(get_wan_mac)
[ -z "$wan_mac" ] && wan_mac="00:03:7F:EE:EE:EF"

lan_eth=`nvram get lan_eth`
[ -z "$lan_eth" ] && lan_eth="eth1.1"

wan_eth=`nvram get wan_eth`
[ -z "$wan_eth" ] && wan_eth="eth1.2"

lan_bridge=`nvram get lan_bridge`
[ -z "$lan_bridge" ] && lan_bridge="br0"

lan_ipaddr=`nvram get lan_ipaddr`
[ -z "$lan_ipaddr" ] && lan_ipaddr="192.168.0.1"

lan_netmask=`nvram get lan_netmask`
[ -z "$lan_netmask" ] && lan_netmask="255.255.255.0"

######################
# Main proceed flow  #
######################
# 1) insert module
if [ "$hnat_enable" = "0" ]; then
	echo "Inserting switch driver - HNAT NOT enable ..."
	insmod /lib/modules/2.6.31/net/athrs_gmac.ko enable_l3_offload=0
else
	echo "Inserting switch driver - HNAT enable ..."
	insmod /lib/modules/2.6.31/net/athrs_gmac.ko enable_l3_offload=1
fi

# 2) up interface
ifconfig eth0 up
ifconfig eth1 up

# 3) set vlan
vconfig add eth1 1
vconfig add eth1 2

# 4) set lan / wan mac
ifconfig $lan_eth hw ether $lan_mac
ifconfig $wan_eth hw ether $wan_mac

ifconfig $lan_eth up
ifconfig $wan_eth up
# 5) set bridge
# 6) set up lan ip
if [ "$lan_bridge" != "" ]; then
	brctl addbr $lan_bridge
	brctl stp $lan_bridge off
	brctl setfd $lan_bridge 0
	brctl addif $lan_bridge $lan_eth
	ifconfig $lan_bridge $lan_ipaddr netmask $lan_netmask
	ifconfig $lan_bridge up
	brctl addif $lan_bridge $lan_eth
else
	ifconfig $lan_eth $lan_ipaddr netmask $lan_netmask
	ifconfig $lan_eth up
fi

# 7) misc
# avoid eth0 send out DAD packet
echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6
# always disable ipv6 forward at startup time for support 6204bis G-3
echo 1 > /proc/sys/net/ipv6/disable_forward

#echo "Setting vlan ..."
#ethreg -i eth0 0x660=0x0014017e # Port0_Lookup_CTRL
#ethreg -i eth0 0x420=0x00010001 # PORT0_VLAN_CTRL0
#ethreg -i eth0 0x66c=0x0014017d # Port1_Lookup_CTRL
#ethreg -i eth0 0x428=0x00010001 # PORT1_VLAN_CTRL0
#ethreg -i eth0 0x678=0x0014017b # PORT2_LOOKUP_CTRL
#ethreg -i eth0 0x430=0x00010001 # PORT2_VLAN_CTRL0
#ethreg -i eth0 0x684=0x00140177 # PORT3_LOOKUP_CTRL
#ethreg -i eth0 0x438=0x00010001 # PORT3_VLAN_CTRL0
#ethreg -i eth0 0x690=0x0014016f # PORT4_LOOKUP_CTRL
#ethreg -i eth0 0x440=0x00010001 # PORT4_VLAN_CTRL0
#ethreg -i eth0 0x69c=0x0014015f # PORT5_LOOKUP_CTRL
#ethreg -i eth0 0x448=0x00020001 # PORT5_VLAN_CTRL0
#ethreg -i eth0 0x6a8=0x0004013f # PORT6_LOOKUP_CTRL
#ethreg -i eth0 0x450=0x00010001 # PORT6_VLAN_CTRL0
#ethreg -i eth0 0x610=0x001bd560 # Group Ports to VID 1
#ethreg -i eth0 0x614=0x80010002 # Group Ports to VID 1
#ethreg -i eth0 0x610=0x001b7fe0 # Group Ports to VID 2
#ethreg -i eth0 0x614=0x80020002 # Group Ports to VID 2
#ethreg -i eth0 0x424=0x00002040 # PORT0_VLAN_CTRL1
#ethreg -i eth0 0x42c=0x00001040 # PORT1_VLAN_CTRL1
#ethreg -i eth0 0x434=0x00001040 # PORT2_VLAN_CTRL1
#ethreg -i eth0 0x43c=0x00001040 # PORT3_VLAN_CTRL1
#ethreg -i eth0 0x444=0x00001040 # PORT4_VLAN_CTRL1
#ethreg -i eth0 0x44c=0x00001040 # PORT5_VLAN_CTRL1
#ethreg -i eth0 0x454=0x00001040 # PORT6_VLAN_CTRL1
#ethreg -i eth0 0x94=0x0000007e  # PORT6_STATUS
#ethreg -i eth0 0x0c=0x01000000  # PORT6 PAD MODE CTRL


#echo "Setting MODULE_EN"
#if [ "$hnat_enable" = "1" ]; then
#	ethreg -i eth0 0x30=0x80000307
#else
#	ethreg -i eth0 0x30=0x80000303
#fi

echo "end $0"
