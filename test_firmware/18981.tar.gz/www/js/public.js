﻿var time="<!--# echo session_timeout -->";
var global_timer_id=0;
var count_aniloader = 0;	
var percentage_aniloader=5;
var timer_id_aniloader = -1;
var type_aniloader=1;
var page_forward_need_flag=1;
var fw_upload=0;
var fw_check_type=0;//0: Enter by Firmware.htm, 1: Enter by index.htm
var aniloader_return="http://<!--# echo ap_device_name -->" +"/login_real.htm";
var spinner,spinner_S;
var opts = {
  lines: 12, // The number of lines to draw
  length: 10, // The length of each line
  width: 3, // The line thickness
  radius: 16, // The radius of the inner circle
  corners: 1, // Corner roundness (0..1)
  rotate: 0, // The rotation offset
  color: '#555', // #rgb or #rrggbb
  speed: 1, // Rounds per second
  trail: 60, // Afterglow percentage
  shadow: false, // Whether to render a shadow
  hwaccel: false, // Whether to use hardware acceleration
  className: 'spinner', // The CSS class to assign to the spinner
  zIndex: 2e9, // The z-index (defaults to 2000000000)
  top: '12', // Top position relative to parent in px
  left: '12' // Left position relative to parent in px
};
var opts_white = {
  lines: 12, // The number of lines to draw
  length: 10, // The length of each line
  width: 3, // The line thickness
  radius: 12, // The radius of the inner circle
  corners: 1, // Corner roundness (0..1)
  rotate: 0, // The rotation offset
  color: '#FFF', // #rgb or #rrggbb
  speed: 1, // Rounds per second
  trail: 60, // Afterglow percentage
  shadow: false, // Whether to render a shadow
  hwaccel: false, // Whether to use hardware acceleration
  className: 'spinner', // The CSS class to assign to the spinner
  zIndex: 2e9, // The z-index (defaults to 2000000000)
  top: '12', // Top position relative to parent in px
  left: '12' // Left position relative to parent in px
};

var loading_big_png = new Image();
loading_big_png.src = "image/loading_big.png";

function HASH_TABLE(){	
	this.hash_table = new Array();
}

HASH_TABLE.prototype={
	clear: function(){
		this.hash_table = new Array();
	},
	
	get: function(key){
		return this.hash_table[key];
	},
	
	put: function(key, value){
		if (key == null || value == null) {
			throw "NullPointerException {" + key + "},{" + value + "}";
		}else{
			this.hash_table[key] = value;
		}
	},
	
	size: function(){
		var size = 0;
		
		for (var i in this.hash_table){
			if (this.hash_table[i] != null){
				size++;
			}
		}
		
		return size;
	},
	
	isEmpty: function(){
		return (parseInt(this.size()) == 0) ? true : false;
	}
}

/**
value:type_aniloader
decide which kind of time for current page use
type_aniloader=1 -> 60sec
type_aniloader=2 -> 30sec
type_aniloader=3 -> 20sec
type_aniloader=4 -> 15sec
type_aniloader=5 -> 12sec
type_aniloader=6 -> 10sec
others -> 60sec
**/
var _menu_list_home = new Array("index.htm","Wireless_client.htm");
var _menu_list_settings = new Array("Wireless.htm","Extwireless.htm","Network.htm");
var _menu_list_management = new Array("Admin.htm","System.htm","Firmware.htm","Statistics.htm");

function jump_to(link){
	var tmp_link=gen_forward_link(link);
	window.location.href=tmp_link;
}

function language_menu_change(item,act){
	if(act==1){
		$("#"+item).css("display", "");
		$("#"+item+"_no").css("display", "none");
	}else if(act==0){
		$("#"+item).css("display", "none");
		$("#"+item+"_no").css("display", "");
	}
}

function gen_menu(obj){
	var str="";
	var lang_flag=0;

	if((internal_lang=="DE")||(internal_lang=="CS")||(internal_lang=="HR")||(internal_lang=="PL")||(internal_lang=="SL")){
		lang_flag=1;
	}

	if(lang_flag==1){
		str+="<div id=\"menu\" style=\"left:470px;width:460px\"><ul><li class=\"parent";
		str+="\" style=\"width:180px;height:46px\"><a ";
		if($.inArray(obj,_menu_list_home)==-1){
			str+="onmouseover=\"language_menu_change('menu_home_back',1)\" onmouseout=\"language_menu_change('menu_home_back',0)\"";
		} 
		str+=" onclick=\"jump_to('index.htm')\" style=\"cursor:pointer\"><!--div style=\"position:relative\"-->";
		str+="<div id=\"menu_home_back\" name=\"menu_home_back\" style=\"top: 0px; height:46px; position: relative;width:180px;";
		if($.inArray(obj,_menu_list_home)==-1){
			str+="display:none";
		} 
		str+="\"><img src=\"image/menu_select.jpg\" style=\"width:180px;height:46px\"></div>";
		str+="<div id=\"menu_home_back_no\" name=\"menu_home_back\" style=\"top: 0px; height:46px; position: relative;width:180px;";
		if($.inArray(obj,_menu_list_home)!=-1){
			str+="display:none";
		} 
		str+="\">&nbsp;</div>";
		str+="<div style=\"position:absolute;top:0px;left:0px;width:180px\"><script>show_words(_home);</script><!--/div-->";
		str+="</div></a></li>";
	}else{
		str+="<div id=\"menu\"><ul><li class=\"parent";
		
		if($.inArray(obj,_menu_list_home)!=-1){
			str+=" parentEnable";
		} 
		str+="\"><a onclick=\"jump_to('index.htm')\" style=\"cursor:pointer\"><script>show_words(_home);</script></a></li>";
	}

	str+="<li class=\"parent";
	
	if($.inArray(obj,_menu_list_settings)!=-1){
		str+=" parentEnable\" onmouseover=\"this.className='parentOn parentEnable'\" onmouseout=\"this.className='parent parentEnable'";
	}else{
		str+="\" onmouseover=\"this.className='parentOn parentEnable'\" onmouseout=\"this.className='parent'";
	}
	str+="\"><a onclick=\"\" style=\"cursor:pointer\"><script>show_words(_settings);</script></a>";
	str+="<ul><img src=\"image/this.png\" style=\"position: absolute;top: -7px;left: 63px;\" alt=\"\" width=\"14\" height=\"7\" />";
	str+="<li><a onclick=\"jump_to('Wireless.htm')\" style=\"cursor:pointer\"><script>show_words(_wifi);</script></a></li>";
	str+="<li><a onclick=\"jump_to('Extwireless.htm')\" style=\"cursor:pointer\"><script>show_words(_ext_wireless);</script></a></li>";
	str+="<li><a onclick=\"jump_to('Network.htm')\" style=\"cursor:pointer\"><script>show_words(_network);</script></a></li>";
	
	str+="</ul></li><li class=\"parent";
	if($.inArray(obj,_menu_list_management)!=-1){
		str+=" parentEnable\" onmouseover=\"this.className='parentOn parentEnable'\" onmouseout=\"this.className='parent parentEnable'";
	}else{
		str+="\" onmouseover=\"this.className='parentOn parentEnable'\" onmouseout=\"this.className='parent'";
	}
	str+="\"><a onclick=\"\" style=\"cursor:pointer\"><script>show_words(_management);</script></a>";
	str+="<ul><img src=\"image/this.png\" style=\"position: absolute;top: -7px;left: 63px;\" alt=\"\" width=\"14\" height=\"7\" />";
	str+="<li><a onclick=\"jump_to('Admin.htm')\" style=\"cursor:pointer\"><script>show_words(_admin);</script></a></li>";
	str+="<li><a onclick=\"jump_to('System.htm')\" style=\"cursor:pointer\"><script>show_words(_system);</script></a></li>";
	str+="<li><a onclick=\"jump_to('Firmware.htm')\" style=\"cursor:pointer\"><script>show_words(_upgrade);</script></a></li>";
	str+="<li><a onclick=\"jump_to('Statistics.htm')\" style=\"cursor:pointer\"><script>show_words(_stats);</script></a></li>";
	str+="</ul></li></ul></div>";

	document.write(str);
}
function createRequest() {
	var XMLhttpObject = false;
	if(window.XMLHttpRequest) {
		try {
			XMLhttpObject = new XMLHttpRequest();
		} catch (e) {
		}
	} else if(window.ActiveXObject) {
		try {
			XMLhttpObject = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try {
				XMLhttpObject = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e) {
				return null;
			}
		}
	}
	return XMLhttpObject;
}
function discard_duplicate(){
	var tmp_list;
	var tmp_count=0;
	tmp_list=site_list;
	site_list = new Array();

	for(var i=0; i<tmp_list.length; i++){
		var discard_flag=0;
		for(var j=0; j<tmp_count; j++){
			discard_flag=0;
			if(site_list[j].get("ssid")==tmp_list[i].get("ssid")){
				discard_flag++;
			}
			if(( (site_list[j].get("security").search("NONE")!=-1) && (tmp_list[i].get("security").search("NONE")!=-1) )||( (site_list[j].get("security").search("NONE")==-1) && (tmp_list[i].get("security").search("NONE")==-1) )){
				discard_flag++;
			}
			if(discard_flag==2){
				break;
			}
		}
		if(discard_flag<2){
			site_list.push(tmp_list[i]);
			tmp_count++;
		}

	}
}
function init_process_bar_T(msg){
	var tmp=0;
	percentage_aniloader = 0;

   	if(msg.match(/(default|wf)/)){
   		clearTimeout(global_timer_id);
   	}				
	if (timer_id_aniloader != -1){
		clearInterval(timer_id_aniloader);
	}
	if((type_aniloader>6)||(type_aniloader<0)){
		type_aniloader=1;
	}
	creat_ani_loader('ani_test');
}

function process_survey_ssid(tmp_ssid,prefix_count){
	if((prefix_count>0)&&(!isNaN(prefix_count))){
		if(tmp_ssid.length>prefix_count){
			return tmp_ssid.substr(0,prefix_count)+"...";
		}else{
			return tmp_ssid;
		}
	}else{
		return tmp_ssid;
	}
}
function change_bar_T(){
	if (percentage_aniloader < 300){
		percentage_aniloader += (5*type_aniloader);
		$("#loading_1 div").animate({width: (percentage_aniloader) + "px"});
		
	}else{
	}
}
function count_down_T(msg){
	var countdown_callback = function(){count_down_T(msg)};
	var count_seconds = parseInt(60/type_aniloader, 10);
	
	if (count_aniloader == count_seconds) {
		if(msg.match(/fw_upgrade/)) {
			get_by_id("show_sec").innerHTML = "100%";
		} else {
			get_by_id("show_sec").innerHTML = "0";
			
			if (msg == 'wf' || msg =='default')
				get_by_id("btn_reconnect_confirm").style.display="";
		}

		if(msg.match(/(gen|fw_upgrade)/)){	
			location.href = aniloader_return;
		}
		return;
	} else {
		if(msg.match(/fw_upgrade/)) {
			get_by_id("show_sec").innerHTML = parseInt(100*count_aniloader*type_aniloader/60)+'%';			
		} else {
			get_by_id("show_sec").innerHTML = count_seconds-count_aniloader;
		}
		count_aniloader++;
		setTimeout(countdown_callback, 1100);
	}
}

function select_msg(msg){
	var msg_mapping = {
		'default': _msg_default_save,
		'wf' : _msg_wf_save,
		'gen' : _gensave
	};	
	var adj_height ={
		'default': 20,
		'fw_upgrade' : 40,
		'wf' : 10,
		'gen' : 40
	};
	var str  = '<div id=\"boder_block\" style=\"height:'+ adj_height[msg] + 'px\"></div><div id=\"aniloader_bk\">';
	
	if (msg == 'wf' || msg =='default'){
		var button_left = "";
		var image_width = "";
		var msg_left = "";
		
		if (msg == 'default'){
			button_left = "165px";
			image_width = "450px";
			msg_left = "330px";
		}else {
			button_left = "150px";
			image_width = "420px";
			msg_left = "290px";
		}	
		str += '<img src=\"' + loading_big_png.src + '\" width=\"'+ image_width +'\" height=\"'+ image_width +'\" /></div>';
		str += '<div id=\"aniloader\"><span id=\"ani_test\"></span></div>';		
		str += '<div id=\"aniloader_title3\" style=\"width: '+ msg_left +';left: 60px;height: 170px;\">';  	
		str += '<table style=\"height: 170px;\"><tr><td valign=\"middle\" align=\"center\">';
		str += '<div id=\"aniloader_info\" style=\"color:#000000;font:12pt Arial;height:30px;line-height:30px\"><span id=\"show_sec\"></span>&nbsp;'+_seconds_c+'</div><div>' + msg_mapping[msg] + '</div></td></tr></table></div>';
		str += '<div id=\"btn_reconnect_confirm\" class=\"Styled-btn-w\" onclick=\"uLightBoxTS.clear();\" style=\"top:10px;left:' + button_left + ';cursor:pointer;display:none\">'+_ok+'</div>';
	}else{
		str += '<img src=\"'+ loading_big_png.src +'\" width="368" height="368" /></div>';
		if(msg != 'fw_upgrade') {
			str += '<div id=\"aniloader\"><span id=\"ani_test\"></span></div>';				
			str += '<div id=\"aniloader_title3\"><table><tr><td valign=\"middle\" align=\"center\">'
			str += '<div id=\"aniloader_info\" style=\"color:#000000;font:12pt Arial\">';
			str += '<span id=\"show_sec\"></span>&nbsp;'+_seconds_c+'&nbsp;</div>'+ msg_mapping[msg] +'';	
			str += '</td></tr></table></div>';
		} else {		
			str += '<div id=\"aniloader_info\" style=\"color:#000000;font:12pt Arial;font-weight: 600;\">'+_upgrading+'...&nbsp;<span id=\"show_sec\"></span></div>';
			str += '<div id=\"aniloader\"><span id=\"ani_test\"></span></div>';
			str += '<div id=\"aniloader_title2\" style=\"text-align:left;width:230px;left:65px\">';
			str += '<table><tr><td valign=\"middle\" align=\"center\">';
			str += _fw_upload_warm +'</td></tr></table></div>';
		}
	}

	return str;
}

function reboot_bar(msg){
	var box_width="368px";
	if(msg=='default'){
		box_width="450px";
	}else if(msg=='wf'){
		box_width="420px";
	}

	uLightBoxTS.init({
        override:true,
        background: 'black',
        centerOnResize: true,
        fade: true
    });
    uLightBoxTS.alert({
    width: box_width,    
    title: '',
    opened: function(){                
        	get_by_id("lbContentTS").innerHTML = select_msg(msg);
       	}
   	});
   	
  	init_process_bar_T(msg);
   	count_down_T(msg);
}

function creat_ani_loader(target){
   	var target = document.getElementById(target);
	spinner = new Spinner(opts).spin(target);
}
function creat_ani_loader_s(target){
   	var target = document.getElementById(target);
	spinner_S = new Spinner(opts_white).spin(target);
}
function time_out(){
	time=time-1;
	if(time<0){
		window.location.href="login_real.htm";
	}
	global_timer_id=setTimeout("time_out()",1000);
}

function show_words(word)
{
	with(document){
		return write(word);
	}
}
function get_by_id(id){
	with(document){
		return getElementById(id);
	}
}

var key_num_array = new Array("64", "128");
var all_ip_addr_msg = new Array(
MSG006, MSG007, MSG002, MSG002, MSG002, MSG002, 
MSG026, MSG027, MSG028, MSG029, TEXT031, TEXT032,
TEXT030, MSG003a);

//IPV6
var all_ipv6_addr_msg = new Array(
MSG006,	MSG007,	MSG018, MSG019, MSG020, MSG021, MSG022, MSG023, MSG024, MSG025,
MSG026, MSG027, MSG028, MSG029, MSG030, MSG031, MSG032, MSG033, "",  "",	
MSG034, MSG035
);

var check_num_msg = new Array(check_num_msg1,check_num_msg2,check_num_msg3,check_num_msg4);

//many pages will use the array.
var subnet_mask_msg = new Array(
SUBMASK_0, SUBMASK_1, SUBMASK_2, SUBMASK_3, SUBMASK_4, 
SUBMASK_5, SUBMASK_6, SUBMASK_7, SUBMASK_8, SUBMASK_9);
var subnet_mask = new Array(0, 128, 192, 224, 240, 248, 252, 254, 255);
function addr_obj(addr, e_msg, allow_zero, is_network){
	this.addr = addr;
	this.e_msg = e_msg;
	this.allow_zero = allow_zero;		
	this.is_network = is_network;
}

function ipv6_addr_obj(addr, e_msg, allow_zero, is_network){
	this.addr = addr;
	this.e_msg = e_msg;
	this.allow_zero = allow_zero;	
	this.is_network = is_network;	
}

function varible_obj(var_value, e_msg, min, max, is_even){
	this.var_value = var_value;
	this.e_msg = e_msg;
	this.min = min;
	this.max = max;		
	this.is_even = is_even;		
}

function Find_word(strOrg,strFind){
	var index = 0;
	index = strOrg.indexOf(strFind,index);
	if (index > -1){
		return true;
	}
	return false;
}

function check_varible(obj){
	var temp_obj = obj.var_value.split(" ");

	if (temp_obj == "" || temp_obj.length > 1){
//		alert(MSG012);
		alert(obj.e_msg[0]);//EMPTY_VARIBLE_ERROR
		return false;
	}else if (isNaN(obj.var_value) || Find_word(obj.var_value,".")){
//		alert(MSG013);
		alert(obj.e_msg[1]);//INVALID_VARIBLE_ERROR
		return false;
	}else if (parseInt(obj.var_value) < obj.min || parseInt(obj.var_value) > obj.max){
//		alert(MSG014);
		alert(obj.e_msg[2]);//VARIBLE_RANGE_ERROR
		return false;
	}else if (obj.is_even && (parseInt(obj.var_value) % 2 != 0)){
//		alert(MSG015);
		alert(obj.e_msg[3]); //EVEN_NUMBER_ERROR
		return false;
	}
	return true;
}

function transValue(data)
{
	var value =0;
	data = data.toUpperCase();

	if(data == "0")
		value =0;
	else if(data =="1")
		value = 1;
	else if(data =="2")
		value = 2;
	else if(data =="3")
		value = 3;
	else if(data =="4")
		value = 4;	
	else if(data =="5")
		value = 5;
	else if(data =="6")
		value = 6;
	else if(data =="7")
		value = 7;
	else if(data =="8")
		value = 8;
	else if(data =="9")
		value = 9;
	else if(data =="A")
		value = 10;
	else if(data =="B")
		value = 11;
	else if(data =="C")
		value = 12;
	else if(data =="D")
		value = 13;
	else if(data =="E")
		value = 14;
	else if(data =="F")
		value = 15;				
	else
		value = 0;
	return value ;				
}

function check_ipv6_symbol(strOrg,strFind){
	/*For fitting old check_ipv6_address function use*/	
	/*if false return 2, if have double-colon return 1, completely IPv6 address return 0*/
	var symbol_count=0; 
	var _index = 0;
	var current_index =-1;
	var dc_flag=0; 
	strFind = ":";	
	for (_index=0;_index<strOrg.length;_index++) {
		_index = strOrg.indexOf(strFind,_index);	
		if(_index<=-1)	
			break;
		else{
			if(_index == -1){
				return -1;
			}else{
				symbol_count++;
				if((_index-current_index)==1){
					dc_flag++;
					if(dc_flag>1){
						alert(ipv6_ip_double_colon);
						return 2;
					}
				}	
				current_index = _index;	
			}	
		}	
	}
	if(symbol_count<2 || symbol_count>7){ 
		alert(ipv6_ip_illegal_arr);
		return 2;	
	}	
	if(symbol_count>=2 && symbol_count<7 && dc_flag==0){	
		alert(ipv6_ip_illegal_arr);
		return 2;	
	}	
	if(symbol_count>7 && dc_flag>0){ 
		alert(ipv6_ip_illegal_arr);
		return 2;
	}	
	return dc_flag;
} 

/* For status v6 address shown,
[Rule] if DUT got Global + ULA address: shown Global address only.
	   if DUT got ULA address only: shown ULA address only.
 */
function v6_global_addr(ip){
	var v6_ip="", v6_ip_new="", ula_addr="", global_addr="";

	v6_ip = ip.toUpperCase().split(",");
	for(var idx=0; idx<v6_ip.length; idx++){	
		if((v6_ip[idx].charAt(0)=="F") && (v6_ip[idx].charAt(1)=="C" || v6_ip[idx].charAt(1)=="D")){	// check ULA address.
			ula_addr += v6_ip[idx]+"<br>";	// let ULA address together.
		}else{
			global_addr += v6_ip[idx]+"<br>";	// let Global address together.
		}
	}

	v6_ip_new = (global_addr != "")?global_addr:ula_addr;
	return v6_ip_new;
}

function check_ipv6_address(my_obj,strFind){
	var ip = my_obj.addr;
	var count_zero=0; 
	var ip_temp;
	var sum = 0;
	var ipv6_field_number = 0;
	if(strFind == "::"){ 
		if (my_obj.addr.length == 2){ 
			if(ip[0].charAt(0) =="f" || ip[0].charAt(0) =="F"){
				if(ip[0].charAt(1) =="f" || ip[0].charAt(1) =="F"){
					alert(my_obj.e_msg[21]);//IPv6_MULTICASE_IP_ERROR
					return false;
				}	
			}	
			for(var i = 0; i < 2; i++){	
				ip_temp = ip[i].split(":");
				for(var index =0; index < ip_temp.length; index++){
					if(ip_temp[index].length == 0 || ip_temp[index].length > 4){
						alert(my_obj.e_msg[0]); //IPv6_INVALID_IP
						return false;
					}
					for(var pos =0; pos < ip_temp[index].length ;pos++){
						if(!check_hex(ip_temp[index].charAt(pos))){
							alert(my_obj.e_msg[2+ipv6_field_number]); //IPv6_FIRST_IP_ERROR
							return false;
						}
						sum += transValue(ip_temp[index].charAt(pos))*(pos+1);	
					}
					ipv6_field_number++;	
				}
			}
			if(sum == 0){ 
				alert(my_obj.e_msg[1]);//IPv6_ZERO_IP
				return false; 
			}
		}else{	
			alert(my_obj.e_msg[0]); //IPv6_INVALID_IP
			return false;
		}
	} else{	
		if (my_obj.addr.length == 8){ 
			if(ip[0].charAt(0) =="f" || ip[0].charAt(0) =="F"){
				if(ip[0].charAt(1) =="f" || ip[0].charAt(1) =="F"){
					alert(my_obj.e_msg[21]);//IPv6_MULTICASE_IP_ERROR
					return false;
				}	
			}	
			for(var i = 0; i < ip.length; i++){
				if (ip[i] == "0"){
					count_zero++;
				}else if((ip[i].charAt(0) =="0") && (ip[i].charAt(1) =="0")){
					count_zero++;	
				}else if((ip[i].charAt(0) =="0") && (ip[i].charAt(1) =="0") && (ip[i].charAt(2) =="0")){
					count_zero++;	
				}else if((ip[i].charAt(0) =="0") && (ip[i].charAt(1) =="0") && (ip[i].charAt(2) =="0") && (ip[i].charAt(3) =="0")){
					count_zero++;	
				}
			} 
			if (!my_obj.allow_zero && count_zero == 8){	
				alert(my_obj.e_msg[1]);	//IPv6_ZERO_IP
				return false; 
			}else{
				count_zero=0;
				for(var i = 0; i < ip.length; i++){
					if(ip[i].length > 4 || ip[i].length == 0){
						alert(my_obj.e_msg[0]);//IPv6_INVALID_IP
						return false;
					}
					for(var index =0; index < ip[i].length ;index++){
						if(!check_hex(ip[i].charAt(index))){
							alert(my_obj.e_msg[2+i]); //IPv6_FIRST_IP_ERROR
							return false;
						}
					}
				}
			}
		}else{	
			alert(my_obj.e_msg[0]);//IPv6_INVALID_IP
			return false;
		}	
	}
	return true;
} 


function replace_msg(obj_S){
	obj_D = new Array();
	for (i=0;i<obj_S.length;i++){
		obj_D[i] = obj_S[i];
		if((i==2)&&(obj_D[i]==MSG002)){
			obj_D[i] = obj_D[i].replace("%s", "1st");
		}
		if((i==3)&&(obj_D[i]==MSG002)){
			obj_D[i] = obj_D[i].replace("%s", "2nd");
		}
		if((i==4)&&(obj_D[i]==MSG002)){
			obj_D[i] = obj_D[i].replace("%s", "3rd");
		}
		if((i==5)&&(obj_D[i]==MSG002)){
			obj_D[i] = obj_D[i].replace("%s", "4th");
		}
		obj_D[i] = addstr(obj_D[i], replace_msg.arguments[1]);
		obj_D[i] = obj_D[i].replace("%1n", replace_msg.arguments[2]);
		obj_D[i] = obj_D[i].replace("%2n", replace_msg.arguments[3]);
	}
	return obj_D;
}
function addstr(input_msg)
{
	var last_msg = "";
	var str_location;
	var temp_str_1 = "";
	var temp_str_2 = "";
	var str_num = 0;
	temp_str_1 = addstr.arguments[0];
	while(1)
	{
		str_location = temp_str_1.indexOf("%s");
		if(str_location >= 0)
		{
			str_num++;
			temp_str_2 = temp_str_1.substring(0,str_location);
			last_msg += temp_str_2 + addstr.arguments[str_num];
			temp_str_1 = temp_str_1.substring(str_location+2,temp_str_1.length);
			continue;
		}
		if(str_location < 0)
		{
			last_msg += temp_str_1;
			break;
		}
	}
	return last_msg;
}

function check_domain(ip, mask, gateway){
	var temp_ip = ip.addr;
	var temp_mask = mask.addr;
	var temp_gateway = gateway.addr;
	var temp_str = "";

	for (var i = 0; i < 4; i++){
		temp_str += temp_gateway[i];

		if (i < 3){
			temp_str += ".";
		}
	}

	if (gateway.allow_zero && (temp_str == "0.0.0.0" || temp_str == "...")){
		return true;
	}

	for (var i = 0; i < temp_ip.length; i++){
		if ((temp_ip[i] & temp_mask[i]) != (temp_gateway[i] & temp_mask[i])){
			return false;		// when not in the same subnet mask, return false
		}
	}

	return true;
}

function check_ip_range(order, my_obj, mask){
	var which_ip = (my_obj.addr[order]).split(" ");
	var start, end;

	if (isNaN(which_ip) || which_ip == "" || which_ip.length > 1 || (which_ip[0].length > 1 && which_ip[0].substring(0,1) == "0")){	// if the address is invalid
		alert(my_obj.e_msg[2 + order]);
		return false;
	}

	if (order == 0){				// the checking range of 1st address
		start = 1;
	}else{
		start = 0;
	}

	if (mask[order] != 255){		
		if (parseInt(which_ip) >= 0 && parseInt(which_ip) <= 255){	
			end = (~mask[order]+256);				
			start = mask[order] & which_ip;	
			end += start;

			if (end > 255){
				end = 255;
			}
		}else{
			end = 255;
		}
	}else{
		end = 255;
	}


	if (order == 3){
		if ((mask[0] == 255) && (mask[1] == 255) && (mask[2] == 255)){
			start += 1;
			end -= 1;
		}else{
			if (((mask[0] | (~my_obj.addr[0]+256)) == 255) && ((mask[1] | (~my_obj.addr[1]+256)) == 255) && ((mask[2] | (~my_obj.addr[2]+256)) == 255)){
				start += 1;
			}

			if (((mask[0] | my_obj.addr[0]) == 255) && ((mask[1] | my_obj.addr[1]) == 255) && ((mask[2] | my_obj.addr[2]) == 255)){			
				end -= 1;
			}				
		}
	}

	if (parseInt(which_ip) < start || parseInt(which_ip) > end){			
		alert(my_obj.e_msg[6 + order] + " " + start + " ~ " + end + "."); //FIRST_RANGE_ERROR=6
		return false;
	}

	return true;
}

function check_current_range(order, my_obj, checking_ip, mask){
	var which_ip = (my_obj.addr[order]).split(" ");
	var start, end;

	if (isNaN(which_ip) || which_ip == "" || which_ip.length > 1 || (which_ip[0].length > 1 && which_ip[0].substring(0,1) == "0")){	// if the address is invalid
		alert(my_obj.e_msg[2 + order]);
		return false;
	}

	if (order == 0){				// the checking range of 1st address
		start = 1;	
	}else{
		start = 0;				
	}

	if (mask[order] != 255){				
		if (parseInt(checking_ip[order]) >= 0 && parseInt(checking_ip[order]) <= 255){	
			end = (~mask[order]+256);				
			start = mask[order] & checking_ip[order];	
			end += start;

			if (end > 255){
				end = 255;
			}
		}else{
			end = 255;
		}
	}else{
		end = 255;
	}

	if (order == 3){
		if ((mask[0] == 255) && (mask[1] == 255) && (mask[2] == 255)){
			start += 1;
			end -= 1;
		}else{		
			if (((mask[0] | (~my_obj.addr[0]+256)) == 255) && ((mask[1] | (~my_obj.addr[1]+256)) == 255) && ((mask[2] | (~my_obj.addr[2]+256)) == 255)){
				start += 1;
			}

			if (((mask[0] | my_obj.addr[0]) == 255) && ((mask[1] | my_obj.addr[1]) == 255) && ((mask[2] | my_obj.addr[2]) == 255)){			
				end -= 1;
			}	
		}	
	}

	if (parseInt(which_ip) < start || parseInt(which_ip) > end){			
		alert(my_obj.e_msg[6 + order] + " " + start + " ~ " + end + ".");		
		return false;
	}

	return true;
}

function check_hex(data){
	data = data.toUpperCase();
	for (var i = 0; i < data.length; i++){	
		var temp_char = data.charAt(i);
		
		if (!(temp_char >= 'A' && temp_char <= 'F') && !(temp_char >= '0' && temp_char <= '9')){	
			return false;
		}
	}
	return true;
}										
function check_address(my_obj, mask_obj, ip_obj){
	var count_zero = 0;
	var count_bcast = 0;	
	var ip = my_obj.addr;
	var mask;

	if (my_obj.addr.length == 4){
		// check the ip is not multicast IP (127.x.x.x && 224.x.x.x ~ 239.x.x.x)
		if((my_obj.addr[0] == "127") || ((my_obj.addr[0] >= 224) && (my_obj.addr[0] <= 239))){
			alert(my_obj.e_msg[12]); //MULTICASE_IP_ERROR
			return false;
		}
		// check the ip is "0.0.0.0" or not
		for(var i = 0; i < ip.length; i++){
			if (ip[i] == "0"){
				count_zero++;			
			}
		}

		if (!my_obj.allow_zero && count_zero == 4){	// if the ip is not allowed to be 0.0.0.0
			alert(my_obj.e_msg[1]);			// but we check the ip is 0.0.0.0
			return false;
		}else if (count_zero != 4){		// when IP is not 0.0.0.0, checking range. Otherwise no need to check		
			count_zero = 0;

			if (check_address.arguments.length >= 2 && mask_obj != null){
				mask = mask_obj.addr;
			}else{
				mask = new Array(255,255,255,0);
			}

			for(var i = 0; i < ip.length; i++){

				if (check_address.arguments.length == 3 && ip_obj != null){
					if (!check_current_range(i, my_obj, ip_obj.addr, mask)){
						return false;
					}
				}else{					
					if (!check_ip_range(i, my_obj, mask)){
						return false;
					}
				}
			}		

			for (var i = 0; i < 4; i++){	// check the IP address is a network address or a broadcast address																							
				if (((~mask[i] + 256) & ip[i]) == 0){	// (~mask[i] + 256) = reverse mask[i]
					count_zero++;						
				}

				if ((mask[i] | ip[i]) == 255){
					count_bcast++;
				}
			}

			if ((count_zero == 4 && !my_obj.is_network) || (count_bcast == 4)){
				alert(my_obj.e_msg[13]);			
				return false;
			}													
		}
	}else{	// if the length of ip is not correct, show invalid ip msg
		alert(my_obj.e_msg[13]);
		return false;
	}

	return true;
}

function check_mask(my_mask){
	var temp_mask = my_mask.addr;

	if (temp_mask.length == 4){
		for (var i = 0; i < temp_mask.length; i++){
			var which_ip = temp_mask[i].split(" ");
			var mask = parseInt(temp_mask[i]);
			var in_range = false;
			var j = 0;

			if (isNaN(which_ip) || which_ip == "" || which_ip.length > 1 || (which_ip[0].length > 1 && which_ip[0].substring(0,1) == "0")){	// if the address is invalid
				alert(my_mask.e_msg[2 + i]);
				return false;
			}

			if (i == 0){	// when it's 1st address
				j = 1;		// the 1st address can't be 0
			}

			for (; j < subnet_mask.length; j++){
				if (mask == subnet_mask[j]){
					in_range = true;
					break;
				}else{
					in_range = false;
				}
			}

			if (!in_range){
				alert(my_mask.e_msg[6 + i]);
				return false;
			}

			if (i != 0 && mask != 0){ // when not the 1st range and the value is not 0
				if (parseInt(temp_mask[i-1]) != 255){  // check the previous value is 255 or not
					alert(ipaddr_msg0);
					return false;
				}
			}

			if (i == 3 && (parseInt(mask) == 254 || parseInt(mask) == 255)){	// when the last mask address is 255
				alert(subnet_mask_msg[9]);
				return false;
			}
		}
	}else{
		alert(my_mask.e_msg[0]);//INVALID_IP
		return false;
	}

	return true;
}

function get_by_name(name){
	with(document){
		return getElementsByName(name);
	}
}
function set_selectIndex(which_value, obj){
	for (var pp=0; pp<obj.options.length; pp++){
		if (which_value == obj.options[pp].value){
			obj.selectedIndex = pp;
			break;
		}
	}
}

function set_checked(which_value, obj){
	if(obj.length > 1){
		obj[0].checked = true;
		for(var pp=0;pp<obj.length;pp++){
			if(obj[pp].value == which_value){
				obj[pp].checked = true;
			}
		}
	}else{
		obj.checked = false;
		if(obj.value == which_value){
			obj.checked = true;
		}
	}
}
function isExist_var(obj)
{
	return ((get_by_id(obj) != null ) ? true : false); 
}
function getVal(obj)
{
	/* maybe need to justify obj type */
	return get_by_id(obj).value;
}
function wps_behavior(security, cipher, broadcast)
{

	if (broadcast) {
		get_by_id("wps_enable").value = 0;
		return true;
	}
	
	if (security.match(/wep/g)) {
		get_by_id("wps_enable").value = 0;
		return true;
	}

	if (security.match(/_psk/g) && cipher == "tkip") {
		get_by_id("wps_enable").value = 0;
		return true;
	}

	if (security.match(/_eap/g)) {			//WPA-Enterprise
		get_by_id("wps_enable").value = 0;
		return true;
	}

	return false;
}


function isWpsGrayOut(obj)
{
	var wlan0_en = isExist_var("wlan0_enable") ? getVal("wlan0_enable") : "-1";
	var wlan1_en = isExist_var("wlan1_enable") ? getVal("wlan1_enable") : "-1";

	var wlan0_sec = isExist_var("wlan0_security") ? getVal("wlan0_security") : "-1";
	var wlan1_sec = isExist_var("wlan1_security") ? getVal("wlan1_security") : "-1";

	var wlan0_cipher =  isExist_var("wlan0_psk_cipher_type") ? getVal("wlan0_psk_cipher_type") : "-1";
	var wlan1_cipher =  isExist_var("wlan1_psk_cipher_type") ? getVal("wlan1_psk_cipher_type") : "-1";

	var wlan0_bcast = isExist_var("wlan0_ssid_broadcast") ?  getVal("wlan0_ssid_broadcast") : "-1";
	var wlan1_bcast = isExist_var("wlan1_ssid_broadcast") ?  getVal("wlan1_ssid_broadcast") : "-1";

	var vflag = false;
	if (wlan0_en == "1") {
		if (wps_behavior(wlan0_sec, wlan0_cipher, !parseInt(wlan0_bcast))) {
			vflag = true;
		}
	} else if(wlan0_en == "0") {
		get_by_id("wps_enable").value = 0;
		vflag = true;
	}

	if (wlan1_en == "1") {
		if (wps_behavior(wlan1_sec, wlan1_cipher, !parseInt(wlan1_bcast))) {
			vflag =true;
		}
	} else if(wlan1_en == "0") {
		get_by_id("wps_enable").value = 0;
		vflag = true;
	}

	get_by_id(obj).disabled = vflag;
}
function get_checked_value(obj){
	if(obj.length > 1){
		for(var pp=0;pp<obj.length;pp++){
			if(obj[pp].checked){
				return obj[pp].value;
			}
		}
	}else{
		if(obj.checked){
			return obj.value;
		}else{
			return 0;
		}
	}	
	return 0;
}

function check_lan_setting(ip, mask, gateway, obj_word){				
	if (!check_mask(mask)){
		return false;   // when subnet mask is not in the subnet mask range
	}else if (!check_address(ip, mask)){
		return false;		// when ip is invalid
	}else if (!check_address(gateway, mask, ip)){
		return false;	// when gateway is invalid
	}else if (!check_domain(ip, mask, gateway)){		// check if the ip and the gateway are in the same subnet mask or not
		var gateway_ipaddr_1 = gateway.addr[0]+"."+gateway.addr[1]+"."+gateway.addr[2]+"."+gateway.addr[3];
		alert(addstr(TEXT043, obj_word, gateway_ipaddr_1));
		return false;
	}
	return true;
}

function check_ssid(tmp_ssid){
	var i;
	var error =false;

	if(tmp_ssid == "") {
		alert(_badssid);
		return true;
	}
	for(i = 0; i<tmp_ssid.length; i++){
		var c = tmp_ssid.charCodeAt(i);
		if( c >= 32 && c <= 126){
			continue;
		}else{
			alert(_illegal_ssid);
			return true;
		}

	}
	return error;
}
function check_DeviceName(tmp_hostName)
{
	var i;
	var error =false;
	var tmp_count=0;

	if (tmp_hostName.length <= 63){
		var tmp_stringlength = tmp_hostName.length - 1
		for(i = 0; i<tmp_hostName.length; i++) {
			var c = tmp_hostName.substring(i,i+1);
			if (("0" <= c && c <= "9")){
				tmp_count=tmp_count+1;
			}
			if((("0" <= c && c <= "9") || ("a" <= c && c <= "z") ||
					("A" <= c && c <= "Z") || (i!=0 && c=="-") &&
					(i!=tmp_stringlength && c=="-")) && 
					(tmp_count != tmp_hostName.length)) {
				continue;
			} else {
				alert(GW_LAN_DEVICE_NAME_INVALID);
				error= true;
				return error;
			}
		}
	} else {
		alert(GW_LAN_DEVICE_NAME_INVALID);
		error= true;
		return error;
	}
	return error;
}

function isHex(str) {
	var i;
	for(i = 0; i<str.length; i++) {
		var c = str.substring(i, i+1);
		if(("0" <= c && c <= "9") || ("a" <= c && c <= "f") || ("A" <= c && c <= "F")) {
			continue;
		}
		return false;
	}
	return true;
}
function a_to_hex(inValue) {
	var outValue = "";
	if (inValue) {
		for (i = 0; i < inValue.length; i++) {
			if(inValue.charCodeAt(i).toString(16) < 10)
				outValue += 0;
			if(inValue.charCodeAt(i).toString(16) > 'a' && inValue.charCodeAt(i).toString(16) <= 'f')
				if(inValue.charCodeAt(i).toString(16).length == 1)
					outValue += 0;
			outValue += inValue.charCodeAt(i).toString(16);
		}
	}
	return outValue;
}
function hex_to_a(inValue){
	outValue = "";
	var k = '';
	for (i = 0; i < inValue.length; i++) {
		l = i % 2;
		if (l == 0)
			k += "%";
		k += inValue.substr(i, 1);
	}
	outValue = unescape(k);
	return outValue;
}
function create_favorite_link(url){
	var is_support = check_support_bookmark();
		
	if (is_support > 0){	
		if (confirm(_setup_wizard_info)){
			if(is_support == 1){	//Firefox
				window.sidebar.addPanel(_setup_wizard_info2,url,"");			
			}else if (is_support == 2) {	//IE favorite
			if (check_ie_version()){	// when IE version is 8 or above				
					window.external.AddToFavoritesBar(url, _setup_wizard_info2);
			}else{				
					window.external.AddFavorite(url, _setup_wizard_info2);
				}
			}
		}
	}	
}
function check_support_bookmark(){
	var isMSIE = (-[1,]) ? false : true;
	var is_support = 0;
	
	if(window.sidebar && window.sidebar.addPanel){	//Firefox
		is_support = 1;
	}else if (isMSIE && window.external) {	//IE favorite
		is_support = 2;
	}
	
	return is_support;
}
function check_ie_version(){
	var version = 6;
	
	if (navigator.appName == 'Microsoft Internet Explorer') {
		var agent = navigator.userAgent;
		var index = agent.indexOf("MSIE");
		
		if (index != -1){
			version = parseFloat(agent.substring(index + 5, index+8));
		}		
	}
	
	    if (version >= 8) {
		return true;	
	    }
	
	return false;
}


function send_submit(which_form){
	get_by_id(which_form).submit();
}
function ReplaceAll(strOrg,strFind,strReplace){
	var index = 0;
	while(strOrg.indexOf(strFind,index) != -1){
		strOrg = strOrg.replace(strFind,strReplace);
		index = strOrg.indexOf(strFind,index);
	}
	return strOrg
}

var enc64List, dec64List;

function base64Encode(str) {
	var c, d, e, end = 0;
	var u, v, w, x;
	var ptr = -1;
	var input = str.split("");
	var output = "";
	while(end == 0) {
		c = (typeof input[++ptr] != "undefined") ? input[ptr].charCodeAt(0) :
			((end = 1) ? 0 : 0);
		d = (typeof input[++ptr] != "undefined") ? input[ptr].charCodeAt(0) :
			((end += 1) ? 0 : 0);
		e = (typeof input[++ptr] != "undefined") ? input[ptr].charCodeAt(0) :
			((end += 1) ? 0 : 0);
		u = enc64List[c >> 2];
		v = enc64List[(0x00000003 & c) << 4 | d >> 4];
		w = enc64List[(0x0000000F & d) << 2 | e >> 6];
		x = enc64List[e & 0x0000003F];

		// handle padding to even out unevenly divisible string lengths
		if (end >= 1) {x = "=";}
		if (end == 2) {w = "=";}

		if (end < 3) {output += u + v + w + x;}
	}
	// format for 76-character line lengths per RFC
	var formattedOutput = "";
	var lineLength = 76;
	while (output.length > lineLength) {
		formattedOutput += output.substring(0, lineLength) + "\n";
		output = output.substring(lineLength);
	}
	formattedOutput += output;
	return formattedOutput;
}

function initBase64() {
	enc64List = new Array();
	dec64List = new Array();
	var i;
	for (i = 0; i < 26; i++) {
		enc64List[enc64List.length] = String.fromCharCode(65 + i);
	}
	for (i = 0; i < 26; i++) {
		enc64List[enc64List.length] = String.fromCharCode(97 + i);
	}
	for (i = 0; i < 10; i++) {
		enc64List[enc64List.length] = String.fromCharCode(48 + i);
	}
	enc64List[enc64List.length] = "+";
	enc64List[enc64List.length] = "/";
	for (i = 0; i < 128; i++) {
		dec64List[dec64List.length] = -1;
	}
	for (i = 0; i < 64; i++) {
		dec64List[enc64List[i].charCodeAt(0)] = i;
	}
}

//Self-initialize the global variables
initBase64();
function jump_if(){
	for (var i = 0; i < document.forms.length; i++) {
		if (is_form_modified(document.forms[i].id)) {
			if (!confirm (up_jt_1+ "\n" +up_jt_2 +"\n"+ up_jt_3)) {
				return false;
			}
		}
	}
	return true;
}
/*ck add start*/
	var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

	function encode_base64(psstr)
	{
		return psstr;
	}

	function encode64(input)
	{
		var output = "";
		var chr1, chr2, chr3;
		var enc1, enc2, enc3, enc4;
		var i = 0;

		do {
			chr1 = input.charCodeAt(i++);
			chr2 = input.charCodeAt(i++);
			chr3 = input.charCodeAt(i++);

			enc1 = chr1 >> 2;
			enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
			enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
			enc4 = chr3 & 63;

			if (isNaN(chr2)) {
				enc3 = enc4 = 64;
			} else if (isNaN(chr3)) {
				enc4 = 64;
			}

			output = output + keyStr.charAt(enc1) + keyStr.charAt(enc2) + 
				 keyStr.charAt(enc3) + keyStr.charAt(enc4);
		} while (i < input.length);
   
		return output;
	}
function get_radio_value(which_radio){
	var obj = get_by_name(which_radio);
	
	for (var i = 0; i < obj.length; i++){
		if (obj[i].checked){
			return obj[i].value;
		}
	}
	
	return "";
}
function change_radio(which_radio,index){
	var select_index=parseInt(index);
	var obj = get_by_name(which_radio);
	var tmp_value = get_radio_value(which_radio);
	obj[tmp_value].checked=false;
	obj[select_index].checked=true;
	for (var i = 0; i < obj.length; i++){
		var name= which_radio + "_"+ i;
		if (obj[i].checked){
			//get_by_id(which_radio + "_"+ i).innerHTML="<img src=\"image/select_.gif\" style=\"vertical-align:middle;\"/>";
			$("#"+name).attr("class","cus_radio_on");
		}else{
			//get_by_id(which_radio + "_" + i).innerHTML="<img src=\"image/select.gif\" style=\"vertical-align:middle;\"/>";
			$("#"+name).attr("class","cus_radio_off");
		}
	}
}

function replace_special_char(src_str){
	var dest_src = "";
	
	for (var i = 0; i < src_str.length; i++){
		var ch = src_str.charAt(i);
		
		if (ch == '>'){
			dest_src += "&gt;";
		}else if (ch == '<'){
			dest_src += "&lt;";
		}else if (ch == ' '){
			dest_src += "&nbsp;";
		}else if (ch == '&'){
			dest_src += "&amp;";
		}else{
			dest_src += ch;
		}
	}
	
	return dest_src;
}
function check_ascii(data){
	
	for (var i = 0; i < data.length; i++){	
		var temp_char = data.charCodeAt(i);
		
		if (temp_char < 32 || temp_char > 126){	// if the character is less than a space(0x20) or greater than ~(0x7F)
			return false;
		}
	}
	
	return true;
}
/*ck add end*/
function is_form_modified(form_id)
{
	var df = document.forms[form_id];
	if (!df) {
		return false;
	}
	if (df.getAttribute('modified') == "true") {
		return true;
	}
	if (df.getAttribute('saved') != "true") {
		return false;
	}
	for (var i = 0, k = df.elements.length; i < k; i++) {
		var obj = df.elements[i];
		if (obj.getAttribute('modified') == 'ignore') {
			continue;
		}
		var name = obj.tagName.toLowerCase();
		if (name == 'input') {
			var type = obj.type.toLowerCase();
			if (((type == 'text') || (type == 'textarea') || (type == 'password') || (type == 'hidden')) &&
					!are_values_equal(obj.getAttribute('default'), obj.value)) {
				return true;
			} else if (((type == 'checkbox') || (type == 'radio')) && !are_values_equal(obj.getAttribute('default'), obj.checked)) {
				return true;
			}
		} else if (name == 'select') {
			var opt = obj.options;
			for (var j = 0; j < opt.length; j++) {
				if (!are_values_equal(opt[j].getAttribute('default'), opt[j].selected)) {
					return true;
				}
			}
		}
	}
	return false;
}
function are_values_equal(val1, val2)
{
	/* Make sure we can handle these values. */
	switch (typeof(val1)) {
	case 'boolean':
	case 'string':
	case 'number':
		break;
	default:
		// alert("are_values_equal does not handle the type '" + typeof(val1) + "' of val1 '" + val1 + "'.");
		return false;
	}

	switch (typeof(val2)) {
	case 'boolean':
		switch (typeof(val1)) {
		case 'boolean':
			return (val1 == val2);
		case 'string':
			if (val2) {
				return (val1 == "1" || val1.toLowerCase() == "true" || val1.toLowerCase() == "on");
			} else {
				return (val1 == "0" || val1.toLowerCase() == "false" || val1.toLowerCase() == "off");
			}
			break;
		case 'number':
			return (val1 == val2 * 1);
		}
		break;
	case 'string':
		switch (typeof(val1)) {
		case 'boolean':
			if (val1) {
				return (val2 == "1" || val2.toLowerCase() == "true" || val2.toLowerCase() == "on");
			} else {
				return (val2 == "0" || val2.toLowerCase() == "false" || val2.toLowerCase() == "off");
			}
			break;
		case 'string':
			if (val2 == "1" || val2.toLowerCase() == "true" || val2.toLowerCase() == "on") {
				return (val1 == "1" || val1.toLowerCase() == "true" || val1.toLowerCase() == "on");
			}
			if (val2 == "0" || val2.toLowerCase() == "false" || val2.toLowerCase() == "off") {
				return (val1 == "0" || val1.toLowerCase() == "false" || val1.toLowerCase() == "off");
			}
			return (val2 == val1);
		case 'number':
			if (val2 == "1" || val2.toLowerCase() == "true" || val2.toLowerCase() == "on") {
				return (val1 == 1);
			}
			if (val2 == "0" || val2.toLowerCase() == "false" || val2.toLowerCase() == "off") {
				return (val1 === 0);
			}
			return (val2 == val1 + "");
		}
		break;
	case 'number':
		switch (typeof(val1)) {
		case 'boolean':
			return (val1 * 1 == val2);
		case 'string':
			if (val1 == "1" || val1.toLowerCase() == "true" || val1.toLowerCase() == "on") {
				return (val2 == 1);
			}
			if (val1 == "0" || val1.toLowerCase() == "false" || val1.toLowerCase() == "off") {
				return (val2 === 0);
			}
			return (val1 == val2 + "");
		case 'number':
			return (val2 == val1);
		}
		break;
	default:
		return false;
	}
	return false;
}
function is_ascii(value)
{
	value += "";
	return value.match(/^[\x20-\x7E]*$/) ? true : false;
}function key_word(newobj,obj){
	get_by_id(obj).value = newobj.value;
}
function checksessionStorage()
{
	/* Because old browsers (it's likes IE5.5, IE6, ...etcs.) not support HTML5 function, we just do it with old arch. */
	if (typeof(sessionStorage) === "undefined") {
		return "<!--# echo get_current_user -->";
	} else {
		return sessionStorage.getItem("account");
	}
}
function ssid_decode(key)
{
	var ssid = get_by_id(key).value;
	var ssid_tmp = "";
	for (var i = 0; i < ssid.length; i++) {
		if (encodeURI(ssid.charAt(i)) === "%C2%A0") {
			ssid_tmp += decodeURI("%20");
		} else {
			ssid_tmp += ssid.charAt(i);
		}
	}
	return ssid_tmp
}

function html_tran_echot(key){	
	var key_tmp = "";
	for (var i = 0; i < key.length; i++) {
		if (key.charAt(i) == ' ') {
			key_tmp += "&#160;";
		}else if (key.charAt(i) == '"'){
			key_tmp += "&#34;";
		}else if (key.charAt(i) == '&'){	
			key_tmp += "&#38;";
		}else if (key.charAt(i) == '\''){
			key_tmp += "&#39;";
		}else if (key.charAt(i) == '\\'){
			key_tmp += "&#92;";
		}else {
			key_tmp += key.charAt(i);
		}
	}
	return key_tmp;	
}

/*
 * set_form_default_values
 *	Save a form's current values to a custom attribute.
 */
function set_form_default_values(form_id)
{
	var df = document.forms[form_id];
	if (!df) {
		return;
	}
	for (var i = 0, k = df.elements.length; i < k; i++) {
		var obj = df.elements[i];
		if (obj.getAttribute('modified') == 'ignore') {
			continue;
		}
		var name = obj.tagName.toLowerCase();
		if (name == 'input') {
			var type = obj.type.toLowerCase();
			if ((type == 'text') || (type == 'textarea') || (type == 'password') || (type == 'hidden')) {
				obj.setAttribute('default', obj.value);
				/* Workaround for FF error when calling focus() from an input text element. */
				if (type == 'text') {
					obj.setAttribute('autocomplete', 'off');
				}
			} else if ((type == 'checkbox') || (type == 'radio')) {
				obj.setAttribute('default', obj.checked);
			}
		} else if (name == 'select') {
			var opt = obj.options;
			for (var j = 0; j < opt.length; j++) {
				opt[j].setAttribute('default', opt[j].selected);
			}
		}
	}
	df.setAttribute('saved', "true");
}
function disable_all_btn(is_disable){
	var input_objs = document.getElementsByTagName("input");

	if (input_objs != null){
		for (var i = 0; i < input_objs.length; i++){
			if (input_objs[i].type == "button" || input_objs[i].type == "submit"){
				input_objs[i].disabled = is_disable;
			}
		}
	}
}
//ck add end

function set_checked(which_value, obj){
	if(obj.length > 1){
		obj[0].checked = true;
		for(var pp=0;pp<obj.length;pp++){
			if(obj[pp].value == which_value){
				obj[pp].checked = true;
			}
		}
	}else{
		obj.checked = false;
		if(obj.value == which_value){
			obj.checked = true;
		}
	}
}

/**
 *	get_digit_number() : get the two digit number
 *
 *	Parameter(s) :
 *		num		 :	number 
 *			 
 * Return : two digit number
 * 	
 **/
function get_digit_number(num){
	if(num<=9){
		return "0" + num;
	}
	
	return num;
}

var fw_date_array="<!--# echo sys_fw_date -->".split(" ");
var _copyright=_copyright_src.replace(/2012/,fw_date_array[2]);
function gen_copyright(){
	var str = "";
	str = "<div class=\"copyright\">";
	str += _copyright;
	str += "</div>";
	document.write(str);
}

function check_reboot(){
	var str="";	
	str +="<li style=\"display:block;color:#FFF\"><div>|</div></li>";
	str +="<li style=\"display:none\" id=\"reboot_now\" name=\"reboot_now\"><div class=\"top_btn\" onclick=\"jump_reboot_now();\" style=\"cursor:pointer\"><script>show_words(YM3);</script></div></li>";
	document.write(str);
	if("<!--# echo reboot_type -->"!="")
		get_by_id("reboot_now").style.display = "block";
}

function jump_reboot_now(){    
    type_aniloader=3/4;
    send_post('apply.cgi', 'form_reboot');
    if("<!--# echo extwifi_modified -->" == "1")
        reboot_bar("wf");
    else
        reboot_bar("gen");
}

function jump_reboot(){
	send_submit("form_reboot");
}

function reboot_needed(url){
	var str = "";
	str = "<form id=\"form_reboot\" name=\"form_reboot\" method=\"post\" action=\"apply.cgi\">";
	str += "<input type=\"hidden\" name=\"html_response_page\" value=\"" + url + "\">";
	str += "<input type=\"hidden\" name=\"html_response_return_page\" value=\"" + url + "\">";
	str += "<script>document.form_reboot.html_response_return_page.value = \"" + url + "\";<\/script>";
	str += "<input type=\"hidden\" id=\"html_response_message\" name=\"html_response_message\" value=\"reboot_go\">";	
	str += "<input type=\"hidden\" name=\"action\" value=\"reboot_needed\">";
	str += "</form>";
	document.write(str);
}

function custom_select(select_id, return_str , orig_select_id ,onclick_fn){
	$("#" + select_id +" p").click(function(){
		var ul = $("#" + select_id +" ul");
		if(ul.css("display")=="none"){
			ul.slideDown("fast");
		}else{
			ul.slideUp("fast");
		}
	});

	$("#" + select_id +" ul li a").click(function(){
		var txt = $(this).text();
		var value = $(this).attr("rel");
		var which_value = txt.split(");");
		var tmp_orig_select_id = get_by_id(orig_select_id);
		
		if (typeof which_value[1] == "undefined"){			 //ie8
			$("#" + select_id +" p").html( which_value[0] );
		}else{												//firebox, chrom
			$("#" + select_id +" p").html( which_value[1] );
		}
		
		$("#" + select_id +" ul").hide();
		
		if( tmp_orig_select_id != null){
			set_selectIndex(value, tmp_orig_select_id);
		}
		
		if(typeof onclick_fn == "function"){
			onclick_fn();
		}	
	});
}	
	
function set_custom_selectIndex(which_value, obj, custom_id, custom_select_str){
	for (var pp=0; pp<obj.options.length; pp++){
		if (which_value == obj.options[pp].value){
			obj.selectedIndex = pp;
			$("#"+ custom_id +" p").html( custom_select_str[pp] );
			break;
		}
	}
}	

function iOS_check(){
	if (/ip(hone|od|ad)|Mac/i.test(navigator.userAgent || navigator.vendor || window.opera)){
		return 1;
	} else {
		return 0;
	}
}

function gen_forward_link(rsp_page){

	var ret = rsp_page;	
	var regex = /^\d+\.\d+\.\d+\.\d+$/;
	var sys_lan_mac="<!--# echo sys_lan_mac -->".split(":");


	if("<!--# echo reboot_type -->"!=""){
		return rsp_page;
	} else if(regex.test(window.location.host)) {
		ret = "http://<!--# echo ap_device_name -->" + sys_lan_mac[4] + sys_lan_mac[5];
		if(iOS_check()==1)
			ret += ".local.";
		ret +="/"+rsp_page;		
	}

	return ret;
}

function preload_image(img_array) {
	var length = img_array.length;
	for(var i=0; i<length; i++)
		new Image().src = img_array[i];
 }	

function send_post(post_url, post_form){
	var post_data = $('#'+post_form).serialize();

	var ajax_obj = $.ajax({
		type: 'POST',
		url: post_url,
		cache: false,
		data: post_data
	});
	return ajax_obj;
}

function reboot_check(){		
	uLightBox.init({
        override:true,
        background: 'black',
        centerOnResize: true,
        fade: true
    });
    uLightBox.alert({
        width: '700px',
        title: YM1,
        leftButtons: [YM4, YM3],
        opened: function(){
            $('<span />').html(YM2).appendTo('#lbContent');
        },
        onClick: function(button) {                
            if (button == YM4) {
                this.clear();
                //location.href = get_by_id("html_response_return_page").value;
            } else if (button == YM3) { 
	          	send_post('apply.cgi', 'form_reboot');
	        	type_aniloader=3/4;
	        	this.clear();
	        	
				if("<!--# echo extwifi_modified -->" == "1" || $("#extwifi_modified").val()=="1")					
					reboot_bar("wf");
				else
					reboot_bar("gen");
            }
        }
	});
}

function text_autocap_off(){
	if(iOS_check()==1){
		$('input[type=text],input[type=password]').each(function(){
			var tmp_obj = $(this);
			tmp_obj.attr('autocapitalize', 'off');	
		});
	}
}
var internal_lang = fn_get_lang();

function create_multi_language(init_lang){
	var lang_switch_obj = {
		"default": 'English', ES:'Español', DE:'Deutsch', FR:'Français', IT:'Italiano', RU:'Русский',
		PT:'Português',	JP:'日本語', TW:'繁體中文', CN:'简体中文', KR:'한국어', CS:'Česky', DA:'Dansk', 
		EL:'Ελληνικά',	FI:'Suomi', HR:'Hrvatski', HU:'Magyar', NL:'Nederlands', NO:'Norsk', PL:'Polski', 
		RO:'Română', SL:'Slovenščina', SE:'Svenska'
	};

	var custom_lang_switch_str = [];
	var which_dom_p = $("#custom_lang_switch p");
	var which_dom_ul = $("#custom_lang_switch ul");

	which_dom_p.html(lang_switch_obj[init_lang]);		
	for(var key in lang_switch_obj){
		which_dom_ul.append("<li><a>"+ lang_switch_obj[key] +"</a></li>");
		$("#custom_lang_switch a:last").attr("rel", key);			
		custom_lang_switch_str.push(key);
	}

	var change_language = function(){
		var val = which_dom_p.html();
		var xhr;		
		if(lang_switch_obj[init_lang] != val) {				
			$.each(custom_lang_switch_str, function(){
				if(lang_switch_obj[this] == val){
					//var data = {action:"lang", language:this, html_response_page:"post_result.xml"};
					//xhr = $.post('apply.cgi', data);		
					save_dom(this);	
				}
			});
			xhr.done(function(){
				window.location.href = window.location.pathname + "#" + val;
				window.location.reload(true);
			});
		}
	};

	custom_select("custom_lang_switch", custom_lang_switch_str, null, change_language);
}

function save_dom(Nlang){
	var temp_cURL = document.URL.split('#');
	$.jStorage.set("language",Nlang);
	
	window.location.href = temp_cURL[0] +'#'+Nlang;	
	window.location.reload(true);
}
String.prototype.repeat = function( num ){
	return new Array( num + 1 ).join( this );
}