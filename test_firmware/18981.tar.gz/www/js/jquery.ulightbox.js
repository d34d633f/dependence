/*!
 * jQuery uLightBox
 * http://www.userdot.net/#!/jquery
 *
 * Copyright 2011, UserDot www.userdot.net
 * Licensed under the GPL Version 3 license.
 * Version 1.0.0
 *
 */
var uLightBoxT = {
    skeleton: '<div id="uLightBoxTOverlay" style="display:none" class="opaque"><div id="uLightBoxT" class="shadow top bottom" style="display:none"><div id="lbHeader" class="top"></div><div id="lbContentT"></div><div id="lbFooterT" class="bottom"></div></div></div>',
    settings: {},
    init: function(opts) {
        uLightBoxT.settings = opts;
        $('body').append(uLightBoxT.skeleton);
        if (uLightBoxT.settings.override) {
            /*
            $('<script />').attr({
                type:'text/javascript'
            }).html("function alert(val){ uLightBoxT.alert({ title: 'Alert', text: val, rightButtons: ['OK'] }); }").appendTo('head');
            */
            if (uLightBoxT.settings.background != "none" && (uLightBoxT.settings.background == 'white' || uLightBoxT.settings.background == 'black')) {
                $('#uLightBoxTOverlay').addClass(uLightBoxT.settings.background);
            }
            else {
                $('#uLightBoxTOverlay').addClass('none');
            }
        }
        if (uLightBoxT.settings.centerOnResize) {
            $(window).bind('resize', function() {
                uLightBoxT.resize();
            });
        }
    },
    alert: function(options) {
        if (uLightBoxT.isOpen()) {
            return false;
        }
        $('#uLightBoxT').css({
            width: options.width
        });
        uLightBoxT.resize();
        $('#uLightBoxT #lbHeader').html('<header>'+options.title+'</header>');
        buttons = '';
        lb = options.leftButtons;
        rb = options.rightButtons;
        if (lb) {
            for (var i=(options.leftButtons).length-1; i>=0; i--) {
                buttons += '<input type="button" class="flat" value="'+options.leftButtons[i]+'">';
            }
        }
        if (rb) {
            for (var i=(options.rightButtons).length-1; i>=0; i--) {
                buttons += '<input type="button" class="flat floatRight" value="'+options.rightButtons[i]+'">';
            }
        }
        /*
        if (!lb && !rb) {
            buttons += '<input type="button" class="flat floatRight" value="OK">';
        }
        */
        $('#uLightBoxT #lbContentT').html(options.text);
        //uLightBoxT.listen();
        if (uLightBoxT.settings.fade) {
            $('#uLightBoxTOverlay').fadeIn();
        }
        else {
            $('#uLightBoxTOverlay').show();
        }
        if (!!window.jQuery.ui) {
            $('#uLightBoxT').draggable({
                handle: '#lbHeader', 
                containment: 'parent'
            }).show();
        }
        else {
            $('#uLightBoxT').show();
        }
        if (typeof options.opened == 'function') {
            options.opened.call(this);
        }
        if (typeof options.onClick == 'function') {
            uLightBoxT.onClick = options.onClick;
        }
    },
    isOpen: function() {
        var open = $('#uLightBoxT').css('display') == "block";
        return open;
    },
    clear: function() {
        $('#uLightBoxTOverlay').remove();
        if (uLightBoxT.settings.fade) {
            $('#uLightBoxTOverlay').fadeOut();
        }
        else {
            $('#uLightBoxTOverlay').hide();
        }   
        $('body').append(uLightBoxT.skeleton);
        uLightBoxT.resize();
    },
    action: function(key) {
        if (key == "Cancel" || key == "Close" || key == "Quit" || key == "Back" || key == "OK") {
            uLightBoxT.clear();
        }
        uLightBoxT.onClick(key);
    },
    resize: function() {
        var lbox = $('#uLightBoxT');
        var height = parseInt((lbox.css('height')).replace('px', ''));
        var width = parseInt((lbox.css('width')).replace('px', ''));
        lbox.css({
            top: ($(window).height()/2 ) - 100 + 'px',
            left: ($(window).width() - width)/2 + 'px'
        });
    },
    onClick: function() {
        
    },
    destroy: function() {
        $('#uLightBoxTOverlay').remove();
        $(window).unbind('resize');
    }
}
var uLightBox = {
    skeleton: '<div id="uLightBoxOverlay" style="display:none" class="opaque"><div id="uLightBox" class="shadow top bottom" style="display:none"><div id="lbHeader" class="top"></div><div id="lbContent"></div><div id="lbFooter" class="bottom"></div></div></div>',
    settings: {},
    init: function(opts) {
        uLightBox.settings = opts;
        $('body').append(uLightBox.skeleton);
        if (uLightBox.settings.override) {
            /*
            $('<script />').attr({
                type:'text/javascript'
            }).html("function alert(val){ uLightBox.alert({ title: 'Alert', text: val, rightButtons: ['OK'] }); }").appendTo('head');
            */
            if (uLightBox.settings.background != "none" && (uLightBox.settings.background == 'white' || uLightBox.settings.background == 'black')) {
                $('#uLightBoxOverlay').addClass(uLightBox.settings.background);
            }
            else {
                $('#uLightBoxOverlay').addClass('none');
            }
        }
        if (uLightBox.settings.centerOnResize) {
            $(window).bind('resize', function() {
                uLightBox.resize();
            });
        }
    },
    alert: function(options) {
        if (uLightBox.isOpen()) {
            return false;
        }
        $('#uLightBox').css({
            width: options.width
        });
        uLightBox.resize();
        $('#uLightBox #lbHeader').html('<header>'+options.title+'</header>');
        buttons = '';
        lb = options.leftButtons;
        rb = options.rightButtons;
        if (lb) {
            for (var i=(options.leftButtons).length-1; i>=0; i--) {
                buttons += '<input type="button" class="flat" value="'+options.leftButtons[i]+'">';
            }
        }
        if (rb) {
            for (var i=(options.rightButtons).length-1; i>=0; i--) {
                buttons += '<input type="button" class="flat floatRight" value="'+options.rightButtons[i]+'">';
            }
        }
        if (!lb && !rb) {
            buttons += '<input type="button" class="flat floatRight" value="OK">';
        }
        $('#uLightBox #lbFooter').html(buttons);
        $('#uLightBox #lbContent').html(options.text);
        uLightBox.listen();
        if (uLightBox.settings.fade) {
            $('#uLightBoxOverlay').fadeIn();
        }
        else {
            $('#uLightBoxOverlay').show();
        }
        if (!!window.jQuery.ui) {
            $('#uLightBox').draggable({
                handle: '#lbHeader', 
                containment: 'parent'
            }).show();
        }
        else {
            $('#uLightBox').show();
        }
        if (typeof options.opened == 'function') {
            options.opened.call(this);
        }
        if (typeof options.onClick == 'function') {
            uLightBox.onClick = options.onClick;
        }
    },
    isOpen: function() {
        var open = $('#uLightBox').css('display') == "block";
        return open;
    },
    clear: function() {
        $('#uLightBoxOverlay').remove();
        if (uLightBox.settings.fade) {
            $('#uLightBoxOverlay').fadeOut();
        }
        else {
            $('#uLightBoxOverlay').hide();
        }   
        $('body').append(uLightBox.skeleton);
        uLightBox.resize();
    },
    listen: function() {
        $('#lbFooter input').each(function() {
            $(this).attr({
                'id': this.value
            });
        });
        $('#lbFooter input').click(function() {
            uLightBox.action($(this).val());
        });
    },
    action: function(key) {
        if (key == "Cancel" || key == "Close" || key == "Quit" || key == "Back" || key == "OK") {
            uLightBox.clear();
        }
        uLightBox.onClick(key);
    },
    resize: function() {
        var lbox = $('#uLightBox');
        var height = parseInt((lbox.css('height')).replace('px', ''));
        var width = parseInt((lbox.css('width')).replace('px', ''));
        lbox.css({
            top: ($(window).height()/2 ) - 100 + 'px',
            left: ($(window).width() - width)/2 + 'px'
        });
    },
    onClick: function() {
        
    },
    destroy: function() {
        $('#uLightBoxOverlay').remove();
        $(window).unbind('resize');
    }
}

var uLightBoxS = {
    skeleton: '<div id="uLightBoxSOverlay" style="display:none" class="opaque"><div id="uLightBoxS" class="shadow top bottom" style="display:none"><div id="lbHeaderS" class="top"></div><div id="lbContentS"></div><div id="lbFooterS" class="bottom"></div></div></div>',
    settings: {},
    init: function(opts) {
        uLightBoxS.settings = opts;
        $('body').append(uLightBoxS.skeleton);
        if (uLightBoxS.settings.override) {
            /*
            $('<script />').attr({
                type:'text/javascript'
            }).html("function alert(val){ uLightBoxS.alert({ title: 'Alert', text: val, rightButtons: ['OK'] }); }").appendTo('head');
            */
            if (uLightBoxS.settings.background != "none" && (uLightBoxS.settings.background == 'white' || uLightBoxS.settings.background == 'black')) {
                $('#uLightBoxSOverlay').addClass(uLightBoxS.settings.background);
            }
            else {
                $('#uLightBoxSOverlay').addClass('none');
            }
        }
        if (uLightBoxS.settings.centerOnResize) {
            $(window).bind('resize', function() {
                uLightBoxS.resize();
            });
        }
    },
    alert: function(options) {
        if (uLightBoxS.isOpen()) {
            return false;
        }
        $('#uLightBoxS').css({
            width: options.width
        });
        uLightBoxS.resize();
        $('#uLightBoxS #lbHeaderS').html('<header>'+options.title+'</header>');
        buttons = '';
        lb = options.leftButtons;
        rb = options.rightButtons;
        if (lb) {
            for (var i=(options.leftButtons).length-1; i>=0; i--) {
                if(options.leftButtons[i]==_select){
                    buttons += '<div id="Select_btn" onclick="copy_site_info()" style="cursor:pointer">'+options.leftButtons[i]+'</div>';    
                }else if(options.leftButtons[i]==_connect){
                    buttons += '<div id="Select_btn" onclick="check_pass_settings()" style="cursor:pointer" >'+options.leftButtons[i]+'</div>';
                }else if(options.leftButtons[i]==TEXT073){
                    buttons += '<div id="Select_btn" onclick="re_process_wps()" style="cursor:pointer" >'+options.leftButtons[i]+'</div>';
                }else{
                    buttons += '<input type="button" class="flat" value="'+options.leftButtons[i]+'">';
                }
                
            }
        }
        if (rb) {
            for (var i=(options.rightButtons).length-1; i>=0; i--) {
                if(options.leftButtons[i]==_select){
                    buttons += '<div id="Select_btn" onclick="copy_site_info()" style="cursor:pointer">'+options.leftButtons[i]+'</div>';    
                }else if(options.leftButtons[i]==_connect){
                    buttons += '<div id="Select_btn" onclick="check_pass_settings()" style="cursor:pointer" >'+options.leftButtons[i]+'</div>';
                }else if(options.leftButtons[i]==TEXT073){
                    buttons += '<div id="Select_btn" onclick="process_wps()" style="cursor:pointer" >'+options.leftButtons[i]+'</div>';
                }else{
                    buttons += '<input type="button" class="flat" value="'+options.leftButtons[i]+'">';
                }
            }
        }
        if (!lb && !rb) {
            buttons += '<input type="button" class="flat floatRight" value="OK">';
        }
        $('#uLightBoxS #lbFooterS').html(buttons);
        $('#uLightBoxS #lbContentS').html(options.text);
        uLightBoxS.listen();
        if (uLightBoxS.settings.fade) {
            $('#uLightBoxSOverlay').fadeIn();
        }
        else {
            $('#uLightBoxSOverlay').show();
        }
        if (!!window.jQuery.ui) {
            $('#uLightBoxS').draggable({
                handle: '#lbHeaderS', 
                containment: 'parent'
            }).show();
        }
        else {
            $('#uLightBoxS').show();
        }
        if (typeof options.opened == 'function') {
            options.opened.call(this);
        }
        if (typeof options.onClick == 'function') {
            uLightBoxS.onClick = options.onClick;
        }
    },
    isOpen: function() {
        var open = $('#uLightBoxS').css('display') == "block";
        return open;
    },
    clear: function() {
        $('#uLightBoxSOverlay').remove();
        if (uLightBoxS.settings.fade) {
            $('#uLightBoxSOverlay').fadeOut();
        }
        else {
            $('#uLightBoxSOverlay').hide();
        }   
        $('body').append(uLightBoxS.skeleton);
        uLightBoxS.resize();
    },
    listen: function() {
        $('#lbFooterS input').each(function() {
            $(this).attr({
                'id': this.value
            });
        });
        $('#lbFooterS input').click(function() {
            uLightBoxS.action($(this).val());
        });
    },
    action: function(key) {
        if (key == "Cancel" || key == "Close" || key == "Quit" || key == "Back" || key == "OK") {
            uLightBoxS.clear();
        }
        uLightBoxS.onClick(key);
    },
    resize: function() {
        var lbox = $('#uLightBoxS');
        var height = parseInt((lbox.css('height')).replace('px', ''));
        var width = parseInt((lbox.css('width')).replace('px', ''));
        lbox.css({
            top: ($(window).height()/5 )  + 'px',
            left: ($(window).width() - width)/2 + 'px'
        });
    },
    onClick: function() {
        
    },
    destroy: function() {
        $('#uLightBoxSOverlay').remove();
        $(window).unbind('resize');
    }
}
var uLightBoxTS = {
    skeleton: '<div id="uLightBoxTSOverlay" style="display:none" class="opaque"><div id="uLightBoxTS" class="shadow top bottom" style="display:none"><div id="lbHeader" class="top"></div><div id="lbContentTS"></div></div></div>',
    settings: {},
    init: function(opts) {
        uLightBoxTS.settings = opts;
        $('body').append(uLightBoxTS.skeleton);
        if (uLightBoxTS.settings.override) {
            /*
            $('<script />').attr({
                type:'text/javascript'
            }).html("function alert(val){ uLightBoxTS.alert({ title: 'Alert', text: val, rightButtons: ['OK'] }); }").appendTo('head');
            */
            if (uLightBoxTS.settings.background != "none" && (uLightBoxTS.settings.background == 'white' || uLightBoxTS.settings.background == 'black')) {
                $('#uLightBoxTSOverlay').addClass(uLightBoxTS.settings.background);
            }
            else {
                $('#uLightBoxTSOverlay').addClass('none');
            }
        }
        if (uLightBoxTS.settings.centerOnResize) {
            $(window).bind('resize', function() {
                uLightBoxTS.resize();
            });
        }
    },
    alert: function(options) {
        if (uLightBoxTS.isOpen()) {
            return false;
        }
        $('#uLightBoxTS').css({
            width: options.width
        });
        uLightBoxTS.resize();
        $('#uLightBoxTS #lbHeader').html('<header>'+options.title+'</header>');
        buttons = '';
        lb = options.leftButtons;
        rb = options.rightButtons;
        if (lb) {
            for (var i=(options.leftButtons).length-1; i>=0; i--) {
                buttons += '<input type="button" class="flat" value="'+options.leftButtons[i]+'">';
            }
        }
        if (rb) {
            for (var i=(options.rightButtons).length-1; i>=0; i--) {
                buttons += '<input type="button" class="flat floatRight" value="'+options.rightButtons[i]+'">';
            }
        }
        /*
        if (!lb && !rb) {
            buttons += '<input type="button" class="flat floatRight" value="OK">';
        }
        */
        $('#uLightBoxTS #lbContentTS').html(options.text);
        //uLightBoxTS.listen();
        if (uLightBoxTS.settings.fade) {
            $('#uLightBoxTSOverlay').fadeIn();
        }
        else {
            $('#uLightBoxTSOverlay').show();
        }
        if (!!window.jQuery.ui) {
            $('#uLightBoxTS').draggable({
                handle: '#lbHeader', 
                containment: 'parent'
            }).show();
        }
        else {
            $('#uLightBoxTS').show();
        }
        if (typeof options.opened == 'function') {
            options.opened.call(this);
        }
        if (typeof options.onClick == 'function') {
            uLightBoxTS.onClick = options.onClick;
        }
    },
    isOpen: function() {
        var open = $('#uLightBoxTS').css('display') == "block";
        return open;
    },
    clear: function() {
        $('#uLightBoxTSOverlay').remove();
        if (uLightBoxTS.settings.fade) {
            $('#uLightBoxTSOverlay').fadeOut();
        }
        else {
            $('#uLightBoxTSOverlay').hide();
        }   
        $('body').append(uLightBoxTS.skeleton);
        uLightBoxTS.resize();
    },
    action: function(key) {
        if (key == "Cancel" || key == "Close" || key == "Quit" || key == "Back" || key == "OK") {
            uLightBoxTS.clear();
        }
        uLightBoxTS.onClick(key);
    },
    resize: function() {
        var lbox = $('#uLightBoxTS');
        var height = parseInt((lbox.css('height')).replace('px', ''));
        var width = parseInt((lbox.css('width')).replace('px', ''));
        lbox.css({
            top: '150px',
            left: ($(window).width() - width)/2 + 'px'
        });
    },
    onClick: function() {
    },
    destroy: function() {
        $('#uLightBoxTSOverlay').remove();
        $(window).unbind('resize');
    }
}

