
function fn_get_lang(){
	var jvalue = $.jStorage.get("language");
	
	if(!jvalue){
		$.jStorage.set("language","default");
		jvalue = "default";
	}
	
	return jvalue;
}