function dhcponoff()
{
	var cf=document.forms[0];
	if(cf.lan_dhcpmode.checked ==true)
    	{
	        cf.sysPoolStartingAddr4.disabled =false;
	        cf.sysPoolFinishAddr4.disabled =false;
	}
	else
	{
	        cf.sysPoolStartingAddr4.disabled =true;
	        cf.sysPoolFinishAddr4.disabled =true;
	}
}

function valid_add()
{   
        if(resev_array_num==64)  
        {
			alert(reservation_length_64);
                return false;
        }

	location.href="reservation_add_wait.html";
}

function lanip_change(cf)
{
	var addr_array = new Array();
	cf.lan_ipaddr.value=cf.lan_ip1.value+'.'+cf.lan_ip2.value+'.'+cf.lan_ip3.value+'.'+cf.lan_ip4.value;
	addr_array = cf.lan_ipaddr.value.split('.');
	cf.sysPoolStartingAddr1.value = cf.sysPoolFinishAddr1.value=addr_array[0];
	cf.sysPoolStartingAddr2.value = cf.sysPoolFinishAddr2.value= addr_array[1];
	cf.sysPoolStartingAddr3.value = cf.sysPoolFinishAddr3.value=addr_array[2];	
}

function check_clientNumber(cf)
{
	cf.lan_subnet.value=cf.lan_mask1.value+'.'+cf.lan_mask2.value+'.'+cf.lan_mask3.value+'.'+cf.lan_mask4.value;
	var lan_mask=cf.lan_subnet.value;
	cf.lan_ipaddr.value=cf.lan_ip1.value+'.'+cf.lan_ip2.value+'.'+cf.lan_ip3.value+'.'+cf.lan_ip4.value;
	var lan_ip=cf.lan_ipaddr.value;
	var mask_array=lan_mask.split('.');
	var lan_array=lan_ip.split('.');
	var netmask = parseInt(mask_array[3], 10);
	var net_number = 256 / (256 - netmask);
	var client = 255-netmask;
	var localip = parseInt(lan_array[3]);
	var net_start = (netmask & localip) + 1;
	var net_end = (net_start + client) - 1;
	if (localip == (net_start-1)) {
		cf.lan_ipaddr.focus();
		return false;
	}
	if (localip >= (net_end)) {
		cf.lan_ipaddr.focus();
		return false;
	}
	if ((parseInt(cf.sysPoolStartingAddr4.value) < net_start) || (parseInt(cf.sysPoolStartingAddr4.value) >= net_end)) {
		cf.sysPoolStartingAddr4.focus();
		return false;
	}
	if ((parseInt(cf.sysPoolFinishAddr4.value) < net_start) || (parseInt(cf.sysPoolFinishAddr4.value) >= net_end)) {
		cf.sysPoolFinishAddr4.focus();
		return false;
	}
	return true;
}

function checklan(form)
{
	var cf=document.forms[0];
	form.change_network_flag.value=0;
	form.change_network2_flag.value=0;
	form.change_ip_flag.value=0;
	form.dmz_ip.value=dmz_ip;
	form.bs_trustedip.value=bs_trustedip;	
	form.dhcp_start.value=form.sysPoolStartingAddr1.value+'.'+form.sysPoolStartingAddr2.value+'.'+form.sysPoolStartingAddr3.value+'.'+form.sysPoolStartingAddr4.value;
	form.dhcp_end.value=form.sysPoolFinishAddr1.value+'.'+form.sysPoolFinishAddr2.value+'.'+form.sysPoolFinishAddr3.value+'.'+form.sysPoolFinishAddr4.value;
	form.lan_ipaddr.value=form.lan_ip1.value+'.'+form.lan_ip2.value+'.'+form.lan_ip3.value+'.'+form.lan_ip4.value;
	form.lan_subnet.value=form.lan_mask1.value+'.'+form.lan_mask2.value+'.'+form.lan_mask3.value+'.'+form.lan_mask4.value;
	var lan_array=form.lan_ipaddr.value.split('.');
	if( checkipaddr(form.lan_ipaddr.value)== false )
	{	
		alert(invalid_ip);
		return false;
	}
	if( checksubnet(form.lan_subnet.value) == false )
	{
		alert(invalid_mask);
		return false;
	}
	if (endis_wl_radio == "1" && wds_endis_fun == "1" && wds_repeater_basic == "0")
    {}
	else if(form.lan_dhcpmode.checked == true)
	{
		if( checkipaddr(form.dhcp_start.value)== false )
		{
			alert(invalid_dhcp_startip);
			return false;
		}
		if( checkipaddr(form.dhcp_end.value)== false )
		{
			alert(invalid_dhcp_endip);
			return false;	
		}
		if(parseInt(form.sysPoolStartingAddr4.value,10)>parseInt(form.sysPoolFinishAddr4.value,10))
		{
			alert(invalid_dhcp_startendip);
			return false;
		}
		if(lan_array[3]==form.sysPoolStartingAddr4.value || lan_array[3]==form.sysPoolFinishAddr4.value)
		{
			alert(invalid_dhcp_startendip);
			return false;
		}
		if(!check_clientNumber(form))
		{	
			alert(invalid_dhcp_startendip);
			return false;
		}
		if(isSameSubNet(form.lan_ipaddr.value,form.lan_subnet.value,form.dhcp_start.value,form.lan_subnet.value) == false)
		{
			alert(same_subnet_ip_dhcpstart);
			return false;
		}
		if(isSameSubNet(form.lan_ipaddr.value,form.lan_subnet.value,form.dhcp_end.value,form.lan_subnet.value) == false)
		{
		        alert(same_subnet_ip_dhcpend);
		        return false
		}
		if(parseInt(form.sysPoolStartingAddr4.value) <= parseInt(lan_array[3]) && parseInt(lan_array[3]) <= parseInt(form.sysPoolFinishAddr4.value))
        {
            alert(ip_dhcp_rang);
            return false;
        }
	}
	
	if( wan_ip!="0.0.0.0")
        {
                if( wan_type == "pppoe" || wan_type == "pptp" || wan_type == "mulpppoe1" )
                {
                        if(isSameSubNet(form.lan_ipaddr.value,form.lan_subnet.value,wan_ip,form.lan_subnet.value) == true)
                        {
                                alert(conflicted_with_wanip);
                                return false;
                        }
                }
                else
                {
                         if(isSameSubNet(form.lan_ipaddr.value,form.lan_subnet.value,wan_ip,wan_mask) == true)
                        {
                                alert(conflicted_with_wanip);
                                return false;
                        }
                        if(isSameSubNet(form.lan_ipaddr.value,form.lan_subnet.value,wan_ip,form.lan_subnet.value) == true)
                        {
                                alert(conflicted_with_wanip);
                                return false;
                        }
                        if(isSameSubNet(form.lan_ipaddr.value,wan_mask,wan_ip,wan_mask) == true)
                        {
                                 alert(conflicted_with_wanip);
                                 return false;
                        }

                }
                if(isSameIp(wan_ip,form.lan_ipaddr.value) == true)
                {
                        alert(conflicted_with_wanip);
                        return false;
                }
        }

	
	if(isSameIp(old_lanip,form.lan_ipaddr.value)== false)
	{
		//var askstr=changelanip+form.lan_ipaddr.value+" ?";
		//if(!confirm(askstr))
		      //return false;
		alert(changelanip_renew);	
		if(isSameSubNet(form.lan_ipaddr.value,form.lan_subnet.value,old_lanip,old_lanmask)==false)
		{		
		//lan subnet
			new_lanip_array=form.lan_ipaddr.value.split('.');
			new_lansubnet_array=form.lan_subnet.value.split('.');
			addr1=  new_lanip_array[0] & new_lansubnet_array[0];
			addr2=  new_lanip_array[1] & new_lansubnet_array[1];
			addr3=  new_lanip_array[2] & new_lansubnet_array[2];
			addr4=  new_lanip_array[3] & new_lansubnet_array[3];
			var route_dest = addr1+'.'+addr2+'.'+addr3+'.'+addr4;
			var new_reoute_dest_str=addr1+'.'+addr2+'.'+addr3+'.';
			form.network.value=addr1+'.'+addr2+'.'+addr3;
		//dmz
			if(dmz_ip!="")
				{
					var dmz_array=dmz_ip.split('.');
					form.dmz_ip.value=new_reoute_dest_str+dmz_array[3];
				}
				
		//block sites
			if(bs_trustedip!="")
				{
					var bs_trustedip_array=bs_trustedip.split('.');
					form.bs_trustedip.value=new_reoute_dest_str+bs_trustedip_array[3];
				}
			form.change_network_flag.value=1;
		}
		form.change_ip_flag.value=1;
		
		form.action="/cgi-bin/setobject.cgi?/cgi-bin/lan.html"
	}
	else 
	{ 
	       //when lan ip is not changed and subnet is changed 
	    if(isSameIp(old_lanmask,form.lan_subnet.value)==false) 
	    { 
	         var oldNetwork = old_lanmask.split("."); 
	         var nowNetwork = form.lan_subnet.value.split("."); 
	         oldNumofNetwork = getNumOfNetwork(oldNetwork); 
	         newNumofNetwork = getNumOfNetwork(nowNetwork); 
	         if ( oldNumofNetwork < newNumofNetwork ) //If subnet is changed and the subnet range is from big to small, router SHOULD flush all the corresponding configuration. 
	         { 
	              form.change_network2_flag.value=1; 
	         } 
	    } 

	form.action="/cgi-bin/setobject.cgi?/cgi-bin/lan.html"
	}
	return true;
}
function getNumOfNetwork(netArray) 
    { 
	   var getNum=0; 
       getNum=netArray[0]*255*255*255; 
       getNum+=netArray[1]*255*255; 
       getNum+=netArray[2]*255; 
       getNum+=netArray[3]; 
       return getNum; 
   } 

