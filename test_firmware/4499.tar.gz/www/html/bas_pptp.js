function myip_update()
{
    var cf = document.forms[0];

        if((cf.my_ip1.value.length>0)&&(cf.my_ip2.value.length>0)&&(cf.my_ip3.value.length>0)&&(cf.my_ip4.value.length>0))
        {
        setDisabled(false, cf.mygw_1, cf.mygw_2, cf.mygw_3, cf.mygw_4);
    }
    else
    {
        setDisabled(true, cf.mygw_1, cf.mygw_2, cf.mygw_3, cf.mygw_4);
    }
}
function setDNS(cf)
{
	var dflag = cf.DNSAssign[0].checked;
	setDisabled(dflag,cf.pptp_dnsp1,cf.pptp_dnsp2,cf.pptp_dnsp3,cf.pptp_dnsp4,cf.pptp_dnss1,cf.pptp_dnss2,cf.pptp_dnss3,cf.pptp_dnss4);
	DisableFixedDNS = dflag;
}
function idletime(cf)
{
    if(cf.dod.value == "0" || cf.dod.value=="2")
	{
        cf.hidden_pptp_idle_time.value=cf.pptp_idle_time.value;
	cf.pptp_idle_time.disabled=true;
	}
	else
        {
        cf.hidden_pptp_idle_time.value=cf.pptp_idle_time.value;
        cf.pptp_idle_time.disabled=false;
        }
}
function check_wizard_pptp(check)
{
	var cf=document.forms[0];
	if(cf.pptp_username.value=="")
	{
		alert(login_name_null);
		return false;
	}
	for(i=0;i<cf.pptp_username.value.length;i++)
        {
                if(isValidChar(cf.pptp_username.value.charCodeAt(i))==false)
                {
                        alert(loginname_not_allowed);
                        return false;
                }
        }
	for(i=0;i<cf.pptp_password.value.length;i++)
        {
                if(isValidChar(cf.pptp_password.value.charCodeAt(i))==false)
                {
                        alert(password_not_allowed);
                        return false;
                }
        }
	if(cf.pptp_idle_time.value.length<=0)
	{
		alert(idle_time_null);
		return false;
	}
	else if(!_isNumeric(cf.pptp_idle_time.value))
	{
		alert(invalid_idle_time);
		return false;
	}
	cf.pptp_myip.value=cf.my_ip1.value+'.'+cf.my_ip2.value+'.'+cf.my_ip3.value+'.'+cf.my_ip4.value;
	cf.pptp_gateway.value=cf.mygw_1.value+'.'+cf.mygw_2.value+'.'+cf.mygw_3.value+'.'+cf.mygw_4.value;
                if( cf.pptp_myip.value != "..." )
                {
                        if(checkipaddr(cf.pptp_myip.value)==false)
                        {
                                alert(invalid_myip);
                                return false;
                        }
                }
                if(cf.pptp_myip.value=="...")
                {
                    cf.pptp_myip.value="";
                    cf.pptp_gateway.value="";
                    cf.WANAssign.value=0;
                }
                else
                {
                    cf.WANAssign.value=1;
                    if ( cf.pptp_gateway.value != "..." && checkgateway(cf.pptp_gateway.value) == false )
                    {
                        alert(invalid_gateway);
                        return false;
                    }
                }
                if(cf.pptp_servip.value=="")
	        {
	                alert(invalid_servip);
	                return false;
	        }
	        for(i=0;i<cf.pptp_servip.value.length;i++)
	        {
	                if(isValidChar(cf.pptp_servip.value.charCodeAt(i))==false)
	                {
	                        alert(invalid_servip);
	                        return false;
	                }
	        }
	        var serv_array=cf.pptp_servip.value.split('.');
	        if( serv_array.length==4 )
	        {
	                var flag = 0;
	                for( iptab=0; iptab<4; iptab++ )
	                        if( isNumeric(serv_array[iptab], 255) ) flag++;
	                if( flag == 4 )
	                {
	                        if ( checkipaddr(cf.pptp_servip.value) == false )
	                        {
	                                alert(invalid_servip);
	                                return false;
	                        }
	                }
	                else                  //if the serverip is not a correct ip, it is a FQDN. then the My IP Address MUST be blank to indicate DHCP is used to get the router's IP address
	                {
	                        cf.WANAssign.value=0;
	                        cf.pptp_myip.value="";
	                        cf.pptp_gateway.value="";
	                }
	        }
	        else                  //if the serverip is not a correct ip, it is a FQDN. then the My IP Address MUST be blank to indicate DHCP is used to get the router's IP address
	        {
	                cf.WANAssign.value=0;
	                cf.pptp_myip.value="";
	                cf.pptp_gateway.value="";
	        }
	for(i=0;i<cf.pptp_connection_id.value.length;i++)
        {
                if(isValidChar(cf.pptp_connection_id.value.charCodeAt(i))==false)
                {
                        alert(invalid_pptp_connection_id);
                        return false;
                }
        }
	
	if (check == 1)
		cf.run_test.value="test"
	else
		cf.run_test.value="no"	
	return true;
}

function check_pptp(cf,check)
{   
    pptp_connection_id=cf.pptp_connection_id.value;
	pptp_servip=cf.pptp_servip.value;
	cf.pptp_gateway.value=cf.mygw_1.value+'.'+cf.mygw_2.value+'.'+cf.mygw_3.value+'.'+cf.mygw_4.value;
	if(pptp_connection_id.indexOf('"')>-1)
	{
	 cf.pptp_connection_id_hidden.value=pptp_connection_id.replace(/\"/g,'\\\"');
	}
	else
	cf.pptp_connection_id_hidden.value=pptp_connection_id;
	if(pptp_servip.indexOf('"')>-1)
	{
	 cf.pptp_servip_hidden.value=pptp_servip.replace(/\"/g,'\\\"');
	}
	else
	cf.pptp_servip_hidden.value=pptp_servip;
	if(check_wizard_pptp(check)==false)
		return false;
	if(cf.DNSAssign[1].checked == true)
	{
	        cf.pptp_dnsaddr1.value=cf.pptp_dnsp1.value+'.'+cf.pptp_dnsp2.value+'.'+cf.pptp_dnsp3.value+'.'+cf.pptp_dnsp4.value;
	        cf.pptp_dnsaddr2.value=cf.pptp_dnss1.value+'.'+cf.pptp_dnss2.value+'.'+cf.pptp_dnss3.value+'.'+cf.pptp_dnss4.value;
        	if(cf.pptp_dnsaddr2.value=="...")
                	cf.pptp_dnsaddr2.value="";
		if(checkipaddr(cf.pptp_dnsaddr1.value)==false)
		{
			alert(invalid_primary_dns);
			return false;
		}
		if(cf.pptp_dnsaddr2.value!="" && cf.pptp_dnsaddr2.value!="0.0.0.0")
		{
			if(checkipaddr(cf.pptp_dnsaddr2.value)==false)
			{
				alert(invalid_second_dns);
				return false;
			}
		}
	}
	if (cf.MACAssign[2].checked )
	{
		if(maccheck(cf.this_mac.value) == false)
			return false;
	}
	if(!( old_wan_type=="pptp"))
        	cf.change_wan_type.value=0;
	else
        	cf.change_wan_type.value=1;
        if(cf.dod.value == "1")	 
        cf.hidden_pptp_idle_time.value=cf.pptp_idle_time.value;
	return true;
}

function setIP_welcome_pptp()
{
	var cf = document.forms[0];
	var dflag = cf.WANAssign[0].checked;
	setDisabled(dflag,cf.my_ip1,cf.my_ip2,cf.my_ip3,cf.my_ip4);
	DisableFixedIP = dflag;
}


function check_welcome_pptp()
{
	var cf = document.forms[0];
	if(check_wizard_pptp(0)==false)
		return false;
	parent.pptp_username=cf.pptp_username.value;
	parent.pptp_password=cf.pptp_password.value;
	parent.pptp_idle_time=cf.pptp_idle_time.value;
	if(cf.WANAssign[1].checked)
        {
                cf.pptp_myip.value=cf.my_ip1.value+'.'+cf.my_ip2.value+'.'+cf.my_ip3.value+'.'+cf.my_ip4.value;
                if(cf.pptp_myip.value=="...")
                        cf.pptp_myip.value="";
                if(checkipaddr_pptp(cf.pptp_myip.value)==false)
                {
                        alert(invalid_myip);
                        return false;
                }
        }
	else
		cf.pptp_myip.value="";
	parent.pptp_local_ipaddr=cf.pptp_myip.value;
	parent.pptp_server_ipaddr=cf.pptp_servip.value;
	parent.pptp_connect_id=cf.pptp_connection_id.value;
	parent.welcome_wan_type=4;
	return true;
}
