function setDNS(cf)
{
	var dflag = cf.DNSAssign[0].checked;
	setDisabled(dflag,cf.bpa_dnsp1,cf.bpa_dnsp2,cf.bpa_dnsp3,cf.bpa_dnsp4,cf.bpa_dnss1,cf.bpa_dnss2,cf.bpa_dnss3,cf.bpa_dnss4);
	DisableFixedDNS = dflag;
}
function idletime(cf)
{
    if(cf.dod.value == "0" || cf.dod.value=="2")
	{
        cf.hidden_bpa_idle_time.value=cf.bpa_idle_time.value;
	cf.bpa_idle_time.disabled=true;
	}
        else
        {
        cf.hidden_bpa_idle_time.value=cf.bpa_idle_time.value;
    cf.bpa_idle_time.disabled=false;
        }
        
}
function check_wizard_bpa(check)
{
	var cf=document.forms[0];
	if(cf.bpa_username.value == "")
	{
		alert(login_name_null);
		return false;
	}
	for(i=0;i<cf.bpa_username.value.length;i++)
        {
                if(isValidChar(cf.bpa_username.value.charCodeAt(i))==false)
                {
                        alert(loginname_not_allowed);
                        return false;
                }
        }
	for(i=0;i<cf.bpa_password.value.length;i++)
        {
                if(isValidChar(cf.bpa_password.value.charCodeAt(i))==false)
                {
                        alert(password_not_allowed);
                        return false;
                }
        }
	if(cf.bpa_idle_time.value.length<=0)
	{
		alert(idle_time_null);
		return false;
	}
	else if(!_isNumeric(cf.bpa_idle_time.value))
	{
		alert(invalid_idle_time);
		return false;
	}	
	for(i=0;i<cf.bpa_servicename.value.length;i++)
        {
                if(isValidChar(cf.bpa_servicename.value.charCodeAt(i))==false)
                {
                        alert(bpa_invalid_serv_name);
                        return false;
                }
        }
	var serv_array=cf.bpa_servicename.value.split('.'); 
    if(serv_array.length==4) 
    { 
         if(checkipaddr(cf.bpa_servicename.value)==false) 
         { 
                  alert(bpa_invalid_serv_name); 
                  return false; 
         } 
    } 

	if (check == 1)
		cf.run_test.value="test"
	else
		cf.run_test.value="no"
	return true;
}

function check_bpa(cf,check)
{
	if(check_wizard_bpa(check)==false)
		return false;
	if (cf.MACAssign[2].checked == true)
	{   
	      the_mac=cf.this_mac.value; 
          if(the_mac.indexOf(":")==-1 && the_mac.length=="12") 
          { 
           var tmp_mac=the_mac.substr(0,2)+":"+the_mac.substr(2,2)+":"+the_mac.substr(4,2)+":"+the_mac.substr(6,2)+":"+the_mac.substr(8,2)+":"+the_mac.substr(10,2); 
           cf.this_mac.value = tmp_mac; 
           } 
          else if ( the_mac.split("-").length == 6 ) 
          { 
           var tmp_mac = the_mac.replace(/-/g,":"); 
           cf.this_mac.value=tmp_mac; 
          } 
		if(maccheck(cf.this_mac.value) == false)
			return false;
	}
	if(cf.DNSAssign[1].checked == true)
	{
	        cf.bpa_dnsaddr1.value=cf.bpa_dnsp1.value+'.'+cf.bpa_dnsp2.value+'.'+cf.bpa_dnsp3.value+'.'+cf.bpa_dnsp4.value;
                cf.bpa_dnsaddr2.value=cf.bpa_dnss1.value+'.'+cf.bpa_dnss2.value+'.'+cf.bpa_dnss3.value+'.'+cf.bpa_dnss4.value;
                if(cf.bpa_dnsaddr2.value=="...")
                        cf.bpa_dnsaddr2.value="";
		if(checkipaddr(cf.bpa_dnsaddr1.value)==false)
		{
			alert(invalid_primary_dns);
			return false;
		}
		if(cf.bpa_dnsaddr2.value!="" && cf.bpa_dnsaddr2.value!="0.0.0.0")
		{
			if(checkipaddr(cf.bpa_dnsaddr2.value)==false)
			{
				alert(invalid_second_dns);
				return false;
			}
		}
	}
	if(!( wanproto = "bigpond"))
        	cf.change_wan_type.value=0;
	else
        	cf.change_wan_type.value=1;
        if(cf.dod.value == "1") 	 
         cf.hidden_bpa_idle_time.value=cf.bpa_idle_time.value;

	return true;
}


function check_welcome_bpa()
{
	var cf = document.forms[0];
	if(check_wizard_bpa(0)==false)
		return false;

	// Other settings
	parent.telstra_bigpond_user_name = cf.bpa_username.value;
	parent.telstra_bigpond_password = cf.bpa_password.value;
	parent.telstra_idletime = cf.bpa_idle_time.value;
	parent.telstra_bigpond_ip = cf.bpa_servicename.value;
	parent.welcome_wan_type=5;
	return true;
}
