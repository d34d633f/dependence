config_bpa()
{
	$nvram set wan_proto="bigpond"
	$nvram set internet_type="0"
	$nvram set internet_ppp_type="2"
	$nvram set wan_bpa_username=$1
	$nvram set wan_bpa_password=$2
	$nvram set wan_bpa_idle_time=$(($3*60))
	$nvram set wan_bpa_servicename=$4
	$nvram set wan_bpa_dns_assign=$5
	$nvram set wan_ether_dns1=$6
	$nvram set wan_ether_dns2=$7	
	$nvram set wan_bpa_mac_assign=$8
	if [ "$8" = "2" ];then
		$nvram set wan_bpa_this_mac=$9
	fi
	$nvram set change_wan_type=${10}
	$nvram set run_test="${11}"
	$nvram set wan_endis_dod="${12}"
}
