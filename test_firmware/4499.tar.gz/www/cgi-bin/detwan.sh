#!/bin/sh

status_file="/tmp/configs/welcome_wan_type"
status_initializing=0001
status_0_percent=1000
status_25_percent=1025
status_50_percent=1050
status_75_percent=1075
status_90_percent=1090
status_100_percent=1100
status_finish=9999
status_error=10000
status_dynamic=10001
status_pppoe=10002
status_static=10003
status_static_ornot=10004
status_already=10005
status_bigpond=10006
status_pptp=10007
status_plug_off=10008

dhcp_found=0

write_status() # $1: status_number, $2: status_file
{
	echo "$1" > $2
}
detect_dhcp()
{
	local r_val=1

	if [ "x$dhcp_found" = "x1" ]; then
		return 0
	fi

	/sbin/ifconfig vlan0002 up
	if /sbin/udhcpc -n -i vlan0002; then
		r_val=0
	fi
	/sbin/ifconfig vlan0002 down
	/sbin/ifconfig vlan0002 0.0.0.0
	return $r_val
}
detect_pptp() # $1: status_number, $2: status_file
{
	local r_val=1
	/sbin/ifconfig vlan0002 up
	/sbin/ifconfig vlan0002 10.0.0.1 netmask 255.255.255.0
	if /sbin/detport 10.0.0.138 1723; then
		r_val=0
	fi	
	/sbin/ifconfig vlan0002 down
	/sbin/ifconfig vlan0002 0.0.0.0
	return $r_val

}

detect_bigpond()
{
	local r_val=1

	/sbin/ifconfig vlan0002 up
	if /sbin/udhcpc -n -i vlan0002; then 
		dhcp_found=1

		local tmp=$(awk '/^search.*bigpond\.net\.au$/ {print }' /tmp/resolv.conf)
		if [ -n "$tmp" ]; then
			r_val=0
		fi
	fi

	/sbin/ifconfig vlan0002 down
	/sbin/ifconfig vlan0002 0.0.0.0
	return $r_val
}

detect_pppoe()
{
	local r_val=1
	/sbin/ifconfig vlan0002 up
	/usr/sbin/pd
	if [ "$?" = "0" ]; then
		r_val=0
	fi
	/sbin/ifconfig vlan0002 down
	return $r_val
}

mac_spoofing()
{
	/sbin/ifconfig vlan0002 down
	/sbin/ifconfig vlan0002 hw ether $(/usr/sbin/nvram get wan_remote_mac)
	return 0;
}

write_final_status() # $1: wan_mode_det, $2: wan_mode_ori, $3: status_file
{
	local wan_mode_det="$1"
	local wan_mode_det_tmpfile="/tmp/wanmode"
	local status_number
	
	if [ "$1" = "unknow" -a "$2" = "static" ]; then
		wan_mode_det="static"
	fi
	
	case "$wan_mode_det" in
		dhcp)
			echo "wanmode 0 (dynamic)" > $wan_mode_det_tmpfile
			status_number="$status_dynamic"
			;;
		pppoe)
			echo "wanmode 2 (pppoe)" > $wan_mode_det_tmpfile
			status_number="$status_pppoe"
			;;
		static)
			echo "wanmode 1 (static)" > $wan_mode_det_tmpfile
			status_number="$status_static"
			;;
		bigpond)
			echo "wanmode 4 (bigpond)" > $wan_mode_det_tmpfile
                        status_number="$status_bigpond"
			;;
		 pptp)
                        echo "wanmode 5 (pptp)" > $wan_mode_det_tmpfile
                        status_number="$status_pptp"
                        ;;
		*)
			echo "wanmode 3 (unknown)" > $wan_mode_det_tmpfile
			status_number="$status_static_ornot"
			;;
	esac

	if [ "$wan_mode_det" = "$2" -a "$wan_mode_det" != "unknown" ]; then
		status_number="$status_already"
	fi
	write_status $status_number $3
}

#----------------------------------

write_status $status_initializing $status_file
wan_mode_ori=$(nvram get wan_proto)
write_status $status_0_percent $status_file
/usr/bin/detcable
if [ $? -eq 1 ] || [ ! -f /usr/bin/detcable ]; then
#	. /demo/firewall.sh stop > /dev/null 2>&1
	/sbin/cmdwan stop > /dev/null 2>&1
	wan_mode_det="unknown"
	if detect_pppoe; then
		wan_mode_det="pppoe"
	elif detect_bigpond; then
		wan_mode_det="bigpond"
	elif detect_pptp; then
		wan_mode_det="pptp"
	elif detect_dhcp; then
		wan_mode_det="dhcp"
	elif mac_spoofing && detect_dhcp; then
		/usr/sbin/nvram set wan_ether_mac_assign=1
		wan_mode_det="dhcp"
	elif mac_spoofing && detect_pptp; then
		/usr/sbin/nvram set wan_pptp_mac_assign=1
		wan_mode_det="pptp"
	fi	
	/sbin/cmdwan restart > /dev/null 2>&1
	write_status $status_100_percent $status_file
	write_final_status "$wan_mode_det" "$wan_mode_ori" "$status_file"
else	# /usr/bin/detcable fail
	write_status $status_100_percent $status_file
	write_status $status_plug_off $status_file
fi

