config_wan()
{
	$nvram set wan_endis_spi=$1
	$nvram set wan_endis_dmz=$2
	$nvram set dmz_ipaddr="$3"
	$nvram set wan_endis_rspToPing=$4
	$nvram set wan_nat_fitering=$6
	$nvram set wan_nat_fitering=$5
	basic_type=$($nvram get internet_type)
	ppp_login_type=$($nvram get internet_ppp_type)
	if [ $basic_type -eq 0 ];then
		if [ $ppp_login_type -eq 0 ];then
			$nvram set wan_pppoe_mtu=$6
		elif [ $ppp_login_type -eq 1 ];then
			$nvram set wan_pptp_mtu=$6
		elif [ $ppp_login_type -eq 3 ];then
			$nvram set wan_mulppp_mtu=$6
		else
			$nvram set wan_dhcp_mtu=$6
		fi
	else
		$nvram set wan_dhcp_mtu=$6
	fi
	$nvram set forfirewall="wan_setup"
}
