config_scienario() 
{
	$nvram set scienario=$1
}

config_scienario2()
{
        $nvram set scienario2=$1
}

config_scienario3()
{
        $nvram set scienario3=$1
}
