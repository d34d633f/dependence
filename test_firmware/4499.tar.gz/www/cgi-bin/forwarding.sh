get_proto() #$1:0 -- tcp, 1--udp, 2--all
{
	if [ "$1" = "0" ]; then
		echo -n "tcp"
	elif [ "$1" = "1" ]; then
		echo -n "udp"
	else
		echo -n "*"
	fi
}

config_forwarding_add()
{
	add_num=$(ls /tmp/configs | grep forwarding | grep -v ^size | wc -l)
	add_num=$(($add_num+1))
	$nvram set forwarding$add_num="$1 $2 $3 $4 $5 0"
	if [ "$6" = "1" ];then
		add_num=$(($add_num+1))
		$nvram set forwarding$add_num="$1 TCP 1503 1503 $5 1"
	fi
	$nvram set fw_port_ip$add_num="$3-$4>$5:$3-$4,$(get_proto $2),on"
	$nvram set port_forward_trigger="0"
	$nvram set forfirewall="port_forward"
}

config_forwarding_editnum()
{
	$nvram set portforward_editnum=$1
	$nvram set forfirewall="port_forward"
}

config_forwarding_edit()
{
	edit_num=$($nvram get portforward_editnum)
	total_num=$(ls /tmp/configs | grep forwarding | grep -v ^size | wc -l)
	if [ $edit_num -lt $total_num ];then
		serflag_num=$(($edit_num+1))
		serflag=`$nvram get forwarding$serflag_num | awk '{print $6 }'`
		if [ "$serflag" = "0" ];then
			if [ "$6" = "0" ];then
				$nvram set forwarding$edit_num="$1 $2 $3 $4 $5 0"
			else
				$nvram set forwarding$edit_num="$1 $2 $3 $4 $5 0"
				config_forwarding_insert $edit_num
			fi
		else
			if [ "$6" = "1" ];then
				$nvram set forwarding$edit_num="$1 $2 $3 $4 $5 0"
				$nvram set forwarding$serflag_num="$1 TCP 1503 1503 $5 1"
			else
				$nvram set forwarding$edit_num="$1 $2 $3 $4 $5 0"
				config_forwarding_del $serflag_num
			fi
		fi
	else 
		if [ "$6" = "0" ];then
				$nvram set forwarding$edit_num="$1 $2 $3 $4 $5 0"
		else
				$nvram set forwarding$edit_num="$1 $2 $3 $4 $5 0"
				config_forwarding_insert $edit_num
		fi
	fi
	$nvram set fw_port_ip$add_num="$3-$4>$5:$3-$4,$(get_proto $2),on"
	$nvram set port_forward_trigger="0"
	$nvram set forfirewall="port_forward"
}

config_forwarding_del()
{
	serflag_num=$(($1+1))
	rm -f /tmp/configs/forwarding$1
	serflag=`$nvram get forwarding$serflag_num | awk '{print $6 }'`
	if [ "$serflag" = "1" ];then
		rm -f /tmp/configs/forwarding$serflag_num
	fi
	$nvram set fw_port_ip$1
	$nvram show | grep forwarding | grep -v ^size | sort -n > /tmp/aa
	cat /tmp/aa | /bin/grep 'forwarding[0-9]=' > /tmp/cc
	cat /tmp/aa | /bin/grep 'forwarding[0-9][0-9]=' >> /tmp/cc
	mv /tmp/cc /tmp/aa
	$nvram set port_forward_trigger="0"
	line=`grep "forwarding" -c /tmp/aa`
	num=1
	while (test $num -le $line)
	do
		name=`sed ''"$num"'p' -n /tmp/aa | sed 's/forwarding.*=//'`
		forwarding_name=forwarding$num
		$nvram set $forwarding_name="$name"
		num=$(($num+1))
	done
	if [ $1 != $num ];then
		rm -f /tmp/configs/forwarding$num 
		$nvram set fw_port_ip$1
	fi
	rm -f /tmp/aa
	$nvram set forfirewall="port_forward"
}

config_forwarding_insert()
{
	$nvram show | grep forwarding | grep -v ^size > /tmp/aa
	cat /tmp/aa | /bin/grep 'forwarding[0-9]=' > /tmp/cc
	cat /tmp/aa | /bin/grep 'forwarding[0-9][0-9]=' >> /tmp/cc
	mv /tmp/cc /tmp/aa
	line=`grep "forwarding" -c /tmp/aa`
	num=$1
	new_num=$(($1+1))
	new_line=$(($line+1))
	while (test $line -gt $num)
	do
		name=`sed ''"$line"'p' -n /tmp/aa | sed 's/forwarding.*=//'`
		forwarding_name=forwarding$new_line
		$nvram set $forwarding_name="$name"
		line=$(($line-1))
		new_line=$(($new_line-1))
	done
	addname=`$nvram get forwarding$1 | awk '{print $1 }'`
	addip=`$nvram get forwarding$1 | awk '{print $5 }'`
	if [ $line -gt $num ];then
		$nvram set forwarding$new_num="$addname TCP 1503 1503 $addip 1"
	elif [ $line -eq $num ];then
		$nvram set forwarding$new_line="$addname TCP 1503 1503 $addip 1"
	fi
	rm -f /tmp/aa
}
