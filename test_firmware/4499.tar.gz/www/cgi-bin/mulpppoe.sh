config_mulpppoe_add()
{
	add_num=$(ls /tmp/configs | grep mulpppoe_setting | grep -v ^size | wc -l)
	add_num=$(($add_num+1))
	$nvram set mulpppoe_setting$add_num="$1 $2 $3 $4 $5 $6 $7" 
	$nvram set count_mulpppoe=$add_num
}

config_mulpppoe_editnum()
{
	$nvram set mul_editnum=$1
}

config_mulpppoe_addnum()
{
	$nvram set mul_addnum=$1
}

config_mulpppoe_edit()
{
	edit_num=$($nvram get mul_editnum)
	$nvram set mulpppoe_setting$edit_num="$1 $2 $3 $4 $5 $6 $7" 
}

config_mulpppoe_del()
{
	rm -f /tmp/configs/mulpppoe_setting$1 
	$nvram show | grep mulpppoe_setting | grep -v ^size > /tmp/aa
	cat /tmp/aa | /bin/grep 'mulpppoe_setting[0-9]=' > /tmp/cc
	cat /tmp/aa | /bin/grep 'mulpppoe_setting[0-9][0-9]=' >> /tmp/cc
	mv /tmp/cc /tmp/aa
	line=`grep "mulpppoe_setting" -c /tmp/aa`
	num=1
	while (test $num -le $line)
	do
		name=`sed ''"$num"'p' -n /tmp/aa | sed 's/mulpppoe_setting.*=//'`
		mulpppoe_name=mulpppoe_setting$num
		$nvram set $mulpppoe_name="$name"
		num=$(($num+1))
	done
	if [ $1 != $num ];then
		rm -f /tmp/configs/mulpppoe_setting$num 
	fi
	rm -f /tmp/aa
	add_num=$(ls /tmp/configs | grep mulpppoe_setting | grep -v ^size | wc -l)
	add_num=$(($add_num+0))
	$nvram set count_mulpppoe=$add_num
}

config_mulpppoe_apply()
{
	$nvram set wan_proto="mulpppoe1"
	$nvram set internet_type="0"
	$nvram set internet_ppp_type="3"
	$nvram set wan_mulpppoe1_username=$1
	$nvram set wan_mulpppoe1_passwd=$2
	$nvram set wan_mulpppoe1_service=$3
	$nvram set wan_mulpppoe1_idletime=$(($4*60))
	$nvram set wan_mulpppoe1_wan_assign=$5
	$nvram set wan_mulpppoe1_ip=$6
	$nvram set wan_mulpppoe1_dns_assign=$7
	$nvram set wan_ether_dns1=$8
	$nvram set wan_ether_dns2=$9
	$nvram set wan_mulpppoe2_session=${10}
	$nvram set wan_mulpppoe2_policy=${11}
	$nvram set wan_mulpppoe2_username=${12}
	$nvram set wan_mulpppoe2_password=${13}
	$nvram set wan_mulpppoe2_servicename=${14}
	$nvram set static_conflict=${15} 
	if [ "${10}" = "2" ];then
		$nvram set wan_mulpppoe2_east_username=${12}
		$nvram set wan_mulpppoe2_east_password=${13}
	fi
	if [ "${10}" = "1" ];then
		$nvram set wan_mulpppoe2_west_username=${12}
		$nvram set wan_mulpppoe2_west_password=${13}
	fi
	if [ "${10}" = "3" ];then
		$nvram set wan_mulpppoe2_other_username=${12}
		$nvram set wan_mulpppoe2_other_password=${13}
	fi
	$nvram set change_wan_type=${16}
	$nvram set run_test="${17}"
        $nvram set wan_endis_dod="${18}"

}
