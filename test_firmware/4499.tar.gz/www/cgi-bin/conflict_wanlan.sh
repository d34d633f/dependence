#!/bin/sh
LAN_IP="/tmp/configs/lan_ipaddr"
LAN_MASK="/tmp/configs/lan_netmask"
DHCP_START="/tmp/configs/dhcp_start"
DHCP_END="/tmp/configs/dhcp_end"

local ret=0
ip0=$(/usr/sbin/nvram get lan_ipaddr | sed 's/\([0-9]*.[0-9]*.[0-9]*\).*/\1/')

if [ "$ip0" = "192.168.1" ] ; then
	ret=1
elif [ "$ip0" = "10.0.0" ] ; then
	ret=2
fi

case "$ret" in
	1)
	echo 10.0.0.1 > $LAN_IP
	echo 10.0.0.2 > $DHCP_START
	echo 10.0.0.254 > $DHCP_END
	;;
	2)
	echo 172.16.0.1 > $LAN_IP
	echo 172.16.0.2 > $DHCP_START
	echo 172.16.0.254 > $DHCP_END
	;;
	0)
	echo 192.168.1.1 > $LAN_IP
	echo 192.168.1.2 > $DHCP_START
	echo 192.168.1.254 > $DHCP_END
	;;
esac

echo 255.255.255.0 > $LAN_MASK
