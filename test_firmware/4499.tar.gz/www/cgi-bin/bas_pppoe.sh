config_pppoe()
{
	$nvram set wan_proto="pppoe"
	$nvram set internet_type="0"
	$nvram set internet_ppp_type="0"
	$nvram set wan_pppoe_username=$1
	$nvram set wan_pppoe_passwd=$2
	$nvram set wan_pppoe_service=$3
	$nvram set wan_pppoe_idletime=$(($4*60))
	$nvram set wan_pppoe_wan_assign=$5
	$nvram set wan_pppoe_ip=$6
	$nvram set wan_pppoe_dns_assign=$7
	$nvram set wan_ether_dns1=$8
	$nvram set wan_ether_dns2=$9	
	$nvram set static_conflict=${10}	
	$nvram set change_wan_type=${11}
	$nvram set run_test="${12}"
	$nvram set wan_endis_dod="${13}"
}
