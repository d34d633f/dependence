#!/bin/sh

nvram="/usr/sbin/nvram"
awk="/www/cgi-bin/shawk.sh"
iptables="/usr/sbin/iptables"
ifconfig="/sbin/ifconfig"
lan_if="br0"
lan_ip=`$ifconfig $lan_if | grep "inet addr:" | sed -e 's/:/ /g' | $awk -F -n3`
lan_mask=`$ifconfig $lan_if | grep "Mask:" | sed -e 's/:/ /g' | $awk -F -n7`
class_lan=$lan_ip/$lan_mask
wan_if=`$nvram get wan_ifname`
[ "$($nvram get wan_proto)" = "pppoe" -o "$($nvram get wan_proto)" = "pptp" -o "$($nvram get wan_proto)" = "l2tp" -o "$($nvram get wan_proto)" = "mulpppoe1" ] && wan_if=ppp0

port_trigger_start()
{
	timeout=`$nvram get porttrigger_timeout`
	disable_port_trigger=`$nvram get disable_port_trigger`
	if [ $disable_port_trigger -eq 0 ] ; then
		$iptables -t nat -A port_trigger_dnat -j TRIGGER --trigger-type dnat
		$iptables -A port_trigger_fwd -j TRIGGER --trigger-type in
		num=1
		total_num=$(ls /tmp/configs/triggering* | grep triggering | grep -v ^size -c)
		while [ $num -le $total_num ] ;
		do
			service_entry=`$nvram get triggering$num`
			enable_type=`echo $service_entry | $awk -F -n9`
			if [ $enable_type -eq 1 ] ; then
				service_user=`echo $service_entry | $awk -F -n3`
				[ $service_user = "any" ] && service_user=$class_lan
				service_type=`echo $service_entry | $awk -F -n4`
				trigger_port=`echo $service_entry | $awk -F -n5`
				starting_port=`echo $service_entry | $awk -F -n7`
				ending_port=`echo $service_entry | $awk -F -n8`
				connection_type=`echo $service_entry | $awk -F -n6`
				[ $connection_type = "TCP/UDP" ] && connection_type="all"
			
				$iptables -A port_trigger_fwd -i $lan_if -o $wan_if -p $service_type -s \
					$service_user --dport $trigger_port -j TRIGGER --trigger-type out \
					--trigger-proto $connection_type --trigger-match $trigger_port \
					--trigger-relate $starting_port-$ending_port --trigger-timeout $timeout
			fi
			num=$(($num+1))
		done 
	fi
}
port_trigger_stop()
{
	$iptables -t nat -F port_trigger_dnat
	$iptables -F port_trigger_fwd
}

case "$1" in
	start)
		port_trigger_start
		;;
	stop)
		port_trigger_stop
		;;
	restart)
		port_trigger_stop
		port_trigger_start
		;;
	*)
		logger -- "I do not know what you want me to do"
		;;
esac
