config_welcome()
{
	$nvram set internet_type="$1"
	$nvram set internet_ppp_type="$2"
	if [ "$1" = "0" -a "$2" = "0" ];then
		$nvram set wan_proto="pppoe"
	elif [ "$1" = "0" -a "$2" = "1" ];then
		$nvram set wan_proto="pptp"
	elif [ "$1" = "0" -a "$2" = "2" ];then
		$nvram set wan_proto="bigpond"	
	elif [ "$1" = "1" -a "$2" = "0" -a "${17}" = "0" ];then
		$nvram set wan_proto="dhcp"
	else
		$nvram set wan_proto="static"
	fi		
	$nvram set wl_country="$3"
	$nvram set wl_ssid="$4"
	$nvram set wl_channel="$5"
	$nvram set wl_hidden_channel="$5"
	$nvram set wl_sectype="$6"
	$nvram set wl_wpa1_psk="$7"
	$nvram set wl_wpa2_psk="$8"
	$nvram set wl_wpas_psk="$9"
	$nvram set wl_sec_wpaphrase_len="${10}"
	$nvram set wl_key1="${11}"
	$nvram set wl_key="1"
	$nvram set key_length="${12}"
	$nvram set dns_hijack="${13}"
	$nvram set wan_ipaddr="${14}"
	$nvram set wan_netmask="${15}"
	$nvram set wan_gateway="${16}"	
	$nvram set wan_ether_wan_assign="${17}"
	$nvram set wan_ether_dns1="${18}"
	$nvram set wan_ether_dns2="${19}"	
	$nvram set wan_hostname="${20}"
	$nvram set wan_domain="${21}"
	$nvram set wan_pppoe_username="${22}"
	$nvram set wan_pppoe_passwd="${23}"
	$nvram set wan_pppoe_service="${24}"
	$nvram set wan_pppoe_idletime="$((${25}*60))"	
	$nvram set wan_pppoe_wan_assign="${26}"
	$nvram set wan_pppoe_ip="${27}"
	$nvram set wan_pptp_username="${28}"
	$nvram set wan_pptp_password="${29}"
	$nvram set wan_pptp_idle_time="$((${30}*60))"
	$nvram set wan_pptp_local_ip="${31}"
	$nvram set wan_pptp_server_ip="${32}"
	$nvram set wan_pptp_connection_id="${33}"
	$nvram set wan_pptp_wan_assign="${34}"
	$nvram set wan_bpa_username="${35}"
	$nvram set wan_bpa_password="${36}"
	$nvram set wan_bpa_servicename="${37}"
	$nvram set wan_bpa_idle_time="$((${38}*60))"	
	$nvram set blank_status="0"
	$nvram set endis_wl_radio=1
	$nvram set view_wizard="0"
	$nvram set after_welcome="1"
}

config_welcome_adva_nohijack()
{
	$nvram set dns_hijack=0
	$nvram set endis_wl_radio=1
	$nvram set view_wizard="0"
	$nvram set after_welcome="1"
}
