config_lan() #$2: lan ip, $3:lan netmask, $4:lan dhcp mode, $5:dhcp ip start, $6:dhcp ip end,  $7:network_flag $8:ip_flag $9:network $10:dmz_ip ${11{:bs_trustedip $13:network2_flag, if lan ip is not changed, and subnet is changed.
{
	endis_wl_radio=$($nvram get endis_wl_radio)
	wds_endis_fun=$($nvram get wds_endis_fun)
	wds_repeater_basic=$($nvram get wds_repeater_basic)
	
	$nvram set netbiosname=$1
	if [ $endis_wl_radio -eq 1 -a $wds_endis_fun -eq 1 -a $wds_repeater_basic -eq 0 ];then
		$nvram set repeater_ip=$2
	else
		$nvram set lan_ipaddr=$2
	fi
	$nvram set lan_netmask=$3
	if [ "$4" = "1" ];then
		$nvram set lan_dhcp=1
		$nvram set dhcp_start=$5
		$nvram set dhcp_end=$6
	else
		$nvram set lan_dhcp=0
	fi
	if [ "$7" = "1" ];then
		for file in `ls /tmp/configs | grep forwarding | grep -v ^size`
		do
			 new_info=`sed "s/[0-9]*\.[0-9]*\.[0-9]*/$9/" /tmp/configs/$file`
			 $nvram set $file="$new_info"
		done
		for file in `ls /tmp/configs | grep triggering | grep -v ^size`
		do
			 new_info=`sed "s/[0-9]*\.[0-9]*\.[0-9]*/$9/" /tmp/configs/$file`
			 $nvram set $file="$new_info"
		done
		for file in `ls /tmp/configs | grep reservation | grep -v ^size`
		do
			 new_info=`sed "s/[0-9]*\.[0-9]*\.[0-9]*/$9/" /tmp/configs/$file`
			 $nvram set $file="$new_info"
		done
		for file in `ls /tmp/configs | grep block_services | grep -v ^size`
		do
			 new_info=`sed "s/[0-9]*\.[0-9]*\.[0-9]*/$9/g" /tmp/configs/$file`
			 $nvram set $file="$new_info"
		done		
		$nvram set dmz_ipaddr="$10"
		$nvram set block_trustedip="${11}"
	fi
	if [ "x${12}" = "x" ];then
		$nvram set rip_version=0
                $nvram set rip_direction=0
	else
		$nvram set rip_version=${12}
		$nvram set rip_direction=${13}
	fi
	if [ "${14}" = "1" ];then 
        rm -f /tmp/configs/forwarding* 
        rm -f /tmp/configs/triggering* 
        rm -f /tmp/configs/reservation* 
        rm -f /tmp/configs/block_services* 
    fi 
	   $nvram set forfirewall="lan_setup"
}
