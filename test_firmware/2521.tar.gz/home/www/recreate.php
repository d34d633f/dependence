<?php
	ob_start();
	if(isset($_GET['username'])==false){
         header('location:index.php');
     }     
	else
	{
	function getLoginUser()
	{
		$file = '/tmp/sessionid';
		if (!file_exists($file)) return '';
		$fp = fopen($file, "rb");
		if (!$fp) return '';
		$str = file_get_contents($file);
		fclose($fp);
		$strArr = explode(",",$str);
		return $strArr[2].",".$strArr[3].",".$strArr[4];
	}

	session_start();
	$loggeduser=getLoginUser();
	@unlink('/tmp/sessionid');
	session_destroy();
	
	session_start();
	$currentuser=explode(",",$loggeduser);
	$_SESSION['username']   = $currentuser[0];
	$_SESSION['previlige']   = $currentuser[1];
	$_SESSION['user_logged']   = $currentuser[2];
	$fp = fopen('/tmp/sessionid', 'w');
	fwrite($fp, session_id().','.$_SERVER['REMOTE_ADDR'].','.$_SESSION['username'].','.$_SESSION['previlige'].','.$_SESSION['user_logged']);
	fclose($fp);
	echo 'recreateok';
	}
	ob_end_flush();
?>
