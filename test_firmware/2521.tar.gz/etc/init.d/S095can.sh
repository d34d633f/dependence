# socketCAN & PEAK driver loading
if [ ! ${PLATFORM} ]; then

insmod /lib/modules/socket-CAN/can.ko
insmod /lib/modules/socket-CAN/can-raw.ko
insmod /lib/modules/socket-CAN/can-bcm.ko
insmod /lib/modules/socket-CAN/can-isotp.ko
insmod /lib/modules/socket-CAN/vcan.ko
insmod /lib/modules/peak-linux-driver/pcan.ko

/sbin/ifconfig can0 up
/sbin/ifconfig can1 up
/sbin/ifconfig vcan0 up

fi
