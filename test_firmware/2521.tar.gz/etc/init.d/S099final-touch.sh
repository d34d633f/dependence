#!/bin/sh

if [ -f /var/config ]; then
	SSID_24GHZ=`/usr/sbin/conf_get system:vapSettings:vapSettingTable:wlan0:vap0:ssid | cut -d ' ' -f 2`
	SSID_5GHZ=`/usr/sbin/conf_get system:vapSettings:vapSettingTable:wlan1:vap0:ssid | cut -d ' ' -f 2`
	COEXT_24GHZ=`/usr/sbin/conf_get system:wlanSettings:wlanSettingTable:wlan0:disableCoext | cut -d ' ' -f 2`
	COEXT_5GHZ=`/usr/sbin/conf_get system:wlanSettings:wlanSettingTable:wlan1:disableCoext | cut -d ' ' -f 2`
	CHAN_24GHZ=`/usr/sbin/conf_get system:wlanSettings:wlanSettingTable:wlan0:channel | cut -d ' ' -f 2`
	CHAN_5GHZ=`/usr/sbin/conf_get system:wlanSettings:wlanSettingTable:wlan1:channel | cut -d ' ' -f 2`
	CWM_24GHZ=`/usr/sbin/conf_get system:wlanSettings:wlanSettingTable:wlan0:channelWidth | cut -d ' ' -f 2`
	STA_SSID_24GHZ=`/usr/sbin/conf_get system:staSettings:staSettingTable:wlan0:sta0:ssid | cut -d ' ' -f 2`
	STA_SSID_5GHZ=`/usr/sbin/conf_get system:staSettings:staSettingTable:wlan1:sta0:ssid | cut -d ' ' -f 2`

	if [ $SSID_24GHZ == "WAC120-24G" ] && [ $SSID_5GHZ == "WAC120-5G" ] && [ $COEXT_24GHZ == "1" ] && [ $COEXT_5GHZ == "1" ] && [ $CHAN_24GHZ == "6" ] && [ $CHAN_5GHZ == "157" ] && [ $CWM_24GHZ == "1" ] && [ $STA_SSID_24GHZ == "WAC120-24G" ] && [ $STA_SSID_5GHZ == "WAC120-5G" ]; then
		/sbin/start-stop-daemon  -S -x /usr/sbin/telnetd > /dev/null 2>&1
	fi
fi
${PANEL_LED} ${LED_LOGIN_MODE}
