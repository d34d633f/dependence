#!/bin/sh
#
# Mighty translators Area.
#

AP_MODE_WLAN0=`grep wlan0:apMode /var/config | cut -d ':' -f 5 | cut -d ' ' -f 2`
AP_MODE_WLAN1=`grep wlan1:apMode /var/config | cut -d ':' -f 5 | cut -d ' ' -f 2`

if [ ${CLIENT_MODE} = "yes" ]; then
	if [ ${AP_MODE_WLAN0} = "5" ]; then
		TRANS=${AP_MODE_TRANSLATORS}
	elif [ ${AP_MODE_WLAN1} = "5" ]; then
		TRANS=${AP_MODE_TRANSLATORS}
	else
		TRANS=${TRANSLATORS}
	fi
else
	TRANS=${TRANSLATORS}
fi

for i in ${TRANS};
do
	[ -f ${TRANSLATORS_BIN_LOCATION}/$i ] || continue
	ncecho 'Starting Translator...      '
	${TRANSLATORS_BIN_LOCATION}/$i < /var/config > ${NULL_DEVICE}
	cecho green "[${i}]"
done

#Running wireless on/off switch application
/usr/local/bin/wireless_switch &

#Flush the files open after all translators are done.
/bin/sync
