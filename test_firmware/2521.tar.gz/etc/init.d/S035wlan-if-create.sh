#!/bin/sh

vap_and_wds()
{
	ncecho 'Creating vap interface.     '

		for i in `seq 0 $(expr $NO_OF_RADIOS - 1)`;do
			for j in `seq 0 $(expr $NO_OF_VAPS - 1)`; do
				${WLANCONFIG} wifi${i}vap$j create wlandev wifi${i} wlanmode ap > ${NULL_DEVICE}
				if [ ${j} = 0 ]; then
					${IFCONFIG} wifi${i}vap$j txqueuelen 200
				else	
					${IFCONFIG} wifi${i}vap$j txqueuelen 50
				fi
			done
		done
		cecho green '[DONE]'


		ncecho 'Creating wds interface.     '

		for i in `seq 0 $(expr $NO_OF_RADIOS - 1)`;do
			for j in `seq 0 $(expr $NO_OF_WDS - 1)`; do
				${WLANCONFIG} wifi${i}wds$j create wlandev wifi${i} wlanmode ap> ${NULL_DEVICE}
				${WLANCONFIG} wifi${i}wds$j nawds mode 2
				${IFCONFIG} wifi${i}wds$j mtu 1504 txqueuelen 50
				/sbin/iwpriv wifi${i}wds$j wds 1
			done
		done
		cecho green '[DONE]'
}

client_mode_wlan0()
{
		ncecho 'Creating sta interface.     '
		${WLANCONFIG} wifi0vap0 create wlandev wifi0 wlanmode sta > ${NULL_DEVICE}
		${IFCONFIG} wifi0vap0 txqueuelen 200
		cecho green '[DONE]'
}

client_mode_wlan1()
{
		ncecho 'Creating sta interface.     '
		${WLANCONFIG} wifi1vap0 create wlandev wifi1 wlanmode sta > ${NULL_DEVICE}
		${IFCONFIG} wifi1vap0 txqueuelen 200
		cecho green '[DONE]'
}

AP_MODE_WLAN0=`grep wlan0:apMode /var/config | cut -d ':' -f 5 | cut -d ' ' -f 2`
AP_MODE_WLAN1=`grep wlan1:apMode /var/config | cut -d ':' -f 5 | cut -d ' ' -f 2`

if [ ${CLIENT_MODE} = "yes" ]; then
	if [ ${AP_MODE_WLAN0} = "5" ]; then
		client_mode_wlan0
	elif [ ${AP_MODE_WLAN1} = "5" ]; then
		client_mode_wlan1
	else
		vap_and_wds
	fi
else
	vap_and_wds
fi
